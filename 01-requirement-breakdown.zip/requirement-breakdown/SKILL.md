---
name: requirement-breakdown
description: 把用户粘贴的需求原文、PRD 或原型截图拆解为功能点级别的结构化输出，供产品、研发、QA 复用。适用场景：大需求拆分、需求评审前整理、研发交接前准备。
---

# 需求拆解

将散乱的需求材料拆解为功能点级别的结构化输出，作为后续 PRD 生成、研发交接、测试用例等技能的输入。

## 支持的输入
- 粘贴的需求文字
- 上传的 PRD 文档
- 上传的原型截图
- 以上混合输入

## 默认输出

除非用户指定格式，始终同时输出：
1. 三列 CSV（fenced csv 块）
2. 结构化 JSON（fenced json 块）
3. 文字摘要：核心模块、高风险点、待确认项

## CSV 格式

固定三列：`"一级模块","功能点","实现详细描述"`

规则：每字段双引号包裹；`"` 转义为 `""`；每行重复模块名；禁止用 Markdown 表格代替。

## JSON 格式

```json
{
  "summary": {
    "input_type": "prd|screenshot|pasted_text|mixed",
    "module_count": 0,
    "feature_count": 0,
    "core_modules": [],
    "risks": [],
    "pending_questions": []
  },
  "modules": [{
    "module_name": "",
    "features": [{
      "feature_name": "",
      "scenario": "",
      "trigger": "",
      "rules": [],
      "validations": [],
      "exceptions": [],
      "permissions": [],
      "data_impact": [],
      "pending_questions": []
    }]
  }]
}
```

## 拆解流程

1. 识别输入类型
2. 提取事实（业务目标、模块、用户行为、规则、状态、权限、数据对象、异常、不确定项）
3. 拆分功能点 — 参考 `references/decomposition-rules.md`
4. 构建 CSV 和 JSON — 参考 `references/output-template.md`
5. 质量自检 — 对照 `references/quality-checklist.md`

## `实现详细描述` 写法

```
场景：...；触发：...；规则：...；校验：...；异常：...；权限：...；数据影响：...；待确认：...；
```

不需要每项都有，但每行必须具体到可以估时和出测试用例。

## 基本原则

- 不猜测无依据的事实，不确定项写 `待确认`
- 模块名和功能点名保持简洁、稳定，避免"相关功能""管理能力"等模糊命名
- 默认中文输出

## 参考文件

- `references/decomposition-rules.md`
- `references/output-template.md`
- `references/quality-checklist.md`
