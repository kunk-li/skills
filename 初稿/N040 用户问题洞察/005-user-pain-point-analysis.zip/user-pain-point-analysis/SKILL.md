---
name: user-pain-point-analysis
description: analyze requirement context, feedback, interview notes, tickets, or behavior descriptions to identify core user pain points, affected roles, impact scope, evidence strength, and the gap between current and desired experience. use when the user needs demand translated into user problems, friction sources, and consequence statements before value assessment, prioritization, journey mapping, or solution discussion.
---

# 用户痛点分析

## Overview

把需求背景、反馈和现状描述转成清晰的用户问题陈述。
重点解释“谁在什么任务下遇到了什么阻碍，造成了什么后果”，不直接替代优先级决策或方案设计。

## Working rules

- 把痛点写成用户问题，不写成功能建议。
- 关键结论统一标注：`已确认`、`合理推断`、`待确认`。
- 区分角色、任务、触发场景、影响后果，避免把多个用户群体混成一个痛点。
- 根因可以推断，但必须明确是“可能根因”而不是既成事实。

## Workflow

1. 定位分析对象：明确用户角色、任务目标、触发场景、当前做法。
2. 提取摩擦事件：从等待、失败、重复输入、规则不清、反馈延迟、信息缺失、绕路操作等现象里抽取问题线索。
3. 归纳痛点：把相似问题合并成主题，但保留关键角色或场景差异。
4. 评估影响：分别说明对效率、成功率、出错率、协同成本、满意度、收入或转化的影响。
5. 拆分层级：区分表象问题、可能根因、当前限制条件。
6. 标注证据：指出哪些来自原始材料，哪些是合理推断，哪些仍需补充访谈或数据验证。

## Standard pain statement

默认优先使用以下句式整理单个痛点：

`当 [角色] 试图在 [场景] 完成 [任务] 时，会因为 [摩擦/阻碍] 导致 [直接后果]，进一步带来 [业务或体验影响]。`

## Input expectations

适合接收：

- 需求背景补全结果
- 访谈摘录、客服反馈、工单、聊天记录、行为描述、业务现状说明
- 任何能够体现“用户做什么、哪里失败、造成什么影响”的材料

## Output template

### 1. 痛点总览

- 核心角色：
- 核心任务：
- 最主要的 3-5 个痛点：

### 2. 痛点卡片

| pain id | 角色 | 场景/任务 | 痛点陈述 | 直接后果 | 影响范围 | 证据强度 | 证据状态 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| P1 |  |  |  |  |  | 强 / 中 / 弱 | 已确认 / 合理推断 / 待确认 |

### 3. 根因拆分

| pain id | 表象问题 | 可能根因 | 已知限制/边界 | 备注 |
| --- | --- | --- | --- | --- |
| P1 |  |  |  |  |

### 4. 证据与不确定性

| pain id | 主要证据 | 缺什么证据 | 建议补充方式 |
| --- | --- | --- | --- |
| P1 |  |  |  |

## Low-evidence fallback

如果证据不足，至少输出：

1. 候选痛点列表
2. 每个候选痛点对应的最小证据
3. 需要进一步确认的角色、场景或后果

## Quality checklist

- 不把“需要一个功能”当作痛点本身。
- 不把产品方抱怨、研发抱怨、运营抱怨直接等同于用户痛点，除非明确对应到了用户任务。
- 不混淆“用户体验不好”和“业务目标受损”这两类影响，最好分别写出。
- 痛点合并时保留角色差异、流程差异和规则差异。
- 根因分析止于可解释层，不延展成详细解决方案。

## Boundaries and hand-offs

- 上游通常来自 `requirement-context-enrichment`。
- 如果用户要看完整过程中的阶段、触点和断点，交给 `user-journey-analysis`。
- 如果用户要判断“值不值得做”，交给 `requirement-value-assessment`。
- 如果用户要做版本排序，交给 `requirement-priority-assessment`。

## Example requests

- 根据这份需求背景，提炼用户最核心的痛点和影响范围。
- 把客服反馈整理成用户痛点卡片，并标出证据强弱。
- 从访谈记录里抽出用户问题，不要直接写解决方案。
