---
name: user-journey-analysis
description: map the user journey from entry to goal completion using requirement context, flow descriptions, screenshots, service records, or research notes, and highlight stages, goals, actions, touchpoints, blockers, and breakpoints. use when the user needs a structured journey view to understand where friction occurs, where drop-offs happen, or where supporting capabilities are missing before solution design or prioritization.
---

# 用户旅程分析

## Overview

还原用户从起点到目标完成的真实路径，识别关键阶段、动作、触点和断点。
输出重点是“现状旅程和阻塞点”，不是理想化流程图，也不是界面方案。

## Working rules

- 先明确起点、终点、角色和分析目标，再拆阶段。
- 旅程必须按时间顺序展开，不跳步、不倒叙、不把系统内部处理伪装成用户动作。
- 多角色或多旅程场景时，优先分开输出，不把不同用户路径揉成一条线。
- 关键判断统一标注：`已确认`、`合理推断`、`待确认`。

## Workflow

1. 划定边界：明确起点、终点、角色、关键目标和分析范围。
2. 拆阶段：按用户视角拆出阶段、目标、动作和系统触点。
3. 标注反馈：补充每一步的系统反馈、等待状态、失败状态或信息缺失。
4. 识别断点：抓出等待、失败、绕路、反复确认、信息不透明、规则冲突等问题点。
5. 解释影响：说明断点触发条件、受影响对象、后果和可能原因。
6. 汇总重点：输出最值得关注的高影响断点和信息缺口。

## Multi-journey rule

遇到以下情况时，优先拆成多条旅程或多泳道：

- 不同角色的目标不同
- 起点或终点不同
- 决策路径明显分叉
- 同一流程在不同条件下规则完全不同

## Input expectations

适合接收：

- 需求背景补全结果
- 流程描述、原型说明、客服案例、访谈记录、业务规则摘要、页面截图
- 能体现“用户何时进入、做了什么、系统如何反馈、哪里卡住”的任何材料

## Output template

### 1. 旅程总览

- 角色：
- 起点：
- 终点：
- 核心目标：
- 关键断点：

### 2. 旅程表

| 阶段 | 阶段目标 | 用户动作 | 系统触点/反馈 | 断点/阻塞 | 可能原因 | 证据状态 |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  | 已确认 / 合理推断 / 待确认 |

### 3. 高影响断点

| breakpoint id | 所在阶段 | 触发条件 | 后果 | 影响对象 | 优先级 |
| --- | --- | --- | --- | --- | --- |
| B1 |  |  |  |  | 高 / 中 / 低 |

### 4. 信息缺口

| 缺口 | 影响哪一段旅程 | 为什么重要 | 建议补充方式 |
| --- | --- | --- | --- |
|  |  |  |  |

## Low-evidence fallback

如果材料不足以画出完整旅程，也要输出“简版旅程”：

1. 当前已知阶段
2. 每段最关键动作
3. 已观察到的断点
4. 无法确认的阶段或角色

## Quality checklist

- 不用理想流程替代真实现状。
- 不把用户动作和系统内部处理混在同一列。
- 不把后续优化建议写进当前旅程表，建议只能放在补充说明里。
- 每个断点至少写清“触发条件 + 后果”，不要只写抽象名词。
- 旅程图如果依赖强假设，必须显式标注。

## Boundaries and hand-offs

- 上游通常来自 `requirement-context-enrichment`。
- 如果重点是提炼核心用户问题而不是还原过程，交给 `user-pain-point-analysis`。
- 如果重点是评估价值、成本、风险或优先级，交给对应的规划类 skill。

## Example requests

- 把这个注册到下单的过程梳理成用户旅程，并指出关键断点。
- 根据访谈和现有流程描述，输出一版用户旅程分析。
- 把不同角色的审批流程拆成两条旅程，不要混在一起。
