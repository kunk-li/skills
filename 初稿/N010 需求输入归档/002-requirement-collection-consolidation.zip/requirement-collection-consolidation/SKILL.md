---
name: requirement-collection-consolidation
description: consolidate requirement inputs from multiple sources into a de-duplicated,
  source-aware, and categorized view. use when chatgpt needs to merge meeting notes,
  chats, prds, spreadsheets, screenshots, or pasted requests into one grounded requirement
  set before analysis, prioritization, planning, or handoff.
---

# 需求收集归并

## 作用
汇总多个来源的需求输入，合并重复表达，形成可继续分析的统一需求视图。默认基于会话中已提供的材料工作，不假设外部连接器一定可用。

## 优先吸收的输入
- 需求文档、会议纪要、聊天记录、截图、表格、粘贴文本。
- 来源标签、版本标签、业务线标签、时间信息。
- 多个批次输入时，保留来源映射和时间上下文。
- 若已有上游产物，先吸收其中已确认的事实；若关键信息缺失，先给最佳努力结果，再把假设和待确认项单独列出。

## 不要用于
- 在没有证据时补写用户未提出的需求。
- 擅自做优先级排序、价值判断或冲突裁决。

## 处理步骤
1. 识别来源、时间、业务对象和需求粒度，先统一表述口径。
2. 把重复、近似、互补的内容归并到同一条需求下，并保留来源映射。
3. 按模块、角色、流程阶段或问题类型分类展示。
4. 把冲突、缺口和待确认项单独列出。

## 输出要求
- 默认展示统一需求表述、来源映射、分类标签。
- 冲突项要并列呈现，不擅自替用户裁决。
- 输入很乱时，先给可读结果，再给信息缺口。
- 用户指定输出格式时严格跟随；否则使用下面的默认结构。

## 默认输出结构
```markdown
# 需求归并结果

## 合并后需求清单
- 统一需求：
- 来源：
- 分类：
- 备注：

## 重复 / 冲突说明
- 归并组：
- 差异点：

## 待确认项
- 
```

## 质量要求
- 优先保留事实、原话意图和来源，不凭空补需求。
- 同义不同表述要合并，冲突表述要并列标出。
- 当来源很多时，优先给统一视图，而不是逐条平铺原文。
