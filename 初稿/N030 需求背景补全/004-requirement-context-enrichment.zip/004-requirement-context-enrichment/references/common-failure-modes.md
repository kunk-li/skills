# Common Failure Modes

1. Writing only a summary instead of a working document.
2. Mixing fact, inference, and pending items in one paragraph.
3. Assuming background knowledge the reader does not have.
4. Listing issues without impact or suggested next action.
5. Producing abstract design talk without modules, tables, or concrete examples.
6. Turning ambiguous PRD language into fake certainty.
7. Duplicating upstream analysis without adding the unique value of this skill.
