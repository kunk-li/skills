# Orchestration Guide

## Single-skill mode
- Use this skill alone when the user asks specifically for this deliverable and there is no need to assemble a full PRD-to-design chain.
- In single-skill mode, still produce a complete, readable output for humans. Do not assume other skills have run.

## Multi-skill mode
- When upstream skill outputs are available, absorb them explicitly and say which sections were reused.
- Preserve traceability: keep a small “source of truth” section showing whether a point comes from PRD fact, derived inference, or unresolved item.
- Do not duplicate upstream work mechanically. Summarize upstream outputs and spend most effort on this skill’s unique value.

## Evidence hierarchy
1. Explicit PRD facts
2. Stable inferences from multiple PRD facts
3. Unresolved assumptions that must remain open

## Collaboration contract
- If an upstream skill is missing, fall back to PRD text and state the limitation.
- If a downstream skill is likely, shape output into reusable blocks, tables, and IDs rather than loose prose.
- Always separate confirmed facts, inferred recommendations, and pending items.
