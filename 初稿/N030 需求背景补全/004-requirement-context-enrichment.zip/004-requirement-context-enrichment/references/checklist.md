# Delivery Checklist

- Is the output understandable to a newcomer who has not read the original PRD?
- Are confirmed facts separated from suggestions and unresolved items?
- Are key tables present instead of only long prose?
- Are decision points, ambiguity, and missing evidence clearly marked?
- Does the output name the next downstream skill or next human action?
- Does the output avoid pretending uncertain content is confirmed?
- Is the result directly usable in a meeting, design review, or handoff?
