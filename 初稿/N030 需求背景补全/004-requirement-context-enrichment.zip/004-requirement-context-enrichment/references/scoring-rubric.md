# Scoring Rubric

## 1 - Weak
Generic summary, little structure, poor traceability, not directly usable.

## 2 - Basic
Some structure exists, but newcomer readability, decisions, or implementation value is still weak.

## 3 - Usable
Readable and actionable. Main facts, risks, and pending items are present. Can support a real meeting or design step.

## 4 - Strong
Clear for mixed audiences, high traceability, reusable tables, and strong downstream value.

## 5 - Excellent
Newcomer-friendly, meeting-ready, implementation-aware, and easy to hand off without extra oral explanation.
