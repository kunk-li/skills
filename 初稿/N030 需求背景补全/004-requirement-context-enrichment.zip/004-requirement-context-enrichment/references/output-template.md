# Output Template

Use this default structure unless the user explicitly requests another format.

## 1. 文档用途 / How to use this document
- Explain who should read it and how it should be used.

## 2. 已确认事实
- List only facts directly supported by PRD or by clearly traceable derived outputs.

## 3. 背景与术语速读
- Explain business background in simple language for newcomers.

## 4. 业务背景与目标
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 5. 范围 / 非范围
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 6. 角色与职责
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 7. 关键术语词典
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 8. 端到端业务场景
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 9. 新人易误解点
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 10. 待确认上下文
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 11. 待确认项
- List unresolved items, impact, and who should answer them.

## 12. 下一步
- Recommend the next downstream skill or human action.