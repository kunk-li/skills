# Example IO

## Example input
- PRD for a multi-role OA approval flow with draft, submit, approve, reject, revoke, and audit requirements.

## Good output characteristics
- Explains the business goal in simple language first.
- Identifies actors, states, rules, and unresolved items.
- Uses tables for fields, states, permissions, and decisions.
- Leaves clear next steps for review or design.
