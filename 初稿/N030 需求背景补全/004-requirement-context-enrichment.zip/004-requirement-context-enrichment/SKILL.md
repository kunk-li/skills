---
name: requirement-context-enrichment
description: enrich prd business context for newcomers and downstream review/design. use when the input is mainly prd text and readers do not yet understand business background, business terms, scope boundaries, actors, upstream/downstream dependencies, or why the requirement exists. this skill can be used standalone to produce a readable context brief, or before review-doc-generator and rd-design-generator as the context foundation.
---
# requirement-context-enrichment

## Role / 角色定位
- 把 PRD 先翻译成新人能理解的业务上下文稿。
- 单个可用；多个 skill 组合时作为链路中的稳定节点。

## Single-skill value / 单独使用价值
- 独立产出《业务背景与范围说明》，用于 onboarding、需求预读、会前对齐。
- 即使没有其他 skill 结果，也要产出完整、可读、可交付的 markdown 文档。

## Multi-skill value / 组合使用价值
- 作为评审文档与研发总设计的上游，先把背景、术语、边界讲清。
- 组合使用时，优先吸收上游结构化结果，但不得机械重复上游内容。

## Primary inputs / 主要输入
- 必需：PRD 原文或以 PRD 为唯一来源的结构化分析结果。
- 可选：其他 skill 的派生结果，但只能把它们视为 PRD 派生证据，不可引入代码、数据库现状或口头背景作为事实。

## Required output / 必须输出
输出必须是 Markdown，并覆盖以下核心章节：
- 业务背景与目标
- 范围 / 非范围
- 角色与职责
- 关键术语词典
- 端到端业务场景
- 新人易误解点
- 待确认上下文


## Execution workflow / 执行流程
1. 通读 PRD，先列出显式事实、角色、对象、动作、状态、规则与边界。
2. 如果有上游 skill 结果，先做对齐：哪些结论与 PRD 一致、哪些只是推断、哪些仍未决。
3. 只在 PRD 事实足够支撑时做推断；否则明确标注为待确认项。
4. 生成本 skill 的主交付物，而不是停留在摘要或点评层。
5. 用 `references/checklist.md` 自检，并按 `references/scoring-rubric.md` 自评分。

## Collaboration contract / 协作契约
- 上游：通常只有 PRD 原文。
- 下游：review-doc-generator、036-engineering-requirement-parsing、rd-design-generator。
- 交接要求：输出中必须给出：术语表、角色表、范围表、主流程说明，这些是下游直接可复用的块。

## Rules / 核心规则
- 必须把“已确认事实 / 推断建议 / 待确认项”分层书写。
- 必须优先面向新人、新手、非业务背景读者，先解释再下结论。
- 必须尽量表格化呈现角色、对象、状态、规则、问题、风险、决策项。
- 必须给至少一个具体业务例子或最小场景说明，帮助陌生读者理解。
- 不得把模糊内容写成既定事实。
- 不得只输出 3-5 条摘要结论冒充交付物。

## Quality bar / 质量门槛
- 交付质量最低要达到 rubric 的 3/5（usable）。
- 判定标准：新人不看原 PRD，也能说出“为什么做、谁在用、做什么、不做什么”。
- 如果做不到，必须显式写出缺口与原因。

## Reference files / 参考文件
- `references/output-template.md`：默认输出模板
- `references/checklist.md`：交付前检查清单
- `references/scoring-rubric.md`：质量评分标准
- `references/common-failure-modes.md`：常见失败模式
- `references/orchestration.md`：单 skill / 多 skill 编排说明
- `references/example-io.md`：输入输出示例
