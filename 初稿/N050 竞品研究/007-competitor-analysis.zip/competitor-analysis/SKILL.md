---
name: competitor-analysis
description: analyze competitors or internal alternatives by extracting comparable capabilities, rules, limitations, packaging differences, and workflow patterns for a defined business area or module. use when the user provides notes, screenshots, public materials, demo observations, or experience records and needs a structured competitor comparison before benchmarking, requirement planning, or priority assessment.
---

# 竞品分析

## Overview

把一个或多个竞品在指定业务问题、模块或场景上的做法整理成可比较的分析结果。
重点是复原“它们怎么做、规则有什么差异、限制在哪里、这些差异意味着什么”，不直接替代我方路线决策。

## Working rules

- 先界定分析范围，再选择对比维度，不做泛化的“大而全”扫描。
- 所有关键观察统一标注：`已确认`、`合理推断`、`待确认`。
- 不同版本、不同市场、不同套餐、不同入口的差异必须显式标注，不混成一个结论。
- 不把“未观察到”写成“没有”。
- 洞察可以指出启发，但不要代替产品负责人拍板。

## Workflow

1. 定义范围：明确业务问题、目标模块、目标用户、对比样本和时间范围。
2. 选取维度：从能力、入口、规则、权限、配置性、异常处理、数据口径、协同方式、限制条件、价格/套餐差异中选出最相关的 4-8 个维度。
3. 逐个提取事实：按样本记录已观察到的能力、规则、限制和默认策略。
4. 整理差异：找出谁支持、谁不支持、支持到什么程度、约束是什么。
5. 解释含义：说明差异可能带来的体验影响、运营影响、落地复杂度或定位差异。
6. 沉淀模式：总结行业共性、明显分化点、空白点和证据缺口。

## Dimension selection hints

选择维度时优先遵循：

- 一行只比较一个层级的对象，不把“功能点 + 商业结果”混在一个维度里
- 维度必须能横向复用到所有样本
- 如果任务聚焦模块，优先比较与该模块直接相关的规则和限制，而不是品牌层面的泛描述

## Input expectations

适合接收：

- 需求背景补全结果
- 竞品名单、公开资料、截图、体验记录、评测笔记、版本说明、定价页、帮助中心内容
- 用户自己总结的观察也可以用，但要保留为“观察结论”而不是未经核验的事实

## Output template

### 1. 样本说明

- 分析范围：
- 目标模块 / 场景：
- 对比样本：
- 版本 / 时间说明：

### 2. 对比矩阵

| 维度 | 样本 | 观察结果 | 规则/限制 | 证据状态 | 来源/时间 |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  | 已确认 / 合理推断 / 待确认 |  |

### 3. 关键模式与差异

- 行业共性：
- 明显分化点：
- 需要重点关注的限制：
- 目前无法确认的点：

### 4. 启发与不确定性

| 观察 | 可能启发 | 不确定性/边界 |
| --- | --- | --- |
|  |  |  |

## Low-evidence fallback

如果证据不足以完成完整竞品分析，至少输出：

1. 已确认的样本事实
2. 最重要的差异线索
3. 仍未覆盖的关键维度
4. 需要优先补充验证的样本或页面

## Quality checklist

- 不把能力差异直接写成我方路线结论。
- 不混淆“功能存在”“规则支持”“默认开启”“可配置”这几种不同层级。
- 不忽略入口、权限、套餐、市场差异带来的偏差。
- 不把一个局部页面观察外推成整个平台能力结论。
- 有冲突信息时，保留冲突并说明可能原因。

## Boundaries and hand-offs

- 上游通常来自 `requirement-context-enrichment`。
- 如果用户已经明确指定模块并需要逐项对标，优先交给 `competitor-feature-benchmarking`。
- 如果用户要判断“值不值得做”或“先做什么”，交给价值、成本、风险、优先级类 skill。

## Example requests

- 帮我分析 3 个竞品在审批流配置上的能力、规则和差异。
- 整理这些竞品截图和体验记录，输出能力点与限制对比。
- 比较几个内部替代方案在权限管理上的流程差异和边界条件。
