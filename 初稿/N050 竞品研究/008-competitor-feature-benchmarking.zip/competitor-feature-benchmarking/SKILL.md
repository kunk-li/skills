---
name: competitor-feature-benchmarking
description: benchmark a specified module, page, workflow, or feature set against one or more competitors using explicit, reusable comparison dimensions and a side-by-side structure. use when the user already knows the target scope and needs a focused benchmark, gap analysis, or discussion-ready comparison table instead of a broad market scan.
---

# 竞品功能对标

## Overview

围绕一个已经明确的模块、页面、流程或功能集合做逐项对标。
核心目标是产出可复用、可讨论、可落表的对比结果，而不是把局部模块对标扩展成完整市场策略结论。

## Working rules

- 先锁定模块边界，再建统一维度，再做横向比较。
- 维度必须同层、可复用、可横向比较，不混合能力、效果、价值三个层级。
- 对每一项都标注证据状态：`已确认`、`合理推断`、`待确认`。
- 对“我方现状”不清楚时明确写 `待确认`，不要默认“没有”。

## Workflow

1. 明确对标范围：模块边界、目标角色、场景、入口和时间版本。
2. 设计维度：优先使用能力点、规则、异常处理、配置性、权限、数据可见性、效率体验等维度。
3. 逐项填表：记录我方现状、竞品表现、差距类型和证据来源。
4. 标注差距：把差距分成 `缺失`、`弱支持`、`规则差异`、`体验差异`、`信息不足`。
5. 总结重点：提炼最重要的缺口、优势项和需要进一步确认的内容。

## Input expectations

适合接收：

- 竞品分析结果
- 我方模块说明、竞品名单、截图、体验记录、原型、帮助中心、说明文档
- 用户自己整理的对标维度草稿

## Output template

### 1. 对标概览

- 目标模块：
- 目标角色 / 场景：
- 样本：
- 版本 / 时间说明：

### 2. 对标表

| 维度 | 我方现状 | 竞品表现 | 差距类型 | 差距影响 | 证据状态 | 来源 |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  | 缺失 / 弱支持 / 规则差异 / 体验差异 / 信息不足 |  | 已确认 / 合理推断 / 待确认 |  |

### 3. 差距摘要

- 明显缺口：
- 我方优势：
- 值得重点验证的维度：

### 4. 待确认项

| 项目 | 为什么待确认 | 建议补证方式 |
| --- | --- | --- |
|  |  |  |

## Low-evidence fallback

如果信息不足，至少输出：

1. 已可确认的对标维度
2. 暂时无法判断的维度
3. 当前最关键的差距线索

## Quality checklist

- 不把模块对标写成整体竞品结论。
- 不把“未观察到”误写成“竞品没有”。
- 不用一句抽象评价替代逐项维度，例如“体验更好”必须拆开写清原因。
- 不把我方未知项默认为缺失。
- 如果不同样本覆盖范围不一致，显式注明样本不可完全横向比较的原因。

## Boundaries and hand-offs

- 上游通常来自 `competitor-analysis`。
- 如果用户需要完整市场扫描和模式总结，优先交给 `competitor-analysis`。
- 如果用户接下来要做价值、成本或优先级判断，可以把对标结果作为输入交给对应规划类 skill。

## Example requests

- 对标一下批量审批模块，按入口、规则、异常处理和配置性逐项比较。
- 把这几个竞品在用户权限管理模块上的能力差距整理成表格。
- 对比我方和竞品在导出能力上的规则差异，不要扩展成完整市场分析。
