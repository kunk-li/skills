---
name: requirement-cost-estimation
description: produce a rough requirement cost estimate by outlining likely implementation, data, integration, testing, release, coordination, and change-management effort drivers from requirement context. use when the user needs an early sizing view before detailed technical design, estimation workshops, or scheduling, and needs effort bands plus uncertainty instead of a final engineering commitment.
---

# 需求成本预估

## Overview

在缺少完整技术方案的前提下，对需求投入做早期粗估。
输出关注的是成本来源、投入等级、波动因素和不确定性，不是正式工时承诺或排期承诺。

## Working rules

- 默认输出等级或区间，不伪装成精确工时。
- 成本至少拆成开发成本和非开发成本两大类。
- 关键结论统一标注：`已确认`、`合理推断`、`待确认`。
- 先解释驱动因素，再给等级，不直接拍一个结果。

## Default cost buckets

默认至少考虑以下成本项：

1. 实现改造：前后端、规则引擎、权限、状态机、页面改造
2. 数据成本：数据模型、口径调整、迁移、兼容、历史数据处理
3. 集成成本：接口、外部系统、上下游链路、联调依赖
4. 测试成本：功能测试、回归测试、兼容性验证、边界场景验证
5. 发布协同成本：灰度、培训、配置迁移、运营跟进、上线切换
6. 变更管理成本：沟通、评审、方案反复、需求澄清、版本协调

## Rating guidance

默认使用低 / 中 / 高；必要时可补充区间或 t-shirt size。

- 低：局部变更，依赖少，规则简单，回归范围小
- 中：存在多规则、多状态、单一外部依赖或中等回归成本
- 高：跨系统、数据模型变化、迁移兼容、复杂权限、显著协同成本或大范围回归

## Workflow

1. 判断需求类型：新能力、改造、兼容、联动、流程性调整或规则性调整。
2. 拆成本项：分别估实现、数据、集成、测试、发布协同、变更管理。
3. 识别驱动因素：规则复杂度、状态数量、权限粒度、系统数量、历史兼容、灰度要求、组织协同面。
4. 给出等级：按每项成本给出低 / 中 / 高判断，并说明依据。
5. 暴露不确定性：指出最可能拉高或拉低成本的未知项。
6. 给出推进建议：说明是否建议先补信息、先拆需求或先做技术预研。

## Input expectations

适合接收：

- 需求背景补全结果
- 需求范围、规则复杂度、系统数量、依赖对象、时间约束、历史兼容要求
- 如果没有技术细节，也可以先给投入等级，不要停在“无法评估”

## Output template

### 1. 成本摘要

- 总体投入等级：低 / 中 / 高
- 主要成本来源：
- 估算置信度：高 / 中 / 低

### 2. 成本分项表

| 成本项 | 等级/区间 | 主要驱动因素 | 证据状态 | 说明 |
| --- | --- | --- | --- | --- |
| 实现改造 | 低 / 中 / 高 |  | 已确认 / 合理推断 / 待确认 |  |
| 数据成本 | 低 / 中 / 高 |  | 已确认 / 合理推断 / 待确认 |  |
| 集成成本 | 低 / 中 / 高 |  | 已确认 / 合理推断 / 待确认 |  |
| 测试成本 | 低 / 中 / 高 |  | 已确认 / 合理推断 / 待确认 |  |
| 发布协同成本 | 低 / 中 / 高 |  | 已确认 / 合理推断 / 待确认 |  |
| 变更管理成本 | 低 / 中 / 高 |  | 已确认 / 合理推断 / 待确认 |  |

### 3. 波动因素

| 未知项 | 可能如何影响成本 | 影响方向 |
| --- | --- | --- |
|  |  | 拉高 / 拉低 / 双向 |

### 4. 推进建议

- 是否建议先拆分：
- 是否建议先补信息：
- 是否建议技术预研：

## Low-evidence fallback

如果信息不足以做分项粗估，至少输出：

1. 当前可见的主要成本驱动因素
2. 粗略总体等级
3. 最影响准确性的未知项

## Quality checklist

- 不忽略测试、联调、回归、发布、培训等非开发成本。
- 不把“业务很重要”当作“成本很高”的直接证据。
- 不在没有依据时给精确天数或人周。
- 不把多个子需求的复杂度简单平均成一个结论，必要时先拆分。

## Boundaries and hand-offs

- 上游通常来自 `requirement-context-enrichment`，必要时可参考 `requirement-risk-assessment`。
- 如果用户要判断价值大小，交给 `requirement-value-assessment`。
- 如果用户要做综合排序，交给 `requirement-priority-assessment`。

## Example requests

- 粗估一下这组需求的研发、测试和协同成本，并说明影响因素。
- 按高、中、低给我判断这批需求的投入级别。
- 先不要给工时，先按成本来源拆开评估这项改造的复杂度。
