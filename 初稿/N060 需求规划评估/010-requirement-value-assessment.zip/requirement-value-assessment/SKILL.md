---
name: requirement-value-assessment
description: evaluate requirement value by examining user benefit, business impact, strategic fit, leverage, and timing signals from requirement context and supporting materials. use when the user needs a structured value view for a feature, requirement group, or initiative before prioritization, scope trade-offs, or roadmap discussion, and needs rationale plus uncertainty instead of roi promises.
---

# 需求价值评估

## Overview

判断一个需求、功能组或能力方向“值不值得做”，并说明为什么。
重点输出价值依据、受益对象、成立前提和不确定性，不做正式 ROI 承诺，也不替代最终立项决策。

## Working rules

- 价值判断必须绑定到明确对象：谁受益、受益什么、在什么时间窗口内体现。
- 关键结论统一标注：`已确认`、`合理推断`、`待确认`。
- 缺少量化数据时可以给定性结论，但必须说明依据和边界。
- 不把“有人提出需求”直接等同于“高价值”。

## Default value dimensions

默认至少从以下维度评估：

1. 用户价值：是否显著降低摩擦、提升成功率、提升效率或改善体验
2. 业务价值：是否影响收入、成本、转化、留存、风险控制或运营效率
3. 战略价值：是否匹配当前方向、关键客户、重点场景或平台能力建设
4. 杠杆价值：是否能复用到多个角色、多个流程或后续能力建设
5. 时间性：价值是否依赖窗口期、外部节点或版本节奏

## Rating guidance

默认使用高 / 中 / 低判断；必要时再扩展为更细的分数。

- 高：受益对象明确、影响明显、与目标强相关，且证据较充分
- 中：存在明确价值，但范围、时机或证据还不够强
- 低：价值局部、条件苛刻、受益面有限，或证据明显不足

## Workflow

1. 界定评估对象：功能、需求组、能力项还是改造方向。
2. 明确受益对象：用户、运营、销售、管理者、合作方、平台侧等。
3. 按维度判断：分别评估用户价值、业务价值、战略价值、杠杆价值和时间性。
4. 绑定证据：把每个判断和现状痛点、目标、数据线索、竞品信息或组织目标对应起来。
5. 提炼结论：给出总体价值判断、成立前提和主要不确定性。

## Input expectations

适合接收：

- 需求背景补全结果
- 业务目标、用户问题、现状数据线索、竞品分析、版本背景、组织优先方向
- 用户若只给功能点，也可以先从场景和目标倒推价值路径

## Output template

### 1. 价值摘要

- 评估对象：
- 总体价值判断：高 / 中 / 低
- 最核心支撑理由：

### 2. 价值维度表

| 维度 | 判断 | 受益对象 | 价值表现 | 时间性 | 证据状态 |
| --- | --- | --- | --- | --- | --- |
| 用户价值 | 高 / 中 / 低 |  |  | 近期 / 中期 / 长期 | 已确认 / 合理推断 / 待确认 |
| 业务价值 | 高 / 中 / 低 |  |  | 近期 / 中期 / 长期 | 已确认 / 合理推断 / 待确认 |
| 战略价值 | 高 / 中 / 低 |  |  | 近期 / 中期 / 长期 | 已确认 / 合理推断 / 待确认 |
| 杠杆价值 | 高 / 中 / 低 |  |  | 近期 / 中期 / 长期 | 已确认 / 合理推断 / 待确认 |

### 3. 价值成立前提

| 前提/假设 | 为什么重要 | 若不成立会怎样 |
| --- | --- | --- |
|  |  |  |

### 4. 待确认项

| 缺口 | 对价值判断影响 | 建议补证方式 |
| --- | --- | --- |
|  |  |  |

## Low-evidence fallback

如果证据不足，至少输出：

1. 候选价值点
2. 支撑这些价值点的最小证据
3. 最影响判断的未知项

## Quality checklist

- 不用空泛表述代替价值，例如“用户会更喜欢”必须写出具体受益。
- 不把未经验证的收益数字包装成确定回报。
- 不把价值大小和实施难度混成一个判断。
- 不把单一客户诉求自动升级成全局高价值，除非明确说明范围和战略意义。

## Boundaries and hand-offs

- 上游通常来自 `requirement-context-enrichment`，必要时也可结合 `competitor-analysis` 或 `user-pain-point-analysis`。
- 如果用户要评估投入大小，交给 `requirement-cost-estimation`。
- 如果用户要判断不确定性和阻塞风险，交给 `requirement-risk-assessment`。
- 如果用户要综合排序，交给 `requirement-priority-assessment`。

## Example requests

- 评估这个需求的业务价值、用户价值和战略价值。
- 帮我判断这组功能改造值不值得优先投入。
- 从价值角度解释为什么这个能力应该进入版本讨论。
