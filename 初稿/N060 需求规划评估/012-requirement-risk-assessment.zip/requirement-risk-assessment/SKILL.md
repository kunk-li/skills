---
name: requirement-risk-assessment
description: identify early requirement risks across implementation, release, collaboration, policy, data, dependency, and rule dimensions before detailed solution design. use when the user wants a forward-looking view of what may go wrong, what needs confirmation, and what could block delivery, rollout, or adoption, with risk statements and mitigation directions instead of formal launch approval.
---

# 需求风险预判

## Overview

提前识别需求在实现、上线、协同、规则、数据和组织推进上的主要风险。
输出的是前置风险判断和缓解方向，不替代正式技术评审、风控评审或上线审批。

## Working rules

- 每条风险至少写成“风险 + 触发条件 + 后果”的完整结构。
- 默认同时判断发生可能性和影响程度，再形成总体风险级别。
- 关键结论统一标注：`已确认`、`合理推断`、`待确认`。
- 风险可以基于经验推断，但必须区分“已发生问题”和“潜在风险”。

## Default risk categories

默认至少从以下角度检查：

1. 实现风险：规则复杂、状态机复杂、权限复杂、技术债、不可逆改造
2. 数据风险：口径变化、历史兼容、迁移、数据质量、审计痕迹
3. 集成风险：上下游依赖、接口稳定性、联调资源、第三方能力限制
4. 发布风险：灰度切换、回滚难度、配置差异、培训与支持准备
5. 协同风险：跨团队职责不清、需求理解不一致、评审链路过长
6. 规则/合规风险：审批规则、权限边界、合规要求、合同或政策约束

## Rating guidance

默认给出：发生可能性、影响程度、总体风险级别。

- 高风险：一旦触发会明显阻塞交付、上线或关键业务目标，且短期内难以规避
- 中风险：会影响效率、质量或范围，但可通过拆分、补证、预研、灰度等方式控制
- 低风险：影响面有限，或已有成熟缓解路径

## Workflow

1. 明确范围：需求边界、目标版本、依赖系统、关键规则。
2. 逐类识别风险：按默认风险类别逐项扫描，不漏掉协同和发布问题。
3. 形成风险陈述：为每条风险补充触发条件、后果、暴露阶段。
4. 判断等级：说明发生可能性、影响程度和总体判断依据。
5. 给出缓解方向：用确认、拆分、预研、灰度、监控、兜底、回滚方案等方式对应高风险项。
6. 汇总优先项：挑出需要最先确认或处理的阻塞项。

## Input expectations

适合接收：

- 需求背景补全结果
- 规则说明、依赖关系、业务约束、版本计划、历史问题、跨团队协同信息
- 没有技术细节时，也可先从业务规则、组织依赖和发布影响角度识别风险

## Output template

### 1. 风险摘要

- 总体风险判断：高 / 中 / 低
- 最高优先级风险：
- 最关键的不确定性：

### 2. 风险登记表

| risk id | 风险描述 | 触发条件 | 后果 | 发生可能性 | 影响程度 | 暴露阶段 | 证据状态 | 缓解方向 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| R1 |  |  |  | 高 / 中 / 低 | 高 / 中 / 低 | 设计 / 开发 / 联调 / 发布 / 运营 | 已确认 / 合理推断 / 待确认 |  |

### 3. 高优先级风险

| risk id | 为什么优先 | 建议先做什么 |
| --- | --- | --- |
| R1 |  |  |

### 4. 待确认项

| 缺口 | 对风险判断影响 | 建议补证方式 |
| --- | --- | --- |
|  |  |  |

## Low-evidence fallback

如果信息不足，至少输出：

1. 候选高风险项
2. 每项风险的最小触发条件
3. 最需要补证的未知项

## Quality checklist

- 不只列风险名词，必须写触发条件和后果。
- 不把“可能复杂”当作完整风险结论，必须说明复杂在哪里。
- 不把风险判断写成正式审批意见。
- 不忽略发布、培训、运营支持、回滚等后置风险。

## Boundaries and hand-offs

- 上游通常来自 `requirement-context-enrichment`。
- 如果用户要看投入大小，交给 `requirement-cost-estimation`。
- 如果用户要综合做排序，交给 `requirement-priority-assessment`。

## Example requests

- 请提前识别这个需求在实现、上线和协同上的主要风险。
- 把这份需求整理成风险清单，并标出最需要先确认的项。
- 只做前置风险判断，不要给方案设计。
