---
name: requirement-priority-assessment
description: assess requirement priority by combining value, urgency, dependency unlock, cost, risk, and confidence considerations into a transparent ranking rationale. use when the user wants a structured prioritization view for candidate requirements, backlog items, or scope trade-offs after requirement context and market understanding are available, and needs ranking logic plus caveats instead of a black-box score.
---

# 需求优先级评估

## Overview

把一组候选需求按优先级做透明排序，并解释排序依据。
核心目标是给出可讨论的排序逻辑、分层结果和争议点，而不是把建议排序伪装成最终版本决策。

## Working rules

- 排序前先校准：需求粒度一致、目标一致、资源池一致、比较边界一致。
- 默认同时考虑价值、紧迫性、依赖解锁、成本、风险和判断置信度。
- 关键结论统一标注：`已确认`、`合理推断`、`待确认`。
- 不完整信息也可以做排序，但必须明确哪些位置最不稳定。

## Default ranking logic

默认按以下顺序综合判断：

1. 是否支撑明确业务目标或关键用户问题
2. 是否存在时间窗口、强依赖或解锁作用
3. 在当前成本和风险约束下是否值得优先投入
4. 结论置信度是否足够支撑当前排序

默认 tie-breaker：

- 先看是否解锁其他高价值项
- 再看时间敏感性
- 再看低成本 / 低风险的快速收益机会
- 最后看证据置信度

## Workflow

1. 校准比较对象：检查粒度、目标、版本边界、资源池是否一致。
2. 建维度：至少覆盖价值、紧迫性、依赖解锁、成本、风险、置信度。
3. 逐项判断：为每项需求填写每个维度的结论和依据。
4. 形成分层：给出高 / 中 / 低优先级或 p0 / p1 / p2 分层。
5. 解释排序：说明为什么排前、为什么后置、哪些依赖或不确定性会触发重排。
6. 标出争议项：把排序最不稳定的需求单独列出。

## Input expectations

适合接收：

- 需求背景补全结果
- 竞品分析、价值评估、成本预估、风险预判结果
- 待排序需求列表、业务目标、版本约束、资源约束、外部时间窗口

## Output template

### 1. 排序摘要

- 比较边界：
- 优先级分层：高 / 中 / 低 或 p0 / p1 / p2
- 最值得先做的项：

### 2. 排序表

| 需求 | 价值 | 紧迫性 | 依赖解锁 | 成本 | 风险 | 置信度 | 建议优先级 | 核心理由 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 高 / 中 / 低 | 高 / 中 / 低 | 强 / 中 / 弱 | 低 / 中 / 高 | 低 / 中 / 高 | 高 / 中 / 低 | 高 / 中 / 低 |  |

### 3. 排序理由

- 为什么排前：
- 为什么后置：
- 哪些是依赖驱动排序：

### 4. 不稳定项与重排触发条件

| 项目 | 为什么不稳定 | 触发重排的条件 |
| --- | --- | --- |
|  |  |  |

## Low-evidence fallback

如果信息不足，至少输出：

1. 暂时可形成的粗分层
2. 每层最主要的判断依据
3. 最可能导致整体重排的未知项

## Quality checklist

- 不混用不同粒度需求直接排序。
- 不用黑箱打分替代理由，给分必须能解释。
- 不把建议优先级写成已经确认的 roadmap 结论。
- 不忽略“先做基础能力可解锁多个后续需求”的场景。

## Boundaries and hand-offs

- 适合吸收 `requirement-value-assessment`、`requirement-cost-estimation`、`requirement-risk-assessment` 的结果作为输入。
- 如果用户只想单独评估价值、成本或风险，不要强行升级成优先级排序。

## Example requests

- 把这批需求按价值、成本、风险和紧急性排序，并解释依据。
- 帮我做一个版本优先级评估，标出最值得先做的 5 项。
- 先做粗分层，不要假装精确到完全确定的顺序。
