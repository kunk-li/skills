---
name: requirement-deduplication-and-clustering
description: identify duplicate requirements, repeated asks, and near-duplicate demand across requirement lists, notes, chats, tickets, or backlog exports. use when the user needs overlapping items grouped, exact duplicates separated from theme-level similarity, and a traceable clustering result before context enrichment, prioritization, or requirement writing.
---

# 需求去重与聚类

## Overview

把多来源需求材料拆成最小需求项，区分精确重复、近似重复和仅主题相关，并输出可追溯的聚类结果。
重点是识别与归并依据，不负责决定最终保留哪条需求进入版本。

## Working rules

- 先拆最小需求项，再做聚类，不直接拿整段纪要或整页 prd 去比。
- 保留原文、来源、时间和上下文摘要，确保可追溯。
- 把关系强度明确分成：`确定重复`、`高度相似`、`仅主题相关`。
- 证据不足时标 `待确认`，不要为了聚类完整而强行合并。

## Atomic item rule

拆最小需求项时，优先抽出：

- 角色 / 提出方
- 动作
- 对象
- 触发条件
- 约束条件或特殊规则
- 原始来源 id / 时间 / 片段

如果一条记录包含多个动作或多个场景，先拆成多条再聚类。

## Similarity rule

默认按以下规则判断：

- 确定重复：角色、动作、对象、触发条件、约束条件基本一致，仅措辞差异
- 高度相似：核心用户目标一致，但场景、约束或细节略有不同
- 仅主题相关：都在谈同一主题，但目标、动作或边界明显不同

## Workflow

1. 归一输入：给每条原始材料分配来源标识和原文引用。
2. 拆原子项：按角色、动作、对象、条件、约束拆成最小需求项。
3. 找精确重复：先识别完全重复或轻微措辞差异项。
4. 做相似聚类：按目标、动作、对象、触发条件和约束条件聚成主题簇。
5. 保留差异：明确同簇内不能直接合并的角色差异、规则差异、场景差异。
6. 输出结果：给出 cluster id、代表表述、成员、关系强度和合并依据。

## Input expectations

适合接收：

- 需求列表、工单导出、访谈记录、聊天摘录、prd、会议纪要、表格导出
- 多来源、多时间批次的材料也可以处理，但要保留来源和时间标签

## Output template

### 1. 总览

- 原始需求项数量：
- 精确重复数量：
- 相似聚类数量：
- 争议项数量：

### 2. 聚类结果表

| cluster id | 主题 | 代表表述 | 成员 source id | 关系强度 | 合并依据 | 证据状态 |
| --- | --- | --- | --- | --- | --- | --- |
| C1 |  |  |  | 确定重复 / 高度相似 / 仅主题相关 |  | 已确认 / 合理推断 / 待确认 |

### 3. 差异保留表

| cluster id | 不可直接合并的差异 | 为什么重要 |
| --- | --- | --- |
| C1 |  |  |

### 4. 待确认项

| 项目 | 为什么可能误合并/漏合并 | 建议人工确认点 |
| --- | --- | --- |
|  |  |  |

## Low-evidence fallback

如果信息太乱或上下文太少，至少输出：

1. 已识别出的明显重复项
2. 候选主题簇
3. 最容易误合并的边界项

## Quality checklist

- 不凭表面词相似就合并语义不同的需求。
- 每个 cluster 都要有明确合并依据。
- 不因为来自同一来源就默认相似；也不因为来源不同就拒绝聚类。
- 对跨时间、跨版本材料，必要时保留“同主题但不同阶段诉求”的差异。

## Boundaries and hand-offs

- 结果通常可作为 `requirement-context-enrichment` 的上游输入。
- 如果用户接下来要解释业务背景或范围，交给 `requirement-context-enrichment`。
- 如果用户要决定版本取舍，交给规划类 skill，不要在此处替代取舍决策。

## Example requests

- 把这 50 条需求去重并按主题聚类，给出每组的代表性表述。
- 对工单和访谈里重复出现的诉求做归并，并指出哪些只是相似不是重复。
- 按来源保留可追溯信息，不要只输出一句总结。
