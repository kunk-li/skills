# CSV Row Decomposition Guidance

The CSV is the core deliverable. Treat each row as a compact, implementation-oriented requirement unit.

## Decomposition rules

- Split by independently buildable capability.
- Do not merge create, edit, query, submit, approve, reject, bind, unbind, import, export, or status change into one row when they follow different rules.
- If a prototype contains multiple pages or tabs, extract one or more rows from each area when backend behavior differs.
- If one business object has separate operator roles, split rows when permissions or state transitions differ.

## Detail field rules

Use `功能场景详情` to encode the backend meaning of the row. Prefer this order:

1. 场景
2. 触发
3. 规则
4. 校验
5. 异常
6. 权限
7. 数据影响
8. 假设
9. 待确认

Not every row needs every label, but the field should still be specific enough for engineering and QA.

## Writing rules

- Prefer concrete verbs: 新增, 编辑, 查询, 提交, 审批, 驳回, 禁用, 启用, 绑定, 认领, 邀约, 转化.
- Keep each row compact but specific.
- Use semicolon-separated clauses so the CSV stays readable.
- Put missing or uncertain information into `待确认` instead of guessing.
- Put backend defaults such as Java, Spring Boot, REST, or relational database into `假设` only when the source does not confirm them.

## Good split examples

- `审批中心` / `发起审批`
- `审批中心` / `待办审批处理`
- `招聘管理` / `招聘申请`
- `招聘管理` / `职位发布`
- `招聘管理` / `面试管理`

## Poor split examples

- `审批中心` / `审批相关功能`
- `招聘管理` / `招聘全流程`

These are too broad for backend estimation and testing.
