# Java Backend Requirements CSV Template

Always use the following three-column CSV structure.

```csv
"大类模块","需实现功能点","功能场景详情"
"<模块名称>","<功能点名称>","场景：...；触发：...；规则：...；校验：...；异常：...；权限：...；数据影响：...；假设：...；待确认：...；"
```

## Column intent

- `大类模块`: High-level business module or subsystem.
- `需实现功能点`: Independently understandable feature point.
- `功能场景详情`: Compact backend-ready requirement detail written as structured clauses.

## Formatting rules

- Always keep exactly three columns.
- Always quote every field with double quotes.
- Escape embedded `"` as `""`.
- Repeat the module value for each row.
- Do not add blank columns, comments, footnotes, markdown tables, or prose around the CSV unless the user asks.
