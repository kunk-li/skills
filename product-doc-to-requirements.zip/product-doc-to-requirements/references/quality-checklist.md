# Quality Checklist

Check every output against this list before finalizing.

## Structure
- Is the output valid CSV instead of prose or markdown table?
- Is the header row exactly `大类模块,需实现功能点,功能场景详情`?
- Does every row contain exactly three columns?
- Are all fields quoted correctly?

## Decomposition
- Is each row an independently understandable feature point?
- Are rows split finely enough for engineering estimation and QA verification?
- Are module names stable and readable?

## Detail Quality
- Does `功能场景详情` contain concrete backend-relevant behavior instead of vague summaries?
- Are rules, validations, exceptions, permissions, and data impact included when relevant?
- Are assumptions and unknowns marked explicitly instead of hidden?

## Grounding
- Are unsupported guesses avoided?
- Are inaccessible link details called out explicitly when they affect the result?
- Does the output follow any style example provided by the user while remaining valid CSV?

## Java Backend Specificity
- Would a Java backend team know what service behavior must be implemented from the CSV rows?
- Are important state changes, persistence impact, and operator permissions visible in the detail field?
- Are concurrency, idempotency, or audit concerns included when clearly implied?
