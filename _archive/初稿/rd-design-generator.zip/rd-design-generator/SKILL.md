---
name: rd-design-generator
description: generate a newcomer-friendly overall engineering design document from prd text and derived requirement analyses. use when the team needs a design that explains business intent, module boundaries, data, interfaces, state, error handling, development order, and test focus clearly enough for less experienced engineers to start implementation. standalone output is a full design doc. in combination it consumes review and engineering requirement outputs to form a stronger design.
---
# rd-design-generator

## Role / 角色定位
- 生成面向新人研发的总程序设计文档。
- 单个可用；多个 skill 组合时作为链路中的稳定节点。

## Single-skill value / 单独使用价值
- 独立产出《研发总设计》。
- 即使没有其他 skill 结果，也要产出完整、可读、可交付的 markdown 文档。

## Multi-skill value / 组合使用价值
- 吸收 036/038/review-doc-generator 等结果，形成更强的设计主文档。
- 组合使用时，优先吸收上游结构化结果，但不得机械重复上游内容。

## Primary inputs / 主要输入
- 必需：PRD 原文或以 PRD 为唯一来源的结构化分析结果。
- 可选：其他 skill 的派生结果，但只能把它们视为 PRD 派生证据，不可引入代码、数据库现状或口头背景作为事实。

## Required output / 必须输出
输出必须是 Markdown，并覆盖以下核心章节：
- 读者说明
- 业务目标与术语
- 系统边界
- 模块划分
- 核心流程 / 时序
- 状态流转
- 权限与校验
- 接口设计
- 数据模型
- 异常处理
- 非功能要求
- 开发顺序
- 测试策略
- 待确认项


## Execution workflow / 执行流程
1. 通读 PRD，先列出显式事实、角色、对象、动作、状态、规则与边界。
2. 如果有上游 skill 结果，先做对齐：哪些结论与 PRD 一致、哪些只是推断、哪些仍未决。
3. 只在 PRD 事实足够支撑时做推断；否则明确标注为待确认项。
4. 生成本 skill 的主交付物，而不是停留在摘要或点评层。
5. 用 `references/checklist.md` 自检，并按 `references/scoring-rubric.md` 自评分。

## Collaboration contract / 协作契约
- 上游：PRD 必需；036、038、review-doc-generator 强烈建议。
- 下游：039-technical-solution-draft-generation、031-handover-package-generation、具体开发实施。
- 交接要求：输出中必须把实现顺序、依赖、风险与未决项写清，便于新人接手。

## Rules / 核心规则
- 必须把“已确认事实 / 推断建议 / 待确认项”分层书写。
- 必须优先面向新人、新手、非业务背景读者，先解释再下结论。
- 必须尽量表格化呈现角色、对象、状态、规则、问题、风险、决策项。
- 必须给至少一个具体业务例子或最小场景说明，帮助陌生读者理解。
- 不得把模糊内容写成既定事实。
- 不得只输出 3-5 条摘要结论冒充交付物。

## Quality bar / 质量门槛
- 交付质量最低要达到 rubric 的 3/5（usable）。
- 判定标准：新人研发读完能开始设计和编码，不需要再靠口头补背景。
- 如果做不到，必须显式写出缺口与原因。

## Reference files / 参考文件
- `references/output-template.md`：默认输出模板
- `references/checklist.md`：交付前检查清单
- `references/scoring-rubric.md`：质量评分标准
- `references/common-failure-modes.md`：常见失败模式
- `references/orchestration.md`：单 skill / 多 skill 编排说明
- `references/example-io.md`：输入输出示例
