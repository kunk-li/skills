# Output Template

Use this default structure unless the user explicitly requests another format.

## 1. 文档用途 / How to use this document
- Explain who should read it and how it should be used.

## 2. 已确认事实
- List only facts directly supported by PRD or by clearly traceable derived outputs.

## 3. 背景与术语速读
- Explain business background in simple language for newcomers.

## 4. 读者说明
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 5. 业务目标与术语
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 6. 系统边界
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 7. 模块划分
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 8. 核心流程 / 时序
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 9. 状态流转
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 10. 权限与校验
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 11. 接口设计
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 12. 数据模型
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 13. 异常处理
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 14. 非功能要求
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 15. 开发顺序
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 16. 测试策略
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 17. 待确认项
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 18. 待确认项
- List unresolved items, impact, and who should answer them.

## 19. 下一步
- Recommend the next downstream skill or human action.