# Output Template

Use this default structure unless the user explicitly requests another format.

## 1. 文档用途 / How to use this document
- Explain who should read it and how it should be used.

## 2. 已确认事实
- List only facts directly supported by PRD or by clearly traceable derived outputs.

## 3. 背景与术语速读
- Explain business background in simple language for newcomers.

## 4. 文档使用说明
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 5. 业务背景速读
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 6. 评审目标与范围
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 7. 主流程讲解
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 8. 功能拆解
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 9. 规则与边界
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 10. 风险与影响
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 11. 待确认与决策项
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 12. 会议结论记录区
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 13. 会后动作
- Fill this section with concrete, reusable content, preferring tables where appropriate.

## 14. 待确认项
- List unresolved items, impact, and who should answer them.

## 15. 下一步
- Recommend the next downstream skill or human action.