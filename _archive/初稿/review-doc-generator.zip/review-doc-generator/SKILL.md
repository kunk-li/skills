---
name: review-doc-generator
description: generate a review-ready document from prd text and derived analyses for mixed audiences, including people who do not know the business background. use when the team needs a meeting-ready review document instead of scattered review notes. standalone output is a full review package. in combination this skill assembles context, quality findings, pending decisions, and engineering concerns into one meeting document.
---
# review-doc-generator

## Role / 角色定位
- 生成可直接拿去评审会使用的会议文档。
- 单个可用；多个 skill 组合时作为链路中的稳定节点。

## Single-skill value / 单独使用价值
- 独立产出《需求/方案评审文档》，新人可直接预读。
- 即使没有其他 skill 结果，也要产出完整、可读、可交付的 markdown 文档。

## Multi-skill value / 组合使用价值
- 吸收 004/023/025/029/030/036 的结果，成为评审会主文档。
- 组合使用时，优先吸收上游结构化结果，但不得机械重复上游内容。

## Primary inputs / 主要输入
- 必需：PRD 原文或以 PRD 为唯一来源的结构化分析结果。
- 可选：其他 skill 的派生结果，但只能把它们视为 PRD 派生证据，不可引入代码、数据库现状或口头背景作为事实。

## Required output / 必须输出
输出必须是 Markdown，并覆盖以下核心章节：
- 文档使用说明
- 业务背景速读
- 评审目标与范围
- 主流程讲解
- 功能拆解
- 规则与边界
- 风险与影响
- 待确认与决策项
- 会议结论记录区
- 会后动作


## Execution workflow / 执行流程
1. 通读 PRD，先列出显式事实、角色、对象、动作、状态、规则与边界。
2. 如果有上游 skill 结果，先做对齐：哪些结论与 PRD 一致、哪些只是推断、哪些仍未决。
3. 只在 PRD 事实足够支撑时做推断；否则明确标注为待确认项。
4. 生成本 skill 的主交付物，而不是停留在摘要或点评层。
5. 用 `references/checklist.md` 自检，并按 `references/scoring-rubric.md` 自评分。

## Collaboration contract / 协作契约
- 上游：PRD 必需；004、023、025、029、030、036 可选但强烈建议。
- 下游：rd-design-generator、031-handover-package-generation。
- 交接要求：输出中必须把“事实 / 建议 / 待决策”分层，并预留会议记录区。

## Rules / 核心规则
- 必须把“已确认事实 / 推断建议 / 待确认项”分层书写。
- 必须优先面向新人、新手、非业务背景读者，先解释再下结论。
- 必须尽量表格化呈现角色、对象、状态、规则、问题、风险、决策项。
- 必须给至少一个具体业务例子或最小场景说明，帮助陌生读者理解。
- 不得把模糊内容写成既定事实。
- 不得只输出 3-5 条摘要结论冒充交付物。

## Quality bar / 质量门槛
- 交付质量最低要达到 rubric 的 3/5（usable）。
- 判定标准：完全不懂业务的人也能看懂并参与评审，会议可直接照文档推进。
- 如果做不到，必须显式写出缺口与原因。

## Reference files / 参考文件
- `references/output-template.md`：默认输出模板
- `references/checklist.md`：交付前检查清单
- `references/scoring-rubric.md`：质量评分标准
- `references/common-failure-modes.md`：常见失败模式
- `references/orchestration.md`：单 skill / 多 skill 编排说明
- `references/example-io.md`：输入输出示例
