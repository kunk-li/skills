# priority rules

## base impact
- p0: compliance breach, money loss, data leak, irreversible corruption, release blocker
- p1: core business interruption or high user-facing failure
- p2: important but non-blocking degradation
- p3: low-frequency or cosmetic coverage

## adjusters
- boost priority when logic is newly introduced, complex, or historically fragile
- boost priority when the point protects a blocker, regulated rule, or p0 acceptance criterion
- reduce priority only when the path is explicitly low-impact and low-frequency
