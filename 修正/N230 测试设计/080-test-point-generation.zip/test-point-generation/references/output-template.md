# output template

Use a csv-friendly table plus short analysis sections.

## Required sections
1. metadata
2. scope_summary
3. test_points
4. coverage_matrix_seed
5. coverage_gaps
6. downstream_handoff
7. self_check

## Required test_points columns
| tp_id | module | tp_intent | tp_perspective | description | priority | derived_from | notes |
|---|---|---|---|---|---|---|---|

## Scale guidance
- small feature: 10-25 rows
- medium feature: 25-60 rows
- large workflow: 60-150 rows
