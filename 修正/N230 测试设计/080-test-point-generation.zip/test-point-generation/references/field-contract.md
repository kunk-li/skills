# field contract

## shared metadata
- `selected_mode`: chosen operating mode
- `readiness`: ready / constrained / blocked
- `evidence_profile`: direct / mixed / partial
- `tool_collaboration_mode`: standalone / chained / gate-support

## test point fields
- `tp_id`: stable id such as `TP-ORDER-001`
- `tp_intent`: one of the standardized intent classes
- `tp_perspective`: one of input_output / actor / time / concurrency / state
- `derived_from`: source ids from ac, rules, blockers, or nfr items
- `priority`: p0 / p1 / p2 / p3
- `coverage_status`: covered / partial / pending_confirmation
