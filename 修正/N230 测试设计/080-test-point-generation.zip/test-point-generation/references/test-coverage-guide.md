# test coverage guide

## mandatory baseline
For each core acceptance criterion, try to cover:
- one positive intent
- one negative intent
- one boundary intent

## add mandatory extra intents when applicable
- money, pii, regulated workflow -> security + compliance
- high-concurrency operation -> concurrency + performance
- cross-system workflow -> exception + resilience

## good wording
Prefer:
- `验证订单创建在用户状态为 active 时成功`
- `验证未登录用户无法访问审批接口`
Avoid:
- `验证功能正常`
