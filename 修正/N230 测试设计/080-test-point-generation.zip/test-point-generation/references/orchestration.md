# orchestration

## n230 chain
1. `test-point-generation` defines what should be validated.
2. `test-case-generation` converts selected points into executable cases.
3. `boundary-condition-generation` extends target cases with edge-focused coverage.
4. `exception-scenario-generation` extends target cases with failure and recovery coverage.

## standalone use
Each skill may run alone, but ids should remain compatible:
- TP ids feed TC coverage references.
- BC and ES artifacts should point back to TP or TC ids.

## downstream
- N240 consumes `测试用例集.xlsx` most directly.
- N260 consumes coverage completeness, especially p0 and nfr protection.
