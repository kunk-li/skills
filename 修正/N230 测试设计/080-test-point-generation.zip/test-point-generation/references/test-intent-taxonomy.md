# test intent taxonomy

Use exactly one primary intent per test point.

- `functional_positive`: happy path and expected success path
- `functional_negative`: invalid input or rejection behavior
- `boundary`: limit values and threshold behavior
- `exception`: timeout, dependency failure, rollback, recovery
- `concurrency`: simultaneous access, lock, ordering, idempotency under load
- `performance`: latency, throughput, capacity, degradation under scale
- `security`: authentication, authorization, injection, abuse
- `compliance`: audit, retention, masking, append-only, mandatory controls
