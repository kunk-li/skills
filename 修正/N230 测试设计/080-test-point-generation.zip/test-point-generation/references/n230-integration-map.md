# n230 integration map

## workflow node
- node: `N230`
- goal: turn acceptance and requirement structure into test design artifacts

## canonical inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

## canonical outputs
- `测试点清单.csv`
- `测试用例集.xlsx`
- `边界条件清单.csv`
- `异常场景清单.csv`

## downstream handoff
- to `N240`: executable coverage and automation-tier hints
- to `N260`: coverage matrix, p0 completeness, and nfr protection evidence
