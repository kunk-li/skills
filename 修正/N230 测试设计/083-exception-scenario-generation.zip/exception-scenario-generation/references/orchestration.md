# orchestration

Exception scenarios extend normal cases with failure and recovery behavior.
- Prefer linking to TP or TC ids when available.
- Feed N240 with automatable fault-injection hints.
- Feed N250 and N260 with category and recovery evidence.
