# recovery strategy matrix

- `retry_automatic`: system retries with bounded policy
- `retry_user_initiated`: user may safely retry
- `fallback`: stale cache, default path, or degraded mode
- `compensate`: saga or explicit rollback path
- `manual_intervention`: operator or human approval needed
- `ignore_and_continue`: non-critical failure tolerated without hard stop

For each scenario, verify both trigger and exit behavior.
