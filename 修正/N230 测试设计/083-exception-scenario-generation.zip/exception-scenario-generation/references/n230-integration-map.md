# n230 integration map

## workflow node
- node: `N230`
- artifact target: `异常场景清单.csv`

## upstream
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`
- optional `测试点清单.csv`, `测试用例集.xlsx`, and n170 outputs

## downstream
- `N240`: automation and fault injection planning
- `N250`: defect attribution categories and reproduction support
- `N260`: gate validation for p0 recovery, fallback, and idempotency under error
