# field contract

- `es_id`: stable id such as `ES-ORDER-001`
- `exception_category`: standardized failure class
- `trigger`: precise failure injection or abnormal condition
- `expected_behavior`: response, state, and signal expectations
- `recovery_strategy`: retry_automatic / retry_user_initiated / fallback / compensate / manual_intervention / ignore_and_continue
