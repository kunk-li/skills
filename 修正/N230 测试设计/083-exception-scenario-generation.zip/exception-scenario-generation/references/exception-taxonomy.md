# exception taxonomy

Use the category file for exact naming. Typical families include:
- input validation
- authentication
- authorization
- business rule rejection
- resource state mismatch
- infrastructure failure
- external dependency failure
