# output template

## required sections
1. metadata
2. exception_summary
3. exception_scenarios
4. propagation_checks
5. recovery_checks
6. downstream_handoff
7. self_check

## required columns
| es_id | target_flow | exception_category | trigger | expected_behavior | recovery_strategy | related_tc_or_tp | notes |
|---|---|---|---|---|---|---|---|
