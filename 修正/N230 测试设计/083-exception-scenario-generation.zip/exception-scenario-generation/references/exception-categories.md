# exception categories

- `input_validation`: malformed or invalid input, 400-style outcomes
- `authentication`: missing or invalid identity, 401-style outcomes
- `authorization`: forbidden operation, 403-style outcomes
- `business_rule`: rule rejection or domain conflict, 409/422-style outcomes
- `resource_state`: missing, locked, deleted, or incompatible state
- `infrastructure`: db, queue, cache, disk, or internal service fault
- `external_dependency`: partner api timeout, error, or unavailable dependency
