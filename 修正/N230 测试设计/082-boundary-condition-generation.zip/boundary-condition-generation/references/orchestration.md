# orchestration

Boundary coverage extends but does not replace core cases.
- Prefer referencing existing TP or TC ids.
- Feed N240 with automation-friendly edge values.
- Feed N260 with proof that threshold and limit coverage exists.
