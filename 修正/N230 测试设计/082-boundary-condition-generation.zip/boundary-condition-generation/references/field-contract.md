# field contract

- `bc_id`: stable id such as `BC-ORDER-001`
- `boundary_kind`: one primary boundary class
- `boundary_value`: exact edge input or environment condition
- `expected_behavior`: accept / reject / degrade / alert / throttle
- `related_tc_or_tp`: linked testcase or test-point ids
