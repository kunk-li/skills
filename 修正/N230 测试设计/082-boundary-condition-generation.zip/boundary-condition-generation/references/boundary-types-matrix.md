# boundary types matrix

Use the primary taxonomy file for exact naming, but remember these families:
- numeric
- string_length
- collection
- temporal
- state
- cardinality
- precision
- encoding
