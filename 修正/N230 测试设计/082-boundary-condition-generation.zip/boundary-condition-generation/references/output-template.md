# output template

## required sections
1. metadata
2. boundary_summary
3. boundary_items
4. combination_plan
5. env_boundary_notes
6. downstream_handoff
7. self_check

## required columns
| bc_id | target_object | target_field | boundary_kind | boundary_value | expected_behavior | related_tc_or_tp | notes |
|---|---|---|---|---|---|---|---|
