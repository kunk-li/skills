# n230 integration map

## workflow node
- node: `N230`
- artifact target: `边界条件清单.csv`

## upstream
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`
- optional `测试点清单.csv` and `测试用例集.xlsx`

## downstream
- `N240`: automate selected edge cases
- `N260`: verify p0 thresholds and regulated limits were not skipped
