# boundary kind taxonomy

- `numeric`: min, min-1, min+1, max-1, max, max+1, zero, negative, overflow
- `string_length`: empty, shortest, exact-max, max+1, whitespace, special chars
- `collection`: empty, singleton, full page, max set, max+1
- `temporal`: before, exact time, after, period edge, cross-day/month/year, dst
- `state`: allowed transition edge and forbidden transition edge
- `cardinality`: zero, one, many, upper-bound
- `precision`: decimal places, rounding edge, integer overflow
- `encoding`: ascii, unicode, emoji, control chars, normalization edge
