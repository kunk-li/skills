# combinatorial guidance

Use combinations selectively:
- pairwise for most multi-field boundaries
- max-min combinations for high-risk numeric or temporal pairs
- null-plus-value when one side is optional
- avoid full-cartesian explosion unless the scope is tiny

When reduced coverage is used, explain the reduction rule.
