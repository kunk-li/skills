---
name: boundary-condition-generation
description: generate workflow-aligned boundary-condition coverage from acceptance criteria, requirement structure, schemas, and testcase context. use when chatgpt works in testing & qa / test design and must produce the workflow-aligned boundary artifact for n230 to protect thresholds, limits, combinations, and environment edges before automation or gate review.
---
# boundary-condition-generation

## Role / role positioning
This skill aligns to testing & qa -> test design -> 边界条件清单.csv. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on thresholds, extremes, paradox values, and combinational edge coverage.
- Extend core scenarios with edge cases; do not replace full executable testcases.
- Do not drift into generic performance planning or chaos orchestration unless the edge itself is the verified boundary.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `numeric_only`: focus on numeric, precision, and threshold boundaries.
- `text_only`: focus on strings, encoding, and input-shape limits.
- `full_spectrum`: cover all relevant boundary kinds including environment and combinations.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `测试点清单.csv`
- `测试用例集.xlsx`
- `接口设计草案.yaml`
- `表结构设计草案.sql`
- `业务规则清单.csv`
- threshold configs, limit tables, rate-limit definitions, or data dictionaries

## Standalone rule / standalone usage
This skill must still work on one field, one threshold rule, or one operation.

Degradation rules:
- If schema or field constraints are missing, emit only confirmed boundary families and tag missing thresholds as `pending_limit_definition`.
- If testcase context is absent, reference the target object or acceptance criterion directly.
- If combinational coverage would explode, prefer pairwise or representative combinations and state the reduction logic.
- Keep the output shape stable even when only one boundary family is known.

## Core output contract / core output contract
Default to csv-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.boundary_condition_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 边界条件清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `boundary_summary`
- `boundary_items[]`
- `combination_plan[]`
- `env_boundary_notes[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every boundary item must declare one `boundary_kind` from `references/boundary-kind-taxonomy.md`.
- Cover both `valid-but-fragile` and `invalid-but-plausible` edge values when the domain supports them.
- Include paradox cases where reasonable values are often rejected or bad values often slip through.
- Use pairwise or focused combination logic from `references/combinatorial-guidance.md` instead of brute-force explosion.
- Add environment boundaries only when the feature truly depends on time, capacity, concurrency, or resource ceilings.

## Execution workflow / execution workflow
1. Read requirements, testcase context, and limit definitions.
2. Identify boundary-bearing fields, states, and environment constraints.
3. Expand them by boundary kind and edge-value catalog.
4. Add combination candidates where cross-field extremes matter.
5. Normalize traceability back to rules, acceptance criteria, or testcase ids.
6. Emit handoff notes for automation and gate review.

## Dynamic completeness / dynamic completeness
- Small scope: enumerate direct min/max/empty/default cases.
- Medium scope: add paradox values and selected combinations.
- Large scope: group by object or field family and explicitly document reduction strategy.
- If environment boundaries are material, show them separately from pure input-field boundaries.

## Quality bar / quality bar
A good result should prevent easy-to-miss production defects around thresholds, precision, rare encodings, or resource limits. The artifact must be specific enough that downstream teams can automate or manually verify the edge behavior without guessing which values matter.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/boundary-types-matrix.md`
- `references/boundary-kind-taxonomy.md`
- `references/combinatorial-guidance.md`
- `references/n230-integration-map.md`
