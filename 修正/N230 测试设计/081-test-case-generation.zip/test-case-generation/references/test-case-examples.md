# testcase examples

Use these patterns:
- actor + action + result
- explicit preconditions
- concrete input values
- observable assertions

Example title:
`普通员工提交请假申请成功并生成待审批记录`
