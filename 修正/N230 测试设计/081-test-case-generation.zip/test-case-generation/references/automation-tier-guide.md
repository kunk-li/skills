# automation tier guide

- `t1_automated_unit`: function or method level, every commit
- `t2_automated_integration`: service or component integration, every pr
- `t3_automated_e2e`: full journey or browser automation, daily or release
- `t4_manual`: visual, exploratory, or human-verification cases

Prefer keeping manual-only coverage under a small minority unless the scenario is truly hard to automate.
