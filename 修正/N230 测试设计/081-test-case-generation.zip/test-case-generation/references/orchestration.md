# orchestration

## role in n230
- Converts test intent into executable coverage.
- Feeds N240 with automation and fixture hints.
- Feeds N260 with evidence that p0 paths are concretely specified.

## neighbor skills
- Input may come from `test-point-generation`.
- `boundary-condition-generation` and `exception-scenario-generation` extend specific cases, not replace them.
