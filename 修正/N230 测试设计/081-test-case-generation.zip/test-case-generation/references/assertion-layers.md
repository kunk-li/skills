# assertion layers

## response level
- status code
- body fields
- headers

## state level
- database state
- cache state
- emitted event state

## side-effect level
- audit entry
- notification
- external call behavior

Important cases should assert across all three levels when evidence exists.
