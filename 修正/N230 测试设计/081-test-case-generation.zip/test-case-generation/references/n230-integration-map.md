# n230 integration map

## workflow node
- node: `N230`
- artifact target: `测试用例集.xlsx`

## canonical upstream
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`
- optionally `测试点清单.csv`

## canonical downstream
- `N240`: automation orchestration, fixture setup, api scripts
- `N260`: p0 verification, gate completeness, evidence of case independence
