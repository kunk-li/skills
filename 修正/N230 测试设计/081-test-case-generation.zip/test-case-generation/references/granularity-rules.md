# granularity rules

- minimum: 3 observable steps
- typical: 5-10 steps
- maximum: 15 steps

If a case exceeds 15 steps, split by sub-scenario or extract shared setup.
If a case is under 3 steps, check whether preconditions or assertions are underspecified.
