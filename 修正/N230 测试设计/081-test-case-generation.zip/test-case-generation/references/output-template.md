# output template

Use workbook-friendly sheets or markdown sections that can be exported to xlsx.

## Required sections
1. metadata
2. case_summary
3. fixtures
4. test_cases
5. automation_distribution
6. downstream_handoff
7. self_check

## Required testcase columns
| tc_id | title | covered_tp | automation_tier | preconditions | steps | test_data | assertions | teardown | notes |
|---|---|---|---|---|---|---|---|---|---|
