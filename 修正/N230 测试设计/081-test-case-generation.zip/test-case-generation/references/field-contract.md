# field contract

## fixture fields
- `fixture_id`: stable reusable fixture name
- `setup`: ordered data/setup actions
- `teardown`: cleanup actions
- `scope`: shared / scenario / tc_specific

## testcase fields
- `tc_id`: stable id such as `TC-ORDER-001`
- `covered_tp`: linked test-point ids
- `automation_tier`: t1_automated_unit / t2_automated_integration / t3_automated_e2e / t4_manual
- `assertions`: response, state, and side-effect checks
