---
name: test-case-generation
description: generate workflow-aligned executable test cases from acceptance criteria, test points, and requirement structure. use when chatgpt works in testing & qa / test design and must produce the workflow-aligned test-case artifact for n230 before automation orchestration, defect attribution, or quality-gate aggregation.
---
# test-case-generation

## Role / role positioning
This skill aligns to testing & qa -> test design -> 测试用例集.xlsx. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on executable cases with setup, steps, assertions, and automation tier.
- Convert test intent into runnable or reviewable cases without pretending tests were executed.
- Do not switch into regression scheduling, release sign-off, or defect triage.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `from_ac_mode`: derive cases directly from acceptance criteria.
- `from_tp_mode`: expand curated test points into cases.
- `bdd_mode`: generate Gherkin-style cases while preserving workflow metadata.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `测试点清单.csv`
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`
- `接口设计草案.yaml`
- `错误码清单.csv`
- known fixtures or environment assumptions

## Standalone rule / standalone usage
This skill must still work on a single test point, one acceptance criterion, or one API operation.

Degradation rules:
- If upstream test points are missing, derive a minimal testcase registry directly from acceptance criteria and tag each case as `seeded_without_tp`.
- If setup data is unclear, emit fixture proposals instead of inventing real environment facts.
- If assertions beyond response-level are uncertain, keep them explicit as `pending_state_assertion` or `pending_side_effect_assertion`.
- Preserve the same output shape even when only one case can be confirmed.

## Core output contract / core output contract
Default to spreadsheet-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.test_case_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 测试用例集.xlsx`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `case_summary`
- `fixtures[]`
- `test_cases[]`
- `automation_distribution`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every testcase must have a stable `tc_id` and should reference at least one `tp_id` or `ac_id`.
- Use `references/granularity-rules.md` to keep each case between 3 and 15 observable steps.
- Every important testcase should include assertions at response level, state level, and side-effect level when evidence exists.
- Prefer reusable fixtures over copy-pasted data setup.
- Cases must be order-independent unless explicitly declared as sharing a named fixture.
- Assign one `automation_tier` from `references/automation-tier-guide.md`.

## Execution workflow / execution workflow
1. Read acceptance criteria and available test points.
2. Group the scope into scenarios and derive reusable fixtures.
3. Write executable cases with preconditions, steps, data, and multilayer assertions.
4. Normalize independence and teardown expectations.
5. Assign automation tiers and downstream automation hints.
6. Emit traceability and readiness notes for N240 and N260.

## Dynamic completeness / dynamic completeness
- Small scope: produce a compact workbook-style set with direct traceability.
- Medium scope: add reusable fixtures, multilayer assertions, and automation distribution.
- Large scope: cluster cases by scenario or module and avoid bloated monolithic cases.
- If only smoke coverage is possible, mark missing negative, boundary, or exception expansions explicitly.

## Quality bar / quality bar
A good result should be close enough for qa or engineers to execute or automate without first re-deriving fixtures, assertions, or scope. The artifact must reduce ambiguity, not merely restate requirements.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/test-case-examples.md`
- `references/granularity-rules.md`
- `references/automation-tier-guide.md`
- `references/assertion-layers.md`
- `references/n230-integration-map.md`
