# Output template

Required severity columns:
- defect_id
- impact_to_users
- impact_to_data
- impact_to_compliance
- impact_to_business
- likelihood
- overall_severity
- response_sla
- fix_sla
- escalation_rule
- reasoning
