# Severity assessment rubric

Default labels:
- `P0`
- `P1`
- `P2`
- `P3`
- `TBD` only when critical dimensions are missing
