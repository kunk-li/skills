# SLA and escalation policy

Default SLA:
- `P0`: respond 1h, fix 24h
- `P1`: respond 4h, fix 3d
- `P2`: respond 1d, fix 2w
- `P3`: respond 1w, fix when convenient

Escalation:
- overdue P1 can escalate to P0 if business context tightens
- compliance defects notify compliance owner immediately
