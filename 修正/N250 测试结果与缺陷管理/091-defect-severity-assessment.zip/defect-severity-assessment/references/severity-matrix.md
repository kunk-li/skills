# Severity matrix

Score these dimensions separately:
- user impact
- data impact
- compliance impact
- business impact

Default rule:
- overall severity = max dimension severity
- compliance P0 overrides everything else
