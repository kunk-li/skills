---
name: defect-severity-assessment
description: generate workflow-aligned severity decisions with impact reasoning, likelihood, sla, and escalation guidance from classified defects and failure evidence. use when chatgpt works in testing & qa / result and defect management and must produce the n250 severity artifact for gate, release, rollback, or escalation decisions.
---
# defect-severity-assessment

## Role / role positioning
This skill aligns to testing & qa -> result and defect management -> 缺陷严重级评估.csv. It delivers a workflow-aligned artifact for N250.

### Boundary
- Turn defect evidence into auditable severity decisions.
- Use multi-dimensional impact, likelihood, and SLA logic instead of subjective labels.
- Highlight escalation and stop-the-line conditions explicitly.
- Do not classify defect taxonomy again unless needed to explain severity reasoning.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_sev`: produce a fast severity call for one urgent issue.
- `comprehensive_sev`: evaluate multi-dimensional impact, likelihood, SLA, and escalation.
- `batch_reassess`: reassess a backlog or release batch using updated policy.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试执行结果`
- `自动化触发建议.md`
- `日志摘录.md`
- `Bug现象记录.md`

### optional enhancement inputs
- `缺陷分类表.csv`
- `测试失败归因.md`
- revenue, user, or compliance exposure estimates
- incident frequency or historical recurrence
- release schedule or hotfix context

## Standalone rule / standalone usage
This skill must still work on one blocker candidate, one release batch, one compliance issue, or one cluster of similar defects.

Degradation rules:
- If likelihood evidence is weak, keep `likelihood` conservative and explain why.
- If user or revenue impact is unknown, do not invent business numbers; mark the missing factor.
- If classification is provisional, still emit severity rows with `pending_dimension_confirmation` rather than breaking the schema.
- Maintain stable output shape for urgent triage and broad reassessment alike.

## Core output contract / core output contract
Default to csv-friendly tables or Markdown tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `severity_rows[]`
- `severity_matrix_summary`
- `sla_actions[]`
- `escalation_watch[]`
- `circuit_breaker_evaluation`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: decision_support`
- `stage_position: testing_and_qa.result_and_defect_management.defect_severity_assessment`
- `workflow_node: N250`
- `node_artifact_target: 缺陷严重级评估.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Use the multi-dimensional severity matrix from `references/severity-matrix.md`.
- Evaluate at least user impact, data impact, compliance impact, and business impact.
- Apply likelihood from `always`, `frequent`, `occasional`, `rare`, or `one_in_million` before final scoring.
- Any compliance-P0 condition must override likelihood and become P0.
- Every severity result must bind to SLA and escalation policy from `references/sla-and-escalation-policy.md`.
- Explain the reasoning trail so reviewers can audit severity changes later.

## Execution workflow / execution workflow
1. Read defect rows, attribution evidence, and operational or business impact signals.
2. Score impact dimensions and likelihood.
3. Determine overall severity using max-impact and policy overrides.
4. Attach response SLA, fix SLA, and escalation checkpoints.
5. Evaluate whether the defect set triggers circuit-breaker behavior.
6. Emit severity rows and downstream release or gate implications.

## Dynamic completeness / dynamic completeness
- Single urgent issue: emphasize final severity, SLA, and escalation trigger.
- Release batch: show grouped severity distribution and blocker accumulation.
- Backlog reassessment: preserve reasoning and changed policy basis.
- Sparse evidence: show which missing dimension prevents stronger confidence.

## Quality bar / quality bar
A good result should make severity defensible, reproducible, and actionable for gate owners, release leads, and incident responders.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
- `references/severity-assessment-rubric.md`
- `references/severity-matrix.md`
- `references/sla-and-escalation-policy.md`
- `references/circuit-breaker-policy.md`
- `references/n250-integration-map.md`
