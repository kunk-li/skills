---
name: defect-classification
description: generate workflow-aligned defect classification tables from failure evidence, bug observations, and traceability context. use when chatgpt works in testing & qa / result and defect management and must produce the n250 classification artifact for downstream severity, reproduction, gate, or release decisions.
---
# defect-classification

## Role / role positioning
This skill aligns to testing & qa -> result and defect management -> 缺陷分类表.csv. It delivers a workflow-aligned artifact for N250.

### Boundary
- Turn attributed failures and bug reports into structured defect records.
- Model one-to-many and many-to-one mapping between failures and defects.
- Distinguish type, root cause, compliance sensitivity, and lifecycle position.
- Do not replace severity scoring; prepare the evidence and structure for it.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `bulk_classify`: classify many failures or tickets into a consistent registry.
- `trend_analysis`: emphasize category distribution, repeated patterns, and quality trends.
- `rca_driven`: classify from root-cause material and backfill lifecycle and traceability fields.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试执行结果`
- `自动化触发建议.md`
- `日志摘录.md`
- `Bug现象记录.md`

### optional enhancement inputs
- `测试失败归因.md`
- testcase ids and suite ids
- module ownership maps
- recent release identifiers
- compliance or audit obligations
- production incident or monitoring references

## Standalone rule / standalone usage
This skill must still work on one defect ticket, one failure cluster, one module slice, or one release batch.

Degradation rules:
- If attribution evidence is missing, classify only what the bug observation directly supports and mark `pending_attribution_confirmation`.
- If module ownership is unknown, keep `module` conservative and do not invent ownership.
- If the same failure can map to one shared defect, prefer shared `defect_id` logic over record duplication.
- Keep the registry shape stable even when some dimensions are provisional.

## Core output contract / core output contract
Default to csv-friendly tables or Markdown tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `defect_rows[]`
- `classification_summary`
- `root_cause_distribution[]`
- `test_traceability[]`
- `circuit_breaker_evaluation`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: structured_registry`
- `stage_position: testing_and_qa.result_and_defect_management.defect_classification`
- `workflow_node: N250`
- `node_artifact_target: 缺陷分类表.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Use the 5-dimensional matrix from `references/defect-classification-matrix.md` for every defect row.
- Assign one `defect_root_cause_kind` from `references/root-cause-taxonomy.md`.
- Mark `compliance_flag` explicitly and escalate zero-tolerance cases via `references/circuit-breaker-policy.md`.
- Record whether a failure created a new defect, updated an existing one, or was classified as flaky/no-defect.
- Capture `discovered_by`, `should_have_been_caught_by`, and `fix_verified_by` fields whenever traceability exists.
- Keep classification evidence-friendly so severity assessment can be audited later.

## Execution workflow / execution workflow
1. Read failure attribution, bug observation, and testcase context.
2. Decide the failure-to-defect mapping: one failure to one defect, many failures to one defect, or failure without defect.
3. Populate defect rows with type, module, lifecycle phases, root cause, and compliance sensitivity.
4. Add traceability links to testcase ids, alerts, user reports, fixes, and regression expectations.
5. Evaluate whether the classified defects trigger stop-the-line conditions.
6. Emit a registry that downstream severity and release gate consumers can use directly.

## Dynamic completeness / dynamic completeness
- Single defect: keep the row tight but complete.
- Failure cluster: emphasize shared cause and grouped defect mapping.
- Release batch: provide summary distributions and circuit-breaker view.
- Sparse evidence: permit `unknown` or `pending_confirmation` instead of fake certainty.

## Quality bar / quality bar
A good result should make defect inventory analyzable, auditable, and immediately reusable for severity decisions, RCA, gate checks, and regression backfill.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
- `references/defect-taxonomy-guide.md`
- `references/defect-classification-matrix.md`
- `references/root-cause-taxonomy.md`
- `references/circuit-breaker-policy.md`
- `references/n250-integration-map.md`
