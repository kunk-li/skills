# Cross-skill orchestration

N250 canonical chain:
1. `test-failure-attribution` explains what failed and why.
2. `defect-classification` decides whether failures map to one or more defects.
3. `defect-severity-assessment` scores urgency, SLA, and escalation.
4. `defect-reproduction-steps-generation` prepares engineering handoff and regression follow-up.

Shared ids:
- `failure_id`
- `defect_id`
- `tc_id`
- `ci_run_id`
- `fix_pr_id`
- `regression_tc_id`
