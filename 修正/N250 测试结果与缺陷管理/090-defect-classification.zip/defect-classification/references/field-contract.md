# Field contract

Common trace fields:
- `failure_id`
- `defect_id`
- `tc_id`
- `suite_id`
- `module`
- `environment`
- `evidence_refs[]`
- `owner`
- `status`

Output conventions:
- Markdown artifacts should still expose table-like stable sections.
- CSV artifacts should preserve ids and traceability columns.
- `downstream_handoff` should say what N260, N270, or N320 should consume next.
