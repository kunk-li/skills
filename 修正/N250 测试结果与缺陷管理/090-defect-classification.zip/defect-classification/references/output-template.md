# Output template

Required defect columns:
- defect_id
- related_failures[]
- type
- module
- phase_introduced
- phase_detected
- defect_root_cause_kind
- compliance_flag
- discovered_by
- should_have_been_caught_by[]
- fix_verified_by[]
- breaker_relevant
