# Readiness inheritance

- `ready`: preferred inputs are present and evidence is consistent enough for downstream use.
- `partial`: output contract is stable but some dimensions remain provisional.
- `blocked`: critical evidence gaps prevent trustworthy completion.

Rules:
- Preserve output shape even when readiness is partial.
- Use explicit pending markers rather than silent omissions.
- Treat upstream artifacts as the source of truth when they already exist.
