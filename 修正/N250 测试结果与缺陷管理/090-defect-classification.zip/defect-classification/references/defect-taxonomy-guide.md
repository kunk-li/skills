# Defect taxonomy guide

Primary defect `type` values:
- `functional`
- `ui_ux`
- `performance`
- `security`
- `compliance`
- `data_integrity`
