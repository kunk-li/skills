# Quality checklist

- Are facts and hypotheses clearly separated?
- Are ids, modules, environments, and testcase references preserved?
- Is uncertainty explicit instead of hidden?
- Are downstream actions or handoff notes present?
- Does the output match the workflow target artifact?
