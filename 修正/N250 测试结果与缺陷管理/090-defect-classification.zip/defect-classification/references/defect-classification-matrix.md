# Defect classification matrix

For each defect, classify:
- D1 `type`
- D2 `severity` (filled or pending)
- D3 `module`
- D4 `phase_introduced`
- D5 `phase_detected`
- `detection_delay`
