# Real examples

Example patterns to emulate:
- one flaky testcase mapping to zero defects but a quarantine action.
- three failed tests mapping to one shared defect.
- one compliance bug discovered in test and escalated immediately.
- one failed testcase turned into a regression testcase after fix verification.
