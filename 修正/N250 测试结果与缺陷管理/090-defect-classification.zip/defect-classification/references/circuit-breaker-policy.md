# Circuit breaker policy

Default stop-the-line triggers:
- any compliance blocker
- two consecutive blockers in the same module or release slice
- more than five new blockers in one day
- regression pass rate collapse from above 95% to below 80% across three runs

Default actions:
- pause merge or release candidate progression
- require RCA and owner acknowledgment
- notify PM, tech lead, and quality owner
- evaluate rollback or hotfix path
