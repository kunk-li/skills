# N250 integration map

Workflow node: `N250`

Preferred inputs:
- `测试执行结果`
- `自动化触发建议.md`
- `日志摘录.md`
- `Bug现象记录.md`

Target outputs:
- `测试失败归因.md`
- `缺陷分类表.csv`
- `缺陷严重级评估.csv`
- `缺陷复现步骤.md`

Downstream consumers:
- `N260` gate and special-test aggregation
- `N270` release preparation and blocking logic
- `N300` monitoring and incident triage
- `N320` postmortem and RCA follow-up
