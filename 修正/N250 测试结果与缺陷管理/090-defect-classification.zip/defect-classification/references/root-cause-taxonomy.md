# Root cause taxonomy

Use one dominant root cause kind:
- `RC01 logic_error`
- `RC02 null_handling`
- `RC03 concurrency`
- `RC04 idempotency`
- `RC05 transaction_boundary`
- `RC06 data_validation`
- `RC07 authentication`
- `RC08 authorization`
- `RC09 audit_compliance`
- `RC10 performance`
- `RC11 configuration`
- `RC12 external_integration`
