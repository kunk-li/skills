---
name: test-failure-attribution
description: generate workflow-aligned failure attribution from test outputs, logs, automation context, and bug observations. use when chatgpt works in testing & qa / result and defect management and must produce the n250 attribution artifact before defect classification, severity assessment, reproduction packaging, or circuit-breaker decisions.
---
# test-failure-attribution

## Role / role positioning
This skill aligns to testing & qa -> result and defect management -> 测试失败归因.md. It delivers a workflow-aligned artifact for N250.

### Boundary
- Explain why a failure likely happened and what evidence supports the conclusion.
- Model failure-to-defect relationships explicitly instead of assuming one failure equals one defect.
- Do not assign final release go/no-go; feed that decision downstream.
- Do not invent root causes without evidence and confidence.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_triage`: produce a fast first-pass attribution for one failed run or one defect ticket.
- `deep_analysis`: run the full attribution pipeline with evidence gathering, clustering, candidate ranking, and follow-up actions.
- `pattern_registry`: maintain or apply reusable attribution patterns and historical analogs across repeated failures.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试执行结果`
- `自动化触发建议.md`
- `日志摘录.md`
- `Bug现象记录.md`

### optional enhancement inputs
- trace or span snippets
- metrics snapshots
- recent deployment or config change records
- recent merged PR or release notes
- historical failure clusters
- impacted testcase ids, suite ids, or CI run ids

## Standalone rule / standalone usage
This skill must still work on one failed test, one CI run, one cluster of similar failures, or one user-reported defect signal.

Degradation rules:
- If automation context is missing, attribute only from test output, logs, and symptoms, and mark `pending_trigger_context`.
- If logs are partial, separate facts from hypotheses and lower confidence rather than over-claiming.
- If multiple failures likely share one root cause, cluster them instead of duplicating analysis.
- Keep the output contract stable even when the available evidence is narrow.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `failure_scope_summary`
- `attribution_rows[]`
- `evidence_bundle[]`
- `failure_clusters[]`
- `hypotheses_ranked[]`
- `recommended_next_steps[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: diagnostic_attribution`
- `stage_position: testing_and_qa.result_and_defect_management.test_failure_attribution`
- `workflow_node: N250`
- `node_artifact_target: 测试失败归因.md`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Classify every failure using one `failure_category` from `references/failure-category-taxonomy.md`.
- Separate **observed facts**, **hypotheses**, and **recommended actions**.
- Every top hypothesis must include confidence and supporting evidence references.
- Aggregate repeated failures into clusters when the signature is materially the same.
- When a failure likely belongs to test code, environment, or external dependency, say so explicitly instead of forcing a product defect conclusion.
- Flag circuit-breaker candidates when blocker accumulation or compliance evidence crosses thresholds from `references/circuit-breaker-policy.md`.

## Execution workflow / execution workflow
1. Collect evidence from test output, logs, automation trigger context, bug observations, and recent change signals.
2. Normalize each failure into a stable row with testcase, environment, symptom, and candidate ownership.
3. Match against known failure patterns and historical clusters when evidence exists.
4. Produce ranked hypotheses with category, confidence, evidence chain, and immediate next action.
5. Cluster repeated failures and mark whether they imply one shared defect, multiple defects, flaky behavior, or unknown scope.
6. Emit downstream handoff for classification, severity, reproduction, and circuit-breaker handling.

## Dynamic completeness / dynamic completeness
- Single failure: keep the report compact but still evidence-backed.
- Repeated CI failures: emphasize clustering, common cause, and routing.
- Release-preventing blockers: make circuit-breaker signals and compliance implications explicit.
- Sparse evidence: preserve structure and uncertainty markers rather than pretending certainty.

## Quality bar / quality bar
A good result should reduce triage time, make uncertainty explicit, and hand downstream skills a stable defect-ready evidence package. It must help teams decide whether to fix code, repair tests, stabilize environment, or stop the line.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/failure-category-taxonomy.md`
- `references/auto-attribution-pipeline.md`
- `references/circuit-breaker-policy.md`
- `references/n250-integration-map.md`
