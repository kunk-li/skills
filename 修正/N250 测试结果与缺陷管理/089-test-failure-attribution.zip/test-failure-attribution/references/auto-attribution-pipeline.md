# Auto attribution pipeline

1. collect evidence: output, logs, metrics, traces, deployment/config deltas
2. pattern match: known signatures and historical analogs
3. generate hypotheses: category, evidence, confidence, next check
4. cluster failures: same signature, same module, same run, same owner hint
5. validate after fix: rerun and record attribution accuracy
