# Common failure modes

Avoid these mistakes:
- Treating every failed testcase as a unique defect.
- Stating root cause without evidence or confidence.
- Ignoring environment and dependency signals.
- Mixing facts, guesses, and action items into one paragraph.
