# Failure category taxonomy

Use one primary `failure_category` per failure:
- `F01 code_bug`
- `F02 test_bug`
- `F03 data_dependency`
- `F04 env_issue`
- `F05 external_dependency_down`
- `F06 timing_issue`
- `F07 resource_exhaustion`
- `F08 flaky_race_condition`
- `F09 config_drift`
- `F10 known_limitation`
