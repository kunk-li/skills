# Output template

## metadata
selected_mode, readiness, evidence_profile, workflow_node, node_artifact_target

## failure_scope_summary
Summarize the failed runs, suites, environments, and notable patterns.

## attribution_rows
Recommended columns:
- failure_id
- tc_id
- environment
- symptom
- failure_category
- top_hypothesis
- confidence
- owner_hint
- shared_defect_candidate

## evidence_bundle
Quote or reference the key logs, metrics, traces, or observations.

## failure_clusters
Group repeated failures by shared signature when applicable.

## recommended_next_steps
Explain what to inspect, rerun, fix, or route next.
