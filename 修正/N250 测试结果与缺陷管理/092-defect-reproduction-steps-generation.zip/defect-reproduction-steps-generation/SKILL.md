---
name: defect-reproduction-steps-generation
description: generate workflow-aligned reproduction packages from failed testcases, bug observations, logs, and environment context. use when chatgpt works in testing & qa / result and defect management and must produce the n250 reproduction artifact for engineering handoff, fix verification, or regression backfill.
---
# defect-reproduction-steps-generation

## Role / role positioning
This skill aligns to testing & qa -> result and defect management -> 缺陷复现步骤.md. It delivers a workflow-aligned artifact for N250.

### Boundary
- Turn failed tests, bug reports, and observed symptoms into reproducible steps.
- Reuse testcase fixtures and failure evidence whenever possible.
- Describe environment, timing, concurrency, and data prerequisites explicitly.
- Do not claim the defect is verified unless reproduction has actually been confirmed.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `from_failed_tc`: derive reproduction packages from one or more failed testcases and their logs.
- `from_user_report`: build a structured reproduction draft from user or support observations.
- `docker_compose_script`: focus on environment scaffolding and reproducible runtime setup when local replay is hard.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试执行结果`
- `自动化触发建议.md`
- `日志摘录.md`
- `Bug现象记录.md`

### optional enhancement inputs
- `测试失败归因.md`
- `缺陷分类表.csv`
- `缺陷严重级评估.csv`
- failed testcase definitions or fixture manifests
- environment snapshots, config diffs, or docker compose snippets
- traces, HAR files, screenshots, or screen recordings

## Standalone rule / standalone usage
This skill must still work on one failed testcase, one user-reported bug, one concurrency issue, or one environment-specific defect.

Degradation rules:
- If the failed testcase already contains reproducible steps, derive the package from it before inventing new phrasing.
- If the environment is only partially known, mark missing conditions instead of fabricating them.
- If timing or concurrency matters, switch to structured timing notation rather than vague prose.
- Keep the output contract stable even when the reproduction confidence is partial.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `reproduction_packages[]`
- `environmental_conditions[]`
- `data_prerequisites[]`
- `timing_conditions[]`
- `verification_status`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: handoff_ready_result`
- `stage_position: testing_and_qa.result_and_defect_management.defect_reproduction_steps_generation`
- `workflow_node: N250`
- `node_artifact_target: 缺陷复现步骤.md`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Prefer `from_failed_tc` derivation whenever testcase and log evidence already exist.
- Structure each reproduction package as preconditions, steps, expected result, actual result, evidence, and cleanup.
- Use `references/reproduction-patterns-guide.md` for api, ui, concurrency, config, and performance reproduction variants.
- Use structured timing notation from `references/timing-and-concurrency-template.md` when order or latency matters.
- Reuse fixture names and environment conditions instead of duplicating setup prose.
- Track reproducibility status and confidence rather than declaring success by default.

## Execution workflow / execution workflow
1. Read the failed testcase or bug report and identify the minimal path to reproduce.
2. Extract preconditions, environment, data prerequisites, and expected vs actual behavior.
3. Convert timing- or concurrency-sensitive defects into structured steps.
4. Remove irrelevant noise while preserving evidence links and verification hooks.
5. Mark whether the package is verified, pending verification, or environment-limited.
6. Emit a handoff-ready document for engineering, QA, and regression backfill.

## Dynamic completeness / dynamic completeness
- Straightforward testcase failure: keep the package short and executable.
- User-reported issue: emphasize missing conditions and reproduction uncertainty.
- Concurrency or timing issue: use structured timing DSL and multi-actor setup.
- Environment-sensitive issue: foreground exact versions, flags, and data state.

## Quality bar / quality bar
A good result should let another engineer or tester reproduce the defect with minimal clarification, while honestly showing which parts are inferred and which parts are confirmed.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/reproduction-patterns-guide.md`
- `references/timing-and-concurrency-template.md`
- `references/circuit-breaker-policy.md`
- `references/n250-integration-map.md`
