# Common failure modes

Avoid these mistakes:
- Rewriting testcase steps manually when they already exist.
- Omitting environment or feature-flag conditions.
- Using vague timing language for race conditions.
- Claiming reproducibility without verification status.
