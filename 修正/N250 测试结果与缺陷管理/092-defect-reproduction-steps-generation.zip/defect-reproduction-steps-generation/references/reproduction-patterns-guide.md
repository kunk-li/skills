# Reproduction patterns guide

Common patterns:
- API defect: request, auth, payload, expected vs actual, logs
- UI defect: browser, navigation, clicks, screenshots, console
- concurrency defect: two actors, start window, expected split outcome
- config defect: feature flags, env vars, rollout state
- performance defect: dataset size, duration, thresholds, observations
