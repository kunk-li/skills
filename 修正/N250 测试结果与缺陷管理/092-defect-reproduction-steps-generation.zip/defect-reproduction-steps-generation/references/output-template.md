# Output template

Each reproduction package should include:
- `repro_id`
- `source_failure_id`
- `source_tc_id`
- `preconditions`
- `steps`
- `expected_result`
- `actual_result`
- `environmental_conditions`
- `data_prerequisites`
- `timing_conditions`
- `verification_status`
- `evidence_refs[]`
