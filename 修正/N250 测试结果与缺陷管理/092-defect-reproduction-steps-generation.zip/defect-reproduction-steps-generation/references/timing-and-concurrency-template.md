# Timing and concurrency template

Example structure:
- `t=0.0s` actor A performs action X
- `t=0.1s` actor B performs action Y
- `window <= 100ms`
- expected: one success, one conflict
- actual: both success
