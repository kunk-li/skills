# Persistence convention guide

Repository 层默认应关注：
- 软删过滤
- 多租户字段过滤
- 乐观锁版本字段
- 分页返回统一
- 锁定方法显式命名
- N+1 风险提示

不应承担：
- 业务流程编排
- HTTP 语义
- 权限决策
