# Repository query guide

规则：
- 简单静态条件：方法名或简洁接口
- 复杂静态条件：`@Query` / XML / named query
- 动态条件：Specification / QueryDSL / QueryWrapper / 等价 query builder
- 条件超过 3 个字段时，优先动态查询方案，不要拼长方法名
