---
name: repository-draft-generation
description: generate workflow-aligned repository or mapper drafts from schema definitions, query goals, pagination rules, lock hints, and index design guidance. use when chatgpt works in coding & implementation / scaffold generation and must produce the workflow-aligned Repository草稿.java for n190 while keeping business orchestration and transport semantics outside the persistence layer.
---
# repository-draft-generation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 脚手架生成 -> Repository草稿.java」。

它是 **direct_result** 型技能：目标是把 schema、查询目标、索引线索和持久化约束，落成可以被下游继续补 SQL、Mapper 或静态质量检查的 **`Repository草稿.java`**。

### Boundary / 边界
- 负责 repository / mapper 接口、查询方法、锁定方法、分页与返回契约、N+1 风险提示。
- 负责把 schema 与 index 约束转成 persistence 层约定。
- 不负责业务编排、HTTP 语义或复杂业务规则。
- 不负责伪装成可直接运行的持久层实现。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `jpa_only`：面向 Spring Data JPA / Specification / QueryDSL 风格。
- `mybatis_only`：面向 MyBatis / MyBatis-Plus / XML / Wrapper 风格。
- `polyglot`：JPA 主 + MyBatis 复杂查询等混合模式，但项目内规则必须写清。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `接口设计草案.yaml`
- `表结构设计草案.sql`

### 可选增强输入
- `索引建议清单.csv`
- `数据流图.md`
- `工程骨架.zip`
- 已有 ORM / Mapper 规范、分页规范、锁策略、软删 / 多租户约定

## Standalone rule / 独立使用规则
即使没有完整 Service 草稿，也可以单独使用。

降级规则：
- 若只有 schema，也可先输出 provisional repository / mapper contract。
- 顶部必须标明 `readiness: provisional`。
- 对查询目标、分页风格、锁策略和返回类型不确定的地方，必须显式写 `pending_persistence_questions[]`。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.scaffold_generation.repository_draft_generation`
  - `workflow_node: N190`
  - `node_artifact_target: Repository草稿.java`
  - `evidence_profile`
  - `persistence_style`
- `repository_registry[]`
- `query_method_plan[]`
- `pagination_contract`
- `locking_method_plan[]`
- `common_field_policy`
- `n_plus_one_watchlist[]`
- `pending_persistence_questions[]`
- `downstream_handoff`
  - `workflow_downstream`: `N200`, `N210`
  - `artifact_name: Repository草稿.java`
  - `sibling_contracts`: `controller`, `service`, `scaffold`
- `self_check`

## Design rules / 设计规则
### Query strategy discipline
简单查询、复杂静态查询、动态查询必须按统一选型表达，不要同项目随意混用。

### Naming discipline
复杂查询条件超过 3 个字段时，不要继续拉长方法名；应改为 Specification / Wrapper / DSL 或等价方案。

### Pagination discipline
分页返回风格必须统一；offset/page 与 cursor 风格不可无序混搭。

### Locking clarity
需要行锁、逻辑锁或 for-update 语义时，必须显式标出方法与用途。

### Common field consistency
软删、多租户、乐观锁、审计字段等基础字段处理应统一，不应每个 repository 自己发明。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness` 与 ORM / mapper style。
2. 从 schema 中抽取主键、唯一键、索引、软删、多租户与版本字段。
3. 从接口与业务动作中抽取查询、更新、分页、锁定需求。
4. 生成 `repository_registry[]` 与 `query_method_plan[]`。
5. 明确 `pagination_contract`、`locking_method_plan[]` 与 `common_field_policy`。
6. 扫描可能的 `n_plus_one_watchlist[]`。
7. 把不确定项放进 `pending_persistence_questions[]`。
8. 形成 workflow 对齐的 **`Repository草稿.java`**。
9. 输出 `downstream_handoff` 给 N200 / N210。
10. 用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 简单表：基础 CRUD + 分页 + exists / count。
- 中型模块：加入动态查询、锁定、软删、多租户。
- 复杂读模型：加入复杂查询策略说明和 N+1 风险观察点。

## Quality bar / 质量门槛
合格结果应让后续开发者明确知道：哪些查询怎么查、分页怎么统一、锁怎么表达、哪些字段自动处理、哪里可能有 N+1 风险，而不是到实现阶段再重想一遍持久层约定。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/n190-integration-map.md`
- `references/repository-query-guide.md`
- `references/persistence-convention-guide.md`
