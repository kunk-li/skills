# Service transaction and AOP guide

推荐规则：
- 读方法：`readOnly` 事务或等价声明
- 写方法：标准 REQUIRED 事务
- saga step / outbox publishing：必要时 `REQUIRES_NEW` 或 after-commit event
- 幂等、审计、并发控制、缓存优先声明式，不要散落在业务代码里
