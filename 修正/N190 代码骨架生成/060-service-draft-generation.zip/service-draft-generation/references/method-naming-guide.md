# Method naming guide

推荐命名：
- createXxx
- findXxxById
- listXxx / pageXxx
- updateXxx
- removeXxx / archiveXxx
- handleXxxCommand
- processXxxStep

避免同一 codebase 同时混用 `get/find/query`、`delete/remove`、`save/create` 的无序命名。