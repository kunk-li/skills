---
name: service-draft-generation
description: generate workflow-aligned service drafts from business flows, api contracts, transaction intent, concurrency rules, idempotency requirements, audit needs, and repository responsibilities. use when chatgpt works in coding & implementation / scaffold generation and must produce the workflow-aligned Service草稿.java for n190 while keeping transport and raw persistence details outside the service layer.
---
# service-draft-generation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 脚手架生成 -> Service草稿.java」。

它是 **direct_result** 型技能：目标是把接口契约、业务流程和 N170 的非功能约束，落成可以被继续补细节和做静态检查的 **`Service草稿.java`**。

### Boundary / 边界
- 负责业务步骤骨架、事务边界、异常语义、幂等 / 审计 / 并发 / 缓存 等声明式位点。
- 负责定义 service 与 repository 的职责边界。
- 不负责写 HTTP 细节或原始 SQL。
- 不负责伪装成已完成业务实现。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `business_logic_mode`：默认模式；突出业务步骤和方法编排。
- `aop_heavy_mode`：强调声明式幂等、审计、缓存、限流等 AOP 位点。
- `saga_mode`：面向 Saga / step service / after-commit event 的服务骨架。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `接口设计草案.yaml`
- `表结构设计草案.sql`

### 可选增强输入
- `并发控制建议.md`
- `幂等设计建议.md`
- `审计留痕方案.md`
- `权限模型设计.md`
- `性能风险分析.md`
- `安全风险分析.md`
- `工程骨架.zip`
- 现有 Service 风格与命名规范

## Standalone rule / 独立使用规则
即使没有完整 Controller 或 Repository 草稿，也可以单独使用。

降级规则：
- 若缺少非功能设计输入，可先输出 provisional service flow。
- 必须显式区分 `confirmed / inferred / pending` 的事务、幂等、并发和异常规则。
- 不确定的步骤应用 TODO，而不是硬编码为稳定实现。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.scaffold_generation.service_draft_generation`
  - `workflow_node: N190`
  - `node_artifact_target: Service草稿.java`
  - `evidence_profile`
  - `service_style`
- `service_registry[]`
- `method_flow_skeletons[]`
- `transaction_template[]`
- `aop_declaration_plan[]`
- `exception_semantics[]`
- `repository_call_hints[]`
- `pending_business_rules[]`
- `downstream_handoff`
  - `workflow_downstream`: `N200`, `N210`
  - `artifact_name: Service草稿.java`
  - `sibling_contracts`: `controller`, `repository`, `scaffold`
- `self_check`

## Design rules / 设计规则
### Transaction discipline
必须明确读写事务边界，必要时给出 `after_commit`、`requires_new`、`read_only` 等意图说明。

### Service slimming
若单方法步骤过长、分支过多或注入依赖过多，应显式提醒拆分。

### Exception discipline
只使用业务异常层次，不要默认 `RuntimeException` 或返回 `null`。

### Declarative nonfunctional concerns
幂等、审计、并发控制、缓存、限流等，优先表达为注解 / 切面 / 声明式位点。

### Naming consistency
Service 方法命名必须和 Controller 调用语义、Repository 访问意图保持一致。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness` 与 service style。
2. 从技术方案和 OpenAPI 中提炼业务动作与 method skeleton。
3. 结合 N170 约束，补事务、幂等、审计、并发与异常语义。
4. 生成 `service_registry[]` 与 `method_flow_skeletons[]`。
5. 标注 `repository_call_hints[]`，但不写原始 SQL。
6. 把不确定业务规则放进 `pending_business_rules[]`。
7. 形成 workflow 对齐的 **`Service草稿.java`**。
8. 输出 `downstream_handoff` 给 N200 / N210。
9. 用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 简单 CRUD：方法签名 + 基本事务 / 异常语义。
- 中等业务：加入幂等、审计、缓存与状态流转步骤。
- 复杂流程：加入 saga / after-commit event / 补偿位点说明。

## Quality bar / 质量门槛
合格结果应让后续开发者看清：方法做什么、哪些地方开事务、哪些地方做幂等 / 审计 / 并发保护、异常如何表达，而不是再猜一遍服务层设计。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/n190-integration-map.md`
- `references/service-transaction-aop-guide.md`
- `references/method-naming-guide.md`
