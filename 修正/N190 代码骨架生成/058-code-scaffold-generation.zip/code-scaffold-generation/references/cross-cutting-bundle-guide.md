# Cross-cutting bundle guide

脚手架应一次性放入：
- global exception handler
- request trace / request logging / correlation id
- auth filter / internal endpoint guard
- audit aspect / idempotent annotation / concurrency annotation
- base entity / api response / page response
- observability init / docker / ci / local dev bootstrap

这些内容应放在框架级，不要等到 Controller / Service / Repository 草稿时临时散落。