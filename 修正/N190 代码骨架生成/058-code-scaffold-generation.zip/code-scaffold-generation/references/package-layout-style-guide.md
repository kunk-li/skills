# Package layout style guide

## Allowed layout styles
- `layered`
- `feature_based`
- `ddd_hexagonal`

## Selection hints
- 小项目或教学演示：`layered`
- 中型业务系统：`feature_based`
- 长期演进的大型系统：`ddd_hexagonal`

同一工程只允许一种主布局风格；不要混用。若现有仓库已经有固定风格，优先兼容现有真实工程。