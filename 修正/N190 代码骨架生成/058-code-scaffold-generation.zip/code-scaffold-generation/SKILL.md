---
name: code-scaffold-generation
description: generate workflow-aligned project scaffolds, shared common modules, cross-cutting starter bundles, and bootstrap packages from technical solution notes, api contracts, schema drafts, and engineering conventions. use when chatgpt works in coding & implementation / scaffold generation and must produce the workflow-aligned 工程骨架.zip for n190 before controller, service, repository detail generation, implementation enrichment, or static quality checks.
---
# code-scaffold-generation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 脚手架生成 -> 工程骨架.zip」。

它是 **direct_result** 型技能：目标不是泛泛给项目建议，而是把上游技术方案、接口契约和数据模型，落成可以被下游直接消费的 **`工程骨架.zip`** 级别结构定义。

### Boundary / 边界
- 负责工程目录、模块边界、包布局、starter files、shared common 和 bootstrap package。
- 负责一次性定义 cross-cutting concern bundle，避免后续各层各写各的。
- 可以从 OpenAPI 与 schema 派生占位类和目录，但不替代 Controller / Service / Repository 的详细草稿。
- 不负责宣称代码已经可运行上线；只负责给出**稳定、可继续填充**的工程骨架。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `single_module_mode`：单模块或单 bounded context 骨架。
- `multi_module_mode`：多模块 / multi-module 工程骨架。
- `microservice_mode`：多服务 + shared-common + infra/bootstrap 的完整骨架。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `接口设计草案.yaml`
- `表结构设计草案.sql`

### 可选增强输入
- `模块边界图.md`
- `服务拆分建议.md`
- `并发控制建议.md`
- `幂等设计建议.md`
- `审计留痕方案.md`
- `权限模型设计.md`
- 目标语言、框架、构建工具、已有仓库风格、CI 约束

## Standalone rule / 独立使用规则
即使只拿到技术方案分析，也可以单独使用。

降级规则：
- 缺少 OpenAPI 或 schema 时，也可先生成 provisional scaffold。
- 顶部必须标明 `readiness: provisional`。
- 必须显式写出 `stack_assumptions[]`、`layout_assumptions[]` 与 `pending_decisions[]`。
- 不得伪装成“已经与真实契约完全对齐”。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.scaffold_generation.code_scaffold_generation`
  - `workflow_node: N190`
  - `node_artifact_target: 工程骨架.zip`
  - `evidence_profile`
  - `target_stack`
  - `package_layout_style`
- `scaffold_manifest`
- `project_structure`
- `package_layout_plan`
- `cross_cutting_concerns_bundle`
- `shared_common_generation`
- `bootstrap_package`
- `stack_assumptions[]`
- `pending_decisions[]`
- `downstream_handoff`
  - `workflow_downstream`: `N200`, `N210`
  - `artifact_name: 工程骨架.zip`
  - `sibling_contracts`: `controller`, `service`, `repository`
- `self_check`

## Design rules / 设计规则
### Package layout style
必须显式选一种：
- `layered`
- `feature_based`
- `ddd_hexagonal`

同一工程只允许一种主布局，不要混用。

### Contract-first scaffolding
若提供 `接口设计草案.yaml`，必须优先从契约反推：
- controller 包与 endpoint 聚合
- request / response DTO 目录
- validation / auth / error handling 占位

### Schema-aware persistence scaffolding
若提供 `表结构设计草案.sql`，必须给出：
- entity / model 目录
- repository / mapper 目录
- 分页、乐观锁、软删、多租户等基础字段承接点

### Cross-cutting once, not everywhere
必须一次性纳入：
- global exception handling
- request trace / logging
- auth / audit / idempotent / concurrency annotations or aspects
- metrics / tracing / structured logging
- base entity / api response / paginated response

### Bootstrap completeness
骨架应尽量包含：
- build files
- docker / compose
- ci config
- lint / format / commit hooks
- local dev bootstrap
- readme quick start

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`target_stack` 与 `package_layout_style`。
2. 从技术方案中抽取模块边界、分层模式和工程规模。
3. 从 OpenAPI 中抽取 controller / dto / auth / error 对齐点。
4. 从 schema 中抽取 entity / repository / mapper / base field 对齐点。
5. 生成 `project_structure` 与 `scaffold_manifest`。
6. 一次性补齐 `cross_cutting_concerns_bundle` 与 `shared_common_generation`。
7. 生成 `bootstrap_package`，覆盖本地开发与基础 CI。
8. 明确哪些内容是占位、假设与待确认。
9. 形成 workflow 对齐的 **`工程骨架.zip`** 产物说明。
10. 输出 `downstream_handoff` 给 N200 / N210。
11. 使用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 小项目：可输出单服务 / 单模块骨架。
- 中型项目：应覆盖多个模块和 shared common。
- 微服务项目：应覆盖服务目录、shared-common、infra 和 bootstrap 套件。

## Quality bar / 质量门槛
合格结果应让下游可以直接开始补 DTO、异常、SQL 和静态质量检查，而不需要重新讨论工程目录、命名方式、cross-cutting 放哪里。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/n190-integration-map.md`
- `references/package-layout-style-guide.md`
- `references/cross-cutting-bundle-guide.md`
