# Controller contract style

Controller 层默认只承担：
- HTTP 路由映射
- 参数接收 / validation
- service 调用
- response envelope 封装
- swagger / api docs 注解

不承担：
- 事务边界
- 原始 SQL
- 复杂业务判断
- repository 直接访问
