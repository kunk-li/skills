# N190 integration map

## Workflow position
- stage: 编码与实现 / 脚手架生成
- workflow node: N190

## Workflow inputs
- 技术方案分析.md
- 接口设计草案.yaml
- 表结构设计草案.sql

## Node outputs
- 工程骨架.zip
- Controller草稿.java
- Service草稿.java
- Repository草稿.java

## Downstream
- N200：补足 DTO / Enum / Validator / Exception / SQL 细节
- N210：进行代码规范、重复、异常、事务和线程安全检查

## Sibling contracts
- scaffold 提供 layout / base / cross-cutting 标准
- controller 绑定 API 契约
- service 绑定业务流程与 N170 非功能约束
- repository 绑定 schema / query / index 约束
