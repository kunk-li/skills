# N190 orchestration

N190 内部推荐顺序：

1. `code-scaffold-generation`
   - 确定目录结构、包布局、cross-cutting starter 与 shared common。
2. `controller-draft-generation`
   - 从 OpenAPI 派生接口层签名，固定 HTTP/DTO 边界。
3. `service-draft-generation`
   - 从业务流程与非功能约束派生事务、幂等、审计和异常语义。
4. `repository-draft-generation`
   - 从 schema 与查询目标派生数据访问接口与映射约定。

协同原则：
- Controller 不直接决定持久化细节。
- Service 不漂移 HTTP 契约。
- Repository 不吸收业务编排。
- 全部产物都要给 N200 / N210 可消费的 handoff。
