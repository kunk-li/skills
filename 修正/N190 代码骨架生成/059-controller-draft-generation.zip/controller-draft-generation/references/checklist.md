# Checklist

交付前逐项检查：

1. 是否显式声明 `selected_mode`、`readiness`、`workflow_node`、`node_artifact_target`。
2. 是否优先对齐 N190 标准输入：`技术方案分析.md`、`接口设计草案.yaml`、`表结构设计草案.sql`。
3. 是否区分 `confirmed / inferred / pending` 的信息来源。
4. 是否只做本层职责，不越界补全相邻层细节。
5. 是否能直接形成节点标准产物，而不是泛化建议。
6. 是否补写 `downstream_handoff` 给 N200 / N210。
7. 是否明确哪些内容是占位、TODO 或待确认。
