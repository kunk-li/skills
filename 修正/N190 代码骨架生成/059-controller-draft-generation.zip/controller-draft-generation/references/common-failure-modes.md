# Common failure modes

常见失败模式：

- 把 N190 写成通用代码建议，而不是 workflow 节点产物生成。
- 忽略 `接口设计草案.yaml`，导致骨架与 N150 契约漂移。
- 忽略 `表结构设计草案.sql`，导致 Repository 与实体映射失真。
- 在 Controller 中写事务、SQL、复杂业务编排。
- 在 Service 中写 HTTP 语义或原始持久化细节。
- 在 Repository 中塞业务规则、跨层决策或 transport 语义。
- 没有标出假设与待确认项，导致占位实现看似已可上线。
- 只给目录树，不给 cross-cutting bundle、命名规范和下游交接说明。
