# Example I/O

## Example input
- 技术方案分析.md：订单域采用 feature-based 分层
- 接口设计草案.yaml：包含 `/orders`、`/orders/{id}`、`POST /orders/{id}/cancel`
- 表结构设计草案.sql：`orders`、`order_items` 两张表

## Example output expectation
- `code-scaffold-generation`：产出 feature-based 工程骨架 + shared common + bootstrap package
- `controller-draft-generation`：产出 `OrderController`，方法签名对齐 OpenAPI
- `service-draft-generation`：产出 `OrderService`，带事务、幂等、审计位置说明
- `repository-draft-generation`：产出 `OrderRepository`，含分页、锁定和 N+1 风险提示
