# OpenAPI to Controller mapping

映射规则：
- `paths.{path}.{method}` -> controller method
- path params -> `@PathVariable`
- query params -> `@RequestParam`
- header params -> `@RequestHeader`
- request body -> request DTO
- responses -> response wrapper / dto / swagger annotations
- security -> `@RequireRole` / `@RequirePermission` 或等价声明

优先保证方法签名与 OpenAPI 对齐；不要先写业务实现。