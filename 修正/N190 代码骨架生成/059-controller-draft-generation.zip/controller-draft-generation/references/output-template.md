# Output template

在未被用户指定其他格式时，默认使用以下结构输出。保留标题顺序；字段可扩展，但不要缺主干。

```markdown
# <artifact name>

## metadata
- selected_mode:
- readiness:
- function_bias: direct_result
- stage_position:
- workflow_node: N190
- node_artifact_target:
- evidence_profile:

## main_result
[本 skill 的核心结构化结果]

## unresolved_items
- ...

## downstream_handoff
- workflow_downstream:
- artifact_name:
- sibling_contracts:

## self_check
- [ ] 输入是否对齐 workflow 节点定义
- [ ] 输出是否能被下游直接消费
```
