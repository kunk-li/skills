---
name: controller-draft-generation
description: generate workflow-aligned controller drafts from openapi contracts, endpoint rules, validation constraints, response envelopes, and authorization declarations. use when chatgpt works in coding & implementation / scaffold generation and must produce the workflow-aligned Controller草稿.java for n190 while keeping business orchestration, transactions, and persistence details outside the controller layer.
---
# controller-draft-generation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 脚手架生成 -> Controller草稿.java」。

它是 **direct_result** 型技能：目标是把 N150 的接口契约和 N190 的工程骨架，落成可以被下游继续补实现与静态检查的 **`Controller草稿.java`**。

### Boundary / 边界
- 负责 endpoint 映射、参数接收、validation、swagger 注解、权限声明、service 调用占位与统一响应包装。
- 负责与 OpenAPI 保持 contract-first 对齐。
- 不负责写复杂业务逻辑、事务边界或 Repository 调用。
- 不负责伪装成已完成的可上线接口实现。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `from_openapi`：默认模式；从 `接口设计草案.yaml` 派生 Controller。
- `crud_controller`：从资源定义批量生成 CRUD 五方法骨架。
- `skeleton_only`：仅给类与方法签名、注解和 TODO，不展开 body。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `接口设计草案.yaml`
- `表结构设计草案.sql`

### 可选增强输入
- `错误码清单.csv`
- `权限模型设计.md`
- `幂等设计建议.md`
- `工程骨架.zip` 或脚手架目录约定
- 现有 Controller 风格、返回包装约定、注解规范

## Standalone rule / 独立使用规则
即使缺少完整 Service / Repository 草稿，也可以单独使用。

降级规则：
- 有 OpenAPI 时，仍应先完成 Controller 契约层草稿。
- 若缺 OpenAPI，只能基于 endpoint 列表输出 provisional controller。
- 顶部必须标明 `readiness: provisional`，并显式写出 `service_signature_hints[]`。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.scaffold_generation.controller_draft_generation`
  - `workflow_node: N190`
  - `node_artifact_target: Controller草稿.java`
  - `evidence_profile`
  - `response_envelope_style`
- `controller_registry[]`
- `endpoint_to_method_mapping[]`
- `validation_mapping[]`
- `swagger_annotation_plan[]`
- `authorization_declaration[]`
- `service_signature_hints[]`
- `pending_contract_gaps[]`
- `downstream_handoff`
  - `workflow_downstream`: `N200`, `N210`
  - `artifact_name: Controller草稿.java`
  - `sibling_contracts`: `service`, `repository`, `scaffold`
- `self_check`

## Design rules / 设计规则
### OpenAPI first
若提供 `接口设计草案.yaml`，必须优先从契约派生 method signature。

### Validation auto derivation
应尽量从 schema 派生：
- required -> `@NotNull` / `@NotBlank`
- min/max length -> `@Size`
- numeric range -> `@Min` / `@Max`
- pattern -> `@Pattern`
- enum / format -> 自定义或等价校验注解

### Response wrapper discipline
必须统一写成功包装、错误走全局异常处理，不混用 Map、裸对象和多种风格。

### Swagger completeness
应生成 summary / description / response / parameter 占位，避免文档缺口。

### Authorization declaration discipline
权限统一用声明式注解或等价声明，不要在 Controller 内塞复杂权限逻辑。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness` 与 web stack。
2. 解析 OpenAPI、接口语义、header / path / query / body 约束。
3. 生成 controller class 与 method 签名。
4. 映射 validation 注解与 response envelope。
5. 补齐 swagger annotation plan 与 authorization declaration。
6. 为每个方法写 `service_signature_hints[]`，但不展开业务实现。
7. 把不确定的契约缺口放进 `pending_contract_gaps[]`。
8. 形成 workflow 对齐的 **`Controller草稿.java`**。
9. 输出 `downstream_handoff` 给 N200 / N210。
10. 用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 单接口：覆盖单类或单 endpoint。
- 单资源：覆盖 CRUD + 动作型接口。
- 多模块：按模块输出多个 controller registry 项。

## Quality bar / 质量门槛
合格结果应保证 HTTP 层签名、参数、validation、响应包装和权限声明已经稳定，不会让后续实现因为契约漂移而返工。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/n190-integration-map.md`
- `references/openapi-controller-mapping.md`
- `references/controller-contract-style.md`
