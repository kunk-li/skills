# Common Failure Modes

- only drawing happy path and forgetting failure recovery
- saying systems “interact” without source, target, or direction
- omitting data classification for sensitive flows
- mixing provisional guesses with confirmed flows
- inventing indexes or schema changes instead of handing off to 046 / 047
- ignoring batch, replay, or DLQ paths in event-heavy systems
