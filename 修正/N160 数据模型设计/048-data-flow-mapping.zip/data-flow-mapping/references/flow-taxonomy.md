# Flow Taxonomy

## flow_category
- happy_path
- retry
- fallback
- compensation
- dead_letter
- replay
- migration

## flow_semantics
- sync_call
- async_publish
- async_subscribe
- batch_export
- streaming_push
- webhook
- file_transfer
- db_replication
- shared_storage_access

## topology
- point_to_point
- broadcast
- gather
- pipeline
- request_response
- pub_sub
