# Scoring Rubric

Score each dimension 1-5:
- lifecycle clarity
- flow completeness
- exception-path coverage
- data classification clarity
- metrics usefulness
- downstream handoff usability

24-30: implementation-ready
18-23: review-ready
12-17: partial
below 12: provisional only
