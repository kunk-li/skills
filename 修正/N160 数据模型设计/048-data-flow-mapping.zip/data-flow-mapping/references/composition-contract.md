# Composition Contract

Stable output names:
- `flow_scope`
- `data_lifecycle_views`
- `flow_catalog`
- `flow_diagram`
- `exception_path_coverage`
- `data_classification_summary`
- `flow_metrics_summary`
- `gaps_and_risks`
- `downstream_handoff`

Composition notes:
- consumes 046 schema names and 047 access-path hints
- feeds dependency, consistency, testing, monitoring, and N170 design
