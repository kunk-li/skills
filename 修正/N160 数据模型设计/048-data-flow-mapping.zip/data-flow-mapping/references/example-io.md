# Example IO

Input:
- ticket approval technical flow
- schema for ticket, approval_step, audit_event
- api endpoints for submit / approve / reject
- async audit event publication

Output:
- happy path from submit to approval and audit write
- retry / compensation notes for async publish failure
- data classification note for ticket payload vs audit payload
- index handoff hint for audit export by date
