# Mode Selection

| mode | use when | emphasis |
| --- | --- | --- |
| flow-from-analysis | requirements and tech notes drive the map | end-to-end logical flow |
| from-api-catalog | sync APIs dominate | request-response chains |
| from-event-catalog | async/event systems dominate | publish-subscribe chains |
| resilience-review | failures and recovery matter most | exception paths |
