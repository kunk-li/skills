# Flow Structure Guide

Recommended order:
1. flow scope
2. lifecycle view
3. flow catalog
4. diagram
5. exception coverage
6. gaps and risks
7. downstream handoff

Diagram rule:
- use stable names from upstream schemas / APIs / events
- use one notation style consistently
- label sync vs async vs batch where it matters
