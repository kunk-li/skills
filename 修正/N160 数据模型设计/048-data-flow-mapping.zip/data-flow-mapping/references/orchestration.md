# Orchestration

## Upstream
Best inputs:
- technical solution analysis
- table-schema-design-recommendation
- api-design-recommendation
- index-design-recommendation
- state transition and business rule artifacts

## Downstream
Main consumers:
- dependency identification
- data consistency check generation
- performance and reliability review
- monitoring design
- test scenario generation

## 048 -> other nodes
| 048 field | consumer | why |
| --- | --- | --- |
| flow_catalog | dependency identification | identify coupling and handoffs |
| data_classification_summary | security / compliance review | data protection scope |
| exception_path_coverage | test / resilience design | failure-case coverage |
| flow_metrics_summary | performance / monitoring | capacity and latency assumptions |
