---
name: data-flow-mapping
description: map data creation, change, synchronization, retry, compensation, and consumption paths from technical solution notes, table schemas, api catalogs, event catalogs, or existing operational knowledge. use when chatgpt works in technical solution design / data design and must produce structured data-flow understanding for consistency review, dependency identification, data consistency checks, monitoring design, or resilience analysis.
---
# data-flow-mapping

## Role / 角色定位
本 skill 对齐技能总表中的「技术方案设计 -> 数据设计 -> 数据流分析 / 数据流梳理」。

它是 **understanding_support** 型技能：重点是把“创建、变更、同步和消费链路”讲清楚，帮助后续一致性、测试、依赖、监控和韧性设计，而不是直接替代最终技术裁决。

### Boundary / 边界
- 止于方案、接口、数据与任务设计，不进入代码编写、测试执行和发布落地。
- 负责组织关系、流转、拓扑和异常路径，不直接输出最终实现动作。
- 表结构定义优先由 046 提供；访问路径优化优先由 047 提供。
- 本 skill 不应把安全、容量、SLO、监控全部定死，只提供 flow-aware 输入与风险提示。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 4 种模式：
- `flow-from-analysis`：从技术方案、业务规则、状态流转和表结构出发梳理流；默认模式。
- `from-api-catalog`：基于 API surface 推导同步调用链与写入链路。
- `from-event-catalog`：基于事件或消息目录推导异步发布 / 订阅链路。
- `resilience-review`：围绕 retry / fallback / compensation / DLQ / replay 做异常流补全。

## Primary inputs / 主要输入
### 推荐输入
- 技术方案分析
- 表结构设计建议
- API catalog / interface intent / webhook list
- 事件目录、批处理、定时任务、导出任务
- 状态流转、审计要求、保留与归档规则

### 可选增强
- 线上事故复盘、重试规则、DLQ 说明
- 流量规模预估、峰值倍数、传输大小
- 敏感数据分类要求

## Standalone rule / 独立使用规则
可以单独使用，但没有 046 / API / 事件目录时必须降级：
- 允许从 PRD、技术方案文字和状态流转中推 provisional flows。
- 但必须显式标记 `confirmed / inferred / pending`。
- 若异常流证据不足，不能假装系统天然可靠；应在 `exception_path_coverage` 中写出缺口。

## Core output contract / 核心输出契约
默认输出 Markdown，图示优先 ASCII；环境支持时可追加 Mermaid。优先遵循 `references/output-template.md` 与 `references/flow-structure.md`。

结果至少包含：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: understanding_support`
  - `stage_position: technical_solution_design.data_design.data_flow_analysis`
  - `evidence_profile`
- `flow_scope`
- `data_lifecycle_views[]`
- `flow_catalog[]`
  - `flow_id`
  - `flow_category`
  - `flow_semantics`
  - `source`
  - `target`
  - `payload`
  - `trigger`
  - `topology`
  - `sync_or_async`
  - `storage_touchpoints`
  - `data_classification`
  - `flow_metrics`
  - `reliability_notes`
  - `evidence`
  - `confidence`
- `flow_diagram`
- `exception_path_coverage`
- `data_classification_summary`
- `flow_metrics_summary`
- `gaps_and_risks`
- `open_questions[]`
- `downstream_handoff`
- `self_check`

## Design rules / 设计规则
### Happy + exception coverage / 正常流 + 异常流并存
每个关键业务用例都应至少描述：
- 1 条 `happy_path`
- 以及适用时至少 1 条 `retry` / `fallback` / `compensation` / `dead_letter` / `replay`

如果某类异常流不适用，必须明确写 `not_applicable`，而不是完全缺失。

### Flow semantics discipline / 语义纪律
每条流都必须给出 `flow_semantics`，只允许使用受控类别，如：
- `sync_call`
- `async_publish`
- `async_subscribe`
- `batch_export`
- `streaming_push`
- `webhook`
- `file_transfer`
- `db_replication`
- `shared_storage_access`

### Data classification discipline / 数据分类纪律
每条流必须标 `data_classification`：
- `public`
- `internal`
- `confidential`
- `pii`
- `financial`
- `regulated`

对高敏类别必须补充最少保护提示：传输加密、日志脱敏、访问控制、审计要求。

### Topology and direction discipline / 拓扑与方向纪律
每条流必须写明 `topology`，如：
- `point_to_point`
- `broadcast`
- `gather`
- `pipeline`
- `request_response`
- `pub_sub`

不要用模糊的“系统 A 和 B 有交互”代替方向化流定义。

### Flow metrics discipline / 流量规模纪律
关键流尽量给：
- `per_event_size`
- `events_per_second` 或 daily volume
- 延迟预期
- delivery guarantee / retry budget
- peak factor

若只能估算，也要标 estimated，而不是伪装成测量值。

### Boundary discipline / 边界纪律
- 不要在本 skill 中重新定义表结构；引用 046 的命名。
- 不要直接设计完整索引；只指出某条流需要的 access path，再 handoff 给 047。
- 不要把 resilience、security、monitoring 直接定成最终实现，只输出 flow-aware 输入。

## Execution workflow / 执行流程
1. 识别 selected mode 与 evidence profile。
2. 统一业务对象、表、API、事件和批任务命名。
3. 先画 happy path，再补 retry / fallback / compensation / DLQ / replay。
4. 为每条流补上 semantics、topology、direction、classification、metrics。
5. 对涉及存储的步骤引用 046 的表或对象命名。
6. 对依赖访问路径的批量 / 检索流，向 047 提出 access-path hints。
7. 输出 lifecycle view、diagram、异常覆盖度和 gaps。
8. 形成 handoff 给一致性检查、依赖识别、监控、测试与 N170 设计。
9. 运行 checklist 与 common-failure review。

## Dynamic completeness / 动态完整度
- 单用例：全链路细化到触发、写入、消费、异常
- 中等系统：覆盖全部核心链路 + 关键异常流
- 大型系统：优先覆盖核心 happy path、跨边界链路和高风险异常流；低风险边角链路可摘要

## Quality bar / 质量门槛
合格结果应让 reviewer 能快速回答：
- 数据从哪来、到哪去、怎么失败、如何恢复
- 哪些流含敏感数据
- 哪些流依赖异步、批量或跨库一致性
- 哪些流可能需要额外索引、监控、测试与补偿设计

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/flow-taxonomy.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/output-template.md`
- `references/flow-structure.md`
- `references/flow-taxonomy.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
