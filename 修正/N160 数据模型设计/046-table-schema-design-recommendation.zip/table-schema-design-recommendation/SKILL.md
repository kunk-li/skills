---
name: table-schema-design-recommendation
description: recommend tables, columns, relationships, primary key strategies, stack-aware ddl choices, standard columns, constraint placement, and schema evolution rules from requirement analysis, technical solution notes, data objects, or existing schema inputs. use when chatgpt works in technical solution design / data design and must produce draft, checklist, or structured schema recommendations for downstream index design, data-flow mapping, performance review, repository drafting, sql generation, or engineering review.
---
# table-schema-design-recommendation

## Role / 角色定位
本 skill 对齐技能总表中的「技术方案设计 -> 数据设计 -> 表结构设计」。

它是 **direct_result** 型技能：要把“给出表、字段、关系和约束建议”落成可交付的结构化结果，而不是只给口头建议。

### Boundary / 边界
- 止于方案、接口、数据与任务设计，不进入代码编写、测试执行和发布落地。
- 负责提出表结构、字段、主键、约束、时间字段、软删和演进建议。
- 不直接修改真实数据库、代码或线上流程。
- 二级索引、覆盖索引、冗余索引治理主要交给 `index-design-recommendation`。
- 数据创建 / 变更 / 同步 / 异常链路主要交给 `data-flow-mapping`。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 4 种模式：
- `schema-from-analysis`：从开发需求解析、技术方案分析、数据对象和规则中设计表结构；默认模式。
- `reverse-engineer`：从现有 schema / DDL / ER 图逆向整理结构并指出问题。
- `compare-stacks`：同一逻辑模型在 mysql / postgres / sqlserver / oracle 等候选栈下做差异对比。
- `migration-planning`：围绕 schema 演进、兼容性、迁移与回滚策略输出。

## Primary inputs / 主要输入
### 推荐输入
- 开发需求解析 / technical solution analysis
- 数据对象清单、业务规则、状态流转、权限与审计要求
- 现有 DDL、ER 图、schema 文档、migration 历史
- API 草案、批处理需求、保留期限 / retention 规则

### 可选增强
- 目标数据库引擎、版本、扩展能力
- 多租户、append-only、PII / financial / regulated 要求
- 历史 schema 变更事故、性能瓶颈、表规模预估

## Standalone rule / 独立使用规则
即使没有上游结构化输出，也可以单独使用。

降级规则：
- 若只有 PRD 或技术方案文字，允许反推 provisional schema。
- 若只有既有 DDL，允许做 reverse-engineer 整理与 gap 分析。
- 若 `target_stack` 未确认，不要伪装成“最终可执行通用 DDL”；应输出 compare matrix 或 `pending decision`。
- 必须把 `confirmed / inferred / pending` 分层写清楚。

## Core output contract / 核心输出契约
默认输出 Markdown，并可在需要时补 SQL appendix 或 migration appendix。优先遵循 `references/output-template.md` 与 `references/ddl-structure.md`。

结果至少包含这些结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.data_design.table_schema_design`
  - `evidence_profile`
- `target_stack`
  - `engine`
  - `dialect`
  - `version`
  - `extensions`
  - `stack_decision_status`
- `logical_model_summary`
- `table_catalog[]`
  - `table_id`
  - `name`
  - `purpose`
  - `store_type`
  - `columns[]`
  - `primary_key`
  - `foreign_keys_or_soft_refs`
  - `standard_columns_profile`
  - `soft_delete_policy`
  - `timezone_policy`
  - `retention_or_append_only_hint`
  - `pii_or_sensitive_fields`
  - `evidence`
  - `confidence`
- `pk_strategy_decisions[]`
- `standard_columns_template`
- `constraints_placement`
- `schema_evolution_rules`
- `migration_plan[]`
- `open_questions[]`
- `downstream_handoff`
- `self_check`

## Design rules / 设计规则
### Stack-first rule / 栈先行
先确认 `target_stack`，再落物理 DDL。

如果目标栈不清楚：
- 先给 `stack_comparison`，再给 provisional DDL。
- 显式说明 mysql / postgres / sqlserver / oracle 的差异点，不要用“通用 SQL”掩盖差异。

典型差异应被显式利用或规避：
- MySQL: `JSON`, generated column, InnoDB, `utf8mb4` / collation
- PostgreSQL: `JSONB`, `GIN`, `TIMESTAMPTZ`, partitioning
- SQL Server / Oracle: computed or generated behavior only when justified

### PK strategy discipline / 主键策略纪律
每张表必须给出主键策略或继承的项目级策略。

允许的推荐类型：
- `auto_increment` / `bigserial`
- `ulid`
- `snowflake`
- `uuid`
- `composite`

决策至少考虑：
- 预期数据量
- 写入并发
- 是否需要 public_id 与内部 PK 分离
- 是否要跨库唯一
- 是否需要有序写入 / 减少索引热点

### Standard columns discipline / 标准列纪律
默认标准列模板至少考虑：
- `id`
- `created_at` / `updated_at`
- `created_by` / `updated_by`
- `version`

按场景可选：
- `is_deleted` / `deleted_at` / `deleted_by`
- `tenant_id`

但以下表可豁免，且必须写明理由：
- append-only 表
- lookup / reference 表
- 临时或幂等表

所有时间字段默认 UTC 存储。显示时区转换属于应用层或 UI 层，不属于持久层时间真相。

### Constraint placement / 约束落点纪律
每条关键约束都要归类为：
- `db_constraint`
- `application_constraint`
- `double_sided`

放置原则：
- 数据不变式优先放 DB 层
- 合规关键或 append-only 规则可做双保险
- 跨服务、依赖外部状态、不可稳定表达的规则不要假装能完全落 DB

### Evolution discipline / 演进纪律
任何破坏性变更都必须附：
- forward plan
- rollback plan
- compatibility note
- risk note

默认兼容规则：至少向后兼容 1 个版本，除非明确写出 waiver。

大表变更必须提及在线迁移或分阶段迁移策略，而不是只写一个理想化 `ALTER TABLE`。

### Boundary discipline / 边界纪律
- 不要在本 skill 中展开完整二级索引策略；将访问路径优化交给 047。
- 不要用 narrative flow 取代 schema 设计；流向和异常链路交给 048。
- 不要把业务猜测写成 finalized DDL。

## Execution workflow / 执行流程
1. 识别 selected mode、stage position、evidence profile。
2. 确认或比较 `target_stack`。
3. 归一业务对象、生命周期、ownership、敏感数据类别。
4. 先建逻辑模型，再映射到物理表与存储特性。
5. 为每张表给出 PK 策略与理由。
6. 应用标准列、软删、时区、租户与审计模板。
7. 将关键规则落到 `constraints_placement`。
8. 记录栈差异、兼容性影响和 schema evolution 策略。
9. 在需要时给 SQL appendix 或 migration appendix。
10. 输出给 047 / 048 / N170 / N190 / N200 / N330 的 handoff。
11. 运行 checklist 与 common-failure review。

## Dynamic completeness / 动态完整度
- 单个 feature：覆盖全部核心表
- 中等系统：覆盖全部核心表 + 关键卫星表
- 大型域：核心表详写，低价值卫星表可摘要并显式 defer

不要为了凑条数而制造表，也不要因为系统大就只给空泛原则。

## Quality bar / 质量门槛
合格结果应当能被以下下游直接消费，而不需重新解释：
- `index-design-recommendation`
- `data-flow-mapping`
- 性能 / 安全 / 审计设计
- Repository / SQL / migration 草稿生成

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/stack-and-pk-taxonomy.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/output-template.md`
- `references/ddl-structure.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/stack-and-pk-taxonomy.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
