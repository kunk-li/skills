# Scoring Rubric

Score each dimension 1-5:
- stack fit
- schema completeness
- PK and lifecycle clarity
- constraint placement clarity
- evolution readiness
- downstream handoff usability

24-30: implementation-ready
18-23: review-ready
12-17: partial
below 12: provisional only
