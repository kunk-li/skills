# Mode Selection

| mode | use when | emphasis |
| --- | --- | --- |
| schema-from-analysis | requirements and solution notes are primary | fresh schema proposal |
| reverse-engineer | existing ddl or schema already exists | normalize and gap-find |
| compare-stacks | target DB is undecided | engine-aware comparison |
| migration-planning | schema change risk is central | evolution, rollback, rollout |
