# Checklist

- target_stack chosen or explicitly pending
- table catalog complete for in-scope entities
- every table has PK rationale
- standard columns / exemptions explained
- timezone policy explicit
- soft-delete policy explicit
- constraints placed in db / application / double_sided buckets
- schema evolution and migration notes included
- secondary index work deferred to 047 where appropriate
- downstream handoff included
