# Stack and PK Taxonomy

## Engine notes
- mysql_8: good default OLTP choice, explicit charset/collation matters
- postgres_15: strong JSONB and advanced indexing story
- sqlserver_2022 / oracle_19: use only when enterprise constraints require them

## PK guidance
- auto_increment / bigserial: simple, local, low-concurrency friendly
- ulid: sortable and portable when public_id style matters
- snowflake: strong for distributed high-volume writes
- uuid: use cautiously when random write amplification is acceptable or mitigated
- composite: use when natural identity is truly stable and query patterns justify it
