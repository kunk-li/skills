# Common Failure Modes

- generic ddl with no target stack
- UUID used everywhere without volume or write-path reasoning
- soft delete mixed inconsistently across similar tables
- UTC / timezone policy omitted
- all business rules forced into DB constraints even when external-state dependent
- no migration / rollback note for destructive change
- secondary index over-design inside this skill instead of handing off to 047
