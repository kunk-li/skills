# Composition Contract

This skill should emit stable, machine-readable names for:
- `table_catalog`
- `pk_strategy_decisions`
- `standard_columns_template`
- `constraints_placement`
- `schema_evolution_rules`
- `migration_plan`
- `downstream_handoff`

Downstream expectations:
- 047 consumes valid table/column names and uniqueness baseline
- 048 consumes storage touchpoints, append-only hints, and sensitive data markers
