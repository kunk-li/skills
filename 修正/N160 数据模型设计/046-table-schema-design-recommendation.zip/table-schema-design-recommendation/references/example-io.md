# Example IO

Input:
- technical solution summary for ticket approval
- data objects: ticket, approval_step, audit_event
- target_stack: mysql_8

Output:
- core table catalog with ticket / approval_step / audit_event
- PK strategy note per table
- standard columns policy
- append-only exemption for audit_event
- migration and downstream handoff notes
