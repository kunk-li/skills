# DDL Structure Guide

Default to review-oriented Markdown first. Add SQL snippets only when requested or when the design would be unclear without them.

Minimum SQL appendix structure:
1. project stack note
2. table blocks ordered by lifecycle or dependency
3. PK / UNIQUE / CHECK / FK or soft reference notes
4. migration note when the DDL implies destructive change

Keep SQL stack-aware:
- MySQL: engine, charset, collation, JSON handling
- PostgreSQL: JSONB, TIMESTAMPTZ, GIN / partition notes when relevant
- Do not emit fake cross-engine DDL and call it final.
