---
name: index-design-recommendation
description: recommend unique, composite, covering, and query-driven indexes from query patterns, schema recommendations, api usage, batch access paths, or existing explain evidence. use when chatgpt works in technical solution design / data design and must produce decision-support index recommendations, redundancy audits, read-write tradeoff notes, and validation plans for downstream query optimization, performance review, or data-flow design.
---
# index-design-recommendation

## Role / 角色定位
本 skill 对齐技能总表中的「技术方案设计 -> 数据设计 -> 索引设计」。

它是 **decision_support** 型技能：核心不是直接改数据库，而是把“给出唯一索引、联合索引和查询索引建议”转成有依据、有取舍、有审计能力的决策产物。

### Boundary / 边界
- 止于方案、接口、数据与任务设计，不进入代码编写、测试执行和发布落地。
- 负责提出索引建议、解释读写权衡、指出冗余和缺失。
- 不直接创建或修改线上索引。
- 表结构本身、字段类型和主键策略优先由 `table-schema-design-recommendation` 定义。
- 流量和异常链路的语义说明优先由 `data-flow-mapping` 补足。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `pre-design`：基于 query patterns 和 046 的表结构做前置索引设计；默认模式。
- `audit-existing`：基于已有 schema、索引清单、usage stats 或 explain 结果做索引审计。
- `explain-driven-review`：围绕具体慢查询、EXPLAIN 或 rows examined 问题给修正建议。

## Primary inputs / 主要输入
### 推荐输入
- `query_patterns_input`
- 表结构设计结果、主键和唯一约束
- API 草案中的过滤、分页、排序和搜索场景
- 批处理、导出、同步、归档任务说明
- 已有 explain、慢查询、usage stats（如有）

### 可选增强
- 表规模预估、写入 TPS、读写比例
- retention / append-only / 高峰倍数
- 现有索引清单和冗余索引候选

## Standalone rule / 独立使用规则
可以单独使用，但没有 query patterns 时必须降级：
- 先从 API、报表、批量导出、列表页、检索需求中提 provisional patterns。
- 将这些模式明确标记为 `inferred_query_pattern`。
- 不能因为“怕漏加”就生成大量缺乏服务对象的索引。

## Core output contract / 核心输出契约
默认输出 Markdown，必要时附 CSV-like table。优先遵循 `references/output-template.md` 与 `references/query-pattern-contract.md`。

结果至少包含：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: decision_support`
  - `stage_position: technical_solution_design.data_design.index_design`
  - `evidence_profile`
- `query_patterns_summary`
- `index_catalog[]`
  - `idx_id`
  - `table_name`
  - `index_name`
  - `columns`
  - `index_type`
  - `index_purpose`
  - `query_patterns_served`
  - `composite_order_rationale`
  - `uniqueness`
  - `write_cost_note`
  - `storage_cost_note`
  - `evidence`
  - `confidence`
- `covering_index_analysis[]`
- `deferred_or_rejected_indexes[]`
- `cost_model`
- `index_count_audit`
- `validation_plan`
- `open_questions[]`
- `downstream_handoff`
- `self_check`

## Design rules / 设计规则
### Query-first rule / 查询模式优先
每个索引都必须服务至少一个已知 query pattern、join path、sort path、batch path 或 uniqueness rule。

若一个索引不服务任何明确模式：
- 默认进入 `deferred_or_rejected_indexes`
- 不要因为“以后可能有用”而默认保留

### Read-write cost discipline / 读写权衡纪律
对每个索引都要给出：
- `read_benefit`
- `write_cost`
- `storage_cost`（定性或估计）

对高写入表必须更克制：
- append-only / audit / event 类表，要特别警惕索引膨胀
- 若写入 TPS 很高，优先保核心检索路径，延后低收益索引

### Composite order discipline / 复合索引顺序纪律
默认使用以下顺序规则：
1. 等值列优先
2. 等值列内部高选择性优先
3. 范围 / 排序列靠后
4. 覆盖列只在收益明确时追加到尾部

输出中必须给出 `composite_order_rationale`，不能只报一个列组合。

### Covering index discipline / 覆盖索引纪律
当查询返回列较少且访问频繁时，主动检查覆盖索引机会。
但不要为了“全覆盖”把索引扩成宽索引怪物。

### Count and redundancy discipline / 数量与冗余纪律
每张表都要做 `index_count_audit`：
- 检查冗余前缀索引
- 检查长期未使用索引（若有证据）
- 检查表总索引数是否超过合理水平

### Boundary discipline / 边界纪律
- 不要重新发明表结构或字段类型；缺字段时回推给 046。
- 不要把流量语义和异常链路全部在本 skill 里讲完；交给 048。
- 不要把 DBA 执行步骤伪装成已落地变更。

## Execution workflow / 执行流程
1. 识别 selected mode 与 evidence profile。
2. 归一 query patterns，标注 confirmed / inferred。
3. 对齐 046 中的表名、列名、主键与唯一约束。
4. 为高频点查、范围查、排序、join、batch、aggregate 场景设计索引。
5. 为每条索引写清楚 service pattern、顺序理由和读写成本。
6. 扫描 covering 机会。
7. 扫描冗余索引、未使用索引和过度索引表。
8. 形成 validation plan（EXPLAIN / usage / rows examined / p99 验证）。
9. 输出 handoff 给查询优化、性能评审、048 流分析和 N200 SQL 草稿。
10. 运行 checklist 与 common-failure review。

## Dynamic completeness / 动态完整度
- 单功能：覆盖全部关键查询路径
- 中等系统：覆盖全部高频路径 + 高风险批任务
- 大型系统：优先覆盖核心读写链路，低频路径可进入 deferred section

## Quality bar / 质量门槛
合格结果应使 reviewer 能回答：
- 这个索引到底服务什么查询
- 它的写入代价是否值得
- 列顺序是否合理
- 是否存在冗余或过度索引

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/query-pattern-contract.md`
- `references/cost-model-guide.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/output-template.md`
- `references/query-pattern-contract.md`
- `references/cost-model-guide.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
