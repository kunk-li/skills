# Scoring Rubric

Score each dimension 1-5:
- query coverage
- order rationale quality
- read/write tradeoff clarity
- redundancy governance
- validation readiness
- downstream handoff usability

24-30: implementation-ready
18-23: review-ready
12-17: partial
below 12: provisional only
