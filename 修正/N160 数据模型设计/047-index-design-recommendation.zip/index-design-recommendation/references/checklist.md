# Checklist

- every index serves a real pattern or constraint
- query patterns are explicit and confidence-tagged
- composite order rationale is written
- write cost note included
- covering opportunities reviewed
- redundancy and count audit included
- missing table or field issues pushed back to 046
- validation plan included
