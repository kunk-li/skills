# Cost Model Guide

Estimate qualitatively or quantitatively:
- read_benefit: scan reduction, sort avoidance, join improvement
- write_cost: extra index maintenance per insert/update/delete
- storage_cost: key width, row count, replicas

Suggested interpretation:
- high read benefit + low write cost: strong recommend
- moderate benefit + moderate cost: conditional
- low benefit + high write cost: reject or defer
