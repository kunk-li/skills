# Mode Selection

| mode | use when | emphasis |
| --- | --- | --- |
| pre-design | schema and access paths are being designed | forward-looking recommendation |
| audit-existing | current indexes already exist | governance and cleanup |
| explain-driven-review | slow query or explain evidence exists | targeted correction |
