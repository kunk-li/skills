# Example IO

Input:
- table schema for order and audit_event
- query patterns: list orders by tenant and created_at; fetch order by public_id; export audit_event by month

Output:
- index catalog covering public_id lookup, tenant/time list query, and audit export range scan
- write-cost caution on audit_event
- validation plan with EXPLAIN focus
