# Orchestration

## Upstream
Best inputs:
- table-schema-design-recommendation
- api-design-recommendation
- data-flow-mapping for batch/export flows
- slow query or explain evidence when auditing existing systems

## Downstream
Main consumers:
- query optimization recommendation
- performance risk analysis
- data-flow-mapping
- SQL draft generation / DBA review

## 047 -> 048 mapping
| 047 field | 048 usage |
| --- | --- |
| query_patterns_summary | identify read paths and batch flows |
| index_catalog | validate whether a flow has supporting access paths |
| write_cost_note | flag high-write pressure on flow hotspots |
| deferred indexes | mark potential future bottlenecks |
