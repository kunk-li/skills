# Common Failure Modes

- index created with no explicit query pattern served
- composite order chosen without equality/selectivity reasoning
- covering index expanded until it becomes too wide
- high-write table overloaded with low-value indexes
- redundant prefix indexes ignored
- schema holes silently filled instead of escalating back to 046
