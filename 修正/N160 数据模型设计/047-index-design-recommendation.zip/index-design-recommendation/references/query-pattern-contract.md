# Query Pattern Contract

Minimum fields per query pattern:
- pattern_id
- table or entity
- type: point_lookup / range / sort / join / aggregate / batch_read
- frequency or importance
- conditions
- sort_by
- returning columns
- latency requirement
- confidence

When exact frequency is unknown, use relative labels such as high / medium / low.
