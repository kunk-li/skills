# Output Template: Index Design Recommendation

## 1. Objective
- scope
- selected_mode
- readiness
- stage_position

## 2. Evidence Profile
| source | what it confirms | remaining uncertainty |

## 3. Query Patterns Summary
| pattern_id | type | frequency | conditions | sort | returning | confidence |

## 4. Index Catalog
| idx_id | table_name | index_name | columns | index_type | index_purpose | query_patterns_served | composite_order_rationale | uniqueness | write_cost_note | storage_cost_note | evidence | confidence |

## 5. Covering Index Analysis
| pattern_id | current_state | proposed_covering_shape | benefit | caution |

## 6. Deferred or Rejected Indexes
| candidate | reason_not_now | trigger_to_revisit |

## 7. Cost Model and Count Audit
- read_benefit vs write_cost summary
- redundant indexes
- excessive count tables
- unused index hints if evidence exists

## 8. Validation Plan
| query | how to validate | success signal |

## 9. Downstream Handoff
| consumer | what to read | why |

## 10. Self-Check
Summarize checklist and scoring outcomes.
