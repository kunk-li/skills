# bug 5 elements

Every bug analysis should organize evidence into:
1. symptoms
2. impact
3. evidence
4. attribution hypotheses
5. decision

This skill is for fast triage and action framing, not for deep five-why RCA.
