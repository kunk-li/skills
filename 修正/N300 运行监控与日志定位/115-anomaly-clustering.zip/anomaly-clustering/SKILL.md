---
name: anomaly-clustering
description: generate workflow-aligned 异常聚类表.csv outputs from 发布后验证清单.csv, 日志文件, 监控面板截图, trace数据, diff风险点评.md, and incident evidence. use when chatgpt works in operations & runtime / monitoring and diagnosis and must produce the n300 异常聚类表.csv artifact, interpret observability signals, preserve incident_id across metric/log/trace evidence, and hand off actionable findings to n310, n320, or n330.
---
# anomaly-clustering

## Role / role positioning
This skill aligns to operations & runtime -> monitoring and diagnosis -> 异常聚类表.csv. It is the authoritative N300 skill for cross signal pattern grouping and cluster prioritization.

### Boundary
- Own the N300 artifact `异常聚类表.csv` and keep the output contract stable.
- Preserve `incident_id` and cross-reference shared observability evidence instead of creating a disconnected report.
- Consume metrics, logs, traces, and release context only to the depth required for this skill boundary.
- Hand off deeper containment, response, or remediation choices to downstream N310 / N320 / N330 artifacts rather than overreaching.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `realtime_clustering`
- `batch_mode`
- `pattern_learning`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `发布后验证清单.csv`
- `日志文件`
- `监控面板截图`
- `trace数据`
- `Diff风险点评.md`

### optional enhancement inputs
- alert payloads or incident notifications
- dashboard queries or monitor definitions
- service topology or ownership map
- release manifest or rollout notes
- known incident / rca history
- business metric definitions and baselines

## Standalone rule / standalone usage
This skill must still work on one incident, one alert burst, one trace, one log bundle, or one metric anomaly slice.

Degradation rules:
- If only one evidence family is present, keep the output contract stable and mark missing evidence families in `downstream_handoff`.
- If time windows are incomplete, state the observed window explicitly and avoid fake historical comparisons.
- If ownership or topology is missing, keep routing or scope fields as placeholders rather than guessing.

## Core output contract / core output contract
Default to the evidence-first structure in `references/output-template.md`.

The result must include at least:
- `metadata`
- `incident_overview`
- `clustering_scope`
- `anomaly_clusters[]`
- `known_vs_unknown_summary`
- `prioritization_ranking`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: cross_signal_pattern_grouping_and_cluster_prioritization`
- `stage_position: operations_runtime.monitoring_and_diagnosis.anomaly_clustering`
- `workflow_node: N300`
- `node_artifact_target: 异常聚类表.csv`
- `evidence_profile`
- `tool_collaboration_mode`
- `incident_id`

Primary rows or structured entries must preserve:
- `cluster_id`
- `clustering_algorithm`
- `signature`
- `signal_types`
- `frequency_window`
- `representative_examples`
- `known_pattern_match`
- `cluster_priority`
- `growth_trend`
- `owner_placeholder`

## Design rules / design rules
- State the clustering algorithm and feature basis; never present opaque clusters.
- Prioritize clusters by impact, novelty, and growth instead of count alone.
- Separate known recurring clusters from genuinely new signatures.
- Keep cluster rows machine-friendly for downstream dashboards or RCA grouping.
- Always preserve `incident_id`, source time window, and source system references.
- Distinguish observed facts from hypotheses.
- Separate business-visible impact from purely technical noise when both appear in the same incident.

## Execution workflow / execution workflow
1. Normalize the incident scope, time window, release context, and evidence sources.
2. Interpret the evidence family owned by this skill while preserving cross-signal references.
3. Convert findings into the stable row or section contract for `异常聚类表.csv`.
4. Flag unknowns, contradictions, and next-best evidence instead of overstating confidence.
5. Hand off actionable next steps to N310 / N320 / N330 with incident continuity preserved.

## Dynamic completeness / dynamic completeness
- If multiple incidents appear mixed in one bundle, separate them by `incident_id` or explicit cluster key before summarizing.
- If one finding depends on another N300 skill, keep a concise cross-reference instead of duplicating the full analysis.
- If baselines are missing, prefer directional interpretation plus `needs_baseline_confirmation` over unsupported severity claims.
- If business and technical signals disagree, surface the disagreement explicitly instead of collapsing them into one judgement.

## Quality bar / quality bar
A good N300 output is incident-centric, quantitatively grounded, clear about confidence, explicit about evidence lineage, and immediately reusable by response, RCA, or improvement workflows.

## Reference files / reference files
- `references/clustering-priority-matrix.md`
- `references/incident-contract.md`
- `references/observability-query-abstraction.md`
- `references/incident-timeline-orchestration.md`
- `references/signal-taxonomy.md`
- `references/field-contract.md`
- `references/output-template.md`
- `references/boundaries-and-handoffs.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
