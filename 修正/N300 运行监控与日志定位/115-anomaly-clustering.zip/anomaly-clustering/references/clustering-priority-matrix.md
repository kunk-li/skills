# clustering priority matrix

## Suggested algorithms
- logs: NLP / template clustering / DBSCAN-style grouping
- metrics: density-based or change-point grouping
- traces: hierarchical similarity

## Priority drivers
- frequency
- business impact
- user count
- growth trend
- new vs known signature
