# common failure modes

Use these cross-skill buckets when it helps:
- config drift
- dependency timeout
- pool exhaustion
- stale cache
- missing trace propagation
- noisy alert fan-out
- schema / rollout mismatch
- traffic spike without capacity
- business metric drop with technical signals normal
