# incident contract

Use a stable shared structure across all N300 skills.

## Minimum keys
- `incident_id`
- `incident_title`
- `signal_sources[]`
- `time_window`
- `service_scope[]`
- `release_context`
- `evidence_refs[]`
- `status`

## Shared evidence conventions
Every skill should preserve:
- `incident_id`
- `query_or_source`
- `time_window`
- `service_scope`
- `trace_id_refs[]`
- `log_refs[]`
- `metric_refs[]`
- `owner_placeholder`
