# incident timeline orchestration

All N300 skills should preserve one incident storyline.

## Timeline checkpoints
- `t_detected`
- `t_first_alert`
- `t_first_user_visible_signal`
- `t_first_metric_deviation`
- `t_first_error_log`
- `t_trace_observed`
- `t_scope_peak`
- `t_containment`
- `t_recovery`

## Cross-skill rule
- `alert-attribution` creates or normalizes the incident entry.
- `monitoring-metric-interpretation` explains metric movement.
- `log-analysis` and `trace-call-chain-analysis` deepen technical evidence.
- `bug-analysis` produces rapid symptom-focused triage.
- `root-cause-analysis-recommendation` turns evidence into deep hypotheses.
- `impact-scope-analysis` quantifies who and what is affected.
- `anomaly-clustering` and `frequent-error-summary` provide pattern context.
