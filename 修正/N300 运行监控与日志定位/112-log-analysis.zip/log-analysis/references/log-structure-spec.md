# log structure spec

## Required JSON fields
- `timestamp`
- `level`
- `service`
- `trace_id`
- `event`
- `message`

## Policy highlights
- redact PII and secrets
- keep query abstraction portable across Loki, Splunk, Datadog, and CloudWatch
- treat missing trace_id as an observability gap, not a minor note
