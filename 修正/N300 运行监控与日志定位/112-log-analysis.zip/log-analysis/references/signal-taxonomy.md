# signal taxonomy

## Technical signals
- latency
- traffic
- errors
- saturation
- queue depth
- replica lag
- cache hit ratio
- dependency latency

## Business signals
- transaction success rate
- conversion rate
- active users
- checkout completion
- complaint rate
- refund / churn signals

## Usage rule
Every interpretation should say whether a signal is:
- `technical_only`
- `business_only`
- `cross_signal`
