# real examples

## Example pattern 1
- sudden p99 spike with flat traffic and rising DB wait time
- likely next step: trace critical path + DB diagnostics

## Example pattern 2
- user-visible conversion drop with normal infra metrics
- likely next step: business metric drill-down + bug symptom review

## Example pattern 3
- one root alert causing multiple downstream 5xx alerts
- likely next step: alert dedup + impact scope + RCA handoff
