# boundaries and handoffs

## Boundary summary
- metric interpretation explains signals; it does not cluster incidents.
- log analysis interprets structured log evidence; it does not replace trace critical-path analysis.
- trace analysis explains causal path and bottlenecks; it does not own final business scope.
- bug analysis is fast symptom triage; RCA is deep cause analysis.
- anomaly clustering groups patterns; frequent error summary ranks recurring issues.
- impact scope quantifies affected parties; alert attribution deduplicates and routes initial signals.

## Downstream to N310 / N320 / N330
- N310 consumes actionable containment, hotfix, and prioritization hints.
- N320 consumes timeline, evidence, and RCA structure.
- N330 consumes recurring patterns and instrumentation gaps as improvement inputs.
