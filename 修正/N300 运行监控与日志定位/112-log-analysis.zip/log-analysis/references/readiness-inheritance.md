# readiness inheritance

## default rule
If upstream N290 release validation or deployment evidence is incomplete, keep the N300 output contract stable and lower readiness rather than dropping sections.

## confidence rule
When evidence is indirect or partial:
- keep the hypothesis
- lower confidence
- list the next best evidence to collect
