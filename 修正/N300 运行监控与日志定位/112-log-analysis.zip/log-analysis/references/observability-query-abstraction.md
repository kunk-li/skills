# observability query abstraction

Use abstract filters first, then translate only when necessary.

## Abstract filter shape
- `service = "..."`
- `level = "..."`
- `trace_id = "..."`
- `event = "..."`
- `time between [start, end]`
- `metric = "..." and window = "..."`

## Backend translations
- Loki
- Splunk
- Datadog
- CloudWatch
- Tempo / Jaeger / OpenTelemetry backends

Always keep the abstract form in the output contract even if a backend-specific query is also provided.
