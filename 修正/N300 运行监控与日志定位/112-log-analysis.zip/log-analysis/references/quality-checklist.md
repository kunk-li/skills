# quality checklist

A high-quality N300 result should be:
- incident-oriented rather than tool-oriented
- explicit about time windows and source systems
- quantitative when making anomaly or scope claims
- clear about confidence and unknowns
- explicit about next steps and downstream handoff
