# field contract

## readiness values
- `draft`
- `partial`
- `ready`

## evidence profile values
- `metrics_only`
- `logs_only`
- `traces_only`
- `multi_signal`
- `historical_enriched`

## tool collaboration mode values
- `unified_observability_plane`
- `single_incident_traceback`
- `batch_pattern_review`
