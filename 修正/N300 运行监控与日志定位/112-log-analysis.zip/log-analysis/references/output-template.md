# output template

Default to a concise, evidence-first report with stable headings:
1. metadata
2. incident overview
3. main findings
4. evidence summary
5. decision / recommendation
6. downstream handoff
7. self-check

CSV-oriented skills should also provide a normalized row schema.
