# trace critical path playbook

## Required checks
- critical path duration share
- top span contributors
- missing span or propagation gaps
- error span highlighting
- baseline comparison against recent healthy traces

## Span naming preference
- `http.GET /path`
- `db.SELECT table`
- `cache.GET keyspace`
- `external.service.operation`
