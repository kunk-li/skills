# alert routing and dedup

## Dedup goals
- suppress same-alert repeats in a short window
- merge correlated downstream alerts under one likely root alert
- reduce alert storms into one incident storyline

## Routing goals
Map alert families to primary and secondary responders with escalation timers.
