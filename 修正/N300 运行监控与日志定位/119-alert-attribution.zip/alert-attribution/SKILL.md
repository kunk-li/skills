---
name: alert-attribution
description: generate workflow-aligned 告警归因.md outputs from 发布后验证清单.csv, 日志文件, 监控面板截图, trace数据, diff风险点评.md, and incident evidence. use when chatgpt works in operations & runtime / monitoring and diagnosis and must produce the n300 告警归因.md artifact, interpret observability signals, preserve incident_id across metric/log/trace evidence, and hand off actionable findings to n310, n320, or n330.
---
# alert-attribution

## Role / role positioning
This skill aligns to operations & runtime -> monitoring and diagnosis -> 告警归因.md. It is the authoritative N300 skill for alert deduplication routing and initial incident hypothesis.

### Boundary
- Own the N300 artifact `告警归因.md` and keep the output contract stable.
- Preserve `incident_id` and cross-reference shared observability evidence instead of creating a disconnected report.
- Consume metrics, logs, traces, and release context only to the depth required for this skill boundary.
- Hand off deeper containment, response, or remediation choices to downstream N310 / N320 / N330 artifacts rather than overreaching.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `dedup_only`
- `root_cause_hint`
- `routing_only`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `发布后验证清单.csv`
- `日志文件`
- `监控面板截图`
- `trace数据`
- `Diff风险点评.md`

### optional enhancement inputs
- alert payloads or incident notifications
- dashboard queries or monitor definitions
- service topology or ownership map
- release manifest or rollout notes
- known incident / rca history
- business metric definitions and baselines

## Standalone rule / standalone usage
This skill must still work on one incident, one alert burst, one trace, one log bundle, or one metric anomaly slice.

Degradation rules:
- If only one evidence family is present, keep the output contract stable and mark missing evidence families in `downstream_handoff`.
- If time windows are incomplete, state the observed window explicitly and avoid fake historical comparisons.
- If ownership or topology is missing, keep routing or scope fields as placeholders rather than guessing.

## Core output contract / core output contract
Default to the evidence-first structure in `references/output-template.md`.

The result must include at least:
- `metadata`
- `incident_overview`
- `alert_clusters[]`
- `dedup_summary`
- `likely_root_alert`
- `routing_decision`
- `upstream_downstream_map`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: alert_deduplication_routing_and_initial_incident_hypothesis`
- `stage_position: operations_runtime.monitoring_and_diagnosis.alert_attribution`
- `workflow_node: N300`
- `node_artifact_target: 告警归因.md`
- `evidence_profile`
- `tool_collaboration_mode`
- `incident_id`

Primary rows or structured entries must preserve:
- `alert_group_id`
- `alert_type`
- `dedup_key`
- `correlated_alerts`
- `likely_root_component`
- `initial_hypothesis`
- `primary_responder`
- `secondary_responder`
- `escalation_sla`

## Design rules / design rules
- Reduce alert storms into one incident narrative whenever there is evidence of a common root source.
- Differentiate root alert candidates from cascading symptom alerts.
- Always include routing and escalation ownership, not just technical hypotheses.
- Preserve enough correlation detail for later timeline and RCA work.
- Always preserve `incident_id`, source time window, and source system references.
- Distinguish observed facts from hypotheses.
- Separate business-visible impact from purely technical noise when both appear in the same incident.

## Execution workflow / execution workflow
1. Normalize the incident scope, time window, release context, and evidence sources.
2. Interpret the evidence family owned by this skill while preserving cross-signal references.
3. Convert findings into the stable row or section contract for `告警归因.md`.
4. Flag unknowns, contradictions, and next-best evidence instead of overstating confidence.
5. Hand off actionable next steps to N310 / N320 / N330 with incident continuity preserved.

## Dynamic completeness / dynamic completeness
- If multiple incidents appear mixed in one bundle, separate them by `incident_id` or explicit cluster key before summarizing.
- If one finding depends on another N300 skill, keep a concise cross-reference instead of duplicating the full analysis.
- If baselines are missing, prefer directional interpretation plus `needs_baseline_confirmation` over unsupported severity claims.
- If business and technical signals disagree, surface the disagreement explicitly instead of collapsing them into one judgement.

## Quality bar / quality bar
A good N300 output is incident-centric, quantitatively grounded, clear about confidence, explicit about evidence lineage, and immediately reusable by response, RCA, or improvement workflows.

## Reference files / reference files
- `references/alert-routing-and-dedup.md`
- `references/incident-contract.md`
- `references/observability-query-abstraction.md`
- `references/incident-timeline-orchestration.md`
- `references/signal-taxonomy.md`
- `references/field-contract.md`
- `references/output-template.md`
- `references/boundaries-and-handoffs.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
