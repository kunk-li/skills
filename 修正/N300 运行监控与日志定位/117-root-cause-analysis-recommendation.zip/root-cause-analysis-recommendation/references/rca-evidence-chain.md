# rca evidence chain

Every hypothesis must include:
- supporting evidence
- contradicting evidence
- confidence
- additional investigation needed

Every deep RCA should also include a five-why chain and distinguish containment from prevention.
