# monitoring framework

## Mandatory signal families
- 4 golden signals: latency, traffic, errors, saturation
- 4 business signal families: business_value, user_experience, business_outcome, business_health

## Metric tiers
- `T1_SLI`
- `T2_KPI`
- `T3_operational`
- `T4_debug_only`

## Anomaly judgement methods
- threshold_based
- baseline_based
- change_point_detection
- composite_alerting
