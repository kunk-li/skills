# impact measurement dimensions

Use quantified scope where possible.

## Core dimensions
- users
- functions / journeys
- services / components
- data / records
- revenue / business value
- compliance exposure
- temporal scope

Every numeric claim should cite its data source or say `unable_to_measure`.
