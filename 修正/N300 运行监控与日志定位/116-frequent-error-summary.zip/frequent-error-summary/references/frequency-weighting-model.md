# frequency weighting model

## Windows
- last_hour
- last_24h
- last_7d
- last_30d

## Weighted score
Use:
`weighted_score = raw_count * business_weight * severity_weight`

Also group sibling errors by likely root-cause family where evidence supports it.
