# Environment Difference Dimensions

## Recommended comparison dimensions
- version and artifact parity
- config and secret source parity
- scale and capacity parity
- monitoring and alert parity
- network reachability and isolation
- dependency mode parity (real, sandbox, mock)
- data representativeness and freshness
- compliance or policy switches

## Difference nature guidance
- `legitimate`: intentional and documented for environment purpose
- `drift`: should match but does not
- `pending_consolidation`: known mismatch with accepted remediation plan
- `unknown`: new or unexplained mismatch

## Readiness scoring anchors
- 90+: ready for release validation or realistic rehearsal
- 75-89: usable with clear follow-up actions
- below 75: insufficient for confident release execution rehearsal
