---
name: environment-difference-check
description: generate workflow-aligned environment difference checks from 发布说明.md, 发版检查清单.csv, 环境配置清单, and environment snapshots. use when chatgpt works in release & delivery / release execution and must produce the n280 环境差异检查单.csv artifact, separate legitimate differences from drift, score environment readiness, verify isolation, or prepare downstream release-task-orchestration inputs.
---
# environment-difference-check

## Role / role positioning
This skill aligns to release & delivery -> release execution -> 环境差异检查单.csv. It is the authoritative N280 skill for environment parity, drift, readiness, and isolation analysis.

### Boundary
- Own environment difference discovery, legitimacy tagging, topology visibility, readiness scoring, and isolation findings.
- Consume release context and environment inventories instead of recreating release strategy or task orchestration.
- Do not replace configuration-change-check for config diff semantics.
- Do not replace release-task-orchestration for executable release sequencing.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `snapshot_mode`
- `drift_detection`
- `isolation_audit`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `发布说明.md`
- `发版检查清单.csv`
- `环境配置清单`

### optional enhancement inputs
- environment snapshots
- topology diagrams
- cluster manifests
- GitOps desired state
- live environment facts
- network policy exports
- staging readiness notes

## Standalone rule / standalone usage
This skill must still work on one environment pair, one staging-vs-prod comparison, or one isolation audit.

Degradation rules:
- If only one environment snapshot is available, emit observation and unknowns rather than fake comparisons.
- If legitimacy policy is incomplete, keep `difference_nature` explicit and mark review-needed items.
- If topology is partial, score readiness conservatively and expose missing evidence.

## Core output contract / core output contract
Default to csv-friendly tables matching `references/output-template.md`.

The result must include at least:
- `metadata`
- `environment_inventory`
- `difference_register[]`
- `difference_nature_summary`
- `environment_topology`
- `env_readiness_scores`
- `isolation_findings`
- `remediation_queue[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: environment_parity_and_drift_detection`
- `stage_position: release_and_delivery.release_execution.environment_difference_check`
- `workflow_node: N280`
- `node_artifact_target: 环境差异检查单.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Tag every observed difference with one `difference_nature`: `legitimate`, `drift`, `pending_consolidation`, or `unknown`.
- Always separate environment purpose from environment drift; some differences are intentional.
- Keep environment topology explicit across `dev`, `test`, `staging`, `prod`, and `dr` when evidence exists.
- Score readiness across representativeness, config alignment, monitoring parity, and isolation fitness.
- Isolation checks must explicitly guard against lower environments reaching production data or credentials.

## Execution workflow / execution workflow
1. Collect release inputs, environment configuration inventories, and available snapshots.
2. Compare environment facts and classify each difference by nature and operational impact.
3. Build or update topology, readiness scoring, and isolation findings.
4. Emit remediation tasks and downstream handoff for release execution orchestration and post-release validation.

## Dynamic completeness / dynamic completeness
- If only expected-difference policy exists but live environment facts do not, keep a policy-only register and mark runtime validation pending.
- If drift is suspected but not proven, mark it `unknown` with required evidence instead of over-asserting.
- If environments differ by design, keep the legitimacy rationale explicit so future reviewers do not reopen the same question.

## Quality bar / quality bar
A good environment difference check turns ambiguous environment mismatch into actionable parity, readiness, and isolation decisions.

## Reference files / reference files
- `references/environment-diff-dimensions.md`
- `references/field-contract.md`
- `references/output-template.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/cross-skill-orchestration.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
