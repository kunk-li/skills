# Real Examples

## example 1: 配置变更检查

输入：一份 application.yml diff、版本说明、发版检查单。
输出：按 `config_key / v_old / v_new / change_type / candidate_impact / pending_items` 组织的 csv 检查表。

## example 2: 环境差异检查

输入：dev/test/staging/prod 四环境导出的关键配置清单。
输出：多环境对比表，标明 `diff_type`、`priority`、`observation`、`recommended_followup`。

## example 3: 任务编排

输入：配置变更检查结果、环境差异结果、发布时间窗口与负责人列表。
输出：带 `phase / order / owner / est_time_min / dependencies` 的发布任务编排表。
