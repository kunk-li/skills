# Cross Skill Orchestration

## N280 execution chain
1. Consume N270 release artifacts, especially release notes and release checklist.
2. Use `configuration-change-check` to classify config changes and rollout impact.
3. Use `environment-difference-check` to separate legitimate differences from drift.
4. Use `release-task-orchestration` to turn validated release intent into executable tasks.
5. Hand the resulting execution state to N290 for post-release validation and to N330 for ops documentation if needed.

## Shared state recommendations
Prefer a shared execution state with:
- `release_state`
- `config_state`
- `environment_state`
- `task_state`
- `rollback_state`

## Duplication boundary
- Do not recreate N270 release notes or risk registers.
- Do not replace N290 validation or acceptance records.
- Do not bury blockers; expose them as explicit handoff items.
