# Common Failure Modes

## N280-specific failure modes
- plaintext secrets committed into config repos
- legitimate environment differences misclassified as drift
- undocumented restart requirements causing surprise downtime
- release tasks that cannot resume safely after partial failure
- multi-service deployment order violating compatibility constraints
- stale GitOps state differing from live cluster state
- release steps marked done without evidence or verification
