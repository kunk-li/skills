# Output Template

## Default result frame
Every result should include:
1. `metadata`
2. primary registry table(s)
3. blockers or pending items
4. downstream handoff
5. self-check

## CSV-friendly guidance
- Keep identifiers stable and machine-friendly.
- Prefer one row per actionable item.
- Keep `owner`, `status`, `priority`, and `evidence` explicit.
- Use comments or notes fields only after core fields are complete.

## Markdown guidance
When the user wants Markdown instead of csv, preserve the same field semantics in tables or nested bullet groups.
