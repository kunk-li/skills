# Quality Checklist

A good N280 output should:
- stay aligned to workflow node N280 and its exact artifact target
- separate confirmed facts from assumptions
- name blockers explicitly instead of hiding them in prose
- state owners, verification methods, and evidence expectations
- keep downstream handoff to N290 and N330 explicit
- avoid redoing N270 release planning work
