# Readiness Inheritance

## Readiness vocabulary
- `ready`: evidence is sufficient for execution or signoff
- `constrained`: usable with explicit limitations or pending confirmations
- `blocked`: missing critical evidence or unresolved blockers

## Inheritance rule
N280 should inherit upstream release readiness from N270, but must downgrade readiness if:
- configuration drift is unresolved
- required environment isolation is broken
- release tasks lack retry / rollback / resume handling
