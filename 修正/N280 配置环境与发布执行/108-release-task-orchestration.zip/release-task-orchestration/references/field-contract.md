# Field Contract

## Shared fields
Use stable cross-skill names wherever possible:
- `id`
- `priority`
- `owner`
- `status`
- `evidence`
- `upstream`
- `blocking_dimensions`
- `automation_level`
- `verified_by`
- `verified_at`

## Status vocabulary
Use only:
- `pending`
- `ready`
- `blocked`
- `waived`
- `in_progress`
- `done`
- `failed`

## Priority vocabulary
Use only:
- `critical`
- `high`
- `medium`
- `low`

## N280 artifact alignment
- `configuration-change-check` owns `配置变更检查单.csv`
- `environment-difference-check` owns `环境差异检查单.csv`
- `release-task-orchestration` owns `发布任务编排表.csv`

## Cross-node handoff
- N270 release artifacts remain source-of-truth release intent.
- N280 produces execution-ready checks and task orchestration.
- N290 consumes release execution status and verified environment state.
