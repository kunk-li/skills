# Release Task Phases and Dependencies

## Suggested release phases
- `P1_prepare`: artifact, approvals, config validation, environment checks
- `P2_pre_stage`: staging deploy, smoke, or dry-run checks
- `P3_execute`: production rollout, canary or phased promotion
- `P4_verify`: post-release smoke, dashboards, alerts, early validation
- `P5_stabilize`: observation window, rollback readiness, closeout tasks

## Dependency guidance
- Build, sign, and scan tasks should complete before rollout.
- Environment blockers must be cleared before production traffic changes.
- Cross-service provider updates usually precede consumer updates unless compatibility proof exists.
- Verification tasks should block closeout even if deployment technically succeeded.

## Resumability guidance
Each task should state:
- whether it is idempotent
- whether it supports checkpoint resume
- whether retry is safe automatically
- whether rollback or manual approval is needed on failure
