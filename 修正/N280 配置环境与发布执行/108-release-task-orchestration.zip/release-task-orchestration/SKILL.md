---
name: release-task-orchestration
description: generate workflow-aligned release task orchestration from 发布说明.md, 发版检查清单.csv, 环境配置清单, and upstream n280 checks. use when chatgpt works in release & delivery / release execution and must produce the n280 发布任务编排表.csv artifact, define release dag tasks, assign failure handling, model cross-service release ordering, or support resumable gitops-native release execution.
---
# release-task-orchestration

## Role / role positioning
This skill aligns to release & delivery -> release execution -> 发布任务编排表.csv. It is the authoritative N280 skill for executable release sequencing and operational control flow.

### Boundary
- Own release task decomposition, dependency ordering, failure policies, resumability, and execution observability.
- Consume upstream release intent, config findings, and environment findings instead of recreating them.
- Do not replace N270 rollback planning, but consume rollback constraints when sequencing release work.
- Do not replace N290 post-release validation, but hand off execution checkpoints and verification hooks.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `simple_sequential`
- `dag_enterprise`
- `gitops_native`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `发布说明.md`
- `发版检查清单.csv`
- `环境配置清单`

### optional enhancement inputs
- `配置变更检查单.csv`
- `环境差异检查单.csv`
- rollback plan
- canary strategy
- compatibility matrix
- release manifest
- pipeline or workflow templates

## Standalone rule / standalone usage
This skill must still work on one service release, one rollout slice, or one recovery path.

Degradation rules:
- If upstream N280 checks are missing, keep the DAG stable but mark unresolved preconditions explicitly.
- If rollback details are partial, default failure policies to conservative `notify_and_wait` or `abort` rather than inventing unsafe rollback automation.
- If cross-service compatibility is unknown, avoid parallel rollout recommendations that assume compatibility.

## Core output contract / core output contract
Default to csv-friendly tables matching `references/output-template.md`.

The result must include at least:
- `metadata`
- `task_registry[]`
- `phase_map`
- `dag_overview`
- `failure_policies`
- `checkpoint_and_resume_rules`
- `cross_service_coordination`
- `observability_and_notifications`
- `release_execution_package`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: release_execution_dag_and_operational_control`
- `stage_position: release_and_delivery.release_execution.release_task_orchestration`
- `workflow_node: N280`
- `node_artifact_target: 发布任务编排表.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Prefer declarative DAG orchestration over purely procedural step lists.
- Every task must declare dependencies, verification method, and `on_failure` behavior.
- Supported `on_failure` strategies: `abort`, `retry_n_times`, `rollback`, `continue_with_warning`, `notify_and_wait`, `skip`.
- Track resumability explicitly: `idempotent`, `checkpointable`, `resumable`, and `manual_safe_to_retry` where needed.
- Model cross-service ordering whenever consumer-provider compatibility or shared rollout windows matter.
- Keep GitOps-native execution paths first-class when config and environment state are repo-driven.

## Execution workflow / execution workflow
1. Ingest release intent, checklist state, config findings, and environment findings.
2. Build task registry entries with phases, dependencies, owners, verification steps, and failure handling.
3. Resolve cross-service ordering and identify parallelizable subgraphs.
4. Emit resumability rules, observability hooks, and downstream handoff for N290 and N330.

## Dynamic completeness / dynamic completeness
- If tasks are only partially automatable, keep `automation_level` explicit rather than pretending end-to-end automation exists.
- If a task is not safe to retry, surface a manual decision gate.
- If GitOps is absent, still emit a declarative orchestration plan, but note the manual execution boundary.

## Quality bar / quality bar
A good release task orchestration turns release intent into an executable, observable, restart-safe rollout plan instead of a fragile checklist narrative.

## Reference files / reference files
- `references/release-task-phases-and-dependencies.md`
- `references/field-contract.md`
- `references/output-template.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/cross-skill-orchestration.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
