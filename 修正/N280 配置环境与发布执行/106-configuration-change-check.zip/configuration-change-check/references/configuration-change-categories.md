# Configuration Change Categories

## Canonical kinds
- `CF01 application_config`: business toggles, service-level functional parameters
- `CF02 infrastructure_config`: deployment specs, ingress, service mesh, helm values
- `CF03 secrets`: credentials, tokens, certificates, keys
- `CF04 feature_flag`: gated release toggles and cohort switches
- `CF05 policy_config`: compliance, AOP, security, governance policy switches
- `CF06 monitoring_config`: alerts, dashboards, scraping, SLO thresholds
- `CF07 network_config`: DNS, routing, TLS, firewall, allow-lists
- `CF08 resource_limits`: cpu, memory, replicas, quota, autoscaling thresholds

## Review expectations
- `CF03` requires security-grade evidence and no plaintext handling.
- `CF04` must state disable path and default value.
- `CF06` must state post-release verification evidence.
- `CF07` must state blast radius and isolation consequences.
- `CF08` must state scaling or restart implications.

## Impact fields
Every row should evaluate:
- affected services
- owner
- reload mode
- rollout strategy
- verification method
- rollback relevance
