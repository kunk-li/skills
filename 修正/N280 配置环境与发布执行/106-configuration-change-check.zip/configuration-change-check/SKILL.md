---
name: configuration-change-check
description: generate workflow-aligned configuration change checks from 发布说明.md, 发版检查清单.csv, 环境配置清单, and config diffs. use when chatgpt works in release & delivery / release execution and must produce the n280 配置变更检查单.csv artifact, classify configuration changes, enforce secret handling rules, estimate reload or restart impact, or feed release-task-orchestration.
---
# configuration-change-check

## Role / role positioning
This skill aligns to release & delivery -> release execution -> 配置变更检查单.csv. It is the authoritative N280 skill for configuration change inspection.

### Boundary
- Own configuration change classification, secret handling, impact estimation, reload behavior, and config review blockers.
- Consume upstream N270 release artifacts instead of recreating release planning assets.
- Do not replace environment-difference-check for parity analysis.
- Do not replace release-task-orchestration for execution sequencing.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `validate_only`
- `impact_analysis_only`
- `gitops_deploy`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `发布说明.md`
- `发版检查清单.csv`
- `环境配置清单`

### optional enhancement inputs
- config repo diffs
- values.yaml or application.yml changes
- helm or k8s manifests
- secret inventory or vault mapping
- release manifest
- config drift evidence
- service ownership map

## Standalone rule / standalone usage
This skill must still work on one service config diff, one environment patch set, or one release slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If secret source-of-truth is missing, classify findings conservatively and surface a blocker instead of guessing.
- If deployment context is partial, separate hot-reload assumptions from confirmed restart requirements.

## Core output contract / core output contract
Default to csv-friendly tables matching `references/output-template.md`.

The result must include at least:
- `metadata`
- `config_change_inventory[]`
- `config_kind_summary`
- `secret_handling_findings`
- `impact_analysis`
- `reload_action_matrix`
- `gitops_and_versioning_notes`
- `blockers_and_pending[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: configuration_change_inspection_and_release_impact`
- `stage_position: release_and_delivery.release_execution.configuration_change_check`
- `workflow_node: N280`
- `node_artifact_target: 配置变更检查单.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Classify each configuration item into exactly one `config_kind`: `CF01 application_config`, `CF02 infrastructure_config`, `CF03 secrets`, `CF04 feature_flag`, `CF05 policy_config`, `CF06 monitoring_config`, `CF07 network_config`, `CF08 resource_limits`.
- Never allow plaintext secret handling to be normalized; flag it as a blocker and recommend vault or sealed-secret paths.
- Every configuration change must state owner, expected evidence, and rollout impact.
- Every change must declare `reload_mode`: `hot_reload`, `restart_required`, `rolling_update`, or `manual_trigger`.
- Prefer GitOps-compatible versioning notes whenever config repos, tags, or manifests are part of the evidence.

## Execution workflow / execution workflow
1. Collect release inputs, configuration inventories, and concrete config diffs.
2. Normalize changes into configuration items with old value, new value, environment scope, and config kind.
3. Run secret handling checks, versioning checks, impact analysis, and reload-mode analysis.
4. Emit blocker items and downstream instructions for environment comparison and execution orchestration.

## Dynamic completeness / dynamic completeness
- If a value is intentionally redacted, preserve the change semantics without revealing the secret.
- If only a subset of environments is known, state that impact analysis may be incomplete instead of inventing parity.
- If multiple services consume the same config, surface a shared-impact note instead of duplicating rows blindly.

## Quality bar / quality bar
A good configuration change check makes config risk auditable, secret-safe, rollout-aware, and immediately usable by release execution teams.

## Reference files / reference files
- `references/configuration-change-categories.md`
- `references/field-contract.md`
- `references/output-template.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/cross-skill-orchestration.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
