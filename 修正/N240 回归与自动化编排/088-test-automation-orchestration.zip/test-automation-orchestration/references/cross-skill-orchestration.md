# cross-skill orchestration · n240

N240 node collaboration model:
1. `regression-test-checklist-generation` chooses scope and tiers for broad confidence.
2. `smoke-test-checklist-generation` chooses the fast confidence path for deployment and probe timing.
3. `api-test-script-generation` creates executable bundles from contracts and testcase assets.
4. `test-automation-trigger-recommendation` maps change context to suites and timing.
5. `test-automation-orchestration` binds suites, stages, isolation, cleanup, and release hooks.

Preferred downstream mapping:
- N250 consumes failure-routing hints and suite ids.
- N260 consumes confidence, suite coverage, and blocking rules.
- N270 consumes pre-release smoke, orchestration hooks, and post-deploy checks.
