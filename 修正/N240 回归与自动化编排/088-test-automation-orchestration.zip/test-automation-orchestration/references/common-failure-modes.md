# common failure modes · n240

Avoid these mistakes:
- generating assets that claim execution results instead of design-time intent
- mixing regression, smoke, trigger, and orchestration concerns into one artifact
- omitting duration budgets, blocking behavior, or isolation needs
- forgetting downstream handoff notes for N250, N260, or N270

- sharing one mutable database across parallel jobs with no isolation plan
- adding cache without invalidation logic or lockfile keying
- describing deployment promotion in prose but not in the stage graph
