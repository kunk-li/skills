# examples · test-automation-orchestration

- parallel lint, unit, and security scan -> then build and integration tests -> then staging deploy and post-deploy smoke
- nightly enterprise run -> includes T0/T1/T2, flaky quarantine reporting, and failure triage hooks into issue creation
