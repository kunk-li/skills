# field contract · n240 shared fields

Shared metadata fields:
- `selected_mode`
- `readiness`
- `function_bias`
- `stage_position`
- `workflow_node`
- `node_artifact_target`
- `evidence_profile`
- `tool_collaboration_mode`

Shared traceability fields:
- `suite_id`
- `tc_id`
- `tp_id`
- `risk_ref`
- `api_ref`
- `task_ref`
- `module_or_flow`
- `evidence`

Shared execution-policy fields:
- `tier`
- `blocking_behavior`
- `max_duration`
- `dependencies`
- `cleanup_requirements`
- `isolation_level`
