# readiness inheritance · n240

Use one of three readiness values:
- `pass`: inputs are sufficient and the artifact can be used directly downstream.
- `constrained`: one or more important inputs are missing, so the artifact is usable with caveats.
- `blocked`: a core prerequisite is missing and only a placeholder or request-for-input artifact is safe.

Never silently upgrade readiness. If a key source is absent, keep the output shape stable and record the gap in `downstream_handoff`.
