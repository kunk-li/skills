---
name: test-automation-orchestration
description: generate workflow-aligned automation orchestration plans and pipeline yaml from testcase assets, trigger recommendations, api test bundles, and diff-risk evidence. use when chatgpt works in testing & qa / regression and automation and must produce the n240 orchestration artifact for ci design, environment isolation, or deployment verification flow.
---
# test-automation-orchestration

## Role / role positioning
This skill aligns to testing & qa -> regression and automation -> 自动化测试编排.yaml. It delivers a workflow-aligned artifact for N240.

### Boundary
- Own stage ordering, suite-to-stage binding, isolation, cache, cleanup, and deployment test orchestration.
- Do not replace the trigger policy artifact; consume it.
- Do not replace detailed testcase or script generation; consume those artifacts as suite inputs.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `minimal_ci`: create a compact pipeline for smaller projects or bootstrap stages.
- `enterprise_ci`: build a multi-stage pipeline with isolation, caching, cleanup, and deployment promotion.
- `gitops_mode`: express orchestration with promotion and environment control suitable for gitops flows.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `开发任务拆分表.csv`
- `接口设计草案.yaml`
- `Diff风险点评.md`

### optional enhancement inputs
- 回归测试清单.csv
- 冒烟测试清单.csv
- 接口测试脚本.zip
- 自动化触发建议.md
- release notes
- environment topology
- container/runtime constraints
- historical CI duration metrics

## Standalone rule / standalone usage
This skill must still work on one diff, one module, one endpoint group, or one release slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If testcase assets are missing, derive provisional outputs from API contracts, tasks, and diff evidence without pretending full coverage certainty.
- If release or environment details are missing, keep deployment claims conservative and explicitly mark them as pending confirmation.

## Core output contract / core output contract
Default to Markdown or yaml/csv-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `pipeline_overview`
- `stage_graph[]`
- `suite_registry_bindings[]`
- `isolation_strategy`
- `parallelism_strategy`
- `caching_strategy`
- `cleanup_policy`
- `deployment_orchestration`
- `failure_triage_hooks[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: pipeline_orchestration`
- `stage_position: testing_and_qa.regression_and_automation.test_automation_orchestration`
- `workflow_node: N240`
- `node_artifact_target: 自动化测试编排.yaml`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Choose and justify environment isolation level L1/L2/L3 per suite type.
- Express stage dependencies as a DAG, not a flat serial list by default.
- Use caching only where keys and invalidation rules are explicit.
- Every job must define cleanup behavior, timeout, and resource limits.
- Deployment promotion and post-deploy smoke must be visible rather than hidden in prose.

## Execution workflow / execution workflow
1. Read trigger recommendations, suite artifacts, script bundle manifest, and environment constraints.
2. Choose minimal_ci, enterprise_ci, or gitops_mode and define the stage graph.
3. Bind suites to stages, parallel groups, isolation level, cache policy, and cleanup hooks.
4. Add deployment promotion, canary or rollback logic, and post-deploy smoke/test hooks when required.
5. Emit yaml-ready orchestration plus failure triage handoff for N250 and N270.

## Dynamic completeness / dynamic completeness
- Small project: keep stages few but still explicit about cleanup and isolation.
- Large service or platform: use enterprise stage graph, environment promotion, and triage hooks.
- GitOps mode: emphasize environment promotion, approvals, and canary checks.

## Quality bar / quality bar
A good orchestration artifact is executable in spirit: stages are ordered, suites are bound, isolation is credible, cleanup is guaranteed, and release-facing hooks are visible to downstream teams.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
