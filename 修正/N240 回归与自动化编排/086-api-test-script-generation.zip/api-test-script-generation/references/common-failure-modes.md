# common failure modes · n240

Avoid these mistakes:
- generating assets that claim execution results instead of design-time intent
- mixing regression, smoke, trigger, and orchestration concerns into one artifact
- omitting duration budgets, blocking behavior, or isolation needs
- forgetting downstream handoff notes for N250, N260, or N270

- dumping all tests into one file with no suite separation
- hard-coding credentials or ids into generated scripts
- regenerating scripts without preserving notes about custom assertions
