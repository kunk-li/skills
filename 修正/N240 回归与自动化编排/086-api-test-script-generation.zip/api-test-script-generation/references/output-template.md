# output template · api-test-script-generation

Represent the bundle as a zip-ready manifest such as:
- `tests/contract/test_<resource>_contract.py`
- `tests/functional/test_<resource>_flows.py`
- `fixtures/auth.py`
- `fixtures/data_factory.py`
- `config/.env.example`
- `README.md`

For each manifest item include:
- `path`
- `purpose`
- `traceability_refs`
- `depends_on`
- `customization_notes`
