# examples · api-test-script-generation

- OpenAPI adds `POST /orders` -> output includes contract test, happy-path functional test, missing field test, unauthorized test, and idempotency conflict test
- only error codes change -> output refreshes contract assertions and negative-path checks without regenerating unrelated flow tests
