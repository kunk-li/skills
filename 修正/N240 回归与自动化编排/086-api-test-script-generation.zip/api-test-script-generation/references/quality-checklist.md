# quality checklist · n240

Before finalizing, verify:
- the artifact matches the declared N240 output target
- selected mode and readiness are explicit
- key assumptions and exclusions are visible
- downstream handoff notes are present
- the artifact is easy to consume by adjacent nodes without reinterpretation

- Do scripts clearly separate contract versus functional purposes?
- Are fixtures shared and environment-safe instead of hard-coded?
- Do assertions go beyond status code into schema, fields, and side-effects where relevant?
