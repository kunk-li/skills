---
name: api-test-script-generation
description: generate workflow-aligned api test script bundles from openapi contracts, testcase assets, task breakdowns, and diff-risk evidence. use when chatgpt works in testing & qa / regression and automation and must produce the n240 api test script artifact for contract checks, functional api coverage, or automation handoff.
---
# api-test-script-generation

## Role / role positioning
This skill aligns to testing & qa -> regression and automation -> 接口测试脚本.zip. It delivers a workflow-aligned artifact for N240.

### Boundary
- Own the bundle structure, script scope, fixtures, and assertion design for API automation assets.
- Do not decide pipeline triggers or full CI orchestration.
- Do not claim runtime pass results; generate script assets and handoff guidance only.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `from_openapi_mode`: derive contract-first tests directly from the current api specification.
- `functional_mode`: focus on business flows and side-effect checks around the api layer.
- `data_driven_mode`: generate scripts plus fixtures for parameterized datasets from csv/json sources.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `开发任务拆分表.csv`
- `接口设计草案.yaml`
- `Diff风险点评.md`

### optional enhancement inputs
- 测试点清单.csv
- 异常场景清单.csv
- 边界条件清单.csv
- 错误码清单.csv
- 幂等设计建议.md
- 并发控制建议.md
- 表结构设计草案.sql
- environment variables
- vault-based credentials

## Standalone rule / standalone usage
This skill must still work on one diff, one module, one endpoint group, or one release slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If testcase assets are missing, derive provisional outputs from API contracts, tasks, and diff evidence without pretending full coverage certainty.
- If release or environment details are missing, keep deployment claims conservative and explicitly mark them as pending confirmation.

## Core output contract / core output contract
Default to Markdown or yaml/csv-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `bundle_summary`
- `script_bundle_manifest[]`
- `contract_tests[]`
- `functional_tests[]`
- `fixture_plan[]`
- `auth_fixtures[]`
- `data_factory_plan[]`
- `environment_contract`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: executable_asset_generation`
- `stage_position: testing_and_qa.regression_and_automation.api_test_script_generation`
- `workflow_node: N240`
- `node_artifact_target: 接口测试脚本.zip`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Derive endpoint coverage from OpenAPI first whenever the spec is available.
- Every generated test should define schema, status, field, and side-effect assertions when applicable.
- Prefer env vars, factories, and fixtures over hard-coded ids, tokens, or emails.
- Separate contract tests from functional tests so execution policies remain clear.
- Use shared session-scoped auth fixtures for repeated roles instead of repeated login steps.

## Execution workflow / execution workflow
1. Read OpenAPI paths, response schemas, testcase priorities, and diff-risk notes.
2. Choose contract-first, functional-first, or data-driven bundle mode.
3. Generate bundle folders, test files, fixtures, auth helpers, and environment contracts.
4. Add schema/status/field/side-effect assertion layers and boundary/errorcode cases when the evidence supports them.
5. Emit handoff notes for trigger selection, CI placement, and release evidence.

## Dynamic completeness / dynamic completeness
- Single endpoint: generate a minimal bundle with one contract file and shared fixtures.
- Module-level API change: group tests by resource and role.
- Large release: split into contract suite, functional suite, and data-driven extension sets.

## Quality bar / quality bar
A good script bundle is directly usable by automation engineers, environment-portable, and traceable back to the api contract and testcase assets.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
