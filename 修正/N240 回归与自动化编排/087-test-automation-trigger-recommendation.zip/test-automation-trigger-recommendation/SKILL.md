---
name: test-automation-trigger-recommendation
description: generate workflow-aligned automation trigger recommendations from testcase assets, diff analysis, api contracts, and review evidence. use when chatgpt works in testing & qa / regression and automation and must produce the n240 trigger recommendation artifact before pipeline wiring, ci policy tuning, or failure feedback design.
---
# test-automation-trigger-recommendation

## Role / role positioning
This skill aligns to testing & qa -> regression and automation -> 自动化触发建议.md. It delivers a workflow-aligned artifact for N240.

### Boundary
- Own trigger timing, suite mapping, retry policy, and manual trigger simplification.
- Do not generate the final CI yaml graph; hand that to orchestration.
- Do not duplicate regression or smoke scope design beyond what is needed for trigger decisions.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `trigger_designer`: design a new multi-stage trigger policy for a project or module.
- `diff_analyzer`: decide what should run for a specific diff or change set.
- `release_gate_mode`: optimize triggers around merge, release, and post-deploy readiness.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `开发任务拆分表.csv`
- `接口设计草案.yaml`
- `Diff风险点评.md`

### optional enhancement inputs
- 回归测试清单.csv
- 冒烟测试清单.csv
- 接口测试脚本.zip
- 研发依赖清单.csv
- historical flaky metrics
- CI duration baselines
- release calendar inputs

## Standalone rule / standalone usage
This skill must still work on one diff, one module, one endpoint group, or one release slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If testcase assets are missing, derive provisional outputs from API contracts, tasks, and diff evidence without pretending full coverage certainty.
- If release or environment details are missing, keep deployment claims conservative and explicitly mark them as pending confirmation.

## Core output contract / core output contract
Default to Markdown or yaml/csv-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `scope_summary`
- `trigger_matrix`
- `diff_based_selection[]`
- `selected_suites[]`
- `retry_and_flaky_policy`
- `manual_trigger_options[]`
- `slo_alignment_notes[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: trigger_policy_design`
- `stage_position: testing_and_qa.regression_and_automation.test_automation_trigger_recommendation`
- `workflow_node: N240`
- `node_artifact_target: 自动化触发建议.md`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Use a 6-stage x 4-context trigger matrix as the default mental model.
- Prefer diff-based suite selection over static run-everything defaults.
- Separate flaky retry handling from real failure blocking policy.
- Reduce manual triggers to smoke, sanity, full_regression, and custom unless the user explicitly needs more.
- Make time budgets and blocking behavior explicit for every trigger row.

## Execution workflow / execution workflow
1. Read testcase tiers, regression/smoke outputs, diff-risk notes, and release context.
2. Map the change to trigger stage(s): pre-commit, pr-open, pr-update, pr-merge, pre-release, post-deploy.
3. Select suites by diff impact and fallback policy.
4. Add flaky retry, quarantine, and manual trigger simplification rules.
5. Emit handoff data for orchestration, defect triage, and gate use.

## Dynamic completeness / dynamic completeness
- Docs-only change: mostly skip or route to smoke sanity.
- Hotfix: keep suites narrow but blocking rules strict.
- Release mode: bias toward T2/T3 and post-deploy smoke requirements.

## Quality bar / quality bar
A good trigger artifact reduces waste, chooses suites for real reasons, and makes CI behavior predictable to both developers and release owners.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
