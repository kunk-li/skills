# common failure modes · n240

Avoid these mistakes:
- generating assets that claim execution results instead of design-time intent
- mixing regression, smoke, trigger, and orchestration concerns into one artifact
- omitting duration budgets, blocking behavior, or isolation needs
- forgetting downstream handoff notes for N250, N260, or N270

- keeping fourteen manual triggers when four would cover the real workflow
- ignoring diff context and always recommending the same suites
- blocking CI on known flaky tests without quarantine policy
