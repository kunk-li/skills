# examples · test-automation-trigger-recommendation

- docs-only PR -> output maps pre-commit and pr-update to skip or smoke, not to full regression
- hotfix touching auth and migration files -> output chooses targeted regression plus strict post-deploy smoke and rollback-sensitive alerts
