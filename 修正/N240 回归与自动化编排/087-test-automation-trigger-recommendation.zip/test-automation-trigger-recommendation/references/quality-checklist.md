# quality checklist · n240

Before finalizing, verify:
- the artifact matches the declared N240 output target
- selected mode and readiness are explicit
- key assumptions and exclusions are visible
- downstream handoff notes are present
- the artifact is easy to consume by adjacent nodes without reinterpretation

- Does every trigger row state both selected suites and blocking behavior?
- Is diff-based selection more specific than generic run-all defaults?
- Are flaky retries explicit rather than implied?
