# output template · test-automation-trigger-recommendation

Recommended sections:
1. summary
2. trigger matrix table
3. diff-based selection notes
4. retry and flaky policy
5. manual trigger options
6. downstream handoff
