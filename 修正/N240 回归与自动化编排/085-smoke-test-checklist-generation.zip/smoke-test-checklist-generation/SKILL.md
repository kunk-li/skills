---
name: smoke-test-checklist-generation
description: generate workflow-aligned smoke-test checklists from testcase assets, api contracts, deployment timing, and diff-risk evidence. use when chatgpt works in testing & qa / regression and automation and must produce the n240 smoke checklist artifact for rapid validation before or after deployment.
---
# smoke-test-checklist-generation

## Role / role positioning
This skill aligns to testing & qa -> regression and automation -> 冒烟测试清单.csv. It delivers a workflow-aligned artifact for N240.

### Boundary
- Own the minimal confidence set for fast validation.
- Do not expand into broad regression coverage or full pipeline design.
- Do not confuse health pings with true smoke coverage.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `health_only`: focus on l0/l1 checks and the smallest fast path.
- `production_probe`: optimize for post-deploy and synthetic monitoring probes.
- `release_gate_smoke`: cover the pre-release and post-deploy smoke set for change approval.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `开发任务拆分表.csv`
- `接口设计草案.yaml`
- `Diff风险点评.md`

### optional enhancement inputs
- 测试点清单.csv
- 异常场景清单.csv
- 并发控制建议.md
- 幂等设计建议.md
- 发布风险评估.md
- 发版检查清单.csv
- synthetic monitoring requirements
- runbook inputs

## Standalone rule / standalone usage
This skill must still work on one diff, one module, one endpoint group, or one release slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If testcase assets are missing, derive provisional outputs from API contracts, tasks, and diff evidence without pretending full coverage certainty.
- If release or environment details are missing, keep deployment claims conservative and explicitly mark them as pending confirmation.

## Core output contract / core output contract
Default to Markdown or yaml/csv-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `scope_summary`
- `health_tier`
- `smoke_timing`
- `checklist_items[]`
- `new_feature_smoke_gaps[]`
- `duration_budget_estimate`
- `deployment_notes[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: fast_gate_validation`
- `stage_position: testing_and_qa.regression_and_automation.smoke_test_checklist_generation`
- `workflow_node: N240`
- `node_artifact_target: 冒烟测试清单.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Keep smoke fast: fast under 2 minutes, standard under 5, extended under 15.
- Separate l0 health, l1 smoke, l2 deep smoke, and l3 pre-release smoke.
- Differentiate pre-deploy and post-deploy objectives.
- New core api, state machine, role, or integration change should add at least one smoke stub.
- Prefer high-value, low-count checks over broad lists that become regression in disguise.

## Execution workflow / execution workflow
1. Classify timing: pre-deploy, post-deploy, or continuous probe.
2. Identify the absolute minimum business paths and dependency-health signals required.
3. Assign each item to an l0/l1/l2/l3 health tier and duration budget.
4. Add new-feature smoke stubs for newly introduced critical endpoints or roles.
5. Emit deployment notes for N250, N260, and N270.

## Dynamic completeness / dynamic completeness
- Small API change: one l1 path plus auth or read/write proof may be enough.
- Deployment with infrastructure changes: include l0, l1, and selective l2 checks.
- Production-probe mode: bias toward post-deploy availability, dependency reachability, and metric proof.

## Quality bar / quality bar
A good smoke artifact stays fast, proves the system is really usable, and makes timing-specific checks obvious without turning into a hidden regression pack.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
