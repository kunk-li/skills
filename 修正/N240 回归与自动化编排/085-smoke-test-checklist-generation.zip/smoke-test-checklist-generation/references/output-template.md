# output template · smoke-test-checklist-generation

Recommended columns:
- `id`
- `health_tier`
- `smoke_timing`
- `duration_budget`
- `core_flow_or_probe`
- `preconditions`
- `expected_signal`
- `dependencies`
- `rollback_or_alert_hint`
- `evidence`
