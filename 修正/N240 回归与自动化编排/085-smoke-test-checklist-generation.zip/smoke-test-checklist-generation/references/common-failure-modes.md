# common failure modes · n240

Avoid these mistakes:
- generating assets that claim execution results instead of design-time intent
- mixing regression, smoke, trigger, and orchestration concerns into one artifact
- omitting duration budgets, blocking behavior, or isolation needs
- forgetting downstream handoff notes for N250, N260, or N270

- calling an eight-minute pack fast smoke with no split plan
- using only health endpoints and calling it business smoke coverage
- forgetting to add new critical endpoints into smoke after feature growth
