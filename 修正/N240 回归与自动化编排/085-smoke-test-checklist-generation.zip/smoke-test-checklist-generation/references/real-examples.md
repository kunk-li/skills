# examples · smoke-test-checklist-generation

- pre-deploy release check -> includes config lint, core create/read path, and auth validation under 5 minutes
- post-deploy production probe -> includes health endpoint, one read api, one write api, cache check, and metric reporting proof
