---
name: regression-test-checklist-generation
description: generate workflow-aligned regression checklists from testcase assets, task breakdowns, api contracts, and diff-risk evidence. use when chatgpt works in testing & qa / regression and automation and must produce the n240 regression checklist artifact before trigger selection, pipeline orchestration, release gating, or failure triage.
---
# regression-test-checklist-generation

## Role / role positioning
This skill aligns to testing & qa -> regression and automation -> 回归测试清单.csv. It delivers a workflow-aligned artifact for N240.

### Boundary
- Own regression scope selection, tiering, and confidence framing.
- Do not turn into a smoke-only list or pipeline yaml generator.
- Do not claim execution results; design what should run next.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_impact_scan`: derive the minimum regression set from the current diff and risk context.
- `full_suite`: build a tiered regression checklist for merge or release decisions.
- `flaky_cleanup`: focus on unstable tests, quarantine logic, and cleanup recommendations.
- `release_gate_mode`: optimize the artifact for N260 and N270 readiness decisions.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `开发任务拆分表.csv`
- `接口设计草案.yaml`
- `Diff风险点评.md`

### optional enhancement inputs
- 测试点清单.csv
- 边界条件清单.csv
- 异常场景清单.csv
- 研发依赖清单.csv
- 并发控制建议.md
- 性能风险分析.md
- historical flaky data
- recent production defects
- release risk notes

## Standalone rule / standalone usage
This skill must still work on one diff, one module, one endpoint group, or one release slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If testcase assets are missing, derive provisional outputs from API contracts, tasks, and diff evidence without pretending full coverage certainty.
- If release or environment details are missing, keep deployment claims conservative and explicitly mark them as pending confirmation.

## Core output contract / core output contract
Default to Markdown or yaml/csv-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `scope_summary`
- `regression_tiers[]`
- `checklist_items[]`
- `excluded_scope[]`
- `flaky_watchlist[]`
- `historical_weight_notes[]`
- `regression_confidence_estimate`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: scope_and_confidence_planning`
- `stage_position: testing_and_qa.regression_and_automation.regression_test_checklist_generation`
- `workflow_node: N240`
- `node_artifact_target: 回归测试清单.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Apply regression scope strategy first: full, impact-based, or smoke-only fallback.
- Tier suites as T0/T1/T2/T3 and keep time budgets explicit.
- Separate flaky or quarantined checks from true blockers.
- Use recent bug history and high-risk modules to elevate must-run cases.
- Do not duplicate smoke-only checks unless they are regression-critical.

## Execution workflow / execution workflow
1. Read diff, tasks, api contract deltas, and risk review evidence.
2. Map changed modules to impact radius and choose regression scope strategy.
3. Assign items into T0/T1/T2/T3 with must, should, and optional reasoning.
4. Flag flaky or quarantined items and explain their blocking effect.
5. Estimate confidence and emit handoff notes for N250, N260, and N270.

## Dynamic completeness / dynamic completeness
- Small change: keep to T0 and a narrow impact-based set.
- Medium change: include T0/T1 and explicit dependency expansion.
- Large or release change: add T2/T3 planning and confidence factors.
- If migration, auth, audit, or compliance modules are touched, force full-regression reasoning.

## Quality bar / quality bar
A good artifact makes it obvious what must run now, what can wait, why the chosen scope is sufficient, and how much trust the team should place in the result.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
