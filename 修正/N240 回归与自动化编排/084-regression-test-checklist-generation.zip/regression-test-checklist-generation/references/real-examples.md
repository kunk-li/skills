# examples · regression-test-checklist-generation

- diff touches `src/order/*` and one OpenAPI path -> output keeps T0/T1, expands to dependent payment callbacks, and excludes unrelated admin modules
- diff includes `migration/*` -> output escalates to full regression and requires schema backward-compatibility checks
