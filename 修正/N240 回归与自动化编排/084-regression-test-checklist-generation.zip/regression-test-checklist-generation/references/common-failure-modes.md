# common failure modes · n240

Avoid these mistakes:
- generating assets that claim execution results instead of design-time intent
- mixing regression, smoke, trigger, and orchestration concerns into one artifact
- omitting duration budgets, blocking behavior, or isolation needs
- forgetting downstream handoff notes for N250, N260, or N270

- turning every historically flaky test into a blocker without triage
- calling a full-site suite impact-based without evidence
- mixing smoke-only checks into regression scope with no justification
