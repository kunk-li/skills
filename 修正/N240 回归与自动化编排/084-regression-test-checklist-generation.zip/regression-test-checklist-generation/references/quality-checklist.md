# quality checklist · n240

Before finalizing, verify:
- the artifact matches the declared N240 output target
- selected mode and readiness are explicit
- key assumptions and exclusions are visible
- downstream handoff notes are present
- the artifact is easy to consume by adjacent nodes without reinterpretation

- Does the checklist clearly distinguish regression coverage from smoke coverage?
- Is every T0 item tied to a business-critical or recently changed flow?
- Are flaky items quarantined or explained instead of silently mixed into blockers?
