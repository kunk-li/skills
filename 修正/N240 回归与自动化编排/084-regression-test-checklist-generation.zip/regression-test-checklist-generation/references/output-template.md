# output template · regression-test-checklist-generation

Recommended columns:
- `id`
- `tier`
- `priority`
- `module_or_flow`
- `check_name`
- `why_in_scope`
- `dependencies`
- `historical_weight`
- `flaky_state`
- `blocking_level`
- `evidence`
- `traceability_refs`
