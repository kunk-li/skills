# 跨 skill 编排说明

## 推荐链路

1. `diff-risk-review`：提取风险、验证重点和 open questions。
2. `code-review-comment-generation`：补充 reviewer 关注点与 blocker。
3. `pull-request-description-generation`：整合成 PR 描述。
4. `commit-message-generation`：从 PR 描述压缩生成合并前后的提交信息。

## 本 skill 需要承接的最小字段

- `id`
- `name`
- `evidence`
- `confidence`
- `open_questions`
- `severity`
- `validation_focus`
- `rollback_notes`

## 什么时候不要继续串联

- 关键验证信息为空，且用户又要求“已验证完成”的 PR 描述。
- 风险和评论仍明显冲突，尚未整理出一致口径。
