# N220 integration map

Node: N220 code review and submission collaboration.

Recommended node inputs:
- 代码规范检查单.csv
- 开发任务拆分表.csv
- git diff/改动列表

Node outputs:
- CodeReview评论.md
- Diff风险点评.md
- PR描述.md
- 提交信息.txt

Workflow downstream:
- N240
- N270
- N300
