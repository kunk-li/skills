# Traceability chain

Preferred chain:
Jira or issue id -> branch name -> commit message -> PR description -> release note.

Keep ids stable across artifacts when evidence exists.
Do not invent ticket ids, issue ids, or release labels.
