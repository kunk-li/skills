# 字段命名 contract

本批次统一原则：**共享语义统一命名，专有语义最小扩展**。

## 共享字段

| 字段 | 说明 |
| --- | --- |
| `id` | 当前输出中的稳定项 ID；不要混用 rule_id / risk_id / comment_id 等同义字段。 |
| `name` | 短标题；适合做表格第一眼识别。 |
| `object_name` | 核心业务对象、资源或实体名。 |
| `action_name` | 核心动作、意图或行为。 |
| `trigger` | 触发当前项成立、执行或评估的事件。 |
| `preconditions` | 前置条件、进入条件、适用条件。统一用数组。 |
| `constraints` | 硬约束、校验、guard、限制。统一用数组。 |
| `roles` | 相关角色、调用方、责任方。统一用数组。 |
| `evidence` | 支撑结论的原文、截图定位、日志片段、diff 线索等。统一用数组。 |
| `confidence` | 证据强度。默认优先 `direct` / `inferred` / `unknown`。 |
| `open_questions` | 尚未确认、需要补证据或需要业务拍板的问题。统一用数组。 |

## 使用规则

- 同义语义只保留一个新名字；不要在同一份 JSON 里混用旧字段与新字段。
- 若一个条目涉及多个对象、多个动作或多个结果，优先拆条，而不是把多个值塞进一个字段。
- 若必须向后兼容旧版输入，可在分析阶段做映射，但最终输出仍使用新字段。

## 本 skill 允许保留的专有扩展字段

- `change_summary`
- `impact_scope`
- `validation_notes`
- `rollback_notes`
- `reviewer_checklist`
