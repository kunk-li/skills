# Testing evidence guidance

Separate automated and manual evidence.
Prefer concrete items such as unit, integration, e2e, screenshots, logs, or CI results.
If evidence is missing, mark the gap explicitly instead of implying success.
