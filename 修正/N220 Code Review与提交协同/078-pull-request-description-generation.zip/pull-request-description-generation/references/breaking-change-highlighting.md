# Breaking change highlighting

Highlight breaking changes near the top of the PR description.
Include affected api, config, schema, migration notes, and rollback or upgrade guidance when available.
Avoid burying breaking changes deep inside the details section.
