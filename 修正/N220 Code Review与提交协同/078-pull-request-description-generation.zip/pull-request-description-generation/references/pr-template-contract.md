# PR template contract

Default required sections:
1. summary
2. related items
3. type
4. breaking changes
5. change details
6. testing
7. checklist
8. deployment notes

Keep section order stable unless the user supplies a stronger template.
