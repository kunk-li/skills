# 跨 skill 编排说明

## 推荐链路

1. `diff-risk-review`：先做上线前风险扫描。
2. `code-review-comment-generation`：把风险和规范转成 reviewer 可执行评论。
3. `pull-request-description-generation`：沉淀改动背景、风险和验证说明。
4. `commit-message-generation`：生成最终提交信息。

## 与上游对接时保留的字段

- `id`
- `name`
- `evidence`
- `confidence`
- `open_questions`
- `severity`
- `category`

## 不要继续串联的情况

- 当前评论主要来自猜测，证据不足。
- 输入没有足够代码上下文，无法定位评论。
- 用户只要单点 review 反馈，不需要端到端链路。
