# Review comment types

Use one comment_type per review item:
- blocker: must fix before merge
- suggestion: recommended improvement
- nitpick: tiny non-blocking issue
- question: reviewer needs clarification
- praise: positive feedback worth preserving
