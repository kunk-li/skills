# Review load guidance

PR size tiers:
- XS: less than 100 loc
- S: 100 to 300 loc
- M: 300 to 500 loc
- L: 500 to 1000 loc
- XL: more than 1000 loc

XL pull requests should be split before normal review whenever possible.
Calibrate comment count and reviewer count to the tier.
