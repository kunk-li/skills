# Project convention boundary

Prefer comments grounded in agreed project conventions.
If a point is only reviewer taste and no convention exists, downgrade it to question or omit it.
Avoid relitigating style choices already settled by formatter, lint, or team docs.
