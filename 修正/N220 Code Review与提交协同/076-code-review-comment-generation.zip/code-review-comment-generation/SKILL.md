---
name: code-review-comment-generation
description: generate workflow-aligned code review comments from git diffs, task context, static-analysis outputs, and project conventions. use when chatgpt works in coding & implementation / code review and submission collaboration and must produce the workflow-aligned review comment artifact for n220 after n210 static checks and before pr description or merge collaboration.
---
# code-review-comment-generation

## Role / role positioning
This skill aligns to coding & implementation -> code review and submission collaboration -> CodeReview评论.md. It delivers a workflow-aligned artifact for N220.

### Boundary
- Focus on reviewer-ready comments, not generic static analysis duplication.
- Convert findings into consistent reviewer language with action level and teaching value.
- Do not impersonate final approval, merge authority, or release judgement.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `learning_mode`: explanation-heavy, suitable for junior authors.
- `senior_mode`: concise, architecture-focused comments.
- `batch_mode`: multiple PRs or multiple patch groups in one run.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `代码规范检查单.csv`
- `开发任务拆分表.csv`
- `git diff/改动列表`

### optional enhancement inputs
- `Diff风险点评.md`
- project conventions or coding guidelines
- ticket ids, task ids, branch names
- reviewer preferences or team collaboration norms

## Standalone rule / standalone usage
This skill must still work on a single diff hunk, a patch summary, or one changed file.

Degradation rules:
- If no upstream static issues are available, state that duplication filtering is limited.
- If code context is partial, comment on confirmed evidence only.
- Use `pending_context` when the reviewer would need broader codebase context.
- Keep the output shape stable even for tiny diffs.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_review_and_submission_collaboration.code_review_comment_generation`
  - `workflow_node: N220`
  - `node_artifact_target: CodeReview评论.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `pr_size_assessment`
- `review_focus`
- `comments[]`
- `suppressed_duplicates[]`
- `teaching_notes[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every comment must carry one `comment_type` from `references/review-comment-types.md`.
- Do not restate N210 issues verbatim; reference them via `source_issue_id` or summarize once.
- Use project conventions when available; otherwise downgrade taste-based comments to `question` or omit them.
- Keep blocker comments concrete: problem, why, suggested change, risk.
- Include at least some positive or clarifying comments when deserved; do not turn review into pure negativity.
- Use the PR-size guidance in `references/review-load-guidance.md` to calibrate comment density.
- Link comments to task ids, rule ids, or risk ids when evidence exists.

## Execution workflow / execution workflow
1. Read the diff and identify the change intent and touched modules.
2. Filter out issues already fully covered by N210 or formatting tools.
3. Classify remaining comments by `comment_type` and action strength.
4. Add teaching context for blocker and high-value suggestions.
5. Group comments so a reviewer can paste or adapt them directly.
6. Prepare downstream hints for PR description and merge collaboration.

## Dynamic completeness / dynamic completeness
- Small diff: keep only the highest-signal comments.
- Medium diff: add traceability and suppressed-duplicate notes.
- Large diff: group by module or risk theme, not by raw line order.
- If input is only a static issue list without code, produce comment seeds, not fake line-level comments.

## Quality bar / quality bar
A good result should help reviewers focus on machine-blind issues, communicate clearly with authors, and avoid review fatigue. The artifact must be directly reusable in a PR conversation.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/field-contract.md`
- `references/readiness-inheritance.md`
- `references/n220-integration-map.md`
- `references/traceability-chain.md`
- `references/review-comment-types.md`
- `references/review-load-guidance.md`
- `references/project-convention-boundary.md`
