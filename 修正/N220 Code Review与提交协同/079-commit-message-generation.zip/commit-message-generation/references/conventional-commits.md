# Conventional commits

Default structure:
<type>(<scope>): <subject>

Optional body and footer should preserve traceability.

Common types:
- feat
- fix
- refactor
- perf
- test
- docs
- style
- chore
- build
- ci
