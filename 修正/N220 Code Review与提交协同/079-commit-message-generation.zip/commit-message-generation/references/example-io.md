# 示例输入输出

## 示例 1：新增订单超时取消任务

### 输入线索
- 新增定时取消未支付订单
- 增加库存回补保护

### 候选
- `feat(order): cancel overdue unpaid orders automatically`
- `feat(order): add timeout cancellation job for unpaid orders`

## 示例 2：修复权限校验缺失

### 输入线索
- 补回导出接口的角色校验

### 候选
- `fix(export): restore role checks for export endpoint`
- `fix(auth): enforce export permission validation`
