# 跨 skill 编排说明

## 推荐链路

1. `diff-risk-review`：识别风险与验证重点。
2. `code-review-comment-generation`：形成 reviewer 反馈。
3. `pull-request-description-generation`：沉淀完整 PR 描述。
4. `commit-message-generation`：压缩生成提交标题与正文。

## 上游优先读取的信息

- PR 标题与背景
- 主要改动摘要
- 风险或兼容性变化
- 是否需要 breaking change 或 issue footer

## 不要继续串联的情况

- 上游仍是多个不相关主题，没有拆分。
- 当前输入更适合生成发布说明而不是 commit message。
