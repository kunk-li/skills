---
name: commit-message-generation
description: generate workflow-aligned commit messages from git diffs, task context, ticket ids, and pr summaries. use when chatgpt works in coding & implementation / code review and submission collaboration and must produce the workflow-aligned commit message artifact for n220 while preserving traceability into pr, release, and defect workflows.
---
# commit-message-generation

## Role / role positioning
This skill aligns to coding & implementation -> code review and submission collaboration -> 提交信息.txt. It delivers a workflow-aligned artifact for N220.

### Boundary
- Focus on commit history quality and traceability.
- Prefer standardized commit candidates and split guidance over prose essays.
- Do not rewrite repository history beyond the scope the user provided.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `auto_draft`: suggest one or more commit candidates from diff evidence.
- `single`: emit one best commit message.
- `multi_commit_refine`: suggest split, reorder, or squash strategy.
- `changelog_extract`: format commits for downstream release-note use.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `代码规范检查单.csv`
- `开发任务拆分表.csv`
- `git diff/改动列表`

### optional enhancement inputs
- `PR描述.md`
- ticket ids, branch names, release labels
- risk notes or reviewer summary
- commit policy documents

## Standalone rule / standalone usage
This skill must still work on a small diff, a single logical change, or a task title.

Degradation rules:
- If scope is unclear, lower certainty and prefer generic-but-accurate scope names.
- If multiple unrelated themes exist, recommend split commits rather than forcing one message.
- If no ticket id exists, do not fabricate a footer.
- Keep output format stable even when body and footer are absent.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_review_and_submission_collaboration.commit_message_generation`
  - `workflow_node: N220`
  - `node_artifact_target: 提交信息.txt`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `suggested_strategy`
- `commit_candidates[]`
- `linked_ticket_ids[]`
- `breaking_flags[]`
- `merge_strategy_hint`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Enforce the structure in `references/conventional-commits.md` unless the user explicitly overrides it.
- Distinguish `type`, `scope`, `subject`, `body`, and `footer` clearly.
- Prefer accurate scope over flashy wording.
- For complex changes, include `What / Why / How / Impact` guidance in the body.
- Use issue and ticket footers when evidence exists; never invent ids.
- Surface breaking changes explicitly and consistently.
- Recommend squash, merge, or rebase strategy based on change granularity.

## Execution workflow / execution workflow
1. Detect the dominant logical change and likely commit type.
2. Infer or confirm scope from touched modules.
3. Draft one or more conventional-commit candidates.
4. Add body and footer when the change is complex or traceability requires it.
5. If the diff contains multiple unrelated themes, recommend a split strategy.
6. Hand off traceability to PR and release workflows.

## Dynamic completeness / dynamic completeness
- Tiny change: one concise candidate may be enough.
- Medium change: add body guidance and ticket footers.
- Multi-theme diff: produce split suggestions instead of one overloaded title.
- If breaking-change evidence is uncertain, phrase it as pending confirmation.

## Quality bar / quality bar
A good result should be short enough to use, strong enough to preserve traceability, and aligned with downstream PR and release generation.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/field-contract.md`
- `references/readiness-inheritance.md`
- `references/n220-integration-map.md`
- `references/traceability-chain.md`
- `references/conventional-commits.md`
- `references/merge-strategy-guidance.md`
