# 常见失败模式

## 1. 把关键词命中直接当风险结论
修正：脚本命中只能作为信号，还要结合业务上下文和实际 diff 证据。

## 2. 风险多但缺验证重点
修正：高风险项至少补一个 validation_focus；线上影响项还应补 monitoring_focus 或 rollback_notes。

## 3. 只给结论，不保留待确认项
修正：对关键对象、角色、数据流不明确的地方新增 `open_questions`。

## 4. 字段漂移
修正：输出前按 `references/field-contract.md` 归一化字段名称。
