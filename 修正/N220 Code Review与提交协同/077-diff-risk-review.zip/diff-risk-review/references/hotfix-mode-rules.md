# Hotfix mode rules

For hotfix reviews:
- prefer the minimum necessary diff
- require rollback clarity
- require test focus even if time is compressed
- highlight config and data risks immediately
- do not pad with nonessential refactor suggestions
