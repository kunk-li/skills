# High risk area policy

Treat changes in these kinds of areas as risk amplifiers when evidence exists:
- audit or compliance logic
- authorization and permission logic
- money, amount, settlement, or pricing logic
- schema migrations and data backfills
- configuration and feature-flag centers
- core state machines and irreversible transitions
