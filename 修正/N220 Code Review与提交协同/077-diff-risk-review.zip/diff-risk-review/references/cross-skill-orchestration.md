# 跨 skill 编排说明

## 在整条链路中的位置

- 上游常见输入：
- 代码 diff、变更描述、schema 改动、配置改动
- 下游常见去向：
- `regression-test-checklist-generation`
- `post-release-validation-checklist`

## 推荐串联方式

1. 如果上游仍是大段 prose，先做结构化，再继续串联。
2. 输出时优先保留共享字段与本 skill 的专有扩展字段，不要只给自然语言总结。
3. 如果关键对象、状态、角色或证据不明确，先输出 `open_questions`，不要把猜测继续传给下游。

## 交给下游时至少保留这些字段

- `id`
- `name`
- `object_name`
- `action_name`
- `trigger`
- `preconditions`
- `constraints`
- `roles`
- `evidence`
- `confidence`
- `open_questions`
- `severity`
- `category`
- `impact`
- `validation_focus`
- `monitoring_focus`
- `rollback_notes`

## 什么时候不要继续串联

- 关键对象、状态、角色或时间窗口仍不明确。
- 当前结论主要来自猜测，证据不足以支撑下游定稿。
- 用户只要单点答案，不需要端到端链路。
