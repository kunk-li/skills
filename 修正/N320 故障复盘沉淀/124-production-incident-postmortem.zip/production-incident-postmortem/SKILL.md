---
name: production-incident-postmortem
description: produce blame-less production postmortems for n320 postmortem work. use when the user needs a structured 线上问题复盘 from incident evidence, timelines, logs, traces, alerts, or remediation notes, and the desired output is 线上问题复盘.md or an RCA-style postmortem with five-whys, systemic causes, and executable follow-up actions. especially useful after incidents, service degradation, compliance events, or recurring operational failures.
---

# Production Incident Postmortem

## Role
Produce a **blame-less, evidence-backed postmortem** for the N320 node. Turn incident evidence into a reusable explanation of what happened, why it happened, and what must change.

## Stage position
- workflow node: N320
- node goal: 整理故障时间线并输出线上问题复盘
- node output target: `线上问题复盘.md`
- upstream handoff: `incident-timeline-compilation`, `根因定位建议.md`, `影响范围分析.md`
- downstream handoff: `N340`, `N390`

## Primary inputs
Prefer these inputs when available:
- `故障时间线.md`
- `根因定位建议.md`
- `影响范围分析.md`
- remediation notes, rollback notes, incident communications, decision logs

If no timeline exists, you may still proceed from incident evidence, but you must mark the timeline as incomplete.

## Standalone rule
You can run independently from raw RCA material. Do not block on missing timeline or missing impact scope. Produce the postmortem with explicit evidence gaps and a list of items that still require confirmation.

## Core output contract
Default output is a postmortem document that can be saved as `线上问题复盘.md`.

A strong default structure is:
1. incident summary
2. business and technical impact
3. what happened
4. five-whys analysis
5. contributing factor categories
6. root cause statement
7. containment and remediation already taken
8. action items
9. follow-up risks and learning
10. evidence gaps or unanswered questions

## Design rules
- Keep the tone blame-less. Talk about systems, signals, guardrails, handoffs, and process gaps instead of blaming people.
- Separate symptom, near cause, and systemic cause.
- Use **five-whys** and push the analysis to at least **L3 systemic depth** unless the evidence truly does not support it.
- Organize causes across these five categories when relevant:
  - people and role clarity
  - process and review flow
  - technology and system behavior
  - monitoring and observability
  - mechanism or governance
- If the evidence only supports a hypothesis, say so and attach a confidence level.
- Action items must be concrete. Avoid vague items such as "improve awareness" or "strengthen training" unless they are converted into measurable work.

Read `references/tl-blame-less-rules.md` before finalizing tone.
Read `references/why-depth-rubric.md` when deciding whether the RCA is deep enough.
Read `references/action-item-contract.md` when shaping corrective actions.

## Execution workflow
1. Consolidate the incident summary from the timeline and source evidence.
2. State the impact in user, service, data, compliance, and operational terms when possible.
3. Build the five-whys chain and push until you reach a systemic cause or an evidence limit.
4. Classify contributing factors across the five cause categories.
5. Draft a root-cause statement that is supported by evidence, not intuition.
6. Convert lessons into action items with full execution fields.
7. Run the blame-less checker and the why-depth rubric before finalizing.

## Why-depth rubric
Use these depth levels to judge the RCA:
- `L1 symptom`: what visibly failed
- `L2 near_cause`: the immediate technical or procedural trigger
- `L3 systemic_cause`: the missing guardrail, review, ownership, or design rule
- `L4 organizational_cause`: recurring cross-team or operating-model weakness
- `L5 strategic_cause`: incentives, values, or long-term structural choices

Target `L3` or deeper for any serious incident. If you stop earlier, explain why.

## Action item contract
Every action item should include five fields:
- `what`
- `who_role`
- `deadline`
- `success_criteria`
- `dependency`

If an action item cannot be expressed in those fields, it is probably too vague.

## Dynamic completeness
At minimum, include:
- one concise incident summary
- one impact statement
- one five-whys chain
- one supported root-cause statement
- one action-item table with executable owners and deadlines

When evidence is richer, expand to a full postmortem package.

## Quality bar
A good result:
- is clearly blame-less
- reaches systemic depth instead of stopping at surface causes
- makes confidence and evidence visible
- turns lessons into actions that can be tracked
- can be consumed directly by audit, governance, or best-practice documentation

## Standalone use cases
- write a production postmortem after an outage or severe degradation
- run a structured RCA for a recurring operations issue
- convert remediation notes into a reusable learning artifact
- prepare a governance-ready incident review without naming individuals

## Composition contract
When `incident-timeline-compilation` is also used:
- that skill owns factual chronology
- this skill owns causal analysis and improvement commitments
- reuse timeline anchors and evidence references instead of rebuilding chronology from scratch
