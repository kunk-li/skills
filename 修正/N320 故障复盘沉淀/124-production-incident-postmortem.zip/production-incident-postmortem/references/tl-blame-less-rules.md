# Blame-less Rules for Incident Documentation

Use this rule set whenever you draft incident timelines or postmortems.

## Core principle
Describe systems, signals, decisions, handoffs, constraints, and missing safeguards. Do not attribute fault to an individual person.

## Preferred subject forms
- team names: sre, api team, compliance, database team
- role names: on-call engineer, incident commander, release manager, tech lead
- system names: api-gateway, order-service, mysql-primary, prometheus
- process or mechanism names: escalation policy, rollout checklist, timeout policy, canary gate

## Avoid
- personal names
- emails or chat handles as owners
- wording that frames one person as the cause
- moral judgment language such as careless, negligent, forgot, should have known

## Rewrite patterns
- "alice misconfigured the alert" -> "the alert configuration was changed without the expected review gate"
- "bob forgot to rotate the key" -> "the key-rotation process did not trigger before expiry"
- "charlie deployed the bad build" -> "the release pipeline promoted a build without blocking on the missing check"

## Owner field policy
Owner fields must use a role or team, never a person.
Examples:
- `owner_role: sre`
- `owner_role: compliance_officer`
- `owner_role: order_service_team`

## Blame-less checker
Before finalizing, scan the draft for:
- `@` mentions
- personal email patterns
- common Chinese or English full-name patterns
- direct blame verbs next to a person name
If found, rewrite the sentence around role, team, system, process, or mechanism.
