# Action Item Contract

Every action item must be concrete enough to track.

## Required fields
- `what`: the exact change or deliverable
- `who_role`: team or role, never a person name
- `deadline`: target date or time window
- `success_criteria`: measurable evidence that the action worked
- `dependency`: prerequisite task, approval, rollout, or resource

## Good examples
- `what`: add a release gate that blocks if rollback rehearsal evidence is missing
  `who_role`: release_engineering
  `deadline`: 2026-06-15
  `success_criteria`: all production releases include rehearsal evidence links in the checklist
  `dependency`: pipeline rule update approved by sre

- `what`: standardize incident alert routing for db saturation alerts
  `who_role`: sre
  `deadline`: next sprint
  `success_criteria`: db saturation alerts route only to dba+sre and duplicate cascades drop by 80 percent
  `dependency`: alert routing table review

## Reject vague action items
Rewrite or reject items such as:
- strengthen awareness
- improve communication
- be more careful
- pay more attention
