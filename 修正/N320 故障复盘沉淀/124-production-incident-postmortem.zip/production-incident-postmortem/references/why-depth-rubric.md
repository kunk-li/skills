# Why-Depth Rubric

Use this rubric to prevent shallow postmortems.

## Depth levels
- `L1 symptom`: visible failure or complaint
- `L2 near_cause`: immediate trigger such as timeout, missing check, bad deploy, wrong config
- `L3 systemic_cause`: missing guardrail, review rule, ownership boundary, validation step, or architectural assumption
- `L4 organizational_cause`: recurring coordination, staffing, process, or operating-model weakness
- `L5 strategic_cause`: incentive, value, roadmap, or structural choice that keeps recreating similar incidents

## Minimum expectation
- minor incidents may stop at L2 if the evidence is truly limited
- meaningful service incidents should reach L3
- recurring or severe incidents should attempt L4 or L5

## Warning signs of shallow RCA
- stops at "human error"
- stops at "bug in code"
- stops at "misconfiguration" without asking why it passed the system
- proposes only awareness or training without a control change
