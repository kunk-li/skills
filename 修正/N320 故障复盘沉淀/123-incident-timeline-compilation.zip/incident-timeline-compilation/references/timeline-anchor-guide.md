# Timeline Anchor Guide

Use these anchors to group incident facts. Keep them generic and reusable.

1. `detection` - first signal, alert, report, or symptom noticed
2. `triage` - first classification, prioritization, or confirmation that the issue is real
3. `escalation` - handoff to a higher-severity channel, team, or incident lead
4. `diagnosis` - evidence gathering, narrowing, hypothesis testing
5. `mitigation` - actions that reduce blast radius or user harm
6. `verification` - checks that confirm whether mitigation worked
7. `remediation` - corrective technical change, patch, config change, or operational fix
8. `recovery` - service, workflow, or user path restored to acceptable state
9. `communication` - internal or external communication, status updates, or stakeholder notices
10. `archival` - incident closure, record preservation, audit handoff, or postmortem scheduling

If the incident includes a special time-sensitive period, describe it generically, for example:
- `compliance-sensitive-window`
- `peak-traffic-window`
- `billing-close-window`
- `regulated-processing-window`
