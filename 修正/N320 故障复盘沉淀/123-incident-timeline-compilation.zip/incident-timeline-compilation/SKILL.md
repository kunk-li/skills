---
name: incident-timeline-compilation
description: compile incident timelines for n320 postmortem work. use when the user needs a structured, blame-less timeline from alerts, logs, traces, tickets, chat notes, or incident fragments, and the desired output is 故障时间线.md or a timeline section that can feed a production postmortem. especially useful for incident reconstruction, after-action review preparation, regulatory or audit-safe factual chronology, and situations where facts must be separated from inference.
---

# Incident Timeline Compilation

## Role
Produce a **fact-first, blame-less incident timeline** for the N320 node. Convert scattered operational evidence into a chronology that other humans or downstream skills can trust.

## Stage position
- workflow node: N320
- node goal: 整理故障时间线并输出线上问题复盘
- node output target: `故障时间线.md`
- downstream handoff: `production-incident-postmortem`, `N340`, `N390`

## Primary inputs
Prefer these inputs when available:
- `日志分析.md`
- `告警归因.md`
- alert records, log excerpts, trace snapshots, ticket updates, chat notes, monitoring screenshots

Also accept partial fragments, raw notes, or mixed evidence.

## Standalone rule
You can run without the companion postmortem skill. If only fragments are available, still produce a usable draft timeline. Mark unsupported intervals, unresolved timestamps, and missing evidence explicitly instead of inventing continuity.

## Core output contract
Default output is a timeline document or table that can be saved as `故障时间线.md`.

Each timeline entry should prefer these 10 fields:
- `timestamp`
- `actor_role`
- `signal`
- `action`
- `state_change`
- `evidence_ref`
- `owner_role`
- `escalation`
- `communication`
- `note`

The timeline should also group entries into these lifecycle anchors when possible:
1. detection
2. triage
3. escalation
4. diagnosis
5. mitigation
6. verification
7. remediation
8. recovery
9. communication
10. archival

## Design rules
- Keep the timeline factual. Do not embed root-cause conclusions here.
- Separate three layers whenever needed:
  - confirmed fact
  - bounded inference
  - open question
- Normalize timestamps to one timezone if possible and state the timezone.
- Preserve evidence anchors. Every important event should point to a source or evidence note.
- Use a **blame-less** style at all times. Owners must be roles or teams, not individuals.
- If the incident involves a sensitive operating window, describe it generically as a `compliance-sensitive-window` or other contextual window rather than project-specific jargon.
- If multiple fragments conflict, keep both with a conflict note instead of silently choosing one.

Read `references/tl-blame-less-rules.md` when drafting or checking tone.
Read `references/timeline-anchor-guide.md` when deciding lifecycle anchors.

## Execution workflow
1. Gather all available evidence and list the missing sources.
2. Normalize timestamps, timezone, system names, and role labels.
3. Extract event candidates and map them to the narrowest valid lifecycle anchor.
4. Build the chronology in timestamp order.
5. For every major incident step, attach evidence, owner role, escalation, and communication signals.
6. Run the blame-less checker before finalizing.
7. Add a short unresolved-items section for gaps that the postmortem should investigate later.

## Dynamic completeness
At minimum, include the earliest detection point, the first responder action, the decisive mitigation or rollback action, the restoration point, and the communication or archival endpoint.

If data is richer, expand to a full anchor-by-anchor timeline.

## Quality bar
A good result:
- reads as a trustworthy chronology rather than an opinion piece
- contains no personal blame framing
- can be handed directly to the postmortem skill without reformatting
- makes missing evidence visible
- distinguishes action taken from state change observed

## Standalone use cases
- reconstruct a production incident from mixed logs and chat fragments
- prepare a regulator-safe or audit-safe factual chronology
- summarize a complex decision timeline for senior review
- convert incident notes into a reusable timeline template for later RCA

## Composition contract
When `production-incident-postmortem` is also used:
- this skill owns **what happened and when**
- the postmortem skill owns **why it happened and what must change**
- do not pre-fill root-cause claims into the timeline unless they are explicitly framed as later conclusions
