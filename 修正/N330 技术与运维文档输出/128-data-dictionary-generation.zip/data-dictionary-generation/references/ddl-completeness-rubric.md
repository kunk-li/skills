# 数据字典完整性自检

每个核心对象至少检查：
- `primary_key`
- `foreign_keys`
- `indexes`
- `charset_or_encoding`
- `nullable_and_required`
- `default_values`
- `enum_or_reference_tables`
- `source_of_truth`
- `related_api_ids`
- `related_field_ids`

若缺任何一类，必须在“缺失与待确认”里显式暴露。
