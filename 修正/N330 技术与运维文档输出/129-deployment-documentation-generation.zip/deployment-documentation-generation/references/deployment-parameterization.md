# 部署参数化规则

## 可配置项
- `{CANARY_STAGES}`: 阶段列表，而不是固定 3 阶
- `{CANARY_PERCENTAGES}`: 每阶段流量或 cohort
- `{ROLLBACK_OPTIONS}`: 按 RTO 排序的回滚路径列表
- `{PHASE_TO_GATE_RULES}`: 每个部署 phase 完成后的 gate 条件
- `{DEPLOYMENT_TOOLCHAIN}`: Helm / Argo CD / Spinnaker / GitLab CI / GitHub Actions 等

## 要求
- 不要把 `5% -> 25% -> 100%` 写死成唯一方案。
- 不要把 4 个回滚 phase 写死成所有项目都适用。
- 始终说明哪些值是“当前项目填充值”，哪些是“模板参数”。
