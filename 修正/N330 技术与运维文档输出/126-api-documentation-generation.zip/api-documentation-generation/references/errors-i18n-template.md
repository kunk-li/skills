# Error 文档国际化模板

每个错误码建议同时给出：
- `error_code`
- `http_status`
- `default_message_zh_cn`
- `default_message_en_us`
- `cause`
- `client_action`
- `server_action`
- `related_api_ids`
