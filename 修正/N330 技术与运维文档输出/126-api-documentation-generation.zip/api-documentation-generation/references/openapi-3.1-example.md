# OpenAPI 3.1 示例骨架

```yaml
openapi: 3.1.0
info:
  title: Example API
  version: 1.0.0
paths:
  /tickets/{ticket_type}:
    post:
      operationId: API-id-01
      summary: create ticket by type
      parameters:
        - name: ticket_type
          in: path
          required: true
          schema:
            type: string
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CreateTicketRequest'
      responses:
        '200':
          description: success
        '400':
          description: validation error
components:
  schemas:
    CreateTicketRequest:
      type: object
```
```
