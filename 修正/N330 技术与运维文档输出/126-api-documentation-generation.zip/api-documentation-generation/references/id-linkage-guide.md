# N080 / N090 ID 对齐指引

## 优先复用的 ID
- 页面：`P-{module}-{nn}`
- 功能：`FT-{module}-{page_seq}-{nn}`
- 后端能力：`BE-{module}-{nn}`
- 接口：`API-{module}-{nn}`
- 动作：`ACT-{module}-P{page_seq}-{nn}`
- 字段：`FLD-{module}-P{page_seq}-{nn}`
- PRD 章节：`PRD-XX`

## 使用规则
- 引用现有 ID 时，保持原样，不增删前缀。
- 不能确认对应关系时，写 `待确认`，不要自行映射。
- 若输出面向独立项目且没有上游 ID，可临时生成 `TEMP-*`，但必须在“缺失与待确认”中要求回填。
