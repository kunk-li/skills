# N330 文档家族交叉链接规则

## 目标
把 125-130 六份文档做成一个可以独立阅读、也可以组合消费的文档家族。

## 统一 cross-link 字段
每份文档都尽量显式给出：
- `doc_family_id`: 固定写 `n330-rd-doc-suite`
- `doc_id`: 当前文档自己的稳定标识
- `related_module_ids`: 来自模块设计或上游原型/PRD 的模块标识
- `related_feature_ids`: 优先复用 `FT-{module}-{page_seq}-{nn}`
- `related_api_ids`: 优先复用 `API-{module}-{nn}`
- `related_field_ids`: 优先复用 `FLD-{module}-P{page_seq}-{nn}`
- `related_prd_sections`: 优先复用 `PRD-XX`
- `related_runbooks`: 指向部署文档或维护手册中的 runbook / phase / scenario

## 跨节点 ID 对齐
- 若上游已有 N080 `FT- / API- / FLD-`，不得重新发明新的主键空间。
- 若上游已有 N090 `PRD-XX`，应在相关章节显式回链。
- 若缺少上游 ID，可临时生成占位 ID，但必须标注为 `temporary_id`，并在文档里单列待回填项。

## 组合使用建议
- 127 先定义模块与服务卡片。
- 126 与 128 复用 127 的模块边界与服务卡片。
- 125 汇总 126/127/128 为新人或开发者入口。
- 129 复用 127 的服务依赖与 126 的接口入口。
- 130 复用 129 的部署/回滚路径与 N300/N310 的运维场景。
