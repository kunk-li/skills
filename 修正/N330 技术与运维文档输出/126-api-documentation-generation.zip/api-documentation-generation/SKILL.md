---
name: api-documentation-generation
description: generate api documentation for the n330 technical and operations documentation node. use when ChatGPT needs to turn endpoint definitions, controller drafts, backend capabilities, or integration notes into a grounded api document with explicit granularity rules, stable api ids, and reusable request, response, and error sections.
---

# 接口文档生成

## Role
作为 N330 文档家族中的接口契约文档生成器，产出面向联调、集成、测试和客户端的 API 文档。默认优先复用上游 `API-*` ID，不重新发明接口编号体系。

## Selected mode
- `api_level`：关键接口逐个成文。
- `module_level`：按业务模块分组。
- `hybrid`：对外接口逐个成文，对内辅助接口按模块分组。
- `controller_fallback`：只有 controller 或路由定义时，从代码反推。

## Primary inputs
- 接口设计草案、controller/service 草稿、OpenAPI 片段、错误码定义
- 上游 N080 `API-*`、`BE-*`
- 上游 N090 `PRD-XX`
- DTO / VO / validator / exception 类定义

## Standalone rule
单独使用时也必须先决定 API 文档粒度，不得既像 endpoint 文档又像模块综述而没有粒度声明。

## Core output contract
默认输出这些部分：
1. 文档范围与粒度策略
2. API 索引表（必须包含 `API-*` 或临时 ID）
3. 认证、鉴权、幂等、限流约定
4. 请求参数与 schema
5. 响应 schema 与状态码
6. 错误码与 i18n 模板
7. 版本与兼容性说明
8. cross-links
9. 缺失与待确认

API 索引表至少给出：
- `api_id`
- `module`
- `method`
- `path`
- `operation_summary`
- `related_prd_sections`
- `related_feature_ids`

## Design rules
- 优先复用 N080 `API-{module}-{nn}`；没有时才允许 `TEMP-API-*`。
- 必须显式声明文档粒度：`api_level` / `module_level` / `hybrid`。
- 错误码文档不要只写中文；至少保留 i18n 模板位。
- 若输入不足以生成严格 OpenAPI，也可以生成接口说明稿，但必须显式说明尚未达到 machine-readable 级别。

## Execution workflow
1. 判断当前更适合接口级、模块级还是混合级。
2. 收集 endpoint、request、response、error、auth 五类信息。
3. 建 API 索引表并与 `API-*` 对齐。
4. 生成 schema、错误码与兼容性说明。
5. 用 `cross-links` 回链到 `PRD-XX`、`FT-*`、数据对象与相关模块文档。

## Dynamic completeness
- 只有 controller 路由，没有错误码时：允许继续，但错误码章节必须标缺口。
- 只有 PRD 与 backend capability，没有最终路径时：输出接口意图稿，不伪造最终 path 和 schema。

## Standalone use cases
- REST API 项目联调文档
- 内部平台 API 治理
- 第三方开放接口说明
- 从 controller 代码反推 OpenAPI 草稿

## Quality bar
- 是否声明了 API 文档粒度
- 是否对齐了 `API-*`
- 是否给出 request/response/error 三件套
- 是否预留 i18n 错误码结构
- 是否可被测试、客户端、运维共同消费

## References
- `references/api-granularity-rules.md`
- `references/openapi-3.1-example.md`
- `references/errors-i18n-template.md`
- `references/id-linkage-guide.md`
- `references/n330-document-family-crosslinks.md`
