# 技术栈占位符模板

将项目特定技术栈改成参数化占位符，不要把某一项目的实现写死成全局默认：

- `{DATABASE}`
- `{ORM}`
- `{RUNTIME}`
- `{MESSAGE_BROKER}`
- `{CACHE}`
- `{RESILIENCE_PATTERN}`
- `{SAGA_PATTERN}`
- `{OBSERVABILITY_STACK}`
- `{CI_CD_PLATFORM}`

## 写法要求
- 先写“能力需求”，再写“当前项目填充值”。
- 若项目未给出具体技术栈，输出占位符而非拍脑袋指定具体产品。
