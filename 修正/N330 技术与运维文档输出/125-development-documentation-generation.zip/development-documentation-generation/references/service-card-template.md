# 服务卡片模板

固定使用 6 字段：
1. `name`
2. `responsibilities`
3. `interfaces`
4. `dependencies`
5. `nfr_expectations`
6. `sizing_or_scale_assumption`

## 示例
```yaml
service_card:
  name: order-service
  responsibilities:
    - 负责订单生命周期与状态迁移
  interfaces:
    - API-order-01
    - event: order.created
  dependencies:
    - payment-service
    - audit-service
  nfr_expectations:
    - p99 < 200ms
    - 所有写操作可审计
  sizing_or_scale_assumption:
    - 峰值 300 qps
```
