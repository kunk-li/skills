---
name: development-documentation-generation
description: generate developer-facing documentation for the n330 technical and operations documentation node. use when ChatGPT needs to turn architecture, product, api, data, deployment, or operations materials into an onboarding and implementation guide that stays grounded, stack-agnostic, and cross-linked to the rest of the document family.
---

# 开发文档生成

## Role
作为 N330 文档家族中的开发者入口文档生成器，产出“新人 3 天能上手、已有成员能快速对齐”的开发文档。默认把模块、接口、数据、部署和运维文档串成一个统一入口，而不是只做孤立说明。

## Selected mode
先判断并显式选择一种模式：
- `document_family_aligned`：已有 126/127/128/129/130 或等价材料，适合做统一入口。
- `stack_placeholder_first`：技术栈不完整，先保留 `{DATABASE}` 等占位符，不硬写具体产品。
- `direct_input_fallback`：仅有零散设计材料，也要给出最小可读版本。

## Primary inputs
优先使用：
- 技术方案、模块设计、接口说明、数据字典、部署说明、维护手册
- 上游 N080 / N090 的 `FT-*`、`API-*`、`FLD-*`、`PRD-XX`
- 当前项目的技术栈、开发流程、环境约束、禁令或特殊规范

## Standalone rule
单独使用时也可以输出开发文档，但必须显式区分：
- 已确认的技术栈与流程
- 仍需用占位符保留的栈选择
- 需要由 126/127/128/129/130 后续补链的内容

## Core output contract
默认输出以下章节，标题可微调，但语义不能缺：
1. 文档摘要
2. 读者与适用范围
3. 系统与模块总览
4. 技术栈占位符表
5. 服务卡片汇总
6. 核心开发流程
7. 关键约束 / 禁令 / 非功能要求
8. 本地开发与调试入口
9. cross-links
10. 缺失与待确认

`cross-links` 至少给出：
- 相关 `PRD-XX`
- 相关 `FT-*`
- 相关 `API-*`
- 指向 126/127/128/129/130 的文档位点

## Design rules
- 不要把 `{DATABASE}`、`{ORM}`、`{SAGA_PATTERN}` 等占位符直接替换成某项目默认值，除非输入明确给出。
- 服务说明优先复用统一服务卡片 6 字段格式。
- 文档目标是“开发者能快速上手”，不是重写 PRD 或架构方案。
- 若发现项目特有死令、合规禁令或运维约束，写成“当前项目填充值”，不要写成跨项目普适规律。

## Execution workflow
1. 识别读者：新人开发、已有开发、外包接手、实施支持。
2. 收集模块、接口、数据、部署、维护五类交叉引用。
3. 建立技术栈占位符表，再填入已知项目值。
4. 用服务卡片串起模块边界与开发入口。
5. 在文末输出 `cross-links` 和缺失项，确保后续可以和其他 N330 skill 组合。

## Dynamic completeness
- 只有模块，没有接口/数据时：允许先输出开发文档骨架，但必须标记哪些章节待 126/128 补齐。
- 有接口和数据但没有部署/维护信息时：仍可给开发文档，但 `cross-links` 要显式说明运维部分缺失。

## Standalone use cases
- 新项目 onboarding 文档
- 遗留系统补齐开发者入口文档
- 外包或跨团队交接文档
- 培训 / bootcamp 材料骨架

## Quality bar
交付前检查：
- 是否已经把项目特定技术栈占位符化
- 是否已经回链到 `PRD-XX`、`FT-*`、`API-*`
- 是否用统一服务卡片而不是散乱段落
- 是否把缺失与待确认显式写出
- 是否能独立阅读，同时又能顺利组合进入 N330 文档家族

## References
- 先读 `references/tech-stack-placeholder-template.md`
- 需要统一服务描述时读 `references/service-card-template.md`
- 需要做跨文档链接时读 `references/n330-document-family-crosslinks.md`
- 需要和 N080 / N090 对齐时读 `references/id-linkage-guide.md`
