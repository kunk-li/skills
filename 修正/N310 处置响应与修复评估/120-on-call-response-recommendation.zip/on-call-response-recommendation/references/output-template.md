# Output Template

## Recommended metadata block
- `selected_mode`
- `readiness`
- `evidence_profile`
- `workflow_node`
- `node_artifact_target`
- `function_bias`
- `stage_position`
- `tool_collaboration_mode`

## Evidence discipline
Always separate:
- direct evidence
- inference
- assumption
- blocker / missing input
