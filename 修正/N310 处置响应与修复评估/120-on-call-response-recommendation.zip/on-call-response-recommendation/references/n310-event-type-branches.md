# N310 Event Type Branches

Use exactly one primary `event_type_branch` for each recommendation.

## compliance
Use when the incident may violate audit, authorization, privacy, regulatory, or policy constraints.
Prioritize containment, evidence preservation, signoff, and legal/compliance notification.

## performance
Use when the main symptom is latency regression, throughput collapse, queue buildup, or resource saturation without clear correctness breach.
Prioritize capacity, throttling, rollbackability, and safe degradation.

## availability
Use when the service or critical capability is unavailable, unstable, or repeatedly failing for users.
Prioritize user restoration speed, blast-radius reduction, rollback, and incident communication.

## data_consistency
Use when the main risk involves duplicate writes, stale reads, inconsistent state propagation, lost updates, replay, or irreversible business-state corruption.
Prioritize write protection, reconciliation, data safety, and reversibility.
