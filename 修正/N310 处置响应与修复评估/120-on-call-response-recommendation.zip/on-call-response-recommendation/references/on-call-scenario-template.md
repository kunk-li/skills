# On-call Scenario Template

Each response scenario should include:
- `scenario_id`
- `event_type_branch`
- `trigger_signal`
- `tier_recommendation`
- `initial_detection_actions`
- `containment_actions`
- `escalation_targets`
- `signoff_requirements`
- `audit_requirements`
- `stabilization_exit_criteria`
