# N310 Handoff Contract

## Shared fields
Every N310 output should expose these machine-readable anchors when possible:
- `incident_id`
- `event_type_branch`
- `readiness`
- `evidence_profile`
- `open_blockers[]`
- `owner_placeholders[]`
- `downstream_handoff`

## 120 -> 121
`on-call-response-recommendation` should hand off:
- tier recommendation
- incident snapshot
- containment already attempted
- temporary restrictions or kill-switch actions
- unresolved blockers

## 121 -> 122
`remediation-plan-recommendation` should hand off:
- selected remediation candidate
- whether `hotfix` is recommended
- expected diff surface
- rollback assumptions
- regression minimums
- approvals required

## N310 -> downstream nodes
- `N270`: when the selected path is hotfix or emergency release
- `N320`: when incident timeline, decisions, and remediation outcomes should be preserved for retrospective review
