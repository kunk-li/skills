# Quality Checklist

Before finalizing:
- Keep the result within N310 scope.
- Make the decision path auditable.
- Prefer quantitative thresholds over prose-only judgement.
- Surface blockers explicitly.
- Keep outputs consumable by the next skill or human owner.
