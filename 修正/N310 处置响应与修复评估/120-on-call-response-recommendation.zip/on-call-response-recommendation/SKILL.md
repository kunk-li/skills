---
name: on-call-response-recommendation
description: generate workflow-aligned on-call response recommendations from 根因定位建议.md, 影响范围分析.md, 告警归因.md, incident alerts, and runtime evidence. use when chatgpt works in operations governance / incident response and must produce the n310 值班处置建议.md artifact, auto-classify incident tier from compliance impact, user impact, and reversibility, branch handling by compliance/performance/availability/data_consistency event types, recommend responder sequence, containment steps, escalation windows, and audit-ready runbook actions.
---
# on-call-response-recommendation

## Role / role positioning
This skill aligns to operations governance -> incident response -> 值班处置建议.md. It is the authoritative N310 skill for immediate response ordering and incident-command guidance.

### Boundary
- Own first-response sequencing, incident tier recommendation, event-type branching, containment ordering, and escalation guidance.
- Consume upstream observability evidence instead of recreating deep RCA.
- Do not replace `remediation-plan-recommendation` for durable fix-path selection.
- Do not replace `hotfix-risk-assessment` for emergency change gating.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_triage`
- `scenario_playbook`
- `major_incident_command`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `根因定位建议.md`
- `影响范围分析.md`
- `告警归因.md`

### optional enhancement inputs
- raw alert payloads or incident summaries
- recent deployment or config-change evidence
- dashboard screenshots or query results
- time-window logs or traces
- customer-facing impact reports
- feature-flag inventory or kill-switch list
- on-call roster, escalation tree, or signoff roster

## Standalone rule / standalone usage
This skill must still work from a single alert, one incident summary, or one partial evidence bundle.

Degradation rules:
- If root cause evidence is weak, lead with containment-first actions and mark the analysis as provisional.
- If roster or signoff ownership is missing, emit explicit blockers instead of inventing names.
- If only technical signals exist, still classify the event type, but keep business-impact assumptions separate.

## Core output contract / core output contract
Default to markdown sections or table-like structures that can be copied into `值班处置建议.md`.

The result must include at least:
- `metadata`
- `incident_snapshot`
- `tier_auto_classification`
- `event_type_branch`
- `response_sequence[]`
- `containment_options[]`
- `escalation_chain`
- `communication_points`
- `signoff_and_audit_requirements`
- `handoff_to_remediation`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: immediate_response_ordering_and_incident_command_guidance`
- `stage_position: operations_governance.incident_response.on_call_response`
- `workflow_node: N310`
- `node_artifact_target: 值班处置建议.md`
- `evidence_profile`
- `tool_collaboration_mode`

Each `response_sequence` step must include:
- `step_id`
- `goal`
- `action`
- `owner_role`
- `timebox`
- `verification_signal`
- `fallback_if_unsuccessful`

## Design rules / design rules
- Use exactly one `event_type_branch`: `compliance`, `performance`, `availability`, or `data_consistency`.
- Always auto-classify a recommended tier using three factors: `compliance_impact`, `user_impact`, and `reversibility`.
- Use `Tier 0` for compliance breach or irreversible data harm even when traffic is low.
- Use `Tier 1` for widespread or systemic impact, or a composite score >= 7.
- Every response must separate detection, containment, communication, signoff, and audit actions.
- Every scenario must preserve a downstream handoff packet for remediation planning.
- Replace project-specific incident names with event-type placeholders; do not hardcode one business's dead-order rules, audit windows, or saga names as if they were universal.

## Execution workflow / execution workflow
1. Normalize the alert, impact evidence, and observability clues into one incident snapshot.
2. Identify the primary `event_type_branch` and compute the recommended incident tier.
3. Build a short, time-boxed response sequence focused on containment and evidence preservation.
4. Add escalation, signoff, and audit requirements consistent with the event type.
5. Hand off unresolved diagnosis and durable-fix needs to remediation planning.

## Dynamic completeness / dynamic completeness
- If evidence is weak, provide competing hypotheses only after the immediate response order is clear.
- If the event spans multiple domains, name one primary branch and list secondaries in `incident_snapshot` instead of mixing playbooks.
- If rollback or kill-switch capability is unknown, treat that uncertainty as a blocker.

## Quality bar / quality bar
A good on-call response recommendation is fast to execute, quantitatively tiered, explicit about ownership, and safe to hand to a real responder under pressure.

## Reference files / reference files
- `references/n310-event-type-branches.md`
- `references/n310-tier-and-criticality-rubrics.md`
- `references/n310-handoff-contract.md`
- `references/on-call-scenario-template.md`
- `references/output-template.md`
- `references/quality-checklist.md`
