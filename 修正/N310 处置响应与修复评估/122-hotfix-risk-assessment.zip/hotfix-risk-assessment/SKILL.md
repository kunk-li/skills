---
name: hotfix-risk-assessment
description: generate workflow-aligned hotfix risk assessments from 修复方案建议.md, 根因定位建议.md, 影响范围分析.md, 告警归因.md, and proposed patch scope. use when chatgpt works in operations governance / incident response and must produce the n310 热修复风险评估.md artifact, apply event-type-specific checklists, quantify hotfix go/no-go risk, connect remediation plans to review, regression, rollout, and rollback gates, or support emergency release approval.
---
# hotfix-risk-assessment

## Role / role positioning
This skill aligns to operations governance -> incident response -> 热修复风险评估.md. It is the authoritative N310 skill for deciding whether an emergency change is safe enough to execute.

### Boundary
- Own hotfix checklisting, go/no-go recommendation, and emergency-change guardrails.
- Consume remediation recommendations instead of redefining the bug or the fix intent.
- Do not replace on-call containment guidance.
- Do not replace long-form RCA or retrospective work.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `rapid_hotfix_gate`
- `event_type_checklist`
- `comprehensive_go_no_go`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `根因定位建议.md`
- `影响范围分析.md`
- `告警归因.md`

### optional enhancement inputs
- `修复方案建议.md`
- candidate patch or diff summary
- regression evidence or minimum suite map
- rollback plan or rollback evidence
- signoff roster and release-owner map
- canary or release guardrail rules

## Standalone rule / standalone usage
This skill must still work from a proposed fix summary and a rough incident description.

Degradation rules:
- If remediation details are missing, assess the hotfix as provisional and flag missing change-scope evidence.
- If rollback evidence is missing, treat that gap as a blocker, not a mild note.
- If signoff ownership is unknown, preserve the checklist but block `go`.

## Core output contract / core output contract
Default to markdown sections or tables that can be copied into `热修复风险评估.md`.

The result must include at least:
- `metadata`
- `hotfix_candidate_summary`
- `event_type_branch`
- `per_type_checklist[]`
- `checklist_summary`
- `risk_matrix`
- `go_no_go_recommendation`
- `blockers[]`
- `required_approvals`
- `regression_minimums`
- `rollout_guardrails`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: emergency_change_risk_assessment_and_release_gate`
- `stage_position: operations_governance.incident_response.hotfix_risk_assessment`
- `workflow_node: N310`
- `node_artifact_target: 热修复风险评估.md`
- `evidence_profile`
- `tool_collaboration_mode`

Each `per_type_checklist` item must include:
- `checklist_id`
- `event_type_branch`
- `requirement_level`
- `control_area`
- `question`
- `verification_method`
- `evidence_expected`
- `blocker_if_failed`
- `owner_role`
- `can_be_deferred`
- `notes`

## Design rules / design rules
- Use one primary `event_type_branch`: `compliance`, `performance`, `availability`, or `data_consistency`.
- Use `requirement_level`: `mandatory`, `signoff_required`, `recommended`.
- Default risk weights should be visible and adjustable: `compliance_exposure 0.30`, `user_impact 0.25`, `diff_surface 0.15`, `stateful_change_risk 0.20`, `regression_confidence 0.10`.
- Always compute a weighted score and map it to `go`, `conditional_go`, or `no_go`.
- Missing rollback evidence, missing signoff owner, unresolved compliance exposure, or absent regression minimums are automatic blockers.
- The checklist must branch by event type so the operator sees only the relevant controls first.
- When the incident is marked as hotfix, the result should be easy to attach to a PR, release ticket, or approval thread.

## Execution workflow / execution workflow
1. Normalize the candidate fix, incident impact, and primary event type.
2. Select the relevant per-type checklist branch and required controls.
3. Score hotfix risk using the weighted matrix and identify hard blockers.
4. Translate the result into a clear `go`, `conditional_go`, or `no_go` recommendation.
5. Emit rollout, regression, signoff, and rollback guardrails for the execution team.

## Dynamic completeness / dynamic completeness
- If the hotfix is only one candidate among several remediation paths, state that explicitly and keep the recommendation conditional.
- If the event type is mixed, keep one primary branch and list secondary checklist add-ons instead of blending everything into one generic list.
- If the patch scope is tiny but touches irreversible data or compliance rules, do not let the low diff size hide the true risk.

## Quality bar / quality bar
A good hotfix risk assessment is short enough to act on during an incident, but strict enough to stop unsafe emergency releases.

## Reference files / reference files
- `references/n310-event-type-branches.md`
- `references/n310-tier-and-criticality-rubrics.md`
- `references/n310-handoff-contract.md`
- `references/hotfix-checklist-per-type.md`
- `references/output-template.md`
- `references/quality-checklist.md`
