# Hotfix Checklist Per Event Type

## compliance
Focus on signoff, audit evidence, blast radius, policy compatibility, and rollback safety.

## performance
Focus on traffic shaping, baseline comparisons, capacity guardrails, canary, and rollback speed.

## availability
Focus on restoration speed, health probes, dependency reachability, rollback, and communications.

## data_consistency
Focus on write protection, reconciliation plan, irreversible data risk, replay behavior, and rollback window.
