---
name: remediation-plan-recommendation
description: generate workflow-aligned remediation plans from 根因定位建议.md, 影响范围分析.md, 告警归因.md, incident constraints, and optional on-call outputs. use when chatgpt works in operations governance / incident response and must produce the n310 修复方案建议.md artifact, compare containment, hotfix, patch release, next regular release, or rollback-first paths, quantify critical/major/minor severity with configurable weights, and prepare hotfix candidates for hotfix-risk-assessment.
---
# remediation-plan-recommendation

## Role / role positioning
This skill aligns to operations governance -> incident response -> 修复方案建议.md. It is the authoritative N310 skill for deciding how the incident should be corrected, not just temporarily contained.

### Boundary
- Own durable-fix option design, tradeoff comparison, and path recommendation.
- Consume incident evidence and on-call actions instead of rediscovering alert context.
- Distinguish temporary containment from durable correction.
- Do not replace `hotfix-risk-assessment` for release gating once the preferred path is `hotfix`.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `stabilize_now`
- `balanced_tradeoff`
- `long_term_fix_alignment`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `根因定位建议.md`
- `影响范围分析.md`
- `告警归因.md`

### optional enhancement inputs
- `值班处置建议.md`
- recent deployment or config-change evidence
- candidate diff scope or patch notes
- rollback capability evidence
- owner map and signoff rules
- regression suite availability and test evidence

## Standalone rule / standalone usage
This skill must still work from one incident brief, one bug cluster, or one RCA summary.

Degradation rules:
- If impact data is partial, keep the option set stable and mark scoring uncertainty.
- If rollbackability is unknown, never assume it is safe; treat the gap as a decision penalty.
- If on-call outputs are absent, infer containment assumptions from the incident evidence and label them.

## Core output contract / core output contract
Default to markdown sections or tables that can be copied into `修复方案建议.md`.

The result must include at least:
- `metadata`
- `incident_summary`
- `severity_quantification`
- `decision_weight_profile`
- `remediation_options[]`
- `selected_path_recommendation`
- `hotfix_trigger_decision`
- `regression_and_validation_expectations`
- `dependencies_and_preconditions`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: remediation_option_design_and_fix_path_tradeoff`
- `stage_position: operations_governance.incident_response.remediation_planning`
- `workflow_node: N310`
- `node_artifact_target: 修复方案建议.md`
- `evidence_profile`
- `tool_collaboration_mode`

Each `remediation_option` must include:
- `fix_id`
- `remediation_path`
- `event_type_branch`
- `objective`
- `immediate_effect`
- `long_term_effect`
- `implementation_scope`
- `blast_radius`
- `rollback_path`
- `criticality_class`
- `decision_inputs`
- `regression_expectation`
- `approvals_needed`
- `recommended_when`
- `not_recommended_when`

## Design rules / design rules
- Use one of these `remediation_path` values: `containment_only`, `hotfix`, `patch_release`, `next_regular_release`, `rollback_first_then_fix`.
- Keep a configurable `decision_weight_profile`; default weights should be visible, not hidden.
- Default weight profile: `regulatory_impact 0.30`, `user_impact 0.25`, `rollbackability 0.20`, `implementation_scope 0.15`, `verification_cost 0.10`.
- Use `criticality_class`: `Critical`, `Major`, `Minor`.
- `Critical` applies when compliance impact is non-none, user impact is >= 10%, irreversible data risk exists, or no safe rollback path exists for an active incident.
- Every recommendation must show both the short-term stabilizing move and the durable fix path.
- If the preferred path is `hotfix`, the handoff to `hotfix-risk-assessment` is mandatory.

## Execution workflow / execution workflow
1. Normalize incident facts, impact, attribution, and current containment state.
2. Quantify criticality and expose the decision-weight profile.
3. Generate multiple remediation paths with explicit tradeoffs.
4. Pick the preferred path and justify why alternatives are weaker.
5. Emit the exact downstream hotfix handoff when emergency release is recommended.

## Dynamic completeness / dynamic completeness
- When evidence is incomplete, prefer multiple scored options over false certainty.
- If the incident is reversible by rollback alone, still document why rollback-first is or is not sufficient.
- If compliance or data safety implications exist, force them into the scoring model even if technical signals look mild.

## Quality bar / quality bar
A good remediation plan recommendation makes tradeoffs explicit, keeps weights auditable, and leaves no ambiguity about whether the next action is containment, rollback, hotfix, patch, or deferred fix.

## Reference files / reference files
- `references/n310-event-type-branches.md`
- `references/n310-tier-and-criticality-rubrics.md`
- `references/n310-handoff-contract.md`
- `references/remediation-decision-matrix.md`
- `references/output-template.md`
- `references/quality-checklist.md`
