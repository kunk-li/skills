---
name: effort-estimation-assistant
description: estimate engineering effort, uncertainty, buffer, calendar impact, and historical calibration from task breakdowns, technical solution notes, architecture outputs, nonfunctional constraints, or mixed planning evidence. use when chatgpt works in technical solution design / task management and must produce the workflow-aligned 工时估算表.csv for n180 before sprint planning, staffing, review coordination, test planning, release preparation, or cross-team commitment.
---
# effort-estimation-assistant

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 任务管理 -> 工时估算表」。

它是 **direct_result** 型技能：目标是把任务、模块或需求范围，转换成可沟通、可校准、可汇总的 **`工时估算表.csv`**，而不是给一个拍脑袋的总人天数。

### Boundary / 边界
- 负责三点估算、置信度、缓冲策略、effort 与 duration 区分、历史校准与项目级汇总。
- 负责把估算假设和主要成本驱动写清楚。
- 不负责重新拆任务；若任务粒度失衡，应回推给 `development-task-breakdown`。
- 不负责完整依赖图、关键路径与资源冲突；这些由 `dependency-identification` 深化。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `quick_estimate`：轻量估算，给核心项的 expected 和大致区间。
- `probabilistic_estimate`：默认模式，要求三点估算与置信度说明。
- `calibrated_estimate`：在 probabilistic 基础上加入历史校准、buffer 透明化与项目级可承诺日期推导。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `模块边界图.md`
- `服务拆分建议.md`
- `数据流图.md`

### 节点内最强输入
- `开发任务拆分表.csv`

### 可选增强输入
- 历史任务估算与实际耗时
- 团队容量、角色构成、日历窗口、外部联调计划
- `并发控制建议.md`
- `性能风险分析.md`
- `安全风险分析.md`
- `需求漏洞清单.csv`

## Standalone rule / 独立使用规则
即使没有完整任务表，只要有方案和模块范围，也可以单独使用。

降级规则：
- 若没有稳定任务清单，只能输出模块级或需求级粗估。
- 顶部必须标明 `readiness: provisional`。
- 必须显式区分 `confirmed / inferred / pending` 的估算对象。
- 缺乏关键依赖或历史对照时，不得伪装成高可信度估算。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.task_management.effort_estimation`
  - `node_artifact_target: 工时估算表.csv`
  - `workflow_node: N180`
  - `evidence_profile`
- `estimate_registry[]`
- `assumption_set[]`
- `buffer_strategy`
- `historical_calibration`
- `project_rollup`
- `confidence_summary`
- `downstream_handoff`
  - `workflow_downstream`: `N190`, `N220`, `N240`, `N270`, `N330`, `N350`
  - `artifact_name: 工时估算表.csv`
- `self_check`

### Required estimate fields / 必填字段
每条估算至少包含：
- `task_id`
- `task_name`
- `estimate_scope`
- `three_point_estimate`
  - `optimistic`
  - `most_likely`
  - `pessimistic`
  - `expected`
  - `std_dev`
- `uncertainty_level`
- `confidence`
- `cost_drivers[]`
- `key_assumptions[]`
- `effort_pd`
- `duration_days`
- `buffer_applied`

## Design rules / 设计规则
### PERT discipline / 三点估算纪律
默认使用 PERT：
- `expected = (O + 4M + P) / 6`
- `std_dev = (P - O) / 6`

不要只给单点数字而不解释区间来源。

### Historical calibration / 历史校准
若有历史数据，必须显式写：
- 相似任务样本
- `calibration_factor`
- 校准前 / 校准后差异

若没有历史数据，必须写 `historical_calibration: unavailable`，不要假装组织已有成熟标定库。

### Buffer transparency / 缓冲透明化
必须分开写：
- `raw_estimate`
- `task_level_buffer`
- `sprint_level_buffer`
- `project_contingency`

不能把 buffer 偷偷揉进 expected 数字里。

### Effort vs duration discipline / 工作量与时长纪律
- `effort_pd` 表示纯投入人天。
- `duration_days` 表示日历上的完成时间，必须考虑等待、评审、联调和资源排队。

### Uncertainty discipline / 不确定性纪律
必须使用以下之一：
- `well_known`
- `familiar`
- `partial`
- `novel`
- `research`

若 `novel` 或 `research` 过多，应显式建议 spike 或先降级承诺。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 确定估算层级：任务级、模块级或需求级。
3. 优先消费 `开发任务拆分表.csv`；若缺失，则从方案中抽取估算对象。
4. 为每个对象生成 `three_point_estimate`、`uncertainty_level` 与 `confidence`。
5. 写出 `cost_drivers[]` 与 `key_assumptions[]`，解释估算来源。
6. 若有历史数据，生成 `historical_calibration` 并调整 expected。
7. 分开计算 `effort_pd` 与 `duration_days`，不要混写。
8. 透明化 buffer，形成项目级 `project_rollup`。
9. 形成面向 N180 标准产物的 **`工时估算表.csv`**。
10. 输出 `downstream_handoff`，供 N190 / N220 / N240 / N270 / N330 / N350 消费。
11. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 任务级明确：覆盖全部关键任务的三点估算。
- 模块级明确：覆盖核心模块与高风险联调项。
- 大型项目：优先覆盖关键路径候选、外部依赖密集项与高不确定项。

## Quality bar / 质量门槛
合格结果应能支撑排期、资源沟通与版本承诺，而不是只提供“看起来像数字”的表面精度。

## Reference files / 参考文件
- `references/output-template.md`
- `references/estimation-techniques.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/n180-integration-map.md`
