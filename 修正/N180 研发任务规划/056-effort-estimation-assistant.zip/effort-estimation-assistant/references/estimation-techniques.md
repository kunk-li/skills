# 估算技术说明

默认推荐 **three-point + analogous** 的组合；在说明里直接点明采用的技术即可。

## 1. Expert Judgment

适用：任务独立、团队经验充足、输入较完整。

风险：容易受个人经验偏差影响。

## 2. Three-point / PERT

适用：存在中等不确定性，需要给出上下界。

做法：至少保留 `best / expected / worst` 三列；需要汇总时再说明加权口径。

## 3. Analogous Estimation

适用：团队有相似历史任务或可比模块。

做法：引用相似任务作为基线，再根据差异调整。

## 4. Parametric Estimation

适用：同类任务很多，例如“每个 API 约 1 pd”。

风险：过度简化时容易低估边界条件。

## 5. Planning Poker / Team Review

适用：多人协作，需要共享认知并对齐假设。

本 skill 不组织会议，但可以提醒用户在高争议任务上采用团队复核。
