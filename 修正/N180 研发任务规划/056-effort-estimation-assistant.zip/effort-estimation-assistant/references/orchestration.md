# 056 编排说明

## 上游优先级

优先复用以下输入：

1. 055 开发任务拆分结果
2. 技术方案分析
3. 模块边界图
4. 数据流图
5. API 清单
6. 表结构与索引变更
7. 非功能需求
8. 待决问题清单

## 与 055 的字段映射

| 055 字段 | 056 字段 | 说明 |
|---|---|---|
| task_id | task_id | 一一对应 |
| task_name | task_name | 名称保持一致 |
| estimate_pd | pd_expected 的输入基线 | 056 可围绕它展开三点估算 |
| priority | confidence / risk_buffer_pd 的参考 | blocker 往往意味着更低 confidence |
| depends_on | cost_drivers / notes | 依赖越重，缓冲通常越大 |

## 与 057 的协同

- 057 给出的关键依赖、外部对象和阻塞风险应进入 `cost_drivers` 或 `notes`。
- 如果 057 标记 `blocking_risk=high`，056 通常不应给 high confidence。
- 若 057 识别出固定联调窗口，056 需要单独说明 `calendar_days` 影响。

## 反向约束

- `estimate_id` 数量通常应小于等于 055 的任务数加上少量汇总或假设行。
- 每个明确的 `task_id` 最好对应恰好 1 条主估算记录。
- Blocked 任务的 `pd_best / pd_expected / pd_worst` 应为 `?`、区间或空值。
- `size_tshirt` 应与 `pd_expected` 大致一致。
