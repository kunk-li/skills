# Output Template: 工时估算表

## 默认交付结构

### 1. 估算范围与 readiness

先说明：

- 当前估算层级：需求 / 模块 / 任务
- readiness：pass / constrained / blocked
- 估算口径：人天、t-shirt size、还是区间

### 2. 全局假设

至少覆盖以下 5 类：

1. 团队规模与角色分配
2. 并行度上限
3. 外部依赖 SLA 或联调窗口
4. 待确认问题何时决策
5. 工作量到日历时间的换算口径

### 3. 主估算表

默认使用以下 13 列：

| 列名 | 含义 |
|---|---|
| estimate_id | 估算 ID，例如 `EST-001` |
| task_id | 对应的 055 任务 ID |
| task_name | 任务名 |
| pd_best | 乐观估时 |
| pd_expected | 最可能估时 |
| pd_worst | 悲观估时 |
| size_tshirt | XS / S / M / L / XL |
| key_assumptions | 关键假设 |
| cost_drivers | 成本驱动因子 |
| risk_buffer_pd | 风险缓冲 |
| confidence | high / medium / low |
| calendar_days | 对应日历时间 |
| notes | 备注 |

### 4. 合计行

每个 wave 或模块可额外给一条汇总行：

- `estimate_id = EST-SUM-WAVE1`
- `task_id = summary`

### 5. 待确认问题

单独列出会显著改变估算的假设，例如：

- 外部接口是否复用
- 数据迁移是否要回刷历史数据
- 联调窗口是否固定

## 计算与映射规则

### Three-point 默认规则

可以采用以下任一表达：

- 直接保留 best / expected / worst 三列
- 需要汇总时，再说明加权公式，例如 `best x 0.2 + expected x 0.6 + worst x 0.2`

### T-shirt 映射

- XS: < 1 pd
- S: 1-2 pd
- M: 2-3 pd
- L: 3-5 pd
- XL: > 5 pd

### Confidence 规则

- high：需求明确、技术熟悉、依赖就绪
- medium：存在部分未知，但范围仍可控
- low：关键依赖未决或输入明显不完整

## 禁止项

- 不要只给 `pd_expected` 单点而没有上下界，除非用户明确只要极简版。
- 不要为 blocked 任务给出伪精确数字。
- 不要把所有任务的 confidence 都填成 high。
- 不要把风险缓冲隐藏到主估值里而不说明。
- 不要把工作量和日历时间混成一个字段。
