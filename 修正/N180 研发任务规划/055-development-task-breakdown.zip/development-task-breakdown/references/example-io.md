# 055 示例输入输出

## 示例输入

用户给出：

- 目标：为 CRM 系统新增“线索去重规则配置”能力
- 已知模块：配置页、去重规则 API、规则表、定时回刷任务
- 约束：本周先完成配置页和后端主链路；数据回刷方案待确认

## 示例输出（节选）

### 前置阻塞项

| blocking_issue | impact_scope | needed_input | suggested_owner |
|---|---|---|---|
| 历史数据回刷策略未定 | wave 2 / 数据任务 | 确认全量回刷还是增量回刷 | 产品 + 后端 |

### 任务清单

| task_id | task_name | task_type | module | wave | sprint | description | acceptance_criteria | estimate_pd | depends_on | owner_role | priority | evidence | mode |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| TK-001 | 新增规则配置表与索引 | db | dedupe-core | 1 | S1 | 创建规则主表与唯一索引 | 建表 SQL 通过评审并在测试库验证 | 1.0 |  | backend | major | 表结构草稿 | confirmed |
| TK-002 | 实现规则配置查询与保存 API | backend | dedupe-api | 1 | S1 | 支持规则列表、保存与校验 | 关键接口通过 5 个用例并写入规则表 | 1.5 | TK-001 | backend | blocker | API 草稿 | confirmed |
| TK-003 | 实现规则配置页表单与校验 | frontend | dedupe-ui | 1 | S1 | 新增配置页与前端表单校验 | 页面可新增、编辑并提示校验错误 | 1.5 | TK-002 | frontend | major | 页面原型 | confirmed |
| TK-004 | 接入规则发布后的联调回归 | integration | dedupe-e2e | 1 | S2 | 前后端联调并验证主流程 | 主流程回归通过且无阻断缺陷 | 1.0 | TK-002;TK-003 | qa | major | 联调清单 | confirmed |
| TK-005 | 设计历史数据回刷任务占位 | backend | dedupe-replay | 2 | S2 | 先定义回刷任务接口与参数 | 形成候选方案待确认 | ? |  | backend | blocker | 待决问题 Q-12 | constrained |

### 关键路径

`TK-001 -> TK-002 -> TK-003 -> TK-004`

说明：主链路受 API 完成与前后端联调窗口限制，最早上线时间由上述 4 个任务决定。
