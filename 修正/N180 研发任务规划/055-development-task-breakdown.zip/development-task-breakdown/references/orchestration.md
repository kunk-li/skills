# 055 编排说明

## 上游优先级

优先复用以下输入，缺失时才降级：

1. 技术方案分析
2. 模块边界图
3. 服务拆分建议
4. 数据流图
5. API 清单
6. 表结构与索引设计
7. 非功能设计（监控、性能、可靠性）
8. 需求漏洞清单 / 待决问题清单

若只有 PRD 或粗略方案，可直接拆分，但必须标记 `inferred`。

## 下游衔接

- **056 工时估算**：每个 `task_id` 对应一条估算记录；055 的 `estimate_pd` 只是输入基线，不替代三点估算。
- **057 依赖识别**：055 的 `depends_on` 需要能展开为依赖边；高优先级 blocker 任务应在 057 中出现。
- **项目管理 / 甘特图**：055 的 wave、sprint、priority 可以直接作为排期输入。

## 字段级映射

### 055 -> 056

| 055 字段 | 056 字段 | 说明 |
|---|---|---|
| task_id | task_id | 一一对应 |
| task_name | task_name | 名称保持一致 |
| estimate_pd | pd_expected 的输入基线 | 056 再扩成 best / expected / worst |
| owner_role | notes / assumptions | 仅作上下文，不强制保留 |
| priority | confidence / risk_buffer 的参考 | blocker 往往意味着更低 confidence |

### 055 -> 057

| 055 字段 | 057 字段 | 说明 |
|---|---|---|
| task_id | from_task / to_task_or_object | 依赖边的锚点 |
| depends_on | 依赖边集合 | 一对多展开 |
| priority | blocking_risk | blocker 往往对应 high |
| evidence | evidence | 保持来源可追踪 |

## 反向约束

### 056 基于 055 的约束

- 估算记录数应接近 055 的任务数，加上少量全局假设行。
- 每个明确的 `task_id` 最好只有一条主估算记录。
- 如果 055 已标记 blocked，056 不应给出确定三点估算。

### 057 基于 055 的约束

- `from_task` 和 `to_task_or_object` 优先引用 055 中已存在的 `task_id`。
- 055 的 `depends_on` 至少应是 057 依赖图的子集。
- 055 中的 blocker 任务应至少在 057 中出现一次。
