# Output Template: 开发任务拆分表

## 默认交付结构

### 1. 前置阻塞项（若存在关键缺口）

必需列：`blocking_issue`、`impact_scope`、`needed_input`、`suggested_owner`。

### 2. 任务清单（主产出）

默认输出 csv 或 markdown 表，使用以下 14 列：

| 列名 | 含义 | 允许值 / 备注 |
|---|---|---|
| task_id | 任务 ID | `TK-001` 这类稳定编号 |
| task_name | 任务名 | 动宾结构，建议 20 字以内 |
| task_type | 类型 | backend / frontend / db / infra / test / config / integration / docs |
| module | 所属模块 | 直接复用上游模块名或模块 ID |
| wave | 所属 wave | 1 / 2 / 3 |
| sprint | 所属 sprint | `S1` / `S2` / `S3` |
| description | 任务描述 | 1-2 句说明范围 |
| acceptance_criteria | 完成标准 | 必须可验证 |
| estimate_pd | 粗估人天 | 0.5-2；不确定时填 `?` |
| depends_on | 依赖任务 | 逗号或分号分隔 |
| owner_role | 负责人角色 | 角色而非姓名 |
| priority | 优先级 | blocker / major / minor |
| evidence | 证据锚点 | 模块 / API / 表 / 方案段落 |
| mode | 模式 | confirmed / constrained / blocked / inferred |

### 3. 依赖链路

使用 ASCII 或 Mermaid 表达关键链路。例如：

```text
TK-001 -> TK-003 -> TK-007
```

### 4. 关键路径

说明：

- 最长依赖链
- 关键链的累计人天或预计时长
- 影响上线的核心原因

### 5. 可并行任务组

按 sprint 或模块分组，列出：

- 并行任务集合
- 并行前提
- 并行上限

### 6. 排期建议

只有在用户给出容量、上线日或成员信息时再输出。至少写明：

- 任务分 wave / sprint 的理由
- 高风险任务是否需要前置
- 是否需要预留联调与测试缓冲

### 7. 风险提示

单列以下对象：

- 高不确定任务
- 跨团队依赖
- 数据准备依赖
- 外部接口依赖

## 额外规则

- Blocked 任务不要给出看似精确的 `estimate_pd`。
- Wave 3 未决任务可以保留占位行，但必须标 `mode=constrained` 或 `blocked`。
- 若用户只给高层方案，可输出候选任务，但必须在 `mode` 或备注中写明 `inferred`。
