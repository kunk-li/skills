# N180 integration map

## Workflow alignment
This skill belongs to N180 in `skills_workflow_v2`.

### N180 node contract
- Inputs: `技术方案分析.md`, `模块边界图.md`, `服务拆分建议.md`, `数据流图.md`
- Outputs:
  - `开发任务拆分表.csv`
  - `工时估算表.csv`
  - `研发依赖清单.csv`
- Downstream nodes:
  - `N190`
  - `N220`
  - `N240`
  - `N270`
  - `N330`
  - `N350`

## Internal handoff inside N180
- `development-task-breakdown` should provide stable `task_id` and `traces_to`.
- `effort-estimation-assistant` should reuse `task_id` and avoid renaming rows.
- `dependency-identification` should anchor dependency edges on `task_id` whenever possible.

## Node-level quality expectations
- Task granularity is explicit.
- Estimates separate effort and duration.
- Dependencies distinguish task edges from resource or external constraints.
- All three artifacts are reusable by downstream implementation, review, testing, release, documentation, and coordination nodes.
