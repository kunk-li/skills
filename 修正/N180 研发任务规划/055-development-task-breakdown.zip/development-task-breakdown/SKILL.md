---
name: development-task-breakdown
description: break technical solution notes, architecture boundaries, api and data outputs, nonfunctional constraints, or mixed implementation plans into workflow-aligned execution tasks. use when chatgpt works in technical solution design / task management and must produce the workflow-aligned 开发任务拆分表.csv for n180 before effort estimation, dependency analysis, code generation, review coordination, test planning, release preparation, or documentation handoff.
---
# development-task-breakdown

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 任务管理 -> 开发任务拆分表」。

它是 **direct_result** 型技能：目标不是泛泛给项目建议，而是把上游技术方案、边界、接口、数据与非功能设计，落成可以被下游直接消费的 **`开发任务拆分表.csv`**。

### Boundary / 边界
- 负责把需求与技术方案拆成可执行任务单元。
- 负责定义任务粒度、任务类型、DoD、追溯关系与 spike 管理。
- 可给出 `estimate_hint_pd` 作为粒度辅助，但不替代正式工时估算；正式三点估算与 buffer 由 `effort-estimation-assistant` 负责。
- 可显式写前置依赖，但不替代关键路径、浮动时间与资源冲突分析；这些由 `dependency-identification` 深化。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `brainstorm_mode`：从方案和需求快速生成候选任务树，适合早期规划。
- `refined_mode`：输出完整任务清单，包含 `task_size_tier`、`task_kind`、`definition_of_done`、`traces_to`；默认模式。
- `jira_export`：在 refined 基础上使用更稳定的 epic / story / task / subtask 结构，方便导入 Jira、Linear 或项目计划工具。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `模块边界图.md`
- `服务拆分建议.md`
- `数据流图.md`

### 可选增强输入
- `接口设计草案.yaml`
- `表结构设计草案.sql`
- `并发控制建议.md`
- `幂等设计建议.md`
- `性能风险分析.md`
- `安全风险分析.md`
- 现有 Epic、里程碑、验收标准、团队容量信息

## Standalone rule / 独立使用规则
即使只拿到技术方案分析或粗粒度设计，也可以单独使用。

降级规则：
- 若缺少模块边界、数据流或接口契约，可先输出候选 WBS。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的任务与追溯关系。
- 无法确认的大任务不可硬拆成看似精确的 Sprint 任务；应转成 spike、占位任务或待确认项。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.task_management.development_task_breakdown`
  - `node_artifact_target: 开发任务拆分表.csv`
  - `workflow_node: N180`
  - `evidence_profile`
- `task_registry[]`
- `granularity_audit`
- `coverage_backtrace`
- `spike_register[]`
- `orphan_items[]`
- `project_breakdown_health`
- `downstream_handoff`
  - `workflow_downstream`: `N190`, `N220`, `N240`, `N270`, `N330`, `N350`
  - `artifact_name: 开发任务拆分表.csv`
- `self_check`

### Required task fields / 必填任务字段
每个任务至少包含：
- `task_id`
- `task_name`
- `task_kind`
- `task_size_tier`
- `estimate_hint_pd`
- `owner_role`
- `definition_of_done`
- `traces_to`
- `depends_on_hint`
- `confidence`
- `mode`

## Design rules / 设计规则
### Task size tier / 粒度分档
必须强制使用以下分档：
- `XS`: `< 0.5 pd`
- `S`: `0.5-2 pd`
- `M`: `2-5 pd`
- `L`: `5-10 pd`
- `XL`: `> 10 pd`

执行规则：
- `M`：强烈建议继续拆分。
- `L`：必须拆分，除非它明确是 milestone / placeholder。
- `XL`：不得作为可执行 Sprint 任务进入最终表。

### Task kind taxonomy / 任务类型矩阵
每个任务必须使用以下类型之一：
- `design`
- `development`
- `refactor`
- `test`
- `integration`
- `infrastructure`
- `documentation`
- `investigation`

### Definition of Done discipline / 完成定义纪律
每个任务都必须包含 DoD。默认至少检查：
- 代码或文档产出完成
- review 通过
- 相关测试补齐或验证通过
- 无 blocker 缺陷
- 文档同步
- 需要的 gate 条件满足

### Trace discipline / 追溯纪律
`traces_to` 至少覆盖这些来源中的相关项：
- `requirements`
- `apis`
- `acs`
- `decisions`
- `nfr_items`

若某条需求、API、AC 或 NFR 没有任何任务覆盖，必须进入 `orphan_items[]`。

### Spike discipline / Spike 纪律
探索型工作必须显式写：
- `is_spike: true`
- `timebox`
- `expected_output`
- `exit_criteria`

Spike 不得伪装成普通开发任务。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 从技术方案、边界、接口、数据流与 N170 约束中抽取交付对象。
3. 先形成粗粒度 WBS，再向下拆到可独立验收的任务。
4. 为每个任务赋予 `task_kind`、`task_size_tier`、`owner_role` 与 `definition_of_done`。
5. 建立 `traces_to`，把任务回指到需求、API、AC、决定项和 NFR。
6. 把未知较高的项转为 spike 或 pending 任务，不伪装成稳定开发项。
7. 运行 `granularity_audit`，检查是否存在过大或过碎任务。
8. 产出 `coverage_backtrace` 与 `orphan_items[]`，确认上游关键对象都被覆盖。
9. 形成面向 N180 标准产物的 **`开发任务拆分表.csv`**。
10. 输出 `downstream_handoff`，供 N190 / N220 / N240 / N270 / N330 / N350 消费。
11. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小型项目：覆盖全部任务、DoD 与追溯关系。
- 中型项目：覆盖全部关键链路，并明确低优先级或延后项。
- 大型项目：优先覆盖核心业务链、关键路径候选、跨团队联调与高风险交付面。

## Quality bar / 质量门槛
合格结果应能直接进入估算、依赖分析与项目排期，而不需要再次解释“这个任务到底在做什么、做到什么算完”。

## Reference files / 参考文件
- `references/output-template.md`
- `references/task-granularity-guide.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/n180-integration-map.md`
