# Output Template: 研发依赖清单

## 默认交付结构

### 1. 识别范围与 readiness

先说明当前覆盖的材料、主要盲区，以及 readiness：pass / constrained / blocked。

### 2. 主依赖表

默认输出以下 14 列：

| 列名 | 含义 | 允许值 / 备注 |
|---|---|---|
| dep_id | 依赖 ID | `DEP-001` |
| dep_type | 依赖类型 | 参考 taxonomy |
| from_task | 来源任务 | task_id、问题 ID 或模块名 |
| to_task_or_object | 目标任务 / 对象 | task_id、外部系统、团队或决策对象 |
| dep_strength | 强度 | strong / medium / weak / environment |
| scope | 范围 | infra / db / backend / frontend / external / architecture / compliance 等 |
| description | 描述 | 一句话说明关系 |
| precondition | 前置条件 | 依赖解除或可推进的条件 |
| blocking_risk | 阻塞风险 | high / medium / low |
| mitigation | 缓解方案 | 具体动作，不写套话 |
| status | 状态 | confirmed / 待解决 / 等待 / 并行 |
| owner | 责任角色 | 角色或团队 |
| evidence | 证据锚点 | 上游方案段落、task_id、API、表 |
| mode | 模式 | confirmed / inferred / constrained / blocked |

### 3. 关键阻塞总览

单独列出：

- `status=待解决`
- 且 `blocking_risk=high`

### 4. 本周必决清单

将需要产品、架构、安全、外部团队在本周决策的问题单列出来，供 PM 或周会使用。

### 5. 并行使能点

单独列出 `parallel_enable` 或能显著释放并行度的依赖，例如：

- 测试环境准备完成
- API 契约冻结
- 共享组件发布完成

## 最低覆盖要求

- 如果结果只覆盖 2-3 类依赖，通常不算完整。
- 默认至少覆盖 8 类依赖，实在不足时要解释原因。
- 不能只识别技术串行关系，忽略 PRD、合规、环境和决策型依赖。
