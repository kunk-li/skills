# 057 编排说明

## 上游优先级

优先复用以下输入：

1. 055 开发任务拆分结果
2. 技术方案分析
3. 数据流图
4. 模块边界图
5. API 清单与契约草稿
6. 表结构与数据迁移方案
7. 非功能与环境准备说明
8. 待决问题清单

## 与 055 的字段映射

| 055 字段 | 057 字段 | 说明 |
|---|---|---|
| task_id | from_task / to_task_or_object | 依赖边锚点 |
| depends_on | 依赖关系集合 | 可拆成一对多边 |
| priority | blocking_risk | blocker 往往对应 high |
| evidence | evidence | 保持来源可追踪 |

## 与 056 的协同

- 057 识别到的高风险依赖应进入 056 的 `cost_drivers` 或 `notes`。
- 若某依赖固定占用外部窗口，056 需要把它反映到 `calendar_days`。
- 056 若将任务标为 low confidence，通常能在 057 中找到未决依赖或高风险边。

## 反向约束

- `from_task` 和 `to_task_or_object` 优先引用 055 中存在的 `task_id`，除非对象是外部系统或决策实体。
- 055 中 `depends_on` 至少应是 057 依赖图的子集。
- 055 中 priority=blocker 的任务，至少应在 057 的依赖表中出现一次。
