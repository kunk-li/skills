# 057 示例输入输出

## 示例输入

基于 CRM 线索去重配置能力的方案与 055 任务清单，用户希望识别 wave 1 / wave 2 的依赖关系与关键阻塞。

## 示例输出（节选）

### 主依赖表

| dep_id | dep_type | from_task | to_task_or_object | dep_strength | scope | description | precondition | blocking_risk | mitigation | status | owner | evidence | mode |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| DEP-001 | task_sequence | TK-002 | TK-003 | strong | backend/frontend | 配置页依赖 API 契约与保存接口完成 | API 字段和错误码冻结 | high | 先冻结契约并提供 mock | confirmed | backend + frontend | API 草稿 | confirmed |
| DEP-002 | env_dependency | TK-004 | 测试环境账号与回归数据 | environment | external | 联调回归依赖测试环境账号和基础数据 | 测试环境账号开通且样例数据导入完成 | high | 提前申请账号并准备最小数据集 | 待解决 | qa / infra | 联调清单 | constrained |
| DEP-003 | data_decision | TK-005 | 历史数据回刷策略 | medium | data | 回刷任务占位依赖产品确认全量或增量方案 | 产品确认回刷口径 | high | 本周在方案评审会上定稿 | 待解决 | 产品 + backend | Q-12 | constrained |
| DEP-004 | parallel_enable | TK-001 | TK-002;TK-003 | weak | db/backend/frontend | 规则表与索引完成后，后端和前端可并行推进 | 建表 SQL 通过评审并在测试库验证 | low | 优先完成表结构评审 | 并行 | backend | 表结构草稿 | confirmed |

### 关键阻塞总览

- DEP-001：API 契约未冻结会阻断前端开发与联调。
- DEP-002：测试环境账号和数据未准备会推迟联调窗口。
- DEP-003：回刷策略未定会阻断 wave 2 数据任务。

### 本周必决清单

1. 冻结规则配置 API 契约与错误码。
2. 确认测试环境账号申请人和最小样例数据准备人。
3. 决定历史数据回刷采用全量还是增量策略。
