# 16 类依赖目录

默认优先从以下目录中选用最贴切的类型；必要时可补充子类，但不要随意发明含糊标签。

1. `task_sequence`：任务间严格串行
2. `data_dependency`：依赖数据准备、回刷、迁移或同步
3. `platform_enablement`：平台、中间件、基础设施前置
4. `cross_team`：跨团队配合、接口排期、评审窗口
5. `architecture_decision`：架构方案待决
6. `security_decision`：安全评审、鉴权策略、脱敏方案待决
7. `data_decision`：口径、主数据、数据保留策略待决
8. `prd_gap`：需求缺口、规则缺失、业务口径不明
9. `env_dependency`：测试、预发、网络、密钥、账号等环境准备
10. `test_dependency`：测试数据、测试工具、回归资源
11. `monitoring`：日志、指标、告警、可观测性准备
12. `documentation`：设计文档、接口文档、操作手册缺失
13. `compliance`：法务、隐私、审计、合规签字
14. `ux_dependency`：设计稿、交互稿、文案确认
15. `knowledge`：信息待确认、历史实现未知、领域知识空白
16. `parallel_enable`：能够释放并行度的正向使能点

## 使用规则

- 尽量使用现成类型，不要把所有问题都塞进 `task_sequence`。
- `parallel_enable` 是正向依赖，不是阻塞项；但它应单独列出，帮助团队找并行机会。
- 若最终覆盖类型少于 8 类，必须解释是材料过少还是场景确实简单。
