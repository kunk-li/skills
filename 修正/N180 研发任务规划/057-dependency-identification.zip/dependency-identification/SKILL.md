---
name: dependency-identification
description: identify execution, resource, external-team, environment, decision, and approval dependencies from technical solution notes, architecture outputs, task breakdowns, estimates, or mixed planning materials. use when chatgpt works in technical solution design / task management and must produce the workflow-aligned 研发依赖清单.csv for n180 before implementation scheduling, review coordination, test planning, release preparation, staffing decisions, or project risk tracking.
---
# dependency-identification

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 任务管理 -> 研发依赖清单」。

它是 **direct_result** 型技能：目标是把任务、资源、外部团队与环境约束，组织成可消费的 **`研发依赖清单.csv`**，并自动指出关键路径、浮动时间与高风险阻塞。

### Boundary / 边界
- 负责识别任务依赖、资源依赖、外部依赖、环境依赖、决策依赖与审批依赖。
- 负责判断依赖是否必要、是否可避免，并识别关键路径与资源冲突。
- 不负责重新拆任务；任务对象本身优先来自 `development-task-breakdown`。
- 不负责正式工时估算；工期计算需要尽量复用 `effort-estimation-assistant` 的 duration 输入。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `lightweight`：仅输出任务到任务的主依赖关系。
- `full`：默认模式，覆盖任务、资源、外部团队、环境，并计算关键路径与浮动时间。
- `risk_mode`：聚焦高风险依赖、关键路径上的外部瓶颈与资源冲突。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `模块边界图.md`
- `服务拆分建议.md`
- `数据流图.md`

### 节点内最强输入
- `开发任务拆分表.csv`
- `工时估算表.csv`

### 可选增强输入
- 资源池信息、团队 availability、环境就绪计划
- 外部团队 SLA、审批流、合规窗口
- 发布节奏、联调窗口、关键里程碑

## Standalone rule / 独立使用规则
即使只有技术方案与高层任务，也可以单独使用。

降级规则：
- 若没有标准任务表，可先输出模块级或里程碑级依赖图。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的依赖边。
- 若缺少 duration 或资源信息，不得伪造精确关键路径总时长，只能输出 provisional path。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.task_management.dependency_identification`
  - `node_artifact_target: 研发依赖清单.csv`
  - `workflow_node: N180`
  - `evidence_profile`
- `dependency_registry[]`
- `critical_path_analysis`
- `float_analysis[]`
- `resource_assignment_conflicts[]`
- `avoidable_dependencies[]`
- `blocker_dependencies[]`
- `downstream_handoff`
  - `workflow_downstream`: `N190`, `N220`, `N240`, `N270`, `N330`, `N350`
  - `artifact_name: 研发依赖清单.csv`
- `self_check`

### Required dependency fields / 必填字段
每条依赖至少包含：
- `dep_id`
- `from_task`
- `to_task`
- `dependency_kind`
- `blocking_strength`
- `avoidability`
- `owner`
- `prerequisite`
- `mitigation`
- `confidence`
- `mode`

## Design rules / 设计规则
### Dependency kind taxonomy / 依赖类型分类
必须使用以下之一：
- `task_output`
- `resource_constraint`
- `knowledge_transfer`
- `external_team`
- `environmental`
- `decision`
- `approval`

### Avoidability discipline / 可避免性纪律
每条依赖必须标为以下之一：
- `necessary`
- `designed`
- `scheduling`
- `artificial`

对 `designed / scheduling / artificial` 必须给出去耦或并行化建议。

### Critical path discipline / 关键路径纪律
在 `full` 或 `risk_mode` 下，必须输出：
- `critical_path`
- `critical_tasks`
- `total_duration_days`
- `near_critical_paths`

若缺少 duration 数据，必须明确标记 `provisional_critical_path`。

### Float discipline / 浮动时间纪律
在可计算时，为每个主要任务提供：
- `total_float`
- `free_float`

### Resource discipline / 资源约束纪律
当资源池已知时，必须额外识别：
- 单资源过载
- 专家瓶颈
- 环境排他冲突
- 外部团队时窗冲突

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 优先消费 `开发任务拆分表.csv` 与 `工时估算表.csv`；若缺失，则从方案推导粗粒度交付对象。
3. 先对依赖分类，再判断阻塞强度与 owner。
4. 为每条依赖赋予 `avoidability`，识别可消除或可并行化的边。
5. 若 duration 已知，自动计算 `critical_path_analysis` 与 `float_analysis[]`。
6. 若资源信息已知，生成 `resource_assignment_conflicts[]`。
7. 汇总 `blocker_dependencies[]` 与 `avoidable_dependencies[]`。
8. 形成面向 N180 标准产物的 **`研发依赖清单.csv`**。
9. 输出 `downstream_handoff`，供 N190 / N220 / N240 / N270 / N330 / N350 消费。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小型项目：覆盖所有显性前置依赖。
- 中型项目：覆盖全部关键路径候选、外部依赖与资源瓶颈。
- 大型项目：优先覆盖关键链、近关键链、审批与环境时窗冲突。

## Quality bar / 质量门槛
合格结果应能直接支撑排期、资源调度与风险沟通，而不需要再做一次“哪些依赖最危险”的人工重算。

## Reference files / 参考文件
- `references/output-template.md`
- `references/dependency-taxonomy.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/n180-integration-map.md`
