# Common Failure Modes

## F-042-01: 只有一个方案
Fix by providing at least two candidates, and three in comparison mode.

## F-042-02: 没有解释为什么拆 / 不拆
Fix by assigning explicit `decomposition_driver` values to each candidate.

## F-042-03: 只写收益，不写代价
Fix by requiring `service_cost_analysis` for every serious candidate.

## F-042-04: 忽略团队现实
Fix by adding `team_alignment` and checking ownership feasibility.

## F-042-05: 把 shared library 和独立服务混为一谈
Fix by explicitly comparing `shared_library` / `local_module` / `future_service`.

## F-042-06: phase recommendation 没有 trigger
Fix by adding concrete signals, metrics, or organizational preconditions.

## F-042-07: 没有 041 却假装边界已确定
Fix by generating a provisional baseline module catalog and lowering confidence.

## F-042-08: 拆分后形成 distributed monolith
Fix by calling out synchronous cascades, shared-db coupling, or excessive cross-service transactions.
