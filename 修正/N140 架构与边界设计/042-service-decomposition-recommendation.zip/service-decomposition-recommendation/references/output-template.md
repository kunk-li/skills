# Output Template: Service Decomposition Recommendation

本模板用于输出“服务分解建议”。默认结构如下，可按上下文适配，但核心字段不要缺。

## 1. Objective
- 当前要回答的服务拆分问题
- selected mode（assessment / comparison / planning）
- 分析范围 / 不覆盖范围
- 当前状态（single deployable unit / modular monolith / existing services）

## 2. Evidence Profile
| 证据类型 | 是否具备 | 用途 | 可信度 |
|---|---|---|---|
| 041 边界分析 |  |  |  |
| PRD / 业务说明 |  |  |  |
| 架构/部署图 |  |  |  |
| API / 事件 / 数据流 |  |  |  |
| 团队 / ownership |  |  |  |
| 历史变更 / 容量 / 事故 |  |  |  |

## 3. Confirmed Facts
| 来源 | 已确认事实 |

## 4. Baseline Modules
### 4.1 Module Catalog
若有 041，继承其模块清单；若无，则在这里生成 provisional baseline。

| module_id | 模块 | 当前形态 | confidence | 说明 |

### 4.2 Anti-split Constraints Inherited or Derived
| constraint | why | affected_modules |

## 5. Candidate Options
### 5.1 Candidate Summary
| candidate_id | candidate_style | owned_modules | primary_driver | fit_for_current_stage |

### 5.2 Candidate Detail (repeat for each serious candidate)
- ASCII deployment diagram
- Benefits
- Costs
- Best-fit scenario
- Why now / why not now

### 5.3 Decision Matrix
| 维度 | Candidate A | Candidate B | Candidate C |
至少覆盖：开发速度、运维成本、故障隔离、独立扩展、事务复杂度、团队并行度、共享治理难度、适合当前阶段。

## 6. Decomposition Drivers
| candidate_id | primary_driver | secondary_drivers | evidence | validation method |

## 7. Service Cost Analysis
### 7.1 By candidate
| candidate_id | deployment | development | operational | distributed_complexity | overall_cost_signal |

### 7.2 Notable distributed risks
| risk | affected_candidate | why_it_matters | mitigation |

## 8. Team Alignment
| candidate_id | owning_team_model | load_signal | org_precondition | risk |

## 9. Communication Paths
| 场景 | from | to | 建议方式 | why |

## 10. Shared Components Governance
| capability | recommendation | version_policy | breaking_change_policy | release_ownership |

## 11. Recommendation and Anti-recommendation
### 11.1 Recommended candidate
- 推荐原因
- 当前阶段收益
- 主要前提条件

### 11.2 Not recommended now
- 不推荐原因
- 何时重审

### 11.3 Optional architecture_fitness_score
如使用，必须明确其为启发式比较指标。

## 12. Evolution Roadmap
| phase | target_state | incremental_value | trigger | rollback_or_hold_condition |

## 13. Unclear Items
| # | 问题 | 影响 | 建议补充证据 / owner |

## 14. Suggested Next Step
| 下游动作 | 可直接消费的输入 | 启动条件 |

## 15. Self-Check
- 是否区分了 confirmed / inferred / pending
- 是否解释了 why split / why not split
- 是否给了代价、团队与治理
- 是否显式给了 anti-split warnings
- 是否给了 roadmap 或明确说明本轮不覆盖
