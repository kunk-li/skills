# Checklist

## 核心契约
- [ ] 输出顶部写明 selected mode 与 readiness/provisional 状态
- [ ] 若无 041，已生成 baseline module catalog，并标明 confirmed / inferred / pending
- [ ] 至少有 2 个可比较候选；comparison mode 下至少 3 个
- [ ] 推荐候选与不推荐候选都已显式标注

## 驱动力与代价
- [ ] 每个候选都写了 `decomposition_driver`
- [ ] 每个候选都写了 benefit 和 cost，不是只有优点
- [ ] `service_cost_analysis` 已覆盖 deployment / development / operational / distributed_complexity
- [ ] 若 cost 明显高于 benefit，已给出不拆或暂缓拆的结论

## 团队与治理
- [ ] `team_alignment` 已说明 owning_team、team_size、负担与风险
- [ ] `shared_components_governance` 已区分 shared_library / local_module / future_service
- [ ] 未错误地下沉业务规则或流程编排为 shared library

## 组合协同
- [ ] 若有 041，模块清单、anti-split constraints、coupling inventory 已被消费
- [ ] communication paths 与 boundary constraints 没有互相冲突
- [ ] evolution roadmap 与 team reality 保持一致

## 风险与反模式
- [ ] 已显式写出 anti-split warnings
- [ ] 已扫描至少主要反模式：distributed_monolith / shared_db / chatty_service / synchronous_cascade
- [ ] phase / roadmap 包含 trigger，不是“未来看情况”

## 违规检测
- [ ] 没有把 provisional 边界伪装成 confirmed
- [ ] 没有把模块边界与服务拆分混为一谈
- [ ] 没有在证据不足时给出过强结论
