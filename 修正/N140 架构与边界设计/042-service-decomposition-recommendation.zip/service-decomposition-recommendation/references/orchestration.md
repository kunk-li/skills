# Orchestration

## Typical upstream inputs
优先读取：
1. `module-boundary-identification` 输出
2. PRD / 技术方案分析 / 架构说明
3. 现有服务清单、部署图、依赖图、ownership 信息
4. API / 数据流 / 事务链路 / 历史变更

## What this skill adds
- 候选服务拓扑
- decomposition drivers
- service cost analysis
- team alignment
- anti-split warnings
- shared governance
- evolution roadmap

## 041 -> 042 field mapping
| 041 输出 | 042 消费方式 | 用途 |
|---|---|---|
| `module_catalog` | baseline modules | 建立候选服务归属范围 |
| `module_scale` | candidate granularity | 判断按 bounded context、component 或 service 为基础 |
| `coupling_inventory` | communication / cost input | 判断跨服务调用与 distributed complexity |
| `shared_component_candidates` | shared governance input | 决定保留 shared 还是升级为服务 |
| `co_change_hints` | merge/split hints | 判断哪些边界当前应保持一起演进 |
| `anti-split constraints` | anti-split warnings | 防止拆分破坏关键边界 |
| `boundary_metrics` | fitness comparison input | 作为候选比较的辅助指标 |

## Downstream handoff
- API 设计：消费推荐候选、服务归属与 communication paths
- 数据设计：消费 data ownership / shared-data 风险 / transaction hints
- 路线图规划：消费 evolution roadmap 与 trigger matrix
- ADR 编写：组合边界图、服务拓扑、代价与路线

## Execution order
优先顺序为 041 → 042。
若直接运行 042，也必须先在文中构造 provisional baseline modules，而不是跳过边界分析。
