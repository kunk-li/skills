# Decomposition Drivers

## D1 business_domain
适用：业务语义和生命周期明显独立。
检验：职责、语言、状态边界是否清晰。

## D2 scalability
适用：某部分负载、吞吐或扩缩容需求明显独立。
检验：独立扩容是否真的减少成本或瓶颈。

## D3 availability
适用：关键路径需要独立故障隔离。
检验：拆分后是否降低 blast radius，而不是只增加网络 hop。

## D4 compliance
适用：审计、数据隔离、权限隔离有强约束。
检验：是否必须独立 ownership、存储、访问控制或变更轨迹。

## D5 reusability
适用：能力跨多个业务域重复使用。
检验：复用是否稳定且不把业务逻辑误下沉。

## D6 team_ownership
适用：团队需要独立节奏、独立责任边界。
检验：团队是否真的存在且长期维护该服务。

## D7 technology_diversity
适用：子系统需要不同技术栈或运行模型。
检验：技术差异是否真实必要，而非偏好驱动。

## D8 deployment_cadence
适用：某部分发布节奏明显快于其他部分。
检验：拆分后能否真正减少联动发布与回归成本。

## Warning
不要把 driver 当作结论。driver 只是“为什么值得考虑拆分”，仍需结合 cost、team、governance 和 anti-pattern 检查。
