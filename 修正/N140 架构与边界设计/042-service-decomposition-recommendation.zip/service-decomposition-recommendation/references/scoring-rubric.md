# Scoring Rubric

## 1 - Too shallow
- 只有一个方案或一句结论
- 没有 driver、cost、team alignment
- 没有 anti-split warnings

## 2 - Usable but unstable
- 有多个候选，但缺少代价、团队或治理信息
- 能说出推荐，但 why now / why not now 不充分
- roadmap 或 trigger 不具体

## 3 - Review-ready
- 候选、driver、cost、team、communication、governance、roadmap 基本齐全
- 推荐 / 不推荐明确
- 可用于架构评审和下游 API / data ownership 讨论

## 4 - Reusable architecture asset
- 不同输入模式下都能稳定降级
- 独立使用与 041 组合使用都保持一致口径
- 能明确回答“为什么现在是 2 个服务而不是 1 个或 5 个”
- shared governance、团队现实、分布式代价被系统化纳入判断

Minimum acceptable score: 3
