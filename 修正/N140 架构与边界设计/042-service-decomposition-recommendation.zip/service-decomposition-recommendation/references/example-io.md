# Example Input / Output

## Example input
A legacy platform includes identity verification, approval workflows, compliance checks, audit logging, reporting, and shared contract libraries. Available evidence includes a PRD summary, a module boundary analysis, an API list, and a service ownership list.

## Example output sketch
- Selected mode: comparison
- Baseline modules: identity, approval, compliance, audit, reporting, shared-contract, platform-core
- Candidate A: modular monolith with stronger local boundaries
- Candidate B: domain services for identity / approval-compliance / audit-reporting platform
- Candidate C: finer-grained services with higher distributed cost
- Drivers: compliance for audit, reusability for identity, business_domain for approval/compliance split discussion
- Recommended: Candidate B for current team size and change cadence
- Not recommended now: Candidate C due to cross-service transaction risk and team overload
- Shared governance: dto/error contracts stay shared library; audit remains service due to compliance isolation
- Roadmap: keep reporting local now, split only after query load and ownership divergence rise
