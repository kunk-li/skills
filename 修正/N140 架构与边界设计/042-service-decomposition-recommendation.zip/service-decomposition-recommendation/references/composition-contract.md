# Composition Contract

## Goal
让 `service-decomposition-recommendation` 单独可用，但与 `module-boundary-identification` 组合时更强。

## Required handoff fields from 041
优先消费：
- `module_catalog`
- `module_scale`
- `coupling_inventory`
- `shared_component_candidates`
- `co_change_hints`
- `anti-split constraints`
- `boundary_metrics`

## What 042 must add
在 041 之上继续补：
- `decomposition_driver`
- `service_cost_analysis`
- `team_alignment`
- `shared_components_governance`
- `evolution_roadmap`

## Combined workflow
1. 041 收敛边界、反向边界、耦合与 shared candidates
2. 042 基于这些边界构造服务候选并比较 trade-off
3. 组合后可整理为 ADR，至少包含：
   - baseline boundary map
   - candidate service topology
   - drivers and anti-split warnings
   - cost and team fit
   - roadmap and governance

## Combined quality rule
如果 041 仍是 provisional 或 confidence 偏低，042 必须同步降低结论强度，不能给出比 041 更“确定”的推荐。
