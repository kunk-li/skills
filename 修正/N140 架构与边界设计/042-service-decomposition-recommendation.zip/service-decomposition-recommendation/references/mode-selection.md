# Mode Selection

## Use assessment mode when
- 团队主要想判断当前是否值得拆分
- 更关心 yes/no + principal trade-offs，而不是完整迁移路线
- 输入证据有限，但足够做现状评估

## Use comparison mode when
- 需要准备架构评审或方案对比
- 团队想看保守 / 中度 / 激进多候选
- 当前最重要的是看权衡，而不是立刻开工

## Use planning mode when
- 已经有较明确推荐，需要阶段化落地
- 团队关心 next phase、trigger、rollback or hold condition
- 需要把拆分路径与组织、运维、治理一起规划

## Escalation rule
若输入既包含边界分析，又包含团队、部署、事务、shared governance 等证据，优先使用 `planning mode`；
若只有 PRD 或概念设计，优先使用 `comparison mode`，避免给出过强的执行性结论。
