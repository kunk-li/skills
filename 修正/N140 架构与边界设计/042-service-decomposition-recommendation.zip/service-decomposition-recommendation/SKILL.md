---
name: service-decomposition-recommendation
description: recommend how modules, bounded contexts, or components should be grouped into deployable services using decomposition drivers, cost analysis, team alignment, communication paths, and staged evolution guidance. use when chatgpt works in technical solution design / architecture split and must produce a workflow-aligned 服务拆分建议.md for n140 after boundary analysis and before task planning or architecture review.
---
# service-decomposition-recommendation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 架构拆分 -> 服务拆分建议」。

它是 **direct_result** 型技能：目标是把“要不要拆、怎么拆、何时拆”落成可交付的 **`服务拆分建议.md`**，供 N140 节点输出并交给 N180 使用。

### Boundary / 边界
- 负责决定哪些边界应该组合成部署单元，哪些值得拆成独立服务。
- 负责评估驱动力、收益、代价、团队适配度与演进路径。
- 不负责重新定义模块边界本身；该职责优先由 `module-boundary-identification` 负责。
- 不进入 API 细化、数据建模、代码实现或测试落地。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `assessment`：只判断现状是否值得拆、现在拆不拆。
- `comparison`：给出保守 / 中度 / 激进等多候选对比。
- `planning`：在已有目标态的前提下，输出阶段化演进路线。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`：N140 节点标准输入

### 节点内优先增强输入
- `模块边界图.md` 或 041 的结构化输出：N140 节点内前置 handoff

### 可选增强输入
- PRD、业务说明、现有服务清单、架构图、部署图、依赖图
- API / 事件 / 数据流清单
- 表归属、shared data 现状、事务链路
- 团队结构、ownership、发布节奏、on-call 责任、历史事故

## Standalone rule / 独立使用规则
即使没有 041 输出，也可以单独使用。

降级规则：
- 若无模块边界输入，必须先生成 provisional baseline module catalog。
- 顶部必须标明 `readiness: provisional`。
- 服务归属、通信方式、shared governance 都要区分 `confirmed / inferred / pending`。
- 不得假装模块边界已经被正式确认。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.architecture_split.service_decomposition_design`
  - `node_artifact_target: 服务拆分建议.md`
  - `workflow_node: N140`
  - `evidence_profile`
- `baseline_module_catalog[]` 或继承的 `module_catalog[]`
- `service_candidates[]`
  - `candidate_id`
  - `candidate_style`
  - `owned_modules`
  - `decomposition_driver`
  - `benefits`
  - `costs`
  - `fit_for_current_stage`
- `service_cost_analysis[]`
  - `deployment`
  - `development`
  - `operational`
  - `distributed_complexity`
- `team_alignment[]`
- `communication_paths[]`
- `anti_split_warnings[]`
- `shared_components_governance[]`
- `evolution_roadmap[]`
- `downstream_handoff`
  - `primary_workflow_consumer: N180`
  - `artifact_name: 服务拆分建议.md`
  - `consumable_sections`: `service_candidates`, `service_cost_analysis`, `team_alignment`, `communication_paths`, `evolution_roadmap`
- `self_check`

## Design rules / 设计规则
### Decomposition driver discipline / 分解驱动力纪律
每个推荐候选至少标 1 个主驱动力，必要时再标次驱动力：
- `D1 business_domain`
- `D2 scalability`
- `D3 availability`
- `D4 compliance`
- `D5 reusability`
- `D6 team_ownership`
- `D7 technology_diversity`
- `D8 deployment_cadence`

不能只写“建议拆分”，必须说明**因为什么驱动拆分**。

### Cost discipline / 代价纪律
每新增一个服务，至少评估 4 类代价：
1. `deployment`
2. `development`
3. `operational`
4. `distributed_complexity`

若 `cost >> benefit`，必须明确给出“建议不拆”或“暂缓拆”。

### Team alignment rule / 团队对齐规则
- 每个候选应写 `owning_team`、`team_size`、`other_services_owned_by_same_team`。
- 若一个团队需要长期维护超过 3 个高复杂服务，应提示过载风险。
- 若一个服务需要多团队共同长期拥有，应提示权责不清。
- 若推荐候选依赖尚不存在的团队结构，必须写组织前提或落地风险。

### Shared component governance / 共享组件治理
输出中必须显式区分：
- `shared_library`
- `local_module`
- `future_service`

默认不要把核心业务规则、编排流、状态机、独立审计 / 权限 / 可用性能力做成 shared library。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 优先消费 `技术方案分析.md` 与 041 的边界结果。
3. 若无 041，先生成 provisional baseline module catalog。
4. 构造保守 / 中度 / 激进等候选，或按 assessment / planning 深度输出。
5. 为每个候选标注 `decomposition_driver`、服务归属、通信方式、关键收益。
6. 对每个候选补充 `service_cost_analysis` 与 `team_alignment`。
7. 比较事务复杂度、调用链、shared governance 与演进门槛。
8. 生成阶段化 `evolution_roadmap` 或“不拆”建议。
9. 形成面向 N140 标准交付物的 **`服务拆分建议.md`**。
10. 输出 `downstream_handoff`，供 N180 消费。
11. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小系统：覆盖全部候选与关键权衡
- 中等系统：至少覆盖保守 / 中度 / 激进 3 档
- 大型系统：聚焦核心服务域、关键共享争议、阶段化路线与触发信号

不要为了显得“微服务化”而硬拆，也不要为了保守而回避明显的合规或扩展问题。

## Quality bar / 质量门槛
合格结果应能直接支撑 N140 节点产物归档，并被 N180 任务规划直接消费。

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/decomposition-drivers.md`
- `references/common-failure-modes.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/decomposition-drivers.md`
- `references/mode-selection.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
