# Mode Selection

## Use standalone-static mode when
- 只有 PRD、需求文档、会议纪要、架构说明
- 目标是先得到一版可评审的边界图
- 当前更关心职责与交接，而不是精确耦合数字

## Use evidence-enriched mode when
- 有代码目录、依赖关系、接口表、数据库归属、事件流、提交历史
- 希望把 coupling inventory、co-change hints 做得更客观
- 需要为后续服务拆分提供更强证据

## Use upstream-assisted mode when
- 已有结构化需求分析、技术方案分析、现有边界草图
- 当前重点是继承事实并补足边界细节，而不是重新发明模块集合

## Escalation rule
若输入中既有上游分析，也有代码与历史证据，优先按 `evidence-enriched mode` 输出，但 confirmed facts 仍以已确认上游结论为准。
