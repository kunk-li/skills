# Composition Contract

## Goal
让 `module-boundary-identification` 单独可用，但与 `service-decomposition-recommendation` 组合时更强。

## Required handoff fields
当下游要做服务拆分时，041 最少应输出：
- `module_catalog`
- `module_scale`
- `coupling_inventory`
- `shared_component_candidates`
- `co_change_hints`
- `anti-split constraints`

## Combined workflow
1. 041 先收敛“边界是什么”
2. 042 再回答“边界如何组合为服务”
3. 若两者连续使用，最终可整理为 Architecture ADR，至少包含：
   - 边界图
   - 候选服务拓扑
   - 驱动力与代价
   - 演进路线
   - shared governance

## Combined quality rule
若 041 的边界置信度低，042 必须同步降低推荐力度，不能比 041 更乐观。
