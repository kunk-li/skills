# Checklist

## 核心契约
- [ ] 输出顶部写明 selected mode、主分析 scale、readiness/provisional 状态
- [ ] `module_scale` 已为每个模块显式标注
- [ ] 若存在多层级对象，已给出 parent-child / contains 关系
- [ ] confirmed / inferred / pending 已分层

## 边界完整度
- [ ] 每个模块都有 IN / OUT，且不是只有一句摘要
- [ ] `boundary_metrics` 已给出，并标明 metric_source
- [ ] `coupling_inventory` 已覆盖关键跨模块交互
- [ ] `necessary` / `designed` / `shared` 已区分
- [ ] 所有 `designed` coupling 都有 elimination_path
- [ ] 所有 `shared` coupling 都有 governance_hint

## 可独立使用
- [ ] 即使没有上游 skill，也能说明证据来源与置信度
- [ ] 若没有代码/历史数据，已显式说明哪些指标是 heuristic
- [ ] 若没有历史变更记录，`co_change_hints` 已降级为 hypothesis 或说明 unavailable

## 共享能力判断
- [ ] 已明确 shared component candidate 与 future service 的区别
- [ ] 没有把业务策略或流程编排错误地下沉为 shared library

## 组合协同
- [ ] 已输出 decomposition-ready handoff
- [ ] anti-split constraints 可直接供 042 或等价服务拆分步骤消费
- [ ] handoff points 可直接供 API / data-flow / table design 使用

## 违规检测
- [ ] 没有把服务拆分结论提前替代 042
- [ ] 没有把模糊边界伪装成 confirmed
- [ ] 没有为了“看起来完整”虚构精确指标
