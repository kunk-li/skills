# Common Failure Modes

## F-041-01: module scale 混用
Fix by forcing `module_scale` for every module and separating parent-child relations.

## F-041-02: 只写承担，不写不承担
Fix by requiring at least one explicit OUT rule for every module.

## F-041-03: coupling 只有名字，没有分类
Fix by classifying every critical coupling as necessary / designed / shared.

## F-041-04: designed coupling 没有改造路径
Fix by adding `elimination_path` for all designed coupling.

## F-041-05: 共享库与独立服务边界模糊
Fix by explicitly comparing shared_library / local_module / future_service.

## F-041-06: 没有历史证据却伪造精确 co-change 数字
Fix by using hypothesis or qualitative change-locality hints.

## F-041-07: 提前输出服务拆分结论
Fix by stopping at decomposition-ready handoff and leaving grouping decisions to 042.
