# Metrics and Taxonomy

## Module scale taxonomy
- `code_package`: 代码目录或 package 级
- `bounded_context`: 业务语义与语言边界级
- `component`: 独立职责组件，可同进程或独立进程
- `service`: 独立部署单元
- `system`: 多服务组成的业务系统

## Coupling kinds
- `sync_rpc`: 同步接口调用
- `async_event`: 异步事件 / 消息
- `shared_data`: 共享表、共享缓存、共享 key-space
- `shared_library`: 共享代码依赖
- `shared_config`: 共享配置 / 规则源
- `shared_runtime`: 共享运行时或基础资源

## Volume taxonomy
- `low`: 偶发或边缘场景
- `medium`: 常规业务链路存在，但非核心热点
- `high`: 高频主链路或高影响依赖

## Necessity taxonomy
- `necessary`: 业务本质决定，难以消除
- `designed`: 由当前架构或实现选择引入，可改造
- `shared`: 由共性下沉带来，需要治理而非简单消除

## Boundary metrics
可以使用 0-10、low/medium/high 或混合形式，但必须说明来源。

### cohesion
模块内部职责是否围绕同一业务目标、数据对象或变化原因。

### coupling_afferent (Ca)
其他模块对当前模块的依赖压力。

### coupling_efferent (Ce)
当前模块对其他模块的依赖压力。

### stability
可用 `Ce / (Ca + Ce)` 的直觉版本，也可给定性档位。
- `stable`: 更像基础设施或稳定平台能力
- `balanced`: 兼具供给与消费关系
- `unstable`: 更像前台业务能力，依赖外部较多

## Co-change guidance
- > 70% 或“几乎总是一起改”：边界可疑
- 30% - 70%：需要结合业务判断
- < 30%：边界通常较健康

没有真实变更历史时，不要伪造百分比；改用 hypothesis。
