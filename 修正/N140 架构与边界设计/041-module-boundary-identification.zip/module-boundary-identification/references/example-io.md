# Example Input / Output

## Example input
A legacy platform has approval flows, identity verification, compliance checks, audit logging, and reporting. Available evidence includes a PRD summary, current service list, API list, and a basic dependency diagram.

## Example output sketch
- Selected mode: evidence-enriched
- Primary analysis scale: bounded_context
- Module catalog: identity, approval, compliance, audit, reporting, platform-core
- Coupling inventory distinguishes necessary vs designed dependencies
- Shared candidates: error-contract, dto-schema, observability-kit
- Anti-split constraints: audit keeps immutable log ownership; approval does not own identity lifecycle
- Decomposition-ready handoff: approval + compliance should be evaluated separately, reporting may stay local at current stage
