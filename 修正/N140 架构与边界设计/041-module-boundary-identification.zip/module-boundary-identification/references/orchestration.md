# Orchestration

## Typical upstream inputs
优先读取：
1. 结构化需求分析 / 技术方案分析 / PRD
2. 现有架构图、服务清单、模块说明
3. 代码结构、依赖图、历史变更、接口/表归属

## What this skill adds
- 统一后的 module scale
- 模块边界与反向边界
- coupling inventory
- shared component candidates
- co-change hints
- decomposition-ready handoff

## 041 -> 042 field mapping
| 041 输出 | 042 消费方式 | 用途 |
|---|---|---|
| `module_catalog` | baseline modules / owned modules | 建立候选服务的归属范围 |
| `module_scale` | candidate granularity | 判断以 bounded context、component 还是 service 为拆分基准 |
| `boundary_metrics` | boundary health input | 辅助计算 candidate fit |
| `coupling_inventory` | communication / cost analysis | 判断跨服务调用、事务复杂度、shared risk |
| `shared_component_candidates` | shared governance | 决定保留 shared library 还是升级成独立服务 |
| `co_change_hints` | evolution and merge/split hints | 判断边界是否应合并或保持拆分 |
| `anti-split constraints` | anti-split warnings | 避免拆分破坏核心边界 |

## Downstream handoff
- `service-decomposition-recommendation`：消费模块清单、耦合、shared candidates、anti-split constraints
- API 设计：消费 handoff points 与关键交互图
- 数据流 / 表设计：消费边界、shared_data coupling 与 ownership hints

## Execution order
优先先做 041，再做 042。
若直接做 042，也应先在文内生成一版 provisional module catalog，而不是跳过边界分析。
