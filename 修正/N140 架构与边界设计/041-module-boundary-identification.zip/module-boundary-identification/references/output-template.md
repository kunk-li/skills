# Output Template: Boundary Analysis Report

本模板用于输出“模块边界识别”结果。默认结构如下，可按上下文适配，但核心字段不要缺。

## 1. Objective
- 当前分析目标
- 分析范围 / 不覆盖范围
- 本次主分析层级（`module_scale`）
- selected mode（standalone-static / evidence-enriched / upstream-assisted）

## 2. Evidence Profile
| 证据类型 | 是否具备 | 用途 | 可信度 |
|---|---|---|---|
| 需求/PRD |  |  |  |
| 架构说明 |  |  |  |
| 代码结构/依赖 |  |  |  |
| 历史变更 |  |  |  |
| 运行链路/API/表归属 |  |  |  |
| 团队/ownership 信息 |  |  |  |

## 3. Confirmed Facts
| 来源 | 已确认事实 |

## 4. Scale Model and Layered View
### 4.1 Module Scale Catalog
| module_id | 名称 | module_scale | parent/contains | confidence |

### 4.2 Layered / Context Map
- 至少给 1 张 ASCII 图
- 若同时出现多个 scale，明确层级关系

## 5. Boundary Analysis
### 5.1 Module Ledger
| module_id | 模块 | 承担（IN） | 不承担（OUT） | owner_hint | confidence |

### 5.2 Boundary Metrics
| module_id | cohesion | coupling_afferent | coupling_efferent | stability | instability_tier | metric_source |

### 5.3 Coupling Inventory
| from_module | to_module | coupling_kind | volume | necessity | rationale | elimination_path / governance_hint |

要求：
- `necessity = necessary` 时，说明为什么不可避免
- `necessity = designed` 时，必须给 elimination_path
- `necessity = shared` 时，必须给 governance_hint

### 5.4 Shared Component Candidates
| candidate | 推荐形态（shared_library / local_module / future_service） | rationale | governance_hint |

### 5.5 Co-change Hints
| modules | co_change_rate_or_signal | observation | implication |

若无历史证据，可改为：
| modules | hypothesis | 可能一起变化的原因 | implication |

## 6. Handoff and Interaction Map
### 6.1 Handoff Points
| from | to | 交接内容 | 形式 | criticality |

### 6.2 Key Interaction Diagram
- 至少 1 张 ASCII 图
- 优先覆盖高影响链路、跨域边界、共享组件争议点

## 7. Risks and Anti-patterns
### 7.1 Boundary Risks
| risk_id | 风险 | 来源 | 严重度 | 缓解 |

### 7.2 Anti-pattern Scan
| anti_pattern | evidence | why_it_matters | recommended_fix |

## 8. Decomposition-ready Handoff
本章是给 `service-decomposition-recommendation` 或等价下游直接消费的字段。

### 8.1 Bounded Context / Component Candidates
| candidate | why_it_is_separate | current_scale | split_sensitivity |

### 8.2 Anti-split Constraints
| constraint | why | affected_modules |

### 8.3 Shared vs Service Decision Hints
| capability | current_recommendation | why_not_the_other_option |

## 9. Unclear Items
| # | 问题 | 影响 | 建议补充证据 / owner |

## 10. Suggested Next Step
| 下游动作 | 可以直接使用的输入 | 启动条件 |

## 11. Self-Check
- 是否显式声明了主分析 scale
- 是否把 confirmed / inferred / pending 分开
- 是否给出了 coupling inventory
- 是否区分了 necessary / designed / shared
- 是否给了 decomposition-ready handoff
