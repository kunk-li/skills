# Scoring Rubric

## 1 - Too shallow
- 模块只有名字，没有 scale、边界和 handoff
- 没有 coupling inventory
- 没有区分事实与推断

## 2 - Usable but unstable
- 有模块职责，但 scale 混用或 OUT 不明确
- 有 handoff，但没有把 designed vs necessary coupling 分开
- 共享能力与独立服务的判断不稳定

## 3 - Review-ready
- scale 明确，模块 ledger 完整
- coupling inventory、boundary metrics、handoff、风险齐全
- confirmed / inferred / pending 清晰
- 可独立复用，也可供服务拆分直接消费

## 4 - Reusable architecture asset
- 不同输入模式下都能稳定降级
- shared library / local module / future service 的判断有一致规则
- decomposition-ready handoff 稳定，可跨项目复用
- 能支持架构评审对“为什么是这个边界”提出挑战

Minimum acceptable score: 3
