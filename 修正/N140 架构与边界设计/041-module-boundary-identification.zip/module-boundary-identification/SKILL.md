---
name: module-boundary-identification
description: identify module boundaries, module scale, responsibilities, out-of-scope areas, coupling inventory, and shared-component candidates from technical solution notes, architecture evidence, legacy-system structure, code layout, or upstream analysis. use when chatgpt works in technical solution design / architecture split and must produce a reusable boundary map for n140 before service decomposition, task planning, or architecture review. especially useful when the team needs a deliverable-aligned 模块边界图.md rather than loose discussion.
---
# module-boundary-identification

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 架构拆分 -> 模块边界识别」。

它是 **direct_result** 型技能：目标不是泛泛讨论“模块怎么拆”，而是产出可直接沉淀为 **`模块边界图.md`** 的结构化边界结果，供 N140 节点交付与 N180 下游消费。

### Boundary / 边界
- 负责识别模块、限界上下文、组件或服务候选的边界。
- 负责说明每个模块的 in-scope / out-of-scope、耦合、交接点、共享组件争议。
- 不负责决定最终服务部署组合；该职责交给 `service-decomposition-recommendation`。
- 不进入 API 细化、数据流细化、代码实现、测试执行或发布落地。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `standalone-static`：只有 PRD、技术方案、系统说明、服务清单等文本证据时使用。
- `evidence-enriched`：同时具备代码结构、依赖关系、接口清单、表归属、运行链路、提交历史等证据时使用。
- `upstream-assisted`：已有结构化上游结果或节点内前置分析结果时使用。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`：N140 节点在 skills_workflow 中的标准输入

### 可选增强输入
- PRD、业务说明、现有系统说明、遗留架构材料
- 代码结构、依赖图、现有模块 / 服务清单
- git log、历史变更记录、incident 记录
- API 清单、数据库归属、事件流、团队 ownership 信息

## Standalone rule / 独立使用规则
即使没有上游结构化输出，也可以单独使用。

降级规则：
- 若只有原始技术方案文字，允许反推出 provisional module baseline。
- 顶部必须标明 `readiness: provisional`。
- 任何模块、指标、耦合都必须区分 `confirmed / inferred / pending`。
- 没有真实证据时，不得伪装成精确测量；应标 `metric_source: heuristic`。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.architecture_split.module_boundary_design`
  - `node_artifact_target: 模块边界图.md`
  - `workflow_node: N140`
  - `evidence_profile`
- `module_catalog[]`
  - `module_id`
  - `name`
  - `module_scale`
  - `responsibilities`
  - `out_of_scope`
  - `owner_hint`
  - `confidence`
- `boundary_metrics[]`
  - `cohesion`
  - `coupling_afferent`
  - `coupling_efferent`
  - `stability`
  - `instability_tier`
  - `metric_source`
- `coupling_inventory[]`
  - `from_module`
  - `to_module`
  - `coupling_kind`
  - `volume`
  - `necessity`
  - `rationale`
  - `elimination_path` or `governance_hint`
- `co_change_hints[]`
- `shared_component_candidates[]`
- `handoff_points[]`
- `boundary_risks[]`
- `downstream_handoff`
  - `primary_workflow_consumer: N180`
  - `artifact_name: 模块边界图.md`
  - `consumable_sections`: `module_catalog`, `handoff_points`, `coupling_inventory`, `shared_component_candidates`, `boundary_risks`
- `self_check`

## Design rules / 设计规则
### Module scale discipline / 模块层级纪律
“module” 不固定等于代码包或微服务。每个模块必须显式填写 `module_scale`，仅允许：
- `code_package`
- `bounded_context`
- `component`
- `service`
- `system`

若同时出现多个 scale：
- 先建立 parent-child 或 contains 关系
- 再声明主分析层级
- 不要把不同 scale 的对象混写成同一层结论

### Evidence-aware scoring / 证据感知评分
- 有真实代码、依赖图、提交历史时，优先给 observed 指标。
- 没有真实证据时，可用 low / medium / high 或 0-10 启发式评分，但必须标 `metric_source: heuristic`。
- 没有数据支撑时，宁可给区间或定性档位，也不要伪装成精确数字。

### Boundary discipline / 边界纪律
- 每个模块至少有 1 条清晰的 OUT 规则；复杂模块建议 2-3 条。
- 每条 coupling 必须分类为 `necessary` / `designed` / `shared`。
- 对 `designed` 必须给 `elimination_path`；对 `shared` 必须给 `governance_hint`。
- 不能因为未来可能拆服务，就提前把边界结论写成服务级实现设计。
- 只输出“供下游考虑”的 service handoff，不替代 042 的职责。

### Shared library decision rule / shared library 判断规则
默认不要把以下内容做成 shared library：
- 核心业务规则
- 可变流程编排、状态机
- 跨域写操作
- 需要独立权限、独立审计、独立可用性的能力

只有同时满足以下条件时，才优先考虑 shared library：
- 跨多个模块重复使用
- 语义稳定，变更频率低
- 不持有业务状态
- 不隐含跨模块控制流

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 以 `技术方案分析.md` 或可用证据为起点抽取候选模块。
3. 统一 `module_scale`，必要时建立 parent-child 关系。
4. 为每个模块写清 IN / OUT，不得只写职责不写反向边界。
5. 盘点 handoff 与依赖，形成 `coupling_inventory`。
6. 标记 `necessary / designed / shared` 并补齐治理或消解建议。
7. 在有历史证据时补 `co_change_hints`，没有则写 hypothesis。
8. 识别 `shared_component_candidates` 与边界风险。
9. 生成面向 N140 标准交付物的 **`模块边界图.md`** 结构。
10. 输出 `downstream_handoff`，供 N180 消费。
11. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
输出深度随系统规模调整：
- 1-3 个模块：覆盖全部关键 handoff 与 coupling
- 4-8 个模块：覆盖全部高影响 handoff，并至少覆盖中高频 coupling
- 8 个以上模块：至少覆盖核心业务链路、跨团队边界、共享组件争议点

不要为了凑条数制造模块，也不要因为系统大就只给口号。

## Quality bar / 质量门槛
合格结果应能直接支撑 N140 节点产物归档，并被 N180 直接消费，而不需要重新解释。

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/metrics-taxonomy.md`
- `references/common-failure-modes.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/metrics-taxonomy.md`
- `references/mode-selection.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
