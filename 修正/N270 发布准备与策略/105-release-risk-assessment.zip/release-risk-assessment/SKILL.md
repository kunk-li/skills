---
name: release-risk-assessment
description: generate workflow-aligned release risk assessments from release manifests, diff risk evidence, gate results, and deployment scope. use when chatgpt works in release & delivery / release preparation and must produce the n270 发布风险评估.md artifact, risk scoring, mitigation planning, or cross-release release risk tracking.
---
# release-risk-assessment

## Role / role positioning
This skill aligns to release & delivery -> release preparation -> 发布风险评估.md. It delivers the authoritative workflow-aligned artifact for N270.

### Boundary
- Own release risk identification scoring and mitigation.
- Consume upstream N260 gate evidence instead of re-running quality gate logic.
- Keep direct downstream use in N280, N290, and N360 explicit.
- Use the shared `release_manifest` as the preferred cross-skill truth source whenever multiple N270 artifacts coexist.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_risk_scan`
- `comprehensive`
- `comparative`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### optional enhancement inputs
- release manifest
- historical release risks
- defect severity trends
- rollback plan
- canary strategy
- dependency changes
- migration notes

## Standalone rule / standalone usage
This skill must still work on one release candidate, one service release, one hotfix, or one release decision slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If evidence is partial, separate confirmed facts from assumptions and open risks.
- Keep release decisions conservative when critical release readiness, rollback, or canary evidence is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize the referenced output-template file.

The result must include at least:
- `metadata`
- `risk_summary`
- `risk_register[]`
- `risk_scoring_model`
- `mitigation_playbook`
- `cross_release_tracking`
- `decision_rationale`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: release_risk_identification_scoring_and_mitigation`
- `stage_position: release_and_delivery.release_preparation.release_risk_assessment`
- `workflow_node: N270`
- `node_artifact_target: 发布风险评估.md`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Keep release risk distinct from already-materialized defects; risks are forward-looking and mitigation-driven.
- Score each risk with standardized likelihood, impact, score, and level fields.
- Every high or critical risk must have executable mitigation actions and clear owners.
- Track risk status across releases so repeated patterns become organizational learning instead of isolated notes.

## Execution workflow / execution workflow
1. Collect release scope, gate posture, diff risk inputs, and historical comparable releases.
2. Scan the standard risk categories and score each one with likelihood, impact, and resulting level.
3. Attach mitigation actions, release-manifest links, and ownership to each active risk.
4. Emit downstream handoff for N280, N290, and N360 so release coordination can act on active risks.

## Dynamic completeness / dynamic completeness
- If evidence is sparse, keep categories stable but lower confidence and surface unknowns directly.
- If a risk is already mitigated, keep it in history instead of hiding it; the release story still matters.
- If comparative mode is selected, show how this release differs from similar past releases, not just the current top-five risks.

## Quality bar / quality bar
A good release risk assessment turns vague concern into scored, owned, mitigated, and trackable release decision inputs.

## Reference files / reference files
- `references/risk-assessment-rubric.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
