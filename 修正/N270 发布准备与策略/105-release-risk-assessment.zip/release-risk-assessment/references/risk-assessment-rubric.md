# release risk model

## Risk categories
- `code_change_risk`
- `dependency_risk`
- `data_migration_risk`
- `performance_risk`
- `security_risk`
- `compliance_risk`
- `availability_risk`
- `user_experience_risk`
- `integration_risk`
- `operational_risk`
- `rollback_risk`
- `business_risk`

## Required fields
- `risk_id`
- `category`
- `likelihood`
- `impact`
- `risk_score`
- `risk_level`
- `mitigation_actions[]`
- `mitigation_status`
- `release_manifest_links[]`
- `owner`
