# Output Template: 发布风险评估

## Suggested columns
| risk_id | category | likelihood | impact | risk_score | risk_level | owner | mitigation_actions | status | release_link |
|---|---|---|---|---|---|---|---|---|---|
