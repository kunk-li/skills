---
name: release-note-generation
description: generate workflow-aligned release notes from release manifests, change inventories, pr descriptions, commit history, and gate evidence. use when chatgpt works in release & delivery / release preparation and must produce the n270 发布说明.md artifact, multi-audience release communication, breaking change sections, or linked release messaging.
---
# release-note-generation

## Role / role positioning
This skill aligns to release & delivery -> release preparation -> 发布说明.md. It delivers the authoritative workflow-aligned artifact for N270.

### Boundary
- Own release communication and audience view generation.
- Consume upstream N260 gate evidence instead of re-running quality gate logic.
- Keep direct downstream use in N280, N290, and N360 explicit.
- Use the shared `release_manifest` as the preferred cross-skill truth source whenever multiple N270 artifacts coexist.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `from_commits_only`
- `curated_mode`
- `multi_format`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### optional enhancement inputs
- git log or tag range
- commit messages
- linked PRs and tickets
- change inventory
- release manifest
- risk register
- canary strategy
- rollback plan

## Standalone rule / standalone usage
This skill must still work on one release candidate, one service release, one hotfix, or one release decision slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If evidence is partial, separate confirmed facts from assumptions and open risks.
- Keep release decisions conservative when critical release readiness, rollback, or canary evidence is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize the referenced output-template file.

The result must include at least:
- `metadata`
- `release_identity`
- `technical_view`
- `user_view`
- `operator_view`
- `compliance_view`
- `breaking_changes_prominent`
- `change_links[]`
- `migration_guidance`
- `known_issues_or_open_risks`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: release_communication_and_audience_view_generation`
- `stage_position: release_and_delivery.release_preparation.release_note_generation`
- `workflow_node: N270`
- `node_artifact_target: 发布说明.md`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Separate technical, user, operator, and compliance views instead of mixing audiences.
- Elevate breaking changes into a dedicated high-visibility section with before/after, migration path, and rollback reference.
- Prefer commit and PR extraction for traceability, but rewrite overly technical commit phrasing into audience-appropriate release wording.
- Every listed change must link back to PRs, commits, or ticket identifiers.

## Execution workflow / execution workflow
1. Collect the normalized change inventory and release metadata from the shared manifest or upstream artifacts.
2. Separate changes by audience and identify breaking, migration, operational, and compliance-relevant items.
3. Generate multi-view release notes with explicit links, migration guidance, and high-visibility breaking change coverage.
4. Call out remaining known issues, open risks, and downstream operator actions.

## Dynamic completeness / dynamic completeness
- If traceability sources are incomplete, keep the release note structure stable and mark missing links explicitly.
- If no breaking changes exist, emit a clear `breaking_changes_prominent: none` section instead of omitting it.
- If only technical evidence exists, keep user-facing language conservative and do not invent product promises.

## Quality bar / quality bar
A good release note lets developers, users, operators, and compliance readers each find the information they need without reinterpreting internal release artifacts.

## Reference files / reference files
- `references/release-note-template.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
