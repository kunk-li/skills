# Output Template: 发布说明

## Required sections
- release_identity
- audience_views
- breaking_changes_prominent
- migration_guidance
- linked_changes
- open_risks
- downstream_handoff
