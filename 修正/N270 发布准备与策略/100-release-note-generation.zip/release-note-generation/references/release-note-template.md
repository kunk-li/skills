# release note template

## Required release note views
- `technical_view`
- `user_view`
- `operator_view`
- `compliance_view`

## Mandatory high-visibility sections
- `version_and_window`
- `headline_summary`
- `breaking_changes_prominent`
- `change_links`
- `migration_guidance`
- `known_issues_or_open_risks`
- `downstream_handoff`

## Rules
- Always separate audience views instead of blending all content into one stream.
- Every breaking change must include before/after, migration path, and rollback reference.
- Every listed change must point back to commits, PRs, or ticket IDs.
