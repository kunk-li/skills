---
name: canary-release-recommendation
description: generate workflow-aligned canary release strategies from release manifests, release risks, gate evidence, and deployment constraints. use when chatgpt works in release & delivery / release preparation and must produce the n270 灰度发布建议.md artifact, cohort-based rollout strategy, promotion metric thresholds, or canary rollback triggers.
---
# canary-release-recommendation

## Role / role positioning
This skill aligns to release & delivery -> release preparation -> 灰度发布建议.md. It delivers the authoritative workflow-aligned artifact for N270.

### Boundary
- Own canary rollout strategy and promotion control.
- Consume upstream N260 gate evidence instead of re-running quality gate logic.
- Keep direct downstream use in N280, N290, and N360 explicit.
- Use the shared `release_manifest` as the preferred cross-skill truth source whenever multiple N270 artifacts coexist.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `simple_canary`
- `advanced_canary`
- `shadow_first`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### optional enhancement inputs
- release manifest
- risk register
- service SLOs
- observability baseline
- traffic segmentation data
- feature flags
- rollback plan

## Standalone rule / standalone usage
This skill must still work on one release candidate, one service release, one hotfix, or one release decision slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If evidence is partial, separate confirmed facts from assumptions and open risks.
- Keep release decisions conservative when critical release readiness, rollback, or canary evidence is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize the referenced output-template file.

The result must include at least:
- `metadata`
- `canary_summary`
- `canary_pattern`
- `cohort_strategy`
- `promotion_metrics[]`
- `promotion_automation`
- `rollback_triggers[]`
- `stage_plan[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: canary_rollout_strategy_and_promotion_control`
- `stage_position: release_and_delivery.release_preparation.canary_release_recommendation`
- `workflow_node: N270`
- `node_artifact_target: 灰度发布建议.md`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Choose a canary pattern explicitly: linear, conservative, aggressive, cohort_based, or region_based.
- Express go/no-go rules as a machine-readable metrics matrix, not only prose.
- Separate auto-promote, manual-review, and auto-halt conditions clearly.
- Always tie canary design back to rollback triggers and release risk posture.

## Execution workflow / execution workflow
1. Collect release scope, blast-radius concerns, baseline metrics, and rollback readiness.
2. Choose the rollout pattern and cohort strategy that fit release risk and business exposure.
3. Define stage-by-stage promotion metrics, observation windows, automation level, and halt conditions.
4. Emit canary guidance that N280 can operationalize and N290 can validate after deployment.

## Dynamic completeness / dynamic completeness
- If observability thresholds are incomplete, default promotion to manual review and state what is missing.
- If release risk is high, bias toward conservative or shadow-first rollout patterns.
- If rollout is region-based or cohort-based, say why that segmentation contains blast radius better than simple traffic percentage.

## Quality bar / quality bar
A good canary recommendation makes rollout shape, cohort choice, metric thresholds, promotion logic, and rollback triggers precise enough to execute without subjective interpretation.

## Reference files / reference files
- `references/canary-stage-patterns.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
