# Output Template: 灰度发布建议

## Required sections
- canary_summary
- stage_plan
- cohort_strategy
- promotion_metrics
- rollback_triggers
- promotion_automation
- downstream_handoff
