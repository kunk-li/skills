# canary patterns and metrics matrix

## Supported patterns
- `linear`
- `conservative`
- `aggressive`
- `cohort_based`
- `region_based`

## Promotion metrics
Represent thresholds as machine-readable rows:
- `metric_name`
- `baseline_source`
- `promote_if`
- `manual_review_if`
- `halt_if`
- `observation_window`
- `minimum_sample_requirement`

## Trigger rules
- Hard rollback triggers must be executable and unambiguous.
- If thresholds are qualitative only, mark `promotion_automation` as `review_gate`.
