# rollback phase model

## Phase ladder
- `phase_1_feature_flag`: fastest containment path for gated functionality
- `phase_2_image_rollback`: application image rollback with compatibility check
- `phase_3_ddl_rollback`: schema rollback with DBA approval and dry-run evidence
- `phase_4_disaster_recovery`: backup restore or DR cutover for severe incidents

## Evidence rule
Every phase must declare:
- `dry_run_evidence`
- `rollback_time_window`
- `owner`
- `approval_requirement`
- `data_compatibility_assumption`

## Hard rule
Phase 3 and Phase 4 must not be presented as ready if dry-run evidence is missing.
