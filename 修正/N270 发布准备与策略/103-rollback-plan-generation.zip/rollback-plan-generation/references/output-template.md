# Output Template: 回滚预案

## Required sections
- rollback_summary
- rollback_decision_tree
- rollback_phases
- dry_run_evidence
- rollback_time_windows
- data_rollback_strategy
- downstream_handoff
