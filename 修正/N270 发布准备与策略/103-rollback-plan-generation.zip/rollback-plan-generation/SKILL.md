---
name: rollback-plan-generation
description: generate workflow-aligned rollback plans from release manifests, gate evidence, risk assessments, and deployment scope. use when chatgpt works in release & delivery / release preparation and must produce the n270 回滚预案.md artifact, release rollback phase planning, dry-run evidence requirements, or multi-service rollback coordination.
---
# rollback-plan-generation

## Role / role positioning
This skill aligns to release & delivery -> release preparation -> 回滚预案.md. It delivers the authoritative workflow-aligned artifact for N270.

### Boundary
- Own rollback path design and rehearsal readiness.
- Consume upstream N260 gate evidence instead of re-running quality gate logic.
- Keep direct downstream use in N280, N290, and N360 explicit.
- Use the shared `release_manifest` as the preferred cross-skill truth source whenever multiple N270 artifacts coexist.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `simple_rollback`
- `full_spectrum`
- `rehearsal_coach`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### optional enhancement inputs
- release manifest
- deployment topology
- migration plan
- service compatibility map
- backup policy
- dry-run records
- risk register

## Standalone rule / standalone usage
This skill must still work on one release candidate, one service release, one hotfix, or one release decision slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If evidence is partial, separate confirmed facts from assumptions and open risks.
- Keep release decisions conservative when critical release readiness, rollback, or canary evidence is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize the referenced output-template file.

The result must include at least:
- `metadata`
- `rollback_summary`
- `rollback_phases[]`
- `rollback_decision_tree`
- `dry_run_evidence[]`
- `rollback_time_windows[]`
- `multi_service_coordination`
- `data_rollback_strategy`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: rollback_path_design_and_rehearsal_readiness`
- `stage_position: release_and_delivery.release_preparation.rollback_plan_generation`
- `workflow_node: N270`
- `node_artifact_target: 回滚预案.md`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Always separate feature-flag, image, DDL, and disaster-recovery rollback phases.
- Treat dry-run evidence as mandatory for Phase 3 and Phase 4 readiness.
- Make rollback time windows explicit so teams know when rollback is still viable versus when forward-fix is safer.
- Represent data rollback realistically; do not pretend append-only or state-machine data can always be reversed cleanly.

## Execution workflow / execution workflow
1. Collect release scope, migration detail, compatibility assumptions, and risk posture.
2. Draft the rollback phase ladder with prerequisites, ownership, approval gates, and execution estimates.
3. Bind every phase to dry-run evidence, time-window validity, and service/data compatibility assumptions.
4. Emit downstream handoff for N280 and N290, especially where deployment or validation steps depend on rollback readiness.

## Dynamic completeness / dynamic completeness
- If no data migration exists, keep schema rollback minimal but still show why Phase 3 is low relevance.
- If dry-run evidence is missing, preserve the phase structure and mark readiness as blocked rather than hiding the gap.
- If the system is multi-service, include compatibility sequencing even when only one service changed materially.

## Quality bar / quality bar
A good rollback plan makes it obvious what rollback path exists, how quickly it can execute, what evidence proves it is real, and when rollback becomes less safe than forward repair.

## Reference files / reference files
- `references/rollback-plan-phases.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
