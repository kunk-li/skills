---
name: release-checklist-generation
description: generate workflow-aligned release execution checklists from release manifests, gate decisions, pr descriptions, and release policies. use when chatgpt works in release & delivery / release preparation and must produce the n270 发版检查清单.csv artifact, timeline-aware execution steps, release owner signoff items, or automation coverage for a release.
---
# release-checklist-generation

## Role / role positioning
This skill aligns to release & delivery -> release preparation -> 发版检查清单.csv. It delivers the authoritative workflow-aligned artifact for N270.

### Boundary
- Own release execution readiness and checklist state management.
- Consume upstream N260 gate evidence instead of re-running quality gate logic.
- Keep direct downstream use in N280, N290, and N360 explicit.
- Use the shared `release_manifest` as the preferred cross-skill truth source whenever multiple N270 artifacts coexist.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_release`
- `enterprise_release`
- `continuous_deployment`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### optional enhancement inputs
- release manifest
- release calendar
- artifact registry info
- branch/tag policy
- signoff matrix
- canary strategy
- rollback plan
- communication plan

## Standalone rule / standalone usage
This skill must still work on one release candidate, one service release, one hotfix, or one release decision slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If evidence is partial, separate confirmed facts from assumptions and open risks.
- Keep release decisions conservative when critical release readiness, rollback, or canary evidence is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize the referenced output-template file.

The result must include at least:
- `metadata`
- `release_identity`
- `checklist_summary`
- `release_timeline`
- `release_checklist_state[]`
- `signoff_matrix[]`
- `automation_coverage`
- `blocked_items[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: release_execution_readiness_and_checklist_state_management`
- `stage_position: release_and_delivery.release_preparation.release_checklist_generation`
- `workflow_node: N270`
- `node_artifact_target: 发版检查清单.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Position this checklist as release execution readiness, not as a duplicate of the broader N260 pre-launch checklist.
- Assign every item a timeline marker, owner, evidence expectation, and requirement level.
- Persist checklist state per release so blocked, waived, and skipped items are explicit and reviewable.
- Differentiate mandatory, strongly recommended, recommended, and optional items clearly.

## Execution workflow / execution workflow
1. Normalize release execution steps from the manifest, timeline, branch/versioning plan, and signoff requirements.
2. Assign every item a status model, owner, timing window, evidence requirement, and automation level.
3. Separate blocked items and waived items from completed items so release readiness is machine-readable.
4. Emit downstream handoff for N280, N290, and N360, especially where execution state still depends on other teams.

## Dynamic completeness / dynamic completeness
- If a release is small, reduce breadth but keep timing, owner, evidence, and requirement fields stable.
- If automation exists for an item, show it instead of restating manual instructions only.
- If a mandatory item is not satisfied, highlight it as a release blocker instead of burying it in notes.

## Quality bar / quality bar
A good release checklist makes it obvious what must happen, who owns it, when it must happen, what evidence proves completion, and what still blocks the release.

## Reference files / reference files
- `references/release-checklist-categories.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
