# Output Template: 发版检查清单

## Suggested columns
| checklist_id | category | time_window | requirement_level | status | owner | automation | evidence_ref | blocker | next_action |
|---|---|---|---|---|---|---|---|---|---|
