# release checklist execution model

## Category intent
`release-checklist-generation` owns release execution readiness, not broad pre-launch governance.

Suggested categories:
- `version_and_branching`
- `artifact_and_signature`
- `announcement_and_channel`
- `release_window_and_staffing`
- `monitoring_markers`
- `canary_execution_readiness`
- `rollback_confirmation`
- `stakeholder_communication`

## Timeline markers
Use standardized timing markers:
- `T-14d`
- `T-7d`
- `T-3d`
- `T-1d`
- `T-0`
- `T+1h`
- `T+24h`
- `T+7d`
