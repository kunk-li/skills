# readiness inheritance

Readiness hints should inherit from upstream N260 gate status.

Recommended interpretation:
- `green`: gate pass, blockers closed, release evidence mostly complete
- `amber`: conditional-go or known mitigation actions still open
- `red`: blocker present, rollback not validated, or canary/risk evidence insufficient
