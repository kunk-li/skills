# change summary impact model

## Positioning
`change-summary-generation` is the internal decision-support view for releases.
It should be more technical, quantitative, and risk-aware than the outward-facing release note.

## Mandatory per-change elements
- `change_id`
- `title`
- `technical_scope`
- `users_affected`
- `modules_touched[]`
- `tests_affected[]`
- `migration_required`
- `backward_compatible`
- `team_effort`
- `risk_assessment`
