# real examples

Example signals worth highlighting:
- release contains a DB migration and a new config flag
- canary is limited to internal users first because business blast radius is high
- rollback is image-safe for 24h only because old binaries cannot read new long-lived data after that
