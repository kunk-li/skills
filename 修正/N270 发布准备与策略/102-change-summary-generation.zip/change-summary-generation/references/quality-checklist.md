# quality checklist

A strong N270 artifact:
- is explicitly tied to the official N270 output name
- references the shared `release_manifest`
- names blockers, mitigations, and remaining unknowns directly
- avoids copying raw gate data without interpreting release consequences
- makes downstream use in N280, N290, and N360 obvious
