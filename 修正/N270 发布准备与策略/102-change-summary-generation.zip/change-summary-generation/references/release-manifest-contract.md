# release_manifest contract

Use a stable shared structure across all N270 skills.

## Minimum keys
- `version`
- `release_train`
- `target_release_window`
- `change_inventory[]`
- `quality_gate_snapshot`
- `release_checklist_state[]`
- `rollback_assets[]`
- `canary_strategy`
- `risk_register[]`
- `release_links`

## Change inventory row
| field | meaning |
|---|---|
| change_id | stable identifier for the release change |
| title | short change label |
| source_refs | linked commits, PRs, tickets, or tasks |
| scope | module or business area |
| change_type | feat / fix / perf / refactor / docs / chore / ops |
| breaking_flag | yes / no |
| migration_required | yes / no |
| risk_level | low / medium / high / critical |
| owner | accountable engineer or team |

## Status conventions
- `not_started`
- `in_progress`
- `done`
- `blocked`
- `waived`
- `not_applicable`

## Evidence conventions
Every executable release item should expose:
- `evidence_ref`
- `verified_by`
- `verified_at`
- `source_system`
