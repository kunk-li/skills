# Output Template: 变更摘要

## Required sections
- change_summary_overview
- impact_quantification
- high_risk_changes
- compatibility_notes
- operational_followups
- downstream_handoff
