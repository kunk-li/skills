# N270 collaboration matrix

## Shared release_manifest contract
All six N270 skills must treat `release_manifest` as the single shared source of truth for release state.

Recommended manifest sections:
- `release_identity`: version, release train, target date, release manager, release window
- `change_inventory[]`: normalized entries from tasks, PRs, and commit history
- `quality_gate_snapshot`: imported gate status, blockers, pending conditions, overrides
- `release_checklist_state[]`: executable release-step state with owner, timing, and evidence
- `rollback_assets[]`: phase-specific rollback options, dry-run evidence, and time-window limits
- `canary_strategy`: cohort, promotion policy, metric thresholds, rollback triggers
- `risk_register[]`: active release risks with likelihood, impact, mitigation, and status
- `handoff_targets`: outputs prepared for N280, N290, and N360

## Cross-skill sequencing
1. `change-summary-generation` normalizes the change inventory for internal release decision-making.
2. `release-note-generation` derives audience-facing release communication from the shared manifest.
3. `release-risk-assessment` scores risks and injects mitigation actions into the manifest.
4. `release-checklist-generation` turns the manifest into executable checklist state and owner/timing assignments.
5. `rollback-plan-generation` derives rollback paths and dry-run evidence requirements from release scope and risks.
6. `canary-release-recommendation` binds cohort strategy, promotion thresholds, and rollback triggers to the release.

## Closure rules
- If risk mitigation actions are generated, corresponding checklist items must exist.
- If rollback dry-run evidence is missing for a release-critical phase, checklist state must stay blocked.
- If canary metrics thresholds are not machine-readable, canary promotion must default to manual review.
- If a blocker closes, update `release_manifest` first, then regenerate downstream assets.

## Downstream handoff
- N280 consumes release explanation, executable checklist state, environment-sensitive rollback details, and canary policy.
- N290 consumes checklist completion, canary outcomes, and release communication to prepare acceptance and first-run validation.
- N360 consumes release health, active risk posture, and release decision rationale for coordination and stakeholder tracking.
