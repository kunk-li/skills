# Field contract

## Shared metadata requirements
Every N270 artifact should expose `metadata` with:
- `selected_mode`
- `readiness`
- `function_bias`
- `stage_position`
- `workflow_node: N270`
- `node_artifact_target`
- `evidence_profile`
- `tool_collaboration_mode`

## Shared downstream_handoff expectations
`downstream_handoff` should name:
- primary consumers: N280, N290, N360
- missing evidence that blocks safe downstream use
- manual decisions still required
- refresh triggers when upstream inputs change
