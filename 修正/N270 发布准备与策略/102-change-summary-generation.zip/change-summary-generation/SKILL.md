---
name: change-summary-generation
description: generate workflow-aligned internal change summaries from release manifests, task breakdowns, pr descriptions, and diff risk evidence. use when chatgpt works in release & delivery / release preparation and must produce the n270 变更摘要.md artifact for internal decision support, impact analysis, release scoping, or risk-focused change explanation.
---
# change-summary-generation

## Role / role positioning
This skill aligns to release & delivery -> release preparation -> 变更摘要.md. It delivers the authoritative workflow-aligned artifact for N270.

### Boundary
- Own internal change inventory and impact summarization.
- Consume upstream N260 gate evidence instead of re-running quality gate logic.
- Keep direct downstream use in N280, N290, and N360 explicit.
- Use the shared `release_manifest` as the preferred cross-skill truth source whenever multiple N270 artifacts coexist.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `per_release`
- `cumulative`
- `risk_focused`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### optional enhancement inputs
- release manifest
- commit range
- ticket metadata
- test changes
- migration notes
- risk register
- historical release summaries

## Standalone rule / standalone usage
This skill must still work on one release candidate, one service release, one hotfix, or one release decision slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If evidence is partial, separate confirmed facts from assumptions and open risks.
- Keep release decisions conservative when critical release readiness, rollback, or canary evidence is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize the referenced output-template file.

The result must include at least:
- `metadata`
- `change_summary_overview`
- `change_inventory[]`
- `impact_quantification`
- `high_risk_changes[]`
- `cross_version_view`
- `decision_support_notes`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: internal_change_inventory_and_impact_summarization`
- `stage_position: release_and_delivery.release_preparation.change_summary_generation`
- `workflow_node: N270`
- `node_artifact_target: 变更摘要.md`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Keep change summary internal and decision-oriented; do not just duplicate outward-facing release notes.
- Quantify impact per change: users affected, modules touched, tests affected, migration need, compatibility, and effort.
- Highlight high-risk changes explicitly and bind them to risk mitigation or rollback concerns.
- Support cumulative multi-release views without losing per-release granularity.

## Execution workflow / execution workflow
1. Normalize the release change inventory from tasks, PRs, and commit data.
2. Quantify technical and operational impact for each change and group high-risk or breaking changes.
3. Produce an internal summary optimized for release planning, approval, and downstream coordination.
4. Point downstream consumers to canary, rollback, and risk sections when a change needs extra protection.

## Dynamic completeness / dynamic completeness
- If release scope is small, keep the structure stable but trim low-value sections rather than inventing detail.
- If cumulative mode is selected, show deltas and aggregation across versions instead of flattening everything into one list.
- If impact cannot be quantified yet, say so directly and surface it as a release uncertainty.

## Quality bar / quality bar
A good change summary tells internal stakeholders what changed, why it matters, where risk concentrates, and what release actions those changes imply.

## Reference files / reference files
- `references/change-summary-components.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
