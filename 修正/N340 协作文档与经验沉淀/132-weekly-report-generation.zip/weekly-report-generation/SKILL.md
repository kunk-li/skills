---
name: weekly-report-generation
description: generate weekly reports for the n340 collaboration and knowledge node. use when ChatGPT needs to summarize weekly progress, blockers, risks, and next steps from status updates, task lists, blockers, meeting notes, sprint data, or mixed project materials, especially for tl, pm, or l6 reporting views that require concise, blame-less, role-appropriate reporting rather than freeform narrative.
---

# 周报生成

## Role
作为 N340 协作治理节点中的周报生成器，把分散的任务状态、会议结果、阻塞项和风险信息收敛为可直接汇报的周报，而不是替用户做价值判断或追责。

## Stage position
- workflow node: N340
- node goal: 沉淀协作文档与经验资产
- node output target: `周报.md`
- downstream handoff: `management review`, `N360 cross-team sync`, `N390 audit and template reuse`

## Selected mode
- `tl_weekly`
- `pm_weekly`
- `l6_weekly`
- `neutral_summary_fallback`

## Primary inputs
优先消费：
- 任务状态、阻塞项、风险项、会议纪要
- 来自状态同步或节奏管理的数据表
- 需求、发布、验收、故障处置的阶段性结果

如果来源混杂，先做事实归并再输出周报。

## Standalone rule
即使没有完整状态表，也必须能基于现有材料输出一版有边界感的周报，并明确哪些部分来自事实、哪些是待确认缺口。

## Core output contract
默认输出包含：
1. 本周概览
2. 本周核心进展
3. 阻塞与风险
4. 下周重点
5. 需要协同或决策的事项
6. 数据口径与待确认

角色差异：
- `tl_weekly`：强调交付推进、技术风险、资源协调
- `pm_weekly`：强调范围、依赖、里程碑、协同状态
- `l6_weekly`：强调整体态势、关键风险、跨团队影响、是否需要决策

## Design rules
- 采用 **blame-less** 风格，不点名归责。
- 周报默认是 **汇总**，不是裁判书；避免写“谁做得不好”。
- 风险与阻塞要分开：阻塞是已经卡住，风险是尚未发生但可能影响。
- 尽量使用时间锚点、数量、状态变化，不只写抽象形容词。
- 当存在多角色视角时，必须选择最匹配的模板，而不是用一份通用模板硬凑。

## Execution workflow
1. 归并输入材料中的事实、风险、阻塞、里程碑变化。
2. 识别报告对象：TL、PM、L6，或未知。
3. 按角色模板组织内容。
4. 对每个风险和阻塞给出当前状态与后续动作。
5. 输出为可直接汇报的 markdown 文档。

## Dynamic completeness
最小版本也必须至少有：
- 1 段整体概览
- 3 类核心进展
- 阻塞与风险分栏
- 下周重点

## Quality bar
好周报应满足：
- 面向目标角色
- 不混淆事实、风险、阻塞
- 不做主观裁判
- 具备直接汇报可读性
- 能和状态同步数据互相映射

## Standalone use cases
- TL 周报
- PM 项目周报
- L6 管理汇总
- Sprint 周度同步

## Composition contract
与状态同步 / 节奏管理联动时：
- 上游负责提供结构化状态与 blocker 数据
- 本 skill 负责按读者视角重组为周报
- 不反向修改源数据口径，只做聚合表达

## References
- `references/weekly-template-per-role.md`
- `references/blameless-collaboration-rules.md`
- `references/n340-cross-skill-handoffs.md`
