# Blame-less Collaboration Rules

- Use role or team labels instead of personal names.
- Avoid phrasing like “X forgot” or “Y caused”.
- Prefer “owner role unclear”, “handoff missing”, “decision not recorded”, “dependency unresolved”.
- If the source names a person, convert it to a role when possible.
