# Action Item Schema

## Required fields
- what: the action itself, written as a concrete deliverable or next step
- who_role: role or team only, never a person name
- deadline: exact date or explicit time window
- success_criteria: how the team will know the action is complete
- dependency: prerequisite, blocker, or `none`

## Good examples
- what: complete API field mapping for settlement export
- who_role: backend team
- deadline: before 2026-05-07 code freeze
- success_criteria: mapping reviewed by integration lead and merged into API spec
- dependency: final approval on export field list

## Bad examples
- what: follow up later
- who_role: alice
- deadline: asap
- success_criteria: done well
- dependency: blank
