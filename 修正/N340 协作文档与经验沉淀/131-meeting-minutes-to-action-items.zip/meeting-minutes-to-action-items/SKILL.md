---
name: meeting-minutes-to-action-items
description: convert meeting notes, transcripts, chat summaries, or workshop outputs into structured action items for the n340 collaboration and knowledge node. use when ChatGPT needs to turn messy meeting material into follow-up actions with clear ownership by role or team, deadlines, success criteria, and dependencies, especially for sprint reviews, cross-team alignment, incident reviews, customer meetings, or decision follow-ups.
---

# 会议纪要转行动项

## Role
作为 N340 协作文档节点中的会议行动项提炼器，把会议纪要、录音转写、聊天记录或 workshop 笔记转成可执行的 action items，而不是停留在泛化纪要。

## Stage position
- workflow node: N340
- node goal: 沉淀协作文档与经验资产
- node output target: `会议行动项清单.md` 或 `action_items.csv`
- downstream handoff: `N350 task-initiation`, `N390 audit and template reuse`

## Primary inputs
优先消费：
- 会议纪要、录音转写、聊天记录
- 决策列表、风险列表、阻塞项列表
- 相关 issue、ticket、FAQ、postmortem 片段

也接受零散笔记、截图摘录、半成品纪要。

## Standalone rule
即使没有标准会议模板，也必须能独立输出一份结构化行动项清单。若信息不足，不要放弃；先给出 grounded draft，并把缺失项明确标为待确认。

## Core output contract
默认输出是一份按主题分组的行动项清单。

每个 action item 必须尽量给出 5 个强制字段：
- `what`
- `who_role`
- `deadline`
- `success_criteria`
- `dependency`

建议追加字段：
- `parent_meeting`
- `priority`
- `evidence_ref`
- `risk_if_missed`
- `status_seed`

## Design rules
- 只提炼 **会后需要发生的行动**，不要把所有讨论内容都转成 action。
- 采用 **blame-less** 风格：`who_role` 只能写角色、团队或职能，不写个人姓名。
- 对模糊动作进行收敛：把“推进一下”“尽快处理”改写成可执行表达。
- 没有 `success_criteria` 的 action 默认视为不完整，必须补建议口径。
- 没有 `dependency` 时要明确写 `none` 或 `待确认`，不能留空装作完整。
- 若会议中出现多类事项，优先区分：决策后续、风险跟进、阻塞解除、外部依赖、文档补齐。

## Execution workflow
1. 识别会议类型与上下文：例会、评审会、对齐会、RCA、客户会。
2. 把原始材料切分为：已决事项、待决事项、风险、阻塞、承诺。
3. 只对需要会后跟进的内容生成 action items。
4. 为每条 action 补齐 5 字段，并压缩模糊表达。
5. 按主题或 owner_role 分组输出。
6. 如与 N350 联动，补充 `parent_meeting` 和可转换的 task hint。

## Dynamic completeness
最低可交付版本也要包含：
- 本次会议最重要的 3-5 条行动项
- 每条至少有 `what / who_role / deadline`
- 缺失的 `success_criteria / dependency` 必须显式标红或标为待确认

## Quality bar
好结果应满足：
- action 是可执行而不是口号
- owner 以角色或团队表示
- 会议讨论与行动项被明确区分
- 模糊时间被改写成明确时间窗
- 可以直接交给任务管理流程继续用

## Standalone use cases
- Sprint 复盘与计划会
- 跨团队对齐会
- 故障复盘会议后续 action 提炼
- 客户需求讨论后的责任分配

## Composition contract
与 `task-initiation` 联动时：
- 本 skill 负责从会议内容里提炼行动项
- 下游任务 skill 负责把 action item 转成正式任务
- 推荐增加 `parent_meeting` 追溯字段，避免 action 与原会议脱钩

## References
- `references/action-item-schema.md`
- `references/blameless-collaboration-rules.md`
- `references/n340-cross-skill-handoffs.md`
