# FAQ Taxonomy

Recommended top-level categories:
- onboarding
- development
- api_and_integration
- operations_and_deployment
- incident_and_troubleshooting
- process_and_governance
- security_and_compliance
- release_and_change_management
- data_and_dictionary
- business_and_product_usage

Use fewer categories for small teams; merge near-empty categories instead of creating many single-entry buckets.
