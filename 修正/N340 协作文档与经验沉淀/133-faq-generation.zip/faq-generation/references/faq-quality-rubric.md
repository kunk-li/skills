# FAQ Quality Rubric

Each FAQ should pass these checks:
1. Question is phrased as a real user question.
2. Answer is concise, stable, and directly useful.
3. Example or link is present.
4. The entry is not a duplicate of an existing FAQ.
5. Taxonomy placement is reasonable.
