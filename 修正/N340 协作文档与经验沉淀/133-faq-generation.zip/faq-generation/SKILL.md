---
name: faq-generation
description: generate faq content for the n340 collaboration and knowledge node. use when ChatGPT needs to turn repeated questions from docs, support interactions, onboarding notes, incidents, release work, or team discussions into a structured faq with clear taxonomy, concise answers, examples or links, and semantic deduplication to avoid repeated entries.
---

# FAQ 生成

## Role
作为 N340 知识沉淀节点中的 FAQ 生成器，把重复问答、散碎答疑和文档盲区收敛为可搜索、可维护的 FAQ，而不是简单把原句堆成问答列表。

## Stage position
- workflow node: N340
- node goal: 沉淀协作文档与经验资产
- node output target: `faq.md` 或 `faq.csv`
- downstream handoff: `knowledge base`, `onboarding`, `N390 reusable templates`

## Primary inputs
优先消费：
- 开发文档、API 文档、运维手册、发布与复盘材料
- 历史问答、群聊高频问题、支持工单、onboarding 记录
- 已有 FAQ 草稿或旧版知识库

## Standalone rule
即使没有正式分类体系，也必须先做主题聚类，再输出一份有 taxonomy 的 FAQ 草稿。不能直接把原始问题顺序平铺出来。

## Core output contract
每条 FAQ 必须采用三段式：
- `question`
- `answer`
- `example_or_link`

推荐附加：
- `faq_category`
- `audience`
- `source_refs`
- `duplicate_group`
- `maintenance_note`

## Official taxonomy
默认优先使用以下大类：
1. onboarding
2. development
3. api_and_integration
4. operations_and_deployment
5. incident_and_troubleshooting
6. process_and_governance
7. security_and_compliance
8. release_and_change_management
9. data_and_dictionary
10. business_and_product_usage

## Design rules
- 每条 FAQ 必须满足 Question + Answer + Example/Link 三段式。
- 如果没有可用示例，也要给“related doc link”或“how to verify”作为第三段，不允许空缺。
- 对语义高度相近的问题做去重；避免“同问异写”生成多条重复 FAQ。
- FAQ 面向检索与复用，答案应短、稳、可引用，不写成长篇培训文。
- 如果问题来自特定项目术语，优先加通用表述或别名，提升跨项目可用性。

## Execution workflow
1. 收集问题池与已有答案源。
2. 先做语义聚类与重复问题合并。
3. 按官方 taxonomy 分类。
4. 为每条 FAQ 生成三段式内容。
5. 标记缺少示例、缺少来源、待补链接的条目。

## Dynamic completeness
最低可交付版本也必须包含：
- 清晰 taxonomy
- 每类至少 1-3 条 FAQ
- 每条 FAQ 的 question、answer、example_or_link
- 重复问题合并说明

## Quality bar
好 FAQ 应满足：
- 可以被搜索和直接复用
- 不重复答同一件事
- 问题表述贴近真实提问
- 答案不空泛
- 第三段 example_or_link 不缺失

## Standalone use cases
- 新人 onboarding FAQ
- 技术支持 FAQ
- 运维 FAQ
- 流程与治理 FAQ

## Composition contract
与开发文档、维护手册、最佳实践联动时：
- FAQ 负责把“反复被问的问题”沉淀成检索资产
- best-practice 负责把“可推广的方法”沉淀成 pattern
- 相同主题可 cross-link，但不要把 FAQ 写成 pattern 手册

## References
- `references/faq-taxonomy.md`
- `references/faq-quality-rubric.md`
- `references/n340-cross-skill-handoffs.md`
