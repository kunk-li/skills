# Pattern 6-field Template

- context: where the pattern applies
- problem: what recurring difficulty appears
- solution: what repeatable approach works
- consequences: benefits and tradeoffs
- anti_pattern: what to avoid instead
- evidence: postmortem, docs, metrics, or repeated examples supporting it
