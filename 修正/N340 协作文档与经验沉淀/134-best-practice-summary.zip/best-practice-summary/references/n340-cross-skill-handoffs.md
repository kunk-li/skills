# N340 Cross-skill Handoffs

- meeting-minutes-to-action-items -> task-initiation: action items can become tasks.
- weekly-report-generation <- status sync / blocker extraction: weekly reports should consume structured progress and blockers.
- faq-generation <- development docs / ops docs / repeated questions.
- best-practice-summary <- postmortems / repeated wins / repeated failures.
