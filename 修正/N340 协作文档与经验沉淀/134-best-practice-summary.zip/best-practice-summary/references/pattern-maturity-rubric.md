# Pattern Maturity Rubric

## proposed
- derived from reasoning, a single example, or limited evidence
- still needs validation in real work

## validated
- applied successfully more than once or supported by strong evidence
- can be recommended with moderate confidence

## canonical
- repeatedly validated across contexts
- accepted as a default team or platform practice
