---
name: best-practice-summary
description: summarize reusable best practices for the n340 collaboration and knowledge node. use when ChatGPT needs to turn repeated wins, repeated failures, postmortem lessons, architecture patterns, process learnings, or operating experience into a structured pattern library with fixed fields, maturity levels, cross-links, and explicit evidence instead of loose anecdotal notes.
---

# 最佳实践总结

## Role
作为 N340 经验沉淀节点中的 Pattern 提炼器，把历史事件、成熟做法和反复验证的经验整理为可复用的 best practice，而不是停留在“这次我们这么做了”的叙述层面。

## Stage position
- workflow node: N340
- node goal: 沉淀协作文档与经验资产
- node output target: `best_practices.md` 或 `pattern_library.md`
- downstream handoff: `N390 templates`, `training`, `future project bootstrap`

## Primary inputs
优先消费：
- postmortem、timeline、FAQ、开发文档、运维手册
- 历史成功案例、失败案例、改进记录
- 过程规范、架构设计经验、团队治理经验

## Standalone rule
即使只有部分案例，也必须先提炼 pattern 候选，并显式标成熟度。不要把推演性的建议伪装成已验证最佳实践。

## Core output contract
每条 Pattern 必须固定 6 字段：
- `context`
- `problem`
- `solution`
- `consequences`
- `anti_pattern`
- `evidence`

并强制补一个成熟度字段：
- `maturity`: `proposed` / `validated` / `canonical`

## Design rules
- Pattern 必须比具体项目更抽象，尽量去掉项目特定黑话。
- 不允许把单次推演结果直接写成 canonical。
- 没有 evidence 的 pattern 只能是 `proposed`。
- `anti_pattern` 不能缺；否则会把 pattern 写成空洞宣传稿。
- 如果 pattern 来自 incident 或复盘，必须 cross-link 到对应 postmortem 或 timeline。

## Execution workflow
1. 从历史材料中识别重复出现的做法、教训或决策模式。
2. 合并相似候选项，避免“同一经验换名字”。
3. 用 6 字段模板重写成可复用 Pattern。
4. 根据 evidence 质量和验证次数标成熟度。
5. 输出 pattern 列表，并标注哪些仍需后续验证。

## Dynamic completeness
最低可交付版本也至少要有：
- 3-5 条 pattern
- 每条的 6 字段
- 明确 maturity
- 与 FAQ / postmortem / 文档的交叉引用

## Quality bar
好 pattern 应满足：
- 不是项目私话堆砌
- 有明确问题场景
- 有反例或 anti-pattern
- 成熟度不夸大
- 后续团队可以复用，而不是只能原班人马看懂

## Standalone use cases
- 架构 best practice 库
- 流程改进 pattern 库
- incident lesson learned 库
- 培训与 onboarding 案例库

## Composition contract
与 FAQ 和 postmortem 联动时：
- FAQ 负责“经常被问什么”
- postmortem 负责“这次为什么出事”
- 本 skill 负责“以后应该如何稳定地做”

## References
- `references/pattern-6-field-template.md`
- `references/pattern-maturity-rubric.md`
- `references/n340-cross-skill-handoffs.md`
