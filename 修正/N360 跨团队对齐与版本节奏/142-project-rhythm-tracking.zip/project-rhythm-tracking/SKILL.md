---
name: project-rhythm-tracking
description: track project rhythm, milestone slippage, and key checkpoints for n360 coordination. use when chatgpt should produce rfc4180 csv snapshots or delta updates, keep stable rhythm ids, validate an exact 13-column schema, use pipe-separated list fields, synthesize blocker and risk refs from n350 inputs, and support standalone tracking from roadmaps or release calendars.
---

# 项目节奏跟踪

把 roadmap、任务状态、风险台账、门禁与周会更新，压缩成 **可周刷、可看板消费、可复盘** 的项目节奏表。

先阅读：
- `references/n360-contracts.md`
- `references/csv-schema.md`
- `references/csv-list-field-escape.md`

## 优先模式
- 旧节奏表 + 新周会 / 新状态 / 新风险 → **delta mode**，保留 `rhythm_id`，只刷新变化行。
- 没有旧表 → **snapshot mode**，基于当前 roadmap / 发布计划生成完整节奏快照。

## Standalone 加强
即使缺 `任务状态同步` 或 `风险项清单`，也可以仅基于：
- roadmap
- 发布计划
- 里程碑日历
- 周会纪要

先生成节奏骨架；拿不到的值写 `待确认`，不要伪造 blocker / risk id。

## 工作流
1. 先识别周期标签（如 sprint、发布周、灰度周、合规周）与对应 milestone。
2. 为每行补齐 `status`、计划日期、预测日期、偏差、相关 blocker / risk / HCN。
3. 多个 blocker / risk / HCN 必须按 `references/csv-list-field-escape.md` 使用 `|`，不要用裸逗号。
4. 若用户只要摘要，可输出 markdown quick view；但默认机器消费模式优先输出 CSV。
5. 若输入里引用的 blocker / risk 已有稳定 id，必须原样复用，不要在 N360 里重命名。

## 默认契约模式（推荐）
当结果要给 Grafana / Python / Excel / N370 / N390 消费时，输出：

- schema: `n360.project-rhythm-tracking.v2`
- exact columns:
  `rhythm_id,period,milestone,owner,status,plan_date,forecast_date,variance_days,blocker_refs,risk_refs,hcn_refs,next_action,evidence_ref`

## status 枚举
仅使用：`PLANNED` / `ON_TRACK` / `AT_RISK` / `OFF_TRACK` / `DONE`

- `PLANNED`：已入计划，但还未到执行观察点
- `ON_TRACK`：当前没有明显偏离
- `AT_RISK`：已有风险或轻度偏差，但尚未脱轨
- `OFF_TRACK`：关键路径已明显偏离或被 blocker 卡住
- `DONE`：该周期 / milestone 已完成

## 严格边界
- 这里只做节奏展示与跟踪，不替代范围裁剪或正式排期决策。
- 不在这里重算 N350 的 blocker / risk 定义，只复用或引用。
- 不把“还没证据的担忧”写成 blocker_refs。

## 质量检查
完成前确认：
- 列数、表头、列表字段转义都稳定。
- `blocker_refs` / `risk_refs` / `hcn_refs` 没有裸逗号。
- 若输出 CSV，遵守 `references/csv-schema.md`，必要时可运行 `scripts/validate_csv.py`。
