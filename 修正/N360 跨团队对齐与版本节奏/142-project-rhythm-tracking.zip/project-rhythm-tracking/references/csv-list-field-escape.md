# csv list field escape

当一个 CSV 单元格里需要放多个引用或多个 id 时，优先使用 `|`。

## 方案对比
1. **pipe (`|`)**
   - 优点：对 Excel、Python、Grafana 都友好
   - 缺点：字段里不要再混入裸 `|`
   - **推荐**

2. **双引号 + 逗号**
   - 优点：理论上符合 CSV
   - 缺点：人手编辑时最容易出错，本节点 v1 bug 就来自这里

3. **json 数组**
   - 优点：机器友好
   - 缺点：人眼阅读和手工维护成本高

## 本节点规则
- `blocker_refs`、`risk_refs`、`hcn_refs`、`evidence_ref` 一律使用 `|`
- 不要在单元格里写 `A,B,C`
- 需要空值时留空，不要写假 id
