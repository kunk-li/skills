# project-rhythm-tracking csv schema

schema: `n360.project-rhythm-tracking.v2`

## columns
`rhythm_id,period,milestone,owner,status,plan_date,forecast_date,variance_days,blocker_refs,risk_refs,hcn_refs,next_action,evidence_ref`

## field rules
- `rhythm_id`: 稳定 id，如 `RHY-001`
- `period`: 周期标签，如 `Sprint-2/W1`、`Release-Wk`、`Canary-W1`
- `status`: `PLANNED` / `ON_TRACK` / `AT_RISK` / `OFF_TRACK` / `DONE`
- `plan_date` / `forecast_date`: 日期、时间窗口或 `待确认`
- `variance_days`: 整数天数；拿不到时写 `待确认`
- `blocker_refs` / `risk_refs` / `hcn_refs` / `evidence_ref`: 多值时统一 `|`

## csv rules
- RFC-4180
- UTF-8
- 列表字段不用裸逗号，统一 `|`

## example
```csv
rhythm_id,period,milestone,owner,status,plan_date,forecast_date,variance_days,blocker_refs,risk_refs,hcn_refs,next_action,evidence_ref
RHY-001,Sprint-3/W2,完成灰度前回归检查,QA,AT_RISK,2026-05-08,2026-05-10,2,BLK-003|BLK-007,RISK-005,HCN-024,在 5/06 前锁定回归范围与责任人,meeting:weekly-2026-04-23#topic:5
```
