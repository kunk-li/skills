# N360 协同契约

## 在流程中的位置
- 将本 skill 视为 **N360 跨团队对齐与版本节奏** 的子能力。
- N360 负责把任务、风险、测试、发布和周会信号整理成 **跨团队可对齐、可裁剪、可跟踪** 的治理产物。
- `product-engineering-alignment-summary`、`qa-engineering-alignment-summary`、`project-rhythm-tracking` 保持 **帮助理解 / 辅助查看，不裁判**。
- `version-scope-trimming-recommendation` 可以给出建议，但**不替代负责人拍板**。

## 优先吸收的输入
1. `需求优先级建议.csv`
2. `发布风险评估.md`
3. `测试失败归因.md`
4. `任务状态同步.md` / `任务状态同步.csv`
5. `风险项清单.csv`
6. Roadmap、PRD、周会纪要、跨团队对齐纪要、质量门禁结果

## standalone fallback
- 缺上游结构化产物时，可从 **PRD / roadmap / QA 会议纪要 / release plan** 直接生成 baseline，不因为缺 N350/N250/N270 就阻塞。
- 当用户要做未来预演、周度 rehearsal 或阶段节奏预估时，默认至少覆盖 **5 个关键周期**：当前基线、下个 sprint handoff、发布前、发布周、灰度 / 合规周；窗口更长时扩到 5-7 个周期。

## cross-skill handoff
- 对齐摘要中未决议题可沉淀 `action_ref`，供 N340 会议行动项或 N350 `task-initiation` 继续消费。
- 若发现 `gate fail`、高风险或 `hard-rule violation`，应显式提示 N141 版本裁剪评估。
- 项目节奏跟踪优先复用 N350 的 `blocker_refs` / `risk_refs`，不要在 N360 里重新发明 id。

## 统一契约
- 结构化结果优先使用 **RFC-4180 兼容 CSV** 或字段稳定的 markdown 表。
- 第一行只放表头，不加第二表头或解释行。
- 多值字段统一使用 `|`，不要在单元格里用裸逗号拼接列表。
- 缺失但不能伪造的字段写 `待确认` 或 `待核对`。
- 有旧台账时保留稳定 `topic_id` / `decision_point` / `rhythm_id`，优先 delta 更新。
- 若要给下游机器消费，在正文中显式声明 `schema` 与 `version`，不要悄悄改列名。
