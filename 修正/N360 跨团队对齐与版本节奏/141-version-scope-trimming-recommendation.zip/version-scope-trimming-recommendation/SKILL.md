---
name: version-scope-trimming-recommendation
description: recommend version scope-trim options for n360 release governance. use when chatgpt should formalize trigger rules with a small dsl, compare keep-scope versus trim or split options, abstract hard-rule violations, cite tradeoffs and confidence, preserve visible signoff chains, and output structured recommendation rows without making the final release decision.
---

# 版本范围裁剪建议

把风险、门禁、节奏和对齐信号整理成 **可解释、可触发、可签字** 的版本范围裁剪建议。

先阅读：
- `references/n360-contracts.md`
- `references/decision-option-schema.md`
- `references/trigger-rules-dsl.md`
- `references/hard-rule-violation.md`

## 优先模式
- 旧裁剪记录 + 新门禁 / 风险 / 状态信号 → **delta mode**，保留原 `decision_point`。
- 没有旧记录 → **fresh assessment**，从当前版本窗口重新评估。

## 工作流
1. 先抽取 release window、gate 信号、blocked 数、最高风险分、未决对齐议题和 signoff 约束。
2. 用 `references/trigger-rules-dsl.md` 把触发条件写成简短规则，再判断 `trigger_result = YES / NO / UNKNOWN`。
3. 在默认三类选项中给建议：
   - `A_KEEP_SCOPE_WITH_MITIGATION`
   - `B_TRIM_SCOPE`
   - `C_SPLIT_OR_DELAY`
4. 用 tradeoff、confidence 和 signoff chain 解释建议，但不要替负责人拍板。
5. 若存在 `hard_rule_violation`，按 `references/hard-rule-violation.md` 处理：**违反死令的选项不能继续推荐**。

## 默认输出
默认给 **markdown 决策 memo + 结构化表格**，至少包含：
- 触发规则与是否命中
- 推荐选项与备选项
- tradeoff
- confidence
- required_signoff
- next_step

若用户明确要机器消费、沉淀决策台账或给 N370 / N380 使用，则输出 `references/decision-option-schema.md` 中定义的 CSV。

## 触发规则要求
- 没有足够证据时，把 `trigger_result` 写成 `UNKNOWN`，不要硬判 `YES`。
- 不要只写自然语言感受；尽量用简单可复核的条件表达式。
- 若 `gate fail`、`risk_score >= 15`、`blocked_count` 明显上升、`days_left` 很短，应优先进入 scope review。

## 严格边界
- 不替代 release owner、PM、QA 或 HCN 最终拍板。
- 不伪造签字链、法务 / 合规结论或门禁结果。
- 不把“建议”写成“已经决议”，除非输入材料已经明确决议完成。

## 质量检查
完成前确认：
- 推荐选项能被明确的 trigger rule 支撑。
- `hard_rule_violation = YES` 时，没有继续推荐会违规的选项。
- confidence、tradeoff、required_signoff 都清晰可追溯。
- 若输出 CSV，遵守 `references/decision-option-schema.md`，必要时可运行 `scripts/validate_csv.py`。
