# hard-rule violation

`hard_rule_violation` 用来抽象任何 **不可违背的死令类约束**，例如：
- 合规或法务硬约束
- 审计 / 安全必须项
- 对外 SLA 或重大客户承诺
- 平台明确禁止绕过的门禁

## 使用规则
- 一旦确认存在 `hard_rule_violation = YES`，不能推荐仍然让该违规继续存在的选项。
- 不要把“普通风险较高”混同为 hard rule；hard rule 是 **不允许破例** 的约束。
- 若是否构成 hard rule 证据不足，写 `待核对` 到说明里，并把结构化字段保守记成 `NO` 或 `UNKNOWN` 旁注，而不是伪造确认。
