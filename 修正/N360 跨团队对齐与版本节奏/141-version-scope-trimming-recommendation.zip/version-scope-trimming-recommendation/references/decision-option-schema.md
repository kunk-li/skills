# version scope trimming decision schema

schema: `n360.version-scope-trimming.v2`

## default markdown table
| decision_point | trigger_rule | trigger_result | recommended_option | alternative_options | tradeoff_summary | confidence | hard_rule_violation | required_signoff | evidence_ref | next_step |
|---|---|---|---|---|---|---|---|---|---|---|

## csv columns
`decision_point,trigger_rule,trigger_result,recommended_option,alternative_options,tradeoff_summary,confidence,hard_rule_violation,required_signoff,evidence_ref,next_step`

## field rules
- `decision_point`: 稳定 id，如 `STR-001`
- `trigger_rule`: 使用 `references/trigger-rules-dsl.md` 的简短 DSL
- `trigger_result`: 仅用 `YES` / `NO` / `UNKNOWN`
- `recommended_option`: 仅用 `A_KEEP_SCOPE_WITH_MITIGATION` / `B_TRIM_SCOPE` / `C_SPLIT_OR_DELAY`
- `alternative_options` / `required_signoff` / `evidence_ref`: 多值时统一 `|`
- `confidence`: 仅用 `LOW` / `MEDIUM` / `HIGH`
- `hard_rule_violation`: 仅用 `YES` / `NO`

## key rule
若 `hard_rule_violation = YES`，则 `recommended_option` 不能是 `A_KEEP_SCOPE_WITH_MITIGATION`。

## csv rules
- RFC-4180
- UTF-8
- 列表字段不用裸逗号，统一 `|`

## example
```csv
decision_point,trigger_rule,trigger_result,recommended_option,alternative_options,tradeoff_summary,confidence,hard_rule_violation,required_signoff,evidence_ref,next_step
STR-001,when gate.any_fail == true and release.days_left <= 7 then recommend(B_TRIM_SCOPE),YES,B_TRIM_SCOPE,A_KEEP_SCOPE_WITH_MITIGATION|C_SPLIT_OR_DELAY,裁剪低价值范围能保住主路径上线但会牺牲部分演示功能,MEDIUM,NO,PM|ENG|QA,doc:release-risk#section:summary|meeting:weekly-2026-04-23#topic:4,在 4/24 前完成待裁剪项确认
```
