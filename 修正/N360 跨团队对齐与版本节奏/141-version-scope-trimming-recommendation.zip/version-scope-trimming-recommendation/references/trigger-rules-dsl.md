# trigger rules dsl

## syntax
使用下面的最小格式：

`when <condition> then <action>`

### supported actions
- `trigger(scope_review)`
- `recommend(A_KEEP_SCOPE_WITH_MITIGATION)`
- `recommend(B_TRIM_SCOPE)`
- `recommend(C_SPLIT_OR_DELAY)`
- `forbid(A_KEEP_SCOPE_WITH_MITIGATION)`
- `forbid(B_TRIM_SCOPE)`
- `forbid(C_SPLIT_OR_DELAY)`

### common signals
- `gate.any_fail`
- `gate.fail_count`
- `risk.max_score`
- `status.blocked_count`
- `release.days_left`
- `hcn.pending_count`
- `hard_rule_violation`

### operators
`==` `!=` `>` `>=` `<` `<=` `and` `or`

## examples
- `when gate.any_fail == true and release.days_left <= 7 then trigger(scope_review)`
- `when risk.max_score >= 15 or status.blocked_count >= 3 then recommend(B_TRIM_SCOPE)`
- `when hard_rule_violation == true then forbid(A_KEEP_SCOPE_WITH_MITIGATION)`
- `when gate.fail_count >= 2 and release.days_left <= 3 then recommend(C_SPLIT_OR_DELAY)`

## interpretation
- 证据足够且条件命中 → `trigger_result = YES`
- 证据足够且未命中 → `trigger_result = NO`
- 关键信号缺失或互相冲突 → `trigger_result = UNKNOWN`
