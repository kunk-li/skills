#!/usr/bin/env python3
import csv
import sys
from pathlib import Path

SCHEMA_NAME = 'n360.version-scope-trimming.v2'
EXPECTED_HEADERS = ['decision_point', 'trigger_rule', 'trigger_result', 'recommended_option', 'alternative_options', 'tradeoff_summary', 'confidence', 'hard_rule_violation', 'required_signoff', 'evidence_ref', 'next_step']
REQUIRED_FIELDS = {'decision_point', 'trigger_rule', 'trigger_result', 'recommended_option', 'tradeoff_summary', 'confidence', 'hard_rule_violation', 'required_signoff', 'evidence_ref', 'next_step'}
LIST_FIELDS = {'alternative_options', 'required_signoff', 'evidence_ref'}
ALLOWED_TRIGGER = {'YES', 'NO', 'UNKNOWN'}
ALLOWED_OPTION = {'A_KEEP_SCOPE_WITH_MITIGATION', 'B_TRIM_SCOPE', 'C_SPLIT_OR_DELAY'}
ALLOWED_CONFIDENCE = {'LOW', 'MEDIUM', 'HIGH'}
ALLOWED_HARD = {'YES', 'NO'}


def fail(msg: str) -> int:
    print(f'[FAIL] {msg}')
    return 1


def ok(msg: str) -> int:
    print(f'[OK] {msg}')
    return 0


def main() -> int:
    if len(sys.argv) != 2:
        print('usage: python scripts/validate_csv.py <version-scope-trimming.csv>')
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        return fail(f'file not found: {path}')
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        if headers != EXPECTED_HEADERS:
            return fail(f'header mismatch for {SCHEMA_NAME}. expected={EXPECTED_HEADERS} got={headers}')
        rows = list(reader)
    if not rows:
        return fail('csv has no data rows')

    seen = set()
    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED_FIELDS:
            if not (row.get(field) or '').strip():
                return fail(f'row {idx} missing required field: {field}')
        for field in LIST_FIELDS:
            value = (row.get(field) or '').strip()
            if ',' in value:
                return fail(f"row {idx} field '{field}' must use '|' instead of commas for multi-value lists")
        ident = (row.get('decision_point') or '').strip()
        if ident in seen:
            return fail(f'duplicate decision_point at row {idx}: {ident}')
        seen.add(ident)
        trigger_result = (row.get('trigger_result') or '').strip()
        if trigger_result not in ALLOWED_TRIGGER:
            return fail(f'row {idx} invalid trigger_result: {trigger_result}')
        option = (row.get('recommended_option') or '').strip()
        if option not in ALLOWED_OPTION:
            return fail(f'row {idx} invalid recommended_option: {option}')
        confidence = (row.get('confidence') or '').strip()
        if confidence not in ALLOWED_CONFIDENCE:
            return fail(f'row {idx} invalid confidence: {confidence}')
        hard = (row.get('hard_rule_violation') or '').strip()
        if hard not in ALLOWED_HARD:
            return fail(f'row {idx} invalid hard_rule_violation: {hard}')
        if hard == 'YES' and option == 'A_KEEP_SCOPE_WITH_MITIGATION':
            return fail(f'row {idx} cannot recommend A_KEEP_SCOPE_WITH_MITIGATION when hard_rule_violation is YES')
    return ok(f'{SCHEMA_NAME} validation passed: {len(rows)} rows')


if __name__ == '__main__':
    raise SystemExit(main())
