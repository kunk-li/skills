# qa-engineering alignment topic schema

schema: `n360.qa-engineering-alignment.v2`

## default markdown table
| topic_id | 议题 | QA 视角 | 研发视角 | 当前差异 | 待决方 | deadline | faq_ref | action_ref | evidence_ref | status |
|---|---|---|---|---|---|---|---|---|---|---|

## csv columns
`topic_id,topic,qa_view,engineering_view,current_gap,decision_owner,deadline,evidence_ref,faq_ref,action_ref,status`

## field rules
- `topic_id`: 稳定 id，如 `QEA-001`
- `qa_view`: 测试口径、缺陷判定、验收边界、覆盖范围或环境要求
- `engineering_view`: 研发约束、实现代价、修复窗口或回归成本
- `faq_ref` / `evidence_ref` / `action_ref`: 多值时统一 `|`
- `faq_ref`: 推荐格式 `faq:<entry_id>`；若已有标准答案，优先复用 FAQ 而不是重复升级
- `action_ref`: 推荐格式 `meeting:<meeting_id>#action:<n>` 或 `task:TASK-001`
- `status`: 仅用 `OPEN` / `WAITING_DECISION` / `ALIGNED`

## csv rules
- RFC-4180
- UTF-8
- 列表字段不用裸逗号，统一 `|`

## example
```csv
topic_id,topic,qa_view,engineering_view,current_gap,decision_owner,deadline,evidence_ref,faq_ref,action_ref,status
QEA-001,hotfix 是否需要全链路回归,QA 希望至少补做支付链路回归,研发认为仅修复单模块即可上线,回归范围认定不一致,QA|ENG,2026-04-28,meeting:qa-sync-2026-04-23#topic:1,,meeting:qa-sync-2026-04-23#action:2,WAITING_DECISION
```
