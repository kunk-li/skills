---
name: qa-engineering-alignment-summary
description: summarize qa and engineering alignment topics for n360 cross-team governance. use when chatgpt should compare qa expectations with engineering constraints, keep a neutral summarize-not-judge bias, support standalone baselines from qa notes or test plans, output fixed alignment-topic structures or optional csv handoff rows, preserve stable topic ids, and connect repeated answers to faq refs or downstream actions.
---

# 测试-研发对齐摘要

把缺陷、验收、覆盖率、回归范围、压测与 hotfix 争议整理成 **不裁判、可回收、可交接** 的测研对齐摘要。

先阅读：
- `references/n360-contracts.md`
- `references/alignment-topic-schema.md`
- `references/rehearsal-coverage.md`

## 优先模式
- 有旧对齐台账 + 本周新测试材料 → **delta mode**，保留 `topic_id`。
- 缺 N250 / N230 结构化输出，但有 QA 周会纪要、测试计划、缺陷摘录 → **baseline mode**，先产对齐骨架。

## 工作流
1. 分开抽取 **QA 视角**、**研发视角**、共同事实、未决项。
2. 聚焦缺陷严重级、验收口径、回归范围、 flaky 阈值、压测窗口、hotfix 回归等争议。
3. 每个议题尽量补齐：`topic_id`、议题、双方视角、当前 gap、待决方、deadline、证据、FAQ / action handoff。
4. 若某个分歧其实已经被团队 FAQ 回答，写入 `faq_ref`，并避免把它继续包装成新争议。
5. 若用户要求阶段预演，按 `references/rehearsal-coverage.md` 至少覆盖 5 个关键周期。

## 默认输出
默认给 **markdown 摘要 + 结构化表格**，结构固定为：
- 已对齐结论
- 待决议题
- 需补充测试证据的项
- 可沉淀 FAQ 的重复问题

若用户明确要机器消费、导出表格或继续 handoff 给 N350 / N340，则输出 `references/alignment-topic-schema.md` 中定义的 CSV。

## Standalone 加强
缺 N250 defect 表、缺 N230 测试点时，也可以仅基于：
- QA 周会纪要
- 测试计划 / 验收标准
- 缺陷摘录
- 回归记录

生成基线摘要。拿不到的判断条件写 `待确认`，不要伪造通过率、覆盖率或严重级。

## 严格边界
- 只汇总分歧与待决项，不替 QA 或研发拍板。
- 不在这里写正式测试方案、缺陷归因或上线裁剪结论。
- 只在发现高风险 / hard rule / gate fail 信号时提示 N141 或相关门禁。

## 质量检查
完成前确认：
- 每个议题都说明了“争议点、证据、待决方、回收时间”。
- FAQ 已覆盖的问题不被重复制造成新议题。
- 若输出 CSV，遵守 `references/alignment-topic-schema.md`，必要时可运行 `scripts/validate_csv.py`。
