---
name: product-engineering-alignment-summary
description: summarize product and engineering alignment topics for n360 cross-team governance. use when chatgpt should compare product expectations with engineering constraints, keep a neutral summarize-not-judge bias, support standalone baselines from prds or roadmaps, output fixed alignment-topic structures or optional csv handoff rows, preserve stable topic ids, and prepare unresolved topics for downstream action tracking.
---

# 产品-研发对齐摘要

把散落在 PRD、roadmap、会议纪要、任务状态、方案说明里的信息，整理成 **不裁判、可跟进、可交接** 的产研对齐摘要。

先阅读：
- `references/n360-contracts.md`
- `references/alignment-topic-schema.md`
- `references/rehearsal-coverage.md`

## 优先模式
- 有旧对齐台账 + 本周新材料 → **delta mode**，保留 `topic_id`，只更新变化点。
- 只有 PRD / roadmap / 会议纪要 → **baseline mode**，先产出基线对齐议题，不等待 N070 / N270 / N250。

## 工作流
1. 先分开抽取 **产品视角**、**研发视角**、共同事实、未决问题。
2. 只汇总差异、约束、依赖和待决项；不要替任一方“判赢”。
3. 每个议题都尽量补齐：`topic_id`、议题名称、双方视角、当前 gap、待决方、deadline、证据、action handoff。
4. 若用户要求周度 / 阶段预演，按 `references/rehearsal-coverage.md` 至少覆盖 5 个关键周期，不要只给 3 周就结束。
5. 若议题其实已经明确结论，`status` 标 `ALIGNED`；若仍需拍板，标 `WAITING_DECISION`。

## 默认输出
默认先给 **markdown 摘要 + 结构化表格**，结构固定为：
- 已对齐事项
- 待决议题
- 需要 N350 / 会议 action 跟进的项
- 风险提示（仅点到为止，不替代 risk / scope trim skill）

如果用户明确要机器消费、导入表格、继续给 N350 / N370 使用，则输出 `references/alignment-topic-schema.md` 中定义的 CSV。

## Standalone 加强
即使没有上游结构化产物，也可以仅基于：
- PRD
- roadmap
- 周会纪要
- 关键聊天摘录

先产出 **对齐基线**。此时要把不确定处标成 `待确认`，不要伪造研发承诺或发布日期。

## 严格边界
- 不做价值判断、优先级排序或最终拍板。
- 不在这里产出完整需求文档、技术方案或测试方案。
- 不把 scope trim 结论写死；只在有明显信号时提示 N141。

## 质量检查
完成前确认：
- 每个议题都能回答“差异是什么、谁来拍板、何时回收”。
- 保持 **只汇总不裁判**。
- 若输出 CSV，遵守 `references/alignment-topic-schema.md`，必要时可运行 `scripts/validate_csv.py`。
