#!/usr/bin/env python3
import csv
import sys
from pathlib import Path

SCHEMA_NAME = 'n360.product-engineering-alignment.v2'
EXPECTED_HEADERS = ['topic_id', 'topic', 'product_view', 'engineering_view', 'current_gap', 'decision_owner', 'deadline', 'evidence_ref', 'action_ref', 'status']
REQUIRED_FIELDS = {'topic_id', 'topic', 'product_view', 'engineering_view', 'current_gap', 'decision_owner', 'deadline', 'evidence_ref', 'status'}
LIST_FIELDS = {'evidence_ref', 'action_ref'}
ALLOWED_STATUS = {'OPEN', 'WAITING_DECISION', 'ALIGNED'}


def fail(msg: str) -> int:
    print(f'[FAIL] {msg}')
    return 1


def ok(msg: str) -> int:
    print(f'[OK] {msg}')
    return 0


def main() -> int:
    if len(sys.argv) != 2:
        print('usage: python scripts/validate_csv.py <product-engineering-alignment.csv>')
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        return fail(f'file not found: {path}')
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        if headers != EXPECTED_HEADERS:
            return fail(f'header mismatch for {SCHEMA_NAME}. expected={EXPECTED_HEADERS} got={headers}')
        rows = list(reader)
    if not rows:
        return fail('csv has no data rows')

    seen = set()
    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED_FIELDS:
            if not (row.get(field) or '').strip():
                return fail(f'row {idx} missing required field: {field}')
        for field in LIST_FIELDS:
            value = (row.get(field) or '').strip()
            if ',' in value:
                return fail(f"row {idx} field '{field}' must use '|' instead of commas for multi-value lists")
        ident = (row.get('topic_id') or '').strip()
        if ident in seen:
            return fail(f'duplicate topic_id at row {idx}: {ident}')
        seen.add(ident)
        status = (row.get('status') or '').strip()
        if status not in ALLOWED_STATUS:
            return fail(f'row {idx} invalid status: {status}')
    return ok(f'{SCHEMA_NAME} validation passed: {len(rows)} rows')


if __name__ == '__main__':
    raise SystemExit(main())
