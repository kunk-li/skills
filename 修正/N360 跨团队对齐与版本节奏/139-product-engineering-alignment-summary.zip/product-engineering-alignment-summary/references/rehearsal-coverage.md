# rehearsal coverage guidance

当用户要求“预演未来几周的对齐焦点”“阶段切换前的待决议题盘点”时，默认不要只覆盖 3 个周期。

## minimum coverage
至少覆盖以下 5 个关键周期：
1. 当前基线周
2. 下个 sprint handoff
3. 发布前检查周
4. 发布周
5. 灰度 / 合规 / canary 周

## longer windows
- 若版本窗口更长，扩到 **5-7 个周期**。
- 若输入里已有明确 milestone 节点，以 milestone 为主，不必强行按自然周切。

## output expectation
每个周期至少回答：
- 这一周期最可能冒出的待决议题是什么
- 对齐双方是谁
- 若不解决，会影响哪个 milestone
- 是否需要预先生成 `action_ref`
