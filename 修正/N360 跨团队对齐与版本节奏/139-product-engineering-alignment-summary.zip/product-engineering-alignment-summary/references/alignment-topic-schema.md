# product-engineering alignment topic schema

schema: `n360.product-engineering-alignment.v2`

## default markdown table
| topic_id | 议题 | 产品视角 | 研发视角 | 当前差异 | 待决方 | deadline | action_ref | evidence_ref | status |
|---|---|---|---|---|---|---|---|---|---|

## csv columns
`topic_id,topic,product_view,engineering_view,current_gap,decision_owner,deadline,evidence_ref,action_ref,status`

## field rules
- `topic_id`: 稳定 id，如 `PEA-001`
- `product_view`: 产品期望、业务目标、范围要求或时间要求
- `engineering_view`: 技术约束、依赖、资源、实现路径或交付窗口
- `current_gap`: 只描述当前差异，不给裁判结论
- `decision_owner`: 负责人、角色或小组；未知时写 `待确认`
- `deadline`: 明确日期、周期标签或 `待确认`
- `evidence_ref` / `action_ref`: 多值时统一 `|`
- `action_ref`: 推荐格式 `meeting:<meeting_id>#action:<n>` 或 `task:TASK-001`
- `status`: 仅用 `OPEN` / `WAITING_DECISION` / `ALIGNED`

## csv rules
- RFC-4180
- UTF-8
- 列表字段不用裸逗号，统一 `|`

## example
```csv
topic_id,topic,product_view,engineering_view,current_gap,decision_owner,deadline,evidence_ref,action_ref,status
PEA-001,灰度阶段是否保留高级筛选,产品希望首版保留以支撑客户演示,研发认为当前实现会压缩回归窗口,价值诉求与交付窗口冲突,PM|ENG,2026-04-29,meeting:weekly-2026-04-23#topic:2,meeting:weekly-2026-04-23#action:3,WAITING_DECISION
```
