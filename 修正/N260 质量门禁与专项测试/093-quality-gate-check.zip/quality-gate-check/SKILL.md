---
name: quality-gate-check
description: generate workflow-aligned quality gate decisions from testcase assets, regression evidence, static-check outputs, specialty test results, and blocker state. use when chatgpt works in testing & qa / quality gate and specialty testing and must produce the n260 gate artifact for release readiness, conditional-go decisions, blocker tracking, or override review.
---
# quality-gate-check

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 质量门禁检查单.md. It delivers the authoritative workflow-aligned gate artifact for N260.

### Boundary
- Own gate aggregation, weighting, veto logic, pass-condition tracking, and override framing.
- Consume specialty test outputs rather than duplicating them.
- Do not fabricate pass results for specialty areas that are still pending evidence.
- Express decision rationale transparently enough for N270, N280, and N370 to consume.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_check`: aggregate available inputs fast without full history or override analysis.
- `full_gate`: produce the complete decision packet with weights, blocker registry, conditions, history, and override review.
- `what_if`: simulate how the conclusion changes if blockers close, dimensions improve, or overrides apply.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 上线前检查清单.csv
- 数据一致性检查项.csv
- 权限测试点.csv
- 并发测试点.csv
- 幂等测试点.csv
- 性能测试场景.csv
- blocker registry snapshots
- historical gate decisions
- release target or calendar context
- override requests or waiver records

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `gate_summary`
- `gate_dimensions[]`
- `aggregation_algorithm`
- `dimension_weights`
- `blocker_registry[]`
- `pass_conditions_machine_readable[]`
- `gate_history[]`
- `override_records[]`
- `decision_rationale`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: gate_aggregation_and_decision`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.quality_gate_check`
- `workflow_node: N260`
- `node_artifact_target: 质量门禁检查单.md`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Declare one aggregation algorithm explicitly: all_pass, weighted_threshold, or veto_based.
- Treat compliance and other hard-veto dimensions as explicit vetoes instead of hiding them in prose.
- Represent conditional-go conditions as machine-readable checks, not only narrative bullets.
- Show which specialty outputs and blockers drive each dimension status.
- Highlight overrides with owner, expiry, documented risk, and reevaluation trigger.

## Execution workflow / execution workflow
1. Collect specialty outputs, blocker state, and readiness evidence.
2. Normalize all gate dimensions and bind supporting check items to each dimension.
3. Apply the declared aggregation algorithm and compute provisional gate status.
4. Evaluate blocker state, pass conditions, and any override records.
5. Emit the final gate artifact with rationale, open risks, and downstream release handoff.

## Dynamic completeness / dynamic completeness
- If only partial specialty evidence exists, keep the gate artifact stable but mark dimensions as pending or conditional with explicit reasons.
- If one hard-veto dimension fails, surface that immediately even when weighted totals look high.
- For release-critical slices, include gate history and trend framing so stakeholders see movement, not only a snapshot.

## Quality bar / quality bar
A good artifact makes it obvious why the gate is pass, conditional-go, or no-go; which blockers remain; what must change to reach pass; and whether any override meaningfully changes risk.

## Reference files / reference files
- `references/gate-aggregation-models.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
