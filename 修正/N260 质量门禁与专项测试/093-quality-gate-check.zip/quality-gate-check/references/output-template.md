# Output Template: 质量门禁检查

## 默认结构
- `门禁结论`
- `已确认事实`
- `阻塞与高风险问题`
- `缺失证据`
- `复查条件`
- `建议动作`

## 推荐字段
| gate_type | item | gate_decision | priority | blocking_reason | evidence_ref | owner | next_action |
|---|---|---|---|---|---|---|---|

## 聚合判定规则
- `pass`: 无 blocker，且关键证据完整。
- `constrained`: 可推进，但存在必须跟踪的缺口或条件。
- `blocked`: 关键证据缺失，或存在未缓解 blocker。

## 禁止
- ❌ 把“建议补测”写成“已经通过”。
- ❌ 没有依据就直接给 go/no-go。
- ❌ 混用专项状态与最终门禁审批状态。
