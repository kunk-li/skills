# Gate aggregation models

- `all_pass`: every dimension must be pass.
- `weighted_threshold`: compute weighted score with pass=100, conditional=70, pending=50, fail=0.
- `veto_based`: any configured hard-veto dimension fail forces no-go before weighted scoring.

## Recommended defaults
- Use `veto_based` when compliance, security, or data integrity can block release independently.
- Use `weighted_threshold` for broader portfolio governance where some dimensions can be conditional.
- Keep `all_pass` for the strictest regulated flows.
