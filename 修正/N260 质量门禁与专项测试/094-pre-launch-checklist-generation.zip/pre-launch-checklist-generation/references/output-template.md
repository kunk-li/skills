# Output Template: 上线前检查清单

## 推荐 csv 字段
`pre_id | category | item | severity | owner | verify_method | acceptance | evidence_ref | status`

## 必覆盖
- 代码 / 部署 / 安全 / 监控 / 回滚 五大维度各至少 1 组
- 每项必须有 `owner` 与 `acceptance`
- 缺证时用 `todo` 或 `待确认` 明示

## 规模参考
- 小版本：20-40 条
- 中版本：40-80 条
- 大版本：80-150 条

## 禁止
- ❌ 无 owner
- ❌ 无 acceptance
- ❌ 用泛泛描述替代可验证动作
