# Launch checklist categories

Recommended universal categories:
- code_ready
- environment
- configuration
- data_migration
- monitoring_alerting
- rollback_readiness
- communication
- on_call_staffing
- runbook_documented
- stakeholder_signoff
