---
name: pre-launch-checklist-generation
description: generate workflow-aligned pre-launch readiness checklists from gate evidence, testcase assets, specialty readiness signals, and release context. use when chatgpt works in testing & qa / quality gate and specialty testing and must produce the n260 pre-launch checklist artifact before release preparation, environment validation, or stakeholder signoff.
---
# pre-launch-checklist-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 上线前检查清单.csv. It delivers the high-level release-readiness checklist artifact for N260.

### Boundary
- Own cross-cutting release-readiness checks, timing windows, evidence capture, and signoff routing.
- Do not restate deep specialty assertions that belong to data consistency, permission, concurrency, idempotency, or performance skills.
- Consume gate and specialty completion status as meta-evidence.
- Keep launch timing, ownership, and proof requirements explicit.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `minimal_launch`: produce a small-project or low-risk release checklist with the minimum mandatory categories.
- `enterprise_launch`: produce a full multi-owner, evidence-rich checklist for larger or higher-risk releases.
- `template_by_industry`: adapt category emphasis and signoff pressure for industry-specific release governance.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 质量门禁检查单.md
- 发布说明草案
- change calendar constraints
- 值班排班计划
- rollback rehearsal evidence
- customer communication plan
- deployment topology
- environment inventory

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `launch_scope_summary`
- `category_summary[]`
- `checklist_items[]`
- `time_window_plan[]`
- `signoff_matrix`
- `evidence_requirements[]`
- `open_gaps[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: release_readiness_meta_checks`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.pre_launch_checklist_generation`
- `workflow_node: N260`
- `node_artifact_target: 上线前检查清单.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Group checks into clear pre-launch categories instead of one flat list.
- Separate T-14d, T-7d, T-3d, T-1d, T-1h, T+1h, and T+24h windows when relevant.
- Require evidence and named verifier for every non-trivial check item.
- Use signoff routing to make ownership and escalation visible.
- Reference specialty completion as meta-checks instead of duplicating specialty content.

## Execution workflow / execution workflow
1. Read gate status, specialty readiness, release scope, and environment context.
2. Choose minimal or enterprise framing and group checks by pre-launch category.
3. Assign each check a time window, verifier, evidence expectation, and signoff path.
4. Flag open gaps that must be resolved before release approval.
5. Emit checklist rows ready for N270 and N280 execution tracking.

## Dynamic completeness / dynamic completeness
- Small releases can keep the checklist lean, but still require code, environment, monitoring, rollback, and ownership visibility.
- If gate status is conditional or no-go, surface launch blockers directly in the checklist rather than burying them.
- If release context is incomplete, keep categories and signoffs stable while marking missing evidence explicitly.

## Quality bar / quality bar
A good artifact tells the team exactly what must be checked, by whom, when, with what evidence, and what still blocks launch.

## Reference files / reference files
- `references/launch-checklist-categories.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
