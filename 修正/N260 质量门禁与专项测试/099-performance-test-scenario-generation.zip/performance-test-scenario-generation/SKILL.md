---
name: performance-test-scenario-generation
description: generate workflow-aligned performance test scenarios from testcase assets, performance-risk evidence, gate context, and service-level targets. use when chatgpt works in testing & qa / quality gate and specialty testing and must produce the n260 performance specialty artifact before release gating, baseline comparison, or capacity validation.
---
# performance-test-scenario-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 性能测试场景.csv. It delivers the performance specialty artifact for N260.

### Boundary
- Own performance test-type selection, baseline comparison framing, data-volume alignment, monitoring stack requirements, and reproducibility rules.
- Consume performance-risk analysis and testcase assets from upstream nodes.
- Do not collapse performance into one generic load test; separate load, stress, spike, soak, and capacity purposes.
- Make benchmark quality and repeatability visible, not only latency targets.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `load_test_only`: focus on standard load validation against SLO or release thresholds.
- `full_spectrum`: cover load, stress, spike, soak, and capacity perspectives.
- `continuous_perf`: shape scenarios for recurring or CI-integrated performance validation.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 性能风险分析.md
- service SLO definitions
- production baseline history
- test environment capacity profile
- anonymized production snapshots
- monitoring dashboard links

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `perf_scope_summary`
- `scenario_rows[]`
- `perf_test_types[]`
- `baseline_comparison`
- `data_volume_alignment`
- `monitoring_stack`
- `reproducibility_plan`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: performance_baseline_and_slo_validation`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.performance_test_scenario_generation`
- `workflow_node: N260`
- `node_artifact_target: 性能测试场景.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Assign each scenario one performance test type and clear objective.
- Compare current targets against a baseline or state why no reliable baseline exists yet.
- Check data volume realism before trusting any result.
- Specify the full monitoring stack needed to interpret the run.
- Require reproducibility rules so outlier runs do not drive gate decisions blindly.

## Execution workflow / execution workflow
1. Read performance-risk evidence, target SLOs, testcase assets, and environment capacity context.
2. Choose the required performance test types and define scenario rows with load shape and acceptance thresholds.
3. Attach baseline comparison, data-volume alignment, and monitoring requirements.
4. Add reproducibility rules, warm-up assumptions, and repeat-run expectations.
5. Emit gate-ready performance rows and downstream release/operations handoff.

## Dynamic completeness / dynamic completeness
- At minimum, define load and stress perspectives; core services should extend into spike, soak, or capacity modes when risk justifies it.
- If production-like data volume is unavailable, surface trust limits explicitly.
- If monitoring is incomplete, mark the result as low-confidence rather than overstating pass claims.

## Quality bar / quality bar
A good artifact states what performance question is being asked, what load shape answers it, how results compare to baseline, and whether the evidence is trustworthy enough for a gate decision.

## Reference files / reference files
- `references/performance-scenario-matrix.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
