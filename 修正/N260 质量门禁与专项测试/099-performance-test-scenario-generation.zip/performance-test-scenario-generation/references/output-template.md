# Output Template: 性能测试场景

## 推荐 csv 字段
`pf_id | scenario | load_model | target_object | slo | metric | bottleneck_hint | evidence_ref | status`

## 必覆盖
- 吞吐、时延、资源占用至少覆盖两类
- 对关键链路写清负载模型与 slo
- 对高风险场景给出瓶颈观察点或降级触发点

## 禁止
- ❌ 只写“压测一下”不写负载模型
- ❌ 不写 p95/p99、吞吐或资源指标
