# Performance scenario matrix

Supported performance test types:
- `load`
- `stress`
- `spike`
- `soak`
- `capacity`

Each scenario should declare:
- target qps or concurrency
- duration
- success criteria
- required telemetry
- baseline reference or no-baseline note
