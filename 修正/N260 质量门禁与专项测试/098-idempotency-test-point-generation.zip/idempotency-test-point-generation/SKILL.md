---
name: idempotency-test-point-generation
description: generate workflow-aligned idempotency test points from testcase assets, idempotency design, gate context, and retry-risk evidence. use when chatgpt works in testing & qa / quality gate and specialty testing and must produce the n260 idempotency specialty artifact before release gating, retry safety review, or multi-channel duplicate-handling validation.
---
# idempotency-test-point-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 幂等测试点.csv. It delivers the idempotency specialty artifact for N260.

### Boundary
- Own duplicate-request, retry, TTL, multi-channel, and degraded-store idempotency cases.
- Consume idempotency design and test assets rather than restating API contracts generically.
- Do not reduce the topic to same-key/same-payload only; handle degraded and non-HTTP channels too.
- Make timeout and retry realism explicit where possible.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `http_only`: focus on HTTP APIs and request-key semantics.
- `multi_channel`: cover HTTP, consumer, webhook, scheduler, and saga-step idempotency surfaces.
- `chaos_mode`: combine retry and duplicate behavior with network disturbance or store outages.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 幂等设计建议.md
- 消息消费者定义
- webhook contracts
- scheduler retry policy
- TTL policy
- network fault tooling
- duplicate-event history

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `channel_scope_summary`
- `idempotency_test_patterns[]`
- `ttl_boundary_tests[]`
- `network_simulation_plan`
- `channel_coverage[]`
- `negative_case_matrix[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: retry_safety_and_dedup_validation`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.idempotency_test_point_generation`
- `workflow_node: N260`
- `node_artifact_target: 幂等测试点.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Cover same-key same-payload, same-key different-payload, missing-key, invalid-key, TTL, degraded-store, concurrent duplicate, and timeout-retry cases.
- Treat HTTP, message, webhook, scheduler, and saga-step surfaces separately when they exist.
- Use realistic network or timeout simulation whenever retry safety depends on transport behavior.
- State what the canonical duplicate outcome should be: replay, reject, or reprocess.
- Mark any shared overlap with concurrency or data-consistency checks through shared IDs.

## Execution workflow / execution workflow
1. Read idempotency design, retry assumptions, testcase assets, and channel context.
2. Choose HTTP-only or multi-channel framing and map required patterns.
3. Add TTL boundary and degraded-store cases, then specify network simulation where valuable.
4. Define the expected outcome for each duplicate or retry pattern.
5. Emit gate-ready idempotency rows and downstream handoff for release and operations.

## Dynamic completeness / dynamic completeness
- Simple synchronous APIs can stay HTTP-focused; webhooks, consumers, and sagas require multi-channel coverage.
- If TTL policy is unknown, keep explicit open questions rather than assuming expiry behavior.
- If store-availability assumptions are weak, separate strong claims from exploratory chaos cases.

## Quality bar / quality bar
A good artifact makes duplicate handling expectations unambiguous, degraded cases explicit, and retry behavior believable under real transport conditions.

## Reference files / reference files
- `references/idempotency-key-patterns.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
