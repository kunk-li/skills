# Idempotency pattern anchors

Recommended baseline patterns:
- same_key_same_payload
- same_key_diff_payload
- diff_key_same_payload
- key_missing_when_required
- key_format_invalid
- key_ttl_expired
- degraded_store_with_db_fallback
- fully_degraded_duplicate_store
- concurrent_same_key
- retry_after_timeout
