# Output Template: 幂等测试点

## 推荐 csv 字段
`it_id | key_pattern | object | trigger | expected_behavior | window | dedup_storage | evidence_ref | status`

## 必覆盖
- 至少覆盖一种 key 模式和一种冲突模式
- 明确同 key 同 payload 与同 key 不同 payload 的预期差异
- 对 mq 或异步消费链路写出去重存储位置

## 禁止
- ❌ 把“防重复提交”写成泛泛口号
- ❌ 不区分 key 模式与业务对象
