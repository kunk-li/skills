# Output Template: 并发测试点

## 推荐 csv 字段
`ct_id | race_type | object | trigger | concurrency_level | expected_behavior | lock_strategy | evidence_ref | status`

## 必覆盖
- 写写冲突或唯一性竞争至少一类
- 对关键链路给出并发量级或压测档位
- 说明期望行为是串行化、拒绝、重试还是幂等吸收

## 禁止
- ❌ 只写“多点几次”这种不可执行描述
- ❌ 不写并发量级与触发方式
