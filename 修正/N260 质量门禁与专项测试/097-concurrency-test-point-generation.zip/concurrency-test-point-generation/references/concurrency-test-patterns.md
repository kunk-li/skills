# Concurrency scenario catalog

Suggested scenario anchors:
- create_unique
- update_same_record
- balance_adjustment
- state_transition
- sequential_operation
- scheduled_batch
- distributed_claim
- cache_refresh
- leader_election
- resource_pool
- fan_out_fan_in
- external_callback_race
