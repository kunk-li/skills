# N260 共享字段契约

## 共享字段
- `id`: 各专项产物的唯一标识，例如 `pre_id`、`dc_id`、`pt_id`、`ct_id`、`it_id`、`pf_id`
- `priority`: `P0 / P1 / P2`
- `owner`: 团队、角色或责任人
- `status`: `pending / pass / fail / waived`
- `evidence_ref`: 截图、日志、case id、监控图或链接引用
- `severity`: `blocker / major / minor`

## 共享约束
- 同一行只表达一个检查点，不把多个动作揉成一句话。
- `status` 表示当前验证状态，不表示最终上线审批结果。
- `evidence_ref` 允许为空，但必须显式标为 `todo` 或 `tbd`，不能静默缺失。
- `priority` 与 `severity` 不等价：前者是处理优先级，后者是风险影响等级。

## 专项扩展字段
- 094: `category / verify_method / acceptance`
- 095: `consistency_type / expected_behavior / recovery`
- 096: `role / resource / action / expected_result`
- 097: `race_type / concurrency_level / lock_strategy`
- 098: `key_pattern / window / dedup_storage`
- 099: `scenario / load_model / slo / metric`
- 093: `gate_type / gate_decision / blocking_reason / next_action`
