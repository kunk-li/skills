# Real Examples

## Example 1: pass
输入：发布说明、专项清单、监控配置、回滚脚本、测试结果齐全。
输出：完整专项表格，`status` 大多为 `pass`，门禁结论为 `pass`，只保留少量低风险观察项。

## Example 2: constrained
输入：核心证据存在，但部分接口日志、监控截图或 owner 缺失。
输出：保留 `confirmed` 项，同时把缺证项列入 `blocked/todo`，结论为 `constrained`，并写明复查条件。

## Example 3: blocked
输入：只有口头描述，没有正式发布材料或测试证据。
输出：仅生成最小必要清单或最小风险提醒，结论不做放行判断，明确标记 `blocked` 与缺失证据。
