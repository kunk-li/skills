# Data consistency kinds

- `CC01 within_database`
- `CC02 across_databases`
- `CC03 master_replica`
- `CC04 db_cache`
- `CC05 db_search_index`
- `CC06 cross_service`
- `CC07 external_system`

For each kind, declare whether the expected model is strong, eventual, or eventual-with-lag-bounds.
