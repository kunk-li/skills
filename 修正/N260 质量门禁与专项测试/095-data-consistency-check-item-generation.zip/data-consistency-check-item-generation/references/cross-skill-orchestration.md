# N260 collaboration matrix

## Shared principles
- Bind every specialty check item to one or more `gate_dimensions[]` so aggregation is machine-readable.
- Keep a `blocker_registry[]` with status, blocking dimensions, evidence, and close criteria.
- De-duplicate overlapping checks across data consistency, permission, concurrency, and idempotency before emitting final rows.
- Recompute gate state whenever blocker status, pass condition status, or override status changes.

## Cross-skill handoff
- `quality-gate-check` consumes normalized outputs from all six specialty skills and emits the authoritative gate decision.
- `pre-launch-checklist-generation` consumes gate state and specialty completion summaries but does not repeat specialty check details.
- `data-consistency-check-item-generation`, `permission-test-point-generation`, `concurrency-test-point-generation`, `idempotency-test-point-generation`, and `performance-test-scenario-generation` each emit rows that can be traced into gate dimensions.

## De-duplication guidance
- If two specialty skills describe materially the same assertion, keep one canonical row and link the other via `deduplicated_links[]`.
- Use shared IDs when permission changes affect data consistency, or when concurrency and idempotency checks share the same race surface.

## Downstream readiness
- N270 consumes gate decision, blocker state, and pre-launch readiness.
- N280 consumes launch checklist timing, evidence, and environment checks.
- N370 may consume gate rationale, override records, and blocker trends for platform-level routing or escalation.
