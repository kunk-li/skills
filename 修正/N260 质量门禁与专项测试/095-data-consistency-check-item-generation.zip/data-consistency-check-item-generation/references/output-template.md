# Output Template: 数据一致性检查项

## 推荐 csv 字段
`dc_id | consistency_type | object | trigger | expected_behavior | recovery | evidence_ref | status`

## 必覆盖
- 缓存 / 消息 / 事务 / 最终一致性 四类至少覆盖相关项
- 说明触发条件、期望表现与恢复方式
- 结果缺证时必须保留 `待确认`

## 禁止
- ❌ 只写“数据一致”而不写对象和触发条件
- ❌ 忽略恢复或补偿路径
