---
name: data-consistency-check-item-generation
description: generate workflow-aligned data consistency check items from testcase assets, data-flow evidence, gate context, and nonfunctional design signals. use when chatgpt works in testing & qa / quality gate and specialty testing and must produce the n260 data-consistency artifact before release gating, reconciliation planning, or remediation design.
---
# data-consistency-check-item-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 数据一致性检查项.csv. It delivers the specialty consistency-check artifact for N260.

### Boundary
- Own consistency-kind selection, reconciliation checks, failure scenarios, and remediation paths.
- Cover within-database, cross-database, cache, search index, cross-service, and external-system consistency without collapsing them into one generic list.
- Do not replace performance or permission testing; link overlap through de-duplication rather than repetition.
- Make eventual-vs-strong consistency expectations explicit.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `within_db_only`: focus on same-database consistency, constraints, and repair checks.
- `distributed_mode`: cover multi-database, cross-service, cache, and external-system consistency.
- `continuous_reconciliation`: design checks suitable for recurring or continuous reconciliation rather than one-off validation.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 表结构设计草案.sql
- 索引建议清单.csv
- 审计留痕方案.md
- 事件定义或topic清单
- cache topology
- external system contracts
- repair runbooks

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `consistency_scope_summary`
- `check_items[]`
- `consistency_kind_matrix[]`
- `failure_scenarios[]`
- `remediation_strategies[]`
- `deduplicated_links[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: consistency_and_reconciliation_planning`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.data_consistency_check_item_generation`
- `workflow_node: N260`
- `node_artifact_target: 数据一致性检查项.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Assign one consistency_kind to every row and make the expected consistency model explicit.
- Cover both nominal and degraded scenarios such as replica lag, cache miss storms, message backlog, or network partitions.
- Prefer remediation-aware checks over alarm-only rows when a repair path is known.
- Mark overlaps with permission, concurrency, or idempotency checks instead of duplicating them blindly.
- Call out the data source, reconciliation method, and acceptance threshold for each check.

## Execution workflow / execution workflow
1. Read data-flow, schema, testcase, and nonfunctional context relevant to consistency surfaces.
2. Choose consistency kinds and enumerate check rows with method, threshold, and evidence expectations.
3. Add degraded or recovery scenarios for each important consistency surface.
4. Attach remediation or recovery guidance where feasible.
5. Emit de-duplicated rows ready for gate aggregation and release-readiness handoff.

## Dynamic completeness / dynamic completeness
- Simple services can focus on within-db and db-cache checks; distributed flows should expand into cross-service and external-system models.
- If topology is unclear, keep row structure stable and mark topology assumptions openly.
- When eventual consistency is accepted, define lag bounds and reconciliation cadence instead of pretending strong consistency.

## Quality bar / quality bar
A good artifact makes it clear what consistency promise is expected, how it will be checked, what failure modes matter, and how the team recovers when drift is found.

## Reference files / reference files
- `references/data-consistency-types.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
