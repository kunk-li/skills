# Permission test dimensions

Minimum dimensions to consider:
- matrix completeness
- direct privilege escalation
- indirect privilege escalation
- horizontal access abuse
- contextual authorization
- delegation / temporary token lifecycle
- separation of duties
