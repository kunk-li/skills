# Output Template: 权限测试点

## 推荐 csv 字段
`pt_id | role | resource | action | expected_result | channel | mask_rule | evidence_ref | status`

## 必覆盖
- 至少包含允许与拒绝两个方向
- 高风险资源必须覆盖字段级与渠道级限制
- 对临时授权或撤销场景给出时效性测试点

## 禁止
- ❌ 只写“越权测试”而不写角色、资源和动作
- ❌ 忽略脱敏或字段可见性
