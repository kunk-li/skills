---
name: permission-test-point-generation
description: generate workflow-aligned permission and authorization test points from testcase assets, permission matrices, gate context, and nonfunctional authorization design. use when chatgpt works in testing & qa / quality gate and specialty testing and must produce the n260 permission specialty artifact before release gating, access review, or compliance checks.
---
# permission-test-point-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 权限测试点.csv. It delivers the authorization specialty artifact for N260.

### Boundary
- Own permission matrix coverage, denial coverage, escalation resistance, contextual authorization, delegation, and SoD checks.
- Consume permission design and matrix artifacts rather than re-deriving the model from scratch.
- Do not replace security architecture review; focus on executable or checklist-ready authorization test points.
- Make allow, deny, and delegated cases equally visible.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `rbac_only`: focus on role-resource-action matrix coverage and straightforward allow/deny cases.
- `abac_mode`: add contextual policies such as time, geography, org scope, or state-based access.
- `sod_audit`: focus on separation-of-duties, delegation, and high-risk authorization edges.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 权限模型设计.md
- 审计留痕方案.md
- delegation policy
- temporary token policy
- 组织结构或租户边界
- identity provider claims mapping

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `matrix_scope_summary`
- `permission_cells[]`
- `test_points[]`
- `privilege_escalation_tests[]`
- `contextual_permission_tests[]`
- `delegation_tests[]`
- `sod_tests[]`
- `missing_matrix_cells[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: authorization_and_sod_validation`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.permission_test_point_generation`
- `workflow_node: N260`
- `node_artifact_target: 权限测试点.csv`
- `evidence_profile`
- `tool_collaboration_mode`

## Design rules / design rules
- Ensure every role-resource-action cell has an allow or deny test representation.
- Test direct escalation, indirect escalation, and horizontal access abuse separately.
- Represent contextual rules with explicit clocks, state assumptions, or environment assumptions.
- Cover delegation and temporary-token lifecycles when they exist.
- Treat SoD rules as first-class test points rather than narrative notes.

## Execution workflow / execution workflow
1. Read the permission matrix, authorization design, testcase context, and gate needs.
2. Normalize the matrix into allow and deny cells, then identify missing or risky coverage.
3. Add escalation, contextual, delegation, and SoD scenarios where relevant.
4. Mark overlaps with data consistency or audit checks through shared IDs.
5. Emit gate-ready permission rows and downstream release notes.

## Dynamic completeness / dynamic completeness
- Simple RBAC modules can stay matrix-driven; richer ABAC or delegated-access flows must expand contextual coverage.
- If the permission matrix is incomplete, surface missing cells instead of pretending test completeness.
- If compliance or PII access is involved, elevate denial and audit assertions explicitly.

## Quality bar / quality bar
A good artifact makes it easy to see who should be allowed, who must be denied, where escalation could happen, and which permission edges still lack evidence.

## Reference files / reference files
- `references/permission-test-dimensions.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
