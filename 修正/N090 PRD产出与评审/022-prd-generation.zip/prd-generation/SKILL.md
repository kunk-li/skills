---
name: prd-generation
description: generate a review-ready prd draft from structured requirement outputs, requirement notes, business rules, state transitions, permissions, screenshots, prototype analyses, and upstream quality findings. use when the user needs a formal prd draft or prd skeleton that can be reviewed, circulated, or handed off, rather than scattered requirement fragments. especially useful after requirement breakdown, prototype analysis, rule extraction, state mapping, permission extraction, or quality review, and also useful for legacy-system documentation backfill, refactor baseline documentation, and migration-prd drafting.
---

# PRD Generation

生成可评审的 PRD 主稿。该 skill 是 N090 链路中的 **Stage A**，负责把结构化需求材料沉淀成统一主稿，为后续补齐和评审提问提供稳定底座。

## Usage modes / 使用模式
### Single-skill value / 单独使用价值
- 仅基于原始 PRD、需求笔记或碎片化需求材料即可独立生成可评审主稿。
- 没有 023/024 或其他结构化上游时，也必须给出 16 节完整骨架，并把缺失内容显式标到对应章节。

### Standalone use cases / 独立使用场景
- 新项目从 0 到 1 的 PRD 起草。
- 旧系统 / 既有版本的文档化反向补全。
- 重构、迁移、合规整改前的 baseline PRD 沉淀。
- 评审前把散乱需求笔记收敛成统一文档。

### Multi-skill value / 组合使用价值
- 与 023 `prd-completion` 组合时，可把主稿中的缺口转成章节级补齐动作。
- 与 024 `prd-review-question-generation` 组合时，可把 `PRD-XX` 章节直接转成评审问题和决策议程。
- 与 N070/N080 输出组合时，可把对象、规则、状态、权限和原型证据统一落章。

## Fallback behavior / 降级策略
- 若只有原始需求片段或会议笔记，仍要生成 PRD 骨架，并在不确定位置写 `待确认`。
- 若缺少结构化规则、状态、权限或对象材料，不得静默补完；把缺失内容沉淀到 `PRD-15 待确认项` 或相关章节的待确认子节。
- 若没有质量审查或补全结果，仍可单独生成主稿，但必须说明当前版本缺少评审前补齐输入。

## PRD type variants / PRD 类型分支
- 先识别当前 PRD 更接近 `new product / enhancement / refactor / migration` 中的哪一类。
- 无论属于哪一类，都必须保留 `PRD-01` 到 `PRD-16`。
- 章节重心按 `references/prd-type-variants.md` 调整，但不得因为是增强或迁移就删节。

## Inputs

接受以下任意组合输入：
- structured requirement output
- upstream requirement analysis outputs
- raw requirement notes or pasted PRD fragments
- business rules, state flows, permissions, and data objects
- screenshots, prototype notes, or page analyses
- quality review findings or pending-item lists

## Core goal

输出必须是 **可评审 PRD 主稿**，不是摘要，不是点评，不是散点笔记。

## Mandatory structure

除非用户明确要求另一种输出格式，否则 **必须** 使用 `references/output-template.md` 中定义的 **16 节固定结构**，并保留章节 ID：
- `PRD-01` 到 `PRD-16`

允许在章节内部增加子节，但不得跳过任何主节。信息不足时，也要保留该节并标记 `待确认`。

## Required writing contract

每次输出都必须显式区分：
- **已确认事实**
- **合理归纳**
- **待确认项**

不得把三层内容混写成一个结论。

## Workflow

每次都按以下顺序执行：

1. 先识别输入证据层级：Primary / Upstream / Secondary。
2. 先搭 16 节骨架，再回填内容。
3. 为每节分配 `PRD-XX` ID，并尽量写明来源依据。
4. 若存在 N080 上游，显式保留 `P- / FT- / ACT- / FLD-` 作为 cross-reference。
5. 把 scope、roles、flows、rules、states、permissions、data、exceptions、constraints、acceptance 全部显式落章。
6. 执行全局约束扫描：红线/合规、幽灵实体、跨模块联动缺口。
7. 若已有质量审查或补全结果，抽出 blocker 形成 `评审前提 / 已知缺口` 子节，但不得替代正式章节。
8. 信息不足时，保留章节、缩短正文，并把不确定内容移入 `PRD-15 待确认项`。
9. 交付前用 `references/checklist.md` 自检，并按 `references/scoring-rubric.md` 自评分。

## Cross-node alignment / 跨节点对齐
- `PRD-04`、`PRD-05` 优先保留页面或场景锚点 `P-{module}-{nn}`。
- `PRD-06` 若已有 N080 feature catalog，优先复用 `FT-...` 作为功能点引用。
- `PRD-09` 若已有动作目录，优先复用 `ACT-...` 作为权限动作锚点。
- `PRD-10` 和 `PRD-11` 若已有字段目录，优先复用 `FLD-...` / `F{seq}`。
- 不得因为 N090 自己有 `PRD-XX`，就抹掉上游实体 ID。

## Grounding rules

- 不得声称已经最终定稿、签字通过或可直接上线。
- 不得发明指标、上线时间、owner、排期、接口实现细节。
- 不得把缺失决策静默补成既定事实。
- 必须优先使用表格呈现 rules、states、permissions、data、exceptions、acceptance。
- 必须让新人读者能先看懂业务背景，再读细节。
- 必须遵守 `references/N090_COMMON_CONTRACTS.md`。

## Collaboration contract

- **上游**：需求拆解、业务规则抽取、状态梳理、权限提取、原型解析、质量审查结果。
- **下游**：023 `prd-completion`、024 `prd-review-question-generation`。
- **交接要求**：下游必须能按 `PRD-XX` 章节 ID 精确引用本输出。

## Boundary reminders

- 阶段边界：止于需求理解、结构化与文档化，不进入研发方案设计和代码实现。
- 动作边界：负责生成文档主稿，不代替补齐清单和评审问题。
- 若用户要求 JSON、CSV、清单等格式，可以改表现形式，但仍需覆盖同等信息密度与追溯性。

## Reference files

- `references/output-template.md`: 强制 16 节模板与章节 ID
- `references/section-guidance.md`: 分节写作指导
- `references/prd-type-variants.md`: 新需求 / 增强 / 重构 / 迁移的章节重心差异
- `references/checklist.md`: 交付前检查清单
- `references/scoring-rubric.md`: 质量评分标准
- `references/orchestration.md`: 单 skill / 多 skill 编排与阶段顺序
- `references/example-io.md`: 输入输出示例
- `references/common-failure-modes.md`: 常见失败模式
- `references/N090_COMMON_CONTRACTS.md`: N090 共同契约
