# Common Failure Modes

1. Producing a long summary instead of a PRD draft.
2. Hiding unresolved items in prose instead of using a dedicated section.
3. Omitting acceptance criteria or review-ready acceptance notes.
4. Mixing confirmed facts with inferred content.
5. Repeating upstream analysis without consolidating it into document form.
6. Skipping exceptions, edge cases, or non-functional constraints.
7. Writing a draft that only experts can understand.
