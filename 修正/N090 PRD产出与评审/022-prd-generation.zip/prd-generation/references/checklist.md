# Delivery Checklist

交付前确认：

- 是否保留了全部 16 个主节，并带有 `PRD-01` 到 `PRD-16`？
- 是否把 已确认事实 / 合理归纳 / 待确认项 分层表达？
- 是否显式写出了 scope、roles、flows、rules、states、permissions、data、exceptions、constraints、acceptance？
- 是否完成了红线/合规、幽灵实体、跨模块联动三类全局约束扫描？
- 是否把 unresolved blocker 放进 `PRD-15 待确认项`，而不是埋进正文？
- 是否让没有业务背景的新读者也能看懂前几节？
- 下游 023/024 能否直接按 `PRD-XX` 引用本稿？
