# Orchestration Guide

## Stage position
- 本 skill 是 **Stage A**。
- 标准链路：`022 prd-generation -> 023 prd-completion -> 024 prd-review-question-generation`。

## Single-skill mode
- 当用户只要求“生成 PRD 主稿”时，可单独使用。
- 即便单独使用，也必须保留完整 16 节，而不是输出摘要版 PRD。

## Multi-skill mode
- 若已有上游结构化结果，优先复用术语和结构，但不要机械复制上游内容。
- 为 023/024 提供稳定锚点：所有章节都要有 `PRD-XX`。
- 若发现输入质量不足，必须在 `PRD-15` 中显式暴露，留给 023/024 继续处理。

## Handoff requirement
- 023 必须能基于 `PRD-XX` 生成 `GAP-XXX`。
- 024 必须能基于 `PRD-XX` 与 `GAP-XXX` 生成 `Q-XXX`。
