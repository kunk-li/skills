# Section Guidance

## Background and goal
Start simple. A newcomer should understand what business problem this PRD addresses.

## Scope and non-scope
Be explicit. Avoid implied boundaries.

## Feature requirements
Use requirement IDs when the draft is large enough to benefit from them.
If N080 `FT-...` IDs exist, preserve them as cross-reference IDs instead of renaming them.

## Rules / states / permissions
These are high-risk sections. Prefer tables over long prose.
If N080 `ACT-...` IDs exist, keep them visible in permissions and edge-case sections.

## Data objects
Do not invent fields. If fields are incomplete, mark them as pending.
If N080 `FLD-...` IDs exist, keep them in field mapping or appendix columns.

## Exceptions and edge cases
Mention invalid flows, blocked operations, timeout handling, and risky parallel actions when source support exists.

## Acceptance criteria
Focus on reviewable behavior, not implementation details.

## Pending items
Phrase each item as a decision or confirmation point, not as a vague note.
