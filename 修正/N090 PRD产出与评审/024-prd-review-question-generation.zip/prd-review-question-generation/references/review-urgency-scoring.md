# Review Urgency Scoring

用于 `prd-review-question-generation` 的会议问题排序。

## 输入因子
- `blocking_level`：`blocker / major / minor`
- `deadline_proximity`：
  - `immediate`：本次评审会必须定
  - `near_term`：设计前必须定
  - `next_handoff`：交接前必须定
  - `open_end`：可以后续澄清

## 建议权重
- `blocking_weight`：`blocker=5, major=3, minor=1`
- `deadline_weight`：`immediate=4, near_term=3, next_handoff=2, open_end=1`

## 推荐计算
- `question_urgency_score = blocking_weight * deadline_weight`
- 在同一优先级内，按 `question_urgency_score` 从高到低排序。

## 解释要求
每个高优先级问题都应说明：
- 为什么现在必须问
- 谁必须回答
- 不决策会卡在哪个阶段
