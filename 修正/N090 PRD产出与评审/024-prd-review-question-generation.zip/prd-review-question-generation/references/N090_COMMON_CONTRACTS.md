# N090 Common Contracts

这份共同契约适用于 `prd-generation`、`prd-completion`、`prd-review-question-generation` 三个 skill，目的是让 022/023/024 在保持通用性的同时具备可复制的协同能力。

## C1. 输入分层契约

所有 skill 都必须按下列顺序判断证据权重：

1. **Primary inputs**：当前节点直接消费的核心输入。
2. **Upstream outputs**：上游 skill 的结构化结果，可复用但不得高于 Primary inputs。
3. **Secondary context**：原始笔记、截图、补充说明，仅用于辅助解释。

规则：
- 不得让 Secondary context 覆盖 Primary inputs。
- 上游结论若与 Primary inputs 冲突，必须显式标记为 `待确认`。
- 任何无法定位到证据层级的内容，不得写成既定事实。

## C2. 三层表达契约

每个 skill 的输出都必须显式区分：
- **已确认事实**：可以被输入直接支持。
- **合理归纳**：由多个事实稳定推导得到。
- **待确认项**：缺证据、缺裁决、缺 owner 的内容。

不得把三层混写在同一条结论里。

## C3. ID 命名空间契约

为保证跨 skill 追溯，统一使用以下 ID：

### 022 PRD section IDs
- `PRD-01` 文档信息与版本说明
- `PRD-02` 背景与目标
- `PRD-03` 范围与非范围
- `PRD-04` 角色与核心场景
- `PRD-05` 业务流程/页面或能力概览
- `PRD-06` 功能需求清单
- `PRD-07` 业务规则
- `PRD-08` 状态流转
- `PRD-09` 权限要求
- `PRD-10` 数据对象与关键字段
- `PRD-11` 异常与边界处理
- `PRD-12` 非功能与约束
- `PRD-13` 验收标准
- `PRD-14` 依赖与风险
- `PRD-15` 待确认项
- `PRD-16` 附录/参考输入

### 023 gap IDs
- 使用 `GAP-001`、`GAP-002`…
- 每个 gap 必须至少包含：`gap_id`、`gap_type`、`related_prd_sections`

### 024 question IDs
- 使用 `Q-001`、`Q-002`…
- 每个问题必须至少包含：`q_id`、`priority`、`related_prd_sections`
- 若 024 消费了 023 的结果，还必须尽量填写 `related_gap_ids`

## C3.1. 跨节点 ID 对齐契约（与 N080 对齐）

当 N080 原型解析结果存在时，必须保留其 ID，不得重命名或重新编号：
- `P-{module}-{nn}`：页面/容器锚点，优先在 `PRD-04`、`PRD-05` 引用。
- `FT-{module}-{page_seq}-{nn}`：功能点锚点，优先在 `PRD-06` 引用。
- `ACT-{module}-P{page_seq}-{nn}`：动作锚点，优先在 `PRD-09`、`PRD-11` 引用。
- `FLD-{module}-P{page_seq}-{nn}` 与 `F{seq}`：字段锚点，优先在 `PRD-10`、`PRD-11` 引用。

规则：
- `PRD-XX` 是 N090 内部章节 ID，不替代上游实体 ID。
- 上游实体 ID 应作为 cross-reference 使用，而不是被抹掉。
- 若 N080 与 PRD 表述冲突，必须保留冲突并标记为 `待确认`。

## C4. 双向反哺契约

- 023 和 024 发现的 blocker、红线、缺页、冲突项，必须能够反向指向 022 的 `PRD-XX` 章节。
- 当 023/024 发现“当前 PRD 根本没有对应章节内容”时，也必须引用最应该补入的 `PRD-XX`。
- 若发现上游输入缺失导致无法判断，需显式标记：
  - `upstream_missing`
  - `needs_prd_backfill`
  - `needs_review_decision`

## C5. 全局约束扫描契约

三个 skill 都必须显式扫描以下风险：

1. **红线/政策/合规约束**：是否存在触碰禁用词、合规红线、安全要求、审计要求但未落文档。
2. **幽灵实体/幽灵流程**：是否出现未定义角色、状态、对象、页面、权限动作。
3. **跨模块联动缺口**：是否出现流程前后不闭合、责任人缺失、source of truth 缺失、依赖未说明。

若扫描到风险，必须进入显式输出，而不是埋在正文中。

## C6. 阶段顺序契约

标准顺序：

- **Stage A / 022**：`prd-generation` 生成主稿。
- **Stage B / 023**：`prd-completion` 识别缺口并提出回填方案。
- **Stage C / 024**：`prd-review-question-generation` 把未决项转成会议问题与决策项。

规则：
- 024 若缺少 023，则必须说明“问题列表可能缺少 completion-derived gaps”。
- 023 若缺少 022，则必须说明“按 PRD 原文补齐，缺少统一主稿结构”。

## C7. 输出后自检契约

交付前必须至少自检以下 6 项：

1. 结构是否完整。
2. 事实/归纳/待确认是否分层。
3. ID 与追溯关系是否完整。
4. 是否完成 C5 全局约束扫描。
5. 是否对新人友好。
6. 是否可被下游直接消费。

## C8. 证据锚点契约

- 022 每章至少给出简短“来源依据”或在表格/段落中明确来源。
- 023 每个 gap 必须给出 `related_prd_sections`，必要时补 `evidence_note`。
- 024 每个问题必须给出 `related_prd_sections`，若来自 023 还需给出 `related_gap_ids`。
- 不允许出现“无法解释来源”的结论、gap 或问题。
