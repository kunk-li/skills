# Common Failure Modes

1. Asking generic filler questions that do not change design or delivery.
2. Listing too many low-value questions and hiding the blockers.
3. Failing to say why a question matters.
4. Omitting who should answer the question.
5. Turning unresolved questions into assumed answers.
6. Producing a brainstorming list instead of a meeting-ready agenda.
7. Asking duplicate questions that differ only in wording.
