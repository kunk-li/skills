# Scoring Rubric

## 1 - Weak
问题泛泛、无优先级、无追溯、无法驱动会议决策。

## 2 - Basic
有一些可用问题，但 blocker 不突出，缺少 why/consequence/responder，也没有紧迫度打分。

## 3 - Usable
问题清单可用于会议，P0/P1/P2 清晰，关键问题能推动确认，并有基础紧迫度排序。

## 4 - Strong
问题兼具优先级、追溯性、后果说明、紧迫度评分与决策对象，主持人可直接使用。

## 5 - Excellent
形成完整的会议风险叙事，`Q-XXX -> GAP-XXX -> PRD-XX` 追溯清晰，紧迫度排序可靠，会后决策项可直接落纪要。
