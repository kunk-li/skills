# Orchestration Guide

## Stage position
- 本 skill 是 **Stage C**。
- 标准链路：`022 prd-generation -> 023 prd-completion -> 024 prd-review-question-generation`。

## Single-skill mode
- 用户只有 PRD 时也可单独使用。
- 但必须说明：若缺少 023，则问题列表可能遗漏 completion-derived gaps。

## Multi-skill mode
- 若存在 023，优先把 `GAP-XXX` 转成 `Q-XXX`。
- 若存在质量审查结果，吸收 blocker，但避免与 gap 重复提问。
- 输出必须支持会后回溯：`Q-XXX -> GAP-XXX -> PRD-XX`。
