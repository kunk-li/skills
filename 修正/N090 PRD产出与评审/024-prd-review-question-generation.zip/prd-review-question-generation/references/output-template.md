# Output Template

除非用户明确要求另一种格式，否则 **必须按以下 5 节顺序输出**。

## 1. 开场风险摘要
- 简洁说明本次评审为什么重要，最大的 blocker 在哪里。

## 2. 最高优先级问题
- 先列 P0 问题，建议每条给 `Q-XXX`、`related_prd_sections`、必要时 `related_gap_ids`、`question_urgency_score`。

## 3. 分主题问题清单
- 优先用表格，建议列：
  - `q_id`
  - `priority`
  - `blocking_level`
  - `deadline_proximity`
  - `question_urgency_score`
  - `category`
  - `question`
  - `why_it_matters`
  - `consequence_if_unresolved`
  - `suggested_responder`
  - `decision_phase`
  - `related_prd_sections`
  - `related_gap_ids`

## 4. 建议参会角色
- 只列真正能回答问题的人/角色，不做泛泛罗列。

## 5. 会后必须形成的决策项
- 把最高优先级未决项改写成“会议结束前必须形成的决策”。
