---
name: prd-review-question-generation
description: generate high-value review questions, challenge points, decision prompts, and meeting-ready discussion items for a prd review. use when the user wants a structured question list that exposes ambiguity, missing rules, risky assumptions, ownership gaps, state-orchestration issues, failure handling gaps, or handoff risks before review. especially useful after prd-generation, prd-completion, or quality review, when the team needs not just questions but decision-oriented review prompts with suggested owners, consequences, and urgency scoring.
---

# PRD Review Question Generation

把 PRD 和补全缺口转成会议可用的问题、挑战点和决策项。该 skill 是 N090 链路中的 **Stage C**。

## Usage modes / 使用模式
### Single-skill value / 单独使用价值
- 仅基于 PRD 主稿也能独立产出会议可用的问题清单。
- 即使没有 023 补齐结果，也要交付可追溯、可决策的问题，而不是只说“信息不全”。

### Standalone use cases / 独立使用场景
- PRD 评审会前的问题准备。
- 项目 kickoff 前的关键决策问题梳理。
- 跨团队评审前的议题清单准备。
- 管理层或合规评审前的 blocker 汇总。

### Multi-skill value / 组合使用价值
- 与 022 `prd-generation` 组合时，可按 `PRD-XX` 精确定位问题来源。
- 与 023 `prd-completion` 组合时，可把 `GAP-XXX` 转成会议决策问题，并形成 `Q-XXX -> GAP-XXX -> PRD-XX` 的追溯链。

## Fallback behavior / 降级策略
- 若没有 023 输入，直接从 PRD 主稿识别 blocker / major / minor 问题，并显式说明缺少 gap 级追溯信息。
- 若输入只有零散需求说明，也要先归并问题主题，再输出会议问题清单。
- 若某些问题无法锁定 owner、后果或决策时点，必须保留问题本身，并把缺失信息写为 `待确认`，不得删题。

## Inputs

接受以下任意组合输入：
- a PRD draft
- PRD completion findings
- quality review findings
- supporting requirement notes
- screenshots or upstream analyses when helpful

强推荐输入顺序：022 PRD 主稿 + 023 补全建议。

## Core goal

产出必须优化“会议决策价值”，而不只是堆问题数量。

## Mandatory output

除非用户明确要求另一种格式，否则 **必须** 使用 `references/output-template.md` 中定义的固定结构：
1. 开场风险摘要
2. 最高优先级问题
3. 分主题问题清单
4. 建议参会角色
5. 会后必须形成的决策项

同时满足：
- 每个问题使用 `Q-XXX`
- 每个问题必须给出 `related_prd_sections`
- 若输入里有 023，则尽量给出 `related_gap_ids`
- 每个关键问题都应补 `blocking_level / deadline_proximity / question_urgency_score`
- 默认主输出应为 markdown；用户明确要 CSV/表格时，可额外附表，但不应默默退化成只有 csv

## Question taxonomy

优先从以下主题提问：
- 范围与边界
- owner / source of truth
- 状态编排与联动
- 权限边界与安全
- 失败补偿与异常
- 数据定义与字段口径
- 验收与测试
- 依赖与交接

## Question urgency / 问题紧迫度
- 若有 023 gap，优先使用其 `blocking` 级别作为 `blocking_level`。
- 再判断 `deadline_proximity`：本次评审必决 / 设计前必决 / 交接前必决 / 可后续澄清。
- 默认使用 `references/review-urgency-scoring.md` 中的模型计算 `question_urgency_score`。
- 在同一优先级内，按 `question_urgency_score` 从高到低排列。

## Workflow

每次都按以下顺序执行：
1. 先识别 blocker、major、minor 三档风险。
2. 若 023 存在，优先把 `GAP-XXX` 转成可决策问题；若缺 023，显式说明限制。
3. 按 `PRD-XX` 和 `GAP-XXX` 建立问题追溯关系。
4. 对最高优先级问题解释：为什么要问、谁来答、不决策会怎样、在哪个阶段必须决定。
5. 给关键问题补 `blocking_level / deadline_proximity / question_urgency_score`。
6. 执行全局约束扫描，优先暴露红线/合规、幽灵实体、跨模块联动缺口。
7. 合并重复问题，优先保留最能推动决策的表述。
8. 交付前用 `references/checklist.md` 自检，并按 `references/scoring-rubric.md` 自评分。

## Grounding rules

- 只问具体、可回答、会影响评审/设计/交接/实现的问题。
- 不得把未决问题写成既定答案。
- 不得输出大量 filler questions。
- 必须复用上游术语与 ID。
- 必须遵守 `references/N090_COMMON_CONTRACTS.md`。

## Collaboration contract

- 上游：022 `prd-generation`、023 `prd-completion`、需求质量审查。
- 下游：人工评审会议、会议纪要、需求交接包。
- 交接要求：会议主持人应能按 `Q-XXX -> GAP-XXX -> PRD-XX` 回溯问题来源。

## Boundary reminders

- 止于会议问题、挑战点、讨论提示和决策项，不代替技术方案与评审结论本身。
- 若用户明确要求 CSV，可附 CSV 风格表格，但默认仍要保留会议叙事结构。

## Reference files

- `references/output-template.md`: 强制会议输出结构
- `references/checklist.md`: 交付前检查清单
- `references/scoring-rubric.md`: 质量评分标准
- `references/review-urgency-scoring.md`: 问题紧迫度模型
- `references/meeting-facilitation-guide.md`: 会议主持与升级建议
- `references/orchestration.md`: 阶段顺序与多 skill 协作说明
- `references/example-io.md`: 输入输出示例
- `references/common-failure-modes.md`: 低价值问题模式
- `references/N090_COMMON_CONTRACTS.md`: N090 共同契约
