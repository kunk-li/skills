---
name: prd-completion
description: identify, classify, and complete missing but required prd information from a review, handoff, and downstream-delivery perspective. use when a prd draft or structured requirement package is missing scope, rules, actors, states, permissions, exceptions, ownership, source-of-truth definitions, acceptance criteria, or decision points, and the team needs a concrete backfill plan before serious review, design, or handoff. can be used standalone as a completion memo, or after prd-generation and quality review to turn identified gaps into actionable chapter updates with scored priority.
---
# prd-completion

把 PRD 缺失信息组织成“可回填、可追溯、可交接”的补齐方案。该 skill 是 N090 链路中的 **Stage B**。

## Single-skill value / 单独使用价值
- 仅基于 PRD 原文或结构化需求结果即可独立输出《PRD 待补齐清单》。
- 没有 022 主稿时，也必须产出可交接的 gap 清单、章节建议和最小补稿动作。

## Standalone use cases / 独立使用场景
- PRD 评审前的缺口盘点。
- 交接前的文档完整性体检。
- 合规、审计、质量 review 前的补稿清单整理。
- 老项目文档返工时的缺口治理。

## Multi-skill value / 组合使用价值
- 与 022 `prd-generation` 组合时，可把主稿缺口转成章节级补稿动作。
- 与 024 `prd-review-question-generation` 组合时，可把 `GAP-XXX` 直接转成评审问题底稿。

## Fallback behavior / 降级策略
- 若没有 022 输出，直接基于原始 PRD 或需求材料补齐，并显式说明当前模式为 `direct-from-source`。
- 若缺少结构化审查结果，仍要按章节输出 gap，但不要伪造 owner、优先级或 draft insert。
- 若某个 gap 无法稳定归类到标准 taxonomy，先记录为最接近的缺口类型，并在 `evidence_note` 里说明不确定性。

## Role / 角色定位
- 系统化识别 PRD 缺口。
- 把缺口落成章节级补稿动作，而不是泛泛点评。
- 为 024 和评审会提供可追溯的 `GAP-XXX` 底稿。

## Inputs / 输入边界
### Primary
- PRD 原文，或以 PRD 为唯一来源的结构化分析结果。

### Upstream (recommended)
- 022 `prd-generation` 输出。
- 需求质量审查结果、待确认项列表。

### Cross-reference (optional)
- 结构化需求四件套、原型摘录、评审会议纪要。

## Mandatory output

除非用户明确要求另一种格式，否则 **必须** 使用 `references/output-template.md` 中定义的固定结构输出，并遵守以下约束：
- 每个 gap 使用 `GAP-XXX`。
- 每个 gap 必须给出 `related_prd_sections`。
- 若 gap 会进入评审问题阶段，尽量补 `review_followup`。
- 每个 gap 都要补 `urgency_score / impact_score / resolution_difficulty_score / priority_score`。
- 必须包含“全局约束/红线扫描”章节，不得省略。

## Standard gap taxonomy / 标准缺口分类
默认使用以下缺口类型，并按最接近的一类归档：
- `missing_scope`
- `missing_rule`
- `missing_state`
- `missing_permission`
- `missing_data_definition`
- `missing_source_of_truth`
- `missing_owner`
- `missing_failure_result`
- `missing_audit_requirement`
- `missing_acceptance_criteria`
- `missing_orchestration`
- `missing_policy_definition`

若默认 taxonomy 明显不足，允许使用 `custom:<name>` 扩展，但必须遵守 `references/gap-taxonomy-extension.md`。

## Standard record format / 标准记录格式
每个 gap 至少给出：
- `gap_id`
- `gap_type`
- `section`
- `related_prd_sections`
- `finding`
- `impact`
- `minimal_fill`
- `suggested_owner`
- `blocking`
- `urgency_score`
- `impact_score`
- `resolution_difficulty_score`
- `priority_score`

能补时再补：
- `draft_insert`
- `review_followup`
- `evidence_note`

## Gap scoring / 缺口评分
- 必须使用三维评分模型对 gap 排序。
- 默认用 `priority_score = urgency_score * impact_score * resolution_difficulty_score`。
- 同分时先看 `blocking`，再看是否影响本次 review / design / handoff。
- 具体规则见 `references/gap-scoring-model.md`。

## Execution workflow / 执行流程
1. 先按 `PRD-XX` 章节重建 PRD 骨架，识别显式事实与已缺失章节。
2. 若有 022 结果，优先以其为主稿；若没有，明确说明是“直接基于原始 PRD 补齐”。
3. 先做 C5 全局约束扫描：红线/合规、幽灵实体、跨模块联动缺口。
4. 再按标准 taxonomy 归类缺口，避免只写“信息不全”。
5. 给每个 gap 打三维分，算出 `priority_score`，再排序。
6. 先给总览，再按章节给回填建议，再给最小补稿内容。
7. blocker 级缺口必须给出最小补齐动作，并指明建议 owner 或讨论对象。
8. 无法推断时，明确写入待确认项，不得伪造内容。
9. 用 `references/checklist.md` 自检，并按 `references/scoring-rubric.md` 自评分。

## Collaboration contract / 协作契约
- 上游：022 `prd-generation`、需求质量审查、原始 PRD。
- 下游：024 `prd-review-question-generation`、评审文档、需求交接包。
- 交接要求：024 必须能用 `GAP-XXX + related_prd_sections` 直接转为 `Q-XXX`。
- 必须遵守 `references/N090_COMMON_CONTRACTS.md`。

## Rules / 核心规则
- 必须把 已确认事实 / 推断建议 / 待确认项 分层书写。
- 必须优先面向新人、新手、非业务背景读者，先解释再下结论。
- 必须优先给出可执行的补稿动作，而不是泛泛点评。
- 必须尽量表格化呈现角色、对象、状态、规则、问题、风险、决策项。
- 必须显式指出应补入哪一个 `PRD-XX`。
- 不得把模糊内容写成既定事实。
- 不得只输出 3-5 条摘要结论冒充交付物。

## Reference files / 参考文件
- `references/output-template.md`：强制输出模板
- `references/checklist.md`：交付前检查清单
- `references/scoring-rubric.md`：质量评分标准
- `references/gap-scoring-model.md`：gap 三维评分模型
- `references/gap-taxonomy-extension.md`：taxonomy 扩展规则
- `references/common-failure-modes.md`：常见失败模式
- `references/orchestration.md`：单 skill / 多 skill 编排说明
- `references/example-io.md`：输入输出示例
- `references/N090_COMMON_CONTRACTS.md`：N090 共同契约
