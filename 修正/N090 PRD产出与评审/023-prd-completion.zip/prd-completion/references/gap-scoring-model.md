# Gap Scoring Model

用于 `prd-completion` 的缺口优先级排序。

## 三维评分
每个 gap 都应给出 1-5 分：
- `urgency_score`：离评审 / 设计 / 交接越近，分越高。
- `impact_score`：若不解决，对评审、设计、实现、交接影响越大，分越高。
- `resolution_difficulty_score`：越难补、越需要提前拉齐，分越高。

## 推荐计算
- `priority_score = urgency_score * impact_score * resolution_difficulty_score`
- 同分时按 `blocking` 级别排序：`blocker > major > minor`

## 解释要求
- 不得只给分数，不解释来源。
- 每个高分 gap 至少要解释：为什么紧急、为什么影响大、为什么不容易补。
