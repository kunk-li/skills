# Gap Taxonomy Extension

默认 taxonomy 仍是 N090 的 12 类标准缺口。只有在默认 taxonomy 无法准确描述缺口时，才允许扩展。

## 扩展规则
1. 优先尝试用默认 taxonomy 中最接近的一类。
2. 若确实不适用，可使用 `custom:<name>` 形式，例如：
   - `custom:missing_compliance`
   - `custom:missing_safety`
   - `custom:missing_reporting`
3. 使用自定义 taxonomy 时，必须补三项：
   - `custom_taxonomy_name`
   - `why_default_taxonomy_insufficient`
   - `classification_rule`
4. 自定义 taxonomy 不能只是换个说法；必须带来实质上的判定差异。

## 推荐扩展场景
- 强监管行业：`custom:missing_compliance_evidence`
- 安全关键系统：`custom:missing_safety_guardrail`
- 国际化产品：`custom:missing_regionalization_rule`
- 报表/财务系统：`custom:missing_reporting_definition`

## 仍然要保留的共性
- 每个 gap 仍必须有 `GAP-XXX`
- 仍必须给出 `related_prd_sections`
- 仍必须给出最小补齐动作
