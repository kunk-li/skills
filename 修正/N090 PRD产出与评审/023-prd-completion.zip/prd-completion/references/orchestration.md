# Orchestration Guide

## Stage position
- 本 skill 是 **Stage B**。
- 标准链路：`022 prd-generation -> 023 prd-completion -> 024 prd-review-question-generation`。

## Single-skill mode
- 当用户只有原始 PRD，仍可单独运行。
- 但必须说明“缺少统一 PRD 主稿结构”，并尽量重建 `PRD-XX` 映射关系。

## Multi-skill mode
- 若存在 022，优先消费 022 作为主稿。
- 若存在质量审查结果，吸收其中的 blocker，但不能只复制审查结论。
- 输出必须为 024 提供可直接转换的问题底稿：`GAP-XXX + related_prd_sections + review_followup`。

## Evidence hierarchy
1. 显式 PRD 事实
2. 多处事实支持的稳定归纳
3. 未裁决、未证明、未成文的待确认项
