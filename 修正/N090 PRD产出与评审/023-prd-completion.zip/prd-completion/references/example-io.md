# Example IO

## Example input
- 一份 022 生成的 PRD 主稿，包含 `PRD-01` 到 `PRD-16`。
- 其中 `PRD-11` 对失败处理写得很弱，`PRD-13` 缺少明确验收标准。

## Good output characteristics
- 输出 `GAP-001` 指向 `PRD-11`，说明失败结果未落文档。
- 输出 `GAP-002` 指向 `PRD-13`，给出最小验收标准骨架。
- `review_followup` 能直接被 024 改写为会议问题。
- 先有总览，再有章节回填建议，再有最小补稿内容。
