# Common Failure Modes

1. Writing only a summary instead of a working completion document.
2. Mixing fact, inference, and pending items in one paragraph.
3. Naming gaps without showing where they should be fixed in the PRD.
4. Giving generic suggestions like "补充信息" without a minimal-fill action.
5. Producing abstract design talk without modules, tables, or concrete examples.
6. Turning ambiguous PRD language into fake certainty.
7. Duplicating upstream analysis without adding completion value.
8. Failing to convert blocker gaps into reviewable questions or chapter-level edits.
