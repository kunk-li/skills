# Scoring Rubric

## 1 - Weak
只是泛泛点评 PRD 不完整，没有 gap id、没有章节回填建议、没有评分。

## 2 - Basic
能看出主要缺口，但追溯性和可执行性不足，taxonomy 和排序仍很弱。

## 3 - Usable
有明确 `GAP-XXX`、章节回填点、优先级和基础三维评分，可作为补稿清单使用。

## 4 - Strong
兼顾新人可读性、章节级回填、gap traceability、taxonomy 解释与下游复用价值。

## 5 - Excellent
不仅识别缺口，还完成全局约束扫描、taxonomy 治理、三维评分排序和 024-ready 的问题转化线索。
