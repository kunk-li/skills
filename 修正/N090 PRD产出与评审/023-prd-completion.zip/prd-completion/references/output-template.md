# Output Template

除非用户明确要求另一种格式，否则 **必须按以下顺序输出**。如信息不足，也必须保留章节并标记 `待确认`。

## 1. 文档用途 / How to use this document
- 说明谁来读、怎么用、是否用于评审前补稿。

## 2. 已确认事实
- 只列由 PRD 或上游结果直接支持的事实。

## 3. 背景与术语速读
- 面向新人解释业务背景与关键术语。

## 4. 全局约束 / 红线扫描
- 扫描红线/合规、幽灵实体、跨模块联动缺口。

## 5. 缺失信息总览
- 用表格列出 `gap_id / gap_type / related_prd_sections / blocking / urgency_score / impact_score / resolution_difficulty_score / priority_score`。

## 6. Gap taxonomy / 缺口分类
- 按标准 taxonomy 分组，不要只罗列散点问题。
- 若使用自定义 taxonomy，必须解释为什么默认 taxonomy 不足。

## 7. 按章节补齐建议
- 以 `PRD-XX` 为主键，说明应补到哪一章。

## 8. 建议回填草案
- 能补则给最小 draft insert、表格框架或段落骨架。

## 9. 无法推断项
- 不能补的必须保留为待确认。

## 10. 优先级排序
- 按 `priority_score` 排序，并补充是 review 前 / design 前 / handoff 前 必须关闭。

## 11. 影响说明
- 解释为什么这些 gap 会影响评审、设计、交接或实现。

## 12. 建议提问清单
- 把 blocker gap 转成评审会问题，并尽量给 `review_followup`。

## 13. 下一步
- 推荐下一步人工动作或下游 skill。
