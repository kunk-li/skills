---
name: post-release-validation-checklist
description: generate workflow-aligned post-release validation checklists from 验收标准.md, 发布说明.md, 发布任务编排表.csv, deployment evidence, and runtime baselines. use when chatgpt works in release & delivery / post-release validation and must produce the n290 发布后验证清单.csv artifact, prioritize p0/p1/p2 post-release checks, quantify baseline-based pass criteria, define active vs passive validation, connect related prvs across time windows, or feed go-live-acceptance-assistant with machine-readable prv results.
---
# post-release-validation-checklist

## Role / role positioning
This skill aligns to release & delivery -> post-release validation -> 发布后验证清单.csv. It is the authoritative N290 skill for designing what must be validated after deployment.

### Boundary
- Own PRV planning, checkpoint design, validation criteria, priority assignment, and post-release failure playbooks.
- Consume upstream N270/N280 release assets instead of recreating release strategy or deployment orchestration.
- Do not replace `go-live-acceptance-assistant` for GO / CONDITIONAL GO / NO-GO synthesis.
- Do not replace incident-analysis skills for runtime RCA after a failed validation item.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `rapid_prv`
- `comprehensive_prv`
- `continuous_prv`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `发布说明.md`
- `发布任务编排表.csv`

### optional enhancement inputs
- rollout timeline or traffic phase plan
- monitoring dashboards or query definitions
- risk register or release manifest
- pre-release performance baselines
- post-deploy smoke evidence
- on-call roster or owner map
- incident history or defect registry
- blocker registry and override notes

## Standalone rule / standalone usage
This skill must still work on one service rollout, one module release, or one partial deployment slice.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If baseline data is missing, never invent thresholds; emit `needs_baseline_confirmation` and preserve the validation item.
- If only passive monitoring signals exist, clearly separate passive observation from active validation tasks.

## Core output contract / core output contract
Default to csv-friendly tables matching `references/output-template.md`.

The result must include at least:
- `metadata`
- `prv_items[]`
- `dimension_coverage_matrix`
- `checkpoint_plan`
- `related_prv_graph`
- `on_failure_playbooks[]`
- `decision_mapping_summary`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: post_release_validation_planning_and_checkpoint_design`
- `stage_position: release_and_delivery.release_validation.post_release_validation_checklist`
- `workflow_node: N290`
- `node_artifact_target: 发布后验证清单.csv`
- `evidence_profile`
- `tool_collaboration_mode`

Each `prv_item` must include:
- `prv_id`
- `time_window`
- `validation_type`
- `prv_priority`
- `requirement`
- `prv_dimension`
- `metric_or_check`
- `baseline_source`
- `tolerance_rule`
- `sample_window`
- `sample_size_min`
- `pass_criteria`
- `fail_criteria`
- `related_prvs`
- `evidence_expected`
- `owner_placeholder`
- `on_failure_action`

## Design rules / design rules
- Use `prv_priority`: `P0`, `P1`, `P2`.
- Use `requirement`: `mandatory`, `signoff_required`, `observe_only`.
- Use `validation_type`: `active_probe`, `passive_observation`, `synthetic_monitor`, `human_confirmation`.
- Use `prv_dimension`: `D1 functional`, `D2 data_integrity`, `D3 performance`, `D4 security`, `D5 compliance`, `D6 integration`, `D7 monitoring`, `D8 rollback_readiness`.
- Every P0 item must be binary-verifiable or quantitatively measurable; never leave a P0 item as prose-only judgement.
- Every PRV must declare baseline-aware criteria whenever a metric is involved; absolute-only criteria are allowed only when no trustworthy baseline exists.
- Every PRV failure path must map to a specific playbook, escalation target, and decision SLA.
- Every dimension must appear in the coverage matrix in `comprehensive_prv` mode; missing dimensions are blockers.
- Use time windows that preserve continuity, for example `t_plus_0m`, `t_plus_15m`, `t_plus_1h`, `t_plus_24h`, `t_plus_7d`, `t_plus_28d`.

## Execution workflow / execution workflow
1. Normalize acceptance criteria, release scope, and deployment orchestration into concrete validation objects.
2. Partition candidate validations into explicit time windows and identify whether each one is active or passive.
3. Assign priority, dimension, requirement level, evidence source, and baseline/tolerance rules.
4. Link related PRVs that must be evaluated together or in sequence.
5. Attach failure playbooks and GA-decision mapping hints for downstream acceptance.
6. Emit a stable checklist structure ready for operators, reviewers, or the next skill.

## Dynamic completeness / dynamic completeness
- If an item is only meaningful under real traffic, mark it as `passive_observation` or `synthetic_monitor` instead of pretending it can be manually executed at T+0.
- If multiple PRVs validate the same risk, connect them through `related_prvs` and surface one primary item with linked companions.
- If rollback readiness is inherited from N270/N280 evidence, preserve that linkage instead of duplicating the rollback plan.
- If one missing upstream artifact prevents quantitative validation, keep the PRV row but downgrade readiness and state the exact missing evidence.

## Quality bar / quality bar
A good post-release validation checklist is prioritized, dimension-complete, baseline-aware, decision-connected, and immediately executable by release or on-call teams.

## Reference files / reference files
- `references/prv-dimensions-and-playbooks.md`
- `references/release-outcome-contract.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/readiness-inheritance.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
