# Release outcome contract

Use this shared structure when the N290 pair works together.

```json
{
  "release_outcome": {
    "release_id": "",
    "release_scope": [],
    "prv_results": [],
    "metrics_snapshot": {},
    "incidents": [],
    "defects_found": [],
    "risks_materialized": [],
    "ga_decision": {}
  }
}
```

## Required handoff fields from 109 to 110
- `prv_id`
- `time_window`
- `prv_priority`
- `prv_dimension`
- `validation_type`
- `pass_criteria`
- `fail_criteria`
- `evidence_expected`
- `on_failure_action`
- `related_prvs`

## Rules
- 109 defines what should be validated.
- 110 records what was actually observed and whether GA criteria are met.
- New observations that were not planned must be preserved as extra evidence, not retrofitted into earlier PRV rows without traceability.
