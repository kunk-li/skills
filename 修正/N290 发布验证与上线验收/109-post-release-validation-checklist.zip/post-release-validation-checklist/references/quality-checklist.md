# Quality checklist

Before finalizing the output:
- Confirm every P0 item is measurable or binary-verifiable.
- Confirm all 8 dimensions are represented in comprehensive mode.
- Confirm each metric-based PRV has a baseline source or an explicit missing-baseline warning.
- Confirm every PRV has a concrete owner placeholder and expected evidence.
- Confirm every failure path points to an escalation or rollback playbook.
- Confirm no item silently assumes live traffic before the time window exists.
