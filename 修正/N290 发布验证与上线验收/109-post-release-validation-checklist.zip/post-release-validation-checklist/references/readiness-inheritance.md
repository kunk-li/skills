# 发布后验证 readiness inheritance

当上游材料已经包含 readiness、gate、受限发布或 blocked 状态时，用本规则继承，而不是重新发明就绪结论。

## 三种继承档位

### 1. pass
- 可覆盖 `t0 + t1 + same_day + day2_plus` 全时间窗口。
- `must` 项完整，且可附带 `should` / `sample` 项。
- 可在摘要里写“按全窗口验证计划执行”。

### 2. constrained
- 仅保证 `t0 + t1` 的 `must` 项完整。
- `same_day / day2_plus` 仅保留重点观察项与待确认 TODO。
- 必须显式写出哪些观察项尚未具备执行条件。

### 3. blocked
- 仅输出 smoke-level 核心 top 5 项。
- 不扩写完整 PRV，不伪造后续监控项。
- 摘要中要直说“当前仅可形成受阻态最小检查集”。

## single source of truth 规则

- 不上调 readiness：上游是 `constrained`，本 skill 不能写成 `pass`。
- 不声称 PRV 已验证：本 skill 产物定义的是“应验证什么”，不是“已经验证了什么”。
- 若上游 readiness 缺失，可写 `unknown`，不要默认按 `pass` 处理。

## gate-aware 输出方式

当输入明确提到 gate 或分阶段放量时：
- 把与 gate 决策强相关的观察项放在更靠前位置。
- 对受限项显式拆成“已确认区”和“待观察区”。
- `confidence` 优先使用 `explicit / inferred / unknown`，不要留空。
