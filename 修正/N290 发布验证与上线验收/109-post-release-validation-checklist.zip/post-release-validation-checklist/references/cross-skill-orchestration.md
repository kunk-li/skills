# Cross-skill orchestration

## Position in the N290 node
- Upstream node inputs: acceptance criteria, release notes, and release task orchestration
- Current skill: define the post-release validation checklist
- Downstream companion: `go-live-acceptance-assistant`
- Node output chain: `发布后验证清单.csv` -> `上线验收记录.md`

## Collaboration contract
1. `post-release-validation-checklist` defines the planned validation set.
2. Each planned row must have a stable `prv_id`.
3. `go-live-acceptance-assistant` consumes the executed results using `linked_prv_ids[]` or a one-to-one `prv_results[]` mapping.
4. If an unplanned observation appears after deployment, keep it as an additional observation; never silently rewrite the planned checklist.
5. Decision hints flow forward, but final GO / CONDITIONAL GO / NO-GO synthesis belongs to the companion skill.

## Minimum handoff fields
- `prv_id`
- `time_window`
- `prv_priority`
- `prv_dimension`
- `validation_type`
- `pass_criteria`
- `fail_criteria`
- `evidence_expected`
- `on_failure_action`
- `related_prvs`

## Shared structure
Use `references/release-outcome-contract.md` as the shared release outcome data structure.
