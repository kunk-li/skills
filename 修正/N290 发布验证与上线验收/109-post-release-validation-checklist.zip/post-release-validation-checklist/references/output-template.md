# Output template

Use a csv-friendly markdown table plus a short summary.

## Summary
- release scope
- selected mode
- readiness
- checklist size and time windows
- highest-risk P0 items

## Required tables
1. `prv_items`
2. `dimension_coverage_matrix`
3. `checkpoint_plan`
4. `on_failure_playbooks`
5. `downstream_handoff`
