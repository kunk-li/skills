# Cross-skill orchestration

## Position in the N290 node
- Upstream node inputs: acceptance criteria, release notes, and release task orchestration
- Upstream companion inside N290: `post-release-validation-checklist`
- Current skill: synthesize evidence and assist the go-live / GA decision
- Downstream node: N300 monitoring and incident analysis

## Collaboration contract
1. `post-release-validation-checklist` defines what should be checked and when.
2. This skill records what was actually observed and how that maps to GO / CONDITIONAL GO / NO-GO / DEFERRED REVIEW.
3. Reuse `prv_id` through `linked_prv_ids[]` or `prv_results[]` references.
4. New observations that were not planned must remain visible as additional release-outcome facts.
5. Decision output must be traceable enough for later N300/N320 analysis.

## Minimum handoff fields
- `prv_id`
- `time_window`
- `status`
- `evidence`
- `linked_alerts_or_incidents`
- `conditions`
- `recommendation`
- `follow_up_items`

## Shared structure
Use `references/release-outcome-contract.md` as the shared data structure for N290 outputs.
