# Quality checklist

Before finalizing the output:
- Confirm recommendation state is explicit and justified.
- Confirm hard requirements and soft requirements are separated.
- Confirm the observation period is adequate for the decision state.
- Confirm signoff fields are real, pending, or omitted; never invent approvals.
- Confirm follow-up items exist for any conditional or deferred decision.
- Confirm linked PRV traceability remains intact.
