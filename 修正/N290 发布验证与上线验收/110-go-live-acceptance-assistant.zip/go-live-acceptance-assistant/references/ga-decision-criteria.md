# GA decision criteria

## Recommendation states
- `GO`: all hard requirements satisfied and soft requirements satisfied within tolerance
- `CONDITIONAL_GO`: hard requirements satisfied, but one or more soft requirements need explicit signoff or follow-up
- `NO_GO`: any hard requirement violated or any critical blocker remains open
- `DEFERRED_REVIEW`: observation window or evidence is incomplete; decision should not be finalized yet

## Typical hard requirements
- all P0 PRVs pass
- zero active compliance violations
- zero active security incidents of release-blocking severity
- zero active data-loss or data-corruption events
- zero open P0 defects directly linked to the release

## Typical soft requirements
- P1 PRV pass rate meets target
- performance stays within agreed tolerance versus baseline
- open P1 defects remain under the agreed cap and have owners
- user complaints stay under the agreed limit
- rollback readiness remains valid inside the effective window

## Observation guidance
- cover at least one early checkpoint and one extended checkpoint
- include a representative traffic sample window
- use baseline comparisons instead of gut-feel statements such as "looks normal"

## Role-based view hints
- PM: user-visible impact and business outcomes
- Tech Lead: technical stability, defects, and architecture health
- SRE: SLO, incidents, rollback readiness, and monitoring health
- Compliance / L6: compliance events, audit completeness, and approved exceptions
