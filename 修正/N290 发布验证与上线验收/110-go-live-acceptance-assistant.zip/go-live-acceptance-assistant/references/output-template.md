# Output template

Use a decision-ready markdown record.

## Sections
1. release snapshot
2. ga decision view
3. ga criteria evaluation
4. role-based views
5. blockers and conditions
6. ga decision record
7. post-ga tracking
8. downstream handoff
