# 上线验收 readiness inheritance

当上游清单、发布计划或 gate 说明已经带有 readiness / constrained / blocked 状态时，本 skill 只继承与展开，不重写上游结论。

## 三种继承档位

### pass
- 可以按完整阶段结构整理记录。
- 所有阶段都可以填观察事实与证据。
- 未闭合问题可以保留，但不影响“按计划进入下一阶段”的叙述方式。

### constrained
- 重点整理当前已执行阶段的事实与证据。
- 对尚未执行或受限阶段，保留占位和待确认，不要假装已有结果。
- `decision_inputs` 中要明确写出限制条件。

### blocked
- 只记录当前可确认的事实、阻塞点和最小验证结果。
- 不扩写后续阶段“正常应有表现”。
- 摘要中直接说明“当前为 blocked 状态验收记录”。

## single source of truth 规则

- 不上调 readiness。
- 不把 gate 输入写成 gate 结论。
- 不把观察记录写成 RCA 或正式复盘定稿。
