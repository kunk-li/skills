# Release outcome contract

Use this shared structure when the N290 pair works together.

```json
{
  "release_outcome": {
    "release_id": "",
    "release_scope": [],
    "prv_results": [],
    "metrics_snapshot": {},
    "incidents": [],
    "defects_found": [],
    "risks_materialized": [],
    "ga_decision": {
      "recommendation": "GO|CONDITIONAL_GO|NO_GO|DEFERRED_REVIEW",
      "hard_requirements": [],
      "soft_requirements": [],
      "conditions": []
    }
  }
}
```

## Minimum inputs expected from checklist execution
- `prv_id`
- `status`
- `observed_value`
- `pass_criteria`
- `fail_criteria`
- `time_window`
- `evidence`
- `linked_alerts_or_incidents`

## Rules
- Planned validation structure should remain linkable to observed execution results.
- Decision records must preserve both evidence and missing-evidence gaps.
