---
name: go-live-acceptance-assistant
description: generate workflow-aligned go-live acceptance records and ga decision support from 验收标准.md, 发布说明.md, 发布任务编排表.csv, executed prv results, metrics snapshots, incidents, and signoff evidence. use when chatgpt works in release & delivery / post-release validation and must produce the n290 上线验收记录.md artifact, assemble a ga dashboard, evaluate hard and soft acceptance criteria, issue go / conditional go / no-go recommendations, maintain decision traceability, or track post-ga follow-up items.
---
# go-live-acceptance-assistant

## Role / role positioning
This skill aligns to release & delivery -> post-release validation -> 上线验收记录.md. It is the authoritative N290 skill for turning post-release observations into structured go-live acceptance records and GA decision support.

### Boundary
- Own release-outcome synthesis, GA criteria evaluation, dashboard-style decision support, role-based decision views, and decision record keeping.
- Consume upstream release assets and N290 PRV results instead of redefining the validation scope.
- Do not replace `post-release-validation-checklist` for planned post-release checks.
- Do not replace incident or root-cause analysis skills for deep runtime investigation.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `dashboard_mode`
- `auto_decision_mode`
- `audit_mode`

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `发布说明.md`
- `发布任务编排表.csv`

### strongly recommended node-internal input
- `发布后验证清单.csv` or structured PRV execution results

### optional enhancement inputs
- metrics snapshots and SLO reports
- incident or alert summaries
- defect registry and blocker status
- signoff roster or approval records
- customer feedback or complaint summaries
- risk register and mitigation status
- historical release comparison data

## Standalone rule / standalone usage
This skill must still work on one deployment wave, one canary phase, or one partial acceptance checkpoint.

Degradation rules:
- If PRV outputs are missing, synthesize an acceptance record from explicit observations but mark the missing planned-validation layer in `downstream_handoff`.
- If quantitative evidence is incomplete, keep the decision state conservative and preserve unresolved hard requirements.
- If the user only wants a dashboard, keep the decision record lightweight but do not invent signoffs.

## Core output contract / core output contract
Default to a decision-ready markdown record matching `references/output-template.md`.

The result must include at least:
- `metadata`
- `release_outcome`
- `ga_decision_view`
- `ga_criteria_evaluation`
- `role_based_views`
- `ga_decision_record`
- `post_ga_tracking`
- `blockers_and_conditions`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: go_live_acceptance_synthesis_and_ga_decision_support`
- `stage_position: release_and_delivery.release_validation.go_live_acceptance`
- `workflow_node: N290`
- `node_artifact_target: 上线验收记录.md`
- `evidence_profile`
- `tool_collaboration_mode`

`release_outcome` must contain at least:
- `release_id`
- `prv_results[]`
- `metrics_snapshot`
- `incidents[]`
- `defects_found[]`
- `risks_materialized[]`
- `ga_decision`

## Design rules / design rules
- Evaluate hard requirements separately from soft requirements.
- Use recommendation states: `GO`, `CONDITIONAL_GO`, `NO_GO`, `DEFERRED_REVIEW`.
- Every recommendation must include explicit reasoning, evidence references, and unresolved conditions.
- Keep role-based views for at least `pm`, `tech_lead`, `sre`, and `compliance_or_l6` when those concerns are relevant.
- Preserve `linked_prv_ids` or equivalent PRV traceability from checklist planning to observed outcomes.
- Any conditional or deferred decision must produce concrete follow-up items, owners, and due dates.
- Never fabricate signoff; if no approver is provided, keep the signoff field as pending.

## Execution workflow / execution workflow
1. Normalize release context, PRV outcomes, incidents, metrics, blockers, and signoff evidence into a shared release outcome structure.
2. Evaluate hard and soft GA criteria, including observation-window coverage and unresolved blocker conditions.
3. Build a dashboard-style decision view for all stakeholders.
4. Generate a recommendation state and a machine-readable decision record with rationale and evidence.
5. Carry forward accepted risks, deferred items, and post-GA follow-up tracking.
6. Emit a stable acceptance record that can be consumed by monitoring, incident response, or postmortem workflows.

## Dynamic completeness / dynamic completeness
- If not enough time has elapsed for a full observation period, prefer `DEFERRED_REVIEW` or `CONDITIONAL_GO` over a premature GO.
- If hard requirements are unmet or evidence is missing, do not blur the line between missing evidence and passing evidence.
- If multiple PRV failures share a root symptom, cluster them but preserve the individual linked PRV references.
- If historical release data exists, use it to contextualize the decision without overriding current hard failures.

## Quality bar / quality bar
A good go-live acceptance record is evidence-backed, criteria-driven, role-readable, traceable, and able to survive post-hoc audit.

## Reference files / reference files
- `references/ga-decision-criteria.md`
- `references/release-outcome-contract.md`
- `references/go-live-acceptance-phases-guide.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/readiness-inheritance.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
