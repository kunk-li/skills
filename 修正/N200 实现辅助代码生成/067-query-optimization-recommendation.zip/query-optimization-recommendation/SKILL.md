---
name: query-optimization-recommendation
description: generate workflow-aligned query optimization analysis from sql drafts, execution plans, index hints, and pagination patterns. use when chatgpt works in coding & implementation / code generation and must produce the workflow-aligned 查询优化建议.md for n200 after scaffold generation and before static quality checks or documentation generation.
---
# query-optimization-recommendation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 代码生成 -> 查询优化建议.md」。

它是 **direct_result** 型技能：目标不是泛泛讨论数据库性能，而是把 SQL 草稿、执行计划、索引命中、N+1 风险和分页策略，稳定落成可被下游直接消费的 **`查询优化建议.md`** 级别优化建议。

### Boundary / 边界
- 负责 explain analysis、N+1 检测、索引建议、缓存建议和分页策略。
- 负责收益 / 代价 / 待验证项的结构化输出。
- 不替代真实生产压测或 DBA 最终决策。
- 不脱离现有 SQL / schema 自行虚构访问模式。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `explain_mode`：以执行计划为主做瓶颈分析。
- `index_mode`：以索引设计和 SQL 语句为主做优化建议。
- `code_level_mode`：以 ORM / repository 访问模式为主识别 N+1、深分页等问题。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `接口设计草案.yaml`
- `业务规则清单.csv`
- `错误码清单.csv`
- `表结构设计草案.sql`

### 可选增强输入
- `SQL草稿.sql`
- EXPLAIN 输出
- 慢查询样本
- 索引清单与查询模式

## Standalone rule / 独立使用规则
即使只拿到 SQL 片段、EXPLAIN 结果或慢查询现象，也可以单独使用。

降级规则：
- 缺少真实 EXPLAIN 时，也可先输出 heuristic 分析，但必须标明 `evidence_profile: heuristic_only`。
- 缺少 schema 时，也可先给 rewrite / pagination / caching notes。
- 顶部必须标明 `readiness: provisional` 或 `readiness: constrained`。
- 必须显式写出 `assumptions[]`、`missing_measurements[]` 与 `pending_validations[]`。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: analysis_with_direct_handoff`
  - `stage_position: coding_and_implementation.code_generation.query_optimization_recommendation`
  - `workflow_node: N200`
  - `node_artifact_target: 查询优化建议.md`
  - `evidence_profile`
- `bottleneck_summary`
- `explain_analysis[]`
- `n_plus_one_detection[]`
- `index_recommendations[]`
- `caching_recommendation`
- `pagination_strategy`
- `rewrite_candidates[]`
- `drift_watchlist[]`
- `downstream_handoff`
  - `workflow_downstream`: `N210`, `N330`
  - `artifact_name: 查询优化建议.md`
  - `sibling_dependencies`: `sql`, `dto`, `validator`
- `self_check`

## Design rules / 设计规则
### Explain analysis
优先使用真实 explain / analyze 结果；没有时只能输出 heuristic bottleneck，不能伪装成实测结论。

### N+1 detection
必须显式检查循环查询、lazy serialization、批量缺失等典型模式。

### Index recommendations
每条索引建议都应尽量带：目标查询、DDL 草案、收益、写入代价和是否可能冗余。

### Caching and pagination
当查询是高读低写时，要显式评估缓存；当出现深分页或大 offset 时，要显式评估 keyset / cursor 策略。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness` 与 source of truth。
2. 归纳瓶颈类型：seq scan、filesort、temp table、deep pagination、N+1 等。
3. 输出 `explain_analysis[]` 与 `n_plus_one_detection[]`。
4. 给出索引、rewrite、缓存和分页策略建议。
5. 标出收益、代价、风险和待验证项。
6. 输出 drift watchlist。
7. 形成 workflow 对齐的 **`查询优化建议.md`** 产物说明。
8. 输出 `downstream_handoff` 给 N210 / N330。
9. 使用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 只有 SQL：至少给 rewrite + index hints。
- 有 explain：补 bottleneck 定位与收益估计。
- 有 ORM / repository 上下文：必须补 N+1、深分页和 caching recommendation。

## Quality bar / 质量门槛
合格结果应让下游可以直接开始做静态检查、repository 修正和文档沉淀，而不需要重新讨论慢点究竟是索引、SQL 写法、ORM 模式还是分页策略的问题。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
