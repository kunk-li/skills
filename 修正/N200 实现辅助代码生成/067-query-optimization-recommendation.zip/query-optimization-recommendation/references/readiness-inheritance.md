# Readiness inheritance

## Rules
- `pass`: SQL text, symptoms, and index or plan context are detailed enough for prioritized advice.
- `constrained`: some evidence is missing; provide hypothesis-based recommendations and state the uncertainty.
- `blocked`: optimization advice would be mostly guesswork; output a diagnostic checklist and missing-data request instead.

## Source-of-truth rule
Use the provided SQL, explain-plan evidence, and system symptoms as the source of truth for the diagnosis.

## Gate-aware rule
When plan evidence or volume data is missing, present recommendations as hypotheses and keep validation steps explicit.
