# Scoring rubric for optimization recommendations

Score each category from 0 to 2.

## 1. Root-cause quality
- 0: symptoms only, no plausible causes
- 1: partial cause analysis
- 2: causes are plausible and clearly linked to evidence

## 2. Recommendation quality
- 0: vague or generic suggestions
- 1: partly actionable suggestions
- 2: concrete, prioritized, and context-aware options

## 3. Tradeoff handling
- 0: only benefits, no costs
- 1: some tradeoffs noted
- 2: benefit, cost, and validation needs are balanced

## 4. Advisory discipline
- 0: overclaims validation or certainty
- 1: some uncertainty handling
- 2: uncertainty and validation boundaries are explicit
