# Output template: query optimization recommendation

## Required structure
### 1. Problem summary
Group findings by severity such as HIGH, MEDIUM, and LOW.

### 2. Top issues
For each important issue, include all six elements:
- problem symptom
- likely cause
- recommendation
- expected benefit
- cost or tradeoff
- what still needs validation

### 3. Anti-patterns
Include a short list of actions that should not be taken.

### 4. Suggested next step
Recommend whether the next step belongs to SQL rewrite, index design, DBA review, or application-layer change.

## Required behavior
- Prefer multiple candidate options instead of one rigid recommendation when tradeoffs are meaningful.
- Quantify expected benefit when the input allows a reasonable estimate.
- Keep unknowns visible instead of claiming the optimization has already been validated.

## Boundary rules
- Do not claim benchmark results that were not provided.
- Do not skip tradeoffs when recommending indexes or query rewrites.
- Do not treat advisory output as execution approval.
