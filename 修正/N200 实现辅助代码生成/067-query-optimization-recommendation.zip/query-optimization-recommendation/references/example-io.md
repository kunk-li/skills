# Example inputs and outputs for query optimization recommendations

## Example 1: Slow paged query
Input:
- high latency on a sorted list query with offset pagination

Output shape:
- severity-ranked issue
- root cause note about sort and offset cost
- candidate keyset pagination suggestion with tradeoff note

## Example 2: Missing covering index
Input:
- explain plan shows full scan and sort

Output shape:
- recommendation for candidate composite index
- note about write amplification and validation steps

## Example 3: Mixed root causes
Input:
- SQL is wide, application fetches too many columns, data volume is growing

Output shape:
- separate issues for SQL rewrite, field selection, and index strategy
- prioritized next steps
