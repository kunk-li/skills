# Common failure modes for query optimization recommendations

## F1. Recommend indexes without tradeoffs
Symptom: every problem gets a blanket “add an index” answer.
Fix: explain write cost, storage cost, and alternative rewrites.

## F2. Ignore root cause layers
Symptom: SQL text, index design, and application usage are not separated.
Fix: classify bottlenecks by query, index, model, or calling pattern.

## F3. Stay vague
Symptom: recommendations say “optimize” without concrete direction.
Fix: propose specific rewrite or index candidates and next validation steps.

## F4. Skip anti-patterns
Symptom: only positive suggestions appear, so risky moves stay invisible.
Fix: include explicit “do not do” items.

## F5. Pretend validation already happened
Symptom: advice sounds benchmarked or approved.
Fix: keep benchmarks, explain plans, and DBA signoff as explicit open items.
