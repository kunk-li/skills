# Orchestration for query optimization recommendations

## Upstream inputs
- Candidate SQL statements or execution plans
- Table shape, index information, and data volume
- Known latency symptoms or throughput pain points
- Business constraints and acceptable tradeoffs

## Downstream consumers
- SQL draft authors can revise statements and indexes.
- DBA or data platform reviewers can validate or reject suggested changes.
- Application owners can decide whether to change call patterns or pagination behavior.

## Collaboration details
- Load [n200-collaboration-matrix.md](n200-collaboration-matrix.md) when relating findings back to sql, dto, validator, enum, or exception skills.
