# Orchestration for sql draft generation

## Upstream inputs
- Table design and column semantics
- Index strategy and query goals
- Validation and state-transition requirements
- API or report output fields

## Downstream consumers
- Optimization analysis consumes these statements, indexes, and bottlenecks.
- DTO design may need returned column alignment.
- Service or repository code may embed or call these statements later.

## Collaboration details
- Load [n200-collaboration-matrix.md](n200-collaboration-matrix.md) when coordinating with dto, enum, validator, exception, or optimization skills.
- Load [n200-java-conventions.md](n200-java-conventions.md) only when SQL is being wrapped into Java repository or mapper code.
