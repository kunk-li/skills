# Scoring rubric for sql drafts

Score each category from 0 to 2.

## 1. Query intent clarity
- 0: the statement purpose is unclear
- 1: purpose is mostly clear
- 2: purpose, predicates, and return shape are clear

## 2. Performance awareness
- 0: no index or cost awareness
- 1: some performance hints exist
- 2: index, pagination, and concurrency assumptions are explicit

## 3. Safety
- 0: unsafe broad writes or hidden assumptions
- 1: mostly safe with some gaps
- 2: write scope and assumptions are explicit and defensive

## 4. Dialect and transaction handling
- 0: ignores dialect or transaction concerns
- 1: partial notes only
- 2: relevant dialect and transaction notes are visible
