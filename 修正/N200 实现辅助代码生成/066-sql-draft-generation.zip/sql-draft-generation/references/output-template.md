# Output template: sql drafts

## Required statement header
```sql
-- Q-{MODULE}-{NN}: {business purpose}
-- Index: {IDX-XXX or candidate index}
-- Dialect: {mysql | postgresql | other}
-- Concurrency: {none | for update | nowait | skip locked}
-- Readiness: {pass | constrained | blocked}
```

## Required SQL qualities
- Select explicit columns instead of `SELECT *`.
- Show the main filter predicates and the intended index relationship.
- Mark ordering, pagination, and transaction assumptions explicitly.
- For writes, describe the state-transition or idempotency expectation in comments.

## Optional transaction block pattern
```sql
BEGIN;
-- step 1
-- step 2
COMMIT;
```
Use it only when the user has already indicated a multi-statement transactional intent.

## Boundary rules
- Do not invent hidden tables, columns, or joins without marking them as assumptions.
- Do not generate unsafe broad updates or deletes without a clear where clause.
- Do not claim the SQL has been tested, explained, benchmarked, or approved by a DBA.
