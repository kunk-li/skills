# Readiness inheritance

## Rules
- `pass`: tables, predicates, and key constraints are known well enough to draft concrete SQL.
- `constrained`: some joins, indexes, or dialect details are missing; produce assumption-marked SQL.
- `blocked`: schema hints are too thin; output only query intent decomposition and open questions.

## Source-of-truth rule
Treat provided schema, field semantics, and dialect notes as the source of truth.

## Gate-aware rule
When indexes, joins, or transaction semantics are unclear, keep those as visible assumptions instead of silently filling them in.
