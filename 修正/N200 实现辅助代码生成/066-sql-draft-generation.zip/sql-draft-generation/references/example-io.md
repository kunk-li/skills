# Example inputs and outputs for sql draft generation

## Example 1: Read query with paging
Input:
- filter by eid and status
- return recent 20 rows ordered by created time

Output shape:
- explicit column list
- where clause note and paging comment

## Example 2: State transition write
Input:
- update status only when current status is ACTIVE

Output shape:
- CAS-style update predicate note
- affected-row handling comment

## Example 3: Partial schema
Input:
- only table and field hints are known

Output shape:
- assumption-marked SQL skeleton
- DBA review checklist for missing joins or indexes
