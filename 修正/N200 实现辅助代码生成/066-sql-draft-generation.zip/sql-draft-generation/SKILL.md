---
name: sql-draft-generation
description: generate workflow-aligned sql drafts from schema contracts, migration intent, dialect constraints, and query change requirements. use when chatgpt works in coding & implementation / code generation and must produce the workflow-aligned SQL草稿.sql for n200 after scaffold generation and before static quality checks or documentation generation.
---
# sql-draft-generation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 代码生成 -> SQL草稿.sql」。

它是 **direct_result** 型技能：目标不是泛泛讨论 SQL 风格，而是把 schema contract、迁移意图、索引调整和注入防护要求，稳定落成可被下游直接消费的 **`SQL草稿.sql`** 级别 SQL / migration 草稿。

### Boundary / 边界
- 负责 DDL / DML 草稿、migration 版本化、方言兼容性、online DDL 建议与注入防护规则。
- 负责索引冗余检查、回滚说明和 schema drift 风险提示。
- 不替代 DBA 最终审阅，也不替代真实生产变更窗口评估。
- 不脱离上游 schema contract 随意设计表结构。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `ddl_only`：以 schema 变更和 migration 为主输出 DDL 草稿。
- `migration_generate`：重点生成 Flyway / Liquibase 风格版本化变更与 rollback notes。
- `query_optimize`：以查询重写、索引和方言兼容为主输出 SQL 草稿。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `接口设计草案.yaml`
- `业务规则清单.csv`
- `错误码清单.csv`
- `表结构设计草案.sql`

### 可选增强输入
- `索引建议清单.csv`
- 迁移脚本目录、DB 方言约束
- 慢查询样本、现有表定义
- 发布窗口与回滚要求

## Standalone rule / 独立使用规则
即使只拿到 schema 草案、DDL 需求或 SQL 片段，也可以单独使用。

降级规则：
- 缺少完整 schema 时，也可先输出 migration skeleton、dialect notes 和 pending validations。
- 缺少运行数据时，也可先输出 heuristic 的 online DDL 和 index redundancy 提示，但必须标注不是实测结论。
- 顶部必须标明 `readiness: provisional` 或 `readiness: constrained`。
- 必须显式写出 `dialect_assumptions[]`、`rollback_notes[]` 与 `pending_validations[]`。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_generation.sql_draft_generation`
  - `workflow_node: N200`
  - `node_artifact_target: SQL草稿.sql`
  - `evidence_profile`
- `migration_framework`
- `dialect_compatibility`
- `ddl_dml_catalog[]`
- `online_ddl_strategy`
- `index_redundancy_check`
- `parameterization_rules`
- `rollback_notes[]`
- `drift_watchlist[]`
- `downstream_handoff`
  - `workflow_downstream`: `N210`, `N330`
  - `artifact_name: SQL草稿.sql`
  - `sibling_dependencies`: `query_optimization`, `dto`, `repository`
- `self_check`

## Design rules / 设计规则
### Migration framework
必须显式声明 migration 方案，例如 `flyway`、`liquibase` 或受控 custom script；不要输出不可追溯的散装 SQL。

### Dialect compatibility
必须指明目标方言，并显式写出不兼容语法、替代表达和迁移风险。不要把 MySQL / PostgreSQL / Oracle 差异隐身处理。

### Online DDL strategy
只要涉及大表或潜在锁表，就必须输出 online / concurrent / batch 策略和预计锁影响，不要只给裸 `ALTER TABLE`。

### Index redundancy and injection guardrails
新增索引时必须检查 prefix redundancy、重复索引与覆盖索引机会；所有动态 SQL 都应强调参数化和白名单，不要输出字符串拼接式示例。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness` 与 source of truth。
2. 抽取 schema 变更、查询意图、索引和 migration 需求。
3. 固化 migration framework 与目标方言。
4. 输出 `ddl_dml_catalog[]` 与 rollback notes。
5. 给出 `online_ddl_strategy`、`index_redundancy_check` 和 `parameterization_rules`。
6. 标出 dialect drift、schema drift 和发布窗口风险。
7. 形成 workflow 对齐的 **`SQL草稿.sql`** 产物说明。
8. 输出 `downstream_handoff` 给 N210 / N330。
9. 使用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 只有 schema 变更：至少给 migration framework、DDL 草稿和 rollback notes。
- 有方言与表规模信息：补 online DDL 与兼容性说明。
- 有查询 / 索引上下文：必须补 redundancy check、parameterization rules 和 drift watchlist。

## Quality bar / 质量门槛
合格结果应让下游直接开始静态检查、repository 接线和文档沉淀，而不需要重新讨论脚本如何版本化、方言是否可落地、在线变更怎么做、以及 SQL 安全边界在哪里。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md`
