---
name: validator-code-generation
description: generate workflow-aligned validator drafts from api contracts, business rules, dto fields, and error semantics. use when chatgpt works in coding & implementation / code generation and must produce the workflow-aligned 校验器代码.java for n200 after scaffold generation and before static quality checks or documentation generation.
---
# validator-code-generation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 代码生成 -> 校验器代码.java」。

它是 **direct_result** 型技能：目标不是泛泛讨论参数校验，而是把 API contract、字段约束、业务规则和跨字段条件，稳定落成可被下游直接消费的 **`校验器代码.java`** 级别 validator / annotation 草稿。

### Boundary / 边界
- 负责标准 validator、业务特定 validator、跨字段约束和 i18n message key 设计。
- 负责 rule-to-validator traceability 与 composable validation bundles。
- 不负责完整 Controller / Service 实现，也不替代数据库约束。
- 不把业务规则只写进文档而不落到 validator 草稿里。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `standard_lib_only`：以内建标准 validators 为主输出可复用草稿。
- `business_specific`：从 `业务规则清单.csv`、字段约束和 domain 规则派生项目特定 validators。
- `rule_traceability`：重点输出规则 ID、校验器、message key 和触发上下文的映射关系。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `接口设计草案.yaml`
- `业务规则清单.csv`
- `错误码清单.csv`
- `表结构设计草案.sql`

### 可选增强输入
- `DTO_VO草稿.zip`
- 字段约束表、OpenAPI schema、JSR-380 约定
- 已有 validator 库、国际化 message 文件
- 前端表单校验规则说明

## Standalone rule / 独立使用规则
即使只拿到字段清单、规则表或 OpenAPI，也可以单独使用。

降级规则：
- 缺少 schema 时，也可先输出 contract-first validator 草稿。
- 缺少 DTO 草稿时，也可先输出 annotation 设计、message key 与 traceability 表。
- 顶部必须标明 `readiness: provisional` 或 `readiness: constrained`。
- 必须显式写出 `rule_source_mapping[]`、`cross_field_constraints[]` 与 `pending_decisions[]`。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_generation.validator_code_generation`
  - `workflow_node: N200`
  - `node_artifact_target: 校验器代码.java`
  - `evidence_profile`
- `standard_validator_bundle`
- `business_specific_validators[]`
- `rule_source_mapping[]`
- `cross_field_constraints[]`
- `i18n_message_keys[]`
- `composable_validation_bundles[]`
- `drift_watchlist[]`
- `downstream_handoff`
  - `workflow_downstream`: `N210`, `N330`
  - `artifact_name: 校验器代码.java`
  - `sibling_dependencies`: `dto`, `enum`, `exception`
- `self_check`

## Design rules / 设计规则
### Standard validator bundle
默认优先复用标准 validators：邮箱、手机号、UUID、金额、日期区间、URL、文件类型、枚举值等。不要为常见场景重复造轮子。

### Rule traceability
每个业务特定 validator 都应尽量绑定来源规则，例如 `RULE-AMOUNT-001 -> @ValidAmount(min=1,max=500000)`；不要只写模糊的“按业务校验”。

### Cross-field constraints
跨字段场景优先用声明式 class-level annotation，例如 `@DateRange`、`@FieldsMatch`、`@ConditionalRequired`，不要退化成大量 `@AssertTrue` 内联逻辑。

### i18n message keys
message 不要硬编码文本。应输出稳定 message key，并说明 locale 文件需要补哪些 key。

### Composable validation
对于频繁复用的规则，优先组合成复合注解，例如 `@EmailNormalized`、`@MonetaryAmount`、`@PasswordStrong`。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness` 与 source of truth。
2. 从 API contract、字段 schema 和业务规则抽取字段级与跨字段约束。
3. 先归并可复用的标准 validator，再生成业务特定 validator。
4. 建立 `rule_source_mapping[]`，把规则 ID、字段、validator 和 message key 对齐。
5. 输出 `cross_field_constraints[]` 与 `composable_validation_bundles[]`。
6. 标出 validator 与 DTO / DB constraint / error mapping 的 drift 风险。
7. 形成 workflow 对齐的 **`校验器代码.java`** 产物说明。
8. 输出 `downstream_handoff` 给 N210 / N330。
9. 使用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 简单接口：至少覆盖字段级标准 validator 与 message key。
- 中等复杂度：补业务特定 validator、rule traceability 与跨字段约束。
- 高规则密度：必须补 composable bundles、drift watchlist 和 pending decisions。

## Quality bar / 质量门槛
合格结果应让下游直接开始静态检查、测试补全和文档生成，而不需要重新讨论哪些规则该写进注解、哪些应该作为 class-level validator、以及 i18n 错误信息从哪里来。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md`
