# Example inputs and outputs for validator generation

## Example 1: Bean validation plus business rule
Input:
- request has `email`, `eid`, `newAlias`
- alias uniqueness requires repository lookup

Output shape:
- DTO annotations for format rules
- business validator method for uniqueness check

## Example 2: State transition validator
Input:
- current status and target status must obey a finite state machine

Output shape:
- dedicated state validator or helper class
- explicit allowed transition table

## Example 3: Incomplete framework input
Input:
- rules are known, framework is not

Output shape:
- framework-neutral pseudocode
- explicit `assumed=` note for later Java adaptation
