# Common failure modes for validator generation

## F1. Put complex validation in controllers
Symptom: controllers contain branching rule logic instead of delegating validation.
Fix: move reusable or business-heavy checks into validator components.

## F2. Duplicate the same rule in multiple layers
Symptom: the same rule appears in DTO annotations, controller checks, and service code.
Fix: keep one clear owner per rule.

## F3. Hide database cost
Symptom: uniqueness or existence checks look cheap but require queries.
Fix: add performance notes and index assumptions.

## F4. Give validators side effects
Symptom: validation code mutates state or writes data.
Fix: validators should only verify and throw.

## F5. Swallow failures
Symptom: validation returns null or false without domain context.
Fix: raise the declared exception or error code path explicitly.
