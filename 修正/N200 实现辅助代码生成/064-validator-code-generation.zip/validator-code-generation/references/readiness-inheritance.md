# Readiness inheritance

## Rules
- `pass`: DTO fields, rules, and failure semantics are known well enough to draft validators directly.
- `constrained`: rules are partial; emit validator skeletons and note missing framework or query assumptions.
- `blocked`: rule definitions are too vague; output a validation inventory and open questions only.

## Source-of-truth rule
Treat the supplied contract, DTO shape, and business rules as authoritative for validation scope.

## Gate-aware rule
When readiness is constrained or blocked, do not invent repository calls, error codes, or full annotations without marking them as assumptions.
