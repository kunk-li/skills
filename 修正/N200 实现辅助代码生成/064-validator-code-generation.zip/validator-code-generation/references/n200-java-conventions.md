# N200 Java and service conventions

## Default stack
- Java 17
- Spring Boot 3.2 style annotations and package layout
- Jakarta Validation 3.x
- Lombok for boilerplate reduction
- MyBatis or MyBatis-Plus style repository code when SQL or mapper code is requested

## Package layout
Use a stable package path such as:
`com.company.<domain>.<module>.<layer>`

Typical layers for this batch:
- `dto`
- `enums`
- `validator`
- `exception`
- `repository` or `mapper`

## Naming rules
- DTO request: `{Action}{Object}Request`
- DTO response: `{Object}DTO` or `{Action}{Object}Response`
- VO: `{Object}VO` only when the team already uses VO terminology
- Enum: `{Object}Status`, `{Object}Type`, `{Object}Event`, `ErrorCode`
- Validator annotation: `Valid{Concept}`
- Validator class: `{Concept}Validator` or `{Object}BusinessValidator`
- Exception class: `{Concept}Exception`

## Cross-language fallback
When the user does not provide a target language or framework:
1. Ask for it when the conversation allows.
2. If you still need to proceed, output pseudocode or a language-neutral structure.
3. Mark the assumption explicitly and do not pretend the draft is production-ready.
