# Orchestration for validator generation

## Upstream inputs
- DTO and field contracts
- Enum value sets and transition rules
- Business validation requirements
- Exception or error-code strategy

## Downstream consumers
- Controllers trigger annotation-based validation.
- Service code calls business validators and state-machine checks.
- Exception handling layers transform validation failures into response models.

## Collaboration details
- Load [n200-collaboration-matrix.md](n200-collaboration-matrix.md) when coordinating with dto, enum, exception, sql, or optimization skills.
- Load [n200-java-conventions.md](n200-java-conventions.md) for Java annotation and package conventions.
