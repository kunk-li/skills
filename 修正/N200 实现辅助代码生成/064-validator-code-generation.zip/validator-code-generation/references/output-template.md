# Output template: validator code

## Required layering
1. DTO annotation validation for simple format and nullability rules.
2. Custom constraint annotations for reusable format rules.
3. Business validator classes for database-backed or cross-field checks.
4. State-machine validators for transition legality.

## Required custom annotation skeleton
```java
@Documented
@Constraint(validatedBy = ValidXValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidX {
    String message() default "invalid value";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
```

## Required business validator skeleton
```java
@Component
@RequiredArgsConstructor
public class XBusinessValidator {
    private final XRepository repository;

    /**
     * Rule: {description}
     * Performance: {index or query note}
     * Throws: {exception type or error code}
     */
    public void checkX(...) {
        // validation only, no mutation
    }
}
```

## Boundary rules
- Do not push heavy business validation into controllers.
- Do not give validators side effects.
- Do not swallow exceptions or return null for failed validation paths.
- Do not pretend database-backed validation is free; call out query or index assumptions.
