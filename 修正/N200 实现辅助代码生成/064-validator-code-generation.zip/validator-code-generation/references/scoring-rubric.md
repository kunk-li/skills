# Scoring rubric for validator drafts

Score each category from 0 to 2.

## 1. Layer separation
- 0: all validation logic is mixed together
- 1: partial separation only
- 2: simple, reusable, and business-heavy rules are clearly separated

## 2. Failure-path clarity
- 0: no clear exception path
- 1: partial exception guidance
- 2: failure type or error code is explicit

## 3. Performance awareness
- 0: database-backed validation has no cost notes
- 1: some cost notes exist
- 2: query, index, or latency assumptions are visible where relevant

## 4. Reusability
- 0: repeated ad hoc checks
- 1: some reusable structure
- 2: reusable annotations or validator classes are evident
