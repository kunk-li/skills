# N200 workflow-aligned collaboration matrix

## Workflow node alignment
- `workflow_node`: `N200`
- `stage`: `编码与实现 / 代码生成`
- standard node inputs:
  - `接口设计草案.yaml`
  - `业务规则清单.csv`
  - `错误码清单.csv`
  - `表结构设计草案.sql`
- standard node outputs:
  - `DTO_VO草稿.zip`
  - `枚举定义.java`
  - `校验器代码.java`
  - `异常类.java`
  - `SQL草稿.sql`
  - `查询优化建议.md`
- workflow downstream:
  - `N210`
  - `N330`

## Recommended execution order
1. `enum-definition-generation`
2. `exception-class-generation`
3. `dto-vo-generation`
4. `validator-code-generation`
5. `sql-draft-generation`
6. `query-optimization-recommendation`

This is the preferred local order, not a hard dependency chain. If inputs are partial, generate the local artifact with explicit assumptions and keep the unresolved gaps visible.

## Sibling handoffs
| From | To | Handoff |
|---|---|---|
| enum-definition-generation | dto-vo-generation | enum code, wire format, message key, lifecycle notes |
| enum-definition-generation | validator-code-generation | allowed value set, categorical vs flag semantics |
| exception-class-generation | controller/service layers | base hierarchy, error code binding, stack policy |
| exception-class-generation | dto-vo-generation | error payload conventions and message key usage |
| dto-vo-generation | validator-code-generation | field names, nullability, nested structure, cross-field candidates |
| dto-vo-generation | sql-draft-generation | transport-field to storage-field alignment notes |
| sql-draft-generation | query-optimization-recommendation | candidate statements, indexes, migrations, dialect notes |
| query-optimization-recommendation | sql-draft-generation | rewrite proposals, exact DDL suggestions, cache and pagination notes |

## Shared design rules
- Treat API schema, DB schema, business rules, and error-code catalog as the source of truth.
- Do not silently let `Entity` escape across API boundaries.
- Prefer one-way derivation instead of parallel maintenance whenever possible.
- Preserve drift explicitly when contracts conflict; do not silently pick a side.
- Keep outputs small enough for N210 static review and N330 documentation generation to consume without re-deriving semantics.
