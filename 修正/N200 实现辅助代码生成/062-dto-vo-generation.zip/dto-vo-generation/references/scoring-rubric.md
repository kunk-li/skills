# Scoring rubric for dto and vo drafts

Score each category from 0 to 2.

## 1. Contract alignment
- 0: fields drift from the provided contract
- 1: most fields align but some constraints are missing
- 2: names, required fields, and structure align closely with the contract

## 2. Transport boundary quality
- 0: entity leakage or mixed responsibilities
- 1: mostly separated but with some ambiguity
- 2: request, response, and internal models are clearly separated

## 3. Validation readiness
- 0: no usable validation hints
- 1: partial annotations or comments
- 2: required validation hints are consistently mapped

## 4. Assumption handling
- 0: hidden assumptions
- 1: some assumptions are marked
- 2: assumptions, missing inputs, and readiness are explicit
