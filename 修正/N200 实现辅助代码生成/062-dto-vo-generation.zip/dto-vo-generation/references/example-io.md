# Example inputs and outputs for dto and vo generation

## Example 1: Java request and response
Input:
- POST /aliases/change
- required fields: eid, newAlias
- response fields: ticketId, idempotencyHit

Output shape:
- `AliasChangeRequest`
- `AliasTicketDTO`
- comments for unresolved masking or enum fields

## Example 2: Schema-first planning
Input:
- OpenAPI schema with nested `address` object
- pagination wrapper already exists

Output shape:
- class list with nested structure
- shared wrapper reuse note
- `@Valid` on nested object

## Example 3: Input is incomplete
Input:
- only field names and display labels, no framework

Output shape:
- language-neutral class skeleton
- explicit `assumed=` note
- checklist of missing serialization and validation rules
