# Orchestration for dto and vo generation

## Upstream inputs
- API design or endpoint contract
- Shared schemas and field definitions
- Enum candidates and validation rules
- Visibility, masking, and pagination conventions

## Downstream consumers
- Controllers consume request and response DTOs directly.
- Validators consume field names, annotations, and nested structure.
- Service code uses the models as transport contracts, not persistence models.

## Collaboration details
- Load [n200-collaboration-matrix.md](n200-collaboration-matrix.md) when coordinating with enum, validator, exception, sql, or optimization skills.
- Load [n200-java-conventions.md](n200-java-conventions.md) when a Java stack is requested or assumed.
