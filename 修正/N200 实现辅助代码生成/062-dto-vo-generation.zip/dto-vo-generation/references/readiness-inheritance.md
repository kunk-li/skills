# Readiness inheritance

## Rules
- `pass`: upstream API contract and field semantics are complete enough to draft full request and response classes.
- `constrained`: part of the contract exists; generate class skeletons and mark unknown fields, validation rules, or visibility logic.
- `blocked`: upstream material is too thin; output only a minimal field inventory, assumptions, and next questions.

## Source-of-truth rule
Use the provided contract, schema, and field lists as the source of truth. Do not silently invent production semantics.

## Gate-aware rule
When readiness is not `pass`, add a class-level note such as `Readiness: constrained` and list the blocked items.
