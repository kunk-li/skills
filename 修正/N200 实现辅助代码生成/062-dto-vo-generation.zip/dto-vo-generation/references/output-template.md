# Output template: dto and vo drafts

## Required file organization
- Prefer one module-level file or one class per file, based on the team convention.
- Keep request and response classes separate unless the contract is intentionally symmetric.
- Do not put persistence entities in the same file as outward-facing DTOs.

## Required class skeleton
```java
/**
 * API-XXX {method path} request or response model.
 * Baseline: {api contract or schema reference}
 * Readiness: {pass | constrained | blocked}
 * Notes: {assumptions or unresolved fields}
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class {Action}{Object}Request {

    @NotBlank(message = "...")
    @Size(min = 1, max = 64)
    private String fieldName;

    @Valid
    private NestedObject nested;
}
```

## Naming rules
- Request: `{Action}{Object}Request`
- Response: `{Object}DTO` or `{Action}{Object}Response`
- VO: use only if the codebase already distinguishes VO from DTO.
- Sensitive fields should use explicit names such as `realNameMasked` or `idNumberHash`.

## Required coverage
- For each API, include request and response models or explain why one side is absent.
- Reflect upstream `required`, `pattern`, range, and enum constraints in annotations or comments.
- Use `@Valid` for nested objects when nested validation is expected.
- Keep pagination or common wrappers in reusable shared types when they recur.

## Boundary rules
- Do not add business logic methods beyond trivial constructors or builder helpers.
- Do not inherit outward-facing DTOs from entities.
- Do not leak raw database naming such as `created_at` unless the API contract truly uses it.
- Do not claim the classes are already compiled, tested, or wired into controllers.
