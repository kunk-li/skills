# Common failure modes for dto and vo generation

## F1. Expose entities directly
Symptom: return persistence objects or database field names directly.
Fix: create transport-specific DTO classes and map fields explicitly.

## F2. Miss required validation hints
Symptom: required or pattern fields become plain strings without constraints.
Fix: map upstream contract constraints to annotations or comments.

## F3. Collapse request and response into one class without reason
Symptom: one model carries both inbound validation and outbound display-only fields.
Fix: split request and response responsibilities.

## F4. Ignore masking or visibility rules
Symptom: sensitive fields are emitted with raw names and values.
Fix: encode masking semantics or nullability rules in class comments and field names.

## F5. Pretend the draft is production-ready
Symptom: output claims the DTO is final, compiled, or integrated.
Fix: keep draft language and unresolved assumptions explicit.
