---
name: dto-vo-generation
description: generate workflow-aligned request, response, command, query, event, and view model drafts from api contracts, business rules, error-code conventions, and schema hints. use when chatgpt works in coding & implementation / code generation and must produce the workflow-aligned DTO_VO草稿.zip for n200 after scaffold generation and before static quality checks or documentation generation.
---
# dto-vo-generation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 代码生成 -> DTO_VO草稿.zip」。

它是 **direct_result** 型技能：目标不是泛泛讨论数据传输模型，而是把上游接口契约、业务规则和数据模型，稳定落成可被下游直接消费的 **`DTO_VO草稿.zip`** 级别 DTO / view model 草稿。

### Boundary / 边界
- 负责 request / response / command / query / event / view 类型的传输模型。
- 负责字段命名、嵌套对象抽取、基础类型约定、null 处理和 mapper 策略。
- 不负责 persistence `Entity` 设计本身，也不负责 Controller / Service 的详细实现。
- 不把 `Entity` 直接暴露给 API 层。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `from_openapi`：以 `接口设计草案.yaml` 为主生成 transport models。
- `from_schema`：以 `表结构设计草案.sql` 为主，反推 transport drafts。
- `contract_merge_mode`：综合 API contract、业务规则和 schema 做对齐输出。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `接口设计草案.yaml`
- `业务规则清单.csv`
- `错误码清单.csv`
- `表结构设计草案.sql`

### 可选增强输入
- `技术方案分析.md`
- `Controller草稿.java`
- 已有字段清单、分页规范、脱敏规则、共享 schema 说明

## Standalone rule / 独立使用规则
即使只拿到 API contract 或字段清单，也可以单独使用。

降级规则：
- 缺少 schema 时，也可先生成 contract-first DTO drafts。
- 缺少 OpenAPI 时，也可先输出 field table、class skeleton 与 mapper notes。
- 顶部必须标明 `readiness: provisional` 或 `readiness: constrained`。
- 必须显式写出 `type_assumptions[]`、`shared_object_candidates[]` 与 `pending_decisions[]`。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_generation.dto_vo_generation`
  - `workflow_node: N200`
  - `node_artifact_target: DTO_VO草稿.zip`
  - `evidence_profile`
- `dto_kind_policy`
- `dto_catalog[]`
- `shared_nested_objects[]`
- `null_handling_policy`
- `primitive_type_conventions`
- `mapper_strategy`
- `drift_watchlist[]`
- `downstream_handoff`
  - `workflow_downstream`: `N210`, `N330`
  - `artifact_name: DTO_VO草稿.zip`
  - `sibling_dependencies`: `enum`, `validator`, `exception`
- `self_check`

## Design rules / 设计规则
### DTO kind naming
必须使用以下后缀，不使用 `XxxDTO` / `XxxVO` / `XxxData`：
- `XxxRequest`
- `XxxResponse`
- `XxxCommand`
- `XxxQuery`
- `XxxEvent`
- `XxxView`

### Shared nested objects
当嵌套结构出现 3 次以上，或字段相似度超过 80%，必须列入 `shared_nested_objects[]` 候选，例如：`Address`、`Money`、`TimeRange`、`PersonRef`、`PaginationInfo`。

### Null handling policy
必须显式选择一种：`exclude_null`、`include_null`、`use_optional_wrapper`。同一输出不要混用多种 null 策略。

### Primitive type conventions
默认遵循：时间用 ISO 8601 UTC；金额不要裸 `BigDecimal` 直接穿透；ID wire format 优先 `String`；枚举 wire format 用 string code；分页统一 `PageRequest` / `PageResponse`。

### Mapper strategy
必须声明映射方式：`mapstruct`、`modelmapper` 或 `handwritten`。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness` 与 source of truth。
2. 区分 request / response / command / query / event / view 的职责边界。
3. 从 API contract 提取字段、nullability、枚举和分页结构。
4. 从 schema 提取 persistence alignment，但不把 Entity 直接穿透到 API。
5. 识别重复嵌套结构并抽取 `shared_nested_objects[]`。
6. 固化 `primitive_type_conventions` 与 `null_handling_policy`。
7. 给出 mapper strategy 与 drift watchlist。
8. 形成 workflow 对齐的 **`DTO_VO草稿.zip`** 产物说明。
9. 输出 `downstream_handoff` 给 N210 / N330。
10. 使用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 小接口：至少覆盖 request / response。
- 中等复杂度：补 command / query / view 以及 shared nested objects。
- 跨模块接口：必须显式列出 shared object、type conventions 和 drift watchlist。

## Quality bar / 质量门槛
合格结果应让下游直接开始补 validation、异常映射和 documentation，而不需要重新讨论 DTO 命名、字段可空性、时间 / 金额 / ID 的跨端约定。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md`
