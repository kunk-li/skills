---
name: enum-definition-generation
description: generate workflow-aligned enum drafts from api contracts, business rules, table constraints, and bounded value sets. use when chatgpt works in coding & implementation / code generation and must produce the workflow-aligned 枚举定义.java for n200 after scaffold generation and before static quality checks or documentation generation.
---
# enum-definition-generation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 代码生成 -> 枚举定义.java」。

它是 **direct_result** 型技能：目标不是泛泛讨论常量集合，而是把状态、类型、错误码伴生值和受限值域，稳定落成可被下游直接消费的 **`枚举定义.java`** 级别 enum 草稿。

### Boundary / 边界
- 负责 categorical / flag 两类 enum 的定义草稿。
- 负责 code-first 的 DB / wire format 对齐、i18n key、兼容性与生命周期规则。
- 不负责异常处理实现本身，也不负责 DTO / validator / SQL 的完整生成。
- 不把开放集合错误地枚举化。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `from_rules`：从业务规则、状态机、错误类别生成 enum。
- `from_schema`：从表约束、代码表、DB code 集合反推 enum。
- `contract_merge_mode`：综合 API contract、规则和 schema 做统一枚举输出。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `接口设计草案.yaml`
- `业务规则清单.csv`
- `错误码清单.csv`
- `表结构设计草案.sql`

### 可选增强输入
- 状态流转表.csv
- 现有 DB code / code table
- i18n 词条说明
- 前端枚举展示需求

## Standalone rule / 独立使用规则
即使只拿到值域列表、状态机说明或 DB code，也可以单独使用。

降级规则：
- 缺少 API contract 时，也可先生成 enum catalog + Java skeleton。
- 缺少 schema 时，也可先输出 wire / DB mapping assumptions。
- 顶部必须标明 `readiness: provisional` 或 `readiness: constrained`。
- 必须显式写出 `compatibility_assumptions[]`、`deprecated_values[]` 与 `pending_decisions[]`。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_generation.enum_definition_generation`
  - `workflow_node: N200`
  - `node_artifact_target: 枚举定义.java`
  - `evidence_profile`
- `enum_kind_policy`
- `enum_catalog[]`
- `wire_and_db_mapping`
- `i18n_bundle`
- `lifecycle_compatibility_rules`
- `drift_watchlist[]`
- `downstream_handoff`
  - `workflow_downstream`: `N210`, `N330`
  - `artifact_name: 枚举定义.java`
  - `sibling_dependencies`: `dto`, `validator`, `exception`
- `self_check`

## Design rules / 设计规则
### Enum kind
必须区分：
- `categorical`：互斥状态 / 类型 / 分类
- `flag`：位掩码权限或组合型值域

### Code-first mapping
必须以 `code` 作为跨层单一值，不依赖 Java `name()` 或 ordinal。
默认要求：
- DB 存 string code
- wire format 传 string code
- Java enum 提供 `fromCode(...)`
- 禁止依赖 `EnumType.ORDINAL`

### i18n bundle
必须给出 messageKey 方案，并显式列出至少：
- `default_locale_keys[]`
- `missing_locales[]`
- `frontend_exposure_policy`

### Lifecycle compatibility rules
必须声明：
- 是否允许追加值
- 如何处理 `@Deprecated` 老值
- 是否允许只读兼容旧值
- 新值上线前是否需要 DB / consumer 双边准备

## Execution workflow / 执行流程
1. 识别真正闭集、稳定且值得枚举化的集合。
2. 选择 `selected_mode`、`readiness` 与 source of truth。
3. 区分 categorical 与 flag，避免混型。
4. 固化 code-first wire / DB mapping。
5. 给出 i18n key 和生命周期兼容规则。
6. 标出 deprecated values、unknown values fallback 与 drift watchlist。
7. 形成 workflow 对齐的 **`枚举定义.java`** 产物说明。
8. 输出 `downstream_handoff` 给 N210 / N330。
9. 使用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 小型值域：至少覆盖 code、含义、兼容性。
- 中型系统：补 i18n、deprecated 生命周期、前后端暴露策略。
- 状态机密集场景：必须显式写出 categorical / flag 区分和 drift watchlist。

## Quality bar / 质量门槛
合格结果应让下游可以直接开始接 DTO、validator、异常映射和文档暴露，而不需要重新讨论枚举值究竟传 code、name 还是数字。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md`
