# Readiness inheritance

## Rules
- `pass`: stable value set and serialized form are known.
- `constrained`: values are mostly known, but transitions, codes, or compatibility rules remain partial.
- `blocked`: the value set is too unstable or too incomplete; output only a candidate inventory and warnings.

## Source-of-truth rule
Prefer explicit contract values, table constraints, or rule documents over guessed names.

## Gate-aware rule
When the value set is still changing, mark the draft as constrained and avoid language that implies the enum is final.
