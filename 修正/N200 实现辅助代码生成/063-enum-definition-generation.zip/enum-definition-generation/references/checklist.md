# Enum delivery checklist

- [ ] 只为稳定闭集生成 enum，而非开放集合
- [ ] 枚举值与上游 contract、DDL check 或接口返回值一致
- [ ] 状态型 enum 已写出合法流转或至少注明终态
- [ ] `ErrorCode`、类型枚举、状态枚举没有语义混装
- [ ] 反查方法只在确有序列化 code 时提供
- [ ] 输出中没有 setter、业务数据、上线承诺
