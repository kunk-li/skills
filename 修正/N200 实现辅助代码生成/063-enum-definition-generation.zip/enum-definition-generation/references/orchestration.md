# Orchestration for enum definition generation

## Upstream inputs
- Business rules and status definitions
- DDL check constraints or reference data
- API values and serialized forms
- Error semantics and event categories

## Downstream consumers
- DTO fields use enums as typed value sets.
- Validators enforce enum membership and transitions.
- Exception code systems may import `ErrorCode` or category enums.

## Collaboration details
- Load [n200-collaboration-matrix.md](n200-collaboration-matrix.md) when coordinating with dto, validator, exception, sql, or optimization skills.
- Load [n200-java-conventions.md](n200-java-conventions.md) when emitting Java code.
