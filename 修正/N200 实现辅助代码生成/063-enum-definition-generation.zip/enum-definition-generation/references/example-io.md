# Example inputs and outputs for enum generation

## Example 1: Status enum
Input:
- statuses: CREATED, ACTIVE, REVOKED, EXPIRED
- serialized values equal stored strings

Output shape:
- `AliasStatus` enum with transition notes

## Example 2: Error code companion
Input:
- stable error categories and 12 known codes

Output shape:
- `ErrorCode` enum or companion enum draft
- note about exception package ownership if needed

## Example 3: Open set should not become enum
Input:
- dynamic role codes managed by admin console

Output shape:
- refusal to hard-code the open set
- recommendation to keep registry or configuration driven
