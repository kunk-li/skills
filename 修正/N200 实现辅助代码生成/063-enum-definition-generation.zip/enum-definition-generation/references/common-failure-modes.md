# Common failure modes for enum generation

## F1. Turn an open set into an enum
Symptom: generate enums for fast-changing or unbounded business data.
Fix: keep open sets in configuration, registry, or database tables.

## F2. Drift from database or API values
Symptom: enum names look neat but serialized values no longer match the contract.
Fix: preserve the real codes or document the mapping explicitly.

## F3. Mix unrelated semantics in one enum
Symptom: one enum contains status, channel, and severity together.
Fix: split by one semantic axis per enum.

## F4. Skip transition hints for state enums
Symptom: consumers cannot tell which status changes are legal.
Fix: document allowed transitions in comments or helper methods.

## F5. Hide instability
Symptom: draft outputs look final even when value lists are still changing.
Fix: label assumptions and readiness clearly.
