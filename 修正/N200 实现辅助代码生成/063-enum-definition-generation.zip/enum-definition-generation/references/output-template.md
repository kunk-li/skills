# Output template: enum definitions

## Required shape
```java
/**
 * {Object} status or type.
 * Source: {contract, ddl check, or rule reference}
 * Readiness: {pass | constrained | blocked}
 * State notes: {optional transition hints}
 */
public enum {Name} {
    VALUE_A("A", "Description A"),
    VALUE_B("B", "Description B");

    private final String code;
    private final String description;

    {Name}(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() { return code; }
    public String getDescription() { return description; }
}
```

## Naming rules
- Enum class names should be singular and PascalCase.
- Enum values should be `SCREAMING_SNAKE_CASE`.
- Align serialized values with the source-of-truth contract or DDL check constraints.

## Required guidance
- Document valid transitions when the enum represents a state machine.
- Add `fromCode` or equivalent reverse mapping only when a serialized code is part of the contract.
- Keep enums immutable; do not add setters.

## Boundary rules
- Do not force open-ended datasets such as department ids or frequently changing role catalogs into enums.
- Do not bake i18n translations into enum values unless the codebase explicitly does so.
- Do not pretend the enum is final when the source contract is still unstable.
