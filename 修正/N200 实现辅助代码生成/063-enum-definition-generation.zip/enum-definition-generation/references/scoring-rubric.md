# Scoring rubric for enum drafts

Score each category from 0 to 2.

## 1. Bounded-set judgment
- 0: open sets forced into enums
- 1: mostly bounded, with some weak candidates
- 2: only stable closed sets are represented

## 2. Value alignment
- 0: serialized values drift from the source
- 1: minor drift or missing mapping notes
- 2: serialized values align cleanly with the source-of-truth

## 3. Semantic clarity
- 0: mixed meanings in one enum
- 1: some ambiguity remains
- 2: each enum has one clear semantic axis

## 4. State and compatibility notes
- 0: no transition or compatibility hints
- 1: partial hints only
- 2: transition and compatibility notes are explicit where needed
