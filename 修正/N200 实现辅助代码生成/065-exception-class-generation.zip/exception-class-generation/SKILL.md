---
name: exception-class-generation
description: generate workflow-aligned exception drafts from error-code contracts, failure semantics, validator outcomes, and infrastructure error handling rules. use when chatgpt works in coding & implementation / code generation and must produce the workflow-aligned 异常类.java for n200 after scaffold generation and before static quality checks or documentation generation.
---
# exception-class-generation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「编码与实现 -> 代码生成 -> 异常类.java」。

它是 **direct_result** 型技能：目标不是泛泛讨论异常风格，而是把业务失败、鉴权失败、参数失败、基础设施失败和外部依赖失败，稳定落成可被下游直接消费的 **`异常类.java`** 级别异常骨架。

### Boundary / 边界
- 负责基础异常层次、ErrorCode 绑定、结构化上下文和 stacktrace policy。
- 负责异常与 validator / controller advice / response mapping 的边界说明。
- 不负责完整 GlobalExceptionHandler 实现，也不直接覆盖日志平台配置。
- 不通过无限派生异常类表达所有业务差异。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `from_errorcodes`：以 `错误码清单.csv` 为主生成异常层次。
- `failure_semantics_mode`：以失败语义和规则为主生成骨架。
- `contract_merge_mode`：综合 error codes、validator outcomes 与 infrastructure rules 统一输出。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `接口设计草案.yaml`
- `业务规则清单.csv`
- `错误码清单.csv`
- `表结构设计草案.sql`

### 可选增强输入
- validator 草稿
- 现有异常基类
- handler / advice 约定
- 运行时日志策略

## Standalone rule / 独立使用规则
即使只拿到错误码或失败语义，也可以单独使用。

降级规则：
- 缺少 API contract 时，也可先生成 five-class hierarchy 和 error binding notes。
- 缺少 validator 细节时，也可先给 exception mapping assumptions。
- 顶部必须标明 `readiness: provisional` 或 `readiness: constrained`。
- 必须显式写出 `context_payload_assumptions[]` 与 `pending_decisions[]`。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_generation.exception_class_generation`
  - `workflow_node: N200`
  - `node_artifact_target: 异常类.java`
  - `evidence_profile`
- `exception_hierarchy`
- `error_code_binding`
- `unchecked_policy`
- `structured_context_payload`
- `stacktrace_policy`
- `handler_integration_notes`
- `drift_watchlist[]`
- `downstream_handoff`
  - `workflow_downstream`: `N210`, `N330`
  - `artifact_name: 异常类.java`
  - `sibling_dependencies`: `enum`, `validator`, `dto`
- `self_check`

## Design rules / 设计规则
### Flat hierarchy
默认只保留五类基础：
- `ValidationException`
- `BusinessException`
- `AuthException`
- `InfrastructureException`
- `ExternalServiceException`

差异化优先通过 `ErrorCode` 表达，而不是无限新建子类。

### Unchecked policy
除非明确要求兼容 checked API，默认统一为 unchecked exception。

### Structured context
异常内容必须优先结构化：`errorCode + context + cause`，而不是散文式 message。

### Stacktrace policy
业务异常默认可关闭重栈；系统异常和基础设施异常默认保留完整 stacktrace。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness` 与 source of truth。
2. 归并失败语义，落到五类基础异常层次。
3. 建立 ErrorCode 到异常类型的绑定规则。
4. 固化结构化上下文 payload 与 stacktrace policy。
5. 写出与 validator、DTO response、advice 层的 integration notes。
6. 标出 hierarchy drift 和 over-modeling 风险。
7. 形成 workflow 对齐的 **`异常类.java`** 产物说明。
8. 输出 `downstream_handoff` 给 N210 / N330。
9. 使用 checklist 与 failure review 自检。

## Dynamic completeness / 动态完整度
- 简单服务：至少给 five-class hierarchy 和 error binding。
- 中等复杂度：补 structured context、stacktrace policy、handler notes。
- 高失败密度：必须给 drift watchlist 和 validator / response mapping 边界。

## Quality bar / 质量门槛
合格结果应让下游直接开始接静态检查、错误响应统一和文档说明，而不需要重新讨论异常到底按场景爆炸建类还是按 ErrorCode 控制粒度。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md`
