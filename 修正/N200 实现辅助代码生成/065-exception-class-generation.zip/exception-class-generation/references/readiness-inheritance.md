# Readiness inheritance

## Rules
- `pass`: failure categories and outward-facing error semantics are sufficiently known.
- `constrained`: some categories or handler mappings are still unresolved; produce hierarchy skeletons only.
- `blocked`: failure semantics are too vague; output a category inventory and open questions.

## Source-of-truth rule
Use the provided error contract and failure semantics as the authoritative basis for exception design.

## Gate-aware rule
When handler mappings or error codes are unclear, mark them as unresolved rather than pretending the runtime flow is finished.
