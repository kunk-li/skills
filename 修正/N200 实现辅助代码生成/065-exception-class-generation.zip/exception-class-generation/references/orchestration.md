# Orchestration for exception generation

## Upstream inputs
- Error semantics and failure taxonomies
- Validation and business rule failure paths
- API error response contracts
- Logging and audit expectations

## Downstream consumers
- Validators and services throw these exceptions.
- Advice or global handlers map them to error responses.
- DTO response models may include stable error payload fields.

## Collaboration details
- Load [n200-collaboration-matrix.md](n200-collaboration-matrix.md) when coordinating with dto, enum, validator, sql, or optimization skills.
- Load [n200-java-conventions.md](n200-java-conventions.md) for Java naming and package conventions.
