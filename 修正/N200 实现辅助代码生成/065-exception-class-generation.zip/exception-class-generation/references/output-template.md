# Output template: exception classes

## Required inheritance idea
```java
public abstract class BaseException extends RuntimeException {
    private final ErrorCode errorCode;

    protected BaseException(ErrorCode errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public ErrorCode getErrorCode() {
        return errorCode;
    }
}
```

Then derive only the categories that truly need distinct handling, for example:
- `BusinessException`
- `ValidationException`
- `AuthzException`
- `StateTransitionException`
- `InfrastructureException`

## Required design rules
- Prefer a small, coherent hierarchy over one exception per minor variation.
- Bind exceptions to stable error codes or failure categories.
- Preserve causes when wrapping lower-level exceptions.
- Document which layer is expected to translate the exception into an API response.

## Boundary rules
- Do not create an explosion of tiny exception classes without distinct handling value.
- Do not expose sensitive payloads in messages.
- Do not claim the exception flow is already fully wired into runtime handlers.
