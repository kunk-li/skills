# Example inputs and outputs for exception generation

## Example 1: Business and validation split
Input:
- duplicate alias is a business failure
- malformed eid is a validation failure

Output shape:
- `BusinessException`
- `ValidationException`
- note about shared `ErrorCode`

## Example 2: Infrastructure wrapping
Input:
- repository timeout or db connectivity issue

Output shape:
- `InfrastructureException` draft with cause-preserving constructor

## Example 3: Advice mapping note
Input:
- API returns stable error response payload

Output shape:
- exception hierarchy plus note for global handler translation
