# Exception delivery checklist

- [ ] 已区分业务、鉴权、参数、状态、基础设施等主要异常类别
- [ ] 没有为每个微小差异都生成独立异常类
- [ ] `ErrorCode` 或失败类别绑定方式清楚
- [ ] 包装底层异常时保留 cause
- [ ] 消息内容不泄露敏感字段
- [ ] advice 或 handler 层的对接说明已标出
