# Common failure modes for exception generation

## F1. Create one class per error code
Symptom: the hierarchy explodes into dozens of near-empty subclasses.
Fix: keep a small set of categories and attach stable error codes.

## F2. Throw generic runtime exceptions
Symptom: business failures become opaque `RuntimeException` paths.
Fix: route failures through the declared base hierarchy.

## F3. Lose the cause chain
Symptom: wrapped infrastructure failures lose the original exception context.
Fix: preserve `cause` constructors.

## F4. Leak sensitive data in messages
Symptom: raw ids, names, or internal details appear in outward-facing exception text.
Fix: keep messages safe and push sensitive context into internal logging only.

## F5. Pretend handler integration is complete
Symptom: drafts sound as if advice layers and http mapping are already done.
Fix: describe the intended handler integration as a draft boundary only.
