# N200 collaboration matrix

## workflow alignment
- `workflow_node`: `N200`
- recommended node inputs:
  - `接口设计草案.yaml`
  - `业务规则清单.csv`
  - `错误码清单.csv`
  - `表结构设计草案.sql`
- downstream handoff:
  - `N210` for static quality review
  - `N330` for documentation and knowledge output

## recommended execution order
1. `enum-definition-generation`
2. `exception-class-generation`
3. `dto-vo-generation`
4. `validator-code-generation`
5. `sql-draft-generation`
6. `query-optimization-recommendation`

This is the preferred order, not a hard runtime dependency. When inputs are partial, generate the local draft and mark assumptions.

## field and contract handoffs
| From | To | Handoff |
|---|---|---|
| Enum | DTO/VO | enum typed fields, code-first wire values, i18n keys |
| Enum | Exception | `ErrorCode` and bounded failure categories |
| DTO/VO | Validator | field names, nullability, nested structure, pagination fields |
| Validator | Exception | validation failure categories and error binding expectations |
| SQL | DTO/VO | returned columns and naming alignment |
| SQL | Optimization | statements, plans, index assumptions, bottlenecks |
| Optimization | SQL | rewrite suggestions, index ideas, caching and pagination notes |

## readiness and source-of-truth rules
- Inherit readiness from upstream material. Do not upgrade blocked or constrained inputs on your own.
- Treat user-provided api contracts, schemas, field lists, rule tables, and error codes as the source of truth.
- When sources conflict, preserve the conflict explicitly in output comments instead of silently picking one side.
