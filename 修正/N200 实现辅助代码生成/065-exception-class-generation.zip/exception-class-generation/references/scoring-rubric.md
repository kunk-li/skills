# Scoring rubric for exception drafts

Score each category from 0 to 2.

## 1. Hierarchy quality
- 0: chaotic or overgrown hierarchy
- 1: usable but with some redundancy
- 2: small, coherent, and meaningful hierarchy

## 2. Error semantics
- 0: failure types are unclear
- 1: mostly clear but some categories blur together
- 2: failure categories and handling intent are explicit

## 3. Error-code binding
- 0: no stable error-code story
- 1: partial or inconsistent binding
- 2: stable and well-described binding strategy

## 4. Safety and handler awareness
- 0: leaks sensitive data or ignores translation layer
- 1: some safety notes exist
- 2: message safety and handler boundary are explicit
