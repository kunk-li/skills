# Output template: performance risk analysis

## 1. Objective
State the system scope, the most important flows, and the review decision needed.

## 2. Confirmed facts
List only facts grounded in the input.

## 3. SLO targets
List explicit or inferred targets such as:
- p95 or p99 latency
- throughput or qps
- concurrency
- availability
- async backlog or freshness lag
- recovery or degradation expectations

## 4. Performance risks
This is the main section.
Required columns:
| risk id | scenario | likely bottleneck | impact | severity | mitigation direction | affected slo |

Use severity levels such as high, medium, and low.

## 5. Bottleneck analysis
Scan at least these layers when relevant:
- database
- connection pool
- cache
- remote dependencies
- cpu or memory
- queue or mq
- bandwidth or network

## 6. Load patterns
Cover:
- typical daily load shape
- burst or abnormal load
- peak timing or batch windows

## 7. Mitigations
Split into:
- architecture-level changes
- hotspot-specific changes
- emergency or degradation options

## 8. Capacity planning
List the main resources, the watch signals, and what trigger should cause scaling or redesign.

## 9. Open questions
Use `Q-{NN}` ids.

## 10. Self-check
Confirm coverage, evidence quality, and blocked items.
