# Scoring rubric for performance risk analysis

## 4 - handoff ready
The output defines realistic targets, names the main bottleneck candidates, grades the risks, and provides actionable mitigation and capacity guidance.

## 3 - review ready
The major hotspots are clear, but some target assumptions, burst analysis, or signal definitions still need follow-up.

## 2 - partial
The output identifies some bottlenecks but lacks structured risk grading or capacity guidance.

## 1 - weak
The output is generic performance advice without grounded paths or targets.
