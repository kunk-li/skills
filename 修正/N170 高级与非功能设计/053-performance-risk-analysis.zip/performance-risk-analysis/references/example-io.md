# Example input and output shape

## Example input
A solution sketch says the system serves a request-driven workflow, runs nightly backfills, uses cache for hot reads, and receives settlement callbacks in bursts.

## Expected output shape
- confirmed facts table
- slo targets section
- risk table with ids such as `P-01`
- bottleneck analysis by layer
- load-pattern section
- mitigation and capacity-planning sections
