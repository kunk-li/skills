# Common failure modes for performance risk analysis

## F1: listing generic bottlenecks with no business path
Symptom: the output says "database may be slow" without naming the affected flow.
Fix: tie every risk to a concrete path and affected slo.

## F2: focusing only on average load
Symptom: the design ignores bursts, batch windows, or callback storms.
Fix: include peak and abnormal patterns explicitly.

## F3: treating cache as a guaranteed fix
Symptom: the output recommends caching without addressing invalidation, cold starts, or stampedes.
Fix: mention cache limits and fallback behavior.

## F4: ignoring queue and worker backlog
Symptom: async work exists but queue depth and drain rate are never discussed.
Fix: include backlog, retry, and freshness lag in the analysis.

## F5: promising precise numbers without evidence
Symptom: exact latency or capacity claims appear without load data.
Fix: label inferred targets as assumptions and say what must be measured later.
