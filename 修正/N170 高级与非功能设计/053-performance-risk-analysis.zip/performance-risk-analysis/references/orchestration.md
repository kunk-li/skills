# Orchestration for performance risk analysis

## Upstream inputs
- solution materials and workflow descriptions
- data model or storage recommendations if available
- concurrency, retry, or audit requirements when present

## Downstream consumers
- performance testing and scenario design
- capacity planning and observability setup
- engineering review of hotspots and mitigations

## Field-level mapping
- business path -> slo target
- bottleneck layer -> risk row
- queue or retry path -> burst-risk candidate
- audit retention or query requirement -> storage or query overhead
- blocked module -> placeholder risk row

## Batch coordination
Reuse `references/n170-integration-map.md` whenever the user is designing several N170 deliverables together.

## Standalone mode
If upstream materials are missing, infer from the design text and mark the target or risk as `inferred`.

## Evidence format

Use one stable reference style throughout a deliverable:

- api references: `API-{NNN}`
- table references: exact table name or `T{NN}`
- index references: `IDX-{NNN}`
- gap or question anchors: `GAP-{NN}` or `Q-{NN}`
- threat or risk anchors: `T-{NN}` or `R-{NN}`
- error codes: exact `SCREAMING_SNAKE_CASE`
