# Performance risk checklist

## Coverage
- [ ] important request, job, and callback paths are covered
- [ ] explicit or inferred slo targets are stated
- [ ] risk grading is present
- [ ] bottleneck layers are scanned systematically
- [ ] mitigation and capacity guidance are both present

## Design quality
- [ ] each risk links to a likely bottleneck layer
- [ ] burst behavior is covered, not just steady state
- [ ] emergency or degradation behavior is addressed
- [ ] signals and thresholds are suggested for monitoring
- [ ] blocked paths are not presented as fully analyzed

## Batch alignment
- [ ] lock, queue, or retry pressure from related skills is reflected
- [ ] audit-retention or audit-query overhead is reflected when relevant
- [ ] abuse or ddos-like security concerns are reflected when relevant
