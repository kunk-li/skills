---
name: performance-risk-analysis
description: analyze performance risks, hotspots, bottlenecks, capacity assumptions, and degradation plans from technical solution notes, vulnerability findings, schema drafts, permission constraints, api surfaces, and data-flow evidence. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 性能风险分析.md for n170 before task planning, implementation review, quality gates, or governance review.
---
# performance-risk-analysis

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 性能风险分析」。

它是 **direct_result** 型技能：目标是把 SLO、热点、瓶颈、资源预算、降级策略与压测计划落成可交付的 **`性能风险分析.md`**，而不是只给“可能会慢”这类定性提醒。

### Boundary / 边界
- 负责建立 SLO 论证链、热点扫描、瓶颈判断、容量预算、降级矩阵与压测计划。
- 负责把 schema、数据流、接口与依赖关系转成性能风险清单。
- 不替代并发与幂等设计，但应消费它们的约束并暴露交汇风险。
- 不替代安全威胁建模，但要识别 DoS、滥用与依赖级雪崩的性能后果。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `hotspot_scan`：快速识别热点与瓶颈；默认模式。
- `capacity_planning`：重点输出资源预算与扩容余量。
- `perf_test_planning`：重点输出压测场景、环境与通过条件。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `需求漏洞清单.csv`
- `表结构设计草案.sql`
- `权限矩阵.csv`

### 可选增强输入
- API 草案、数据流图、依赖清单、缓存设计、批任务设计、异步消费设计
- 预估流量、峰值场景、历史性能事故、SLA 或 timeout 约束
- `data_classification`、审计与授权链路、发布节奏与业务高峰窗口

## Standalone rule / 独立使用规则
即使只有技术方案与粗略流量预期，也可以单独使用。

降级规则：
- 若没有真实 benchmark，只能给 `assumed SLO` 与容量估算。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的负载、SLO、资源与风险。
- 不得把设计推断写成生产承诺。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.advanced_design.performance_risk_analysis`
  - `node_artifact_target: 性能风险分析.md`
  - `workflow_node: N170`
  - `evidence_profile`
- `slo_derivation[]`
- `hotspot_scan[]`
- `bottleneck_layers[]`
- `resource_budget`
- `degradation_matrix[]`
- `perf_test_plan[]`
- `blocker_signals[]`
- `downstream_handoff`
  - `workflow_downstream`: `N180`, `N210`, `N260`, `N390`
  - `artifact_name: 性能风险分析.md`
- `self_check`

## Design rules / 设计规则
### SLO derivation discipline / SLO 推导纪律
每个 SLO 必须写明：
- business requirement
- upstream or downstream timeout constraint
- benchmark or experience basis
- resource budget assumption

没有依据时，必须标成 assumption 或 stretch goal。

### Hotspot discipline / 热点纪律
至少检查这些 pattern：
- high write single table
- auto increment contention
- cold start
- time bomb growth
- thundering herd
- fanout amplification
- convoy / queue buildup

### Resource budget discipline / 资源纪律
至少估算：
- CPU
- memory
- connections
- storage growth
- network bandwidth
- headroom

### Degradation discipline / 降级纪律
每个关键依赖至少说明：
- timeout
- retry
- circuit breaker
- rate limit
- fallback behavior

### Perf test discipline / 压测纪律
关键路径必须有：
- load profile
- environment
- pass criteria
- observed metrics to collect

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 抽取关键 request / callback / batch / stream 路径。
3. 为关键路径建立 `slo_derivation`。
4. 结合 schema、data flow、依赖链扫描热点与瓶颈。
5. 输出资源预算与降级矩阵。
6. 生成 `perf_test_plan`。
7. 标记 blocker_signals 与跨切面风险。
8. 形成面向 N170 标准产物的 **`性能风险分析.md`**。
9. 输出 `downstream_handoff`，供 N180 / N210 / N260 / N390 消费。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 单服务：覆盖全部关键路径与主要依赖
- 中型系统：覆盖 steady state + peak + batch / callback 热点
- 大型平台：聚焦高价值路径、热点表、关键依赖与容量 cliff

## Quality bar / 质量门槛
合格结果应让团队明确知道“慢在哪里、为什么慢、要准备多少资源、出问题时怎么降级、如何验证”。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
