# Concurrency control checklist

## Coverage
- [ ] confirmed facts are separated from inferred recommendations
- [ ] all state-changing actions were scanned for concurrent access
- [ ] hotspots are ranked by likelihood and damage
- [ ] every high-risk hotspot has at least two control options
- [ ] must-test cases exist for the critical scenarios

## Design quality
- [ ] the recommended control matches the actual race shape
- [ ] retry, dedupe, and ordering assumptions are explicit
- [ ] lock-heavy choices explain throughput and deadlock tradeoffs
- [ ] queue or async choices explain delivery and reorder risks
- [ ] optimistic choices explain conflict detection and retry behavior

## Batch alignment
- [ ] idempotency dependencies are called out when duplicate work is possible
- [ ] audit requirements are called out when conflicts or overrides matter
- [ ] performance implications are called out for lock contention or queue buildup
- [ ] security implications are called out for lock abuse or starvation

## Prohibited mistakes
- [ ] no vague statement like "add lock" without scope and trigger
- [ ] no hidden assumptions about single-user behavior
- [ ] no blocked module presented as fully designed
