# Orchestration for concurrency control recommendation

## Upstream inputs
- PRD facts or upstream technical-design outputs
- api or workflow descriptions for mutating operations
- data-model outputs if table or object boundaries are already known

## Downstream consumers
- implementation design and code review
- idempotency design for duplicate-processing paths
- audit design for conflict, override, or manual-repair events
- performance and security analysis for contention and starvation risks

## Field-level mapping
- mutating operation -> hotspot id
- shared object -> lock or version scope
- retry path -> idempotency dependency
- manual override or forced repair -> audit event candidate
- queue serialization decision -> performance backlog consideration

## Batch coordination
Reuse `references/n170-integration-map.md` whenever the user is designing several N170 deliverables together.

## Standalone mode
If upstream materials are missing, infer from the PRD and mark the hotspot and recommendation as `inferred`.

## Evidence format

Use one stable reference style throughout a deliverable:

- api references: `API-{NNN}`
- table references: exact table name or `T{NN}`
- index references: `IDX-{NNN}`
- gap or question anchors: `GAP-{NN}` or `Q-{NN}`
- threat or risk anchors: `T-{NN}` or `R-{NN}`
- error codes: exact `SCREAMING_SNAKE_CASE`
