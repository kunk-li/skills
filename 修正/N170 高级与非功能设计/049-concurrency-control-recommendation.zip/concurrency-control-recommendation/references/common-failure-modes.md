# Common failure modes for concurrency control recommendation

## F1: recommending a lock without defining the protected object
Symptom: the output says to lock but never says what key or object is serialized.
Fix: always name the shared object and the competing actors.

## F2: solving a duplicate-processing problem with locking only
Symptom: retries and redelivery exist, but the design ignores dedupe or idempotency.
Fix: combine concurrency control with idempotency rules when the same request may reappear.

## F3: treating ordering problems as simple race conditions
Symptom: the design focuses on mutual exclusion but ignores out-of-order callbacks or async completions.
Fix: add sequence numbers, version checks, or terminal-state guards.

## F4: selecting pessimistic locking for broad workflows by default
Symptom: long user-driven flows stay locked across network or approval delays.
Fix: prefer short critical sections, optimistic checks, or queue serialization.

## F5: missing failure-observability requirements
Symptom: the design has controls but no way to observe retries, deadlocks, queue lag, or conflict rates.
Fix: require metrics, logs, and alertable signals in must-test cases.
