# Output template: concurrency control recommendation

## 1. Objective
State the business scope, the shared objects under contention, and the intended review outcome.

## 2. Confirmed facts
List only facts grounded in the input.

## 3. Concurrency hotspots
This is the main section.

### Required structure
Rank hotspots by likelihood multiplied by damage.

#### High risk
For each item include:
- hotspot id
- shared object
- competing actors
- race shape
- damage if broken
- evidence anchors

#### Medium risk
Keep lighter but still structured.

#### Low risk
Note why lighter controls are acceptable.

## 4. Control options
For every high-risk hotspot, compare two or three candidate controls.

Required columns:
| hotspot id | option | idea | strengths | weaknesses | fit by qps or load shape | recommendation |

## 5. Failure scenarios
Must classify at least these patterns when relevant:
- deadlock
- long transaction stall
- stale read drift
- out-of-order completion
- duplicate processing

## 6. Must-test cases
Use a table:
| cc-id | scenario | expected outcome | required observability |

## 7. Blocked scope
List deferred modules or unresolved preconditions without pretending they are designed.

## 8. Open questions
Use `Q-{NN}` ids.

## 9. Self-check
Confirm coverage, evidence quality, and blocked items.
