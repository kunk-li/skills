# Scoring rubric for concurrency control recommendation

## 4 - handoff ready
The output identifies the real hotspots, compares viable controls, explains tradeoffs, and gives must-test cases that an engineer can implement from.

## 3 - review ready
The hotspot list and recommendations are solid, but some option detail or observability detail is still thin.

## 2 - partial
The output names some concurrency issues but lacks clear control scope, tradeoffs, or test cases.

## 1 - weak
The output is generic advice with little grounding in the actual workflow.
