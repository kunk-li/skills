# Example input and output shape

## Example input
A PRD says that a user can submit an approval request, an approver can accept it, an admin can force-close it, and async callbacks may arrive from an external system.

## Expected output shape
- confirmed facts table
- hotspot list with ids such as `CC-01`
- control-options comparison per hotspot
- failure scenarios section
- must-test cases table
- blocked scope and open questions
