---
name: concurrency-control-recommendation
description: design concurrency control strategies from technical solution notes, vulnerability findings, schema drafts, permission constraints, api contracts, data-flow evidence, or upstream nonfunctional analysis. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 并发控制建议.md for n170 before task planning, static review, special testing, or governance review.
---
# concurrency-control-recommendation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 并发控制建议」。

它是 **direct_result** 型技能：目标是把竞争、锁、隔离级别、顺序约束和 must-test 场景落成可交付的 **`并发控制建议.md`**，而不是只给几个泛化建议。

### Boundary / 边界
- 负责识别竞争热点、竞态场景、锁策略、序列化策略与事务保护方式。
- 负责比较乐观锁、悲观锁、队列化、版本控制、状态机守卫、分布式锁等方案。
- 不负责重放幂等语义本身；该职责交给 `idempotency-design-recommendation`。
- 不负责安全威胁建模、审计保留或性能容量建模，但要为这些技能提供并发假设与 blocker 信号。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `scenario_checklist`：快速识别业务场景会命中哪些竞态类型；默认模式。
- `tech_pick`：在候选实现方案之间做技术选型与 trade-off。
- `workflow_hardening`：围绕关键流程输出完整的锁、隔离、顺序与失败恢复策略。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `需求漏洞清单.csv`
- `表结构设计草案.sql`
- `权限矩阵.csv`

### 可选增强输入
- API 草案、错误码草案、数据流图、事件流、回调设计、定时任务设计
- 现有并发事故、重试策略、消费模式、job 运行方式
- `data_classification`、append-only、审计或合规要求

## Standalone rule / 独立使用规则
即使只有技术方案与业务描述，也可以单独使用。

降级规则：
- 若缺少明确流程或对象模型，可先输出 provisional race map。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的对象、操作、竞争关系。
- 没有真实吞吐或冲突率时，不得伪装成精确锁等待或性能结论。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.advanced_design.concurrency_control`
  - `node_artifact_target: 并发控制建议.md`
  - `workflow_node: N170`
  - `evidence_profile`
- `scenario_inventory[]`
- `race_scenarios[]`
- `lock_selection_decision[]`
- `lock_granularity[]`
- `locking_order_policy`
- `isolation_strategy[]`
- `control_recommendations[]`
- `must_test_cases[]`
- `blocker_signals[]`
- `downstream_handoff`
  - `workflow_downstream`: `N180`, `N210`, `N260`, `N390`
  - `artifact_name: 并发控制建议.md`
- `self_check`

## Design rules / 设计规则
### Race scenario taxonomy / 竞态场景分类
至少检查这些类型：
- `RS-01 write_write`
- `RS-02 read_modify_write`
- `RS-03 unique_check_race`
- `RS-04 increment_race`
- `RS-05 duplicate_produce`
- `RS-06 duplicate_consume`
- `RS-07 aba`
- `RS-08 temporal_ordering`
- `RS-09 fence_violation`
- `RS-10 resource_starvation`

### Lock selection discipline / 锁选型纪律
每个高风险场景至少比较两种控制方式，并说明主选与备选：
- optimistic CAS / versioning
- pessimistic lock / `FOR UPDATE`
- queue serialization
- state-machine guard
- distributed lock with renewal and fencing token

### Lock granularity discipline / 粒度纪律
必须显式说明锁粒度：
- `table_level`
- `row_level`
- `record_logical`
- `key_level`

不要把无索引查询导致的隐式大锁误写成“行级锁”。

### Isolation discipline / 隔离纪律
每个关键场景应写：
- baseline isolation
- additional lock if needed
- reason

默认优先“较低隔离级别 + 显式热点保护”，不要无理由把所有流程升到 `SERIALIZABLE`。

### Deadlock discipline / 死锁纪律
必须定义：
- 全局加锁顺序
- lock timeout
- deadlock retry policy
- 不持锁跨 I/O 规则

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 从技术方案、schema、权限与流程中抽取共享对象与状态变更操作。
3. 盘点并发 actor、回调、任务、重试与消费路径。
4. 将关键场景归类到 `race_scenarios`。
5. 为高风险场景比较控制方式并给 `lock_selection_decision`。
6. 明确锁粒度、隔离级别、加锁顺序与失败恢复。
7. 生成 must-test cases 与 blocker_signals。
8. 形成面向 N170 标准产物的 **`并发控制建议.md`**。
9. 输出 `downstream_handoff`，供 N180 / N210 / N260 / N390 消费。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 单个 API / 单条流程：覆盖全部共享对象与状态迁移
- 中型业务流：覆盖全部高风险热点与关键交叉路径
- 大型系统：聚焦核心竞争域、热点流程、外部回调与批处理交汇点

## Quality bar / 质量门槛
合格结果应能直接指导实现、测试与专项门禁，而不需要再次解释“为什么这里会冲突”。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
