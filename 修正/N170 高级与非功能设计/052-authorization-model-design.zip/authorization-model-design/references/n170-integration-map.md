# N170 integration map

Use this file to reason about adjacent N170 skills when the user is working on non-functional design as a set instead of as a single deliverable.

## Cross-skill matrix

| from | strongest links |
| --- | --- |
| concurrency control | idempotency, performance, security |
| idempotency | concurrency control, audit trail, security |
| audit trail | idempotency, authorization, security |
| authorization model | audit trail, security, concurrency control |
| performance risk | concurrency control, audit trail, security |
| security risk | authorization model, performance risk, audit trail |

## Practical guidance

- Reuse the same evidence anchors across the related deliverables.
- Keep blocked scope consistent across all skills in the batch.
- If one deliverable depends on another skill's field names, say so explicitly instead of silently rephrasing.
- If the user only asks for one skill, do not force the other five; mention them only when they materially improve the answer.
