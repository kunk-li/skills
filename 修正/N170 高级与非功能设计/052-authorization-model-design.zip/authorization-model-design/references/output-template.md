# Output template: authorization model design

## 1. Objective
Answer what authorization model is chosen, why it fits, and what review decision is needed.

## 2. Confirmed facts
List only facts grounded in the input.

## 3. Authorization model choice
### 3.1 model selection
Explicitly choose one of:
- rbac
- rbac plus scope
- abac fragments
- hybrid rbac plus abac
- another mainstream model if the input demands it

### 3.2 model dimensions
Cover:
- subjects or roles
- permissions or actions
- resources
- context attributes

### 3.3 evaluation flow
Include an ascii pipeline with six or more steps.

## 4. Role catalog
Cover role groups, key permissions, inheritance, and ghost-role rejection.

## 5. Resource-action matrix
Use a table such as:
| resource | view | edit | approve | export | notes |

If field-level permissions matter, add a separate sub-section.

## 6. Permission composition
Must discuss at least:
- multiple concurrent roles
- temporary grants or delegated tokens
- context or scope-based narrowing

## 7. Special scenarios
Cover when relevant:
- channel isolation
- hidden entities or physical invisibility
- high-intensity or emergency paths
- degraded or fallback mode

## 8. Storage and caching
State the source of truth, cache strategy, and invalidation behavior.

## 9. Open questions
Use `Q-{NN}` ids.

## 10. Self-check
Confirm coverage, evidence quality, and blocked items.
