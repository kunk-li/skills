# Orchestration for authorization model design

## Upstream inputs
- permission matrix or role catalog if available
- PRD facts, resource definitions, and action definitions
- security or audit requirements when present

## Downstream consumers
- implementation design for access checks
- audit design for decision and override events
- security analysis for privilege-escalation and bypass risks
- concurrency analysis for matrix refresh or invalidation races

## Field-level mapping
- role or subject -> role catalog entry
- resource and action -> matrix cell
- context attribute -> abac rule or scope rule
- deny reason -> audit or security event candidate
- cache invalidation path -> concurrency concern

## Batch coordination
Reuse `references/n170-integration-map.md` whenever the user is designing several N170 deliverables together.

## Standalone mode
If upstream materials are missing, infer from the PRD and mark the model choice or rule as `inferred`.

## Evidence format

Use one stable reference style throughout a deliverable:

- api references: `API-{NNN}`
- table references: exact table name or `T{NN}`
- index references: `IDX-{NNN}`
- gap or question anchors: `GAP-{NN}` or `Q-{NN}`
- threat or risk anchors: `T-{NN}` or `R-{NN}`
- error codes: exact `SCREAMING_SNAKE_CASE`
