# Common failure modes for authorization model design

## F1: choosing pure rbac when the real business need is contextual
Symptom: roles exist, but channel, ownership, region, or scope conditions are ignored.
Fix: add abac or scoped rules where context truly matters.

## F2: defining field-level permissions without a trigger
Symptom: the output says a field is visible sometimes but never states when.
Fix: tie the field rule to role, status, channel, or ownership conditions.

## F3: ignoring ghost roles or invalid role codes
Symptom: the model assumes every supplied role identifier is valid.
Fix: define explicit rejection behavior for unknown roles.

## F4: describing caches without naming the source of truth
Symptom: the design speeds up access checks but never says what storage is authoritative.
Fix: define the authority and invalidation path.

## F5: failing to explain how multiple roles compose
Symptom: it is unclear whether privileges union, intersect, or require priority rules.
Fix: define composition behavior explicitly.
