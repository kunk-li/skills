# Scoring rubric for authorization model design

## 4 - handoff ready
The output clearly justifies the authorization model, defines the role catalog and matrix, explains composition and evaluation behavior, and is actionable for implementation review.

## 3 - review ready
The core model is clear, but some composition, cache, or special-scenario detail still needs follow-up.

## 2 - partial
The output names roles and permissions but lacks a complete model or evaluation pipeline.

## 1 - weak
The output is generic access-control advice without a grounded model.
