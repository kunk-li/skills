# Example input and output shape

## Example input
A PRD says internal reviewers, external partners, and admins can all access requests, but some actions depend on region, tenant, channel, and ownership.

## Expected output shape
- confirmed facts table
- model-choice section
- role catalog
- resource-action matrix
- permission composition rules
- evaluation pipeline, blocked scope, and open questions
