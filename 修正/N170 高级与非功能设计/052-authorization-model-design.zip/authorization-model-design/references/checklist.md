# Authorization model checklist

## Coverage
- [ ] the model choice is explicit and justified
- [ ] subjects, resources, actions, and context are all covered
- [ ] the role catalog is present
- [ ] the resource-action matrix is present
- [ ] the evaluation pipeline has six or more steps
- [ ] special scenarios are covered when relevant

## Design quality
- [ ] ghost roles or invalid role codes are explicitly rejected
- [ ] field-level permissions have scenario triggers if they exist
- [ ] multi-role composition rules are explicit
- [ ] source of truth and cache invalidation are explicit
- [ ] blocked domains are not presented as designed

## Batch alignment
- [ ] auditable decision points are identified for audit design
- [ ] cache-refresh and matrix-update risks are identified for concurrency analysis
- [ ] threat surfaces are identified for security analysis
