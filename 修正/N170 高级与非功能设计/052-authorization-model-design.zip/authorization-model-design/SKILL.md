---
name: authorization-model-design
description: design authorization models from technical solution notes, vulnerability findings, schema drafts, permission matrices, api surfaces, and contextual access requirements. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 权限模型设计.md for n170 before task planning, implementation, permission testing, or governance review.
---
# authorization-model-design

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 权限模型设计」。

它是 **direct_result** 型技能：目标是把角色、资源、动作、属性、裁决逻辑与策略生命周期落成可交付的 **`权限模型设计.md`**，而不是只给一个 RBAC 表格。

### Boundary / 边界
- 负责选择授权范式、定义策略裁决算法、划分 PDP / PEP / PIP / PAP、设计委托与策略生命周期。
- 负责把 `权限矩阵.csv` 与上下文约束转成可执行的授权模型。
- 不替代安全威胁建模，但要为权限提升、越权与代理授权提供结构化基础。
- 不替代审计留痕，但要指出哪些授权决策与策略变更必须入审计。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `paradigm_analyzer`：优先决定 RBAC / ABAC / ReBAC / hybrid；默认模式。
- `policy_architecture`：重点输出 PDP / PEP / PIP / PAP 架构与裁决链路。
- `delegation_hardening`：重点处理委托、代理、临时权限和策略生命周期。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `需求漏洞清单.csv`
- `表结构设计草案.sql`
- `权限矩阵.csv`

### 可选增强输入
- API 草案、数据流、组织角色结构、租户模型、字段脱敏要求、现有授权系统说明
- `data_classification`、审计要求、代理 / 副职 / 临时授权场景

## Standalone rule / 独立使用规则
即使只有权限矩阵、角色说明与技术方案，也可以单独使用。

降级规则：
- 若资源或动作模型不完整，可先输出 provisional authorization matrix。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的角色、资源、属性与策略。
- 不得用“管理员全权限”掩盖未建模的权限边界。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.advanced_design.authorization_model_design`
  - `node_artifact_target: 权限模型设计.md`
  - `workflow_node: N170`
  - `evidence_profile`
- `authorization_matrix[]`
- `auth_paradigm_decision`
- `combining_algorithm`
- `policy_architecture`
- `delegation_model`
- `policy_lifecycle`
- `decision_examples[]`
- `blocker_signals[]`
- `downstream_handoff`
  - `workflow_downstream`: `N180`, `N210`, `N260`, `N390`
  - `artifact_name: 权限模型设计.md`
- `self_check`

## Design rules / 设计规则
### Paradigm discipline / 范式纪律
必须说明主范式与原因：
- `rbac`
- `abac`
- `rebac`
- `hybrid`

不要只报一个名词，必须解释为什么它适合当前业务形态。

### Decision algorithm discipline / 裁决纪律
必须显式选择：
- `deny_overrides`
- `permit_overrides`
- `first_applicable`
- `only_one_applicable`
- `ordered_deny_overrides`

安全敏感系统默认优先考虑 `deny_overrides`。

### Architecture discipline / 架构纪律
必须说明：
- `PAP`
- `PDP`
- `PEP`
- `PIP`

并明确谁是 authoritative source、缓存在哪、如何失效。

### Delegation discipline / 委托纪律
若存在代理、代办、副职、on behalf of 场景，必须说明：
- `from` / `to`
- `scope`
- `valid_from` / `valid_until`
- `revocable`
- `transitive`
- 审计记录方式

### Policy lifecycle discipline / 策略生命周期纪律
策略不是一次性配置，必须说明：
- draft / active / deprecated / archived
- 生效时间
- 变更记录
- 灰度与回滚方式

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 从 `权限矩阵.csv`、技术方案与上下文约束中抽取 actor / resource / action。
3. 确定授权范式与裁决算法。
4. 设计 `policy_architecture` 与决策链路。
5. 处理委托 / 代理 / 临时授权与字段级限制。
6. 设计策略生命周期、变更与回滚。
7. 标记 blocker_signals 与需审计项。
8. 形成面向 N170 标准产物的 **`权限模型设计.md`**。
9. 输出 `downstream_handoff`，供 N180 / N210 / N260 / N390 消费。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 单业务域：覆盖全部角色、资源、动作与关键属性
- 中型系统：覆盖多租户、字段可见性、关键代理场景
- 大型平台：聚焦策略裁决架构、委托治理与生命周期控制

## Quality bar / 质量门槛
合格结果应让实现、测试与治理团队明确知道“谁能对什么做什么，在什么条件下做，以及策略如何演进”。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
