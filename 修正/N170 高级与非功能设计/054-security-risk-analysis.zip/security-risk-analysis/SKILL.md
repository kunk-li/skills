---
name: security-risk-analysis
description: analyze security risks, threat models, control gaps, residual risks, severity sla, supply-chain issues, and compliance alignment from technical solution notes, vulnerability findings, schema drafts, permission constraints, api surfaces, and data classification. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 安全风险分析.md for n170 before task planning, implementation review, special testing, or governance review.
---
# security-risk-analysis

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 安全风险分析」。

它是 **direct_result** 型技能：目标是把威胁建模、控制项、残余风险、修复优先级与合规映射落成可交付的 **`安全风险分析.md`**，而不是只给散乱的风险点清单。

### Boundary / 边界
- 负责建立 STRIDE 为主的威胁模型、数据保护三要素、供应链安全、severity SLA 与合规映射。
- 负责识别入口、信任边界、敏感资产、提权路径与高风险依赖。
- 不输出攻击操作细节；保持在设计审查与控制建议层级。
- 不替代授权、审计或性能设计，但要消费这些设计并暴露跨切面 blocker。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `stride_workshop`：以 STRIDE 为主做结构化威胁建模；默认模式。
- `compliance_gap_analysis`：重点输出法规与控制项差距。
- `control_hardening`：重点输出控制缺口、severity、SLA 与修复优先级。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `需求漏洞清单.csv`
- `表结构设计草案.sql`
- `权限矩阵.csv`

### 可选增强输入
- API 草案、数据流图、依赖清单、外部回调、认证授权方案、审计方案
- `data_classification`、敏感字段、合规范围、既有 incident 或 threat intel

## Standalone rule / 独立使用规则
即使只有技术方案与敏感数据 / 动作描述，也可以单独使用。

降级规则：
- 若系统分层或 trust boundary 不完整，可先输出 provisional threat map。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的入口、控制、法规适用与风险等级。
- 没有依据时，不得擅自声称某法规必然适用。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.advanced_design.security_risk_analysis`
  - `node_artifact_target: 安全风险分析.md`
  - `workflow_node: N170`
  - `evidence_profile`
- `threat_scope`
- `stride_analysis[]`
- `data_protection_triad`
- `supply_chain_security`
- `severity_sla`
- `compliance_mapping`
- `risk_register_entries[]`
- `incident_scenarios[]`
- `blocker_signals[]`
- `downstream_handoff`
  - `workflow_downstream`: `N180`, `N210`, `N260`, `N390`
  - `artifact_name: 安全风险分析.md`
- `self_check`

## Design rules / 设计规则
### STRIDE discipline / STRIDE 纪律
对每个组件 / 数据流 / 外部集成，优先扫描：
- `spoofing`
- `tampering`
- `repudiation`
- `information_disclosure`
- `denial_of_service`
- `elevation_of_privilege`

### Data protection discipline / 数据保护纪律
必须覆盖三要素：
- `in_transit`
- `at_rest`
- `in_use`

并结合 `data_classification` 说明哪些级别必须加密、脱敏、审计与访问控制。

### Supply chain discipline / 供应链纪律
至少说明：
- dependency scanning
- SBOM
- signing / provenance
- base image hygiene
- runtime protection

### Severity and SLA discipline / 严重级与 SLA 纪律
每个高优先风险必须标：
- `severity`
- `fix_sla`
- `owner_hint`
- `mitigation_direction`

### Compliance discipline / 合规纪律
只有在输入提供了行业、地域或业务范围依据时，才映射 GDPR / PCI / HIPAA / SOX / 中国个保法等控制项。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 抽取入口点、trust boundary、敏感资产、外部依赖与高权限动作。
3. 对关键组件与数据流运行 `stride_analysis`。
4. 设计 `data_protection_triad` 与控制缺口。
5. 评估供应链与依赖安全。
6. 给出 severity、SLA、compliance mapping 与 incident scenarios。
7. 标记 blocker_signals 与跨切面交汇风险。
8. 形成面向 N170 标准产物的 **`安全风险分析.md`**。
9. 输出 `downstream_handoff`，供 N180 / N210 / N260 / N390 消费。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 单一集成：覆盖全部入口、密钥、回调与敏感数据流
- 中型系统：覆盖所有关键组件、外部依赖与高权限路径
- 大型平台：聚焦核心 trust boundary、合规域与公开暴露面

## Quality bar / 质量门槛
合格结果应让团队明确知道“哪里最容易被打、当前有什么控制、还缺什么、多久必须修、哪些场景是 blocker”。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
