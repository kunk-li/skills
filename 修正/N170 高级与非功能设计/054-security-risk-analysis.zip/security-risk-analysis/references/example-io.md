# Example input and output shape

## Example input
A solution sketch includes external callbacks, partner-facing endpoints, sensitive personal data, privileged admin actions, and third-party integrations.

## Expected output shape
- confirmed facts table
- threat-model section with ids such as `T-01`
- control categories section
- prioritized residual-risk table
- incident-response scenarios
- compliance alignment, blocked scope, and open questions
