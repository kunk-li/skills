# Common failure modes for security risk analysis

## F1: mixing generic security advice with no threat frame
Symptom: the output lists random controls but never explains the actual threat categories.
Fix: choose a threat frame and apply it consistently.

## F2: treating existing controls as complete without evidence
Symptom: the design assumes auth, encryption, or logging already exist and work.
Fix: label controls as present, partial, assumed, or missing.

## F3: focusing only on prevention and ignoring detection and response
Symptom: the output lists controls but no incident scenarios or response needs.
Fix: add incident-response scenarios and detection hooks.

## F4: collapsing authorization and security into one vague section
Symptom: privilege boundaries are discussed loosely without naming the specific threat.
Fix: map privilege-escalation and bypass risks explicitly.

## F5: overclaiming compliance coverage
Symptom: the output states compliance is satisfied without input evidence.
Fix: speak only to alignment needs grounded in the provided materials.
