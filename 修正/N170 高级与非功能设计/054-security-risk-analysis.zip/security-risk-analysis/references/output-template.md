# Output template: security risk analysis

## 1. Objective
State the system scope, sensitive assets, and the review decision needed.

## 2. Confirmed facts
List only facts grounded in the input.

## 3. Threat model
Choose and state a frame such as stride, cia, or another mainstream model.

Required columns:
| threat id | threat | surface or boundary | current control | residual risk | severity |

## 4. Security controls
Group controls at least by:
- authentication
- authorization
- data protection
- input validation
- operational security
- response and recovery

## 5. High-priority residual risks
Use levels such as blocker, major, and minor.
Required columns:
| risk id | impact | current state | recommendation | decision deadline |

## 6. Incident-response scenarios
Describe at least five when relevant, such as:
- credential abuse
- privilege escalation
- sensitive-data exposure
- unsafe dependency or integration failure
- audit gap or delayed detection

## 7. Compliance alignment
List only relevant policy, control, or regulatory considerations grounded in the input.

## 8. Blocked scope
List deferred domains or unresolved prerequisites.

## 9. Open questions
Use `Q-{NN}` ids.

## 10. Self-check
Confirm coverage, evidence quality, and blocked items.
