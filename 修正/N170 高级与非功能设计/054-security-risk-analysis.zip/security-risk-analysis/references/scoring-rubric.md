# Scoring rubric for security risk analysis

## 4 - handoff ready
The output uses a clear threat frame, maps controls and residual risks well, prioritizes meaningful issues, and provides actionable incident and compliance guidance.

## 3 - review ready
The key risks are clear, but some control mapping, residual-risk detail, or incident coverage still needs follow-up.

## 2 - partial
The output identifies some risks but lacks a coherent frame or prioritization.

## 1 - weak
The output is generic security advice without grounded threats or controls.
