# Orchestration for security risk analysis

## Upstream inputs
- design materials, interface descriptions, and data-flow descriptions
- authorization, audit, and dependency details when present
- compliance or policy constraints when present

## Downstream consumers
- security review and control planning
- incident-response preparation
- engineering follow-up on residual risks

## Field-level mapping
- trust boundary or entry point -> threat row
- existing control -> control category
- privileged action -> residual-risk candidate
- detection or logging need -> audit dependency
- blocked domain -> placeholder risk row

## Batch coordination
Reuse `references/n170-integration-map.md` whenever the user is designing several N170 deliverables together.

## Standalone mode
If upstream materials are missing, infer from the design text and mark the threat or risk as `inferred`.

## Evidence format

Use one stable reference style throughout a deliverable:

- api references: `API-{NNN}`
- table references: exact table name or `T{NN}`
- index references: `IDX-{NNN}`
- gap or question anchors: `GAP-{NN}` or `Q-{NN}`
- threat or risk anchors: `T-{NN}` or `R-{NN}`
- error codes: exact `SCREAMING_SNAKE_CASE`
