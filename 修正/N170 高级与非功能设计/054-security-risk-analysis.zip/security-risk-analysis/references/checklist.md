# Security risk checklist

## Coverage
- [ ] entry points and trust boundaries are identified
- [ ] a threat-model frame is stated and used consistently
- [ ] controls are grouped clearly
- [ ] residual risks are prioritized
- [ ] incident-response scenarios are present
- [ ] compliance alignment is included when relevant

## Design quality
- [ ] each high-priority risk maps to impact and a mitigation direction
- [ ] missing, partial, and assumed controls are distinguished
- [ ] sensitive data and privileged actions are treated explicitly
- [ ] blocked domains are not presented as fully analyzed

## Batch alignment
- [ ] authorization weaknesses align with the authorization-model deliverable
- [ ] auditable security events align with the audit deliverable
- [ ] ddos or abuse-related load concerns align with the performance deliverable
