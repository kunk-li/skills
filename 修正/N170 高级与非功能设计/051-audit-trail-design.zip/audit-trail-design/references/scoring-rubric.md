# Scoring rubric for audit trail design

## 4 - handoff ready
The output defines the right event catalog, before-after rules, retention guidance, query needs, and privacy controls clearly enough for implementation and compliance review.

## 3 - review ready
The output covers the core audit shape, but some retention detail, sensitive-field handling, or query detail still needs follow-up.

## 2 - partial
The output names some events but lacks traceability detail or privacy rules.

## 1 - weak
The output is generic advice without grounded event design.
