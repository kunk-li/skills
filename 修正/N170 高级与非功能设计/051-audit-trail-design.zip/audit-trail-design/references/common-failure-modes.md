# Common failure modes for audit trail design

## F1: logging actions but not their targets
Symptom: the event names the actor but not the resource or record affected.
Fix: always define target identity and scope.

## F2: requiring before and after snapshots for everything
Symptom: the design stores huge snapshots even when a simple event fact would do.
Fix: reserve before and after capture for material state changes or investigations.

## F3: treating sensitive fields like ordinary strings
Symptom: passwords, secrets, tokens, or personal identifiers appear in raw form.
Fix: define masking, hashing, omission, or tokenization rules explicitly.

## F4: defining retention without investigator queries
Symptom: storage guidance exists but nobody can answer how auditors will search it.
Fix: pair retention decisions with concrete query patterns.

## F5: forgetting to audit audit access
Symptom: the system logs business actions but not access to sensitive audit history.
Fix: add meta-audit requirements when audit data itself is sensitive.
