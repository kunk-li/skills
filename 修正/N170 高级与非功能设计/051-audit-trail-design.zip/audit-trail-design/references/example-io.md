# Example input and output shape

## Example input
A PRD says that an operator can approve or reject requests, an admin can override the decision, background jobs may expire requests, and the system stores sensitive contact data.

## Expected output shape
- confirmed facts table
- audit event catalog with ids such as `AUD-01`
- before-after rules section
- retention guidance section
- query requirements section
- privacy notes, blocked scope, and open questions
