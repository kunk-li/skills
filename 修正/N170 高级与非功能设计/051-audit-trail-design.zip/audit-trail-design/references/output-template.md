# Output template: audit trail design

## 1. Objective
State the business scope, the investigation or compliance goal, and the kinds of actions that need traceability.

## 2. Confirmed facts
List only facts grounded in the input.

## 3. Audit events
This is the main section.

Classify events by type and severity.
Suggested severities: critical, high, medium, low.

Required columns:
| event id | trigger | actor | target | key fields | before required | after required | severity |

## 4. Field before and after rules
Split into:
- must capture before and after
- optional before and after
- prohibited raw capture for sensitive fields

For sensitive fields, state whether to hash, mask, tokenize, summarize, or omit.

## 5. Retention guidance
Cover:
- hot, warm, cold, and delete horizons
- partitioning hints
- legal or policy constraints if provided

## 6. Query requirements
At minimum include:
- investigator queries
- object-history queries
- actor-history queries
- admin review queries
- meta-audit queries for audit access itself

## 7. Privacy notes
Explain field-level masking and the boundary between audit data and operational logs.

## 8. Blocked scope
List deferred modules or unresolved preconditions.

## 9. Open questions
Use `Q-{NN}` ids.

## 10. Self-check
Confirm coverage, evidence quality, and blocked items.
