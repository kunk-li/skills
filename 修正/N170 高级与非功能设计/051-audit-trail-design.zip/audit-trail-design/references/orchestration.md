# Orchestration for audit trail design

## Upstream inputs
- PRD facts or upstream technical-design outputs
- action flows, approval flows, and state transitions
- authorization and security requirements where relevant

## Downstream consumers
- implementation design for event emission and storage
- compliance and investigation workflows
- security review and incident response planning
- performance planning for retention and query load

## Field-level mapping
- action or change -> audit event id
- sensitive field -> masking or omission rule
- duplicate suppression or replay outcome -> auditable event candidate
- authorization step -> approval or denial event candidate
- blocked module -> placeholder event family

## Batch coordination
Reuse `references/n170-integration-map.md` whenever the user is designing several N170 deliverables together.

## Standalone mode
If upstream materials are missing, infer from the PRD and mark the event row or rule as `inferred`.

## Evidence format

Use one stable reference style throughout a deliverable:

- api references: `API-{NNN}`
- table references: exact table name or `T{NN}`
- index references: `IDX-{NNN}`
- gap or question anchors: `GAP-{NN}` or `Q-{NN}`
- threat or risk anchors: `T-{NN}` or `R-{NN}`
- error codes: exact `SCREAMING_SNAKE_CASE`
