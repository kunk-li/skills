# Audit trail design checklist

## Coverage
- [ ] event catalog covers critical actor and system actions
- [ ] severity is assigned consistently
- [ ] before and after rules are defined where state changes matter
- [ ] retention and query requirements are both present
- [ ] privacy handling exists for sensitive fields

## Design quality
- [ ] audit events include enough identity and target context
- [ ] raw sensitive data is not logged without justification
- [ ] retention guidance reflects likely investigation windows
- [ ] query requirements map to real operator or compliance needs
- [ ] meta-audit expectations are covered when audit access itself is sensitive

## Batch alignment
- [ ] duplicate suppression or replay outcomes are auditable when needed
- [ ] authorization decisions are auditable when permission boundaries matter
- [ ] security incidents and high-risk controls map into the event catalog
- [ ] performance implications of large retention or query volume are called out

## Prohibited mistakes
- [ ] no confusion between audit logs and debug logs
- [ ] no blocked module presented as fully designed
- [ ] no raw sensitive-field capture without a stated rule
