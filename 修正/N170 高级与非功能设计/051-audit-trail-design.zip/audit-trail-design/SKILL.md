---
name: audit-trail-design
description: design audit trail requirements from technical solution notes, vulnerability findings, schema drafts, permission constraints, data classification, and compliance context. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 审计留痕方案.md for n170 before task planning, implementation, special testing, or governance review.
---
# audit-trail-design

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 审计留痕方案」。

它是 **direct_result** 型技能：目标是把审计事件、append-only 保障、查询模式、访问控制与保留策略落成可交付的 **`审计留痕方案.md`**，而不是只写“关键操作要审计”。

### Boundary / 边界
- 负责定义审计事件 schema、事件目录、留痕范围、append-only 技术保障、访问控制与 retention。
- 负责把合规和事故追溯需求转成可查询、可治理的审计模型。
- 不替代安全威胁建模，但要为安全和合规提供审计控制证据。
- 不替代性能容量分析，但要暴露审计写入和查询带来的性能压力。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `schema_bootstrap`：从零开始设计统一审计 schema 与事件目录；默认模式。
- `gap_analysis`：审查现有系统哪些敏感操作缺少审计。
- `retention_planning`：重点输出保留、冷热分层与归档策略。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `需求漏洞清单.csv`
- `表结构设计草案.sql`
- `权限矩阵.csv`

### 可选增强输入
- 数据流图、接口草案、敏感字段清单、合规要求、现有日志与审计表设计
- `data_classification`、append-only、导出与查询场景、组织角色模型

## Standalone rule / 独立使用规则
即使只有技术方案、schema 草案与敏感操作描述，也可以单独使用。

降级规则：
- 若没有现有事件目录，可先生成 provisional audit event catalog。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的事件、字段、访问控制与 retention。
- 不得用“会记录日志”代替真正的审计设计。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.advanced_design.audit_trail_design`
  - `node_artifact_target: 审计留痕方案.md`
  - `workflow_node: N170`
  - `evidence_profile`
- `standard_audit_schema`
- `event_catalog[]`
- `append_only_enforcement`
- `audit_access_control`
- `query_patterns[]`
- `retention_strategy`
- `gap_analysis[]`
- `blocker_signals[]`
- `downstream_handoff`
  - `workflow_downstream`: `N180`, `N210`, `N260`, `N390`
  - `artifact_name: 审计留痕方案.md`
- `self_check`

## Design rules / 设计规则
### Standard schema discipline / 标准 schema 纪律
所有审计事件默认至少包含：
- `event_id`
- `event_time`
- `event_name`
- `event_version`
- `actor`
- `target`
- `action`
- `context`
- `payload`
- `compliance`

### Append-only discipline / append-only 纪律
必须至少说明以下层级中的实施方案：
- `db_layer`
- `application_layer`
- `infrastructure_layer`
- `compliance_layer`

合规级审计至少要有双保险，不得只写口头“不可修改”。

### Access control discipline / 访问控制纪律
必须说明：
- 谁能读审计
- 谁能导出审计
- 审计访问本身如何再被审计
- 异常访问如何告警

### Query and retention discipline / 查询与保留纪律
必须说明：
- `by_actor`
- `by_target`
- `by_event_type`
- `timeline`
- `correlation`

同时必须给出 retention category、冷热分层与归档 / 销毁规则。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 抽取关键动作、敏感对象、追责要求与合规要求。
3. 设计 `standard_audit_schema` 与 `event_catalog`。
4. 设计 append-only 技术保障与访问控制。
5. 设计查询模式、索引暗示与保留策略。
6. 标记 gap、风险与 blocker_signals。
7. 形成面向 N170 标准产物的 **`审计留痕方案.md`**。
8. 输出 `downstream_handoff`，供 N180 / N210 / N260 / N390 消费。
9. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 单一流程：覆盖全部关键动作与追责路径
- 中型系统：覆盖全部高敏对象与主要 actor / target 查询路径
- 大型平台：聚焦核心合规域、导出风险、冷热分层与长期保留策略

## Quality bar / 质量门槛
合格结果应能让实现、合规和专项测试团队明确知道“记什么、怎么防篡改、谁能查、保留多久”。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
