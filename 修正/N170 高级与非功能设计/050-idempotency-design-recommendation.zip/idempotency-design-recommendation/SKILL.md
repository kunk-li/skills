---
name: idempotency-design-recommendation
description: design idempotency strategies from technical solution notes, vulnerability findings, schema drafts, permission constraints, api contracts, callback flows, or message-processing materials. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 幂等设计建议.md for n170 before task planning, implementation scaffolding, quality gates, or special testing.
---
# idempotency-design-recommendation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 幂等设计建议」。

它是 **direct_result** 型技能：目标是把重复请求、重试、重放、重复消费与去重策略落成可交付的 **`幂等设计建议.md`**，而不是停留在“加个幂等键”这类口号。

### Boundary / 边界
- 负责定义 operation 级幂等范围、key 生成方式、重复到达行为、存储策略与 TTL。
- 负责区分 API 幂等、消息消费幂等、Saga step 幂等、定时任务幂等。
- 不负责竞争资源序列化本身；该职责交给 `concurrency-control-recommendation`。
- 不负责错误码总表，但应为错误冲突、重复提交、重放冲突提供语义种子。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `quick_design`：按 scope 快速给默认方案；默认模式。
- `analyzer`：审计现有方案是否真正幂等并指出缺口。
- `workflow_hardening`：对关键流程输出完整重试、重播、去重与降级策略。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `需求漏洞清单.csv`
- `表结构设计草案.sql`
- `权限矩阵.csv`

### 可选增强输入
- API 草案、接口意图、消息模型、回调设计、Saga 流程、定时任务说明
- 现有 X-Idempotency-Key、唯一索引、Redis / DB 去重表设计
- `data_classification`、审计要求、客户端重试窗口

## Standalone rule / 独立使用规则
即使只有技术方案与 API / 流程描述，也可以单独使用。

降级规则：
- 若缺少实现细节，可先输出 provisional operation catalog。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的 scope、key、payload 规则。
- 不得假装系统已经具备 exactly-once 语义。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.advanced_design.idempotency_design`
  - `node_artifact_target: 幂等设计建议.md`
  - `workflow_node: N170`
  - `evidence_profile`
- `operation_catalog[]`
- `idempotency_scope[]`
- `key_generation_strategy[]`
- `idempotency_behavior[]`
- `storage_strategy[]`
- `ttl_guidelines[]`
- `gap_analysis[]`
- `blocker_signals[]`
- `downstream_handoff`
  - `workflow_downstream`: `N180`, `N210`, `N260`, `N390`
  - `artifact_name: 幂等设计建议.md`
- `self_check`

## Design rules / 设计规则
### Scope discipline / 范围纪律
每个 operation 必须先归到以下 scope 之一：
- `api_idempotency`
- `message_consumer_idempotency`
- `saga_step_idempotency`
- `scheduled_task_idempotency`

### Key strategy discipline / key 纪律
每个 must-idempotent operation 至少比较一种主策略与一种备选：
- `client_provided`
- `server_generated_nonce`
- `content_hash`
- `business_key`

### Duplicate behavior discipline / 重复到达纪律
必须显式写明：
- 同 key + 同 payload：返回旧结果 / no-op / merge
- 同 key + 异 payload：`409 conflict` 或等价协议冲突
- 不同 key + 同 payload：是否允许独立处理

### Storage discipline / 存储纪律
必须说明：
- Redis、DB、消息表或 saga 表谁是主存储
- 兜底策略是什么
- Redis 不可用时如何降级
- 成功结果与失败结果是否缓存，以及 TTL 差异

### TTL discipline / TTL 纪律
TTL 不能拍脑袋。至少要结合：
- 客户端重试窗口
- 业务容忍的重复窗口
- 存储成本
- 审计 / 合规要求

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 抽取所有可能重复到达或被重试的 operation。
3. 将 operation 归类到 `idempotency_scope`。
4. 设计 key、payload canonicalization、重复行为与冲突行为。
5. 设计 storage strategy、兜底与 TTL。
6. 标记 gap、风险与 blocker_signals。
7. 形成面向 N170 标准产物的 **`幂等设计建议.md`**。
8. 输出 `downstream_handoff`，供 N180 / N210 / N260 / N390 消费。
9. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 单个 API：覆盖全部重试与重复提交路径
- 中型流程：覆盖 API、回调、消费与 Saga 关键步骤
- 大型系统：聚焦金融、合规、外部集成与高代价重复路径

## Quality bar / 质量门槛
合格结果应让实现和测试团队明确知道“哪些操作必须幂等、用什么 key、重复来时怎么处理”。

## Reference files / 参考文件
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
