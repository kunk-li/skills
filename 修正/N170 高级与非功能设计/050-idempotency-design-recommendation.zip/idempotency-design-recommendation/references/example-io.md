# Example input and output shape

## Example input
A PRD says a user can submit payment once, the client may retry on timeout, an async callback confirms settlement later, and consumers may redeliver the settlement event.

## Expected output shape
- confirmed facts table
- operation classification table with ids such as `OP-01`
- dedupe-key design table
- retry behavior matrix
- consumer rules section
- idempotency gaps, blocked scope, and open questions
