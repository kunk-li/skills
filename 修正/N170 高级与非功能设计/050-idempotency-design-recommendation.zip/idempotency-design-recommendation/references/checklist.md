# Idempotency design checklist

## Coverage
- [ ] all externally repeatable operations were scanned
- [ ] must-idempotent, safe, and non-idempotent classes are separated
- [ ] every important operation has a key-source decision
- [ ] duplicate outcomes are explicitly defined
- [ ] retry behavior is covered for sync and async paths

## Design quality
- [ ] dedupe storage and retention are realistic for the operation frequency
- [ ] the design explains collision handling
- [ ] non-idempotent operations explain why they stay non-idempotent
- [ ] callback and consumer behavior is addressed where needed
- [ ] gap items include trigger conditions to revisit

## Batch alignment
- [ ] concurrency conflicts are linked when duplicate work can race
- [ ] audit requirements are linked when duplicate suppression must be traceable
- [ ] performance impact is linked when retries can create storms
- [ ] security risk is linked when replay or token reuse matters

## Prohibited mistakes
- [ ] no vague statement like "make it idempotent" without key and outcome
- [ ] no assumption of exactly-once delivery without evidence
- [ ] no blocked module presented as fully designed
