# Output template: idempotency design recommendation

## 1. Objective
State the business scope, the repeatable operations under review, and the decision goal.

## 2. Confirmed facts
List only facts grounded in the input.

## 3. Idempotent operations
This is the main section.

Classify operations into:
- must-idempotent
- naturally safe
- explicitly non-idempotent

Required columns:
| op id | api or event | method or trigger | classification | why | key source | duplicate outcome |

## 4. Dedupe keys
Explain the chosen strategy per important operation.

Cover these patterns when relevant:
- time-window keys
- uuid or request-id caches
- business-object state guards

Required columns:
| op id | key design | storage | retention window | collision rule | notes |

## 5. Retry behavior
Include:
- http or rpc retry matrix
- worker retry guidance
- callback or message redelivery rules
- backoff or storm-protection notes

## 6. Consumer rules
At minimum compare:
- message-id based dedupe
- business-state based dedupe

## 7. Idempotency gaps
Use risk grading such as blocker or major.
Required columns:
| gap id | missing control | impact | recommended fix | trigger to revisit |

## 8. Blocked scope
List deferred modules or unresolved preconditions.

## 9. Open questions
Use `Q-{NN}` ids.

## 10. Self-check
Confirm coverage, evidence quality, and blocked items.
