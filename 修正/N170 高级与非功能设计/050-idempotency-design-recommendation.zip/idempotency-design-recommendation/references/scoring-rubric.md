# Scoring rubric for idempotency design recommendation

## 4 - handoff ready
The output classifies the right operations, proposes believable keys and retention logic, defines duplicate outcomes, and covers retry paths well enough for implementation.

## 3 - review ready
The operation map is solid, but some key detail, retention logic, or consumer behavior still needs follow-up.

## 2 - partial
The output names some duplicate risks but lacks operation-level decisions.

## 1 - weak
The output is generic advice without grounded key design or retry logic.
