# Orchestration for idempotency design recommendation

## Upstream inputs
- PRD facts or upstream technical-design outputs
- api, callback, and consumer descriptions
- workflow steps where retries or redelivery may occur

## Downstream consumers
- implementation design for request handling and consumer logic
- audit design for duplicate suppression, replay rejection, or manual recovery
- performance analysis for retry storms and cache pressure
- security analysis for replay and forged-redelivery paths

## Field-level mapping
- operation id -> dedupe key design
- retry path -> duplicate outcome
- callback or message flow -> consumer-rule pattern
- blocked operation -> idempotency gap placeholder

## Batch coordination
Reuse `references/n170-integration-map.md` whenever the user is designing several N170 deliverables together.

## Standalone mode
If upstream materials are missing, infer from the PRD and mark the operation row or gap as `inferred`.

## Evidence format

Use one stable reference style throughout a deliverable:

- api references: `API-{NNN}`
- table references: exact table name or `T{NN}`
- index references: `IDX-{NNN}`
- gap or question anchors: `GAP-{NN}` or `Q-{NN}`
- threat or risk anchors: `T-{NN}` or `R-{NN}`
- error codes: exact `SCREAMING_SNAKE_CASE`
