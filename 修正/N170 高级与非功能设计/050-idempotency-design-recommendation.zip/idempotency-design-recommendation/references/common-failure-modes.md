# Common failure modes for idempotency design recommendation

## F1: using only the business object id when the same object supports multiple distinct operations
Symptom: one key incorrectly dedupes different actions.
Fix: include operation identity, actor, or state context when needed.

## F2: treating retries and redelivery as identical
Symptom: the design handles client retries but ignores async callbacks or worker retries.
Fix: cover sync and async repeat paths separately.

## F3: defining a key without a duplicate outcome
Symptom: the design stores a dedupe key but never says whether the duplicate gets the old result, a rejection, or a no-op.
Fix: define the duplicate outcome explicitly.

## F4: choosing a retention window with no relation to business timing
Symptom: the key expires too early or lives forever.
Fix: tie retention to retry windows, callback delays, or business dispute windows.

## F5: ignoring replay-sensitive security edges
Symptom: tokens, signatures, or callbacks can be replayed even though the business operation is deduped.
Fix: call out replay protections and security dependencies.
