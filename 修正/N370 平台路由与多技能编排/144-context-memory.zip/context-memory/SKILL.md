---
name: context-memory
description: build a cold-start snapshot and stable memory view for n370 workflows. use when chatgpt should preserve decisions, blockers, risks, deferred work, open questions, and pm overrides across sessions, emit a fixed-field snapshot contract, and keep downstream audit or orchestration consumers aligned without rewriting the whole project history.
---

# 上下文记忆

把跨会话、跨阶段、跨人员的项目信息压缩成 **可冷启动、可续写、可审计** 的上下文快照。

先阅读：
- `references/snapshot-contract.md`
- `references/cold-start-checklist.md`
- `references/audit-alignment.md`

## 固定 7 字段
快照主体固定包含：
`state` / `decisions` / `blockers` / `risks` / `deferred` / `open_questions` / `pm_overrides`

不要删字段，不要换同义名。

## 推荐输出模式
- 用户要冷启动包 / 交接包 → **snapshot mode**，输出 markdown 摘要 + JSON 或 YAML 附录
- 用户要只看关键信息 → **quick view**，但字段语义仍要对应固定 7 字段
- 用户给了旧快照 + 新变化 → **delta mode**，保留原 `snapshot_id` 或追加版本，不重写整段历史

## 默认契约模式（推荐）
当结果要给下游 N370 / N390 / handoff 消费时，输出：

- schema: `n370.context-memory.v2`
- top-level fields:
  `schema,snapshot_id,node_id,state,decisions,blockers,risks,deferred,open_questions,pm_overrides,evidence_ref`

规则：
- `state` 是当前局面，不是项目全史
- `decisions` 只记录已经落锤或明确待撤销的事项
- `blockers` / `risks` 尽量复用上游稳定 id
- `pm_overrides` 只放人工覆盖与拍板，不混入普通观察
- 拿不到内容时用空数组或 `unknown`，不要伪造

## 工作流
1. 先区分“事实状态”和“背景材料”。
2. 把会影响下次冷启动的内容优先写入固定 7 字段。
3. 若有旧快照，优先增量刷新，不删除仍然有效的决定。
4. 对每条重大变更标注来源证据。
5. 输出前用 `references/cold-start-checklist.md` 反查一次。

## 严格边界
- 不在这里重做详细业务分析。
- 不把猜测写成决议。
- 不把任务清单整表复制进 snapshot；只保留对冷启动最关键的摘要。

## 质量检查
- 固定 7 字段都存在。
- 决议、阻塞、风险、延期项彼此不混类。
- `pm_overrides` 只记录人工拍板。
- 若输出机器可读快照，可运行 `scripts/validate_snapshot.py`。
