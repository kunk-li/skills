#!/usr/bin/env python3
import json
import sys
from pathlib import Path
import yaml

REQUIRED = [
    'schema','snapshot_id','node_id','state','decisions','blockers','risks',
    'deferred','open_questions','pm_overrides','evidence_ref'
]

def load_any(path: Path):
    text = path.read_text(encoding='utf-8')
    if path.suffix.lower() == '.json':
        return json.loads(text)
    return yaml.safe_load(text)

def main():
    if len(sys.argv) != 2:
        print('Usage: python validate_snapshot.py <snapshot.yaml|json>')
        sys.exit(1)
    data = load_any(Path(sys.argv[1]))
    for key in REQUIRED:
        if key not in data:
            raise ValueError(f'missing required field: {key}')
    if data['schema'] != 'n370.context-memory.v2':
        raise ValueError('schema must be n370.context-memory.v2')
    for key in ['decisions','blockers','risks','deferred','open_questions','pm_overrides','evidence_ref']:
        if not isinstance(data[key], list):
            raise ValueError(f'{key} must be a list')
    if not isinstance(data['state'], dict):
        raise ValueError('state must be a mapping')
    print('snapshot is valid')

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'validation failed: {e}')
        sys.exit(1)
