# 与 Audit 的对齐方式

Snapshot 可以视为 audit 的一种 state view。

## 推荐保留的共享语义
- `snapshot_id`
- `state.current_pipeline_id`
- `state.current_state_id`
- 决议 / 阻塞 / 风险的稳定 ID
- `evidence_ref`

## 对齐原则
- audit 更关心“发生过什么”；snapshot 更关心“现在接手需要知道什么”。
- 两者可以共享字段，但不要把 snapshot 写成流水账。
