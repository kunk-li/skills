# 冷启动 Checklist

新会话接手前，优先检查：
1. `state` 是否足够说明当前卡在哪个 node / pipeline / state。
2. 最近的关键 `decisions` 是否齐全。
3. 当前仍未解除的 `blockers` 与 `risks` 是否区分清楚。
4. `deferred` 是否明确说明被延后而非被删除。
5. `open_questions` 是否足以指导下一轮追问或验证。
6. 是否存在 `pm_overrides`，以及这些人工拍板是否覆盖了默认规则。
7. 证据引用是否够下一位读者快速复核。
