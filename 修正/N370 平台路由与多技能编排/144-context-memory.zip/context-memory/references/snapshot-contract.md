# Snapshot Contract

## Canonical structure

```yaml
schema: n370.context-memory.v2
snapshot_id: SNAP-20260423-01
node_id: N370
state:
  stage: N370
  current_pipeline_id: PL-01
  current_state_id: N370.PL-01.ST-03
  summary: 需求质量门禁已结束，等待多 skill 编排。
decisions: []
blockers: []
risks: []
deferred: []
open_questions: []
pm_overrides: []
evidence_ref: []
```

## 字段规则
- `state` 只描述当前局面与最近一次 handoff 所需状态。
- `decisions` / `blockers` / `risks` / `deferred` / `open_questions` / `pm_overrides` 统一用列表。
- 列表元素可为字符串或结构化对象，但同一份快照内尽量保持一种风格。
- `evidence_ref` 记录支撑快照的来源；多值建议用数组。
