#!/usr/bin/env python3
import ast
import sys
from pathlib import Path
import yaml

PRIORITY = {"P0": 0, "P1": 1, "P2": 2}

def err(msg):
    raise ValueError(msg)

def load_yaml(path):
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def validate_expr(node):
    allowed = (
        ast.Expression, ast.BoolOp, ast.UnaryOp, ast.BinOp,
        ast.And, ast.Or, ast.Not, ast.Compare, ast.Name,
        ast.Load, ast.Constant, ast.Call, ast.Gt, ast.GtE,
        ast.Lt, ast.LtE, ast.Eq, ast.NotEq,
    )
    for n in ast.walk(node):
        if not isinstance(n, allowed):
            err(f"Unsupported syntax in condition_dsl: {type(n).__name__}")
        if isinstance(n, ast.Call):
            if not isinstance(n.func, ast.Name) or n.func.id not in {"has", "contains", "count"}:
                err("Only has(), contains(), count() helpers are allowed")

def eval_expr(expr, context):
    tree = ast.parse(expr, mode='eval')
    validate_expr(tree)
    def has(key):
        return key in context and context[key] not in (None, '', [], {})
    def contains(key, value):
        target = context.get(key)
        if isinstance(target, list):
            return value in target
        if isinstance(target, str):
            return value in target
        return False
    def count(key):
        target = context.get(key)
        if target is None:
            return 0
        if isinstance(target, (list, tuple, dict, str)):
            return len(target)
        return int(target)
    names = {k: v for k, v in context.items() if k.isidentifier()}
    env = {"__builtins__": {}, "has": has, "contains": contains, "count": count, **names}
    return bool(eval(compile(tree, '<dsl>', 'eval'), env, {}))

def validate_route(r, seen_ids):
    required = [
        "route_id","pipeline_id","state_id","trigger_type","condition_dsl","selected_skill",
        "priority","fallback_chain","inputs_required","outputs_expected","rationale",
        "confidence","evidence_ref"
    ]
    for key in required:
        if key not in r:
            err(f"route missing required field: {key}")
    rid = r['route_id']
    if rid in seen_ids:
        err(f"duplicate route_id: {rid}")
    seen_ids.add(rid)
    if r['priority'] not in PRIORITY:
        err(f"invalid priority for {rid}: {r['priority']}")
    if not isinstance(r['fallback_chain'], list):
        err(f"fallback_chain must be a list: {rid}")
    if not isinstance(r['inputs_required'], list) or not isinstance(r['outputs_expected'], list):
        err(f"inputs_required/outputs_expected must be lists: {rid}")
    if not isinstance(r['evidence_ref'], list):
        err(f"evidence_ref must be a list: {rid}")
    if not str(r['pipeline_id']).startswith('PL-'):
        err(f"pipeline_id format invalid: {rid}")
    if '.R' not in str(r['route_id']) or '.ST-' not in str(r['state_id']):
        err(f"route_id/state_id do not follow shared id space: {rid}")
    validate_expr(ast.parse(r['condition_dsl'], mode='eval'))

def choose_route(routes, context):
    matched = []
    for idx, r in enumerate(routes):
        if eval_expr(r['condition_dsl'], context):
            matched.append((PRIORITY[r['priority']], idx, r))
    if not matched:
        return None
    matched.sort(key=lambda x: (x[0], x[1]))
    return matched[0][2]

def main():
    if len(sys.argv) != 2:
        print('Usage: python validate_routes.py <routes.yaml>')
        sys.exit(1)
    data = load_yaml(sys.argv[1])
    if data.get('schema') != 'n370.skill-routing-selection.v2':
        err('schema must be n370.skill-routing-selection.v2')
    if 'node_id' not in data or 'routes' not in data:
        err('top-level fields node_id and routes are required')
    if not isinstance(data['routes'], list) or not data['routes']:
        err('routes must be a non-empty list')
    seen = set()
    for r in data['routes']:
        validate_route(r, seen)
    for case in data.get('test_cases', []):
        if 'context' not in case:
            err('test case missing context')
        chosen = choose_route(data['routes'], case['context'])
        if chosen is None:
            err(f"no route matched test case {case.get('case_id','UNKNOWN')}")
        expected_skill = case.get('expected_selected_skill')
        expected_route = case.get('expected_route_id')
        if expected_skill and chosen['selected_skill'] != expected_skill:
            err(f"test {case.get('case_id')} expected skill {expected_skill} got {chosen['selected_skill']}")
        if expected_route and chosen['route_id'] != expected_route:
            err(f"test {case.get('case_id')} expected route {expected_route} got {chosen['route_id']}")
    print('route yaml is valid')

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'validation failed: {e}')
        sys.exit(1)
