---
name: skill-routing-selection
description: select the best-fit skill, route rule, and fallback chain for n370 orchestration. use when chatgpt needs to turn mixed workflow context into a canonical route decision or ruleset yaml, preserve shared pipeline_id and state_id references, validate condition_dsl, and keep route outputs machine-consumable for multi-skill orchestration or state mapping.
---

# Skill 路由选择

把“当前任务该走哪个 skill、哪个 pipeline、失败后怎么兜底”整理成 **可复核、可测试、可继续编排** 的路由规则或单次路由决策。

先阅读：
- `references/n370-id-space.md`
- `references/route-schema.md`
- `references/test-harness.md`

## 优先模式
- 用户要“当前这次该调用哪个 skill” → **decision mode**
- 用户要“沉淀一整套路由规则” → **ruleset mode**
- 用户只要快速查看 → 可给 markdown / csv quick view，但**机器消费默认用 YAML**

## 默认契约模式（推荐）
当结果要给 N370 / engine / QA harness 消费时，输出 YAML：

- schema: `n370.skill-routing-selection.v2`
- top-level fields:
  `schema,node_id,routes`
- each route fields:
  `route_id,pipeline_id,state_id,trigger_type,condition_dsl,selected_skill,priority,fallback_chain,inputs_required,outputs_expected,rationale,confidence,evidence_ref`

规则：
- 共享 ID 必须遵守 `references/n370-id-space.md`
- `priority` 仅用 `P0` / `P1` / `P2`
- `fallback_chain` 按顺序列出替代 skill 或人工节点
- `condition_dsl` 使用 `references/route-schema.md` 里的 DSL，不要混写自然语言触发条件
- 一条 route 只表达一个明确选择，不把多个 skill 塞进 `selected_skill`

## 工作流
1. 先识别当前上下文属于哪个 node / pipeline / state。
2. 把信号拆成 trigger、约束、风险、缺失依赖四层。
3. 只选择最窄、最合适的 skill；不要把“可能相关”都并列塞进主选项。
4. 若上游信息不足，保留 route，但把不确定性写进 `confidence` 和 `rationale`。
5. 若用户给了旧规则，优先增量刷新，不随意改动已有 `route_id`。

## Route DSL 使用规则
- 优先写可测试的表达式，例如：
  `stage == "N100" and has("prd") and risk_count >= 1`
- 允许的 helper 见 `references/route-schema.md`
- 不要把“建议、解释、备注”写进 `condition_dsl`
- 解释性内容写进 `rationale`

## 严格边界
- 这里只做路由选择，不替代业务分析 skill 本身产出专业结论。
- 不在这里补写需求、测试、发布正文。
- 不把 fallback 写成新的主 route。

## 质量检查
在完成前确认：
- `route_id`、`pipeline_id`、`state_id` 可跨 skill 对齐。
- `condition_dsl` 可被测试 harness 理解。
- `selected_skill` 是单一主选项，`fallback_chain` 顺序明确。
- 若输出 YAML，可运行 `scripts/validate_routes.py`。
