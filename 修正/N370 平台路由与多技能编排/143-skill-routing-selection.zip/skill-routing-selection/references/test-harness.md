# Route Test Harness

在把 route 交给 engine 或其他人之前，优先准备可运行的测试用例。

## 推荐结构

```yaml
schema: n370.skill-routing-selection.v2
node_id: N370
routes: [...]
test_cases:
  - case_id: CASE-01
    context:
      stage: N100
      prd: PRD.md
      risk_count: 2
    expected_selected_skill: requirement-quality-review
```

## 校验目标
- 同一个 context 是否稳定命中同一条主 route
- 高优先级 route 是否会覆盖低优先级 route
- fallback 是否只在主 route 不满足时再生效

需要时运行：
`python scripts/validate_routes.py path/to/routes.yaml`
