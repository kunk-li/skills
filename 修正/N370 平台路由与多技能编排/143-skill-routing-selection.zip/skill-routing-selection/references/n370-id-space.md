# N370 共享 ID 空间

为了让 route / pipeline / state / snapshot 能跨 skill 无歧义引用，统一使用以下约定：

## 共享字段
- `node_id`: 例如 `N370`
- `pipeline_id`: 例如 `PL-01`
- `state_id`: 例如 `N370.PL-01.ST-01`
- `route_id`: 例如 `N370.PL-01.ST-01.R01`
- `transition_id`: 例如 `N370.PL-01.TR-01`
- `snapshot_id`: 例如 `SNAP-20260423-01`

## 使用规则
- `pipeline_id` 在同一 workflow 中唯一。
- `state_id` 必须显式挂到某个 `pipeline_id` 下。
- `route_id` 必须绑定具体 `state_id`。
- 144 snapshot 里若引用当前 pipeline / state，也使用同一套 ID。
- 不要在不同 skill 中为同一 pipeline / state 发明不同名字。
