# Route Schema 与 Condition DSL

## Canonical YAML

```yaml
schema: n370.skill-routing-selection.v2
node_id: N370
routes:
  - route_id: N370.PL-01.ST-01.R01
    pipeline_id: PL-01
    state_id: N370.PL-01.ST-01
    trigger_type: user_request
    condition_dsl: stage == "N100" and has("prd") and risk_count >= 1
    selected_skill: requirement-quality-review
    priority: P0
    fallback_chain:
      - manual-confirmation-node-management
    inputs_required: [prd, requirement_tree]
    outputs_expected: [quality_review]
    rationale: 需求已进入门禁且风险信号明确，优先走审查 skill。
    confidence: high
    evidence_ref: [note:gate-review]
```

## `trigger_type` 枚举
`user_request` / `artifact_ready` / `gate_result` / `incident_signal` / `manual_override`

## `condition_dsl` 规则
推荐使用安全的、可测试的表达式：
- 比较：`stage == "N100"`
- 数值：`risk_count >= 1`
- 布尔：`needs_handoff and not gate_passed`
- helper:
  - `has("field")`
  - `contains("list_field", "token")`
  - `count("list_field")`
- 组合：`and` / `or` / `not`

不要在 `condition_dsl` 中写解释性 prose。
