---
name: multi-skill-orchestration
description: design a reusable pipeline yaml for n370 orchestration. use when chatgpt needs to sequence multiple skills with explicit step dependencies, timeouts, fallbacks, compensation, and shared pipeline_id or state_id references, including standalone draft mode when route rules or state maps are incomplete.
---

# 多 skill 编排

把多个原子 skill 串成 **可执行顺序清晰、失败有兜底、可继续 machine consume** 的 pipeline YAML。

先阅读：
- `references/n370-id-space.md`
- `references/pipeline-schema.md`
- `references/compensation-patterns.md`

## Standalone 模式
即使缺 143 route rules 或 146 state map，也可以仅基于：
- 用户目标
- 输入产物列表
- 已知上下游依赖

先生成 pipeline 草案；缺失的 state 或 skill 在 YAML 中明确标 `待确认`，不要伪造依赖。

## 默认契约模式（推荐）
输出 YAML：

- schema: `n370.multi-skill-orchestration.v2`
- top-level fields:
  `schema,node_id,pipeline_id,pipeline_name,entry_state_id,goal,steps`
- each step fields:
  `step_id,state_id,skill,depends_on,inputs,outputs,success_if,fallback,timeout_minutes,compensation`

规则：
- `pipeline_id` / `state_id` 必须遵守共享 ID 空间
- `depends_on` 只引用已声明的 `step_id`
- `fallback` 必须写成结构化对象，不要散落在 prose 里
- `timeout_minutes` 必须是正整数
- `compensation` 写回滚、补偿或人工兜底动作，不写空话

## 工作流
1. 先确定 pipeline 目标和入口状态。
2. 把技能拆成最小可审阅步骤，每步只负责一个明确意图。
3. 明确依赖、超时、失败分支和补偿动作。
4. 若信息不足，允许保留 `待确认`，但不要制造不存在的 skill。
5. 完成前检查 DAG 是否无环。

## 严格边界
- 这里只做编排，不替代被编排 skill 的专业分析。
- 不把 route 决策和 state 细节写成 pipeline 正文；只引用其 ID。
- 不输出与 pipeline 无关的大段说明文。

## 质量检查
- 每个 step 都有清晰的依赖与输出。
- fallback 与 compensation 可操作，而不是空泛建议。
- 若输出 YAML，可运行 `scripts/validate_pipeline.py`。
