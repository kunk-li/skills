# Compensation Patterns

常见补偿动作：
- 回退到上一个稳定快照
- 切换到人工确认节点
- 重新拉起某一步并保留失败证据
- 降级为 quick view 输出，等待补齐输入

`compensation` 应写可执行动作，不写“加强沟通”“持续跟踪”这类空泛语句。
