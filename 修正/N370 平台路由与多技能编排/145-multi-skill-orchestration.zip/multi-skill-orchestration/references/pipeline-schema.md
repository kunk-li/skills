# Pipeline Schema

```yaml
schema: n370.multi-skill-orchestration.v2
node_id: N370
pipeline_id: PL-01
pipeline_name: requirement-gate-to-handoff
entry_state_id: N370.PL-01.ST-01
goal: 从门禁结果推进到可交接产物
steps:
  - step_id: STEP-01
    state_id: N370.PL-01.ST-01
    skill: skill-routing-selection
    depends_on: []
    inputs: [quality_review]
    outputs: [route_rules]
    success_if: [生成主 route]
    fallback:
      on_failure: [human-confirmation-node-management]
    timeout_minutes: 20
    compensation: []
```

必填字段：`steps[] + depends_on + fallback + timeout_minutes + compensation`
