# N370 共享 ID 空间

统一约定：
- `pipeline_id`: `PL-01`
- `state_id`: `N370.PL-01.ST-01`
- `step_id`: `STEP-01`

一个 pipeline 内：
- `step_id` 唯一
- `state_id` 唯一
- 入口状态通过 `entry_state_id` 指向
