#!/usr/bin/env python3
import sys
from pathlib import Path
import yaml

def fail(msg):
    raise ValueError(msg)

def dfs(graph, node, visiting, visited):
    if node in visiting:
        fail(f'cycle detected at {node}')
    if node in visited:
        return
    visiting.add(node)
    for nxt in graph.get(node, []):
        dfs(graph, nxt, visiting, visited)
    visiting.remove(node)
    visited.add(node)

def main():
    if len(sys.argv) != 2:
        print('Usage: python validate_pipeline.py <pipeline.yaml>')
        sys.exit(1)
    data = yaml.safe_load(Path(sys.argv[1]).read_text(encoding='utf-8'))
    if data.get('schema') != 'n370.multi-skill-orchestration.v2':
        fail('schema must be n370.multi-skill-orchestration.v2')
    required_top = ['node_id','pipeline_id','pipeline_name','entry_state_id','goal','steps']
    for key in required_top:
        if key not in data:
            fail(f'missing top-level field: {key}')
    steps = data['steps']
    if not isinstance(steps, list) or not steps:
        fail('steps must be a non-empty list')
    seen_steps = set()
    seen_states = set()
    graph = {}
    for step in steps:
        req = ['step_id','state_id','skill','depends_on','inputs','outputs','success_if','fallback','timeout_minutes','compensation']
        for key in req:
            if key not in step:
                fail(f"step missing field: {key}")
        sid = step['step_id']
        if sid in seen_steps:
            fail(f'duplicate step_id: {sid}')
        seen_steps.add(sid)
        stid = step['state_id']
        if stid in seen_states:
            fail(f'duplicate state_id: {stid}')
        seen_states.add(stid)
        if not isinstance(step['depends_on'], list):
            fail(f'depends_on must be list: {sid}')
        if not isinstance(step['inputs'], list) or not isinstance(step['outputs'], list):
            fail(f'inputs/outputs must be list: {sid}')
        if not isinstance(step['success_if'], list):
            fail(f'success_if must be list: {sid}')
        if not isinstance(step['fallback'], dict):
            fail(f'fallback must be mapping: {sid}')
        if not isinstance(step['compensation'], list):
            fail(f'compensation must be list: {sid}')
        if not isinstance(step['timeout_minutes'], int) or step['timeout_minutes'] <= 0:
            fail(f'timeout_minutes must be positive int: {sid}')
        graph[sid] = step['depends_on']
    if data['entry_state_id'] not in seen_states:
        fail('entry_state_id must appear in steps.state_id')
    for sid, deps in graph.items():
        for dep in deps:
            if dep not in seen_steps:
                fail(f'{sid} depends on unknown step_id: {dep}')
    visited = set()
    for sid in seen_steps:
        dfs(graph, sid, set(), visited)
    print('pipeline yaml is valid')

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'validation failed: {e}')
        sys.exit(1)
