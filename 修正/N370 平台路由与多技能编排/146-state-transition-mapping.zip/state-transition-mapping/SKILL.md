---
name: state-transition-mapping
description: map workflow or object states into a machine-consumable state transition artifact. use when chatgpt needs explicit state_id, transition_id, trigger_type, guard_dsl, mode selection, and handoff or full outputs that can connect to n370 routing and orchestration without field drift.
---

# 状态流转梳理

把 workflow、对象生命周期、gate/handoff/canary 等过程整理成 **强字段契约、可机读、可跨 skill 引用** 的状态机产物。

先阅读：
- `references/n370-id-space.md`
- `references/field-contract.md`
- `references/mode-selection.md`
- `references/transition-dsl.md`
- `references/output-template.md`

## 输出模式
- `review`：信息还不够，先给审阅版
- `handoff`：信息不完整但已足够继续交接
- `system`：只要机器可读结构
- `full`：正文 + 表格 + Mermaid + JSON/YAML 附录

先按 `references/mode-selection.md` 决定模式，不要随意切换。

## 默认契约模式（推荐）
输出 JSON 或 YAML：

- schema: `n370.state-transition-mapping.v2`
- top-level fields:
  `schema,node_id,pipeline_id,mode,summary,states,transitions,open_questions`
- state fields:
  `state_id,name,object_name,definition,preconditions,constraints,roles,entry_actions,exit_conditions,evidence,confidence,open_questions`
- transition fields:
  `transition_id,name,object_name,action_name,on_event,trigger_type,state_from,state_to,guard_dsl,expected_result,failure_branch,roles,evidence,confidence,open_questions`

## DSL 与 ID 规则
- `state_id` / `transition_id` 必须遵守共享 ID 空间
- `guard_dsl` 使用 `references/transition-dsl.md`
- `on_event` 写事件名，如 `gate_passed`、`handoff_requested`、`canary_started`
- 一个 transition 只表达一个明确去向；分叉必须拆条

## 工作流
1. 先确认核心对象或 workflow 边界。
2. 枚举初始态、中间态、失败态、终态。
3. 为每条流转补齐 `on_event`、`trigger_type`、`guard_dsl`、失败分支。
4. 不完整时优先降级为 `handoff` 或 `review`，不要假装 full 数据完备。
5. 输出前核对表格、Mermaid、结构化附录是否一致。

## 严格边界
- 不把业务规则清单、权限矩阵、API 目录塞进状态机。
- 不混用旧字段和新字段；字段归一先看 `references/field-contract.md`。
- 不把自然语言说明塞进 `guard_dsl`。

## 质量检查
- 每条 transition 都能指向已声明的 `state_id`。
- `guard_dsl` 可以被静态校验。
- 模式选择符合 `references/mode-selection.md`。
- 如输出机器可读结果，可运行 `scripts/validate_state_map.py`。
