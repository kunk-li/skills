# 字段命名 contract

## 共享字段
- `state_id`
- `transition_id`
- `name`
- `object_name`
- `action_name`
- `preconditions`
- `constraints`
- `roles`
- `evidence`
- `confidence`
- `open_questions`

## 专有扩展字段
- `on_event`
- `trigger_type`
- `state_from`
- `state_to`
- `guard_dsl`
- `expected_result`
- `failure_branch`
- `entry_actions`
- `exit_conditions`

## 兼容映射
- `from` → `state_from`
- `to` → `state_to`
- `guards` → `guard_dsl` 或 `constraints`
- `entity` → `object_name`
