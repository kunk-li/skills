# N370 共享 ID 空间

- `pipeline_id`: `PL-01`
- `state_id`: `N370.PL-01.ST-01`
- `transition_id`: `N370.PL-01.TR-01`

使用规则：
- 同一 pipeline 内的 `state_id` 唯一
- 同一 pipeline 内的 `transition_id` 唯一
- `state_from` / `state_to` 只能引用已声明 `state_id`
