# Mode Selection

优先按以下规则选择模式：

1. 用户明确要求 JSON/YAML only → `system`
2. 已知状态 >= 3，且多数 transition 同时具备来源、目标、事件、约束 → `full`
3. 核心状态和主要流转已知，但 guard / 分支仍有缺口 → `handoff`
4. 连主要状态或核心对象都不稳定 → `review`

不要因为用户没指定就默认 `full`。
