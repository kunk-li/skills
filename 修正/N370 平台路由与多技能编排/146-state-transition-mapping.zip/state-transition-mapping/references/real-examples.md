# 真实样例（用于对齐粒度）

- 发布流程：`draft` → `ready_for_gate` → `gate_passed` → `canary_s1` → `ga`
- 工单升级：`new` → `triaging` → `waiting_user` → `escalated` → `resolved`
- 需求交接：`draft` → `reviewing` → `handoff_ready` → `accepted`
