# 跨 skill 编排说明

- 上游常见输入：route rules、pipeline yaml、handoff 包
- 下游常见去向：quality gate、release orchestration、audit
- 输出时优先保留 `state_id` / `transition_id`，不要只给 prose 总结
