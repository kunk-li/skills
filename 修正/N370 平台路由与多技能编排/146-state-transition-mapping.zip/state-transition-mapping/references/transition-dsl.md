# Transition DSL

推荐使用可机读的 guard 表达式：

- `gate_result == "passed"`
- `signed_off_count >= 2`
- `contains("tags", "canary") and gate_result == "passed"`
- `has("rollback_plan") and not hard_rule_violation`

helper 与路由 DSL 对齐：
- `has("field")`
- `contains("list_field", "token")`
- `count("list_field")`

`on_event` 单独记录触发事件名，示例：
- `gate_passed`
- `handoff_requested`
- `canary_started`
- `rollback_triggered`
