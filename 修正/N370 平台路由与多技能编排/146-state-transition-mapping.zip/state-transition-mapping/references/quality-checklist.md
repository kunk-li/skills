# 质量检查清单

- [ ] 状态与动作没有混名
- [ ] 每条流转都有 `on_event`、`state_from`、`state_to`
- [ ] `guard_dsl` 可读且可校验
- [ ] Mermaid 与结构化附录一致
- [ ] 未混用旧字段
