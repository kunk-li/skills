#!/usr/bin/env python3
import ast
import json
import sys
from pathlib import Path
import yaml

def fail(msg):
    raise ValueError(msg)

def load_any(path):
    text = Path(path).read_text(encoding='utf-8')
    if Path(path).suffix.lower() == '.json':
        return json.loads(text)
    return yaml.safe_load(text)

def validate_expr(expr):
    tree = ast.parse(expr, mode='eval')
    allowed = (
        ast.Expression, ast.BoolOp, ast.UnaryOp, ast.And, ast.Or, ast.Not,
        ast.Compare, ast.Name, ast.Load, ast.Constant, ast.Call,
        ast.Gt, ast.GtE, ast.Lt, ast.LtE, ast.Eq, ast.NotEq,
    )
    for n in ast.walk(tree):
        if not isinstance(n, allowed):
            fail(f'unsupported syntax in guard_dsl: {type(n).__name__}')
        if isinstance(n, ast.Call):
            if not isinstance(n.func, ast.Name) or n.func.id not in {'has','contains','count'}:
                fail('only has(), contains(), count() are allowed in guard_dsl')

def main():
    if len(sys.argv) != 2:
        print('Usage: python validate_state_map.py <state_map.yaml|json>')
        sys.exit(1)
    data = load_any(sys.argv[1])
    if data.get('schema') != 'n370.state-transition-mapping.v2':
        fail('schema must be n370.state-transition-mapping.v2')
    for key in ['node_id','pipeline_id','mode','summary','states','transitions','open_questions']:
        if key not in data:
            fail(f'missing top-level field: {key}')
    if data['mode'] not in {'review','handoff','system','full'}:
        fail('invalid mode')
    if not isinstance(data['states'], list) or not isinstance(data['transitions'], list):
        fail('states and transitions must be lists')
    state_ids = set()
    for s in data['states']:
        for key in ['state_id','name','object_name','definition','preconditions','constraints','roles','entry_actions','exit_conditions','evidence','confidence','open_questions']:
            if key not in s:
                fail(f'state missing field: {key}')
        if s['state_id'] in state_ids:
            fail(f'duplicate state_id: {s["state_id"]}')
        state_ids.add(s['state_id'])
        if s['confidence'] not in {'explicit','inferred','unknown'}:
            fail(f'invalid state confidence: {s["state_id"]}')
    trans_ids = set()
    for t in data['transitions']:
        for key in ['transition_id','name','object_name','action_name','on_event','trigger_type','state_from','state_to','guard_dsl','expected_result','failure_branch','roles','evidence','confidence','open_questions']:
            if key not in t:
                fail(f'transition missing field: {key}')
        if t['transition_id'] in trans_ids:
            fail(f'duplicate transition_id: {t["transition_id"]}')
        trans_ids.add(t['transition_id'])
        if t['state_from'] not in state_ids or t['state_to'] not in state_ids:
            fail(f'transition references unknown state: {t["transition_id"]}')
        if t['trigger_type'] not in {'user','system','scheduled','external','manual'}:
            fail(f'invalid trigger_type: {t["transition_id"]}')
        if t['confidence'] not in {'explicit','inferred','unknown'}:
            fail(f'invalid transition confidence: {t["transition_id"]}')
        validate_expr(t['guard_dsl'])
    print('state map is valid')

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'validation failed: {e}')
        sys.exit(1)
