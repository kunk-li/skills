---
name: technical-solution-draft-generation
description: draft a detailed technical solution from requirements and upstream analysis. use when converting a preferred technical direction into an implementation-oriented design inside n130 technical solution analysis and review, especially from technical-solution-analysis plus 开发需求解析.md, 接口意图清单.csv, and 需求漏洞清单.csv, while staying within the n130 v2 artifact contract and design-stage boundary.
---
# technical-solution-draft-generation

Produce a tactical design draft that a new engineer can use to start implementation planning.

Use the shared v2 contract in `references/v2-alignment.md` and the chain rules in `references/orchestration.md`.

## role and boundary
This skill is the preferred **step 2 of 3** inside `N130 technical solution analysis and review`.

Stay inside the skill-catalog boundary:
- turn a chosen or provisional direction into modules, flows, draft interfaces, and design-level topology
- support downstream architecture, api, data, non-functional, task-planning, and documentation work
- do not replace final N150 api design, final N160 schema design, code generation, testing, or release execution

## operate in the right mode
Choose exactly one mode and state it near the top:
- `minimal_mode`: use for one feature or a short design spike; keep only core architecture and critical contracts
- `standard_mode`: use for normal project work; include all required design sections
- `enterprise_mode`: use for multi-service or compliance-heavy work; include full topology, richer failure handling, and stronger traceability

If upstream analysis is missing, continue in `provisional` readiness and say which conclusions are inferred.

## preferred inputs
Use only user-provided material and traceable upstream outputs as facts.

Primary v2 packet when present:
- `technical-solution-analysis` output
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`

Also accept:
- requirements docs, prds, stories, acceptance criteria
- api intent extraction or equivalent interface intent notes
- user-provided architecture notes, review notes, and constraint tables

Do not invent current implementation details or hard-code platform facts that were never provided.

## primary job
Turn the chosen direction into a reusable design draft that covers:
1. candidate options and recommendation
2. requirement-to-module traceability
3. module responsibilities and boundaries
4. core flows, data flow, and state transitions
5. draft interface contracts
6. unified non-functional design
7. deployment topology and rollout shape
8. unresolved items for review

## mandatory design structure
Use Markdown. Prefer tables and compact diagrams in text form.

### 1. artifact contract header
Start with a compact contract block containing:
- `artifact_id`
- `artifact_type: technical_solution_draft`
- `schema_version: n130.v2`
- `node_id: N130`
- `step_order: 2_of_3` or `standalone`
- `skill_name: technical-solution-draft-generation`
- `readiness`
- `contract_status`
- `confidence_summary` for `confirmed`, `inferred`, and `pending`
- `source_artifacts`
- `upstream_dependencies`
- `downstream_targets`
- `route_back_to`

### 2. design header
Include:
- `solution_id`
- `mode`
- `scope`
- `sources_used`
- `recommended_option`

### 3. candidate options
Produce at least three candidates when the problem is non-trivial:
- `A minimal`
- `B ideal`
- `C balanced`

For each candidate include:
- summary
- pros
- cons
- main risks
- fit against constraints

Then state:
- `recommended`
- `rationale`
- `risks_accepted`
- `resolution_history` for non-selected options

If upstream analysis already recommended an option, preserve that recommendation unless the draft uncovers a concrete conflict and explain the conflict explicitly.

### 4. requirement coverage matrix
Always include a coverage matrix mapping requirements to modules and patterns.
Suggested columns:
- `module`
- `requirement_refs`
- `acceptance_refs`
- `patterns_used`
- `coverage_note`

Call out:
- `orphan_requirements`
- `orphan_acceptance_criteria`
- `orphan_modules`

### 5. business and technical architecture
Provide:
- business context and main actors
- system context and module map
- module responsibilities
- module boundaries and ownership
- communication style between modules (`sync_rest`, `async_event`, `batch`, `stream`, or similar)

### 6. core flows and state handling
For each important flow, include:
- trigger
- happy path
- key validations
- side effects
- error path or compensation path
- state transitions if relevant

For complex behavior, include a simple step list, state table, or pseudocode.

### 7. data architecture
Cover:
- core entities and stores
- read and write paths
- important indexes or partition hints if supported by requirements
- retention, audit, or lineage notes when relevant

If the system evolves from an existing one, reflect `as_is`, `to_be`, and `transitional` data behavior instead of describing only the target state.

### 8. interface contracts
For every cross-module call or event, create a draft contract.
For each contract include:
- `contract_id`
- `caller`
- `callee`
- `purpose`
- `style`
- `draft_signature` with method, topic, or path and key payload shape
- `nfr_hints` such as qps, latency, idempotency, retry, cache, ordering
- `failure_mode`

These are draft contracts only. Make them precise enough for downstream api or schema design, but do not invent unsupported fields or pretend to replace final N150 or N160 deliverables.

### 9. unified non-functional sections
Always include these eight sections, even if some are brief:
1. business architecture
2. technical architecture
3. data architecture
4. concurrency and consistency
5. idempotency and compensation
6. security and authorization
7. audit and compliance
8. observability

In each section, include when relevant:
- current state
- target state
- key mechanisms
- validation method

If `需求漏洞清单.csv` is present, explicitly map unresolved defects into the relevant non-functional or unresolved-items section.

### 10. deployment topology
Always specify the runtime shape at design level:
- orchestration platform or hosting model
- service count and replica assumptions
- resource shape if known
- network zones or boundaries
- access control and tls or mtls expectations
- data layer instances such as db, cache, queue
- environment differences across dev, test, staging, prod

If exact counts are unknown, provide placeholders and the decision variable rather than omitting the section.

### 11. delivery plan
Include:
- dependency order
- implementation waves or milestones
- migration steps if needed
- rollback considerations
- test anchors

### 12. unresolved items
End with:
- unresolved functional questions
- unresolved contract questions
- unresolved scale or topology questions
- review-needed decisions

### 13. node self-check summary
End with a self-check block containing:
- `check_scope`
- `coverage_status`
- `blockers`
- `open_questions_count`
- `highest_risk_area`
- `rerun_trigger`
- `next_best_action`

### 14. downstream handoff
Append a compact handoff block for review or downstream nodes:
- `selected_candidate`
- `rejected_candidates`
- `key_trade_offs`
- `interface_contracts_summary`
- `deployment_decisions`
- `defect_items_to_carry_forward`
- `unresolved_items`
- `adjacent_nodes_to_notify` such as `N140`, `N150`, `N160`, `N170`, `N180`, `N330`

## chain rules
- In workflow v2, prefer the in-node order `technical-solution-analysis -> technical-solution-draft-generation -> solution-review-question-generation`.
- Preserve the upstream analysis recommendation, assumptions, major failure modes, and defect-derived risks.
- Show exactly how the recommendation became modules, flows, interfaces, and topology.
- If the chosen direction still stands but design details are weak, set `route_back_to = draft` in later review outputs.

## output rules
- Keep `confirmed`, `inferred`, and `pending` content visibly distinct.
- Do not skip candidate options just because one option feels obvious.
- Do not scatter non-functional requirements randomly; keep them in the fixed sections.
- Make module boundaries and interfaces explicit enough that downstream work does not start from zero.
- Prefer tables for coverage, interfaces, dependencies, and rollout waves.

## gate-aware downgrade
- If `readiness = blocked`, output only artifact contract header, design scope, blockers, minimum next steps, and node self-check summary.
- If `readiness = constrained` or `provisional`, write full detail for confirmed scope and directional placeholders for blocked scope.

## self-check before finishing
Verify all of the following:
- at least three candidate options exist or the shortfall is justified
- every important requirement is mapped to a module or called out as orphaned
- every cross-module interaction has a draft contract
- all eight non-functional sections exist
- deployment topology is present
- defect items were consumed
- node self-check exists
- unresolved items are explicit and reviewable
