# orchestration

Use these skills independently or as a chain.

## default n130 chain
1. `technical-solution-analysis`
2. `technical-solution-draft-generation`
3. `solution-review-question-generation`

This is the preferred in-node order for workflow v2.

## standalone use
- `technical-solution-analysis`: compare approaches and expose constraints, assumptions, and failure modes.
- `technical-solution-draft-generation`: turn one chosen or assumed direction into a structured design draft.
- `solution-review-question-generation`: stress-test an analysis or design pack and prepare a real review meeting.

## shared contract fields
Keep these headings stable across all three outputs:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `node_id`
- `step_order`
- `readiness`
- `contract_status`
- `confidence_summary`
- `source_artifacts`
- `upstream_dependencies`
- `downstream_targets`
- `route_back_to`
- `node self-check summary`

## risk carry-forward
- turn `需求漏洞清单.csv` into assumptions, constraints, risks, unresolved items, or blocker questions
- do not bury upstream defects in prose

## feedback loop
- route back to analysis if a review question challenges assumptions, constraints, or the option set itself
- route back to draft generation if the chosen approach is acceptable but details, contracts, or topology are weak

## health signals
A strong v2 pack usually shows:
- schema and step order are explicit
- constraints are classified
- at least three options were compared where appropriate
- assumptions are explicit
- critical failure modes are captured
- unresolved items are easy to review
- node self-check makes blockers visible
