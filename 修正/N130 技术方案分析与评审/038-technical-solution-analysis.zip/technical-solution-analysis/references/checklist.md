# checklist

Run this check before finishing.

## universal
- use only traceable facts from user-provided material
- separate confirmed, inferred, and pending content
- keep the document usable as a standalone artifact
- include visible next steps or follow-up actions
- include the v2 artifact contract header
- include the node self-check summary
- keep outputs inside technical solution design boundaries

## analysis-specific
- classify important constraints
- compare multiple options
- make the recommendation logic visible
- surface assumptions and failure modes
- absorb requirement defect items into risks, assumptions, or blockers

## draft-specific
- include candidate options and recommendation
- include requirement traceability
- include draft interfaces
- include non-functional sections and deployment topology
- mark anything that belongs to N150 or N160 as draft-only, not final

## review-specific
- make blocker items obvious
- attach evidence and owners
- assign review rounds and criticality
- include follow-up status
- point review findings back to analysis or draft when needed
