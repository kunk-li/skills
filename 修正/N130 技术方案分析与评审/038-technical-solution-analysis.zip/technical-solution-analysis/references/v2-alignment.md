# v2 alignment

Use this reference to keep the N130 skill trio aligned with the skill catalog and workflow v2.

## workflow role
- node: `N130`
- node name: `technical solution analysis and review`
- default in-node order: `technical-solution-analysis` -> `technical-solution-draft-generation` -> `solution-review-question-generation`
- standalone use is allowed, but keep the same artifact contract so a later node can still consume the output.

## preferred source packet
Treat these as the primary v2 packet when present:
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`
- upstream N130 artifacts from analysis, draft, or prior review

Do not ignore `需求漏洞清单.csv`. Carry it into assumptions, risks, unresolved items, or blocker questions.

## artifact contract header
Start every output with a compact contract header.

Required fields:
- `artifact_id`
- `artifact_type`
- `schema_version: n130.v2`
- `node_id: N130`
- `step_order`: `1_of_3`, `2_of_3`, `3_of_3`, or `standalone`
- `skill_name`
- `readiness`: `pass`, `constrained`, `blocked`, or `provisional`
- `contract_status`: `draft`, `review_ready`, or `blocked`
- `confidence_summary`: counts or short bullets for `confirmed`, `inferred`, and `pending`
- `source_artifacts`
- `upstream_dependencies`
- `downstream_targets`
- `route_back_to`: `none`, `analysis`, or `draft`

## node self-check summary
End every output with a node self-check block.

Required fields:
- `check_scope`
- `coverage_status`
- `blockers`
- `open_questions_count`
- `highest_risk_area`
- `rerun_trigger`
- `next_best_action`

## readiness hints
- `pass`: enough confirmed information to feed downstream work directly.
- `constrained`: direction is usable, but one or more design areas are narrow or weak.
- `provisional`: significant inference exists; continue, but mark uncertain parts clearly.
- `blocked`: cannot safely continue beyond minimal blockers and next steps.

## route-back rules
- send `route_back_to = analysis` when the option set, assumptions, or constraints are wrong.
- send `route_back_to = draft` when the chosen direction is acceptable but details, contracts, or topology are weak.
- keep `route_back_to = none` when the pack is consumable as-is.

## catalog boundary alignment
The skill catalog places this trio inside technical solution design. Keep outputs inside:
- solution direction
- draft interfaces and data design hints
- review preparation
- task and handoff readiness

Do not cross into:
- code generation
- test execution
- release execution
- production operation handling
