# scoring rubric

Score from 1 to 5.

## 1 unusable
The output is mostly summary, misses key structure, or hides uncertainty.

## 2 weak
The output has some useful content but still lacks major sections needed for decisions.

## 3 usable
The output supports a real team discussion or planning step, though some gaps remain.

## 4 strong
The output is decision-ready, traceable, and structured for reuse by downstream work.

## 5 exemplary
The output is highly reusable, explicitly handles uncertainty, and supports both standalone use and chained workflows with minimal rework.
