# example io

## example input packet
- 开发需求解析.md
- 接口意图清单.csv
- 需求漏洞清单.csv
- optional upstream analysis or design draft

## shared v2 contract header
- artifact_id
- artifact_type
- schema_version: n130.v2
- node_id: N130
- step_order
- readiness
- contract_status
- confidence_summary
- source_artifacts
- upstream_dependencies
- downstream_targets
- route_back_to

## analysis output shape
- artifact contract header
- problem framing
- constraint taxonomy
- architecture states
- candidate options
- trade-off matrix
- assumptions
- failure mode analysis
- recommendation
- open items
- node self-check summary
- downstream handoff

## draft output shape
- artifact contract header
- candidate options and recommendation
- requirement coverage matrix
- architecture and flows
- data architecture
- interface contracts draft
- non-functional sections
- deployment topology
- unresolved items
- node self-check summary
- downstream handoff

## review output shape
- artifact contract header
- blocker summary
- question table
- node self-check summary
- route-back summary
- optional review summary
