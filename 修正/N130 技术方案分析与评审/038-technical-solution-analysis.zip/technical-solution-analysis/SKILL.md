---
name: technical-solution-analysis
description: analyze technical solution directions, constraints, candidate options, trade-offs, assumptions, architecture states, and failure modes before writing a full design. use when working in n130 technical solution analysis and review, especially from 开发需求解析.md, 接口意图清单.csv, and 需求漏洞清单.csv, or when a standalone technical decision memo must still align to the n130 v2 artifact contract.
---
# technical-solution-analysis

Produce a strategy-layer technical analysis, not a full implementation design.

Use the shared v2 contract in `references/v2-alignment.md` and the chain rules in `references/orchestration.md`.

## role and boundary
This skill is the preferred **step 1 of 3** inside `N130 technical solution analysis and review`.

Stay inside the skill-catalog boundary:
- analyze solution direction, module boundary implications, interface intent, data implications, and risk
- prepare downstream handoff for draft generation, review generation, and adjacent N140/N150/N160/N170/N180 work
- do not generate runnable code, test execution plans, or release actions

## operate in the right mode
Choose exactly one mode early and state it near the top:
- `quick_analysis`: use for one focused topic or sparse inputs; produce a compact but decision-ready analysis
- `deep_analysis`: use for end-to-end solution analysis; produce the full structure
- `adr_mode`: use when the user mainly needs an architecture decision record

If the input is incomplete, keep working in `provisional` readiness rather than stopping. Separate `confirmed`, `inferred`, and `pending` content.

## preferred inputs
Treat only user-provided material and explicitly traceable upstream outputs as facts.

Primary v2 packet when present:
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`

Also accept:
- requirements docs, prds, problem statements, user stories
- upstream structured outputs such as requirement parsing or prior analysis
- existing design notes, review notes, risk logs, incident learnings, and constraint lists supplied by the user

Do not present unstated codebase realities, database realities, team history, or “industry common practice” as confirmed facts.

## primary job
Turn raw requirements into a reusable analysis artifact that answers:
1. what problem must be solved
2. what constraints truly bind the solution
3. what candidate approaches exist
4. why one path is preferred
5. what assumptions and failure modes could break the decision
6. what downstream design and review work should happen next

## mandatory output structure
Use Markdown. Prefer tables for anything comparative.

### 1. artifact contract header
Start with a compact contract block containing:
- `artifact_id`
- `artifact_type: technical_solution_analysis`
- `schema_version: n130.v2`
- `node_id: N130`
- `step_order: 1_of_3` or `standalone`
- `skill_name: technical-solution-analysis`
- `readiness`
- `contract_status`
- `confidence_summary` for `confirmed`, `inferred`, and `pending`
- `source_artifacts`
- `upstream_dependencies`
- `downstream_targets`
- `route_back_to`

### 2. problem framing
Capture:
- business or system goal
- primary actors and key flows
- success criteria
- explicit out-of-scope items

### 3. constraint taxonomy
Classify every important constraint into one of these six groups:
- `C1 technical_stack`
- `C2 performance_slo`
- `C3 business_rules`
- `C4 compliance_regulatory`
- `C5 operational`
- `C6 organizational`

For every constraint, include:
- `constraint_id`
- `category`
- `statement`
- `hardness`: `hard`, `soft`, or `preference`
- `source`
- `verifiability`
- `waivable_by`
- `impact_if_ignored`

If `需求漏洞清单.csv` is present, map each relevant defect to one of: constraint gap, assumption risk, failure mode, or blocker. Do not leave the defect list unconsumed.

### 4. architecture states
For architecture evolution, always produce three states:
- `as_is`: current state, current data flow, current limits
- `to_be`: target state, target data flow, expected gains
- `transitional`: coexistence strategy, migration path, rollback path, data transition

If the project is greenfield, write `as_is = none / greenfield` and still provide `to_be` plus `transitional`.

### 5. candidate options
Produce at least three options whenever the decision space is non-trivial:
- one minimal option
- one ideal option
- one balanced option

If fewer than three viable options exist because of hard constraints, say so explicitly and still list rejected near-options.

### 6. trade-off matrix
Always show a structured comparison table. Use 4 to 8 dimensions when meaningful.
Suggested dimensions:
- performance
- consistency
- availability
- implementation complexity
- runtime or delivery cost
- scalability
- maintainability
- team familiarity

State the decision rule used:
- `weighted_sum`
- `dominance`
- `lexicographic_priority`
- or another explicit rule

### 7. assumptions
List all meaningful assumptions with:
- `assumption_id`
- `statement`
- `confidence`
- `verification_method`
- `if_false_impact`
- `mitigation`

If a low-confidence assumption comes from a known requirement gap or defect item, say so.

### 8. failure mode analysis
Perform lightweight FMEA for critical components or dependencies.
For each row include:
- `component`
- `failure_mode`
- `detection`
- `severity`
- `likelihood` if supportable
- `impact`
- `mitigation`
- `owner_or_layer`

For non-trivial systems, aim for at least three failure modes per critical component.

### 9. recommendation
State:
- recommended option
- why alternatives were not selected
- accepted risks
- decision preconditions
- recommended rollout order or wave plan

### 10. open items
Separate:
- `pending_confirmations`
- `blocked_dependencies`
- `follow_up_questions`

### 11. node self-check summary
End with a self-check block containing:
- `check_scope`
- `coverage_status`
- `blockers`
- `open_questions_count`
- `highest_risk_area`
- `rerun_trigger`
- `next_best_action`

### 12. downstream handoff
End with a compact handoff block that downstream skills can consume:
- `recommended_candidate`
- `constraint_taxonomy_summary`
- `assumptions_to_verify`
- `failure_modes_to_carry_forward`
- `defect_items_to_carry_forward`
- `decisions_needing_review`
- `adjacent_nodes_to_notify` such as `N140`, `N150`, `N160`, `N170`, `N180`

### 13. optional adr block
In `adr_mode` or when useful, append:
- `context`
- `options_considered`
- `decision`
- `consequences`

## chain rules
- In workflow v2, prefer the in-node order `technical-solution-analysis -> technical-solution-draft-generation -> solution-review-question-generation`.
- When used before draft generation or review generation, expose the recommended option, rejected options, assumptions, defect-derived risks, and failure modes in reusable headings.
- If downstream work challenges the option set, constraints, or assumptions, set `route_back_to = analysis`.

## output rules
- Keep facts, inference, and pending items separate.
- Prefer tables over long prose.
- Make the analysis understandable to a new engineer or reviewer.
- Never jump from constraints directly to a recommendation without showing at least one structured comparison.
- Do not hide uncertainty; turn it into assumptions, open items, or risks.

## gate-aware downgrade
- If `readiness = blocked`, output only: artifact contract header, confirmed facts, blockers, minimum next steps, and node self-check summary.
- If `readiness = constrained` or `provisional`, still produce the full structure, but visibly mark blocked areas and split recommendations into waves.

## self-check before finishing
Verify all of the following:
- every key constraint is categorized
- every non-trivial decision has multiple options
- recommendation rationale is visible, not implied
- assumptions are explicit
- failure modes are present for critical components
- defect items were consumed
- node self-check exists
- downstream handoff exists
