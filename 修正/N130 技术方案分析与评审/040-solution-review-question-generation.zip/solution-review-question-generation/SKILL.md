---
name: solution-review-question-generation
description: generate focused, blocker-first technical review questions from requirements, analysis, and design drafts. use when preparing or running n130 technical solution analysis and review, especially from technical-solution-analysis, technical-solution-draft-generation, and 需求漏洞清单.csv, and when the output must stay inside the n130 v2 artifact contract instead of becoming another design document.
---
# solution-review-question-generation

Produce a decision-ready review question pack, not another solution draft.

Use the shared v2 contract in `references/v2-alignment.md` and the chain rules in `references/orchestration.md`.

## role and boundary
This skill is the preferred **step 3 of 3** inside `N130 technical solution analysis and review`.

Stay inside the skill-catalog boundary:
- convert weak, risky, missing, or under-defended design areas into structured review questions
- help a team decide blockers, owners, due points, and route-back actions
- do not rewrite the full design, generate code, or replace later execution-stage testing and release work

## operate in the right mode
Choose exactly one mode and state it near the top:
- `vision_mode`: use for early directional review; focus on a small set of high-leverage questions
- `deep_mode`: use for architecture or detailed review; produce broad coverage and blocker-first ordering
- `probe_only`: use to aggressively scan for blind spots without generating many clarification questions

If the input is sparse, continue in `provisional` readiness and ask narrower questions rather than fabricating candidate answers.

## preferred inputs
Use only user-provided source material and traceable upstream outputs as evidence.

Primary v2 packet when present:
- `technical-solution-analysis` output
- `technical-solution-draft-generation` output
- `需求漏洞清单.csv`

Also accept:
- requirements docs and problem statements
- review notes, decision logs, and unresolved item lists supplied by the user

Do not rely on private memory, oral context, or assumed implementation history.

## primary job
Turn unresolved, risky, or weakly-supported design areas into structured review questions that help a team decide:
1. what must be answered before proceeding
2. what is a blocker vs a detail
3. who should answer
4. when the answer is needed
5. what evidence supports asking the question
6. whether the question implies a return to analysis or design draft

## mandatory output structure
Default to a Markdown table. If the user explicitly wants CSV, output CSV.

### 1. artifact contract header
Start with a compact contract block containing:
- `artifact_id`
- `artifact_type: solution_review_question_pack`
- `schema_version: n130.v2`
- `node_id: N130`
- `step_order: 3_of_3` or `standalone`
- `skill_name: solution-review-question-generation`
- `readiness`
- `contract_status`
- `confidence_summary` for `confirmed`, `inferred`, and `pending`
- `source_artifacts`
- `upstream_dependencies`
- `downstream_targets`
- `route_back_to`

### 2. review header
Include:
- `review_pack_id`
- `mode`
- `scope`
- `sources_used`
- `recommended_review_round`

### 3. blocker summary
Before the main table, summarize:
- blocker count
- major count
- minor count
- nice-to-have count
- top 3 must-answer questions

If `需求漏洞清单.csv` is present, say which blocker or major items came directly from prior defects or requirement gaps.

### 4. question table
Each question must include these columns:
- `question_id`
- `question_kind`
- `target_round`
- `criticality`
- `area`
- `question`
- `why_now`
- `evidence`
- `expected_answer_type`
- `decision_owner`
- `must_answer_before`
- `status`
- `route_back_to`
- `follow_up_action`

### 5. question kinds
Classify every question as exactly one of:
- `CLARIFY`
- `CHALLENGE`
- `COMPLETE`
- `RISK`
- `VALIDATION`
- `ALTERNATIVE`
- `PRIOR_ART`
- `COST`

Use kinds intentionally:
- use `CLARIFY` for ambiguity in wording or missing semantics
- use `CHALLENGE` when the design picked a path without enough defense
- use `COMPLETE` when material is missing
- use `RISK` for failure, scale, or resilience concerns
- use `VALIDATION` when a claim needs proof, measurement, or test design
- use `ALTERNATIVE` when another path deserves direct comparison
- use `PRIOR_ART` when precedent matters
- use `COST` when runtime or delivery cost may dominate the decision

### 6. review rounds
Assign each question to one review round:
- `R1 vision`
- `R2 architecture`
- `R3 detailed`
- `R4 final`
- `R5 post_mortem`

Recommended volume:
- `vision_mode`: 3 to 5 questions, mostly R1
- `deep_mode`: 12 to 40 questions across R2 and R3, plus a few R4 gate questions
- `probe_only`: probe-triggered questions only

### 7. criticality
Mark every question as one of:
- `blocker`
- `major`
- `minor`
- `nice_to_have`

Sort the output by criticality first, then by review round.

### 8. auto-generated probes
Always scan for classic blind spots and generate questions when evidence suggests risk.
Use these probe families:
- `P1 single_point_of_failure`
- `P2 thundering_herd`
- `P3 race_condition`
- `P4 unbounded_queue`
- `P5 clock_skew_sensitivity`
- `P6 cascading_failure`
- `P7 data_growth`
- `P8 backward_incompatibility`
- `P9 cold_start_behavior`
- `P10 observability_gap`

Trigger probes when relevant keywords or structures appear. Example mappings:
- cache -> `P2`, `P9`
- queue or event bus -> `P4`
- distributed lock, concurrent update, saga -> `P3`
- scheduler, cron, ttl, expiry -> `P5`
- shared dependency or central gateway -> `P1`, `P6`

### 9. answer tracking
For every question, include a lightweight tracking state:
- `raised`
- `in_review`
- `answered`
- `accepted`
- `reopened`
- `parked`
- `closed`

If no answer exists yet, default to `raised`.

### 10. route-back logic
When a question materially invalidates the current design:
- say `route_back_to = analysis` if the underlying assumption, constraint, option set, or defect interpretation is wrong
- say `route_back_to = draft` if the decision is sound but the design detail is weak or incomplete
- keep `route_back_to = none` if the question can be closed without rework

### 11. node self-check summary
End with a self-check block containing:
- `check_scope`
- `coverage_status`
- `blockers`
- `open_questions_count`
- `highest_risk_area`
- `rerun_trigger`
- `next_best_action`

### 12. review routing summary
After the table, summarize:
- `analysis_return_items`
- `draft_return_items`
- `meeting_agenda_top_items`
- `parked_items`

### 13. optional review summary
Optionally add a short Markdown summary:
- biggest unresolved themes
- review meeting agenda suggestion
- decisions that can be parked

## evidence rules
- Every question must cite or explicitly name the evidence source from the input packet.
- If evidence is weak, phrase the item as a clarification or validation question rather than a confident challenge.
- Never invent options or owner names that the source material does not support.

## chain rules
- In workflow v2, prefer the in-node order `technical-solution-analysis -> technical-solution-draft-generation -> solution-review-question-generation`.
- Convert assumptions into `VALIDATION` or `CLARIFY` questions.
- Convert failure modes and defect-derived risks into `RISK` questions.
- Convert rejected candidates and trade-offs into `ALTERNATIVE` or `COST` questions.
- Convert unresolved items into explicit owner-bound questions.

## gate-aware downgrade
- If `readiness = blocked`, output only artifact contract header, blocker summary, minimum next steps, node self-check summary, and route-back summary.
- If `readiness = constrained` or `provisional`, keep blocker and major questions, but avoid fake detail in options.

## self-check before finishing
Verify all of the following:
- every question is specific and answerable
- blocker items are obvious at a glance
- each question has kind, round, criticality, evidence, owner, and due point
- probe coverage exists for likely blind spots
- defect items were converted into visible review questions or blockers
- node self-check exists
- the pack helps a meeting reach decisions, not just surface discussion topics
