# Fallback category checklist

## CSV schema

Column order is mandatory:

| column | required | allowed / format | meaning |
|---|---:|---|---|
| fb_id | yes | stable ID such as `FB-001` | Fallback record ID |
| fb_name | yes | text | Human-readable fallback name |
| category | yes | `DATA_DEGRADATION`, `SERVICE_DEGRADATION`, `PROCESS_DEGRADATION`, `POLICY_DEGRADATION` | Fallback category |
| trigger_ref | yes | gate, blocker, risk, incident, state, or pipeline ID | What activates or evaluates the fallback |
| gate_ref | recommended | `GATE-###`, `not_applicable`, or `待确认` | Gate linked to the fallback |
| activation_status | yes | `READY`, `ACTIVE`, `PENDING`, `BLOCKED`, `DISABLED`, `NOT_APPLICABLE` | Current fallback status |
| rehearsal_allowed | yes | `yes`, `no`, `conditional`, `not_allowed` | Whether this fallback can be rehearsed |
| rehearsal_status | yes | `NOT_STARTED`, `PASSED`, `FAILED`, `WAIVED`, `FORBIDDEN`, `NOT_APPLICABLE` | Rehearsal result |
| owner | yes | person, team, role, or `待确认` | Owner responsible for switch decision |
| severity | yes | `P0`, `P1`, `P2`, `P3` | Governance urgency |
| preconditions | yes | text or pipe-list | Conditions before switching |
| switch_action | yes | concrete action | What to do when activating fallback |
| rollback_action | yes | concrete action, `not_applicable`, or `待确认` | How to return to normal path |
| hcn_ref | required for active, blocked, disabled, or conditional paths | `HCN-###`, `not_applicable`, or `待确认` | Human confirmation node |
| audit_required | yes | `yes` or `no` | Whether an audit record must be emitted |
| evidence_ref | yes | source IDs or `待确认`; pipe-list allowed | Evidence backing fallback design |
| notes | optional | text | Warnings, scope limits, irreversible conditions |

## Category checklists

### DATA_DEGRADATION
Check:
- source of truth is identified;
- data freshness impact is stated;
- recovery or reconciliation action exists;
- data loss or duplication risk is visible;
- audit is required when user, financial, compliance, or production data is affected.

### SERVICE_DEGRADATION
Check:
- degraded service behavior is explicit;
- feature flag, circuit breaker, alternate provider, or static fallback is named;
- user impact and observability signal are visible;
- rollback to normal service is defined.

### PROCESS_DEGRADATION
Check:
- manual actor or team is named;
- manual procedure has a start and stop condition;
- SLA impact is stated;
- escalation path is documented.

### POLICY_DEGRADATION
Check:
- policy, scope, eligibility, compliance, or release rule being changed is named;
- hard-rule violations are not bypassed;
- approval authority is identified;
- audit is required for compliance-affecting changes.

## Rehearsal guidance

Use `rehearsal_allowed=not_allowed` and `rehearsal_status=FORBIDDEN` for fallbacks that cannot be safely exercised, such as destructive disaster-recovery reversal, irreversible compliance changes, or production-only operations.
