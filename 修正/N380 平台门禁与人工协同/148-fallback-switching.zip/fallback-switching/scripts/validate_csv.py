#!/usr/bin/env python3
"""Validate fallback switching CSV records."""

import csv
import sys
from pathlib import Path

EXPECTED_COLUMNS = [
    "fb_id", "fb_name", "category", "trigger_ref", "gate_ref", "activation_status",
    "rehearsal_allowed", "rehearsal_status", "owner", "severity", "preconditions",
    "switch_action", "rollback_action", "hcn_ref", "audit_required", "evidence_ref", "notes",
]

CATEGORIES = {"DATA_DEGRADATION", "SERVICE_DEGRADATION", "PROCESS_DEGRADATION", "POLICY_DEGRADATION"}
STATUSES = {"READY", "ACTIVE", "PENDING", "BLOCKED", "DISABLED", "NOT_APPLICABLE"}
REHEARSAL_ALLOWED = {"yes", "no", "conditional", "not_allowed"}
REHEARSAL_STATUS = {"NOT_STARTED", "PASSED", "FAILED", "WAIVED", "FORBIDDEN", "NOT_APPLICABLE"}
SEVERITY = {"P0", "P1", "P2", "P3"}
YES_NO = {"yes", "no"}
REQUIRED = {
    "fb_id", "fb_name", "category", "trigger_ref", "activation_status", "rehearsal_allowed",
    "rehearsal_status", "owner", "severity", "preconditions", "switch_action",
    "rollback_action", "hcn_ref", "audit_required", "evidence_ref",
}


def validate(path: Path) -> int:
    errors = []
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != EXPECTED_COLUMNS:
            errors.append("header mismatch: expected " + ",".join(EXPECTED_COLUMNS))
            errors.append("actual: " + ",".join(reader.fieldnames or []))
            print_errors(errors)
            return 1
        rows = list(reader)

    if not rows:
        errors.append("CSV has no data rows")

    seen = set()
    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED:
            if not (row.get(field) or "").strip():
                errors.append(f"row {idx}: {field} is required")
        fb_id = (row.get("fb_id") or "").strip()
        if fb_id in seen:
            errors.append(f"row {idx}: duplicate fb_id {fb_id}")
        seen.add(fb_id)

        category = (row.get("category") or "").strip()
        if category not in CATEGORIES:
            errors.append(f"row {idx}: category must be one of {sorted(CATEGORIES)}")
        status = (row.get("activation_status") or "").strip()
        if status not in STATUSES:
            errors.append(f"row {idx}: activation_status must be one of {sorted(STATUSES)}")
        rehearsal_allowed = (row.get("rehearsal_allowed") or "").strip()
        if rehearsal_allowed not in REHEARSAL_ALLOWED:
            errors.append(f"row {idx}: rehearsal_allowed must be one of {sorted(REHEARSAL_ALLOWED)}")
        rehearsal_status = (row.get("rehearsal_status") or "").strip()
        if rehearsal_status not in REHEARSAL_STATUS:
            errors.append(f"row {idx}: rehearsal_status must be one of {sorted(REHEARSAL_STATUS)}")
        severity = (row.get("severity") or "").strip()
        if severity not in SEVERITY:
            errors.append(f"row {idx}: severity must be one of {sorted(SEVERITY)}")
        audit_required = (row.get("audit_required") or "").strip()
        if audit_required not in YES_NO:
            errors.append(f"row {idx}: audit_required must be yes or no")

        hcn_ref = (row.get("hcn_ref") or "").strip()
        if status in {"ACTIVE", "BLOCKED", "DISABLED"} and hcn_ref in {"", "not_applicable"}:
            errors.append(f"row {idx}: {status} fallback requires hcn_ref")
        if rehearsal_allowed == "not_allowed" and rehearsal_status != "FORBIDDEN":
            errors.append(f"row {idx}: not_allowed rehearsal must have rehearsal_status=FORBIDDEN")
        if status in {"ACTIVE", "BLOCKED", "DISABLED"} and audit_required != "yes":
            errors.append(f"row {idx}: {status} fallback requires audit_required=yes")
        if category == "POLICY_DEGRADATION" and audit_required != "yes":
            errors.append(f"row {idx}: POLICY_DEGRADATION requires audit_required=yes")

    if errors:
        print_errors(errors)
        return 1
    print(f"OK: {path} has {len(rows)} valid fallback rows")
    return 0


def print_errors(errors):
    for error in errors:
        print("ERROR:", error, file=sys.stderr)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: validate_csv.py <fallback_records.csv>", file=sys.stderr)
        sys.exit(2)
    sys.exit(validate(Path(sys.argv[1])))
