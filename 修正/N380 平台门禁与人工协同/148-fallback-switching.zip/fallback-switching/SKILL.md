---
name: fallback-switching
description: produce structured fallback switching plans for workflow, release, service, data, process, or policy degradation. use when a gate, node, pipeline step, deployment, test, service, or business process fails or receives conditional-go and the user needs a backup path, manual takeover, rollback, contingency checklist, rehearsal rule, fallback CSV, or audit-ready degraded operation plan.
---

# Fallback Switching

Use this skill to define fallback paths when a gate, workflow step, release action, integration, service, data path, or governance decision cannot safely proceed as planned. Keep the skill at the fallback/governance layer; do not re-implement the failed upstream skill.

## Core behavior

Default output is `失败兜底切换记录.csv` using the schema in `references/fallback-category-checklist.md`.

Work only from provided evidence. If the fallback cannot be fully specified, keep the row, mark unknowns as `待确认`, and use `activation_status=PENDING` instead of inventing a plan.

## Workflow

1. Identify the trigger: failed gate, conditional gate, failed pipeline step, blocker, production signal, or manual decision.
2. Classify the fallback category as one of the four governance categories.
3. Select the category-specific checklist from `references/fallback-category-checklist.md`.
4. Decide whether fallback is `READY`, `ACTIVE`, `PENDING`, `BLOCKED`, `DISABLED`, or `NOT_APPLICABLE`.
5. Specify switch action, rollback action, rehearsal rule, owner, HCN link, and audit requirement.
6. Produce CSV in the exact schema order.
7. When a CSV is produced or modified, run `scripts/validate_csv.py <csv-file>` whenever file execution is available.

## Four fallback categories

Use exactly one category per row:

- `DATA_DEGRADATION`: data fallback, snapshot, restore, readonly mode, degraded freshness, or historical data.
- `SERVICE_DEGRADATION`: service fallback, feature flag, circuit breaker, alternate provider, scale-down, or static response.
- `PROCESS_DEGRADATION`: manual takeover, reduced workflow, approval detour, limited operating procedure, or delayed processing.
- `POLICY_DEGRADATION`: scope reduction, rule tightening, eligibility restriction, compliance hold, or release policy change.

## Output contract

Use exact column order from the reference:

```csv
fb_id,fb_name,category,trigger_ref,gate_ref,activation_status,rehearsal_allowed,rehearsal_status,owner,severity,preconditions,switch_action,rollback_action,hcn_ref,audit_required,evidence_ref,notes
```

CSV rules:
- Use RFC-4180 CSV.
- Use `|` for list-like fields.
- Do not use bare commas inside unquoted values.
- Use `not_allowed` for fallbacks that must not be rehearsed.
- Use `not_applicable` when a field is explicitly irrelevant.
- Use `待确认` when human confirmation is still needed.

## Gate and HCN linkage

- A `COND_GO` gate should usually activate or verify a fallback row.
- A `FAIL` gate should either activate fallback or document why fallback is not safe.
- `BLOCKED` or `DISABLED` fallbacks require `hcn_ref` and `audit_required=yes`.
- Fallback decisions may be consumed by gate-pass-decision, human-confirmation-node-management, state-transition-mapping, audit-trail-management, or governance dashboards.

## Quality bar

Before finalizing, verify:
- The category is one of the four canonical values.
- `switch_action` and `rollback_action` are concrete enough for an operator or PM to execute.
- Non-trivial fallback paths have a human owner.
- Rehearsal restrictions are explicit, especially for dangerous, irreversible, or compliance-bound fallbacks.
- The CSV validates with `scripts/validate_csv.py` when possible.
