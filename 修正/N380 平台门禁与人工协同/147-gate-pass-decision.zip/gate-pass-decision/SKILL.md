---
name: gate-pass-decision
description: produce structured gate pass decisions for workflow, release, checkpoint, quality, compliance, or governance gates. use when deciding pass, conditional-go, fail, pending, or not-assessed from quality checks, release checklists, blockers, risks, state transitions, fallback plans, or human signoff records; use for N380 gate records, aggregate gate rollups, confidence scoring, HCN escalation, fallback activation, audit-ready CSV outputs, or governance dashboard inputs.
---

# Gate Pass Decision

Use this skill to turn gate evidence into audit-ready gate decisions. Keep the skill at the governance layer: decide whether a workflow, release, phase, state transition, or checkpoint may proceed; do not redo the domain review performed by upstream product, engineering, QA, security, or release skills.

## Core behavior

Work from evidence supplied in the conversation or uploaded files. If evidence is incomplete, keep the record, mark weak fields as `待确认`, and lower confidence instead of inventing facts.

Default output is `门禁放行记录.csv` using the schema in `references/gate-decision-schema.md`. For a narrative request, provide a concise summary plus the CSV-ready table.

## Workflow

1. Normalize input evidence into gate candidates.
2. Classify each gate as `NODE`, `PHASE`, `RELEASE`, `DECISION`, `CANARY`, `GA`, or `CUSTOM`.
3. Apply the aggregation DSL from `references/gate-decision-schema.md`.
4. Assign `decision` as `PASS`, `COND_GO`, `FAIL`, `PENDING`, or `NOT_ASSESSED`.
5. Assign `confidence` as `HIGH`, `MEDIUM`, or `LOW` using the confidence rubric.
6. Link each non-PASS gate to an HCN and, when a conditional or failed path needs degraded operation, a fallback record.
7. Emit audit-ready records with stable IDs and evidence references.
8. When a CSV is produced or modified, run `scripts/validate_csv.py <csv-file>` before final delivery whenever file execution is available.

## Aggregation rules

Use these rules in order:

1. If `hard_rule_violations > 0`, decision is `FAIL`.
2. Else if `blocker_pending > 0`, decision is `FAIL`.
3. Else if `fail_count > 0`, decision is `FAIL`.
4. Else if `cond_go_count > 0`, decision is `COND_GO`.
5. Else if `pending_count > 0`, decision is `PENDING` unless an explicitly approved conditional path exists, then `COND_GO`.
6. Else if `not_assessed_count > 0`, decision is `NOT_ASSESSED`.
7. Else if all required dimensions are passed, decision is `PASS`.

For any `FAIL`, `COND_GO`, `PENDING`, or `NOT_ASSESSED` decision, populate `hcn_ref`. For `FAIL` or `COND_GO`, populate `fallback_ref` unless fallback is explicitly not applicable.

## Output contract

Use exact column order from `references/gate-decision-schema.md`:

```csv
gate_id,gate_name,gate_type,scope_ref,decision,confidence,pass_count,cond_go_count,fail_count,pending_count,not_assessed_count,blocker_pending,hard_rule_violations,hcn_ref,fallback_ref,state_transition_ref,audit_ref,evidence_ref,rationale,next_action
```

CSV rules:
- Use RFC-4180 CSV.
- Use `|` for list-like fields such as multiple evidence refs, HCN refs, or state transition refs.
- Do not use bare commas inside unquoted values.
- Use `待确认` for missing but required human knowledge.
- Use stable references: `GATE-###`, `HCN-###`, `FB-###`, `AU-###`, `STATE-###`, or the upstream artifact ID when available.

## Handoff behavior

- Gate `FAIL` should trigger HCN escalation and may trigger version scope trimming or fallback.
- Gate `COND_GO` should preserve the condition, owner, due date, and fallback dependency.
- Gate `PENDING` should not silently become `PASS`; keep the unresolved condition visible.
- Gate outcomes may be consumed by state-transition, fallback-switching, human-confirmation-node-management, audit-trail-management, or governance dashboards.

## Quality bar

Before finalizing, verify:
- Every decision has evidence or is explicitly marked `待确认`.
- Non-PASS gates include HCN linkage.
- Conditional and failed paths show the next action.
- Confidence is lower when evidence is missing or assumptions are used.
- The CSV validates with `scripts/validate_csv.py` when possible.
