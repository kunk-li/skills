---
name: human-confirmation-node-management
description: produce structured human confirmation node records for workflow governance, release approvals, gate escalation, fallback activation, compliance signoff, and audit-ready human decision tracking. use when the user needs HCN lists, signer chains, approval preconditions, signing strength classification, SLA queues, reversible/irreversible approval flags, or automatic audit-event templates linked to Gate, Fallback, State, or Scope decisions.
---

# Human Confirmation Node Management

Use this skill to manage human confirmation nodes (HCNs): places where a human, role, or committee must confirm, sign, approve, reject, or escalate a workflow decision. Keep the skill at the governance layer; do not replace the human decision or domain review.

## Core behavior

Default output is `人工确认节点清单.csv` using the schema in `references/hcn-schema-and-signing-strength.md`.

Work only from provided evidence. If signer, authority, deadline, or precondition is missing, keep the HCN row and mark the field `待确认`; do not silently remove the approval node.

## Workflow

1. Identify decision points requiring human confirmation: failed gates, conditional-go gates, irreversible fallback, hard-rule exceptions, compliance approvals, release decisions, or state transitions.
2. Normalize each point into an HCN record with fixed fields.
3. Classify HCN `type` and `signing_strength` using the 4-level taxonomy in the reference.
4. Determine signers, required count, preconditions, post-actions, reversibility, SLA priority, and audit requirement.
5. Produce CSV in exact schema order.
6. For every signed or rejected HCN, emit or template an audit event.
7. When a CSV is produced or modified, run `scripts/validate_csv.py <csv-file>` whenever file execution is available.

## Signing strength taxonomy

Use exactly one value:

- `WEAK`: single acknowledgement, informational confirmation, reversible, low impact.
- `MEDIUM`: single accountable approver, moderate impact, reversible or easy to correct.
- `STRONG`: multiple signers or role separation, high impact, production/release/compliance relevance.
- `VERY_STRONG`: multi-party signoff for irreversible, high-risk, hard-rule, GA, canary expansion, rollback, compliance, or financial/legal exposure.

## Output contract

Use exact column order from the reference:

```csv
hcn_id,title,type,signing_strength,signers,required_count,status,preconditions,post_actions,audit_required,reversible,gate_ref,fallback_ref,state_ref,audit_event_template,sla_priority,due_at,evidence_ref,notes
```

CSV rules:
- Use RFC-4180 CSV.
- Use `|` for list-like fields such as `signers`, `preconditions`, and refs.
- Do not use bare commas inside unquoted values.
- Use `待确认` for missing human knowledge.
- Use `not_applicable` when a reference is explicitly irrelevant.

## Audit linkage

For every HCN where `audit_required=yes`, provide `audit_event_template` with enough information to generate an audit row:

```text
AU:new actor={signer} action={approved|rejected|escalated} target={hcn_id} decision={status} evidence={evidence_ref}
```

The audit event should preserve actor, timestamp if available, action, target HCN, decision, linked gate/fallback/state, and evidence.

## Gate and fallback linkage

- Failed, pending, or conditional gates should link to an HCN.
- Active, blocked, disabled, dangerous, or non-rehearsable fallbacks should link to an HCN.
- HCNs can also serve as state-transition triggers for state-transition-mapping.

## Quality bar

Before finalizing, verify:
- `required_count` does not exceed the number of listed signers unless signers are `待确认`.
- `VERY_STRONG` and `STRONG` approvals have `audit_required=yes`.
- Irreversible or hard-rule-related approvals are not downgraded to weak confirmation.
- Preconditions and post-actions are concrete enough to execute.
- The CSV validates with `scripts/validate_csv.py` when possible.
