# HCN schema and signing strength

## CSV schema

Column order is mandatory:

| column | required | allowed / format | meaning |
|---|---:|---|---|
| hcn_id | yes | stable ID such as `HCN-001` | Human confirmation node ID |
| title | yes | text | Human-readable node title |
| type | yes | `ACK`, `APPROVAL`, `MULTI_SIGN`, `ESCALATION`, `OVERRIDE`, `ROLLBACK`, `RELEASE`, `COMPLIANCE`, `CUSTOM` | HCN type |
| signing_strength | yes | `WEAK`, `MEDIUM`, `STRONG`, `VERY_STRONG` | Approval strength level |
| signers | yes | role/person pipe-list or `待确认` | People or roles required |
| required_count | yes | integer >= 1, or `0` only when status is `DRAFT` and signers are unknown | Required approvals |
| status | yes | `DRAFT`, `PENDING`, `APPROVED`, `REJECTED`, `ESCALATED`, `EXPIRED`, `WAIVED` | Current HCN status |
| preconditions | yes | text or pipe-list | Conditions that must hold before asking for signoff |
| post_actions | yes | text or pipe-list | Actions to perform after confirmation |
| audit_required | yes | `yes` or `no` | Whether an audit event must be generated |
| reversible | yes | `yes`, `no`, or `partial` | Whether the decision can be reverted |
| gate_ref | recommended | `GATE-###`, `not_applicable`, or `待确认` | Related gate |
| fallback_ref | recommended | `FB-###`, `not_applicable`, or `待确认` | Related fallback |
| state_ref | recommended | `STATE-###`, `TR-###`, `not_applicable`, or `待确认` | Related state transition |
| audit_event_template | required when audit_required=yes | template text | Audit row template |
| sla_priority | yes | `P0`, `P1`, `P2`, `P3` | SLA priority |
| due_at | yes | ISO date/time, relative deadline, or `待确认` | Deadline or SLA bound |
| evidence_ref | yes | source IDs or `待确认`; pipe-list allowed | Evidence backing HCN design |
| notes | optional | text | Special governance notes |

## Signing strength levels

### WEAK
Use for informational acknowledgement. Typical pattern: one signer, reversible, low risk, audit optional.

### MEDIUM
Use for accountable approval by one role or owner. Typical pattern: one required signer, moderate impact, audit preferred.

### STRONG
Use when role separation, production impact, release gating, compliance concern, or cross-team responsibility exists. Typical pattern: two or more signers or one formal authority, audit required.

### VERY_STRONG
Use for irreversible, high-risk, hard-rule, GA, canary expansion, rollback, compliance, financial, legal, or multi-party approvals. Audit is required; reversibility should normally be `no` or `partial`.

## Audit event template

Use this canonical shape when no existing audit schema is supplied:

```text
AU:new actor={signer} action={approved|rejected|escalated|waived} target={hcn_id} linked_gate={gate_ref} linked_fallback={fallback_ref} linked_state={state_ref} decision={status} evidence={evidence_ref}
```

## Escalation notes

- Gate `FAIL`, `PENDING`, `NOT_ASSESSED`, and `COND_GO` should normally have an HCN.
- Fallback `ACTIVE`, `BLOCKED`, `DISABLED`, `not_allowed` rehearsal, or policy degradation should normally have an HCN.
- Scope trimming and hard-rule override should normally be `STRONG` or `VERY_STRONG`.
