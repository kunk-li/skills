#!/usr/bin/env python3
"""Validate human confirmation node CSV records."""

import csv
import sys
from pathlib import Path

EXPECTED_COLUMNS = [
    "hcn_id", "title", "type", "signing_strength", "signers", "required_count", "status",
    "preconditions", "post_actions", "audit_required", "reversible", "gate_ref", "fallback_ref",
    "state_ref", "audit_event_template", "sla_priority", "due_at", "evidence_ref", "notes",
]

TYPES = {"ACK", "APPROVAL", "MULTI_SIGN", "ESCALATION", "OVERRIDE", "ROLLBACK", "RELEASE", "COMPLIANCE", "CUSTOM"}
STRENGTH = {"WEAK", "MEDIUM", "STRONG", "VERY_STRONG"}
STATUS = {"DRAFT", "PENDING", "APPROVED", "REJECTED", "ESCALATED", "EXPIRED", "WAIVED"}
YES_NO = {"yes", "no"}
REVERSIBLE = {"yes", "no", "partial"}
SLA = {"P0", "P1", "P2", "P3"}
REQUIRED = {
    "hcn_id", "title", "type", "signing_strength", "signers", "required_count", "status",
    "preconditions", "post_actions", "audit_required", "reversible", "sla_priority",
    "due_at", "evidence_ref",
}


def validate(path: Path) -> int:
    errors = []
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != EXPECTED_COLUMNS:
            errors.append("header mismatch: expected " + ",".join(EXPECTED_COLUMNS))
            errors.append("actual: " + ",".join(reader.fieldnames or []))
            print_errors(errors)
            return 1
        rows = list(reader)

    if not rows:
        errors.append("CSV has no data rows")

    seen = set()
    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED:
            if not (row.get(field) or "").strip():
                errors.append(f"row {idx}: {field} is required")
        hcn_id = (row.get("hcn_id") or "").strip()
        if hcn_id in seen:
            errors.append(f"row {idx}: duplicate hcn_id {hcn_id}")
        seen.add(hcn_id)

        hcn_type = (row.get("type") or "").strip()
        if hcn_type not in TYPES:
            errors.append(f"row {idx}: type must be one of {sorted(TYPES)}")
        strength = (row.get("signing_strength") or "").strip()
        if strength not in STRENGTH:
            errors.append(f"row {idx}: signing_strength must be one of {sorted(STRENGTH)}")
        status = (row.get("status") or "").strip()
        if status not in STATUS:
            errors.append(f"row {idx}: status must be one of {sorted(STATUS)}")
        audit_required = (row.get("audit_required") or "").strip()
        if audit_required not in YES_NO:
            errors.append(f"row {idx}: audit_required must be yes or no")
        reversible = (row.get("reversible") or "").strip()
        if reversible not in REVERSIBLE:
            errors.append(f"row {idx}: reversible must be one of {sorted(REVERSIBLE)}")
        sla = (row.get("sla_priority") or "").strip()
        if sla not in SLA:
            errors.append(f"row {idx}: sla_priority must be one of {sorted(SLA)}")

        raw_required = (row.get("required_count") or "").strip()
        try:
            required_count = int(raw_required)
        except ValueError:
            errors.append(f"row {idx}: required_count must be an integer")
            required_count = 0
        if required_count < 0:
            errors.append(f"row {idx}: required_count must be >= 0")

        signers_raw = (row.get("signers") or "").strip()
        signers = [] if signers_raw in {"", "待确认"} else [s for s in signers_raw.split("|") if s]
        if signers and required_count > len(signers):
            errors.append(f"row {idx}: required_count exceeds number of signers")
        if not signers and status != "DRAFT" and signers_raw != "待确认":
            errors.append(f"row {idx}: signers missing outside DRAFT")
        if status != "DRAFT" and required_count < 1:
            errors.append(f"row {idx}: non-DRAFT HCN requires required_count >= 1")

        audit_template = (row.get("audit_event_template") or "").strip()
        if audit_required == "yes" and not audit_template:
            errors.append(f"row {idx}: audit_required=yes requires audit_event_template")
        if strength in {"STRONG", "VERY_STRONG"} and audit_required != "yes":
            errors.append(f"row {idx}: {strength} requires audit_required=yes")
        if strength == "VERY_STRONG" and reversible == "yes":
            errors.append(f"row {idx}: VERY_STRONG should not be fully reversible; use no or partial")
        if hcn_type in {"ROLLBACK", "RELEASE", "COMPLIANCE", "OVERRIDE"} and strength == "WEAK":
            errors.append(f"row {idx}: {hcn_type} cannot use WEAK signing_strength")

    if errors:
        print_errors(errors)
        return 1
    print(f"OK: {path} has {len(rows)} valid HCN rows")
    return 0


def print_errors(errors):
    for error in errors:
        print("ERROR:", error, file=sys.stderr)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: validate_csv.py <hcn_records.csv>", file=sys.stderr)
        sys.exit(2)
    sys.exit(validate(Path(sys.argv[1])))
