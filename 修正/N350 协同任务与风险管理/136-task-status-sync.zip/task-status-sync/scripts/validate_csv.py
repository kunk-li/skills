#!/usr/bin/env python3
import csv
import sys
from pathlib import Path

SCHEMA_NAME = 'n350.task-status-sync.v2'
EXPECTED_HEADERS = ['id', 'title', 'owner', 'status', 'progress_summary', 'blocker_refs', 'dependency_refs', 'next_step', 'deadline', 'last_update', 'evidence_ref']
REQUIRED_FIELDS = set(['id', 'title', 'owner', 'status', 'progress_summary'])
LIST_FIELDS = set(['blocker_refs', 'dependency_refs', 'evidence_ref'])

def fail(msg: str) -> int:
    print(f"[FAIL] {msg}")
    return 1

def ok(msg: str) -> int:
    print(f"[OK] {msg}")
    return 0

def main() -> int:
    if len(sys.argv) != 2:
        print('usage: python scripts/validate_csv.py <task-status-sync.csv>')
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        return fail(f"file not found: {path}")
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        if headers != EXPECTED_HEADERS:
            return fail(f"header mismatch for {SCHEMA_NAME}. expected={EXPECTED_HEADERS} got={headers}")
        rows = list(reader)
    if not rows:
        return fail("csv has no data rows")

    seen_ids = set()
    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED_FIELDS:
            if not (row.get(field) or '').strip():
                return fail(f"row {idx} missing required field: {field}")
        for field in LIST_FIELDS:
            value = (row.get(field) or '').strip()
            if ',' in value:
                return fail(f"row {idx} field '{field}' must use '|' instead of commas for multi-value lists")
        id_field = next((k for k in EXPECTED_HEADERS if k.endswith('_id') or k == 'id'), None)
        if id_field:
            ident = (row.get(id_field) or '').strip()
            if ident in seen_ids:
                return fail(f"duplicate id at row {idx}: {ident}")
            seen_ids.add(ident)
        status = (row.get('status') or '').strip()
        allowed_status = {'TODO','IN_PROGRESS','DONE','BLOCKED'}
        if status not in allowed_status:
            return fail(f"row {idx} invalid status: {status}")
    return ok(f"{SCHEMA_NAME} validation passed: {len(rows)} rows")

if __name__ == '__main__':
    raise SystemExit(main())
