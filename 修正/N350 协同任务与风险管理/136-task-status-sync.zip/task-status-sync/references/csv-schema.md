# task-status-sync csv schema

schema: `n350.task-status-sync.v2`

## columns
`id,title,owner,status,progress_summary,blocker_refs,dependency_refs,next_step,deadline,last_update,evidence_ref`

## field rules
- `status`: 仅允许 `TODO` / `IN_PROGRESS` / `DONE` / `BLOCKED`
- `progress_summary`: 先事实，后待核对项
- `blocker_refs` / `dependency_refs` / `evidence_ref`: 多值用 `|`
- `last_update`: 保留时间线信息，便于 delta 更新

## csv rules
- RFC-4180
- UTF-8
- 列表字段不用裸逗号，统一 `|`

## example
```csv
id,title,owner,status,progress_summary,blocker_refs,dependency_refs,next_step,deadline,last_update,evidence_ref
TASK-001,完成交接包字段核对,张三,IN_PROGRESS,已完成字段梳理并提交一版核对表,,TASK-000,补齐剩余差异项,2026-05-02,2026-04-23,meeting:weekly-2026-04-23#action:2
```
