#!/usr/bin/env python3
import csv
import sys
from pathlib import Path

SCHEMA_NAME = 'n350.blocker-extraction.v2'
EXPECTED_HEADERS = ['blocker_id', 'title', 'affected_task_ids', 'blocker_type', 'severity', 'owner', 'evidence_ref', 'impact_summary', 'unblock_action', 'escalation_path', 'status']
REQUIRED_FIELDS = set(['blocker_id', 'title', 'blocker_type', 'severity', 'owner', 'evidence_ref', 'impact_summary', 'status'])
LIST_FIELDS = set(['affected_task_ids', 'evidence_ref', 'escalation_path'])

def fail(msg: str) -> int:
    print(f"[FAIL] {msg}")
    return 1

def ok(msg: str) -> int:
    print(f"[OK] {msg}")
    return 0

def main() -> int:
    if len(sys.argv) != 2:
        print('usage: python scripts/validate_csv.py <blockers.csv>')
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        return fail(f"file not found: {path}")
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        if headers != EXPECTED_HEADERS:
            return fail(f"header mismatch for {SCHEMA_NAME}. expected={EXPECTED_HEADERS} got={headers}")
        rows = list(reader)
    if not rows:
        return fail("csv has no data rows")

    seen_ids = set()
    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED_FIELDS:
            if not (row.get(field) or '').strip():
                return fail(f"row {idx} missing required field: {field}")
        for field in LIST_FIELDS:
            value = (row.get(field) or '').strip()
            if ',' in value:
                return fail(f"row {idx} field '{field}' must use '|' instead of commas for multi-value lists")
        id_field = next((k for k in EXPECTED_HEADERS if k.endswith('_id') or k == 'id'), None)
        if id_field:
            ident = (row.get(id_field) or '').strip()
            if ident in seen_ids:
                return fail(f"duplicate id at row {idx}: {ident}")
            seen_ids.add(ident)
        blocker_type = (row.get('blocker_type') or '').strip()
        allowed_type = {'dependency','decision','resource','technical','external','compliance','other'}
        if blocker_type not in allowed_type:
            return fail(f"row {idx} invalid blocker_type: {blocker_type}")
        severity = (row.get('severity') or '').strip()
        if severity not in {'low','medium','high'}:
            return fail(f"row {idx} invalid severity: {severity}")
        status = (row.get('status') or '').strip()
        if status not in {'OPEN','MONITORING','RESOLVED'}:
            return fail(f"row {idx} invalid status: {status}")
    return ok(f"{SCHEMA_NAME} validation passed: {len(rows)} rows")

if __name__ == '__main__':
    raise SystemExit(main())
