# blocker evidence_ref 模板

`evidence_ref` 必须能让下游人员追溯到“为什么说它是 blocker”。

## 推荐格式
- `meeting:<meeting_id>#action:<n>`
- `doc:<file_or_doc>#section:<anchor>`
- `ticket:<system>-<id>`
- `log:<log_name>#ts:<timestamp>`
- `chat:<channel_or_thread>#msg:<id>`

## 最低要求
- 至少能回答“证据来自哪里”。
- 如果证据不完整但 blocker 明显存在，先写 `待核对`，同时在 `impact_summary` 或补充说明里写出缺什么证据。

## blocker vs risk
- **blocker**：已经发生，正在阻塞进度。
- **risk**：尚未发生，但有较高可能影响进度 / 范围 / 质量。

## 升级路径提示
- 指向质量门禁 / 缺陷熔断：优先考虑 `N250`
- 需要人工确认 / 跨团队拍板 / 平台放行：优先考虑 `N380`
- 仅需项目经理协同：可写 `PM`
