# blocker-extraction csv schema

schema: `n350.blocker-extraction.v2`

## columns
`blocker_id,title,affected_task_ids,blocker_type,severity,owner,evidence_ref,impact_summary,unblock_action,escalation_path,status`

## field rules
- `affected_task_ids` / `evidence_ref` / `escalation_path`: 多值用 `|`
- `blocker_type`: `dependency` / `decision` / `resource` / `technical` / `external` / `compliance` / `other`
- `severity`: `low` / `medium` / `high`
- `status`: `OPEN` / `MONITORING` / `RESOLVED`
- `evidence_ref`: 必填；拿不到时写 `待核对`

## csv rules
- RFC-4180
- UTF-8
- 列表字段不用裸逗号，统一 `|`

## example
```csv
blocker_id,title,affected_task_ids,blocker_type,severity,owner,evidence_ref,impact_summary,unblock_action,escalation_path,status
BLK-001,测试环境账号未开通,TASK-003|TASK-004,resource,high,李四,ticket:OPS-129,阻塞回归执行并影响本周节奏,由运维在 4/24 前完成开通,PM|N380,OPEN
```
