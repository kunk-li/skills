---
name: task-initiation
description: generate structured task drafts from handover packs, meeting action items, gap lists, incidents, or change requests for n350 coordination. use when chatgpt should output reusable task rows or rfc4180 csv with explicit placeholders, configurable priority modes, stable task ids, parent refs, and evidence refs without directly operating an external task system.
---

# 任务发起

把需求、决议、gap、故障 action、变更说明整理成 **可执行且可交接** 的任务清单。

先阅读：
- `references/n350-contracts.md`
- `references/csv-schema.md`
- `references/task-priority-modes.md`（仅在需要切换优先级体系时）

## 先做这件事
先判断是 **全量起草** 还是 **增量合并**：
1. 已有旧任务台账 + 新输入信号 → **增量合并**，保留已有 `id`
2. 没有旧台账 → **全量起草**

## 优先吸收的输入
1. `需求交接包.zip`
2. `行动项清单.csv` / 会议纪要
3. `需求变更影响分析.md`
4. GAP、incident RCA、上线问题、周报
5. 用户现有任务模板或字段约束

## 工作流
1. 只提取输入中已经被支持的事实、动作、依赖、待确认项。
2. 将大目标拆成可验收的最小任务，避免把多个无关目标塞进一条任务。
3. 为每条任务补齐目标、完成标准、依赖、证据来源和上游来源。
4. 若用户给了既有台账，优先复用既有 `id`、`owner`、`deadline`，仅更新确有新依据的字段。
5. 若关键信息缺失，不要伪造，使用 `待确认`。
6. 若用户未指定格式且结果需要下游消费，优先输出 **schema 化 CSV**。

## 默认契约模式（推荐）
当用户需要结构化结果、后续要给 N340/N360/N370 消费、或明确提到 CSV / 表格 / 导入任务系统时，输出：

- schema: `n350.task-initiation.v2`
- exact columns:
  `id,title,owner,priority,status,deadline,dependencies,success_criteria,evidence_ref,parent_ref`

规则：
- `status` 默认优先用 `TODO`；只有输入明确显示已启动 / 已完成 / 已阻塞时才改成其他值。
- `dependencies`、`evidence_ref`、`parent_ref` 是多值字段时统一用 `|`。
- 如果来源是会议 action，`parent_ref` 优先写成 `meeting:<meeting_id>#action:<n>`。
- `evidence_ref` 可以为空事实极少；若需要证据但拿不到，写 `待核对`，不要编造链接或 ticket。

## 优先级模式
- 优先沿用用户或上游已有模式。
- 若需要切换，读取 `references/task-priority-modes.md`。
- 同一份输出不要混用多种优先级体系。
- 用户未指定时，回退到 `P0-P3`。

## 何时输出 markdown 而不是 csv
仅当用户明确说“先给草稿”“只要正文模板”“不需要机器消费”时，输出 markdown；但字段语义仍然保持与 CSV 契约一致。

## 严格边界
- 不直接创建真实工单。
- 不替代项目经理拍板 owner、排期、资源承诺。
- 不把需求分析、技术方案、测试方案细节展开成专业产出；这里只做任务层结构化。

## 质量检查
在完成前确认：
- 每条任务都能回答“做什么、做到什么算完成、依赖什么、来自哪里”。
- 没有把多个不相关目标混成一条任务。
- 缺失字段被显式标为 `待确认`，而不是被伪造。
- 若输出 CSV，遵守 `references/csv-schema.md`，必要时可运行 `scripts/validate_csv.py`。
