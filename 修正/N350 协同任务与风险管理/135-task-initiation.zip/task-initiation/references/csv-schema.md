# task-initiation csv schema

schema: `n350.task-initiation.v2`

## columns
`id,title,owner,priority,status,deadline,dependencies,success_criteria,evidence_ref,parent_ref`

## field rules
- `id`: 稳定任务 id，如 `TASK-001`
- `title`: 可执行标题，不写纯口号
- `owner`: 未知时写 `待确认`
- `priority`: 统一采用单一体系；默认 `P0-P3`
- `status`: `TODO` / `IN_PROGRESS` / `DONE` / `BLOCKED` / `待确认`
- `deadline`: 日期、时间窗口或 `待确认`
- `dependencies`: 多值时用 `|`
- `success_criteria`: 尽量写可验收条件
- `evidence_ref`: 多值时用 `|`；缺证据但需要证据时写 `待核对`
- `parent_ref`: 指向上游 action / issue / gap / incident

## csv rules
- 遵守 RFC-4180
- UTF-8 编码
- 多值字段不用裸逗号，统一 `|`

## example
```csv
id,title,owner,priority,status,deadline,dependencies,success_criteria,evidence_ref,parent_ref
TASK-001,完成交接包字段核对,张三,P1,TODO,2026-05-02,TASK-000|API-002,交接包字段清单通过校验,doc:handover#fields,meeting:prd-review-2026-04-21#action:3
```
