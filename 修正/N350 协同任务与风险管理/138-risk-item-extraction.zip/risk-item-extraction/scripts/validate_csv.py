#!/usr/bin/env python3
import csv
import sys
from pathlib import Path

SCHEMA_NAME = 'n350.risk-item-extraction.v2'
EXPECTED_HEADERS = ['risk_id', 'title', 'category', 'likelihood', 'impact', 'risk_score', 'affected_scope', 'trigger_signal', 'mitigation', 'mitigation_owner', 'mitigation_due', 'evidence_ref', 'scope_trim_candidate', 'related_blocker_ids']
REQUIRED_FIELDS = set(['risk_id', 'title', 'category', 'likelihood', 'impact', 'risk_score', 'mitigation', 'evidence_ref', 'scope_trim_candidate'])
LIST_FIELDS = set(['affected_scope', 'evidence_ref', 'related_blocker_ids'])

def fail(msg: str) -> int:
    print(f"[FAIL] {msg}")
    return 1

def ok(msg: str) -> int:
    print(f"[OK] {msg}")
    return 0

def main() -> int:
    if len(sys.argv) != 2:
        print('usage: python scripts/validate_csv.py <risks.csv>')
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        return fail(f"file not found: {path}")
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        if headers != EXPECTED_HEADERS:
            return fail(f"header mismatch for {SCHEMA_NAME}. expected={EXPECTED_HEADERS} got={headers}")
        rows = list(reader)
    if not rows:
        return fail("csv has no data rows")

    seen_ids = set()
    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED_FIELDS:
            if not (row.get(field) or '').strip():
                return fail(f"row {idx} missing required field: {field}")
        for field in LIST_FIELDS:
            value = (row.get(field) or '').strip()
            if ',' in value:
                return fail(f"row {idx} field '{field}' must use '|' instead of commas for multi-value lists")
        id_field = next((k for k in EXPECTED_HEADERS if k.endswith('_id') or k == 'id'), None)
        if id_field:
            ident = (row.get(id_field) or '').strip()
            if ident in seen_ids:
                return fail(f"duplicate id at row {idx}: {ident}")
            seen_ids.add(ident)
        category = (row.get('category') or '').strip()
        allowed_category = {'schedule','resource','dependency','technical','quality','security','compliance','external','other'}
        if category not in allowed_category:
            return fail(f"row {idx} invalid category: {category}")
        try:
            likelihood = int((row.get('likelihood') or '').strip())
            impact = int((row.get('impact') or '').strip())
            risk_score = int((row.get('risk_score') or '').strip())
        except ValueError:
            return fail(f"row {idx} likelihood/impact/risk_score must be integers")
        if not (1 <= likelihood <= 5 and 1 <= impact <= 5):
            return fail(f"row {idx} likelihood and impact must be in 1..5")
        if risk_score != likelihood * impact:
            return fail(f"row {idx} risk_score must equal likelihood * impact")
        scope_trim_candidate = (row.get('scope_trim_candidate') or '').strip()
        if scope_trim_candidate not in {'YES','NO'}:
            return fail(f"row {idx} invalid scope_trim_candidate: {scope_trim_candidate}")
    return ok(f"{SCHEMA_NAME} validation passed: {len(rows)} rows")

if __name__ == '__main__':
    raise SystemExit(main())
