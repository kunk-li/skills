# risk-item-extraction csv schema

schema: `n350.risk-item-extraction.v2`

## columns
`risk_id,title,category,likelihood,impact,risk_score,affected_scope,trigger_signal,mitigation,mitigation_owner,mitigation_due,evidence_ref,scope_trim_candidate,related_blocker_ids`

## field rules
- `category`: `schedule` / `resource` / `dependency` / `technical` / `quality` / `security` / `compliance` / `external` / `other`
- `likelihood` / `impact`: `1-5`
- `risk_score`: `likelihood × impact`
- `affected_scope` / `evidence_ref` / `related_blocker_ids`: 多值用 `|`
- `scope_trim_candidate`: `YES` / `NO`

## csv rules
- RFC-4180
- UTF-8
- 列表字段不用裸逗号，统一 `|`
- 输出前先按 `risk_score desc`、再按 `impact desc` 排序

## example
```csv
risk_id,title,category,likelihood,impact,risk_score,affected_scope,trigger_signal,mitigation,mitigation_owner,mitigation_due,evidence_ref,scope_trim_candidate,related_blocker_ids
RISK-001,外部依赖接口可能延期,dependency,4,4,16,支付接入|回归计划,供应商尚未确认联调窗口,由接口负责人在 4/25 前锁定联调计划,王五,2026-04-25,meeting:vendor-sync-2026-04-23#action:1,YES,
```
