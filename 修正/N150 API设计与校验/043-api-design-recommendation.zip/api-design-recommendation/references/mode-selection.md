# Mode Selection

Choose the simplest mode that matches the evidence.

## Use `from_intent` when
- you have requirements, workflow text, or upstream intent extraction
- the system is being designed or redesigned
- project policy still needs to be established

## Use `from_existing` when
- you have current endpoints, OpenAPI, gateway configs, or controller annotations
- you need to normalize drift in an existing project
- you need to capture legacy exceptions explicitly

## Use `openapi_export` when
- a machine-readable contract is required
- downstream code generation or linting is expected
- the user asked for OpenAPI 3.x output or schema export
