# Example Input / Output

## Example input
A workflow says: employees submit leave, managers approve or reject, HR can view but cannot approve, and the system may send callbacks to payroll.

## Example output sketch
- `api_policy.style = mixed` with resource CRUD plus action endpoints for approval transitions
- `api_kind = crud_resource` for leave request creation and retrieval
- `api_kind = state_transition` for approve/reject operations
- `api_kind = webhook_callback` for payroll callback handling
- shared schemas for leave request, actor context, and standard error envelope
- downstream handoff listing auth scopes, error seeds, and OpenAPI export readiness
