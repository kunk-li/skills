# Composition Contract for the N150 Trio

When 043, 044, and 045 are used together, keep one shared project contract object.

## Canonical shared structure
```yaml
project_api_contract:
  policies: ...
  rules: ...
  error_codes: ...
  apis:
    - id: ...
      design_ref: ...
      compliance_status: ...
      errors_applicable: [...]
  maturity_signals:
    overall_score: null
    blockers: []
```

## 043 responsibilities
- define `policies`
- define the API surface under `apis[*].design_ref`
- seed error scenarios and metadata

## 044 responsibilities
- define `rules`
- attach `compliance_status`
- identify blockers, waivers, and cross-API consistency issues

## 045 responsibilities
- define `error_codes`
- map codes to APIs
- confirm client guidance and localization readiness
