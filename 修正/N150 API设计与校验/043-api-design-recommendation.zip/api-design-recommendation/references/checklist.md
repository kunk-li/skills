# 043 Delivery Checklist

## Policy baseline
- [ ] `api_policy` exists before per-API drafting
- [ ] style, versioning, pagination, envelope, auth baseline, and request ID policy are explicit
- [ ] any policy deviation is recorded as a waiver or exception

## Contract completeness
- [ ] every API has `api_id`, `api_kind`, protocol, operation, request, response, metadata, and evidence
- [ ] stateful resources include `available_actions` when that materially helps clients
- [ ] shared request/response shapes are extracted into `shared_schemas`
- [ ] write APIs include idempotency behavior

## Consistency and safety
- [ ] pagination and filtering follow one project rule unless an exception is justified
- [ ] GET or equivalent safe operations do not mutate state
- [ ] sensitive data is not silently placed in query parameters
- [ ] response envelopes and error-format assumptions are stable for downstream reuse

## Cross-skill alignment
- [ ] output is immediately usable by 044 as a compliance baseline
- [ ] output contains error-case seeds for 045
- [ ] `downstream_handoff` includes OpenAPI/export hints when relevant
