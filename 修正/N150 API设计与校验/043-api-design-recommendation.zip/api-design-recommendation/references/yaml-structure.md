# YAML Structure Contract

Use this structure when the output is YAML, `markdown_and_yaml`, or OpenAPI-adjacent.

## Top-level sections
- `metadata`
- `api_policy`
- `api_catalog`
- `shared_schemas`
- `pagination_contract`
- `consistency_waivers`
- `open_questions`
- `downstream_handoff`
- `self_check`

## metadata
Required keys:
- `artifact_type: api_design_draft`
- `selected_mode`
- `readiness`
- `coverage_scope`
- `excluded_scope`
- `generated_from`

## api_policy
Required keys:
- `style`
- `mixed_rules`
- `versioning`
- `pagination`
- `filter`
- `response_envelope`
- `error_format`
- `idempotency`
- `request_id`
- `auth_baseline`

## api_catalog[]
Each entry should contain:
- `api_id`
- `name`
- `api_kind`
- `protocol`
- `method_or_operation`
- `path_or_topic`
- `purpose`
- `request`
- `response`
- `available_actions`
- `contract_metadata`
- `policy_exceptions`
- `error_case_seeds`
- `evidence`
- `confidence`

## shared_schemas[]
For each schema include:
- `schema_name`
- `fields`
- `reused_by`
- `notes`

## pagination_contract
Required keys:
- `default_style`
- `request_shape`
- `response_shape`
- `limit_max`
- `waivers`

## downstream_handoff
Required consumers:
- `api-spec-compliance-check`
- `api-error-code-design`
Optional consumers:
- OpenAPI export
- data-model design
- code generation
