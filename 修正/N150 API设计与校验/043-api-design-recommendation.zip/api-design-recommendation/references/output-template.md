# Output Template: API Design Recommendation

## 1. Objective
State scope, selected mode, excluded scope, and readiness.

## 2. Evidence Profile
| source | what it confirms | remaining uncertainty |

## 3. Project API Policy
Use a structured table or YAML block covering:
- style
- versioning
- pagination
- filter/sort rules
- envelope and error format
- idempotency
- request ID
- auth baseline

## 4. API Surface Summary
| api_id | api_kind | method_or_operation | path_or_topic | owner | confidence |

## 5. Detailed API Catalog
For each API include:
- purpose
- request
- response
- available actions when relevant
- metadata
- policy exceptions
- evidence
- open questions
- error-case seeds

## 6. Shared Schemas and Conventions
| schema or convention | reused by | notes |

## 7. Consistency Waivers
| api_id | waived rule | reason | review trigger |

## 8. Downstream Handoff
| consumer | what it should read | why |

## 9. Open Questions
| id | question | impact | owner |

## 10. Self-Check
Summarize checklist and scoring results.
