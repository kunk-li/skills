# API Policy Taxonomy

## Style
- `rest_oriented`
- `action_oriented`
- `mixed`

## Versioning
- `url_path`
- `header`
- `query`

## Pagination
- `offset_limit`
- `cursor`
- `page_size`

## Response envelope
- `none` for bare HTTP body plus status semantics
- `custom_envelope` such as `{ code, message, data }`
- `rfc7807` for problem details on errors

## Idempotency
Recommended header: `X-Idempotency-Key`
Typical apply set:
- POST with create-or-trigger semantics
- PUT/PATCH when retries matter

## API kinds
- `crud_resource`
- `state_transition`
- `composite_query`
- `batch_operation`
- `webhook_callback`
- `stream_event`
- `rpc_command`

## Contract metadata
Recommended minimum:
- `stability`
- `owner`
- `auth`
- `rate_limit`
- `sla`
- `idempotent`
- `safe`
