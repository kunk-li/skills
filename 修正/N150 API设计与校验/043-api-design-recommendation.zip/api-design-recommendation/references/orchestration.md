# Orchestration

## Upstream expectations
Best inputs:
- API intent extraction or requirement analysis for candidate operations
- module-boundary-identification for ownership and handoff boundaries
- service-decomposition-recommendation for deployment and communication constraints
- existing OpenAPI or endpoint inventories for reverse-engineering

## 043 -> 044 mapping
| 043 field | 044 usage |
|---|---|
| `api_policy` | rule baseline and consistency checks |
| `api_catalog[].api_kind` | method/style checks |
| `pagination_contract` | pagination consistency checks |
| `contract_metadata` | auth, rate-limit, and SLA checks |
| `consistency_waivers` | exception-aware linting |

## 043 -> 045 mapping
| 043 field | 045 usage |
|---|---|
| `error_case_seeds` | candidate error-code inventory |
| `response_envelope` / `error_format` | error response baseline |
| `available_actions` | state-related error scenarios |
| `auth_baseline` | auth/authz categories |

## Recommended sequence
Preferred design loop:
1. 043 draft or normalize the contract surface
2. 044 run MUST / MUST_NOT gate immediately
3. 043 revise the draft if needed
4. 045 design the error-code registry
5. 044 optionally re-check cross-API consistency and error coverage
