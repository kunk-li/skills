# Common Failure Modes for API Design Recommendation

## F1: no project policy, only endpoint list
Fix: define `api_policy` first, then design endpoints.

## F2: mixed API styles without an explicit rule
Fix: set `api_policy.style = mixed` and document `mixed_rules`.

## F3: every workflow step becomes a bespoke endpoint
Fix: classify APIs using `api_kind` and consolidate where a stable resource model exists.

## F4: no distinction between resource actions and state transitions
Fix: use `crud_resource` vs `state_transition` explicitly.

## F5: pagination drift across similar APIs
Fix: define one primary pagination contract and log any exceptions.

## F6: stateful APIs without client guidance
Fix: add `available_actions` or `_links` hints for state-machine-heavy resources.

## F7: metadata omitted because it feels operational
Fix: include ownership, stability, auth, rate limits, and SLA expectations in `contract_metadata`.

## F8: OpenAPI export requested but shared schemas were never normalized
Fix: extract reusable schemas first, then export.
