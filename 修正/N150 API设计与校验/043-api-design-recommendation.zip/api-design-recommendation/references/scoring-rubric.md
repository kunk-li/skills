# 043 Scoring Rubric

Score each dimension from 1 to 5.

## A. Policy quality
1 = endpoint list only, 5 = stable project-level policy with explicit exceptions

## B. Contract completeness
1 = partial sketch, 5 = reusable API catalog with shared schemas and metadata

## C. Consistency discipline
1 = style drift and pagination drift, 5 = one coherent design baseline

## D. Downstream readiness
1 = 044 and 045 must reinterpret the draft, 5 = downstream skills can consume it directly

A strong delivery should average at least 4/5.
