---
name: api-design-recommendation
description: recommend api contracts, project-level api policy, resource and action patterns, pagination and filtering conventions, response envelopes, contract metadata, and openapi-ready structures from requirement analysis, api intent, architecture notes, boundary outputs, existing specs, or live api inventories. use when chatgpt works in technical solution design / api design and must produce the workflow-aligned 接口设计草案.yaml for n150 before compliance checking, error-code design, code generation, test orchestration, or technical documentation.
---
# api-design-recommendation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> API设计 -> 接口契约设计」。

它是 **direct_result** 型技能：目标是把产品 / 技术意图落实成可消费的接口契约，而不是只讨论“接口大概怎么设计”。默认交付物要对齐 N150 节点标准产物 **`接口设计草案.yaml`**。

### Boundary / 边界
- 负责定义项目级 `api_policy` 和 API surface。
- 负责给出 OpenAPI-ready 的请求 / 响应 / path / operation 结构。
- 负责为 044 提供设计期规范基线、为 045 提供 error seeds。
- 不负责最终规范门禁判定；该职责交给 `api-spec-compliance-check`。
- 不负责错误码注册表本身；该职责交给 `api-error-code-design`。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `from_intent`：从需求、流程、接口意图或上游结构化分析设计 API；默认模式。
- `from_existing`：从现有 OpenAPI、接口清单、注解或 legacy 文档逆向整理。
- `openapi_export`：在正常分析基础上额外产出机器可消费的 YAML / OpenAPI 结构。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `开发需求解析.md`
- `接口意图清单.csv`
- `技术方案分析.md`

### 可选增强输入
- 模块边界、服务拆分、现有 API inventory、OpenAPI 文件、控制器注解
- 数据对象、共享 schema、权限要求、审计要求、对外集成说明

## Standalone rule / 独立使用规则
即使没有完整上游节点输出，也可以单独使用。

降级规则：
- 若缺少结构化 API intent，可从 PRD / 流程 / 技术方案反推 provisional contract。
- 顶部必须标明 `readiness: provisional`。
- 必须把 `confirmed / inferred / pending` 分开写。
- 未决的 style、versioning、auth、pagination 选择必须进入 `open_questions` 或 `policy_exceptions`。

## Core output contract / 核心输出契约
默认输出应以 YAML / OpenAPI-ready 契约为主，必要时附简短 Markdown 说明。优先复用 `references/output-template.md` 与 `references/yaml-structure.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.api_design.contract_design`
  - `node_artifact_target: 接口设计草案.yaml`
  - `workflow_node: N150`
  - `evidence_profile`
- `api_policy`
- `api_catalog[]`
- `shared_schemas[]`
- `pagination_contract`
- `consistency_waivers[]`
- `open_questions[]`
- `downstream_handoff`
  - `intra_node_consumers`: `api-spec-compliance-check`, `api-error-code-design`
  - `workflow_downstream`: `N190`, `N200`, `N240`, `N330`
  - `artifact_name: 接口设计草案.yaml`
- `self_check`

### Required `api_policy`
必须先定义：
- `style`
- `mixed_rules` when needed
- `versioning`
- `pagination`
- `filter`
- `response_envelope`
- `error_format`
- `idempotency`
- `request_id`
- `auth_baseline`

### Required per-API fields
每个 API 至少包含：
- `api_id`
- `name`
- `api_kind`
- `protocol`
- `method_or_operation`
- `path_or_topic`
- `purpose`
- `request`
- `response`
- `available_actions` when stateful
- `contract_metadata`
- `policy_exceptions`
- `error_case_seeds`
- `evidence`
- `confidence`

## Design rules / 设计规则
### Policy-first discipline / 策略先行
- 先定义 `api_policy`，再写单个 API。
- 任何偏离项目 policy 的 API 都必须记录 `policy_exception_reason`。
- 不得随意混用 REST、action-oriented 和 RPC-like 风格。

### Resource vs action discipline / 资源与动作纪律
- 稳定 CRUD 优先资源路径。
- 真正的状态迁移、跨资源命令才用 action path。
- 若团队故意选择动作风格，也要把它写成 policy decision，而不是默许的不一致。

### Pagination and filter discipline / 分页过滤纪律
- 每个项目定义一个主分页风格。
- offset 风格必须返回 `total / offset / limit`。
- cursor 风格必须返回 `next_cursor / has_more`。
- 未经说明，不要把 PII 放进 query parameter。

### Contract metadata discipline / 契约元数据纪律
每个 API 必须包含或继承：
- `stability`
- `owner`
- `auth`
- `rate_limit`
- `sla`
- `idempotent`
- `safe`
- `deprecated_since / sunset_date` when needed

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 以 `开发需求解析.md`、`接口意图清单.csv`、`技术方案分析.md` 为主输入建模。
3. 先定义项目级 `api_policy`。
4. 构造 `api_catalog`，为每个 API 归类 `api_kind`。
5. 统一 pagination、filter、response envelope、auth、metadata。
6. 抽取 `shared_schemas`。
7. 生成 `error_case_seeds`，供 045 继续设计。
8. 形成面向 N150 节点标准产物的 **`接口设计草案.yaml`**。
9. 输出 `downstream_handoff`，供 044、045 以及 N190 / N200 / N240 / N330 使用。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小 feature：覆盖全部接口
- 中等系统：覆盖全部关键业务与对外暴露接口
- 大型平台：至少覆盖核心 API catalog、项目 policy、高风险 path，并显式标 deferred area

不要为了凑完整度制造并不存在的接口，也不要因为系统大就只给空泛 guideline。

## Quality bar / 质量门槛
合格结果应能直接被 044 与 045 继续消费，并能被 N190 / N200 / N240 / N330 复用，而不需要二次翻译。

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/api-policy-taxonomy.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/output-template.md`
- `references/yaml-structure.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/api-policy-taxonomy.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
