# Orchestration

## Upstream expectations
Preferred upstream input is 043 output or a project API catalog.

## 043 -> 044 mapping
| upstream field | this skill uses it for |
|---|---|
| `api_policy` | baseline rule set |
| `api_catalog` | per-API checks |
| `shared_schemas` | response and schema consistency |
| `consistency_waivers` | exception-aware linting |
| `downstream_handoff` | check scope and consumers |

## 044 -> 043 feedback loop
- MUST and MUST_NOT findings should send the design back to 043 immediately.
- SHOULD findings should inform revision priorities.
- policy drift should become explicit waivers or design fixes.

## 044 -> 045 mapping
| finding type | downstream implication |
|---|---|
| missing error code coverage | add or normalize codes |
| inconsistent envelope | align error response baseline |
| auth or rate-limit gaps | ensure category and client-guidance coverage |
| undocumented errors | add registry entries or spec updates |
