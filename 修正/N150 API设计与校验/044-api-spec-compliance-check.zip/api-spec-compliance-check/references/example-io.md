# Example Input / Output

## Example input
A project has mixed endpoints for `/leave-requests`, approval actions, and webhook callbacks, plus a shared error envelope.

## Example output sketch
- blocker: GET endpoint mutates approval state
- major: pagination parameters differ between list APIs
- major: request ID header missing on callback path
- warning: versioning rule not documented for one legacy endpoint
- cross-API conflict: `status` means workflow state in one API and health state in another
