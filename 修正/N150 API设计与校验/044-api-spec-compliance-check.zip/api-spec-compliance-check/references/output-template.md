# Output Template: API Spec Compliance Check

## 1. Objective
State selected mode, reviewed scope, and policy baseline source.

## 2. Coverage Summary
| area | coverage | evidence level |

## 3. Gate Decision
| decision | blocking count | major count | notes |

## 4. Findings by Severity
Summarize blockers, majors, warnings, and optional items.

## 5. Findings by Category
| rule_category | count | dominant pattern |

## 6. Cross-API Consistency Findings
| rule_id | affected APIs | conflict | required fix |

## 7. Automation Integration
Describe CI, lint, or Spectral export guidance when requested.

## 8. Feedback Handoff
| consumer | what to fix or consume | priority |

## 9. Self-Check
Summarize checklist and scoring results.
