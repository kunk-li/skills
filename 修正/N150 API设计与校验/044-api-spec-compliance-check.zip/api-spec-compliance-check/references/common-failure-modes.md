# Common Failure Modes for API Spec Compliance Check

## F1: issue list without a baseline
Fix: state the policy source and rule catalog before listing findings.

## F2: all findings treated as equally severe
Fix: use RFC 2119 severity and keep blockers separate.

## F3: only single-API checking, no ecosystem consistency
Fix: run cross-API consistency checks whenever enough surface area exists.

## F4: design-time problems found only at the end
Fix: run MUST checks as soon as each API or shared policy is drafted.

## F5: implementation-only evidence used to excuse contract drift
Fix: check L1, L2, and L3 separately; drift still needs a finding.

## F6: intentional exceptions hidden inside pass results
Fix: record waivers explicitly with owner and review trigger.
