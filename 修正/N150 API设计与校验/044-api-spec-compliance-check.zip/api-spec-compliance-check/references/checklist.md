# 044 Delivery Checklist

## Baseline and coverage
- [ ] policy baseline source is explicit
- [ ] findings use `rule_category`, `severity`, and `check_level`
- [ ] blocked or undefined APIs are not treated as full passes
- [ ] cross-API consistency was checked when enough APIs exist

## Gate quality
- [ ] MUST and MUST_NOT findings are clearly separated
- [ ] SHOULD and MAY findings are not overstated as blockers
- [ ] fix suggestions are actionable and specific
- [ ] waivers and exceptions are recorded, not hidden

## Cross-skill alignment
- [ ] feedback can go directly back into 043
- [ ] error-related findings can go directly into 045
- [ ] automation advice is present when CI or lint output is requested
