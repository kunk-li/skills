# 044 Scoring Rubric

Score each dimension from 1 to 5.

## A. Baseline clarity
1 = no clear rule baseline, 5 = explicit policy source and consistent rule use

## B. Severity discipline
1 = everything is an issue, 5 = blocker, warning, and optional items are clearly separated

## C. Coverage depth
1 = a few spot checks, 5 = level-aware checks plus cross-API consistency

## D. Actionability
1 = vague comments, 5 = fix-ready findings and automation guidance

A strong delivery should average at least 4/5.
