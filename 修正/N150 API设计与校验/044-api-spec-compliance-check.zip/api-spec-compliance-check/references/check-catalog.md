# API Compliance Check Catalog

Use this as the minimum rule baseline.

## R-NAMING
- path and topic naming are consistent
- field naming style is consistent
- operation names and API IDs are stable

## R-METHOD
- safe methods do not mutate state
- write operations use an appropriate method or command style
- action endpoints are justified by policy

## R-VERSIONING
- version strategy is explicit and project-wide
- incompatible change handling is defined

## R-RESPONSE
- success and error envelopes are consistent
- pagination response shape is consistent
- status codes are semantically appropriate

## R-ERROR
- error response shape is stable
- 4xx and 5xx responses use documented error codes where required
- error-code coverage matches API behavior

## R-AUTH
- authentication requirement is explicit
- authorization scopes or permissions are explicit
- field-level or role-level restrictions are not ambiguous

## R-SECURITY
- transport/signature expectations are defined when needed
- request correlation and abuse controls exist
- rate limiting is present for sensitive or high-volume APIs

## R-COMPLIANCE
- PII exposure is controlled
- audit requirements are not bypassed
- logging and retention implications are acknowledged when relevant

## Cross-API consistency rules
- X-01 ID type consistency
- X-02 field semantic consistency
- X-03 pagination parameter consistency
- X-04 error envelope consistency
- X-05 time format consistency
- X-06 monetary field consistency
- X-07 CRUD behavior consistency
- X-08 auth mechanism consistency
- X-09 request ID header consistency
- X-10 versioning consistency
