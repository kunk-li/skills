# Mode Selection

## Use `audit_existing` when
- a current API surface already exists
- you want a standards audit or modernization baseline
- drift and waivers must be documented

## Use `lint_pr` when
- only changed APIs or schemas need review
- speed matters but gate discipline must remain
- shared conventions might still be affected by the delta

## Use `emit_spectral_rules` when
- the team wants lint rules or CI integration
- OpenAPI-first governance is in scope
- automatable and manual checks need to be separated
