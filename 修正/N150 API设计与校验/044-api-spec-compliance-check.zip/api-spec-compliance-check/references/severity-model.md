# Severity Model

Use RFC 2119 keywords only.

## MUST
Violation blocks the gate unless explicitly waived by project governance.

## MUST_NOT
Forbidden condition. Treat as a blocker.

## SHOULD
Strong recommendation. Usually a warning unless the risk is compounded.

## SHOULD_NOT
Strong anti-pattern warning.

## MAY
Optional best practice. Never present as a blocker.

## Gate heuristic
- any unresolved MUST or MUST_NOT -> fail
- many related SHOULD findings -> warn and require review
- MAY findings -> informational only
