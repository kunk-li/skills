---
name: api-error-code-design
description: design or normalize api error-code systems using project-level naming conventions, http status mapping policy, hierarchy, localization requirements, client guidance, and traceability to related apis and compliance findings. use when chatgpt works in technical solution design / api design and must produce the workflow-aligned 错误码清单.csv for n150 after api contract drafting and compliance review but before code generation, test design, or api documentation.
---
# api-error-code-design

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> API设计 -> 错误语义设计」。

它是 **direct_result** 型技能：目标不是简单罗列错误常量，而是形成可供实现、校验、测试与文档复用的 **`错误码清单.csv`** / registry 结构。

### Boundary / 边界
- 负责定义错误码体系、命名规范、HTTP 映射、多语言消息与客户端行为指导。
- 负责把 043 的 error seeds 与 044 的覆盖缺口统一收口成 registry。
- 不替代 043 的接口设计，也不替代 044 的规范 gate。
- 重点是让所有 4xx / 5xx 或协议错误场景拥有稳定、可追踪、可消费的语义标识。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `audit_existing`：现有错误码、异常映射、响应样例已存在时做标准化。
- `hierarchy_refactor`：错误码过于扁平、命名混乱时做层级重构。
- `i18n_batch_translate`：语义体系已稳定，但多语言消息缺失时补齐本地化。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `开发需求解析.md`
- `接口意图清单.csv`
- `技术方案分析.md`

### 节点内优先增强输入
- `接口设计草案.yaml` 或 043 的结构化输出
- `API规范检查单.csv` 或 044 的结构化 findings

### 可选增强输入
- 现有 error constants、response samples、exception mappings、历史 registry、i18n 文件

## Standalone rule / 独立使用规则
即使没有完整 043 / 044 输出，也可以单独使用。

降级规则：
- 若只有 PRD / 技术方案，可先生成 provisional registry。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / normalized / proposed` 错误码。
- 未决的命名、HTTP 映射或 locale 要求必须列入 `open_questions`。

## Core output contract / 核心输出契约
默认输出应以机器友好的 registry / CSV 结构为主，可附短摘要。优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.api_design.error_semantics_design`
  - `node_artifact_target: 错误码清单.csv`
  - `workflow_node: N150`
  - `evidence_profile`
- `error_policy`
- `error_registry[]`
- `coverage_summary`
- `orphan_or_missing_codes[]`
- `exports`
- `open_questions[]`
- `downstream_handoff`
  - `intra_node_dependencies`: `api-design-recommendation`, `api-spec-compliance-check`
  - `workflow_downstream`: `N190`, `N200`, `N240`, `N330`
  - `artifact_name: 错误码清单.csv`
- `self_check`

### Required `error_policy`
至少包含：
- `naming_convention`
- `http_status_mapping_policy`
- `minimum_locales`
- `client_action_enum`
- `compatibility_policy`

### Required per-code fields
每条错误码至少包含：
- `error_code`
- `http_status`
- `domain`
- `category`
- `specific`
- `scenario`
- `messages`
- `params`
- `client_guidance`
- `related_apis`
- `evidence`
- `status`

## Design rules / 设计规则
### Naming convention discipline / 命名纪律
使用项目级模板：
`{DOMAIN}_{CATEGORY}_{SPECIFIC}`
- upper snake case only
- 一个语义场景对应一个 code
- 不得混用 `ERR_*`、`*_ERROR` 与自然语言名

### HTTP mapping discipline / HTTP 映射纪律
- 每个 code 必须映射到且仅映射到一个 HTTP 或协议状态。
- 若项目故意偏离标准映射，必须记录 waiver 与理由。

### Localization discipline / 本地化纪律
- 至少提供两个 locale：项目主语言 + English。
- 消息参数必须显式声明。
- user-facing 与 developer-facing 消息默认不应完全相同。

### Client guidance discipline / 客户端指导纪律
每个 code 必须包含结构化 `client_guidance.action`。
允许的 action：
- `show_to_user`
- `retry_with_backoff`
- `retry_after`
- `refresh_token`
- `fail_fast`
- `fallback_to_cached`
- `alert_support`
- `silent_ignore`

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 读取 043 的 error seeds 与 044 的覆盖缺口。
3. 定义项目级 `error_policy`。
4. 种出候选 code，并统一命名、层级与 HTTP 映射。
5. 补充多语言消息与参数声明。
6. 为每个 code 增加 `client_guidance`。
7. 检查 documented 4xx / 5xx 路径覆盖度，识别 orphan 或 missing code。
8. 形成面向 N150 节点标准产物的 **`错误码清单.csv`** / registry。
9. 输出 `downstream_handoff`，供 N190 / N200 / N240 / N330 使用。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小 feature：覆盖全部显式业务错误与基础设施错误
- 中等服务：覆盖全部用户可见与集成可见失败场景
- 大型平台：重点放在层级质量、重复清理、本地化覆盖与 client guidance 一致性

不要把 registry 做成一次性表格，也不要因为 scope 大就回避 coverage 检查。

## Quality bar / 质量门槛
合格结果应能直接被实现层、测试层、文档层复用，而不需要二次解释错误语义。

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/error-taxonomy.md`
- `references/http-status-mapping.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/output-template.md`
- `references/error-taxonomy.md`
- `references/http-status-mapping.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
