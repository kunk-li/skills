# Output Template: API Error Code Design

## 1. Objective
State selected mode, scope, readiness, and intended consumers.

## 2. Error Policy
Show naming convention, status mapping policy, locale baseline, client action enum, and compatibility policy.

## 3. Registry Summary
| family or domain | count | notable notes |

## 4. Error Registry
For each entry include code, status, scenario, locales, params, client guidance, related APIs, and evidence.

## 5. Coverage Gaps and Orphans
| type | item | impact | required action |

## 6. Export Notes
Describe YAML, JSON, properties, or compatibility aliases when relevant.

## 7. Open Questions
| id | question | affected codes | impact |

## 8. Self-Check
Summarize checklist and scoring results.
