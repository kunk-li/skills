# Example Input / Output

## Example input
A project has codes like `ERR_INVALID_REQUEST`, `TOKEN_EXPIRED_ERROR`, and `PAYMENT_DOWN`, plus undocumented 429 responses.

## Example output sketch
- normalized naming convention: `DOMAIN_CATEGORY_SPECIFIC`
- refactored codes grouped under AUTH, VALIDATION, DEPENDENCY, and RATE_LIMIT
- at least two locales per code
- `RATE_LIMIT_EXCEEDED` mapped to 429 with `retry_after` client guidance
- orphan legacy alias list retained for migration
