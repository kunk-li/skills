# HTTP Status Mapping Guidance

Use this as the default policy.

| HTTP | category guidance | meaning |
|---|---|---|
| 400 | `VALIDATION` | malformed request or bad input |
| 401 | `AUTH` | missing or invalid authentication |
| 403 | `AUTH` | authenticated but forbidden |
| 404 | `RESOURCE` | entity not found |
| 405 | `RESOURCE` or method policy | method not allowed |
| 409 | `CONFLICT` or `STATE` | state conflict or duplicate conflict |
| 410 | `RESOURCE` or state retirement | gone permanently |
| 422 | `VALIDATION` | semantically invalid request |
| 423 | `STATE` | locked resource |
| 429 | `RATE_LIMIT` | request limit exceeded |
| 500 | `INTERNAL` | internal failure |
| 502 | `DEPENDENCY` | upstream failure |
| 503 | `DEPENDENCY` or service availability | service unavailable |
| 504 | `DEPENDENCY` | upstream timeout |

If a project intentionally diverges from this map, record a waiver and rationale.
