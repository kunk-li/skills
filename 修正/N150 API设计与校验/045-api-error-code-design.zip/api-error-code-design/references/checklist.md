# 045 Delivery Checklist

## Policy baseline
- [ ] `error_policy` exists and defines naming, mapping, locales, and client actions
- [ ] every code follows one naming convention
- [ ] every code maps to exactly one status

## Registry completeness
- [ ] every entry has domain, category, specific, scenario, messages, params, and client guidance
- [ ] at least two locales are present unless the caller explicitly narrowed the scope
- [ ] related APIs or source evidence are attached where possible

## Coverage and hygiene
- [ ] duplicate or overlapping codes are identified
- [ ] orphan codes and missing codes are surfaced
- [ ] 4xx and 5xx paths are not missing documented error coverage

## Cross-skill alignment
- [ ] registry aligns with 043 error-case seeds
- [ ] registry responds to 044 error-related findings
- [ ] envelope and client behavior assumptions remain consistent across the project
