# Common Failure Modes for API Error Code Design

## F1: three naming systems in one registry
Fix: define one naming convention and map legacy aliases explicitly.

## F2: status code chosen by habit, not semantics
Fix: apply the mapping policy first, then handle exceptions with waivers.

## F3: one code reused for unrelated scenarios
Fix: split by semantic scenario, not by implementation convenience.

## F4: translated messages added after semantics drifted
Fix: stabilize code meaning before localization.

## F5: no client action guidance
Fix: every code should tell clients whether to retry, refresh, show, ignore, or escalate.

## F6: registry cannot tell which APIs actually use each code
Fix: attach `related_apis` and surface orphans.
