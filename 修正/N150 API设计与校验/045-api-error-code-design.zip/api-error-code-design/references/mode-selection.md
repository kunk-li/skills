# Mode Selection

## Use `audit_existing` when
- you already have error constants or response samples
- you need normalization and cleanup rather than greenfield design
- legacy aliases or duplicated codes must be preserved explicitly

## Use `hierarchy_refactor` when
- the registry is flat or hard to navigate
- category boundaries are unclear
- naming is inconsistent across teams or services

## Use `i18n_batch_translate` when
- semantics and naming are mostly stable
- localization is incomplete
- code identity should not change during the task
