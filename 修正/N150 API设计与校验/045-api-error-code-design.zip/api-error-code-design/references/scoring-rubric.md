# 045 Scoring Rubric

Score each dimension from 1 to 5.

## A. Naming and hierarchy quality
1 = inconsistent flat list, 5 = stable hierarchy and naming convention

## B. Semantic correctness
1 = weak status mapping and overlaps, 5 = clear scenario separation and mapping discipline

## C. Localization and client usability
1 = one-language list with no guidance, 5 = multilingual messages plus structured client actions

## D. Traceability and coverage
1 = codes are isolated from APIs, 5 = registry coverage and orphan analysis are explicit

A strong delivery should average at least 4/5.
