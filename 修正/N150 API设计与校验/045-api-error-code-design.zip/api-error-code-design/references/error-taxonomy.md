# Error Taxonomy

## Naming format
Use:
`{DOMAIN}_{CATEGORY}_{SPECIFIC}`

Examples:
- `ORDER_VALIDATION_MISSING_FIELD`
- `AUTH_TOKEN_EXPIRED`
- `PAYMENT_DEPENDENCY_GATEWAY_DOWN`
- `TICKET_STATE_INVALID_FOR_ACTION`

## Recommended category families
- `VALIDATION`
- `AUTH`
- `RESOURCE`
- `STATE`
- `CONFLICT`
- `DEPENDENCY`
- `RATE_LIMIT`
- `INTERNAL`

## Hierarchy
Every code should decompose into:
- `domain`
- `category`
- `specific`

## Localization
Recommended minimum locales:
- project primary language
- English

## Client action enum
- `show_to_user`
- `retry_with_backoff`
- `retry_after`
- `refresh_token`
- `fail_fast`
- `fallback_to_cached`
- `alert_support`
- `silent_ignore`
