# Orchestration

## Upstream expectations
Best inputs:
- 043 for API error-case seeds, policy, and envelope assumptions
- 044 for missing coverage, inconsistency, and gating findings
- existing registry or implementation constants for migration work

## 043 -> 045 mapping
| upstream field | this skill uses it for |
|---|---|
| `error_case_seeds` | candidate registry entries |
| `api_policy.error_format` | envelope assumptions |
| `contract_metadata.auth` | auth/authz-related categories |
| `api_catalog[].api_id` | `related_apis` linkage |

## 044 -> 045 mapping
| review finding | downstream implication |
|---|---|
| missing error code coverage | add or link codes |
| inconsistent envelope | normalize error structure assumptions |
| auth or rate-limit gap | ensure category coverage |
| undocumented errors | surface missing registry entries |

## Feedback to 043 or 044
- if one API has too many scenario-specific errors, 043 may need to simplify the contract surface
- if error-code waivers conflict with policy, 044 should record them explicitly
