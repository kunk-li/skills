---
name: quality-scoring-engine
description: produce configurable quality scorecards for requirements, engineering, testing, release, governance, and operations artifacts. use when the user needs weighted scoring with evidence, confidence, gate recommendations, or quality trends. supports 15 core dimensions plus extension dimensions, equal/priority/custom weighting, csv validation, and score-to-gate linkage without replacing human approval.
---

# Quality Scoring Engine

Score workflow artifacts with evidence, confidence, and configurable weights. This skill supports governance decisions but does not replace the accountable owner or gate approver.

## Core contract

Default output is `质量评分结果.csv` using exactly this schema:

```csv
scoring_run_id,artifact_ref,dimension_id,dimension_name,dimension_type,score,weight,weighted_score,confidence,evidence_ref,gate_signal,notes
```

Rules:
- `scoring_run_id`: stable run id such as `QS-2026-04-24-01`.
- `artifact_ref`: artifact being scored, e.g. `PRD@v2`, `gate:G-014`, `release:R-2026-04`.
- `dimension_id`: `Q-001` style id.
- `dimension_type`: `core` or `extension`.
- `score`: numeric 0.0-10.0.
- `weight`: numeric > 0. Equal, priority, or custom weighting is allowed.
- `weighted_score`: `score * weight` rounded consistently.
- `confidence`: `high`, `medium`, or `low`.
- `evidence_ref`: source artifact, AU id, gate id, test report, or `待核对`.
- `gate_signal`: `PASS`, `COND_GO`, `FAIL`, or `INFO`.
- `notes`: short rationale and cross-links, using `|` for multi-value data.

## Dimension model

Use 15 core dimensions unless the user supplies a different scoring config. Add extension dimensions only when they are material.

Core dimensions:
1. requirement_completeness
2. requirement_executability
3. scope_control
4. stakeholder_alignment
5. technical_feasibility
6. architecture_consistency
7. api_contract_quality
8. data_model_quality
9. code_quality
10. test_coverage
11. defect_risk
12. release_readiness
13. operational_readiness
14. auditability
15. template_reusability

Common extensions: `security_score`, `privacy_score`, `ux_score`, `performance_score`, `cost_score`, `vendor_sla_score`, `compliance_score`.

## Weighting modes

Choose one weighting mode and state it in the output summary:

- `Equal`: all dimensions have the same weight.
- `Priority`: high-risk or high-priority dimensions get larger weights.
- `Custom`: use user-provided weights. If weights do not sum to 1.0, keep raw weights but report the normalized average in the summary.

## Score to Gate linkage

Default gate advice:

- `score < 6.0` -> `FAIL`
- `6.0 <= score < 7.5` -> `COND_GO`
- `score >= 7.5` -> `PASS`
- `INFO` only for dimensions that are intentionally non-gating.

If any core dimension is `FAIL`, recommend that the related Gate should not be unconditional PASS. If confidence is low, downgrade the certainty of the recommendation and request more evidence rather than overclaiming.

## Workflow

1. Identify artifacts and evidence to score.
2. Choose dimension set: 15 core + needed extensions.
3. Choose weighting mode: Equal, Priority, or Custom.
4. Assign evidence-backed scores, confidence, and notes.
5. Compute weighted score for each row.
6. Derive gate signals from thresholds.
7. Validate with `scripts/validate_csv.py <csv>`.
8. Summarize average score, low-confidence areas, fail/cond-go dimensions, and recommended follow-up.

## Boundaries

- This skill provides scoring and gate advice; it does not approve releases or override Gate/HCN owners.
- If evidence is missing, assign low confidence and use `evidence_ref=待核对`.
- Do not present scores as objective truth; they are structured decision support.
