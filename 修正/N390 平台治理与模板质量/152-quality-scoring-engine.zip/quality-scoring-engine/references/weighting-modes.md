# Weighting Modes

## Equal

Use when no dimension is explicitly more important.

## Priority

Use when project priorities or risk register indicate that some dimensions matter more. Typical high-priority examples: compliance, security, release readiness, auditability.

## Custom

Use when the user provides exact weights. If weights are raw scores rather than normalized percentages, preserve them and normalize only in the summary calculation.

Always state which mode was used.
