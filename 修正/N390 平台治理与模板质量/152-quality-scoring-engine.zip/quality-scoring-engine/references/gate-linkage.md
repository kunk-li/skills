# Score to Gate Linkage

Default row-level mapping:

- `score < 6.0` -> `FAIL`
- `6.0 <= score < 7.5` -> `COND_GO`
- `score >= 7.5` -> `PASS`
- `INFO` -> non-gating context only

Aggregate recommendation:

- Any core `FAIL` -> related Gate should not be unconditional PASS.
- More than 30% `COND_GO` among core dimensions -> recommend Gate `COND_GO` unless owner overrides.
- All core dimensions PASS and average >= 7.5 -> Gate can be recommended PASS if evidence confidence is not low.

Gate recommendation is advisory and should be consumed by `gate-pass-decision` or a human approver.
