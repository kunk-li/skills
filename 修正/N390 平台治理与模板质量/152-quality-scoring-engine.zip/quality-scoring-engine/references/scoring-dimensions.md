# Scoring Dimensions

## Core 15

1. requirement_completeness
2. requirement_executability
3. scope_control
4. stakeholder_alignment
5. technical_feasibility
6. architecture_consistency
7. api_contract_quality
8. data_model_quality
9. code_quality
10. test_coverage
11. defect_risk
12. release_readiness
13. operational_readiness
14. auditability
15. template_reusability

## Extension examples

- security_score
- privacy_score
- ux_score
- performance_score
- cost_score
- vendor_sla_score
- compliance_score

Add extensions only when they change a decision or gate recommendation.
