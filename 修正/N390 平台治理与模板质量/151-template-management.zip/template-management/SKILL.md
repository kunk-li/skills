---
name: template-management
description: catalog, validate, and lifecycle-manage reusable templates for governance workflows. use when the user needs a template library index for prds, review docs, csv schemas, yaml pipelines, audit logs, gate records, hcn forms, scorecards, patterns, runbooks, release artifacts, or postmortems. supports active/dormant/deprecated lifecycle states, metadata validation, adjacent-skill mapping, and migration guidance.
---

# Template Management

Manage reusable templates as governance assets. This skill catalogs templates, tracks versions and lifecycle state, and explains which adjacent skills consume or produce each template.

## Core contract

Default output is `模板库索引.csv` using exactly this schema:

```csv
template_id,title,artifact_type,version,lifecycle_status,frequency,adjacent_skills,deprecation_date,success_criteria,owner,last_reviewed,evidence_ref,notes
```

Rules:
- `template_id`: stable id such as `TPL-001`.
- `artifact_type`: `md`, `csv`, `yaml`, `json`, `xlsx`, `docx`, `pptx`, `code`, `pattern`, `runbook`, or `other`.
- `version`: semantic-ish version such as `v1.0`, `v2.1`, or `1.0.0`.
- `lifecycle_status`: `active`, `dormant`, or `deprecated`.
- `frequency`: `daily`, `weekly`, `sprint`, `monthly`, `release`, `on-change`, `ad-hoc`, or `unknown`.
- `adjacent_skills`: pipe-delimited skill names, e.g. `gate-pass-decision|audit-trail-management`.
- `deprecation_date`: ISO date, empty for non-deprecated templates, required for `deprecated` templates.
- `success_criteria`: how to know this template is still useful. Do not leave blank for active templates.
- `evidence_ref`: source artifact, decision id, AU id, or `待核对`.

## Lifecycle policy

Use the lifecycle rules in `references/lifecycle-policy.md`:

- `active`: used by a current workflow, referenced by downstream skills, or required by governance.
- `dormant`: valid but not used recently; keep for reuse or migration.
- `deprecated`: superseded, unsafe, or no longer compatible; keep only for audit/history.

Never silently delete a template from the index. Mark it `deprecated`, fill `deprecation_date`, and add a migration target in `notes`.

## Workflow

1. Identify template candidates from artifacts, skill outputs, governance docs, or existing libraries.
2. Normalize each candidate into the CSV schema.
3. Map adjacent skills explicitly.
   - Gate / fallback / HCN CSVs are governance templates.
   - Audit ledgers are immutable record templates.
   - Quality scorecards are scoring templates.
   - Best-practice patterns may be registered as `artifact_type=pattern`.
4. Apply lifecycle state using the policy.
5. Validate the CSV with `scripts/validate_csv.py <csv>`.

## Boundaries

- This skill manages templates; it does not replace the domain skill that fills the template.
- It may recommend lifecycle migration, but it does not delete or rewrite published artifacts.
- When source evidence is missing, use `evidence_ref=待核对` and keep the row reviewable.
