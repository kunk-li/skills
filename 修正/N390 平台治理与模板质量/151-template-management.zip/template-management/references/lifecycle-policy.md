# Template Lifecycle Policy

## active

Use when the template is currently recommended, required by a workflow, or actively consumed by at least one skill.

Required:
- `success_criteria` is non-empty.
- `deprecation_date` is empty.

## dormant

Use when the template is valid but not currently recommended or frequently used.

Typical reasons:
- Project phase ended.
- Template is kept for fallback or historical replay.
- Template may become active again in a future release.

## deprecated

Use when the template should not be used for new work.

Required:
- `deprecation_date` is set.
- `notes` should include a migration target when available.
- Keep the row for auditability; do not delete it.
