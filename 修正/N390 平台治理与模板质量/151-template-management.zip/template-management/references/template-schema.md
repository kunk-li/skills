# Template Library Schema

Default artifact: `模板库索引.csv`

Required columns:

```csv
template_id,title,artifact_type,version,lifecycle_status,frequency,adjacent_skills,deprecation_date,success_criteria,owner,last_reviewed,evidence_ref,notes
```

## Field guidance

- Use `|` for multi-value `adjacent_skills`.
- Keep `template_id` stable across versions.
- Track version changes in `version`, not by creating duplicate ids unless the template has materially changed purpose.
- `notes` can hold `replaces=TPL-003|migration_target=TPL-017`.
