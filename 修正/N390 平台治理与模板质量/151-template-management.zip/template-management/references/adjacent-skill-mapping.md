# Adjacent Skill Mapping

Register adjacent skills so downstream users know where a template belongs.

Examples:

- Gate record template: `gate-pass-decision|audit-trail-management|quality-scoring-engine`
- HCN form template: `human-confirmation-node-management|audit-trail-management`
- Fallback runbook template: `fallback-switching|audit-trail-management`
- Project rhythm CSV template: `project-rhythm-tracking|template-management`
- Best-practice pattern template: `best-practice-summary|template-management`

Use pipe separators and avoid bare commas in CSV cells.
