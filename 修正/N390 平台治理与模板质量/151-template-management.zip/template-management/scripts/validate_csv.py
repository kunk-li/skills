#!/usr/bin/env python3
"""Validate template-management CSV files."""

from __future__ import annotations

import argparse
import csv
import re
import sys
from pathlib import Path

EXPECTED = [
    "template_id", "title", "artifact_type", "version", "lifecycle_status", "frequency",
    "adjacent_skills", "deprecation_date", "success_criteria", "owner", "last_reviewed", "evidence_ref", "notes"
]
ID_RE = re.compile(r"^TPL-\d{3,6}$")
STATUS = {"active", "dormant", "deprecated"}
TYPES = {"md", "csv", "yaml", "json", "xlsx", "docx", "pptx", "code", "pattern", "runbook", "other"}
FREQ = {"daily", "weekly", "sprint", "monthly", "release", "on-change", "ad-hoc", "unknown"}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path", type=Path)
    args = parser.parse_args(argv)
    try:
        with args.csv_path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            if reader.fieldnames != EXPECTED:
                raise ValueError(f"header must be exactly {EXPECTED}, got {reader.fieldnames}")
            rows = list(reader)
        if not rows:
            raise ValueError("template index must contain at least one row")
        seen = set()
        for i, row in enumerate(rows, start=2):
            tid = row["template_id"].strip()
            if not ID_RE.match(tid):
                raise ValueError(f"line {i}: template_id must look like TPL-001, got {tid!r}")
            if tid in seen:
                raise ValueError(f"line {i}: duplicate template_id {tid}")
            seen.add(tid)
            for col in ["title", "artifact_type", "version", "lifecycle_status", "frequency", "owner", "last_reviewed", "evidence_ref"]:
                if not row[col].strip():
                    raise ValueError(f"line {i}: {col} must not be empty")
            if row["artifact_type"].strip() not in TYPES:
                raise ValueError(f"line {i}: unsupported artifact_type {row['artifact_type']!r}")
            status = row["lifecycle_status"].strip()
            if status not in STATUS:
                raise ValueError(f"line {i}: lifecycle_status must be one of {sorted(STATUS)}")
            if row["frequency"].strip() not in FREQ:
                raise ValueError(f"line {i}: frequency must be one of {sorted(FREQ)}")
            if "," in row["adjacent_skills"]:
                raise ValueError(f"line {i}: adjacent_skills must use pipe separators, not commas")
            if status == "active":
                if row["deprecation_date"].strip():
                    raise ValueError(f"line {i}: active template cannot have deprecation_date")
                if not row["success_criteria"].strip():
                    raise ValueError(f"line {i}: active template requires success_criteria")
            if status == "deprecated" and not row["deprecation_date"].strip():
                raise ValueError(f"line {i}: deprecated template requires deprecation_date")
    except Exception as exc:
        print(f"INVALID: {exc}", file=sys.stderr)
        return 1
    print(f"VALID template index: {args.csv_path} ({len(rows)} rows)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
