---
name: audit-trail-management
description: generate and validate append-only audit trails for governance workflows. use when the user needs an immutable audit log for decisions, gate outcomes, hcn signoffs, fallback activations, state transitions, template changes, artifact versions, or ai-assisted decisions. supports csv audit ledgers, event-to-audit conversion, snapshot-as-current-state views, and append-only validation against a previous ledger.
---

# Audit Trail Management

Create append-only audit records for governance events. This skill is a governance sink: it records what happened, who/what acted, which artifact version changed, what evidence supports it, whether the action is reversible, and any notes needed for downstream review.

## Core contract

Default output is `审计留痕日志.csv` using exactly this 8-column schema:

```csv
id,timestamp,actor,action,artifact_version,evidence_ref,reversible,notes
```

Column rules:
- `id`: stable audit id such as `AU-001`; never reuse an id for a different event.
- `timestamp`: ISO-8601 date or datetime. Use `待确认` only when the source does not provide a time.
- `actor`: person, role, system, gate, hcn, workflow node, or `待确认`.
- `action`: one concise event description, for example `gate_pass_decision`, `hcn_signed`, `fallback_activated`, `snapshot_created`, `template_deprecated`, `quality_score_updated`.
- `artifact_version`: artifact id plus version, such as `gate:G-012@v1.2`, `hcn:HCN-07@v1`, `snapshot:N370-02@v3`, or `待确认`.
- `evidence_ref`: source reference, event id, meeting/action id, PR, ticket, or `待核对`. Do not leave blank.
- `reversible`: one of `YES`, `NO`, `PARTIAL`, `UNKNOWN`.
- `notes`: short context. Put cross-links here, e.g. `gate_ref=G-012|hcn_ref=HCN-07|score_ref=QS-2026-04-24`.

Use `|` for multi-value notes or references. Do not use bare commas inside a CSV cell unless the CSV writer quotes the field correctly.

## Workflow

1. Identify audit-worthy events from the provided materials.
   - Gate or release decision? Record `gate_pass_decision`.
   - Human confirmation or signoff? Record `hcn_signed` or `hcn_rejected`.
   - Fallback activation or rollback decision? Record `fallback_activated`.
   - State-machine transition? Record `state_transitioned`.
   - Template lifecycle change? Record `template_registered`, `template_updated`, `template_deprecated`.
   - Quality score update that changes gate advice? Record `quality_score_updated`.
2. Preserve append-only semantics.
   - Never edit, delete, renumber, or reorder existing AU rows.
   - If an earlier row was wrong, append a correction row with a new `id` and reference the old id in `notes`.
   - If the user provides a previous ledger, validate that the previous rows remain an exact prefix.
3. Normalize N370/N380/N390 cross-links.
   - Treat a context-memory snapshot as an audit current-state view, not a replacement for the ledger.
   - Convert HCN signoff events into audit rows using `actor=<signer role/person>` and `action=hcn_signed`.
   - Convert Gate decisions into audit rows using `actor=<gate owner/system>` and `action=gate_pass_decision`.
4. Validate output before presenting or saving the CSV.
   - Use `scripts/validate_csv.py <csv>` for one ledger.
   - Use `scripts/validate_csv.py <new.csv> --previous <old.csv>` when checking append-only updates.

## Snapshot view rule

When asked for a snapshot/current-state memo, do not replace the audit log. Produce a snapshot derived from the latest relevant AU rows with these sections: current_state, decisions, blockers, risks, deferred, open_questions, pm_overrides. Keep the AU log as the source of truth.

## Boundaries

- This skill records governance facts and supported decisions; it does not decide whether a Gate should pass.
- This skill can convert N380 Gate/HCN/Fallback events into AU rows, but it does not own Gate criteria or signoff policy.
- If evidence is incomplete, emit the row with `evidence_ref=待核对` and explain the gap.
