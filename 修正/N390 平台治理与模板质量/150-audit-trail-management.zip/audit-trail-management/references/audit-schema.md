# Audit CSV Schema

Default artifact: `审计留痕日志.csv`

Required columns, in exact order:

```csv
id,timestamp,actor,action,artifact_version,evidence_ref,reversible,notes
```

## Allowed values

- `id`: `AU-001`, `AU-002`, ...; use a stable prefix and monotonically increasing number.
- `reversible`: `YES`, `NO`, `PARTIAL`, `UNKNOWN`.
- `timestamp`: ISO date or datetime preferred; use `待确认` only when missing.

## Event naming examples

- `gate_pass_decision`
- `hcn_signed`
- `hcn_rejected`
- `fallback_activated`
- `fallback_rehearsal_skipped`
- `state_transitioned`
- `template_registered`
- `template_deprecated`
- `quality_score_updated`
- `snapshot_created`
- `pm_override_recorded`

## Cross-link convention

Use `notes` for machine-friendly key/value links:

```text
gate_ref=G-012|hcn_ref=HCN-07|fallback_ref=FB-003|score_ref=QS-2026-04-24
```

Keep the fixed 8 columns stable. Add new relationships inside `notes` rather than adding ad-hoc columns.
