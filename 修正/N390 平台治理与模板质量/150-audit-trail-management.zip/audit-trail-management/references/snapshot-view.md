# Snapshot as Audit Current-State View

A snapshot is a view over the audit trail, not a replacement for the audit trail.

Use this 7-section structure when asked to produce a cold-start or handoff snapshot:

1. `state`
2. `decisions`
3. `blockers`
4. `risks`
5. `deferred`
6. `open_questions`
7. `pm_overrides`

Each item should reference one or more AU rows. If no AU row exists yet, append a new AU row before publishing the snapshot.
