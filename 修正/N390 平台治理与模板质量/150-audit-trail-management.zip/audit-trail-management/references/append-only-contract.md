# C10 Append-Only Contract

Append-only means the ledger is immutable after a row is published.

## Rules

1. Never modify an existing row.
2. Never delete an existing row.
3. Never reuse an `id` for another event.
4. Never reorder already-published rows.
5. If a row is wrong, append a correction row with a new `id` and reference the old id in `notes`.
6. When comparing old and new ledgers, the old file must be an exact prefix of the new file.

## Implementation guidance

For a production system, enforce append-only at two layers:

- Storage layer: database trigger, immutable object storage, write-once log, or versioned append file.
- Application layer: guardrail such as `@AppendOnly` / policy middleware that rejects update and delete operations.

## Correction example

```csv
AU-049,2026-04-24T10:00:00+09:00,PM,gate_pass_decision,gate:G-014@v2,G-014-evidence,NO,decision=COND_GO
AU-050,2026-04-24T10:30:00+09:00,PM,audit_correction,audit:AU-049@v1,G-014-correction,NO,corrects=AU-049|field=artifact_version
```
