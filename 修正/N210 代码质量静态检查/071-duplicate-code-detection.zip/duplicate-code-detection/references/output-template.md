# Output template: workflow-aligned duplicate code inventory

Required sections:
1. metadata
2. duplication_summary
3. duplication_clusters[]
4. refactor_candidates[]
5. allowlist_applied[]
6. self_check

Cluster fields:
| duplication_id | severity | detection_algorithm | similarity | locations | min_lines | allowlisted | rationale | recommendation |
|---|---|---|---|---|---|---|---|---|
