# Duplication policy

Default threshold:
- similarity: 0.85
- min_lines: 6
- ignore_imports: true
- ignore_comments: true

Typical allowlist candidates: generated code, mapping stubs, boilerplate test scaffolds, intentionally repeated CRUD wrappers.
