---
name: duplicate-code-detection
description: generate workflow-aligned duplicate-code findings with similarity thresholds, allowlists, and refactor-ready clustering. use when chatgpt works in coding & implementation / code quality static check and must produce the workflow-aligned duplicate code inventory for n210 without misclassifying intentional templates as debt.
---
# duplicate-code-detection

## Role / role positioning
This skill aligns to coding & implementation -> code quality static check -> 重复代码清单.csv. It delivers a workflow-aligned artifact for N210.

### Boundary
- Focus on duplication clusters, not general style issues.
- Distinguish refactor-ready duplication from allowed boilerplate.
- Be explicit about algorithm and threshold choices.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_duplicate_scan`: token-based fast screening.
- `semantic_scan`: higher precision semantic similarity scan.
- `refactor_ready`: only emit clusters worth refactoring.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `工程骨架.zip`
- `Service草稿.java`
- `并发控制建议.md`
- `技术方案分析.md`

### optional enhancement inputs
- generated-code paths
- template directories
- crud allowlists
- shared component policy

## Standalone rule / standalone usage
This skill must still work on a single file, a diff, or a narrow code slice.

Degradation rules:
- If workflow inputs are partial, limit scope to confirmed evidence.
- Mark inferred logic as `assumption` or `pending_context`.
- Do not fabricate runtime proof when only static code is available.
- Keep output shape stable even in constrained mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.duplicate_code_detection`
  - `workflow_node: N210`
  - `node_artifact_target: 重复代码清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `duplication_summary`
- `duplication_clusters[]`
- `allowlist_applied[]`
- `refactor_candidates[]`
- `shared_component_hints[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Declare detection_algorithm and duplication_threshold.
- Ignore imports and comments by default.
- Use an allowlist for generated or template-heavy code.
- Explain whether the duplicate cluster should become a method, component, base class, or remain duplicated.

Also enforce these N210-wide rules:
- Use the unified severity matrix from `references/severity-matrix.md`.
- Add business traceability when evidence exists.
- State how the finding complements mature tools rather than cloning them.

## Execution workflow / execution workflow
1. Screen for clone candidates using the selected algorithm.
2. Apply thresholds and allowlists before judging debt.
3. Group confirmed clusters and calculate shared similarity.
4. Promote only refactor-ready groups into explicit candidates.
5. Link duplicate groups to shared-component or refactoring follow-up.

## Dynamic completeness / dynamic completeness
- Small input: emit only confirmed findings, but keep the same output fields.
- Medium input: add traceability, severity normalization, and grouped recommendations.
- Large review scope: merge repeated findings, prefer representative evidence, and keep the artifact directly consumable by N220 and N260.

## Quality bar / quality bar
A good result should let downstream reviewers or gate owners act immediately without first normalizing severity, translating tool noise, or guessing whether the issue matters to the workflow.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/readiness-inheritance.md`
- `references/n210-integration-map.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/duplication-policy.md`
