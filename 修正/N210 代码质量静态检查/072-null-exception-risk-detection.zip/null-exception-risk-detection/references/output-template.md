# Output template: shared risk bundle contribution

Artifact target: 风险检查清单.csv

Required sections:
1. metadata
2. risk_summary
3. risk_catalog[]
4. null_source_trace[]
5. annotation_gaps[]
6. optional_misuse_cases[]
7. self_check

Risk fields:
| risk_id | severity | risk_family | issue_kind | location | null_source | evidence | recommendation | linked_rules | linked_nfr | source_skill |
|---|---|---|---|---|---|---|---|---|---|---|
