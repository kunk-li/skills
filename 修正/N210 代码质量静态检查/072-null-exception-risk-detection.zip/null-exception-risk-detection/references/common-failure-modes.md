# Common Failure Modes

## 通用
- F1: 把推断包装成确定事实
- F2: 没有位置或范围仍给强结论
- F3: 同类问题机械穷举导致输出失焦
- F4: 只说问题不说原因或建议

## 本 skill 重点
- F5: 把所有 null 都当高危 crash
- F6: 忽略 Optional / @Nullable 既有约定
- F7: 把待验证方式写成已复现结论
