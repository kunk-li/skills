# Null and Optional policy

- use Optional only for return values
- avoid Optional as fields
- avoid Optional.get without guard
- avoid orElse(null)
- add explicit nullable or nonnull annotations where the project supports them
