---
name: null-exception-risk-detection
description: generate workflow-aligned null and exception risk findings from code drafts, optional usage, annotations, and entry-point validation gaps. use when chatgpt works in coding & implementation / code quality static check and must contribute null and exception risks into the shared risk checklist for n210.
---
# null-exception-risk-detection

## Role / role positioning
This skill aligns to coding & implementation -> code quality static check -> 风险检查清单.csv. It delivers a workflow-aligned artifact for N210.

### Boundary
- Focus on null sources, unsafe dereferences, Optional misuse, and exception-handling gaps.
- Prefer annotation-aware and source-trace reasoning over generic IDE duplication.
- Emit rows compatible with the shared N210 risk bundle contract.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `annotation_wire`: focus on nullable or nonnull annotation gaps.
- `optional_mode`: focus on Optional misuse patterns.
- `source_trace`: trace each risk back to likely null origin.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `工程骨架.zip`
- `Service草稿.java`
- `并发控制建议.md`
- `技术方案分析.md`

### optional enhancement inputs
- bean validation rules
- exception hierarchy
- annotation standards
- api nullability hints

## Standalone rule / standalone usage
This skill must still work on a single file, a diff, or a narrow code slice.

Degradation rules:
- If workflow inputs are partial, limit scope to confirmed evidence.
- Mark inferred logic as `assumption` or `pending_context`.
- Do not fabricate runtime proof when only static code is available.
- Keep output shape stable even in constrained mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.null_exception_risk_detection`
  - `workflow_node: N210`
  - `node_artifact_target: 风险检查清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `risk_summary`
- `risk_catalog[]`
- `null_source_trace[]`
- `annotation_gaps[]`
- `optional_misuse_cases[]`
- `risk_handoff_bundle`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Assume non-null by default only when the project convention says so.
- Flag unsafe Optional.get, orElse(null), and nullable dereference chains.
- Trace each risk back to a likely source such as input, db lookup, deserialization, or external api.
- Keep output rows compatible with the shared risk artifact.

Also enforce these N210-wide rules:
- Use the unified severity matrix from `references/severity-matrix.md`.
- Add business traceability when evidence exists.
- State how the finding complements mature tools rather than cloning them.

## Execution workflow / execution workflow
1. Map likely null origins from entry points, lookups, and external calls.
2. Check annotation gaps and nullable misuse.
3. Scan Optional patterns and exception-handling fallthrough.
4. Emit risk rows using the shared risk contract.
5. Provide preventive fixes at the source, not just at the crash point.

## Dynamic completeness / dynamic completeness
- Small input: emit only confirmed findings, but keep the same output fields.
- Medium input: add traceability, severity normalization, and grouped recommendations.
- Large review scope: merge repeated findings, prefer representative evidence, and keep the artifact directly consumable by N220 and N260.

## Quality bar / quality bar
A good result should let downstream reviewers or gate owners act immediately without first normalizing severity, translating tool noise, or guessing whether the issue matters to the workflow.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/readiness-inheritance.md`
- `references/n210-integration-map.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/null-optional-policy.md`
- `references/risk-bundle-contract.md`
