---
name: thread-safety-risk-check
description: generate workflow-aligned thread-safety findings for shared mutable state, bean lifecycle hazards, threadlocal leaks, and lock-order risks. use when chatgpt works in coding & implementation / code quality static check and must contribute thread-safety risks into the shared risk checklist for n210.
---
# thread-safety-risk-check

## Role / role positioning
This skill aligns to coding & implementation -> code quality static check -> 风险检查清单.csv. It delivers a workflow-aligned artifact for N210.

### Boundary
- Focus on singleton bean state, threadlocal lifecycle, non-thread-safe collections, unsafe lazy init, and lock ordering.
- Avoid spending most of the output on generic library warnings already handled by baseline tools.
- Emit rows compatible with the shared N210 risk bundle contract.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `bean_state_only`: focus on singleton bean mutable state.
- `threadlocal_lifecycle`: focus on threadlocal or mdc cleanup.
- `lock_order`: focus on lock ordering and deadlock risk.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `工程骨架.zip`
- `Service草稿.java`
- `并发控制建议.md`
- `技术方案分析.md`

### optional enhancement inputs
- concurrency design
- bean scopes
- cache usage
- async execution model

## Standalone rule / standalone usage
This skill must still work on a single file, a diff, or a narrow code slice.

Degradation rules:
- If workflow inputs are partial, limit scope to confirmed evidence.
- Mark inferred logic as `assumption` or `pending_context`.
- Do not fabricate runtime proof when only static code is available.
- Keep output shape stable even in constrained mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.thread_safety_risk_check`
  - `workflow_node: N210`
  - `node_artifact_target: 风险检查清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `risk_summary`
- `thread_safety_risks[]`
- `bean_state_findings[]`
- `threadlocal_findings[]`
- `lock_graph_findings[]`
- `risk_handoff_bundle`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Treat mutable singleton bean fields as a primary risk source.
- Check ThreadLocal and MDC cleanup paths.
- Flag unsafe collection choices in shared concurrent contexts.
- Treat lock ordering and double-checked locking correctness as explicit checks.

Also enforce these N210-wide rules:
- Use the unified severity matrix from `references/severity-matrix.md`.
- Add business traceability when evidence exists.
- State how the finding complements mature tools rather than cloning them.

## Execution workflow / execution workflow
1. Inspect shared mutable state and bean scope assumptions.
2. Check threadlocal lifecycle and async contamination risk.
3. Check collection and lazy initialization choices.
4. Check lock ordering and deadlock potential.
5. Emit unified risk rows and concrete concurrency-safe alternatives.

## Dynamic completeness / dynamic completeness
- Small input: emit only confirmed findings, but keep the same output fields.
- Medium input: add traceability, severity normalization, and grouped recommendations.
- Large review scope: merge repeated findings, prefer representative evidence, and keep the artifact directly consumable by N220 and N260.

## Quality bar / quality bar
A good result should let downstream reviewers or gate owners act immediately without first normalizing severity, translating tool noise, or guessing whether the issue matters to the workflow.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/readiness-inheritance.md`
- `references/n210-integration-map.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/thread-safety-catalog.md`
- `references/risk-bundle-contract.md`
