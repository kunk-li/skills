# Thread-safety catalog

- mutable singleton bean state
- ThreadLocal set without remove
- MDC contamination
- non-thread-safe collections in shared state
- unsafe double-checked locking
- inconsistent lock ordering
