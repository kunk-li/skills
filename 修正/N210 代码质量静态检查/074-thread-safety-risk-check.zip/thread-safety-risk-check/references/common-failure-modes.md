# Common Failure Modes

## 通用
- F1: 把推断包装成确定事实
- F2: 没有位置或范围仍给强结论
- F3: 同类问题机械穷举导致输出失焦
- F4: 只说问题不说原因或建议

## 本 skill 重点
- F5: 看到 shared state 就武断给 critical
- F6: 忽略已有锁、CAS 或并发容器
- F7: 只说“可能有问题”不给控制建议
