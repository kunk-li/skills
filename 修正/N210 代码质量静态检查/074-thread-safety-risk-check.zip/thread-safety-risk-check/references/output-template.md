# Output template: shared thread-safety risk contribution

Artifact target: 风险检查清单.csv

Required sections:
1. metadata
2. risk_summary
3. thread_safety_risks[]
4. bean_state_findings[]
5. threadlocal_findings[]
6. lock_graph_findings[]
7. self_check

Risk fields:
| risk_id | severity | risk_family | issue_kind | location | evidence | recommendation | linked_rules | linked_nfr | source_skill |
|---|---|---|---|---|---|---|---|---|---|
