---
name: naming-optimization-recommendation
description: generate workflow-aligned naming improvements for classes, methods, variables, fields, constants, and package terms. use when chatgpt works in coding & implementation / code quality static check and must produce the workflow-aligned naming optimization report for n210 while binding code names to glossary terms and team naming policy.
---
# naming-optimization-recommendation

## Role / role positioning
This skill aligns to coding & implementation -> code quality static check -> 命名优化建议.md. It delivers a workflow-aligned artifact for N210.

### Boundary
- Focus on naming clarity, semantic conflicts, glossary binding, and rename safety.
- Do not act like a formatter or linter clone.
- Do not bulk-rename blindly without caller or search scope hints.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `dictionary_mode`: maintain and extend the naming dictionary.
- `conflict_scan`: focus on same-name-different-meaning and different-name-same-meaning conflicts.
- `bulk_rename`: prepare grouped rename suggestions with replacement scopes.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `工程骨架.zip`
- `Service草稿.java`
- `并发控制建议.md`
- `技术方案分析.md`

### optional enhancement inputs
- domain glossary
- api contract names
- database naming policy
- existing abbreviation dictionary

## Standalone rule / standalone usage
This skill must still work on a single file, a diff, or a narrow code slice.

Degradation rules:
- If workflow inputs are partial, limit scope to confirmed evidence.
- Mark inferred logic as `assumption` or `pending_context`.
- Do not fabricate runtime proof when only static code is available.
- Keep output shape stable even in constrained mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.naming_optimization_recommendation`
  - `workflow_node: N210`
  - `node_artifact_target: 命名优化建议.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `naming_policy_summary`
- `glossary_binding`
- `abbreviation_dict_delta`
- `naming_issues[]`
- `semantic_conflicts[]`
- `rename_batches[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Use explicit naming conventions for method verbs and boolean prefixes.
- Bind business terms to the approved glossary when one exists.
- Treat uncontrolled abbreviations as a policy issue, not just a stylistic nit.
- Prefer rename batches over isolated rename trivia.

Also enforce these N210-wide rules:
- Use the unified severity matrix from `references/severity-matrix.md`.
- Add business traceability when evidence exists.
- State how the finding complements mature tools rather than cloning them.

## Execution workflow / execution workflow
1. Identify naming hotspots and group them by concept.
2. Bind confirmed business concepts to glossary terms.
3. Flag semantic conflicts and ambiguous abbreviations.
4. Propose rename batches with search scope and replacement hints.
5. Separate policy-level issues from one-off cosmetic issues.

## Dynamic completeness / dynamic completeness
- Small input: emit only confirmed findings, but keep the same output fields.
- Medium input: add traceability, severity normalization, and grouped recommendations.
- Large review scope: merge repeated findings, prefer representative evidence, and keep the artifact directly consumable by N220 and N260.

## Quality bar / quality bar
A good result should let downstream reviewers or gate owners act immediately without first normalizing severity, translating tool noise, or guessing whether the issue matters to the workflow.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/readiness-inheritance.md`
- `references/n210-integration-map.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/naming-dictionary-policy.md`
