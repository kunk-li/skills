# Naming dictionary policy

- variables and fields: camelCase
- constants: UPPER_SNAKE_CASE
- classes: PascalCase nouns
- boolean names: is / has / can / should
- methods: verb-first
- find may return empty; fetch should return value or fail
