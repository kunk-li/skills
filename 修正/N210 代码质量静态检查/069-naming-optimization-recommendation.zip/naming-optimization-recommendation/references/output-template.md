# Output template: workflow-aligned naming optimization report

Required sections:
1. metadata
2. naming_policy_summary
3. naming_issues[]
4. semantic_conflicts[]
5. rename_batches[]
6. self_check

Issue fields:
| naming_id | severity | symbol_kind | current_name | suggested_name | location | issue_type | glossary_term | evidence | rename_scope | recommendation |
|---|---|---|---|---|---|---|---|---|---|---|
