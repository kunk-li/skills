---
name: low-quality-code-detection
description: generate workflow-aligned low-quality code findings that complement sonar-class tooling with business-aware and project-specific checks. use when chatgpt works in coding & implementation / code quality static check and must produce the workflow-aligned low-quality code issue list for n210 instead of repeating generic static-analysis signals.
---
# low-quality-code-detection

## Role / role positioning
This skill aligns to coding & implementation -> code quality static check -> 低质量代码清单.csv. It delivers a workflow-aligned artifact for N210.

### Boundary
- Focus on low-quality code findings that are not already fully explained by standard tools.
- Use issue kinds: bug, code_smell, vulnerability, hotspot.
- Provide metric evidence instead of vague quality complaints.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `biz_specific`: business-rule-aware custom checks only.
- `metrics_only`: emit quantified maintainability metrics.
- `threshold_check`: alert only on configured thresholds.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `工程骨架.zip`
- `Service草稿.java`
- `并发控制建议.md`
- `技术方案分析.md`

### optional enhancement inputs
- business rule catalog
- project-specific policies
- sonarqube or ide findings
- nfr ids

## Standalone rule / standalone usage
This skill must still work on a single file, a diff, or a narrow code slice.

Degradation rules:
- If workflow inputs are partial, limit scope to confirmed evidence.
- Mark inferred logic as `assumption` or `pending_context`.
- Do not fabricate runtime proof when only static code is available.
- Keep output shape stable even in constrained mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.low_quality_code_detection`
  - `workflow_node: N210`
  - `node_artifact_target: 低质量代码清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `issue_summary`
- `issue_catalog[]`
- `issue_kind_distribution`
- `metric_snapshots[]`
- `business_rule_links[]`
- `sonar_overlap_filter`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- State how the finding differs from a generic tool signal.
- Always classify findings into bug, code_smell, vulnerability, or hotspot.
- Include metric evidence such as loc, complexity, nesting, coupling, or cohesion.
- Prefer project-specific and business-context signals over repeated baseline rules.

Also enforce these N210-wide rules:
- Use the unified severity matrix from `references/severity-matrix.md`.
- Add business traceability when evidence exists.
- State how the finding complements mature tools rather than cloning them.

## Execution workflow / execution workflow
1. Filter out commodity signals already handled well by standard tools.
2. Measure maintainability and structural metrics for confirmed code regions.
3. Attach business-rule or project-policy context where available.
4. Classify findings by issue kind and unified severity.
5. Emit a compact issue list that can feed review and gate decisions.

## Dynamic completeness / dynamic completeness
- Small input: emit only confirmed findings, but keep the same output fields.
- Medium input: add traceability, severity normalization, and grouped recommendations.
- Large review scope: merge repeated findings, prefer representative evidence, and keep the artifact directly consumable by N220 and N260.

## Quality bar / quality bar
A good result should let downstream reviewers or gate owners act immediately without first normalizing severity, translating tool noise, or guessing whether the issue matters to the workflow.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/readiness-inheritance.md`
- `references/n210-integration-map.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/detector-boundary.md`
