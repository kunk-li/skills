# Detector boundary

This skill should be strongest where mature tools are weakest: business-rule-aware checks, project policy checks, workflow gate reasoning, plain-language explanations, and traceability.
