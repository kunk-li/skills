# Common Failure Modes

## 通用
- F1: 把推断包装成确定事实
- F2: 没有位置或范围仍给强结论
- F3: 同类问题机械穷举导致输出失焦
- F4: 只说问题不说原因或建议

## 本 skill 重点
- F5: 把个人编码偏好当作质量缺陷
- F6: 只有现象没有 reasoning
- F7: severity 不分层
