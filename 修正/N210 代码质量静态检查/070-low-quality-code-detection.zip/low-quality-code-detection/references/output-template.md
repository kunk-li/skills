# Output template: workflow-aligned low-quality code issue list

Required sections:
1. metadata
2. issue_summary
3. issue_catalog[]
4. metric_snapshots[]
5. sonar_overlap_filter
6. self_check

Issue fields:
| issue_id | severity | issue_kind | location | metric_evidence | business_context | recommendation | source_skill |
|---|---|---|---|---|---|---|---|
