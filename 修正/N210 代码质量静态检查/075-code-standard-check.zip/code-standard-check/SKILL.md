---
name: code-standard-check
description: generate workflow-aligned project and organization code-standard findings from project rules, framework policy, and team conventions. use when chatgpt works in coding & implementation / code quality static check and must produce the workflow-aligned code-standard checklist for n210 while leaving commodity language formatting to dedicated tools.
---
# code-standard-check

## Role / role positioning
This skill aligns to coding & implementation -> code quality static check -> 代码规范检查单.csv. It delivers a workflow-aligned artifact for N210.

### Boundary
- Focus on organization-standard and project-standard rules.
- Treat language-formatting rules as baseline tool territory unless the workflow adds context.
- Provide a rule tier and version-aware explanation for every violation.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `project_specific`: run project-standard rules only.
- `migration_mode`: evaluate impact before enabling a new rule.
- `violation_stats`: summarize violation counts and trends.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `工程骨架.zip`
- `Service草稿.java`
- `并发控制建议.md`
- `技术方案分析.md`

### optional enhancement inputs
- team rule yaml
- checkstyle or spotless config
- swagger policy
- custom annotations and base classes

## Standalone rule / standalone usage
This skill must still work on a single file, a diff, or a narrow code slice.

Degradation rules:
- If workflow inputs are partial, limit scope to confirmed evidence.
- Mark inferred logic as `assumption` or `pending_context`.
- Do not fabricate runtime proof when only static code is available.
- Keep output shape stable even in constrained mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.code_standard_check`
  - `workflow_node: N210`
  - `node_artifact_target: 代码规范检查单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `rule_tier_summary`
- `violations[]`
- `custom_rule_hits[]`
- `violation_stats`
- `severity_matrix`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Use rule tiers: language_standard, organization_standard, project_standard.
- Center this skill on T2 and T3 rules.
- Support declarative custom rule descriptions and versioned enforcement.
- Attach unified severity and traceability to every violation.

Also enforce these N210-wide rules:
- Use the unified severity matrix from `references/severity-matrix.md`.
- Add business traceability when evidence exists.
- State how the finding complements mature tools rather than cloning them.

## Execution workflow / execution workflow
1. Load team and project rules, then separate commodity tool territory from workflow-specific rules.
2. Evaluate violations against tier, version, and grace-period policy.
3. Emit stable machine-readable violation rows.
4. Summarize custom-rule hits and trend implications.
5. Hand off the checklist to review, gate, and governance consumers.

## Dynamic completeness / dynamic completeness
- Small input: emit only confirmed findings, but keep the same output fields.
- Medium input: add traceability, severity normalization, and grouped recommendations.
- Large review scope: merge repeated findings, prefer representative evidence, and keep the artifact directly consumable by N220 and N260.

## Quality bar / quality bar
A good result should let downstream reviewers or gate owners act immediately without first normalizing severity, translating tool noise, or guessing whether the issue matters to the workflow.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/readiness-inheritance.md`
- `references/n210-integration-map.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/rule-tier-policy.md`
