# Common Failure Modes

## 通用
- F1: 把推断包装成确定事实
- F2: 没有位置或范围仍给强结论
- F3: 同类问题机械穷举导致输出失焦
- F4: 只说问题不说原因或建议

## 本 skill 重点
- F5: 缺少 fallback，输入不足时仍下强结论
- F6: 没有 Inputs 段和相邻技能边界
- F7: 把 review-rules 当死规则，不承认团队差异
