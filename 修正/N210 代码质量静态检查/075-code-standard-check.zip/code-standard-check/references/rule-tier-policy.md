# Rule tier policy

- T1 language_standard: baseline tool territory
- T2 organization_standard: shared multi-project rules
- T3 project_standard: rules specific to this codebase or workflow
