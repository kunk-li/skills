# Output template: workflow-aligned code standard checklist

Artifact target: 代码规范检查单.csv

Required sections:
1. metadata
2. rule_tier_summary
3. violations[]
4. custom_rule_hits[]
5. violation_stats
6. self_check

Violation fields:
| check_id | severity | rule_tier | rule_id | location | evidence | recommendation | linked_rules | linked_nfr | source_skill |
|---|---|---|---|---|---|---|---|---|---|
