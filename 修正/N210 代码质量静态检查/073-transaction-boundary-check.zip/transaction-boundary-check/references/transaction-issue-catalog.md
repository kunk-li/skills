# Transaction issue catalog

- TX01 missing_annotation
- TX02 wrong_propagation
- TX03 nested_rollback_issue
- TX04 self_invocation
- TX05 external_call_in_txn
- TX06 oversized_transaction
- TX07 missing_after_commit
