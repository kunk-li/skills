# Output template: shared transaction risk contribution

Artifact target: 风险检查清单.csv

Required sections:
1. metadata
2. risk_summary
3. transaction_issue_catalog[]
4. propagation_findings[]
5. after_commit_findings[]
6. large_transaction_findings[]
7. self_check

Risk fields:
| risk_id | severity | risk_family | transaction_issue_kind | location | evidence | recommendation | linked_rules | linked_nfr | source_skill |
|---|---|---|---|---|---|---|---|---|---|
