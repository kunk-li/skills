---
name: transaction-boundary-check
description: generate workflow-aligned transaction-boundary findings from service logic, propagation intent, event publication, and consistency-sensitive code paths. use when chatgpt works in coding & implementation / code quality static check and must contribute transaction risks into the shared risk checklist for n210.
---
# transaction-boundary-check

## Role / role positioning
This skill aligns to coding & implementation -> code quality static check -> 风险检查清单.csv. It delivers a workflow-aligned artifact for N210.

### Boundary
- Focus on transaction scope, propagation, rollback semantics, after-commit behavior, and oversized transaction risks.
- Do not pretend every method annotation can be proven statically; mark assumptions when framework details are missing.
- Emit rows compatible with the shared N210 risk bundle contract.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `propagation_only`: focus on propagation mismatches.
- `event_commit_check`: focus on after-commit or outbox problems.
- `txn_size_estimate`: focus on oversized or blocking transactions.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `工程骨架.zip`
- `Service草稿.java`
- `并发控制建议.md`
- `技术方案分析.md`

### optional enhancement inputs
- idempotency design
- audit design
- event publishing code
- service methods with transactional annotations

## Standalone rule / standalone usage
This skill must still work on a single file, a diff, or a narrow code slice.

Degradation rules:
- If workflow inputs are partial, limit scope to confirmed evidence.
- Mark inferred logic as `assumption` or `pending_context`.
- Do not fabricate runtime proof when only static code is available.
- Keep output shape stable even in constrained mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.transaction_boundary_check`
  - `workflow_node: N210`
  - `node_artifact_target: 风险检查清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `risk_summary`
- `transaction_issue_catalog[]`
- `propagation_findings[]`
- `after_commit_findings[]`
- `large_transaction_findings[]`
- `risk_handoff_bundle`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Classify findings using transaction_issue_kind.
- Differentiate missing annotations, wrong propagation, self invocation, external call in transaction, oversized transaction, and missing after-commit handling.
- Prefer precise propagation guidance over blanket annotation advice.
- Treat event publication consistency as a first-class check.

Also enforce these N210-wide rules:
- Use the unified severity matrix from `references/severity-matrix.md`.
- Add business traceability when evidence exists.
- State how the finding complements mature tools rather than cloning them.

## Execution workflow / execution workflow
1. Identify operations that need atomicity and those that are external side effects.
2. Check propagation and rollback intent.
3. Check self-invocation and nested transaction pitfalls.
4. Check after-commit or outbox requirements for published events.
5. Estimate large transaction and blocking risks, then emit shared risk rows.

## Dynamic completeness / dynamic completeness
- Small input: emit only confirmed findings, but keep the same output fields.
- Medium input: add traceability, severity normalization, and grouped recommendations.
- Large review scope: merge repeated findings, prefer representative evidence, and keep the artifact directly consumable by N220 and N260.

## Quality bar / quality bar
A good result should let downstream reviewers or gate owners act immediately without first normalizing severity, translating tool noise, or guessing whether the issue matters to the workflow.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/readiness-inheritance.md`
- `references/n210-integration-map.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/transaction-issue-catalog.md`
- `references/risk-bundle-contract.md`
