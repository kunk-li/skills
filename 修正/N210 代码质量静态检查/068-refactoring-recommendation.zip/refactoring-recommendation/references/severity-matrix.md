# Unified severity matrix

- blocker: must fix before merge or release
- critical: fix in the current sprint
- major: fix soon
- minor: acceptable short-term debt
- info: guidance only

Never invent a skill-local severity ladder.
