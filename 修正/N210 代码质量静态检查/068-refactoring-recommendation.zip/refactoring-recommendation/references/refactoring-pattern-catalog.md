# Refactoring pattern catalog

Use these labels:
- R01 extract_method
- R02 extract_class
- R03 inline_method
- R04 move_method
- R05 rename
- R06 replace_conditional_with_polymorphism
- R07 introduce_parameter_object
- R08 replace_temp_with_query
- R09 decompose_conditional
- R10 encapsulate_field
- R11 replace_magic_number
- R12 extract_interface
- R13 collapse_hierarchy
