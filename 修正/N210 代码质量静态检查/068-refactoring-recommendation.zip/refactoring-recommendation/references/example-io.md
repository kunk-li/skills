# Example IO

## Example 1
### Input
- 代码片段或 diff
- 模块背景
- 用户要求输出结构化问题清单

### Output shape
- machine-readable 清单或受控长度的 markdown 报告
- 每条记录至少含位置、问题、原因/依据、建议、优先级

## Example 2
### Input
- 只有部分文件或部分方法
- 缺团队规范细节

### Output shape
- 显式标记“待确认”或“基于通用规范推断”
- 只在 Confirmed 范围内下结论

## Skill-specific note
- 输出受控长度的 markdown 报告，P0/P1 详细项不过长。
