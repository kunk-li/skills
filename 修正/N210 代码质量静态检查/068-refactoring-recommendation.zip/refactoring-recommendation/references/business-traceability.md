# Business traceability

When evidence exists, link findings to business rule ids, decision ids, nfr ids, api ids, or module ids.
Use explicit arrays such as linked_rules[], linked_decisions[], and linked_nfr[].
If business context is missing, say so instead of fabricating traceability.
