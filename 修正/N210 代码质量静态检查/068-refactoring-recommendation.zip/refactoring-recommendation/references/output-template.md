# Output template: workflow-aligned refactoring report

Required sections:
1. metadata
2. refactoring_summary
3. refactoring_candidates[]
4. before_after_previews[]
5. refactoring_impact[]
6. implementation_sequence[]
7. self_check

Candidate fields:
| refactoring_id | severity | refactoring_pattern | location | evidence | business_value | files_affected | callers_affected | tests_affected | estimated_effort_hours | risk | recommendation |
|---|---|---|---|---|---|---|---|---|---|---|---|
