# N210 跨 Skill 协同地图

## 两组技能

### Group A: 诊断 / 建议类
- 068 refactoring recommendation
- 069 naming optimization recommendation
- 070 low quality code detection
- 071 duplicate code detection
- 072 null exception risk detection
- 073 transaction boundary check
- 074 thread safety risk check

### Group B: 规范对标类
- 075 code standard check

## 产物关系

| 来源 skill | 产物 | 典型下游 |
|---|---|---|
| 070 | 低质量问题清单 | 068 生成重构方向 |
| 071 | 重复代码组清单 | 068 决定 extract-method / 模板抽象 |
| 072 | NPE/异常风险清单 | 068 给 null-safety 重构建议 |
| 073 | 事务风险清单 | 068 给事务边界重构建议 |
| 074 | 并发风险清单 | 068 给线程安全重构建议 |
| 075 | 规范 fail 清单 | 069 给命名建议；070-074 给深扫入口 |
| 069 | 命名建议清单 | 可回写到 075 的命名类规则 |

## 字段级映射
- 068 的 `source_id` 可引用 070-075 的 issue_id / check_id / risk_id
- 069 的 `rule_source` 可引用 075 的 check_id
- 072/073/074 合并输出时，统一字段 `risk_id`,`category`,`severity`,`file_location`,`description`,`recommendation`

## 推荐执行顺序
1. Phase 1: 070 / 071 / 072 / 073 / 074 / 075 并行扫描
2. Phase 2: 068 / 069 基于扫描结果生成建议

## 共享产物模式（072 / 073 / 074）
- 模式 A: 独立输出，各自 CSV，id 前缀分别为 `NPE-`,`TX-`,`TS-`
- 模式 B: 合并输出，默认推荐，统一到“风险检查清单.csv”
- 模式 C: 合并 CSV + 简短 markdown 总览，用于汇报场景

