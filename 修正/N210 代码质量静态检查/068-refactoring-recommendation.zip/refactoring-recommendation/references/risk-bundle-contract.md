# Risk bundle contract

Shared risk artifact: 风险检查清单.csv

Stable fields:
- risk_id
- severity
- risk_family
- issue_kind
- location
- evidence
- recommendation
- linked_rules
- linked_nfr
- source_skill
