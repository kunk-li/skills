# Readiness Inheritance

## 继承规则
- pass: 已有完整代码范围或完整扫描对象，可输出完整清单或完整报告
- constrained: 只有部分模块、部分 diff 或部分文件时，只输出 Confirmed 范围内结果，并把未覆盖范围标为“待扫描”
- blocked: 输入严重不足时，仅输出 smoke-level 观察项、最核心风险或待补充输入清单

## Single-source-of-truth rule
- 不上调 readiness
- 不声称“已验证通过”“已压测完成”或“已在线上复现”
- 不把推断包装成确定事实

## Gate-aware mode
- 若上游已有 gate、review 结论或准入门槛，本 skill 只继承、不重写标准
- constrained 情况下，必须区分 Confirmed 与 Blocked 范围
