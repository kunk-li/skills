---
name: refactoring-recommendation
description: generate workflow-aligned refactoring recommendations from code materials, business rules, and static findings. use when chatgpt works in coding & implementation / code quality static check and must produce the workflow-aligned refactoring report for n210 after scaffold and helper-code generation and before code review or gate aggregation.
---
# refactoring-recommendation

## Role / role positioning
This skill aligns to coding & implementation -> code quality static check -> 重构建议.md. It delivers a workflow-aligned artifact for N210.

### Boundary
- Focus on refactoring opportunities, not generic review comments.
- Always name the refactoring pattern and show a compact before/after direction.
- Do not pretend to rewrite the whole module into final production code.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_scan`: top refactoring opportunities.
- `pattern_specific`: scan for one Fowler-style pattern.
- `what_if`: simulate impact and caller spread before refactoring.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `工程骨架.zip`
- `Service草稿.java`
- `并发控制建议.md`
- `技术方案分析.md`

### optional enhancement inputs
- existing issue lists
- module boundary notes
- business rule ids
- team refactoring constraints

## Standalone rule / standalone usage
This skill must still work on a single file, a diff, or a narrow code slice.

Degradation rules:
- If workflow inputs are partial, limit scope to confirmed evidence.
- Mark inferred logic as `assumption` or `pending_context`.
- Do not fabricate runtime proof when only static code is available.
- Keep output shape stable even in constrained mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.refactoring_recommendation`
  - `workflow_node: N210`
  - `node_artifact_target: 重构建议.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `refactoring_summary`
- `refactoring_candidates[]`
- `before_after_previews[]`
- `refactoring_impact[]`
- `business_value_map[]`
- `implementation_sequence[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Use one of the named refactoring patterns for every candidate.
- Estimate affected files, callers, tests, and migration risk.
- Show a compact before/after preview for blocker and critical findings.
- Map each meaningful refactoring to business value or debt reduction.

Also enforce these N210-wide rules:
- Use the unified severity matrix from `references/severity-matrix.md`.
- Add business traceability when evidence exists.
- State how the finding complements mature tools rather than cloning them.

## Execution workflow / execution workflow
1. Identify structural pain points and their confirmed evidence.
2. Map each candidate to a Fowler-style pattern.
3. Estimate impact, risk, and rollback approach.
4. Add before/after previews for the highest priority items.
5. Sequence the candidates so downstream teams know what to do first.

## Dynamic completeness / dynamic completeness
- Small input: emit only confirmed findings, but keep the same output fields.
- Medium input: add traceability, severity normalization, and grouped recommendations.
- Large review scope: merge repeated findings, prefer representative evidence, and keep the artifact directly consumable by N220 and N260.

## Quality bar / quality bar
A good result should let downstream reviewers or gate owners act immediately without first normalizing severity, translating tool noise, or guessing whether the issue matters to the workflow.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/readiness-inheritance.md`
- `references/n210-integration-map.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/refactoring-pattern-catalog.md`
