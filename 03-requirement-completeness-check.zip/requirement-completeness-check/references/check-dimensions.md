# check dimensions

Use this file as the detailed checklist after the scope is understood.

## 1. business rules (20)

Check whether the requirement defines the decision logic needed to implement the feature correctly.

Core checks:
- trigger conditions for each core action
- branching logic for different user paths or object states
- calculation logic for amounts, counts, quotas, dates, or deadlines
- boundary values, thresholds, and special handling rules
- batch-operation rules, partial success behavior, and rollback expectations
- special cohorts or exception groups, such as vip users, restricted users, blacklists, or internal operators

Red flags:
- phrases like "handle normally", "according to policy", or "same as existing" without the actual rule
- rules defined only for the happy path
- output/result requirements defined without the decision conditions behind them

Typical confirmed gaps:
- missing branch conditions
- missing eligibility rules
- missing calculation formulas or rounding rules
- missing edge-case handling for threshold values

## 2. validations (15)

Check whether the requirement defines what must be validated before an action is accepted.

Core checks:
- required fields
- data formats and length limits
- numeric or date ranges
- business validity checks, such as status allowed, balance sufficient, stock available, or not expired
- error copy, display location, and whether validation is inline, submit-time, or backend-only
- duplicate submission or idempotency protections where relevant

Red flags:
- fields are listed but constraints are absent
- an action can fail but no failure condition is described
- validation result is mentioned without user-facing behavior

Typical confirmed gaps:
- required/optional ambiguity
- missing format or range rules
- missing business legality checks
- missing error feedback behavior

## 3. exception scenarios (15)

Check whether non-happy-path delivery scenarios are defined.

Core checks:
- api failure and timeout handling
- retry behavior and retry limits
- concurrency conflict handling
- partial success in batch flows
- stale data or version mismatch behavior
- fallback or degradation when external dependencies fail
- user messaging for recoverable and non-recoverable failures

Red flags:
- only success response is described
- dependent systems are mentioned but failure behavior is not
- async flows exist but no timeout/reconciliation behavior is defined

Typical confirmed gaps:
- missing timeout rules
- missing conflict resolution path
- missing partial success strategy
- missing dependency-failure fallback

## 4. permissions (15)

Check whether the requirement defines who can do what and on which data.

Core checks:
- actor roles for each operation
- data visibility scope, such as self, team, department, or all
- button or action exposure behavior when unauthorized
- server-side handling of unauthorized attempts
- approval/escalation roles if a workflow includes review or approval
- audit/logging expectations for sensitive operations

Red flags:
- operations are defined without actor constraints
- role names appear but permission scope is unclear
- ui hiding is described without backend enforcement

Typical confirmed gaps:
- missing role-to-action mapping
- missing data-scope rules
- missing unauthorized behavior
- missing approval authority rules

## 5. data impact (15)

Check whether the requirement explains which data changes and what else is affected.

Core checks:
- created, updated, deleted, or derived data objects
- cross-module effects and downstream consumers
- sync, replication, or event propagation requirements
- historical data handling and backfill strategy
- audit logs, operation records, and reporting impact
- soft delete versus hard delete
- data ownership and source of truth when multiple systems are involved

Red flags:
- a feature changes status or records but no persistence impact is described
- reporting is expected but upstream fields are not defined
- deletion/change behavior ignores historical records

Typical confirmed gaps:
- missing affected entities
- missing downstream sync implications
- missing historical/backfill treatment
- missing logging/reporting consequences

## 6. state transitions (10)

Check whether lifecycle and transition logic are complete.

Core checks:
- full state list
- allowed transitions from each state
- triggers and preconditions for transitions
- actor restrictions on transitions
- terminal or irreversible states
- reversal/cancellation/reopen behavior where applicable

Red flags:
- statuses are named but their transitions are not
- a screen or action depends on status but status entry/exit conditions are missing
- irreversible actions are described without explicit warning or recovery rules

Typical confirmed gaps:
- missing state list
- missing transition triggers
- missing invalid-transition behavior
- missing irreversible or rollback rules

## 7. integrations and interfaces (10)

Check whether all internal or external dependencies are defined well enough for delivery.

Core checks:
- dependent internal services or modules
- third-party interfaces and their responsibilities
- request/response expectations at the requirement level
- async messages, events, callbacks, or scheduled jobs
- ownership boundaries between teams or systems
- failure and retry expectations for integrations

Red flags:
- "call external service" appears without business expectation
- notifications are mentioned without trigger timing or payload intent
- cross-team dependency exists but handoff details are absent

Typical confirmed gaps:
- missing dependency list
- missing trigger timing for events or notifications
- missing ownership and interface assumptions
- missing failure expectations for integrations
