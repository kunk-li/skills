# scoring guide

Use this scoring method to keep ratings explainable and conservative.

## 1. dimension weights

| dimension | max score |
|---|---:|
| business rules | 20 |
| validations | 15 |
| exception scenarios | 15 |
| permissions | 15 |
| data impact | 15 |
| state transitions | 10 |
| integrations and interfaces | 10 |

Total: 100

## 2. readiness verdict thresholds

| score | verdict |
|---|---|
| 85-100 | ready with minor fixes |
| 70-84 | conditionally ready |
| 0-69 | not ready for engineering handoff |

## 3. deduction rules

Only deduct for `confirmed gap` items.

Default deduction by impact level:
- blocking: subtract 30% of the dimension max score
- major: subtract 15% of the dimension max score
- minor: subtract 5% of the dimension max score

Examples:
- a blocking business-rules gap deducts 6 points from that dimension
- a major permissions gap deducts 2.25 points from that dimension
- a minor integrations gap deducts 0.5 points from that dimension

## 4. merging and caps

Apply these controls before scoring:
- merge duplicate findings that share the same root cause
- do not deduct twice for the same underlying ambiguity
- cap total deductions in a dimension at that dimension's max score
- round the final total score to the nearest whole number

## 5. handling partial coverage

Use this rule of thumb:
- if enough detail exists to implement the happy path but not edge cases, usually record one or more `major` or `minor` gaps rather than marking the entire dimension as missing
- if the core delivery decision cannot be made from the requirement, treat it as `blocking`

## 6. needs-confirmation items

`needs confirmation` findings should be listed separately and normally do not deduct points.

Only convert them into deductions when:
- the user explicitly asks for strict scoring, or
- the provided materials strongly imply the item should have been present and its absence itself creates delivery risk

If you deduct for such a case, explain the reasoning clearly.

## 7. high-risk defaults

Treat these as blocking by default unless the document clearly makes them non-critical:
- missing core permission model for a feature with role-sensitive actions
- missing state transitions for lifecycle-driven workflows
- missing integration expectations when the feature depends on another system
- missing persistence/data mutation rules for write operations
- missing business-rule branches that determine whether a user can proceed

## 8. explanation requirement

When presenting the score:
- show score by dimension
- list the main deductions
- explain in plain language why the final verdict was chosen
- mention that the score is conservative and based only on evidence in the provided materials
