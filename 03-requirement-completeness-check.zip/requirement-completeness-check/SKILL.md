---
name: requirement-completeness-check
description: analyze prds, requirement docs, feature specs, meeting notes, prototype notes, and draft requirements for missing business rules, validations, exception handling, permissions, data impact, state transitions, and integration details. use when the user asks to review requirement completeness, identify missing items before engineering handoff, check whether a spec is ready for development or qa, find blocking gaps for implementation, or produce a structured gap list with evidence, scoring, and fix priorities.
---

# requirement completeness check

Review requirement materials for implementation readiness. Find missing information that would block or weaken engineering, qa, or cross-team delivery. Produce a structured, evidence-based gap analysis rather than a generic summary.

## Use the available materials first

Accept requirement inputs in any practical form, including PRDs, feature specs, meeting notes, prototype descriptions, screenshots converted to text, changelogs, and fragmented follow-up clarifications from the user.

When the input is incomplete or mixed across messages:
1. Merge all user-provided information into one coherent understanding of scope.
2. State the inferred feature scope in 3 to 6 bullets before scoring.
3. Distinguish between confirmed facts and assumptions.
4. Do not invent missing product behavior.

## Review workflow

Follow this sequence each time.

### Step 1: define the review scope

Start by identifying:
- the business goal or user task
- the main objects or entities affected
- the roles involved
- the key user actions
- the downstream systems or modules that appear affected

If a section is ambiguous, mark it as an assumption or open question rather than silently filling gaps.

### Step 2: extract what is already specified

For each review dimension, extract the requirement statements that are already present. Prefer concise evidence snippets or paraphrases tied to the source text.

### Step 3: check for gaps dimension by dimension

Use `references/check-dimensions.md` as the primary checklist. For each dimension, classify findings into exactly three buckets:
- **covered**: clearly specified and usable by delivery teams
- **partial**: mentioned but missing key detail, edge conditions, or operational clarity
- **missing**: no reliable evidence the requirement is defined

### Step 4: classify issue certainty and impact

For every issue, label both:

- **certainty**
  - `confirmed gap`: the materials provide enough evidence that a necessary item is absent or underdefined
  - `needs confirmation`: the item is commonly required, but the provided materials are too incomplete to conclude it is definitely missing

- **impact**
  - `blocking`: likely prevents engineering start, interface design, state handling, permission design, or test-case construction
  - `major`: does not fully block kickoff but would likely cause rework, wrong implementation, or poor test coverage
  - `minor`: improves completeness and maintainability but is unlikely to block delivery alone

Do not report speculative issues as confirmed gaps.

### Step 5: score conservatively

Use `references/scoring-guide.md`.

Scoring rules:
- Only `confirmed gap` items reduce the score by default.
- `needs confirmation` items should be listed separately and should not be treated as hard deductions unless the user explicitly asks for aggressive scoring.
- When multiple findings describe the same root problem, merge them before scoring.
- Explain the major drivers of the final score in plain language.

### Step 6: recommend the fix order

Prioritize fixes in this order unless the document clearly suggests otherwise:
1. blockers affecting core flow, permissions, state transitions, or integrations
2. major gaps affecting business logic, validations, and data impact
3. minor completeness improvements and wording polish

## Output requirements

Always structure the response in this order.

### 1. scope summary
Provide a brief summary of the feature or requirement set being reviewed.

### 2. readiness verdict
State one overall verdict:
- **ready with minor fixes**
- **conditionally ready**
- **not ready for engineering handoff**

Include one to three sentences explaining why.

### 3. dimension-by-dimension review
For each dimension, include:
- status: `covered` / `partial` / `missing`
- what is already defined
- confirmed gaps
- needs-confirmation items
- delivery risk in one sentence

### 4. prioritized issue list
Create a single merged issue list with these fields:
- priority
- dimension
- issue
- certainty
- impact
- why it matters
- recommended fix
- evidence

### 5. score summary
Include:
- total score out of 100
- score by dimension
- the main deductions applied

### 6. handoff checklist
End with a concise checklist of what the product owner should add or clarify before the next review.

## Evidence standard

Every confirmed gap must include evidence.

Acceptable evidence forms:
- a direct quote from the provided material
- a precise paraphrase of what the material covers
- a clear statement that the document defines adjacent logic but omits the required rule

If no evidence can be pointed to, downgrade the issue to `needs confirmation`.

## Review principles

- Prefer precision over exhaustiveness.
- Avoid duplicate findings across dimensions.
- Treat undocumented core state changes, permissions, external dependencies, and data mutations as high risk by default.
- Separate missing product decisions from missing wording. Focus on the decision gaps.
- Write output that can be pasted directly into a review comment or sent back to the product owner.

## References

- `references/check-dimensions.md` - detailed review checklist and red flags for each dimension
- `references/scoring-guide.md` - conservative scoring method and readiness thresholds
