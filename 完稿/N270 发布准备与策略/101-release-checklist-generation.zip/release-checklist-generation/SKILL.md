---
name: release-checklist-generation
description: >-
  generate n270 release checklist artifacts for release preparation with v2 contract metadata, event emission, differentiated inputs, degradation rules, and standalone or composed workflow use. use when chatgpt must produce 发版检查清单.csv, validate release readiness evidence, or participate in the n270 release package.
---
# release-checklist-generation

## Role
This skill produces the N270 `发版检查清单.csv` artifact. It must remain useful as a standalone skill and must become stronger when combined with other N270 skills through the shared `release_manifest`.

## Boundary
- Own `release_checklist` for N270; do not re-run upstream N260 quality gates or execute downstream N280 deployment actions.
- Consume upstream evidence and peer N270 artifacts when present, but never require all peer artifacts for standalone use.
- Keep downstream handoff to N280, N290, and N360 explicit, including missing evidence and manual decisions.
- Use `references/n270-artifact-contract-v2.md` as the contract source for metadata, events, readiness, and circuit breaker fields.

## Canonical identity
- `skill_id`: `release-checklist-generation`
- `schema_version`: `n270.release_checklist.v2`
- `artifact_version`: `2.0.0`
- `artifact_type`: `release_checklist`
- `emit_event.event_name`: `produced.n270.release_checklist.v2`
- `output_certainty_grade`: `authoritative_artifact`

## Maintenance status
- Treat this package as the N270 v4 maintenance build: core schema, event names, readiness model, and circuit-breaker semantics are frozen for normal use.
- Do not add, remove, or rename required contract fields unless the artifact contract version is explicitly bumped and all six N270 skills are updated together.
- Prefer bug fixes, wording clarifications, platform handoff updates, and registry migration notes over new skill behavior.
- In platform deployments, treat local contract mirrors as packaged fallback material; the artifact contract registry and event-bus ingress are the production authorities.

## Mode selection
Every output must declare `selected_mode`, `readiness`, `evidence_profile`, `output_certainty_grade`, and `emit_event` near the top.

Allowed modes:
- `dry_run_readiness`
- `release_day_runbook`
- `post_release_audit`
- `enterprise_release`

## Inputs
Use a four-tier input model so the skill is independently usable while still benefiting from richer workflow context.

### Minimum viable inputs
- release identity
- release scope or release_manifest summary
- current quality gate status or explicit unknown gate state

### Primary discriminating inputs
These inputs distinguish this skill from the other five N270 skills. Prioritize them when available.
- quality_gate_snapshot with go, conditional_go, no_go, blockers, waivers
- release_note or change_summary for communication and scope
- rollback_readiness and dry_run evidence status
- owners/signoff matrix and release calendar constraints

### Common N270 inputs
Use these as shared release context, not as the only preferred inputs. Always prefer Primary discriminating inputs; treat Common N270 inputs as last-resort fallback, not the default starting point.
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### Optional enhancement inputs
- deployment_plan from N280 when already available
- canary recommendation
- environment/config diff
- audit policy
- SLA policy

## Standalone and degradation rules
- Work on one release candidate, service release, hotfix, or release decision slice without requiring the full six-skill package.
- If minimum inputs are present but primary inputs are incomplete, keep the output contract stable and mark missing items under `evidence_profile.missing_evidence` and `downstream_handoff.missing_evidence_blocks`.
- Separate confirmed facts, assumptions, and unknowns. Do not convert unknowns into confident release statements.
- When evidence is insufficient for safe execution, produce a useful artifact with `readiness: amber` or `readiness: red` instead of refusing or inventing details.
- If invoked from N310 remediation and `orchestration_context.iter_count >= 3`, stop normal regeneration, mark readiness red, set cooldown `PT30M`, and escalate to the release manager / SLA human queue.

## Core output contract
Default to Markdown with YAML-like top metadata, or CSV/YAML-friendly tables when the user asks for a machine-readable artifact.

Required top-level sections:
- `metadata`
- `evidence_profile`
- `checklist_summary`
- `timeline_items[]`
- `blocking_items[]`
- `signoff_matrix[]`
- `automation_coverage`
- `audit_evidence[]`
- `sla_queue_items[]`
- `manual_decisions_required[]`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `skill_id: release-checklist-generation`
- `schema_version: n270.release_checklist.v2`
- `artifact_version: 2.0.0`
- `artifact_type: release_checklist`
- `function_bias: direct_result.release_execution_readiness`
- `stage_position: release_and_delivery.release_preparation.release_checklist_generation`
- `workflow_node: N270`
- `node_artifact_target: 发版检查清单.csv`
- `selected_mode`
- `output_certainty_grade: authoritative_artifact`
- `readiness: green | amber | red`
- `tool_collaboration_mode: standalone | composed | validation_only`
- `emit_event.event_name: produced.n270.release_checklist.v2`
- `circuit_breaker.iter_count / max_iter / cooldown / escalation_target`

## Design rules
- Position this checklist as release execution readiness, not a duplicate of N260 quality gate.
- Every blocking item must have owner, due time, evidence_ref, pass/block state, and next action.
- Human-only items must include SLA, escalation target, and acceptable evidence of confirmation.
- If rollback dry-run evidence is missing for release-critical phases, keep readiness red or blocked.
- Separate dry-run, release-day runbook, post-release verification, and audit views when the user intent differs.

## Execution workflow
1. Import release scope, gate result, release communication state, rollback readiness, and owner matrix.
2. Generate timeline-aware items for pre-deploy, deploy, immediate post-deploy, stabilization, and retrospective windows.
3. Mark each item as automated, semi-automated, or manual-only with evidence and owner fields.
4. Emit blocked items, SLA queue items, and downstream handoff for N280 execution and N290 verification.

## Composition behavior
- In full N270 mode, consult `references/n270-routing-and-orchestration-v2.md` before choosing sequence or parallel execution.
- Treat `release_manifest` as the single source of truth when multiple N270 artifacts coexist; update manifest patches before regenerating downstream artifacts.
- Emit a `produced.n270.*.v2` event for finalized artifacts so N330/N340/N350/N390 can subscribe without polling file names.
- If this artifact changes a field consumed by another N270 skill, list that peer skill under `downstream_handoff.refresh_triggers`.

## Self-check gate
- Run the self-check before finalizing. If any release-critical rule fails, `self_check.passed` must be false and readiness cannot be green.
- If the user asks to validate a generated artifact file, run `python scripts/validate_n270_artifact.py <artifact-file>` as a local LLM self-check. Treat this script as a packaged fallback; production-grade validation should run at the artifact contract registry with the canonical schema.
- Record failed rules, blockers, and exact owner/action needed for recovery.

## Quality bar
A good release checklist can be executed, audited, and blocked without subjective interpretation, while staying distinct from N260 quality scoring.

## Reference files
- `references/n270-artifact-contract-v2.md`
- `references/n270-routing-and-orchestration-v2.md`
- `references/n270-composite-release-manifest-example-v2.md`
- `references/failure-modes.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
- `references/output-template.md`
- `references/release-checklist-categories.md`
