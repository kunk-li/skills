## Mock input fixture

```yaml
mock_input:
  source: "release_identity_only"
  content: "release_id: payment-service-v2.1.3, target_env: production"
  expected_output_shape:
    checklist:
      total_items: ">= 4"
      p0_items: ">= 1"
    self_check:
      passed: true
      warnings: ["Conservative defaults — provide risk assessment to calibrate priorities"]
```
