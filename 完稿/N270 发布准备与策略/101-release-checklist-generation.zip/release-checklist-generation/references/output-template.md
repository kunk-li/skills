# Output template: 发版检查清单.csv

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: release-checklist-generation
  schema_version: n270.release_checklist.v2
  artifact_version: 2.0.0
  artifact_type: release_checklist
  workflow_node: N270
  stage_position: release_and_delivery.release_preparation.release_checklist_generation
  node_artifact_target: 发版检查清单.csv
  selected_mode: <mode>
  output_certainty_grade: authoritative_artifact
  readiness: green | amber | red
  function_bias: direct_result.release_execution_readiness
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.n270.release_checklist.v2
    event_version: 2
    producer_skill: release-checklist-generation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `checklist_summary`
- `timeline_items[]`
- `blocking_items[]`
- `signoff_matrix[]`
- `automation_coverage`
- `audit_evidence[]`
- `sla_queue_items[]`
- `manual_decisions_required[]`

End with:

```yaml
downstream_handoff:
  primary_consumers: [N280, N290, N360]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```
