# Output template: 发版检查清单.csv

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: release-checklist-generation
  schema_version: release-prep.release_checklist.v2
  artifact_version: 2.0.0
  artifact_type: release_checklist
  workflow_node: release-prep
  stage_position: release_and_delivery.release_preparation.release_checklist_generation
  node_artifact_target: 发版检查清单.csv
  selected_mode: <mode>
  output_certainty_grade: authoritative_artifact
  readiness: green | amber | red
  function_bias: direct_result.release_execution_readiness
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.release-prep.release_checklist.v2
    event_version: 2
    producer_skill: release-checklist-generation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `checklist_summary`
- `timeline_items[]`
- `blocking_items[]`
- `signoff_matrix[]`
- `automation_coverage`
- `audit_evidence[]`
- `sla_queue_items[]`
- `manual_decisions_required[]`

End with:

```yaml
downstream_handoff:
  primary_consumers: [release-exec, release-validation, change-tracking]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```


---

## Downstream handoff YAML templates

### 正常路径：checklist → release-task-orchestration
```yaml
downstream_handoff:
  produced_by: release-checklist-generation
  artifact: 发版检查清单.csv
  emit_event:
    event_name: produced.release-prep.release_checklist.v2
    event_delivery: declared_only
  handoffs:
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "8 checklist items: 2 P0 (pass), 4 P1 (3 pass, 1 pending), 2 P2. All P0 cleared."
      required_fields:
        - checklist.items
        - checklist.p0_all_cleared
        - downstream_handoff.p0_summary
      confidence: high
      next_best_checks:
        - "108: add approval gate for CHK-003 (rollback confirmation pending)"
        - "108: use timing_marker T-0 items as deploy preconditions"
    - target: release-risk-assessment
      handoff_type: gap
      summary: "CHK-003 rollback confirmation still pending — risk score may need update"
      required_fields: [item_id, category, status]
      confidence: medium
  refresh_triggers:
    - skill: release-task-orchestration
      reason: "Checklist item status changed — DAG preconditions must re-evaluate"
      condition: "any P0 checklist item status changed"
```

### 阻断路径：P0 checklist item FAILED
```yaml
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      handoff_type: gap
      summary: "BLOCKER: CHK-001 automated tests failing. Block release DAG start."
      blocking: true
      required_fields: [item_id, fail_action, evidence_required]
      next_best_checks:
        - "Do not start release-task-orchestration until CHK-001 is resolved and re-signed"
```


---

## Standalone guarantee
This skill runs with only a release identity and rough scope. Never refuse because risk assessment or rollback plan is absent.

### Minimum standalone example — release ID only
```yaml
metadata:
  readiness: partial
  selected_mode: dry_run_readiness
  output_certainty_grade: authoritative_artifact
evidence_profile:
  confirmed: [release_identity]
  missing_evidence: [quality_gate_snapshot, rollback_plan, risk_assessment]
  missing_evidence_impact: "Checklist uses conservative defaults. High-risk items cannot be weighted without risk assessment."
checklist:
  release_id: payment-service-v2.1.3
  total_items: 8
  items:
    - item_id: CHK-001
      category: code_quality
      description: "All automated tests pass in CI"
      priority: P0
      sign_off_role: tech_lead
      status: unknown
      evidence_required: "CI pipeline green link"
    - item_id: CHK-002
      category: rollback_readiness
      description: "Rollback plan documented and reviewed"
      priority: P0
      sign_off_role: release_manager
      status: unknown
      evidence_required: "rollback-plan-generation artifact or equivalent document"
    - item_id: CHK-003
      category: deployment_window
      description: "Deployment scheduled within approved maintenance window"
      priority: P1
      sign_off_role: release_manager
      status: unknown
    - item_id: CHK-004
      category: monitoring
      description: "Dashboards and alerts confirmed active for target service"
      priority: P1
      sign_off_role: sre
      status: unknown
blockers_and_pending:
  - item: "risk_assessment not provided — CHK-001 priority may need upgrading to P0 critical"
    severity: P1
    action: "Run release-risk-assessment to calibrate item priorities"
downstream_handoff:
  to_skill: release-task-orchestration
  missing_evidence: [quality_gate_snapshot, rollback_plan]
self_check:
  passed: true
  warnings: ["Conservative defaults applied — provide risk assessment to calibrate priorities"]
```

### enterprise_release example — multi-team, CAB required
```yaml
metadata:
  readiness: green
  selected_mode: enterprise_release
checklist:
  release_id: platform-v4.0-enterprise
  total_items: 14
  gate_categories: [security_review, cab_approval, compliance_sign_off, dr_rehearsal]
  items:
    - item_id: CHK-E-001
      category: security_review
      description: "Security team SAST scan passed — no critical findings"
      priority: P0
      sign_off_role: security_lead
      status: pending
      evidence_required: "SAST report with zero critical/high findings"
    - item_id: CHK-E-002
      category: cab_approval
      description: "Change Advisory Board approval obtained"
      priority: P0
      sign_off_role: cab_chair
      status: pending
      deadline: "48h before deploy window"
    - item_id: CHK-E-003
      category: compliance_sign_off
      description: "Compliance officer sign-off for PII data handling changes"
      priority: P0
      sign_off_role: compliance_officer
      status: pending
```

**Key calibration:** `enterprise_release` mode surfaces compliance, security, and CAB gate items as P0. Every enterprise gate item must have a `deadline` and `sign_off_role`. Do not generate execution task ordering — that belongs to release-task-orchestration.

---

## Output completeness rule
Every checklist artifact MUST include ALL of:
- `checklist.items` with ≥ 1 P0 item; each with ALL 8 fields above
- `checklist.weighted_completion` with P0_total, P0_signed, P0_completion_pct
- `config_state.overall_ready_to_proceed` boolean
- `consumer_impact_assessment` when breaking changes present
- `adversarial_detection.injection_attempt_detected` boolean
- `downstream_handoff` to release-task-orchestration
- `feedback_signal_candidates` ≥ 1

---

## Mode selection

### New: `compliance_gate_only` mode — 纯合规门控模式
**Trigger:** Compliance or legal team needs checklist focused purely on regulatory requirements, or user says "compliance checklist only", "GDPR gate items".

```yaml
compliance_gate_only:
  scope: compliance_and_regulatory_items_only
  excluded_categories: [artifact_and_signature, test_pass, environment_check]
  compliance_items:
    - item_id: CHK-COMP-001
      category: compliance_sign_off
      priority: P0
      regulatory_ref: "GDPR Art. 5(1)(f)"
      description: "DPO sign-off: confirm PII data handling changes comply with GDPR"
      sign_off_role: dpo
      timing_marker: T-7d
      fail_action: block_release
      evidence_required: "Signed compliance review document with DPO name and date"
    - item_id: CHK-COMP-002
      category: compliance_sign_off
      priority: P0
      regulatory_ref: "PCI-DSS 4.0 req 6.3.3"
      description: "Security officer sign-off: confirm patching SLA met"
      sign_off_role: security-officer
      timing_marker: T-3d
  compliance_gate_result: pending
```
**SCR:** `selected_mode: compliance_gate_only` → `compliance_gate_only.compliance_items` ≥ 1; all items have `regulatory_ref`.

### New: `hotfix_checklist` mode — 热修复精简门控
**Trigger:** Emergency hotfix requires a minimal pre-deploy checklist (not full 14-day cycle), or user says "hotfix checklist", "emergency deploy gates".

```yaml
hotfix_checklist:
  max_p0_items: 4
  time_budget: 30min
  items:
    - item_id: HF-CHK-001
      description: "Hotfix risk assessment completed (122 verdict: go/conditional_go)"
      priority: P0
      timing_marker: T-0
      fail_action: block_release
      evidence_required: "热修复风险评估.md from skill 122"
    - item_id: HF-CHK-002
      description: "Rollback plan Phase 1 confirmed executable"
      priority: P0
      timing_marker: T-0
      fail_action: block_release
    - item_id: HF-CHK-003
      description: "On-call lead confirmed deployment window"
      priority: P0
      timing_marker: T-0
      evidence_required: "Named on-call engineer + availability confirmed"
    - item_id: HF-CHK-004
      description: "Post-hotfix monitoring increased (error rate alerts at 0.5%)"
      priority: P1
      timing_marker: T-0
  weighted_completion: {P0_total: 3, P0_signed: 0}
```
**SCR:** `selected_mode: hotfix_checklist` → `hotfix_checklist.max_p0_items` ≤ 5; `time_budget` ≤ 60min.


## CSV 序列化规则(node_artifact_target 是 .csv)

本产物 node_artifact_target 是 `.csv`。必须序列化为**既是合法 CSV、又携带上面契约 metadata 信封**的文件:

1. 把上面完整的 metadata 信封及所有 YAML 块,作为文件开头的注释行输出,每行以 `# ` 前缀。CSV 读取器跳过 `#` 行;信封仍可被 `scripts/validate_artifact.py` 机读校验(该校验器按段名子串匹配,注释头满足全部 REQUIRED 段)。
2. 注释信封之后,再输出表头行 + 表格条目(检查项/测试点/任务行)为标准逗号分隔 CSV 行。
3. 不要输出无注释信封的纯数据 CSV——`validate_artifact.py` 会因缺 metadata/self_check/downstream_handoff/evidence_profile/emit_event(或 produced_event)/adversarial_detection/feedback_signal_candidates 等段判 FAIL。

合法示例骨架:

```
# metadata:
#   skill_id: <skill>
#   node_artifact_target: <本产物>.csv
#   readiness: green
# self_check: {passed: true, failed_rules: []}
# downstream_handoff: {primary_consumers: [...]}
# evidence_profile: {confirmed_evidence: [], assumptions: [], missing_evidence: []}
# emit_event: {event_name: produced.<node>.<artifact>.v2}
# adversarial_detection: none_detected
# feedback_signal_candidates: []
<列头1>,<列头2>,<列头3>
<行数据...>
```
