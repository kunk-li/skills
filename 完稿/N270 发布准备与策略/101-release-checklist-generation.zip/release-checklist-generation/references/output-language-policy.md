## Output language policy

### Bilingual term glossary
When outputting in Chinese, use these standardized translations for field names in prose sections:

| English term | 中文标准译法 |
|---|---|
| readiness | 就绪状态 |
| confidence | 置信度 |
| downstream_handoff | 下游移交 |
| evidence_profile | 证据概况 |
| self_check | 自检 |
| blockers_and_pending | 阻断项与待办 |
| field contract | 字段契约 |
| artifact | 制品 |
| circuit_breaker | 熔断器 |
| rollback | 回滚 |
| canary | 灰度 |
| deployment | 部署 |
| incident | 故障 / 事件 |
| blast radius | 影响范围 |
| SLO burn rate | SLO 燃烧率 |

### Japanese output rules (for JP operator contexts)
When `output_language: ja` is set by operator:
- YAML field names: English (unchanged)
- Prose sections: Japanese
- File names: keep Chinese artifact names (workflow contract; do not translate)
- Numbers and measurements: SI units; comma as thousands separator

```yaml
# Japanese prose example
metadata:
  readiness: amber
  # 日本語説明:
  evidence_summary_ja: "決済サービスのエラー率が14:32 UTCから12%に急上昇。SLO消費率: 42倍。即時対応が必要です。"
downstream_handoff:
  next_best_checks_ja:
    - "ログ分析: 決済サービスのエラーログを14:30-14:40 UTCで抽出する"
```

### Korean output rules (for KR operator contexts)
When `output_language: ko` is set:
- YAML field names: English (unchanged)
- Prose sections: Korean
- Measurements: SI units; KRW for currency if revenue impact

### Operator override format
```yaml
# In system prompt or artifact header:
operator_config:
  output_language: zh-CN | zh-TW | ja | ko | en  # default: follow user message language
  artifact_names_translate: false  # never translate node_artifact_target names
  field_names_translate: false     # never translate YAML field names
  glossary_version: "2.0"         # use standardized bilingual glossary above
```
