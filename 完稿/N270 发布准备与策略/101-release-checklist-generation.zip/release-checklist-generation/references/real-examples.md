# real examples

Example signals worth highlighting:
- release contains a DB migration and a new config flag
- canary is limited to internal users first because business blast radius is high
- rollback is image-safe for 24h only because old binaries cannot read new long-lived data after that

---

## Additional scenario: amber degradation — missing commit history

**Scenario:** Skill invoked with only a ticket ID and a one-line change description. No PR, no diff.

**Expected behavior:**
- Produce the artifact in the most useful mode given available evidence.
- Declare `readiness: partial` with explicit `missing_evidence`.
- Populate all stable output sections; use `unknown` or `inferred` for fields that cannot be determined.
- `downstream_handoff.missing_evidence` lists what is needed to reach `readiness: green`.
- `self_check.passed: false` with the specific rule that failed.

**Key calibration:** Never refuse output due to missing optional inputs. A partial artifact with clear evidence gaps is more useful than no artifact. The consumer (release manager, SRE, or next skill) uses the `missing_evidence` list to decide whether to proceed or gather more evidence first.

---

## Example 3: hotfix release — rapid checklist (4 items only)

**Scenario:** Emergency hotfix for payment service. Only 3 P0 items matter.

```yaml
metadata:
  readiness: green
  selected_mode: release_day_runbook
  release_id: payment-service-hotfix-v2.1.4
checklist:
  total_items: 4
  items:
    - item_id: CHK-H-001
      category: rollback_confirmation
      description: "Rollback target (v2.1.3) verified and tested in staging"
      priority: P0
      sign_off_role: sre-lead
      timing_marker: T-1h
      status: pass
      evidence_required: "kubectl rollout history payment-service output"
      fail_action: block_release
      linked_skill: rollback-plan-generation
    - item_id: CHK-H-002
      category: monitoring_markers
      description: "Error rate dashboard active and baseline confirmed"
      priority: P0
      sign_off_role: sre-oncall
      timing_marker: T-30min
      status: pass
      evidence_required: "Dashboard screenshot showing baseline 0.3%"
      fail_action: block_release
    - item_id: CHK-H-003
      category: canary_execution_readiness
      description: "On-call engineer available and briefed on hotfix scope"
      priority: P0
      sign_off_role: release_manager
      timing_marker: T-15min
      status: pass
      evidence_required: "On-call engineer name and acknowledgment"
      fail_action: block_release
    - item_id: CHK-H-004
      category: stakeholder_communication
      description: "PM and SRE-lead notified of hotfix window"
      priority: P1
      sign_off_role: release_manager
      timing_marker: T-30min
      status: pass
downstream_handoff:
  to_skill: release-task-orchestration
self_check:
  passed: true
```

**Key calibration:** Hotfix checklists have ≤5 items. All P0 items must clear before T-0. Do not add P2 items under time pressure — a lean, fully-executed checklist is better than a long partially-executed one.

---

## Example 4: post_release_audit — verifying compliance after deploy

**Scenario:** Compliance team requests a post-deploy audit for a PII-related change.

```yaml
metadata:
  readiness: green
  selected_mode: post_release_audit
  release_id: user-profile-service-v3.1.0
checklist:
  total_items: 6
  gate_categories: [compliance_sign_off, security_review, monitoring_markers]
  items:
    - item_id: CHK-A-001
      category: compliance_sign_off
      description: "DPO sign-off on PII data handling changes confirmed"
      priority: P0
      sign_off_role: dpo
      timing_marker: T+24h
      status: pass
      evidence_required: "DPO approval email or ticket reference"
      fail_action: block_release
    - item_id: CHK-A-002
      category: security_review
      description: "SAST scan post-deploy shows no new critical findings"
      priority: P0
      sign_off_role: security_lead
      timing_marker: T+2h
      status: pass
      evidence_required: "SAST report link with zero critical/high findings"
      fail_action: block_release
```

---

## Example 5: High-risk release — 12+ items, composite_risk_score 0.75

**Scenario:** Major platform release. composite_risk_score from release-risk-assessment is 0.75 (amber, near circuit breaker). Checklist is calibrated to maximum depth.

**Input given:**
- `发布风险评估.md`: composite_risk_score 0.75, amber, 3 high-risk dimensions
- Risk dimensions flagged: data_migration_risk (high), integration_risk (high), rollback_risk (medium)
- Release: multi-service platform upgrade affecting 8 services

**Expected output shape:**
```yaml
metadata:
  readiness: green
  selected_mode: pre_deployment
  risk_calibration_source: release-risk-assessment.composite_risk_score=0.75
checklist:
  risk_calibrated_depth: high    # 0.75 → maximum depth (12+ items)
  total_items: 14
  p0_count: 7
  p1_count: 5
  p2_count: 2
  items:
    - item_id: CHK-001
      category: migration_sign_off
      description: "DB migration dry-run completed in staging with DBA sign-off"
      priority: P0
      sign_off_role: dba
      timing_marker: T-7d
      evidence_required: "DBA approval ticket reference + migration timing report"
      fail_action: block_release
      linked_skill: rollback-plan-generation

    - item_id: CHK-002
      category: rollback_confirmation
      description: "Rollback plan Phase 1-3 rehearsed in staging; SLA confirmed < 15 minutes"
      priority: P0
      sign_off_role: sre-lead
      timing_marker: T-3d
      evidence_required: "Rehearsal report with actual SLA timing"
      fail_action: block_release
      linked_skill: rollback-plan-generation

    - item_id: CHK-003
      category: integration_validation
      description: "All 8 dependent services validated against new API contract in staging"
      priority: P0
      sign_off_role: tech-lead
      timing_marker: T-3d
      evidence_required: "Integration test results for all 8 services (0 failures)"
      fail_action: block_release

    - item_id: CHK-004
      category: canary_readiness
      description: "Canary plan from canary-release-recommendation reviewed and approved"
      priority: P0
      sign_off_role: release_manager
      timing_marker: T-1d
      evidence_required: "Canary plan artifact 金丝雀发布方案.md reviewed"
      fail_action: block_release
      linked_skill: canary-release-recommendation

    - item_id: CHK-005
      category: monitoring_markers
      description: "SLO dashboards and alert thresholds reviewed for canary stage gates"
      priority: P0
      sign_off_role: sre-lead
      timing_marker: T-1d
      evidence_required: "Dashboard link + confirmed baseline metrics"
      fail_action: block_release

    - item_id: CHK-006
      category: compliance_sign_off
      description: "Change Advisory Board (CAB) submission approved for HIGH-category change"
      priority: P0
      sign_off_role: change_manager
      timing_marker: T-2d
      evidence_required: "CAB approval reference number"
      fail_action: block_release

    - item_id: CHK-007
      category: stakeholder_communication
      description: "All 8 service owners notified; maintenance window published externally"
      priority: P0
      sign_off_role: release_manager
      timing_marker: T-3d
      evidence_required: "Notification email thread link"
      fail_action: block_release

    # P1 items (5) ...
    - item_id: CHK-008
      category: security_review
      description: "SAST scan on changed services — no critical/high findings"
      priority: P1
      sign_off_role: security_lead
      timing_marker: T-5d
      fail_action: escalate_to_security

    # ... (CHK-009 to CHK-014 omitted for brevity — follow same pattern)

weighted_completion:
  P0_total: 7
  P0_signed: 7
  P0_completion_pct: 100
downstream_handoff:
  to_skill: release-task-orchestration
  checklist_summary: "14 items. P0: 7/7 signed. High-risk release — all gates cleared."
self_check:
  passed: true
  warnings:
    - "High-risk calibration applied (composite_score 0.75) — 14-item checklist vs 4-item low-risk minimum"
```

**Key calibration:** Risk score mapping: `low (< 0.40) → 4 items`, `medium (0.40-0.60) → 8 items`, `high (0.60-0.80) → 12+ items`. Always document `risk_calibration_source` so downstream consumers know why the checklist is deep.

---

## Example 6: Minimum input — readiness: partial (no risk assessment upstream)

**Scenario:** Operator asks for a checklist with only "payment-service v2.3, DB migration" — no risk assessment artifact.

```yaml
metadata:
  readiness: partial
  selected_mode: pre_deployment
  evidence_profile:
    confirmed: [release_identity, change_description]
    missing_evidence:
      - release-risk-assessment artifact (composite_risk_score unknown — defaulting to medium depth)
      - rollback_plan artifact
    missing_evidence_impact: "Checklist depth defaulted to medium (8 items). May need adjustment after risk assessment."
checklist:
  risk_calibrated_depth: medium    # default when risk assessment absent
  total_items: 6
  items:
    - item_id: CHK-001
      description: "DB migration dry-run completed in staging"
      priority: P0
      sign_off_role: dba
      timing_marker: T-3d
      evidence_required: "DBA sign-off + migration test results"
      fail_action: block_release
    - item_id: CHK-002
      description: "Rollback plan designed and rehearsed"
      priority: P0
      sign_off_role: sre-lead
      timing_marker: T-1d
      evidence_required: "rollback-plan-generation artifact confirmed"
      fail_action: block_release
    # ... remaining items
downstream_handoff:
  missing_evidence: [release_risk_assessment]
  next_best_checks:
    - "Run release-risk-assessment (105) to calibrate checklist depth precisely"
self_check:
  passed: false
  failed_rules:
    - "release_risk_assessment absent — checklist depth defaulted to medium; may be under- or over-scoped"
```


---

## Scenario calibration
See `references/real-examples.md` for release_day_runbook, post_release_audit, and enterprise_release scenarios.

For checklist category definitions, see `references/release-checklist-categories.md`.
For sign-off role assignments and gate definitions, see `references/field-contract.md`.