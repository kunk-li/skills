# Compatibility pointer

This legacy filename is kept for backward compatibility. Use `references/release-prep-routing-and-orchestration-v2.md` as the canonical routing, composition, and closure-rule reference. Do not load both files for the same task.


---

## Boundary comparison table — release-checklist vs related skills

| Dimension | release-checklist-generation | post-release-validation-checklist | release-risk-assessment | release-task-orchestration |
|---|---|---|---|---|
| **Primary question** | "Are we operationally READY to deploy?" | "Did the deployment SUCCEED?" | "Should we deploy at all?" | "How do we sequence the deployment?" |
| **Timing** | Pre-deploy (T-14d to T-0) | Post-deploy (T+0 onwards) | Pre-deploy planning | Execution window |
| **Owns** | Readiness gate items, sign-off tracking, timing markers | PRV items, validation outcomes, GO/NO-GO data for 110 | Risk scoring, go/no-go recommendation | Task DAG, dependency ordering, execution state |
| **Does not own** | Risk scoring (→101), task execution (→108), post-deploy validation (→109) | Pre-deploy readiness (→103), GA decision (→110) | Gate item design (→103) | Gate item design (→103) |

### Hard rules
- **103 never contains**: execution DAG, task dependencies, task timeouts → route to 108
- **103 never contains**: post-deploy validation outcomes → route to 109
- **103 always contains**: at least one P0 item with `fail_action: block_release`
- **Timing boundary**: 103 items have `timing_marker` in [T-14d, T-7d, T-3d, T-1d, T-0]; 109 items start at T+0

---

## Composition behavior
- In full release-prep mode, consult `references/release-prep-routing-and-orchestration.md` before choosing sequence or parallel execution.
- Treat `release_manifest` as the single source of truth when multiple release-prep artifacts coexist; update manifest patches before regenerating downstream artifacts.
- Emit a `produced.release-prep.*.v2` event for finalized artifacts so deployment/rollout/infra/reporting can subscribe without polling file names.
- If this artifact changes a field consumed by another release-prep skill, list that peer skill under `downstream_handoff.refresh_triggers`.


---

| Content type | Belongs in 103? | Route to instead |
|---|---|---|
| Pre-deploy gate item (T-14d to T-0) | ✅ YES | — |
| Post-deploy validation step (T+0 onward) | ❌ NO | post-release-validation-checklist |
| GA decision (GO/NO-GO) | ❌ NO | go-live-acceptance-assistant |
| Execution task with dependencies | ❌ NO | release-task-orchestration |
| Risk score or composite risk analysis | ❌ NO | release-risk-assessment |
| Canary stage traffic configuration | ❌ NO | canary-release-recommendation |
| Rollback procedure phases | ❌ NO | rollback-plan-generation |
| Config reload analysis | ❌ NO | configuration-change-check |

### Timing boundary: 103 vs 109

| Item timing | Belongs in 103 | Belongs in 109 |
|---|---|---|
| T-14d: DPO sign-off | ✅ | |
| T-7d: smoke test environment ready | ✅ | |
| T-0: rollback plan confirmed | ✅ | |
| T+5min: smoke test result | | ✅ |
| T+1h: error rate check | | ✅ |
| T+24h: business KPI validation | | ✅ |

## Mode selection
This skill supports the following execution modes:

- `full_checklist` — standard: generate all P0/P1/P2 items with owners and timing