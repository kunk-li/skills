# failure modes

| id | failure mode | required response |
|---|---|---|
| `RC-F1` | Duplicating N260 gate instead of execution readiness | Reference N260 results and translate them into release actions rather than re-scoring quality. |
| `RC-F2` | Checklist items without owner/time/evidence | Require owner, due_time, evidence_ref, and blocking flag on every executable item. |
| `RC-F3` | Treating missing rollback dry-run as warning only | Make release-critical dry-run gaps blocking. |
| `RC-F4` | Human signoff without SLA | Add sla_due_at and escalation_target for every manual confirmation. |
| `RC-F5` | Unclear machine state | Use pass, fail, blocked, waived, not_applicable, or pending; avoid prose-only statuses. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.
