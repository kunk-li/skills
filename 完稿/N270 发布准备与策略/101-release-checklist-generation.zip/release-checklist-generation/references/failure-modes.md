# failure modes

| id | failure mode | required response |
|---|---|---|
| `RC-F1` | Duplicating release-quality gate instead of execution readiness | Reference release-quality results and translate them into release actions rather than re-scoring quality. |
| `RC-F2` | Checklist items without owner/time/evidence | Require owner, due_time, evidence_ref, and blocking flag on every executable item. |
| `RC-F3` | Treating missing rollback dry-run as warning only | Make release-critical dry-run gaps blocking. |
| `RC-F4` | Human signoff without SLA | Add sla_due_at and escalation_target for every manual confirmation. |
| `RC-F5` | Unclear machine state | Use pass, fail, blocked, waived, not_applicable, or pending; avoid prose-only statuses. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.


---

## Degradation examples — amber extended

### readiness: amber — P1 items in_progress, P0 all signed

```yaml
metadata:
  readiness: amber
evidence_profile:
  confidence_ceiling_applied: medium
checklist:
  weighted_completion:
    P0_total: 3
    P0_signed: 3
    P0_completion_pct: 100
    P1_total: 5
    P1_signed: 3
    P1_completion_pct: 60
  overall_readiness: amber
  amber_reason: "P1 completion 60% — acceptable for release but note outstanding items"
  outstanding_P1:
    - item_id: CHK-007
      description: "Post-mortem from previous incident reviewed"
      sign_off_role: sre-lead
      status: in_progress
      due: "T-0 (recommend before deploy)"
config_state:
  overall_ready_to_proceed: true
  reason: "P0 fully signed — release may proceed; P1 items tracked"
self_check:
  passed: true
  warnings:
    - "amber — P1 completion 60%; 2 items outstanding"
    - "CHK-007 recommended before deploy for best practice"
```