# Field contract v2

Prefer `references/release-prep-artifact-contract-v2.md` for the full contract. This file remains as a compact backward-compatible summary.

Required metadata additions over v1:
- `schema_version`
- `artifact_version`
- `artifact_type`
- `output_certainty_grade`
- `emit_event`
- `circuit_breaker`

Required downstream handoff additions:
- `consumed_fields`
- `missing_evidence_blocks`
- `manual_decisions_required`
- `refresh_triggers`
- `sla_queue_items` when human confirmation is needed


---

## Field contract — checklist_item entry

| Field | Required | Values / notes |
|---|---|---|
| `item_id` | yes | `CHK-{NNN}` format |
| `category` | yes | ∈ {artifact_and_signature, test_pass, environment_check, compliance_sign_off, canary_gate, monitoring_baseline} |
| `priority` | yes | ∈ {P0, P1, P2} |
| `description` | yes | clear action string |
| `sign_off_role` | yes | named role; never `unassigned` for P0 |
| `timing_marker` | yes | `T-{N}d` or `T-0` |
| `fail_action` | yes | ∈ {block_release, escalate, defer_to_p1} |
| `evidence_required` | yes | what constitutes sign-off |