# Quality checklist v2

A strong release-prep artifact:
- exposes `schema_version`, `artifact_version`, `emit_event`, and `circuit_breaker`
- declares minimum, primary discriminating, common, and optional inputs
- is explicitly tied to the official release-prep output name
- references the shared `release_manifest` without requiring all six release-prep artifacts for standalone use
- names blockers, mitigations, owners, SLA, and remaining unknowns directly
- keeps direct-result artifacts separate from decision-support artifacts
- makes downstream use in release-exec, release-validation, and change-tracking obvious
- emits refresh triggers when peer artifacts should be regenerated


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-RELEASEC-051 | Every P0 item has `fail_action: block_release` | conditional | `self_check.failed_rules: ["SCR-RELEASEC-051: P0 item missing block_release fail_action"]` |
| SCR-RELEASEC-052 | `downstream_handoff` to release-task-orchestration present | key check | `self_check.failed_rules: ["SCR-RELEASEC-052: no handoff to 108"]` |
| SCR-RELEASEC-053 | `adversarial_detection` present | key exists | `self_check.warnings: ["SCR-RELEASEC-053: adversarial_detection missing"]` |