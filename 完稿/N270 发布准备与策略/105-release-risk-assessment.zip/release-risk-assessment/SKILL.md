---
name: release-risk-assessment
description: >-
  generate n270 release risk assessment artifacts for release preparation with v2 contract metadata, event emission, differentiated inputs, degradation rules, and standalone or composed workflow use. use when chatgpt must produce 发布风险评估.md, validate release readiness evidence, or participate in the n270 release package.
---
# release-risk-assessment

## Role
This skill produces the N270 `发布风险评估.md` artifact. It must remain useful as a standalone skill and must become stronger when combined with other N270 skills through the shared `release_manifest`.

## Boundary
- Own `release_risk_assessment` for N270; do not re-run upstream N260 quality gates or execute downstream N280 deployment actions.
- Consume upstream evidence and peer N270 artifacts when present, but never require all peer artifacts for standalone use.
- Keep downstream handoff to N280, N290, and N360 explicit, including missing evidence and manual decisions.
- Use `references/n270-artifact-contract-v2.md` as the contract source for metadata, events, readiness, and circuit breaker fields.

## Canonical identity
- `skill_id`: `release-risk-assessment`
- `schema_version`: `n270.release_risk.v2`
- `artifact_version`: `2.0.0`
- `artifact_type`: `release_risk_assessment`
- `emit_event.event_name`: `produced.n270.release_risk.v2`
- `output_certainty_grade`: `decision_support_not_hard_gate`

## Maintenance status
- Treat this package as the N270 v4 maintenance build: core schema, event names, readiness model, and circuit-breaker semantics are frozen for normal use.
- Do not add, remove, or rename required contract fields unless the artifact contract version is explicitly bumped and all six N270 skills are updated together.
- Prefer bug fixes, wording clarifications, platform handoff updates, and registry migration notes over new skill behavior.
- In platform deployments, treat local contract mirrors as packaged fallback material; the artifact contract registry and event-bus ingress are the production authorities.

## Mode selection
Every output must declare `selected_mode`, `readiness`, `evidence_profile`, `output_certainty_grade`, and `emit_event` near the top.

Allowed modes:
- `quick_risk_scan`
- `comprehensive_release_risk`
- `comparative`
- `post_incident_recalibration`
- `final_go_no_go_basis`

## Inputs
Use a four-tier input model so the skill is independently usable while still benefiting from richer workflow context.

### Minimum viable inputs
- release identity or change slice
- diff risk evidence, quality gate snapshot, or explicit change description

### Primary discriminating inputs
These inputs distinguish this skill from the other five N270 skills. Prioritize them when available.
- Diff风险点评.md or structured diff risk assessments
- 质量门禁检查单.md with blockers/waivers/conditional-go state
- historical release risks and similar release outcomes
- defect severity trends and N005 production signals
- change_summary or release_manifest change inventory

### Common N270 inputs
Use these as shared release context, not as the only preferred inputs. Always prefer Primary discriminating inputs; treat Common N270 inputs as last-resort fallback, not the default starting point.
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### Optional enhancement inputs
- rollback plan
- canary recommendation
- dependency changes
- migration notes
- business calendar/freeze periods
- approval path

## Standalone and degradation rules
- Work on one release candidate, service release, hotfix, or release decision slice without requiring the full six-skill package.
- If minimum inputs are present but primary inputs are incomplete, keep the output contract stable and mark missing items under `evidence_profile.missing_evidence` and `downstream_handoff.missing_evidence_blocks`.
- Separate confirmed facts, assumptions, and unknowns. Do not convert unknowns into confident release statements.
- When evidence is insufficient for safe execution, produce a useful artifact with `readiness: amber` or `readiness: red` instead of refusing or inventing details.
- If invoked from N310 remediation and `orchestration_context.iter_count >= 3`, stop normal regeneration, mark readiness red, set cooldown `PT30M`, and escalate to the release manager / SLA human queue.

## Core output contract
Default to Markdown with YAML-like top metadata, or CSV/YAML-friendly tables when the user asks for a machine-readable artifact.

Required top-level sections:
- `metadata`
- `evidence_profile`
- `risk_summary`
- `risk_dimensions[]`
- `risk_register[]`
- `risk_scoring_model`
- `mitigation_mapping[]`
- `cross_release_tracking`
- `n005_feedback_consumption`
- `approval_path`
- `go_no_go_recommendation`
- `decision_rationale`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `skill_id: release-risk-assessment`
- `schema_version: n270.release_risk.v2`
- `artifact_version: 2.0.0`
- `artifact_type: release_risk_assessment`
- `function_bias: decision_support.release_risk_scoring_and_mitigation`
- `stage_position: release_and_delivery.release_preparation.release_risk_assessment`
- `workflow_node: N270`
- `node_artifact_target: 发布风险评估.md`
- `selected_mode`
- `output_certainty_grade: decision_support_not_hard_gate`
- `readiness: green | amber | red`
- `tool_collaboration_mode: standalone | composed | validation_only`
- `emit_event.event_name: produced.n270.release_risk.v2`
- `circuit_breaker.iter_count / max_iter / cooldown / escalation_target`

## Design rules
- Keep release risk forward-looking and mitigation-driven; do not duplicate defect lists unless they change future release risk.
- Score risks with standardized likelihood, impact, score, level, confidence, owner, and mitigation_status fields.
- Consume N005 production signals when present: high-frequency errors, incident postmortems, defect clusters, NPS/user feedback, repeated rollback causes.
- Every high or critical residual risk must map to a mitigation, accepted-risk record, checklist item, rollback condition, or no-go rationale.
- Final go/no-go is decision evidence, not autonomous approval; require explicit approver state for execution.

## Execution workflow
1. Collect release scope, gate posture, diff risk, historical comparable releases, N005 signals, and current mitigations.
2. Score standard risk categories and mark confidence based on evidence completeness.
3. Map mitigations into checklist, rollback, canary, or owner-accepted residual risk records.
4. Emit go/no-go recommendation with rationale, conditions, approval path, and feedback-loop updates.

## Composition behavior
- In full N270 mode, consult `references/n270-routing-and-orchestration-v2.md` before choosing sequence or parallel execution.
- Treat `release_manifest` as the single source of truth when multiple N270 artifacts coexist; update manifest patches before regenerating downstream artifacts.
- Emit a `produced.n270.*.v2` event for finalized artifacts so N330/N340/N350/N390 can subscribe without polling file names.
- If this artifact changes a field consumed by another N270 skill, list that peer skill under `downstream_handoff.refresh_triggers`.

## Self-check gate
- Run the self-check before finalizing. If any release-critical rule fails, `self_check.passed` must be false and readiness cannot be green.
- If the user asks to validate a generated artifact file, run `python scripts/validate_n270_artifact.py <artifact-file>` as a local LLM self-check. Treat this script as a packaged fallback; production-grade validation should run at the artifact contract registry with the canonical schema.
- Record failed rules, blockers, and exact owner/action needed for recovery.

## Quality bar
A good release risk assessment turns uncertainty into scored, owned, mitigated, historically informed, feedback-aware decision evidence.

## Reference files
- `references/n270-artifact-contract-v2.md`
- `references/n270-routing-and-orchestration-v2.md`
- `references/n270-composite-release-manifest-example-v2.md`
- `references/failure-modes.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
- `references/output-template.md`
- `references/risk-assessment-rubric.md`
