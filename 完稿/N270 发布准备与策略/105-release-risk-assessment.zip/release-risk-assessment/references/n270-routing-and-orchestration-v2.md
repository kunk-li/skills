# N270 routing and orchestration v2

## Skill selection
Use the most specific skill first:

| User intent / signal | Primary skill |
|---|---|
| outward-facing release communication, changelog, customer announcement | release-note-generation |
| release-day checklist, dry-run readiness, signoff status, audit checklist | release-checklist-generation |
| internal scope, impact, stakeholder brief, CAB summary, manifest seed | change-summary-generation |
| rollback plan, irreversibility audit, backup/restore evidence, rollback drill | rollback-plan-generation |
| canary rollout, cohort strategy, promotion thresholds, shadow traffic | canary-release-recommendation |
| risk scoring, mitigation mapping, go/no-go evidence, N005 feedback risk | release-risk-assessment |

`canary-release-plan-generation` is an alias. The canonical id is `canary-release-recommendation`.

## Composition patterns
- Minimal standalone: run exactly the skill that matches the requested artifact and keep contract fields stable.
- Fast N270 package: change-summary -> release-note and release-risk in parallel -> rollback and checklist -> canary -> refresh risk if new residual risk appears.
- Safety-first N270 package: change-summary -> release-risk -> rollback -> canary -> checklist -> release-note -> final risk refresh.
- CAB package: change-summary -> release-risk -> rollback -> canary -> checklist -> release-note, then produce the CAB-facing view.

## Closure rules
1. Every high/critical risk mitigation must map to a checklist item, rollback trigger, canary condition, accepted-risk record, or no-go condition.
2. If rollback dry-run evidence is missing for a release-critical phase, checklist readiness must be blocked/red.
3. If canary thresholds are qualitative, promotion_automation must be `review_gate`, not `auto_promote`.
4. If a blocker closes, update release_manifest first and regenerate only the downstream artifacts affected by that changed field.
5. If N005 feedback shows repeated incidents in a release area, release-risk must consume it before canary or checklist are finalized.
6. If any artifact emits readiness red, downstream execution must route to N380/platform_human_queue or an owner-specific SLA queue.

## Parallel and skip rules
- release-note and change-summary can run from the same raw change evidence, but change-summary is preferred as manifest seed in full-node mode.
- rollback and canary can be drafted in parallel only if risk posture and baseline metrics are already available.
- checklist should be refreshed after rollback/canary/risk change because it is the execution state aggregator.
- Any skill can be skipped when the user requests a single artifact; mark skipped peer artifacts in downstream_handoff rather than inventing them.
