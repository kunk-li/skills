# failure modes

| id | failure mode | required response |
|---|---|---|
| `RR-F1` | Confusing defects with forward-looking risks | Use defects as evidence, then express release risk and mitigation status. |
| `RR-F2` | Risk without owner or mitigation | Require owner and mitigation or explicit accepted-risk rationale. |
| `RR-F3` | Ignoring N005 feedback | Consume production signal packages and repeated incident patterns when present. |
| `RR-F4` | Single score without confidence | Add confidence and evidence gaps to every material risk. |
| `RR-F5` | Go/no-go without approval path | Add approver, status, timeout/SLA, and escalation for high or critical risks. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.
