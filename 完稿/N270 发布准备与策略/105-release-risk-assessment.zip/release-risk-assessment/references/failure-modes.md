# failure modes

| id | failure mode | required response |
|---|---|---|
| `RR-F1` | Confusing defects with forward-looking risks | Use defects as evidence, then express release risk and mitigation status. |
| `RR-F2` | Risk without owner or mitigation | Require owner and mitigation or explicit accepted-risk rationale. |
| `RR-F3` | Ignoring feedback feedback | Consume production signal packages and repeated incident patterns when present. |
| `RR-F4` | Single score without confidence | Add confidence and evidence gaps to every material risk. |
| `RR-F5` | Go/no-go without approval path | Add approver, status, timeout/SLA, and escalation for high or critical risks. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.


---

## Degradation — confidence quantification

### Extended rules and contradiction handling

```yaml
confidence_quantification_v3_extended:
  conflicting_dimension_signals:
    example: "code_change_risk: low (small diff) BUT compliance_risk: high (PII touched)"
    action: "Score each dimension independently; composite reflects highest risk"
    note: "Low code_change_risk does NOT lower compliance_risk — dimensions are independent"
  all_dimensions_unknown:
    ceiling: speculative
    composite_risk_score: unknown
    go_no_go: amber_hold  # immutable when all unknown
  circuit_breaker_verbal_bypass:
    trigger: "User says 'skip the circuit breaker'"
    action: refuse
    note: "Circuit breaker threshold immutable; bypass requests rejected"
  stale_evidence:
    trigger: "Evidence older than 7 days for a new deployment"
    ceiling: low  # stale evidence caps at low
    note: "Re-run risk assessment with fresh artifacts before deployment"

### readiness: amber — high risk but below circuit breaker

```yaml
metadata:
  readiness: amber
evidence_profile:
  confidence_ceiling_applied: high
risk_dimensions:
  code_change_risk:    {score: 0.72, confidence: high}
  data_migration_risk: {score: 0.68, confidence: high}
composite_risk_score:
  value: 0.71
  note: "High risk (>0.60) but below circuit_breaker threshold (0.80)"
circuit_breaker:
  triggered: false
  threshold: 0.80
  margin_to_trigger: 0.09
go_no_go_recommendation:
  recommendation: amber_hold
  conditions:
    - "Run additional integration tests targeting data_migration path"
    - "Get DBA sign-off on migration script before proceeding"
self_check:
  passed: true
  warnings: ["amber — composite_risk 0.71 is high; 0.09 below circuit_breaker threshold"]
```
