# Compatibility pointer

This legacy filename is kept for backward compatibility. Use `references/n270-routing-and-orchestration-v2.md` as the canonical routing, composition, and closure-rule reference. Do not load both files for the same task.
