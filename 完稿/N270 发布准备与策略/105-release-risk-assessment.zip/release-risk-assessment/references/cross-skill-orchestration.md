# Compatibility pointer

This legacy filename is kept for backward compatibility. Use `references/release-prep-routing-and-orchestration-v2.md` as the canonical routing, composition, and closure-rule reference. Do not load both files for the same task.


---

## Boundary comparison table — release-risk vs canary vs release-checklist vs rollback

| Dimension | release-risk-assessment | canary-release-recommendation | release-checklist-generation | rollback-plan-generation |
|---|---|---|---|---|
| **Primary question** | "Is this release safe to proceed?" | "What rollout shape minimizes blast radius?" | "Are we operationally ready?" | "How do we reverse if needed?" |
| **Output type** | Risk register with composite score and go/no-go | Progressive rollout plan with stage gates | Pre-deploy readiness checklist with sign-offs | Rollback procedure with phases and triggers |
| **Scope** | Holistic release risk: code, data, infra, dependency, compliance | Rollout-specific: traffic %, cohort, SLO gates | Operational readiness: test pass, oncall, comms | Reversal mechanics: phases, SLA, dry-run |
| **Decision** | Go / amber hold / no-go on the release | Which canary shape and gate thresholds | Are all pre-deploy gates signed off? | Which rollback path and when to trigger |
| **Owns** | Risk scoring across 12 categories, composite risk score, circuit breaker | Stage traffic %, SLO-based auto-halt, abort criteria | Gate items, sign-off tracking, timing markers | Phase ladder, trigger measurement, irreversible_items |
| **Does not own** | Rollout shape (→104), gate tracking (→103), rollback design (→105) | Holistic risk scoring (→101), gate tracking (→103) | Risk scoring (→101), canary design (→104) | Path selection (→121), execution (→108) |

### Routing decision tree
```
User asks...
"How risky is this release?"                        → release-risk-assessment ✓
"Rate risk 1–10"                                    → release-risk-assessment ✓
"Design a gradual rollout plan"                     → canary-release-recommendation
"What do we need to check before deploy?"           → release-checklist-generation
"What happens if we need to roll back?"             → rollback-plan-generation
"What's the blast radius if we proceed?"            → release-risk-assessment ✓ (risk model) + impact-scope-analysis (runtime scope)

Key rule: 101 always runs BEFORE 104. A red from 101 should block 104 execution.
```

---

## Routing decision tree
When unsure which skill to invoke, follow this tree:

```
User question →
  "Should we release?" → release-risk-assessment ✓ YOU ARE HERE
  "How should we roll out?" → canary-release-recommendation
  "What do we need to check?" → release-checklist-generation
  "How do we roll back?" → rollback-plan-generation (105-rollback)
  "What changed?" → change-summary-generation
  "How do we tell users?" → release-note-generation (104-note)

Disambiguation rule: "what risks does the canary plan have?" → route to THIS skill (risk assessment OF a plan)
                     "design a canary plan" → route to canary-release-recommendation
```

---

## Boundary clarification — 12-dimension ownership map

### Which skill owns each risk dimension

| Risk dimension | Primary skill | Supporting skill |
|---|---|---|
| code_change_risk | release-risk-assessment | change-summary supplies change inventory |
| data_migration_risk | release-risk-assessment | config-check for migration-related configs |
| dependency_risk | release-risk-assessment | change-summary supplies dep updates |
| performance_risk | release-risk-assessment | monitoring-metric for baseline SLO |
| rollback_risk | release-risk-assessment | rollback-plan — lower score when plan exists |
| canary_risk | release-risk-assessment | canary — provides blast radius |
| compliance_risk | release-risk-assessment | release-checklist — DPO gate item |
| availability_risk | release-risk-assessment | env-diff — env parity score |
| security_risk | release-risk-assessment | config-check — secret lifecycle |
| ux_risk | release-risk-assessment | impact-scope — affected user count |
| integration_risk | release-risk-assessment | env-diff — service version parity |
| operational_risk | release-risk-assessment | config-check — reload impact |

### When user asks about risk, route rules
```
"Is this release risky?" → 101 ✓
"What's the blast radius?" → 116 (impact-scope)
"Will the canary limit risk?" → 104 (canary design)
"What risks does the config change have?" → 106 (config analysis)
"Is there a compliance risk?" → 101 ✓ (compliance_risk dimension)
```



---

## Composition weight formula (release-prep multi-skill runs)

When multiple release-prep skills contribute to a single `release_manifest`, the composite readiness is computed as:

```
composite_readiness_score =
  Σ (skill_readiness_numeric × skill_weight) / Σ skill_weight

where:
  readiness_numeric: green=1.0, amber=0.5, red=0.0, partial=0.3

skill_weight table (default, adjustable per release type):
  105 release-risk-assessment:         0.30   # Highest — gate driver
  103 rollback-plan-generation:        0.20   # Safety net completeness
  101 release-checklist-generation:    0.15   # Execution readiness
  104 canary-release-recommendation:   0.15   # Rollout safety shape
  100 release-note-generation:         0.10   # Comms completeness
  102 change-summary-generation:       0.10   # Scope clarity
```

**Circuit breaker override:** If **105 readiness = red** OR **103 readiness = red**, the composite readiness is forced to `red` regardless of the weighted average. No weight calculation can override a red from 105 or 103.

**Weight adjustment rule:** For hotfix releases, increase 105 weight to 0.40 and 103 weight to 0.25; reduce 100 to 0.05 and 102 to 0.05, keeping sum = 1.00. Document any weight override in `release_manifest.composition_config.weight_overrides`.



---

## Composition join keys
When multiple release-prep skills contribute to a single `release_manifest`, artifacts are correlated using these join keys:

```yaml
composition_join_keys:
  - release_id                  # unique identifier for the release package
  - schema_version              # must match across all six release-prep artifacts
  - emit_event.event_name       # each artifact emits a distinct v2 event
  - workflow_node: release-prep         # all artifacts share the same workflow node
```

Downstream nodes (release-exec, release-validation, change-tracking) consume release-prep artifacts by referencing `release_id` and verifying `schema_version`. Any release-prep artifact regeneration must emit a `refresh_trigger` listing affected peers.



### readiness: red — no evidence source, all risk items speculative
```yaml
metadata:
  readiness: red
  output_certainty_grade: speculative_only
evidence_profile:
  confirmed: []
  assumed: [risk_items_from_description_only]
risk_register:
  - risk_id: RK-001
    confidence: speculative
    note: "No diff or deployment evidence. All risk items derived from verbal description only."
go_no_go_recommendation:
  verdict: no_go
  reason: "Insufficient evidence to assess risk objectively. Provide diff and deployment context."
self_check:
  passed: false
  failed_rules: ["No evidence source — all risk items speculative"]
```


### readiness: red — composite risk score forces no-go, circuit breaker armed
```yaml
metadata:
  readiness: red
  output_certainty_grade: decision_support_not_hard_gate
composite_risk_score:
  value: 0.91
  threshold: 0.80
  verdict: exceeds_threshold
go_no_go_recommendation:
  verdict: no_go
  reason: "Composite risk 0.91 exceeds threshold 0.80. Three P0 risk items unmitigated."
circuit_breaker:
  armed: true
  trigger_condition: "composite_risk_score > 0.80 AND unmitigated_P0_count > 0"
  escalation_target: [release-manager, engineering-director]
self_check:
  passed: false
  failed_rules: ["Composite risk exceeds threshold — no-go forced"]
```



---

## Boundary comparison table — release-risk precise

| Dimension | release-risk-assessment | configuration-change-check | environment-difference-check | release-checklist-generation |
|---|---|---|---|---|
| **Primary question** | "Is the overall release SAFE?" | "What configs are CHANGING and how?" | "Are staging and prod IN PARITY?" | "Are we READY to start deploying?" |
| **Scope** | Holistic: 12 risk dimensions, composite score | Config-level: CF01-CF08, reload impact | Environment-level: DK1-DK8, parity verdict | Readiness: P0/P1/P2 gate items |
| **Output** | Risk register: composite_score, circuit breaker, go/no-go | Config inventory: kind, reload_mode, secret_lifecycle | Diff register: parity_verdict, env_readiness_score | Checklist: items, timing, sign-off roles |
| **Owns** | Risk scoring, circuit breaker threshold, canary recommendation | Config classification, reload impact, secret detection | Env parity, drift detection, isolation findings | Gate design, timing markers, sign-off role assignment |
| **Does not own** | Config details (→106) · Env parity (→107) · Gate design (→103) · Execution (→108) | Holistic risk (→101) · Env parity (→107) | Config change impact (→106) · Holistic risk (→101) | Risk scoring (→101) · Execution (→108) |

### When to call 101 vs its neighbors
```
"Is this release risky overall?"         → 101 ✓
"What config changes are included?"       → 106
"Is staging aligned with prod?"           → 107
"What gates must be signed before deploy?"→ 103
101 consumes 106+107 as inputs
101 output feeds 103+104+108
```

