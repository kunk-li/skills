# N270 composite release_manifest example v2

```yaml
release_manifest:
  manifest_version: n270.release_manifest.v2
  release_identity:
    version: v1.5.0
    release_train: 2026-04-week4
    target_release_window: 2026-04-29T18:00:00+09:00/PT2H
    release_manager: release_manager
  change_inventory:
    - change_id: CHG-001
      title: idempotent order creation
      source_refs: [PR-1234, TASK-456]
      scope: order-api
      change_type: feat
      breaking_flag: false
      migration_required: true
      risk_level: medium
      owner: order-platform
  quality_gate_snapshot:
    gate_result: conditional_go
    blockers: []
    conditions: [rollback_dry_run_required]
  risk_register:
    - risk_id: RISK-001
      category: data_integrity_risk
      likelihood: medium
      impact: high
      risk_level: high
      mitigation_actions: [pre-release backup, canary 5 percent, data consistency check]
      mitigation_status: in_progress
      owner: order-platform
  rollback_assets:
    - phase: db_migration_rollback
      readiness: amber
      dry_run_evidence_ref: missing
      time_window: T+24h
  canary_strategy:
    pattern: conservative
    promotion_automation: review_gate
    stages: [1%, 5%, 25%, 50%, 100%]
  release_checklist_state:
    - item_id: PRE-ROLLBACK-001
      description: complete rollback dry-run
      blocking: true
      owner: release_manager
      status: blocked
  handoff_targets: [N280, N290, N360]
```
