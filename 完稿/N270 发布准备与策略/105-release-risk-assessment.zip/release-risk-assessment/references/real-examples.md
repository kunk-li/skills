# real-examples — release-risk-assessment

These examples illustrate how to produce this skill's artifact under different evidence conditions.
Use them as output calibration references — not as templates to copy verbatim.

---

## Example 1: Minimum viable input — readiness: partial (verbal description only)

**Scenario:** Release manager describes the release verbally. No PRs, no diffs, no change inventory artifact.

**Input given:**
- "We're releasing payment-service v2.3 this Friday. It includes a DB migration and two new API endpoints."

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  selected_mode: risk_assessment
  evidence_profile:
    confirmed: [verbal_description]
    missing_evidence:
      - change_summary artifact (102) — cannot score code_change_risk without diff
      - rollback_plan artifact (103) — cannot score rollback_risk
      - test_coverage_report — cannot score performance_risk or availability_risk
    missing_evidence_impact: "6 of 12 risk dimensions are estimated from verbal input; composite_score is a rough lower bound only."
  output_certainty_grade: decision_support_not_hard_gate
risk_register:
  - risk_id: RR-001
    category: data_migration_risk
    likelihood: high       # DB migration confirmed verbally
    impact: high
    risk_score: 0.72
    risk_level: high
    confidence: medium
    mitigation_actions:
      - action: "Verify rollback plan covers DB migration (schema revert + DBA approval)"
        owner: DBA team
    mitigation_status: pending
  - risk_id: RR-002
    category: code_change_risk
    likelihood: medium
    impact: medium
    risk_score: 0.40
    risk_level: medium
    confidence: low         # no diff available; estimated from "2 new API endpoints"
    mitigation_actions:
      - action: "Provide PR diff to 102 (change-summary-generation) for precise scoring"
    mitigation_status: pending
composite_risk_score: 0.55  # estimated; should be re-run after evidence is gathered
go_no_go_recommendation:
  recommendation: amber
  canary_recommended: true
  rationale: "DB migration elevates data_migration_risk to high. composite_score estimated at 0.55 — amber gate."
circuit_breaker:
  triggered: false
  note: "Circuit breaker not triggered; estimated score < 0.80. Re-assess after missing evidence gathered."
downstream_handoff:
  missing_evidence: [change_summary_102, rollback_plan_103]
  next_best_checks:
    - "Run change-summary-generation (102) on the PR set to score code_change_risk precisely"
    - "Run rollback-plan-generation (103) to score rollback_risk"
self_check:
  passed: false
  failed_rules:
    - "6 of 12 risk dimensions scored from verbal input only — confidence ceiling: medium"
```

**Key calibration:** Produce a partial artifact with all 12 dimensions attempted. Never refuse because change_summary artifact is absent.

---

## Example 2: Full evidence — readiness: green (composite_score 0.38, low risk)

**Scenario:** Release with full change inventory, test coverage, no migrations, rollback plan confirmed.

**Input given:**
- `变更摘要.md`: 3 PRs, code changes only, no DB migration, no breaking API changes
- Test coverage: 91% unit, 87% integration, 0 flaky tests in last 14d
- `回滚预案.md`: phase_1 image rollback rehearsed, SLA 3min
- Historical incident rate: 0 incidents in last 30 releases for this service

**Expected output shape:**
```yaml
metadata:
  readiness: green
  selected_mode: risk_assessment
  evidence_profile:
    confirmed: [change_summary_102, rollback_plan_103, test_coverage, incident_history]
    missing_evidence: []
  output_certainty_grade: decision_support_not_hard_gate
risk_register:
  - risk_id: RR-001
    category: code_change_risk
    likelihood: low
    impact: low
    risk_score: 0.15
    risk_level: low
    confidence: high
  - risk_id: RR-002
    category: data_migration_risk
    likelihood: none
    impact: none
    risk_score: 0.00
    risk_level: none
    confidence: high
  - risk_id: RR-003
    category: rollback_risk
    likelihood: low
    impact: low
    risk_score: 0.12
    confidence: high   # dry_run confirmed
  # ... remaining 9 dimensions all low
composite_risk_score: 0.38
go_no_go_recommendation:
  recommendation: go
  canary_recommended: false
  rationale: "All 12 dimensions scored low. composite_score 0.38 is well below amber threshold (0.60). Direct rollout acceptable."
circuit_breaker:
  triggered: false
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      summary: "Green: composite 0.38. No canary required. Proceed to release-exec."
self_check:
  passed: true
  warnings: []
```

---

## Example 3: Circuit breaker triggered — readiness: red (composite_score 0.83)

**Scenario:** Large release: schema breaking change, 3rd-party dependency upgrade with known CVE, 0 DB rollback evidence.

**Input given:**
- Schema breaking change: removed `user_id` field from `orders` table
- Dependency: `crypto-lib v3.1.2` upgraded, CVE-2026-0034 (CVSS 8.1) partially mitigated
- Rollback: no schema revert plan, DBA sign-off absent
- Test coverage: 72% (below 80% threshold)

**Expected output shape:**
```yaml
metadata:
  readiness: red
  selected_mode: risk_assessment
  evidence_profile:
    confirmed: [change_summary_102, security_scan]
    missing_evidence: [rollback_plan_103, dba_approval]
risk_register:
  - risk_id: RR-001
    category: data_migration_risk
    likelihood: high
    impact: critical
    risk_score: 0.90
    risk_level: critical
    confidence: high
    mitigation_actions:
      - action: "Design and rehearse schema rollback plan before deployment"
        owner: DBA team
        blocking: true
    mitigation_status: unresolved
  - risk_id: RR-002
    category: security_risk
    likelihood: medium
    impact: high
    risk_score: 0.72
    risk_level: high
    confidence: high
    mitigation_actions:
      - action: "Obtain security team sign-off on CVE-2026-0034 partial mitigation"
        blocking: true
    mitigation_status: pending
  - risk_id: RR-003
    category: rollback_risk
    likelihood: high
    impact: high
    risk_score: 0.85
    risk_level: high
composite_risk_score: 0.83
go_no_go_recommendation:
  recommendation: no_go
  canary_recommended: false
  rationale: "composite_score 0.83 > 0.80 circuit breaker ceiling. Two critical blockers: schema rollback absent, CVE unresolved."
circuit_breaker:
  triggered: true
  trigger_reason: "composite_risk_score 0.83 exceeds hard ceiling 0.80"
  blocking_skills: [canary-release-recommendation, release-task-orchestration]
  resolution_path:
    - "Resolve RR-001: produce rollback-plan-generation (103) with DBA sign-off for schema revert"
    - "Resolve RR-002: obtain security team written exception or upgrade to patched crypto-lib version"
    - "Re-run release-risk-assessment (105) after both blockers resolved"
downstream_handoff:
  urgency: escalate
  blocked_skills: [canary-release-recommendation, release-task-orchestration, release-checklist-generation]
self_check:
  passed: false
  failed_rules:
    - "circuit_breaker triggered: composite_risk_score 0.83 > 0.80"
    - "2 critical blockers unresolved"
```

**Key calibration:** When circuit breaker fires, explicitly name every blocked downstream skill and provide the resolution path. Never silently return amber when score exceeds 0.80.

---

## Example 4: Hotfix weight override — composite_risk_score 0.64 (amber)

**Scenario:** Hotfix release for P1 incident. Release manager asks for risk assessment with hotfix weighting.

**Input given:**
- Hotfix: 8-line null-check fix in `checkout-service`
- Incident: active P1, checkout 35% error rate
- Rollback: image rollback confirmed (1min SLA)
- Weight override requested: hotfix mode

**Key calibration:**
```yaml
composition_config:
  weight_overrides:
    mode: hotfix
    release-risk-assessment: 0.40   # increased per hotfix rule
    rollback-plan-generation: 0.25  # increased
    release-note-generation: 0.05   # reduced (comms less critical for hotfix)
    change-summary-generation: 0.05 # reduced
  weight_override_rationale: "Hotfix mode: rollback readiness and risk score are highest priority"
risk_register:
  - risk_id: RR-001
    category: code_change_risk
    likelihood: low
    impact: medium
    risk_score: 0.30
    confidence: high    # 8-line null-check, well-scoped
  - risk_id: RR-002
    category: availability_risk
    likelihood: low
    impact: low
    risk_score: 0.15
    note: "Incident already at 35% error rate; hotfix risk is low relative to current state"
composite_risk_score: 0.64   # amber — driven by ongoing incident context, not code risk
go_no_go_recommendation:
  recommendation: amber
  canary_recommended: false
  rationale: "Hotfix mode: code change risk low (0.30), rollback confirmed. Amber due to active incident context. Recommend direct hotfix with immediate post-deploy PRV."
```

**Key calibration:** In hotfix mode, document the weight override and rationale. Availability risk is assessed relative to current degraded state, not baseline.

---

## Example 5: Compliance-blocked release — GDPR audit trail missing

**Scenario:** Release modifies user data retention logic. DPO sign-off required but absent.

**Key calibration:**
```yaml
risk_register:
  - risk_id: RR-COMP-001
    category: compliance_risk
    likelihood: certain
    impact: critical
    risk_score: 0.95
    confidence: high
    mitigation_actions:
      - action: "Obtain DPO structured sign-off (not verbal) before deployment"
        blocking: true
        owner: DPO / Legal
    mitigation_status: unresolved
go_no_go_recommendation:
  recommendation: no_go
  canary_recommended: false
  rationale: "Compliance blocker (GDPR): DPO sign-off absent for data retention change. No canary shape resolves a compliance gate."
circuit_breaker:
  triggered: true
  trigger_reason: "compliance_risk: DPO sign-off absent for regulated data change"
  note: "Circuit breaker can trigger on category-specific critical risk even if composite_score < 0.80"
```

**Key calibration:** Compliance blockers can trigger circuit breaker regardless of composite_score. Document the category-specific trigger explicitly.


---

## Mock fixture — test artifact examples

### mock_input: minimal (Tier 1)
```yaml
mock_input:
  scenario: "tier_1_minimal"
  input_description: "Single PR with title only"
  pr_title: "Add retry logic to payment service"
  services_affected: [payment-service]
expected_output:
  readiness: amber
  composite_risk_score: {value: unknown}
  go_no_go_recommendation: {recommendation: amber_hold}
  confidence: speculative
```

### mock_input: high risk (circuit breaker)
```yaml
mock_input:
  scenario: "high_risk_circuit_breaker"
  change_summary_ref: "CHG-20260521-RISK"
  risk_signals:
    - "3 breaking API changes"
    - "DB schema migration on 50M row table"
    - "No rollback plan provided"
expected_output:
  composite_risk_score: {value: ">0.80"}
  circuit_breaker: {triggered: true}
  go_no_go_recommendation: {recommendation: no_go}
  readiness: red
```

