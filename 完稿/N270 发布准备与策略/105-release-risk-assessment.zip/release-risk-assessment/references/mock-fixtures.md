## Mock input fixture

```yaml
mock_input:
  source: "single_diff_file"
  content: "Helm values diff: image.tag v2.1.2 → v2.1.3 (patch version bump)"
  expected_output_shape:
    risk_dimensions:
      min_entries: 3
    composite_risk_score:
      confidence: low  # single diff, limited evidence
    go_no_go_recommendation:
      recommendation: amber_hold  # insufficient evidence for green
    self_check:
      passed: true
      warnings: ["Single diff assessment — confidence low"]
```
