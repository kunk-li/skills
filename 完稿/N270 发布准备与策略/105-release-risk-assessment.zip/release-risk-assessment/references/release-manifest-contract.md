# release_manifest contract v2

Use a stable shared structure across all N270 skills. In standalone mode, create only the slices supported by evidence and mark missing slices explicitly.

## Minimum keys
- `manifest_version: n270.release_manifest.v2`
- `release_identity`
- `change_inventory[]`
- `quality_gate_snapshot`
- `risk_register[]`
- `release_checklist_state[]`
- `rollback_assets[]`
- `canary_strategy`
- `artifact_events[]`
- `handoff_targets`

## Change inventory row
| field | meaning |
|---|---|
| change_id | stable identifier |
| title | short change label |
| source_refs | commits, PRs, tickets, tasks, or assumptions |
| scope | module or business area |
| change_type | feat / fix / perf / refactor / docs / chore / ops |
| breaking_flag | yes / no / unknown |
| migration_required | yes / no / unknown |
| risk_level | low / medium / high / critical / unknown |
| owner | accountable person or team |

## Status conventions
`not_started`, `in_progress`, `done`, `blocked`, `waived`, `not_applicable`, `pending_review`.

## Event conventions
Append a compact entry to `artifact_events[]` whenever a skill emits a produced event.
