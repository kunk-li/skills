# N270 artifact contract v2

This file is the local self-contained mirror of the N270 shared contract layer. In a platform deployment, keep one canonical copy in the artifact contract registry and treat this file as a packaged fallback.

## Required envelope
Every N270 artifact must expose these fields near the top of the output:

```yaml
metadata:
  skill_id: <canonical skill id>
  schema_version: n270.<artifact>.v2
  artifact_version: 2.0.0
  artifact_type: <artifact type>
  workflow_node: N270
  stage_position: release_and_delivery.release_preparation.<skill>
  node_artifact_target: <official artifact file name>
  selected_mode: <mode>
  output_certainty_grade: authoritative_artifact | decision_support_not_hard_gate
  readiness: green | amber | red
  evidence_profile:
    confirmed_evidence: []
    assumptions: []
    missing_evidence: []
  emit_event:
    event_name: produced.n270.<artifact>.v2
    event_version: 2
    producer_skill: <skill id>
    payload_contract: n270_artifact_event.v2
  circuit_breaker:
    source_loop: N310_to_N270 | manual | none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager
  downstream_handoff:
    primary_consumers: [N280, N290, N360]
    consumed_fields: []
    missing_evidence_blocks: []
    manual_decisions_required: []
    refresh_triggers: []
  self_check:
    passed: true | false
    failed_rules: []
```

## Readiness and self-check coupling
- `green`: required evidence is present, self_check passes, and no release-critical blockers remain.
- `amber`: usable with conditions; list each condition and owner.
- `red`: do not treat the artifact as execution-ready. Keep the output contract stable, but block downstream execution.
- If `self_check.passed` is false for any release-critical rule, readiness cannot be green.

## Event bus rules
Emit a produced event for every finalized artifact. The event payload should contain metadata, artifact summary, source refs, readiness, blockers, and downstream handoff. Do not emit an execution-success event; these skills produce planning artifacts and recommendations.

## Circuit breaker rules
When this skill is invoked from N310 remediation back to N270, read `orchestration_context.iter_count` if present. If `iter_count >= 3`, do not regenerate the artifact normally; emit a red readiness artifact with escalation to `release_manager` and `platform_human_queue`.

## Output certainty grades
- `authoritative_artifact`: the skill produces a release artifact that downstream workflows may consume after readiness checks.
- `decision_support_not_hard_gate`: the skill produces evidence or recommendation. It must not be treated as autonomous approval without explicit owner signoff.

## Contract change policy
- Treat the N270 v2 artifact envelope as frozen for this v4 maintenance package.
- Any required-field addition, removal, rename, enum change, or event payload change must bump `schema_version` and update all six N270 skills together.
- If the event payload changes, also review `emit_event.event_version` and `payload_contract` compatibility before publishing.
- In package-only deployments, update every local mirror and run the bundle-level shared mirror check before release.
- In platform deployments, update the contract registry first, then refresh packaged fallback mirrors.
- Wording clarifications, examples, compatibility pointers, and local CI helpers do not require a schema bump when required fields stay unchanged.

## Validator positioning
- `scripts/validate_n270_artifact.py` is a lightweight local self-check for LLM-generated artifacts and CI smoke tests.
- Production-grade validation should run at the artifact contract registry or event-bus ingress using the canonical JSON Schema/Pydantic model.
- Do not treat a local regex pass as business approval, release approval, or execution readiness; readiness still depends on evidence, owner signoff, and downstream gates.
