# Quality checklist v2

A strong N270 artifact:
- exposes `schema_version`, `artifact_version`, `emit_event`, and `circuit_breaker`
- declares minimum, primary discriminating, common, and optional inputs
- is explicitly tied to the official N270 output name
- references the shared `release_manifest` without requiring all six N270 artifacts for standalone use
- names blockers, mitigations, owners, SLA, and remaining unknowns directly
- keeps direct-result artifacts separate from decision-support artifacts
- makes downstream use in N280, N290, and N360 obvious
- emits refresh triggers when peer artifacts should be regenerated
