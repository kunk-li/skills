# Quality checklist v2

A strong release-prep artifact:
- exposes `schema_version`, `artifact_version`, `emit_event`, and `circuit_breaker`
- declares minimum, primary discriminating, common, and optional inputs
- is explicitly tied to the official release-prep output name
- references the shared `release_manifest` without requiring all six release-prep artifacts for standalone use
- names blockers, mitigations, owners, SLA, and remaining unknowns directly
- keeps direct-result artifacts separate from decision-support artifacts
- makes downstream use in release-exec, release-validation, and change-tracking obvious
- emits refresh triggers when peer artifacts should be regenerated


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-RELEASER-051 | Every `risk_dimensions` entry with `score: unknown` has `missing_evidence` | conditional key | `self_check.warnings: ["SCR-RELEASER-051: unknown score without missing_evidence"]` |
| SCR-RELEASER-052 | `output_certainty_grade` ∈ {authoritative_artifact, decision_support_not_hard_gate} | enum | `self_check.warnings: ["SCR-RELEASER-052: output_certainty_grade missing"]` |
| SCR-RELEASER-053 | `feedback_signal_candidates` ≥ 1 | count ≥ 1 | `self_check.warnings: ["SCR-RELEASER-053: FSC missing"]` |
| SCR-RELEASER-054 | `composite_risk_score.value` numeric or "unknown" — never absent | key exists | `self_check.failed_rules: ["SCR-RELEASER-054: composite_risk_score.value missing"]` |