## Output language policy
This skill produces output in the language of the user's request unless overridden by operator configuration.

### Rules
| Condition | Output language |
|---|---|
| User writes in Chinese | Chinese (artifact field names stay in English/YAML; prose sections in Chinese) |
| User writes in English | English throughout |
| Mixed input | Match the dominant language of the user's most recent message |
| Operator sets `output_language` in system prompt | Follow operator setting; override user language |

### Artifact field names
YAML field names (`readiness`, `confidence`, `downstream_handoff`, etc.) are always in English regardless of output language. This ensures machine-readability across language contexts.

### Artifact target file names
The `node_artifact_target` file names (e.g., `告警归因.md`, `发布风险评估.md`) are defined by the workflow contract and do not change based on output language.

### Example: Chinese-language output
```yaml
metadata:
  readiness: red
  selected_mode: dedup_only
  # prose sections below in Chinese
evidence_profile:
  missing_evidence:
    - "结构化告警标签（当前覆盖率不足90%）"
  missing_evidence_impact: "标签覆盖不足，无法进行可靠路由。"
downstream_handoff:
  next_best_checks:
    - "为所有服务强制添加结构化告警标签后，重新运行本 Skill"
```
