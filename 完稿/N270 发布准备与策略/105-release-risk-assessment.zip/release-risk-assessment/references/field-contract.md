# Field contract v2

Prefer `references/release-prep-artifact-contract-v2.md` for the full contract. This file remains as a compact backward-compatible summary.

Required metadata additions over v1:
- `schema_version`
- `artifact_version`
- `artifact_type`
- `output_certainty_grade`
- `emit_event`
- `circuit_breaker`

Required downstream handoff additions:
- `consumed_fields`
- `missing_evidence_blocks`
- `manual_decisions_required`
- `refresh_triggers`
- `sla_queue_items` when human confirmation is needed


---

## Field contract — risk_dimension entry

| Field | Required | Values / notes |
|---|---|---|
| `dimension` | yes | one of 12 canonical names |
| `score` | yes | 0.0–1.0 numeric or `"unknown"` |
| `confidence` | yes | ∈ {high, medium, low, speculative} |
| `evidence_basis` | yes | non-empty list or `["none — verbal description"]` |
| `missing_evidence` | if score=unknown | why score is unknown |
| `mitigation_available` | yes | boolean |