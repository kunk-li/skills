# Readiness inheritance v2

Readiness inherits from upstream release-quality quality posture, peer release-prep artifact state, and the skill self-check.

- `green`: release-quality gate is go or conditions are closed; required evidence exists; self_check passes; no release-critical blockers remain.
- `amber`: conditional-go, missing non-critical evidence, accepted residual risk, or manual confirmation still pending.
- `red`: blocker exists, rollback/canary/risk evidence is unsafe, circuit breaker tripped, or self_check has release-critical failures.

If `self_check.passed: false`, readiness cannot be green. If readiness is red, downstream execution must route to owner escalation, notifications, or the SLA human queue.
