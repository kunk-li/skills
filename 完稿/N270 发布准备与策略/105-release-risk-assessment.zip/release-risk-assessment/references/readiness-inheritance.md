# Readiness inheritance v2

Readiness inherits from upstream N260 quality posture, peer N270 artifact state, and the skill self-check.

- `green`: N260 gate is go or conditions are closed; required evidence exists; self_check passes; no release-critical blockers remain.
- `amber`: conditional-go, missing non-critical evidence, accepted residual risk, or manual confirmation still pending.
- `red`: blocker exists, rollback/canary/risk evidence is unsafe, circuit breaker tripped, or self_check has release-critical failures.

If `self_check.passed: false`, readiness cannot be green. If readiness is red, downstream execution must route to owner escalation, N380, or the SLA human queue.
