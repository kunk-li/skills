# Output template: 发布风险评估.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: release-risk-assessment
  schema_version: n270.release_risk.v2
  artifact_version: 2.0.0
  artifact_type: release_risk_assessment
  workflow_node: N270
  stage_position: release_and_delivery.release_preparation.release_risk_assessment
  node_artifact_target: 发布风险评估.md
  selected_mode: <mode>
  output_certainty_grade: decision_support_not_hard_gate
  readiness: green | amber | red
  function_bias: decision_support.release_risk_scoring_and_mitigation
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.n270.release_risk.v2
    event_version: 2
    producer_skill: release-risk-assessment
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `risk_summary`
- `risk_dimensions[]`
- `risk_register[]`
- `risk_scoring_model`
- `mitigation_mapping[]`
- `cross_release_tracking`
- `n005_feedback_consumption`
- `approval_path`
- `go_no_go_recommendation`
- `decision_rationale`

End with:

```yaml
downstream_handoff:
  primary_consumers: [N280, N290, N360]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```
