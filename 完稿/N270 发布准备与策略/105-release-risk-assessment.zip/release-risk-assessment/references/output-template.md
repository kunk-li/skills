# Output template: 发布风险评估.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: release-risk-assessment
  schema_version: release-prep.release_risk.v2
  artifact_version: 2.0.0
  artifact_type: release_risk_assessment
  workflow_node: release-prep
  stage_position: release_and_delivery.release_preparation.release_risk_assessment
  node_artifact_target: 发布风险评估.md
  selected_mode: <mode>
  output_certainty_grade: decision_support_not_hard_gate
  readiness: green | amber | red
  function_bias: decision_support.release_risk_scoring_and_mitigation
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.release-prep.release_risk.v2
    event_version: 2
    producer_skill: release-risk-assessment
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `risk_summary`
- `risk_dimensions[]`
- `risk_register[]`
- `risk_scoring_model`
- `mitigation_mapping[]`
- `cross_release_tracking`
- `n005_feedback_consumption`
- `approval_path`
- `go_no_go_recommendation`
- `decision_rationale`

End with:

```yaml
downstream_handoff:
  primary_consumers: [release-exec, release-validation, change-tracking]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```


---

## Downstream handoff YAML templates

### 正常路径: risk assessment → canary-release-recommendation + release-checklist
```yaml
downstream_handoff:
  produced_by: release-risk-assessment
  artifact: 发布风险评估.md
  emit_event:
    event_name: produced.release-prep.release_risk_assessment.v2
    event_delivery: declared_only
  handoffs:
    - target: canary-release-recommendation
      handoff_type: evidence
      summary: "composite_risk_score: 0.52 (amber). Recommend canary rollout starting at 5%."
      required_fields:
        - composite_risk_score
        - go_no_go_recommendation
        - circuit_breaker
        - risk_dimensions
      confidence: medium
      next_best_checks:
        - "104: use risk_dimensions.availability_risk to set auto_halt thresholds"
        - "104: composite_risk_score 0.52 → recommend 3-stage canary (not 2-stage)"
    - target: release-checklist-generation
      handoff_type: evidence
      summary: "Risk identified: data_migration_risk: medium → add DBA sign-off P0 gate"
      required_fields: [risk_dimensions.data_migration_risk, risk_dimensions.compliance_risk]
      confidence: medium
      next_best_checks:
        - "103: add P0 checklist item for DBA approval (data_migration_risk: medium)"
  refresh_triggers:
    - skill: canary-release-recommendation
      reason: "Risk score updated — canary thresholds must be recalibrated"
      condition: "composite_risk_score changed by > 0.1 since 104 consumed this"
```

### 高风险路径: composite_risk_score > 0.80 → NO-GO
```yaml
downstream_handoff:
  handoffs:
    - target: canary-release-recommendation
      handoff_type: gap
      summary: "BLOCKER: composite_risk_score 0.87 > 0.80 threshold. DO NOT proceed to 104."
      blocking: true
    - target: release-checklist-generation
      handoff_type: gap
      summary: "HIGH RISK: add mandatory risk_review gate before any deployment tasks"
      blocking: false
```


---

## Standalone guarantee
This skill runs with a single diff file or change description. Never refuse because full quality gate snapshots or PR history are absent.

### Field contract — risk_dimensions row

| Field | Required | Values / notes |
|---|---|---|
| `dimension` | yes | change_scope / test_coverage / historical_defect_rate / dependency_risk / infrastructure_risk / rollback_safety / time_risk |
| `score` | yes | 0.0–1.0 (higher = riskier); `unknown` if evidence absent |
| `confidence` | yes | high / medium / low / speculative |
| `evidence_refs` | yes | list of input sources; empty list `[]` if none |
| `missing_evidence` | if score=unknown | what is needed to compute score |
| `mitigation` | if score ≥ 0.7 | concrete risk mitigation action |

### Scenario calibration
See `references/real-examples.md` for quick_risk_scan (single diff), full multi-skill assessment, and circuit-breaker no_go scenarios.

For risk dimension rubrics and scoring anchors, see `references/risk-assessment-rubric.md`.
For composite score formula and circuit breaker rules, see the composition weight formula section in this SKILL.md.

---

## Output completeness rule
Every risk assessment artifact MUST include ALL of:
- `risk_dimensions` with all 12 entries (score may be `"unknown"`)
- `composite_risk_score.value` numeric 0.0–1.0 or `"unknown"` with `missing_dimensions` count
- `composite_risk_score.scoreable_dimensions` integer
- `go_no_go_recommendation.recommendation` ∈ {go, amber_hold, no_go}
- `circuit_breaker` section (triggered: true/false + threshold declared)
- `downstream_handoff` to ≥ 2 skills with typed `handoff_type`
- `consumer_impact_assessment` (may have `breaking_changes_present: false`)
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 with `signal_type`
- `output_certainty_grade` ∈ {authoritative_artifact, decision_support_not_hard_gate}

---

## Mode selection

### New: `multi_service_risk` mode — 多服务协同发布风险评估
**Trigger:** Release spans 3+ services with interdependencies, or user says "risk assessment for coordinated deployment", "multi-service release risk".

```yaml
multi_service_risk:
  services: [payment-service, auth-service, notification-service]
  per_service_risk:
    - service: payment-service
      code_change_risk: 0.65
      data_migration_risk: 0.30
      primary_risk_factor: "3 API breaking changes"
    - service: auth-service
      code_change_risk: 0.25
      dependency_risk: 0.40
      primary_risk_factor: "JWT library major upgrade"
    - service: notification-service
      code_change_risk: 0.15
      primary_risk_factor: "Minor feature addition"
  cross_service_risks:
    - risk: "auth-service JWT change breaks payment-service token validation"
      severity: high
      mitigation: "Deploy auth-service first; run integration tests before payment-service"
  aggregate_risk:
    composite: 0.58
    highest_risk_service: payment-service
    recommended_sequence: [auth-service, payment-service, notification-service]
  go_no_go_recommendation:
    recommendation: amber_hold
    reason: "auth→payment dependency requires careful sequencing"
```
**SCR:** `selected_mode: multi_service_risk` → `multi_service_risk.cross_service_risks` present; `recommended_sequence` declared.

---

## Downstream handoff

### 正常路径: amber_hold/go → 104 + 103 + 108
```yaml
downstream_handoff:
  produced_by: release-risk-assessment
  artifact: 发布风险评估.md
  emit_event:
    event_name: produced.release-prep.risk_assessment.v2
  handoffs:
    - target: canary-release-recommendation
      handoff_type: evidence
      summary: "composite_risk_score: 0.52. Canary recommended. Highest risk: code_change (0.72)."
      required_fields: [composite_risk_score, go_no_go_recommendation, risk_dimensions]
      confidence: high
      next_best_checks:
        - "104: calibrate stage_1 to 1% given code_change_risk=0.72"
        - "104: use slo_triplets to set auto-halt thresholds"
    - target: release-checklist-generation
      handoff_type: evidence
      summary: "Risk profile ready. Checklist should include: DBA approval (data_migration_risk=0.65)."
      required_fields: [risk_dimensions, composite_risk_score]
      next_best_checks:
        - "103: add P0 gate for DBA sign-off"
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "Risk assessment complete. circuit_breaker threshold: 0.80."
      confidence: high
  refresh_triggers:
    - skill: canary-release-recommendation
      reason: "Risk score changed — canary thresholds must be recalibrated"
      condition: "composite_risk_score changed by > 0.1 or new dimension scored"
    - skill: release-checklist-generation
      reason: "Risk profile updated — checklist gates may need revision"
      condition: "any risk_dimension score changed by > 0.15"
    - skill: release-task-orchestration
      reason: "Risk updated — circuit_breaker threshold recalculation needed"
      condition: "composite_risk_score crosses 0.8 threshold"
```

### 熔断路径: no_go → 阻断所有下游
```yaml
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      handoff_type: gap
      blocking: true
      summary: "CIRCUIT BREAKER: composite_risk=0.87 > 0.80. Do NOT start 108."
    - target: canary-release-recommendation
      handoff_type: gap
      blocking: true
      summary: "NO_GO: canary plan not applicable when overall risk blocked"
```

