# release-risk-assessment — feedback loop protocol

## Retrospective integration
After each release, compare predicted output vs actual release outcome.

### Signal types and corresponding actions
| Signal type | Trigger | Action |
|---|---|---|
| `false_positive` | Output flagged an issue that had no real impact | Add calibration note to real-examples.md; review relevant SCR |
| `false_negative` | Output missed an issue that caused a problem | Add to failure-modes.md; add new SCR; file patch bump |
| `wrong_confidence` | Confidence label did not reflect actual quality | Update confidence_ceiling_rule; add calibration example |
| `correct` | Output accurately predicted outcome | Add green-path example to real-examples.md |

## feedback_signal_candidates schema
Every output artifact MUST include at least one entry:
```yaml
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: wrong_confidence | false_positive | false_negative | correct
    description: "What to verify post-release"
    verification_method: "How to confirm outcome"
    priority: P1 | P2
    status: pending  # updated to 'verified' or 'deferred' post-release
```

## Version bump triggers
- 3+ `false_negative` for same dimension within 90 days → patch bump; add SCR
- New release type or platform → minor bump; add Mode
- Output schema field renamed → major bump; migration guide required

## Consumer impact protocol
Before any version change, assess impact on downstream consumers:
```yaml
consumer_impact_assessment:
  changed_field: "{field name}"
  affected_consumers:
    - skill: "{downstream skill}"
      field_consumed: "{field}"
      action_required: true | false
  notification_method: downstream_handoff.refresh_triggers
```


---

## Feedback loop — release outcome integration

### Release outcome → risk model calibration
After every release, compare the predicted risk level to the actual outcome:

```yaml
outcome_integration:
  release_id: payment-service-v2.1.3
  predicted_risk_level: amber      # what this skill output before release
  actual_outcome: incident         # what happened: success | degraded | incident | rollback
  incident_ref: INC-2026-0520
  
  # Calibration signal
  feedback_signal:
    signal_id: FSC-001
    signal_type: false_negative    # predicted amber, actual was incident-level
    description: "Risk model missed DB connection pool exhaustion risk (change was CF01→should have been CF08)"
    root_cause: "db.pool.max-size change not classified as resource_limits risk dimension"
    calibration_action:
      update_target: "references/risk-assessment-rubric.md"
      add_rule: "CF01 changes that reduce pool/connection limits → auto-elevate to availability_risk: high"
      version_bump: "patch (v2.5.1)"
    
  verification_date: "2026-05-21"
  verified_by: release-manager
```

### Risk model improvement cycle
```yaml
improvement_cycle:
  trigger: "3+ false_negative signals for same risk_dimension in 90-day window"
  action:
    1: "Re-review all risk_dimension scoring rubrics in references/risk-assessment-rubric.md"
    2: "Add new calibration example to references/real-examples.md"
    3: "Consider minor version bump if enum values change"
  owner: risk-model-maintainer
  cadence: quarterly_review_mandatory
```