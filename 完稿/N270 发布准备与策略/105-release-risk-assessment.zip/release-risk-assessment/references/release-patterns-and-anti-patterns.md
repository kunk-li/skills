# release-patterns-and-anti-patterns

Common release patterns and failure modes observed across release-prep skill outputs.

## Recommended patterns

### P01: Risk-gated canary with automatic rollback
Start with ≤5% traffic, measure baseline-derived thresholds, and promote only when
all promotion metrics pass for the full hold_duration. Wire rollback to rollback-plan
triggers automatically.

```yaml
stage_plan:
  - stage_id: S-01
    traffic_pct: 5
    hold_duration: PT15M
    promotion_metrics: [error_rate_p99, latency_p99_ms, business_conversion_rate]
    abort_conditions:
      - error_rate_p99 > 1.5x_baseline
      - latency_p99_ms > 1.3x_baseline
    human_approval_required: false
```

### P02: Checklisted rollback with SLA commitment
Every deployment must have a tested rollback procedure with a named owner and a
committed rollback SLA. Untested rollbacks must be escalated before deploy.

```yaml
rollback_plan:
  rollback_sla: 5min
  tested_rollback: true
  test_evidence: staging-rollback-2024-01-15
  rollback_owner: sre-oncall
```

### P03: Audience-aware release notes
Release notes must address at minimum two audiences: end users (what changes for them)
and operations (what the on-call team must know). A single narrative fails both.

## Anti-patterns

### AP01: Missing baseline for canary thresholds (risk: silent failure)
Setting static thresholds without baseline data means normal traffic variance can
trigger false-positive aborts or, worse, real regressions go undetected.
- **Mitigation:** Always collect ≥7-day same-weekday baseline before setting thresholds.

### AP02: Change summary written after the deploy (risk: misattribution)
Creating change summaries from memory post-deploy leads to omitted changes and
misattributed incidents. Always generate from PR/diff evidence before deploy.

### AP03: Sign-off collected informally (risk: audit gap)
Verbal or chat-based sign-offs cannot be referenced in post-incident reviews.
Always capture sign-off as a structured record with role, name, and timestamp.

### AP04: Rollback plan with untested stateful rollback (risk: data loss)
When a DB migration is involved, rolling back the service without coordinating the
DB state leads to data corruption. Never deploy without a tested DB rollback path.

### AP05: Risk assessment without diff evidence (risk: false confidence)
A risk assessment based only on a verbal description cannot catch unknown blast
radius or dependency coupling. Always require at least a diff summary as evidence.

## Sequencing failures

| Failure | Root cause | Correct order |
|---|---|---|
| Checklist references undefined gate | Checklist generated before risk assessment | 101 → 102 → 103 |
| Rollback triggers don't match risk blockers | Rollback designed before risk assessment | 101 → 105 |
| Release notes incomplete | Notes generated before full change summary | 102 → 104 |
| Canary aborts on valid traffic | Thresholds set without baseline | Collect baseline → 100 |

## Confidence calibration

| Evidence available | Max confidence for any release-prep output |
|---|---|
| Verbal description only | speculative |
| PR description or diff | low |
| PR + risk assessment | medium |
| PR + risk + deployment history + tests | high |
