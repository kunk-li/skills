#!/usr/bin/env python3
"""Validate an N270 artifact envelope for v2 fields.

Usage:
  python scripts/validate_n270_artifact.py path/to/artifact.md

The validator is intentionally lightweight: it checks that the artifact text exposes the
contract-critical keys that N270 downstream routing and event emission rely on.
It is for local LLM self-check and CI smoke tests only. Production-grade validation
should run at the artifact contract registry or event-bus ingress with the canonical schema.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

REQUIRED_KEYS = [
    "schema_version",
    "artifact_version",
    "artifact_type",
    "workflow_node",
    "selected_mode",
    "output_certainty_grade",
    "readiness",
    "evidence_profile",
    "emit_event",
    "circuit_breaker",
    "downstream_handoff",
    "self_check",
]

VALID_READINESS = {"green", "amber", "red"}


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: validate_n270_artifact.py <artifact-file>")
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        print(f"ERROR: artifact not found: {path}")
        return 2
    text = path.read_text(encoding="utf-8")
    missing = [key for key in REQUIRED_KEYS if re.search(rf"\b{re.escape(key)}\b\s*:", text) is None]
    readiness = re.search(r"\breadiness\b\s*:\s*([A-Za-z_\-]+)", text)
    readiness_error = False
    if readiness and readiness.group(1).strip().lower() not in VALID_READINESS:
        readiness_error = True

    if missing or readiness_error:
        if missing:
            print("MISSING_KEYS=" + ",".join(missing))
        if readiness_error:
            print("INVALID_READINESS=" + readiness.group(1))
        return 1
    print("OK: N270 artifact envelope contains required v2 fields")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
