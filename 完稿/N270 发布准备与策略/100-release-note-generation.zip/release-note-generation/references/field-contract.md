# Field contract v2

Prefer `references/release-prep-artifact-contract-v2.md` for the full contract. This file remains as a compact backward-compatible summary.

Required metadata additions over v1:
- `schema_version`
- `artifact_version`
- `artifact_type`
- `output_certainty_grade`
- `emit_event`
- `circuit_breaker`

Required downstream handoff additions:
- `consumed_fields`
- `missing_evidence_blocks`
- `manual_decisions_required`
- `refresh_triggers`
- `sla_queue_items` when human confirmation is needed


---

## Field contract — release_note section entry

| Section | Required | Conditions |
|---|---|---|
| `sections.improvements` | yes | may be `[]` |
| `sections.breaking_changes` | yes | NEVER omitted; may be `[]` |
| `sections.known_issues` | yes | NEVER omitted; may be `[]` |
| `sections.migration_notes` | if breaking_changes non-empty | must have `deadline` + `migration_path` |
| `sections.compliance_section` | Tier 4 only | requires `dpo_sign_off_evidence` |
| `sections.api_changes` | if api_consumer audience | required when api_versioning_summary mode |