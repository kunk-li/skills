# Compatibility pointer

This legacy filename is kept for backward compatibility. Use `references/release-prep-routing-and-orchestration-v2.md` as the canonical routing, composition, and closure-rule reference. Do not load both files for the same task.


---

## Boundary comparison table — release-note vs change-summary vs release-checklist

| Dimension | release-note-generation | change-summary-generation | release-checklist-generation |
|---|---|---|---|
| **Primary question** | "How do we tell users what changed?" | "What changed technically?" | "Are we ready to ship?" |
| **Audience** | External: end users, API consumers, support, compliance | Internal: engineers, SREs, PMs, CAB | Internal: release manager, devops, oncall |
| **Language/Tone** | Plain language, user-benefit framing, no internal jargon | Technical, precise, audience-segmented | Imperative, checklist-style, role-assigned |
| **Required sections** | breaking_changes, improvements, known_issues, migration_notes | change_inventory, audience_views, impact_dimensions | items with priority, sign_off_role, timing_marker |
| **Does not own** | Technical diff (→102), gate items (→103), risk scoring (→101) | External prose (→104), gate tracking (→103) | Change content (→102), narrative (→104) |

### Content boundary enforcement
```
release-note MUST NOT contain:
  ✗ Internal ticket IDs without user context (e.g., "JIRA-4821 fixed" alone)
  ✗ Stack traces or raw error messages
  ✗ Diff stats or file counts
  ✗ Internal team names without context

release-note MUST contain:
  ✓ User-facing description of every change
  ✓ Migration path for every breaking change
  ✓ known_issues section (may be empty list)
  ✓ release_date and version
```

---

## Composition merge strategy
When `release_note` and `change_summary` both patch `release_manifest.change_inventory[]`, apply the following merge priority:
- `release_note` fields win for: `audience_versions`, `publication_channels`, `breaking_changes[]`, `security_updates[]`
- `change_summary` fields win for: `normalized_change_inventory[]`, `impact_quantification`, `decision_support_notes`
- On field collision within the same key, the skill with the higher `artifact_version` timestamp wins; emit `downstream_handoff.manifest_merge_conflict[]` listing every collision.
- `change_summary` content **must never** contain external-audience language (user-benefit framing, marketing tone, public release phrasing). If detected, strip and emit a `self_check.failed_rules` entry: `"change_summary content leaked into external release note"`.



---

## Boundary comparison table — release-note vs all consumers

| Dimension | release-note-generation | change-summary-generation | post-release-validation-checklist | go-live-acceptance-assistant |
|---|---|---|---|---|
| **Primary question** | "How do we communicate changes externally?" | "What changed technically?" | "What must we check after deploy?" | "Did we pass? GO or NO-GO?" |
| **Audience** | External: users, support, API consumers, compliance | Internal: devs, SREs, PMs, CAB | Internal: SRE, devops, oncall (post-deploy) | Internal: release manager, approvers |
| **Output type** | User-facing changelog with migration guides | Normalized change inventory with audience views | PRV item list with checkpoint times | GA decision record with sign-off tracking |
| **Owns** | External narrative, migration guides, known_issues, audience segmentation | Change ID assignment, diff normalization, impact_dimensions | PRV item design, pass/fail criteria, execution results | GA decision authority, criteria evaluation, conditions |
| **Does not own** | Technical diff (→102), PRV design (→109), GA decision (→110) | External prose (→104), PRV (→109), GA (→110) | GA decision (→110), pre-deploy gates (→103), release notes (→104) | PRV design (→109), change analysis (→102) |
| **Typical sequence** | After 102 produces change inventory | Before 104; seeds 104 content | After deploy T+0; before 110 | After 109 collects all PRV results |

### Content boundary enforcement (hard rules)
```
release-note MUST NOT contain:
  ✗ Internal ticket IDs without user context (e.g., "JIRA-4821 fixed" alone)
  ✗ Stack traces, raw error messages, metric values
  ✗ Diff stats, file counts, line change numbers
  ✗ PRV item results or validation outcomes → those go in 109
  ✗ GO/NO-GO decision → that goes in 110

release-note MUST contain:
  ✓ User-facing description for every change
  ✓ Migration path for every breaking change with deadline
  ✓ known_issues section (may be empty [])
  ✓ version + release_date
  ✓ At least one change_link (PR/commit/ticket) per change entry
```



---

## Boundary clarification — release-note within all 23 skills

| Question | Correct skill | Why NOT 104 |
|---|---|---|
| "Summarize changes for engineers" | change-summary-generation | Internal audience |
| "What changed for CAB?" | change-summary-generation cab_brief mode | CAB is internal |
| "Write PRV validation items" | post-release-validation-checklist | Validation ≠ announcement |
| "Issue GA decision" | go-live-acceptance-assistant | Decision ≠ note |
| "List pre-deploy checklist items" | release-checklist-generation | Checklist ≠ note |
| "What risk does this release have?" | release-risk-assessment | Risk ≠ note |
| "Write hotfix emergency communication" | release-note-generation ✓ | hotfix_announcement mode |
| "Write compliance documentation" | release-note-generation ✓ | compliance_view mode |

### Hard timing rule
```
104 is authored ONCE per release cycle:
  - After change-summary-generation produces change inventory
  - Before go-live-acceptance-assistant needs known_issues
  
104 must be RE-AUTHORED if:
  - A new breaking change is discovered post-initial-authoring
  - known_issues changes materially before GA
  
104 must NOT be:
  - A running log of all incidents (→ incident postmortems)
  - A technical design document (→ change-summary engineering view)
```

