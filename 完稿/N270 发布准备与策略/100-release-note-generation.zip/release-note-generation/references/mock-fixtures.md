## Mock input fixture

```yaml
mock_input:
  source: "single_pr_description"
  content: "PR-892: Add retry logic for payment gateway timeouts"
  expected_output_shape:
    release_note:
      sections:
        improvements: present
        known_issues: "[] or populated"
        breaking_changes: "[] — no breaking change in this PR"
      confidence: low
    self_check:
      warnings: ["single PR — note may be incomplete"]
```
