# Quality checklist v2

A strong release-prep artifact:
- exposes `schema_version`, `artifact_version`, `emit_event`, and `circuit_breaker`
- declares minimum, primary discriminating, common, and optional inputs
- is explicitly tied to the official release-prep output name
- references the shared `release_manifest` without requiring all six release-prep artifacts for standalone use
- names blockers, mitigations, owners, SLA, and remaining unknowns directly
- keeps direct-result artifacts separate from decision-support artifacts
- makes downstream use in release-exec, release-validation, and change-tracking obvious
- emits refresh triggers when peer artifacts should be regenerated


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-RELEASEN-051 | `sections.known_issues` key always present (may be `[]`) | key exists | `self_check.failed_rules: ["SCR-RELEASEN-051: known_issues section omitted entirely"]` |
| SCR-RELEASEN-052 | `sections.breaking_changes` key always present (may be `[]`) | key exists | `self_check.failed_rules: ["SCR-RELEASEN-052: breaking_changes section omitted entirely"]` |
| SCR-RELEASEN-053 | `adversarial_detection.injection_attempt_detected` boolean declared | key exists | `self_check.warnings: ["SCR-RELEASEN-053: injection_attempt_detected field missing"]` |
| SCR-RELEASEN-054 | `confidence` ≤ tier ceiling (see D4 section availability table) | tier check | `self_check.warnings: ["SCR-RELEASEN-054: confidence exceeds tier ceiling"]` |