# failure modes

| id | failure mode | required response |
|---|---|---|
| `RN-F1` | Treating uncertain changes as confirmed | Keep assumptions under evidence_profile.assumptions and avoid publication-ready language until confirmed. |
| `RN-F2` | Mixing internal refactors into external notes | Route refactors to internal_version unless there is clear user-visible impact. |
| `RN-F3` | Burying breaking changes | Use prominent breaking_changes[] with migration steps, dates, and affected audience. |
| `RN-F4` | Dropping traceability | Reject or mark amber when change rows lack source_refs. |
| `RN-F5` | Merging future-scope items into current release | Keep future wave content in known_future_changes or exclude from current release notes. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.
