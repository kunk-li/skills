# failure modes

| id | failure mode | required response |
|---|---|---|
| `RN-F1` | Treating uncertain changes as confirmed | Keep assumptions under evidence_profile.assumptions and avoid publication-ready language until confirmed. |
| `RN-F2` | Mixing internal refactors into external notes | Route refactors to internal_version unless there is clear user-visible impact. |
| `RN-F3` | Burying breaking changes | Use prominent breaking_changes[] with migration steps, dates, and affected audience. |
| `RN-F4` | Dropping traceability | Reject or mark amber when change rows lack source_refs. |
| `RN-F5` | Merging future-scope items into current release | Keep future wave content in known_future_changes or exclude from current release notes. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.


---

## Degradation examples

### readiness: amber — 多格式输出时，部分受众版本缺失

```yaml
metadata:
  readiness: amber
  selected_mode: multi_format
evidence_profile:
  confirmed: [change_summary_102, api_consumer_list]
  missing_evidence: [compliance_sign_off, internal_engineering_review]
  confidence_ceiling_applied: medium
release_note:
  formats_completed:
    external_users: complete
    api_consumers: complete
    compliance_auditors: pending  # amber: compliance section needs DPO sign-off
    support_team: pending         # amber: support FAQ not drafted
  amber_reason: "2 of 4 audience formats incomplete"
self_check:
  passed: true
  warnings:
    - "amber — compliance and support formats pending"
    - "Provide DPO sign-off to complete compliance format"
```

### Confidence quantification
```yaml
confidence_quantification_v2:
  tier_1_single_pr:
    ceiling: low
    known_issues: "unverified (no tracker)"
    readiness: partial
  tier_3_with_change_summary:
    ceiling: medium
    known_issues: "sourced from 102 change_summary"
    readiness: amber
  tier_4_full_plus_tracker:
    ceiling: high
    known_issues: "verified from external tracker"
    readiness: ready
  compliance_without_dpo:
    ceiling: low  # never high without structured evidence
    compliance_section: absent
    note: "Compliance section requires DPO sign-off at minimum Tier 4"
```