# Output template: 发布说明.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: release-note-generation
  schema_version: n270.release_note.v2
  artifact_version: 2.0.0
  artifact_type: release_note
  workflow_node: N270
  stage_position: release_and_delivery.release_preparation.release_note_generation
  node_artifact_target: 发布说明.md
  selected_mode: <mode>
  output_certainty_grade: authoritative_artifact
  readiness: green | amber | red
  function_bias: direct_result.release_communication
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.n270.release_note.v2
    event_version: 2
    producer_skill: release-note-generation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `release_note_summary`
- `audience_versions`
- `highlights[]`
- `new_features[]`
- `improvements[]`
- `bug_fixes[]`
- `breaking_changes[]`
- `deprecations[]`
- `security_updates[]`
- `known_issues[]`
- `publication_channels`

End with:

```yaml
downstream_handoff:
  primary_consumers: [N280, N290, N360]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```
