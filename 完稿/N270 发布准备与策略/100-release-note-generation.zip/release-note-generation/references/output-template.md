# Output template: 发布说明.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: release-note-generation
  schema_version: release-prep.release_note.v2
  artifact_version: 2.0.0
  artifact_type: release_note
  workflow_node: release-prep
  stage_position: release_and_delivery.release_preparation.release_note_generation
  node_artifact_target: 发布说明.md
  selected_mode: <mode>
  output_certainty_grade: authoritative_artifact
  readiness: green | amber | red
  function_bias: direct_result.release_communication
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.release-prep.release_note.v2
    event_version: 2
    producer_skill: release-note-generation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `release_note_summary`
- `audience_versions`
- `highlights[]`
- `new_features[]`
- `improvements[]`
- `bug_fixes[]`
- `breaking_changes[]`
- `deprecations[]`
- `security_updates[]`
- `known_issues[]`
- `publication_channels`

End with:

```yaml
downstream_handoff:
  primary_consumers: [release-exec, release-validation, change-tracking]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```


---

## Downstream handoff YAML templates

### 含breaking changes路径: 触发 release-task 消费者通知任务
```yaml
downstream_handoff:
  handoffs:
    - target: go-live-acceptance-assistant
      handoff_type: evidence
      summary: "Release note v2.1.3: 1 breaking change (API response format). known_issues: 1 (PDF timeout)."
      required_fields: [version, sections.breaking_changes, sections.known_issues]
      confidence: medium
    - target: release-task-orchestration
      handoff_type: action_hint
      summary: "1 breaking change requires consumer notification task at T-7d"
      required_fields: [sections.breaking_changes[0].migration_deadline]
      next_best_checks:
        - "108: add T-7d consumer notification task"
        - "108: add T-1d migration guide review gate"
  refresh_triggers:
    - skill: go-live-acceptance-assistant
      reason: "Release note updated after initial GA — re-evaluate known_issues"
      condition: "release_note.version or known_issues changed"
```


---

## Standalone guarantee
This skill runs with a single PR or commit message. Never refuse because a full change summary is absent.

### Minimum standalone example — one PR, external audience
```yaml
metadata:
  readiness: partial
  selected_mode: from_commits_only
  output_certainty_grade: authoritative_artifact
evidence_profile:
  confirmed: [pr_description]
  missing_evidence: [change_summary, risk_assessment]
  missing_evidence_impact: "Release note covers one PR only. Missing PRs will not appear."
release_note:
  version: v2.1.3
  release_type: patch
  release_date: "2026-05-20"
  sections:
    improvements:
      - "Payment checkout now retries automatically on transient gateway errors, reducing failed transactions."
    known_issues: []
    breaking_changes: []
    migration_notes: []
  audience: external
  confidence: low
  missing_content_notice: "This note covers PR-892 only. Additional changes may not be reflected."
downstream_handoff:
  to_skill: go-live-acceptance-assistant
  missing_evidence: [complete_change_inventory]
self_check:
  passed: true
  warnings: ["Single PR input — note may be incomplete. Provide change_summary for full coverage."]
```

### api_consumer_update example — breaking change notice
```yaml
metadata:
  readiness: green
  selected_mode: api_consumer_update
release_note:
  version: v3.0.0
  release_type: major
  sections:
    breaking_changes:
      - change: "POST /v2/payments endpoint removed"
        migration: "Use POST /v3/payments instead. Request body schema is identical; only URL changes."
        migration_deadline: "2026-08-01"
        affected_consumers: [mobile-app, partner-api]
      - change: "Authorization header now required on all /orders endpoints (was optional)"
        migration: "Add 'Authorization: Bearer {token}' to all /orders requests."
        migration_deadline: "2026-08-01"
    deprecation_notices:
      - "GET /v2/users/profile is deprecated. Use GET /v3/users/me. Both available until 2026-08-01."
    improvements:
      - "Response times improved by 40% on /v3/payments due to connection pooling."
```

**Key calibration:** `api_consumer_update` mode must always include `migration` instructions and `migration_deadline` for breaking changes. Never list a breaking change without a migration path.

---

## Output completeness rule
Every release note artifact MUST include ALL of:
- `sections.breaking_changes` key always present (may be `[]`)
- `sections.known_issues` key always present (may be `[]`)
- `metadata.version` declared
- `downstream_handoff` to go-live-acceptance-assistant
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry
- `consumer_impact_assessment` present when breaking_changes non-empty

**Hard rules:**
- `breaking_changes` non-empty → `migration_notes` with `deadline` MUST be present
- `compliance_section` NEVER authored without structured DPO evidence
- `known_issues: []` valid only if external tracker confirms no issues

---

## Mode selection

### New: `api_consumer_update` mode — API消费者专项更新说明
**Trigger:** Release contains API changes that specifically affect API consumers (breaking changes, new endpoints, deprecations), or user says "API changelog for consumers", "developer release notes", "API migration guide".

```yaml
api_consumer_update:
  target_audience: api_consumers
  api_version: "v3.0"
  changes:
    breaking:
      - endpoint: "POST /v2/payments"
        change: "Response field 'transaction_id' renamed to 'payment_id'"
        migration: "Update all references from transaction_id to payment_id"
        sunset_date: "2026-08-21"
        migration_guide_url: "https://docs.example.com/api/v2-to-v3"
    new_endpoints:
      - endpoint: "POST /v3/payments/retry"
        description: "Idempotent payment retry with X-Idempotency-Key header"
        available_from: "2026-05-21"
    deprecated:
      - endpoint: "GET /v1/charges"
        deprecation_date: "2026-05-21"
        removal_date: "2026-11-21"
        replacement: "GET /v3/payments"
  consumer_action_required: true
  migration_urgency: high
  estimated_migration_effort: "2-4 hours per consuming service"
```
**SCR:** `selected_mode: api_consumer_update` → `api_consumer_update.api_version` declared; `changes.breaking` or `changes.deprecated` present; `consumer_action_required` boolean.

---

## Downstream handoff YAML templates

### 正常路径：release note 发布后移交 go-live-acceptance + configuration-change-check
```yaml
downstream_handoff:
  produced_by: release-note-generation
  artifact: 发布说明.md
  emit_event:
    event_name: produced.release-prep.release_note.v2
    event_delivery: declared_only
  handoffs:
    - target: go-live-acceptance-assistant
      handoff_type: evidence
      summary: "Release note v2.1.3: 2 improvements, 0 breaking changes, 1 known issue"
      required_fields: [version, release_type, sections.breaking_changes, sections.known_issues]
      confidence: high
      next_best_checks:
        - "go-live-acceptance: use sections.known_issues as acceptance condition input"
    - target: configuration-change-check     # release-exec node consumer
      handoff_type: evidence
      summary: "Release note contains config change references — consume for reload impact"
      required_fields: [version, sections.improvements]
      confidence: medium
  refresh_triggers:
    - skill: change-summary-generation
      reason: "If change_summary is updated after note generation, re-run release-note-generation"
      condition: "change_summary.artifact_version > release_note.source_change_summary_version"
```

### 破坏性变更路径：通知下游 API 消费者技能
```yaml
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      handoff_type: action_hint
      summary: "Breaking change detected: notify API consumer teams before T-0"
      required_fields: [sections.breaking_changes, sections.migration_notes]
      confidence: high
      next_best_checks:
        - "Add pre-release notification task to release-task-orchestration DAG"
        - "Schedule migration guide review in release checklist"
```

