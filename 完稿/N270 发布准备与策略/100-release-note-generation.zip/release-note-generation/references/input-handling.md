## Large input handling — release artifact strategies

### Token budget management for release artifacts
```yaml
token_budget:
  p0_blockers:    35%   # Critical blockers always processed first
  high_risk:      30%   # Risk score ≥ 0.7 items
  medium_risk:    25%   # Risk score 0.4–0.69 items
  low_risk_summary: 10% # Group and summarize

budget_rule: "A P0 blocker discovered at any point immediately halts low-risk processing."
```

### Skill-specific large input strategies

#### release-risk-assessment: large diff sets
```yaml
large_diff_strategy:
  tier_50_files: "Analyze all files"
  tier_200_files:
    step_1: "Fully analyze: schema migrations, security-related, config CF03/CF05"
    step_2: "Sample application logic (CF01): 1 per service, highest churn file"
    step_3: "Group infrastructure (CF02/CF08) by service; summarize per group"
  tier_over_200_files:
    filter_template: |
      git diff --name-only HEAD~1 | grep -E '\.(sql|yaml|env|secret|pem)$'
      # Security-critical files first; re-invoke with this subset
    expected_reduction: "200 files → ~20 critical files"
```

#### release-checklist-generation: large quality gate snapshots
```yaml
large_checklist_strategy:
  tier_20_items: "Process all checklist items"
  tier_100_items:
    step_1: "Process all P0 items fully"
    step_2: "Group P1 items by category; surface blockers only"
    step_3: "P2 items: emit category summary with count"
  tier_over_100_items:
    filter_template: "Provide only items with status=fail or status=blocked"
    emit_summary: true
```

#### release-note-generation: large PR sets
```yaml
large_pr_strategy:
  tier_20_prs: "Process all PRs"
  tier_100_prs:
    step_1: "Process all breaking_change-labeled PRs fully"
    step_2: "Process all security/hotfix-labeled PRs fully"
    step_3: "Group feature PRs by service; one sentence per group"
  tier_over_100_prs:
    filter_template: |
      gh pr list --label "breaking-change,security,hotfix" --json title,body,number
      # Re-invoke with this filtered set first; expand incrementally
```

### Complete large-input output example (release-prep)
```yaml
evidence_profile:
  input_received:
    pr_count: 147
    services: 8
  grouping_applied: true
  items_fully_reviewed: 12      # breaking-change + security PRs
  items_summarized: 135         # feature PRs grouped by service
  sampling_caveat: "Feature PRs summarized per service. Breaking changes and security PRs fully reviewed."
  filter_template_for_full_analysis: |
    # To get full coverage, re-invoke with:
    gh pr list --label "breaking-change" --json title,body,number > breaking_prs.json
```


---

## Input elasticity — Tier field-level rules

### What each tier unlocks per output section

| Section | Tier 1 (single PR) | Tier 2 (+tickets+labels) | Tier 3 (+change_summary) | Tier 4 (full+compliance) |
|---|---|---|---|---|
| `improvements` | ≤2 inferred | multiple from tickets | complete from 102 | complete+verified |
| `breaking_changes` | inferred_only | labelled if tagged | confirmed from diff | confirmed+DPO reviewed |
| `known_issues` | `[]` (unverified) | from PR labels only | from 102 tracker-linked | from external tracker |
| `migration_notes` | absent | minimal | PR-based with deadline | full with SLA+DPO |
| `compliance_section` | absent | absent | absent | Tier 4 only |
| `audience_views` | engineering_only | engineering+users | all 4 audiences | all 4+compliance |
| `confidence` | low | low-medium | medium | high |

### Hard rules by tier
```yaml
tier_hard_rules:
  tier_1:
    confidence: low  # always; single PR cannot be high
    known_issues: []  # always; cannot verify without tracker
    compliance_section: absent  # always at T1
  tier_4:
    compliance_section: "only authored with structured DPO evidence"
    confidence: high  # only if no contradictions
    known_issues: "must come from external tracker, not PR labels"
  contradiction_rule:
    "breaking_changes_claimed_safe_in_PR_but_diff_shows_breaking":
      resolution: trust_diff
      confidence: medium  # diff available but PR claim contradicts
      note: "diff analysis overrides PR prose claims"
```