---
name: release-note-generation
description: >-
  generate n270 release note artifacts for release preparation with v2 contract metadata, event emission, differentiated inputs, degradation rules, and standalone or composed workflow use. use when chatgpt must produce 发布说明.md, validate release readiness evidence, or participate in the n270 release package.
---
# release-note-generation

## Role
This skill produces the N270 `发布说明.md` artifact. It must remain useful as a standalone skill and must become stronger when combined with other N270 skills through the shared `release_manifest`.

## Boundary
- Own `release_note` for N270; do not re-run upstream N260 quality gates or execute downstream N280 deployment actions.
- Consume upstream evidence and peer N270 artifacts when present, but never require all peer artifacts for standalone use.
- Keep downstream handoff to N280, N290, and N360 explicit, including missing evidence and manual decisions.
- Use `references/n270-artifact-contract-v2.md` as the contract source for metadata, events, readiness, and circuit breaker fields.

## Canonical identity
- `skill_id`: `release-note-generation`
- `schema_version`: `n270.release_note.v2`
- `artifact_version`: `2.0.0`
- `artifact_type`: `release_note`
- `emit_event.event_name`: `produced.n270.release_note.v2`
- `output_certainty_grade`: `authoritative_artifact`

## Maintenance status
- Treat this package as the N270 v4 maintenance build: core schema, event names, readiness model, and circuit-breaker semantics are frozen for normal use.
- Do not add, remove, or rename required contract fields unless the artifact contract version is explicitly bumped and all six N270 skills are updated together.
- Prefer bug fixes, wording clarifications, platform handoff updates, and registry migration notes over new skill behavior.
- In platform deployments, treat local contract mirrors as packaged fallback material; the artifact contract registry and event-bus ingress are the production authorities.

## Mode selection
Every output must declare `selected_mode`, `readiness`, `evidence_profile`, `output_certainty_grade`, and `emit_event` near the top.

Allowed modes:
- `from_commits_only`
- `curated_mode`
- `multi_format`
- `api_consumer_update`

## Inputs
Use a four-tier input model so the skill is independently usable while still benefiting from richer workflow context.

### Minimum viable inputs
- version or release identifier
- at least one PR, commit, ticket, or change row

### Primary discriminating inputs
These inputs distinguish this skill from the other five N270 skills. Prioritize them when available.
- prs_in_release[] with pr_description, labels, commit refs, and ticket refs
- audience_context including internal, external, api_consumer, operator, compliance
- version context with current_version, previous_version, release_type, target date
- breaking/deprecation/security markers from commits, labels, API/schema diffs

### Common N270 inputs
Use these as shared release context, not as the only preferred inputs. Always prefer Primary discriminating inputs; treat Common N270 inputs as last-resort fallback, not the default starting point.
- `开发任务拆分表.csv`
- `PR描述.md`
- `Diff风险点评.md`
- `质量门禁检查单.md`

### Optional enhancement inputs
- i18n_config
- publication channels
- screenshots or docs links
- known issues
- support notes

## Standalone and degradation rules
- Work on one release candidate, service release, hotfix, or release decision slice without requiring the full six-skill package.
- If minimum inputs are present but primary inputs are incomplete, keep the output contract stable and mark missing items under `evidence_profile.missing_evidence` and `downstream_handoff.missing_evidence_blocks`.
- Separate confirmed facts, assumptions, and unknowns. Do not convert unknowns into confident release statements.
- When evidence is insufficient for safe execution, produce a useful artifact with `readiness: amber` or `readiness: red` instead of refusing or inventing details.
- If invoked from N310 remediation and `orchestration_context.iter_count >= 3`, stop normal regeneration, mark readiness red, set cooldown `PT30M`, and escalate to the release manager / SLA human queue.

## Core output contract
Default to Markdown with YAML-like top metadata, or CSV/YAML-friendly tables when the user asks for a machine-readable artifact.

Required top-level sections:
- `metadata`
- `evidence_profile`
- `release_note_summary`
- `audience_versions`
- `highlights[]`
- `new_features[]`
- `improvements[]`
- `bug_fixes[]`
- `breaking_changes[]`
- `deprecations[]`
- `security_updates[]`
- `known_issues[]`
- `publication_channels`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `skill_id: release-note-generation`
- `schema_version: n270.release_note.v2`
- `artifact_version: 2.0.0`
- `artifact_type: release_note`
- `function_bias: direct_result.release_communication`
- `stage_position: release_and_delivery.release_preparation.release_note_generation`
- `workflow_node: N270`
- `node_artifact_target: 发布说明.md`
- `selected_mode`
- `output_certainty_grade: authoritative_artifact`
- `readiness: green | amber | red`
- `tool_collaboration_mode: standalone | composed | validation_only`
- `emit_event.event_name: produced.n270.release_note.v2`
- `circuit_breaker.iter_count / max_iter / cooldown / escalation_target`

## Design rules
- Generate internal and external versions by default; add API-consumer version when API consumers are affected.
- Place breaking changes and required migrations near the top and never bury them in normal feature text.
- Every listed change must trace to PR, commit, ticket, task, or explicit assumption.
- External wording must be user-benefit oriented and must not leak internal refactor details or exploit details.
- If i18n is requested, mark machine translations as needing human review before publication.

## Execution workflow
1. Normalize PR, commit, ticket, and manifest change rows into audience-safe release topics.
2. Classify each topic into feature, improvement, bug fix, security, performance, deprecation, breaking, known issue, or internal-only.
3. Generate the requested publication views and channel summaries while keeping traceability links.
4. Emit missing evidence, publication approvals, and downstream documentation/support handoff explicitly.

## Composition behavior
- In full N270 mode, consult `references/n270-routing-and-orchestration-v2.md` before choosing sequence or parallel execution.
- Treat `release_manifest` as the single source of truth when multiple N270 artifacts coexist; update manifest patches before regenerating downstream artifacts.
- Emit a `produced.n270.*.v2` event for finalized artifacts so N330/N340/N350/N390 can subscribe without polling file names.
- If this artifact changes a field consumed by another N270 skill, list that peer skill under `downstream_handoff.refresh_triggers`.

## Self-check gate
- Run the self-check before finalizing. If any release-critical rule fails, `self_check.passed` must be false and readiness cannot be green.
- If the user asks to validate a generated artifact file, run `python scripts/validate_n270_artifact.py <artifact-file>` as a local LLM self-check. Treat this script as a packaged fallback; production-grade validation should run at the artifact contract registry with the canonical schema.
- Record failed rules, blockers, and exact owner/action needed for recovery.

## Quality bar
A good release note gives each audience the right amount of information, highlights breaking changes, preserves traceability, and stays publishable without reinterpreting internal artifacts.

## Reference files
- `references/n270-artifact-contract-v2.md`
- `references/n270-routing-and-orchestration-v2.md`
- `references/n270-composite-release-manifest-example-v2.md`
- `references/failure-modes.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
- `references/output-template.md`
- `references/release-note-template.md`
