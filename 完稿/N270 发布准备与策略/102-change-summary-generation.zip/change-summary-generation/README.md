# change-summary-generation

**Node**: release-prep  
**Artifact**: `变更摘要.md`  
**Contract**: `release-prep-v2.5.0`  

## What it does
Summarize code, config, and data changes from PRs into a structured, audience-segmented change inventory.

## Where it sits in the workflow
- **Upstream**: (entry point — PRs merged)
- **Downstream**: release-note-generation, release-risk-assessment, release-checklist-generation

## Quick start
```bash
# Validate an artifact produced by this skill
python scripts/validate_artifact.py path/to/变更摘要.md --report-coverage
```

## File layout
```
change-summary-generation/
├── SKILL.md                    # Skill instructions (≤500 lines)
├── README.md                   # This file
├── agents/
│   └── openai.yaml             # Display metadata for agent runtimes
├── scripts/
│   └── validate_artifact.py    # Artifact validator (exit 0=PASS, 1=FAIL, 2=error)
└── references/                 # On-demand detail files (loaded only when needed)
    ├── field-contract.md        # Field-level schema definitions
    ├── output-contract.yaml     # Machine-readable output contract
    ├── output-template.md       # Artifact template with all required sections
    ├── real-examples.md         # Calibration examples (min input / rich input / edge cases)
    ├── failure-modes.md         # Degradation examples and circuit breaker scenarios
    ├── cross-skill-orchestration.md  # Downstream handoff and boundary tables
    ├── feedback-loop.md         # Feedback integration and retrospective flow
    ├── quality-checklist.md     # SCR rules and quality gate definitions
    ├── readiness-inheritance.md # How readiness propagates across skills
    ├── adversarial-defense.md   # Full forbidden pattern table and trust boundaries
    ├── input-handling.md        # Token budget, large input strategies, sampling rules
    └── maintenance.md           # Contract evolution, upgrade paths, consumer impact
```

## Changelog
See `CHANGELOG.md` at the skill-set root for version history.  
Current contract version: `release-prep-v2.5.0`
