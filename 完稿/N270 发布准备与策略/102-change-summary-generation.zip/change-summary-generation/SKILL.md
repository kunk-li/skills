---
name: change-summary-generation
description: >-
  generate n270 change summary artifacts for release preparation with v2 contract metadata, event emission, differentiated inputs, degradation rules, and standalone or composed workflow use. use when chatgpt must produce 变更摘要.md, validate release readiness evidence, or participate in the n270 release package.
---
# change-summary-generation

## Role
This skill produces the N270 `变更摘要.md` artifact. It must remain useful as a standalone skill and must become stronger when combined with other N270 skills through the shared `release_manifest`.

## Boundary
- Own `change_summary` for N270; do not re-run upstream N260 quality gates or execute downstream N280 deployment actions.
- Consume upstream evidence and peer N270 artifacts when present, but never require all peer artifacts for standalone use.
- Keep downstream handoff to N280, N290, and N360 explicit, including missing evidence and manual decisions.
- Use `references/n270-artifact-contract-v2.md` as the contract source for metadata, events, readiness, and circuit breaker fields.

## Canonical identity
- `skill_id`: `change-summary-generation`
- `schema_version`: `n270.change_summary.v2`
- `artifact_version`: `2.0.0`
- `artifact_type`: `change_summary`
- `emit_event.event_name`: `produced.n270.change_summary.v2`
- `output_certainty_grade`: `authoritative_artifact`

## Maintenance status
- Treat this package as the N270 v4 maintenance build: core schema, event names, readiness model, and circuit-breaker semantics are frozen for normal use.
- Do not add, remove, or rename required contract fields unless the artifact contract version is explicitly bumped and all six N270 skills are updated together.
- Prefer bug fixes, wording clarifications, platform handoff updates, and registry migration notes over new skill behavior.
- In platform deployments, treat local contract mirrors as packaged fallback material; the artifact contract registry and event-bus ingress are the production authorities.

## Mode selection
Every output must declare `selected_mode`, `readiness`, `evidence_profile`, `output_certainty_grade`, and `emit_event` near the top.

Allowed modes:
- `standalone_internal_summary`
- `manifest_seed`
- `cumulative`
- `risk_focused`
- `cab_brief`

## Inputs
Use a four-tier input model so the skill is independently usable while still benefiting from richer workflow context.

### Minimum viable inputs
- release identity or change slice
- at least one task, PR, commit, ticket, or explicit change description

### Primary discriminating inputs
These inputs distinguish this skill from the other five N270 skills. Prioritize them when available.
- change_inventory source rows from tasks, PRs, commits, tickets, or release_manifest
- impact dimensions: users_affected, modules_touched, tests_affected, migrations, compatibility, team effort
- stakeholder target: PM, engineering, ops, security, compliance, support
- decision context: why this change, alternatives, constraints, unresolved questions

### Common N270 inputs
Use these as shared release context, not as the only preferred inputs. Always prefer Primary discriminating inputs; treat Common N270 inputs as last-resort fallback, not the default starting point.
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### Optional enhancement inputs
- release_note for consistency check
- risk register
- test changes
- migration notes
- historical release summaries
- CAB template

## Standalone and degradation rules
- Work on one release candidate, service release, hotfix, or release decision slice without requiring the full six-skill package.
- If minimum inputs are present but primary inputs are incomplete, keep the output contract stable and mark missing items under `evidence_profile.missing_evidence` and `downstream_handoff.missing_evidence_blocks`.
- Separate confirmed facts, assumptions, and unknowns. Do not convert unknowns into confident release statements.
- When evidence is insufficient for safe execution, produce a useful artifact with `readiness: amber` or `readiness: red` instead of refusing or inventing details.
- If invoked from N310 remediation and `orchestration_context.iter_count >= 3`, stop normal regeneration, mark readiness red, set cooldown `PT30M`, and escalate to the release manager / SLA human queue.

## Core output contract
Default to Markdown with YAML-like top metadata, or CSV/YAML-friendly tables when the user asks for a machine-readable artifact.

Required top-level sections:
- `metadata`
- `evidence_profile`
- `role_mode`
- `change_summary_overview`
- `normalized_change_inventory[]`
- `impact_quantification`
- `stakeholder_views`
- `high_risk_changes[]`
- `decision_support_notes`
- `manifest_seed_patch`
- `consumer_timing`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `skill_id: change-summary-generation`
- `schema_version: n270.change_summary.v2`
- `artifact_version: 2.0.0`
- `artifact_type: change_summary`
- `function_bias: direct_result.internal_change_inventory_and_impact_summary`
- `stage_position: release_and_delivery.release_preparation.change_summary_generation`
- `workflow_node: N270`
- `node_artifact_target: 变更摘要.md`
- `selected_mode`
- `output_certainty_grade: authoritative_artifact`
- `readiness: green | amber | red`
- `tool_collaboration_mode: standalone | composed | validation_only`
- `emit_event.event_name: produced.n270.change_summary.v2`
- `circuit_breaker.iter_count / max_iter / cooldown / escalation_target`

## Design rules
- Declare whether the output is standalone_internal_summary or manifest_seed; these are different roles.
- Do not duplicate outward-facing release notes; focus on internal decision context, impact, and release scope.
- Quantify impact per change and preserve per-release granularity in cumulative mode.
- Name the consumer and timing for every decision-support section, especially N270 peer skills, N280, N290, and N360.
- If the summary seeds release_manifest.change_inventory[], keep IDs stable so peer skills can reference them.

## Execution workflow
1. Normalize raw change evidence into stable change rows with source refs and impact fields.
2. Choose standalone summary, manifest seed, cumulative, risk-focused, or CAB brief mode based on user intent and inputs.
3. Group changes by impact, risk, stakeholder, and release action implications.
4. Emit manifest_seed_patch and downstream handoff so peer skills can consume the inventory without re-parsing raw inputs.

## Composition behavior
- In full N270 mode, consult `references/n270-routing-and-orchestration-v2.md` before choosing sequence or parallel execution.
- Treat `release_manifest` as the single source of truth when multiple N270 artifacts coexist; update manifest patches before regenerating downstream artifacts.
- Emit a `produced.n270.*.v2` event for finalized artifacts so N330/N340/N350/N390 can subscribe without polling file names.
- If this artifact changes a field consumed by another N270 skill, list that peer skill under `downstream_handoff.refresh_triggers`.

## Self-check gate
- Run the self-check before finalizing. If any release-critical rule fails, `self_check.passed` must be false and readiness cannot be green.
- If the user asks to validate a generated artifact file, run `python scripts/validate_n270_artifact.py <artifact-file>` as a local LLM self-check. Treat this script as a packaged fallback; production-grade validation should run at the artifact contract registry with the canonical schema.
- Record failed rules, blockers, and exact owner/action needed for recovery.

## Quality bar
A good change summary tells internal stakeholders what changed, why it matters, where risk concentrates, who consumes the decision context, and how the manifest should update.

## Reference files
- `references/n270-artifact-contract-v2.md`
- `references/n270-routing-and-orchestration-v2.md`
- `references/n270-composite-release-manifest-example-v2.md`
- `references/failure-modes.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
- `references/output-template.md`
- `references/change-summary-components.md`
