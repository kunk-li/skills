# Compatibility pointer

This legacy filename is kept for backward compatibility. Use `references/release-prep-routing-and-orchestration-v2.md` as the canonical routing, composition, and closure-rule reference. Do not load both files for the same task.


---

## Boundary comparison table — release-prep 家族精确边界

### change-summary vs release-note vs release-risk vs release-checklist

| Dimension | change-summary-generation | release-note-generation | release-risk-assessment | release-checklist-generation |
|---|---|---|---|---|
| **Primary question** | "What changed technically, for which audience?" | "How do we communicate changes externally?" | "Is this release safe to proceed?" | "Are we operationally ready to deploy?" |
| **Audience** | Internal: engineers, SREs, PMs, CAB | External: users, support, API consumers, compliance | Internal: release manager, SRE, approvers | Internal: release manager, devops, oncall |
| **Output type** | Normalized change inventory with multi-audience views | User-facing changelog, migration guides, known issues | Risk register with composite score and go/no-go | Checklist of readiness items with sign-off roles |
| **Owns** | Change ID assignment, diff normalization, audience tagging | External narrative, migration guide authoring | Risk scoring, risk category classification | Gate items, sign-off tracking, timing markers |
| **Does not own** | External narrative (→104), risk scoring (→101), gate items (→103) | Technical diff (→102), risk assessment (→101) | Change inventory (→102), gate sequencing (→103) | Change analysis (→102), risk scoring (→101) |
| **Typical trigger** | After PR merge, before release planning | After change-summary ready, for stakeholder comms | After change-summary ready, before go/no-go | Alongside or after risk assessment, before deploy |

### Routing decision tree
```
User says...
"What changed in this release?"           → change-summary-generation ✓
"Write release notes for users"           → release-note-generation
"How risky is this release?"              → release-risk-assessment
"What do we need to check before deploy?" → release-checklist-generation
"Summarize for the CAB committee"         → change-summary-generation ✓ (cab_brief mode)
"Write API migration guide"               → release-note-generation (api_consumer_update mode)
"Rate risk level 1–10"                    → release-risk-assessment

When unsure between 102 and 104:
  Audience internal? → 102 (change-summary)
  Audience external? → 104 (release-note)
  Need both?         → run 102 first, then feed its output to 104
```

---

## Composition: manifest_seed ID stability contract
When `selected_mode: manifest_seed`, the `change_inventory[].change_id` values become cross-skill references. Apply these rules:
- `change_id` format: `CHG-{YYYYMMDD}-{sequence}` — deterministic and collision-free within a release
- Once emitted, a `change_id` must **not** change between regenerations unless the underlying source ref changes
- If a `change_id` conflict is detected with an existing manifest entry, emit `manifest_seed_patch.conflicts[]` with: `change_id`, `conflict_type: duplicate | stale | version_mismatch`, and `resolution: keep_new | keep_existing | manual`
- Downstream skills (`release-note-generation`, `release-risk-assessment`) must reference `change_id` values from the most recent `change_summary` manifest_seed; if their version is older, emit `downstream_handoff.refresh_triggers: [change-summary-generation]`



---

## Boundary comparison table — change-summary vs all consumers

| Dimension | change-summary-generation | release-note-generation | release-risk-assessment | configuration-change-check |
|---|---|---|---|---|
| **Primary question** | "What changed, for which internal audience?" | "How do we tell users?" | "Is the release safe?" | "How do configs reload?" |
| **Audience** | Internal: engineers, SREs, PMs, CAB, audit | External: users, support, customers | Internal: release manager, SRE, approvers | Internal: devops, platform |
| **Output type** | Normalized change inventory with multi-audience views | User-facing changelog | Risk register with composite score | Config change inventory with reload modes |
| **Owns** | change_id assignment, change_kind classification, audience_views, impact_dimensions | External narrative, migration guides, known_issues | Risk scoring across 12 categories | Config classification (CF01-CF08), reload_mode, secret lifecycle |
| **Does not own** | External narrative (→104), risk scoring (→101), config reload analysis (→106) | Technical diff (→102), risk assessment (→101), config details (→106) | Change inventory (→102), config reload (→106) | Change narrative (→102), risk scoring (→101) |

### Routing decision tree (extended)
```
Who reads this?
  Internal only (devs, SREs, PMs, CAB)       → change-summary-generation ✓
  External (users, support, compliance)        → release-note-generation
  Risk gate (release manager, SRE approver)    → release-risk-assessment
  Deploy impact (reload, rollback relevance)   → configuration-change-check
  Both internal AND external                   → run 102 first → feed to 104

Is the input a config diff (values.yaml, env vars)?
  YES, with change context                     → change-summary-generation ✓ for narrative; 106 for reload analysis
  YES, checking parity between environments    → environment-difference-check
```



---

## Boundary comparison table — change-summary precise

| Dimension | change-summary-generation | release-note-generation | configuration-change-check | release-risk-assessment |
|---|---|---|---|---|
| **Primary audience** | Internal (devs, SREs, PMs, CAB, audit) | External (users, support, compliance, API consumers) | Internal ops (devops, SRE, platform) | Internal (release manager, SRE lead, approvers) |
| **Output language** | Technical, precise, audience-segmented | Plain language, user-benefit framing | Operational, config-focused | Risk-analytical, scoring-focused |
| **Owns** | change_id assignment, change_kind classification, impact_dimensions, audience_views | External narrative, migration guides, known_issues | Config classification (CF01-CF08), reload_mode, secret lifecycle | Risk scoring, 12 dimensions, composite score, go/no-go |
| **Does not own** | External narrative (→104), config reload impact (→106), risk scoring (→101) | Technical diff (→102), config analysis (→106), risk (→101) | Change narrative (→102), external comms (→104), holistic risk (→101) | Change inventory (→102), config details (→106), external comms (→104) |
| **Trigger words** | "summarize for CAB", "change record", "what changed internally" | "write changelog", "release notes", "user announcement" | "config impact", "reload needed?", "secret rotation" | "how risky?", "should we deploy?", "risk assessment" |

### Boundary enforcement: 102 vs 104 decision guide
```
Is the audience external (users/customers/API consumers)? → 104
Is the audience internal (devs/SREs/CAB/audit)?          → 102 ✓
Is the question "what changed?" (not "is it risky?")     → 102 ✓
Is the question "is it safe?" (not "what changed?")      → 101
Is the question about config reload impact specifically?  → 106
Does output need user-benefit language?                   → 104
Does output need technical diff analysis?                 → 102 ✓
```

