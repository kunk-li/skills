# real examples

Example signals worth highlighting:
- release contains a DB migration and a new config flag
- canary is limited to internal users first because business blast radius is high
- rollback is image-safe for 24h only because old binaries cannot read new long-lived data after that

---

## Additional scenario: amber degradation — missing commit history

**Scenario:** Skill invoked with only a ticket ID and a one-line change description. No PR, no diff.

**Expected behavior:**
- Produce the artifact in the most useful mode given available evidence.
- Declare `readiness: partial` with explicit `missing_evidence`.
- Populate all stable output sections; use `unknown` or `inferred` for fields that cannot be determined.
- `downstream_handoff.missing_evidence` lists what is needed to reach `readiness: green`.
- `self_check.passed: false` with the specific rule that failed.

**Key calibration:** Never refuse output due to missing optional inputs. A partial artifact with clear evidence gaps is more useful than no artifact. The consumer (release manager, SRE, or next skill) uses the `missing_evidence` list to decide whether to proceed or gather more evidence first.

---

## Example 4: manifest_seed mode — 3 services, cross-team release

**Scenario:** Platform team releases 3 microservices together. Change summary seeds the release manifest.

```yaml
metadata:
  readiness: green
  selected_mode: manifest_seed
change_inventory:
  - change_id: CHG-20260520-001
    source_ref: PR-892
    title: "Add retry logic for payment gateway timeouts"
    services_touched: [payment-service]
    change_kind: application_logic
    audience_views:
      engineering: "Retry up to 3× on gateway timeout with exponential backoff (500ms/1s/2s)"
      ops: "May reduce payment timeout incidents; monitor gateway error_rate post-deploy"
      pm: "Reduces checkout failure rate from transient gateway issues"
    impact_dimensions:
      migrations: none
      backward_compatible: true
      tests_affected: [PaymentProcessorTest, GatewayRetryTest]
    confidence: high
  - change_id: CHG-20260520-002
    source_ref: PR-893
    title: "Increase JWT token TTL from 1h to 4h"
    services_touched: [auth-service]
    change_kind: config_change
    audience_views:
      engineering: "JWT_TTL env var updated: 3600 → 14400. Hot reload supported."
      ops: "Config change — rolling restart not required (hot_reload)"
      pm: "Users will stay logged in longer; reduces session interruption complaints"
    impact_dimensions:
      migrations: none
      backward_compatible: true
    confidence: high
  - change_id: CHG-20260520-003
    source_ref: PR-894
    title: "Migrate notification service to async queue"
    services_touched: [notification-service]
    change_kind: schema_migration
    audience_views:
      engineering: "Added notification_queue table; old sync path deprecated but still active for 30 days"
      ops: "DB migration: additive (no data loss). Rollback: disable feature flag 'async_notifications'"
    impact_dimensions:
      migrations: additive
      backward_compatible: true
    confidence: high
summary_stats:
  total_changes: 3
  services_touched: 3
  high_risk_changes: 0
  confidence_overall: high
downstream_handoff:
  to_skill: release-note-generation
  change_ids_for_release_notes: [CHG-20260520-001, CHG-20260520-002, CHG-20260520-003]
self_check:
  passed: true
  failed_rules: []
```

**Key calibration:** `manifest_seed` mode requires stable `change_id` values (never change them between regenerations for the same source PR). All three `audience_views` should tell different stories for the same change — not be copies of the engineering description.

---

## Example 5: Breaking change with migration guide — compliance audience view

**Scenario:** API breaking change: response field renamed. Affects external consumers. Compliance requires CAB submission.

**Input given:**
- PR-901: `GET /v2/orders` response field `order_id` renamed to `order_reference` (BREAKING)
- CAB submission deadline: 48h before deploy
- DPO review: required (order data contains PII)

**Key calibration:**
```yaml
change_inventory:
  - change_id: CHG-20260521-BC-001
    source_ref: PR-901
    title: "Rename order_id to order_reference in GET /v2/orders response"
    services_touched: [order-service]
    change_kind: api_contract
    migration_scope: breaking
    audience_views:
      engineering: "Response field renamed: order_id → order_reference. All consumers must update field reference. Old field removed — no alias provided."
      external: "BREAKING: The GET /v2/orders response field 'order_id' has been renamed to 'order_reference'. Update your integration before {deadline}. See migration guide: https://docs.example.com/v2-migration"
      compliance: "Breaking API change affecting order data fields (PII scope: order_reference contains customer linkage). DPO review required. CAB category: HIGH."
      support: "Customers using the Orders API will see errors if they reference 'order_id' after deploy. Escalation path: engineering on-call."
    impact_dimensions:
      migrations: breaking
      backward_compatible: false
      deadline: "2026-06-04T00:00:00Z"   # 14-day migration window
      migration_path: "Replace order_id with order_reference in all API consumer integrations"
    confidence: high
flags_for_downstream:
  breaking_changes: [CHG-20260521-BC-001]
  cab_required: true
  cab_category: HIGH
  dpo_review_required: true
downstream_handoff:
  to_skill: release-risk-assessment
  breaking_changes_flag: true
  note: "Breaking change detected — release-risk-assessment should elevate integration_risk"
self_check:
  passed: true
  warnings:
    - "breaking_change detected: all 4 audience_views required; check external and compliance views are present"
```

**Key calibration:** A breaking change must produce all 4 audience_views with distinct content. The external view must include the migration deadline and guide URL. Never mark `migration_scope: breaking` without also flagging `backward_compatible: false` and populating `migration_path`.

---

## Example 6: Minimum input — readiness: partial (ticket only, no PR)

**Scenario:** Release manager provides only a Jira ticket ID and a one-line description. No PRs, no diffs.

**Input given:**
- Ticket: JIRA-4421 — "Fix payment timeout retry logic"
- No PR attached, no diff available

**Key calibration:**
```yaml
metadata:
  readiness: partial
  selected_mode: standalone_internal_summary
  evidence_profile:
    confirmed: [ticket_description]
    missing_evidence:
      - PR diff (cannot classify change_kind without diff)
      - service name (inferred: payment-service)
      - test coverage
    missing_evidence_impact: "change_kind inferred; audience_views are best-effort only; confidence: low"
change_inventory:
  - change_id: CHG-20260521-PARTIAL-001
    source_ref: JIRA-4421
    title: "Fix payment timeout retry logic (inferred from ticket)"
    services_touched: [payment-service]  # inferred
    change_kind: application_logic       # inferred — verify with PR
    migration_scope: none                # assumed — verify with diff
    confidence: low
    audience_views:
      engineering: "Ticket states: payment timeout retry logic fix. Diff required to confirm scope."
      ops: "Impact unknown without diff. Likely low-risk based on description; verify."
self_check:
  passed: false
  failed_rules:
    - "PR diff absent — change_kind and migration_scope are inferred, not confirmed"
```


---

## Scenario calibration
See `references/real-examples.md` for cumulative, risk_focused, and manifest_seed scenarios.

For change-summary components (what to include per stakeholder view), see `references/change-summary-components.md`.
For manifest_seed ID stability rules, see the composition section in this SKILL.md.