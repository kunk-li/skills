# Field contract v2

Prefer `references/release-prep-artifact-contract-v2.md` for the full contract. This file remains as a compact backward-compatible summary.

Required metadata additions over v1:
- `schema_version`
- `artifact_version`
- `artifact_type`
- `output_certainty_grade`
- `emit_event`
- `circuit_breaker`

Required downstream handoff additions:
- `consumed_fields`
- `missing_evidence_blocks`
- `manual_decisions_required`
- `refresh_triggers`
- `sla_queue_items` when human confirmation is needed


---

## Field contract — change_inventory row

| Field | Required | Values / notes |
|---|---|---|
| `change_id` | yes | `CHG-{YYYYMMDD}-{seq}`, stable and collision-free within a release |
| `source_ref` | yes | PR number, commit hash, ticket ID, or explicit change description |
| `title` | yes | one-line summary, ≤ 120 chars |
| `services_touched[]` | yes | list of service names; `[]` only if infrastructure-only |
| `change_kind` | yes | `application_logic` / `config_change` / `schema_migration` / `dependency_update` / `security_fix` / `performance` / `documentation` |
| `audience_views` | yes | at least `engineering`; add `ops`, `pm`, `compliance` when relevant |
| `impact_dimensions.migrations` | yes | `none` / `additive` / `breaking` |
| `impact_dimensions.backward_compatible` | yes | `true` / `false` / `unknown` |
| `confidence` | yes | `high` / `medium` / `low` — low when source is verbal description only |

---

## Boundary enforcement: no external audience language
`change_summary` is strictly an internal artifact. The following content is **prohibited** regardless of mode:
- User-benefit framing ("customers will now enjoy…", "this update makes it easier to…")
- Marketing language or public-facing product descriptions
- Content replicating `audience_versions.external` from `release-note-generation`

If external-audience language is detected in input change descriptions, strip it during normalization and flag in `self_check.failed_rules: "external audience language stripped from change_inventory"`.

