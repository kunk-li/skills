# failure modes

| id | failure mode | required response |
|---|---|---|
| `CS-F1` | Duplicating release notes | Keep audience-facing text out unless used as consistency reference; focus on internal impact and decisions. |
| `CS-F2` | Hiding the manifest seed role | Declare role_mode and include manifest_seed_patch when used as the N270 seed. |
| `CS-F3` | No consumer or timing | For each decision note, state who consumes it and when. |
| `CS-F4` | Flattening cumulative changes | Keep version/source references and deltas in cumulative mode. |
| `CS-F5` | Impact without evidence | Separate confirmed impact from assumptions and unknowns. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.
