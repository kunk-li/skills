## Mock input fixture

```yaml
# Minimum mock input for testing this skill standalone
mock_input:
  source: "ticket_description_only"
  content: "TICKET-4821: Add retry logic to payment gateway timeout handling"
  expected_output_shape:
    change_id: "CHG-20260520-001"
    confidence: low
    change_kind: application_logic
    audience_views:
      engineering: present
    self_check:
      passed: true
      warnings: ["low confidence — provide PR diff to upgrade"]
```
