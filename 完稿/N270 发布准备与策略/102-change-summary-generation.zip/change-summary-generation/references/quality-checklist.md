# Quality checklist v2

A strong release-prep artifact:
- exposes `schema_version`, `artifact_version`, `emit_event`, and `circuit_breaker`
- declares minimum, primary discriminating, common, and optional inputs
- is explicitly tied to the official release-prep output name
- references the shared `release_manifest` without requiring all six release-prep artifacts for standalone use
- names blockers, mitigations, owners, SLA, and remaining unknowns directly
- keeps direct-result artifacts separate from decision-support artifacts
- makes downstream use in release-exec, release-validation, and change-tracking obvious
- emits refresh triggers when peer artifacts should be regenerated


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-CHANGESU-051 | No "chatgpt" in content | string search | `self_check.failed_rules: ["SCR-CHANGESU-051: chatgpt brand word — BLOCKER"]` |
| SCR-CHANGESU-052 | `summary_stats.confidence_overall` declared | key exists | `self_check.warnings: ["SCR-CHANGESU-052: confidence_overall missing from summary_stats"]` |
| SCR-CHANGESU-053 | When contradiction detected: `discrepancy_note` present | conditional | `self_check.warnings: ["SCR-CHANGESU-053: contradiction detected but no discrepancy_note"]` |