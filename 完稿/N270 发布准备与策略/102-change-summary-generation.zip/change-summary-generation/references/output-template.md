# Output template: 变更摘要.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: change-summary-generation
  schema_version: n270.change_summary.v2
  artifact_version: 2.0.0
  artifact_type: change_summary
  workflow_node: N270
  stage_position: release_and_delivery.release_preparation.change_summary_generation
  node_artifact_target: 变更摘要.md
  selected_mode: <mode>
  output_certainty_grade: authoritative_artifact
  readiness: green | amber | red
  function_bias: direct_result.internal_change_inventory_and_impact_summary
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.n270.change_summary.v2
    event_version: 2
    producer_skill: change-summary-generation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `role_mode`
- `change_summary_overview`
- `normalized_change_inventory[]`
- `impact_quantification`
- `stakeholder_views`
- `high_risk_changes[]`
- `decision_support_notes`
- `manifest_seed_patch`
- `consumer_timing`

End with:

```yaml
downstream_handoff:
  primary_consumers: [N280, N290, N360]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```
