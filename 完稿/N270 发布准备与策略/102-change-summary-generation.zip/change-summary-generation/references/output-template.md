# Output template: 变更摘要.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: change-summary-generation
  schema_version: release-prep.change_summary.v2
  artifact_version: 2.0.0
  artifact_type: change_summary
  workflow_node: release-prep
  stage_position: release_and_delivery.release_preparation.change_summary_generation
  node_artifact_target: 变更摘要.md
  selected_mode: <mode>
  output_certainty_grade: authoritative_artifact
  readiness: green | amber | red
  function_bias: direct_result.internal_change_inventory_and_impact_summary
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.release-prep.change_summary.v2
    event_version: 2
    producer_skill: change-summary-generation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `role_mode`
- `change_summary_overview`
- `normalized_change_inventory[]`
- `impact_quantification`
- `stakeholder_views`
- `high_risk_changes[]`
- `decision_support_notes`
- `manifest_seed_patch`
- `consumer_timing`

End with:

```yaml
downstream_handoff:
  primary_consumers: [release-exec, release-validation, change-tracking]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```


---

## Downstream handoff YAML templates

### 正常路径：向 release-note-generation 和 release-risk-assessment 移交
```yaml
downstream_handoff:
  produced_by: change-summary-generation
  artifact: 变更摘要.md
  emit_event:
    event_name: produced.release-prep.change_summary.v2
    event_delivery: declared_only
  handoffs:
    - target: release-note-generation
      handoff_type: evidence
      summary: "3 changes normalized: CHG-001(application_logic), CHG-002(config_change), CHG-003(schema_migration). All audience views populated."
      required_fields: [change_inventory, change_ids_for_release_notes, audience_views]
      confidence: high
      missing_evidence: []
      next_best_checks:
        - "release-note-generation: translate CHG-001~003 into external changelog"
    - target: release-risk-assessment
      handoff_type: evidence
      summary: "CHG-003 has schema_migration impact — flag as data_migration_risk: medium"
      required_fields: [change_inventory, impact_dimensions.migrations]
      confidence: high
      next_best_checks:
        - "release-risk-assessment: assign data_migration_risk score for CHG-003"
  refresh_triggers:
    - skill: release-note-generation
      reason: "change_summary regenerated with new PRs — release note must be regenerated"
      condition: "change_summary.artifact_version > release_note.source_change_summary_version"
```

### 降级路径：仅 Tier 1 输入，向下游声明低置信度
```yaml
downstream_handoff:
  handoffs:
    - target: release-note-generation
      handoff_type: evidence
      summary: "1 change entry, confidence: low. Release note will be incomplete."
      confidence: low
      missing_evidence: [pr_diff, full_pr_list]
      next_best_checks:
        - "Provide PR diffs to upgrade confidence before generating release notes"
```


---

## Standalone guarantee
This skill runs with only a ticket ID or one-line change description. Never refuse because PR, commits, or manifest are absent.

### Minimum standalone example — ticket ID only
```yaml
metadata:
  readiness: partial
  selected_mode: standalone_internal_summary
  output_certainty_grade: authoritative_artifact
evidence_profile:
  confirmed: [ticket_description]
  missing_evidence: [pr_diff, commit_refs, test_coverage_delta]
  missing_evidence_impact: "Change inventory has one entry. Scope confidence is low. Risk dimensions estimated from ticket title only."
change_inventory:
  - change_id: CHG-20260520-001
    source_ref: "TICKET-4821"
    description: "Add retry logic to payment gateway timeout handling"
    services_touched: [payment-service]
    change_kind: application_logic
    audience_views:
      engineering: "Retry up to 3× on gateway timeout with exponential backoff (500ms, 1s, 2s)"
      ops: "May reduce payment timeout incidents; monitor gateway error rate post-deploy"
      pm: "Reduces checkout failure rate caused by transient gateway issues"
    impact_dimensions:
      users_affected: partial   # transient payment failures; estimated impact unknown
      migrations: none
      compatibility: backward_compatible
      tests_affected: unknown   # no PR diff available
    confidence: low
    missing_details: [implementation_diff, test_plan, PR_link]
summary_stats:
  total_changes: 1
  services_touched: 1
  confidence_overall: low
downstream_handoff:
  to_skill: release-note-generation
  change_ids_for_release_notes: [CHG-20260520-001]
  missing_evidence: [pr_diff, commit_refs]
self_check:
  passed: true
  warnings: ["Single ticket input — scope confidence low. Provide PR diff to increase confidence to medium/high."]
```

### cab_brief example — multi-service CAB submission
```yaml
metadata:
  readiness: green
  selected_mode: cab_brief
change_inventory:
  - change_id: CHG-20260520-001
    source_ref: PR-892
    services_touched: [payment-service]
    change_kind: application_logic
    cab_summary: "Payment retry logic — backward compatible, no DB changes, tested in staging"
    risk_level: low
    rollback_plan_ref: rollback-plan-generation
  - change_id: CHG-20260520-002
    source_ref: PR-893
    services_touched: [auth-service]
    change_kind: config_change
    cab_summary: "Increase JWT token TTL from 1h to 4h — config hot reload, no restart"
    risk_level: medium
    rollback_plan_ref: rollback-plan-generation
cab_verdict_inputs:
  combined_risk_level: medium
  requires_cab_approval: true
  rationale: "CHG-20260520-002 is a security-adjacent config change requiring CAB sign-off"
```

**Key calibration:** `cab_brief` mode targets Change Advisory Board reviewers. Every item needs `cab_summary` (one sentence), `risk_level`, and `rollback_plan_ref`. Do not include engineering implementation details in `cab_summary`.

---

## Output completeness rule
Every change summary artifact MUST include ALL of:
- `change_inventory` ≥ 1 entry; each with `change_id`, `change_kind`, `audience_views.engineering`, `impact_dimensions`
- `summary_stats.total_changes` numeric
- `summary_stats.change_kind_breakdown` enumerated
- `summary_stats.migration_count` numeric (may be 0)
- `downstream_handoff` to release-risk-assessment and release-note-generation
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry
- `consumer_impact_assessment` when `migration_count` > 0 or `breaking_changes` present

**Hard rules:**
- `change_id` MUST follow `CHG-{YYYYMMDD}-{NNN}` format
- `audience_views.engineering` NEVER omitted regardless of audience_context
- `impact_dimensions.migrations` ∈ {none, additive, breaking, breaking_provisional, unknown}
- `confidence: high` requires structured diff + CI results + no contradictions

---

## Mode selection

### New: `delta_summary` mode — 增量变更摘要（Sprint-to-Sprint）
**Trigger:** Team wants to know what changed since last release or sprint, or says "what's new since v2.0?", "delta since last deploy", "incremental changes".

```yaml
delta_summary:
  baseline_version: "v2.0.3"
  current_version: "v2.1.0"
  delta_window: "2026-05-07 to 2026-05-21"
  pr_count: 12
  delta_inventory:
    new_since_baseline:
      - change_id: CHG-20260521-001
        change_kind: feature
        description: "Idempotent payment retry added"
        first_appeared: "2026-05-14"
    modified_since_baseline:
      - change_id: CHG-20260521-005
        change_kind: bugfix
        description: "Fixed checkout timeout under load"
    reverted_since_baseline: []
  migration_delta:
    new_migrations: 1
    removed_migrations: 0
```
**SCR:** `selected_mode: delta_summary` → `delta_summary.baseline_version` declared; `delta_summary.delta_window` present.

---

## Downstream handoff YAML

### 正常路径: 多PR完整摘要 → release-note + release-risk + release-checklist
```yaml
downstream_handoff:
  produced_by: change-summary-generation
  artifact: 变更摘要.md
  emit_event:
    event_name: produced.release-prep.change_summary.v2
  handoffs:
    - target: release-note-generation
      handoff_type: evidence
      summary: "3 changes: CHG-001(app_logic), CHG-002(config_change), CHG-003(schema_migration). All audience views ready."
      required_fields: [change_inventory, change_ids_for_release_notes, audience_views]
      confidence: high
      next_best_checks:
        - "104: translate CHG-001~003 into user-benefit language"
        - "104: CHG-003 schema_migration needs migration_guide section"
    - target: release-risk-assessment
      handoff_type: evidence
      summary: "CHG-003 has schema_migration: breaking — flag data_migration_risk"
      required_fields: [change_inventory, impact_dimensions.migrations]
      confidence: medium
      next_best_checks:
        - "101: set data_migration_risk: medium for CHG-003"
    - target: release-checklist-generation
      handoff_type: evidence
      summary: "CHG-003 schema migration needs DBA P0 sign-off gate"
      required_fields: [change_inventory[2].impact_dimensions]
      confidence: medium
      next_best_checks:
        - "103: add P0 DBA_approval gate for CHG-003"
  refresh_triggers:
    - skill: release-note-generation
      reason: "Change summary updated with new PR — note must be regenerated"
      condition: "change_summary.version > release_note.source_version"
    - skill: release-risk-assessment
      reason: "Change inventory changed — risk scores must be recalculated"
      condition: "change_summary.change_count changed"
```

### 降级路径: Tier 1 输入 → 低置信度移交
```yaml
downstream_handoff:
  handoffs:
    - target: release-note-generation
      handoff_type: gap
      summary: "Tier 1 input — 1 change entry, confidence: low. Release note will be incomplete."
      confidence: low
      missing_evidence: [pr_diff, full_pr_list]
      next_best_checks:
        - "Provide PR diffs to upgrade confidence before generating release notes"
```

