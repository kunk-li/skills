---
name: canary-release-recommendation
description: >-
  generate n270 canary recommendation artifacts for release preparation with v2 contract metadata, event emission, differentiated inputs, degradation rules, and standalone or composed workflow use. use when chatgpt must produce 灰度发布建议.md, validate release readiness evidence, or participate in the n270 release package.
---
# canary-release-recommendation

## Role
This skill produces the N270 `灰度发布建议.md` artifact. It must remain useful as a standalone skill and must become stronger when combined with other N270 skills through the shared `release_manifest`.

## Boundary
- Own `canary_recommendation` for N270; do not re-run upstream N260 quality gates or execute downstream N280 deployment actions.
- Consume upstream evidence and peer N270 artifacts when present, but never require all peer artifacts for standalone use.
- Keep downstream handoff to N280, N290, and N360 explicit, including missing evidence and manual decisions.
- Use `references/n270-artifact-contract-v2.md` as the contract source for metadata, events, readiness, and circuit breaker fields.

## Canonical identity
- `skill_id`: `canary-release-recommendation`
- `aliases`: `canary-release-plan-generation`
- `schema_version`: `n270.canary_recommendation.v2`
- `artifact_version`: `2.0.0`
- `artifact_type`: `canary_recommendation`
- `emit_event.event_name`: `produced.n270.canary_recommendation.v2`
- `output_certainty_grade`: `decision_support_not_hard_gate`

## Maintenance status
- Treat this package as the N270 v4 maintenance build: core schema, event names, readiness model, and circuit-breaker semantics are frozen for normal use.
- Do not add, remove, or rename required contract fields unless the artifact contract version is explicitly bumped and all six N270 skills are updated together.
- Prefer bug fixes, wording clarifications, platform handoff updates, and registry migration notes over new skill behavior.
- In platform deployments, treat local contract mirrors as packaged fallback material; the artifact contract registry and event-bus ingress are the production authorities.

## Mode selection
Every output must declare `selected_mode`, `readiness`, `evidence_profile`, `output_certainty_grade`, and `emit_event` near the top.

Allowed modes:
- `simple_canary`
- `advanced_canary`
- `shadow_first`
- `cohort_based`
- `region_based`

## Inputs
Use a four-tier input model so the skill is independently usable while still benefiting from richer workflow context.

### Minimum viable inputs
- release identity
- risk posture or impact scope
- at least qualitative traffic or cohort information

### Primary discriminating inputs
These inputs distinguish this skill from the other five N270 skills. Prioritize them when available.
- slo_triplets and observability baseline
- traffic segmentation data and cohort eligibility
- release risk assessment
- rollback plan and rollback triggers
- feature flags and deployment constraints

### Common N270 inputs
Use these as shared release context, not as the only preferred inputs. Always prefer Primary discriminating inputs; treat Common N270 inputs as last-resort fallback, not the default starting point.
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### Optional enhancement inputs
- shadow traffic evidence
- business SLI baseline
- regional traffic profile
- VIP/enterprise exclusion policy
- historical canary outcomes

## Standalone and degradation rules
- Work on one release candidate, service release, hotfix, or release decision slice without requiring the full six-skill package.
- If minimum inputs are present but primary inputs are incomplete, keep the output contract stable and mark missing items under `evidence_profile.missing_evidence` and `downstream_handoff.missing_evidence_blocks`.
- Separate confirmed facts, assumptions, and unknowns. Do not convert unknowns into confident release statements.
- When evidence is insufficient for safe execution, produce a useful artifact with `readiness: amber` or `readiness: red` instead of refusing or inventing details.
- If invoked from N310 remediation and `orchestration_context.iter_count >= 3`, stop normal regeneration, mark readiness red, set cooldown `PT30M`, and escalate to the release manager / SLA human queue.

## Core output contract
Default to Markdown with YAML-like top metadata, or CSV/YAML-friendly tables when the user asks for a machine-readable artifact.

Required top-level sections:
- `metadata`
- `evidence_profile`
- `canary_summary`
- `canonical_skill_id_and_aliases`
- `canary_pattern`
- `cohort_strategy`
- `stage_plan[]`
- `promotion_metrics[]`
- `promotion_automation`
- `rollback_triggers[]`
- `human_review_gates[]`
- `monitoring_dashboards`
- `decision_limits`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `skill_id: canary-release-recommendation`
- `schema_version: n270.canary_recommendation.v2`
- `artifact_version: 2.0.0`
- `artifact_type: canary_recommendation`
- `function_bias: decision_support.canary_rollout_strategy`
- `stage_position: release_and_delivery.release_preparation.canary_release_recommendation`
- `workflow_node: N270`
- `node_artifact_target: 灰度发布建议.md`
- `selected_mode`
- `output_certainty_grade: decision_support_not_hard_gate`
- `readiness: green | amber | red`
- `tool_collaboration_mode: standalone | composed | validation_only`
- `emit_event.event_name: produced.n270.canary_recommendation.v2`
- `circuit_breaker.iter_count / max_iter / cooldown / escalation_target`

## Design rules
- Keep canonical skill id as canary-release-recommendation; treat canary-release-plan-generation as an alias only.
- Choose an explicit rollout pattern and justify cohort selection with blast-radius reasoning.
- Move SLOs, baseline, traffic segmentation, risk, and rollback from optional nice-to-have into primary discriminating inputs.
- Express go/no-go rules as a machine-readable metrics matrix; prose-only thresholds must force manual review.
- Tie every auto-halt or rollback recommendation to rollback-plan triggers and release-risk posture.

## Execution workflow
1. Collect release risk, rollback readiness, SLO baselines, traffic cohorts, and observability evidence.
2. Choose rollout pattern, cohort order, stage percentages, hold times, and monitoring intensity.
3. Define metric thresholds, progression, pause, rollback, and human-review conditions.
4. Emit decision limits and mark output as decision_support_not_hard_gate unless authorized owners approve.

## Composition behavior
- In full N270 mode, consult `references/n270-routing-and-orchestration-v2.md` before choosing sequence or parallel execution.
- Treat `release_manifest` as the single source of truth when multiple N270 artifacts coexist; update manifest patches before regenerating downstream artifacts.
- Emit a `produced.n270.*.v2` event for finalized artifacts so N330/N340/N350/N390 can subscribe without polling file names.
- If this artifact changes a field consumed by another N270 skill, list that peer skill under `downstream_handoff.refresh_triggers`.

## Self-check gate
- Run the self-check before finalizing. If any release-critical rule fails, `self_check.passed` must be false and readiness cannot be green.
- If the user asks to validate a generated artifact file, run `python scripts/validate_n270_artifact.py <artifact-file>` as a local LLM self-check. Treat this script as a packaged fallback; production-grade validation should run at the artifact contract registry with the canonical schema.
- Record failed rules, blockers, and exact owner/action needed for recovery.

## Quality bar
A good canary recommendation gives precise stages, cohorts, metrics, thresholds, rollback triggers, and decision limits without pretending to be an execution approval.

## Reference files
- `references/n270-artifact-contract-v2.md`
- `references/n270-routing-and-orchestration-v2.md`
- `references/n270-composite-release-manifest-example-v2.md`
- `references/failure-modes.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
- `references/output-template.md`
- `references/canary-stage-patterns.md`
