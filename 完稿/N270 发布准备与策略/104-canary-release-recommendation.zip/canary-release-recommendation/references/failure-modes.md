# failure modes

| id | failure mode | required response |
|---|---|---|
| `CY-F1` | Qualitative thresholds with automatic promotion | Set promotion_automation to review_gate when thresholds are not machine-readable. |
| `CY-F2` | Missing baseline/SLO evidence | Keep readiness amber/red and request baseline metrics or SLO triplets. |
| `CY-F3` | No cohort rationale | Explain why the selected cohort reduces blast radius. |
| `CY-F4` | Canary not tied to rollback | Link every hard trigger to rollback_triggers[] and rollback_plan references. |
| `CY-F5` | Treating recommendation as final approval | Use output_certainty_grade decision_support_not_hard_gate and require owner approval for execution. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.
