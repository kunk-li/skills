# Quality checklist v2

A strong release-prep artifact:
- exposes `schema_version`, `artifact_version`, `emit_event`, and `circuit_breaker`
- declares minimum, primary discriminating, common, and optional inputs
- is explicitly tied to the official release-prep output name
- references the shared `release_manifest` without requiring all six release-prep artifacts for standalone use
- names blockers, mitigations, owners, SLA, and remaining unknowns directly
- keeps direct-result artifacts separate from decision-support artifacts
- makes downstream use in release-exec, release-validation, and change-tracking obvious
- emits refresh triggers when peer artifacts should be regenerated


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-CANARYRE-051 | When `readiness: red`: `canary_plan.status: emergency_halt` present | conditional | `self_check.failed_rules: ["SCR-CANARYRE-051: red readiness without halt status"]` |
| SCR-CANARYRE-052 | `latency_sensitive_canary` mode: Stage 1 `traffic_pct` ≤ 5 | conditional | `self_check.failed_rules: ["SCR-CANARYRE-052: latency_sensitive stage 1 > 5%"]` |
| SCR-CANARYRE-053 | No "chatgpt" in content | string search | `self_check.failed_rules: ["SCR-CANARYRE-053: chatgpt brand word — BLOCKER"]` |