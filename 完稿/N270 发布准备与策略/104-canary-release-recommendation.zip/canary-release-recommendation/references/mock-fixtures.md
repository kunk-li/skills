## Mock input fixture

```yaml
mock_input:
  source: "service_name_traffic_info"
  content: "service: payment-service, current_rps: 10000, target_traffic_pct_start: 5"
  expected_output_shape:
    canary_plan:
      stages:
        min_count: 2
        stage_1_traffic_pct: "<= 10"
    abort_criteria:
      min_entries: 1
    self_check:
      passed: true
      warnings: ["Conservative defaults — provide slo_triplets to calibrate stage gates"]
```
