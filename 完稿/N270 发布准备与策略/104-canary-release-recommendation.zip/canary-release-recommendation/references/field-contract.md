# Field contract v2

Prefer `references/release-prep-artifact-contract-v2.md` for the full contract. This file remains as a compact backward-compatible summary.

Required metadata additions over v1:
- `schema_version`
- `artifact_version`
- `artifact_type`
- `output_certainty_grade`
- `emit_event`
- `circuit_breaker`

Required downstream handoff additions:
- `consumed_fields`
- `missing_evidence_blocks`
- `manual_decisions_required`
- `refresh_triggers`
- `sla_queue_items` when human confirmation is needed


---

## Field contract — canary_stage entry

| Field | Required | Values / notes |
|---|---|---|
| `stage_id` | yes | `stage_{N}` format |
| `traffic_pct` | yes | numeric 1–100; stage_1 ≤ 10 for medium+ risk |
| `duration` | yes | ISO 8601 or `{N}m` |
| `promotion_criteria` | yes | ≥ 1 measurable criterion with numeric threshold |
| `auto_halt_on_breach` | yes | boolean; always true for production |
| `rollback_trigger` | yes | condition string wired to rollback-plan-generation |
| `confidence` | yes | ∈ {high, medium, low, speculative} |