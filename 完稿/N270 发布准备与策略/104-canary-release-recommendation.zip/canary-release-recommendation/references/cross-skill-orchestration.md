# Compatibility pointer

This legacy filename is kept for backward compatibility. Use `references/release-prep-routing-and-orchestration-v2.md` as the canonical routing, composition, and closure-rule reference. Do not load both files for the same task.


---

## Boundary comparison table — canary vs release-risk vs release-task vs rollback

| Dimension | canary-release-recommendation | release-risk-assessment | release-task-orchestration | rollback-plan-generation |
|---|---|---|---|---|
| **Primary question** | "What traffic split strategy minimizes risk?" | "Should we release at all?" | "What is the execution sequence?" | "How do we reverse the rollout?" |
| **Output type** | Progressive rollout plan: stages, SLO gates, auto-halt, abort criteria | Risk register: 12 risk categories, composite score, go/no-go | Execution DAG: tasks, timeouts, approval gates | Rollback procedure: phases, triggers, SLA |
| **Timing** | After risk assessment clears, before execution | Before canary design | During execution window | Pre-planned alongside canary design |
| **Owns** | Stage traffic %, promotion criteria, auto-halt triggers, cohort selection | Risk scoring, holistic risk register | Task DAG, execution sequencing | Rollback phases, trigger conditions |
| **Does not own** | Risk scoring (→101), execution tasks (→108), rollback design (→105) | Canary shape (→104), gate tracking (→103) | Canary strategy (→104), risk analysis (→101) | Path selection (→121), execution (→108) |

### When NOT to use this skill
- **"What risks does the canary plan have?"** → release-risk-assessment, not canary design
- **"Execute the rollout"** → release-task-orchestration
- **"Roll back the canary"** → rollback-plan-generation + release-task-orchestration
- **"A stage failed, what do we do?"** → on-call-response-recommendation → remediation-plan-recommendation

### Canonical execution sequence
```
101 (risk gate) → 104 (canary design) → 108 (execution DAG)
                                      ↑ consumes canary plan as input
105 (rollback) → pre-planned alongside 104 → 108 wires rollback_triggers
```

---

## Routing decision tree
```
User question →
  "Design a canary/rollout plan" → canary-release-recommendation ✓ YOU ARE HERE
  "What risks does this release have?" → release-risk-assessment
  "Is this hotfix safe to ship?" → hotfix-risk-assessment
  "Execute the rollout" → release-task-orchestration
  "How do we reverse the rollout?" → rollback-plan-generation (105-rollback)
```