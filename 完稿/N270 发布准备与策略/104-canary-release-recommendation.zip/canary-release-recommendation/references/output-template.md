# Output template: 灰度发布建议.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: canary-release-recommendation
  schema_version: release-prep.canary_recommendation.v2
  artifact_version: 2.0.0
  artifact_type: canary_recommendation
  workflow_node: release-prep
  stage_position: release_and_delivery.release_preparation.canary_release_recommendation
  node_artifact_target: 灰度发布建议.md
  selected_mode: <mode>
  output_certainty_grade: decision_support_not_hard_gate
  readiness: green | amber | red
  function_bias: decision_support.canary_rollout_strategy
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.release-prep.canary_recommendation.v2
    event_version: 2
    producer_skill: canary-release-recommendation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `canary_summary`
- `canonical_skill_id_and_aliases`
- `canary_pattern`
- `cohort_strategy`
- `stage_plan[]`
- `promotion_metrics[]`
- `promotion_automation`
- `rollback_triggers[]`
- `human_review_gates[]`
- `monitoring_dashboards`
- `decision_limits`

End with:

```yaml
downstream_handoff:
  primary_consumers: [release-exec, release-validation, change-tracking]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```


---

## Downstream handoff YAML templates

### 正常路径：canary plan → release-task-orchestration
```yaml
downstream_handoff:
  produced_by: canary-release-recommendation
  artifact: 灰度发布建议.md
  emit_event:
    event_name: produced.release-prep.canary_recommendation.v2
    event_delivery: declared_only
  handoffs:
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "2-stage canary plan ready: Stage 1 (5% 30min), Stage 2 (25% 60min). SLO-based auto-halt active."
      required_fields:
        - canary_plan.stages
        - canary_plan.abort_criteria
        - circuit_breaker
        - rollback_triggers
      confidence: medium
      next_best_checks:
        - "108: wire canary_plan.stages as deploy DAG phases"
        - "108: wire rollback_triggers as circuit_breaker inputs"
        - "108: set approval gate between stage_1 and stage_2"
    - target: rollback-plan-generation
      handoff_type: action_hint
      summary: "Canary stage gates defined — wire rollback_triggers into rollback phases"
      required_fields: [rollback_triggers, abort_criteria]
      confidence: medium
      next_best_checks:
        - "105: confirm Phase 1 (feature flag off) covers stage_1 abort criteria"
  refresh_triggers:
    - skill: release-task-orchestration
      reason: "Canary plan updated — DAG phases must be regenerated"
      condition: "canary_plan.artifact_version > orchestration.source_104_version"
```

### 熔断路径：circuit breaker triggered
```yaml
downstream_handoff:
  handoffs:
    - target: on-call-response-recommendation
      handoff_type: routing
      summary: "URGENT: canary circuit breaker triggered at Stage 1. Active incident."
      urgency: immediate
    - target: rollback-plan-generation
      handoff_type: action_hint
      summary: "Initiate Phase 1 rollback immediately (feature flag off)"
      urgency: immediate
      blocking: true
```


---

## Standalone guarantee
This skill runs with only a release identity and traffic information. Never refuse because risk assessment is absent.

### Minimum standalone example — service name + traffic info only
```yaml
metadata:
  readiness: partial
  selected_mode: simple_canary
  output_certainty_grade: decision_support_not_hard_gate
evidence_profile:
  confirmed: [service_name, current_traffic_estimate]
  missing_evidence: [slo_triplets, risk_assessment, rollback_triggers]
  missing_evidence_impact: "Stage gates use conservative defaults. SLO trip triggers are static thresholds only."
canary_plan:
  release_id: payment-service-v2.1.3
  canary_strategy: simple_canary
  stages:
    - stage_id: stage_1
      traffic_pct: 5
      duration: 30m
      promotion_criteria:
        - metric: error_rate
          threshold: "< 1.0%"
          note: "Conservative default — provide SLO triplet to calibrate"
        - metric: p99_latency
          threshold: "< 500ms"
          note: "Conservative default"
      auto_halt_trigger: "error_rate > 2% for 5 consecutive minutes"
      rollback_authority: sre-oncall_no_approval_required
    - stage_id: stage_2
      traffic_pct: 25
      duration: 30m
      promotion_criteria:
        - metric: error_rate
          threshold: "< 1.0%"
      auto_halt_trigger: "error_rate > 2% for 5 consecutive minutes"
    - stage_id: stage_3
      traffic_pct: 100
      duration: 60m_observation
      promotion_criteria:
        - metric: slo_burn_rate
          threshold: "< 1.5×"
abort_criteria:
  - "Any P0 incident opened during canary"
  - "Error rate exceeds 2× static threshold at any stage"
downstream_handoff:
  to_skill: release-task-orchestration
  canary_stages: [stage_1, stage_2, stage_3]
  missing_evidence: [slo_triplets, risk_assessment]
self_check:
  passed: true
  warnings: ["Conservative defaults — provide slo_triplets and risk_assessment to calibrate stage gates"]
```

---

## Output completeness rule
Every canary artifact MUST include ALL of:
- `canary_plan.stages` ≥ 2 entries with ALL 7 fields above
- `canary_plan.abort_criteria` ≥ 1 measurable entry
- `circuit_breaker` section with `enabled: true` + `trigger` + `cooldown` ISO 8601
- `rollback_triggers` wired to skill 105 (rollback-plan-generation)
- `downstream_handoff` to release-task-orchestration
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry
- `consumer_impact_assessment` present
- `output_certainty_grade` ∈ {authoritative_artifact, decision_support_not_hard_gate}

**Hard rules:**
- `stage_1.traffic_pct` ≤ 5 when `composite_risk_score` > 0.5
- `circuit_breaker.enabled: true` ALWAYS — never false
- `auto_halt_on_breach: true` for every production stage

---

## Mode selection

### New: `shadow_mode` mode — 影子流量金丝雀（零用户影响）
**Trigger:** Team wants to test new service version with real traffic but without any user impact, or user says "shadow traffic", "dark launch", "traffic mirroring".

```yaml
shadow_mode:
  traffic_strategy: mirror_not_serve
  shadow_pct: 100  # 100% of prod traffic is mirrored to canary
  user_impact: zero  # shadow responses are discarded; users see prod responses only
  observation_window: 2h
  shadow_comparison:
    - metric: response_time_ms
      prod_p99: 145
      shadow_p99: 152
      delta_pct: 4.8
      acceptable: true
    - metric: error_rate
      prod: 0.28
      shadow: 0.31
      delta_pct: 10.7
      acceptable: false
      note: "Shadow error rate 10.7% higher — investigate before live traffic"
  shadow_verdict: not_ready_for_live
  promotion_to_live: blocked
  reason: "Shadow error rate delta >5% — resolve before proceeding to live canary"
  confidence: high
```
**SCR:** `selected_mode: shadow_mode` → `shadow_mode.user_impact: zero` always; `shadow_verdict` ∈ {ready_for_live, not_ready_for_live, inconclusive}.