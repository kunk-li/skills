# Output template: 灰度发布建议.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: canary-release-recommendation
  schema_version: n270.canary_recommendation.v2
  artifact_version: 2.0.0
  artifact_type: canary_recommendation
  workflow_node: N270
  stage_position: release_and_delivery.release_preparation.canary_release_recommendation
  node_artifact_target: 灰度发布建议.md
  selected_mode: <mode>
  output_certainty_grade: decision_support_not_hard_gate
  readiness: green | amber | red
  function_bias: decision_support.canary_rollout_strategy
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.n270.canary_recommendation.v2
    event_version: 2
    producer_skill: canary-release-recommendation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `canary_summary`
- `canonical_skill_id_and_aliases`
- `canary_pattern`
- `cohort_strategy`
- `stage_plan[]`
- `promotion_metrics[]`
- `promotion_automation`
- `rollback_triggers[]`
- `human_review_gates[]`
- `monitoring_dashboards`
- `decision_limits`

End with:

```yaml
downstream_handoff:
  primary_consumers: [N280, N290, N360]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```
