# real-examples — canary-release-recommendation

These examples illustrate how to produce this skill's artifact under different evidence conditions.
Use them as output calibration references — not as templates to copy verbatim.

---

## Example 1: Minimum viable input — readiness: amber (standalone, no risk assessment)

**Scenario:** Operator provides only service name and a risk label. No SLO triplets, no rollback plan yet.

**Input given:**
- Service: `payment-service v2.3.1`
- Risk posture: `amber` (stated verbally)
- Traffic profile: "mostly internal users first, then external"

**Expected output shape:**
```yaml
metadata:
  readiness: amber
  selected_mode: simple_canary
  evidence_profile:
    confirmed: [release_identity, risk_posture_verbal]
    missing_evidence:
      - slo_triplets (using conservative static thresholds)
      - rollback_plan artifact (using default abort triggers)
      - release-risk-assessment artifact (risk posture inferred from verbal)
    missing_evidence_impact: "Stage gates use static conservative thresholds; cannot calibrate to actual SLO baselines."
  output_certainty_grade: decision_support_not_hard_gate
canary_plan:
  stages:
    - stage_id: stage_1
      label: "Internal users only"
      traffic_pct: 5
      cohort: internal
      duration: PT30M
      gate_status: pending
      promotion_criteria:
        - metric: error_rate
          threshold: 0.5
          unit: percent
          source: assumed_static
        - metric: p99_latency_ms
          threshold: 500
          unit: ms
          source: assumed_static
      abort_criteria:
        - metric: error_rate
          threshold: 2.0
          action: halt_and_alert
    - stage_id: stage_2
      label: "5% external"
      traffic_pct: 5
      cohort: external_sample
      duration: PT1H
      gate_status: blocked_on_stage_1
    - stage_id: stage_3
      label: "Full rollout"
      traffic_pct: 100
      gate_status: blocked_on_stage_2
circuit_breaker:
  halt_on: [error_rate > 2%, p99_latency_ms > 1000]
  cooldown: PT20M
  escalation: on_call_pager
downstream_handoff:
  missing_evidence: [slo_triplets, rollback_plan, release_risk_assessment]
  next_best_checks:
    - "Run release-risk-assessment (105) to get a calibrated composite_risk_score"
    - "Provide rollback-plan-generation (103) output to tighten abort triggers"
self_check:
  passed: false
  failed_rules:
    - "SLO triplets absent — thresholds are static estimates, not calibrated"
    - "release-risk-assessment artifact missing — risk posture taken from verbal input"
```

**Key calibration:** Produce a useful 3-stage scaffold with conservative defaults. Never refuse because SLO triplets are absent.

---

## Example 2: Full evidence — readiness: green (advanced_canary with SLO triplets)

**Scenario:** Operator provides risk assessment (amber, composite 0.55), SLO triplets, rollback plan, and feature flag constraints.

**Input given:**
- `发布风险评估.md`: readiness amber, composite_risk_score 0.55, canary_recommended: true
- SLO triplets: `error_rate < 0.3% (30d baseline: 0.08%)`, `p99_latency_ms < 200ms (baseline: 120ms)`, `availability > 99.9%`
- Rollback plan: image rollback in 3min, DB-safe for 48h
- Feature flag: `payment_v2_enabled` — can disable per cohort

**Expected output shape:**
```yaml
metadata:
  readiness: green
  selected_mode: advanced_canary
  evidence_profile:
    confirmed: [release_risk_assessment, slo_triplets, rollback_plan, feature_flag_config]
    missing_evidence: []
  output_certainty_grade: decision_support_not_hard_gate
canary_plan:
  risk_calibration_source: release-risk-assessment.composite_risk_score=0.55
  stages:
    - stage_id: stage_1
      label: "1% — internal beta"
      traffic_pct: 1
      cohort: internal_beta
      duration: PT20M
      feature_flag_override: payment_v2_enabled=true for cohort
      promotion_criteria:
        - metric: error_rate
          threshold: 0.20    # tighter than SLO (0.3%) because stage_1 is lowest-risk gate
          unit: percent
          baseline: 0.08
          headroom_pct: 150
        - metric: p99_latency_ms
          threshold: 160     # 33% above baseline before SLO ceiling
          baseline: 120
        - metric: availability
          threshold: 99.95
      abort_criteria:
        - metric: error_rate
          threshold: 0.5
          action: flag_disable_then_alert
    - stage_id: stage_2
      label: "10% — external sample"
      traffic_pct: 10
      cohort: external_random_sample
      duration: PT1H
      promotion_criteria:
        - metric: error_rate
          threshold: 0.24    # tightened 20% vs stage_1 gate per contradiction rule
          baseline: 0.08
        - metric: p99_latency_ms
          threshold: 150
      gate_status: blocked_on_stage_1
    - stage_id: stage_3
      label: "100% — full rollout"
      traffic_pct: 100
      duration: PT2H
      gate_status: blocked_on_stage_2
circuit_breaker:
  halt_on: [error_rate > 0.5%, p99_latency_ms > 200, availability < 99.9]
  cooldown: PT20M
  rollback_trigger: rollback-plan-generation.phase_1 (image rollback, 3min SLA)
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "3-stage canary: 1%→10%→100%; SLO-calibrated gates; flag-disable abort path."
      required_fields: [canary_plan.stages, circuit_breaker, rollback_trigger]
self_check:
  passed: true
  warnings: []
```

**Key calibration:** Stage 2 gate tightens error_rate threshold by 20% per contradiction rule `all_stages_identical_slo_gates`. Document the calibration source explicitly.

---

## Example 3: High-risk, circuit breaker override — readiness: red

**Scenario:** release-risk-assessment returned composite_risk_score = 0.82 with recommendation no_go. Operator still asks for a canary plan.

**Input given:**
- `发布风险评估.md`: composite_risk_score 0.82, recommendation: no_go, blocker: schema_migration_with_no_rollback
- Operator: "Can you give me a canary plan anyway?"

**Expected output shape:**
```yaml
metadata:
  readiness: red
  selected_mode: blocked
  evidence_profile:
    confirmed: [release_risk_assessment]
  output_certainty_grade: decision_support_not_hard_gate
canary_plan: null
circuit_breaker:
  triggered: true
  trigger_reason: "release-risk-assessment.recommendation == no_go (composite_score 0.82 > 0.80 ceiling)"
  blocking_rule: contradiction_101_no_go
downstream_handoff:
  urgency: escalate
  next_best_checks:
    - "Resolve blocker: schema_migration_with_no_rollback → run rollback-plan-generation (103)"
    - "Re-run release-risk-assessment (105) after blocker resolution"
    - "Only proceed with canary design when 105 returns amber or green"
self_check:
  passed: false
  failed_rules:
    - "Cannot produce canary plan: release-risk-assessment.no_go is a hard block — resolve risk first"
```

**Key calibration:** Never produce a canary plan when upstream 105 issues no_go. Provide a clear resolution path instead.

---

## Example 4: Region-based canary — DB migration with time-bounded rollback window

**Scenario:** Payment service with a DB column rename migration. Rollback is only safe for 24h after deploy (old binaries can't read new column name after 24h due to caching).

**Input given:**
- Migration: ADD COLUMN `payment_reference_v2`, RENAME old `payment_ref` (soft delete, 7d grace period)
- Rollback window: 24h image-safe; 48h data-safe with manual column restore
- Risk: amber (composite 0.60), canary_recommended: true
- Regions: us-east-1 (primary, 60% traffic), eu-west-1 (30%), ap-northeast-1 (10%)

**Key calibration points in output:**
```yaml
canary_plan:
  selected_mode: region_based
  migration_constraint:
    rollback_window_hours: 24
    rollback_window_warning: "If stage_3 is not complete within 24h of stage_1 start, image rollback window closes."
    dba_checkpoint_required: true
    dba_checkpoint_at: "Before stage_3 (full prod)"
  stages:
    - stage_id: stage_1
      region: ap-northeast-1
      traffic_pct: 10   # 10% of global = full AP region
      rollback_safe: true
    - stage_id: stage_2
      region: eu-west-1
      traffic_pct: 40
      rollback_safe: true
      note: "Must complete within T+18h to leave 6h buffer before rollback window closes"
    - stage_id: stage_3
      region: us-east-1
      traffic_pct: 100
      rollback_safe: conditional
      note: "If reached before T+24h, image rollback still possible. After T+24h, rollback requires DBA manual column restore."
  circuit_breaker:
    halt_on: [error_rate > 0.5%, migration_validation_failed]
    emergency_abort: rollback-plan-generation.phase_1 (image rollback within 24h window)
```

**Key calibration:** Always surface time-bounded rollback windows as explicit constraints. Never silently omit the window in the stage plan.

---

## Example 5: shadow_first mode — new ML inference endpoint

**Scenario:** New ML recommendation endpoint. Cannot afford production traffic errors. Shadow mode required before any live traffic.

**Key calibration:**
```yaml
canary_plan:
  selected_mode: shadow_first
  shadow_phase:
    traffic_pct: 0    # mirrors 100% of prod traffic; responses discarded
    duration: PT4H
    metrics_collected: [latency_p50_p99, error_rate, model_accuracy_proxy]
    promotion_threshold: "shadow error_rate < 0.1% for 2 consecutive hours"
  stages:
    - stage_id: stage_1
      label: "1% live after shadow validation"
      traffic_pct: 1
      gate_status: blocked_on_shadow_phase
      promotion_criteria:
        - metric: error_rate
          threshold: 0.1
        - metric: recommendation_click_rate
          threshold: 0.85   # must not degrade vs baseline
```
