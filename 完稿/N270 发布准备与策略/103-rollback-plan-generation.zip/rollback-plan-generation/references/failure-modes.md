# failure modes

| id | failure mode | required response |
|---|---|---|
| `RB-F1` | Paper rollback without tested path | Mark readiness red or amber until dry-run or restore evidence exists. |
| `RB-F2` | Ignoring irreversible changes | List irreversible_changes[] and recommend forward-compatible or compensation strategies. |
| `RB-F3` | No rollback trigger | Define automatic and manual triggers with thresholds, duration, and authority. |
| `RB-F4` | No post-rollback verification | Require smoke, data integrity, and user-impact checks after rollback. |
| `RB-F5` | Rollback when forward fix is safer | Use rollback_vs_forward_fix_matrix and explain decision rationale. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.


---

## Degradation — confidence quantification extended

### Extended rules

```yaml
confidence_quantification_extended:
  irreversible_without_dba:
    trigger: "Phase includes schema rollback AND dba_approval = pending/absent"
    ceiling: none
    readiness: red
    action: "Block Phase 3+ execution — DBA approval mandatory for schema rollback"
  multiple_phases_untested:
    trigger: "Phases 2+ have dry_run_evidence: not_performed"
    ceiling: medium  # cap at medium when only Phase 1 tested
    note: "Phase 1 tested only; Phases 2+ require explicit dry_run before production use"
  stale_dry_run:
    trigger: "dry_run older than 14 days for a new deployment"
    ceiling: low
    note: "Dry run stale (>14d) — re-rehearse before using as evidence"
  canary_abort_scenario:
    trigger: "selected_mode: canary_abort"
    ceiling: high
    note: "Canary abort: only 5-10% traffic affected; rollback is inherently low-risk"
    irreversible_items: []  # always empty for canary_abort
```

### readiness: amber — Phase 2 dry_run 未执行，高风险

```yaml
metadata:
  readiness: amber
  selected_mode: blue_green_rollback
evidence_profile:
  confirmed: [phase_1_dry_run]
  missing_evidence: [phase_2_dry_run, phase_3_dry_run]
  confidence_ceiling_applied: medium
rollback_plan:
  rollback_phases:
    - phase: 1
      dry_run_evidence: confirmed
      status: ready
    - phase: 2
      phase_name: database_connection_switch
      dry_run_evidence: not_performed
      status: conditional  # amber: needs dry_run before production use
      note: "Phase 2 untested — perform dry_run in staging before relying on this phase"
config_state:
  overall_ready_to_proceed: false
  reason: "Phase 2 dry_run not performed — conditional only"
self_check:
  passed: true
  warnings: ["amber — Phase 2 dry_run not_performed; confidence capped at medium"]
```
