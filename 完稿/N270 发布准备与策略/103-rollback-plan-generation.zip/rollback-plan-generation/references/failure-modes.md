# failure modes

| id | failure mode | required response |
|---|---|---|
| `RB-F1` | Paper rollback without tested path | Mark readiness red or amber until dry-run or restore evidence exists. |
| `RB-F2` | Ignoring irreversible changes | List irreversible_changes[] and recommend forward-compatible or compensation strategies. |
| `RB-F3` | No rollback trigger | Define automatic and manual triggers with thresholds, duration, and authority. |
| `RB-F4` | No post-rollback verification | Require smoke, data integrity, and user-impact checks after rollback. |
| `RB-F5` | Rollback when forward fix is safer | Use rollback_vs_forward_fix_matrix and explain decision rationale. |

If a failure mode is triggered, keep the artifact contract stable, lower readiness as needed, and make the recovery action explicit in `self_check.failed_rules` and `downstream_handoff.manual_decisions_required`.
