## Mock input fixture

```yaml
mock_input:
  source: "service_name_and_target_only"
  content: "service: payment-service, deployment_target: production"
  expected_output_shape:
    rollback_plan:
      rollback_phases: ">= 2 phases"
      rollback_triggers: ">= 1 trigger"
      rollback_time_windows: ">= 2 windows"
      irreversible_items: "[] or populated"
    self_check:
      passed: true
      warnings: ["Conservative defaults — refine with actual topology"]
```
