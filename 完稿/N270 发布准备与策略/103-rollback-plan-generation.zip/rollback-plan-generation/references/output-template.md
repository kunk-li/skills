# Output template: 回滚预案.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: rollback-plan-generation
  schema_version: release-prep.rollback_plan.v2
  artifact_version: 2.0.0
  artifact_type: rollback_plan
  workflow_node: release-prep
  stage_position: release_and_delivery.release_preparation.rollback_plan_generation
  node_artifact_target: 回滚预案.md
  selected_mode: <mode>
  output_certainty_grade: authoritative_artifact
  readiness: green | amber | red
  function_bias: direct_result.rollback_path_and_rehearsal_readiness
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.release-prep.rollback_plan.v2
    event_version: 2
    producer_skill: rollback-plan-generation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `rollback_summary`
- `strategy_selection[]`
- `rollback_phases[]`
- `irreversible_changes[]`
- `data_rollback_handling`
- `trigger_conditions[]`
- `verification_steps[]`
- `communication_plan`
- `rollback_time_windows[]`
- `dry_run_evidence[]`
- `decision_support`

End with:

```yaml
downstream_handoff:
  primary_consumers: [release-exec, release-validation, change-tracking]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```


---

## Downstream handoff YAML templates

### 正常路径: rollback plan → release-task-orchestration + release-risk-assessment
```yaml
downstream_handoff:
  produced_by: rollback-plan-generation
  artifact: 回滚预案.md
  emit_event:
    event_name: produced.release-prep.rollback_plan.v2
    event_delivery: declared_only
  handoffs:
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "Rollback plan ready: Phase 1 (flag off 2min) + Phase 2 (image rollback 12min). SLA: 15min total."
      required_fields:
        - rollback_plan.rollback_phases
        - rollback_plan.rollback_triggers
        - rollback_plan.rollback_time_windows
        - rollback_plan.irreversible_items
      confidence: medium
      next_best_checks:
        - "108: wire rollback_triggers as circuit_breaker inputs in deploy DAG"
        - "108: add Phase 1 + Phase 2 as P5_stabilize tasks"
    - target: release-risk-assessment
      handoff_type: evidence
      summary: "Rollback plan ready (Phase 1+2 confirmed, dry_run: confirmed) — lower rollback_risk dimension"
      required_fields: [rollback_plan.rollback_strategy, dry_run_evidence, rollback_sla]
      confidence: medium
  refresh_triggers:
    - skill: release-task-orchestration
      reason: "Rollback phases updated — circuit_breaker configuration must be regenerated"
      condition: "rollback_plan.rollback_phases changed since 108 consumed this artifact"
```

### 降级: Phase 3/4 缺少 dry_run
```yaml
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      handoff_type: gap
      summary: "Phase 2 SLA unconfirmed (no rehearsal). Use conservative DAG timeout."
      confidence: low
      missing_evidence: [phase_2_dry_run_evidence]
      next_best_checks:
        - "Rehearse rollback in staging before wiring into DAG"
```


---

## Standalone guarantee
This skill runs with only a release identity and change scope. Do not refuse because 105 or other release-prep skills have not been run.

### Minimum standalone example — service name + deployment target only
```yaml
metadata:
  readiness: partial
  selected_mode: simple_rollback
  output_certainty_grade: authoritative_artifact
evidence_profile:
  confirmed: [service_name, deployment_target]
  missing_evidence: [release_manifest, slo_triplets, data_migration_details]
  missing_evidence_impact: "Rollback phases use conservative defaults. Triggers and SLA are placeholders pending evidence."
rollback_plan:
  release_id: payment-service-v2.1.3
  rollback_strategy: image_tag_revert
  rollback_sla: 30m    # conservative default; refine with actual deployment topology
  rollback_phases:
    - phase: 1
      name: pre-rollback checks
      actions:
        - "Confirm rollback target version (default: previous stable tag)"
        - "Verify no active DB migrations were applied"
        - "Confirm rollback ownership with release-manager"
      owner: release-manager
      duration_estimate: 5m
    - phase: 2
      name: execute rollback
      actions:
        - "kubectl set image deployment/payment-service payment-service={previous_tag}"
        - "Monitor pod readiness for 3 minutes"
      owner: devops-team
      duration_estimate: 10m
    - phase: 3
      name: post-rollback validation
      actions:
        - "Run smoke test against /health and /checkout"
        - "Confirm error rate returns to baseline within 5 minutes"
      owner: sre-team
      duration_estimate: 10m
rollback_triggers:
  - trigger_id: RT-001
    condition: "error_rate > 2% for 5 consecutive minutes after deploy"
    action: initiate_phase_1_immediately
    authority: sre-oncall_no_approval_required
  - trigger_id: RT-002
    condition: "P0 smoke test fails post-deploy"
    action: initiate_phase_1_immediately
    authority: automated
rollback_time_windows:
  - phase: post_deploy_safe_window
    window_end: T+30m
    rollback_safe: true
  - phase: forward_fix_only
    window_start: T+4h
    rollback_safe: false
    escalation_action: "Require release-manager approval before rollback"
irreversible_items: []
blockers_and_pending:
  - item: "Rollback target version not confirmed"
    severity: P1
    action: "Specify previous_stable_tag before executing Phase 2"
downstream_handoff:
  to_skill: release-task-orchestration
  missing_evidence: [data_migration_status, slo_triplets]
self_check:
  passed: true
  warnings: ["Rollback SLA is conservative default — refine with actual topology"]
```

### Full-spectrum example — data migration present (irreversibility risk)
```yaml
metadata:
  readiness: amber
  selected_mode: full_spectrum
rollback_plan:
  rollback_strategy: partial_rollback_with_forward_fix_fallback
  irreversible_items:
    - item_id: IRREV-001
      description: "Column 'user_tier' added to payments table — schema migration is irreversible"
      risk: backward_incompatible_if_old_code_deployed
      mitigation: "Keep new column nullable with default NULL. Old code ignores it."
      forward_fix_required_after: T+2h
  rollback_triggers:
    - trigger_id: RT-001
      condition: "error_rate > 1% within first 30 min"
      action: "Initiate rollback ONLY if data_mutation_count < 100 records (check DB log first)"
```

**Key calibration:** When `irreversible_items` exist, rollback is conditional. Always include a `mitigation` and `forward_fix_required_after` field. Set `rollback_safe: conditional` in the corresponding time window.

---

## Output completeness rule
Every rollback artifact MUST include ALL of:
- `rollback_plan.rollback_phases` ≥ 1 phase with ALL 8 fields above
- `rollback_plan.rollback_strategy` ∈ {feature_flag, blue_green, rolling_restart, database_schema_rollback, canary_abort, multi_phase}
- `rollback_plan.rollback_time_windows` with `rollback_safe: true` window declared
- `rollback_plan.irreversible_items` (may be `[]`)
- `rollback_plan.rollback_triggers` ≥ 1 measurable trigger
- `config_state.overall_ready_to_proceed` boolean
- `consumer_impact_assessment` present
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1

---

## Mode selection

### New: `canary_abort` mode — 金丝雀终止回滚
**Trigger:** Canary deployment is being aborted mid-stage and requires rollback only of the canary traffic slice, not full deployment.

```yaml
canary_abort:
  canary_stage_aborted: stage_1
  traffic_at_abort: "5%"
  abort_reason: "error_rate 4.2% > 0.5% threshold at T+12min"
  rollback_approach: traffic_reroute_only
  phases:
    - phase: 1
      phase_name: traffic_reroute
      action: "Route 100% traffic back to stable version (remove canary from load balancer)"
      duration_estimate: 2m
      rollback_sla: 3m
      dry_run_evidence: confirmed
      data_compatibility_assumption: "Only 5% traffic was on canary; no state migration needed"
      owner: devops-oncall
  irreversible_items: []
  total_affected_users_during_canary: "~620 (5% of 12400)"
  note: "Canary abort is inherently low-risk — only 5% of traffic was affected"
```
**SCR:** `selected_mode: canary_abort` → `canary_abort.canary_stage_aborted` declared; `rollback_approach: traffic_reroute_only`.

---

## Downstream handoff YAML templates

### 正常路径：rollback plan 移交 release-risk-assessment + release-task-orchestration
```yaml
downstream_handoff:
  produced_by: rollback-plan-generation
  artifact: 回滚预案.md
  emit_event:
    event_name: produced.release-prep.rollback_plan.v2
    event_delivery: declared_only
  handoffs:
    - target: release-risk-assessment
      handoff_type: evidence
      summary: "Rollback plan ready: Phase 1+2 confirmed, dry_run_evidence=confirmed, SLA=15min"
      required_fields: [rollback_phases, rollback_sla, dry_run_evidence, irreversible_items]
      confidence: high
      next_best_checks:
        - "release-risk-assessment: use rollback_safe=true to lower rollback_risk dimension"
    - target: release-task-orchestration
      handoff_type: action_hint
      summary: "Rollback DAG: Phase 1 (feature flag off, 2min) → Phase 2 (image rollback, 8min)"
      required_fields: [rollback_phases[].actions, rollback_triggers, rollback_sla]
      confidence: high
      next_best_checks:
        - "Add rollback tasks as P5_stabilize phase in release DAG"
        - "Wire rollback_triggers as circuit breaker inputs"
```

### 有不可逆项时的降级路径
```yaml
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      handoff_type: gap
      summary: "IRREV-001: schema migration irreversible after T+2h. Phase 3 requires DBA approval."
      required_fields: [irreversible_items, rollback_time_windows]
      confidence: high
      next_best_checks:
        - "Schedule DBA approval gate in release DAG before T+2h"
        - "Add forward_fix_threshold alert to monitoring dashboard"
```



---

## Downstream handoff

### 正常路径: ready → 108
```yaml
downstream_handoff:
  produced_by: rollback-plan-generation
  artifact: 回滚预案.md
  emit_event:
    event_name: produced.release-prep.rollback_plan.v2
  handoffs:
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "Rollback plan ready. Phase 1: flag disable (2min). Phase 2: image rollback (8min). Total: 10min."
      required_fields: [rollback_plan.rollback_phases, rollback_plan.rollback_triggers, config_state]
      confidence: high
      next_best_checks:
        - "108: wire rollback Phase 1 trigger into P3 circuit breaker on_failure"
        - "108: confirm maintenance window covers estimated 10min rollback SLA"
    - target: release-risk-assessment
      handoff_type: evidence
      summary: "Rollback plan available — rollback_risk dimension can be scored now"
      confidence: high
  refresh_triggers:
    - skill: release-task-orchestration
      reason: "Rollback plan updated — DAG wiring must be regenerated"
      condition: "rollback_plan.rollback_phases or rollback_triggers change"
    - skill: release-risk-assessment
      reason: "Rollback evidence changed — rollback_risk score may change"
      condition: "config_state.overall_ready_to_proceed changes"
```

### 阻断路径: red (DBA unavailable)
```yaml
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      handoff_type: gap
      blocking: true
      summary: "BLOCKED: Phase 3 DBA approval required but unavailable. Do NOT proceed with 108."
```

