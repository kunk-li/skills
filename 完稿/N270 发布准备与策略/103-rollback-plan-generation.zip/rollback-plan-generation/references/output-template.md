# Output template: 回滚预案.md

Start every artifact with this contract envelope:

```yaml
metadata:
  skill_id: rollback-plan-generation
  schema_version: n270.rollback_plan.v2
  artifact_version: 2.0.0
  artifact_type: rollback_plan
  workflow_node: N270
  stage_position: release_and_delivery.release_preparation.rollback_plan_generation
  node_artifact_target: 回滚预案.md
  selected_mode: <mode>
  output_certainty_grade: authoritative_artifact
  readiness: green | amber | red
  function_bias: direct_result.rollback_path_and_rehearsal_readiness
  tool_collaboration_mode: standalone | composed | validation_only
  emit_event:
    event_name: produced.n270.rollback_plan.v2
    event_version: 2
    producer_skill: rollback-plan-generation
  circuit_breaker:
    source_loop: none
    iter_count: 0
    max_iter: 3
    cooldown: PT30M
    escalation_target: release_manager

evidence_profile:
  confirmed_evidence: []
  assumptions: []
  missing_evidence: []
```

Then include these sections:

- `rollback_summary`
- `strategy_selection[]`
- `rollback_phases[]`
- `irreversible_changes[]`
- `data_rollback_handling`
- `trigger_conditions[]`
- `verification_steps[]`
- `communication_plan`
- `rollback_time_windows[]`
- `dry_run_evidence[]`
- `decision_support`

End with:

```yaml
downstream_handoff:
  primary_consumers: [N280, N290, N360]
  consumed_fields: []
  missing_evidence_blocks: []
  manual_decisions_required: []
  refresh_triggers: []
self_check:
  passed: true
  failed_rules: []
```
