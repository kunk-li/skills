# Field contract v2

Prefer `references/release-prep-artifact-contract-v2.md` for the full contract. This file remains as a compact backward-compatible summary.

Required metadata additions over v1:
- `schema_version`
- `artifact_version`
- `artifact_type`
- `output_certainty_grade`
- `emit_event`
- `circuit_breaker`

Required downstream handoff additions:
- `consumed_fields`
- `missing_evidence_blocks`
- `manual_decisions_required`
- `refresh_triggers`
- `sla_queue_items` when human confirmation is needed


---

## Field contract — rollback_phase entry

| Field | Required | Values / notes |
|---|---|---|
| `phase` | yes | integer 1-N |
| `phase_name` | yes | descriptive string |
| `action` | yes | imperative action |
| `rollback_sla` | yes | ISO 8601 duration or `"{N}m"` |
| `owner` | yes | role string |
| `dry_run_evidence` | yes | ∈ {confirmed, not_performed, not_applicable} |
| `data_compatibility_assumption` | yes | string explaining data safety |
| `on_failure` | yes | ∈ {escalate, manual_decision, abort_rollback} |

---

## Rollback safety window escalation rule
`rollback_time_windows[]` must include a `forward_fix_threshold` for each phase. When the current time exceeds the threshold, the recommended strategy automatically escalates to `forward_fix` regardless of operator preference:

```yaml
rollback_time_windows:
  - phase: post_deploy_safe_window
    window_start: T+0m
    window_end: T+30m
    rollback_safe: true
    forward_fix_threshold: null   # rollback preferred in this window
    note: "Rollback is fastest and lowest risk within 30 minutes of deploy"
  - phase: degraded_window
    window_start: T+30m
    window_end: T+4h
    rollback_safe: conditional
    forward_fix_threshold: T+2h
    note: "After T+2h, rollback risk may exceed forward fix risk if stateful data has accumulated"
    escalation_trigger: "If rollback_time > forward_fix_threshold AND data mutation confirmed → escalate to forward_fix"
  - phase: forward_fix_only
    window_start: T+4h
    rollback_safe: false
    forward_fix_threshold: T+0m   # immediately at phase entry
    note: "Rollback not recommended. Stateful changes or user data accumulation makes rollback higher risk than forward fix."
    escalation_action: "Notify release-manager. Require explicit rollback-authorization before proceeding."
```

When emitting `rollback_time_windows[]`, always include at least one phase with `rollback_safe: false` and its `escalation_action` for releases containing stateful changes, schema migrations, or external side effects.

