# Compatibility pointer

This legacy filename is kept for backward compatibility. Use `references/release-prep-routing-and-orchestration-v2.md` as the canonical routing, composition, and closure-rule reference. Do not load both files for the same task.


---

## Boundary comparison table — rollback vs remediation vs release-risk vs release-task

| Dimension | rollback-plan-generation (105-rollback) | remediation-plan-recommendation | release-risk-assessment | release-task-orchestration |
|---|---|---|---|---|
| **Primary question** | "HOW do we roll back if needed?" | "SHOULD we roll back, hotfix, or contain?" | "Should we deploy at all?" | "How do we sequence deploy+rollback as tasks?" |
| **Output type** | Procedure document: phases, triggers, SLA, dry-run evidence | Option comparison: 2-3 paths with ROI and recommendation | Risk register with composite score | Execution DAG with timeouts and failure policies |
| **Decision authority** | Designs the procedure; does NOT decide whether to execute | Recommends which path; does NOT design procedures | Recommends go/no-go; does NOT design rollback | Sequences execution; does NOT design content |
| **Timing** | Pre-deploy planning | During or after incident | Pre-deploy risk gate | Deploy execution window |
| **Owns** | Phase ladder, trigger conditions, rollback SLA, dry-run evidence, irreversible items | Path comparison, feasibility, TTR estimates, recommended path | Risk scoring, category analysis, composite score | Task ordering, dependencies, approval gates, circuit breaker |
| **Does not own** | Path selection (→121), risk scoring (→101), execution DAG (→108) | Procedure design (→105-rollback), execution (→108) | Rollback design (→105-rollback), task sequencing (→108) | Rollback procedure design (→105-rollback) |

### Routing decision tree
```
User asks...
"How do we roll back version X?"                    → rollback-plan-generation ✓
"Should we roll back or hotfix?"                    → remediation-plan-recommendation
"Is this release safe to ship?"                     → release-risk-assessment
"What tasks need to run during deploy?"             → release-task-orchestration
"Design the rollback phases and triggers"           → rollback-plan-generation ✓
"Assess risk of executing the rollback"             → hotfix-risk-assessment

Canonical sequence: 101 (risk) → 105-rollback (design) → 108 (sequence) → 121/122 (decide if needed)
```

### Hard ownership rules
- **rollback-plan MUST NOT contain**: execution DAG, task timeouts, approval gate sequence → route to 108
- **rollback-plan MUST NOT contain**: path recommendation (rollback vs hotfix) → route to 121
- **rollback-plan MUST contain**: Phase 1 and Phase 2 at minimum, even for simple deployments

---

## Boundary comparison table — rollback complete 4-column

| Dimension | rollback-plan-generation | remediation-plan-recommendation | release-task-orchestration | hotfix-risk-assessment |
|---|---|---|---|---|
| **Primary question** | "HOW do we roll back, phase by phase?" | "SHOULD we roll back, hotfix, or contain?" | "How do we sequence rollback as tasks?" | "Is this hotfix safe to deploy?" |
| **Output type** | Procedure: phases, SLAs, triggers, irreversible items | Option comparison: 2-3 paths with TTR and recommendation | Execution DAG with rollback as P5_stabilize phase | Go/no-go verdict with mandatory gate checklist |
| **Timing** | Pre-deploy planning OR triggered during incident | During incident: post-containment decision | Execution window | After fix is designed |
| **Owns** | Phase ladder design, SLA commitments, dry-run evidence, irreversible_items classification | Path selection (rollback vs hotfix vs contain), TTR estimates | Rollback task ordering, circuit breaker wiring | Mandatory gate assessment, compliance check |
| **Does not own** | WHETHER to roll back (→121), SEQUENCING as tasks (→108), hotfix safety (→122) | Procedure design (→105), execution (→108) | Rollback procedure (→105), path decision (→121) | Procedure design (→105), path decision (→121) |

### When to call 105 vs 121
```
"Design the rollback plan"              → rollback-plan-generation ✓
"Should we roll back or hotfix?"        → remediation-plan-recommendation
"Execute the rollback now"              → release-task-orchestration
"Is the hotfix safe to deploy?"         → hotfix-risk-assessment
"What phases does rollback need?"       → rollback-plan-generation ✓
"Rollback failed — what next?"          → on-call → remediation
```

### Mandatory sequencing rule
```
Canonical incident flow:
on-call → RCA → remediation → rollback → release-task
                                              ↘ hotfix-risk → release-task

105 always designed BEFORE incident starts (pre-deploy)
105 EXECUTED via 108, not directly
```



---

## Boundary comparison table — rollback complete

| Dimension | rollback-plan-generation | remediation-plan-recommendation | release-task-orchestration | release-risk-assessment |
|---|---|---|---|---|
| **Core question** | "HOW do we reverse the deployment?" | "WHICH fix path should we take?" | "HOW do we execute the deploy/rollback?" | "Is the overall release SAFE to attempt?" |
| **Output** | Multi-phase rollback procedure: phases, SLAs, dry_run_evidence, irreversible_items | Option comparison: rollback vs hotfix vs containment with TTR and confidence | Executable DAG: tasks, gates, circuit breaker | Risk register: 12 dimensions, composite score |
| **Timing** | Pre-deploy (design before deploy) · Post-decision (execute after 121 selects rollback) | Post-incident (after containment phase) | Pre-deploy + post-incident | Pre-deploy only |
| **Owns** | Rollback procedure design, phase sequencing, dry_run scheduling, SLA guarantees | Fix path selection, TTR comparison, data risk assessment | Execution sequencing, gate management, circuit breaker | Risk dimension scoring, go/no-go |
| **Does not own** | Fix path selection (→121) · Execution (→108) · Overall release risk (→101) | Rollback procedure design (→105) · Execution (→108) | Rollback design (→105) · Fix selection (→121) | Rollback details (→105) · Execution (→108) |

### Hard rules
```
105 MUST be designed BEFORE deployment (pre-deploy safety artifact)
105 MUST be consumed by 108 for rollback wiring — never by 121 for decision
121 decides WHETHER to rollback → 105+108 execute HOW
canary_abort mode in 105 is only for mid-canary aborts, not full rollback
```

