# Quality checklist v2

A strong release-prep artifact:
- exposes `schema_version`, `artifact_version`, `emit_event`, and `circuit_breaker`
- declares minimum, primary discriminating, common, and optional inputs
- is explicitly tied to the official release-prep output name
- references the shared `release_manifest` without requiring all six release-prep artifacts for standalone use
- names blockers, mitigations, owners, SLA, and remaining unknowns directly
- keeps direct-result artifacts separate from decision-support artifacts
- makes downstream use in release-exec, release-validation, and change-tracking obvious
- emits refresh triggers when peer artifacts should be regenerated


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-ROLLBACK-051 | Every phase has `data_compatibility_assumption` | key exists per phase | `self_check.warnings: ["SCR-ROLLBACK-051: phase missing data_compatibility_assumption"]` |
| SCR-ROLLBACK-052 | `feedback_signal_candidates` ≥ 1 | count ≥ 1 | `self_check.warnings: ["SCR-ROLLBACK-052: FSC missing"]` |
| SCR-ROLLBACK-053 | When `readiness: red`: `config_state.overall_ready_to_proceed: false` | conditional | `self_check.failed_rules: ["SCR-ROLLBACK-053: red readiness without blocking flag"]` |