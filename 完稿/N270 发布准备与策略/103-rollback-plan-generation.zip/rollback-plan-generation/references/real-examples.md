# real examples

Example signals worth highlighting:
- release contains a DB migration and a new config flag
- canary is limited to internal users first because business blast radius is high
- rollback is image-safe for 24h only because old binaries cannot read new long-lived data after that

---

## Additional scenario: amber degradation — missing commit history

**Scenario:** Skill invoked with only a ticket ID and a one-line change description. No PR, no diff.

**Expected behavior:**
- Produce the artifact in the most useful mode given available evidence.
- Declare `readiness: partial` with explicit `missing_evidence`.
- Populate all stable output sections; use `unknown` or `inferred` for fields that cannot be determined.
- `downstream_handoff.missing_evidence` lists what is needed to reach `readiness: green`.
- `self_check.passed: false` with the specific rule that failed.

**Key calibration:** Never refuse output due to missing optional inputs. A partial artifact with clear evidence gaps is more useful than no artifact. The consumer (release manager, SRE, or next skill) uses the `missing_evidence` list to decide whether to proceed or gather more evidence first.

---

## Example 4: schema migration with irreversible items

**Scenario:** Deploy includes a DB column addition. Column is nullable — partial rollback possible.

```yaml
metadata:
  readiness: amber
  selected_mode: full_spectrum
rollback_plan:
  rollback_strategy: partial_rollback_with_forward_fix_fallback
  irreversible_items:
    - item_id: IRREV-001
      description: "Column 'user_tier' added to payments table (nullable, default NULL)"
      risk: backward_incompatible_if_old_code_reads_new_column
      mitigation: "Old code ignores unknown columns in ORM. Safe to run old code against new schema."
      forward_fix_required_after: "T+2h"
      dry_run_evidence: confirmed
  rollback_phases:
    - phase: 1
      phase_name: phase_1_feature_flag
      actions: ["Disable feature flag 'user_tier_display' in admin panel"]
      owner: product-team
      duration_estimate: 2m
      dry_run_evidence: confirmed
      rollback_sla: 5m
      data_compatibility_assumption: "Feature flag disables new code path; schema change is benign"
      approval_requirement: none
    - phase: 2
      phase_name: phase_2_image_rollback
      actions: ["kubectl set image deployment/payments payments=v2.1.2"]
      owner: devops-team
      duration_estimate: 8m
      dry_run_evidence: confirmed
      rollback_sla: 15m
      data_compatibility_assumption: "v2.1.2 code ignores user_tier column"
      approval_requirement: oncall_lead
  rollback_triggers:
    - trigger_id: RT-001
      condition: "error_rate > 2% for 5 consecutive minutes after deploy"
      action: initiate_phase_1
      authority: sre-oncall
      measurement_method: "Grafana alert: payment_error_rate > 2% for 5m"
rollback_time_windows:
  - phase: post_deploy_safe_window
    window_end: T+30m
    rollback_safe: true
  - phase: degraded_window
    window_start: T+30m
    window_end: T+4h
    rollback_safe: conditional
    forward_fix_threshold: T+2h
  - phase: forward_fix_only
    window_start: T+4h
    rollback_safe: false
    escalation_action: "Require DBA approval and data migration plan before any rollback"
self_check:
  passed: true
```

---

## Example 5: rehearsal_coach mode — dry-run preparation

**Scenario:** Team wants to rehearse the rollback before the deploy window.

```yaml
metadata:
  readiness: green
  selected_mode: rehearsal_coach
rollback_plan:
  rehearsal_steps:
    - step: 1
      name: "Verify rollback target availability"
      action: "kubectl rollout history payment-service — confirm v2.1.2 is in history"
      success_criteria: "Previous revision listed in rollout history"
      time_estimate: 2m
    - step: 2
      name: "Test rollback command (staging)"
      action: "kubectl rollout undo deployment/payment-service --to-revision=2 (staging only)"
      success_criteria: "Pod restarts and health check passes within 3 minutes"
      time_estimate: 5m
    - step: 3
      name: "Confirm monitoring alerts fire correctly"
      action: "Trigger a mock 2% error rate spike; verify Grafana alert fires within 1m"
      success_criteria: "Alert received in Slack #incidents channel"
      time_estimate: 5m
  rehearsal_verdict:
    all_steps_passed: true
    dry_run_evidence: confirmed
    rollback_confidence: high
    rehearsal_notes: "All steps completed in staging at 2026-05-19T10:00Z. Rollback SLA: 12m actual."
self_check:
  passed: true
```

---

## Example 5: Stale dry-run (>14 days) — confidence ceiling lowered

**Scenario:** Rollback plan was rehearsed 22 days ago. A new deployment requires the plan, but the stale dry-run cap applies.

**Input given:**
- Rollback rehearsal: completed 22 days ago in staging
- Current deployment: payment-service v2.4 (different from v2.2 at rehearsal time)
- DBA approval: confirmed for schema phase

**Expected output shape:**
```yaml
metadata:
  readiness: amber
  selected_mode: full_rollback
  evidence_profile:
    confirmed: [rehearsal_evidence_stale, dba_approval]
    missing_evidence: [fresh_dry_run]
    confidence_ceiling_applied: low    # stale_dry_run rule: > 14 days → ceiling: low
    confidence_ceiling_reason: "Dry run is 22 days old — re-rehearse before production use"
rollback_plan:
  rollback_phases:
    - phase: 1
      phase_name: "Feature flag disable"
      dry_run_evidence: stale     # was confirmed, now stale
      dry_run_age_days: 22
      status: conditional
      confidence: low             # ceiling applied
      sla_basis: historical_or_estimate
      estimated_sla_min: 3
      note: "Stale dry run (22d) — re-rehearse in staging before this deployment"
    - phase: 2
      phase_name: "Image rollback"
      dry_run_evidence: stale
      dry_run_age_days: 22
      status: conditional
      confidence: low
    - phase: 3
      phase_name: "Schema revert"
      dry_run_evidence: not_performed
      dba_approval: confirmed
      status: conditional
      confidence: low
irreversible_items:
  - item: "Schema revert requires DBA manual column restore if > 24h post-deploy"
    window_hours: 24
downstream_handoff:
  missing_evidence: [fresh_dry_run]
  next_best_checks:
    - "Re-rehearse all 3 phases in staging before this deployment — stale dry run (22d) applies confidence ceiling"
    - "If fresh rehearsal not possible, obtain release manager explicit risk acceptance"
self_check:
  passed: true
  warnings:
    - "amber — stale dry_run (22d > 14d threshold); confidence ceiling: low applied to all phases"
    - "Re-rehearse recommended before production deployment"
```

**Key calibration:** Stale dry-run (> 14 days) is a confidence ceiling rule, not a hard blocker. `readiness: amber` not `red` — the plan is still useful but flagged for re-rehearsal. Always note the rehearsal age in days and the specific re-rehearsal recommendation.

---

## Example 6: Minimum viable input — readiness: partial (no deployment context)

**Scenario:** Operator asks for a rollback plan before any PR or deployment details are available.

**Input given:** "We're deploying payment-service next week. Can you prepare a rollback plan?"

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  selected_mode: image_rollback
  evidence_profile:
    confirmed: [service_identity]
    missing_evidence:
      - deployment_details (image tag, deployment method)
      - DB migration scope (phase count unknown)
      - rollback_plan artifact from prior release (SLA unknown)
    missing_evidence_impact: "Phase 2+ cannot be designed without DB migration scope. Phase 1 only (generic image rollback)."
rollback_plan:
  rollback_phases:
    - phase: 1
      phase_name: "Image rollback (generic)"
      rollback_triggers:
        - "P0 SLO breach sustained > 5 minutes post-deploy"
        - "go-live-acceptance-assistant issues NO-GO"
      steps:
        - "Identify current and previous image tags"
        - "Execute image rollback command"
        - "Verify health check passes"
      estimated_sla_min: 5
      confidence: speculative    # no deployment details
      dry_run_evidence: not_performed
irreversible_items:
  - item: "Cannot assess irreversibility without DB migration scope — to be determined"
downstream_handoff:
  missing_evidence: [deployment_details, db_migration_scope]
  next_best_checks:
    - "Provide deployment method (Kubernetes rollout / blue-green / canary) to design Phase 2+"
    - "Run rollback-plan-generation again once PR and migration scope are available"
self_check:
  passed: false
  failed_rules:
    - "deployment_details absent — Phase 2+ cannot be designed; Phase 1 is generic estimate only"
```


---

## Scenario calibration
See `references/real-examples.md` for multi-phase rollback, rehearsal_coach, and post_incident_repair scenarios.

For rollback phase definitions, see `references/rollback-plan-phases.md`.
For release patterns and anti-patterns, see `references/release-patterns-and-anti-patterns.md`.

---

## Mock fixture — test artifact examples

### mock_input: simple flag-based rollback
```yaml
mock_input:
  scenario: "flag_based_rollback_tier3"
  fix_description: "Feature flag 'new_checkout_flow' can be disabled"
  deployment_age_min: 47
  schema_migration: false
  rollback_plan_exists: true
expected_output:
  rollback_plan:
    rollback_strategy: feature_flag
    rollback_phases: [{phase: 1, rollback_sla: "2m", dry_run_evidence: confirmed}]
  readiness: ready
  confidence: medium
```

### mock_input: schema rollback red
```yaml
mock_input:
  scenario: "schema_rollback_dba_unavailable"
  schema_migration: true
  dba_available: false
expected_output:
  readiness: red
  config_state: {overall_ready_to_proceed: false}
  self_check: {passed: false}
```

