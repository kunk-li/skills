---
name: rollback-plan-generation
description: >-
  generate n270 rollback plan artifacts for release preparation with v2 contract metadata, event emission, differentiated inputs, degradation rules, and standalone or composed workflow use. use when chatgpt must produce 回滚预案.md, validate release readiness evidence, or participate in the n270 release package.
---
# rollback-plan-generation

## Role
This skill produces the N270 `回滚预案.md` artifact. It must remain useful as a standalone skill and must become stronger when combined with other N270 skills through the shared `release_manifest`.

## Boundary
- Own `rollback_plan` for N270; do not re-run upstream N260 quality gates or execute downstream N280 deployment actions.
- Consume upstream evidence and peer N270 artifacts when present, but never require all peer artifacts for standalone use.
- Keep downstream handoff to N280, N290, and N360 explicit, including missing evidence and manual decisions.
- Use `references/n270-artifact-contract-v2.md` as the contract source for metadata, events, readiness, and circuit breaker fields.

## Canonical identity
- `skill_id`: `rollback-plan-generation`
- `schema_version`: `n270.rollback_plan.v2`
- `artifact_version`: `2.0.0`
- `artifact_type`: `rollback_plan`
- `emit_event.event_name`: `produced.n270.rollback_plan.v2`
- `output_certainty_grade`: `authoritative_artifact`

## Maintenance status
- Treat this package as the N270 v4 maintenance build: core schema, event names, readiness model, and circuit-breaker semantics are frozen for normal use.
- Do not add, remove, or rename required contract fields unless the artifact contract version is explicitly bumped and all six N270 skills are updated together.
- Prefer bug fixes, wording clarifications, platform handoff updates, and registry migration notes over new skill behavior.
- In platform deployments, treat local contract mirrors as packaged fallback material; the artifact contract registry and event-bus ingress are the production authorities.

## Mode selection
Every output must declare `selected_mode`, `readiness`, `evidence_profile`, `output_certainty_grade`, and `emit_event` near the top.

Allowed modes:
- `simple_rollback`
- `full_spectrum`
- `irreversibility_audit`
- `rehearsal_coach`
- `post_incident_repair`

## Inputs
Use a four-tier input model so the skill is independently usable while still benefiting from richer workflow context.

### Minimum viable inputs
- release identity
- change scope
- deployment or runtime target at the level known

### Primary discriminating inputs
These inputs distinguish this skill from the other five N270 skills. Prioritize them when available.
- deployment topology or rollout model when available
- data_migrations and schema/data change details
- slo_triplets or rollback trigger metrics
- risk register and impact scope
- backup/restore policy and dry-run records

### Common N270 inputs
Use these as shared release context, not as the only preferred inputs. Always prefer Primary discriminating inputs; treat Common N270 inputs as last-resort fallback, not the default starting point.
- `开发任务拆分表.csv`
- `PR描述.md`
- `质量门禁检查单.md`
- `Diff风险点评.md`

### Optional enhancement inputs
- release_note
- canary recommendation
- feature flags
- service compatibility map
- N310 incident remediation context

## Standalone and degradation rules
- Work on one release candidate, service release, hotfix, or release decision slice without requiring the full six-skill package.
- If minimum inputs are present but primary inputs are incomplete, keep the output contract stable and mark missing items under `evidence_profile.missing_evidence` and `downstream_handoff.missing_evidence_blocks`.
- Separate confirmed facts, assumptions, and unknowns. Do not convert unknowns into confident release statements.
- When evidence is insufficient for safe execution, produce a useful artifact with `readiness: amber` or `readiness: red` instead of refusing or inventing details.
- If invoked from N310 remediation and `orchestration_context.iter_count >= 3`, stop normal regeneration, mark readiness red, set cooldown `PT30M`, and escalate to the release manager / SLA human queue.

## Core output contract
Default to Markdown with YAML-like top metadata, or CSV/YAML-friendly tables when the user asks for a machine-readable artifact.

Required top-level sections:
- `metadata`
- `evidence_profile`
- `rollback_summary`
- `strategy_selection[]`
- `rollback_phases[]`
- `irreversible_changes[]`
- `data_rollback_handling`
- `trigger_conditions[]`
- `verification_steps[]`
- `communication_plan`
- `rollback_time_windows[]`
- `dry_run_evidence[]`
- `decision_support`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `skill_id: rollback-plan-generation`
- `schema_version: n270.rollback_plan.v2`
- `artifact_version: 2.0.0`
- `artifact_type: rollback_plan`
- `function_bias: direct_result.rollback_path_and_rehearsal_readiness`
- `stage_position: release_and_delivery.release_preparation.rollback_plan_generation`
- `workflow_node: N270`
- `node_artifact_target: 回滚预案.md`
- `selected_mode`
- `output_certainty_grade: authoritative_artifact`
- `readiness: green | amber | red`
- `tool_collaboration_mode: standalone | composed | validation_only`
- `emit_event.event_name: produced.n270.rollback_plan.v2`
- `circuit_breaker.iter_count / max_iter / cooldown / escalation_target`

## Design rules
- Do not treat rollback as simple git revert; choose among feature flag disable, blue/green swap, canary halt, rolling rollback, DB rollback, or forward fix.
- Analyze irreversible changes explicitly, including destructive schema/data changes and external side effects.
- Treat dry-run evidence as mandatory for high-impact or data-affecting rollback readiness.
- Make time windows explicit: when rollback is safe, degraded, or less safe than forward fix.
- Bind rollback triggers to SLOs, canary metrics, business impact, and manual authority.

## Execution workflow
1. Collect release scope, deployment shape, migration detail, SLO triggers, impact scope, and backup evidence.
2. Select rollback strategies and map them to components, data, flags, infrastructure, and user-facing impact.
3. Define verification, communication, authority, and post-rollback actions.
4. Emit blocked readiness when dry-run, backup, or irreversibility evidence is missing.

## Composition behavior
- In full N270 mode, consult `references/n270-routing-and-orchestration-v2.md` before choosing sequence or parallel execution.
- Treat `release_manifest` as the single source of truth when multiple N270 artifacts coexist; update manifest patches before regenerating downstream artifacts.
- Emit a `produced.n270.*.v2` event for finalized artifacts so N330/N340/N350/N390 can subscribe without polling file names.
- If this artifact changes a field consumed by another N270 skill, list that peer skill under `downstream_handoff.refresh_triggers`.

## Self-check gate
- Run the self-check before finalizing. If any release-critical rule fails, `self_check.passed` must be false and readiness cannot be green.
- If the user asks to validate a generated artifact file, run `python scripts/validate_n270_artifact.py <artifact-file>` as a local LLM self-check. Treat this script as a packaged fallback; production-grade validation should run at the artifact contract registry with the canonical schema.
- Record failed rules, blockers, and exact owner/action needed for recovery.

## Quality bar
A good rollback plan makes the rollback path, dry-run evidence, irreversible-change handling, triggers, authority, and verification concrete enough for incident-time use.

## Reference files
- `references/n270-artifact-contract-v2.md`
- `references/n270-routing-and-orchestration-v2.md`
- `references/n270-composite-release-manifest-example-v2.md`
- `references/failure-modes.md`
- `references/release-manifest-contract.md`
- `references/field-contract.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/real-examples.md`
- `references/output-template.md`
- `references/rollback-plan-phases.md`
