# CHANGELOG

## 2026-04-23 · n120 cleanup pass

Scope: align the skill with the latest N120 analysis feedback while preserving backward-compatible output contracts.

### Changes
- add `references/compatibility-map.md` and keep blueprint-to-runtime mappings explicit
- strengthen the N120 default to stay stack-abstract unless credible stack evidence exists
- restore machine-readable `self_check_rules[]` in the artifact contract and output template
- add backward-compatible consumer split fields: `direct_consumers[]`, `indirect_consumers[]`, and `eventbus_subscribers[]`
- align `n120_mode` with the four N120 workflow modes and keep standalone represented through `workflow_node: standalone`
- add explicit SKILL.md instructions for `soft_gate` handling and node-local self-check behavior

### Not in this package
- platform-side replacement of `primary_downstream_consumers[]`
- node-level `routing_decision` or eventbus registry changes
