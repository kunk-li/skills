# Technical aspect catalog

Status: implemented

Use these canonical aspect keys in `technical_aspects[]`. Every engineering requirement must select at least one. Multiple values are allowed.

## Core aspect set
| Key | 中文 | Typical scope |
| --- | --- | --- |
| `data_storage` | 数据存储 | persistence, schema, retention, queryability |
| `concurrency` | 并发控制 | lock, race condition, ordering, contention |
| `idempotency` | 幂等性 | dedupe, replay safety, same-request handling |
| `caching` | 缓存 | freshness, invalidation, reuse |
| `messaging` | 消息/事件 | events, queue, topic, async workflow |
| `authentication` | 身份认证 | caller identity, service identity |
| `authorization` | 授权 | role, scope, access control |
| `audit` | 审计 | audit trail, retention, tamper resistance |
| `notification` | 通知 | email, sms, push, in-app notification |
| `external_integration` | 外部集成 | partner system, callback, third-party API |
| `observability` | 可观测性 | metrics, logs, tracing, alerting |
| `compliance` | 合规 | policy retention, privacy, regulated handling |

## Default implied needs by aspect

### `messaging`
- event schema contract
- delivery acknowledgement strategy
- retry policy
- dead letter queue handling
- deduplication or replay policy
- ordering or eventual consistency notes

### `idempotency`
- idempotency key location
- storage medium
- ttl or retention window
- same-payload vs different-payload conflict handling
- fallback behavior when the primary idempotency store is unavailable

### `audit`
- audit trigger points
- required audit fields
- immutability guarantees
- retention duration
- audit query permissions

### `notification`
- template management
- delivery channel selection
- retry and suppression strategy
- user preference or opt-out rule
- failure observation

### `external_integration`
- ownership of remote contract
- callback authentication or signature verification
- timeout and retry behavior
- reconciliation strategy
- version compatibility

### `concurrency`
- contention scope
- lock ownership and timeout
- duplicate execution handling
- ordering guarantees
- fallback when coordination fails

### `observability`
- metrics dimensions
- log structure
- trace propagation
- alert thresholds
- operator runbook entry point

### `compliance`
- retention or deletion rule
- masking or redaction
- lawful access and approval path
- evidence preservation
- regional or tenant segregation

## Usage rules
- Keep keys in english for portability.
- Add local explanation in prose when needed, but do not rename the keys.
- When multiple aspects apply, list the small set that truly drives engineering design.
