# Delivery checklist

Status: implemented

## A. Standalone completeness
- [ ] The artifact contains a real engineering requirement inventory, not only commentary.
- [ ] Every requirement has `er_id`, `requirement_statement`, `technical_aspects`, and `er_tier`.
- [ ] The source is traceable through `source_requirements[]` or equivalent evidence.
- [ ] `confirmed`, `inferred`, and `pending` content are clearly separated.
- [ ] Non-functional signals that are already implied have been surfaced instead of deferred silently.

## B. Contract compliance
- [ ] The artifact starts with the header from `artifact-contract.md`.
- [ ] `artifact_type` is `engineering_requirement_inventory`.
- [ ] `schema_version` is present and stable.
- [ ] If the task is N120, `artifact_name` is `开发需求解析.md` and downstream consumers include N130, N150, and N160.

## C. Generality and reuse
- [ ] `technical_aspects[]` uses canonical keys from the catalog.
- [ ] Concrete vendor or framework names appear only in `bound` output or when explicitly required.
- [ ] The wording is portable across domains and projects.
- [ ] The same output could be handed to another team without needing original business jargon explained elsewhere.

## D. Combination readiness
- [ ] `emitted_api_candidates[]` is filled whenever interfaces, callbacks, jobs, or events are implied.
- [ ] IDs are stable and downstream-friendly.
- [ ] `recognized_patterns[]` and `nfr_flags[]` are explicit enough for downstream design work.
- [ ] Open questions are actionable and tied to specific `er_id` values.

## E. One-vote rejection items
Any of the following makes the output non-compliant:
- [ ] Missing `technical_aspects[]` or free-text aspect names that break reuse.
- [ ] No `er_tier`, making decision levels unclear.
- [ ] Hidden technical obligations remain implicit even though the source clearly implies them.
- [ ] Bound implementation details are invented without source evidence.
- [ ] The output cannot be consumed independently from other skills.
- [ ] The output is meant for workflow handoff but lacks the artifact header.
