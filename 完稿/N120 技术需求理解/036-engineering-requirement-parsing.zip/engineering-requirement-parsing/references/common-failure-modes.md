# Common failure modes

## F1: prose instead of requirement units
Symptom: output reads as narrative summary, not as discrete ER rows.
Fix: each sentence that expresses an engineering obligation becomes a separate `er_id` row.

## F2: free-text `technical_aspects`
Symptom: aspects are written as plain phrases like "need to cache" or "should be fast".
Fix: use only canonical keys from `technical-aspect-catalog.md`; any non-catalog term breaks cross-project reuse.

## F3: missing implied needs
Symptom: only sunny-day functional needs appear; retry policy, DLQ, audit retention, idempotency key, and circuit-breaker are absent even when the source clearly implies them.
Fix: for each aspect in `technical_aspects[]`, expand `implied_needs[]` by consulting the aspect catalog.

## F4: mixing tiers in one row
Symptom: a single row says "use Redis cluster with 3 replicas" (t3) while also expressing "distributed caching capability" (t1).
Fix: split into t1 capability + t2 pattern + optional t3 only when the source explicitly mandates the implementation.

## F5: inventing stack bindings
Symptom: specific products, table names, topic names, or frameworks appear in `t1`/`t2` rows without explicit source evidence.
Fix: keep `tech_stack_binding: abstract` by default; only produce bound output when the user or source names the stack.

## F6: sunny-day only
Symptom: exception flows (timeout, retry, cancel, concurrent access, partial failure) are missing from `er_id` rows.
Fix: add separate `er_id` entries for each meaningful exception obligation.

## F7: standalone failure
Symptom: the artifact requires reading another skill's output to make sense.
Fix: `requirement_statement` must be self-explanatory. `source_requirements[]` must trace to a specific line or quote in the input.

## F8: silent confidence
Symptom: inferred requirements look the same as confirmed ones.
Fix: always set `confidence: explicit | inferred | pending` per row and list open questions per `er_id`.
