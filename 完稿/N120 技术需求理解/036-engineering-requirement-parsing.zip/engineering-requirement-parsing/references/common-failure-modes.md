# Common failure modes

Status: implemented

1. Translating business text into generic prose instead of engineering requirement units.
2. Treating `technical_aspects` as free text, which breaks cross-project reuse.
3. Missing hidden technical obligations such as retry, audit retention, idempotency keys, or DLQ handling.
4. Mixing capability-level decisions with implementation-level choices in a single row.
5. Inventing stack-specific solutions without explicit stack input.
6. Forgetting exception paths and only describing the sunny-day flow.
7. Producing output that only works when another skill already ran.
