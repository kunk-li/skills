# Orchestration guide

Status: implemented

## Standalone mode
Use this skill alone when the user needs a reusable engineering requirement inventory from business-facing material.
The output must remain complete without relying on any other skill.

## Workflow-bound mode
When the task belongs to N120:
- default to `deep_parse`
- emit `开发需求解析.md`
- preserve the artifact header from `artifact-contract.md`
- preserve stable `er_id` values for N130, N150, and N160
- emit node-local self-check signals by keeping `self_check: produces`, `self_check_scope: node_local`, and `self_check_rules[]` aligned with the artifact contract
- keep `tech_stack_binding: abstract` unless the user explicitly requests stack binding or the source provides credible stack evidence
- if the source implies interfaces, callbacks, jobs, or events but `emitted_api_candidates[]` is empty, return a `soft_gate` signal rather than silently pretending the requirement is API-free

## Paired mode with api-intent-extraction
This is the strongest default combination for business-to-technical translation.

### 036 -> 037 handoff contract
- `er_id` stays stable and becomes the trace anchor
- `emitted_api_candidates[]` becomes a seed list for downstream API intent generation
- `technical_aspects[]` can prefill downstream `nfr_hints`, exception checks, and style hints
- `recognized_patterns[]` can influence downstream API scaffolding
- the artifact header remains intact when the output is passed through workflow nodes

### Recommended flow
1. Run this skill in `deep_parse` mode.
2. Review `technical_aspects[]`, `implied_needs[]`, `er_tier`, and `recognized_patterns[]`.
3. Hand off `emitted_api_candidates[]` plus all stable IDs into `api-intent-extraction`.
4. If the user later provides stack context, re-run only the affected subset in `bind_to_stack` mode.

## Other downstream consumers
- architecture/design skills: consume `er_tier`, `recognized_patterns[]`, `dependencies[]`
- data modeling skills: consume `objects[]`, storage-facing requirements, and `nfr_flags[]`
- NFR skills: consume `technical_aspects[]`, `implied_needs[]`, and `nfr_flags[]`

## Traceability rule
A downstream skill should always be able to answer:
- which business requirement created this engineering requirement
- which engineering requirement created this interface or design element
- which artifact contract and schema version the handoff used
