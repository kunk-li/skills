# Output template

Status: implemented

Use this template as the default standalone artifact. You may compress sections when the user asks for a lighter output, but do not omit the engineering requirement inventory.

## 0. Artifact contract header
Place this header first. Use the exact keys from `artifact-contract.md`.

```yaml
artifact_name: 开发需求解析.md
artifact_type: engineering_requirement_inventory
schema_version: er-inventory.v1
workflow_node: N120 | standalone
n120_mode: full_n120 | er_only | intent_only | refresh   # required when workflow_node: N120
source_inputs: []
primary_downstream_consumers: [N130, N150, N160]
direct_consumers: [N130, N150, N160]
indirect_consumers: []
eventbus_subscribers: []
event_role: producer
gate_role: soft_gate
self_check: produces
self_check_scope: node_local
self_check_rules:
  - emitted_api_candidates_non_empty_when_interfaces_implied
  - every_er_has_technical_aspects
  - every_er_has_er_tier
```

## 1. Context summary
- source type
- parsing mode: `quick_parse` | `deep_parse` | `bind_to_stack`
- source scope
- key assumptions

## 2. Engineering requirement inventory
Use one row per requirement unit.

| er_id | name | source_requirements | requirement_statement | technical_aspects | implied_needs | er_tier | recognized_patterns | tech_stack_binding | stack_notes | actors | objects | triggers | acceptance | nfr_flags | dependencies | risks | open_questions | emitted_api_candidates | confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## 3. Grouped views
Provide the grouped views that add the most value for the task. Common options:
- grouped by `technical_aspects`
- grouped by `er_tier`
- grouped by `recognized_patterns`
- grouped by object or module

## 4. Hidden technical obligations checklist
List the most important `implied_needs[]` that were surfaced automatically and require explicit confirmation.

## 5. Stack binding notes
Only include this section when mode is `bind_to_stack` or the source already names a stack.

Suggested columns:
| er_id | abstract requirement | bound choice | rationale | stack evidence |
| --- | --- | --- | --- | --- |

## 6. Workflow handoff view
When relevant, provide:
- `emitted_api_candidates[]`
- downstream design implications
- items that should be handed to N130, N150, N160, or N170

## 7. Open questions and decision points
Use one row per unresolved item.

| question_id | related_er_ids | type | question | unblock_condition |
| --- | --- | --- | --- | --- |
