# Artifact contract

Status: implemented

Use this header whenever the output will be consumed beyond the immediate conversation.

## Required header
Place this header at the top of the artifact before the narrative sections.

```yaml
artifact_name: 开发需求解析.md
artifact_type: engineering_requirement_inventory
schema_version: er-inventory.v1
workflow_node: N120 | standalone
n120_mode: full_n120 | er_only | intent_only | refresh   # required when workflow_node: N120
source_inputs:
  - 需求交接包.zip
  - 需求质量审查单.md
  - 验收标准.md
  - raw requirement text
primary_downstream_consumers:
  - N130
  - N150
  - N160
direct_consumers:
  - N130
  - N150
  - N160
indirect_consumers: []
eventbus_subscribers: []
event_role: producer
gate_role: soft_gate
self_check: produces
self_check_scope: node_local
self_check_rules:
  - emitted_api_candidates_non_empty_when_interfaces_implied
  - every_er_has_technical_aspects
  - every_er_has_er_tier
```

## Rules
- When used in N120, keep `artifact_name` as `开发需求解析.md`.
- When used standalone, keep `artifact_type` and `schema_version` unchanged, set `workflow_node: standalone`, and omit `n120_mode` because the four N120 modes apply only to workflow-bound runs.
- In standard N120 runs, prefer `tech_stack_binding: abstract`. Only bind to a concrete stack when the user explicitly requests it or the source supplies credible stack evidence.
- `source_inputs[]` must list the real inputs that were consumed. Do not claim files that were not used. For standalone work, use generic evidence labels such as `prd text`, `meeting note text`, `process description text`, or `policy text` rather than inventing unregistered workflow artifact filenames.
- `primary_downstream_consumers[]` is retained for backward compatibility. `direct_consumers[]` is the preferred direct-consumer list. Do not list semantic neighbors that do not directly consume this artifact. Keep `indirect_consumers[]` and `eventbus_subscribers[]` explicit when known.
- `gate_role: soft_gate` means the artifact may still be valuable even when a reviewer should double-check whether interface implications were missed.
- `self_check: produces` means this skill is responsible for emitting its own node-local review signals by using the bundled checklist, scoring rubric, and failure-mode references. `self_check_rules[]` provides the machine-readable rule entry points for N380 aggregation and linter checks.

## Minimum downstream guarantee
A downstream reviewer should be able to answer all of the following without reopening the original business document:
- what the artifact is
- which workflow node or standalone context produced it
- which N120 mode produced it
- which engineering requirement IDs are stable
- which downstream node should consume it next
