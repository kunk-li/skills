# Compatibility map

Status: implemented

Use this file to map the larger N120 blueprint vocabulary to the compact runtime fields used by this skill. The goal is to keep the skill generic and lightweight without losing traceability back to the v2 design language.

## Engineering requirement identifiers
| Blueprint concept | Runtime field | Notes |
| --- | --- | --- |
| `ER-ORDER-001` style IDs | `er_id` | Keep stable once emitted. Prefer a compact `ER-###` sequence only if no upstream canonical ID exists. |
| `parent_business_req` / `requirement_refs[]` | `source_requirements[]` | Preserve upstream requirement refs, quotes, or IDs here. |

## Technical aspects
| Blueprint key | Runtime value in `technical_aspects[]` |
| --- | --- |
| `TA-01_data_storage` | `data_storage` |
| `TA-02_concurrency` | `concurrency` |
| `TA-03_idempotency` | `idempotency` |
| `TA-04_caching` | `caching` |
| `TA-05_messaging` | `messaging` |
| `TA-06_authentication` | `authentication` |
| `TA-07_authorization` | `authorization` |
| `TA-08_audit` | `audit` |
| `TA-09_notification` | `notification` |
| `TA-10_external_integration` | `external_integration` |
| `TA-11_observability` | `observability` |
| `TA-12_compliance` | `compliance` |

## ER tier mapping
| Blueprint tier | Runtime `er_tier` | Notes |
| --- | --- | --- |
| `T1_capability` | `t1_capability` | Default for capability statements. |
| `T2_pattern` | `t2_pattern` | Preferred N120 landing zone when a reusable pattern is justified. |
| `T3_implementation` | `t3_implementation` | Use only with explicit stack evidence or an explicit binding request. |

## Pattern and API handoff mapping
| Blueprint concept | Runtime field | Notes |
| --- | --- | --- |
| `recognized_patterns[]` | `recognized_patterns[]` | Keep names portable and stack-neutral. |
| API candidates emitted by ER analysis | `emitted_api_candidates[]` | These are seeds for `api-intent-extraction`, not final API contracts. |
| stack binding decision | `tech_stack_binding` + `stack_notes[]` | Keep `abstract` by default in standard N120 runs. |

## Usage rule
When the user or a downstream reviewer speaks in the blueprint vocabulary, translate it into the runtime fields above instead of expanding the runtime schema. This keeps the skill reusable while preserving N120 traceability.
