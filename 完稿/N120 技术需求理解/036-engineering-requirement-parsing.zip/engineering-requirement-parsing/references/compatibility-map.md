# Compatibility map — v2 alignment

Use this file to map the N120 blueprint vocabulary to v2 runtime fields. Updated to align with `artifact-contract.md` v2 schema.

## Engineering requirement identifiers
| Blueprint concept | v2 Runtime field | Notes |
|---|---|---|
| `ER-ORDER-001` style IDs | `er_id` | Stable once emitted; downstream skills reference by this ID |
| `parent_business_req` | `source_requirements[]` | Preserve original refs, quotes, or IDs; never invent |
| N070 `REQ-*` ids | `source_requirements[]` | Inherit when upstream 013/014/015/016/017 artifacts exist |

## Technical aspects (canonical → runtime)
| Blueprint key | Runtime enum in `technical_aspects[]` | Common `implied_needs[]` |
|---|---|---|
| `TA-01_data_storage` | `data_storage` | soft-delete, timezone policy, migration plan |
| `TA-02_concurrency` | `concurrency` | lock strategy, deadlock analysis (→ 049) |
| `TA-03_idempotency` | `idempotency` | idempotency key, storage, TTL (→ 050) |
| `TA-04_caching` | `caching` | invalidation, stampede, TTL |
| `TA-05_messaging` | `messaging` | DLQ, retry, ordering (→ 049) |
| `TA-06_authentication` | `authentication` | token lifecycle, MFA |
| `TA-07_authorization` | `authorization` | RBAC/ABAC selection, SoD (→ 052) |
| `TA-08_audit` | `audit` | append-only, retention (→ 051) |
| `TA-09_notification` | `notification` | delivery guarantee, DLQ |
| `TA-10_external_integration` | `external_integration` | retry, circuit-breaker, idempotency |
| `TA-11_observability` | `observability` | metrics, alerts, tracing |
| `TA-12_compliance` | `compliance` | data residency, retention, PII masking |
| `TA-13_scheduling` | `scheduling` | cron drift, idempotent job |
| `TA-14_security` | `security` | threat model (→ 054) |
| `TA-15_performance` | `performance` | SLO triplet (→ 053) |

## ER tier mapping
| Blueprint tier | Runtime `er_tier` | Default usage |
|---|---|---|
| `T1_capability` | `t1_capability` | What must exist — default for most requirements |
| `T2_pattern` | `t2_pattern` | Recommended implementation pattern |
| `T3_implementation` | `t3_implementation` | Only when source explicitly mandates a concrete choice |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for aggregation | N380 |
| `produced_event` | Event bus trigger | N330, N340 |
| `blocker_mapping` | SLA queue key | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | N110 (upstream PRD revision) |

## Combination rule with 037
When paired with `api-intent-extraction`, pass `emitted_api_candidates[]` as seeds for 037's intent extraction. Do NOT treat them as final API contracts — 037 validates granularity and style independently.
