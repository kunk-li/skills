# Pattern library

Status: implemented

Use this library to recognize reusable engineering solution shapes. Prefer the most portable pattern name first. Add a short rationale, not a long design essay.

## Distributed transaction and consistency
- `saga_orchestration`
- `saga_choreography`
- `two_phase_commit`
- `transactional_outbox`
- `eventual_consistency_reconciliation`

## Idempotency and concurrency
- `idempotency_key`
- `db_unique_constraint`
- `state_machine_cas`
- `optimistic_lock_cas`
- `pessimistic_lock`
- `distributed_lock_lease`
- `read_write_lock`

## Caching
- `cache_aside`
- `write_through`
- `read_through`
- `stale_while_revalidate`

## Messaging and workflow
- `retry_with_backoff`
- `dead_letter_queue`
- `event_schema_versioning`
- `callback_signature_verification`
- `workflow_state_machine`

## Resilience and protection
- `circuit_breaker`
- `timeout_with_fallback`
- `rate_limit_token_bucket`
- `bulkhead_isolation`

## Observability and audit
- `structured_logging`
- `distributed_tracing`
- `metrics_golden_signals`
- `immutable_audit_log`

## Usage rules
- Use `recognized_patterns[]` only when the pattern meaningfully fits the requirement.
- Do not force a pattern onto every row.
- If the source only implies a capability and not a pattern, keep the row at `t1_capability`.
