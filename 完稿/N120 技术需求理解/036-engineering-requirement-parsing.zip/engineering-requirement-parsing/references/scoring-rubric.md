# Scoring rubric

Status: implemented

## A. requirement quality
| Score | Standard |
| --- | --- |
| 5 | Requirements are atomic, traceable, and reusable across projects |
| 4 | Most requirements are well split and actionable |
| 3 | Output is usable but some rows are too broad or too vague |
| 2 | Many rows mix multiple obligations or hide uncertainty |
| 1 | The result is mostly narrative and not implementation-facing |

## B. hidden-needs coverage
| Score | Standard |
| --- | --- |
| 5 | Hidden technical obligations are surfaced systematically by aspect |
| 4 | Most implied needs are captured, with minor omissions |
| 3 | Core implied needs appear, but NFR or exception coverage is uneven |
| 2 | Only sunny-day functional needs are captured |
| 1 | Hidden needs are largely absent |

## C. standalone and combination fitness
| Score | Standard |
| --- | --- |
| 5 | Artifact stands alone and is immediately consumable by downstream skills |
| 4 | Mostly standalone with small gaps |
| 3 | Usable, but traceability or downstream contract needs cleanup |
| 2 | Requires another skill to make sense of the output |
| 1 | Cannot be reused reliably |
