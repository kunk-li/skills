# Example IO

Status: implemented

## Example input
- A story says: “employee onboarding approval requires dual approval, audit retention, reminder notification after timeout, and integration with the hr system.”

## Good output characteristics
- Split the requirement into several engineering units instead of one vague statement.
- Map units to canonical aspects such as `authorization`, `audit`, `notification`, and `external_integration`.
- Surface hidden needs such as timeout scheduler, retry policy, audit retention, and reconciliation.
- Keep the first pass stack-neutral.
- Emit candidate downstream API intents such as create approval, submit decision, query status, reminder trigger, and hr sync callback.
