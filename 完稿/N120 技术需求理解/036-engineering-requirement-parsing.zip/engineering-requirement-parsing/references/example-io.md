# Example I/O

## Example input
"Employee onboarding approval requires dual approval, audit retention for 7 years, reminder notification after 48h timeout, and integration with the HR system."

## Good output — er_id breakdown

```yaml
er_id: ER-001
name: dual-approval-capability
requirement_statement: The system must enforce that no single actor can both create and approve an onboarding request; two distinct authorized approvers must act in sequence.
technical_aspects: [authorization, workflow]
implied_needs: [SoD constraint, audit of each approval decision, state machine guard for approval sequence]
er_tier: t1_capability
recognized_patterns: [saga_orchestration, four_eyes_approval]
tech_stack_binding: abstract
confidence: explicit

er_id: ER-002
name: audit-retention
requirement_statement: All onboarding approval events must be retained in append-only audit storage for a minimum of 7 years.
technical_aspects: [audit, data_retention, compliance]
implied_needs: [append-only enforcement, cold-tier archival after 1 year, PII masking in audit records]
er_tier: t1_capability
nfr_flags: [compliance: 7-year retention, security: append-only]
tech_stack_binding: abstract
confidence: explicit

er_id: ER-003
name: timeout-reminder-notification
requirement_statement: When an approval step has not been actioned within 48 hours, the system must send a reminder notification to the pending approver.
technical_aspects: [notification, scheduling, workflow]
implied_needs: [scheduler/cron job, idempotency for reminder delivery, DLQ for failed notifications]
er_tier: t1_capability
emitted_api_candidates: [reminder_trigger_job, notification_send_callback]
tech_stack_binding: abstract
confidence: explicit

er_id: ER-004
name: hr-system-integration
requirement_statement: Upon final approval, the system must push the onboarding completion event to the HR system via an agreed integration mechanism.
technical_aspects: [external_integration, reliability]
implied_needs: [retry policy, circuit-breaker for HR system unavailability, idempotency key for push, callback failure compensation]
er_tier: t1_capability
emitted_api_candidates: [hr_provisioning_callback, hr_sync_status_query]
tech_stack_binding: abstract
open_questions:
  - id: Q-001
    question: Is HR integration synchronous (blocking) or asynchronous (outbox/event)?
    impact: determines whether ER-004 needs a saga compensation step
confidence: inferred
```

## What makes this good
- Each ER-* is one obligation, not a cluster of obligations.
- `implied_needs[]` surfaces retry, DLQ, SoD, and archival without waiting for downstream skills.
- `open_questions[]` are tied to a specific er_id and state the downstream impact.
- `confidence: inferred` on ER-004 because the integration mechanism was not specified.
- No vendor or framework names; stack remains abstract.

## ex-002 · downgrade example — sparse PRD only (provisional mode)

```yaml
artifact_schema_version: n120.er-inventory.v2.0.0
workflow_node: N120
readiness: provisional
route_back_to: n110
route_back_reason: "source is a one-page PRD with no acceptance criteria, no data objects, and no actor definitions"

confidence_summary:
  confirmed: [ER-001 approval_capability — explicitly stated in PRD]
  inferred: [ER-002 audit_retention — implied by 'compliance' mention without specifics]
  pending: [ER-003 notification_channel — PRD says 'notify user' but channel unspecified]

engineering_requirements:
  - er_id: ER-001
    name: approval-workflow-capability
    requirement_statement: "The system must support a multi-step approval workflow where requests progress through defined states."
    technical_aspects: [authorization, workflow, concurrency]
    implied_needs: [state machine guard, SoD constraint, audit of each decision]
    er_tier: t1_capability
    tech_stack_binding: abstract
    confidence: explicit
    open_questions:
      - id: Q-001
        question: "How many approval steps are required? Is dual-approval mandatory?"
        impact: determines SoD constraint design and saga complexity
        route_back_to: n110

  - er_id: ER-002
    name: audit-retention
    requirement_statement: "All approval actions must be retained for compliance purposes."
    technical_aspects: [audit, compliance]
    implied_needs: [append-only storage, retention period, cold-tier archival]
    er_tier: t1_capability
    tech_stack_binding: abstract
    confidence: inferred
    open_questions:
      - id: Q-002
        question: "What is the minimum retention period? Which regulation applies?"
        impact: determines retention tier design and storage cost
        route_back_to: n110

  - er_id: ER-003
    name: notification-delivery
    requirement_statement: "Users must be notified of approval status changes."
    technical_aspects: [notification, messaging]
    implied_needs: [delivery guarantee, DLQ for failed notifications, retry policy]
    er_tier: t1_capability
    tech_stack_binding: abstract
    confidence: pending
    open_questions:
      - id: Q-003
        question: "Is notification via email, in-app, SMS, or all three?"
        impact: determines notification channel design and retry complexity

rule_results:
  - {rule_id: R01_every_er_has_technical_aspects, severity: reject, result: pass}
  - {rule_id: R04_confidence_explicit_not_silent, severity: reject, result: pass}
  - {rule_id: R05_no_invented_stack_bindings, severity: reject, result: pass}

feedback_signal_to_n005:
  signal_type: gap_detected
  summary: "PRD missing acceptance criteria, actor definitions, and data objects — 3 open questions require PRD revision"
  target_n070_skills: [013-requirement-breakdown, 017-data-object-identification]
```

## ex-003 · blocked — source contradicts itself (route_back required)

```yaml
artifact_schema_version: n120.er-inventory.v2.0.0
skill_name: engineering-requirement-parsing
readiness: blocked
blocker_mapping: B-N120-01
route_back_to: n110
route_back_reason: "Source requirements contain direct contradictions that cannot be resolved without PRD author clarification"

blockers:
  - blocker_id: BLK-001
    type: contradiction
    description: "Section 2.1 states 'no third-party payment processors' but Section 5.3 mandates 'Stripe integration for subscription billing'"
    impact: "Cannot determine TA-10_external_integration scope; C2_regulatory constraints are mutually exclusive"
    resolution_required: "PRD author must resolve contradiction in writing before ER parsing can proceed"
    unblock_evidence: "Revised PRD with contradiction removed, or explicit decision log signed by product owner"

  - blocker_id: BLK-002
    type: missing_actor
    description: "Requirements reference 'approver role' 14 times but no actor definition exists; no org chart or RACI provided"
    impact: "Cannot scope A07_authorization TA; er_tier cannot be assigned for approval-related requirements"
    resolution_required: "Actor definition with permissions + org structure"
    unblock_evidence: "Permission matrix from N070-016 or explicit actor definition table"

partial_output:
  note: "Partial ER inventory produced for non-contradictory requirements only"
  completed_er_count: 3
  blocked_er_count: 5
  completed_ers: [ER-001, ER-002, ER-003]
  blocked_ers: [ER-004 through ER-008 — all touch approval_workflow]

feedback_signal_to_n005:
  signal_type: contradiction_detected
  target_n070_skills: [013-requirement-breakdown, 016-permission-matrix-extraction]
  summary: "2 blockers prevent full ER parsing; PRD revision required before N120 can complete"
```
