---
name: engineering-requirement-parsing
description: translate business requirements into structured engineering requirement units with technical aspects, implied needs, tiers, and v2 contract headers. pairs with api-intent-extraction inside n120.
---
# engineering-requirement-parsing

Turn business language into engineering-ready requirement units that are reusable across projects, readable on their own, and traceable when combined with downstream skills.

## Core promise
- Work **standalone**: produce a complete engineering requirement inventory even when no other skill has run.
- Work **in combination**: emit stable IDs, normalized fields, and handoff-ready metadata that downstream skills can consume directly.
- Stay **generic**: describe requirements in canonical technical language before binding to any framework or vendor stack.
- Stay **workflow-aligned**: when used inside N120, emit a contract-ready artifact that can flow into N130, N150, and N160 without reinterpretation.


## Technical aspect quick-reference
Full catalog in `references/technical-aspect-catalog.md`. Most common aspects and their key `implied_needs[]`:

| Aspect key | Typical implied needs |
|---|---|
| `data_storage` | soft-delete policy, timezone (UTC), migration plan, PK strategy |
| `concurrency` | lock strategy, deadlock analysis, isolation level → feeds 049 |
| `idempotency` | idempotency key, storage tier, TTL, 6-channel coverage → feeds 050 |
| `caching` | invalidation, stampede protection, TTL, read-your-writes risk |
| `messaging` | DLQ, retry policy, ordering guarantee, at-least-once handling |
| `authentication` | token lifecycle, MFA, session management |
| `authorization` | RBAC/ABAC/ReBAC selection, SoD → feeds 052 |
| `audit` | append-only, A01-A10 categories, retention period → feeds 051 |
| `notification` | delivery guarantee, DLQ, template management |
| `external_integration` | retry, circuit-breaker, idempotency, callback compensation |
| `observability` | metrics, alerts, distributed tracing, SLO → feeds 053 |
| `compliance` | data residency, retention, PII masking, regulation mapping → feeds 054 |
| `scheduling` | cron drift, idempotent job, single-instance guarantee |
| `security` | threat model, STRIDE → feeds 054 |
| `performance` | SLO triplet, bottleneck analysis → feeds 053 |

## Trigger conditions and accepted inputs
Use this skill when the source describes business intent or operating rules:
- prd, epic, user story, workflow note, process memo, policy text, meeting note
- `需求交接包.zip`, `验收标准.md`, `开发需求解析.md`, or N110 handover packages
- any upstream structured outputs traceable to business requirements

Inside N120, always pair with `api-intent-extraction`.

Treat the supplied requirement text as the primary source of truth. Upstream outputs are supporting evidence and traceability aids, not permission to invent missing facts.

## Operating modes
Choose the lightest mode that still solves the task.

### 1) `quick_parse`
Use when the user wants a fast first pass.
Output only:
- normalized requirement statements
- `technical_aspects[]`
- `er_tier`
- core acceptance notes
- open questions

### 2) `deep_parse`
Use when the user needs a handoff-quality artifact.
Output everything in the field contract, including:
- `implied_needs[]`
- `recognized_patterns[]`
- `nfr_flags[]`
- `emitted_api_candidates[]`
- dependency and risk notes

### 3) `bind_to_stack`
Use only when the user provides a project stack or explicitly asks for stack-specific guidance.
Start from an abstract engineering requirement and then bind it to the stated stack.
Do not guess a stack.

## Workflow alignment
### Standalone use
Default to the lightest mode that still produces a reusable engineering requirement inventory.

### N120 workflow use
If the request is part of **N120 技术需求理解**, or the inputs resemble `需求交接包.zip`, `需求质量审查单.md`, and `验收标准.md`, do all of the following:
- default to `deep_parse`
- emit a primary artifact named `开发需求解析.md`
- include the artifact header defined in `references/artifact-contract.md`
- use `artifact_type: engineering_requirement_inventory`
- use `schema_version: er-inventory.v1`
- preserve stable `er_id` values so the output can feed `api-intent-extraction`, N130, N150, and N160 directly
- keep canonical enum keys in english even when the explanation body is Chinese
- declare node-local self-check output by using the bundled checklist, scoring rubric, and common-failure references
- treat interface implication gaps as `soft_gate`, not as a silent pass
- keep backward-compatible `primary_downstream_consumers[]` and also fill `direct_consumers[]`, `indirect_consumers[]`, and `eventbus_subscribers[]` when the artifact is used beyond the immediate conversation
- keep `tech_stack_binding: abstract` by default inside standard N120 runs; do not switch to `bind_to_stack` without explicit stack evidence or an explicit user request

## Required workflow
1. Determine whether the task is standalone or workflow-bound. If it is workflow-bound, apply the correct artifact contract before writing the body.
2. Normalize the source into business facts, actors, objects, states, actions, rules, exceptions, and non-functional signals.
3. Split the content into engineering requirement units. One unit should express one meaningful engineering obligation or capability.
4. For each unit, assign at least one `technical_aspects[]` value from `references/technical-aspect-catalog.md`.
5. Expand `implied_needs[]` by consulting the aspect catalog. Promote the most relevant hidden technical obligations into explicit checklist items.
6. Assign `er_tier`:
   - `t1_capability`: what capability must exist
   - `t2_pattern`: what implementation pattern is recommended
   - `t3_implementation`: what concrete implementation choice is required or proposed
7. Recognize reusable solution shapes with `recognized_patterns[]` by consulting `references/pattern-library.md`.
8. Set `tech_stack_binding`:
   - `abstract` by default
   - in standard N120 runs, keep `abstract` unless the source gives credible stack evidence or the user explicitly requests binding
   - `bound` only when the stack is given or explicitly requested
9. If the requirement could emit downstream interfaces, record `emitted_api_candidates[]` using stable names and IDs.
10. Separate `confirmed`, `inferred`, and `pending` content. Do not hide uncertainty inside prose.
11. If the artifact will be consumed by other workflow nodes, keep the output contract and downstream handoff fields explicit.
12. Run the checklist in `references/checklist.md` before finalizing.

## Output contract
Always produce a structured artifact that can be read by humans and reused by other skills. Use the template in `references/output-template.md` and the header rules in `references/artifact-contract.md`.

Always include an artifact header with:
- `artifact_name`
- `artifact_type`
- `schema_version`
- `workflow_node`
- `source_inputs[]`
- `primary_downstream_consumers[]` (for backward compatibility)
- `direct_consumers[]`
- `indirect_consumers[]`
- `eventbus_subscribers[]`
- `event_role`
- `gate_role`
- `self_check`
- `self_check_scope`
- `self_check_rules[]`
- `n120_mode` when `workflow_node: N120`

Each engineering requirement should use this normalized field set:
- `er_id`: stable ID such as `ER-001`
- `name`: short requirement name
- `source_requirements[]`: original business requirement IDs, quotes, or references
- `requirement_statement`: concise engineering statement
- `technical_aspects[]`: one or more canonical aspect keys
- `implied_needs[]`: hidden technical considerations made explicit
- `er_tier`: `t1_capability` | `t2_pattern` | `t3_implementation`
- `recognized_patterns[]`: reusable patterns recognized for this item
- `tech_stack_binding`: `abstract` | `bound`
- `stack_notes[]`: bound-stack details when applicable
- `actors[]`: relevant roles or systems
- `objects[]`: affected business or technical objects
- `triggers[]`: actions, states, schedules, or events that activate the requirement
- `acceptance[]`: verifiable acceptance statements
- `nfr_flags[]`: performance, reliability, security, compliance, observability, and similar non-functional notes
- `dependencies[]`: upstream systems, data, approvals, or prerequisites
- `risks[]`: design or delivery risks
- `open_questions[]`: unresolved decisions or missing evidence
- `emitted_api_candidates[]`: candidate API or event intents that should flow into downstream API analysis
- `confidence`: `explicit` | `inferred` | `pending`

Use canonical english enum keys in fields. User-facing explanation can still be in Chinese.

## Genericity rules
- Prefer portable requirement language such as “distributed lock capability” over vendor language such as “use shedlock” unless stack binding is requested.
- Use `t1_capability` and `t2_pattern` to keep the skill reusable across architectures.
- Only create `t3_implementation` items when the source explicitly requires a concrete implementation or the user asks for bound output.
- Do not let one domain vocabulary leak into the field contract. Normalize names so the same skill works for finance, hr, crm, logistics, or internal tooling.
- Do not assume all requirements map to CRUD. Include workflow, policy, audit, messaging, batch, and exception-oriented requirements.

## Standalone quality bar
When used alone, the artifact must answer all of these:
- what must be built
- which technical aspects are involved
- what hidden technical obligations should not be forgotten
- which items are decisions vs implementation suggestions
- what remains unresolved

If the source is incomplete, still produce the artifact and mark missing pieces as `pending`.

## Combination contract with downstream skills
When this skill feeds `api-intent-extraction` or other design skills:
- keep IDs stable
- fill `emitted_api_candidates[]` whenever a requirement implies an interface, callback, scheduled job, batch operation, or event
- use canonical field names so downstream skills can map without reinterpreting the source
- keep stack-neutral language unless the workflow has entered `bind_to_stack`
- keep the artifact header intact when the output is handed to workflow consumers

## Do not do these things
- do not turn every business sentence into a low-value technical item
- do not collapse multiple obligations into one vague requirement
- do not hide non-functional needs until a downstream stage if they are already implied now
- do not invent concrete products, tables, topics, paths, or frameworks without evidence
- do not output only narrative commentary; always produce a requirement inventory



## ER tier decision quick-reference
Choose the lightest tier that captures the obligation.

| Tier | When to use | Example |
|---|---|---|
| `t1_capability` | source says "must support X" without prescribing how | "system must support dual approval" |
| `t2_pattern` | source implies a well-known solution shape | "use retry with exponential backoff" |
| `t3_implementation` | source names a specific product/table/class | "use Redis for session storage" |

**Rule**: default to `t1_capability`. Only use `t3_implementation` when the source or user explicitly names the implementation. Never infer `t3` from domain knowledge.

## Implied needs quick-reference by technical aspect
| Aspect | Hidden obligations to surface |
|---|---|
| `concurrency` | lock strategy, deadlock analysis, isolation level |
| `idempotency` | key design, storage tier, TTL, 6-channel coverage |
| `audit` | A01-A10 categories, append-only, retention period |
| `authorization` | paradigm (RBAC/ABAC), SoD constraints, PoLP |
| `messaging` | DLQ, retry policy, ordering guarantee |
| `external_integration` | retry, circuit-breaker, idempotency, compensation |
| `scheduling` | cron drift, single-instance guard, idempotent job |
| `compliance` | applicable regulation, data residency, PII masking |

## Pattern library quick-reference
Common recognized patterns and their `er_tier`:

| Pattern | er_tier | Implied downstream skill |
|---|---|---|
| `saga_orchestration` | t2_pattern | 049 concurrency, 050 idempotency |
| `outbox_event_relay` | t2_pattern | 048 data-flow, 050 idempotency |
| `optimistic_locking` | t2_pattern | 049 concurrency |
| `dual_write_with_cdc` | t2_pattern | 048 data-flow |
| `four_eyes_approval` | t2_pattern | 052 authorization, 051 audit |
| `circuit_breaker` | t2_pattern | 053 performance |
| `idempotent_consumer` | t2_pattern | 050 idempotency |

## Confidence and uncertainty discipline
Every engineering requirement must declare its epistemic status:
- `confidence: explicit` — directly stated in the source; traceable to a quote or acceptance criterion
- `confidence: inferred` — implied by context, domain knowledge, or upstream artifact; must cite the reasoning
- `confidence: pending` — cannot be determined without additional information; must state what is missing

Separate `confirmed`, `inferred`, and `pending` content throughout the artifact. Do not hide uncertainty inside polished prose.
## Workflow v2 artifact contract

Every output must include this header block. Use `rule_results[]` format so N380 can aggregate automatically.

```yaml
artifact_schema_version: n120.er-inventory.v2.0.0
artifact_type: engineering_requirement_inventory
workflow_node: N120          # or standalone
skill_name: engineering-requirement-parsing
produced_event: produced.n120.engineering_requirement_inventory.v2
blocker_mapping: B-N120-01
readiness: ready | provisional | blocked
contract_status: draft | review_ready | blocked
confidence_summary:
  confirmed: []
  inferred: []
  pending: []
source_artifacts: []         # list actual inputs; do not claim files not consumed
direct_consumers: [N130, N150, N160]
indirect_consumers: [N170, N180]
eventbus_subscribers: [N330, N340]   # auto-triggered on produced event
route_back_to: none | n110
# none  — upstream artifacts sufficient; proceed to N130
# n110  — source gaps require PRD revision; return to N110 before re-parsing
rule_results:
  - rule_id: R01_every_er_has_technical_aspects
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_every_er_has_er_tier
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R03_emitted_api_candidates_when_interfaces_implied
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R04_confidence_explicit_not_silent
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R05_no_invented_stack_bindings
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R06_implied_needs_expanded
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R07_er_tier_not_all_t3_without_evidence
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R08_emitted_api_candidates_stable_ids
    severity: warn
    result: pass | warn | reject | not_applicable
feedback_signal_to_n005:
  signal_type: none | gap_detected | pattern_signal
  summary: ""                # populate when recurring gaps map to upstream requirement defects
  target_n070_skills:
  - 013-requirement-breakdown
  - 017-data-object-identification
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
```

## Upstream linkage from N070

When upstream N070 or N110 artifacts are available, inherit rather than re-derive:

| upstream artifact | inherit fields | action |
|---|---|---|
| `需求结构拆解.md` (013) | REQ-* ids, domain, L1-L5 levels | map to `er_id`, populate `source_requirements[]` |
| `业务规则清单.md` (014) | RULE-* ids, hardness, condition_expr | populate `nfr_flags[]`, `implied_needs[]` |
| `状态转移图.md` (015) | SM-* ids, trigger_kind, invariants | feed `recognized_patterns[]`, `triggers[]` |
| `权限矩阵.md` (016) | PERM-* ids, subject, grain | populate `actors[]`, security `nfr_flags[]` |
| `数据对象目录.md` (017) | OBJ-* ids, ddd_role, constraint_tags | populate `objects[]`, `implied_needs[]` |
| `需求交接包.zip` / `验收标准.md` (031/032) | acceptance criteria, open_questions | populate `acceptance[]`, `open_questions[]` |

If upstream artifacts exist but fields are missing or inconsistent, record discrepancy in `open_questions[]` and set `confidence: inferred`. Do not silently fill gaps.

## Reference files
Read these on demand:
- `references/artifact-contract.md` for legacy v1 header rules and N120 alignment
- `references/output-template.md` for the output skeleton
- `references/technical-aspect-catalog.md` for aspect enums and implied needs
- `references/pattern-library.md` for reusable engineering patterns
- `references/checklist.md` for self-check
- `references/orchestration.md` for standalone and paired usage
- `references/compatibility-map.md` for blueprint-to-runtime field mapping
- `references/common-failure-modes.md` for pitfalls
- `references/scoring-rubric.md` for quality scoring
- `references/example-io.md` for expected granularity and tone
