---
name: api-intent-extraction
description: extract api, event, callback, batch, and interface intents from business or engineering inputs with granularity control and family grouping. pairs with engineering-requirement-parsing inside n120.
---
# api-intent-extraction

Extract a stable inventory of interface intents from business or engineering inputs. The output must be useful on its own and also easy to combine with upstream requirement-parsing and downstream API design work.

## Core promise
- Work **standalone** from PRDs, stories, workflows, integration notes, or operating procedures.
- Work **in combination** by consuming normalized engineering requirement output without forcing humans to remap fields.
- Stay **style-agnostic**: support rest, graphql, grpc, event-driven, webhook, batch rpc, and streaming styles.
- Stay **workflow-aligned**: when used inside N120, emit a contract-ready, CSV-first inventory that can flow into N150 directly.



## Exception companion quick-reference
For every lifecycle family, check these exception companions before closing the inventory.

| Family pattern | Must check | Common missing intents |
|---|---|---|
| CRUD resource | cancel, soft-delete-undo, bulk-delete | status history query, bulk operations |
| Approval workflow | reject, withdraw, re-submit, timeout-expire | escalation, manual-override |
| Payment / transaction | refund, reversal, capture, void | chargeback, reconciliation-query |
| Async job / export | cancel-job, retry-job, job-status-query | DLQ-requeue, partial-result-download |
| Webhook / callback | callback-failure-compensation, callback-replay | signature-verify endpoint |
| Saga / multi-step | compensate-step-N, rollback-saga | saga-status-query, saga-replay |
| Import / batch | validate-only (dry-run), resume-partial, import-status | error-row-download |

## Trigger conditions
Trigger on any of: `开发需求解析.md`, `接口意图清单.csv`, N120 handoff materials, or any source describing actions, queries, integrations, jobs, callbacks, or events. Inside N120, always pair with `engineering-requirement-parsing`.

## API style quick-reference
| style | when to use |
|---|---|
| `rest` | stable CRUD resources, standard HTTP verbs |
| `graphql` | flexible query, client-driven shape |
| `grpc` | high-throughput internal RPC |
| `event_driven` | async publish/subscribe, state-change notification |
| `webhook` | outbound push to external consumer on trigger |
| `batch_rpc` | bulk operations, import/export, scheduled jobs |
| `streaming` | continuous data flow, real-time feed |

Default to `mixed_style` for complex platforms. Never force everything into REST.

## Accepted inputs
Use this skill when the source describes actions, queries, integrations, jobs, callbacks, events, or interface-facing behavior.
Typical sources:
- business requirement text
- engineering requirement inventories
- flow descriptions
- operational procedures
- integration contracts
- N120 handoff artifacts such as `开发需求解析.md`

If `engineering-requirement-parsing` output is available, treat it as the preferred upstream structure. Otherwise infer the same concepts directly from the source.

## Operating modes
### 1) `rest_first`
Use for simple CRUD or resource-centric systems.
Prioritize `rest` candidate intents while still checking for callbacks, jobs, export/import, or event needs.

### 2) `mixed_style`
Use for complex platforms or when the source already suggests multiple interface styles.
Support `rest`, `graphql`, `grpc`, `event_driven`, `webhook`, `batch_rpc`, and `streaming` side by side.

### 3) `openapi_draft`
Use only when the user explicitly wants a draft API contract.
Generate an intent inventory first, then convert applicable `rest` intents into an OpenAPI-oriented outline. Leave unknown fields as TODO instead of inventing details.

### 4) `api_family_graph`
Use when the user wants relationships visualized.
Group intents into families and optionally render a mermaid graph or adjacency list.

## Workflow alignment
### Standalone use
Default to the lightest mode that still produces a reusable intent inventory.

### N120 workflow use
If the request is part of **N120 技术需求理解**, or the inputs resemble `开发需求解析.md` plus N120 handoff materials, do all of the following:
- default to `mixed_style` unless the domain is clearly CRUD-only
- emit a primary artifact named `接口意图清单.csv`
- include the artifact header defined in `references/artifact-contract.md`
- use `artifact_type: interface_intent_inventory`
- use `schema_version: api-intent-inventory.v1`
- preserve stable `intent_id`, `intent_key`, and `derived_from_er_ids[]`
- make the inventory CSV-compatible even if a markdown summary is also provided
- keep detailed protocol design shallow enough that N150 can still refine it
- do not use `openapi_draft` as the default N120 handoff shape
- declare node-local self-check output by using the bundled checklist, scoring rubric, and common-failure references
- keep backward-compatible `primary_downstream_consumers[]` and also fill `direct_consumers[]`, `indirect_consumers[]`, and `eventbus_subscribers[]` when the artifact is used beyond the immediate conversation
- if the inputs are raw requirement or handoff materials without an ER inventory, prefer upstream 036 output before finalizing the N120-grade intent inventory

## Required workflow
1. Determine whether the task is standalone or workflow-bound. If it is workflow-bound, apply the correct artifact contract before writing the body.
2. Normalize the source into actors, objects, actions, triggers, state changes, integrations, schedules, and exceptions.
3. Apply the granularity rules in `references/granularity-rules.md`.
4. Create one intent per meaningful interface action, not per UI button and not per low-level field.
5. Assign `api_style` and the style-specific fields from `references/style-and-nfr-contract.md`.
6. Fill the shared field contract from `references/field-contract.md`.
7. Attach `nfr_hints` early. Treat these as coarse hints, not final SLO design.
8. Run the exception checklist so that cancel, retry, status, compensation, admin intervention, callback failure, and batch cases are not silently missed.
9. Group related intents into `resource_family` blocks.
10. If upstream engineering requirements exist, populate `derived_from_er_ids[]` and preserve traceability.
11. If the output will feed workflow consumers, preserve the artifact header and CSV-first inventory shape.
12. Use the self-check in `references/checklist.md` before finalizing.

## Shared output contract
Always produce a structured intent inventory using the template in `references/output-template.md` and the header rules in `references/artifact-contract.md`.

Always include an artifact header with:
- `artifact_name`
- `artifact_type`
- `schema_version`
- `workflow_node`
- `source_inputs[]`
- `primary_downstream_consumers[]` (for backward compatibility)
- `direct_consumers[]`
- `indirect_consumers[]`
- `eventbus_subscribers[]`
- `event_role`
- `gate_role`
- `self_check`
- `self_check_scope`
- `self_check_rules[]`
- `n120_mode` when `workflow_node: N120`

Each intent should use these normalized fields:
- `intent_id`: stable machine ID such as `API-001`
- `intent_key`: stable human-readable key such as `order.create`
- `name`: short intent name
- `derived_from_er_ids[]`: upstream engineering requirement IDs when available
- `resource_family`: logical family or lifecycle group
- `api_style`: `rest` | `graphql` | `grpc` | `event_driven` | `webhook` | `batch_rpc` | `streaming`
- `object_name`: primary business object or resource
- `action_name`: primary action
- `purpose`: user or system goal served by this intent
- `trigger`: user action, system event, schedule, upstream callback, or state transition
- `granularity_notes[]`: warnings or justification when a split/merge decision matters
- `exception_apis_checklist[]`: checked exception companions and whether they are needed
- `nfr_hints`: coarse non-functional hints from the contract reference
- `style_fields`: style-specific fields such as path/method, operation type, rpc name, event name, or stream direction
- `actors[]`: relevant users, services, or systems
- `preconditions[]`: entry conditions
- `constraints[]`: validation, permission, idempotency, or audit constraints
- `expected_result`: expected response or outcome
- `side_effects[]`: state changes, messages, notifications, jobs, or audit writes
- `open_questions[]`: unresolved design issues
- `confidence`: `explicit` | `inferred` | `pending`

Use canonical english enum keys in fields. Explanation text may remain in Chinese.

## Granularity rules
Follow all four rules from `references/granularity-rules.md`:
- one business verb
- one transaction or compensation unit
- single responsibility
- coherent response shape

Warn on both extremes:
- **under-splitting**: one intent hides multiple business actions or state transitions
- **over-splitting**: one intent has no meaningful business meaning on its own

## Multi-style rules
- Do not force everything into REST.
- Event publication, callbacks, subscriptions, batch jobs, and streams are first-class intents.
- The same family may include multiple styles.
- Only generate concrete HTTP methods, GraphQL operations, proto names, or event names when the source supports them or the user asked for a draft.

## Standalone quality bar
When used alone, the output must still answer:
- what interface actions exist
- what lifecycle family they belong to
- what exceptions or compensating flows were checked
- what non-functional hints already matter
- what is still unknown

## Combination contract with engineering-requirement-parsing
When upstream ER output exists:
- inherit stable IDs through `derived_from_er_ids[]`
- use upstream `technical_aspects[]` to prefill `nfr_hints` and exception checks
- use upstream `recognized_patterns[]` to scaffold likely intent families
- use upstream `emitted_api_candidates[]` as seeds, but still validate granularity and style
- keep the artifact header intact when the inventory is passed to N150 or adjacent workflow nodes

## Do not do these things
- do not map every UI control to a separate intent
- do not invent protocol details without evidence
- do not use `openapi_draft` unless the user explicitly asks for a draft contract
- do not ignore exception, callback, status, or batch paths
- do not wait until a downstream phase to mention obvious NFR needs already implied now
- do not output only prose; always produce an intent inventory

## Downstream handoff summary
When this skill's output is consumed by downstream nodes:
- `to_043_api_design`: intent_id, intent_key, api_style, nfr_hints, derived_from_er_ids → seeds for api_catalog
- `to_N150_api_design`: full intent inventory as CSV or structured YAML
- `to_N130_solution_analysis`: interface implication gaps flagged as emitted_api_candidates


## Confidence and uncertainty discipline
Every intent must declare its epistemic status:
- `confidence: explicit` — business verb and object directly stated in source
- `confidence: inferred` — implied by workflow description, state machine, or integration note
- `confidence: pending` — style, protocol, or actor cannot be determined without clarification

Separate `confirmed`, `inferred`, and `pending` intents. Mark inferred intents with the evidence cited.

## Standalone mode
When no upstream ER output exists, work directly from PRD or requirements:
- Use `selected_mode: from_source` and set `readiness: provisional`
- Mark all intents as `confidence: inferred` until validated against acceptance criteria
- Do not use `openapi_draft` as default; keep intents at granularity level for N150 to refine
## Workflow v2 artifact contract

Every output must include this header block. Use `rule_results[]` so N380 can aggregate automatically.

```yaml
artifact_schema_version: n120.api-intent-inventory.v2.0.0
artifact_type: interface_intent_inventory
workflow_node: N120          # or standalone
skill_name: api-intent-extraction
produced_event: produced.n120.api_intent_inventory.v2
blocker_mapping: B-N120-02
readiness: ready | provisional | blocked
contract_status: draft | review_ready | blocked
confidence_summary:
  confirmed: []
  inferred: []
  pending: []
source_artifacts: []
direct_consumers: [N150]
indirect_consumers: [N130, N160, N170]
eventbus_subscribers: [N330]  # N330 subscribes to generate API documentation
route_back_to: none | n120-er
# none     — intent inventory complete; N150 may proceed
# n120-er  — intent granularity requires ER revision; return to 036 first
rule_results:
  - rule_id: R01_one_business_verb_per_intent
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_exception_apis_checked
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R03_nfr_hints_populated
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R04_derived_from_er_ids_when_upstream_exists
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R05_no_openapi_draft_by_default
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R06_resource_family_coherent
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R07_nfr_hints_present_for_write_apis
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R08_confidence_not_silent
    severity: reject
    result: pass | warn | reject | not_applicable
feedback_signal_to_n005:
  signal_type: none | gap_detected | pattern_signal
  summary: ""
  target_n070_skills:
  - 013-requirement-breakdown
  - 015-state-transition-mapping
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
```

## Upstream linkage from N070

When upstream artifacts are available, consume rather than re-derive:

| upstream artifact | consume fields | maps to |
|---|---|---|
| `开发需求解析.md` (036) | `er_id`, `emitted_api_candidates[]`, `technical_aspects[]` | `derived_from_er_ids[]`, intent seeds, `nfr_hints` |
| `业务规则清单.md` (014) | RULE-* ids, `condition_expr`, `hardness` | `constraints[]`, `preconditions[]` |
| `状态转移图.md` (015) | SM-* transitions, `trigger_kind` | `trigger`, `side_effects[]`, callback intents |
| `权限矩阵.md` (016) | PERM-* ids, subject, action, effect | `actors[]`, access `constraints[]` |
| `验收标准.md` (032) | acceptance criteria | `expected_result`, exception companions |

## Reference files
Read these on demand:
- `references/artifact-contract.md` for legacy v1 header rules and N120 alignment
- `references/output-template.md` for the default artifact shape
- `references/field-contract.md` for normalized fields
- `references/granularity-rules.md` for split/merge rules
- `references/style-and-nfr-contract.md` for style support and nfr hints
- `references/orchestration.md` for standalone and paired usage
- `references/checklist.md` for self-check
- `references/common-failure-modes.md` for pitfalls
- `references/example-io.md` for target granularity
- `references/scoring-rubric.md` for quality scoring
- `references/compatibility-map.md` for blueprint-to-runtime field mapping
