# CHANGELOG

## 2026-04-23 · n120 cleanup pass

Scope: align the skill with the latest N120 analysis feedback while preserving backward-compatible output contracts.

### Changes
- restore the N120 discovery description so pairing with `engineering-requirement-parsing` is the default combination inside N120
- remove the unregistered `flow-description.md` example input and keep workflow-registered inputs plus generic standalone evidence labels
- restore machine-readable `self_check_rules[]` in the artifact contract and output template
- add backward-compatible consumer split fields: `direct_consumers[]`, `indirect_consumers[]`, and `eventbus_subscribers[]`
- align `n120_mode` with the four N120 workflow modes and keep standalone represented through `workflow_node: standalone`
- preserve dual IDs with `intent_id` and `intent_key`, and keep `derived_from_er_ids[]` mandatory when upstream ERs exist

### Not in this package
- platform-side replacement of `primary_downstream_consumers[]`
- node-level `routing_decision` or eventbus registry changes
