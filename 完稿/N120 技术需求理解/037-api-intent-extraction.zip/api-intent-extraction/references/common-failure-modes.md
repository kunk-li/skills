# Common failure modes

## F1: UI-control explosion
Symptom: every button, tab, or input field becomes a separate intent.
Fix: one business verb = one intent. "Submit form" and "click send" are one intent if they invoke the same backend action.

## F2: sunny-day lifecycle only
Symptom: cancel, retry, status-query, callback-failure, and admin-intervention intents are absent.
Fix: explicitly check `exception_apis_checklist[]` for every family before closing.

## F3: forcing callbacks into POST endpoints
Symptom: `onboarding.hr.provisioning_callback` becomes `POST /hr/notify` instead of a `webhook` style intent.
Fix: use `api_style: webhook | event_driven | batch_rpc` when the source implies it.

## F4: invented protocol details
Symptom: specific HTTP paths, proto method names, or event topic names appear without source evidence.
Fix: keep `style_fields` shallow (method/path direction) until N150 refines them; never invent names.

## F5: NFR hints deferred silently
Symptom: idempotency, auth, audit, and rate-limit needs are noted as "later work" even when the source clearly implies them now.
Fix: populate `nfr_hints` with coarse signals at intent level; N150/N170 will deepen them.

## F6: ungrouped intents
Symptom: related intents (create, update, cancel, status, callback) are listed flat with no `resource_family`.
Fix: group into families; downstream API design relies on family coherence to spot missing members.

## F7: openapi_draft by default
Symptom: the output generates full HTTP path+schema blocks even when the user asked for an intent inventory.
Fix: use `openapi_draft` mode only when the user explicitly requests a draft contract.
