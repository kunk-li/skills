# Common failure modes

Status: implemented

1. Mapping each screen button to a separate intent.
2. Keeping only the sunny-day lifecycle and forgetting cancel, retry, status, callback-failure, or admin intervention paths.
3. Forcing event-driven or callback behavior into fake POST endpoints.
4. Inventing protocol details that the source never stated.
5. Treating NFR concerns as “later work” even when the source already implies them.
6. Leaving related intents ungrouped so downstream design has to rediscover families manually.
7. Requiring upstream skills to make the output understandable.
