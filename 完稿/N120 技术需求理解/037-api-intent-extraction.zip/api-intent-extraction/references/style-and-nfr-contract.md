# Style and NFR contract

Status: implemented

## Supported api styles
| Key | Typical use |
| --- | --- |
| `rest` | resource-oriented HTTP interfaces |
| `graphql` | query/mutation/subscription with flexible field selection |
| `grpc` | service/rpc contracts |
| `event_driven` | publish/subscribe or message bus contracts |
| `webhook` | external callback delivery |
| `batch_rpc` | batch-oriented command or query interfaces |
| `streaming` | websocket, sse, or gRPC streaming |

## Early-stage nfr hint defaults
Use these as defaults, then adjust based on the source.

### Write-like intents
- `idempotency_needed = true`
- `auth_level` is usually `user`, `internal_service`, or `admin`

### Query-like intents
- `idempotency_needed = false`
- `latency_criticality` depends on user-facing importance

### Aspect-to-nfr heuristics
- upstream `concurrency` or `idempotency` -> set `idempotency_needed = true`
- upstream `authentication` -> set `auth_level` to at least `user` or `internal_service`
- upstream `audit` -> set `audit_level = full`
- upstream `compliance` -> set `audit_level = compliance`
- upstream `notification` or high-volume job behavior -> review `ratelimit_tier`
- user-facing critical paths -> review `latency_criticality = high`

## Exception API checklist
Review these companions for every family:
- cancel / revoke / delete
- retry / replay
- status / progress query
- admin intervention / manual repair
- callback failure compensation
- batch import / export
- stream subscription or unsubscribe when streaming applies

Each item may be marked as not needed, but never skip the review silently.
