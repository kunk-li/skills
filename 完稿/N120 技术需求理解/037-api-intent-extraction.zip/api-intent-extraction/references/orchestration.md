# Orchestration guide

Status: implemented

## Standalone mode
Use this skill alone when the user needs an interface intent inventory from business or operational material.
The result must still be complete enough for API review, integration review, or scoping discussion.

## Workflow-bound mode
When the task belongs to N120:
- default to `mixed_style` unless the domain is clearly CRUD-only
- emit `接口意图清单.csv`
- preserve the artifact header from `artifact-contract.md`
- preserve stable `intent_id`, `intent_key`, and `derived_from_er_ids[]` for N150 and adjacent nodes
- do not use `openapi_draft` as the default N120 handoff shape
- if the inputs are only raw requirement or handoff material, prefer upstream 036 output first; do not finalize an N120-grade intent inventory until ER structure exists

## Preferred paired mode: 036 -> 037
This is the strongest business-to-interface path.

### Upstream fields to reuse
- 036 `er_id` -> 037 `derived_from_er_ids[]`
- 036 `objects[]` -> 037 `object_name`
- 036 requirement statements and `emitted_api_candidates[]` -> 037 candidate intents
- 036 `technical_aspects[]` -> 037 `nfr_hints` defaults
- 036 `recognized_patterns[]` -> 037 likely intent families or exception companions
- 036 artifact header -> 037 workflow traceability header

### Recommended flow
1. Run `engineering-requirement-parsing` in `deep_parse` mode.
2. Review requirement inventory, hidden obligations, and emitted API candidates.
3. Run this skill in `mixed_style` mode unless the domain is clearly CRUD-heavy.
4. Preserve traceability with `derived_from_er_ids[]`.
5. Keep both `intent_id` and `intent_key`.
6. Group the result by `resource_family` for downstream design.

## Combination heuristics
- If upstream requirements emphasize `messaging`, always review callback, event, and status paths.
- If upstream requirements include `idempotency` or `concurrency`, prefill `nfr_hints.idempotency_needed = true` for write-like intents.
- If upstream requirements include `audit` or `compliance`, raise `audit_level` accordingly.
- If upstream patterns include `saga_orchestration`, look for start, step, compensate, and status intent families.

## Pattern-driven scaffolding hints
When upstream `recognized_patterns[]` exist, use them as hints rather than hard rules:
- `saga_orchestration` -> review start, step, compensate, and status intents
- `idempotency_key` -> review write intent headers, replay handling, and 409/conflict semantics
- `retry_with_backoff` -> review retry trigger or job intent and failure status visibility
- `rate_limit_token_bucket` -> review 429-like protection semantics or throttling events

## Traceability rule
A reviewer should be able to move in both directions:
- from engineering requirement to interface intent
- from interface intent back to the requirement that justified it
- from either artifact back to the workflow contract and schema version
