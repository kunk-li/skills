# Compatibility map — v2 alignment

Maps N120 blueprint vocabulary to v2 runtime fields for api-intent-extraction.

## Intent identifiers
| Blueprint concept | v2 Runtime field | Notes |
|---|---|---|
| `API-ORDER-CREATE` style IDs | `intent_key` | Human-readable stable key, e.g. `order.create` |
| Stable machine ID | `intent_id` | Compact stable ID, e.g. `API-001` — never changes across revisions |
| Upstream ER refs | `derived_from_er_ids[]` | Mandatory when 036 output exists; empty array when standalone |

## Intent family and action mapping
| Blueprint concept | Runtime field | Example value |
|---|---|---|
| Resource family / lifecycle group | `resource_family` | `order_approval` |
| Business verb | `action_name` | `create`, `approve`, `cancel` |
| Business object | `object_name` | `OnboardingDraft`, `ApprovalDecision` |
| Interface style | `api_style` | `rest` / `event_driven` / `webhook` / `batch_rpc` |

## API style runtime mapping
| Blueprint notion | `api_style` value | style_fields prefix |
|---|---|---|
| REST CRUD or state transition | `rest` | `style_fields.rest.method`, `.path` |
| GraphQL query/mutation/subscription | `graphql` | `style_fields.graphql.operation_type` |
| gRPC service method | `grpc` | `style_fields.grpc.service`, `.method` |
| Async publish/subscribe | `event_driven` | `style_fields.event_driven.topic`, `.event_name` |
| Outbound push to registered URL | `webhook` | `style_fields.webhook.callback_url_pattern` |
| Bulk import/export/scheduled | `batch_rpc` | `style_fields.batch_rpc.trigger` |
| Continuous stream | `streaming` | `style_fields.streaming.direction` |

## NFR hint mapping (coarse — N150/N170 will deepen)
| Upstream signal | `nfr_hints` field |
|---|---|
| "idempotent" in ER or story | `idempotency: key_based` |
| Auth/permission reference | `auth: PERM_XXX` |
| "must audit" | `audit: required` |
| Rate limit mention | `rate_limit: yes` |
| SLO/latency target | `latency_hint: <target>` |

## v2 contract field cross-reference
| v2 field | Purpose | Consumer |
|---|---|---|
| `produced_event` | `produced.n120.api_intent_inventory.v2` | N330 doc generation |
| `route_back_to: n120-er` | Granularity issue requires 036 revision | 036 skill |
| `rule_results[]` | Gate results R01-R05 | N380 |
| `feedback_signal_to_n005` | Pattern gap triggers N070 revision | N005 |

## Combination rule with 036
When `emitted_api_candidates[]` exist from 036, treat them as seeded intent candidates. Still validate each against granularity rules — do not assume seeds are correctly sized. A single ER candidate may split into 2–3 intents or merge with another.
