# Compatibility map

Status: implemented

Use this file to map the higher-level N120 blueprint vocabulary to the compact interface-inventory fields used by this skill.

## Intent identifiers
| Blueprint concept | Runtime field | Notes |
| --- | --- | --- |
| `API-ORDER-CREATE` style readable IDs | `intent_key` | Preferred human-readable key, for example `order.create`. |
| stable machine ID | `intent_id` | Use a compact stable ID such as `API-001`. Keep it diff-stable across revisions. |
| upstream ER refs | `derived_from_er_ids[]` | Mandatory when the source includes upstream ER output. |

## Family and action mapping
| Blueprint concept | Runtime field |
| --- | --- |
| resource family | `resource_family` |
| business verb / action | `action_name` |
| resource / object | `object_name` |
| api style | `api_style` |

## Style mapping
| Blueprint notion | Runtime field | Notes |
| --- | --- | --- |
| REST path/method shape | `style_fields.rest.*` | Keep shallow unless the task explicitly asks for a draft contract. |
| GraphQL query/mutation/subscription | `style_fields.graphql.*` | |
| gRPC service/method | `style_fields.grpc.*` | |
| event / webhook / callback | `style_fields.event_driven.*` or `style_fields.webhook.*` | |

## Combination rule with 036
When paired with `engineering-requirement-parsing`, keep both `intent_id` and `intent_key`, preserve `derived_from_er_ids[]`, and treat `emitted_api_candidates[]` as hints rather than final intent boundaries.
