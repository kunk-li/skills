# Artifact contract

Status: implemented

Use this header whenever the output will be consumed beyond the immediate conversation.

## Required header
Place this header at the top of the artifact before the summary sections.

```yaml
artifact_name: 接口意图清单.csv
artifact_type: interface_intent_inventory
schema_version: api-intent-inventory.v1
workflow_node: N120 | standalone
n120_mode: full_n120 | er_only | intent_only | refresh   # required when workflow_node: N120
source_inputs:
  - 开发需求解析.md
  - 需求交接包.zip
  - 需求质量审查单.md
  - 验收标准.md
  - raw requirement text
primary_downstream_consumers:
  - N130
  - N150
direct_consumers:
  - N130
  - N150
indirect_consumers: []
eventbus_subscribers: []
event_role: producer
gate_role: none
self_check: produces
self_check_scope: node_local
self_check_rules:
  - every_intent_has_api_style
  - every_intent_has_intent_key
  - derived_from_er_ids_present_when_upstream_er_exists
```

## Rules
- When used in N120, keep `artifact_name` as `接口意图清单.csv`.
- When used standalone, keep `artifact_type` and `schema_version` unchanged, set `workflow_node: standalone`, and omit `n120_mode` because the four N120 modes apply only to workflow-bound runs.
- `source_inputs[]` must list the real inputs that were consumed. Do not claim files that were not used. For standalone work, use generic evidence labels such as `prd text`, `meeting note text`, `process description text`, or `integration note text` rather than inventing unregistered workflow artifact filenames.
- The primary inventory must be CSV-compatible even if you also provide a markdown explanation.
- Keep `derived_from_er_ids[]` whenever upstream engineering requirements exist. `self_check_rules[]` provides the machine-readable rule entry points for N380 aggregation and linter checks.
- Use both `intent_id` and `intent_key` when the inventory is intended for downstream review, diffing, or orchestration.
- `openapi_draft` is allowed only when the user explicitly requests a draft contract. It is not the default N120 handoff shape.
- In N120 `full_n120` or `refresh` mode, do not finalize an intent inventory from raw requirement material until upstream ER output or an equivalent ER abstraction is available.

## Minimum downstream guarantee
A downstream reviewer should be able to answer all of the following without reopening the original product document:
- what this intent inventory is
- which workflow node or standalone context produced it
- which N120 mode produced it
- which interface intent IDs and readable intent keys are stable
- which engineering requirement IDs justified each intent when upstream ERs exist
- which downstream node should consume it next
