# Field contract

Status: implemented

Use this normalized contract so the skill stays reusable across architectures and integrates cleanly with upstream and downstream skills.

## Shared fields
| Field | Meaning |
| --- | --- |
| `intent_id` | stable machine ID such as `API-001` |
| `intent_key` | stable human-readable key such as `order.create` |
| `name` | short readable label |
| `derived_from_er_ids[]` | upstream engineering requirement IDs |
| `resource_family` | lifecycle or object family that groups related intents |
| `api_style` | interface style enum |
| `object_name` | primary business object or resource |
| `action_name` | primary action |
| `purpose` | why this intent exists |
| `trigger` | event, user action, schedule, callback, or state change |
| `granularity_notes[]` | split/merge rationale or warnings |
| `exception_apis_checklist[]` | reviewed companion intents and need/no-need decisions |
| `actors[]` | users, services, or systems involved |
| `preconditions[]` | entry conditions |
| `constraints[]` | validation, permission, idempotency, audit, or policy constraints |
| `expected_result` | response or outcome |
| `side_effects[]` | state changes or emitted actions |
| `open_questions[]` | unresolved design points |
| `confidence` | `explicit` | `inferred` | `pending` |

## NFR hints contract
Use this as a coarse early-stage hint block.

```json
{
  "expected_qps": "low|medium|high|extreme",
  "latency_criticality": "low|medium|high",
  "idempotency_needed": true,
  "ratelimit_tier": "per_user|per_tenant|global|none",
  "auth_level": "anonymous|user|internal_service|admin",
  "audit_level": "none|access|full|compliance"
}
```

## Style fields
Use the minimum style-specific fields required to express the intent.

### `rest`
- `method`
- `path_hint`
- `path_params[]`
- `query_params[]`
- `body_hint[]`

### `graphql`
- `operation_type`
- `operation_name`
- `args[]`
- `fields[]`

### `grpc`
- `service`
- `rpc`
- `request_proto_hint`
- `response_proto_hint`

### `event_driven`
- `event_name`
- `publisher`
- `subscribers[]`
- `payload_hint[]`

### `webhook`
- `callback_name`
- `producer`
- `consumer`
- `payload_hint[]`

### `batch_rpc`
- `interface_name`
- `batch_scope`
- `payload_hint[]`

### `streaming`
- `interface_name`
- `stream_direction`
- `payload_hint[]`

## Usage rules
- Keep shared semantics in shared fields and protocol details in `style_fields`.
- Prefer empty or TODO values over invented protocol details.
- Use `intent_key` for readable, diff-friendly references and `intent_id` for stable machine-facing references.
- If an intent truly spans multiple objects or styles, split it unless the source explicitly treats them as one coherent interface unit.
