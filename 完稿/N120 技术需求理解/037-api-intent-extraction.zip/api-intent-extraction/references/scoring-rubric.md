# Scoring rubric

Status: implemented

## A. intent coverage
| Score | Standard |
| --- | --- |
| 5 | Main lifecycle, exceptions, callbacks, and non-REST styles are all covered appropriately |
| 4 | Main lifecycle and most exceptions are covered |
| 3 | Core intents are usable but some styles or exceptions are thin |
| 2 | Mainly sunny-day command/query coverage |
| 1 | Inventory is too sparse to hand off |

## B. granularity quality
| Score | Standard |
| --- | --- |
| 5 | Splits are stable, justified, and reviewer-friendly |
| 4 | Mostly well-sized with minor edge-case issues |
| 3 | Usable but some intents are too broad or too narrow |
| 2 | Granularity varies heavily by row |
| 1 | No clear splitting logic |

## C. standalone and combination fitness
| Score | Standard |
| --- | --- |
| 5 | Output stands alone and integrates cleanly with 036 or downstream API design |
| 4 | Mostly complete with small traceability gaps |
| 3 | Usable, but one of standalone or combination quality needs manual cleanup |
| 2 | Depends heavily on human reinterpretation |
| 1 | Cannot be reused reliably |
