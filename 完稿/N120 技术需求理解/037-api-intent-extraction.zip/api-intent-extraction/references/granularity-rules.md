# Granularity rules

Status: implemented

Use these four rules together to keep intent splitting stable across teams.

## R1. one business verb
One intent should represent one meaningful business action or retrieval purpose.

## R2. one transaction or compensation unit
One call or interface action should map to one execution unit or one compensation unit.
If compensation is independent, it deserves its own intent.

## R3. single responsibility
An intent should do one job. Creation, approval, cancellation, refund, export, and callback handling are usually distinct.

## R4. coherent response shape
The response or outcome should have one coherent semantic purpose. If the source implies unrelated payload shapes, the intent is probably under-split.

## Under-splitting signals
- One intent spans multiple lifecycle states.
- One intent hides create + approve + notify + sync as a single action.
- One intent mixes command and analytics/export semantics.

## Over-splitting signals
- The split exists only because different buttons lead to the same action.
- The split isolates fields rather than business meaning.
- The split creates intents without an independent caller purpose.

## Review tip
When unsure, ask: “Would a reviewer treat this as one business capability or several?”
