# Example I/O

## Example input
"Employee onboarding approval: employees submit drafts, managers approve or reject, the system sends reminders after 48h, and triggers an HR provisioning callback on final approval."

## Good output — intent inventory

```yaml
resource_family: onboarding_approval

intents:
  - intent_id: API-001
    intent_key: onboarding.draft.create
    api_style: rest
    object_name: OnboardingDraft
    action_name: create
    purpose: Employee initiates an onboarding approval request
    trigger: employee submits form
    nfr_hints: {idempotency: key_based, auth: PERM_ONBOARDING_CREATE, audit: required}
    exception_apis_checklist:
      - cancel_draft: needed
      - status_query: needed
    confidence: explicit

  - intent_id: API-002
    intent_key: onboarding.approval.submit
    api_style: rest
    object_name: ApprovalDecision
    action_name: submit
    purpose: Manager records approve or reject decision on a pending request
    trigger: manager clicks approve/reject
    nfr_hints: {idempotency: key_based, auth: PERM_ONBOARDING_APPROVE, audit: required}
    granularity_notes: ["approve and reject share one intent — both are decisions on the same state transition"]
    confidence: explicit

  - intent_id: API-003
    intent_key: onboarding.reminder.trigger
    api_style: batch_rpc
    object_name: PendingApprovalStep
    action_name: send_reminder
    purpose: Scheduled job sends reminder to approver after 48h inactivity
    trigger: scheduler / cron, 48h elapsed
    nfr_hints: {idempotency: job_attempt_based, audit: required}
    exception_apis_checklist:
      - reminder_failure_dlq: needed
    confidence: inferred

  - intent_id: API-004
    intent_key: onboarding.hr.provisioning_callback
    api_style: webhook
    object_name: HRProvisioningEvent
    action_name: push
    purpose: System notifies HR of final approval to trigger employee provisioning
    trigger: final_approval state transition
    nfr_hints: {idempotency: key_based, retry: yes, auth: outbound_hmac}
    exception_apis_checklist:
      - callback_failure_compensation: needed
      - callback_status_query: needed
    confidence: inferred
    open_questions:
      - "Is HR callback synchronous or async outbox?"

  - intent_id: API-005
    intent_key: onboarding.draft.status
    api_style: rest
    object_name: OnboardingDraft
    action_name: get_status
    purpose: Read current state and approval history of a draft
    trigger: employee or manager polls status
    nfr_hints: {auth: PERM_ONBOARDING_READ, cache: short-ttl}
    confidence: explicit
```

## What makes this good
- Scheduler job (API-003) and webhook (API-004) are not forced into fake POST endpoints.
- Reminder is `batch_rpc`, HR callback is `webhook` — multi-style in one family.
- `exception_apis_checklist` catches DLQ and callback compensation before downstream design.
- `open_questions` on API-004 surfaces the blocking integration decision early.
- No invented HTTP paths or proto names — those are for N150 API design.

## ex-002 · granularity failures — before and after

```yaml
# BEFORE: under-splitting (one giant intent hiding 4 actions)
- intent_id: API-BAD-001
  intent_key: approval.manage
  action_name: manage        # BAD: 'manage' is not a verb — it hides create/submit/approve/reject
  granularity_notes: ["FAIL: single intent covers create_draft, submit, approve, and reject — four distinct state transitions"]

# AFTER: correct split
- intent_id: API-001
  intent_key: approval.draft.create
  api_style: rest
  action_name: create
  purpose: "Employee creates an initial approval request draft"
  confidence: explicit

- intent_id: API-002
  intent_key: approval.draft.submit
  api_style: rest
  action_name: submit
  purpose: "Employee submits draft for manager review"
  trigger: "employee clicks 'Submit for review'"
  confidence: explicit

- intent_id: API-003
  intent_key: approval.decision.record
  api_style: rest
  action_name: decide
  purpose: "Manager records approve or reject decision"
  granularity_notes: ["approve and reject share one intent — both are decisions on the same state transition; separate if response shapes differ significantly"]
  confidence: explicit

- intent_id: API-004
  intent_key: approval.reminder.trigger
  api_style: batch_rpc
  action_name: send_reminder
  purpose: "Scheduler triggers reminder after 48h inactivity"
  trigger: "cron job, 48h elapsed since last action"
  nfr_hints: {idempotency: job_attempt_based}
  confidence: inferred

# OVER-SPLITTING example (also wrong):
- intent_id: API-BAD-002
  intent_key: approval.draft.set_subject
  action_name: set_subject   # BAD: field-level action, not a business verb
  granularity_notes: ["FAIL: setting a field is not a separate API — this belongs in approval.draft.create or approval.draft.update"]
```

## ex-003 · degraded — no ER input; working from PRD prose only

```yaml
artifact_schema_version: n120.api_intent_inventory.v2.0.0
skill_name: api-intent-extraction
readiness: provisional
selected_mode: from_source
evidence_profile:
  confirmed: []
  inferred: [all intents derived from PRD section 3 prose]
  pending: [actor verification, callback URL pattern, pagination style]

intents:
  - intent_id: API-001
    intent_key: leave.request.create
    api_style: rest
    action_name: create
    confidence: inferred
    inferred_from: "PRD: 'employees can submit leave requests'"
    granularity_notes: ["inferred from prose — may need split if approval and draft are separate states"]

  - intent_id: API-002
    intent_key: leave.approval.decide
    api_style: rest
    action_name: decide
    confidence: inferred
    inferred_from: "PRD: 'managers approve or reject requests'"
    granularity_notes: ["approve + reject share one intent provisionally — verify if response shapes differ"]

degraded_reason: "No structured ER output (036) available; all intents inferred from PRD prose"
degraded_impact: "NFR hints absent; API style unverified; exception companions not confirmed"
pending_evidence:
  - "ER output from 036 to validate intent boundaries"
  - "Actor definitions to confirm who can call each API"
  - "API style decision (REST vs event-driven for approval notification)"

route_back_to: null
feedback_signal_to_n005:
  signal_type: provisional_output
  summary: "Intent inventory provisional — 2 intents inferred, 0 confirmed. Run 036 first for higher confidence."
```

## ex-004 · blocked — contradictory style requirements cannot be resolved

```yaml
skill_name: api-intent-extraction
readiness: blocked
blocker_mapping: B-N120-02
route_back_to: engineering-requirement-parsing

blockers:
  - blocker_id: BLK-INTENT-001
    type: contradictory_style_requirements
    description: "ER-010 states 'must use REST for all external APIs', ER-011 requires 'real-time push notifications via WebSocket'. Cannot classify intents without resolving style conflict."
    impact: "api_style field cannot be assigned for notification intents — REST polling vs WebSocket are architecturally incompatible"
    resolution_required: "Route back to 036 to resolve ER-010 vs ER-011 contradiction"
    unblock_evidence: "Revised ER with single style policy, or explicit decision accepting mixed styles"

  - blocker_id: BLK-INTENT-002
    type: missing_actor_definitions
    description: "3 intents reference 'external partner API' but no partner actor definition exists in any upstream artifact"
    impact: "Cannot set auth, rate_limit_ref, or NFR hints for partner-facing APIs without actor definition"
    resolution_required: "Actor definition for external partners from N070-016 permission-matrix-extraction"

partial_output:
  confirmed_intents: [API-001, API-002, API-003]
  blocked_intents: [API-004 through API-006 - all partner-facing]
  intent_catalog_complete: false
```
