# Example IO

Status: implemented

## Example input
- “Employee onboarding approval needs create draft, submit, dual approval decisions, cancellation before final approval, reminder timeout handling, and hr-system callback after provisioning.”

## Good output characteristics
- Produces an approval family instead of one giant process intent.
- Distinguishes user commands, status queries, scheduler jobs, and external callbacks.
- Flags exception companions such as cancel, retry reminder, and callback failure compensation.
- Adds coarse `nfr_hints` for auth, audit, and idempotency.
- Preserves upstream ER traceability when available.
