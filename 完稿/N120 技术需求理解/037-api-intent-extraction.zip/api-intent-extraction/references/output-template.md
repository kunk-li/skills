# Output template

Status: implemented

Use this as the default handoff artifact.

## 0. Artifact contract header
Place this header first. Use the exact keys from `artifact-contract.md`.

```yaml
artifact_name: 接口意图清单.csv
artifact_type: interface_intent_inventory
schema_version: api-intent-inventory.v1
workflow_node: N120 | standalone
n120_mode: full_n120 | er_only | intent_only | refresh   # required when workflow_node: N120
source_inputs: []
primary_downstream_consumers: [N130, N150]
direct_consumers: [N130, N150]
indirect_consumers: []
eventbus_subscribers: []
event_role: producer
gate_role: none
self_check: produces
self_check_scope: node_local
self_check_rules:
  - every_intent_has_api_style
  - every_intent_has_intent_key
  - derived_from_er_ids_present_when_upstream_er_exists
```

## 1. Context summary
- parsing mode: `rest_first` | `mixed_style` | `openapi_draft` | `api_family_graph`
- source type
- key assumptions

## 2. Intent inventory
Render this section in a CSV-compatible column order whenever the output is meant for workflow handoff.
Use one row per interface intent.

| intent_id | intent_key | name | derived_from_er_ids | resource_family | api_style | object_name | action_name | purpose | trigger | granularity_notes | exception_apis_checklist | nfr_hints | actors | preconditions | constraints | expected_result | side_effects | open_questions | confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## 3. Family view
Group intents by `resource_family`.
Suggested columns:
| resource_family | primary_actor | key intents | shared invariants | lifecycle gaps |
| --- | --- | --- | --- | --- |

## 4. Exception and completeness review
List companion intents that were checked, for example:
- cancel / revoke / delete
- retry / replay
- status / progress query
- admin intervention
- callback failure compensation
- batch import / export

## 5. Style-specific appendix
Only include subsections that are needed.

### rest
| intent_id | method | path_hint | path_params | query_params | body_hint |
| --- | --- | --- | --- | --- | --- |

### graphql
| intent_id | operation_type | operation_name | args | fields |
| --- | --- | --- | --- | --- |

### grpc
| intent_id | service | rpc | request_proto_hint | response_proto_hint |
| --- | --- | --- | --- | --- |

### event_driven / webhook
| intent_id | event_name_or_callback | publisher | subscribers_or_consumer | payload_hint |
| --- | --- | --- | --- | --- |

### batch_rpc / streaming
| intent_id | interface_name | batch_or_stream_direction | payload_hint |
| --- | --- | --- | --- |

## 6. Open questions
| question_id | related_intent_ids | question | impact |
| --- | --- | --- | --- |

## 7. Optional OpenAPI draft section
Include only when mode is `openapi_draft` and only for `rest` intents with enough evidence.
