# Delivery checklist

Status: implemented

## A. Standalone completeness
- [ ] The artifact contains a real intent inventory, not only narrative explanation.
- [ ] Every intent has `intent_id`, `resource_family`, `api_style`, `object_name`, `action_name`, and `purpose`.
- [ ] Non-REST styles were checked explicitly instead of assumed away.
- [ ] `nfr_hints` are present whenever the source implies performance, idempotency, auth, audit, rate limit, or latency concerns.
- [ ] Exception companions were reviewed instead of silently omitted.

## B. Contract compliance
- [ ] The artifact starts with the header from `artifact-contract.md`.
- [ ] `artifact_type` is `interface_intent_inventory`.
- [ ] `schema_version` is present and stable.
- [ ] If the task is N120, `artifact_name` is `接口意图清单.csv` and the primary inventory is CSV-compatible.

## C. Granularity quality
- [ ] No UI-control explosion.
- [ ] No mega-intent that hides multiple business actions.
- [ ] Split and merge decisions are justified in `granularity_notes[]` when needed.
- [ ] Each intent still has a meaningful business purpose.

## D. Combination readiness
- [ ] `derived_from_er_ids[]` is filled when upstream ERs exist.
- [ ] `resource_family` grouping is coherent and useful for downstream design.
- [ ] Upstream technical aspects or patterns have been reflected into `nfr_hints` or scaffolding where appropriate.
- [ ] Open questions point to specific intent IDs.

## E. One-vote rejection items
Any of the following makes the output non-compliant:
- [ ] Forcing all intents into REST when the source clearly implies other styles.
- [ ] Inventing methods, paths, proto names, or event names without evidence.
- [ ] Missing exception review for an asynchronous or workflow-heavy domain.
- [ ] The output cannot be consumed independently from other skills.
- [ ] The output is meant for workflow handoff but lacks the artifact header or CSV-first inventory.
