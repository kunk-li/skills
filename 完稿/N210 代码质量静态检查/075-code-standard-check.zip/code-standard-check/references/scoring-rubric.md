# code-standard-check 评分标准 v2.4

## 总览

输出按 4 个维度评分，每维 0-3 分，总分 0-12。等级映射:

| 总分 | 等级 | 含义 |
|---|---|---|
| 11-12 | **S** | 可直接消费; 字段、位置、依据齐全 |
| 9-10 | **A** | 生产可用; 轻微补齐 |
| 6-8 | **B** | 有用但需人工修订 |
| ≤5 | **C** | 不建议直接消费 |

---

## 维度 1: 规则定位精度 (rule_localization)

衡量: 每条 violation 是否能精确定位到代码 + 规则.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% violation 同时声明 file_path、line_range、rule_id (STD-CATEGORY-NNN), 含原始代码片段 (≤6 行) |
| **A (2)** | ≥90% violation 完整定位; 少量 (<10%) 仅给出 file 级 |
| **B (1)** | 50-90% 完整定位, 其余仅类名/包名 |
| **C (0)** | <50% 含 line_range, 或无 rule_id |

---

## 维度 2: 规则证据深度 (rule_evidence_depth)

衡量: 每条 violation 是否引用具体规则文档/约定来源.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% violation 引用 review-rules.md 中具体 rule_id, 含 introduced_version + tech_stack 字段 |
| **A (2)** | ≥80% 含 rule_id 引用; 余下用具体规则名 |
| **B (1)** | 仅给规则类别 (如 "命名规范"), 无具体 rule_id |
| **C (0)** | 凭直觉判断, 未引用任何规则源 |

---

## 维度 3: 严重度与 SLA 一致性 (severity_sla_consistency)

衡量: severity 分级是否合理 + SLA 标注是否一致.

| 等级 | 标准 |
|---|---|
| **S (3)** | severity 严格用 critical/high/medium/low/info 五档, 所有 critical 含 sla_escalation_hint, 分布合理 (critical < 5%) |
| **A (2)** | 五档分级清晰, 个别 critical 缺 SLA 提示 |
| **B (1)** | 仅二档 (high/low) 或 critical 占比 >20% (说明分级失效) |
| **C (0)** | 无 severity 字段, 或全部标 critical/全部 low |

---

## 维度 4: 跨 skill 交付质量 (cross_skill_handoff)

衡量: 与 N210 其他 skill 的协同 + node_aggregation 模式完整度.

| 等级 | 标准 |
|---|---|
| **S (3)** | node_aggregation 模式下 source_findings[] 含全部 7 个 sibling 的 source_skill + source_id, aggregation_status 准确, 产出 produced.n210.code_quality_static_check.completed 事件 |
| **A (2)** | 收齐 ≥5 个 sibling 的 source_findings, aggregation_status 准确 |
| **B (1)** | 仅本 skill 自己的 finding, 未做跨 skill 整合 |
| **C (0)** | 未声明 produced 事件, 或 source_findings 字段缺失 |

---

## 红线 (违反则直接归 C 或 0)

- 把 commodity formatting 检查 (缩进、空格、import 排序) 作为输出主体 -> 重复成熟 linter, R07_no_linter_duplication 直接 reject
- critical 级 violation 不带 sla_escalation_hint -> R04 reject
- 自定义规则缺 rule_lifecycle 字段 (introduced_version/tech_stack/deprecation_policy) -> R05 reject
- 多栈项目未给规则标 tech_stack[] -> 误用风险, R10 warn

---

## 等级映射示例

- **S+ (12)**: 全部 4 维满分, 输出含规则可视化清单 + node_aggregation
- **S (11)**: 3 维满分 + 1 维 A
- **A (9-10)**: 字段完整但 critical 比例略偏高, 或部分规则未引用 rule_id
- **B (6-8)**: 主要 violation 覆盖但 location/evidence 字段不全
- **C (<6)**: 仅给 "建议" 而无规则、位置、严重度依据

---

## 自评示例

```yaml
self_score:
  rule_localization: 3
  rule_evidence_depth: 3
  severity_sla_consistency: 2
  cross_skill_handoff: 3
  total: 11
  band: S
  rationale: 1 处 SLA 提示遗漏, 已在 pending[] 中列出供人工补充
```
