# Rule tier policy

Use this policy for narrative judgment; `v2-schema-catalog.md` is the enum source of truth.

## Tier definitions

| tier | owner | examples | default execution |
|---|---|---|---|
| T1_standard | language/tool baseline | Google Java Style, PEP 8, ESLint recommended, formatting, imports | Delegate to Checkstyle, PMD, Spotless, ESLint, PyLint, or equivalent tools. Do not re-litigate commodity style unless the user asks for a summary. |
| T2_organizational | organization engineering standards | structured logs, controller annotations, error-code conventions, package layering, observability tags | Evaluate with organization rules and emit `STD-ORG-*` ids. Tie findings to standards or conventions when available. |
| T3_project | project or repository-specific rules | audit annotations, transaction isolation requirements, module naming, DTO exposure rules, project-specific validation | Evaluate with project rules and emit `STD-PROJ-*` ids. Prefer explicit project references over generic style opinions. |

## Dispatch rules

1. If a mature linter already owns the check, classify it as `T1_standard` and report only summarized violations or tool gaps.
2. If the rule applies across multiple repositories or teams, classify it as `T2_organizational`.
3. If the rule is tied to the current project, module, business workflow, or compliance requirement, classify it as `T3_project`.
4. When a rule can be both T2 and T3, choose T3 if the project has a stricter or narrower version.
5. Never block on a new rule unless `rule_versioning.current_enforcement` is `enforced`.

## Rule lifecycle fields

Every custom T2/T3 rule should carry:

| field | meaning |
|---|---|
| introduced_in | version, date, or decision where the rule was introduced |
| grace_period | migration window before the rule becomes blocking |
| enforce_since | version or date when severity becomes authoritative |
| current_enforcement | `grace_period`, `enforced`, `deprecated`, or `removed` |
| replacement_rule | required when current rule is deprecated or removed |

## Declarative YAML pattern

Use this shape when authoring or explaining project-specific rules:

```yaml
rule_id: STD-PROJ-007
name: audit_annotation_required_for_write_api
scope: method
applies_when:
  annotation_present: [PostMapping, PutMapping, PatchMapping, DeleteMapping]
require:
  annotation_present: Auditable
severity: critical
introduced_in: v1.5
grace_period: 30d
enforce_since: v1.6
```

## Finding expectations

A strong finding includes `rule_tier`, `rule_id`, `rule_versioning`, `violation`, `evidence`, `suggested_fix`, `auto_fixable`, and `related_standard_check_ids` when another N210 skill consumes the standard finding.
