# N210 integration map

Node: N210 code quality static check.

Recommended node inputs:
- 工程骨架.zip
- Service草稿.zip
- 并发控制建议.md
- 技术方案分析.md

Node outputs:
- 代码规范检查单.csv
- 重构建议.md
- 命名优化建议.md
- 低质量代码清单.csv
- 重复代码清单.csv
- 风险检查清单.csv

Workflow downstream:
- N220
- N250
- N260
- N370
- N390
