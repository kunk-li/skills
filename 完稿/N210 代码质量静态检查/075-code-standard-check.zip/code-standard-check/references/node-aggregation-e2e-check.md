# Node aggregation E2E checklist

Use this checklist only in `code-standard-check` when `selected_mode: node_aggregation`, or when validating the full N210 node after all eight skills have produced artifacts.

## Required input bundle

| artifact | producing skill | required for final report |
|---|---|---|
| 代码规范检查单.csv | code-standard-check | yes |
| 重构建议.md | refactoring-recommendation | preferred |
| 命名优化建议.md | naming-optimization-recommendation | preferred |
| 低质量代码清单.csv | low-quality-code-detection | preferred |
| 重复代码清单.csv | duplicate-code-detection | preferred |
| 风险检查清单.csv | null-exception-risk-detection, transaction-boundary-check, thread-safety-risk-check | preferred |

If only `代码规范检查单.csv` is available, produce a constrained aggregation report and declare missing sections.

## Report acceptance checklist

- The report contains: category statistics, top refactoring recommendations, business/NFR gaps, duplicate-code opportunities, null/exception review, transaction review, thread-safety review, project-rule compliance, technical-debt register, and gate decision.
- Each section links back to source ids rather than paraphrasing unsupported conclusions.
- The technical-debt register uses minutes or person-days consistently.
- The gate decision explains blocker/critical findings and names the downstream owner.
- The produced event is included in a fenced YAML block and follows `produced.n210.code_quality_static_check.completed`.

## Minimal produced event example

```yaml
name: produced.n210.code_quality_static_check.completed
producer: N210
payload_schema: N210CodeQualityReport.v1
report_artifact: N210_code_quality_report.md
readiness: pass
subscribers:
  - N220_code_review
  - N250_defect_management
  - N260_quality_gate
  - N370_skill_orchestration
  - N390_quality_scoring
```
