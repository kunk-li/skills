# code-standard-check 常见失败模式 v2.4

## 通用部分（F1-F4）

### F1. 把推断包装成确定事实

**症状**：标 `severity: critical` 但 finding 没有 sla_escalation_hint，且没有引用 review-rules.md 中的具体 rule_id。仅基于"代码看上去违反某种通用规范"的直觉。

**影响**：critical 误标触发告警流程，造成虚假紧急事件。下游 `node_aggregation` 模式会把这条 finding 直接合入聚合产出，人工发现是臆造时整套报告可信度受损。

**修正**：
- 所有 violation 必须引用 `review-rules.md` 中具体 `rule_id`；没有对应规则进 `pending[]` 或降级 severity。
- `severity_matrix.md` 提供 severity 映射依据；查不到映射降级到 medium。
- R02_finding_id_stable / R05_rule_lifecycle_declared 是 reject 级红线。

---

### F2. 没有位置或范围仍给强结论

**症状**：仅写 `class: OrderService` 没有 line 行号；或仅写 `module: order` 没有具体文件。

**影响**：IDE / GitHub annotation 无法消费；人工要打开整个文件搜索；node_aggregation 时 source_id 无法精确合并。

**修正**：location.file_path + location.line_range 必填；snippet 字段（≤6 行）必填。

---

### F3. 同类问题机械穷举

**症状**：项目里 50 处方法名 snake_case，输出 50 条 STD-NAMING-001 ~ STD-NAMING-050。

**影响**：高严重度 violation 被淹没；阅读疲劳；优先级失效。

**修正**：cluster_id 把同根因 finding 合成 1 条主 finding + sample_locations[]；finding 总数超 50 截断到 top-30。

---

### F4. 只说问题不说原因或建议

**症状**：finding 只有 issue_kind 和 description，缺 evidence 和 recommendation。

**影响**：人工拿到 finding 后还要花时间判断为什么是问题、怎么改；高 finding 数时等同于让人重做分析。

**修正**：issue_kind + evidence (引用规则) + recommendation (具体动作) 三件套必填；critical/high 给 ≥2 个 fix 选项。

---

## 本 skill 重点（F5-F8）

### F5. 重复成熟 linter 已覆盖的 commodity formatting

**症状**：输出主体是缩进、空格、import 排序、未用变量、final 字段等已被 SonarQube/PMD/ESLint/SpotBugs 覆盖的格式类问题。

**影响**：浪费上下文；产出与 linter 报告 90%+ 重叠，没有增量价值；用户会质疑"这些 IDE 已经标了，为什么还需要 LLM 跑一遍"。

**修正**：
- R07_no_linter_duplication 规则强制：tech_stack 已有成熟 linter 时，commodity formatting 类规则一律抑制。
- 输出聚焦在 review-rules.md 中的团队特定规则、跨 linter 边界的语义规则、业务关联约束。
- 对 commodity 类 finding 单独输出一段 "deferred_to_linters" 计数，但不展开内容。

---

### F6. 缺少 fallback，输入不足时仍下强结论

**症状**：项目无 review-rules.md 但仍按某个"业界规范"硬性判断 violation；或 stack 未识别但仍给出语言特定规则建议。

**影响**：误用风险；用户的实际规范可能与你的假设相反，强结论变错误结论。

**修正**：
- review-rules.md 缺失 → 进 `pending[]`，仅给 commodity 类 finding 并标 `evidence_profile: heuristic_only`。
- stack 未识别 → readiness 降为 constrained，仅做语言无关的检查（命名一致性、大小写）。
- 在 SKILL.md 的 Inputs 段明确声明最小输入边界。

---

### F7. 把 review-rules 当死规则，不承认团队差异

**症状**：项目 review-rules.md 中明确说"允许 lombok @Data"，但仍输出 `STD-002 不应使用 @Data` 类 violation。或 review-rules 标 `severity: low` 但本 skill 输出 `severity: critical`。

**影响**：违反"用户已有规范优先"原则；造成 finding 数虚高 + 优先级混乱。

**修正**：
- review-rules.md 中的 status: deprecated / approved 必须被尊重。
- severity 映射时，review-rules.md 中显式指定的 severity 优先于 severity-matrix.md 的默认映射。
- 检测到与 review-rules 冲突时，先标 `conflicts_with_review_rule: <rule_id>`，让人工裁决。

---

### F8. node_aggregation 模式漏收 sibling

**症状**：`selected_mode: node_aggregation` 但 `source_findings[]` 仅含 3-4 个 sibling 的 finding，未声明缺失（应有 7 个 N210 sibling）。

**影响**：聚合产出不完整但 readiness 标 pass；下游 N220 / N300 误以为已收齐全部 N210 输出。

**修正**：
- R08_aggregation_complete 规则：必须显式列出所有 7 个 sibling；缺失的标 `aggregation_status: partial` + `missing_contributors: [...]`。
- produced.n210.code_quality_static_check.completed 事件 contributors_received vs contributors_expected 字段必填。
