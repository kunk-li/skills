# V2 schema catalog

This file is the enum and field source of truth. `rule-tier-policy.md` and `review-rules.md` give narrative rules.

## rule_tier values
- T1_standard
- T2_organizational
- T3_project

## severity values
- blocker
- critical
- major
- minor
- info

## rule_engine values
- custom_linter
- ast_pattern
- regex_based
- semantic_rule

## current_enforcement values
- grace_period
- enforced
- deprecated
- removed

## required fields
- `rule`: rule_id, rule_name, rule_description, severity, examples.
- `custom_rule_definition`: yaml_declaration, rule_engine.
- `rule_versioning`: introduced_in, grace_period, enforce_since, current_enforcement, deprecation_path.
- `differentiation_from_checkstyle`: what is delegated to Checkstyle/PMD and what this skill owns.
- `active_rules`: by_tier, disabled_rules.

## node aggregation mode
When selected_mode is `node_aggregation`, consume the six N210 artifacts and produce `N210_code_quality_report.md` plus `produced.n210.code_quality_static_check.completed`.
