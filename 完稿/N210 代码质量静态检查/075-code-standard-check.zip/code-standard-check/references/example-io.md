# Example IO: code-standard-check

## Scenario A: Standalone single-file review

### Input

```java
// OrderService.java (excerpt)
@Service
public class OrderService {
    public Order get_order(Long id) {  // snake_case in Java
        if (id == null) {
            throw new RuntimeException("id is null");  // generic exception
        }
        return orderRepository.findById(id).get();  // Optional.get without isPresent
    }
}
```

User prompt: "请检查这段代码是否符合规范"

### Output (artifact_contract YAML block)

```yaml
artifact_contract:
  schema_version: n210.code-standard-check.v2.4
  produced_by: code-standard-check
  selected_mode: project_specific
  readiness: constrained
  evidence_profile: code_only
  confirmed:
    - file: OrderService.java
    - line_range: [3, 9]
  inferred:
    - language: java
    - convention_set: google-java-style (assumed; no project config provided)
  pending:
    - actual project review-rules.md
    - team naming convention deviations

violations:
  - finding_id: STD-NAMING-001
    rule_id: GJS-METHOD-CASE
    severity: medium
    location:
      file: OrderService.java
      line_range: [3, 3]
    issue_kind: naming_convention_violation
    snippet: "public Order get_order(Long id)"
    evidence: "Java method names use camelCase per Google Java Style; snake_case is conventional in Python"
    recommendation: "rename to getOrder; update 6 callers (use IDE refactor)"
    tech_stack: [java]
    introduced_version: v1.0
  - finding_id: STD-EXCEPTION-002
    rule_id: TEAM-EX-001
    severity: high
    sla_escalation_hint: false
    location:
      file: OrderService.java
      line_range: [5, 5]
    issue_kind: generic_exception_thrown
    snippet: "throw new RuntimeException"
    evidence: "team standard requires domain-specific exceptions; see 错误码清单.csv"
    recommendation: "throw new OrderNotFoundException(id); register error_code ORD-404"
    related_standard_check_ids: []
```

### Self-score

```yaml
self_score:
  rule_localization: 3
  rule_evidence_depth: 2  # GJS rule cited but team rule_id placeholder
  severity_sla_consistency: 3
  cross_skill_handoff: 2  # standalone, no aggregation context
  total: 10
  band: A
```

---

## Scenario B: N210 node_aggregation mode

### Input

User prompt: "完成 N210 节点的代码规范聚合, 7 个 sibling 已运行"

Available artifacts:
- `代码规范检查单.csv` (this skill's prior run)
- `重复代码清单.csv` (from duplicate-code-detection)
- `命名优化建议.md` (from naming-optimization-recommendation)
- `重构建议.md` (from refactoring-recommendation)
- `风险检查清单.csv` (npe./tsr./txn. rows from 3 risk skills)
- `质量改进清单.csv` (from low-quality-code-detection)

### Output

```yaml
artifact_contract:
  schema_version: n210.code-standard-check.v2.4
  produced_by: code-standard-check
  selected_mode: node_aggregation
  readiness: pass
  evidence_profile: full_workflow_context
  aggregation_status: complete

source_findings:
  - source_skill: duplicate-code-detection
    source_artifact: 重复代码清单.csv
    source_id_range: [DUP-001, DUP-047]
    reason_used: cross-reference for naming conflicts in duplicated blocks
  - source_skill: naming-optimization-recommendation
    source_artifact: 命名优化建议.md
    source_id_range: [NAME-001, NAME-023]
    reason_used: confirm rename suggestions don't violate review-rules.md
  - source_skill: null-exception-risk-detection
    source_artifact: 风险检查清单.csv
    source_id_range: [npe.0001, npe.0042]
    reason_used: npe risks are auto-promoted to high-severity standard violations

produced_event:
  name: produced.n210.code_quality_static_check.completed
  contributors_received: 7
  contributors_expected: 7
  total_findings: 142
  by_severity: {critical: 3, high: 28, medium: 67, low: 35, info: 9}
```

### Self-score

```yaml
self_score:
  rule_localization: 3
  rule_evidence_depth: 3
  severity_sla_consistency: 3
  cross_skill_handoff: 3
  total: 12
  band: S+
```

---

## Scenario C: Migration mode (legacy code)

### Input

User: "我们要从 Spring Boot 1.5 迁移到 Spring Boot 3, 帮我标出会受影响的规范违规"

### Output

Reactive only on rules with `tech_stack: [spring_boot_3+]`. Older rules pending until project upgrade. selected_mode = `migration_mode`, readiness = `constrained` (full migration evidence not yet available).

---

## Common readiness states

| readiness | when |
|---|---|
| `pass` | full project context + review-rules.md available |
| `constrained` | code provided but no review-rules.md |
| `blocked` | only project description, no code |
| `provisional` | partial code (e.g. interface only) |
