# Output template: workflow-aligned code standard checklist

Artifact target: code standard checklist / 代码规范检查单.csv

Required sections:
1. metadata
2. rule_tier_summary
3. violations[]
4. custom_rule_hits[]
5. violation_stats
6. active_rules
7. node_aggregation_report when selected_mode is node_aggregation
8. self_check

Violation fields:
| check_id | severity | confidence | rule_tier | rule_id | rule_engine | current_enforcement | location | evidence | recommendation | linked_rules | linked_nfr | source_skill |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

Allowed `rule_tier` values: T1_standard, T2_organizational, T3_project.
Allowed `rule_engine` values: custom_linter, ast_pattern, regex_based, semantic_rule.
Allowed `current_enforcement` values: grace_period, enforced, deprecated, removed.

Custom rule fields: yaml_declaration, rule_name, rule_description, introduced_in, grace_period, enforce_since, deprecation_path, replacement_rule.

Node aggregation fields: source_artifacts[], category_summary, top_refactoring_recommendations, business_rule_implementation, transaction_review, thread_safety_review, project_rule_compliance, technical_debt_register, gate_recommendation, produced_event.

Cross-skill fields: all rows should include `confidence`, `related_standard_check_ids`, and `source_skill` when applicable.
