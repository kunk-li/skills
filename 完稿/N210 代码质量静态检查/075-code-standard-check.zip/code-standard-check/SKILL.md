---
name: code-standard-check
description: Code standard review — analyze code, diffs, repositories, or workflow artifacts for organization and project code-standard violations. use for standalone rule review, migration impact checks, or code-quality static checks that need a workflow-aligned code-standard checklist while delegating commodity formatting to mature linters.
---
# code-standard-check

## Role / role positioning
检查组织/项目代码规范，作为 N210 基线规则输出. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `代码规范检查单.csv`.

## Boundary / 边界
- 负责检查组织/项目代码规范违规、命名、分层、安全与异常处理规范。
- 在 N210 `node_aggregation` 模式下，作为唯一事件发布者，聚合所有子技能发现。
- 不负责 Checkstyle/ESLint 已覆盖的格式类规则；这些规则委托给 linter（`tool_collaboration_mode: delegate`）。
- 不替代 SonarQube 的重复代码或复杂度度量；专注业务语义规则。

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- project_specific
- migration_mode
- violation_stats
- node_aggregation


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 项目代码 + review-rules.md + tech_stack 全部齐备 | 完整 violation list + rule_id 引用 + severity 五档 |
| `provisional` | 代码齐备但 review-rules.md 缺失 | 输出 commodity 类 finding + heuristic 标注，team 规则进 pending |
| `constrained` | 仅有部分代码（如 diff），无完整 context | 仅输出 diff 范围内 violation，缺跨文件分析 |
| `blocked` | 仅有项目描述，无代码 | 输出 `request_for_inputs[]` |

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- coding conventions from N190
- organization standards
- project-specific rules
- existing linter configs and reports
- 代码规范检查单.csv
- 重构建议.md
- 命名优化建议.md
- 低质量代码清单.csv
- 重复代码清单.csv
- 风险检查清单.csv

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.code_standard_check`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 代码规范检查单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- rule_tier_summary
- violations[]
- custom_rule_hits[]
- violation_stats
- node_aggregation
- active_rules
- node_aggregation_report when `selected_mode: node_aggregation`
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.


## Multi-stack rule management

This skill defaults to Java (Spring) coding standards but supports multi-stack projects. When context indicates a non-Java stack:

| Stack | Standard source | Key rule categories |
|---|---|---|
| Java | Google Java Style / Alibaba Java Coding Guidelines | Naming, exception, concurrency, Javadoc |
| TypeScript | ESLint recommended + Airbnb / project .eslintrc | any type, strict null, import order |
| Python | PEP8 + project pylint/ruff config | Naming (snake_case), type hints, docstring |
| Go | `gofmt` + `golangci-lint` | Error wrapping, goroutine leak, interface naming |
| Kotlin | Kotlin Coding Conventions | `data class` vs POJO, coroutine scope, null-safety |

### Rule lifecycle management
Custom rules must declare:
- `rule_id`: stable identifier (e.g. `PROJ-STD-001`)
- `introduced_version`: sprint or release when rule was added
- `deprecation_policy`: how long deprecated rules are enforced before removal
- `tech_stack`: which stacks the rule applies to

When a rule is deprecated, it must remain in the catalog with `status: deprecated` for at least one release cycle before removal.

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. If `selected_mode: node_aggregation`, produce `N210_code_quality_report.md` and `produced.n210.code_quality_static_check.completed`; otherwise hand off to N220, N260, N370, N390, or refactoring as appropriate.
6. For `node_aggregation`, validate the report and event with `references/node-aggregation-e2e-check.md` before finalizing.

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.

## Tech stack adapter / 技术栈适配

本 skill 支持多语言项目的代码规范检查。按技术栈切换适用规则集：

| 栈 | 规范来源 | 重点检查类别 |
|---|---|---|
| Java | Google Java Style / Alibaba Java Coding Guidelines | 命名、异常、并发、Javadoc |
| TypeScript | ESLint recommended + Airbnb / project .eslintrc | `any` 类型、strict null、import 顺序 |
| Python | PEP8 + project pylint/ruff config | snake_case 命名、类型注解、docstring |
| Go | `gofmt` + `golangci-lint` | error 包装、goroutine 泄漏、接口命名 |
| Kotlin | Kotlin Coding Conventions | data class 使用、协程作用域、null-safety |

当栈未声明时：从文件扩展名推断；推断结果记入 `inferred[]`。多栈项目中每条规则必须声明 `tech_stack[]` 适用范围（R10 规则）。

## Machine-readable self_check rules

- `R01_mode_declared`: `selected_mode` 必须是 `project_specific | migration_mode | violation_stats | node_aggregation` 之一; `on_violation: reject`
- `R02_finding_id_stable`: 每条 violation 必须有格式为 `STD-{CATEGORY}-{NNN}` 的稳定 `rule_id`; `on_violation: reject`
- `R03_severity_set`: `severity` 必须是 `critical | high | medium | low | info` 之一; `on_violation: reject`
- `R04_sla_hint_critical`: `severity: critical` 必须附 `sla_escalation_hint: true`; `on_violation: reject`
- `R05_rule_lifecycle_declared`: 自定义规则必须有 `rule_id`、`introduced_version`、`tech_stack`、`deprecation_policy`; `on_violation: reject`
- `R06_deprecated_status_retained`: deprecated 规则必须保留 `status: deprecated` 至少一个 release 周期; `on_violation: warn`
- `R07_no_linter_duplication`: 已有成熟 linter 覆盖的格式类规则（缩进、空格、import 排序）不得重复输出; `on_violation: warn`
- `R08_aggregation_complete`: `node_aggregation` 模式必须从全部 N210 子技能收集 `source_findings[]`；缺失子技能时标 `aggregation_status: partial`; `on_violation: reject`
- `R09_produced_event_on_aggregation`: `node_aggregation` 模式完成后必须声明 `produced.n210.code_quality_static_check.completed` 事件; `on_violation: reject`
- `R10_tech_stack_per_rule`: 多栈项目中每条规则必须声明适用的 `tech_stack[]`; `on_violation: warn`

## Common failure modes

1. **Linter 重复输出** — 对已有 ESLint/Checkstyle 覆盖的格式规则（缩进、import 排序）再次逐一列出，信噪比下降。修复：加载已有 linter 配置，对格式类规则应用 `tool_collaboration_mode: delegate`，只输出 linter 无法检测的业务语义规则。
2. **deprecated 规则仍触发 reject** — 规则已标 `status: deprecated` 但仍在 `violation_stats` 中以 `on_violation: reject` 执行，造成误阻断。修复：`deprecated` 状态规则只能 `on_violation: warn`，保留期满后才可移除。
3. **node_aggregation 遗漏子技能** — 聚合时只合并了部分 N210 子技能的 `source_findings[]`，漏掉 `thread-safety-risk-check` 或 `transaction-boundary-check` 的发现，导致 N210 报告不完整。修复：aggregation 步骤必须枚举所有期望子技能并逐一校验是否已收到输出；缺失时标 `aggregation_status: partial`，不得静默通过。

## N210 内部 skill 协同规则

`code-standard-check` 在 `node_aggregation` 模式下作为 N210 唯一事件发布者，必须遵守以下协同约束：

| 子技能 | 产物字段 | 聚合时必须校验 |
|---|---|---|
| `duplicate-code-detection` | `duplication_clusters[].finding_id` | finding_id 格式合规 |
| `low-quality-code-detection` | `issue_catalog[].finding_id` | severity 枚举合规 |
| `naming-optimization-recommendation` | `naming_issues[].finding_id` | related_standard_check_ids 存在 |
| `null-exception-risk-detection` | `risk_catalog[].finding_id` | sla_escalation_hint 对 critical 已设 |
| `refactoring-recommendation` | `refactoring_candidates[].refactor_id` | roi_analysis 存在 |
| `thread-safety-risk-check` | `thread_safety_risks[].finding_id` | severity 枚举合规 |
| `transaction-boundary-check` | `transaction_issue_catalog[].finding_id` | severity 枚举合规 |

收到任一子技能输出时，必须在 `node_aggregation_report` 中记录该子技能的 `readiness` 和 `finding_count`。

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Reference files / reference files
- `references/standard-check-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/standard-check-self-check.yaml`: R01-R10 机读门禁规则
- `references/standard-check-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/rule-tier-policy.md`
- `references/review-rules.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/node-aggregation-e2e-check.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
