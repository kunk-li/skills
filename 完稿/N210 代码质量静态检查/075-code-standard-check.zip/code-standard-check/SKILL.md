---
name: code-standard-check
description: analyze code, diffs, repositories, or workflow artifacts for organization and project code-standard violations. use for standalone rule review, migration impact checks, or n210 code-quality static checks that need a workflow-aligned code-standard checklist while delegating commodity formatting to mature linters.
---
# code-standard-check

## Role / role positioning
检查组织/项目代码规范，作为 N210 基线规则输出. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `代码规范检查单.csv`.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- project_specific
- migration_mode
- violation_stats
- node_aggregation

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- coding conventions from N190
- organization standards
- project-specific rules
- existing linter configs and reports
- 代码规范检查单.csv
- 重构建议.md
- 命名优化建议.md
- 低质量代码清单.csv
- 重复代码清单.csv
- 风险检查清单.csv

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.code_standard_check`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 代码规范检查单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- rule_tier_summary
- violations[]
- custom_rule_hits[]
- violation_stats
- node_aggregation
- active_rules
- node_aggregation_report when `selected_mode: node_aggregation`
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. If `selected_mode: node_aggregation`, produce `N210_code_quality_report.md` and `produced.n210.code_quality_static_check.completed`; otherwise hand off to N220, N260, N370, N390, or refactoring as appropriate.
6. For `node_aggregation`, validate the report and event with `references/node-aggregation-e2e-check.md` before finalizing.

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.

## Reference files / reference files
- `references/rule-tier-policy.md`
- `references/review-rules.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/node-aggregation-e2e-check.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
