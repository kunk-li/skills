# Output template: workflow-aligned refactoring report

Required sections:
1. metadata
2. refactoring_summary
3. refactoring_candidates[]
4. source_findings[]
5. before_after_previews[]
6. refactoring_impact[]
7. roi_analysis
8. implementation_sequence[]
9. downstream_handoff
10. self_check

Candidate fields:
| refactoring_id | severity | confidence | refactoring_pattern | location | evidence | business_value | files_affected | callers_affected | tests_affected | estimated_effort_hours | risk | recommendation | related_standard_check_ids | source_findings |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Allowed `refactoring_pattern` values: RF01_extract_method, RF02_inline_method, RF03_extract_variable, RF04_inline_variable, RF05_move_method, RF06_move_field, RF07_extract_class, RF08_inline_class, RF09_hide_delegate, RF10_introduce_parameter_object, RF11_replace_magic_number, RF12_replace_conditional_with_polymorphism, RF13_replace_type_code_with_subclasses.

`source_findings[]` item fields: source_skill, source_id, source_artifact, reason_used.

Impact fields: current_cyclomatic, after_cyclomatic, reduction_pct, readability_current_score, readability_after_score, maintainability_current_mi, maintainability_after_mi, testability_before, testability_after, performance_impact.

ROI fields: effort_pd, reduced_future_bug_risk, enable_feature_faster, reduced_onboarding_time, enable_unit_testing, introducing_bug_risk, regression_scope, recommendation, priority.

Cross-skill fields: all rows should include `confidence`, `related_standard_check_ids`, and `source_skill` when applicable.
