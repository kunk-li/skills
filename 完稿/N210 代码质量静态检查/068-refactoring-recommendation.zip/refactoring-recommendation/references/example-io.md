# Example IO: refactoring-recommendation

## Scenario A: Standalone refactoring scan integrating multiple findings

### Input

```java
// OrderService.java -- excerpt
public BigDecimal calculatePrice(Order order) {
    BigDecimal price = order.getBasePrice();
    if (order.getCustomer().getLevel().equals("VIP")) {
        price = price.multiply(new BigDecimal("0.8"));
    } else if (order.getCustomer().getLevel().equals("GOLD")) {
        price = price.multiply(new BigDecimal("0.85"));
    } else if (order.getCustomer().getLevel().equals("SILVER")) {
        price = price.multiply(new BigDecimal("0.9"));
    }
    if (order.getQuantity() > 100) {
        price = price.multiply(new BigDecimal("0.95"));
    }
    if (order.getCoupon() != null && order.getCoupon().isValid()) {
        price = price.subtract(order.getCoupon().getDiscount());
    }
    return price;
}

public BigDecimal calculateRefund(Order order) {
    // similar conditional structure for refund
}
```

User context: `重复代码清单.csv` (DUP-014: similar conditional in calculateRefund), `质量改进清单.csv` (LQ-021: violates Open/Closed Principle).

### Output

```yaml
artifact_contract:
  schema_version: n210.refactoring-recommendation.v2.4
  produced_by: refactoring-recommendation
  selected_mode: integrator_mode
  readiness: pass
  evidence_profile: full_workflow_context

source_findings:
  - source_skill: duplicate-code-detection
    source_id: DUP-014
    source_artifact: 重复代码清单.csv
    reason_used: identifies parallel structure between calculatePrice and calculateRefund
  - source_skill: low-quality-code-detection
    source_id: LQ-021
    source_artifact: 质量改进清单.csv
    reason_used: confirms OCP violation; informs polymorphism-based fix

recommendations:
  - finding_id: REF-001
    pattern_name: "Replace Conditional with Polymorphism"
    pattern_source: "Fowler, Refactoring 2e, p.272"
    severity: high
    location: {file: OrderService.java, line_range: [3, 9]}
    consumes: [DUP-014, LQ-021]
    
    before:
      code: |
        if (order.getCustomer().getLevel().equals("VIP")) { price = price.multiply(0.8); }
        else if (...) { ... }
      smells: ["long-if-chain", "magic-numbers", "OCP-violation"]
    
    after:
      code: |
        // CustomerLevel enum holds discount strategy
        public enum CustomerLevel {
            VIP(new BigDecimal("0.8")),
            GOLD(new BigDecimal("0.85")),
            SILVER(new BigDecimal("0.9")),
            STANDARD(BigDecimal.ONE);
            private final BigDecimal discountFactor;
            // ...
            public BigDecimal applyDiscount(BigDecimal price) { return price.multiply(discountFactor); }
        }
        // service:
        price = order.getCustomer().getLevel().applyDiscount(price);
    
    estimate:
      effort_hours: 4
      benefit_score: 5
      impacted_files_count: 6   # OrderService, RefundService, Customer enum, 3 tests
      breaking_change: false    # internal refactor
      
    prerequisites: []  # no upstream refactor needed
    
    migration_steps:
      - step: 1
        action: "Add CustomerLevel enum with discountFactor field and applyDiscount method"
        test_strategy: "unit test for each level; assert price.multiply(factor) matches old branch"
        rollback_hint: "if test fails, enum is independent; remove without affecting current code"
      - step: 2
        action: "Update Customer.getLevel() to return CustomerLevel enum (was String)"
        test_strategy: "migration test for existing serialized data"
        rollback_hint: "keep getLevelString() during transition"
      - step: 3
        action: "Replace if-chain in OrderService.calculatePrice with enum.applyDiscount"
        test_strategy: "regression: same test inputs, same outputs"
        rollback_hint: "git revert single commit"
      - step: 4
        action: "Apply same refactor to OrderService.calculateRefund (consumes DUP-014)"
        test_strategy: "shared discount logic now identical"
        rollback_hint: "n/a"
      - step: 5
        action: "Remove Customer.getLevelString(); update all callers"
        test_strategy: "compile + integration test"
        rollback_hint: "deprecation cycle: keep one release"
    
    deprecation_window: "2 release cycles for Customer.getLevelString()"
    
  - finding_id: REF-002
    pattern_name: "Extract Method"
    pattern_source: "Fowler, Refactoring 2e, p.106"
    severity: medium
    location: {file: OrderService.java, line_range: [11, 14]}
    
    before:
      code: |
        if (order.getQuantity() > 100) { price = price.multiply(0.95); }
        if (order.getCoupon() != null && ...) { price = price.subtract(...); }
      smell: "mixed concerns (volume discount + coupon)"
    
    after:
      code: |
        price = applyVolumeDiscount(price, order.getQuantity());
        price = applyCoupon(price, order.getCoupon());
    
    estimate: {effort_hours: 1, benefit_score: 3, impacted_files_count: 1}
    prerequisites: [REF-001]   # do polymorphism first to maintain consistent style
    migration_steps:
      - step: 1
        action: "Extract applyVolumeDiscount(price, qty) -> BigDecimal"
        test_strategy: "test for boundaries: qty=99, 100, 101"
      - step: 2
        action: "Extract applyCoupon(price, coupon) -> BigDecimal; null-safe"
        test_strategy: "test null coupon and invalid coupon"

prioritization:
  ordered_by: [benefit/effort ratio, prerequisite chain]
  execution_order: [REF-001, REF-002]
```

### Self-score

```yaml
self_score:
  fowler_pattern_accuracy: 3   # Replace Conditional with Polymorphism + Extract Method, with Fowler citations
  priority_roi_estimation: 3   # effort + benefit + impacted_files + breaking_change all present
  upstream_integration: 3      # consumes DUP-014 and LQ-021 explicitly
  migration_completeness: 3    # 5-step migration with test_strategy + rollback_hint each
  total: 12
  band: S+
```

---

## Scenario B: Standalone mode (no upstream findings)

When no sibling artifacts available, this skill discovers refactor opportunities directly from code. `selected_mode: standalone_scan`, `source_findings: []`.

---

## Common readiness states

| readiness | when |
|---|---|
| `pass` | full code + sibling N210 outputs |
| `constrained` | code only, no sibling findings |
| `blocked` | only descriptions |
