# refactoring-recommendation 评分标准 v2.4

## 总览

输出按 4 个维度评分，每维 0-3 分，总分 0-12。

| 总分 | 等级 | 含义 |
|---|---|---|
| 11-12 | **S** | 可直接消费 |
| 9-10 | **A** | 生产可用 |
| 6-8 | **B** | 需人工修订 |
| ≤5 | **C** | 不建议消费 |

---

## 维度 1: Fowler 模式准确度 (fowler_pattern_accuracy)

衡量: 是否准确应用经典重构模式 (而非泛指"抽取共用").

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% recommendation 引用具体 Fowler/Kerievsky 模式名 (e.g. Extract Method, Replace Conditional with Polymorphism, Introduce Parameter Object, Move Method, Inline Class), 含 before/after 代码片段 |
| **A (2)** | ≥80% 引用具体模式, 余下泛指 "抽取/合并" |
| **B (1)** | 仅给重构方向, 未引用模式名 |
| **C (0)** | 把 "改名" "调整顺序" 当重构, 无结构变更 |

---

## 维度 2: 优先级与 ROI 估算 (priority_roi_estimation)

衡量: 是否含 ROI 估算 (改动量 vs 收益) + prerequisite 链.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% 含 estimated_effort_hours + benefit_score (1-5) + impacted_files_count + dependency_chain[] (前置重构), 排序合理 (高 ROI 优先) |
| **A (2)** | 含 effort + benefit, 但 dependency_chain 不全 |
| **B (1)** | 仅给优先级标签 (high/medium/low), 无量化 |
| **C (0)** | 全部 high 优先级, 无 ROI 估算 |

---

## 维度 3: 整合上游 finding (upstream_integration)

衡量: 是否消费 N210 sibling 的 finding 作为输入.

| 等级 | 标准 |
|---|---|
| **S (3)** | source_findings[] 显式列出消费的 sibling finding (含 source_skill + source_id + reason_used), 100% recommendation 关联 ≥1 个 source_finding, 不重复 sibling 已给的建议 |
| **A (2)** | 关联 ≥1 个 sibling, 偶有重复 |
| **B (1)** | 未关联 sibling, 独立产出 |
| **C (0)** | 与 sibling 输出 90%+ 重叠 |

---

## 维度 4: 迁移路径完整度 (migration_completeness)

衡量: 重构步骤是否含分阶段迁移路径 + 测试与回滚.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% recommendation 含 migration_steps[] (3-7 步), 每步含 test_strategy (单元/集成) + rollback_hint, 含 deprecation_window (兼容期) |
| **A (2)** | ≥70% 含 steps + test_strategy, 余下仅给步骤 |
| **B (1)** | 仅给 steps, 无测试策略 |
| **C (0)** | 仅给最终结构, 无迁移路径 |

---

## 红线 (违反则直接归 C 或 0)

- 推荐重构会破坏 API 契约但未标 breaking_change_warning -> 严重错误
- effort_hours 估算明显失实 (如把跨 50 文件的重构标 2h) -> 误导
- 重构推荐数 > 30 -> 用户无法消费, 应分批输出
- 与 source_findings 100% 重复 -> 角色失败

---

## 等级映射示例

- **S+ (12)**: 全部含 Fowler 模式 + ROI + 上游整合 + 迁移路径
- **S (11)**: 3 维满分 + 1 维 A
- **A (9-10)**: 模式准确, ROI 完整但迁移路径粗略
- **B (6-8)**: 模式泛化, 未含 ROI 量化
- **C (<6)**: 仅给重构方向, 无 prerequisite / ROI / migration

---

## 自评示例

```yaml
self_score:
  fowler_pattern_accuracy: 3
  priority_roi_estimation: 3
  upstream_integration: 3
  migration_completeness: 2
  total: 11
  band: S
  rationale: 2 条 recommendation migration_steps 未含 rollback_hint
```
