# V2 schema catalog

This file is the enum and field source of truth. `refactoring-pattern-catalog.md` gives narrative examples.

## refactoring_pattern values
- RF01_extract_method
- RF02_inline_method
- RF03_extract_variable
- RF04_inline_variable
- RF05_move_method
- RF06_move_field
- RF07_extract_class
- RF08_inline_class
- RF09_hide_delegate
- RF10_introduce_parameter_object
- RF11_replace_magic_number
- RF12_replace_conditional_with_polymorphism
- RF13_replace_type_code_with_subclasses

## required fields
- `source_findings[]`: source_skill, source_id, source_artifact, reason_used.
- `before_after`: before_code, after_code, problems[], improvements[].
- `refactoring_impact`: current_cyclomatic, after_cyclomatic, reduction_pct, readability/current/after, maintainability/current/after, performance_impact.
- `roi_analysis`: effort_pd, business_value, regression_scope, recommendation, priority.
- `prerequisites[]`: required, justification.

## recommendation values
- highly_recommended
- recommended
- optional
- not_now
