# refactoring-recommendation 常见失败模式 v2.4

## 通用部分（F1-F4）

### F1. 把推断包装成确定事实

**症状**：推荐 Extract Method 但 effort_hours: 1 而实际涉及 30 个 caller 的 4 小时改动

**影响**：用户基于估时排期；实施时严重超时；信任损失

**修正**：effort_hours 必须基于 impacted_files_count + breaking_change + test 工作量综合估算

---

### F2. 没有位置或范围仍给强结论

**症状**：推荐改进但 location 仅给 "OrderService"，没具体方法/行号

**影响**：人工要打开整个 service 找重构对象；diff 难以预览

**修正**：location 三件套 + before/after 代码片段必填

---

### F3. 同类问题机械穷举

**症状**：对每个长方法都推荐 Extract Method，输出 50 条 REF-* finding

**影响**：用户消费疲劳；高 ROI 重构（如 Polymorphism）被低 ROI（小重构）淹没

**修正**：按 ROI (benefit/effort) 排序；总数 > 30 时仅输出 top 15 + 总览

---

### F4. 只说问题不说原因或建议

**症状**：推荐 "重构这块代码" 但没说 pattern、没 before/after

**影响**：用户不知道怎么重构；产出无增量价值

**修正**：pattern_name (Fowler 命名) + before/after code + migration_steps 必填

---

## 本 skill 重点（F5-F8）

### F5. 复制整文件代码而不是给 before/after 片段

**症状**：before / after 字段把整个 200 行的类全部贴出；diff 不清晰。

**影响**：上下文浪费；用户找不到关键改动点；token 成本高。

**修正**：
- before / after 仅展示关键差异片段（≤ 20 行）。
- 长重构用 migration_steps 分步骤展示，每步 ≤ 10 行 diff。
- 引用 Fowler refactoring 模式名，让有经验的开发者快速理解。

---

### F6. 没有估时、风险或验收标准

**症状**：推荐含 pattern 和 before/after，但 effort_hours / breaking_change / test_strategy / rollback_hint 全部缺失。

**影响**：用户无法排期；无法决策；实施后无法验证。

**修正**：
- effort_hours、benefit_score (1-5)、impacted_files_count、breaking_change 必填。
- migration_steps[] 中每步含 test_strategy + rollback_hint。
- 大于 8 小时的重构必须分解到 ≤ 5 步骤，每步 ≤ 2 小时。

---

### F7. 把命名问题和结构重构混成一类

**症状**：本 skill 推荐既包含 "Rename Method" 也包含 "Extract Class"；前者属于 naming-optimization-recommendation 的范畴。

**影响**：与 sibling 重叠；用户拿到两份相似建议；角色不清。

**修正**：
- rename_only 类型的重构（不改结构）一律不输出，转给 naming-optimization-recommendation。
- 本 skill 仅输出涉及结构变更的重构 (Extract Class/Method、Move、Pull Up/Down、Replace Conditional with Polymorphism、Introduce Parameter Object)。
- 检测到 source_findings 中已有 NAME-* 时，跳过相同 location 的 rename。

---

### F8. 推荐重构破坏 API 契约但未标 breaking_change

**症状**：推荐把 `public List<Order> getOrders(Long uid, String status)` 改为 `getOrders(Long uid, OrderStatus status)`，但 status 是 REST API 参数，breaking_change 未标。

**影响**：上线后客户端 400 Bad Request；事故。

**修正**：
- 修改 public/protected 方法签名时 breaking_change: true。
- 修改 REST endpoint / 序列化字段 / RPC 接口时 breaking_change: true。
- 提供 deprecation_path：旧签名保留 N 个 release，标 @Deprecated。

