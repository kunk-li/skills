# Refactoring pattern catalog

Use the v2 RF identifiers exactly. This file gives narrative guidance; `v2-schema-catalog.md` is the enum source of truth.

| pattern | meaning | main indicators | difficulty |
|---|---|---|---|
| RF01_extract_method | Extract Method | long method, duplicated block, mixed responsibilities | low |
| RF02_inline_method | Inline Method | trivial wrapper called once, indirection without value | low |
| RF03_extract_variable | Extract Variable | complex expression, repeated condition, unclear calculation | low |
| RF04_inline_variable | Inline Variable | temporary name hides rather than clarifies | low |
| RF05_move_method | Move Method | method uses another class more than its own class | medium |
| RF06_move_field | Move Field | field is owned/used more naturally by another class | medium |
| RF07_extract_class | Extract Class | large class, mixed domains, low cohesion | medium |
| RF08_inline_class | Inline Class | tiny class with no independent responsibility | medium |
| RF09_hide_delegate | Hide Delegate | client reaches through object graph to internals | medium |
| RF10_introduce_parameter_object | Introduce Parameter Object | long parameter list, recurring data clumps | low |
| RF11_replace_magic_number | Replace Magic Number | hard-coded numeric or string constants | low |
| RF12_replace_conditional_with_polymorphism | Replace Conditional With Polymorphism | switch/if chain by type or behavior | high |
| RF13_replace_type_code_with_subclasses | Replace Type Code With Subclasses | type field controls behavior | high |

For every recommendation, include `source_findings[]`, before/after preview, impact estimate, prerequisites, and ROI.
