---
name: refactoring-recommendation
description: analyze code, diffs, files, repositories, or other n210 findings for refactoring opportunities with fowler-style patterns, before-after examples, impact estimates, roi, prerequisites, and migration steps. use standalone for refactoring review or as a downstream integrator that prioritizes quality findings.
---
# refactoring-recommendation

## Role / role positioning
把代码异味和上游 finding 转成 Fowler 模式重构建议. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `重构建议.md`.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- quick_scan
- pattern_specific
- what_if

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- 代码规范检查单.csv
- 低质量代码清单.csv
- 重复代码清单.csv
- 风险检查清单.csv
- 命名优化建议.md
- architecture decisions from N140/N170
- historical CR findings from N220

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.refactoring_recommendation`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 重构建议.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- refactoring_summary
- refactoring_candidates[]
- source_findings[]
- before_after_previews[]
- refactoring_impact[]
- roi_analysis
- implementation_sequence[]
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.

## Reference files / reference files
- `references/refactoring-pattern-catalog.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
