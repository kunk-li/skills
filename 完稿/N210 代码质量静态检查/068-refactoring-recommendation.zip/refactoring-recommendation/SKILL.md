---
name: refactoring-recommendation
description: refactoring recommendation — analyze code, diffs, files, repositories, or code-quality findings for refactoring opportunities using Fowler-style patterns. use when asked to improve code maintainability, reduce complexity (Extract Method, Extract Class), eliminate duplication (Pull Up Method), remove code smells (Feature Envy, God Class, Primitive Obsession), or prioritize tech debt by ROI. provides before/after examples, impact estimates, ROI matrix, prerequisites check, and safe migration steps. standalone or downstream integrator of N210 quality findings.
---
# refactoring-recommendation

## Role / role positioning
把代码异味和上游 finding 转成 Fowler 模式重构建议. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `重构建议.md`.

## 使用场景 / When to use

**直接触发（standalone）：**
- 粘贴代码，要求识别代码异味并给出重构建议
- 提到"这段代码很难维护"、"方法太长"、"太多职责"
- 要求给出 before/after 示例和重构步骤

**工作流触发（N210 节点下游）：**
- 接收 `duplicate-code-detection` / `low-quality-code-detection` 输出后，整合优先级与 ROI
- 技术债务清单整理阶段

**不触发（边界外）：**
- 代码规范检查 → 使用 `code-standard-check`
- 重构执行（实际写代码）→ 由开发者或 `code-scaffold-generation` 处理

## Boundary / 边界
- 负责识别重构机会，提供 Fowler 模式映射、before/after 示例、ROI 分析和迁移步骤。
- 可作为下游整合器，优先处理其他 N210 子技能的发现。
- 不执行重构；仅提供建议和步骤。
- 不负责测试覆盖率；测试前置条件由输出中的 `prerequisite_tests_needed` 标记说明。

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- quick_scan
- pattern_specific
- what_if


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 代码 + sibling N210 finding + ROI 估算依据 全部齐备 | 完整 Fowler pattern + before/after + migration_steps + 关联 source_findings |
| `provisional` | 代码齐备但 sibling 输出未到位 | 独立产出，source_findings 标 standalone |
| `constrained` | 仅有部分代码，无 caller 分析 | 仅输出本文件 refactor，跨文件进 pending |
| `blocked` | 仅有项目描述，无代码 | 输出 `request_for_inputs[]` |

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- 代码规范检查单.csv — baseline violations from `code-standard-check`
- 低质量代码清单.csv — quality signals from `low-quality-code-detection`
- 重复代码清单.csv — duplication clusters from `duplicate-code-detection`
- 风险检查清单.csv — risk findings from null/transaction/thread-safety checks
- 命名优化建议.md — naming issues from `naming-optimization-recommendation`
- `模块边界图.md` / `技术方案分析.md` from N140/N170 — architectural direction constrains refactoring scope
- historical CR findings from N220 (optional, available only in iterative cycles — **N220 is downstream of N210 in the primary flow; this input only applies when refactoring is triggered by a review cycle, not during the initial N210 pass**)

### test coverage prerequisite check

Before recommending a non-trivial refactoring (renaming a class, extracting a method, restructuring a module), emit a `test_coverage_prerequisite` block:

```yaml
test_coverage_prerequisite:
  target_code: "OrderService.processPayment()"
  coverage_status: unknown | covered | insufficient | uncovered
  coverage_source: "N240 test results / jacoco report / not available"
  refactoring_safety:
    level: safe | moderate_risk | high_risk
    reason: "No integration tests covering this path; refactoring may break silently"
  recommendation: "Add test coverage before applying Extract Method refactoring"
```

If coverage data is unavailable, set `coverage_status: unknown` and downgrade refactoring confidence to `provisional`.

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.refactoring_recommendation`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 重构建议.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- refactoring_summary
- refactoring_candidates[]
- source_findings[]
- before_after_previews[]
- refactoring_impact[]
- roi_analysis
- implementation_sequence[]
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Tech stack adapter / 技术栈适配

本 skill 支持多语言代码输入。检测规则按语言自动切换：

| 语言 | 主要检测适配 |
|---|---|
| Java/Spring | Spring Bean 生命周期、JPA 注解、@Transactional 语义 |
| TypeScript/JavaScript | async/await 安全、类型断言风险、null 合并 |
| Python | None 检查、Optional 类型、异常链 |
| Go | error 返回值忽略、goroutine 泄漏、nil 解引用 |
| Kotlin | Kotlin 空安全 !! 滥用、协程作用域泄漏 |

当语言未声明时：从文件扩展名或语法特征推断；推断结果记入 `inferred[]`。

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.


## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Produced event / 产物事件

当作为 N210 工作流节点的子技能执行时，本 skill 的产物通过以下事件元数据向下游声明可用性：

```yaml
event_emission:
  emitted_by: standalone_skill  # 本 skill 不自行发布节点级事件
  node_event_publisher: code-standard-check  # N210 唯一事件发布者（node_aggregation 模式）
  artifact_ready_signal: artifact_contract.readiness in [pass, provisional]
  downstream_consumers: [N220, N240, N260, N330, N370, N390]
  finding_contribution:
    target_artifact: "重构建议.md"
    finding_id_prefix: "SEE_SKILL_SELF_CHECK"
```

在 standalone 模式下：直接输出发现列表，无需声明节点事件；节点级事件由 `code-standard-check` 的 `node_aggregation` 模式统一发布。

## Machine-readable self_check rules

- `R01_source_findings_linked`: 当上游 N210 产物存在时，`refactoring_candidates[]` 必须链接 `source_findings[]`; `on_violation: warn`
- `R02_before_after_required`: 非平凡重构（Extract Method / Move Class / 模块重组）必须有 `before_after_previews[]`; `on_violation: reject`
- `R03_test_coverage_gate`: 类重命名、Service 拆分、模块重组等高风险重构必须先输出 `test_coverage_prerequisite` 块; `on_violation: reject`
- `R04_roi_required`: 每个重构候选必须包含 `roi_analysis`（`effort_estimate` + `benefit` + `risk`）; `on_violation: warn`
- `R05_pattern_catalog_cited`: 每条候选必须引用 Fowler 模式名称（如 Extract Method / Replace Conditional with Polymorphism）; `on_violation: warn`
- `R06_sequence_on_multiple`: 存在多个候选时必须输出 `implementation_sequence[]` 以避免冲突; `on_violation: warn`
- `R07_no_fabricated_runtime`: 不得声称性能提升未经 profiling 验证; `on_violation: reject`
- `R08_finding_id_stable`: 每个重构候选必须有稳定 `refactor_id`（格式 `REF-XXX-NNN`）; `on_violation: reject`
- `R09_n220_input_scope_guard`: 来自 N220 的输入仅用于迭代周期触发的重构，不用于初始 N210 pass; `on_violation: warn`

## Common failure modes

1. **跳过测试覆盖门控** — 直接推荐 Extract Service 或 Move Class 等高风险重构，未检查目标代码是否有测试保护，导致重构后行为静默回归。修复：始终先输出 `test_coverage_prerequisite`；`coverage_status: unknown` 时将重构 confidence 降为 `provisional`。
2. **源 finding 悬空** — 列出重构候选但不引用触发它的上游 N210 finding_id，审查者无法追溯依据。修复：每个候选的 `source_findings[]` 必须引用至少一条来自同节点其他 skill 或当前代码分析的 finding_id。
3. **ROI 缺失** — 只给"建议重构"而不量化改动成本与收益，导致优先级无法排序。修复：每条候选输出 `effort_estimate`（人天）、`expected_benefit`（可度量指标）和 `risk_if_not_done`。

## Event publication and N210 aggregation

This skill is a sub-skill of the N210 · 代码质量静态检查 node. It does **not** publish a produced event independently to the event bus.

**How events are published:**
1. This skill outputs its findings with stable `finding_id` values and a populated `downstream_handoff` block.
2. `code-standard-check` (running in `node_aggregation` mode) collects findings from all N210 sub-skills via `source_findings[]`.
3. After aggregation, `code-standard-check` publishes `produced.n210.code_quality_static_check.completed` to the event bus, which triggers N330, N370, N390 subscribers.

**Implication for standalone use:** when this skill is used outside the N210 workflow, callers are responsible for emitting any required produced event.

## SLA escalation to N380

When this skill emits findings with `severity: critical` (P0) or `severity: high` (P1):
- Include `sla_escalation_hint: true` in the finding's `downstream_handoff`.
- Downstream `code-standard-check` aggregator will propagate this flag to N380 · 平台门禁与人工协同 for SLA queue entry.
- Do not attempt to directly invoke N380 from within this skill.

```yaml
# Example finding with escalation hint
finding_id: TXNBC-001
severity: critical
sla_escalation_hint: true
escalation_reason: "Missing rollback on exception path in payment service"
recommended_human_action: "Review transaction boundary before merge"
```

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.


## Machine-readable SLA escalation rule

- `R_SLA_01`: Any finding with `severity: critical` MUST include `sla_escalation_hint: true`; `on_violation: warn`.
- `R_SLA_02`: Any finding with `severity: high` SHOULD include `sla_escalation_hint: true`; `on_violation: warn`.

## Reference files / reference files
- `references/refactoring-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/refactoring-self-check.yaml`: R01-R10 机读门禁规则
- `references/refactoring-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/refactoring-pattern-catalog.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
