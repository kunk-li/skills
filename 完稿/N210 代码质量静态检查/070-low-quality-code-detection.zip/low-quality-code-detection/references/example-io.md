# Example IO: low-quality-code-detection

## Scenario A: Standalone business-aware quality scan

### Input

```java
// OrderService.java
public Order processOrder(OrderRequest req) {
    Order order = new Order();
    order.setUserId(req.getUserId());
    order.setAmount(req.getAmount());

    // problematic: silently swallow exception, lose context
    try {
        riskService.checkRisk(req);
    } catch (Exception e) {
        log.error("risk check failed");
    }

    // problematic: amount calculation without overflow guard
    order.setTotal(req.getAmount() * req.getQuantity());

    // problematic: state transition without validation
    order.setStatus("PAID");

    orderRepository.save(order);
    return order;
}
```

User context: business rules document includes RULE-007 (订单状态机: DRAFT → SUBMITTED → PAID, must validate from-state).

### Output

```yaml
artifact_contract:
  schema_version: n210.low-quality-code-detection.v2.4
  produced_by: low-quality-code-detection
  selected_mode: business_aware_scan
  readiness: pass
  evidence_profile: code_plus_rules

findings:
  - finding_id: LQ-001
    severity: critical
    issue_kind: silent_exception_swallow
    location: {file: OrderService.java, line_range: [9, 11]}
    business_impact: "risk check failure silently ignored; high-risk orders proceed to payment"
    impact_scope: "all calls to processOrder; risk_service unavailability invisible to caller"
    affected_callers: [OrderController.create, BatchOrderJob.replay]
    fix_steps:
      - 1. catch RiskCheckException specifically (not Exception)
      - 2. on failure, throw RiskCheckUnavailableException with original cause
      - 3. caller handles 503 Service Unavailable
      - 4. add metric: risk_check_failures{outcome=swallowed} -> alert
    verification_hint: "unit test with risk service throwing; assert OrderRiskException propagates"
    related_standard_check_ids: []
    
  - finding_id: LQ-002
    severity: high
    issue_kind: arithmetic_overflow_risk
    location: {file: OrderService.java, line_range: [14, 14]}
    business_impact: "amount * quantity may overflow Long.MAX_VALUE for high-value bulk orders"
    impact_scope: "every order processing path"
    fix_steps:
      - 1. use Math.multiplyExact(amount, quantity) - throws on overflow
      - 2. catch ArithmeticException, throw OrderTotalOverflowException
      - 3. add input validation: max quantity per order from RULE-012
    verification_hint: "boundary test: amount=1B, quantity=10K -> should reject"
    rule_id: RULE-012
    
  - finding_id: LQ-003
    severity: critical
    issue_kind: state_transition_without_validation
    location: {file: OrderService.java, line_range: [17, 17]}
    business_impact: "violates RULE-007: order state must transition from SUBMITTED, not from new"
    impact_scope: "every processOrder call; bypasses state machine"
    fix_steps:
      - 1. introduce OrderStateMachine.transition(currentState, action) -> nextState
      - 2. throw IllegalStateTransitionException on invalid transition
      - 3. add @StateMachineGuarded annotation for static analysis
    verification_hint: "tests for all 9 (state, action) combinations from RULE-007"
    rule_id: RULE-007
```

### Self-score

```yaml
self_score:
  business_awareness: 3      # all 3 findings are business-aware (RULE-007, RULE-012, risk semantics)
  risk_localization: 3       # file:line + scope + callers
  fix_path_specificity: 3    # 4-step fixes + verification hint
  cross_skill_handoff: 2     # related_standard_check_ids placeholder; not aggregated yet
  total: 11
  band: S
```

---

## Scenario B: Workflow context with sibling integration

### Input

User: "已运行 code-standard-check 和 refactoring-recommendation, 跑业务感知质量检查"

Available: `代码规范检查单.csv` (STD-001..STD-085), `重构建议.md` (REF-001..REF-023)

### Output (key fields)

```yaml
selected_mode: business_aware_scan_aggregated
findings:
  - finding_id: LQ-007
    related_standard_check_ids: [STD-042]   # consumed STD finding
    avoid_duplication_with: [REF-018]        # acknowledged refactoring overlap, only added business angle
    business_impact: "STD-042 says snake_case violation; here we add: this method handles RULE-007 state transitions, naming inconsistency increases bug risk in critical path"
```

---

## Common readiness states

| readiness | when |
|---|---|
| `pass` | code + business rules available |
| `constrained` | code only; business impact analysis limited |
| `blocked` | only project description |
