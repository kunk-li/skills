# low-quality-code-detection 评分标准 v2.4

## 总览

输出按 4 个维度评分，每维 0-3 分，总分 0-12。

| 总分 | 等级 | 含义 |
|---|---|---|
| 11-12 | **S** | 可直接消费 |
| 9-10 | **A** | 生产可用 |
| 6-8 | **B** | 需人工修订 |
| ≤5 | **C** | 不建议消费 |

---

## 维度 1: 业务感知度 (business_awareness)

衡量: 是否避开通用 linter 已覆盖的纯语法层问题, 聚焦业务规则相关的低质量信号.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% finding 关联具体业务规则 (rule_id) 或业务概念 (e.g. 状态机非法转换、金额计算未防溢出、订单 id 类型不一致); 0% 重复 SonarQube/PMD/ESLint 已覆盖项 |
| **A (2)** | ≥80% 业务相关, 少量重复通用 linter |
| **B (1)** | 50-80% 业务相关, 其余是 linter 重复项 |
| **C (0)** | 输出主体是 linter 重复项 (重复方法、空 catch、未用变量) |

---

## 维度 2: 风险定位与影响范围 (risk_localization)

衡量: 每条 finding 含位置 + 影响范围 (单文件/模块/全局).

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% finding 含 file:line + impact_scope (e.g. "影响订单状态机所有 transition") + affected_callers[] |
| **A (2)** | ≥80% 含 impact_scope, 少量仅给位置 |
| **B (1)** | 仅给位置, 无影响范围 |
| **C (0)** | 仅说"代码质量差", 无定位 |

---

## 维度 3: 修复路径具体度 (fix_path_specificity)

衡量: 每条 finding 是否给可执行修复路径 + 测试建议.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% 含 fix_steps[] (3-5 步骤), 关联 N240 测试模式 (单元/集成/契约), 含 verification_hint |
| **A (2)** | ≥70% 含具体步骤, 余下泛指 "需要重构" |
| **B (1)** | 仅给修复方向, 无步骤分解 |
| **C (0)** | 仅指出问题, 无修复建议 |

---

## 维度 4: 跨 skill 协同 (cross_skill_handoff)

衡量: 是否引用 code-standard-check / refactoring-recommendation 的 finding.

| 等级 | 标准 |
|---|---|
| **S (3)** | finding 含 related_standard_check_ids[] + 与 refactoring-recommendation 协同 (双方互不重复, 引用对方 finding) |
| **A (2)** | 引用 ≥1 个 sibling 的 finding, 避免重复 |
| **B (1)** | 未引用 sibling, 但避免了明显重复 |
| **C (0)** | 输出与 refactoring-recommendation 100% 重叠 |

---

## 红线 (违反则直接归 C 或 0)

- 输出主体是 linter 已覆盖项 (e.g. unused import, magic number) -> 浪费上下文
- finding 缺业务关联 -> 无法判断优先级
- 与 refactoring-recommendation 输出 90%+ 重合 -> 角色定位失败
- 把所有 finding 标 high -> 优先级失效

---

## 等级映射示例

- **S+ (12)**: 全部 finding 业务关联 + 含 impact + fix_steps + 跨 skill 协同
- **S (11)**: 3 维满分 + 1 维 A
- **A (9-10)**: 业务感知强但 fix_steps 粗略
- **B (6-8)**: 部分 finding 重复 linter 或缺业务关联
- **C (<6)**: 与通用 linter 高度重叠

---

## 自评示例

```yaml
self_score:
  business_awareness: 3
  risk_localization: 3
  fix_path_specificity: 2
  cross_skill_handoff: 3
  total: 11
  band: S
  rationale: 2 条 finding 仅给修复方向, 未分解为 3-5 步骤
```
