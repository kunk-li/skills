# V2 schema catalog

This file is the enum and field source of truth. `detector-boundary.md` explains what this skill owns.

## category values
- bug
- code_smell
- vulnerability
- security_hotspot

## business_context_rule.rule_kind values
- anti_real_name_coverage
- append_only_missing
- idempotency_key_missing
- audit_event_missing
- transaction_missing
- permission_check_missing
- rate_limit_missing
- circuit_breaker_missing
- timeout_missing
- retry_logic_missing
- pii_logging_violation
- hardcoded_business_value
- stale_feature_flag

## required fields
- `differentiation_from_sonar`: sonar_detects, this_skill_detects.
- `metrics`: severity, effort_to_fix_minutes, impact_scope, confidence.
- `evidence`: code_snippet, explanation, linked_rule_ref.
- `remediation`: suggested_fix, auto_fixable, before, after.
- `code_quality_summary`: total_findings, by_category, by_severity, technical_debt_minutes, hotspot_files.
