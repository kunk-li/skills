# Output template: workflow-aligned low-quality code issue list

Required sections:
1. metadata
2. issue_summary
3. issue_catalog[]
4. metric_snapshots[]
5. differentiation_from_sonar
6. sonar_overlap_filter
7. code_quality_summary
8. self_check

Issue fields:
| issue_id | severity | confidence | category | business_rule_kind | location | metric_evidence | business_context | linked_rule_ref | differentiation_from_sonar | effort_to_fix_minutes | impact_scope | recommendation | related_standard_check_ids | source_skill |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Allowed `category` values: bug, code_smell, vulnerability, security_hotspot.
Allowed `business_rule_kind` values: anti_real_name_coverage, append_only_missing, idempotency_key_missing, audit_event_missing, transaction_missing, permission_check_missing, rate_limit_missing, circuit_breaker_missing, timeout_missing, retry_logic_missing, pii_logging_violation, hardcoded_business_value, stale_feature_flag.

`differentiation_from_sonar` fields: sonar_detects, this_skill_detects.

`code_quality_summary` fields: total_findings, by_category, by_severity, technical_debt_minutes, hotspot_files[].

Cross-skill fields: all rows should include `confidence`, `related_standard_check_ids`, and `source_skill` when applicable.
