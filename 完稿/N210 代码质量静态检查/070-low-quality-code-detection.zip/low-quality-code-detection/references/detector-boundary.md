# Detector boundary

This skill should complement mature static-analysis tools rather than clone them. Use it for findings that need project rules, business rules, security design, NFR design, or compliance context.

## This skill owns
- Business rule implementation gaps: masking, audit, idempotency, permission, rate limit, timeout, retry, circuit breaker.
- NFR design alignment gaps: resilience, performance, consistency, security, observability.
- Project-specific anti-patterns that generic tools cannot infer.
- Differentiation from SonarQube: explain what Sonar catches and what this skill catches.

## This skill should not own
- Pure formatting, import ordering, indentation, or language-level linting.
- Generic duplicate-code detection when `duplicate-code-detection` is available.
- Null, transaction, or thread-safety deep diagnostics owned by 072/073/074; link to those findings instead.

Every high-confidence business finding must include a `business_rule_kind`, `linked_rule_ref`, confidence, impact scope, and estimated fix effort.
