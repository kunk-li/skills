# low-quality-code-detection 常见失败模式 v2.4

## 通用部分（F1-F4）

### F1. 把推断包装成确定事实

**症状**：标 `business_impact: critical` 但 finding 没有引用业务规则 rule_id，仅基于代码外观判断

**影响**：下游误以为是业务关键问题，触发 escalation；实际是普通代码质量问题

**修正**：business_impact 必须基于 rule_id 引用或 explicit business context；不可基于直觉

---

### F2. 没有位置或范围仍给强结论

**症状**：finding 仅写 "业务逻辑不严谨"，没有具体方法、行号、数据流

**影响**：人工无法定位真正的业务问题；与通用 linter 报告无法区分

**修正**：location 三件套 + impact_scope（影响哪些 caller / use case）必填

---

### F3. 同类问题机械穷举

**症状**：对每个使用魔法数字的位置都列一条 finding；100 个位置变成 100 条

**影响**：高严重度业务问题被淹没；产出与 SonarQube 等工具雷同

**修正**：cluster_id 合并；魔法数字这种通用问题应抑制（让 linter 处理），仅保留与业务规则相关的特殊用法

---

### F4. 只说问题不说原因或建议

**症状**：finding 仅写 "代码质量差"，没有 fix_steps 和 verification_hint

**影响**：用户无法落地修复；价值堆积成空指控

**修正**：fix_steps[] (3-5 步) + verification_hint (如何确认修复有效) 必填

---

## 本 skill 重点（F5-F8）

### F5. 输出主体是 linter 已覆盖项

**症状**：finding 里大量 unused-import / magic-number / empty-catch / unused-variable，与 SonarQube/PMD 重复 90%+。

**影响**：浪费 LLM 上下文；产出无增量价值；用户感知"重复劳动"。

**修正**：
- 已被成熟 linter 覆盖的检查类别一律抑制；输出聚焦在 business_aware 且 linter 不擅长的层面。
- 业务感知类型：状态机非法转换、金额溢出风险、订单 id 类型一致性、并发关键路径上的代码异味。
- linter-redundant 类 finding 单独计数后丢弃，不展开。

---

### F6. finding 缺业务关联

**症状**：finding 列出"方法过长"但没说"为什么这个方法长有问题"——是关键路径上的支付逻辑还是边缘工具方法。

**影响**：优先级失效；用户不知道哪些该先修。

**修正**：
- 每条 finding 必须关联 business context（rule_id / 用例名 / 业务流程节点）。
- 缺业务上下文时降级 severity 到 low 并标 evidence_profile: code_only_no_business_context。

---

### F7. 与 refactoring-recommendation 输出 90%+ 重叠

**症状**：本 skill 与 sibling refactoring-recommendation 的 finding 几乎一一对应，仅措辞略不同。

**影响**：用户拿到两份几乎相同的报告；角色定位失败；浪费 token。

**修正**：
- 本 skill 聚焦 detect (有什么质量问题 + 业务影响)，不出 refactor pattern。
- refactor pattern 由 refactoring-recommendation 给出；本 skill 输出关联 ID 即可。
- avoid_duplication_with[] 字段必填，标识与哪些 sibling finding 关联。

---

### F8. 把所有 finding 标 high

**症状**：总数 50 条 finding，severity 分布 high: 47, medium: 3, low: 0；critical: 0。

**影响**：优先级失效；用户必须重新评估；告警系统响应失真。

**修正**：
- severity 分布健康度：critical < 5%, high < 30%, medium 50%, low 15%, info 部分。
- 偏离健康分布时本 skill 必须自检并降级；或在 self_check 标 distribution_warning。

