---
name: low-quality-code-detection
description: Detect low-quality code signals needing business rules, NFRs, or security context to interpret — quality triage that complements SonarQube-class tools instead of repeating generic output.
---
# low-quality-code-detection

## Role / role positioning
检测业务上下文低质量代码并补足 Sonar 类工具盲点. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `低质量代码清单.csv`.

## Boundary / 边界
- 负责检测需要业务/NFR/安全上下文才能判断的低质量信号（非格式类问题）。
- 不重复 SonarQube 已覆盖的通用复杂度或重复度指标；作为 Sonar 的语义补充。
- 不负责命名问题（由 `naming-optimization-recommendation` 处理）。
- 不负责并发或事务风险（由各专属 skill 处理）。

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- biz_specific
- metrics_only
- threshold_check


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 代码 + 业务规则 + 错误码清单 + sibling N210 输出 全部齐备 | 完整业务感知 finding + impact_scope + fix_steps |
| `provisional` | 代码齐备但业务规则文档缺失 | 输出 finding 但 business_impact 进 pending（仅技术层面） |
| `constrained` | 仅有代码，无业务上下文 | 仅输出语法/结构层 finding，severity 保守 |
| `blocked` | 仅有项目描述，无代码 | 输出 `request_for_inputs[]` |

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- business rules from N070
- security / compliance / NFR designs from N170
- sonarqube / pmd / spotbugs reports
- 代码规范检查单.csv from code-standard-check when available

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.low_quality_code_detection`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 低质量代码清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- issue_summary
- issue_catalog[]
- business_rule_coverage
- metric_snapshots[]
- sonar_overlap_filter
- technical_debt_minutes
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Tech stack adapter / 技术栈适配

本 skill 支持多语言代码输入。检测规则按语言自动切换：

| 语言 | 主要检测适配 |
|---|---|
| Java/Spring | Spring Bean 生命周期、JPA 注解、@Transactional 语义 |
| TypeScript/JavaScript | async/await 安全、类型断言风险、null 合并 |
| Python | None 检查、Optional 类型、异常链 |
| Go | error 返回值忽略、goroutine 泄漏、nil 解引用 |
| Kotlin | Kotlin 空安全 !! 滥用、协程作用域泄漏 |

当语言未声明时：从文件扩展名或语法特征推断；推断结果记入 `inferred[]`。

## Execution workflow / execution workflow
1. 确认可用代码/diff/仓库，以及 Sonar、PMD、SpotBugs 报告（若有）。
2. 选择模式（`biz_specific` / `metrics_only` / `threshold_check`）并声明 `readiness` 和 `evidence_profile`。
3. 加载项目自定义阈值（SonarQube profile / PMD ruleset）或使用 skill 默认值；在 `active_thresholds[]` 中记录 `threshold_source`。
4. 扫描业务上下文信号：magic numbers、硬编码配置、过度抽象（over-engineering）和测试代码质量问题；每类单独归入对应 `finding_kind`。
5. 计算度量快照（`metric_snapshots[]`）：圈复杂度、方法/类长度，与 `active_thresholds[]` 比对。
6. 应用 `sonar_overlap_filter`：已被 Sonar/PMD/SpotBugs 覆盖的 finding 标记为 `tool_covered: true` 并可从结果中过滤。
7. 为每条 finding 估算 `technical_debt_minutes`；severity ≥ high 时附 `sla_escalation_hint: true`。
8. 生成稳定 `finding_id`，填写 `business_rule_coverage` 和 `refactor_candidates[]`。
9. 输出 `downstream_handoff`，向 `refactoring-recommendation` 传递 finding refs，向 `code-standard-check` 传递 `source_findings[]`。
10. 执行 self_check 和 common-failure review。



## Extended detection catalog

In addition to the base capability (business-context quality signals that complement Sonar-class tools), this skill explicitly covers:

### Magic numbers and hard-coded configuration
Detect numeric literals (other than 0, 1, -1) and hard-coded strings used as business logic constants:
- Flag with `finding_kind: magic_number` or `finding_kind: hardcoded_config`
- Recommend extraction to named constants, `@Value` properties, or config maps
- Severity: `low` for purely local constants, `medium` for cross-method constants, `high` for cross-service constants

### Over-engineering detection
Flag unnecessary abstraction that adds complexity without measurable benefit:
- Single-implementation interfaces with no extensibility intent (no test double, no DI, no strategy pattern)
- Generic utility classes with only one caller
- Premature optimization patterns (micro-batching, custom thread pools) without performance evidence
- Record as `finding_kind: over_engineering`, severity `low` unless it creates maintenance burden

### Test code quality
When test files are included in scope, apply a separate quality bar:
- Assert-less tests (`@Test` methods with no assertions) → `severity: high`
- Tests with only `System.out.println` or log statements → `severity: medium`
- Commented-out test blocks > 20 lines → `severity: low`
- Duplicated test setup without `@BeforeEach` extraction → flag for refactor_ready
- Record test findings with `scope: test_code` to allow separate filtering from production code findings

### Threshold policy
Every `threshold_check` mode result must declare `threshold_source`:
- `project_defined`: thresholds from SonarQube profile, PMD ruleset, or team config file
- `skill_default`: built-in defaults (cyclomatic complexity > 10, method length > 50 lines, class length > 300 lines)
- Always record the active thresholds in `active_thresholds[]`

### Dead guard / structural no-op(看似在守、其实是死码)
检测**看似在执行一道安全 / 校验 / 业务约束、实则结构上恒不生效**的守卫——Sonar 类工具看不出(语法完全合法),要懂语义才判:
- **读了不存在的字段 / 键** → 守卫条件恒 false。如 `obj.get("status")` 但该对象实际序列化出的键是另一个名字(`userStatus` / `xxxStatus` 之类,没有 `status`)→ `if("DISABLED".equals(status))` 永不命中,禁用 / 冻结校验是死的。`finding_kind: dead_guard`;落在 auth / 权限 / 状态 / 钱 路径 = **critical/high**。
- **配置的阈值 / 开关被声明但全仓无消费者** → 形同虚设。如一个协签阈值字段(`minApproveCount` 之类)只被赋值、却没有任何地方读它来算完成条件 → "双签"实际一签即过。`finding_kind: unconsumed_control`。
- **其它恒真 / 恒假守卫形态**:与常量比较的死分支、被更早 `return` 短路掉的检查、`@Annotation` 标了但拦截器 / 过滤器未绑定该路径(鉴权拦截器 pathPatterns 漏了该端点 → 标了等于没标)。
- **占位/桩体控制 — 看似在执行、实则空操作恒放行**(`finding_kind: stub_control`):守卫/控制确实被调用到、也确实执行了,但方法体是占位桩——只打日志后照常往下且其后再无任何真实拒绝/throw/return-deny(纯 log-only,非 log-then-enforce)、无条件 `return true / return 0 / return pass`、空方法体、依赖缺失即放行(`if (svc == null) return allow`)、或 TODO 留空——所以它"在跑"但什么都不强制。**与 dead_guard 的区别**:dead_guard 是结构上恒不触发,本类是触发了却空转。落在鉴权 / 二次校验 / 脱敏 / 通知告警送达 / 资金 / 合规路径 = **critical/high**(控制存在的假象比明显缺失更危险,review 容易放过)。
- **代理守卫 — 守卫触发且校验了真属性,但比的是受保护值的代理量而非值本身**(`finding_kind: proxy_guard`):一个守卫确实执行、确实比较了某个真实属性,但比较的是受保护的**冻结 / 不可变 / 防篡改**值的**代理量**(行数 rowCount / 集合大小 size / 存在性 / 已存哈希但从不复校 / 调用方自传的那份数据),而非**受保护的值本身**;所以一个**保持代理量不变的定向篡改**(同行数改一个分值、同 id 换内容)会被守卫放行。典型:`if (rows.size() != snapshot.rowCount) throw` 之后直接用 caller 传入的 `rows` 里的分数算钱,而快照存了 `hash` 却从不重算比对、也不从权威存储重读冻结值——保持 3 行、把某人分数从 60 抬到 90 就会被照单全收。**与同族区别**:dead_guard 结构恒不触发、stub_control 触发后空转不强制、registration_fail_open 执行点没装上——本类**触发了、也强制了,但强制的是错的(更弱的)属性**,受保护值的真实校验(重算哈希比对 / 重读权威值 / 逐字段对比)缺席。**检测法**:定位任何「校验冻结 / 不可变 / 快照 / 防篡改不变量」的守卫,核它比的是**值本身**还是**代理量**;若只比代理量、且受保护值的真值从不复校,或后续计算 / 决策用的是调用方自传的那份值,即报。**排除**:对无不可变 / 防篡改语义的数据做普通 size / 分页 / 非空 / 格式校验(如 `page<0`、`size` 上限)不是本类,不报(present-but-inconsistent 只针对受保护不变量)。落钱 / 鉴权 / 完整性 / 合规路径 = **critical/high**(控制存在的假象比明显缺失更危险,是 present-but-inconsistent 的单站点变体,review 极易放过)。
- **重放 / 快捷分支的授权缺口 — 主路径有守卫、某条 return / mutate 分支绕过它**(`finding_kind: replay_authz_bypass`):一个操作在其**主路径**强制了授权(owner / tenant / 角色 / 归属守卫),但它的**幂等重放 / 已达目标态 / 快捷 early-return / catch-and-return 分支**在守卫之前(或压根不过守卫)就**返回实体数据或施加副作用**——因为「已经是目标态了、直接返回 / 直接跳过」这条分支被误当无害,守卫只写在主路径上。典型:`won = markDone(id, caller); if (won==0) { if (status==DONE) return entity; /* owner 校验只写在这之后的 else 分支 */ }` —— 非 owner 传任意 id 对一条已 DONE 的记录调用,就在 `return entity` 拿到全量实体(payload / 敏感字段 / 外部引用)= IDOR 读旁路;或「重复请求返回已存在实体」的幂等分支直接 `return existing` 不校调用方。**检测法(机械、逐分支,不靠灵感)**:对**每个**操作,枚举它**所有**会 return 实体 / mutate 状态的分支——**尤其** idempotent-replay / already-in-target-state / fast-path 命中 / 早退(`if already X return` / `catch(...) return existing` / `affectedRows==0` 回落)这些**次要分支**——核**每条分支**是否都独立过了该操作主路径同款的 owner / tenant / 角色守卫;任一分支在守卫之前 return 实体或施加副作用即报。**并核 existence-leak 全 op 对齐**:not-found 与 not-authorized 对未授权调用方须在**每个** op 上不可区分(某 op 已收敛成同一响应、姊妹 op 却区分 = 存在性 oracle,归本族)。**与同族区别**:`proxy_guard` 是守卫比了代理量、`stub_control` 是守卫触发后空转、`registration_fail_open` 是执行点没装上、`divergent_duplicated_boundary` 是跨 ≥2 实现点发散——本类是**同一操作内**主路径有守卫、某条分支(常是幂等重放 / 快捷分支)漏守卫(intra-method 分支不对称,单个方法内)。**排除**:确无 owner 语义的公共读 / 明确 public 资源分支不报;spec 签名根本没给调用方身份参数(内部信任边界)标观察项非本类。落鉴权 / 资金 / 隐私 / 合规路径 = **critical/high**(review 与单轮检测极易只看主路径、放过重放 / 快捷分支——present-but-partial 的 intra-method 变体)。
- **注册期 fail-open — 安全强制点的装配代码被吞异常致执行点缺席仍照常启动**(`finding_kind: registration_fail_open`):拦截器/守卫/filter/PEP 的注册/wiring 代码被 swallow-and-continue 的 try{解析依赖/getBean}catch{静默跳过} 包住,或条件注册分支在依赖缺失时默认 off → 依赖缺则该执行点从未装入请求链、应用却照常启动。与同族区别:dead_guard 结构恒不触发、stub_control 触发了空转、本类是执行点根本没被装上。落鉴权/权限/资金/合规路径 = **critical/high**(比明显缺失更隐蔽,启动绿灯掩盖)。
- **跨 ≥2 实现点的控制发散 — 同一控制概念在仓内多个独立实现点之间矛盾且无单一权威源**(`finding_kind: divergent_duplicated_boundary`):同一控制概念/规则/边界(阈值判定 / 状态机转移 / 分类分档边界 / 多人控制旁路 / 并发写锁 / 特权豁免审计)在同一仓库内有 ≥2 个独立代码实现点,而这些实现点之间发散、且无共享常量 / 配置 / helper 收敛。命中任一形态即报:(a)**谓词极性 / 组合相反**——两实现对同一信号用相反比较方向(`<` vs `>`)或相反布尔组合子(AND vs OR),却共享同一输出标志位 / 状态值 / 标签,结论可分叉;(b)**强制强度不一**——同概念多站点约束强度不等(一处有去重 / 自审回避 / 单次性约束、另一处无),最弱实现成旁路(守卫种类含锁 / 冻结 / 空值 / 缺编 fail-closed / 豁免,逐类比对见 Step 2 · 2-C 守卫种类清单锚);(c)**姊妹站点锁不对称**——结构同构的多个整行 RMW 写点(各 `selectById`→内存改→`updateById`)其一已配 `@Version` / select-for-update / 条件原子更新而其余缺,缺锁站点存在 lost-update;(d)**冗余双判致后置死分支**——同一前置在单路径被 ≥2 控制点重复判定,前置等价谓词完全覆盖后置触发条件致后置永不可达(本类只收死分支这一面,后置暴露相异错误码 / 协议状态那一面归错误码族契约 skill);(e)**等价旁路审计 / 门禁不对称**——系统内 ≥2 条语义等价的特权短路 / 豁免路径,其审计可区分性或门禁强度严重不等(一处写可区分 append-only 旁路证据 + 二次认证、另一处退化成普通事件);(f)**权威源在位却被离群实现旁路**(authoritative_inert_divergence)——仓内已存在该控制概念的单一权威定义(枚举 / 常量 / 注册表 / 角色集 / 状态集),却被 ≥2 个离群站点(controller 注解白名单 / 入参校验正则 / validator / 前端常量)各自硬编码重列一份成员集 / 取值集而不引用该权威源,权威源增删成员时离群副本静默落后;**与 (a)-(e) 区别**:此形态权威源确实存在(故非『无单一源』),病在离群实现『有源不引』,修复=离群点改引权威源而非各自重列。检测法(**域无关两步骨架做主路径——先机械建三张清单、再对每张清单逐项反查发散,不靠灵感、不依赖任何团队的命名 / 注释习惯;旧措辞把注释自供锚标成「召回最高优先扫」,换到不写同步注释的团队即整条空转、纯结构同构那条也全漏,故重构如下**):**Step 1 · 建清单(纯 grep 结构枚举,与命名 / 注释无关,域无关)**——枚举仓内三类对象:(1)**权威源清单**=所有定义『允许成员集 / 规范取值域』的单一权威定义(枚举 enum / 常量集 / 常量类 / 角色集 / 权限集 / 状态集 / 类型码表 / 注册表 / 白名单),逐个记下其类型名与全部成员字面量;(2)**阈值·字面量清单**=所有承载业务语义的控制字面量(角色码 / 状态码 / 类型码 / 数值阈值 / 计数门限 / 上下限)的字面量出现点,grep 其裸字面值聚成同值簇(`private static final` / 内联常量 / 注解参数 / 校验正则 / 前端常量各算一处);(3)**写点·转移清单**=每个实体的整行读改写(RMW)写点(`selectById`→内存改→`updateById` 同构)与每个状态转移 / 控制判定 / 特权短路 / 豁免站点。**Step 2 · 反查发散(对 Step1 每张清单逐项反查,机械、命中即报对应形态、域无关)**:(2-A)**权威源→离群副本**(原**权威源成员锚**,跨代码库最普适、对陌生代码库唯一不依赖结构前提的一条,必跑满、不可跳过)——对每个权威源 grep 其成员字面量,凡硬编码重列一份成员集 / 取值集(controller 注解白名单 / 入参校验正则 / validator / 前端常量等)而**不 import / 不引用**该权威源的站点即 (f) 候选『有源不引』,权威源增删成员时这些离群副本静默落后;**且离群副本会系统散布在五类站点、须逐类全扫不可凭印象只扫一两类**——对每个权威源的成员字面量,逐类 grep 这五类:(I)权限/角色/路由类注解参数里枚举的白名单集(注解参数中以数组/逗号列出的角色码/类型码/动作码三元组等),(II)入参/字段校验注解正则里枚举的取值集(形如锚定起止的择一分组正则,把允许动词/状态硬列进 pattern),(III)各 service/orchestrator/校验器里语义命名的私有常量(如角色码/决策动词/事件类型/动作码的 `private static final` 单值常量,同一码常在 ≥两处各自重声明一份),(IV)内联 equals/eq/switch/三元里的裸字面量(`"X".equals(...)` / `== "X"` / `switch(... ){ case "X" }` / 三元里直接写值),(V)DTO/前端/跨端镜像常量(后端枚举在传输对象或前端各复制一份)——任一类的取值集与权威源成员集不一致、或取值落在权威族内却既不 import 也不引用权威源,即 (f);**并含裸字面量旁路**——站点直接用裸字符串 / 数字字面量(裸角色码 / 裸状态码等)压根不声明常量、其值落在某权威族成员集内者同属 (f);**并须跑无源兜底分支**——即便仓内查无任何权威源(清单(1)为空),只要同一控制字面量(角色码 / 状态码 / 类型码)裸散在 ≥2 处独立站点,仍报『应抽枚举单一源』候选(此分支正是清单(1)为空时的兜底,务必跑、勿因「没有权威源」就略过)。(2-B)**阈值·字面量→重复副本**(原**阈值字面量锚**)——对每个同值簇,凡同一业务阈值字面值出现在 ≥2 处独立 `private static final` / 内联即副本发散候选(与 048 R08 互参),锁定后留待收尾横向核取向。(2-C)**写点·转移→守卫对称性 + 锁一致**(原**守卫种类清单锚** + **结构同构 RMW 锚**)——对清单(3)每个写入 / 状态转移站点,逐类核**同一守卫清单**在所有姊妹站点是否对称齐备:**锁守卫**(`@Version` / select-for-update / 条件原子更新)、**冻结·终态守卫**(终态 / 冻结状态拦截)、**空值守卫**(blank / null 校验)、**缺编·fail-closed 守卫**(resolver 标记的缺失记录 / 失败标志是否被消费侧读取放行)、**特权豁免守卫**(同一豁免在各等价站点的存在性与放行强度一致);姊妹站点缺任一类守卫即 (b) 强制强度不一 / (c) 候选——这是 (b) 的可机械执行版,逐类比对而非凭印象,最弱实现成旁路;其中结构同构的多个整行 RMW 写点须额外横向核 `@Version` / select-for-update / 条件原子更新是否在**所有**写点一致,缺锁站点存在 lost-update 即 (c) 姊妹站点锁不对称。**集中守卫旁路核法**:若仓内存在集中的状态机 / 前置校验入口(统一的可转移性 / 合法性断言函数,供各写点调用),先 grep 定位该集中入口符号、再反查清单(3)里每个写点 / 转移站点是否都实际调用了它;凡某写点不调集中入口、改用自己的私有内联前置(就地写一段本地条件判断取代统一断言)放行,则集中校验对该路径恒失效、该路径绕过了统一守卫,归 (b) 强制强度不一 / (c) 守卫发散——核法是把「集中入口的调用点集合」与「清单(3)的全部写点集合」做差集,差集里的写点即旁路嫌疑,逐个核其私有前置是否弱于集中断言。**务必扫满**:同一实体 / 同一控制概念的写点常分散在多个控制器 / service / 定时任务 / 子流程,须把清单(3)里该实体的**每一个**写点跨所有位置逐一核到底,不得在某处命中一条不对称即停——只核一处会漏掉另一处同型的锁 / 守卫不对称。**两步通用收尾——锁定站点后横向比对**:对发散候选逐对比较比较运算符方向(`<` vs `>`)、阈值取向、布尔组合子(AND vs OR)、约束集、锁机制、审计可区分性 / 门禁强度是否等价——两站点对同一信号用相反比较方向或相反布尔组合却共享同一输出标志位 / 状态值 / 标签即 (a) 谓词极性 / 组合相反;同一前置在单路径被 ≥2 控制点重复判定、前置等价谓词完全覆盖后置触发条件致后置永不可达即 (d) 冗余双判致后置死分支(本类只收死分支这一面,后置暴露相异错误码 / 协议状态那一面归错误码族契约 skill);≥2 条语义等价的特权短路 / 豁免路径其审计可区分性或门禁强度严重不等(一处写可区分 append-only 旁路证据 + 二次认证、另一处退化成普通事件)即 (e) 等价旁路审计 / 门禁不对称;**等价路径核法(逐目标态枚举到达路径再逐路径对账,机械可执行)**——对每个目标状态/终态/控制结果,先枚举所有能把实体置到该态的到达路径(常规审批通过 / 特权短路 / 自动任务直推 / 代理或代签 / 工作流引擎直接置态等),grep 出每条路径的写点;再对这批等价路径逐路径对两件事:(1)**审计链对账**——核每条路径是否都写入同一条合规审计链(防篡改 append-only / 哈希链 / 反绕过审计表),凡某路径只写普通本地日志或干脆不写审计 = 审计可区分性严重不等;(2)**区分字段对账**——核每条路径置态时是否都写齐同一套可区分标记(操作主体 / 入口类型 / 来源标志 / 签字方数),凡某路径把状态置成与强路径完全相同却不留任何区分字段、致下游消费方无法把弱路径产物与强路径产物区分开 = 同属 (e);任一处修缺陷后须核所有平行实现是否同步,共享同一输出标志位 / 状态值的多实现尤须逐点对齐。**可选辅助锚(若代码库有此约定则加用以加速定位、无则跳过,均不作主路径、不得标成『最高优先』;其指向的姊妹站点不会因降级而漏——同一批站点已被 Step1 清单(3)的写点 / 转移枚举与 Step2 的反查独立覆盖,辅助锚只是更快指路、非唯一入口)**:(i)**注释自供锚**(原①)——若代码库带『与 X 同口径 / 同义 / 同款 / 一致 / 对齐 / 同 X 逻辑 / 同步自 X / copy from X / 参考 X』之类自承注释,grep 之可快速指向一个须与 X 逐字段比对的姊妹站点;不写这类同步注释的团队跳过此锚(其召回仅在有注释同步文化时高、无则为 0,不影响 Step 1-2 主骨架召回)。(ii)**同名符号锚**(原②)——若并行实现以可识别相关的命名出现(跨 service / impl / controller 类的同动词 / 同前缀的取值 / 校验 / 检查方法、共享同一阈值常量名、同语义常量前缀),枚举之逐对比其守卫强度 / 空值检查 / 阈值 / 错误码是否一致;无可识别命名约定的团队跳过此锚、回退到 Step 1-2 的结构枚举即可。**与同族区别**:`magic_number` / `hardcoded_config` 是单点(只标此处有未命名常量、从不核多点是否同源同义);`dead_guard`(单点条件结构恒假)/ `stub_control`(单控制触发后空转)/ `registration_fail_open`(单装配点缺席)都判单个控制点本身失效——本类必须看到 ≥2 个实现点才成立,轴是「跨点发散 / 不对称」,单点检测查不出。边界一致性是跨实现点的全局不变量而非单点属性,须收敛到单一事实源。落鉴权 / 权限 / 资金 / 风控 / 状态机 / 合规路径 = **critical/high**(present-but-inconsistent:控制有效性退化为「哪条链路先跑 / 挑最弱实现」,比明显缺失更隐蔽)。
- **无生产者的僵尸子系统**(`finding_kind: no_producer`):一整套读取 / 查询 / 扫描 / 处理子系统(连带它的升级、超时、告警分支)围绕一张表 / 队列 / 状态运转,但全仓**没有任何写入方 / 生产者**往里建数据——它永远拿不到数据、整条链空转。是 `unconsumed_control`(声明了没人读)的**逆向**(有人读但没人写)。判:backing store 在全仓只有 schema / 读取、零 INSERT / 生产路径,**且无任何已记录的仓外写入方**(外部系统 / 迁移 / 他服务 / 批量 ETL,以接口契约或对接说明为据)——仅当仓内仓外都没有生产路径、表永远拿不到数据时才判僵尸;被注释 / 不可达死码的 INSERT 与测试夹具 / seed-only 写入不算有效生产者。本形态只定位结构性 gap(读 / 写 / 消费缺一环),其业务量级影响(是否真造成损失、多大)须另行评估、不在本检测结论里量化成本 / 损失(同一 gap 可能被别处机制如产物存在即跳过而稀释)。
- **不可达的再入 / 恢复态**(`finding_kind: unreachable_state`):状态机里某个状态没有任何入边转换——本应"恢复到该态 / 再入该态"的流程会永久卡住(到不了那个状态,或到了出不来)。判:枚举状态转移图——(a) **零入边的非终态** = 不可达再入态,本应被恢复 / 再入却无任何转移指向它 → 报;(b) **零出边的状态**仅当未被显式声明为终止态(无 terminal / final / 结束标记、业务语义上也不是流程终点)时才算缺陷,已声明终态的零出边正常、不报;判零入边时排除恒不可达的死路入边(守卫恒假或源自不可达态的转移不算有效入边),并排除『入边存在但过窄 / 仅人工触发』的状态(它可达、只是入口窄,属入边过窄 / 可达性问题、不是零入边卡死)与『未接线的文档承诺分支』(docstring / 注释指向不存在的字段或从未实装的承诺,是空承诺、不是被掐死的可达态)——这两类都不算零入边不可达态。落在主流程 / 资金 / 生命周期路径 = **high**。
- **方法 = derive-then-diff**:把"声称在守的约束"与"代码结构上是否真能生效"求差;**只报落在安全 / 权限 / 钱 / 状态机 / 合规路径**的死守卫(纯展示 / 日志的恒真分支不报,防误报)。静态结论标明局限(守 R09,不写成运行时已证)。
- **逐维度逐分支彻底,不许检测侧盖章(multi-dimension per-branch discipline)**:一次审计要把上面每类控制**并行全扫**(授权 / 死控 / 代理守卫 / 分支不对称 / 发散 / 不可达态 / 幂等 / 事务边界 / 并发 / 计次),**且每类扫到分支级别**——授权类尤其要对每个操作枚举**每一条** return / mutate 分支(含幂等重放 / 快捷 / 早退分支)逐条核守卫,不能只核主路径就判该维度 clean。一个维度被标 clean 却没写出「核了哪几条分支 / 站点」= **under-probed = 检测侧的 rubber-stamp**(与生成侧 [[my-verification-misses-what-detection-catches]] 同病:只验主路径漏次要分支)——一个真 high 会因此藏到后面某轮才被挖出。**操作性纪律**:对每个访问控制 / 死控维度,在结论里写出「本维度核过的分支 / 站点清单 + 各自结论」,而非只写「clean」;写出被核分支这个动作本身强制逐分支看、防盖章。判据回馈:naive 单轮检测漏掉的 high(如 `replay_authz_bypass` 幂等分支读旁路),用本纪律应能同一轮接住。

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Produced event / 产物事件

当作为 N210 工作流节点的子技能执行时，本 skill 的产物通过以下事件元数据向下游声明可用性：

```yaml
event_emission:
  emitted_by: standalone_skill  # 本 skill 不自行发布节点级事件
  node_event_publisher: code-standard-check  # N210 唯一事件发布者（node_aggregation 模式）
  artifact_ready_signal: artifact_contract.readiness in [pass, provisional]
  downstream_consumers: [N220, N240, N260, N330, N370, N390]
  finding_contribution:
    target_artifact: "低质量代码清单.csv"
    finding_id_prefix: "SEE_SKILL_SELF_CHECK"
```

在 standalone 模式下：直接输出发现列表，无需声明节点事件；节点级事件由 `code-standard-check` 的 `node_aggregation` 模式统一发布。

## Machine-readable self_check rules

- `R01_mode_declared`: `selected_mode` 必须是 `biz_specific | metrics_only | threshold_check` 之一; `on_violation: reject`
- `R02_threshold_source_declared`: `threshold_check` 模式下必须声明 `threshold_source`; `on_violation: reject`
- `R03_finding_id_stable`: 每条 finding 必须有稳定 `finding_id`（格式 `LQC-XXX-NNN`）; `on_violation: reject`
- `R04_severity_set`: `severity` 必须是 `critical | high | medium | low | info` 之一; `on_violation: reject`
- `R05_sla_hint_critical`: `severity: critical` 必须附 `sla_escalation_hint: true`; `on_violation: reject`
- `R06_no_sonar_duplication`: 已有 Sonar/PMD 报告时不得重复输出相同 finding，必须通过 `sonar_overlap_filter`; `on_violation: warn`
- `R07_test_scope_tagged`: 测试代码的 finding 必须标注 `scope: test_code`; `on_violation: warn`
- `R08_debt_minutes_estimated`: 每条 finding 必须包含 `technical_debt_minutes` 估算; `on_violation: warn`
- `R09_no_fabricated_runtime`: 不得把静态分析结论写成运行时已验证事实; `on_violation: reject`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff` 块; `on_violation: reject`

## Common failure modes

1. **Sonar 重复输出** — 对已有 SonarQube 报告的代码再次逐一列出 generic 问题（如命名、Magic Number），造成信噪比下降。修复：优先加载 Sonar 报告，应用 `sonar_overlap_filter`，仅输出工具盲点和业务上下文专属 finding。
2. **过度泛化** — 把所有单实现接口都标为 over-engineering，忽略测试替身、DI 和插件扩展等合法意图。修复：检查接口是否有测试双胞胎、是否在 DI 容器中注册多次；无明确反例时不标为债务。
3. **阈值来源不透明** — 使用 skill 默认阈值（圈复杂度 >10）但未声明，用户以为是项目标准。修复：始终在 `active_thresholds[]` 中写明 `threshold_source: skill_default` 或 `project_defined`。

## Event publication and N210 aggregation

This skill is a sub-skill of the N210 · 代码质量静态检查 node. It does **not** publish a produced event independently to the event bus.

**How events are published:**
1. This skill outputs its findings with stable `finding_id` values and a populated `downstream_handoff` block.
2. `code-standard-check` (running in `node_aggregation` mode) collects findings from all N210 sub-skills via `source_findings[]`.
3. After aggregation, `code-standard-check` publishes `produced.n210.code_quality_static_check.completed` to the event bus, which triggers N330, N370, N390 subscribers.

**Implication for standalone use:** when this skill is used outside the N210 workflow, callers are responsible for emitting any required produced event.

## SLA escalation to N380

When this skill emits findings with `severity: critical` (P0) or `severity: high` (P1):
- Include `sla_escalation_hint: true` in the finding's `downstream_handoff`.
- Downstream `code-standard-check` aggregator will propagate this flag to N380 · 平台门禁与人工协同 for SLA queue entry.
- Do not attempt to directly invoke N380 from within this skill.

```yaml
# Example finding with escalation hint
finding_id: TXNBC-001
severity: critical
sla_escalation_hint: true
escalation_reason: "Missing rollback on exception path in payment service"
recommended_human_action: "Review transaction boundary before merge"
```

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.


## Machine-readable SLA escalation rule

- `R_SLA_01`: Any finding with `severity: critical` MUST include `sla_escalation_hint: true`; `on_violation: warn`.
- `R_SLA_02`: Any finding with `severity: high` SHOULD include `sla_escalation_hint: true`; `on_violation: warn`.

## Reference files / reference files
- `references/lqcd-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/lqcd-self-check.yaml`: R01-R10 机读门禁规则
- `references/lqcd-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/detector-boundary.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
