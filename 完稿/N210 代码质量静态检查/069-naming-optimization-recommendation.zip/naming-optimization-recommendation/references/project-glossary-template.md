# Project glossary template

Use this template when a user provides inline glossary content or asks what counts as an equivalent project glossary.

## Minimum viable glossary

A glossary is sufficient for verified naming alignment when each important term has:

| field | required | meaning |
|---|---|---|
| canonical_term | yes | preferred project term, lower camel or domain noun form |
| definition | yes | business or technical meaning |
| allowed_synonyms | optional | accepted synonyms that should not be flagged |
| forbidden_synonyms | optional | terms that should be renamed to the canonical term |
| abbreviation_policy | optional | allowed or forbidden abbreviations |
| examples | optional | valid class, method, field, or API names |
| owner | optional | product, domain, or architecture owner |

## CSV shape

```csv
canonical_term,definition,allowed_synonyms,forbidden_synonyms,abbreviation_policy,examples,owner
order,commercial order created by checkout,,purchase|trade,no abbreviations,OrderService|createOrder,commerce
customer,end user who owns an account,user,client|member,cust forbidden,CustomerProfile|findCustomer,identity
```

## Markdown shape

```markdown
| canonical_term | definition | allowed_synonyms | forbidden_synonyms | abbreviation_policy | examples | owner |
|---|---|---|---|---|---|---|
| order | commercial order created by checkout |  | purchase, trade | no abbreviations | OrderService, createOrder | commerce |
```

## Degradation rule

If no glossary is available, keep general naming findings but set `readiness: constrained` and `glossary_alignment.status: constrained_missing_glossary`.
Do not claim glossary conflicts without a glossary-backed canonical term.
