# N210 shared contract v1

## Minimum input policy

Every skill must run on at least one of: code snippet, single file, git diff, repository path, or uploaded project archive. Workflow context improves confidence but is not required for standalone use. Missing context sets `readiness: constrained`; missing code sets `readiness: blocked`.

## Shared metadata

| field | rule |
|---|---|
| `selected_mode` | one allowed mode from SKILL.md |
| `readiness` | `pass`, `constrained`, or `blocked` |
| `evidence_profile` | `code_only`, `code_plus_design`, `code_plus_rules`, or `full_workflow_context` |
| `function_bias` | `direct_result` |
| `workflow_node` | `N210` in workflow, otherwise `standalone` |
| `node_artifact_target` | target artifact for this skill |
| `tool_collaboration_mode` | baseline-tool-complement, not baseline-tool-clone |

## Shared finding fields

| finding_id | source_skill | severity | confidence | location | issue_kind | evidence | recommendation | linked_rules | linked_nfr | related_standard_check_ids |
|---|---|---|---|---|---|---|---|---|---|---|

## Cross-skill rules

- `code-standard-check` is the baseline. Other skills consume `代码规范检查单.csv` when available and populate `related_standard_check_ids`.
- `refactoring-recommendation` is the integrator. It must populate `source_findings[]` with `source_skill`, `source_id`, `source_artifact`, and `reason_used`.
- `null-exception-risk-detection`, `transaction-boundary-check`, and `thread-safety-risk-check` emit rows compatible with `风险检查清单.csv`.
- Do not duplicate another skill's finding. Reference it and add only the analysis owned by this skill.


## Self-contained packaging note
This shared contract is intentionally duplicated inside each uploaded skill so every skill remains independently installable. Treat the copies as synchronized canonical content for the N210 node.

## Risk checklist aggregation strategy v2 (added v2.4)

Three N210 skills (`null-exception-risk-detection`, `thread-safety-risk-check`, `transaction-boundary-check`) all declare
`node_artifact_target: 风险检查清单.csv` and contribute rows to the same csv file. To prevent id collisions and
file overwrites when these skills run independently or in parallel, the following protocol is mandatory:

### Per-skill row prefix

| skill | finding_id prefix |
|---|---|
| `null-exception-risk-detection` | `npe.` |
| `thread-safety-risk-check` | `tsr.` |
| `transaction-boundary-check` | `txn.` |

Each skill's `finding_id` must be `<prefix><sequence>` (e.g., `npe.0042`, `tsr.0007`, `txn.0019`).

### File write protocol

- `aggregation_strategy: append_with_skill_prefix`
- `shared_artifact_role: contributor` (no single skill owns the file)
- When run standalone: each skill emits its own rows file or extracts rows from `风险检查清单.csv` matching its prefix
- When run in N210 workflow: the orchestrator (or `code-standard-check` in `node_aggregation` mode) merges all 3 contributors' rows into the canonical csv, validates no prefix collisions, and emits `produced.n210.risk_checklist`

### Conflict resolution

- Two contributors flagging the same code location with different concerns → both rows preserved (different `issue_kind`)
- Two contributors using the same prefix → reject; this is a contract violation
- A contributor missing its prefix → reject; row must be normalized before merging
