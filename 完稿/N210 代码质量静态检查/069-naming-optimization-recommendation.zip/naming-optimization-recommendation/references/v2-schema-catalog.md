# V2 schema catalog

This file is the enum and field source of truth. `naming-dictionary-policy.md` gives narrative rules.

## issue_kind values
- vague
- ambiguous
- semantic_mismatch
- inconsistent_with_glossary
- abbreviation_unclear
- abbreviation_inconsistent
- naming_style_inconsistent
- misleading_prefix
- too_long
- too_short
- single_letter
- plural_singular_mix

## method_prefix_semantics
- get: single cheap query, returns value or throws, no state mutation.
- find: lookup may be absent, Optional or nullable.
- fetch: remote/heavy lookup, cost implied.
- list: multiple results or page.
- count: numeric count.
- exists/is/has/can: boolean existence or capability.
- create/make/build: create object.
- save/persist: persist object.
- update: partial update.
- replace: full replacement.
- delete/remove: delete.
- invoke/execute/run: execute.
- compute/calculate: pure calculation.
- convert/transform/map: conversion.
- of/from: static factory.
- to: convert to target type.

## required fields
- `semantic_analysis`: actual_behavior, name_implies, mismatch_rationale.
- `glossary_alignment`: status, glossary_term, used_synonyms, recommendation.
- `rename_impact`: references_count, cross_file, breaking_api, migration_required, estimated_effort_pd.
- `suggested_names[]`: new_name, rationale, preferred.
