# naming-optimization-recommendation 常见失败模式 v2.4

## 通用部分（F1-F4）

### F1. 把推断包装成确定事实

**症状**：标 `breaking_change: false` 但实际 rename 影响外部 API；或反之

**影响**：用户误以为安全合并，结果断了 client；信任崩溃

**修正**：external_api_impact 字段必填；rename 涉及 public/protected 方法时默认 breaking_change: true 直到证明否

---

### F2. 没有位置或范围仍给强结论

**症状**：rename 建议仅写 "建议改为 X"，没有说原方法在哪

**影响**：无法定位；人工搜索全工程

**修正**：old + new + location.file:line 三件套必填

---

### F3. 同类问题机械穷举

**症状**：对项目所有 snake_case 方法都列一条 rename；100 个方法 100 条

**影响**：用户淹没；忽略真正重要的命名问题（如 glossary 冲突）

**修正**：项目命名规范一致问题应输出 1 条 policy-level finding + 全量列表，不展开成 100 条

---

### F4. 只说问题不说原因或建议

**症状**：建议改名但不说为什么；不说 rename 后的影响

**影响**：用户接受改动后才发现 caller 没改、序列化字段名变了

**修正**：evidence (为什么) + impact_propagation (callers/serialization/breaking_change) 必填

---

## 本 skill 重点（F5-F8）

### F5. 误标行业惯例缩写

**症状**：把 ID、URL、HTTP、JSON、XML、SQL、IO、DB、API 等行业标准缩写标为命名违规，建议改为 Identifier / UniformResourceLocator 等。

**影响**：建议愚蠢化；用户失去信任；产出价值清零。

**修正**：
- abbreviation_policy.allowed 必填，覆盖至少这 9 个行业标准缩写。
- 检查项目 glossary，团队自定义的缩写（如 SKU、DTO、PO）也加入 allowed。
- 仅对 ambiguous 缩写（Srvc、Mgr、Cnt、Usr）输出 finding。

---

### F6. rename 破坏 API 契约但未标 breaking_change

**症状**：建议把 controller 方法 `getUserList` 改名为 `findUsers`，但这个方法是 REST endpoint 路径的一部分（`@GetMapping("/users") public ... getUserList`）。

**影响**：客户端调用 `/users` 仍工作，但若未来基于 method name 自动生成路径会断；或 OpenAPI 生成的 SDK 失效。

**修正**：
- 检测方法上的 `@GetMapping`/`@PostMapping`/`@RequestMapping` 注解；含此类注解的方法 rename 默认 breaking_change: true。
- 检测 `@JsonProperty`/`@SerializedName`，序列化层名称受 rename 影响。
- 检测 RPC 接口（gRPC stub、Dubbo @DubboService）。

---

### F7. 跨仓库 rename 但未标 cross_repo_impact

**症状**：rename 一个 SDK / common-lib 中的类，但调用方分布在 5+ 个其他仓库；推荐里只标 `affected_callers: 12`（仅本仓库的）。

**影响**：用户实施 rename 后，CI 在依赖仓库失败；工作量低估 5-10 倍。

**修正**：
- 检测项目是否是 library（含 publishToMavenLocal / npm publish），是则提示 cross_repo_impact: unknown，建议人工评估外部消费者。
- 提供 deprecation_path：保留旧名 + @Deprecated，让外部仓库平滑迁移。

---

### F8. 把 get/find/load 互换没有语义增益

**症状**：建议 `getUserById` -> `retrieveUserById` 或 `obtainUserById`；这种改名没有语义增益，仅词汇替换。

**影响**：用户消费疲劳；发现建议没价值；信任下降。

**修正**：
- 仅在前缀语义错配时建议 rename（如方法做 IO 但用 get_X，应改为 load_X / fetch_X）。
- 单纯词汇替换（synonyms swap）不输出 finding。
- method_prefix_chart 必须明确每个前缀的语义边界。

