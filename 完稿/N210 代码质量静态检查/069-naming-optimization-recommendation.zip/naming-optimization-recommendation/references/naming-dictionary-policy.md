# Naming dictionary policy

Use this policy for narrative judgment; `v2-schema-catalog.md` contains the stable issue_kind and prefix enums.

## Required context
- A project glossary is required for verified `glossary_alignment`.
- Without a glossary, set `readiness: constrained` and mark glossary checks as `not_evaluated`, while still giving general naming findings.

## Naming baseline
- variables and fields: camelCase.
- constants: UPPER_SNAKE_CASE.
- classes and interfaces: PascalCase nouns; interfaces should not hide behavior behind vague names.
- methods: verb-first and behavior-aligned.
- boolean names: `is`, `has`, `can`, or `should` when practical.
- collections: plural nouns or explicit collection suffix, but avoid mixing singular/plural semantics.

## Prefix semantics
- `get`: cheap single-object retrieval, returns value or throws, should not mutate state.
- `find`: lookup that may be absent, usually Optional or nullable.
- `fetch`: remote/heavy lookup, cost or latency is implied.
- `list`: returns multiple values or a page.
- `count` and `exists`: numeric or boolean existence checks.
- `create`, `build`, `make`: create new object; `save`/`persist`: store it.
- `update`: partial update; `replace`: full replacement; `delete`/`remove`: delete/remove.
- `compute`/`calculate`: pure calculation; `convert`/`transform`/`map`: type conversion.
- `of`/`from`: static factory; `to`: convert to target type.

## Abbreviations
Allowed common abbreviations: id, url, uri, uuid, http, json, xml, sql, api, db, jwt, dto, vo, ui, io.
Discourage unclear abbreviations such as mgr, util, tmp, data, info, handler unless the project glossary explicitly allows them.
