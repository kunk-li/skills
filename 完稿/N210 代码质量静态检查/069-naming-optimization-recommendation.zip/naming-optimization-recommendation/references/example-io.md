# Example IO: naming-optimization-recommendation

## Scenario A: Standalone naming review

### Input

```java
// existing code
public class UserSrvc {  // abbreviation: srvc
    public User getUserData(Long usrId) { ... }    // mixed: usrId vs userId elsewhere
    public List<Order> findOrders(Long userId) { ... }  // returns from cache, name says "find"
    public Optional<User> getUser(Long id) { ... }  // returns Optional but called as get
    public String getUserName(Long userId) {       // hits database; should be "load" or "fetch"
        return userRepository.findById(userId).map(User::getName).orElse(null);
    }
}
```

User input: glossary.md exists with terms `User`, `Order` (no `Usr` allowed).

### Output

```yaml
artifact_contract:
  schema_version: n210.naming-optimization-recommendation.v2.4
  produced_by: naming-optimization-recommendation
  selected_mode: glossary_aligned_review
  readiness: pass
  evidence_profile: code_plus_glossary

abbreviation_policy:
  allowed: [ID, URL, HTTP, JSON, XML, SQL, IO, DB, API]  # industry standards
  forbidden: [Srvc, Usr, Mgr, Cnt]  # ambiguous abbreviations
  glossary_source: docs/glossary.md

renames:
  - finding_id: NAME-001
    rename_kind: class_abbreviation
    severity: high
    old: UserSrvc
    new: UserService
    location: {file: UserSrvc.java, line: 1}
    glossary_violation: "Srvc not in allowed abbreviations; glossary defines 'Service' canonical"
    impact_propagation:
      affected_callers: 23
      subclass_overrides: []
      serialization_impact: none
      external_api_impact: none  # internal class name
    breaking_change: false
    deprecation_path:
      - introduce UserService extends UserSrvc
      - deprecate UserSrvc with @Deprecated(since="2.4", forRemoval=true)
      - remove UserSrvc in v2.6 (after 2 release cycles)
    
  - finding_id: NAME-002
    rename_kind: parameter_consistency
    severity: medium
    old: usrId
    new: userId
    inconsistent_abbreviations:
      - {form: usrId, occurrences: 1, location: UserSrvc.java:3}
      - {form: userId, occurrences: 47, location: multiple}
    unify_to: userId  # majority + glossary-aligned
    impact_propagation:
      affected_callers: 1
    breaking_change: false
    
  - finding_id: NAME-003
    rename_kind: method_prefix_semantics
    severity: high
    old: findOrders
    new: getOrdersFromCache  # OR: cacheService.getOrders depending on architecture
    semantic_mismatch: "method named 'find' implies query, but reads from cache (no IO). Caller may falsely assume DB hit"
    method_prefix_chart:
      get_X: "in-memory access, no IO, returns non-Optional, raises if missing"
      find_X: "may IO, returns Optional, no exception on missing"
      load_X: "explicit IO (DB/network), returns non-Optional, raises if missing"
      fetch_X: "explicit IO from external service, returns non-Optional"
      query_X: "complex DB query, may return list/aggregate"
    recommendation_choice: "rename to getOrdersFromCache to make caching explicit"
    
  - finding_id: NAME-004
    rename_kind: optional_return_signal
    severity: medium
    old: getUser(Long id) -> Optional<User>
    new: findUser(Long id) -> Optional<User>
    semantic_mismatch: "get_X by convention should not return Optional; find_X signals optionality"
    
  - finding_id: NAME-005
    rename_kind: io_intent_signal
    severity: medium
    old: getUserName(Long id)
    new: loadUserName(Long id)
    semantic_mismatch: "getX implies cheap in-memory; this method does DB lookup"
    impact_propagation:
      affected_callers: 12
      external_api_impact: "if exposed as REST endpoint, breaks API contract"
      breaking_change: true
      cross_repo_impact: 3
      mitigation: "deprecate getUserName, add loadUserName, remove after 2 releases"
```

### Self-score

```yaml
self_score:
  glossary_alignment: 3        # all renames cite glossary or explicit reason
  impact_propagation: 3        # callers + serialization + cross-repo analyzed
  method_prefix_semantics: 3   # get/find/load/fetch chart applied
  abbreviation_consistency: 3  # policy declared, forbidden + allowed lists
  total: 12
  band: S+
```

---

## Scenario B: Glossary missing

When `glossary.md` is unavailable, `readiness: constrained` and rename suggestions go to `pending_glossary_review[]`.

---

## Common readiness states

| readiness | when |
|---|---|
| `pass` | code + glossary available |
| `constrained` | code only; rely on industry conventions |
| `blocked` | only descriptions |
