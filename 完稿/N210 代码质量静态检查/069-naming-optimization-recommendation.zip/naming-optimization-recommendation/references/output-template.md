# Output template: workflow-aligned naming optimization report

Required sections:
1. metadata
2. naming_policy_summary
3. glossary_alignment
4. naming_issues[]
5. semantic_conflicts[]
6. rename_batches[]
7. self_check

Issue fields:
| naming_id | severity | confidence | symbol_kind | current_name | suggested_name | location | issue_kind | glossary_term | evidence | rename_scope | recommendation | related_standard_check_ids | source_skill |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Allowed `issue_kind` values: vague, ambiguous, semantic_mismatch, inconsistent_with_glossary, abbreviation_unclear, abbreviation_inconsistent, naming_style_inconsistent, misleading_prefix, too_long, too_short, single_letter, plural_singular_mix.

`glossary_alignment` fields: status (verified, constrained_missing_glossary, not_applicable), glossary_term, used_synonyms[], recommendation.

`semantic_analysis` fields: actual_behavior, name_implies, mismatch_rationale.

`rename_impact` fields: references_count, cross_file, breaking_api, migration_required, estimated_effort_pd.

Cross-skill fields: all rows should include `confidence`, `related_standard_check_ids`, and `source_skill` when applicable.
