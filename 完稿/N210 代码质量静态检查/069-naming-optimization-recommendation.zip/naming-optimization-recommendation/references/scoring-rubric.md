# naming-optimization-recommendation 评分标准 v2.4

## 总览

输出按 4 个维度评分，每维 0-3 分，总分 0-12。

| 总分 | 等级 | 含义 |
|---|---|---|
| 11-12 | **S** | 可直接消费 |
| 9-10 | **A** | 生产可用 |
| 6-8 | **B** | 需人工修订 |
| ≤5 | **C** | 不建议消费 |

---

## 维度 1: 词汇库对齐 (glossary_alignment)

衡量: 命名建议是否与团队术语表/领域词汇对齐.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% rename 建议引用 glossary entry (term + definition + canonical_form), 不存在的术语进 pending_glossary[]. 含 deprecation 路径 (旧名 -> 新名 + 兼容期) |
| **A (2)** | ≥80% 引用 glossary, 余下基于通用命名规范 |
| **B (1)** | 仅基于通用规范 (camelCase/snake_case), 未对齐 glossary |
| **C (0)** | 建议与现有 glossary 冲突且未声明 |

---

## 维度 2: 影响范围与传播链 (impact_propagation)

衡量: rename 建议是否分析了所有 caller / subclass / serialization 影响.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% rename 含 affected_callers[]、subclass_overrides[]、serialization_impact (JSON 字段名/数据库列名/事件 schema)、external_api_impact (是否破坏 API 契约) |
| **A (2)** | ≥80% rename 含 callers + serialization_impact, 少量缺 subclass 分析 |
| **B (1)** | 仅给 caller 计数, 未分析序列化影响 |
| **C (0)** | 未分析影响范围 -> 误用风险 |

---

## 维度 3: 方法前缀语义 (method_prefix_semantics)

衡量: 是否纠正方法前缀语义错配 (e.g. get/find/fetch/load 区分).

| 等级 | 标准 |
|---|---|
| **S (3)** | 检测 get_X 但内部含 IO -> 建议 fetch_X / load_X; find_X 返回 Optional 但调用方未处理 null -> 建议改 require_X 或 get_X_or_null. 含语义对照表 |
| **A (2)** | 主要前缀错配纠正, 但未给完整语义对照 |
| **B (1)** | 仅做命名格式纠正, 未做语义层 |
| **C (0)** | 把 get_X 改成 retrieve_X 这种无语义增益的建议 |

---

## 维度 4: 缩写与一致性 (abbreviation_consistency)

衡量: 处理缩写规范化 + 项目内一致性.

| 等级 | 标准 |
|---|---|
| **S (3)** | 输出 abbreviation_policy (允许集 + 禁用集), 检测 inconsistent_abbreviations[] (e.g. usrId vs userId), 给出 unify_to 建议 |
| **A (2)** | 检测主要不一致, 但未输出完整 policy |
| **B (1)** | 仅检测部分缩写问题 |
| **C (0)** | 把所有缩写都视为问题, 误标 ID/URL/HTTP 等行业惯例 |

---

## 红线 (违反则直接归 C 或 0)

- 把行业惯例缩写 (ID, URL, HTTP, JSON, XML, SQL) 标为命名违规 -> 信号差
- rename 建议会破坏外部 API 契约但未标 breaking_change -> 严重错误
- rename 跨越多个仓库但未标 cross_repo_impact -> 工作量低估

---

## 等级映射示例

- **S+ (12)**: 全部 rename 引用 glossary + 影响完整 + 含 prefix 语义纠正 + 一致性 policy
- **S (11)**: 3 维满分 + 1 维 A
- **A (9-10)**: glossary 对齐但缺 subclass / serialization 分析
- **B (6-8)**: 仅命名格式层, 未做语义层
- **C (<6)**: 误标行业惯例 / 未分析影响

---

## 自评示例

```yaml
self_score:
  glossary_alignment: 3
  impact_propagation: 2
  method_prefix_semantics: 3
  abbreviation_consistency: 3
  total: 11
  band: S
  rationale: 3 条 rename 含 callers 但缺 subclass overrides 分析
```
