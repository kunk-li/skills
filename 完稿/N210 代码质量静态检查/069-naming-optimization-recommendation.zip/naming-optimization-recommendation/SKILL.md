---
name: naming-optimization-recommendation
description: analyze code, diffs, files, apis, or repositories for naming clarity, glossary alignment, method-prefix semantics, abbreviation policy, and rename impact. use for standalone naming review or n210 code-quality static checks that need naming optimization linked to standards and safe rename scope.
---
# naming-optimization-recommendation

## Role / role positioning
优化命名语义、glossary 对齐和 rename 影响. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `命名优化建议.md`.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- dictionary_mode
- conflict_scan
- bulk_rename

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### glossary requirement
- For verified glossary alignment, glossary from N070 or an equivalent project glossary is required.
- If glossary is missing, set `readiness: constrained`, keep generic naming findings, and mark `glossary_alignment.status: constrained_missing_glossary`.
- If the user provides inline terms instead of a file, normalize them using `references/project-glossary-template.md` before judging glossary alignment.

### workflow-aligned preferred inputs
- source code / diff / repository
- glossary from N070
- coding conventions and abbreviation dictionary
- module boundaries from N140
- 代码规范检查单.csv from code-standard-check when available

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.naming_optimization_recommendation`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 命名优化建议.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- naming_policy_summary
- naming_issues[]
- semantic_conflicts[]
- rename_batches[]
- glossary_alignment
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.

## Reference files / reference files
- `references/naming-dictionary-policy.md`
- `references/project-glossary-template.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
