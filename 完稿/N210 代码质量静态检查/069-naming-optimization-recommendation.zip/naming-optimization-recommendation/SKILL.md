---
name: naming-optimization-recommendation
description: Review code, diffs, or APIs for naming clarity — glossary alignment, method-prefix semantics, abbreviation policy, rename impact, and safe rename scope linked to standards.
---
# naming-optimization-recommendation

## Role / role positioning
优化命名语义、glossary 对齐和 rename 影响. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `命名优化建议.md`.

## Boundary / 边界
- 负责检查标识符命名清晰度、词汇表对齐、方法前缀语义和缩写策略。
- 负责评估重命名影响范围（public API vs 内部）。
- 不负责代码结构或逻辑质量；仅关注命名。
- 不替代 IDE 自动重命名工具；提供决策依据，执行由开发者完成。

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- dictionary_mode
- conflict_scan
- bulk_rename


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 代码 + glossary + 命名规范 + caller 分析能力 全部齐备 | 完整 rename + impact_propagation + breaking_change 标注 |
| `provisional` | 代码齐备但 glossary 缺失 | 基于行业惯例输出，glossary 对齐进 pending_glossary[] |
| `constrained` | 仅有部分代码，跨仓库 caller 分析受限 | 仅输出本仓库内可分析的 rename，cross_repo 进 pending |
| `blocked` | 仅有命名风格抱怨，无具体代码 | 输出 `request_for_inputs[]` |

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### glossary requirement
- For verified glossary alignment, glossary from N070 or an equivalent project glossary is required.
- If glossary is missing, set `readiness: constrained`, keep generic naming findings, and mark `glossary_alignment.status: constrained_missing_glossary`.
- If the user provides inline terms instead of a file, normalize them using `references/project-glossary-template.md` before judging glossary alignment.

### workflow-aligned preferred inputs
- source code / diff / repository
- glossary from N070
- coding conventions and abbreviation dictionary
- module boundaries from N140
- `接口设计草案.yaml` from N150 — **API JSON key vs Java field naming consistency**: flag mismatches between `@JsonProperty` / camelCase field names and JSON key names in the OpenAPI spec
- `表结构设计草案.sql` from N160 — **DB column vs Java field naming consistency**: flag `snake_case` column names that do not map cleanly to `camelCase` fields (e.g. missing `@Column(name=...)`, inconsistent abbreviation expansion)
- 代码规范检查单.csv from code-standard-check when available

### DB and API naming consistency checks

When `接口设计草案.yaml` or `表结构设计草案.sql` are provided, output a `cross_layer_naming_matrix[]`:

```yaml
cross_layer_naming_matrix:
  - layer_pair: "java_field <-> json_key"
    java_name: "userId"
    api_name: "user_id"   # mismatch — snake_case in API, camelCase in Java without @JsonProperty
    mismatch: true
    severity: medium
    fix: "Add @JsonProperty(\"user_id\") or align naming convention"
  - layer_pair: "java_field <-> db_column"
    java_name: "createdAt"
    db_column: "gmt_create"   # non-standard prefix pattern
    mismatch: true
    severity: low
    fix: "Add @Column(name=\"gmt_create\") and document convention"
```

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.naming_optimization_recommendation`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 命名优化建议.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- naming_policy_summary
- naming_issues[]
- semantic_conflicts[]
- rename_batches[]
- glossary_alignment
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Tech stack adapter / 技术栈适配

本 skill 支持多语言代码输入。检测规则按语言自动切换：

| 语言 | 主要检测适配 |
|---|---|
| Java/Spring | Spring Bean 生命周期、JPA 注解、@Transactional 语义 |
| TypeScript/JavaScript | async/await 安全、类型断言风险、null 合并 |
| Python | None 检查、Optional 类型、异常链 |
| Go | error 返回值忽略、goroutine 泄漏、nil 解引用 |
| Kotlin | Kotlin 空安全 !! 滥用、协程作用域泄漏 |

当语言未声明时：从文件扩展名或语法特征推断；推断结果记入 `inferred[]`。

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.


## Common failure modes

1. **glossary 缺失时仍给出对齐违规** — 在没有项目 glossary 的情况下声称命名与 glossary 不一致。修复：缺少 glossary 时 `glossary_alignment.status: constrained_missing_glossary`，不输出基于 glossary 的违规 finding。
2. **rename 影响范围低估** — 只给出字段名改动建议，未评估跨层影响（JSON API key、DB column、前端 binding）。修复：每条 rename 建议必须输出 `cross_layer_impact[]`；跨层影响未知时标 `rename_safe: unknown` 并建议先运行 cross_layer_naming_matrix 检查。
3. **批量 rename 无序** — 在 `bulk_rename` 模式下输出多个 rename 但未给出执行顺序，导致重命名冲突。修复：`rename_batches[]` 必须包含 `execution_order` 和冲突检测结果。

## Event publication and N210 aggregation

This skill is a sub-skill of the N210 · 代码质量静态检查 node. It does **not** publish a produced event independently to the event bus.

**How events are published:**
1. This skill outputs its findings with stable `finding_id` values and a populated `downstream_handoff` block.
2. `code-standard-check` (running in `node_aggregation` mode) collects findings from all N210 sub-skills via `source_findings[]`.
3. After aggregation, `code-standard-check` publishes `produced.n210.code_quality_static_check.completed` to the event bus, which triggers N330, N370, N390 subscribers.

**Implication for standalone use:** when this skill is used outside the N210 workflow, callers are responsible for emitting any required produced event.

## SLA escalation to N380

When this skill emits findings with `severity: critical` (P0) or `severity: high` (P1):
- Include `sla_escalation_hint: true` in the finding's `downstream_handoff`.
- Downstream `code-standard-check` aggregator will propagate this flag to N380 · 平台门禁与人工协同 for SLA queue entry.
- Do not attempt to directly invoke N380 from within this skill.

```yaml
# Example finding with escalation hint
finding_id: TXNBC-001
severity: critical
sla_escalation_hint: true
escalation_reason: "Missing rollback on exception path in payment service"
recommended_human_action: "Review transaction boundary before merge"
```

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.


## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Produced event / 产物事件

当作为 N210 工作流节点的子技能执行时，本 skill 的产物通过以下事件元数据向下游声明可用性：

```yaml
event_emission:
  emitted_by: standalone_skill  # 本 skill 不自行发布节点级事件
  node_event_publisher: code-standard-check  # N210 唯一事件发布者（node_aggregation 模式）
  artifact_ready_signal: artifact_contract.readiness in [pass, provisional]
  downstream_consumers: [N220, N240, N260, N330, N370, N390]
  finding_contribution:
    target_artifact: "命名优化建议.md"
    finding_id_prefix: "SEE_SKILL_SELF_CHECK"
```

在 standalone 模式下：直接输出发现列表，无需声明节点事件；节点级事件由 `code-standard-check` 的 `node_aggregation` 模式统一发布。

## Machine-readable self_check rules

- `R01_mode_declared`: `selected_mode` 必须是 `dictionary_mode | conflict_scan | bulk_rename` 之一; `on_violation: reject`
- `R02_finding_id_stable`: 每条 finding 必须有格式为 `NMG-{LAYER}-{NNN}` 的稳定 `finding_id`; `on_violation: reject`
- `R03_severity_set`: `severity` 必须是 `critical | high | medium | low | info` 之一; `on_violation: reject`
- `R04_sla_hint_critical`: `severity: critical` 必须附 `sla_escalation_hint: true`; `on_violation: reject`
- `R05_glossary_status_declared`: 无 glossary 输入时必须设 `glossary_alignment.status: constrained_missing_glossary`，不得输出基于 glossary 的违规; `on_violation: reject`
- `R06_cross_layer_matrix_on_input`: 提供 `接口设计草案.yaml` 或 `表结构设计草案.sql` 时必须生成 `cross_layer_naming_matrix[]`; `on_violation: reject`
- `R07_rename_batch_ordered`: `bulk_rename` 模式下 `rename_batches[]` 必须包含 `execution_order` 字段; `on_violation: warn`
- `R08_cross_layer_impact_stated`: 每条 rename 建议必须声明 `cross_layer_impact[]` 或标 `rename_safe: unknown`; `on_violation: warn`
- `R09_downstream_handoff_present`: 必须输出 `downstream_handoff` 块; `on_violation: reject`

## Machine-readable SLA escalation rule

- `R_SLA_01`: Any finding with `severity: critical` MUST include `sla_escalation_hint: true`; `on_violation: warn`.
- `R_SLA_02`: Any finding with `severity: high` SHOULD include `sla_escalation_hint: true`; `on_violation: warn`.

## Reference files / reference files
- `references/naming-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/naming-self-check.yaml`: R01-R10 机读门禁规则
- `references/naming-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/naming-dictionary-policy.md`
- `references/project-glossary-template.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
