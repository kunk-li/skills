# Example IO: transaction-boundary-check

## Scenario A: Standalone transaction scan

### Input

```java
@Service
public class OrderService {
    @Transactional
    public void createOrder(OrderRequest req) {
        Order order = new Order();
        // ... persist order
        orderRepository.save(order);
        
        // (1) self-invocation: this.publishEvent loses transaction proxy
        this.publishEvent(order);
        
        // (2) external HTTP call inside transaction (long tx)
        riskService.checkRisk(req);  // RestTemplate call, ~500ms
        
        // (3) MQ send inside transaction
        kafkaTemplate.send("order.created", order);
        
        // (4) AFTER_COMMIT publish but in transactional method
        eventPublisher.publishEvent(new OrderCreatedEvent(order));
    }
    
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void publishEvent(Order order) {
        // intended to run in new tx, but called via this. -> proxy bypassed -> runs in caller's tx
    }
    
    @Transactional(rollbackFor = SQLException.class)
    public void updateOrder(Order order) {
        try {
            orderRepository.save(order);
        } catch (RuntimeException e) {
            // (5) RuntimeException caught and not rethrown -> rollback won't happen
            log.error("save failed", e);
        }
    }
    
    @Transactional(readOnly = true)
    public List<Order> findOrders(Long userId) {  // (6) readOnly is correct here
        return orderRepository.findByUserId(userId);
    }
    
    @Async
    public CompletableFuture<Void> asyncProcess(Order order) {
        // (7) @Async crosses thread boundary; @Transactional proxy doesn't propagate
        this.updateOrder(order);
    }
}
```

### Output

```yaml
artifact_contract:
  schema_version: n210.transaction-boundary-check.v2.4
  produced_by: transaction-boundary-check
  selected_mode: standalone_scan
  readiness: pass
  evidence_profile: code_only

risks:
  - finding_id: txn.0001
    severity: critical
    issue_kind: self_invocation_proxy_bypass
    location: {file: OrderService.java, line: 9}
    call_chain: [createOrder -> this.publishEvent]
    danger_explanation: "this.publishEvent() bypasses Spring AOP proxy. @Transactional(REQUIRES_NEW) is ignored; publishEvent runs in createOrder's tx. If createOrder rolls back, publishEvent's writes also roll back, contradicting the REQUIRES_NEW intent."
    fix_options:
      - choice: extract_to_new_service
        code: "Move publishEvent to EventPublishingService injected here; call eventPublishingService.publishEvent(order)"
        when_suitable: "preferred; respects single responsibility"
      - choice: self_inject
        code: "@Autowired private OrderService self; ... self.publishEvent(order);"
        when_suitable: "quick fix; proxy resolves correctly"
      - choice: applicationContext_lookup
        code: "applicationContext.getBean(OrderService.class).publishEvent(order)"
        when_suitable: "rarely; less idiomatic"
    recommended: extract_to_new_service
    testing_strategy:
      verification_hint: "integration test: throw exception after publishEvent; assert publishEvent's writes survived (separate tx)"

  - finding_id: txn.0002
    severity: critical
    issue_kind: long_transaction
    location: {file: OrderService.java, line: 12}
    danger_explanation: "RestTemplate call inside @Transactional. Connection pool: tx holds DB connection during HTTP wait (~500ms). 100 concurrent requests = 100 held connections."
    estimated_duration_ms: 500
    connection_pool_impact: "high; default HikariCP pool=10 -> 5x overload"
    fix_options:
      - choice: move_to_after_commit
        code: |
          @TransactionalEventListener(phase = AFTER_COMMIT)
          public void onOrderCreated(OrderCreatedEvent event) {
              riskService.checkRisk(event.getRequest());
          }
        when_suitable: "if risk check is post-creation enrichment, not gate"
      - choice: split_transaction
        code: "Move riskService.checkRisk OUTSIDE the @Transactional method; orchestrate at controller layer"
        when_suitable: "if risk check is gating (must pass before commit) but tolerable to call before tx start"
      - choice: outbox_pattern
        code: "Persist OrderRiskCheckPending; async worker calls riskService and updates"
        when_suitable: "high-throughput, eventually-consistent"
    recommended: split_transaction
    
  - finding_id: txn.0003
    severity: high
    issue_kind: mq_send_in_transaction
    location: {file: OrderService.java, line: 14}
    danger_explanation: "kafkaTemplate.send() inside transaction: message could be sent to Kafka, but transaction rolls back, leaving consumers seeing phantom event."
    fix_options:
      - choice: outbox_pattern
        code: "Persist OutboxEvent in same tx; separate poller publishes to Kafka after"
        when_suitable: "preferred for production"
      - choice: kafka_transactional
        when_suitable: "if Kafka producer integrated with tx manager (rare)"
      - choice: after_commit_listener
        code: "publish via @TransactionalEventListener(phase = AFTER_COMMIT)"
        when_suitable: "best-effort delivery acceptable"
    recommended: outbox_pattern
    
  - finding_id: txn.0004
    severity: high
    issue_kind: event_phase_unspecified
    location: {file: OrderService.java, line: 17}
    danger_explanation: "eventPublisher.publishEvent in @Transactional method. If listener has @TransactionalEventListener without phase, default is AFTER_COMMIT (good). But if listener uses @EventListener (synchronous), it runs IN the current tx and reads uncommitted data."
    fix_options:
      - choice: declare_phase_explicitly
        code: "@TransactionalEventListener(phase = AFTER_COMMIT)"
        when_suitable: "default for most cases"
      - choice: AFTER_ROLLBACK
        when_suitable: "compensating actions only"
    recommended: declare_phase_explicitly
    
  - finding_id: txn.0005
    severity: critical
    issue_kind: rollback_swallowed_exception
    location: {file: OrderService.java, line: 28}
    danger_explanation: "RuntimeException caught and logged; @Transactional default rolls back on RuntimeException, but caught exception suppresses rollback. Update may persist when it should not."
    fix_options:
      - choice: rethrow_after_log
        code: "log.error(...); throw e;"
        when_suitable: "default; honor original exception semantics"
      - choice: setRollbackOnly
        code: "TransactionAspectSupport.currentTransactionStatus().setRollbackOnly()"
        when_suitable: "if must continue but mark for rollback"
    recommended: rethrow_after_log
    
  - finding_id: txn.0006
    severity: critical
    issue_kind: async_proxy_bypass
    location: {file: OrderService.java, line: 41}
    danger_explanation: "@Async + this.updateOrder() = double proxy bypass. @Async runs on new thread (won't have tx context). @Transactional on updateOrder ignored due to self-invocation."
    fix_options:
      - choice: extract_async_service
        code: "create AsyncOrderService with @Async + @Transactional methods, inject and call"
        when_suitable: "preferred"
    recommended: extract_async_service
    
  # txn.0007 NOT a risk: line 32 readOnly=true is correct optimization

statistics:
  patterns_covered:
    self_invocation: 2          # txn.0001 + txn.0006 (async variant)
    propagation_mismatch: 0
    rollback_scope: 1           # txn.0005
    after_commit_phase: 1       # txn.0004
    long_transaction: 2         # txn.0002 + txn.0003 (MQ counts as IO)
    outbox_pattern: 1           # recommended in 0003
    readonly_misuse: 0          # 0 risks; 1 correct usage detected
  total_categories_covered: 5   # of 7
  
aggregation:
  shared_artifact_role: contributor
  aggregation_strategy: append_with_skill_prefix
  artifact: 风险检查清单.csv
  prefix: txn.
```

### Self-score

```yaml
self_score:
  transaction_pattern_coverage: 2  # 5/7 categories; missing propagation_mismatch and readonly_misuse (input had no examples)
  call_chain_proxy_analysis: 3     # both self-invocation AND async-proxy detected
  long_transaction_detection: 3    # IO (HTTP, MQ) detected with duration estimate + pool impact
  event_eventual_consistency: 3    # phase analysis + outbox recommendation
  total: 11
  band: S
```

---

## Common readiness states

| readiness | when |
|---|---|
| `pass` | full service code + tx config |
| `constrained` | only diff |
| `blocked` | only descriptions |
