# Transaction issue catalog

Use v2 TX identifiers exactly. This file gives narrative guidance; `v2-schema-catalog.md` is the enum source of truth.

| issue_kind | meaning | default severity | core evidence |
|---|---|---|---|
| TX-001_missing_transaction | multiple DB writes without a transaction | critical | two or more write operations without effective boundary |
| TX-002_transaction_on_public_only | annotation placed where proxy will not apply | high | private/protected/non-proxied method annotation |
| TX-003_self_invocation_no_proxy | same-class call bypasses proxy | critical | `this.method()` or direct same-class call to annotated method |
| TX-004_propagation_wrong | propagation does not match consistency intent | high | audit/notification/main transaction mismatch |
| TX-005_after_commit_event | event published before commit when after-commit is required | critical | event publication inside transaction before commit |
| TX-006_long_transaction | external call, slow query, huge batch, sleep, or user wait inside tx | high | lock-holding work inside transaction |
| TX-007_nested_rollback_issue | nested rollback behavior can surprise caller | high | NESTED/REQUIRES_NEW rollback handling unclear |

Every actionable finding should include before_code, after_code, risk_if_not_fixed, and affected_operations when evidence allows it.
