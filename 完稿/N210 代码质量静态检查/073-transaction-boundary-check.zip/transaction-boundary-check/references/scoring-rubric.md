# transaction-boundary-check 评分标准 v2.4

## 总览

输出按 4 个维度评分，每维 0-3 分，总分 0-12。

| 总分 | 等级 | 含义 |
|---|---|---|
| 11-12 | **S** | 可直接消费 |
| 9-10 | **A** | 生产可用 |
| 6-8 | **B** | 需人工修订 |
| ≤5 | **C** | 不建议消费 |

---

## 维度 1: 事务模式覆盖 (transaction_pattern_coverage)

衡量: 是否覆盖 7 大类事务边界风险.

| 等级 | 标准 |
|---|---|
| **S (3)** | 覆盖全部 7 类: (1) self-invocation (同类内部 this.method() 调用导致代理失效); (2) propagation 错配 (REQUIRED 内调用 REQUIRES_NEW 但未挂起); (3) rollback 范围 (RuntimeException vs checked Exception); (4) AFTER_COMMIT 事件未声明导致幻读; (5) 长事务 (内含外部 IO/HTTP/MQ); (6) outbox pattern 缺失; (7) read-only 误标. 每类 ≥1 finding |
| **A (2)** | 覆盖 5-6 类 |
| **B (1)** | 仅 3-4 类 |
| **C (0)** | 仅检测 @Transactional 缺失 |

---

## 维度 2: 调用链与代理分析 (call_chain_proxy_analysis)

衡量: self-invocation / 跨类调用代理失效检测的深度.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% finding 含 call_chain[] (调用栈), 检测 self-invocation 时同时给出 lambda / inner class / scheduled / async 调用路径 (4 类陷阱). 检测 final method @Transactional 失效 (CGLIB 限制) |
| **A (2)** | 主要 self-invocation 检出, 但未覆盖 lambda / async |
| **B (1)** | 仅检测同类直接 this.method() 调用 |
| **C (0)** | 未识别代理机制, 误把所有跨方法调用都标为有事务 |

---

## 维度 3: 长事务量化与外部 IO 检测 (long_transaction_detection)

衡量: 是否检出事务方法内的阻塞 IO 并量化.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% transaction method 扫描内部 IO 调用 (RestTemplate/WebClient/kafkaTemplate.send/S3Client/JdbcTemplate.queryForXxx), 标注 estimated_duration_ms + connection_pool_impact + 推荐拆分方式 (AFTER_COMMIT / outbox / 异步线程池) |
| **A (2)** | 检出主要外部 IO, 推荐拆分方式但缺时长估算 |
| **B (1)** | 仅检出 HTTP 调用, 未识别 MQ / S3 |
| **C (0)** | 未检测 IO -> 长事务风险被遗漏 |

---

## 维度 4: 事件与最终一致性 (event_eventual_consistency)

衡量: 处理 AFTER_COMMIT / outbox / saga 等最终一致性模式的成熟度.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% 事件发布点含 phase 标注 (BEFORE_COMMIT / IN_TX / AFTER_COMMIT / AFTER_ROLLBACK), 检测 AFTER_COMMIT + 数据已提交矛盾, 推荐 outbox pattern 替代直接 publish, 含 idempotency_key 设计建议 |
| **A (2)** | 主要 phase 错配检出, outbox 仅作为可选推荐 |
| **B (1)** | 仅识别 phase 标注缺失, 未推荐替代方案 |
| **C (0)** | 未识别事件与事务交互问题 |

---

## 红线 (违反则直接归 C 或 0)

- 把 readOnly=true 误标为风险 (它是优化提示, 非问题)
- 把所有 RuntimeException 标 rollback 风险但未识别 @Transactional(noRollbackFor=...) 显式声明
- 推荐用 PROPAGATION.NESTED 但项目使用 JPA (NESTED 仅在 JDBC 数据源生效) -> 错误建议
- finding_id 不含 txn. 前缀 -> aggregation 协议违反

---

## 等级映射示例

- **S+ (12)**: 7 类全覆盖 + 代理深度分析 + 长事务量化 + 事件成熟度
- **S (11)**: 3 维满分 + 1 维 A
- **A (9-10)**: 主要类覆盖, IO 检测但缺时长估算
- **B (6-8)**: 仅基础事务问题
- **C (<6)**: 未识别代理机制 / IO / 事件交互

---

## 自评示例

```yaml
self_score:
  transaction_pattern_coverage: 3
  call_chain_proxy_analysis: 3
  long_transaction_detection: 2
  event_eventual_consistency: 3
  total: 11
  band: S
  rationale: 长事务时长估算未含连接池影响量化, 已在 pending[] 列出
```
