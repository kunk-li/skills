# V2 schema catalog

This file is the enum and field source of truth. `transaction-issue-catalog.md` gives narrative detection guidance.

## transaction_issue_kind values
- TX-001_missing_transaction
- TX-002_transaction_on_public_only
- TX-003_self_invocation_no_proxy
- TX-004_propagation_wrong
- TX-005_after_commit_event
- TX-006_long_transaction
- TX-007_nested_rollback_issue

## propagation values
- REQUIRED
- REQUIRES_NEW
- NESTED
- MANDATORY
- SUPPORTS
- NOT_SUPPORTED
- NEVER

## isolation values
- DEFAULT
- READ_UNCOMMITTED
- READ_COMMITTED
- REPEATABLE_READ
- SERIALIZABLE

## large_transaction_issue_kind values
- external_http_call_in_tx
- slow_query_in_tx
- large_batch_in_tx
- user_interaction_in_tx
- thread_sleep_in_tx

## required fields
- `affected_operations[]`: operation, tx_participation.
- `after_commit_analysis`: applicable, events_detected[], risk, fix.
- `large_transaction_analysis`: tx_duration_estimate, detected_issues[], target_tx_duration.
- `remediation`: suggested_fix, before_code, after_code, risk_if_not_fixed, auto_fixable.
