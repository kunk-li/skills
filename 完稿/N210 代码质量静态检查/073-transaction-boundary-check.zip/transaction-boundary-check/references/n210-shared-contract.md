# N210 shared contract v1

## Minimum input policy

Every skill must run on at least one of: code snippet, single file, git diff, repository path, or uploaded project archive. Workflow context improves confidence but is not required for standalone use. Missing context sets `readiness: constrained`; missing code sets `readiness: blocked`.

## Shared metadata

| field | rule |
|---|---|
| `selected_mode` | one allowed mode from SKILL.md |
| `readiness` | `pass`, `constrained`, or `blocked` |
| `evidence_profile` | `code_only`, `code_plus_design`, `code_plus_rules`, or `full_workflow_context` |
| `function_bias` | `direct_result` |
| `workflow_node` | `N210` in workflow, otherwise `standalone` |
| `node_artifact_target` | target artifact for this skill |
| `tool_collaboration_mode` | baseline-tool-complement, not baseline-tool-clone |

## Shared finding fields

| finding_id | source_skill | severity | confidence | location | issue_kind | evidence | recommendation | linked_rules | linked_nfr | related_standard_check_ids |
|---|---|---|---|---|---|---|---|---|---|---|

## Cross-skill rules

- `code-standard-check` is the baseline. Other skills consume `代码规范检查单.csv` when available and populate `related_standard_check_ids`.
- `refactoring-recommendation` is the integrator. It must populate `source_findings[]` with `source_skill`, `source_id`, `source_artifact`, and `reason_used`.
- `null-exception-risk-detection`, `transaction-boundary-check`, and `thread-safety-risk-check` emit rows compatible with `风险检查清单.csv`.
- Do not duplicate another skill's finding. Reference it and add only the analysis owned by this skill.


## Self-contained packaging note
This shared contract is intentionally duplicated inside each uploaded skill so every skill remains independently installable. Treat the copies as synchronized canonical content for the N210 node.
