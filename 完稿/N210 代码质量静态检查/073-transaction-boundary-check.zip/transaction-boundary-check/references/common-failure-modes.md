# transaction-boundary-check 常见失败模式 v2.4

## 通用部分（F1-F4）

### F1. 把推断包装成确定事实

**症状**：标 self-invocation 风险但实际是跨 bean 调用，proxy 正常生效

**影响**：误报；用户拒绝；信任损失

**修正**：call_chain 必须从实际类型推断 proxy 是否生效；接口注入 vs 实现注入区别处理

---

### F2. 没有位置或范围仍给强结论

**症状**：finding 仅说 "事务边界有风险"，没有 call_chain

**影响**：人工无法判断 proxy 链路；fix 选项无法评估

**修正**：call_chain[] 含完整调用栈 + 每个调用点的 transaction context

---

### F3. 同类问题机械穷举

**症状**：对每个 @Transactional 方法都列一条 finding

**影响**：正常使用方法被列为风险；高风险点（self-invocation）被淹没

**修正**：仅输出实际有问题的 finding；正常 @Transactional 不出 finding

---

### F4. 只说问题不说原因或建议

**症状**：建议 "修复事务边界" 但不分场景

**影响**：用户不知道是该 self-inject、extract method、还是改 propagation

**修正**：fix_options 至少给 extract_to_new_service + self_inject + applicationContext_lookup 三种，含选择理由

---

## 本 skill 重点（F5-F8）

### F5. 把 readOnly=true 误标为风险

**症状**：`@Transactional(readOnly = true)` 被标为 "事务边界配置错误"。

**影响**：误报；readOnly=true 是性能优化提示，告诉 JPA 跳过 dirty check + 走 readonly replica，是好实践。

**修正**：
- readOnly=true 必须识别为 optimization hint，不是问题。
- 仅当 readOnly=true 但方法内含 INSERT/UPDATE/DELETE 时才输出 finding。

---

### F6. RuntimeException 被全部标 rollback 风险

**症状**：所有 @Transactional 方法被标 "RuntimeException 会触发 rollback，请检查"。

**影响**：噪声压倒信号；用户拒绝。

**修正**：
- 仅当方法内 catch RuntimeException 且不重抛 / 不调用 setRollbackOnly 时输出 finding。
- @Transactional(noRollbackFor = ...) 显式声明的 exception type 不输出 finding。

---

### F7. 推荐 PROPAGATION.NESTED 但项目使用 JPA

**症状**：fix_options 推荐 `@Transactional(propagation = NESTED)`，但项目使用 JPA / Hibernate。

**影响**：NESTED 仅在 JDBC DataSource 生效（依赖 SAVEPOINT）；JPA 中无效；用户实施后失败。

**修正**：
- 检测项目使用的事务管理器（JpaTransactionManager / DataSourceTransactionManager / JtaTransactionManager）。
- JPA 项目中不推荐 NESTED；推荐 REQUIRES_NEW + 拆分到独立 service。
- 在 fix_options 中标 platform_compatibility 字段。

---

### F8. finding_id 不含 txn. 前缀

**症状**：与 npe.* / tsr.* 共用 风险检查清单.csv，但 finding_id 仅 TXN-001。

**影响**：aggregation 时 id 冲突；node_aggregation 时无法精确合并。

**修正**：finding_id 必须 `txn.0001` 格式；aggregation_strategy 显式声明 append_with_skill_prefix。

