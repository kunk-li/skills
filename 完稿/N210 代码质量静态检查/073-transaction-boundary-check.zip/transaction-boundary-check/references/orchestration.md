# N210 orchestration contract

## Recommended order

1. `code-standard-check` establishes baseline rules and emits `STD-###` ids.
2. `low-quality-code-detection`, `duplicate-code-detection`, `null-exception-risk-detection`, `transaction-boundary-check`, and `thread-safety-risk-check` run in parallel.
3. `naming-optimization-recommendation` handles semantic naming and rename impact.
4. `refactoring-recommendation` consumes upstream ids through `source_findings[]`.
5. The node aggregator creates `N210_code_quality_report.md`.

## Hard handoff fields

| from | to | required field |
|---|---|---|
| `code-standard-check` | all other skills | `related_standard_check_ids[]` |
| diagnostics skills | `refactoring-recommendation` | `source_findings[]` |
| risk skills | N210 aggregator | `risk_handoff_bundle` |

## Ownership

Standards -> 075. Naming -> 069. Low-quality business context -> 070. Duplicate clusters -> 071. Null risks -> 072. Transaction risks -> 073. Thread-safety risks -> 074. Refactoring priorities -> 068.
