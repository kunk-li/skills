# N210 aggregation handoff

## Aggregation owner
Primary owner: `code-standard-check` when `selected_mode: node_aggregation`. Other N210 skills contribute source artifacts and should not claim final ownership unless the user explicitly asks a single skill to aggregate.

Target aggregate artifact: `N210_code_quality_report.md`.

Recommended sections: category statistics, top refactoring recommendations, business-rule/NFR gaps, duplicate-code opportunities, null/exception review, transaction review, thread-safety review, project-rule compliance, technical-debt register, gate decision.

Produced event:

```yaml
name: produced.n210.code_quality_static_check.completed
producer: N210
payload_schema: N210CodeQualityReport.v1
subscribers: [N220_code_review, N250_defect_management, N260_quality_gate, N370_skill_orchestration, N390_quality_scoring]
```

Technical-debt row: `debt_id`, `source_findings`, `category`, `severity`, `effort_minutes`, `risk_if_delayed`, `recommended_owner`, `target_sprint`.

## E2E validation protocol

Use this protocol when validating the N210 aggregation path end to end.

Input artifact bundle:
- `代码规范检查单.csv` from code-standard-check
- `重构建议.md` from refactoring-recommendation
- `命名优化建议.md` from naming-optimization-recommendation
- `低质量代码清单.csv` from low-quality-code-detection
- `重复代码清单.csv` from duplicate-code-detection
- `风险检查清单.csv` from null-exception-risk-detection, transaction-boundary-check, and thread-safety-risk-check

Acceptance checks:
1. Every aggregate row preserves source ids through `source_findings[]`, `risk_id`, `finding_id`, or `related_standard_check_ids`.
2. Severity values use the shared severity matrix and are not re-mapped silently.
3. `technical_debt_register` contains at least `debt_id`, `source_findings`, `category`, `severity`, `effort_minutes`, `risk_if_delayed`, and `recommended_owner`.
4. `gate_decision` states `pass`, `conditional_pass`, or `block` with reasons tied to source findings.
5. The produced event uses `N210CodeQualityReport.v1` and lists downstream subscribers without changing their names.
6. Missing optional input artifacts are declared in `readiness_notes`; they must not be hidden.

