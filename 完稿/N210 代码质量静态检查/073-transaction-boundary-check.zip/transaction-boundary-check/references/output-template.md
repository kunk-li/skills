# Output template: shared transaction risk contribution

Artifact target: risk checklist / 风险检查清单.csv

Required sections:
1. metadata
2. risk_summary
3. transaction_issue_catalog[]
4. propagation_findings[]
5. after_commit_findings[]
6. large_transaction_findings[]
7. remediation_examples[]
8. self_check

Risk fields:
| risk_id | severity | confidence | risk_family | transaction_issue_kind | location | propagation | isolation | affected_operations | evidence | before_code | after_code | risk_if_not_fixed | recommendation | linked_rules | linked_nfr | related_standard_check_ids | source_skill |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Allowed `transaction_issue_kind` values: TX-001_missing_transaction, TX-002_transaction_on_public_only, TX-003_self_invocation_no_proxy, TX-004_propagation_wrong, TX-005_after_commit_event, TX-006_long_transaction, TX-007_nested_rollback_issue.
Allowed `propagation` values: REQUIRED, REQUIRES_NEW, NESTED, MANDATORY, SUPPORTS, NOT_SUPPORTED, NEVER.
Allowed `isolation` values: DEFAULT, READ_UNCOMMITTED, READ_COMMITTED, REPEATABLE_READ, SERIALIZABLE.
Allowed large transaction issue values: external_http_call_in_tx, slow_query_in_tx, large_batch_in_tx, user_interaction_in_tx, thread_sleep_in_tx.

`remediation_examples[]` item fields: before_code, after_code, risk_if_not_fixed, auto_fixable.
Cross-skill fields: all rows should include `confidence`, `related_standard_check_ids`, and `source_skill` when applicable.
