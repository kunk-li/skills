---
name: transaction-boundary-check
description: Audit @Transactional scope, propagation, rollback policy, self-invocation AOP bypass, after-commit events, outbox compliance, silent exception swallowing, and missing readOnly optimizations.
---
# transaction-boundary-check

## Role / role positioning
检测事务边界、传播、回滚、自调用、AFTER_COMMIT 和大事务风险. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `风险检查清单.csv`.

## 使用场景 / When to use

**直接触发（standalone）：**
- 提供 Service 层代码，要求检查 @Transactional 使用是否正确
- 怀疑有 self-invocation（同类方法互调导致事务失效）
- 有 MQ 消息发布在事务内部，担心消息与数据不一致
- 需要确认异常回滚策略是否覆盖业务场景

**工作流触发（N210 节点）：**
- service-draft-generation 输出后，检查事务标注
- 代码 Review 前的事务一致性扫描

**不触发（边界外）：**
- 并发安全（锁、volatile）→ 使用 `thread-safety-risk-check`
- 查询性能 → 使用 `query-optimization-recommendation`

## Boundary / 边界
- 负责分析 @Transactional 传播、回滚策略、自调用绕过、after-commit 事件风险和长事务问题。
- 负责将 critical 级事务风险通过 `sla_escalation_hint` 上报。
- 不负责并发安全；由 `thread-safety-risk-check` 处理。
- 不负责数据库索引或查询优化；由 `query-optimization-recommendation` 处理。

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- propagation_only
- event_commit_check
- txn_size_estimate


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 代码 + 事务管理器配置 + 事件监听器配置 全部齐备 | 完整 7 类风险 + 代理深度分析 + outbox 推荐 |
| `provisional` | 代码齐备但事务管理器配置（JpaTransactionManager 等）未确认 | 输出 finding 但 platform-specific 建议进 pending |
| `constrained` | 仅有部分代码，self-invocation 跨文件分析受限 | 仅输出本文件内的事务问题 |
| `blocked` | 仅有项目描述，无代码 | 输出 `request_for_inputs[]` |

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- service-layer code from N190
- data flows from N160
- concurrency / idempotency / audit / event designs from N170
- 代码规范检查单.csv from code-standard-check when available

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.transaction_boundary_check`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 风险检查清单.csv`
  - `aggregation_strategy: append_with_skill_prefix`  # rows use prefix `txn.` to avoid id collisions across the 3 contributors
  - `shared_artifact_role: contributor`  # 3 skills contribute rows to the same csv
  - `evidence_profile`
  - `tool_collaboration_mode`
- risk_summary
- transaction_issue_catalog[]
- propagation_findings[]
- after_commit_findings[]
- large_transaction_findings[]
- remediation_examples[] with before_code, after_code, risk_if_not_fixed
- risk_handoff_bundle
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Tech stack adapter / 技术栈适配

本 skill 支持多语言代码输入。检测规则按语言自动切换：

| 语言 | 主要检测适配 |
|---|---|
| Java/Spring | Spring Bean 生命周期、JPA 注解、@Transactional 语义 |
| TypeScript/JavaScript | async/await 安全、类型断言风险、null 合并 |
| Python | None 检查、Optional 类型、异常链 |
| Go | error 返回值忽略、goroutine 泄漏、nil 解引用 |
| Kotlin | Kotlin 空安全 !! 滥用、协程作用域泄漏 |

当语言未声明时：从文件扩展名或语法特征推断；推断结果记入 `inferred[]`。

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.


## Common failure modes

1. **自调用漏检** — 同一 Bean 内方法 A 调用方法 B（B 有 `@Transactional`），AOP 代理不拦截，事务不生效，但静态分析未标记。修复：检测同类内的方法调用链，若目标方法有 `@Transactional` 则标 `finding_kind: self_invocation_bypass`。
2. **AFTER_COMMIT 事件误用** — `TransactionSynchronizationAdapter.afterCommit()` 中发起新数据库操作，但外层事务已提交，导致数据不一致。修复：检测 `afterCommit` 回调中是否存在 Repository 调用；发现时标 `severity: high`。
3. **readOnly 事务写操作** — `@Transactional(readOnly=true)` 方法内有写操作（INSERT/UPDATE/DELETE），某些数据库驱动会静默忽略或抛运行时异常。修复：检测 `readOnly=true` 方法体内的 Repository `save/delete/update` 调用；发现时标 `severity: critical`。

## Event publication and N210 aggregation

This skill is a sub-skill of the N210 · 代码质量静态检查 node. It does **not** publish a produced event independently to the event bus.

**How events are published:**
1. This skill outputs its findings with stable `finding_id` values and a populated `downstream_handoff` block.
2. `code-standard-check` (running in `node_aggregation` mode) collects findings from all N210 sub-skills via `source_findings[]`.
3. After aggregation, `code-standard-check` publishes `produced.n210.code_quality_static_check.completed` to the event bus, which triggers N330, N370, N390 subscribers.

**Implication for standalone use:** when this skill is used outside the N210 workflow, callers are responsible for emitting any required produced event.

## SLA escalation to N380

When this skill emits findings with `severity: critical` (P0) or `severity: high` (P1):
- Include `sla_escalation_hint: true` in the finding's `downstream_handoff`.
- Downstream `code-standard-check` aggregator will propagate this flag to N380 · 平台门禁与人工协同 for SLA queue entry.
- Do not attempt to directly invoke N380 from within this skill.

```yaml
# Example finding with escalation hint
finding_id: TXNBC-001
severity: critical
sla_escalation_hint: true
escalation_reason: "Missing rollback on exception path in payment service"
recommended_human_action: "Review transaction boundary before merge"
```

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.

## Scope boundaries and upgrade paths

| Scenario | This skill | Upgrade path |
|---|---|---|
| Local `@Transactional` scope, propagation, rollback | ✅ In scope | — |
| Self-invocation AOP bypass | ✅ In scope | — |
| AFTER_COMMIT event risk | ✅ In scope | — |
| Large transaction size estimation | ✅ In scope | — |
| `@Transactional(readOnly=true)` on read-replica | ✅ In scope | Flag datasource routing inconsistency |
| Nested transaction / SAVEPOINT | ✅ In scope | Flag with severity based on ORM support |
| Distributed transaction (TCC / Saga) | ❌ Out of scope | Escalate to N170 · 高级与非功能设计 or N310 · 处置响应 for Saga compensation design |
| Outbox pattern correctness | ✅ Partial — detect missing transactional outbox | Full outbox implementation review → N140/N170 |

### Read-write split transaction checks
When datasource routing is detected (e.g. `AbstractRoutingDataSource`, `@ReadOnly`, read-replica annotations):
- Verify `@Transactional(readOnly=true)` is consistently applied on read-only service methods.
- Flag write operations routed to read replica as `severity: critical`.
- Flag `@Transactional` without `readOnly` on pure query methods as `severity: low` (missed optimisation).
- Record as `propagation_findings[]` with `routing_context: read_write_split`.


## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Produced event / 产物事件

当作为 N210 工作流节点的子技能执行时，本 skill 的产物通过以下事件元数据向下游声明可用性：

```yaml
event_emission:
  emitted_by: standalone_skill  # 本 skill 不自行发布节点级事件
  node_event_publisher: code-standard-check  # N210 唯一事件发布者（node_aggregation 模式）
  artifact_ready_signal: artifact_contract.readiness in [pass, provisional]
  downstream_consumers: [N220, N240, N260, N330, N370, N390]
  finding_contribution:
    target_artifact: "风险检查清单.csv (tx rows)"
    finding_id_prefix: "SEE_SKILL_SELF_CHECK"
```

在 standalone 模式下：直接输出发现列表，无需声明节点事件；节点级事件由 `code-standard-check` 的 `node_aggregation` 模式统一发布。

## Machine-readable self_check rules

- `R01_mode_declared`: `selected_mode` 必须是 `propagation_only | event_commit_check | txn_size_estimate` 之一; `on_violation: reject`
- `R02_finding_id_stable`: 每条 finding 必须有格式为 `TXN-{TYPE}-{NNN}` 的稳定 `finding_id`; `on_violation: reject`
- `R03_severity_set`: `severity` 必须是 `critical | high | medium | low | info` 之一; `on_violation: reject`
- `R04_sla_hint_critical`: `severity: critical` 必须附 `sla_escalation_hint: true`; `on_violation: reject`
- `R05_self_invocation_checked`: 检测到同 Bean 内 `@Transactional` 方法调用时必须标 `finding_kind: self_invocation_bypass`; `on_violation: warn`
- `R06_readonly_write_is_critical`: `@Transactional(readOnly=true)` 方法内发现写操作必须标 `severity: critical`; `on_violation: reject`
- `R07_after_commit_write_is_high`: `afterCommit()` 回调内发现 Repository 调用必须标 `severity: high`; `on_violation: reject`
- `R08_distributed_txn_escalated`: 分布式事务（TCC/Saga）发现时必须升级到 N170/N310，不得在本 skill 内定案; `on_violation: warn`
- `R09_remediation_examples_present`: 每条高风险 finding 必须提供 `before_code` / `after_code` 修复示例; `on_violation: warn`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff` 和 `risk_handoff_bundle`; `on_violation: reject`

## Machine-readable SLA escalation rule

- `R_SLA_01`: Any finding with `severity: critical` MUST include `sla_escalation_hint: true`; `on_violation: warn`.
- `R_SLA_02`: Any finding with `severity: high` SHOULD include `sla_escalation_hint: true`; `on_violation: warn`.

## Reference files / reference files
- `references/tx-boundary-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/tx-boundary-self-check.yaml`: R01-R10 机读门禁规则
- `references/tx-boundary-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/transaction-issue-catalog.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
- `references/risk-bundle-contract.md`
