---
name: transaction-boundary-check
description: analyze code, diffs, files, or repositories for transaction scope, propagation, rollback, self-invocation, after-commit event, outbox, and long-transaction risks. use standalone for service-layer consistency review or n210 checks that contribute transaction rows into the shared risk checklist.
---
# transaction-boundary-check

## Role / role positioning
检测事务边界、传播、回滚、自调用、AFTER_COMMIT 和大事务风险. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `风险检查清单.csv`.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- propagation_only
- event_commit_check
- txn_size_estimate

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- service-layer code from N190
- data flows from N160
- concurrency / idempotency / audit / event designs from N170
- 代码规范检查单.csv from code-standard-check when available

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.transaction_boundary_check`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 风险检查清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- risk_summary
- transaction_issue_catalog[]
- propagation_findings[]
- after_commit_findings[]
- large_transaction_findings[]
- remediation_examples[] with before_code, after_code, risk_if_not_fixed
- risk_handoff_bundle
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.

## Reference files / reference files
- `references/transaction-issue-catalog.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
- `references/risk-bundle-contract.md`
