---
name: duplicate-code-detection
description: analyze code, diffs, files, or repositories for exact, structural, and semantic duplication with thresholds and allowlists. use for standalone duplicate-code review or n210 code-quality static checks that need a duplicate-code inventory and refactor-ready handoff without flagging intentional templates as debt.
---
# duplicate-code-detection

## Role / role positioning
检测重复代码并区分真实技术债与允许样板. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `重复代码清单.csv`.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- quick_duplicate_scan
- semantic_scan
- refactor_ready

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- module boundaries from N140
- package layout from N190
- existing duplication allowlist
- 代码规范检查单.csv from code-standard-check when available

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.duplicate_code_detection`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 重复代码清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- duplication_summary
- duplication_clusters[]
- allowlist_applied[]
- refactor_candidates[]
- shared_component_hints[]
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.

## Reference files / reference files
- `references/duplication-policy.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
