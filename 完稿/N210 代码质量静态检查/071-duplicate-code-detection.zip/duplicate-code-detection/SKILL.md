---
name: duplicate-code-detection
description: Detect exact, structural, and semantic duplication with thresholds, allowlists, cross-service and config-file scanning — duplicate inventory and refactor-ready handoff without flagging intentional templates.
---
# duplicate-code-detection

## Role / role positioning
检测重复代码并区分真实技术债与允许样板，覆盖代码、配置文件和跨服务场景. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `重复代码清单.csv`.

## Boundary / 边界
- 负责识别精确、结构性、语义性重复代码集群，输出 `重复代码清单.csv`。
- 负责区分意图重复（模板）与可消除重复，提供重构建议。
- 不负责整体代码质量；质量发现由 `low-quality-code-detection` 处理。
- 不执行重构；重构步骤由 `refactoring-recommendation` 处理。

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- `quick_duplicate_scan` — 快速扫描，exact + structural 重复，省略 semantic
- `semantic_scan` — 语义级重复，识别逻辑相同但实现不同的代码块
- `refactor_ready` — 在 semantic_scan 基础上输出可立即执行的重构候选，含 test coverage 关联
- `config_duplication_scan` — 专项扫描配置文件重复（yaml/properties/json/toml/xml）
- `cross_repo_hint` — 单仓库结果 + 跨微服务重复的识别提示（advisory，不执行跨仓库扫描）


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 完整源代码树 + allowlist + tech_stack 齐备 | 三档重复（exact/structural/semantic）+ refactor 建议 + allowlist 应用 |
| `provisional` | 部分代码（如 service 层）+ 无 allowlist 文档 | 输出 detection 结果，generated code 检测降级 |
| `constrained` | 仅有 diff，跨文件检测受限 | 仅输出 diff 内的重复，跨文件进 pending |
| `blocked` | 仅有项目描述，无代码 | 输出 `request_for_inputs[]` |

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- module boundaries from N140 — 区分模块内重复 vs 跨模块重复
- package layout from N190 (工程骨架.zip) — allowlist scaffold 层合法样板重复
- existing duplication allowlist
- 代码规范检查单.csv from code-standard-check when available
- test coverage report (from N240) — `refactor_ready` 模式下评估重复代码的测试保护状态

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Threshold customization
Default thresholds (override via project config or user input):

| Detection type | Default threshold | Override field |
|---|---|---|
| Exact duplication | ≥ 6 lines identical | `exact_line_threshold` |
| Structural duplication | ≥ 10 tokens matching | `structural_token_threshold` |
| Semantic similarity | ≥ 0.80 score | `semantic_similarity_threshold` |
| Config block duplication | ≥ 3 key-value pairs identical | `config_block_threshold` |

When project config provides thresholds, record in `active_thresholds[]`. Unknown → use defaults, set `threshold_source: default`.

## Cross-repo / cross-service duplication policy
`cross_repo_scan_policy`:
- **In scope (single repo)**: Full detection within current repository. Output `duplication_clusters[]` with evidence.
- **Cross-repo hint**: In `cross_repo_hint` mode, emit `cross_service_duplication_hints[]` — advisory patterns only, no cross-repo AST scanning.
- **Out of scope**: Actual multi-repo comparison. Escalate to N140 architecture review for cross-service library extraction.

```yaml
cross_service_duplication_hints:
  - pattern: "PageRequest/PageResponse wrapper pattern"
    found_in: ["OrderService module", "UserService module"]
    candidate_for: "shared-common library extraction"
    escalation: "N140 architecture review recommended"
    confidence: high
```

## Config file duplication (config_duplication_scan mode)
Scan configuration files for:
- **Identical blocks**: Same key-value pairs in multiple files
- **Extractable common config**: Keys in all env profiles → candidate for base config
- **Environment diff**: Legitimately different keys → `env_diff_registry[]`, NOT flagged as debt
- **Secret exposure risk**: Keys containing `password/secret/key/token` in plaintext → `severity: critical`

```yaml
config_duplication_findings:
  - finding_id: CDC-CFG-001
    file_pair: ["application-dev.yml:L12-L18", "application-test.yml:L9-L15"]
    duplicate_keys: ["spring.datasource.driver-class-name", "spring.jpa.show-sql"]
    severity: low
    recommendation: "Extract to application.yml base config"
    env_diff_exempt: false
```

## Scaffold allowlist policy
When `工程骨架.zip` from N190 is provided:
- Auto-allowlist scaffold-generated paths (BaseController, BaseRepository, GlobalExceptionHandler skeletons).
- Record in `allowlist_applied[]` with `source: n190_scaffold`.
- Do NOT flag intentional template patterns from N190 as duplication debt.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.duplicate_code_detection`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 重复代码清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- duplication_summary
- duplication_clusters[]
- allowlist_applied[]
- refactor_candidates[]
- shared_component_hints[]
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Tech stack adapter / 技术栈适配

本 skill 支持多语言代码输入。检测规则按语言自动切换：

| 语言 | 主要检测适配 |
|---|---|
| Java/Spring | Spring Bean 生命周期、JPA 注解、@Transactional 语义 |
| TypeScript/JavaScript | async/await 安全、类型断言风险、null 合并 |
| Python | None 检查、Optional 类型、异常链 |
| Go | error 返回值忽略、goroutine 泄漏、nil 解引用 |
| Kotlin | Kotlin 空安全 !! 滥用、协程作用域泄漏 |

当语言未声明时：从文件扩展名或语法特征推断；推断结果记入 `inferred[]`。

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.


## Common failure modes

1. **allowlist 未应用** — N190 scaffold 生成的 BaseController/BaseRepository 模板被重复标记为技术债。修复：收到 `工程骨架.zip` 时必须先加载 `allowlist_applied[]` 并过滤 scaffold 路径下的 finding。
2. **语义重复误报** — 逻辑不同但代码结构相似的模块被标为语义重复（如两个不同业务的 PageRequest wrapper）。修复：`semantic_scan` 模式下必须检查调用上下文和业务语义，相似度 ≥ 0.8 但业务语义不同时降级为 `shared_component_hints[]` 而非 `duplication_clusters[]`。
3. **跨 repo 越界扫描** — 在 `cross_repo_hint` 模式下尝试直接执行跨仓库 AST 比对。修复：跨 repo 只输出 advisory `cross_service_duplication_hints[]`，实际多仓库比对必须升级到 N140 架构评审。

## Event publication and N210 aggregation

This skill is a sub-skill of the N210 · 代码质量静态检查 node. It does **not** publish a produced event independently to the event bus.

**How events are published:**
1. This skill outputs its findings with stable `finding_id` values and a populated `downstream_handoff` block.
2. `code-standard-check` (running in `node_aggregation` mode) collects findings from all N210 sub-skills via `source_findings[]`.
3. After aggregation, `code-standard-check` publishes `produced.n210.code_quality_static_check.completed` to the event bus, which triggers N330, N370, N390 subscribers.

**Implication for standalone use:** when this skill is used outside the N210 workflow, callers are responsible for emitting any required produced event.

## SLA escalation to N380

When this skill emits findings with `severity: critical` (P0) or `severity: high` (P1):
- Include `sla_escalation_hint: true` in the finding's `downstream_handoff`.
- Downstream `code-standard-check` aggregator will propagate this flag to N380 · 平台门禁与人工协同 for SLA queue entry.
- Do not attempt to directly invoke N380 from within this skill.

```yaml
# Example finding with escalation hint
finding_id: TXNBC-001
severity: critical
sla_escalation_hint: true
escalation_reason: "Missing rollback on exception path in payment service"
recommended_human_action: "Review transaction boundary before merge"
```

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.


## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Produced event / 产物事件

当作为 N210 工作流节点的子技能执行时，本 skill 的产物通过以下事件元数据向下游声明可用性：

```yaml
event_emission:
  emitted_by: standalone_skill  # 本 skill 不自行发布节点级事件
  node_event_publisher: code-standard-check  # N210 唯一事件发布者（node_aggregation 模式）
  artifact_ready_signal: artifact_contract.readiness in [pass, provisional]
  downstream_consumers: [N220, N240, N260, N330, N370, N390]
  finding_contribution:
    target_artifact: "重复代码清单.csv"
    finding_id_prefix: "SEE_SKILL_SELF_CHECK"
```

在 standalone 模式下：直接输出发现列表，无需声明节点事件；节点级事件由 `code-standard-check` 的 `node_aggregation` 模式统一发布。

## Machine-readable self_check rules

- `R01_mode_declared`: `selected_mode` 必须是允许模式之一; `on_violation: reject`
- `R02_finding_id_stable`: 每条 finding 必须有格式为 `DUP-{TYPE}-{NNN}` 的稳定 `finding_id`; `on_violation: reject`
- `R03_severity_set`: `severity` 必须是 `critical | high | medium | low | info` 之一; `on_violation: reject`
- `R04_sla_hint_critical`: `severity: critical` 必须附 `sla_escalation_hint: true`; `on_violation: reject`
- `R05_sla_hint_high`: `severity: high` 应附 `sla_escalation_hint: true`; `on_violation: warn`
- `R06_allowlist_applied`: 存在 N190 scaffold 输入时必须加载并应用 `allowlist_applied[]`; `on_violation: reject`
- `R07_threshold_declared`: 使用的检测阈值必须在 `active_thresholds[]` 中声明 `threshold_source`; `on_violation: warn`
- `R08_cross_repo_advisory_only`: `cross_repo_hint` 模式只能输出 advisory，不得执行实际跨仓库扫描; `on_violation: reject`
- `R09_config_duplication_env_exempt`: `config_duplication_scan` 模式中环境差异字段必须进 `env_diff_registry[]`，不得标为债务; `on_violation: reject`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff` 块; `on_violation: reject`

## Machine-readable SLA escalation rule

- `R_SLA_01`: Any finding with `severity: critical` MUST include `sla_escalation_hint: true`; `on_violation: warn`.
- `R_SLA_02`: Any finding with `severity: high` SHOULD include `sla_escalation_hint: true`; `on_violation: warn`.

## Reference files / reference files
- `references/duplication-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/duplication-self-check.yaml`: R01-R10 机读门禁规则
- `references/duplication-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/duplication-policy.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
