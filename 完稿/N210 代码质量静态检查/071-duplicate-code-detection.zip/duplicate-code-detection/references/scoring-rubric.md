# duplicate-code-detection 评分标准 v2.4

## 总览

输出按 4 个维度评分，每维 0-3 分，总分 0-12。

| 总分 | 等级 | 含义 |
|---|---|---|
| 11-12 | **S** | 可直接消费 |
| 9-10 | **A** | 生产可用 |
| 6-8 | **B** | 需人工修订 |
| ≤5 | **C** | 不建议消费 |

---

## 维度 1: 重复检测精度 (duplicate_precision)

衡量: 是否准确区分 exact / structural / semantic 三类重复, 阈值合理.

| 等级 | 标准 |
|---|---|
| **S (3)** | 三类重复独立计数, 阈值显式声明 (e.g. exact_threshold ≥6 lines, structural ≥10 tokens, semantic AST 相似度 ≥0.8), 含 false_positive_filter |
| **A (2)** | 三类重复区分但阈值默认未调整 |
| **B (1)** | 仅 exact + structural, 未做 semantic 检测 |
| **C (0)** | 把 imports / boilerplate / generated code 算重复, 噪声占比 >30% |

---

## 维度 2: 定位与上下文 (location_context)

衡量: 重复对的位置 + 包含上下文.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% 重复对含 (file_a:line_a, file_b:line_b), 同时给出双方代码片段 + 重复块大小 (行数/token数) |
| **A (2)** | 含位置但仅给一侧代码片段 |
| **B (1)** | 仅类名/方法名级位置 |
| **C (0)** | 仅说"代码 X 与 Y 类似", 无具体位置 |

---

## 维度 3: 重构建议 (refactor_actionability)

衡量: 是否给出可执行的去重建议 (Extract / Pull Up / Strategy / Template).

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% 高严重度重复对附 Fowler-style 重构建议 (Extract Method / Pull Up Method / Form Template Method etc.), 含 ROI 估计 + prerequisites |
| **A (2)** | ≥70% 含具体重构动作, 余下泛指 "可抽取" |
| **B (1)** | 仅指出重复, 无重构建议 |
| **C (0)** | 建议错误 (e.g. 让 generated code 抽取共用基类) |

---

## 维度 4: allowlist 与抑制纪律 (suppression_discipline)

衡量: 对故意重复 (e.g. test fixtures, generated mappers) 的处理.

| 等级 | 标准 |
|---|---|
| **S (3)** | allowlist[] 显式列出 (path glob 或 annotation), 受抑制项标 suppression_reason |
| **A (2)** | 显式抑制 generated code / test fixtures |
| **B (1)** | 未声明 allowlist, 把 generated code 全部识别为重复 |
| **C (0)** | 未做任何抑制, 输出大量误报 |

---

## 红线 (违反则直接归 C 或 0)

- 把 generated code (e.g. JPA Entity getter/setter) 作为重复主体输出 -> 失去意义
- 把 boilerplate (e.g. equals/hashCode) 算重复 -> 噪声压倒信号
- 单条重复对超过 50 行无重构建议 -> 让用户做难活
- aggregation_strategy 缺失但与 risk_skill 共写同一 csv -> 协议违反

---

## 等级映射示例

- **S+ (12)**: 三档重复识别精确, 全部含位置 + 重构建议 + ROI, allowlist 完整
- **S (11)**: 3 维满分 + 1 维 A
- **A (9-10)**: 三档识别清晰但 ROI 估计粗略
- **B (6-8)**: 仅 exact + structural 两档, refactor 建议泛化
- **C (<6)**: 误报多 / 无重构建议 / 无 allowlist

---

## 自评示例

```yaml
self_score:
  duplicate_precision: 3
  location_context: 3
  refactor_actionability: 2
  suppression_discipline: 3
  total: 11
  band: S
  rationale: ROI 估计基于行数粗算, 未含编辑成本 + 测试代价
```
