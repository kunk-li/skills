# V2 schema catalog

This file is the enum and field source of truth. `duplication-policy.md` gives threshold narrative.

## detection_method values
- token_based
- ast_based
- semantic
- hybrid

## duplication_kind values
- exact
- structural
- semantic
- template
- boilerplate

## threshold_config defaults
- min_similarity: 0.80
- min_lines: 10
- min_tokens: 100

## suggested_refactoring values
- extract_method
- extract_class
- template_method
- strategy_pattern
- shared_utility
- inheritance

## allowlist defaults
- Controller CRUD methods
- DTO getter/setter
- Test fixtures setup
- Enum value method
- generated code
