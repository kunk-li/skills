# Duplication policy

Use this policy for threshold and allowlist decisions; `v2-schema-catalog.md` is the enum source of truth.

## Default threshold
- min_similarity: 0.80 for reporting, 0.85 for high-confidence refactor candidates.
- min_lines: 10 for general reporting; allow lower thresholds only for high-risk duplicated business logic.
- min_tokens: 100 when token-based detection is used.
- ignore_imports: true.
- ignore_comments: true.

## Methods
- `token_based`: fast coarse scan, often from PMD CPD or SonarQube.
- `ast_based`: normalize names and literals, better for structural clones.
- `semantic`: use only for high-value candidates; slower and lower confidence unless evidence is strong.
- `hybrid`: recommended pipeline: token coarse scan -> AST refinement -> allowlist filter -> semantic review for high-value candidates.

## Default allowlist
- Generated code, DTO getter/setter, Lombok-generated boilerplate, simple CRUD controller wrappers, test fixture setup, enum code accessors.

Do not flag low-similarity or allowlisted duplication unless there is a clear bug-fix or change-centralization risk.
