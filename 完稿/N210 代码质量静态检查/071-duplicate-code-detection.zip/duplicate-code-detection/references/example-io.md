# Example IO: duplicate-code-detection

## Standalone
Input: source code, a file, or a git diff.
Output: keep the exact fields from `output-template.md`, use enums from `v2-schema-catalog.md`, and mark missing context as `readiness: constrained`.

## N210 workflow
Input: code plus optional workflow artifacts and `代码规范检查单.csv`.
Output artifact: `重复代码清单.csv`.
Handoff: include stable ids and cross-skill fields from `n210-shared-contract.md`.
