# Output template: workflow-aligned duplicate code inventory

Required sections:
1. metadata
2. duplication_summary
3. duplication_clusters[]
4. refactor_candidates[]
5. allowlist_applied[]
6. self_check

Cluster fields:
| duplication_id | severity | confidence | detection_method | duplication_kind | similarity | locations | min_lines | min_tokens | allowlisted | allowlist_pattern_matched | rationale | recommendation | related_standard_check_ids | source_skill |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Allowed `detection_method` values: token_based, ast_based, semantic, hybrid.
Allowed `duplication_kind` values: exact, structural, semantic, template, boilerplate.
Default threshold_config: min_similarity=0.80, min_lines=10, min_tokens=100.
Allowed `suggested_refactoring` values: extract_method, extract_class, template_method, strategy_pattern, shared_utility, inheritance.

Cross-skill fields: all rows should include `confidence`, `related_standard_check_ids`, and `source_skill` when applicable.
