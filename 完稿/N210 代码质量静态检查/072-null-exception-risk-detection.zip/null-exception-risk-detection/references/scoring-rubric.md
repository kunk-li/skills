# null-exception-risk-detection 评分标准 v2.4

## 总览

输出按 4 个维度评分，每维 0-3 分，总分 0-12。

| 总分 | 等级 | 含义 |
|---|---|---|
| 11-12 | **S** | 可直接消费 |
| 9-10 | **A** | 生产可用 |
| 6-8 | **B** | 需人工修订 |
| ≤5 | **C** | 不建议消费 |

---

## 维度 1: NPE 来源溯源 (null_source_tracing)

衡量: 每条 NPE 风险是否追溯到 null 的来源 (input / external API / DB / Optional unwrap).

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% finding 含 null_source 字段 (request_param / db_column / external_api / map_get / autoboxing / optional_unwrap), 配传播路径 (call_chain[]) |
| **A (2)** | ≥80% 含 null_source, 余下仅指 "可能为 null" |
| **B (1)** | 仅指出 "x.y 可能 NPE", 无来源 |
| **C (0)** | 无 null_source 字段 |

---

## 维度 2: 注解一致性检测 (annotation_consistency)

衡量: 检测 @NotNull / @Nullable / @NonNull / Optional 使用一致性.

| 等级 | 标准 |
|---|---|
| **S (3)** | 检测 annotation_drift (同一字段在 entity/dto/api 上注解不一致), 检测 lombok @NonNull + getter 矛盾, 检测 Optional 字段被 null 赋值, 检测 @Nullable 参数未做 null check |
| **A (2)** | 主要 annotation 问题被检出, 但未做跨层对照 |
| **B (1)** | 仅做单层 annotation 检测 |
| **C (0)** | 未识别 annotation 信息 |

---

## 维度 3: 危险模式覆盖 (dangerous_pattern_coverage)

衡量: 是否覆盖 6 大类 NPE 危险模式.

| 等级 | 标准 |
|---|---|
| **S (3)** | 覆盖全部 6 类: (1) Map.get/Cache.get 未判 null; (2) String.equals 反向写法; (3) Integer/Long autoboxing NPE; (4) Optional.get 未判 isPresent; (5) Stream collect to map null value; (6) 异步 CompletableFuture exceptionally 未处理. 每类含 >=1 finding |
| **A (2)** | 覆盖 4-5 类 |
| **B (1)** | 仅 2-3 类 |
| **C (0)** | 仅简单 . 解引用, 未识别复杂模式 |

---

## 维度 4: 修复建议与降级路径 (fix_and_degradation)

衡量: 修复建议是否含降级行为决策 (默认值 / 抛异常 / 早返回 / Optional 包装).

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% finding 含 fix_pattern (defensive / fail_fast / fallback_value / wrap_optional) + recommended_choice (基于业务场景) + 降级行为伪代码 |
| **A (2)** | ≥80% 含 fix_pattern, 余下仅给方向 |
| **B (1)** | 仅给"加 null check", 不分场景 |
| **C (0)** | 无修复建议 |

---

## 红线 (违反则直接归 C 或 0)

- finding 数 >100 但仅来自简单 . 解引用 -> 噪声压倒信号
- 把 lombok @NonNull 标记的字段误标为 NPE 风险 -> 误检
- 给 critical level NPE 建议 "加 null check" 但未分析为何 null 出现 -> 治标不治本
- finding_id 不含 npe. 前缀 (与 thread-safety/transaction-boundary 共用 风险检查清单.csv) -> aggregation 协议违反

---

## 等级映射示例

- **S+ (12)**: 6 大类全覆盖 + 来源溯源 + 注解跨层对照 + 修复模式
- **S (11)**: 3 维满分 + 1 维 A
- **A (9-10)**: 主要类覆盖, 来源溯源完整但 fix 粗略
- **B (6-8)**: 部分类未覆盖或 source 缺失
- **C (<6)**: 仅简单 . 解引用 / 无来源

---

## 自评示例

```yaml
self_score:
  null_source_tracing: 3
  annotation_consistency: 2
  dangerous_pattern_coverage: 3
  fix_and_degradation: 3
  total: 11
  band: S
  rationale: 注解检测仅做单层, 跨层 entity/dto/api 对照未覆盖
```
