# Example IO: null-exception-risk-detection

## Scenario A: Standalone NPE risk scan

### Input

```java
public Order processPayment(Long orderId, Map<String, Object> metadata) {
    Order order = orderRepository.findById(orderId).get();  // (1) Optional.get without isPresent
    String userId = order.getUser().getId();                 // (2) chain deref
    Integer amount = (Integer) metadata.get("amount");       // (3) Map.get may return null + autounbox NPE
    if ("VIP".equals(order.getUser().getLevel())) { ... }    // (4) reverse equals: redundant since 'VIP' is non-null literal, but order.getUser() may NPE
    String result = externalApi.callPayment(userId, amount); // (5) external API may return null
    cache.put("order:" + orderId, result);                   // (6) ConcurrentHashMap rejects null value
    return order;
}

// elsewhere
@NotNull
public User getUser() { return user; }  // (7) returns @NotNull, but field user is unguarded
```

### Output

```yaml
artifact_contract:
  schema_version: n210.null-exception-risk-detection.v2.4
  produced_by: null-exception-risk-detection
  selected_mode: standalone_scan
  readiness: pass
  evidence_profile: code_only

risks:
  - finding_id: npe.0001
    severity: critical
    issue_kind: optional_unwrap
    location: {file: PaymentService.java, line: 2}
    null_source: optional_unwrap
    call_chain: [PaymentController.process -> PaymentService.processPayment -> orderRepository.findById]
    snippet: "orderRepository.findById(orderId).get()"
    fix_pattern: fail_fast
    fix_options:
      - {choice: orElseThrow, code: ".orElseThrow(() -> new OrderNotFoundException(orderId))"}
      - {choice: orElse_with_default, suitable_when: "default order acceptable (rare)"}
    recommended: orElseThrow
    rationale: "payment must fail explicitly when order missing; defaulting to empty Order would corrupt downstream"

  - finding_id: npe.0002
    severity: high
    issue_kind: chain_dereference
    location: {file: PaymentService.java, line: 3}
    null_source: lazy_loaded_relation
    call_chain: [order.getUser() -> User.id]
    snippet: "order.getUser().getId()"
    annotation_drift_detected: true
    annotation_evidence: "User.id field has no @NotNull but getter @NotNull (line 42)"
    fix_pattern: defensive
    fix_options:
      - {choice: optional_chain, code: "Optional.ofNullable(order.getUser()).map(User::getId).orElseThrow(...)"}
      - {choice: jpa_eager_fetch, suitable_when: "user is always needed; avoids N+1"}
    recommended: optional_chain
    
  - finding_id: npe.0003
    severity: critical
    issue_kind: map_get_autounbox
    location: {file: PaymentService.java, line: 4}
    null_source: map_get
    danger_pattern: "Map.get returns null, cast to (Integer), autounbox to int -> NPE"
    fix_pattern: fail_fast
    fix_options:
      - {choice: explicit_check, code: "Object raw = metadata.get(\"amount\"); if (raw == null) throw new MissingMetadataException(\"amount\");"}
      - {choice: typed_metadata, code: "use PaymentMetadata DTO with @NotNull Integer amount"}
    recommended: typed_metadata

  - finding_id: npe.0004
    severity: medium
    issue_kind: redundant_reverse_equals_but_chain_npe_risk
    location: {file: PaymentService.java, line: 5}
    null_source: chain_dereference
    note: "the '.equals' on literal is correct defensive style, but order.getUser() chain NPE is the real risk; this is duplicate of npe.0002"
    relate_to: npe.0002
    
  - finding_id: npe.0005
    severity: high
    issue_kind: external_api_null_response
    location: {file: PaymentService.java, line: 6}
    null_source: external_api
    fix_pattern: fail_fast
    fix_options:
      - {choice: result_validator, code: "if (result == null) throw new ExternalApiResponseInvalidException(...)"}
      - {choice: optional_return_type, code: "change externalApi return type to Optional<String>"}
    recommended: result_validator

  - finding_id: npe.0006
    severity: critical
    issue_kind: concurrent_map_null_value
    location: {file: PaymentService.java, line: 7}
    null_source: external_api  # same source as 0005
    danger_pattern: "ConcurrentHashMap.put rejects null value; if 0005 unfixed, this throws"
    relate_to: npe.0005
    fix_required_only_after: npe.0005

  - finding_id: npe.0007
    severity: medium
    issue_kind: annotation_drift
    location: {file: User.java, line: 42}
    null_source: lombok_annotation_inconsistency
    danger_pattern: "@NotNull on getter but field unguarded; lombok generates getter without null check"
    fix_pattern: defensive
    fix_options:
      - {choice: add_field_annotation, code: "add @NotNull on field declaration + lombok @NonNull"}
      - {choice: explicit_getter, code: "remove @Getter, write getter that throws if null"}
    recommended: add_field_annotation

statistics:
  by_severity: {critical: 3, high: 2, medium: 2, low: 0}
  by_source:
    optional_unwrap: 1
    chain_dereference: 2
    map_get: 1
    external_api: 2
    annotation_inconsistency: 1
  patterns_covered: [optional_unwrap, chain_dereference, map_get_autounbox, external_api, annotation_drift, concurrent_map_null]  # 6 of 6
  
aggregation:
  shared_artifact_role: contributor
  aggregation_strategy: append_with_skill_prefix
  artifact: 风险检查清单.csv
  prefix: npe.
```

### Self-score

```yaml
self_score:
  null_source_tracing: 3
  annotation_consistency: 3
  dangerous_pattern_coverage: 3   # 6/6 categories covered
  fix_and_degradation: 3
  total: 12
  band: S+
```

---

## Scenario B: Workflow contributor mode

When run under N210 workflow, this skill writes rows to `风险检查清单.csv` with `npe.` prefix. Other contributors (`tsr.` for thread-safety, `txn.` for transaction-boundary) write to the same file. Aggregator (code-standard-check in node_aggregation mode) merges all 3.

---

## Common readiness states

| readiness | when |
|---|---|
| `pass` | full code + annotations available |
| `constrained` | only diff or method signatures |
| `blocked` | description only |
