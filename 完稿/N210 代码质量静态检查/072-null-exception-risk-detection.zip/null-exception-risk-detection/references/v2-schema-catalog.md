# V2 schema catalog

This file is the enum and field source of truth. `null-optional-policy.md` gives red-line rules.

## risk_kind values
- missing_null_check
- unsafe_dereference
- optional_misuse
- annotation_missing
- annotation_mismatch
- map_access_unsafe
- collection_null_element
- api_response_nullable
- lombok_non_null_violation
- primitive_autoboxing_null

## null_source_trace.source_kind values
- method_returns_nullable
- database_query_may_return_null
- external_api_response
- user_input_optional
- configuration_optional
- deserialization
- lazy_init_not_yet_initialized
- map_get_result
- stream_findFirst
- first_in_empty_collection

## fix_strategy values
- add_null_check
- use_optional
- add_nonnull_annotation
- add_nullable_annotation
- use_assert_or_require
- use_default_value
- use_coalesce

## required fields
- `null_source_trace`: variable_name, can_be_null_because[].
- `annotation_recommendation`: suggested_annotations[], affected_locations.
- `optional_usage`: current_usage_issue, before, after.
- `test_cases_needed[]`: scenario, expected_behavior.
