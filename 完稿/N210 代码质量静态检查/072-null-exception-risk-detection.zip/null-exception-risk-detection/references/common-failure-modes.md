# null-exception-risk-detection 常见失败模式 v2.4

## 通用部分（F1-F4）

### F1. 把推断包装成确定事实

**症状**：标 `severity: critical` 但 NPE 实际不可达（如 caller 已经做了 null check）

**影响**：假阳性 finding；用户花时间评估发现是误报；产出可信度受损

**修正**：执行 reachability 分析（call_chain 中是否已有 null check）；不可达的 NPE 风险降级到 info

---

### F2. 没有位置或范围仍给强结论

**症状**：仅说 "x.y 可能 NPE"，没有 file:line 也没有 null_source 字段

**影响**：人工无法验证；fix 路径无法选择；与 IDE inspection 雷同

**修正**：location + null_source（来源类别）+ call_chain（传播路径）必填

---

### F3. 同类问题机械穷举

**症状**：对 100 个 .get() 调用每个都列一条 npe.* finding

**影响**：高风险点（如 external API 未判 null）被淹没

**修正**：按 null_source 分类聚合（map_get / external_api / autoboxing），cluster 内仅展开 top 3 sample

---

### F4. 只说问题不说原因或建议

**症状**：建议 "加 null check"，没说默认值是什么、要不要抛异常

**影响**：用户随意加 if (x == null) return null 反而掩盖真正的业务异常

**修正**：fix_pattern (defensive/fail_fast/fallback_value/wrap_optional) + 推荐选项 + 选择理由必填

---

## 本 skill 重点（F5-F8）

### F5. 误把 lombok @NonNull 标记字段当 NPE 风险

**症状**：字段标 `@NonNull`（lombok），lombok 在 setter 中已生成 null check + 抛 NullPointerException；本 skill 仍标 `if not null check, may NPE`。

**影响**：误报；用户拒绝接受建议；信任损失。

**修正**：
- 识别 lombok @NonNull / @NonNullApi / @NonNullFields 注解。
- 识别 javax.validation.constraints.NotNull（在 controller 入口已有 @Valid 校验）。
- 在 annotation-aware 模式下，明确不可能 null 的字段不输出 NPE finding。

---

### F6. 仅检测简单 . 解引用，漏 6 大类危险模式

**症状**：finding 全部来自 `obj.method()` 这种简单 deref，未识别：
- Map.get 未判 null + autoboxing（int = (Integer) map.get(...)）
- Optional.get 未判 isPresent
- ConcurrentHashMap 拒绝 null value
- annotation drift（getter @NotNull 但 field 不是）
- async CompletableFuture exceptionally 未处理
- stream collect to map 含 null value

**影响**：覆盖度不足；用户认为 LLM 与 IDE inspection 同质。

**修正**：dangerous_pattern_coverage 字段必填，列出本次扫描覆盖的 6 类中的几类；至少 4/6 才算 pass。

---

### F7. 给 critical 建议但不溯源

**症状**：标 critical NPE 但 fix 仅说 "加 null check"，未分析 null 为何出现（是 input bug、API 契约、还是真正的业务可能性）。

**影响**：治标不治本；几个月后 null 又从其他路径流入相同点。

**修正**：
- 100% critical/high finding 必须追溯 null_source 至最远输入点：API 入口、DB 查询、external API 响应、配置注入。
- 推荐 fix 时考虑 source 处的修复（如 controller 加 @Valid + @NotNull）vs 终点处的修复（在使用点判 null）。
- 输出 source-aware fix 时优先 source 修复。

---

### F8. finding_id 不含 npe. 前缀

**症状**：与 thread-safety-risk-check (tsr.*)、transaction-boundary-check (txn.*) 共用 风险检查清单.csv，但本 skill 输出 finding_id 为 NPE-001 而非 npe.0001。

**影响**：aggregation 时 id 冲突；3 个 skill 的 row 混淆；node_aggregation 模式下 source_id 无法精确引用。

**修正**：
- finding_id 必须以 `npe.` 前缀 + 4 位 sequence (`npe.0001`)。
- aggregation_strategy: append_with_skill_prefix 必须显式声明。
- self_check.R0X 校验 finding_id 格式。

