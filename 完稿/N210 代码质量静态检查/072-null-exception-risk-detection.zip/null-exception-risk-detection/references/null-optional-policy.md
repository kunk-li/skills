# Null and Optional policy

Use this policy for red lines and narrative guidance; `v2-schema-catalog.md` is the enum source of truth.

## Annotation convention
- Public APIs should declare nullability on parameters and return values when the project supports it.
- Do not mix nullability frameworks in one codebase unless the convention explicitly allows it.
- If convention is missing, set `readiness: constrained` and state the assumed framework.

## Optional red lines
- Use Optional primarily for return values.
- Avoid Optional as fields.
- Avoid Optional as parameters unless the project standard explicitly permits it.
- Never use `Optional.of(nullable)`; use `ofNullable`.
- Avoid `optional.get()` without a presence check or terminal default/exception.
- Avoid `orElse(null)` unless the caller immediately handles null and that handling is shown.

## Null-source tracing priorities
Trace from unsafe dereference backward to source: repository/API return, map access, deserialization, config, user input, lazy init, empty collection, stream optional.
