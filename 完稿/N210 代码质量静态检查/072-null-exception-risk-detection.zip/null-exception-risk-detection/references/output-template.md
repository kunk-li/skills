# Output template: shared risk bundle contribution

Artifact target: risk checklist / 风险检查清单.csv

Required sections:
1. metadata
2. risk_summary
3. risk_catalog[]
4. null_source_trace[]
5. annotation_gaps[]
6. optional_misuse_cases[]
7. test_cases_needed[]
8. self_check

Risk fields:
| risk_id | severity | confidence | risk_family | risk_kind | location | null_source_kind | null_source | evidence | fix_strategy | recommendation | linked_rules | linked_nfr | related_standard_check_ids | source_skill |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Allowed `risk_kind` values: missing_null_check, unsafe_dereference, optional_misuse, annotation_missing, annotation_mismatch, map_access_unsafe, collection_null_element, api_response_nullable, lombok_non_null_violation, primitive_autoboxing_null.
Allowed `null_source_kind` values: method_returns_nullable, database_query_may_return_null, external_api_response, user_input_optional, configuration_optional, deserialization, lazy_init_not_yet_initialized, map_get_result, stream_findFirst, first_in_empty_collection.
Allowed `fix_strategy` values: add_null_check, use_optional, add_nonnull_annotation, add_nullable_annotation, use_assert_or_require, use_default_value, use_coalesce.

Cross-skill fields: all rows should include `confidence`, `related_standard_check_ids`, and `source_skill` when applicable.
