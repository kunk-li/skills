---
name: null-exception-risk-detection
description: NPE risk scan — analyze code, diffs, files, or repositories for null, optional, annotation, map-access, autoboxing, and exception-crash risks with null-source tracing. use for standalone npe review or checks that contribute null and exception risks into the shared risk checklist.
---
# null-exception-risk-detection

## Role / role positioning
检测 NPE、Optional、注解、Map 访问和异常崩溃风险. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `风险检查清单.csv`.

## Boundary / 边界
- 负责识别 NPE 风险：null 来源追踪、Optional 误用、autoboxing 风险、Map.get() 未检查。
- 负责将 critical 级风险通过 `sla_escalation_hint` 上报。
- 不负责业务逻辑错误处理；异常体系由 `exception-class-generation` 处理。
- 不负责并发安全；线程安全由 `thread-safety-risk-check` 处理。

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- `annotation_wire` — `@Nullable`/`@NonNull` annotation consistency and NullAway/Checker alignment
- `optional_mode` — `Optional` misuse (`.get()` without check, `Optional` as field type, nested Optional)
- `source_trace` — trace null propagation from source (DB field, external API, deserialization) to crash site
- `kotlin_null_safety` — `!!` force-unwrap risk, platform type (`T!`) unsafe access, nullable interop with Java code
- `reactive_null_mode` — `Mono.empty()` vs null distinction, `flatMap` null propagation, `Flux` element nullability


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 代码 + 注解配置 (@NotNull/lombok) + 调用链可分析 全部齐备 | 完整 NPE 风险 + null_source 溯源 + 6 类危险模式覆盖 |
| `provisional` | 代码齐备但注解配置不完整（部分 lombok 设置缺失） | 输出 NPE finding，annotation_drift 检测降级 |
| `constrained` | 仅有部分代码，跨调用分析受限 | 仅输出本文件内的 NPE，跨调用进 pending |
| `blocked` | 仅有项目描述，无代码 | 输出 `request_for_inputs[]` |


## Tech stack adapter / 技术栈适配

本 skill 默认 Java 语言场景，但通过 `stack_declaration` 字段适配其他语言：

| stack | 工具/概念映射 | nullability 检测语义 |
|---|---|---|
| `java` | `@NotNull` / `@Nullable` / `Optional<T>` / `lombok @NonNull` | 注解 + Optional 解包 + autoboxing |
| `kotlin` | `T?` 类型系统 / `!!` operator | 编译器已强制；本 skill 检测 `!!` 用法 + Java 互操作边界 |
| `typescript` | `T \| null` / `T \| undefined` / `strict null checks` | tsconfig.strict + 联合类型 + optional chaining 缺失 |
| `python` | `Optional[T]` / `None` / `mypy --strict` | type hint + `None` 默认值 + dict.get(default) |
| `go` | nil pointer / interface{} | 显式 nil check + error 返回值惯例 |
| `rust` | `Option<T>` / `Result<T,E>` | 编译器已强制；本 skill 检测 `unwrap()` 风险 |

**stack_declaration 字段**：
```yaml
stack_declaration:
  primary_stack: java          # 主要栈
  secondary_stacks: []          # 多栈项目
  null_check_idiom: jsr305_with_lombok   # null 检测惯用法
  optional_handling: strict     # strict / lenient / mixed
```

**适配规则**：
- 输入代码语言识别失败 → readiness: constrained，仅做语言无关的语法层 NPE。
- 多栈项目（如 Java service + TS frontend）应分别声明 stack_declaration，输出按 stack 分组。
- 6 类危险模式映射会按 stack 调整：例如 Kotlin 项目重点检测 `!!` 和 Java 互操作；TypeScript 项目重点检测 strict 模式下的 union narrowing。

**与 N190 / N210 sibling 的契约**：
- N190 codegen skill 通过 `stack_declaration` 协商；本 skill 消费同一 stack_declaration 并按 stack 适配检测规则。
- N210 sibling（thread-safety / transaction）在 Java 之外的 stack 中的可用性由 stack_compatibility_matrix.md 声明。

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- nullability coding conventions from N190
- NullAway / Checker / IDE inspection config
- external API or DB response contracts
- `表结构设计草案.sql` from N160 — compare DB column `NOT NULL` constraints against Java `@NonNull` annotations for consistency
- `exception-class-generation` output from N200 — five-layer hierarchy guides which null path triggers which exception type
- 代码规范检查单.csv from code-standard-check when available

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## DB-to-Java nullability consistency check

When `表结构设计草案.sql` is provided, output a `db_java_nullability_matrix[]`:

```yaml
db_java_nullability_matrix:
  - column: "user.email"
    db_nullable: false      # NOT NULL in DDL
    java_annotation: "@Nullable"   # mismatch → severity: high
    mismatch: true
    recommended_fix: "Change to @NonNull or remove @Nullable"
  - column: "order.deleted_at"
    db_nullable: true
    java_annotation: null  # no annotation → severity: low
    mismatch: false
    recommended_fix: "Add @Nullable to make intent explicit"
```

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.null_exception_risk_detection`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 风险检查清单.csv`
  - `aggregation_strategy: append_with_skill_prefix`  # rows use prefix `npe.` to avoid id collisions across the 3 contributors
  - `shared_artifact_role: contributor`  # 3 skills contribute rows to the same csv
  - `evidence_profile`
  - `tool_collaboration_mode`
- risk_summary
- risk_catalog[]
- null_source_trace[]
- annotation_gaps[]
- optional_misuse_cases[]
- risk_handoff_bundle
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.


## Common failure modes

1. **DB nullability 不一致未检查** — 有 `表结构设计草案.sql` 但未生成 `db_java_nullability_matrix[]`，导致 DB `NOT NULL` 与 Java `@Nullable` 冲突漏检。修复：提供 SQL 输入时必须强制生成 nullability 矩阵。
2. **Optional.get() 伪阴性** — `Optional` 链中的 `.get()` 调用前有 `isPresent()` 检查，但检查与 get 之间存在并发修改风险，被误判为安全。修复：在 `optional_mode` 下检查 `isPresent()` 到 `.get()` 之间是否存在共享状态修改路径。
3. **reactive 上下文 null 漏报** — 在 reactive 流中 `Mono.empty()` 被传入 `flatMap` 后的处理函数，未检查是否正确处理 empty 信号，导致静默空结果。修复：`reactive_null_mode` 下必须检查 `flatMap/switchIfEmpty` 的 empty 处理路径。

## Event publication and N210 aggregation

This skill is a sub-skill of the N210 · 代码质量静态检查 node. It does **not** publish a produced event independently to the event bus.

**How events are published:**
1. This skill outputs its findings with stable `finding_id` values and a populated `downstream_handoff` block.
2. `code-standard-check` (running in `node_aggregation` mode) collects findings from all N210 sub-skills via `source_findings[]`.
3. After aggregation, `code-standard-check` publishes `produced.n210.code_quality_static_check.completed` to the event bus, which triggers N330, N370, N390 subscribers.

**Implication for standalone use:** when this skill is used outside the N210 workflow, callers are responsible for emitting any required produced event.

## SLA escalation to N380

When this skill emits findings with `severity: critical` (P0) or `severity: high` (P1):
- Include `sla_escalation_hint: true` in the finding's `downstream_handoff`.
- Downstream `code-standard-check` aggregator will propagate this flag to N380 · 平台门禁与人工协同 for SLA queue entry.
- Do not attempt to directly invoke N380 from within this skill.

```yaml
# Example finding with escalation hint
finding_id: TXNBC-001
severity: critical
sla_escalation_hint: true
escalation_reason: "Missing rollback on exception path in payment service"
recommended_human_action: "Review transaction boundary before merge"
```

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.


## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Produced event / 产物事件

当作为 N210 工作流节点的子技能执行时，本 skill 的产物通过以下事件元数据向下游声明可用性：

```yaml
event_emission:
  emitted_by: standalone_skill  # 本 skill 不自行发布节点级事件
  node_event_publisher: code-standard-check  # N210 唯一事件发布者（node_aggregation 模式）
  artifact_ready_signal: artifact_contract.readiness in [pass, provisional]
  downstream_consumers: [N220, N240, N260, N330, N370, N390]
  finding_contribution:
    target_artifact: "风险检查清单.csv (NPE rows)"
    finding_id_prefix: "SEE_SKILL_SELF_CHECK"
```

在 standalone 模式下：直接输出发现列表，无需声明节点事件；节点级事件由 `code-standard-check` 的 `node_aggregation` 模式统一发布。

## Machine-readable self_check rules

- `R01_mode_declared`: `selected_mode` 必须是允许模式之一; `on_violation: reject`
- `R02_finding_id_stable`: 每条 finding 必须有格式为 `NPE-{MODE}-{NNN}` 的稳定 `finding_id`; `on_violation: reject`
- `R03_severity_set`: `severity` 必须是 `critical | high | medium | low | info` 之一; `on_violation: reject`
- `R04_sla_hint_critical`: `severity: critical` 必须附 `sla_escalation_hint: true`; `on_violation: reject`
- `R05_db_matrix_when_sql_provided`: 提供 `表结构设计草案.sql` 时必须生成 `db_java_nullability_matrix[]`; `on_violation: reject`
- `R06_no_optional_in_field_types`: 检测到 `Optional` 作为字段类型时必须标 `severity: medium` 以上; `on_violation: warn`
- `R07_reactive_empty_checked`: `reactive_null_mode` 下必须检查 `flatMap/switchIfEmpty` 的 empty 处理路径; `on_violation: warn`
- `R08_no_fabricated_runtime`: 不得声称已验证运行时 NPE 发生；静态分析结论必须标明局限; `on_violation: reject`
- `R09_null_source_traced`: `source_trace` 模式下每条 finding 必须追溯 null 来源（DB字段/外部API/反序列化）; `on_violation: warn`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff` 和 `risk_handoff_bundle`; `on_violation: reject`

## Machine-readable SLA escalation rule

- `R_SLA_01`: Any finding with `severity: critical` MUST include `sla_escalation_hint: true`; `on_violation: warn`.
- `R_SLA_02`: Any finding with `severity: high` SHOULD include `sla_escalation_hint: true`; `on_violation: warn`.

## Reference files / reference files
- `references/npe-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/npe-self-check.yaml`: R01-R10 机读门禁规则
- `references/npe-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/null-optional-policy.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
- `references/risk-bundle-contract.md`
