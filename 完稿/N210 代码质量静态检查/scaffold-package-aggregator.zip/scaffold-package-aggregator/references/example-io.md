# Example IO - Scaffold Package Aggregator v2.3

## Input excerpt

来自 N190 4 个 sibling 的 artifact_contract（节选）：

```yaml
# 1) code-scaffold-generation
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: code-scaffold-generation
  artifact_name: 工程骨架.zip
  readiness: pass
  evidence_profile: direct_contract
  stack_declaration: java
  package_layout:
    strategy: feature_based
    base: com.acme.order
  traces_to_tasks: [TASK-S1-001, TASK-S1-002]

# 2) controller-draft-generation
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: controller-draft-generation
  artifact_name: Controller草稿.zip
  readiness: pass
  evidence_profile: direct_contract
  stack_declaration: java
  package_path: com.acme.order.web
  service_method_calls:
    - { service: OrderService, signature: "createOrder(CreateOrderRequest): OrderResponse" }
    - { service: OrderService, signature: "cancelOrder(Long): void" }
  traces_to_tasks: [TASK-S1-001, TASK-S1-003]

# 3) service-draft-generation
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: service-draft-generation
  artifact_name: Service草稿.zip
  readiness: pass
  evidence_profile: direct_contract
  stack_declaration: java
  package_path: com.acme.order.service
  methods:
    - { signature: "createOrder(CreateOrderRequest): OrderResponse" }
    # cancelOrder 缺失 ← 引用断裂
  repository_method_calls:
    - { repository: OrderRepository, signature: "save(Order): Order" }
  traces_to_tasks: [TASK-S1-001, TASK-S1-002]

# 4) repository-draft-generation
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: repository-draft-generation
  artifact_name: Repository草稿.zip
  readiness: pass
  evidence_profile: direct_contract
  stack_declaration: java
  package_path: com.acme.order.repository
  methods:
    - { signature: "save(Order): Order" }
    - { signature: "findById(Long): Optional<Order>" }
  traces_to_tasks: [TASK-S1-002]
```

## Output excerpt

```yaml
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: scaffold-package-aggregator
  artifact_name: N190_scaffold_package.zip
  artifact_type: aggregated_package
  selected_mode: release_scaffold_package
  readiness: constrained        # 因为有 unresolved_references
  evidence_profile: mixed
  source_artifacts:
    - { skill: code-scaffold-generation,    artifact: 工程骨架.zip,        readiness: pass }
    - { skill: controller-draft-generation, artifact: Controller草稿.zip, readiness: pass }
    - { skill: service-draft-generation,    artifact: Service草稿.zip,    readiness: pass }
    - { skill: repository-draft-generation, artifact: Repository草稿.zip, readiness: pass }
  downstream_consumers: [N200, N210, N240, N330]
  traces_to_tasks: [TASK-S1-001, TASK-S1-002, TASK-S1-003]   # union, dedup, sorted

self_gate:
  status: warn
  failed_rules: []
  warnings: ["unresolved_references_count=1"]
  pending: []
  sibling_conflicts: []
  unresolved_references:
    - type: controller_to_service
      controller_class: com.acme.order.web.OrderController
      invoked_method: "OrderService.cancelOrder(Long): void"
      reason: not_found_in_service
      回推: service-draft-generation

quality_self_score:
  scale: 0_to_2_per_dimension
  dimensions:
    source_integration: 1       # 有 1 处 unresolved
    readiness_propagation: 2
    namespace_consistency: 2
    downstream_handoff: 2
  overall_level: A              # 7/8 = A

produced_event:
  event_type: produced.n190.scaffold_package
  contract_version: n190.artifact.v2.3
  artifact_ref: N190_scaffold_package.zip
  emitted_for: [N200, N210, N240, N330]
  unresolved_refs_count: 1
  sibling_conflicts_count: 0
```

## 解读

- 4 个 sibling 各自 readiness=pass，但 aggregator 发现 controller 引用了 service 中不存在的 `cancelOrder` 方法。
- 该引用进入 `unresolved_references[]`，触发 readiness 降级为 `constrained`。
- aggregator **没有自行在 service 草稿中补出 cancelOrder**（违反 R07）。
- `traces_to_tasks` 取 4 sibling 并集后去重排序，得到 3 个唯一 task_id。
- `quality_self_score` 因为 1 处未解决引用扣 1 分，overall_level=A（7/8）。
- 下游 N200/N210/N240/N330 会收到 `unresolved_refs_count: 1` 的提示，判断是否需要等待 service-draft-generation 修复后再启动。
