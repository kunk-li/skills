# N190 scaffold package merge rules v2.3

## Source artifact id 主键

- `code-scaffold-generation` 是 layout 主数据源；`package_layout` 决定 controller / service / repository 类的目标包路径。
- `controller-draft-generation` 提供 controller 类与 service 方法引用清单。
- `service-draft-generation` 提供 service 类、方法签名、repository 方法引用清单。
- `repository-draft-generation` 提供 repository 接口与方法签名。

## 字段级合并表

| 字段 | 取值规则 |
|---|---|
| `stack_declaration` | 4 sibling 必须一致，不一致则进 `sibling_conflicts[]` 并 reject |
| `package_layout` | 取 `code-scaffold-generation` 的值；其他 sibling 必须服从 |
| `traces_to_tasks[]` | 取 4 sibling 并集，去重，按 task_id 升序排序 |
| `confirmed[]` | 取 4 sibling 并集 |
| `inferred[]` | 取 4 sibling 并集 |
| `pending[]` | 取 4 sibling 并集 |
| `readiness` | 取最保守值（blocked > constrained > provisional > pass） |
| `evidence_profile` | 若任一 sibling 为 `heuristic_only`，整体不能高于 `mixed` |

## 交叉引用解析

### controller -> service 引用
- 解析 controller 草稿中所有形如 `service.methodName(...)` 的调用
- 在 service 草稿中查找匹配的 method signature（同名 + 参数类型一致）
- 不匹配的进入 `unresolved_references[]`：
```yaml
- type: controller_to_service
  controller_class: <class>
  invoked_method: <signature>
  reason: not_found_in_service | signature_mismatch
```

### service -> repository 引用
- 解析 service 草稿中所有形如 `repository.methodName(...)` 的调用
- 在 repository 草稿中查找匹配的 method signature
- 不匹配的进入 `unresolved_references[]`：
```yaml
- type: service_to_repository
  service_class: <class>
  invoked_method: <signature>
  reason: not_found_in_repository | signature_mismatch
```

### DTO / Entity 类型一致性
- controller 的 request / response 类型 vs service 方法签名中的对应类型必须一致
- 不一致进入 `unresolved_references[]`：
```yaml
- type: dto_type_mismatch
  controller_method: <method>
  controller_type: <type>
  service_type: <type>
```

## 冲突回推策略

冲突类型与回推目标：

| 冲突类型 | 回推 sibling skill |
|---|---|
| stack_declaration 不一致 | 4 个 sibling 全部，需上游统一决策 |
| package_layout 与 controller 包路径不一致 | controller-draft-generation |
| controller 引用的 service 方法不存在 | service-draft-generation（补方法）或 controller-draft-generation（修引用） |
| service 引用的 repository 方法不存在 | repository-draft-generation 或 service-draft-generation |
| DTO 类型不一致 | controller-draft-generation 与 service-draft-generation 协同 |

aggregator 的边界：**仅记录冲突，不修改 sibling 产物**。
