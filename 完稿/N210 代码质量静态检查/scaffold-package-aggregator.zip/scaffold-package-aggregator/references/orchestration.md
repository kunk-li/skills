# N190 scaffold package orchestration v2.3

## 上游优先级

优先消费以下输入，缺失时按降级规则处理：

1. `code-scaffold-generation` 的 `artifact_contract` + `工程骨架.zip`
2. `controller-draft-generation` 的 `artifact_contract` + `Controller草稿.java`
3. `service-draft-generation` 的 `artifact_contract` + `Service草稿.java`
4. `repository-draft-generation` 的 `artifact_contract` + `Repository草稿.java`
5. `N180_planning_package.md`（用于 traces 校验）
6. `技术方案分析.md` / `模块边界图.md`（用于命名空间校验）

## 下游衔接

| 下游节点 | 消费的字段 | 用途 |
|---|---|---|
| **N200** | `to_dto_vo.required_dtos[]`、`to_validator.required_rules[]`、`to_sql.required_ddl[]` | 生成 DTO/VO/Validator/SQL 草稿 |
| **N210** | `package_layout`、`scope_of_files[]` | 静态检查范围 |
| **N240** | `method_signatures[]`、`test_targets[]` | 生成单测 / 集成测试 |
| **N330** | `api_surface[]`、`endpoint_list[]` | 生成 API 文档 |

## sibling 间字段映射

### scaffold -> controller / service / repository
| scaffold 字段 | sibling 字段 | 说明 |
|---|---|---|
| `package_layout.strategy` | controller / service / repository 的包路径 | 必须服从 |
| `stack_declaration` | 三 sibling 的 `stack_declaration` | 必须一致 |
| `annotation_catalog` | controller / service 的注解集 | 仅作用于声明级 cross-cutting |
| `handoff.to_controller_draft.base_controller` | controller 的父类 | 强约束 |
| `handoff.to_service_draft.transaction_manager` | service 的事务管理器引用 | 强约束 |

### controller -> service
| controller 字段 | service 期待字段 |
|---|---|
| `service_method_calls[]` | `methods[].signature` 必须能匹配 |
| `dto_in / dto_out` | `methods[].param_types / return_type` 必须一致 |

### service -> repository
| service 字段 | repository 期待字段 |
|---|---|
| `repository_method_calls[]` | `methods[].signature` 必须能匹配 |
| `entity_types[]` | `methods[].param_types / return_type` 必须包含相同实体 |

## 反向约束

### 4 sibling 基于 aggregator 的约束
- 任意 sibling 在 N190 中必须至少有一次 standalone 输出能通过 aggregator 的一致性校验。
- `stack_declaration` 是 4 sibling 的契约级共享字段，任意 sibling 修改 stack 必须经过节点级一致性回归。

## 与 planning-package-aggregator 的关系

- N180 aggregator 负责把任务、估算、依赖合成规划包；其 `traces_to_tasks[]` 是 N190 的输入基线。
- N190 aggregator 校验 `traces_to_tasks[]` 是否覆盖了 N180 中的全部相关 backend 任务；缺失任务进入 `pending[]`。

## 与 N200 / N210 的契约边界

- N190 aggregator **不生成** DTO / Validator / SQL，仅声明 `to_N200.required_*[]`。
- N190 aggregator **不执行** 静态检查，仅声明 `to_N210.scope_of_files[]`。
- 越界即违反 `R07_no_rebuild`。
