# scaffold-package-aggregator 常见失败模式 v2.3

## F1. 静默重写 sibling 产物

**症状**：发现 controller 引用的 `OrderService.cancelOrder(...)` 不存在于 service 草稿，aggregator 自行在 service 中补出该方法。

**后果**：违反 single-source-of-truth，service-draft-generation 与 aggregator 输出不一致；下游 N200 / N210 据此生成的 DTO / 静态检查目标错位。

**修复**：必须把缺失签名写入 `unresolved_references[]`，并在 `sibling_conflicts[]` 中标 `回推: service-draft-generation`，aggregator 不修改任何 sibling 产物。这是 `R07_no_rebuild` 的红线。

---

## F2. stack_declaration 不一致被忽略

**症状**：scaffold 声明 `stack: java`，但 controller 由于上游 hint 不全声明 `stack: kotlin`，aggregator 仍输出 readiness=pass。

**后果**：下游 N200 / N240 拿到混栈包，DTO 类型与测试框架选择全部错位。

**修复**：`R02_stack_declaration_consistent` 强制 reject。aggregator 必须先在 `sibling_conflicts[]` 中标记，将 readiness 设为 blocked，回推到 4 个 sibling 协同决策。

---

## F3. traces_to_tasks 重复爆炸

**症状**：4 个 sibling 各自填了相同的 5 个 task_id，aggregator 直接 concat 得到 20 条记录。

**后果**：下游 N240 生成测试时按重复 task 重复生成，N380 SLA 队列指标失真。

**修复**：合并阶段必须按 task_id 唯一化，按字典序排序。`R06_traces_dedup` 在 warn 级别。

---

## F4. unresolved_references 的"软处理"

**症状**：controller -> service 引用有 3 处不匹配，aggregator 把它们写进 `pending[]` 而非 `unresolved_references[]`，并把 readiness 设为 provisional。

**后果**：下游 N200 / N210 不知道有引用断裂，生成的 DTO 与测试基于错误假设。

**修复**：`unresolved_references[]` 是 sibling 间契约级失败，必须独立成段，readiness 不能高于 constrained。`pending[]` 仅用于"需要更多输入才能决定"的待办。

---

## F5. package_layout 双源不对齐

**症状**：scaffold 输出 `feature_based` layout（`com.x.order`、`com.x.user`），但 controller / service 草稿用了 `layer_based` layout（`com.x.controller`、`com.x.service`）。aggregator 直接合并，两套包结构并存。

**后果**：编译可通过但项目结构混乱；后续 IDE 重构、依赖分析、模块拆分都受影响。

**修复**：scaffold 是 layout 主数据源（`R03_package_layout_alignment`）。controller / service / repository 的包路径必须落在 scaffold `package_layout` 内，否则进 `unresolved_references[]` 并回推对应 sibling。

---

## F6. blocked scope 未排除

**症状**：N190 内一个 sibling 因为缺 N170 的 idempotency 设计而被标 blocked，aggregator 把整个 package 标 blocked，但实际上该 cross-cutting 决策不在当前 release scope（`carry_over_policy: can_carry`）。

**修复**：参考 N180 aggregator 的 blocked scope 策略，检查是否带 `sprint.priority_in_sprint: won_t_have` 或 `won_t_have_in_release`。在 release scope 外的 blocked 项可以排除并在 `executive_summary` 注明排除原因。
