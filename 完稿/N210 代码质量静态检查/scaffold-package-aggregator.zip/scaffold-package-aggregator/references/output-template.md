# N190 scaffold package output template

## File: N190_scaffold_package.zip
内含：
- `工程骨架.zip` 解压后的目录树（来自 `code-scaffold-generation`）
- `Controller草稿.zip`（来自 `controller-draft-generation`，解压后按 package_layout 放置）
- `Service草稿.zip`（来自 `service-draft-generation`，解压后按 package_layout 放置）
- `Repository草稿.zip`（来自 `repository-draft-generation`，解压后按 package_layout 放置）
- `N190_scaffold_package.md`（本文件，节点级摘要）

## File: N190_scaffold_package.md（节点级摘要）

```yaml
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: scaffold-package-aggregator
  artifact_name: N190_scaffold_package.zip
  artifact_type: aggregated_package
  selected_mode: release_scaffold_package
  readiness: <pass|provisional|constrained|blocked>
  evidence_profile: <direct_contract|inferred_from_sibling|mixed>
  source_artifacts:
    - skill: code-scaffold-generation
      artifact: 工程骨架.zip
      readiness: <inherit>
      schema_version: <inherit>
    - skill: controller-draft-generation
      artifact: Controller草稿.zip
      readiness: <inherit>
    - skill: service-draft-generation
      artifact: Service草稿.zip
      readiness: <inherit>
    - skill: repository-draft-generation
      artifact: Repository草稿.zip
      readiness: <inherit>
  downstream_consumers: [N200, N210, N240, N330]
  traces_to_tasks: []   # union of 4 siblings, deduplicated, sorted

self_gate:
  status: <pass|warn|block>
  failed_rules: []
  warnings: []
  pending: []
  sibling_conflicts: []
  unresolved_references: []
```

## Sections

### 1. Executive summary
- 一句话陈述：N190 节点对当前 release 的就绪度
- readiness 与 source 4 sibling readiness 的关系（哪一项是最保守约束）
- 待人工决策项（pending[] 中标 `requires_human` 的条目）

### 2. Source artifact rollup
表格列出 4 个 sibling 的 readiness、evidence_profile、conflict_count。

### 3. Namespace consistency report
- `stack_declaration`：4 sibling 取值与是否一致
- `package_layout`：scaffold 主数据，其他 sibling 是否服从
- 类命名空间冲突列表

### 4. Cross-reference resolution
- controller -> service 引用解析率（n / m）
- service -> repository 引用解析率（n / m）
- DTO 类型一致性
- `unresolved_references[]` 详情

### 5. Traces to tasks
- 合并去重后的 N180 task_id 列表
- 缺失追溯（任务在 N180 但本节点未实现，或反之）

### 6. Downstream handoff
- to_N200_dto_vo: required DTO classes
- to_N200_validator: required validation rules
- to_N210_static_check: scope of files
- to_N240_test: method signatures
- to_N330_doc: API surface

### 7. Self check
- failed_rules / warnings / pending 三段式
- quality_self_score 4 维度评分
