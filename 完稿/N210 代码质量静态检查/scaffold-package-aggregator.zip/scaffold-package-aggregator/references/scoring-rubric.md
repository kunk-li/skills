# N190 scaffold package scoring rubric v2.3

总分 8 分，每项 0–2 分。`overall_level` 映射：8 分 = S，6–7 分 = A，4–5 分 = B，<4 分 = C。

## 1. source_integration（源产物整合度）
- **2 分**：4 个 sibling artifact_contract 全部消费、字段全部对齐、controller↔service↔repository 引用全部解析。
- **1 分**：主要 join 完成，但有少量 `unresolved_references[]` 未解决。
- **0 分**：只是把 4 份产物堆叠在一起，未做命名空间或引用关系校验。

## 2. readiness_propagation（readiness 传导）
- **2 分**：`blocked > constrained > provisional > pass` 取最保守口径；source 任一为 blocked 时 package 默认 blocked。
- **1 分**：有 readiness 计算，但门禁规则不完整（如 stack 不一致未触发 reject）。
- **0 分**：不做 readiness 汇总，或在 source 有 blocked 时仍输出 pass。

## 3. namespace_consistency（命名空间一致性）
- **2 分**：4 个 sibling 的 `stack_declaration` / `package_layout` / 类命名 100% 一致；歧义全部解决或显式记录。
- **1 分**：大体一致，少量 stack 或 package 歧义被记录在 `sibling_conflicts[]`。
- **0 分**：命名空间冲突未被识别（如一个 java 一个 kotlin 但 package=pass）。

## 4. downstream_handoff（下游交接）
- **2 分**：`produced_event.emitted_for: [N200, N210, N240, N330]` 完整声明；`traces_to_tasks[]` 去重并按 task_id 排序。
- **1 分**：有 handoff 但部分下游节点字段不完整。
- **0 分**：无 `produced_event` 或无 `downstream_consumers` 段落。

## 红线（直接 0 分）

- aggregator 自行重写 sibling 产物（违反 `R07_no_rebuild`）。
- stack_declaration 不一致但 package readiness 仍输出 pass。
- 4 个 sibling 之间的 unresolved_references 被静默忽略。
