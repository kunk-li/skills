# scaffold-package-aggregator 交付检查清单 v2.3

## A. artifact_contract 完整性
- ☐ 输出以 `artifact_contract` YAML 块开头
- ☐ `schema_version: n190.artifact.v2.3` 已声明
- ☐ `producer_skill: scaffold-package-aggregator`
- ☐ `artifact_type: aggregated_package`
- ☐ `selected_mode` ∈ {`package_summary`, `release_scaffold_package`, `gate_review_package`}

## B. Source artifacts 消费
- ☐ `source_artifacts[]` 列出 4 个 sibling skill 与对应 readiness（`<inherit>` 表示从 sibling 继承）
- ☐ 缺失任一 sibling 时已按 standalone rule 降级 readiness
- ☐ 每个 sibling 的 `evidence_profile` 已传导到 package 级 `evidence_profile`

## C. 一致性校验
- ☐ 4 个 sibling 的 `stack_declaration` 已校验，不一致进入 `sibling_conflicts[]`
- ☐ controller / service / repository 的包路径全部落在 scaffold `package_layout` 内
- ☐ controller -> service 方法引用全部能在 service 草稿中找到，否则进 `unresolved_references[]`
- ☐ service -> repository 方法引用全部能在 repository 草稿中找到，否则进 `unresolved_references[]`
- ☐ DTO / Entity 类型在 controller 与 service 之间引用一致

## D. Readiness gating
- ☐ readiness 取最保守口径（blocked > constrained > provisional > pass）
- ☐ 任一 sibling blocked → package blocked（除非明确排除该层 scope）
- ☐ stack 不一致 → package blocked
- ☐ 存在 unresolved_references → package 至多 constrained
- ☐ 4 sibling 都 pass 且无 unresolved → package pass

## E. Traces 与下游交接
- ☐ `traces_to_tasks[]` 取 4 sibling 并集，去重，按 task_id 排序
- ☐ `downstream_consumers: [N200, N210, N240, N330]` 已声明
- ☐ `produced_event.emitted_for` 列出全部下游节点
- ☐ `unresolved_refs_count` / `sibling_conflicts_count` 已更新

## F. 红线问题
- ☐ 没有自行重写 sibling 产物（违反 `R07_no_rebuild`）
- ☐ 没有在 stack_declaration 不一致时输出 pass
- ☐ 没有静默忽略 unresolved_references
- ☐ 没有把 traces_to_tasks 重复条目带入下游
- ☐ 没有声明 `build_verified` 而未提供构建命令与输出
