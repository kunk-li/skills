---
name: scaffold-package-aggregator
description: aggregate scaffold, controller, service, and repository draft artifacts into a single workflow-aligned scaffold package. use when an llm has or is asked to combine 工程骨架.zip, Controller草稿.java, Service草稿.java, Repository草稿.java into a scaffold package with readiness gating, sibling-conflict reconciliation, downstream handoff, and produced-event metadata.
---
# scaffold-package-aggregator

## Role / 角色定位
本 skill 对齐 `skills_workflow_v2` 中 N190「代码骨架与草稿生成」节点的节点级聚合职责。

它是 **orchestration_result** 型技能：目标是把 `code-scaffold-generation`、`controller-draft-generation`、`service-draft-generation`、`repository-draft-generation` 的产物合并成一份可交付的 **`N190_scaffold_package.zip`**，而不是重新生成骨架、controller、service 或 repository 草稿。

### Boundary / 边界
- 负责校验、合并、去冲突、命名空间统一、依赖一致性检查、节点级 readiness 判定。
- 负责把 4 个 N190 sibling artifact 合成一个可解压、可编译的工程包。
- 不负责重新生成骨架；scaffold 缺失或冲突回推 `code-scaffold-generation`。
- 不负责重新生成 controller / service / repository；签名冲突回推对应 sibling skill。
- 不负责构建（mvn / gradle / npm build）；构建验证由下游 N210 / N240 完成。

## Workflow anchors / 工作流锚点

```yaml
function_bias: orchestration_result
workflow_node: N190
node_artifact_target: N190_scaffold_package.zip
node_artifact_role: aggregated scaffold + drafts package
composition_policy: aggregator_only
content_identity: stable_skill_name_not_archive_number
event_aggregation_note: >
  This skill is the canonical N190 node aggregator. It emits
  produced.N190.scaffold_package after consuming all four sibling
  artifact_contracts (scaffold, controller, service, repository).
```

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `package_summary`：轻量汇总，输出 manifest + readiness rollup，适合评审或上层同步。
- `release_scaffold_package`：默认模式，生成完整 `N190_scaffold_package.zip` 与 manifest。
- `gate_review_package`：聚焦 `blocked` / `constrained` 项与 sibling 间未解决冲突，用于门禁。

## Primary inputs / 主要输入
优先消费以下 N190 sibling artifacts：
- `工程骨架.zip` 或 `code-scaffold-generation` 的 `artifact_contract`
- `Controller草稿.java` 或 `controller-draft-generation` 的 `artifact_contract`
- `Service草稿.java` 或 `service-draft-generation` 的 `artifact_contract`
- `Repository草稿.java` 或 `repository-draft-generation` 的 `artifact_contract`

可选增强输入：
- `N180_planning_package.md` — 用于 traces_to_tasks 校验
- `技术方案分析.md` / `模块边界图.md` — 用于命名空间一致性校验
- `接口设计草案.yaml` / `表结构设计草案.sql` — 用于跨层契约对齐

## Standalone rule / 独立使用规则
即使缺少某一份 sibling artifact，也可以单独使用，但必须按 `references/aggregator-algorithms.yaml` 中的 `partial_input_handling` 降级：

| 可用输入 | readiness | 输出内容 |
|---|---|---|
| 无任何 sibling | `blocked` | `request_for_inputs[]` 列出 4 个所需 skill |
| 仅有 scaffold | `provisional` | manifest + scaffold 层 + `pending_siblings[]` |
| scaffold + controller | `constrained` | 两层包 + controller→service 引用标 `unresolved` |
| scaffold + controller + service | `constrained` | 三层包 + service→repository 引用标 `unresolved` |
| 所有 4 个 sibling | 按 `readiness_propagation` 规则决定 | 完整聚合包 |
| sibling 以文字描述提供（非结构化 YAML） | `provisional` | 从文字提取类名；所有命名空间检查标 `inferred` |

任一 source artifact 为 `blocked` 时，package 默认 `blocked`，除非明确在 `excluded_scope[]` 中排除该层。

### 纯文字输入降级

当输入为自然语言描述（无结构化文件）时：
- 从文字中提取模块名、层次、端点等意图
- 所有推断字段标 `inferred`；`evidence_profile: heuristic_only`
- `readiness: constrained`；`tech_stack_declaration: pending`（未声明时不假设 Java）
- 在 `request_for_inputs[]` 中列出推荐的结构化输入文件

## Required v2 reactive output blocks

每次输出必须以下面的 YAML 块开头：

```yaml
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: scaffold-package-aggregator
  producer_node: N190
  artifact_name: N190_scaffold_package.zip
  artifact_type: aggregated_package
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_sibling | mixed
  source_artifacts:
    - { skill: code-scaffold-generation,    artifact: 工程骨架.zip,        readiness: <inherit> }
    - { skill: controller-draft-generation, artifact: Controller草稿.java, readiness: <inherit> }
    - { skill: service-draft-generation,    artifact: Service草稿.java,    readiness: <inherit> }
    - { skill: repository-draft-generation, artifact: Repository草稿.java, readiness: <inherit> }
  downstream_consumers: [N200, N210, N240, N330]
  traces_to_tasks: []

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending: []
  sibling_conflicts: []

quality_self_score:
  scale: 0_to_2_per_dimension
  dimensions:
    source_integration: null
    readiness_propagation: null
    namespace_consistency: null
    downstream_handoff: null
  overall_level: S | A | B | C
```

## Tech stack adapter / 技术栈适配

本 skill 是聚合器，不直接生成代码，因此不包含独立的技术栈适配规则。技术栈适配由 4 个 sibling skills 各自处理：
- `code-scaffold-generation` — scaffold 层多栈适配
- `controller-draft-generation` — controller 层多栈适配
- `service-draft-generation` — service 层多栈适配
- `repository-draft-generation` — repository 层多栈适配

本 skill 的职责是校验 4 个 sibling 的 `stack_declaration` 必须一致（R02 规则），不一致时 package readiness = blocked。

## Merge rules / 合并规则
- **package layout 主键**：以 `code-scaffold-generation` 输出的 `package_layout` 为主，其他 3 个 sibling 必须遵循该 layout 命名 controller / service / repository 类。
- **stack_declaration 一致性**：4 个 sibling 的 `stack_declaration` 必须一致，否则进入 `sibling_conflicts[]` 并降低 readiness。
- **类名命名空间**：controller 引用的 service 方法签名必须能在 service 草稿中找到；service 引用的 repository 方法必须能在 repository 草稿中找到，否则进 `unresolved_references[]`。
- **DTO / Entity 类型**：service 与 controller 之间的 DTO 类型应一致（实际由 N200 dto-vo-generation 提供，本 aggregator 仅检查类名引用是否一致）。
- **traces_to_tasks 合并**：取 4 个 sibling 的 `traces_to_tasks[]` 并集，去重排序。
- **readiness 取最保守口径**：`blocked` > `constrained` > `provisional` > `pass`。

## Package readiness gating / readiness 判定
- 任一 source artifact 为 `blocked`：package 为 `blocked`，除非 blocked scope 明确不在本 release。
- 任一 source artifact 为 `provisional` 或 `constrained`：package 至多为 `constrained`。
- 4 个 sibling 的 `stack_declaration` 不一致：package 为 `blocked`，必须先回推 sibling 统一。
- 存在 `unresolved_references[]`（controller -> service 或 service -> repository 签名不匹配）：package 为 `constrained`，并写入 `sibling_conflicts[]`。
- 4 个 sibling 都 `pass` 且无未解决引用：package 为 `pass`。

## Execution workflow / 执行流程
1. 识别 4 个 sibling artifact_contract 并解析其 `readiness` / `evidence_profile` / `traces_to_tasks`。
2. 校验 `stack_declaration` 全局一致；不一致进入 `sibling_conflicts[]`。
3. 校验 `package_layout` 与 controller / service / repository 的包路径一致。
4. 解析 controller -> service 方法引用，service -> repository 方法引用；不匹配进入 `unresolved_references[]`。
5. 合并 `traces_to_tasks[]` 并去重。
6. 运行 readiness gating 算出 package 级 `readiness`。
7. 生成 `N190_scaffold_package.zip` manifest 与 `N190_scaffold_package.md` 摘要。
8. 生成 `produced.n190.scaffold_package` 事件 metadata：

```yaml
produced_event:
  event_type: produced.n190.scaffold_package
  contract_version: n190.artifact.v2.3
  artifact_ref: N190_scaffold_package.zip
  emitted_for: [N200, N210, N240, N330]
  unresolved_refs_count: 0
  sibling_conflicts_count: 0
```

9. 输出下游 handoff 给 N200 / N210 / N240 / N330。
10. 使用 checklist 与 common-failure-modes 自检。

## Inline scoring rubric

每次输出完成后用以下标准自评 `quality_self_score`：

| 维度 | 2 分（满分） | 1 分（部分） | 0 分（缺失） |
|---|---|---|---|
| `source_integration` | 4 个 sibling 全部完整 join，命名空间一致 | 主要 join 完成，少量 unresolved | 只是堆叠 4 份产物 |
| `readiness_propagation` | blocked / constrained / provisional 传导正确 | 有 readiness，但规则不完整 | 不做门禁汇总 |
| `namespace_consistency` | stack / package / class 命名 100% 一致 | 大体一致，少量歧义已记录 | 命名空间冲突未被识别 |
| `downstream_handoff` | N200/N210/N240/N330 消费关系明确 | 部分节点可用 | 没有下游契约 |

`overall_level` 映射：8 分 = S，6–7 分 = A，4–5 分 = B，<4 分 = C。

## Machine-readable self_check rules

- `R01_readiness_conservative`: package readiness 取所有 source artifacts 中最保守值（blocked > constrained > provisional > pass）; `on_violation: reject`
- `R02_stack_declaration_consistent`: 4 个 sibling 的 `stack_declaration` 必须一致; `on_violation: reject`
- `R03_package_layout_alignment`: controller / service / repository 的包路径必须落在 scaffold `package_layout` 内; `on_violation: reject`
- `R04_unresolved_references_recorded`: controller -> service 或 service -> repository 签名不匹配必须进入 `unresolved_references[]`; `on_violation: reject`
- `R05_sibling_conflicts_recorded`: 任意 sibling 间的契约冲突必须进入 `sibling_conflicts[]`，不得静默覆盖; `on_violation: reject`
- `R06_traces_dedup`: `traces_to_tasks[]` 必须去重并按 task_id 排序; `on_violation: warn`
- `R07_no_rebuild`: aggregator 禁止重新生成任何 sibling 的产物（如重新写 controller 类）; `on_violation: reject`
- `R08_event_emit_complete`: `produced_event` 必须列出 `emitted_for: [N200, N210, N240, N330]`; `on_violation: reject`

## Common failure modes

1. **静默重写 sibling 产物** — 发现 controller 引用的 service 方法不存在，aggregator 自行补齐 service 方法。修复：必须把缺失签名写入 `unresolved_references[]` 并回推 `service-draft-generation`，aggregator 不修改 sibling 产物。
2. **stack_declaration 不一致被忽略** — 一个 sibling 是 java，另一个是 kotlin，但 package 仍然 readiness=pass。修复：`R02` 强制 reject，必须先把 sibling 拉齐。
3. **traces_to_tasks 重复爆炸** — 4 个 sibling 都引用同一组 task_id，未去重。修复：合并阶段必须按 task_id 唯一化。

## Reference files / 参考文件
- `references/aggregator-algorithms.yaml`: readiness 传导规则、命名空间一致性检查、冲突检测、部分输入处理、traces 合并、事件发布模板
- `references/output-template.md`
- `references/merge-rules.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/scoring-rubric.md`
- `references/orchestration.md`
- `references/example-io.md`
