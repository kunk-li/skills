---
name: thread-safety-risk-check
description: concurrency risk scan — analyze code, diffs, files, or repositories for thread-safety risks including singleton mutable state, unsafe collections (HashMap/ArrayList in Spring beans), ThreadLocal leaks, lazy-init races, double-checked locking errors, volatile gaps, and lock-order deadlock hazards. use when asked to review concurrent code safety, audit Spring singleton beans for shared state, check executor/thread pool usage, or validate atomic operations. contributes thread-safety rows into the shared risk checklist for N210 aggregation.
---
# thread-safety-risk-check

## Role / role positioning
检测单例可变状态、ThreadLocal、并发集合、DCL 和锁顺序风险. This skill is general-purpose and also N210-aware. It can run standalone on a code snippet, file, diff, or repository, and in N210 it contributes to `风险检查清单.csv`.

## 使用场景 / When to use

**直接触发（standalone）：**
- 提供 Service/Repository 代码，要求检查并发安全
- 代码中有 @Service 单例 + 实例字段时
- 怀疑有 ThreadLocal 泄漏或 HashMap 竞态
- 要求 Review 线程池或异步代码安全性

**工作流触发（N210 节点）：**
- N190 骨架生成完成后，进入代码质量检查阶段
- 代码 Review 前的自动化安全扫描

**不触发（边界外）：**
- @Transactional 传播与回滚问题 → 使用 `transaction-boundary-check`
- NPE/空指针风险 → 使用 `null-exception-risk-detection`

## Boundary / 边界
- 负责检测 singleton 可变状态、ThreadLocal 泄漏、不安全集合、DCL 错误、volatile 缺失和锁顺序风险。
- 负责将 critical 级并发风险通过 `sla_escalation_hint` 上报。
- 不负责事务边界问题；事务由 `transaction-boundary-check` 处理。
- 不负责异步消息风险；消息可靠性由 `transaction-boundary-check` 的 outbox 检测覆盖。

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile`.

Allowed modes:
- `bean_state_only` — singleton mutable fields, static state, lazy-init races
- `threadlocal_lifecycle` — ThreadLocal leak, request-scope vs thread-scope mismatch
- `lock_order` — lock hierarchy, deadlock graph, DCL errors, volatile gaps
- `reactive_mode` — Project Reactor / RxJava Scheduler switching, blocking calls in event loop, context propagation (`Context`/`MDC`)
- `virtual_thread_mode` — Java 21+ virtual thread pinning (synchronized + blocking I/O), carrier thread exhaustion, `ReentrantLock` vs `synchronized` guidance


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 代码 + 共享状态分析 + 并发场景说明 全部齐备 | 完整 7 类危险模式覆盖 + fix 多策略 + jcstress 模板 |
| `provisional` | 代码齐备但并发场景（QPS/线程模型）缺 | 输出 finding 但优先级保守，testing_strategy 通用 |
| `constrained` | 仅有部分代码，跨 bean 共享状态分析受限 | 仅输出本文件内可见的并发风险 |
| `blocked` | 仅有项目描述，无代码 | 输出 `request_for_inputs[]` |

## Inputs / input policy
### minimum standalone input
- source code, a single file, a git diff, or a repository path/archive

### workflow-aligned preferred inputs
- source code / diff / repository
- service-layer code from N190
- concurrency design from N170 (`并发控制建议.md`)
- framework config such as Spring bean scope / async executor / scheduler / virtual-thread executor config
- 代码规范检查单.csv from code-standard-check when available
- `enum-definition-generation` output — flag enum (bit-field) thread-safety when accessed concurrently without synchronization

### degradation
- If code exists but context is missing, set `readiness: constrained` and emit only confirmed findings.
- If no code, diff, or relevant artifact exists, set `readiness: blocked`.
- Never fabricate rule links, business intent, runtime proof, or architecture intent from static code alone.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_quality_static_check.thread_safety_risk_check`
  - `workflow_node: N210` when used in workflow, otherwise `standalone`
  - `node_artifact_target: 风险检查清单.csv`
  - `aggregation_strategy: append_with_skill_prefix`  # rows use prefix `tsr.` to avoid id collisions across the 3 contributors
  - `shared_artifact_role: contributor`  # 3 skills contribute rows to the same csv
  - `evidence_profile`
  - `tool_collaboration_mode`
- risk_summary
- thread_safety_risks[]
- bean_state_findings[]
- threadlocal_findings[]
- lock_graph_findings[]
- risk_handoff_bundle
- downstream_handoff
- `severity_matrix`
- `self_check`

Follow `references/n210-shared-contract.md` for shared ids, readiness, severity, `related_standard_check_ids`, and `source_findings[]`.

## V2 schema contract
Consult `references/v2-schema-catalog.md` whenever the request needs precise enums, rule kinds, fix strategies, thresholds, or handoff fields. Do not invent alternate enum names when the catalog contains a suitable value.

## Execution workflow / execution workflow
1. Confirm available code and workflow context.
2. Select the narrowest mode that satisfies the request.
3. Apply this skill's owner rules and avoid duplicating other N210 skills.
4. Emit stable ids and cross-skill references.
5. Hand off to N220, N260, N370, N390, or refactoring as appropriate.


## Common failure modes

1. **虚拟线程 pinning 漏检** — 检测到 `synchronized` 块但未判断内部是否有 blocking I/O（JDBC、文件读写、`Thread.sleep`），漏报 Java 21 carrier thread pinning 风险。修复：`virtual_thread_mode` 下必须检查 `synchronized` 块内的 blocking call；发现时输出到 `pinning_risks[]`。
2. **ThreadLocal 泄漏范围误判** — 在非线程池场景（如每次请求新建线程）下将 ThreadLocal 标为泄漏风险。修复：检查线程生命周期；只有在线程池或 virtual thread 高并发场景下才将 ThreadLocal 列为 `threadlocal_findings[]` 高风险项。
3. **DCL 双重检查锁假阳性** — 已使用 `volatile` 修饰的 DCL 被误报为不安全。修复：检测 DCL 时必须同时确认 `volatile` 标注缺失才报告；已有 `volatile` 且 JDK ≥ 5 的 DCL 标为合规。

## Event publication and N210 aggregation

This skill is a sub-skill of the N210 · 代码质量静态检查 node. It does **not** publish a produced event independently to the event bus.

**How events are published:**
1. This skill outputs its findings with stable `finding_id` values and a populated `downstream_handoff` block.
2. `code-standard-check` (running in `node_aggregation` mode) collects findings from all N210 sub-skills via `source_findings[]`.
3. After aggregation, `code-standard-check` publishes `produced.n210.code_quality_static_check.completed` to the event bus, which triggers N330, N370, N390 subscribers.

**Implication for standalone use:** when this skill is used outside the N210 workflow, callers are responsible for emitting any required produced event.

## SLA escalation to N380

When this skill emits findings with `severity: critical` (P0) or `severity: high` (P1):
- Include `sla_escalation_hint: true` in the finding's `downstream_handoff`.
- Downstream `code-standard-check` aggregator will propagate this flag to N380 · 平台门禁与人工协同 for SLA queue entry.
- Do not attempt to directly invoke N380 from within this skill.

```yaml
# Example finding with escalation hint
finding_id: TXNBC-001
severity: critical
sla_escalation_hint: true
escalation_reason: "Missing rollback on exception path in payment service"
recommended_human_action: "Review transaction boundary before merge"
```

## Quality bar / quality bar
A good result lets downstream reviewers, gate owners, or the N210 aggregator act immediately without normalizing severity, guessing ownership, or re-reading raw code to understand the issue.

## Modern concurrency coverage

| Technology | Key checks | Mode |
|---|---|---|
| Classic threads / synchronized | DCL, volatile gaps, lock ordering, unsafe static | `lock_order`, `bean_state_only` |
| Java `ThreadLocal` | Leak in thread pool, request scope mismatch, `InheritableThreadLocal` with virtual threads | `threadlocal_lifecycle` |
| Project Reactor / WebFlux | Blocking call in non-blocking thread (`block()`, JDBC in Reactor), Scheduler boundary loss, `Context` propagation | `reactive_mode` |
| RxJava | `observeOn` / `subscribeOn` correctness, shared subject thread safety | `reactive_mode` |
| Java 21 Virtual Threads | `synchronized` block holding blocking I/O → carrier thread pinning; recommend `ReentrantLock`; `ThreadLocal` memory amplification | `virtual_thread_mode` |
| Netty / Vert.x event loop | Blocking operation in I/O thread, state mutation across event loop boundaries | `bean_state_only` + `reactive_mode` |
| Kotlin Coroutines | Mutable shared state without `Mutex`, `withContext` for CPU-bound tasks | `reactive_mode` |

When `virtual_thread_mode` is selected, output must include:
- `pinning_risks[]` — synchronized blocks or methods containing blocking I/O
- `reentrantlock_candidates[]` — synchronized blocks that can be safely replaced
- `threadlocal_memory_impact` — estimate of ThreadLocal amplification under high virtual-thread count


## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Tech stack adapter / 技术栈适配

并发风险检测按语言/框架自动适配：

| 语言/框架 | 关键检测点 |
|---|---|
| Java/Spring | @Service singleton 可变字段、HashMap→ConcurrentHashMap、ThreadLocal 泄漏、DCL 错误 |
| Kotlin/Coroutines | coroutine scope 泄漏、SharedFlow/StateFlow 竞态、Mutex vs synchronized |
| TypeScript/Node.js | 全局变量共享、EventEmitter 未移除监听器、异步竞态（async/await + 共享状态） |
| Python | threading.Thread 共享数据、asyncio 任务取消安全、GIL 不保护复合操作 |
| Go | goroutine 泄漏、channel 死锁、sync.Map vs map + mutex、data race (go race detector) |

当语言未声明时：从文件扩展名或语法特征推断；推断结果记入 `inferred[]`。

## Produced event / 产物事件

当作为 N210 工作流节点的子技能执行时，本 skill 的产物通过以下事件元数据向下游声明可用性：

```yaml
event_emission:
  emitted_by: standalone_skill  # 本 skill 不自行发布节点级事件
  node_event_publisher: code-standard-check  # N210 唯一事件发布者（node_aggregation 模式）
  artifact_ready_signal: artifact_contract.readiness in [pass, provisional]
  downstream_consumers: [N220, N240, N260, N330, N370, N390]
  finding_contribution:
    target_artifact: "风险检查清单.csv (thread rows)"
    finding_id_prefix: "SEE_SKILL_SELF_CHECK"
```

在 standalone 模式下：直接输出发现列表，无需声明节点事件；节点级事件由 `code-standard-check` 的 `node_aggregation` 模式统一发布。

## Machine-readable self_check rules

- `R01_mode_declared`: `selected_mode` 必须是允许模式之一; `on_violation: reject`
- `R02_finding_id_stable`: 每条 finding 必须有格式为 `TSR-{MODE}-{NNN}` 的稳定 `finding_id`; `on_violation: reject`
- `R03_severity_set`: `severity` 必须是 `critical | high | medium | low | info` 之一; `on_violation: reject`
- `R04_sla_hint_critical`: `severity: critical` 必须附 `sla_escalation_hint: true`; `on_violation: reject`
- `R05_virtual_thread_pinning_checked`: `virtual_thread_mode` 下必须输出 `pinning_risks[]` 和 `reentrantlock_candidates[]`; `on_violation: reject`
- `R06_dcl_volatile_verified`: DCL 检测必须同时确认 `volatile` 缺失；已有 `volatile` 且 JDK ≥ 5 的 DCL 不得标为高风险; `on_violation: warn`
- `R07_threadlocal_scope_checked`: ThreadLocal 泄漏只在线程池或虚拟线程高并发场景下标为高风险; `on_violation: warn`
- `R08_no_fabricated_concurrency_proof`: 不得声称已发现运行时竞态条件；静态分析结论必须标明局限; `on_violation: reject`
- `R09_lock_graph_acyclic`: `lock_order` 模式下必须检测死锁候选并在 `lock_graph_findings[]` 中输出; `on_violation: warn`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff` 和 `risk_handoff_bundle`; `on_violation: reject`

## Machine-readable SLA escalation rule

- `R_SLA_01`: Any finding with `severity: critical` MUST include `sla_escalation_hint: true`; `on_violation: warn`.
- `R_SLA_02`: Any finding with `severity: high` SHOULD include `sla_escalation_hint: true`; `on_violation: warn`.

## Reference files / reference files
- `references/thread-safety-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/thread-safety-self-check.yaml`: R01-R10 机读门禁规则
- `references/thread-safety-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/thread-safety-catalog.md`
- `references/output-template.md`
- `references/n210-shared-contract.md`
- `references/v2-schema-catalog.md`
- `references/aggregation-handoff.md`
- `references/orchestration.md`
- `references/severity-matrix.md`
- `references/business-traceability.md`
- `references/tool-collaboration.md`
- `references/readiness-inheritance.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/n210-integration-map.md`
- `references/scoring-rubric.md`
- `references/risk-bundle-contract.md`
