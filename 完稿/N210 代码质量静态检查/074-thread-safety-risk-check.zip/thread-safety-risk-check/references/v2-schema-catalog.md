# V2 schema catalog

This file is the enum and field source of truth. `thread-safety-catalog.md` gives narrative detection guidance.

## risk_kind values
- TS-001_stateful_singleton
- TS-002_non_thread_safe_class
- TS-003_unsafe_collection
- TS-004_threadlocal_not_removed
- TS-005_dcl_wrong
- TS-006_static_mutable_state
- TS-007_lazy_init_race
- TS-008_deadlock_risk
- TS-009_incorrect_synchronization
- TS-010_volatile_missing

## thread_source values
- http_request_threads
- scheduled_thread_pool
- async_executor
- message_consumer
- manual_thread

## fix_strategy values
- make_immutable
- synchronize
- use_thread_safe_class
- use_atomic
- use_volatile
- scope_to_method_local
- remove_threadlocal
- use_stream_instead_of_shared_state
- use_lock_ordering

## required fields
- `concurrent_access_analysis`: accessed_by_threads[], shared_state_identified[].
- `remediation`: fix_strategy, before, after, rationale, auto_fixable.
- `test_recommendation`: stress_test, race_detector_tool.
