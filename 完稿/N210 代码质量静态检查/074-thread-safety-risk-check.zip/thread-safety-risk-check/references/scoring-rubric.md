# thread-safety-risk-check 评分标准 v2.4

## 总览

输出按 4 个维度评分，每维 0-3 分，总分 0-12。

| 总分 | 等级 | 含义 |
|---|---|---|
| 11-12 | **S** | 可直接消费 |
| 9-10 | **A** | 生产可用 |
| 6-8 | **B** | 需人工修订 |
| ≤5 | **C** | 不建议消费 |

---

## 维度 1: 危险模式覆盖度 (concurrency_pattern_coverage)

衡量: 是否覆盖 7 大类并发危险模式.

| 等级 | 标准 |
|---|---|
| **S (3)** | 覆盖全部 7 类: (1) singleton mutable state; (2) ThreadLocal leak (未 remove 在线程池); (3) unsafe collection (HashMap/ArrayList 在多线程使用); (4) lazy-init race (DCL 错误); (5) volatile gap (写后读); (6) lock ordering (deadlock 风险); (7) atomicity violation (check-then-act). 每类含 ≥1 finding |
| **A (2)** | 覆盖 5-6 类 |
| **B (1)** | 仅覆盖 3-4 类 |
| **C (0)** | 仅识别明显的 synchronized 缺失 |

---

## 维度 2: 共享状态溯源 (shared_state_tracing)

衡量: 每条 finding 是否追溯到共享状态来源 (static field / singleton / cache / Spring bean).

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% finding 含 shared_state_source (static_field / singleton_bean / cache_layer / threadlocal / external_state) + access_pattern (read_only / write_only / read_write) |
| **A (2)** | ≥80% 含 source, 余下仅指 "线程不安全" |
| **B (1)** | 仅识别 mutability, 未做 source 追溯 |
| **C (0)** | 把 method-local 变量误标线程不安全 |

---

## 维度 3: 修复策略多样性 (fix_strategy_diversity)

衡量: 修复建议是否分场景给出 4 种策略 (immutability / synchronization / thread-confinement / atomic-cas).

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% finding 给 ≥2 种修复选项 + 推荐选项 + 选择理由 (基于读写比例和性能要求): immutability (Collections.unmodifiableList/copy-on-write), synchronization (synchronized/ReentrantLock), thread-confinement (ThreadLocal/单线程化), atomic-cas (AtomicXxx/ConcurrentHashMap) |
| **A (2)** | 给 1 种主推策略 + 简要替代方案 |
| **B (1)** | 仅给一种修复, 无替代分析 |
| **C (0)** | 一律建议 synchronized, 无场景差异 |

---

## 维度 4: 测试与验证策略 (testing_strategy)

衡量: 是否含并发测试建议 (jcstress / TLA+ / 压测 / chaos).

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% high/critical finding 含 testing_strategy (jcstress 模板 / 压测路径 / 模拟竞争场景), 含 verification_hint (如何确认修复有效) |
| **A (2)** | ≥80% high/critical 含测试建议 |
| **B (1)** | 仅给测试方向 (e.g. "建议加并发测试") |
| **C (0)** | 无测试建议 |

---

## 红线 (违反则直接归 C 或 0)

- 把 method-local 变量、final field、effectively immutable 标为线程不安全 -> 误检
- 推荐 synchronized this -> 反模式 (与 lock public 等价)
- 推荐 Vector / Hashtable -> 已淘汰类
- finding_id 不含 tsr. 前缀 -> aggregation 协议违反

---

## 等级映射示例

- **S+ (12)**: 7 类全覆盖 + 状态溯源 + 多策略修复 + 测试方案
- **S (11)**: 3 维满分 + 1 维 A
- **A (9-10)**: 主要类覆盖, 单策略推荐
- **B (6-8)**: 类覆盖部分, 修复粗略
- **C (<6)**: 误检多 / 一刀切 synchronized

---

## 自评示例

```yaml
self_score:
  concurrency_pattern_coverage: 3
  shared_state_tracing: 3
  fix_strategy_diversity: 3
  testing_strategy: 2
  total: 11
  band: S
  rationale: 4 条 high finding 仅给测试方向, 未提供 jcstress 模板
```
