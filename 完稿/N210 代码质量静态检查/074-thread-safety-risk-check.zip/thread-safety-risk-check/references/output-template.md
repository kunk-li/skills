# Output template: shared thread-safety risk contribution

Artifact target: risk checklist / 风险检查清单.csv

Required sections:
1. metadata
2. risk_summary
3. thread_safety_risks[]
4. concurrent_access_analysis[]
5. bean_state_findings[]
6. threadlocal_findings[]
7. lock_graph_findings[]
8. test_recommendation
9. self_check

Risk fields:
| risk_id | severity | confidence | risk_family | risk_kind | location | thread_sources | shared_state | evidence | fix_strategy | recommendation | linked_rules | linked_nfr | related_standard_check_ids | source_skill |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Allowed `risk_kind` values: TS-001_stateful_singleton, TS-002_non_thread_safe_class, TS-003_unsafe_collection, TS-004_threadlocal_not_removed, TS-005_dcl_wrong, TS-006_static_mutable_state, TS-007_lazy_init_race, TS-008_deadlock_risk, TS-009_incorrect_synchronization, TS-010_volatile_missing.
Allowed `thread_source` values: http_request_threads, scheduled_thread_pool, async_executor, message_consumer, manual_thread.
Allowed `fix_strategy` values: make_immutable, synchronize, use_thread_safe_class, use_atomic, use_volatile, scope_to_method_local, remove_threadlocal, use_stream_instead_of_shared_state, use_lock_ordering.

Cross-skill fields: all rows should include `confidence`, `related_standard_check_ids`, and `source_skill` when applicable.
