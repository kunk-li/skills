# Example IO: thread-safety-risk-check

## Scenario A: Standalone concurrency scan

### Input

```java
@Service
public class CounterService {
    private int totalRequests = 0;             // (1) singleton mutable state
    private static Map<String, User> userCache = new HashMap<>();  // (2) unsafe collection
    private ThreadLocal<RequestContext> ctx = new ThreadLocal<>(); // (3) potential leak in pool
    private volatile boolean initialized;       // (4) volatile, but with lazy-init
    private static UserService instance;        // (5) DCL pattern below
    
    public void increment() { totalRequests++; }   // (6) check-then-act, atomicity violation
    
    public void cacheUser(String id, User user) {
        userCache.put(id, user);   // unsafe write
    }
    
    public RequestContext getContext() { return ctx.get(); }
    public void setContext(RequestContext c) { ctx.set(c); }   // never .remove() -> leak
    
    public static UserService getInstance() {
        if (instance == null) {                  // (7) DCL with non-volatile field
            synchronized (UserService.class) {
                if (instance == null) {
                    instance = new UserService();
                }
            }
        }
        return instance;
    }
    
    public synchronized void doSomething() {       // (8) sync on this is questionable
        otherService.process();
    }
}
```

### Output

```yaml
artifact_contract:
  schema_version: n210.thread-safety-risk-check.v2.4
  produced_by: thread-safety-risk-check
  selected_mode: standalone_scan
  readiness: pass
  evidence_profile: code_only

risks:
  - finding_id: tsr.0001
    severity: critical
    issue_kind: atomicity_violation
    pattern: "check_then_act"
    location: {file: CounterService.java, line: 10}
    shared_state_source: singleton_mutable_state
    access_pattern: read_write
    snippet: "totalRequests++"
    danger_explanation: "++ is not atomic: read, increment, write. Two threads can both read 5, both write 6, losing one increment."
    fix_options:
      - choice: AtomicInteger
        code: "private final AtomicInteger totalRequests = new AtomicInteger(0); ... totalRequests.incrementAndGet()"
        when_suitable: "high-throughput counter, no compound condition"
        performance: "lock-free; best"
      - choice: synchronized
        code: "synchronized (this) { totalRequests++; }"
        when_suitable: "if combined with other state changes"
        performance: "lock contention under high load"
      - choice: LongAdder
        code: "private final LongAdder requests = new LongAdder(); ... requests.increment()"
        when_suitable: "extremely high contention; reads via .sum() are slower"
        performance: "best for write-heavy"
    recommended: AtomicInteger
    testing_strategy:
      jcstress_template: |
        @JCStressTest
        @Outcome(id = "20", expect = ACCEPTABLE)
        @State public class CounterTest {
            CounterService s = new CounterService();
            @Actor public void a1() { for (int i=0;i<10;i++) s.increment(); }
            @Actor public void a2() { for (int i=0;i<10;i++) s.increment(); }
            @Arbiter public void result(I_Result r) { r.r1 = s.getTotal(); }
        }
      verification_hint: "JCStress run; expect total=20 always; pre-fix: occasionally <20"

  - finding_id: tsr.0002
    severity: critical
    issue_kind: unsafe_collection
    location: {file: CounterService.java, line: 4, 13}
    shared_state_source: static_field
    access_pattern: read_write
    snippet: "static Map<String, User> userCache = new HashMap<>(); ... userCache.put(id, user)"
    danger_explanation: "HashMap.put can corrupt internal table on concurrent write; documented infinite loop in put()"
    fix_options:
      - choice: ConcurrentHashMap
        code: "static Map<String, User> userCache = new ConcurrentHashMap<>()"
        when_suitable: "default, scales to high concurrency"
        performance: "lock-striping, near lock-free reads"
      - choice: Collections.synchronizedMap
        code: "Collections.synchronizedMap(new HashMap<>())"
        when_suitable: "rarely; iteration must be externally synchronized"
        performance: "single lock, contended"
      - choice: Caffeine.newBuilder().build()
        when_suitable: "if eviction/expiry needed"
    recommended: ConcurrentHashMap
    testing_strategy:
      verification_hint: "stress test 100 threads x 1000 puts; assert final size=100k and no NPE/CME"

  - finding_id: tsr.0003
    severity: high
    issue_kind: threadlocal_leak
    location: {file: CounterService.java, line: 6, 19}
    shared_state_source: threadlocal
    access_pattern: read_write
    danger_explanation: "ctx.set() called but never ctx.remove(); when used in thread pool, RequestContext leaks across requests"
    fix_options:
      - choice: try_finally_remove
        code: "try { ctx.set(c); ... } finally { ctx.remove(); }"
        when_suitable: "request-scoped lifecycle"
      - choice: spring_request_scope
        code: "@RequestScope managed bean instead of ThreadLocal"
        when_suitable: "Spring projects"
    recommended: try_finally_remove
    
  - finding_id: tsr.0004
    severity: critical
    issue_kind: dcl_volatile_missing
    location: {file: CounterService.java, line: 7, 22-29}
    shared_state_source: static_field
    access_pattern: lazy_init
    danger_explanation: "Double-Checked Locking requires `volatile`; without it, partially-constructed instance may be visible. JLS Memory Model issue."
    fix_options:
      - choice: add_volatile
        code: "private static volatile UserService instance;"
        when_suitable: "keep DCL pattern"
      - choice: holder_idiom
        code: "private static class Holder { static final UserService INSTANCE = new UserService(); } public static UserService getInstance() { return Holder.INSTANCE; }"
        when_suitable: "preferred; JVM handles lazy init"
    recommended: holder_idiom
    
  - finding_id: tsr.0005
    severity: medium
    issue_kind: lock_on_this
    pattern: "synchronized_on_this"
    location: {file: CounterService.java, line: 31}
    danger_explanation: "synchronized on `this` exposes lock to outside; external code can synchronize on the same instance and create deadlock. Also: holds lock during otherService.process() (potential long operation)."
    fix_options:
      - choice: private_lock_object
        code: "private final Object lock = new Object(); synchronized (lock) { ... }"
      - choice: ReentrantLock
        when_suitable: "if tryLock() or interruptible needed"
      - choice: shrink_critical_section
        code: "compute outside, sync only the state mutation"
    recommended: shrink_critical_section
    secondary: private_lock_object

statistics:
  patterns_covered:
    singleton_mutable_state: 1
    threadlocal_leak: 1
    unsafe_collection: 1
    lazy_init_race: 1
    volatile_gap: 1
    lock_ordering: 0     # not present in input
    atomicity_violation: 1
  total_categories_covered: 6  # of 7

aggregation:
  shared_artifact_role: contributor
  aggregation_strategy: append_with_skill_prefix
  artifact: 风险检查清单.csv
  prefix: tsr.
```

### Self-score

```yaml
self_score:
  concurrency_pattern_coverage: 3  # 6/7, lock_ordering not in input
  shared_state_tracing: 3
  fix_strategy_diversity: 3        # multi-option for each finding with rationale
  testing_strategy: 3              # jcstress template + verification hint
  total: 12
  band: S+
```

---

## Common readiness states

| readiness | when |
|---|---|
| `pass` | full code + concurrent context |
| `constrained` | only synchronization-related diff |
| `blocked` | only descriptions |
