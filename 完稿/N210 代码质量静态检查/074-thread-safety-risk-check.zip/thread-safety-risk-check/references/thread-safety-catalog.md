# Thread-safety catalog

Use v2 TS identifiers exactly. This file gives narrative guidance; `v2-schema-catalog.md` is the enum source of truth.

| risk_kind | meaning | default severity | common fix |
|---|---|---|---|
| TS-001_stateful_singleton | Spring singleton bean contains mutable request state | critical | move state to method local or request scope |
| TS-002_non_thread_safe_class | shared use of SimpleDateFormat, Calendar, or similar | high | DateTimeFormatter or isolate per call |
| TS-003_unsafe_collection | shared ArrayList/HashMap/HashSet in concurrent context | high | ConcurrentHashMap, synchronized wrapper, immutable copy |
| TS-004_threadlocal_not_removed | ThreadLocal set without finally remove in pooled thread | high | try/finally remove |
| TS-005_dcl_wrong | double-checked locking without volatile | critical | add volatile or use holder pattern |
| TS-006_static_mutable_state | static mutable field shared across threads | high | immutable/final or synchronized/atomic access |
| TS-007_lazy_init_race | lazy init without safe publication | high | synchronize, volatile, holder, or eager init |
| TS-008_deadlock_risk | inconsistent lock ordering | critical | global lock order or reduce lock scope |
| TS-009_incorrect_synchronization | synchronizing on interned or boxed objects | high | private final lock object |
| TS-010_volatile_missing | cross-thread flag or reference lacks visibility guarantee | high | volatile/Atomic/lock or redesign |

Always name likely thread sources: HTTP request threads, scheduler, async executor, message consumer, or manual thread.
