# thread-safety-risk-check 常见失败模式 v2.4

## 通用部分（F1-F4）

### F1. 把推断包装成确定事实

**症状**：标 `severity: critical` 的 race condition 但实际共享状态是 effectively immutable

**影响**：误报；用户拒绝建议（synchronized 一个 final field 没意义）；信任损失

**修正**：shared_state_source 必须是 actually mutable；effectively immutable / final field 不输出 finding

---

### F2. 没有位置或范围仍给强结论

**症状**：finding 仅说 "线程不安全"，没有 access_pattern (read/write) 也没有 shared_state_source

**影响**：无法判断风险等级；fix 选项无法评估

**修正**：location + shared_state_source + access_pattern (read_only/write_only/read_write) 必填

---

### F3. 同类问题机械穷举

**症状**：对每个 HashMap 字段都标线程不安全；10 个字段 10 条 finding

**影响**：高风险并发问题（如 lazy_init race）被淹没

**修正**：按 pattern 聚合 (singleton_state / unsafe_collection / threadlocal_leak)；同 pattern 仅 1 条主 finding + sample

---

### F4. 只说问题不说原因或建议

**症状**：建议 "加 synchronized" 但不分场景

**影响**：用户一律 synchronized 加锁；性能下降；并不一定是正确的修复

**修正**：fix_options 至少给 immutability + synchronization + thread-confinement + atomic-cas 4 类，含选择理由

---

## 本 skill 重点（F5-F8）

### F5. 把 method-local 变量误标线程不安全

**症状**：method 内部 `Map<String, Integer> counts = new HashMap<>();` 被标线程不安全。

**影响**：method-local 变量栈隔离，不可能被多线程访问；finding 错误，用户 100% 拒绝。

**修正**：
- shared_state 检测必须从 field（含 static）出发，不分析 method-local 变量。
- 例外：method-local 变量传给 lambda + 异步执行（CompletableFuture / parallelStream）时才检查 capture。

---

### F6. 推荐 synchronized this 等反模式

**症状**：fix_options 推荐 `synchronized (this) { ... }` 或 `synchronized (UserService.class) { ... }`。

**影响**：synchronized 在 public 锁等于把锁暴露给外部；外部代码可以与本类竞争 / 死锁。

**修正**：
- fix_options 推荐 `private final Object lock = new Object();` 或 `ReentrantLock`，禁止推荐 `synchronized this/class`。
- 检测项目代码中已有的 `synchronized (this)` 直接标 finding（即使其他逻辑无问题）。

---

### F7. 推荐已淘汰类（Vector / Hashtable）

**症状**：fix_options 推荐 `new Vector<>()` 或 `new Hashtable<>()` 替代 ArrayList / HashMap。

**影响**：Vector / Hashtable 性能差（method-level 锁 vs ConcurrentHashMap 的 lock-striping）；用户可能不接受 / 不知道 trade-off。

**修正**：
- 推荐顺序：ConcurrentHashMap > Collections.synchronizedMap > Hashtable（最后选项，仅遗留代码兼容）。
- 推荐 CopyOnWriteArrayList > Collections.synchronizedList > Vector。

---

### F8. finding_id 不含 tsr. 前缀

**症状**：与 npe.* / txn.* 共用 风险检查清单.csv，但 finding_id 仅 TSR-001。

**影响**：aggregation 时 id 冲突；node_aggregation 时无法精确合并。

**修正**：finding_id 必须 `tsr.0001` 格式；aggregation_strategy 显式声明 append_with_skill_prefix。

