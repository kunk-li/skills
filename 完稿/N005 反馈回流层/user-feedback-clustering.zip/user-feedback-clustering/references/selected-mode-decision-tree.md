# Feedback-loop selected-mode decision tree

Select exactly one `selected_mode` and record it in the metadata sidecar. Run `scripts/validate_decision_tree.py .` to ensure this file, `SKILL.md`, `field-contract.yaml`, and `metadata-schema.json` stay aligned.

## user-feedback-clustering
1. Use `nps_feedback` when NPS/open-text survey comments dominate.
2. Use `support_ticket_batch` when support tickets or complaints dominate.
3. Use `app_review_mining` when app-store/public review text dominates.
4. Use `interview_note_clustering` when qualitative research notes dominate.
5. Use `mixed_feedback` when no single feedback source dominates.

## production-signal-aggregation
1. Use `runtime_error_rollup` when runtime_source monitoring/log/frequent-error artifacts dominate.
2. Use `incident_signal_rollup` when postmortem_source postmortem artifacts dominate.
3. Use `defect_trend_rollup` when defect_source defect tables dominate.
4. Use `feedback_pack` when the explicit output is a compact feedback handoff package.
5. Use `multi_source_aggregation` when runtime, defect, incident, and feedback sources are mixed.

## data-driven-requirement-mining
1. Use `backlog_seed` for novel or unclear demand candidates headed to intake.
2. Use `reprioritization` for known scope, existing backlog refs, or urgent reordering headed to reprioritization.
3. Use `incident_prevention` when recurrent incidents drive the hypothesis.
4. Use `customer_pain_mining` when feedback/NPS themes drive the hypothesis.
5. Use `mixed_signal_mining` when production, defect, and feedback evidence all contribute.

## Mode to output contract map

| skill | selected_mode | expected_primary_output | route_guard | required_contract_fields |
|---|---|---|---|---|
| user-feedback-clustering | nps_feedback | 用户反馈聚类表.csv | handoff to PSA/DDRM only | cluster_id,theme,pain_point,feedback_count,representative_evidence_refs,confidence |
| user-feedback-clustering | support_ticket_batch | 用户反馈聚类表.csv | handoff to PSA/DDRM only | cluster_id,theme,pain_point,feedback_count,representative_evidence_refs,confidence |
| user-feedback-clustering | app_review_mining | 用户反馈聚类表.csv | handoff to PSA/DDRM only | cluster_id,theme,pain_point,feedback_count,representative_evidence_refs,confidence |
| user-feedback-clustering | interview_note_clustering | 用户反馈聚类表.csv | handoff to PSA/DDRM only | cluster_id,theme,pain_point,feedback_count,representative_evidence_refs,confidence |
| user-feedback-clustering | mixed_feedback | 用户反馈聚类表.csv | handoff to PSA/DDRM only | cluster_id,theme,pain_point,feedback_count,representative_evidence_refs,confidence |
| production-signal-aggregation | runtime_error_rollup | 线上痛点信号包.json | no final priority decision | signal_id,source_type,observed_problem,evidence_refs,confidence,priority_hint,dedupe_key |
| production-signal-aggregation | incident_signal_rollup | 线上痛点信号包.json | no final priority decision | signal_id,source_type,observed_problem,evidence_refs,confidence,priority_hint,dedupe_key |
| production-signal-aggregation | defect_trend_rollup | 线上痛点信号包.json | no final priority decision | signal_id,source_type,observed_problem,evidence_refs,confidence,priority_hint,dedupe_key |
| production-signal-aggregation | feedback_pack | 线上痛点信号包.json | no final priority decision | signal_id,source_type,observed_problem,evidence_refs,confidence,priority_hint,dedupe_key |
| production-signal-aggregation | multi_source_aggregation | 线上痛点信号包.json | no final priority decision | signal_id,source_type,observed_problem,evidence_refs,confidence,priority_hint,dedupe_key |
| data-driven-requirement-mining | backlog_seed | 数据驱动需求建议.csv | route novel/unclear to intake | suggestion_id,hypothesis_title,user_problem,source_signal_ids,proposed_route,anti_goal,validation_question,recommended_action |
| data-driven-requirement-mining | reprioritization | 数据驱动需求建议.csv | route known urgent scope to reprioritization | suggestion_id,hypothesis_title,user_problem,source_signal_ids,proposed_route,anti_goal,validation_question,recommended_action |
| data-driven-requirement-mining | incident_prevention | 数据驱动需求建议.csv | choose intake or reprioritization, never both | suggestion_id,hypothesis_title,user_problem,source_signal_ids,proposed_route,anti_goal,validation_question,recommended_action |
| data-driven-requirement-mining | customer_pain_mining | 数据驱动需求建议.csv | usually intake unless existing backlog is known | suggestion_id,hypothesis_title,user_problem,source_signal_ids,proposed_route,anti_goal,validation_question,recommended_action |
| data-driven-requirement-mining | mixed_signal_mining | 数据驱动需求建议.csv | choose intake or reprioritization, never both | suggestion_id,hypothesis_title,user_problem,source_signal_ids,proposed_route,anti_goal,validation_question,recommended_action |
