# user-feedback-clustering quality checklist

This skill inherits the 11 common feedback-loop checks from `references/shared-feedback-loop-contract.md#common-quality-checklist`. Do not duplicate the shared list here; keep this file skill-specific.

## Common checklist source
The common 11-point checklist lives only in `references/shared-feedback-loop-contract.md#common-quality-checklist`. This file intentionally contains only skill-specific checks to avoid divergence.

## Skill-specific checks
1. Cluster before suggesting requirements; do not emit backlog items from raw comments.
2. Use privacy-safe summaries and redact emails, phones, tokens, names, or account identifiers unless explicitly required.
3. Treat feedback_count=1 as low/medium confidence unless corroborated by another evidence source.
4. Populate dedupe_key and handoff_signal_tags for PSA/DDRM joins.
5. Keep sentiment, severity_hint, and frequency_hint separate from final product priority.

## Release command
```bash
python scripts/validate_release_consistency.py .
```

## Optional composed handoff checks
```bash
python scripts/validate_feedback_handoff.py --ufc path/to/ufc_a.csv --ufc path/to/ufc_b.csv --psa path/to/psa.json --ddrm path/to/ddrm.csv --strict
python scripts/validate_downstream_handoff.py --ddrm path/to/ddrm.csv --strict
```
