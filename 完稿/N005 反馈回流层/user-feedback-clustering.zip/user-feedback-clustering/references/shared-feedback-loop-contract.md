# Shared feedback-loop contract / 反馈回流共享契约

## Skill family identity
```yaml
skill_family: feedback-loop-suite
stage_hint: feedback_loop
host_workflow_node: <provided by host workflow>
contract_version: feedback-loop-suite-v1.4.1
artifact_family_id: feedback-loop-suite
primary_outputs:
  - 线上痛点信号包.json
  - 数据驱动需求建议.csv
reactive_inputs:
  - signal.runtime_to_feedback
  - signal.postmortem_to_feedback
  - signal.defect_to_feedback
  - signal.external.feedback
downstream_routes:
  - intake
  - reprioritization
```

## Feedback-loop mission
the feedback-loop skill family turns production evidence and user feedback into clean, traceable evidence packages. It is not a replacement for product decision-making. It prepares evidence-backed requirement hypotheses and routes them to intake or reprioritization lanes configured by the host workflow.

## Source artifacts
Preferred source artifacts:
- `高频报错摘要.md` from runtime monitoring / `frequent-error-summary`
- `线上问题复盘.md` or `故障复盘.md` from incident/postmortem sources / `production-incident-postmortem`
- `缺陷分类表.csv` from defect sources / `defect-classification`
- user feedback, NPS, support tickets, survey notes, app-store reviews, customer calls, or VOC notes

## Core join keys
Use these keys whenever possible:
- `source_id`
- `source_type`: `runtime_error / incident_postmortem / defect / user_feedback / nps / support_ticket / survey / other`
- `source_node`: `defect_source / runtime_source / postmortem_source / external / unknown`
- `time_window`
- `service_scope`
- `feature_area`
- `user_segment`
- `incident_id`
- `defect_id`
- `feedback_id`
- `cluster_id`
- `signal_id`
- `suggestion_id`
- `evidence_refs[]`

## Artifact identity and metadata sidecar
Every final CSV/JSON artifact should have a paired `*.metadata.yaml` sidecar with:
- `contract_version: feedback-loop-suite-v1.4.1`
- `skill_family: feedback-loop-suite`, `stage_hint: feedback_loop`, and `host_workflow_node` supplied by the host workflow
- `artifact_family_id: feedback-loop-suite`
- `artifact_id` using the Feedback id space
- `schema`, `selected_mode`, `readiness`, `confidence`, `source_artifacts`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`

Use `references/metadata-schema.json` and `scripts/validate_metadata.py` whenever file execution is available. Metadata schemas set `additionalProperties: false`; unknown metadata keys should fail validation rather than being silently ignored.

## Evidence and confidence
Evidence references should point to source artifacts or uploaded material. Prefer stable anchors:
- document anchors: `[doc_id]§[section].L[start]-L[end]`
- table anchors: `[doc_id]§[sheet_or_table].R[row]C[col]`
- event anchors: `[event_id]§payload.field`

Allowed confidence values:
- `high`
- `medium`
- `low`
- `needs_human_review`

Never silently upgrade confidence. If evidence is partial, keep the row and mark the missing evidence.

## Scoring model
Scores should be numeric values from `0` to `5` unless the user provides a different scale.

Recommended dimensions:
- `frequency_score`: volume, recurrence, trend, or growth rate
- `impact_score`: affected users, revenue, data, compliance, operational burden
- `severity_score`: customer-facing severity, blocker signals, security/data loss risk
- `confidence_score`: completeness and agreement across sources
- `novelty_score`: not already represented in backlog or PRD
- `actionability_score`: clarity of next validation step and owner

Default priority hint:
```text
priority_hint = weighted_sum(frequency, impact, severity, confidence, novelty, actionability)
```
Do not present priority hints as final roadmap decisions.

## Boundary rules
- the feedback loop may create a requirement hypothesis, not a final PRD.
- the feedback-loop may recommend intake or reprioritization routing, not bypass quality gates.
- the feedback loop may aggregate incidents, defects, and feedback, but does not perform RCA, remediation, severity authority, or release go/no-go.
- the feedback loop must keep source artifacts and evidence references available for audit.
- User feedback content must be privacy-safe and should not expose personal identifiers unless the user explicitly requires and it is appropriate.
- Cross-skill handoff must use `cluster_id`, `signal_id`, and `suggestion_id`, not prose-only references.

## Downstream route tokens
Use route tokens instead of fixed workflow node codes:
- `intake`: new or unclear demand candidates for intake review.
- `reprioritization`: known backlog or active scope candidates that need reordering.
- `merge`: duplicate or overlapping demand should be merged with an existing item.
- `monitor`: evidence is not strong enough for action yet.
- `human_review`: conflicting, low-confidence, privacy-sensitive, or policy-sensitive evidence needs review.

## Downstream handoff
For intake, provide intake-ready rows with problem statements, evidence, source links, and open questions.
For reprioritization, provide urgency/value/risk signals, priority hints, confidence, known backlog refs, and recommended decision options.
Run `scripts/validate_feedback_handoff.py` when UFC, PSA, and DDRM artifacts are composed. v1.4.1 supports repeated `--ufc`, `--psa`, and `--ddrm` arguments, so teams can validate several example files without manual concatenation:

```bash
python scripts/validate_feedback_handoff.py --ufc ufc_a.csv --ufc ufc_b.csv --psa psa.json --ddrm ddrm.csv
```

Run `scripts/validate_downstream_handoff.py --ddrm 数据驱动需求建议.csv` before sending DDRM rows to host workflow routes.

## Common quality checklist
These 11 shared checks are the common feedback-loop baseline. Skill-specific checklists should reference this section instead of copying it.

1. Artifact and metadata use `feedback-loop-suite-v1.4.1`.
2. Every row has a stable id, evidence refs, confidence, and source lineage.
3. Row ids match feedback-loop id patterns from `references/feedback-id-space.md`.
4. Required enumerations are valid (`source_type`, `confidence`, `proposed_route`, `recommended_action`).
5. Score fields are numeric and within `0..5`.
6. User feedback is privacy-safe and summarized.
7. Dedupe keys are present before scoring or routing.
8. Low-confidence high-priority claims go to human review or produce a warning.
9. DDRM suggestions include `anti_goal` and `validation_question`.
10. Intake and reprioritization routes are separated and not both chosen in the same row.
11. Produced event, artifact target, and metadata sidecar agree.

## Event names
```yaml
produced.feedback.user-feedback-clustering:
  artifact: 用户反馈聚类表.csv
produced.feedback.production-signal-aggregation:
  artifact: 线上痛点信号包.json
produced.feedback.data-driven-requirement-mining:
  artifact: 数据驱动需求建议.csv
state.feedback.ready_for_intake:
  artifact: 数据驱动需求建议.csv
state.feedback.ready_for_reprioritization:
  artifact: 数据驱动需求建议.csv
exception.feedback.low_confidence_signal:
  reason: insufficient evidence, conflicting sources, or noisy feedback
```
