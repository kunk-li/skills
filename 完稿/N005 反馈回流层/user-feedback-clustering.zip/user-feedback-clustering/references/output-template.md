# Output template / 用户反馈聚类输出模板

## Required pair
Produce `用户反馈聚类表.csv` plus `用户反馈聚类表.metadata.yaml`.
Validate with:
```bash
python scripts/validate_feedback_artifact.py --strict 用户反馈聚类表.csv user-feedback-clustering
python scripts/validate_metadata.py 用户反馈聚类表.metadata.yaml user-feedback-clustering
```

## 1. metadata
```yaml
workflow_node: <provided by host workflow>
skill: user-feedback-clustering
contract_version: feedback-loop-suite-v1.4.1
selected_mode: nps_feedback | support_ticket_batch | app_review_mining | interview_note_clustering | mixed_feedback
readiness: ready | partial | evidence_limited | needs_human_review
artifact_id: UFC-CLUSTER-<scope>-<yyyymm>
artifact_target: 用户反馈聚类表.csv
```

## 2. feedback_source_coverage
| source | included | count | time_window | segment_coverage | note |
|---|---|---:|---|---|---|

## 3. feedback_clusters
| cluster_id | theme | pain_point | jobs_to_be_done | journey_step | feedback_count | source_mix | user_segment | nps_bucket | sentiment | emotion | severity_hint | frequency_hint | representative_summary | representative_evidence_refs | dedupe_key | related_feature_area | known_backlog_refs | handoff_signal_tags | confidence | noise_flag | privacy_note |
|---|---|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## 4. handoff_to_signal_aggregation
```yaml
feedback_cluster_ids: []
handoff_signal_tags: []
high_confidence_pain_points: []
needs_human_review: []
```

## 5. produced_events
```yaml
- event_name: produced.feedback.user-feedback-clustering
  artifact: 用户反馈聚类表.csv
```
