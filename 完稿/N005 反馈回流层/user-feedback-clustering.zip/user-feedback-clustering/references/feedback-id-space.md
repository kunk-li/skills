# Feedback id space / 编号空间

Contract version: `feedback-loop-suite-v1.4.1`

## Artifact ids
- UFC metadata artifacts: `UFC-CLUSTER-<scope>-<yyyymm>`
- PSA metadata artifacts: `PSA-SIGNAL-<scope>-<yyyymm>`
- DDRM metadata artifacts: `DDRM-REQ-<scope>-<yyyymm>`

## Row ids
- UFC cluster rows: `FBCL-<theme_or_area>-<nnn>`
- PSA signal rows: `SIG-<source_or_area>-<nnn>`
- DDRM suggestion rows: `DREQ-<feature_area>-<nnn>`

## Notes
- Use lowercase snake_case for `<scope>`, `<theme_or_area>`, `<source_or_area>`, and `<feature_area>` whenever possible.
- The old draft label `SUG-*` is deprecated. Use `DREQ-*` for DDRM `suggestion_id` values.
- Cross-artifact references use artifact ids in metadata and row ids in artifact rows. Do not replace them with prose-only references.
