# Feedback-loop anti-patterns / 反模式清单

> **Route migration notice (v1.3.x to v1.4.x)**: v1.4.x is an intentionally incompatible CSV/JSON routing-contract upgrade. Replace legacy route field names such as `proposed_next_node` or `proposed_next_route` with `proposed_route`, and replace workflow-node-specific route values with host-neutral route tokens: `intake` or `reprioritization`. Host workflows map these route tokens to local workflow nodes outside the skill package. Artifact validators fail legacy numeric route codes with migration guidance; downstream handoff accepts known legacy CLI target aliases with a warning so hosts can migrate safely.


Use this file before release checks or when a row is low-confidence, high-priority, privacy-sensitive, or routed to reprioritization.

## v1.4+ routing-token migration / 路由 token 迁移

This package is route-neutral. From v1.4 onward, artifacts must use semantic route and source tokens instead of private workflow-node identifiers. Treat older node-bound CSV/JSON fields as retired:

- Replace `proposed_next_node` with `proposed_route`.
- Replace `downstream_nodes` / `consumer_nodes` with `downstream_routes` / `consumer_routes`.
- Use `proposed_route` values `intake` or `reprioritization`.
- Use `source_node` values `defect_source`, `runtime_source`, `postmortem_source`, `external`, or `unknown`.
- Host workflows may keep their own private node mapping outside the skill package, but skill artifacts should only contain route tokens.

Validators surface migration errors explicitly: artifact validators reject retired fields or private node codes in route/source fields, and downstream handoff normalizes known legacy target aliases with a warning.

| id | anti-pattern | why harmful | correct pattern | validator coverage |
|---|---|---|---|---|
| AP-UFC-01 | `cluster_id` is arbitrary, e.g. `random-id-99` | downstream cannot join feedback clusters | use `FBCL-checkout_latency-001` | `validate_feedback_artifact.py` enforces `FBCL-<area>-<nnn>` |
| AP-UFC-02 | `feedback_count="many"` | scoring and confidence cannot be audited | use a positive integer such as `17` | feedback_count must be positive integer |
| AP-UFC-03 | one feedback item marked high confidence | promotes isolated opinion into evidence | use `confidence=low` or add corroborating evidence | warning, strict-mode failure |
| AP-UFC-04 | raw email, phone, or token in feedback summary | privacy/compliance risk | summarize or redact personal identifiers | PII warning, strict-mode failure |
| AP-PSA-01 | `source_type="tea_leaves"` | breaks source separation | choose one of runtime_error/incident_postmortem/defect/user_feedback/nps/support_ticket/survey/other | source_type enum validation |
| AP-PSA-02 | `priority_hint="P0"` | mixes roadmap priority with scoring scale | use numeric 0..5 and keep priority approval outside feedback-loop | numeric 0..5 validation |
| AP-PSA-03 | duplicate `signal_id` | corrupts handoff to DDRM | make ids unique, e.g. `SIG-runtime_error-001` and `SIG-runtime_error-002` | duplicate id validation |
| AP-PSA-04 | low confidence with priority_hint > 3 | overstates noisy signal | route to human_review or add evidence before raising priority_hint | warning, strict-mode failure |
| AP-PSA-05 | zero count/rate with high priority | score conflicts with source volume | set count/rate correctly or lower priority_hint | warning, strict-mode failure |
| AP-DDRM-01 | `proposed_route=invalid_route` | bypasses intake/reprioritization contract | choose `intake` or `reprioritization` | intake/reprioritization enum validation |
| AP-DDRM-02 | `recommended_action=bogus` | downstream cannot route action | choose intake/reprioritize/merge/monitor/human_review | action enum validation |
| AP-DDRM-03 | missing `anti_goal` | scope creep likely | state what the suggestion should not solve | required field validation |
| AP-DDRM-04 | missing `validation_question` | hypothesis cannot be tested | add the next validation or decision question | required field validation |
| AP-DDRM-05 | `novel` demand routed to reprioritization | new demands should enter intake first | route novel/unclear demand to intake unless tied to known backlog | warning, strict-mode failure |
| AP-DDRM-06 | `proposed_route=intake|reprioritization` | ambiguous route | choose exactly one route and explain tradeoff in notes | warning, strict-mode failure |
| AP-META-01 | metadata typo such as `audit_handoffrequired` | unknown key is silently ignored in loose schemas | use only keys in metadata-schema.json | v1.4 metadata additionalProperties=false |
| AP-HANDOFF-01 | manually concatenate UFC files for PSA validation | manual merge can drop cluster ids or headers | pass repeated `--ufc` arguments to the handoff validator | v1.4 handoff multi-file support |
| AP-ROUTE-01 | legacy numeric route code in `proposed_route` or `--target` | binds a reusable skill to a private host workflow | use `intake` or `reprioritization`, then map routes outside the skill | `validate_downstream_handoff.py` compatibility guard |
| AP-ROUTE-02 | legacy field `proposed_next_node` or `proposed_next_route` | mixes old schema with route-neutral v1.4+ artifacts | rename to `proposed_route` | downstream handoff migration error |
