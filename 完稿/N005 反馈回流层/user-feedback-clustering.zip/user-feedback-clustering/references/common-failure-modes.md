# Common failure modes / 常见失败模式

| failure mode | why it is harmful | required mitigation | validator hook |
|---|---|---|---|
| Treating noisy feedback as confirmed demand | Pollutes the requirement pool | Keep confidence, source coverage, and validation questions explicit | confidence + human-review warnings |
| Ranking by raw count only | Ignores severity, data loss, revenue, and compliance | Use frequency + impact + severity + confidence scoring | score range checks |
| Mixing symptoms, root causes, and solutions | Creates unclear downstream requirements | Separate `observed_problem`, evidence, and optional solution | problem-before-solution warning |
| Losing evidence refs | Downstream cannot audit or challenge the suggestion | Every signal and suggestion must carry evidence refs | required evidence fields |
| Duplicating existing backlog items | Inflates demand and misleads prioritization | Add dedupe keys and known backlog/PRD refs | dedupe_key/id duplicate checks |
| Bypassing intake/reprioritization gates | Turns evidence mining into unauthorized roadmap decisions | Route to intake or reprioritization with decision-needed status | route-token enum |
| Exposing personal information | Privacy and compliance risk | Redact PII and summarize representative feedback safely | PII pattern warnings |
| Treating postmortem actions as product requirements | Confuses operational corrective action with user value | Mark operational actions separately from requirement hypotheses | anti_goal + validation_question required |
