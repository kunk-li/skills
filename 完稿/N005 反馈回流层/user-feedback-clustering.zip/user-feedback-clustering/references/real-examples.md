# Real examples / 示例

## Example: NPS detractor cluster
```yaml
cluster_id: FBCL-checkout-001
theme: payment status uncertainty
pain_point: users do not know whether payment succeeded after a timeout
journey_step: checkout_payment
feedback_count: 37
source_mix: [nps, support_ticket]
sentiment: negative
severity_hint: medium
confidence: high
handoff_signal_tags: [checkout, payment, timeout, status_copy]
representative_evidence_refs:
  - "[nps-comments]§table.R18Cfeedback"
```

## Example: low-confidence cluster
```yaml
cluster_id: FBCL-profile-004
theme: profile edit confusion
feedback_count: 2
confidence: low
noise_flag: insufficient_context
handoff_signal_tags: [profile, usability]
```
