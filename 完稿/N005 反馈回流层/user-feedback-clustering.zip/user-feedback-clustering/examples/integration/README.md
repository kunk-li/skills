# Integration Examples / 集成示例

This directory contains a three-artifact integration example demonstrating how all three feedback-loop family skills work together in the feedback-loop cascade:

**user-feedback-clustering → production-signal-aggregation → data-driven-requirement-mining**

## Feedback Loop Cascade (notify-signal-pack)

| Skill | Artifact | File |
| --- | --- | --- |
| UFC user-feedback-clustering | FBCL-mixed-001/002 | `mixed-feedback-example.csv` + `.metadata.yaml` |
| PSA production-signal-aggregation | SIG-notify_feedback-001 | `feedback-pack-signal-example.json` + `.metadata.yaml` |
| DDRM data-driven-requirement-mining | DREQ-feedback-001 | `customer-pain-mining-example.csv` + `.metadata.yaml` |

## Cross-references

- PSA `feedback_cluster_ids: [FBCL-mixed-001]` → references UFC `cluster_id`
- DDRM `source_signal_ids: [SIG-notify_feedback-001]` → references PSA `signal_id`

## Validate the cascade

Run from any feedback-loop skill directory:

```bash
python scripts/validate_feedback_handoff.py \
    --ufc examples/integration/mixed-feedback-example.csv \
    --psa examples/integration/feedback-pack-signal-example.json \
    --ddrm examples/integration/customer-pain-mining-example.csv
```
