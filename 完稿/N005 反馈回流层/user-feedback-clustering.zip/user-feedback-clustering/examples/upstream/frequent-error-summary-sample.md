# 高频报错摘要

- `checkout-api timeout` 在 2026-05-01/2026-05-07 晚高峰升至 4.2%。
- `mfa-code-delay` 在换设备登录路径出现多次告警。
