---
name: user-feedback-clustering
display_name: 用户反馈聚类 / User Feedback Clustering
description: cluster open-ended user feedback, nps comments, support tickets, complaints, survey notes, app reviews, and voc snippets into privacy-safe feedback clusters with evidence refs, counts, sentiment, noise flags, and handoff tags. use when feedback must be deduplicated or summarized as reusable evidence; works standalone or alongside production-signal aggregation and requirement mining. not for aggregating runtime/defect/postmortem signals (use production-signal-aggregation) or converting signals into backlog hypotheses (use data-driven-requirement-mining).
---
# user-feedback-clustering

## Feedback-loop metadata / 阶段元数据
- `skill_family`: `feedback-loop-suite`
- `host_workflow_node`: provided by the host workflow; this skill does not bind itself to a fixed node
- `skill_id`: `user-feedback-clustering`
- `stage_hint`: `feedback_loop.feedback_clustering`
- `prerequisites`: none; the skill is single-skill usable and evidence-gated
- `composable_with`: `['production-signal-aggregation', 'data-driven-requirement-mining']`
- `consumes_when_available`: `['feedback files', 'nps comments', 'support-ticket summaries', 'surveys', 'app reviews', 'voc notes']`
- `route_hints`: `['evidence_handoff']`
- `artifact_target`: `用户反馈聚类表.csv`

## feedback-loop-suite v1.4.1 contract baseline
- `contract_version`: `feedback-loop-suite-v1.4.1`
- `artifact_family_id`: `feedback-loop-suite`
- `schema`: `feedback.user-feedback-clustering.v4`
- `metadata_sidecar`: required for final artifacts (`*.metadata.yaml`) with strict `additionalProperties: false`
- `artifact_id_namespace`: `UFC-CLUSTER-<scope>-<yyyymm>`
- `validation_scripts`: `validate_feedback_artifact.py`, `validate_metadata.py`, `validate_decision_tree.py`, `validate_feedback_handoff.py`, `validate_downstream_handoff.py`, `validate_release_consistency.py`
- `examples/`: contains executable examples, metadata sidecars, and upstream defect/runtime/postmortem samples for regression testing

## Role / 角色定位
Cluster user feedback into clear, privacy-safe, evidence-backed themes. The skill helps any host workflow understand user voice without confusing isolated opinions, duplicates, sentiment, or customer-support workload with confirmed product requirements.

## Single-skill value / 单独使用价值
- Can run on raw feedback, NPS comments, ticket summaries, survey notes, interview snippets, or app-store reviews.
- Produces a reusable feedback-cluster table with sentiment, segment, journey step, and evidence references.
- Keeps representative examples short and privacy-safe.

## Multi-skill value / 组合使用价值
- Can be composed with `production-signal-aggregation` through `feedback_cluster_ids` and user-facing pain-point tags.
- Can be composed with `data-driven-requirement-mining` through voice-of-customer evidence and validation questions.
- Can be joined with runtime signals, defect tables, or postmortems when the same user problem appears in production evidence.

## Allowed inputs / 允许输入
- User feedback, NPS comments, support tickets, customer complaints, survey results, interview summaries, app-store reviews, VOC notes
- Product area taxonomy, user segment definitions, journey maps, and existing backlog refs for mapping only

## Prohibited inputs / 禁止输入
- Raw personal identifiers not needed for clustering.
- One-off feedback promoted to high-priority demand without evidence.
- Long verbatim feedback excerpts that expose users or private context.

## Modes
- `nps_feedback`: use for NPS/open-text survey feedback.
- `support_ticket_batch`: use for support tickets or complaints.
- `app_review_mining`: use for app-store/public reviews.
- `interview_note_clustering`: use for qualitative research notes.
- `mixed_feedback`: default when multiple feedback sources exist.

## Required output sections
1. `metadata`
2. `feedback_source_coverage`
3. `feedback_clusters[]`
4. `segment_and_journey_summary`
5. `sentiment_and_emotion_summary`
6. `noise_and_privacy_notes`
7. `handoff_to_signal_aggregation`
8. `produced_events`
9. `self_check`

## Required row contract
Each cluster row should include:
- `cluster_id`
- `theme`
- `pain_point`
- `jobs_to_be_done`
- `journey_step`
- `feedback_count`
- `source_mix`
- `user_segment`
- `nps_bucket`
- `sentiment`
- `emotion`
- `severity_hint`
- `frequency_hint`
- `representative_summary`
- `representative_evidence_refs[]`
- `dedupe_key`
- `related_feature_area`
- `known_backlog_refs[]`
- `handoff_signal_tags[]`
- `confidence`
- `noise_flag`
- `privacy_note`

## Rules
- `R01_cluster_before_suggestion`: cluster feedback before proposing requirements.
- `R02_privacy_safe`: redact or summarize personal information.
- `R03_short_representative_examples`: use short summaries; avoid long direct quotes.
- `R04_dedupe_required`: merge duplicates and near-duplicates.
- `R05_sentiment_not_priority`: negative sentiment alone is not a priority decision.
- `R06_segment_visible`: when segment is known, preserve it; when unknown, say unknown.
- `R07_confidence_required`: every cluster needs confidence and noise flags.
- `R08_handoff_tags`: each cluster should include tags useful to feedback aggregation.
- `R09_machine_validation`: run artifact, metadata, and handoff validators when execution is available.

## Execution workflow
1. Normalize feedback items and remove obvious spam/noise.
2. Redact or summarize sensitive personal details.
3. Cluster by theme, user job, journey step, product area, and recurring language.
4. Count feedback volume and identify source mix.
5. Assess sentiment, emotion, severity hint, and frequency hint.
6. Link clusters to known backlog or feature area when available.
7. Produce `用户反馈聚类表.csv` and handoff tags for the feedback loop.
8. Emit `produced.feedback.user-feedback-clustering`.
9. Produce the metadata sidecar, run artifact, metadata, decision-tree, handoff, and release-consistency validators, then run the feedback-loop quality checklist.

## Output language and evidence rules
- Follow the user's primary language.
- Preserve product names, feature names, ids, NPS values, and ticket ids as-is.
- Use short representative summaries rather than long verbatim quotes.
- Every cluster should cite representative evidence refs.

## Workflow v2 artifact contract
```yaml
artifact_type: feedback.user-feedback-clustering
schema_version: "1.4.0"
producer_skill: user-feedback-clustering
consumer_routes: [feedback-loop, intake, reprioritization]
workflow_alias: 用户反馈聚类表.csv
produced_event_name: produced.feedback.user-feedback-clustering
canonical_fields:
  - cluster_id
  - theme
  - pain_point
  - journey_step
  - feedback_count
  - user_segment
  - sentiment
  - severity_hint
  - confidence
  - representative_evidence_refs
  - handoff_signal_tags
```

## Self-check / 节点内自检
Before delivery, confirm:
- clusters are not single unverified opinions unless marked as low confidence
- evidence refs and source mix are present
- privacy-sensitive text is redacted or summarized
- sentiment is not treated as final priority
- handoff tags are useful for production-signal aggregation

## Key references
- `references/shared-feedback-loop-contract.md`
- `references/output-template.md`
- `references/field-contract.yaml`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `scripts/validate_feedback_artifact.py`
- `references/metadata-schema.json`
- `references/feedback-id-space.md`
- `references/selected-mode-decision-tree.md`
- `references/anti-patterns.md`
- `examples/`
- `scripts/validate_metadata.py`
- `scripts/validate_feedback_handoff.py`
- `scripts/validate_skill_md.py`
- `scripts/validate_decision_tree.py`
- `scripts/validate_downstream_handoff.py`
- `scripts/validate_release_consistency.py`



## Examples / 回归样例

Use the bundled `examples/` files as executable regression cases. Run:
```bash
python scripts/validate_release_consistency.py .
```
Bundled examples and the modes they cover:

| file | mode |
| --- | --- |
| `examples/nps-detractor-checkout-example.csv` | `nps_feedback` |
| `examples/support-ticket-batch-example.csv` | `support_ticket_batch` |
| `examples/app-review-mining-example.csv` | `app_review_mining` |
| `examples/mixed-feedback-example.csv` | `mixed_feedback` |
