---
name: user-feedback-clustering
display_name: 用户反馈聚类 / User Feedback Clustering
description: cluster user feedback, NPS comments, support tickets, app reviews, and VOC notes into privacy-safe feedback clusters with sentiment, noise flags, and handoff tags. use when feedback needs deduplication or reusable evidence clusters — standalone or with production-signal-aggregation and data-driven-requirement-mining. not for runtime/defect/postmortem signals or backlog hypothesis generation.
---
# user-feedback-clustering

## Feedback-loop metadata / 阶段元数据
- `skill_family`: `feedback-loop-suite`
- `host_workflow_node`: provided by the host workflow; this skill does not bind itself to a fixed node
- `skill_id`: `user-feedback-clustering`
- `stage_hint`: `feedback_loop.feedback_clustering`
- `prerequisites`: none; the skill is single-skill usable and evidence-gated
- `composable_with`: `['production-signal-aggregation', 'data-driven-requirement-mining']`
- `consumes_when_available`: `['feedback files', 'nps comments', 'support-ticket summaries', 'surveys', 'app reviews', 'voc notes']`
- `route_hints`: `['evidence_handoff']`
- `artifact_target`: `用户反馈聚类表.csv`

## feedback-loop-suite v1.4.1 contract baseline
- `contract_version`: `feedback-loop-suite-v1.4.1`
- `artifact_family_id`: `feedback-loop-suite`
- `schema`: `feedback.user-feedback-clustering.v4`
- `metadata_sidecar`: required for final artifacts (`*.metadata.yaml`) with strict `additionalProperties: false`
- `artifact_id_namespace`: `UFC-CLUSTER-<scope>-<yyyymm>`
- `validation_scripts`: `validate_feedback_artifact.py`, `validate_metadata.py`, `validate_decision_tree.py`, `validate_feedback_handoff.py`, `validate_downstream_handoff.py`, `validate_release_consistency.py`
- `examples/`: contains executable examples, metadata sidecars, and upstream defect/runtime/postmortem samples for regression testing

## Role / 角色定位
Cluster user feedback into clear, privacy-safe, evidence-backed themes. The skill helps any host workflow understand user voice without confusing isolated opinions, duplicates, sentiment, or customer-support workload with confirmed product requirements.

## Single-skill value / 单独使用价值
- Can run on raw feedback, NPS comments, ticket summaries, survey notes, interview snippets, or app-store reviews.
- Produces a reusable feedback-cluster table with sentiment, segment, journey step, and evidence references.
- Keeps representative examples short and privacy-safe.

## Multi-skill value / 组合使用价值
- Can be composed with `production-signal-aggregation` through `feedback_cluster_ids` and user-facing pain-point tags.
- Can be composed with `data-driven-requirement-mining` through voice-of-customer evidence and validation questions.
- Can be joined with runtime signals, defect tables, or postmortems when the same user problem appears in production evidence.

## Allowed inputs / 允许输入
- User feedback, NPS comments, support tickets, customer complaints, survey results, interview summaries, app-store reviews, VOC notes
- Product area taxonomy, user segment definitions, journey maps, and existing backlog refs for mapping only

## Prohibited inputs / 禁止输入
- Raw personal identifiers not needed for clustering.
- One-off feedback promoted to high-priority demand without evidence.
- Long verbatim feedback excerpts that expose users or private context.

## Modes
- `nps_feedback`: use for NPS/open-text survey feedback.
- `support_ticket_batch`: use for support tickets or complaints.
- `app_review_mining`: use for app-store/public reviews.
- `interview_note_clustering`: use for qualitative research notes.
- `mixed_feedback`: default when multiple feedback sources exist.

## Required output sections
1. `metadata`
2. `feedback_source_coverage`
3. `feedback_clusters[]`
4. `segment_and_journey_summary`
5. `sentiment_and_emotion_summary`
6. `noise_and_privacy_notes`
7. `handoff_to_signal_aggregation`
8. `produced_events`
9. `self_check`

## Required row contract

Each cluster row must include the following fields. Use `[evidence: assumption]` or `[evidence: open question]` for unconfirmed items.

| field | required | format / enum |
| --- | --- | --- |
| `cluster_id` | required | `UFC-CLUSTER-<scope>-<yyyymm>-<nnn>` |
| `theme` | required | short theme label |
| `pain_point` | required | one-sentence user pain |
| `jobs_to_be_done` | required | job the user is trying to accomplish |
| `journey_step` | required | journey stage where feedback occurs |
| `feedback_count` | required | integer count of source items |
| `source_mix` | required | `\|`-separated source types |
| `user_segment` | required | segment label or `unknown` |
| `nps_bucket` | required | `promoter\|passive\|detractor\|unknown` |
| `sentiment` | required | `positive\|neutral\|negative\|mixed` |
| `emotion` | required | dominant emotion or `unknown` |
| `severity_hint` | required | `critical\|high\|medium\|low` |
| `frequency_hint` | required | `high\|medium\|low\|unknown` |
| `representative_summary` | required | short privacy-safe summary (no verbatim PII) |
| `representative_evidence_refs` | required | `\|`-separated evidence anchors |
| `dedupe_key` | required | canonical key for deduplication |
| `related_feature_area` | required | product area or `unknown` |
| `known_backlog_refs` | recommended | `\|`-separated backlog or PRD IDs |
| `handoff_signal_tags` | required | `\|`-separated tags for PSA handoff |
| `confidence` | required | `high\|medium\|low\|needs_human_review` |
| `noise_flag` | required | `true\|false` |
| `privacy_note` | required | redaction note or `none` |


## Rules
- `R01_cluster_before_suggestion`: cluster feedback before proposing requirements.
- `R02_privacy_safe`: redact or summarize personal information.
- `R03_short_representative_examples`: use short summaries; avoid long direct quotes.
- `R04_dedupe_required`: merge duplicates and near-duplicates.
- `R05_sentiment_not_priority`: negative sentiment alone is not a priority decision.
- `R06_segment_visible`: when segment is known, preserve it; when unknown, say unknown.
- `R07_confidence_required`: every cluster needs confidence and noise flags.
- `R08_handoff_tags`: each cluster should include tags useful to feedback aggregation.
- `R09_machine_validation`: run artifact, metadata, and handoff validators when execution is available.

## Skill-specific anti-patterns (AP-UFC-*)

| id | anti-pattern | why harmful | correct pattern |
| --- | --- | --- | --- |
| AP-UFC-01 | promoting single unverified feedback to high-priority demand | one opinion becomes a roadmap driver without validation | mark as low confidence, add open question, route to human_review |
| AP-UFC-02 | merging semantically different themes into one cluster | downstream loses nuance needed for solution design | keep distinct themes separate; use `overmerge_risk` flag |
| AP-UFC-03 | omitting privacy_note on user feedback summaries | PII may leak into planning artifacts | always populate `privacy_note`; redact identifiers in `representative_summary` |
| AP-UFC-04 | treating negative sentiment alone as a priority signal | high-volume complaints may reflect low-impact annoyances | pair sentiment with `frequency_hint` and `severity_hint` before routing |

## Execution workflow
1. Normalize feedback items and remove obvious spam/noise.
2. Redact or summarize sensitive personal details.
3. Cluster by theme, user job, journey step, product area, and recurring language.
4. Count feedback volume and identify source mix.
5. Assess sentiment, emotion, severity hint, and frequency hint.
6. Link clusters to known backlog or feature area when available.
7. Produce `用户反馈聚类表.csv` and handoff tags for the feedback loop.
8. Emit `produced.feedback.user-feedback-clustering`.
9. Produce the metadata sidecar, run artifact, metadata, decision-tree, handoff, and release-consistency validators, then run the feedback-loop quality checklist.

## Output language and evidence rules
- Follow the user's primary language.
- Preserve product names, feature names, ids, NPS values, and ticket ids as-is.
- Use short representative summaries rather than long verbatim quotes.
- Every cluster should cite representative evidence refs.

## Workflow v2 artifact contract
```yaml
artifact_type: feedback.user-feedback-clustering
schema_version: "1.4.0"
producer_skill: user-feedback-clustering
consumer_routes: [feedback-loop, intake, reprioritization]
workflow_alias: 用户反馈聚类表.csv
produced_event_name: produced.feedback.user-feedback-clustering
canonical_fields:
  - cluster_id
  - theme
  - pain_point
  - journey_step
  - feedback_count
  - user_segment
  - sentiment
  - severity_hint
  - confidence
  - representative_evidence_refs
  - handoff_signal_tags
```

## Self-check / 节点内自检
Before delivery, confirm:
- clusters are not single unverified opinions unless marked as low confidence
- evidence refs and source mix are present
- privacy-sensitive text is redacted or summarized
- sentiment is not treated as final priority
- handoff tags are useful for production-signal aggregation

## Key references
- `references/shared-feedback-loop-contract.md`
- `references/output-template.md`
- `references/field-contract.yaml`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `scripts/validate_feedback_artifact.py`
- `references/metadata-schema.json`
- `references/feedback-id-space.md`
- `references/selected-mode-decision-tree.md`
- `references/anti-patterns.md`
- `examples/`
- `scripts/validate_metadata.py`
- `scripts/validate_feedback_handoff.py`
- `scripts/validate_skill_md.py`
- `scripts/validate_decision_tree.py`
- `scripts/validate_downstream_handoff.py`
- `scripts/validate_release_consistency.py`



## F-family integration cascade

To validate the full UFC → PSA → DDRM three-skill feedback-loop cascade:

```bash
python scripts/validate_feedback_handoff.py \\
    --ufc examples/integration/mixed-feedback-example.csv \\
    --psa examples/integration/feedback-pack-signal-example.json \\
    --ddrm examples/integration/customer-pain-mining-example.csv
```

See `examples/integration/README.md` for the coherent triplet.

## Examples / 回归样例

Use the bundled `examples/` files as executable regression cases. Run:
```bash
python scripts/validate_release_consistency.py .
```
Bundled examples and the modes they cover:

| file | mode |
| --- | --- |
| `examples/nps-detractor-checkout-example.csv` | `nps_feedback` |
| `examples/support-ticket-batch-example.csv` | `support_ticket_batch` |
| `examples/app-review-mining-example.csv` | `app_review_mining` |
| `examples/mixed-feedback-example.csv` | `mixed_feedback` |
