#!/usr/bin/env python3
"""Fail if private workflow-node numeric identifiers appear anywhere in a skill folder."""
from __future__ import annotations
import re
import sys
from pathlib import Path

PREFIX = "N"
NODE_CODE_RE = re.compile(r"\b" + PREFIX + r"\d{3}\b", re.IGNORECASE)
TEXT_EXTS = {".md", ".yaml", ".yml", ".json", ".py", ".csv", ".txt", ".log"}
EXEMPT_DIRS = {"__pycache__", ".git"}


def collect_errors(root: Path) -> list[str]:
    violations: list[str] = []
    for path in root.rglob("*"):
        if any(part in EXEMPT_DIRS for part in path.parts):
            continue
        rel = path.relative_to(root)
        if NODE_CODE_RE.search(str(rel)):
            violations.append(f"{rel}: private workflow-node code in path")
        if not path.is_file() or path.suffix.lower() not in TEXT_EXTS:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for lineno, line in enumerate(text.splitlines(), 1):
            if NODE_CODE_RE.search(line):
                violations.append(f"{rel}:{lineno}: private workflow-node code")
    return violations


def main(root: Path) -> int:
    violations = collect_errors(root)
    if violations:
        print(f"FAIL: {len(violations)} private workflow-node references remain", file=sys.stderr)
        for item in violations[:40]:
            print("  " + item, file=sys.stderr)
        if len(violations) > 40:
            print(f"  ... and {len(violations) - 40} more", file=sys.stderr)
        return 1
    print(f"OK: no private workflow-node references in {root}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: check_node_neutrality.py <skill-dir>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(Path(sys.argv[1])))
