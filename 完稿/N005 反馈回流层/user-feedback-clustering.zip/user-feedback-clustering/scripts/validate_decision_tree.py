#!/usr/bin/env python3
"""Validate selected-mode decision tree alignment for an feedback-loop skill folder.

Checks:
- SKILL.md declares the expected modes for the skill.
- selected-mode-decision-tree.md contains every mode for the skill.
- the Mode to output contract map has a row for every mode.
- metadata-schema.json selected_mode.enum and schema const match the skill config.
- field-contract.yaml mentions the required contract fields.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Dict, List

SKILLS = {
    "user-feedback-clustering": {
        "schema": "feedback.user-feedback-clustering.v4",
        "target": "用户反馈聚类表.csv",
        "modes": ["nps_feedback", "support_ticket_batch", "app_review_mining", "interview_note_clustering", "mixed_feedback"],
        "fields": ["cluster_id", "theme", "pain_point", "feedback_count", "representative_evidence_refs", "confidence"],
    },
    "production-signal-aggregation": {
        "schema": "feedback.production-signal-aggregation.v4",
        "target": "线上痛点信号包.json",
        "modes": ["multi_source_aggregation", "incident_signal_rollup", "defect_trend_rollup", "runtime_error_rollup", "feedback_pack"],
        "fields": ["signal_id", "source_type", "observed_problem", "evidence_refs", "confidence", "priority_hint", "dedupe_key"],
    },
    "data-driven-requirement-mining": {
        "schema": "feedback.data-driven-requirement-mining.v4",
        "target": "数据驱动需求建议.csv",
        "modes": ["backlog_seed", "reprioritization", "incident_prevention", "customer_pain_mining", "mixed_signal_mining"],
        "fields": ["suggestion_id", "hypothesis_title", "user_problem", "source_signal_ids", "proposed_route", "anti_goal", "validation_question", "recommended_action"],
    },
}


def skill_name_from_md(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    m = re.search(r"^name:\s*([^\n]+)$", text, re.M)
    return m.group(1).strip() if m else ""


def section(text: str, heading: str) -> str:
    pat = re.compile(rf"^##\s+{re.escape(heading)}\s*$", re.M)
    m = pat.search(text)
    if not m:
        return ""
    start = m.end()
    n = re.search(r"^##\s+", text[start:], re.M)
    return text[start:start+n.start()] if n else text[start:]


def main(skill_dir: Path) -> int:
    errors: List[str] = []
    skill_md = skill_dir / "SKILL.md"
    name = skill_name_from_md(skill_md)
    if name not in SKILLS:
        print(f"ERROR: unsupported or missing skill name {name!r}", file=sys.stderr)
        return 2
    cfg = SKILLS[name]
    skill_text = skill_md.read_text(encoding="utf-8")
    decision = (skill_dir / "references" / "selected-mode-decision-tree.md").read_text(encoding="utf-8")
    field_contract = (skill_dir / "references" / "field-contract.yaml").read_text(encoding="utf-8")
    schema = json.loads((skill_dir / "references" / "metadata-schema.json").read_text(encoding="utf-8"))

    own_section = section(decision, name)
    if not own_section:
        errors.append(f"decision tree missing section for {name}")
    for mode in cfg["modes"]:
        if f"`{mode}`" not in own_section:
            errors.append(f"decision tree section for {name} missing mode `{mode}`")
        if not re.search(rf"\|\s*{re.escape(name)}\s*\|\s*{re.escape(mode)}\s*\|", decision):
            errors.append(f"mode-to-output-contract map missing row for {name}/{mode}")
        if mode not in skill_text:
            errors.append(f"SKILL.md missing mode {mode}")

    meta_props = schema.get("properties", {}).get("metadata", {})
    if schema.get("additionalProperties") is not False:
        errors.append("metadata-schema root must set additionalProperties: false")
    if meta_props.get("additionalProperties") is not False:
        errors.append("metadata-schema metadata object must set additionalProperties: false")
    schema_modes = meta_props.get("properties", {}).get("selected_mode", {}).get("enum", [])
    if sorted(schema_modes) != sorted(cfg["modes"]):
        errors.append(f"metadata-schema selected_mode enum mismatch: {schema_modes}")
    schema_const = meta_props.get("properties", {}).get("schema", {}).get("const")
    if schema_const != cfg["schema"]:
        errors.append(f"metadata-schema schema const mismatch: {schema_const!r}")
    target_const = meta_props.get("properties", {}).get("artifact_target", {}).get("const")
    if target_const != cfg["target"]:
        errors.append(f"metadata-schema artifact_target const mismatch: {target_const!r}")

    for field in cfg["fields"]:
        if field not in field_contract:
            errors.append(f"field-contract missing required field {field}")
        if field not in decision:
            errors.append(f"decision tree output contract missing required field {field}")

    if errors:
        for err in errors:
            print("ERROR:", err, file=sys.stderr)
        return 1
    print(f"OK: selected-mode decision tree aligned for {name}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: validate_decision_tree.py <skill-dir>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(Path(sys.argv[1])))
