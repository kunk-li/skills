#!/usr/bin/env python3
"""Validate feedback-loop sidecar metadata YAML with stdlib only.

Supports the simple metadata YAML shape used by feedback-loop examples: top-level
`metadata:` and `downstream_handoff:` mappings with scalar values and scalar
lists. It intentionally fails unknown keys to mirror metadata-schema.json
`additionalProperties: false`.

Usage:
  python validate_metadata.py examples/example.metadata.yaml user-feedback-clustering
"""
from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any, Dict, List

CONTRACT_VERSION = "feedback-loop-suite-v1.4.1"
CONFIDENCE = {"high", "medium", "low", "needs_human_review"}
READINESS = {"ready", "partial", "evidence_limited", "needs_human_review"}
YES_NO = {"yes", "no"}
ROUTES = {"intake", "reprioritization", "merge", "monitor", "human_review", "user-feedback-clustering", "production-signal-aggregation", "data-driven-requirement-mining"}
WORKFLOW_NODE_PLACEHOLDERS = {"host-workflow", "tbd", "todo", "待确认", "<host-workflow>", "<由 host workflow 注入>"}

SKILLS = {
    "user-feedback-clustering": {
        "skill_id": "user-feedback-clustering",
        "artifact_target": "用户反馈聚类表.csv",
        "schema": "feedback.user-feedback-clustering.v4",
        "event": "produced.feedback.user-feedback-clustering",
        "artifact_re": re.compile(r"^UFC-CLUSTER-[A-Za-z0-9_-]+-\d{6}$"),
        "modes": {"nps_feedback", "support_ticket_batch", "app_review_mining", "interview_note_clustering", "mixed_feedback"},
    },
    "production-signal-aggregation": {
        "skill_id": "production-signal-aggregation",
        "artifact_target": "线上痛点信号包.json",
        "schema": "feedback.production-signal-aggregation.v4",
        "event": "produced.feedback.production-signal-aggregation",
        "artifact_re": re.compile(r"^PSA-SIGNAL-[A-Za-z0-9_-]+-\d{6}$"),
        "modes": {"multi_source_aggregation", "incident_signal_rollup", "defect_trend_rollup", "runtime_error_rollup", "feedback_pack"},
    },
    "data-driven-requirement-mining": {
        "skill_id": "data-driven-requirement-mining",
        "artifact_target": "数据驱动需求建议.csv",
        "schema": "feedback.data-driven-requirement-mining.v4",
        "event": "produced.feedback.data-driven-requirement-mining",
        "artifact_re": re.compile(r"^DDRM-REQ-[A-Za-z0-9_-]+-\d{6}$"),
        "modes": {"backlog_seed", "reprioritization", "incident_prevention", "customer_pain_mining", "mixed_signal_mining"},
    },
}

REQUIRED_METADATA_FIELDS = {
    "contract_version", "workflow_node", "skill_id", "skill_name",
    "artifact_family_id", "artifact_id", "schema", "selected_mode",
    "readiness", "source_time_window", "source_artifacts",
    "upstream_id_aliases", "evidence_refs", "cross_artifact_refs",
    "pending_clarifications", "confidence", "artifact_target",
    "produced_event_name", "engine_consumable", "privacy_review_required",
    "downstream_routes",
}
ALLOWED_ROOT = {"metadata", "downstream_handoff"}
ALLOWED_METADATA_FIELDS = set(REQUIRED_METADATA_FIELDS)
REQUIRED_HANDOFF_FIELDS = {"contract_version", "artifact_id", "consumer_routes", "cross_artifact_refs", "recommended_next_step"}
ALLOWED_HANDOFF_FIELDS = set(REQUIRED_HANDOFF_FIELDS)
LIST_FIELDS = {"source_artifacts", "upstream_id_aliases", "evidence_refs", "cross_artifact_refs", "pending_clarifications", "downstream_routes", "consumer_routes"}


def parse_scalar(value: str) -> Any:
    value = value.strip()
    if value in {"[]", "[ ]"}:
        return []
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def load_yaml_like(path: Path) -> Dict[str, Any]:
    root: Dict[str, Any] = {}
    current_section: str | None = None
    current_list_key: str | None = None
    for lineno, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()
        if indent == 0 and line.endswith(":"):
            current_section = line[:-1]
            if current_section in root:
                raise ValueError(f"line {lineno}: duplicate top-level key {current_section}")
            root[current_section] = {}
            current_list_key = None
            continue
        if current_section is None:
            raise ValueError(f"line {lineno}: expected top-level section")
        section = root[current_section]
        if indent == 2 and ":" in line and not line.startswith("-"):
            key, value = line.split(":", 1)
            key = key.strip()
            value = value.strip()
            if value == "":
                section[key] = []
                current_list_key = key
            else:
                section[key] = parse_scalar(value)
                current_list_key = None
            continue
        if indent >= 4 and line in {"[]", "[ ]"}:
            if not current_list_key:
                raise ValueError(f"line {lineno}: empty list without list key")
            section[current_list_key] = []
            continue
        if indent >= 4 and line.startswith("-"):
            if not current_list_key:
                raise ValueError(f"line {lineno}: list item without list key")
            section.setdefault(current_list_key, [])
            if not isinstance(section[current_list_key], list):
                raise ValueError(f"line {lineno}: key {current_list_key} is not a list")
            section[current_list_key].append(parse_scalar(line[1:].strip()))
            continue
        raise ValueError(f"line {lineno}: unsupported YAML shape: {raw}")
    return root


def main(path: Path, skill_name: str) -> int:
    if skill_name not in SKILLS:
        print(f"ERROR: unknown skill {skill_name}", file=sys.stderr)
        return 2
    cfg = SKILLS[skill_name]
    errors: List[str] = []
    try:
        data = load_yaml_like(path)
    except Exception as exc:
        print(f"ERROR: cannot parse metadata YAML: {exc}", file=sys.stderr)
        return 2

    root_keys = set(data.keys())
    unknown_root = root_keys - ALLOWED_ROOT
    if unknown_root:
        errors.append(f"unknown top-level metadata keys: {sorted(unknown_root)}")
    missing_root = ALLOWED_ROOT - root_keys
    if missing_root:
        errors.append(f"missing top-level metadata keys: {sorted(missing_root)}")

    md = data.get("metadata", {}) or {}
    handoff = data.get("downstream_handoff", {}) or {}
    if not isinstance(md, dict) or not isinstance(handoff, dict):
        errors.append("metadata and downstream_handoff must be mappings")
        md = md if isinstance(md, dict) else {}
        handoff = handoff if isinstance(handoff, dict) else {}

    unknown_md = set(md.keys()) - ALLOWED_METADATA_FIELDS
    if unknown_md:
        errors.append(f"metadata contains unknown fields: {sorted(unknown_md)}")
    unknown_handoff = set(handoff.keys()) - ALLOWED_HANDOFF_FIELDS
    if unknown_handoff:
        errors.append(f"downstream_handoff contains unknown fields: {sorted(unknown_handoff)}")

    missing = REQUIRED_METADATA_FIELDS - set(md.keys())
    if missing:
        errors.append(f"metadata missing required fields: {sorted(missing)}")
    handoff_missing = REQUIRED_HANDOFF_FIELDS - set(handoff.keys())
    if handoff_missing:
        errors.append(f"downstream_handoff missing required fields: {sorted(handoff_missing)}")

    checks = {
        "contract_version": CONTRACT_VERSION,
        "skill_id": cfg["skill_id"],
        "skill_name": skill_name,
        "artifact_target": cfg["artifact_target"],
        "schema": cfg["schema"],
        "produced_event_name": cfg["event"],
        "artifact_family_id": "feedback-loop-suite",
    }
    for field, expected in checks.items():
        if field in md and md.get(field) != expected:
            errors.append(f"metadata.{field} must be {expected!r}, got {md.get(field)!r}")

    if "workflow_node" in md:
        workflow_node = str(md.get("workflow_node", "")).strip()
        if not workflow_node:
            errors.append("metadata.workflow_node must be a non-empty host-provided value")
        elif workflow_node.lower() in WORKFLOW_NODE_PLACEHOLDERS:
            errors.append("metadata.workflow_node must be an actual host workflow identifier, not a placeholder")

    artifact_id = str(md.get("artifact_id", ""))
    if artifact_id and not cfg["artifact_re"].match(artifact_id):
        errors.append(f"metadata.artifact_id {artifact_id!r} does not match skill id space")
    if md.get("selected_mode") and md.get("selected_mode") not in cfg["modes"]:
        errors.append(f"metadata.selected_mode must be one of {sorted(cfg['modes'])}")
    if md.get("readiness") and md.get("readiness") not in READINESS:
        errors.append(f"metadata.readiness must be one of {sorted(READINESS)}")
    if md.get("confidence") and md.get("confidence") not in CONFIDENCE:
        errors.append(f"metadata.confidence must be one of {sorted(CONFIDENCE)}")
    for key in ("engine_consumable", "privacy_review_required"):
        value = md.get(key)
        if value not in YES_NO:
            errors.append(f"metadata.{key} must be quoted string 'yes' or 'no', got {value!r}")

    for section_name, section in (("metadata", md), ("downstream_handoff", handoff)):
        for key, value in section.items():
            if key in LIST_FIELDS and not isinstance(value, list):
                errors.append(f"{section_name}.{key} must be a list")

    for route_field in ("downstream_routes",):
        routes = md.get(route_field) or []
        if isinstance(routes, list):
            bad = [r for r in routes if str(r).strip() not in ROUTES]
            if bad:
                errors.append(f"metadata.{route_field} contains unsupported route tokens: {bad}")
    routes = handoff.get("consumer_routes") or []
    if isinstance(routes, list):
        bad = [r for r in routes if str(r).strip() not in ROUTES]
        if bad:
            errors.append(f"downstream_handoff.consumer_routes contains unsupported route tokens: {bad}")

    if artifact_id:
        if artifact_id in (md.get("cross_artifact_refs") or []):
            errors.append("metadata.cross_artifact_refs must not include the artifact's own id")
        if artifact_id in (handoff.get("cross_artifact_refs") or []):
            errors.append("downstream_handoff.cross_artifact_refs must not include the artifact's own id")

    if handoff:
        if handoff.get("contract_version") != md.get("contract_version"):
            errors.append("downstream_handoff.contract_version mismatch")
        if handoff.get("artifact_id") != md.get("artifact_id"):
            errors.append("downstream_handoff.artifact_id mismatch")

    if errors:
        for err in errors:
            print("ERROR:", err, file=sys.stderr)
        return 1
    print(f"OK: {path} passes metadata contract for {skill_name} (stdlib parser, additionalProperties=false)")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: validate_metadata.py <metadata.yaml> <skill-name>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(Path(sys.argv[1]), sys.argv[2]))
