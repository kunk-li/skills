#!/usr/bin/env python3
"""Release check for feedback-loop SKILL.md frontmatter and version drift."""
from __future__ import annotations

import re
import sys
from pathlib import Path

CONTRACT_VERSION = "feedback-loop-suite-v1.4.1"
REQUIRED_REFS = [
    CONTRACT_VERSION,
    "metadata-schema.json",
    "validate_feedback_artifact.py",
    "validate_metadata.py",
    "validate_decision_tree.py",
    "validate_feedback_handoff.py",
    "validate_downstream_handoff.py",
    "examples/",
]


def main(path: Path) -> int:
    text = path.read_text(encoding="utf-8")
    errors = []
    if not text.startswith("---"):
        errors.append("missing YAML frontmatter")
    m = re.match(r"^---\n(.*?)\n---", text, re.S)
    if not m:
        errors.append("invalid YAML frontmatter block")
    else:
        fm = m.group(1)
        name = re.search(r"^name:\s*(.+)$", fm, re.M)
        desc = re.search(r"^description:\s*(.+)$", fm, re.M)
        if not name:
            errors.append("frontmatter.name missing")
        elif name.group(1).strip() != name.group(1).strip().lower():
            errors.append("frontmatter.name should be lowercase")
        if not desc:
            errors.append("frontmatter.description missing")
        else:
            lower = desc.group(1).lower()
            if "use when" not in lower:
                errors.append("frontmatter.description should include use-when trigger wording")
            if "not for" not in lower:
                errors.append("frontmatter.description should include a not-for boundary")
    for required in REQUIRED_REFS:
        if required not in text:
            errors.append(f"SKILL.md missing release reference {required!r}")
    forbidden_order_fields = ["`depends" + "_on`", "`blo" + "cks`", "feedback-loop-s" + "01", "feedback-loop-s" + "02", "feedback-loop-s" + "03"]
    for token in forbidden_order_fields:
        if token in text:
            errors.append(f"SKILL.md still contains order-binding token {token!r}")
    retired_versions = (
        "v" + "1.2.0",
        "v" + "1.3.0",
        "v" + "1.3.1",
        "v" + "1.3.2",
        "feedback-loop-suite-v" + "1.3.1",
        "feedback-loop-suite-v" + "1.3.2",
        "feedback-loop-v" + "1.4.0",
        "feedback-loop-suite-v" + "1.4.0",
    )
    if any(token in text for token in retired_versions):
        errors.append("SKILL.md still contains old contract version drift")
    if errors:
        for err in errors:
            print("ERROR:", err, file=sys.stderr)
        return 1
    print(f"OK: {path} passes feedback-loop SKILL.md release check")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: validate_skill_md.py <SKILL.md>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(Path(sys.argv[1])))
