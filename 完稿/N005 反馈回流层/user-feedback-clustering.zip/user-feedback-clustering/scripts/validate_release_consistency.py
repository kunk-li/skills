#!/usr/bin/env python3
"""6-in-1 release consistency check for feedback-loop skill folders.

Checks SKILL.md, node-neutrality, order-neutrality, decision-tree alignment,
example artifacts, metadata sidecars, and local handoff surfaces without binding
the skill to private workflow-node identifiers or skill order.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

SKILL_NAMES = {"user-feedback-clustering", "production-signal-aggregation", "data-driven-requirement-mining"}
CONTRACT_VERSION = "feedback-loop-suite-v1.4.1"
REQUIRED_SCRIPTS = {
    "validate_feedback_artifact.py",
    "validate_metadata.py",
    "validate_decision_tree.py",
    "validate_feedback_handoff.py",
    "validate_downstream_handoff.py",
    "validate_release_consistency.py",
    "validate_skill_md.py",
    "check_node_neutrality.py",
    "check_order_neutrality.py",
}
REQUIRED_REFS = {
    "shared-feedback-loop-contract.md",
    "feedback-id-space.md",
    "metadata-schema.json",
    "field-contract.yaml",
    "quality-checklist.md",
    "anti-patterns.md",
    "selected-mode-decision-tree.md",
}


def load_module(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path.name}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_name(skill_md: Path) -> str | None:
    for line in skill_md.read_text(encoding="utf-8").splitlines():
        if line.startswith("name:"):
            return line.split(":", 1)[1].strip()
    return None


def run_check(errors: list[str], label: str, fn) -> None:
    try:
        code = fn()
    except Exception as exc:
        errors.append(f"{label} crashed: {exc}")
        return
    if code != 0:
        errors.append(f"{label} failed")


def main(skill_dir: Path) -> int:
    errors: list[str] = []
    skill_md = skill_dir / "SKILL.md"
    scripts = skill_dir / "scripts"
    refs = skill_dir / "references"
    examples = skill_dir / "examples"
    name = None

    if not skill_md.exists():
        errors.append("SKILL.md not found")
    else:
        name = read_name(skill_md)
        if name not in SKILL_NAMES:
            errors.append(f"unsupported skill name {name!r}")
        text = skill_md.read_text(encoding="utf-8")
        if CONTRACT_VERSION not in text:
            errors.append(f"SKILL.md missing {CONTRACT_VERSION}")
        if "use when" not in text.lower() or "not for" not in text.lower():
            errors.append("SKILL.md frontmatter should keep use-when and not-for routing language")

    for filename in sorted(REQUIRED_SCRIPTS):
        if not (scripts / filename).exists():
            errors.append(f"missing script {filename}")
    for filename in sorted(REQUIRED_REFS):
        if not (refs / filename).exists():
            errors.append(f"missing reference {filename}")

    if examples.exists():
        artifacts = [p for p in sorted(examples.iterdir()) if p.suffix.lower() in {".csv", ".json"}]
        metas = sorted(examples.glob("*.metadata.yaml"))
        if len(artifacts) < 3:
            errors.append("expected at least 3 CSV/JSON examples")
        if len(metas) < 3:
            errors.append("expected at least 3 metadata sidecars")
    else:
        artifacts = []
        metas = []
        errors.append("examples directory missing")

    if name and not errors:
        skill_check = load_module(scripts / "validate_skill_md.py", "validate_skill_md")
        node_guard = load_module(scripts / "check_node_neutrality.py", "check_node_neutrality")
        order_guard = load_module(scripts / "check_order_neutrality.py", "check_order_neutrality")
        decision = load_module(scripts / "validate_decision_tree.py", "validate_decision_tree")
        artifact_validator = load_module(scripts / "validate_feedback_artifact.py", "validate_feedback_artifact")
        metadata_validator = load_module(scripts / "validate_metadata.py", "validate_metadata")

        run_check(errors, "validate_skill_md.py", lambda: skill_check.main(skill_md))
        node_errors = node_guard.collect_errors(skill_dir)
        errors.extend(f"node-neutrality: {err}" for err in node_errors)
        order_errors = order_guard.collect_errors(skill_dir)
        errors.extend(f"order-neutrality: {err}" for err in order_errors)
        run_check(errors, "validate_decision_tree.py", lambda: decision.main(skill_dir))
        for artifact in artifacts:
            run_check(errors, f"validate_feedback_artifact.py {artifact.name}", lambda artifact=artifact: artifact_validator.validate_rows(artifact, name, strict=False))
        for meta in metas:
            run_check(errors, f"validate_metadata.py {meta.name}", lambda meta=meta: metadata_validator.main(meta, name))

    if errors:
        for err in errors:
            print("ERROR:", err, file=sys.stderr)
        return 1
    print(f"OK: 6-in-1 release consistency checks passed for {name}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: validate_release_consistency.py <skill-dir>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(Path(sys.argv[1])))
