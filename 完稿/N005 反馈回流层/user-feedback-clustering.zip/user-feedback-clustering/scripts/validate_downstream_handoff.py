#!/usr/bin/env python3
"""Validate DDRM handoff readiness for host workflow routes.

Usage:
  python validate_downstream_handoff.py --ddrm requirement_suggestions.csv --target all
  python validate_downstream_handoff.py --ddrm requirement_suggestions.csv --target intake --strict

Compatibility guard:
  This validator accepts known legacy private-node target aliases for host
  migration and normalizes them to route tokens with a warning. Artifact rows
  must still use route tokens and current field names.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List

PLACEHOLDERS = {"", "not_applicable", "n/a", "na", "none", "null", "unknown", "待确认", "不适用", "未知"}
ROUTES = {"intake", "reprioritization"}
VALID_TARGETS = {"all", "intake", "reprioritization"}
PRIVATE_NODE_PREFIX = "N"
LEGACY_TARGET_ALIASES = {PRIVATE_NODE_PREFIX + "010": "intake", PRIVATE_NODE_PREFIX + "060": "reprioritization"}
PRIVATE_NODE_TARGET_RE = re.compile(r"^" + PRIVATE_NODE_PREFIX + r"\d{3}$", re.IGNORECASE)
TARGETS = ROUTES | {"all"}
LEGACY_NUMERIC_ROUTE_RE = re.compile(r"^[nN]\d{3}$")
LEGACY_ROUTE_FIELDS = ("proposed_next_node", "proposed_next_route")


def norm(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return "|".join(norm(v) for v in value if norm(v))
    return str(value).strip()


def blank(value: Any) -> bool:
    return norm(value).lower() in PLACEHOLDERS


def load(path: Path) -> List[Dict[str, Any]]:
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            for key in ("requirement_suggestions", "suggestions", "suggestion_rows", "rows"):
                if isinstance(data.get(key), list):
                    return [dict(r) for r in data[key]]
            return [data]
        return [dict(r) for r in data]
    with path.open(encoding="utf-8-sig", newline="") as f:
        return [dict(r) for r in csv.DictReader(f)]


def get(row: Dict[str, Any], field: str) -> str:
    for key in (field, f"{field}[]"):
        if key in row:
            return norm(row.get(key))
    return ""


def has_nonblank(row: Dict[str, Any], field: str) -> bool:
    return not blank(get(row, field))


def legacy_field_values(row: Dict[str, Any]) -> list[tuple[str, str]]:
    values: list[tuple[str, str]] = []
    for field in LEGACY_ROUTE_FIELDS:
        value = get(row, field)
        if not blank(value):
            values.append((field, value))
    return values


def route_error(value: str, where: str) -> str:
    if LEGACY_NUMERIC_ROUTE_RE.fullmatch(value):
        return f"{where}: legacy numeric route code is no longer accepted; use intake or reprioritization"
    return f"{where}: route must be intake or reprioritization, got {value!r}"


def num(value: str) -> float | None:
    if not value:
        return None
    if re.fullmatch(r"[+-]?\d+(?:\.\d+)?", value):
        return float(value)
    return None



def normalize_target(raw: str) -> tuple[str, str | None, str | None]:
    """Return normalized route target, warning, error.

    Known legacy private-node aliases are accepted for host migration, but all
    artifact rows must still use route tokens. The source keeps legacy aliases
    constructed from pieces so static node-neutrality guards remain meaningful.
    """
    value = str(raw or "").strip()
    if value in VALID_TARGETS:
        return value, None, None
    upper = value.upper()
    if upper in LEGACY_TARGET_ALIASES:
        route = LEGACY_TARGET_ALIASES[upper]
        return route, f"legacy private workflow-node target {value!r} normalized to route token {route!r}; update host mapping to call this script with route tokens", None
    if PRIVATE_NODE_TARGET_RE.fullmatch(upper):
        return "", None, f"private workflow-node target {value!r} has no built-in route mapping; use all/intake/reprioritization"
    return "", None, f"unsupported target {value!r}; use all/intake/reprioritization"

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ddrm", required=True)
    parser.add_argument("--target", default="all", help="all, intake, reprioritization, or a legacy host-node alias")
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()

    target, target_warning, target_error = normalize_target(args.target)
    if target_error:
        print(f"ERROR: {target_error}", file=sys.stderr)
        print("HINT: v1.4+ uses route tokens; host workflows should map private nodes outside this skill.", file=sys.stderr)
        return 2
    if target_warning:
        print(f"WARN: {target_warning}", file=sys.stderr)

    try:
        rows = load(Path(args.ddrm))
    except Exception as exc:
        print(f"ERROR: failed to load DDRM artifact: {exc}", file=sys.stderr)
        return 2

    errors: List[str] = []
    warnings: List[str] = []
    if not rows:
        errors.append("DDRM artifact has no rows")

    for idx, row in enumerate(rows, start=2):
        proposed = get(row, "proposed_route")
        legacy_values = legacy_field_values(row)
        action = get(row, "recommended_action")
        novelty = get(row, "novelty_or_duplicate_status").lower()

        if blank(proposed) and legacy_values:
            legacy_desc = ", ".join(f"{field}={value!r}" for field, value in legacy_values)
            errors.append(
                f"row {idx}: legacy route field detected ({legacy_desc}); rename to proposed_route and use intake or reprioritization"
            )
            continue
        if not blank(proposed) and legacy_values:
            legacy_fields = ", ".join(field for field, _ in legacy_values)
            warnings.append(f"row {idx}: legacy route field(s) also present and ignored: {legacy_fields}")

        if target != "all" and proposed != target:
            continue
        base_required = ["suggestion_id", "hypothesis_title", "user_problem", "source_signal_ids", "anti_goal", "validation_question", "recommended_action"]
        missing = [f for f in base_required if blank(get(row, f))]
        if missing:
            errors.append(f"row {idx}: missing handoff fields {missing}")
        if proposed not in ROUTES:
            errors.append(route_error(proposed, f"row {idx}: proposed_route"))
            continue
        if proposed == "intake":
            if action == "reprioritize":
                warnings.append(f"row {idx}: intake route should not use recommended_action=reprioritize")
            if blank(get(row, "evidence_summary")) and blank(get(row, "source_artifact_refs")):
                errors.append(f"row {idx}: intake route needs evidence_summary or source_artifact_refs")
            if "duplicate" in novelty and blank(get(row, "known_backlog_refs")):
                warnings.append(f"row {idx}: duplicate-like intake item should include known_backlog_refs or route to merge")
        if proposed == "reprioritization":
            if action == "intake":
                warnings.append(f"row {idx}: reprioritization route should not use recommended_action=intake")
            if "novel" in novelty or "new" in novelty:
                warnings.append(f"row {idx}: novel demand should normally route to intake before reprioritization")
            if blank(get(row, "known_backlog_refs")) and action in {"reprioritize", "merge"}:
                errors.append(f"row {idx}: reprioritization/merge needs known_backlog_refs")
            urgency = num(get(row, "urgency_score"))
            value = num(get(row, "business_value_score"))
            risk = num(get(row, "risk_reduction_score"))
            if action == "reprioritize" and all(v is None or v < 3 for v in (urgency, value, risk)):
                warnings.append(f"row {idx}: reprioritize should include at least one strong urgency/value/risk score")

    for warning in warnings:
        print("WARN:", warning, file=sys.stderr)
    if args.strict and warnings:
        errors.extend(f"strict warning: {w}" for w in warnings)
    if errors:
        for err in errors:
            print("ERROR:", err, file=sys.stderr)
        return 1
    print(f"OK: DDRM handoff is ready for {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
