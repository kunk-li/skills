#!/usr/bin/env python3
"""Fail if a skill package reintroduces explicit skill ordering."""
from __future__ import annotations

import re
import sys
from pathlib import Path

TEXT_EXTS = {".md", ".yaml", ".yml", ".json", ".csv", ".py", ".txt", ".log"}
EXEMPT_DIRS = {"__pycache__", ".git"}
SELF_NAME = "check_order_neutrality.py"
DEPENDS_TOKEN = "depends" + "_on"
BLOCKS_TOKEN = "blo" + "cks"
ORDER_KEY_RE = re.compile(r"[`'\"]?\b(?:" + re.escape(DEPENDS_TOKEN) + r"|" + re.escape(BLOCKS_TOKEN) + r")\b[`'\"]?\s*[:=]", re.IGNORECASE)
POSITIONAL_ID_RE = re.compile(r"\b(?:[a-z][a-z0-9_-]*-[sS]\d{2,}|[sS]0[1-9])\b", re.IGNORECASE)
DESC_SEQUENCE_RE = re.compile(r"^description\s*:.*\b(before|after)\b", re.IGNORECASE)


def iter_contract_files(skill_dir: Path):
    for path in sorted(skill_dir.rglob("*")):
        if not path.is_file():
            continue
        if path.name == SELF_NAME:
            continue
        if any(part in EXEMPT_DIRS for part in path.parts):
            continue
        if path.suffix.lower() in TEXT_EXTS:
            yield path


def collect_errors(skill_dir: Path) -> list[str]:
    errors: list[str] = []
    for path in iter_contract_files(skill_dir):
        rel = path.relative_to(skill_dir)
        if POSITIONAL_ID_RE.search(str(rel)):
            errors.append(f"{rel}: positional id in path")
        text = path.read_text(encoding="utf-8", errors="ignore")
        for lineno, line in enumerate(text.splitlines(), start=1):
            if ORDER_KEY_RE.search(line):
                errors.append(f"{rel}:{lineno}: order-binding field key")
            if POSITIONAL_ID_RE.search(line):
                errors.append(f"{rel}:{lineno}: positional skill id")
            if rel.as_posix() == "SKILL.md" and DESC_SEQUENCE_RE.search(line):
                errors.append(f"{rel}:{lineno}: frontmatter description contains sequencing language")
    return errors


def main(skill_dir: Path) -> int:
    errors = collect_errors(skill_dir)
    if errors:
        print(f"FAIL: {len(errors)} order-neutrality violations", file=sys.stderr)
        for err in errors[:40]:
            print(f"  {err}", file=sys.stderr)
        if len(errors) > 40:
            print(f"  ... and {len(errors) - 40} more", file=sys.stderr)
        return 1
    print(f"OK: order-neutral skill package for {skill_dir.name}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: check_order_neutrality.py <skill-dir>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(Path(sys.argv[1])))
