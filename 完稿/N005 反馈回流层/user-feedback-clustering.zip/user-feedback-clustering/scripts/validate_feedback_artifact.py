#!/usr/bin/env python3
"""Strict validator for feedback-loop CSV/JSON artifacts.

Usage:
  python validate_feedback_artifact.py [--strict] artifact.json production-signal-aggregation
  python validate_feedback_artifact.py [--strict] artifact.csv data-driven-requirement-mining
  python validate_feedback_artifact.py [--strict] artifact.csv user-feedback-clustering

Normal mode fails hard contract violations and prints semantic warnings.
Strict mode turns warnings into failures for CI/release checks.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

CONTRACT_VERSION = "feedback-loop-suite-v1.4.1"
PLACEHOLDERS = {"", "not_applicable", "n/a", "na", "none", "null", "unknown", "待确认", "不适用", "未知"}
CONFIDENCE = {"high", "medium", "low", "needs_human_review", "明确写明", "基于上下文推断", "待确认"}
SOURCE_TYPES = {"runtime_error", "incident_postmortem", "defect", "user_feedback", "nps", "support_ticket", "survey", "other"}
SOURCE_NODES = {"defect_source", "runtime_source", "postmortem_source", "external", "unknown"}
RECOMMENDED_ROUTES = {"intake", "reprioritization", "human_review", "monitor_only"}
NOISE_FLAGS = {"false", "possible_duplicate", "spam_or_irrelevant", "insufficient_context"}
SENTIMENT = {"positive", "neutral", "negative", "mixed", "unknown"}
NPS_BUCKET = {"promoter", "passive", "detractor", "unknown"}
NEXT_NODES = {"intake", "reprioritization"}
RECOMMENDED_ACTIONS = {"intake", "reprioritize", "merge", "monitor", "human_review"}
PRIVATE_NODE_RE = re.compile(r"\b" + "N" + r"\d{3}\b", re.IGNORECASE)
RETIRED_ROW_FIELDS = {
    "data-driven-requirement-mining": {"proposed_next_node": "proposed_route"},
    "production-signal-aggregation": {"consumer_nodes": "consumer_routes", "downstream_nodes": "downstream_routes"},
    "user-feedback-clustering": {"consumer_nodes": "consumer_routes", "downstream_nodes": "downstream_routes"},
}

ROW_KEYS = {
    "user-feedback-clustering": ("feedback_clusters", "clusters", "cluster_rows", "rows"),
    "production-signal-aggregation": ("normalized_signal_registry", "signals", "signal_rows", "rows"),
    "data-driven-requirement-mining": ("requirement_suggestions", "suggestions", "suggestion_rows", "rows"),
}

REQUIRED = {
    "user-feedback-clustering": {"cluster_id", "theme", "pain_point", "feedback_count", "representative_evidence_refs", "confidence"},
    "production-signal-aggregation": {"signal_id", "source_type", "observed_problem", "evidence_refs", "confidence", "priority_hint"},
    "data-driven-requirement-mining": {"suggestion_id", "hypothesis_title", "user_problem", "source_signal_ids", "proposed_route", "confidence", "anti_goal", "validation_question", "recommended_action"},
}

ROW_CONTRACT_FIELDS = {
    "user-feedback-clustering": ["cluster_id","theme","pain_point","jobs_to_be_done","journey_step","feedback_count","source_mix","user_segment","nps_bucket","sentiment","emotion","severity_hint","frequency_hint","representative_summary","representative_evidence_refs","dedupe_key","related_feature_area","known_backlog_refs","handoff_signal_tags","confidence","noise_flag","privacy_note"],
    "production-signal-aggregation": ["signal_id","source_type","source_node","source_artifact","observed_problem","feature_area","user_segment","time_window","count_or_rate","frequency_score","impact_score","severity_score","confidence","priority_hint","dedupe_key","related_incident_ids","related_defect_ids","feedback_cluster_ids","candidate_requirement_refs","evidence_refs","noise_reason","recommended_route"],
    "data-driven-requirement-mining": ["suggestion_id","hypothesis_title","user_problem","evidence_summary","source_signal_ids","source_artifact_refs","affected_scope","frequency_score","impact_score","severity_score","business_value_score","risk_reduction_score","urgency_score","confidence","novelty_or_duplicate_status","known_backlog_refs","anti_goal","candidate_solution_optional","validation_question","proposed_route","recommended_action"],
}

ID_RULES = {
    "user-feedback-clustering": ("cluster_id", re.compile(r"^FBCL-[A-Za-z0-9_]+-\d{3,}$")),
    "production-signal-aggregation": ("signal_id", re.compile(r"^SIG-[A-Za-z0-9_]+-\d{3,}$")),
    "data-driven-requirement-mining": ("suggestion_id", re.compile(r"^DREQ-[A-Za-z0-9_]+-\d{3,}$")),
}

SCORE_FIELDS = {
    "production-signal-aggregation": ["frequency_score", "impact_score", "severity_score", "priority_hint"],
    "data-driven-requirement-mining": ["frequency_score", "impact_score", "severity_score", "business_value_score", "risk_reduction_score", "urgency_score"],
    "user-feedback-clustering": [],
}

PII_PATTERNS = [
    ("email", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")),
    ("phone", re.compile(r"(?<!\d)(?:\+?\d[\d \-()]{7,}\d)(?!\d)")),
    ("api_secret", re.compile(r"\b(?:sk|pk|api[_-]?key|token|secret)[-_A-Za-z0-9]{16,}\b", re.I)),
]

TEXT_FIELDS_FOR_PRIVACY = {
    "user-feedback-clustering": ["pain_point", "representative_summary", "privacy_note"],
    "production-signal-aggregation": ["observed_problem", "noise_reason"],
    "data-driven-requirement-mining": ["user_problem", "evidence_summary", "candidate_solution_optional"],
}


def normalize(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return "|".join(normalize(v) for v in value if normalize(v))
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    return str(value).strip()


def get(row: Dict[str, Any], field: str) -> str:
    for key in (field, f"{field}[]"):
        if key in row:
            return normalize(row.get(key))
    return ""


def is_blank(value: Any) -> bool:
    return normalize(value).strip().lower() in PLACEHOLDERS


def split_multi(value: Any) -> List[str]:
    raw = normalize(value)
    if not raw or raw.lower() in PLACEHOLDERS:
        return []
    return [part.strip() for part in re.split(r"[|;；,，]", raw) if part.strip() and part.strip().lower() not in PLACEHOLDERS]


def load_rows(path: Path, skill: str) -> Tuple[List[Dict[str, Any]], List[str]]:
    suffix = path.suffix.lower()
    if suffix == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            for key in ROW_KEYS.get(skill, ("rows",)):
                if isinstance(data.get(key), list):
                    return [dict(r) for r in data[key]], []
            return [data], list(data.keys())
        if isinstance(data, list):
            return [dict(r) for r in data], []
        raise ValueError("JSON root must be an object or array")
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        return [dict(r) for r in reader], list(reader.fieldnames or [])


def parse_int(value: Any) -> int | None:
    raw = normalize(value)
    if not raw:
        return None
    if not re.fullmatch(r"[+-]?\d+", raw):
        return None
    return int(raw)


def parse_number(value: Any) -> float | None:
    raw = normalize(value)
    if not raw:
        return None
    if re.fullmatch(r"[+-]?\d+(?:\.\d+)?%?", raw):
        return float(raw.rstrip("%"))
    return None


def check_score(row: Dict[str, Any], field: str, row_num: int, errors: List[str]) -> float | None:
    raw = get(row, field)
    if is_blank(raw):
        errors.append(f"row {row_num}: {field} is required and must be numeric 0-5")
        return None
    num = parse_number(raw)
    if num is None:
        errors.append(f"row {row_num}: {field} must be numeric 0-5, got {raw!r}")
        return None
    if not (0 <= num <= 5):
        errors.append(f"row {row_num}: {field} must be between 0 and 5, got {raw!r}")
    return num


def check_enum(row: Dict[str, Any], field: str, allowed: set[str], row_num: int, errors: List[str]) -> None:
    raw = get(row, field)
    if not raw:
        return
    if raw not in allowed:
        errors.append(f"row {row_num}: {field} must be one of {sorted(allowed)}, got {raw!r}")


def scan_pii(row: Dict[str, Any], fields: Iterable[str], row_num: int, warnings: List[str]) -> None:
    for field in fields:
        value = get(row, field)
        if not value:
            continue
        for label, pattern in PII_PATTERNS:
            if pattern.search(value):
                warnings.append(f"row {row_num}: possible {label} in {field}; summarize or redact raw personal data")


def validate_rows(path: Path, skill: str, strict: bool = False) -> int:
    if skill not in REQUIRED:
        print(f"Unknown skill: {skill}", file=sys.stderr)
        return 2
    try:
        rows, header = load_rows(path, skill)
    except Exception as exc:
        print(f"ERROR: failed to load {path}: {exc}", file=sys.stderr)
        return 2

    errors: List[str] = []
    warnings: List[str] = []
    if not rows:
        errors.append("artifact has no data rows")

    if header:
        missing_columns = [f for f in ROW_CONTRACT_FIELDS[skill] if f not in header and f + "[]" not in header]
        if missing_columns:
            if strict:
                warnings.append(f"header missing row-contract fields: {missing_columns}")
            else:
                core_missing = [f for f in sorted(REQUIRED[skill]) if f not in header and f + "[]" not in header]
                if core_missing:
                    warnings.append(f"header missing core row-contract fields: {core_missing}")
                elif len(missing_columns) > 5:
                    warnings.append(f"header missing {len(missing_columns)} recommended row-contract fields; rerun with --strict for full list")
                else:
                    warnings.append(f"header missing recommended row-contract fields: {missing_columns}")

    seen_ids: set[str] = set()
    id_field, id_re = ID_RULES[skill]

    for row_num, row in enumerate(rows, start=2 if header else 1):
        missing = [field for field in sorted(REQUIRED[skill]) if is_blank(get(row, field))]
        if missing:
            errors.append(f"row {row_num}: missing required fields {missing}")

        for retired_field, replacement_field in RETIRED_ROW_FIELDS.get(skill, {}).items():
            if retired_field in row and not is_blank(get(row, retired_field)):
                errors.append(f"row {row_num}: retired field {retired_field!r} detected; use {replacement_field!r} with route/source tokens")

        for route_like_field in ("proposed_route", "recommended_route", "source_node"):
            route_like_value = get(row, route_like_field)
            if route_like_value and PRIVATE_NODE_RE.search(route_like_value):
                errors.append(f"row {row_num}: {route_like_field} contains a private workflow-node code; use route/source tokens")

        ident = get(row, id_field)
        if ident:
            if not id_re.match(ident):
                errors.append(f"row {row_num}: {id_field} {ident!r} does not match expected id pattern")
            if ident in seen_ids:
                errors.append(f"row {row_num}: duplicate {id_field} {ident!r}")
            seen_ids.add(ident)

        conf = get(row, "confidence")
        if conf and conf not in CONFIDENCE:
            errors.append(f"row {row_num}: unexpected confidence {conf!r}")

        scan_pii(row, TEXT_FIELDS_FOR_PRIVACY[skill], row_num, warnings)

        if skill == "user-feedback-clustering":
            count_raw = get(row, "feedback_count")
            count = parse_int(count_raw)
            if count is None or count <= 0:
                errors.append(f"row {row_num}: feedback_count must be a positive integer, got {count_raw!r}")
            elif count == 1 and conf == "high":
                warnings.append(f"row {row_num}: single-feedback cluster should not be high confidence")
            if get(row, "noise_flag"):
                check_enum(row, "noise_flag", NOISE_FLAGS, row_num, errors)
            if get(row, "sentiment"):
                check_enum(row, "sentiment", SENTIMENT, row_num, errors)
            if get(row, "nps_bucket"):
                check_enum(row, "nps_bucket", NPS_BUCKET, row_num, errors)
            if is_blank(get(row, "dedupe_key")):
                warnings.append(f"row {row_num}: dedupe_key is recommended for feedback clusters")
            if is_blank(get(row, "handoff_signal_tags")):
                warnings.append(f"row {row_num}: handoff_signal_tags should be populated for PSA/DDRM handoff")

        elif skill == "production-signal-aggregation":
            check_enum(row, "source_type", SOURCE_TYPES, row_num, errors)
            if get(row, "source_node"):
                check_enum(row, "source_node", SOURCE_NODES, row_num, errors)
            if get(row, "recommended_route"):
                check_enum(row, "recommended_route", RECOMMENDED_ROUTES, row_num, errors)
            for field in SCORE_FIELDS[skill]:
                check_score(row, field, row_num, errors)
            priority = parse_number(get(row, "priority_hint"))
            count = parse_number(get(row, "count_or_rate")) if get(row, "count_or_rate") else None
            if get(row, "count_or_rate") and count is None:
                errors.append(f"row {row_num}: count_or_rate should be numeric or percentage-like, got {get(row, 'count_or_rate')!r}")
            if conf == "low" and priority is not None and priority > 3:
                warnings.append(f"row {row_num}: low confidence signal should not carry priority_hint > 3 without human review")
            if count is not None and count <= 0 and priority is not None and priority >= 4:
                warnings.append(f"row {row_num}: priority_hint >= 4 conflicts with non-positive count_or_rate")
            if is_blank(get(row, "dedupe_key")):
                errors.append(f"row {row_num}: dedupe_key is required before scoring")
            if priority is not None and priority >= 4 and is_blank(get(row, "recommended_route")):
                warnings.append(f"row {row_num}: high priority signal should declare recommended_route")

        elif skill == "data-driven-requirement-mining":
            for field in SCORE_FIELDS[skill]:
                if get(row, field):
                    check_score(row, field, row_num, errors)
            proposed = get(row, "proposed_route")
            if re.search(r"[|,，/]+", proposed):
                warnings.append(f"row {row_num}: proposed_route must choose exactly one route, got {proposed!r}")
            elif proposed and proposed not in NEXT_NODES:
                errors.append(f"row {row_num}: proposed_route must be intake or reprioritization, got {proposed!r}")
            action = get(row, "recommended_action")
            if action and action not in RECOMMENDED_ACTIONS:
                errors.append(f"row {row_num}: recommended_action must be one of {sorted(RECOMMENDED_ACTIONS)}, got {action!r}")
            novelty = get(row, "novelty_or_duplicate_status").lower()
            if proposed == "reprioritization" and ("novel" in novelty or "new" in novelty):
                warnings.append(f"row {row_num}: novel requirement should normally route to intake before reprioritization")
            if conf == "low" and action in {"intake", "reprioritize"}:
                warnings.append(f"row {row_num}: low-confidence suggestion should route to human_review or monitor")
            if proposed == "reprioritization" and action == "intake":
                warnings.append(f"row {row_num}: reprioritization route conflicts with intake action")
            if proposed == "intake" and action == "reprioritize":
                warnings.append(f"row {row_num}: intake route conflicts with reprioritize action")
            solutionish = get(row, "user_problem").lower()
            if re.match(r"^(build|implement|add|create|开发|实现|新增)", solutionish):
                warnings.append(f"row {row_num}: user_problem appears solution-first; restate the problem before solution")

    for warning in warnings:
        print("WARN:", warning, file=sys.stderr)
    if strict and warnings:
        errors.extend(f"strict warning: {w}" for w in warnings)
    if errors:
        print("Validation failed:", file=sys.stderr)
        for err in errors:
            print("ERROR:", err, file=sys.stderr)
        return 1
    print(f"Validation passed: {len(rows)} rows for {skill}" + (f" with {len(warnings)} warning(s)" if warnings else ""))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict", action="store_true", help="treat warnings as failures")
    parser.add_argument("artifact")
    parser.add_argument("skill_name")
    args = parser.parse_args()
    return validate_rows(Path(args.artifact), args.skill_name, strict=args.strict)


if __name__ == "__main__":
    raise SystemExit(main())
