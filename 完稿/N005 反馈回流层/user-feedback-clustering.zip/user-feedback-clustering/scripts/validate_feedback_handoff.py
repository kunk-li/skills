#!/usr/bin/env python3
"""Validate cross-skill feedback handoff references.

Examples:
  python validate_feedback_handoff.py --ufc 用户反馈聚类表.csv --psa 线上痛点信号包.json --ddrm 数据驱动需求建议.csv
  python validate_feedback_handoff.py --ufc ufc_a.csv --ufc ufc_b.csv --psa psa_a.json --psa psa_b.json --ddrm ddrm.csv --strict

Checks:
- Multiple UFC/PSA/DDRM artifacts can be supplied without manual concatenation.
- PSA feedback_cluster_ids reference UFC cluster_id values when UFC artifacts are supplied.
- DDRM source_signal_ids reference PSA signal_id values when PSA artifacts are supplied.
- DDRM proposed_route is a single intake or reprioritization route.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

PLACEHOLDERS = {"", "not_applicable", "n/a", "unknown", "待确认", "不适用"}


def norm(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return "|".join(norm(v) for v in value if norm(v))
    return str(value).strip()


def split_multi(value: Any) -> List[str]:
    raw = norm(value)
    if raw.lower() in PLACEHOLDERS:
        return []
    return [p.strip() for p in re.split(r"[|;；,，]", raw) if p.strip() and p.strip().lower() not in PLACEHOLDERS]


def load(path: Path, keys: tuple[str, ...]) -> List[Dict[str, Any]]:
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            for key in keys:
                if isinstance(data.get(key), list):
                    return [dict(r) for r in data[key]]
            return [data]
        return [dict(r) for r in data]
    with path.open(encoding="utf-8-sig", newline="") as f:
        return [dict(r) for r in csv.DictReader(f)]


def load_many(paths: Iterable[str] | None, keys: tuple[str, ...]) -> List[Tuple[Path, Dict[str, Any]]]:
    rows: List[Tuple[Path, Dict[str, Any]]] = []
    for raw in paths or []:
        path = Path(raw)
        try:
            for row in load(path, keys):
                rows.append((path, row))
        except Exception as exc:
            raise RuntimeError(f"failed to load {path}: {exc}") from exc
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ufc", action="append", default=[])
    parser.add_argument("--psa", action="append", default=[])
    parser.add_argument("--ddrm", action="append", default=[])
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    if not any([args.ufc, args.psa, args.ddrm]):
        print("ERROR: provide at least one artifact for handoff validation", file=sys.stderr)
        return 2

    errors: List[str] = []
    warnings: List[str] = []
    try:
        ufc_rows = load_many(args.ufc, ("feedback_clusters", "clusters", "cluster_rows", "rows"))
        psa_rows = load_many(args.psa, ("normalized_signal_registry", "signals", "signal_rows", "rows"))
        ddrm_rows = load_many(args.ddrm, ("requirement_suggestions", "suggestions", "suggestion_rows", "rows"))
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    ufc_ids: dict[str, Path] = {}
    psa_ids: dict[str, Path] = {}

    for path, row in ufc_rows:
        cid = norm(row.get("cluster_id") or row.get("cluster_id[]"))
        if cid:
            if cid in ufc_ids:
                errors.append(f"UFC {path}: duplicate cluster_id {cid} also found in {ufc_ids[cid]}")
            ufc_ids[cid] = path

    for idx, (path, row) in enumerate(psa_rows, start=1):
        sid = norm(row.get("signal_id") or row.get("signal_id[]"))
        if sid:
            if sid in psa_ids:
                errors.append(f"PSA {path} row {idx}: duplicate signal_id {sid} also found in {psa_ids[sid]}")
            psa_ids[sid] = path
        if ufc_ids:
            for cid in split_multi(row.get("feedback_cluster_ids") or row.get("feedback_cluster_ids[]")):
                if cid not in ufc_ids:
                    errors.append(f"PSA {path} row {idx}: feedback_cluster_id {cid} not found in supplied UFC artifacts")
        elif split_multi(row.get("feedback_cluster_ids") or row.get("feedback_cluster_ids[]")):
            warnings.append(f"PSA {path} row {idx}: feedback_cluster_ids present but no UFC artifact was supplied")

    for idx, (path, row) in enumerate(ddrm_rows, start=1):
        proposed = norm(row.get("proposed_route") or row.get("proposed_route[]"))
        if re.search(r"[|,，/]+", proposed):
            warnings.append(f"DDRM {path} row {idx}: proposed_route should choose exactly one route, got {proposed!r}")
        elif proposed not in {"intake", "reprioritization"}:
            errors.append(f"DDRM {path} row {idx}: proposed_route must be intake or reprioritization, got {proposed!r}")
        refs = split_multi(row.get("source_signal_ids") or row.get("source_signal_ids[]"))
        if psa_ids:
            for sid in refs:
                if sid not in psa_ids:
                    errors.append(f"DDRM {path} row {idx}: source_signal_id {sid} not found in supplied PSA artifacts")
        elif refs:
            warnings.append(f"DDRM {path} row {idx}: source_signal_ids present but no PSA artifact was supplied")

    for warning in warnings:
        print("WARN:", warning, file=sys.stderr)
    if args.strict and warnings:
        errors.extend(f"strict warning: {w}" for w in warnings)
    if errors:
        for err in errors:
            print("ERROR:", err, file=sys.stderr)
        return 1
    print(f"OK: feedback handoff references are consistent (ufc_files={len(args.ufc)}, psa_files={len(args.psa)}, ddrm_files={len(args.ddrm)})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
