---
name: production-signal-aggregation
display_name: 线上信号聚合 / Production Signal Aggregation
description: aggregate defects, runtime errors, postmortems, feedback clusters, support tickets, NPS, and product analytics into a deduplicated online pain-point signal package with source lineage, scores, confidence, and route hints. use when multi-source production signals need normalization or quantification — standalone or with requirement mining. not for raw feedback clustering or final roadmap decisions.
---
# production-signal-aggregation

## Feedback-loop metadata / 阶段元数据
- `skill_family`: `feedback-loop-suite`
- `host_workflow_node`: provided by the host workflow; this skill does not bind itself to a fixed node
- `skill_id`: `production-signal-aggregation`
- `stage_hint`: `feedback_loop.signal_aggregation`
- `prerequisites`: none; the skill is single-skill usable and evidence-gated
- `composable_with`: `['user-feedback-clustering', 'data-driven-requirement-mining']`
- `consumes_when_available`: `['feedback clusters', 'defect tables', 'runtime error summaries', 'incident postmortems', 'support-ticket summaries', 'surveys']`
- `route_hints`: `['intake', 'reprioritization', 'human_review']`
- `artifact_target`: `线上痛点信号包.json`

## feedback-loop-suite v1.4.1 contract baseline
- `contract_version`: `feedback-loop-suite-v1.4.1`
- `artifact_family_id`: `feedback-loop-suite`
- `schema`: `feedback.production-signal-aggregation.v4`
- `metadata_sidecar`: required for final artifacts (`*.metadata.yaml`) with strict `additionalProperties: false`
- `artifact_id_namespace`: `PSA-SIGNAL-<scope>-<yyyymm>`
- `validation_scripts`: `validate_feedback_artifact.py`, `validate_metadata.py`, `validate_decision_tree.py`, `validate_feedback_handoff.py`, `validate_downstream_handoff.py`, `validate_release_consistency.py`
- `examples/`: contains executable examples, metadata sidecars, and upstream defect/runtime/postmortem samples for regression testing

## Role / 角色定位
Aggregate multiple online and post-release signals into a normalized, deduplicated, evidence-backed pain-point signal package. The output should make downstream product teams understand what is happening, where, how often, how severe it is, and how reliable the evidence is.

## Single-skill value / 单独使用价值
- Can run on any mix of logs, incident notes, defect tables, feedback snippets, or NPS data.
- Produces a stable signal registry even when some sources are missing.
- Marks missing evidence and confidence instead of blocking the feedback loop.

## Multi-skill value / 组合使用价值
- Can consume `user-feedback-clustering` output when user feedback volume is high.
- Can consume defect, runtime, and postmortem signals while preserving source lineage.
- Can be composed with `data-driven-requirement-mining` through quantified and deduplicated `source_signal_ids`.
- Supports intake and reprioritization route hints without bypassing host workflow gates.

## Allowed inputs / 允许输入
- `高频报错摘要.md`
- `缺陷分类表.csv`
- `线上问题复盘.md` or `故障复盘.md`
- `用户反馈聚类表.csv`
- NPS, support-ticket summaries, customer feedback, product analytics summaries
- Existing backlog or PRD refs, only for deduplication and novelty checks

## Prohibited inputs / 禁止输入
- Private raw user data that is not needed for aggregation.
- Unsupported assumptions about root cause, roadmap commitment, or implementation approach.
- Release go/no-go decisions or remediation approval requests.

## Modes
- `multi_source_aggregation`: default mode for mixed production, defect, incident, and feedback inputs.
- `incident_signal_rollup`: use when postmortems or postmortem_source artifacts dominate.
- `defect_trend_rollup`: use when defect_source defect tables dominate.
- `runtime_error_rollup`: use when runtime_source frequent error or monitoring data dominates.
- `feedback_pack`: use when the output is explicitly for feedback-loop route handoff.

## Required output sections
1. `metadata`
2. `source_coverage`
3. `normalized_signal_registry[]`
4. `deduped_pain_points[]`
5. `trend_and_recurrence_summary`
6. `impact_and_priority_scoring`
7. `noise_and_confidence_notes`
8. `downstream_handoff`
9. `produced_events`
10. `self_check`

## Required row contract

Each normalized signal row must include the following fields.

| field | required | format / enum |
| --- | --- | --- |
| `signal_id` | required | `PSA-SIGNAL-<scope>-<yyyymm>-<nnn>` |
| `source_type` | required | `runtime_source\|defect_source\|postmortem_source\|feedback_source\|survey_source\|analytics_source` |
| `source_node` | required | originating system or team |
| `source_artifact` | required | source file or ticket reference |
| `observed_problem` | required | one-sentence observable problem statement |
| `feature_area` | required | product feature area |
| `user_segment` | required | segment label or `unknown` |
| `time_window` | required | ISO-8601 date range |
| `count_or_rate` | required | numeric count or rate with unit |
| `frequency_score` | required | `high\|medium\|low\|unknown` |
| `impact_score` | required | `critical\|high\|medium\|low` |
| `severity_score` | required | `critical\|high\|medium\|low` |
| `confidence` | required | `high\|medium\|low\|needs_human_review` |
| `priority_hint` | required | `p0\|p1\|p2\|monitor\|human_review` |
| `dedupe_key` | required | canonical key for cross-source deduplication |
| `related_incident_ids` | recommended | `\|`-separated incident IDs |
| `related_defect_ids` | recommended | `\|`-separated defect IDs |
| `feedback_cluster_ids` | recommended | `\|`-separated UFC cluster IDs |
| `candidate_requirement_refs` | recommended | `\|`-separated backlog or PRD IDs |
| `evidence_refs` | required | `\|`-separated evidence anchors |
| `noise_reason` | required | reason if noise flag set, else `none` |


## Rules
- `R01_evidence_required`: every signal row must have at least one evidence reference or be routed to human review.
- `R02_source_separation`: keep runtime, defect, postmortem, and user-feedback sources distinguishable.
- `R03_no_root_cause_overreach`: do not invent root causes; cite postmortem_source/runtime_source if available.
- `R04_no_roadmap_commitment`: priority hints are recommendations, not decisions.
- `R05_dedupe_before_scoring`: deduplicate equivalent signals before ranking.
- `R06_low_confidence_visible`: low-confidence and noisy signals must stay visible with a reason.
- `R07_privacy_safe_feedback`: user feedback must be summarized without unnecessary personal data.
- `R08_downstream_route_declared`: every high-priority pain point must include a recommended intake/reprioritization route.
- `R09_machine_validation`: run artifact, metadata, and handoff validators when execution is available.

## Skill-specific anti-patterns (AP-PSA-*)

| id | anti-pattern | why harmful | correct pattern |
| --- | --- | --- | --- |
| AP-PSA-01 | mixing source types without `source_type` tagging | downstream cannot distinguish runtime errors from user feedback | always populate `source_type` per row with one of the defined enum values |
| AP-PSA-02 | over-ranking high-volume low-severity signals | noisy signals crowd out critical low-volume issues | apply both `frequency_score` and `severity_score`; never rank on volume alone |
| AP-PSA-03 | inventing root causes not in the postmortem source | misleads engineering and planning decisions | cite `postmortem_source` or mark `evidence_status: unverified` |
| AP-PSA-04 | emitting duplicate `signal_id` across aggregation runs | downstream cannot deduplicate or audit signal history | use stable `dedupe_key` and check for existing IDs before emitting new rows |

## Execution workflow
1. Normalize all source artifacts into the shared feedback-loop signal fields.
2. Group records by feature area, user segment, time window, and dedupe key.
3. Link runtime errors, defects, incidents, and feedback clusters when they describe the same observed problem.
4. Score frequency, impact, severity, confidence, novelty, and actionability.
5. Produce a ranked `deduped_pain_points[]` view.
6. Identify noise, gaps, conflicts, and signals needing human review.
7. Create `downstream_handoff.to_requirement_mining`, `to_intake`, and `to_reprioritization`.
8. Emit `produced.feedback.production-signal-aggregation`.
9. Produce the metadata sidecar, run artifact, metadata, decision-tree, handoff, and release-consistency validators, then run the feedback-loop quality checklist before final output.

## Output language and evidence rules
- Follow the user's primary language.
- Preserve technical identifiers, incident ids, defect ids, API names, and metrics as-is.
- Evidence references should use the shared feedback-loop contract when possible.
- If the source is a pasted excerpt without line numbers, describe the source location clearly and mark confidence accordingly.

## Workflow v2 artifact contract
```yaml
artifact_type: feedback.production-signal-aggregation
schema_version: "1.4.0"
producer_skill: production-signal-aggregation
consumer_routes: [intake, reprioritization]
workflow_alias: 线上痛点信号包.json
produced_event_name: produced.feedback.production-signal-aggregation
canonical_fields:
  - signal_id
  - source_type
  - observed_problem
  - feature_area
  - time_window
  - frequency_score
  - impact_score
  - severity_score
  - confidence
  - priority_hint
  - evidence_refs
  - recommended_route
```

## Self-check / 节点内自检
Before delivery, confirm:
- all signal rows have ids, source type, confidence, evidence, and route
- no raw PII is exposed in user-feedback summaries
- high-volume low-impact signals are not over-ranked
- high-severity low-volume signals remain visible
- downstream handoff separates intake intake from reprioritization reprioritization

## Key references
- `references/shared-feedback-loop-contract.md`
- `references/output-template.md`
- `references/field-contract.yaml`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `scripts/validate_feedback_artifact.py`
- `references/metadata-schema.json`
- `references/feedback-id-space.md`
- `references/selected-mode-decision-tree.md`
- `references/anti-patterns.md`
- `examples/`
- `scripts/validate_metadata.py`
- `scripts/validate_feedback_handoff.py`
- `scripts/validate_skill_md.py`
- `scripts/validate_decision_tree.py`
- `scripts/validate_downstream_handoff.py`
- `scripts/validate_release_consistency.py`



## F-family integration cascade

To validate the full UFC → PSA → DDRM three-skill feedback-loop cascade:

```bash
python scripts/validate_feedback_handoff.py \\
    --ufc examples/integration/mixed-feedback-example.csv \\
    --psa examples/integration/feedback-pack-signal-example.json \\
    --ddrm examples/integration/customer-pain-mining-example.csv
```

See `examples/integration/README.md` for the coherent triplet.

## Examples / 回归样例
Use the bundled `examples/` files as executable regression cases. Run:
```bash
python scripts/validate_release_consistency.py .
```
This checks SKILL.md version drift, selected-mode decision tree alignment, all example artifacts, metadata sidecars, and local handoff guards. Differences from examples are allowed, but field names, id patterns, metadata shape, and route-token handoff semantics should stay compatible.
