# Real examples / 示例

## Example: recurring checkout error
```yaml
signal_id: SIG-runtime_error-001
source_type: runtime_error
source_node: runtime_source
observed_problem: checkout payment callback timeout increased after release
feature_area: payment_checkout
time_window: 2026-05-01/2026-05-07
count_or_rate: 431 errors / 7d
frequency_score: 4
impact_score: 4
severity_score: 3
confidence: high
evidence_refs:
  - "[frequent-error-summary]§top_errors.L12-L18"
recommended_route: reprioritization
```

## Example: feedback cluster linked to defect trend
```yaml
pain_point_id: PAIN-account-002
observed_problem: users cannot understand why account verification is rejected
merged_signal_ids: [SIG-user_feedback-008, SIG-defect-014]
priority_hint: 18
recommended_route: intake
validation_question: Is the rejection reason copy insufficient, or is the verification rule incorrect?
```
