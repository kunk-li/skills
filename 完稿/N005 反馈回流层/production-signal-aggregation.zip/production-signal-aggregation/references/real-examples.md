# Real examples / 示例

## Example: recurring checkout error
```yaml
signal_id: SIG-runtime_error-001
source_type: runtime_error
source_node: runtime_source
observed_problem: checkout payment callback timeout increased after release
feature_area: payment_checkout
time_window: 2026-05-01/2026-05-07
count_or_rate: 431 errors / 7d
frequency_score: 4
impact_score: 4
severity_score: 3
confidence: high
evidence_refs:
  - "[frequent-error-summary]§top_errors.L12-L18"
recommended_route: reprioritization
```

## Example: feedback cluster linked to defect trend
```yaml
pain_point_id: PAIN-account-002
observed_problem: users cannot understand why account verification is rejected
merged_signal_ids: [SIG-user_feedback-008, SIG-defect-014]
priority_hint: 18
recommended_route: intake
validation_question: Is the rejection reason copy insufficient, or is the verification rule incorrect?
```

---

## Example 4: JSON signal pack — enum and numeric field rules

**Critical rules for `feedback-pack` and `incident_signal_rollup` modes that produce JSON output**:

The `normalized_signal_registry` rows must follow the same enum constraints as CSV rows:

| field | rule | valid values / format |
| --- | --- | --- |
| `source_node` | must be in enum | `defect_source`, `runtime_source`, `postmortem_source`, `external`, `unknown` |
| `priority_hint` | must be numeric 0–5 | `0` = no priority, `5` = highest; use `3` for "intake-level" signals |
| `count_or_rate` | must be numeric or percentage | `21`, `0.18`, `"12%"`; put descriptive text in `notes` field instead |

**Anti-pattern (causes validator failure)**:
```json
{
  "source_node": "feedback_clustering",
  "priority_hint": "intake",
  "count_or_rate": "18 support tickets + 3 NPS detractor clusters"
}
```

**Correct pattern**:
```json
{
  "source_node": "external",
  "priority_hint": 3,
  "count_or_rate": 21,
  "notes": "18 support tickets + 3 NPS detractor clusters"
}
```

**Note**: `source_node: external` is the correct value for signals originating from user feedback channels (NPS, support tickets, app reviews). Use `runtime_source` only for signals from production monitoring systems.
