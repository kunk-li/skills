# production-signal-aggregation quality checklist

This skill inherits the 11 common feedback-loop checks from `references/shared-feedback-loop-contract.md#common-quality-checklist`. Do not duplicate the shared list here; keep this file skill-specific.

## Common checklist source
The common 11-point checklist lives only in `references/shared-feedback-loop-contract.md#common-quality-checklist`. This file intentionally contains only skill-specific checks to avoid divergence.

## Skill-specific checks
1. Separate source_type/source_node/source_artifact so defect_source/runtime_source/postmortem_source/external evidence remains auditable.
2. Deduplicate with dedupe_key before scoring and before assigning priority_hint.
3. Keep all score fields numeric 0..5 and never present priority_hint as roadmap priority.
4. Route high-priority low-confidence signals to human_review or emit warnings in strict checks.
5. When feedback_cluster_ids are present, validate them against UFC artifacts with validate_feedback_handoff.py.

## Release command
```bash
python scripts/validate_release_consistency.py .
```

## Optional composed handoff checks
```bash
python scripts/validate_feedback_handoff.py --ufc path/to/ufc_a.csv --ufc path/to/ufc_b.csv --psa path/to/psa.json --ddrm path/to/ddrm.csv --strict
python scripts/validate_downstream_handoff.py --ddrm path/to/ddrm.csv --strict
```
