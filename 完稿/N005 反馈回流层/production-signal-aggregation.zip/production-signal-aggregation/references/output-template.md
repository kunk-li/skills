# Output template / 线上痛点信号包输出模板

## Required pair
Produce `线上痛点信号包.json` plus `线上痛点信号包.metadata.yaml`.
Validate with:
```bash
python scripts/validate_feedback_artifact.py --strict 线上痛点信号包.json production-signal-aggregation
python scripts/validate_metadata.py 线上痛点信号包.metadata.yaml production-signal-aggregation
```

## 1. metadata
```yaml
workflow_node: <provided by host workflow>
skill: production-signal-aggregation
contract_version: feedback-loop-suite-v1.4.1
selected_mode: multi_source_aggregation | incident_signal_rollup | defect_trend_rollup | runtime_error_rollup | feedback_pack
readiness: ready | partial | evidence_limited | needs_human_review
artifact_id: PSA-SIGNAL-<scope>-<yyyymm>
artifact_target: 线上痛点信号包.json
source_coverage:
  runtime_error: present | missing | partial
  defect: present | missing | partial
  incident_postmortem: present | missing | partial
  user_feedback: present | missing | partial
```

## 2. normalized_signal_registry
| signal_id | source_type | source_node | source_artifact | observed_problem | feature_area | user_segment | time_window | count_or_rate | frequency_score | impact_score | severity_score | confidence | priority_hint | dedupe_key | related_incident_ids | related_defect_ids | feedback_cluster_ids | candidate_requirement_refs | evidence_refs | noise_reason | recommended_route |
|---|---|---|---|---|---|---|---|---:|---:|---:|---:|---|---:|---|---|---|---|---|---|---|---|

## 3. downstream_handoff
```yaml
to_requirement_mining:
  source_signal_ids: []
to_intake:
  candidate_raw_demands: []
to_reprioritization:
  urgent_signals: []
human_review_queue: []
```

## 4. produced_events
```yaml
- event_name: produced.feedback.production-signal-aggregation
  artifact: 线上痛点信号包.json
```
