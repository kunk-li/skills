---
name: data-driven-requirement-mining
description: mine evidence-backed requirement hypotheses from signal packages, feedback clusters, defects, incidents, nps, support data, and product analytics into 数据驱动需求建议.csv with anti-goals, validation questions, dedupe refs, confidence, and route hints. use when product teams need problem-first demand candidates; works standalone or with feedback clustering and signal aggregation. not for signal aggregation (use production-signal-aggregation), prd drafting, or final priority approval.
---
# data-driven-requirement-mining

## Feedback-loop metadata / 阶段元数据
- `skill_family`: `feedback-loop-suite`
- `host_workflow_node`: provided by the host workflow; this skill does not bind itself to a fixed node
- `skill_id`: `data-driven-requirement-mining`
- `stage_hint`: `feedback_loop.requirement_hypothesis_mining`
- `prerequisites`: none; the skill is single-skill usable and evidence-gated
- `composable_with`: `['user-feedback-clustering', 'production-signal-aggregation']`
- `consumes_when_available`: `['signal packages', 'feedback clusters', 'defect tables', 'runtime error summaries', 'incident postmortems', 'raw evidence summaries']`
- `route_hints`: `['intake', 'reprioritization', 'merge', 'monitor', 'human_review']`
- `artifact_target`: `数据驱动需求建议.csv`

## feedback-loop-suite v1.4.1 contract baseline
- `contract_version`: `feedback-loop-suite-v1.4.1`
- `artifact_family_id`: `feedback-loop-suite`
- `schema`: `feedback.data-driven-requirement-mining.v4`
- `metadata_sidecar`: required for final artifacts (`*.metadata.yaml`) with strict `additionalProperties: false`
- `artifact_id_namespace`: `DDRM-REQ-<scope>-<yyyymm>`
- `validation_scripts`: `validate_feedback_artifact.py`, `validate_metadata.py`, `validate_decision_tree.py`, `validate_feedback_handoff.py`, `validate_downstream_handoff.py`, `validate_release_consistency.py`
- `examples/`: contains executable examples, metadata sidecars, and upstream defect/runtime/postmortem samples for regression testing

## Role / 角色定位
Turn online pain-point signals into evidence-backed requirement hypotheses. The skill explains the user or business problem, why it matters now, what evidence supports it, what is still uncertain, and which host route is appropriate, such as intake, reprioritization, merge, monitor, or human review.

## Single-skill value / 单独使用价值
- Can mine requirement hypotheses directly from incidents, defects, feedback, or metric summaries.
- Produces CSV-friendly rows for backlog intake and planning review.
- Keeps solution suggestions optional and separates them from the problem statement.

## Multi-skill value / 组合使用价值
- Uses `线上痛点信号包.json` to avoid duplicate mining.
- Uses `用户反馈聚类表.csv` to preserve voice-of-customer themes.
- Emits intake-ready candidates and reprioritization signals without assuming a mandatory upstream skill order.

## Allowed inputs / 允许输入
- `线上痛点信号包.json`
- `用户反馈聚类表.csv`
- `缺陷分类表.csv`
- `高频报错摘要.md`
- `线上问题复盘.md`
- NPS, support-ticket summaries, VOC notes, product analytics summaries
- Existing backlog, roadmap, PRD, or requirement ids for deduplication only

## Prohibited inputs / 禁止输入
- Unverified solution mandates disguised as requirements.
- Roadmap commitments, release dates, or final priority decisions without human/product approval.
- Root-cause claims not supported by evidence.

## Modes
- `backlog_seed`: generate new intake candidate demands.
- `reprioritization`: update or reorder existing reprioritization candidates.
- `incident_prevention`: focus on recurrent incidents and prevention requirements.
- `customer_pain_mining`: focus on feedback and NPS themes.
- `mixed_signal_mining`: default when production, defect, and feedback signals are all present.

## Required output sections
1. `metadata`
2. `mining_scope`
3. `requirement_suggestions[]`
4. `dedupe_and_backlog_mapping`
5. `prioritization_evidence`
6. `validation_questions`
7. `human_decision_queue`
8. `downstream_handoff`
9. `produced_events`
10. `self_check`

## Required row contract
Each suggestion row should include:
- `suggestion_id` (use `DREQ-*`; see `references/feedback-id-space.md` for id format) (use `DREQ-*`; see `references/feedback-id-space.md` for id format)
- `hypothesis_title`
- `user_problem`
- `evidence_summary`
- `source_signal_ids[]`
- `source_artifact_refs[]`
- `affected_scope`
- `frequency_score`
- `impact_score`
- `severity_score`
- `business_value_score`
- `risk_reduction_score`
- `urgency_score`
- `confidence`
- `novelty_or_duplicate_status`
- `known_backlog_refs[]`
- `anti_goal`
- `candidate_solution_optional`
- `validation_question`
- `proposed_route`: `intake` or `reprioritization`
- `recommended_action`: `intake / reprioritize / merge / monitor / human_review`

## Rules
- `R01_problem_before_solution`: always state the problem before any candidate solution.
- `R02_evidence_traceability`: source signal ids and evidence refs are required.
- `R03_no_final_priority`: scores and priority hints do not equal final roadmap decisions.
- `R04_dedupe_existing_backlog`: check duplicate or related backlog refs when available.
- `R05_intake_vs_reprioritization_route`: new/unclear demand goes to intake; urgent reordering of known scope goes to reprioritization.
- `R06_validation_question_required`: every hypothesis needs a next validation question or decision.
- `R07_anti_goal_required`: state what this suggestion should not solve to prevent scope creep.
- `R08_low_confidence_review`: low-confidence or conflicting evidence goes to human review.
- `R09_machine_validation`: run artifact, metadata, and handoff validators when execution is available.

## Execution workflow
1. Load aggregated signals or normalize raw evidence using the feedback-loop shared contract.
2. Group signals into distinct user/business problems.
3. Remove duplicate suggestions by problem, segment, and feature area.
4. Map each suggestion to known backlog or PRD refs when available.
5. Score value, risk reduction, urgency, confidence, novelty, and actionability.
6. Decide whether the row is intake, reprioritization, merge, monitor, or human review.
7. Add validation questions and anti-goals.
8. Output `数据驱动需求建议.csv` and a compact handoff block.
9. Emit `produced.feedback.data-driven-requirement-mining`.
10. Produce the metadata sidecar, run artifact, metadata, decision-tree, handoff, and release-consistency validators, then run the feedback-loop quality checklist.

## Output language and evidence rules
- Follow the user's primary language.
- Keep ids, metrics, defect ids, incident ids, and product terms unchanged.
- Do not quote long user feedback; summarize and cite the source.
- Use confidence values from the shared contract.

## Workflow v2 artifact contract
```yaml
artifact_type: feedback.data-driven-requirement-mining
schema_version: "1.4.0"
producer_skill: data-driven-requirement-mining
consumer_routes: [intake, reprioritization]
workflow_alias: 数据驱动需求建议.csv
produced_event_name: produced.feedback.data-driven-requirement-mining
canonical_fields:
  - suggestion_id
  - hypothesis_title
  - user_problem
  - evidence_summary
  - source_signal_ids
  - business_value_score
  - urgency_score
  - risk_reduction_score
  - confidence
  - proposed_route
  - recommended_action
```

## Self-check / 节点内自检
Before delivery, confirm:
- every suggestion is backed by at least one source signal or evidence ref
- new requirements are routed to intake, known urgent scope changes to reprioritization
- assumptions, anti-goals, and validation questions are explicit
- final roadmap priority is not claimed
- duplicate backlog refs are surfaced instead of hidden

## Key references
- `references/shared-feedback-loop-contract.md`
- `references/output-template.md`
- `references/field-contract.yaml`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `scripts/validate_feedback_artifact.py`
- `references/metadata-schema.json`
- `references/feedback-id-space.md`
- `references/selected-mode-decision-tree.md`
- `references/anti-patterns.md`
- `examples/`
- `scripts/validate_metadata.py`
- `scripts/validate_feedback_handoff.py`
- `scripts/validate_skill_md.py`
- `scripts/validate_decision_tree.py`
- `scripts/validate_downstream_handoff.py`
- `scripts/validate_release_consistency.py`



## Examples / 回归样例
Use the bundled `examples/` files as executable regression cases. Run:
```bash
python scripts/validate_release_consistency.py .
```
This checks SKILL.md version drift, selected-mode decision tree alignment, all example artifacts, metadata sidecars, and local handoff guards. Differences from examples are allowed, but field names, id patterns, metadata shape, and route-token handoff semantics should stay compatible.
