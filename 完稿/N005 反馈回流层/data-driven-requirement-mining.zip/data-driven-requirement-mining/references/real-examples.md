# Real examples / 示例

## Example: route to intake
```yaml
suggestion_id: DREQ-checkout-001
hypothesis_title: Improve checkout failure explanation and retry path
user_problem: Users who encounter payment callback timeout do not know whether to retry or wait.
source_signal_ids: [SIG-runtime_error-001, SIG-user_feedback-012]
proposed_route: intake
recommended_action: intake
validation_question: Which retry and status-copy behavior reduces repeat support contacts?
anti_goal: Do not redesign the whole payment architecture in this requirement hypothesis.
confidence: medium
```

## Example: route to reprioritization
```yaml
suggestion_id: DREQ-account-004
hypothesis_title: Reprioritize verification rejection transparency in current account scope
source_signal_ids: [SIG-defect-014, SIG-user_feedback-008]
proposed_route: reprioritization
recommended_action: reprioritize
urgency_score: 5
risk_reduction_score: 4
confidence: high
```
