# Output template / 数据驱动需求建议输出模板

## Required pair
Produce `数据驱动需求建议.csv` plus `数据驱动需求建议.metadata.yaml`.
Validate with:
```bash
python scripts/validate_feedback_artifact.py --strict 数据驱动需求建议.csv data-driven-requirement-mining
python scripts/validate_metadata.py 数据驱动需求建议.metadata.yaml data-driven-requirement-mining
```

## 1. metadata
```yaml
workflow_node: <provided by host workflow>
skill: data-driven-requirement-mining
contract_version: feedback-loop-suite-v1.4.1
selected_mode: backlog_seed | reprioritization | incident_prevention | customer_pain_mining | mixed_signal_mining
readiness: ready | partial | evidence_limited | needs_human_review
artifact_id: DDRM-REQ-<scope>-<yyyymm>
artifact_target: 数据驱动需求建议.csv
```

## 2. requirement_suggestions
| suggestion_id | hypothesis_title | user_problem | evidence_summary | source_signal_ids | source_artifact_refs | affected_scope | frequency_score | impact_score | severity_score | business_value_score | risk_reduction_score | urgency_score | confidence | novelty_or_duplicate_status | known_backlog_refs | anti_goal | candidate_solution_optional | validation_question | proposed_route | recommended_action |
|---|---|---|---|---|---|---|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---|---|

## 3. downstream_handoff
```yaml
to_intake:
  rows: []
to_reprioritization:
  rows: []
human_review_queue: []
```

## 4. produced_events
```yaml
- event_name: produced.feedback.data-driven-requirement-mining
  artifact: 数据驱动需求建议.csv
```
