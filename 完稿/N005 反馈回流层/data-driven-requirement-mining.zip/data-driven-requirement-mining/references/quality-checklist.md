# data-driven-requirement-mining quality checklist

This skill inherits the 11 common feedback-loop checks from `references/shared-feedback-loop-contract.md#common-quality-checklist`. Do not duplicate the shared list here; keep this file skill-specific.

## Common checklist source
The common 11-point checklist lives only in `references/shared-feedback-loop-contract.md#common-quality-checklist`. This file intentionally contains only skill-specific checks to avoid divergence.

## Skill-specific checks
1. State the user/business problem before any candidate solution.
2. Every suggestion needs source_signal_ids, anti_goal, and validation_question.
3. Route novel or unclear candidates to intake; route known urgent scope changes to reprioritization.
4. Use recommended_action only from intake/reprioritize/merge/monitor/human_review.
5. Run validate_downstream_handoff.py before sending DDRM rows to intake or reprioritization.

## Release command
```bash
python scripts/validate_release_consistency.py .
```

## Optional composed handoff checks
```bash
python scripts/validate_feedback_handoff.py --ufc path/to/ufc_a.csv --ufc path/to/ufc_b.csv --psa path/to/psa.json --ddrm path/to/ddrm.csv --strict
python scripts/validate_downstream_handoff.py --ddrm path/to/ddrm.csv --strict
```
