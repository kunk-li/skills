# N170 v2 contract: audit-trail-design

审计设计：10 类强制审计、统一 audit_event schema、append-only 4-tier、保留期、查询权限、PII 处理。

## Metadata contract

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: audit-trail-design
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.audit_trail_design
  node_artifact_target: 审计留痕方案.md
  design_id_pattern: "AUDIT-\\d{3,}"
  produced_event: produced.n170.audit_design.v2
  blocker_mapping: B06
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Input schema with workflow sources

| field | required | from | purpose |
| --- | --- | --- | --- |
| `permissions` | required | N070/permission-matrix-extraction | audit_level and authorization events |
| `state_machines` | required | N070 | 状态迁移事件 |
| `data_flows` | required | N160/data-flow-mapping | 每个 write step |
| `tables` | required | N160 | append_only/regulated 表 |
| `compliance_requirements` | required | context | GDPR/PCI/HIPAA/SOC2/SOX/local |

## Required output schema

- `audit_design.design_id: AUDIT-\d{3,}`
- `mandatory_audit_categories.A01_authentication through A10_financial_transactions`
- `audit_event_schema.mandatory_fields: event_id, event_type, event_version, occurred_at, recorded_at, trace_id, actor, target, action, context`
- `sensitive_field_handling.pii_in_audit + pci_in_audit`
- `append_only_enforcement.tier_1_application_layer through tier_4_grant_revoke`
- `retention_policy.default_retention + by_compliance + archival_strategy + legal_hold`
- `access_control.roles + query_audit + pii_query_controls`
- `implementation_stack + compliance_alignment + derived_from`

## Hard gate rules

| rule | check | on violation |
| --- | --- | --- |
| `R01_all_10_categories_covered` | A01-A10 必须覆盖，A10 不适用时要说明 | `reject` |
| `R02_append_only_4_tier` | append-only 必须有应用层、AOP/拦截、DB trigger、DB 权限四层 | `reject` |
| `R03_mandatory_fields_complete` | audit_event mandatory fields 必须完整 | `reject` |
| `R04_retention_policy_explicit` | 必须明示保留期并与合规最低要求对齐 | `reject` |
| `R05_pii_in_audit_protected` | 审计中的 PII/PCI 必须掩码、hash 或加密 | `reject` |
| `R06_meta_audit_enabled` | 查询 audit 本身必须记录 audit.queried | `reject` |
| `R07_break_glass_requires_alert` | break-glass 或 emergency_admin 必须告警和复核 | `reject` |

## Algorithms and decision logic

- audit_event_derivation: every data_flow write/update/delete/publish_event -> audit event; every state transition with audit_required -> state_changed event; every authorization decision with deny/grant/delegation -> A02 event.
- retention_calculation: choose the strictest applicable retention; if legal_hold exists, legal_hold wins over TTL cleanup.
- sensitive_data_scrubbing: email mask, card masked PAN only, SSN/hash identifiers, never full secret or token.

## Field-level handoff

| link | fields produced/consumed | downstream use |
| --- | --- | --- |
| `from_052_authorization` | `roles, policies, delegation_model, break_glass` | A02_authorization events and audit_access_control |
| `to_054_security` | `append_only_enforcement, audit_event_schema, security_events` | tampering/repudiation mitigations |
| `to_N230_test` | `audit event TC and append-only violation TC` | 审计专项测试用例 |
| `to_N390_governance` | `query_audit and retention_policy` | 平台治理与模板质量 |

## Blocker and event output

```yaml
blocker_signal:
  blocker_id: B06
  source_skill: audit-trail-design
  rule_id: Rxx
  severity: reject | warn
  evidence: []
  recommended_owner: product | engineering | qa | security | compliance
event:
  produced: produced.n170.audit_design.v2
  schema_version: n170.v2.0.0
```

## Minimal worked example

```yaml
design_id: AUDIT-001
mandatory_audit_categories.A04_data_modification.events: [entity_created, entity_updated, entity_deleted]
audit_event_schema.mandatory_fields.event_type.convention: <domain>.<action>
append_only_enforcement.tier_3_db_trigger.enabled: true
access_control.query_audit.enabled: true
retention_policy.default_retention: 7years
derived_from.permission_refs: [PERM-ORDER-READ-ANY]
```

## Standalone behavior

When upstream evidence is missing, still produce a useful provisional artifact. Mark missing source fields as `pending`, inferred design as `inferred`, and hard-gate failures as `blocked` only when the missing evidence prevents a safe recommendation.