# Audit event schema catalog — audit-trail-design

## A01-A10 mandatory event schema templates

| Category | Event name | Mandatory fields | Example value |
|---|---|---|---|
| A01 Authentication | `auth.login.success` | actor_id, ip_address, mfa_used, session_id | `{actor_id: u-123, mfa: totp, session: s-abc}` |
| A01 Authentication | `auth.login.failed` | actor_id, ip_address, failure_reason, attempt_count | `{failure_reason: wrong_password, attempt: 3}` |
| A02 Authorization | `authz.access.denied` | actor_id, resource_type, resource_id, action, policy_id | `{resource: order/o-456, action: cancel, policy: POL-001}` |
| A02 Authorization | `authz.role.assigned` | actor_id, target_user_id, role_name, assigned_by | `{role: manager, assigned_by: admin-u-1}` |
| A03 Data access | `data.pii.accessed` | actor_id, resource_type, resource_id, fields_accessed | `{fields: [email, phone], order_id: o-456}` |
| A04 Data mutation | `data.record.created` | actor_id, resource_type, resource_id, diff_summary | `{resource: order, id: o-789, action: create}` |
| A04 Data mutation | `data.record.deleted` | actor_id, resource_type, resource_id, soft_or_hard | `{resource: draft, id: d-123, type: soft}` |
| A05 Administrative | `admin.config.changed` | actor_id, config_key, old_value_hash, new_value_hash | `{key: max_retry, old_hash: abc, new_hash: def}` |
| A06 Financial | `finance.payment.processed` | actor_id, amount, currency, payment_method_token, tx_id | `{amount: 99.99, currency: USD, tx: tx-789}` |
| A07 System | `system.job.executed` | job_id, job_type, triggered_by, outcome, duration_ms | `{job: nightly-cleanup, outcome: success, ms: 1200}` |
| A08 Integration | `integration.callback.received` | source_system, event_id, event_type, processing_result | `{source: stripe, event_id: evt_123, result: accepted}` |
| A09 Consent | `consent.given` | actor_id, consent_type, purpose, expiry | `{type: marketing_email, purpose: newsletters, expiry: 2027}` |
| A10 Export | `data.export.triggered` | actor_id, export_type, scope_filter, record_count | `{type: gdpr_sar, filter: {user_id: u-123}, count: 847}` |

## Append-only enforcement tier map

| Tier | Mechanism | Provides | When to use |
|---|---|---|---|
| T1 Application | Repository exposes `save()` only; no `update()`/`delete()` | Protects from application code | Always required |
| T2 AOP | Aspect rejects write mutations on audit entity | Protects from internal calls | Required when T1 alone insufficient |
| T3 DB trigger | `BEFORE UPDATE/DELETE` raises SQLSTATE 45000 | Protects from direct DB access | Required for compliance-sensitive audits |
| T4 DB grants | `GRANT INSERT SELECT` only; no UPDATE/DELETE/TRUNCATE | Protects from DB admin access | Required for SOX, HIPAA, PCI-DSS |

## Retention policy by regulation

| Regulation | Minimum retention | Data subject | Archive format |
|---|---|---|---|
| GDPR | 5 years (financial), 3 years (general) | EU persons | Encrypted, EU-resident storage |
| HIPAA | 6 years from creation or last use | US patients | Encrypted, HIPAA-compliant storage |
| PCI-DSS | 1 year online + 3 years archive | Cardholders | Encrypted, access-logged |
| SOX | 7 years (financial records) | US public companies | Tamper-evident, audit-committee access |
| PIPL | Duration of purpose + 3 years | Chinese persons | China-resident storage |
| Internal default | 12 months hot + 36 months warm + 7 years cold | All users | Parquet on object storage |
