# V2 orchestration for audit-trail-design

## Execution modes

- Standalone: produce this skill artifact only. Use `readiness: provisional` when upstream fields are missing.
- N170 batch: use `references/n170-integration-map.md` and keep IDs stable across all six artifacts.
- Gate mode: emit reject/warn results from `references/v2-contract.md` rules and map them to the blocker ID.

## Input normalization

Normalize incoming file names into typed N170 evidence:

| field | required | from | purpose |
| --- | --- | --- | --- |
| `permissions` | required | N070/permission-matrix-extraction | audit_level and authorization events |
| `state_machines` | required | N070 | 状态迁移事件 |
| `data_flows` | required | N160/data-flow-mapping | 每个 write step |
| `tables` | required | N160 | append_only/regulated 表 |
| `compliance_requirements` | required | context | GDPR/PCI/HIPAA/SOC2/SOX/local |

## Output event

```yaml
event:
  produced: produced.n170.audit_design.v2
  schema_version: n170.v2.0.0
  artifact: 审计留痕方案.md
  blocker_mapping: B06
```

## Field-level handoff for this skill

| link | fields | downstream use |
| --- | --- | --- |
| `from_052_authorization` | `roles, policies, delegation_model, break_glass` | A02_authorization events and audit_access_control |
| `to_054_security` | `append_only_enforcement, audit_event_schema, security_events` | tampering/repudiation mitigations |
| `to_N230_test` | `audit event TC and append-only violation TC` | 审计专项测试用例 |
| `to_N390_governance` | `query_audit and retention_policy` | 平台治理与模板质量 |
