# Compatibility map — audit-trail-design v2 alignment

## Input artifact field mapping
| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 052 authorization-model-design | `role assignment events, break_glass flows` | `A02 authorization events` | AUTHZ events define mandatory audit capture points |
| 046 table-schema-design-recommendation | `tables with pii_or_sensitive_fields` | `audit scope determination` | sensitive tables identify audit data access obligations |
| N070 016 permission-matrix-extraction | `PERM-* subject, action, effect` | `A02 actor + action mapping` | permission matrix defines who does what in audit events |

## Output artifact field mapping
| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 054 security-risk-analysis | `append_only_enforcement, audit_event_schema` | `T_tampering and R_repudiation mitigations` | audit controls inform security threat mitigations |
| N300 monitoring | `audit_event metrics, DLQ alerts` | `observability inputs` | audit event rates and DLQ depth become monitoring metrics |
| N390 governance | `retention_policy, query_audit patterns` | `platform governance` | retention rules feed data governance policies |

## v2 contract cross-reference
| v2 field | Purpose | Consumer |
|---|---|---|
| `produced_event` | Event bus trigger | N330, N340 |
| `blocker_mapping` | SLA queue key | N380 |
| `rule_results[]` | Gate pass/warn/reject | N380 |
| `route_back_to` | Return path on gap | Upstream skill |
