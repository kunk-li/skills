# Common failure modes for audit trail design

## F1: logging actions but not their targets
Symptom: the event names the actor but not the resource or record affected.
Fix: always define target identity and scope.

## F2: requiring before and after snapshots for everything
Symptom: the design stores huge snapshots even when a simple event fact would do.
Fix: reserve before and after capture for material state changes or investigations.

## F3: treating sensitive fields like ordinary strings
Symptom: passwords, secrets, tokens, or personal identifiers appear in raw form.
Fix: define masking, hashing, omission, or tokenization rules explicitly.

## F4: defining retention without investigator queries
Symptom: storage guidance exists but nobody can answer how auditors will search it.
Fix: pair retention decisions with concrete query patterns.

## F5: forgetting to audit audit access
Symptom: the system logs business actions but not access to sensitive audit history.
Fix: add meta-audit requirements when audit data itself is sensitive.

## V2.1 contract failure modes

## F6: incomplete mandatory category coverage
Symptom: the event catalog is free-form and misses A01-A10 coverage.
Fix: explicitly list all mandatory categories and mark A10 as required-if-applicable.

## F7: append-only control is single-layer
Symptom: the design relies only on application convention or only on DB trigger.
Fix: require all four tiers: application, AOP/aspect, DB trigger, grant/revoke.

## F8: weak security handoff
Symptom: 054 cannot consume audit events for tampering, repudiation, or security monitoring.
Fix: expose event types, append-only enforcement, sensitive-field handling, and meta-audit controls.

## F9: contract appendix drift
Symptom: the markdown narrative says one thing while `contract_appendix` exposes different IDs, rule results, or handoff fields.
Fix: reconcile narrative and appendix before finalizing; the appendix is what downstream automation consumes.

## F10: blocker without owner or remediation
Symptom: a warning or reject is emitted but no owner, evidence, or next action is named.
Fix: every `blocker_signals[]` item must include `recommended_owner`, evidence, and a remediation hint or pending evidence field.

## F11: treating an emitted audit event as a durable audit record
Symptom: the design fires an audit write asynchronously, best-effort, in an independent transaction, or fire-and-forget, so the business action can commit successfully while the audit write silently fails — e.g. rejected by a background pool, rolled back in its own transaction, dropped by a queue, or dead-lettered with no handler — and no one notices the record is missing.
Fix: for every mandatory audit action, declare how durably the audit write is coupled to the business commit. Either the audit write and the business commit succeed or fail together (e.g. same transaction, a deferred-dispatch outbox the commit owns, or a synchronous commit that depends on the audit write succeeding — examples, not an exhaustive set), or the design explicitly treats the audit write as decoupled. Whenever it is decoupled, specify a loss-detection plus reconciliation or replay mechanism. A decoupled audit write with no loss-detection and no reconciliation/replay is never acceptable — decoupling is permitted only when such a detection-plus-recovery mechanism is specified. Scope: this rule governs PRD-mandated audit/ledger writes; observability/monitoring telemetry (best-effort traces, fire-and-forget alerts) is not an audit-ledger face and lossy tolerance there can be by-design — before firing, apply Gate1 to confirm the PRD defines this write's durability relative to the business commit.
