# Example I/O: audit-trail-design v2.1

## ex-001 · order system audit design

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: audit-trail-design
  workflow_node: N170
  node_artifact_target: 审计留痕方案.md
  selected_mode: full_compliance
  readiness: ready
  design_id_pattern: "AUDIT-\\d{3,}"
  produced_event: produced.n170.audit_design.v2
  blocker_mapping: B06
  evidence_profile:
    confirmed: [PERM-ORDER-READ-ANY, SM-ORDER, FLOW-ORDER-CREATE]
    inferred: [SOX-like retention need]
    pending: [formal jurisdiction list]
audit_design:
  design_id: AUDIT-001
  mandatory_audit_categories:
    A01_authentication: {required: true, events: [login_success, login_failure, logout]}
    A02_authorization: {required: true, events: [permission_denied, role_assigned, break_glass_invoked]}
    A03_data_access_sensitive: {required: true, events: [pii_read, bulk_export]}
    A04_data_modification: {required: true, events: [entity_created, entity_updated, entity_deleted]}
    A05_state_transitions: {required: true, events: [state_changed, state_rollback]}
    A06_configuration_change: {required: true, events: [config_updated, permission_matrix_updated]}
    A07_security_events: {required: true, events: [rate_limit_hit, signature_mismatch]}
    A08_compliance_actions: {required: true, events: [data_export_requested, retention_policy_applied]}
    A09_system_operations: {required: true, events: [deployment, schema_migration]}
    A10_financial_transactions: {required_if_applicable: true, events: [payment_initiated, refund_issued]}
  audit_event_schema:
    mandatory_fields: [event_id, event_type, event_version, occurred_at, recorded_at, trace_id, actor, target, action, context]
    event_type_convention: <domain>.<action>
    sensitive_field_handling:
      pii_in_audit: record actor_id, mask email/phone unless encrypted exception exists
      pci_in_audit: masked PAN only
  append_only_enforcement:
    tier_1_application_layer: repository exposes save/find only
    tier_2_aop_aspect: '@AppendOnlyEnforced blocks update/delete'
    tier_3_db_trigger: BEFORE UPDATE/DELETE trigger rejects mutation
    tier_4_grant_revoke: app_user has SELECT/INSERT only
  retention_policy:
    default_retention: 7years
    archival_strategy:
      hot_tier: 1 year primary DB
      warm_tier: 1-3 years replica/archive DB
      cold_tier: >3 years object storage
  access_control:
    query_audit:
      enabled: true
      event_type: audit.queried
    pii_query_controls:
      bulk_query_throttle: require approval for >1000 rows
  derived_from:
    permission_refs: [PERM-ORDER-READ-ANY]
    state_machine_refs: [SM-ORDER]
    flow_refs: [FLOW-ORDER-CREATE]
    requirement_refs: [REQ-AUDIT-001]
rule_results:
  - {rule_id: R01_all_10_categories_covered, status: pass, evidence: [A01_authentication, A10_financial_transactions]}
  - {rule_id: R02_append_only_4_tier, status: pass, evidence: [tier_1_application_layer, tier_4_grant_revoke]}
  - {rule_id: R06_meta_audit_enabled, status: pass, evidence: [audit.queried]}
blocker_signals: []
contract_appendix:
  id_prefix: AUDIT
  produced_event: produced.n170.audit_design.v2
  downstream_handoff:
    to_054_security: [A07_security_events, append_only_enforcement]
    to_N230_test: [append_only_violation_tests, audit_event_schema_tests]
```

## ex-002 · audit query patterns and cold-tier archival

```yaml
audit_design:
  design_id: AUDIT-002

  access_control:
    query_audit:
      enabled: true
      event_type: audit.queried
      mandatory_fields: [actor_id, query_filter, result_count, trace_id]
      rate_limit: "bulk queries > 1000 rows require manager approval workflow"
      query_patterns:
        - pattern_id: QP-001
          name: "Single record lookup by actor"
          example_query: "SELECT * FROM audit_events WHERE actor_id = ? AND occurred_at > ?"
          index_hint: "idx_audit_actor_occurred — (actor_id, occurred_at)"
          expected_response_time: "< 100ms"
        - pattern_id: QP-002
          name: "Date range export for compliance"
          example_query: "SELECT * FROM audit_events WHERE occurred_at BETWEEN ? AND ?"
          index_hint: "idx_audit_occurred — (occurred_at); partition pruning if monthly partitions enabled"
          expected_response_time: "< 5s for 1-month window"
        - pattern_id: QP-003
          name: "Security incident investigation — all actions by an actor"
          example_query: "SELECT * FROM audit_events WHERE actor_id = ? ORDER BY occurred_at"
          requires_approval: true
          approval_workflow: "manager approval via break-glass process"

  retention_policy:
    hot_tier:
      storage: "primary MySQL 8 audit_events table"
      duration: "12 months"
      exit_condition: "older than 12 months → warm tier"
    warm_tier:
      storage: "read-only replica or dedicated archive DB"
      duration: "12–36 months"
      exit_condition: "older than 36 months → cold tier"
      query_access: "restricted to compliance team; requires ticket"
    cold_tier:
      storage: "AWS S3 Glacier or equivalent object storage"
      duration: "36 months → 7 years (regulatory minimum)"
      format: "Parquet files, partitioned by year/month"
      query_access: "restore request process; SLA 48h"
      deletion: "automatic after 7 years unless hold order active"
      integrity_check: "SHA-256 checksum stored alongside each Parquet file; verified quarterly"
    hold_order:
      supported: true
      trigger: "legal hold, ongoing investigation"
      effect: "suspend automatic deletion; flag records as hold_active=true"

  meta_audit:
    events:
      - audit.queried: "any read access to audit_events table, including by compliance tools"
      - audit.exported: "bulk export triggered"
      - audit.hold_placed: "legal hold applied to records"
      - audit.hold_released: "legal hold lifted; records eligible for retention policy again"
      - audit.tier_migrated: "records moved from hot → warm or warm → cold"
    storage: "separate meta_audit_events table; also append-only"
    access_restriction: "only security team and automated retention job can write"
```

## ex-003 · append-only enforcement failure — negative case

```yaml
# Negative case: what happens when append-only is violated
append_only_failure_scenario:
  scenario: "Developer accidentally adds UPDATE endpoint to audit_events table"
  attack_vector: "Internal actor (or attacker with DB access) updates audit record to hide unauthorized action"
  detection_gap: "If only application-layer protection exists, direct DB access bypasses it"

  violation_example:
    sql: "UPDATE audit_events SET action = 'view' WHERE action = 'delete' AND actor_id = 42"
    effect: "Audit log falsified; compliance violation; legal liability"

  correct_4tier_enforcement:
    tier_1_application:
      status: implemented
      mechanism: "Repository exposes save() and find() only — no update() or delete() methods"
    tier_2_aop:
      status: implemented
      mechanism: "@AppendOnlyEnforced annotation on AuditEventRepository; AOP aspect blocks write mutations"
    tier_3_db_trigger:
      status: implemented
      mechanism: |
        CREATE TRIGGER prevent_audit_update
        BEFORE UPDATE ON audit_events
        FOR EACH ROW
        BEGIN
          SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Audit records are immutable';
        END;
    tier_4_grants:
      status: implemented
      mechanism: "app_user has SELECT, INSERT on audit_events — no UPDATE, DELETE, TRUNCATE"

  negative_case:
    tier_missing: tier_3_db_trigger
    consequence: "DB admin can bypass application and AOP layer via direct SQL client"
    recommendation: "All 4 tiers required; missing any tier is a reject-level violation of R02"
```

## ex-003 · degraded — no permission matrix; audit scope inferred from domain

```yaml
skill_name: audit-trail-design
readiness: provisional
selected_mode: schema_bootstrap
evidence_profile:
  confirmed: [TSA-001 architecture, TBL-TICKET-001 schema]
  inferred: [A01-A10 scope derived from domain description]
  pending: [권限矩阵.csv, DPO PII classification, retention period from legal]

degraded_reason: "No 권限矩阵.csv from N070-016 — actor permissions inferred from architecture description"
degraded_impact: "A02 authorization events are incomplete; actor granularity unconfirmed"

mandatory_categories:
  - category_id: A01
    required: true
    confidence: confirmed
    evidence: "Login/logout explicitly required by ER-009"
  - category_id: A02
    required: true
    confidence: inferred
    note: "Permission matrix not yet available — role assignment events assumed from domain"
    pending_evidence: "권限矩阵.csv from N070-016"
  - category_id: A06
    required: false
    confidence: inferred
    note: "No financial transactions in current scope — confirm if future scope includes billing"

pending_confirmations:
  - "권限矩阵.csv to confirm A02 actor-action scope"
  - "Legal sign-off on retention period (GDPR 5 years vs internal 3 years)"
  - "DPO classification of PII fields in audit events"
```

## ex-004 · blocked — permission matrix absent, A02 scope undefined

```yaml
skill_name: audit-trail-design
readiness: blocked
blocker_mapping: B-N170-05
route_back_to: n070-permission-matrix-extraction

blockers:
  - blocker_id: BLK-AUDIT-001
    type: missing_permission_matrix
    description: "A02 (authorization events) requires knowing which roles exist, which resources they access, and which actions are sensitive enough to audit. None of this is defined without 권限矩阵.csv."
    impact: "A02 is the second-most important audit category — skipping it is a compliance risk for GDPR, SOX, and HIPAA"
    resolution_required: "N070-016 permission-matrix-extraction must complete"
    unblock_evidence: "권限矩阵.csv with subject types, resource types, and sensitivity levels"

  - blocker_id: BLK-AUDIT-002
    type: missing_regulated_fields
    description: "PII and regulated field classification not provided — cannot determine A03 (data access on sensitive fields) scope"
    impact: "A03 is mandatory for GDPR compliance — cannot be designed without knowing which fields are PII"
    resolution_required: "DPO or 046 sensitivity classification must identify regulated fields"
    unblock_evidence: "PII field list from 046 sensitivity-contract.md OR DPO field inventory"

confirmed_categories:
  - A01_authentication: {required: true, confidence: confirmed}
  - A04_data_mutation: {required: true, confidence: inferred}
  - A05_administrative: {required: true, confidence: inferred}
blocked_categories:
  - A02_authorization: {blocked_by: BLK-AUDIT-001}
  - A03_data_access_sensitive: {blocked_by: BLK-AUDIT-002}
```
