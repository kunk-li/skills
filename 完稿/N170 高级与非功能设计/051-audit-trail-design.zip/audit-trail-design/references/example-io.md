# Example I/O: audit-trail-design v2.1

## ex-001 · order system audit design

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: audit-trail-design
  workflow_node: N170
  node_artifact_target: 审计留痕方案.md
  selected_mode: full_compliance
  readiness: ready
  design_id_pattern: "AUDIT-\\d{3,}"
  produced_event: produced.n170.audit_design.v2
  blocker_mapping: B06
  evidence_profile:
    confirmed: [PERM-ORDER-READ-ANY, SM-ORDER, FLOW-ORDER-CREATE]
    inferred: [SOX-like retention need]
    pending: [formal jurisdiction list]
audit_design:
  design_id: AUDIT-001
  mandatory_audit_categories:
    A01_authentication: {required: true, events: [login_success, login_failure, logout]}
    A02_authorization: {required: true, events: [permission_denied, role_assigned, break_glass_invoked]}
    A03_data_access_sensitive: {required: true, events: [pii_read, bulk_export]}
    A04_data_modification: {required: true, events: [entity_created, entity_updated, entity_deleted]}
    A05_state_transitions: {required: true, events: [state_changed, state_rollback]}
    A06_configuration_change: {required: true, events: [config_updated, permission_matrix_updated]}
    A07_security_events: {required: true, events: [rate_limit_hit, signature_mismatch]}
    A08_compliance_actions: {required: true, events: [data_export_requested, retention_policy_applied]}
    A09_system_operations: {required: true, events: [deployment, schema_migration]}
    A10_financial_transactions: {required_if_applicable: true, events: [payment_initiated, refund_issued]}
  audit_event_schema:
    mandatory_fields: [event_id, event_type, event_version, occurred_at, recorded_at, trace_id, actor, target, action, context]
    event_type_convention: <domain>.<action>
    sensitive_field_handling:
      pii_in_audit: record actor_id, mask email/phone unless encrypted exception exists
      pci_in_audit: masked PAN only
  append_only_enforcement:
    tier_1_application_layer: repository exposes save/find only
    tier_2_aop_aspect: '@AppendOnlyEnforced blocks update/delete'
    tier_3_db_trigger: BEFORE UPDATE/DELETE trigger rejects mutation
    tier_4_grant_revoke: app_user has SELECT/INSERT only
  retention_policy:
    default_retention: 7years
    archival_strategy:
      hot_tier: 1 year primary DB
      warm_tier: 1-3 years replica/archive DB
      cold_tier: >3 years object storage
  access_control:
    query_audit:
      enabled: true
      event_type: audit.queried
    pii_query_controls:
      bulk_query_throttle: require approval for >1000 rows
  derived_from:
    permission_refs: [PERM-ORDER-READ-ANY]
    state_machine_refs: [SM-ORDER]
    flow_refs: [FLOW-ORDER-CREATE]
    requirement_refs: [REQ-AUDIT-001]
rule_results:
  - {rule_id: R01_all_10_categories_covered, status: pass, evidence: [A01_authentication, A10_financial_transactions]}
  - {rule_id: R02_append_only_4_tier, status: pass, evidence: [tier_1_application_layer, tier_4_grant_revoke]}
  - {rule_id: R06_meta_audit_enabled, status: pass, evidence: [audit.queried]}
blocker_signals: []
contract_appendix:
  id_prefix: AUDIT
  produced_event: produced.n170.audit_design.v2
  downstream_handoff:
    to_054_security: [A07_security_events, append_only_enforcement]
    to_N230_test: [append_only_violation_tests, audit_event_schema_tests]
```
