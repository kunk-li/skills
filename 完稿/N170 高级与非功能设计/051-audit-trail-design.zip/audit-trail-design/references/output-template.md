# Output template: audit-trail-design v2

Start every answer with the following metadata block when producing a deliverable.

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: audit-trail-design
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.audit_trail_design
  node_artifact_target: 审计留痕方案.md
  design_id_pattern: "AUDIT-\d{3,}"
  produced_event: produced.n170.audit_design.v2
  blocker_mapping: B06
  selected_mode: <mode>
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Required sections

- `audit_design.design_id: AUDIT-\d{3,}`
- `mandatory_audit_categories.A01_authentication through A10_financial_transactions`
- `audit_event_schema.mandatory_fields: event_id, event_type, event_version, occurred_at, recorded_at, trace_id, actor, target, action, context`
- `sensitive_field_handling.pii_in_audit + pci_in_audit`
- `append_only_enforcement.tier_1_application_layer through tier_4_grant_revoke`
- `retention_policy.default_retention + by_compliance + archival_strategy + legal_hold`
- `access_control.roles + query_audit + pii_query_controls`
- `implementation_stack + compliance_alignment + derived_from`

## Machine-readable appendix

At the end of the markdown report, include a compact YAML appendix containing stable IDs, rule results, blocker signals, and downstream handoff.

```yaml
contract_appendix:
  id_prefix: AUDIT
  produced_event: produced.n170.audit_design.v2
  blocker_mapping: B06
  rule_results:
    - rule_id: R01
      status: pass | warn | reject | not_applicable
      evidence: []
  downstream_handoff: []
```
