# V2 hard-gate checklist for audit-trail-design

Use this checklist before finalizing any N170 output. Treat `reject` failures as blocking unless the output is explicitly marked `readiness: blocked` with pending evidence.

## Required metadata

- [ ] `artifact_schema_version: n170.v2.0.0` is present.
- [ ] Design IDs follow `AUDIT-###`.
- [ ] `produced_event: produced.n170.audit_design.v2` is present.
- [ ] `blocker_mapping: B06` is present.
- [ ] `confirmed / inferred / pending` evidence buckets are populated.

## Hard rules

- [ ] `R01_all_10_categories_covered` (reject): A01-A10 必须覆盖，A10 不适用时要说明
- [ ] `R02_append_only_4_tier` (reject): append-only 必须有应用层、AOP/拦截、DB trigger、DB 权限四层
- [ ] `R03_mandatory_fields_complete` (reject): audit_event mandatory fields 必须完整
- [ ] `R04_retention_policy_explicit` (reject): 必须明示保留期并与合规最低要求对齐
- [ ] `R05_pii_in_audit_protected` (reject): 审计中的 PII/PCI 必须掩码、hash 或加密
- [ ] `R06_meta_audit_enabled` (reject): 查询 audit 本身必须记录 audit.queried
- [ ] `R07_break_glass_requires_alert` (reject): break-glass 或 emergency_admin 必须告警和复核
- [ ] `R08_audit_write_durability` (reject): 每个强制审计动作声明审计写相对业务提交的持久性耦合（同事务/独立事务/依赖审计写的同步提交等，列举非穷尽），要么同成败要么明确解耦；解耦时必须有丢失检测 + 对账或重放，禁止业务提交成功而审计静默丢失且无检测

## Cross-skill handoff

- [ ] `from_052_authorization` handoff is explicit: `roles, policies, delegation_model, break_glass` -> A02_authorization events and audit_access_control
- [ ] `to_054_security` handoff is explicit: `append_only_enforcement, audit_event_schema, security_events` -> tampering/repudiation mitigations
- [ ] `to_N230_test` handoff is explicit: `audit event TC and append-only violation TC` -> 审计专项测试用例
- [ ] `to_N390_governance` handoff is explicit: `query_audit and retention_policy` -> 平台治理与模板质量

- [ ] `R_ARCH_DECISION_COMMITTED` (reject): 本 skill 拥有的**架构决策**（审计写入策略(同事务 / outbox+对账·哈希由DB触发器算·投递可靠性)）必须按**四步**拍定,绝不留 `pending`/`UNDETERMINED`/`BLOCKED-for-undefined`/空:① 先查决策是否已存在(PRD/ADR/上游设计);② 查是否被订正(版本叠层:旧值被 ADR 废止但 PRD 留原文);③ **有决策→遵循【现行(最新)】那个**(不照旧原文、不留空、不另套默认);④ 真无来源→用本 skill 工程默认(审计必达用 outbox-in-transaction+异步投递+对账,写失败不静默丢),标 `made_by=design_default`+rationale。把架构决策留空是缺陷——它是本 skill 职责,不是可 defer 给 PRD/下游的缺口;留空会被 026 误升 not_executable、把下游实现推成 stub(A1 核心 0/41 可跑之根)。仅真正的**产品输入**(风险偏好/业务阈值/外部基建供给)可留 `needs_decision`。
