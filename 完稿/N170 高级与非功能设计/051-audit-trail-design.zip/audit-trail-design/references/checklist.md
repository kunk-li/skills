# V2 hard-gate checklist for audit-trail-design

Use this checklist before finalizing any N170 output. Treat `reject` failures as blocking unless the output is explicitly marked `readiness: blocked` with pending evidence.

## Required metadata

- [ ] `artifact_schema_version: n170.v2.0.0` is present.
- [ ] Design IDs follow `AUDIT-###`.
- [ ] `produced_event: produced.n170.audit_design.v2` is present.
- [ ] `blocker_mapping: B06` is present.
- [ ] `confirmed / inferred / pending` evidence buckets are populated.

## Hard rules

- [ ] `R01_all_10_categories_covered` (reject): A01-A10 必须覆盖，A10 不适用时要说明
- [ ] `R02_append_only_4_tier` (reject): append-only 必须有应用层、AOP/拦截、DB trigger、DB 权限四层
- [ ] `R03_mandatory_fields_complete` (reject): audit_event mandatory fields 必须完整
- [ ] `R04_retention_policy_explicit` (reject): 必须明示保留期并与合规最低要求对齐
- [ ] `R05_pii_in_audit_protected` (reject): 审计中的 PII/PCI 必须掩码、hash 或加密
- [ ] `R06_meta_audit_enabled` (reject): 查询 audit 本身必须记录 audit.queried
- [ ] `R07_break_glass_requires_alert` (reject): break-glass 或 emergency_admin 必须告警和复核

## Cross-skill handoff

- [ ] `from_052_authorization` handoff is explicit: `roles, policies, delegation_model, break_glass` -> A02_authorization events and audit_access_control
- [ ] `to_054_security` handoff is explicit: `append_only_enforcement, audit_event_schema, security_events` -> tampering/repudiation mitigations
- [ ] `to_N230_test` handoff is explicit: `audit event TC and append-only violation TC` -> 审计专项测试用例
- [ ] `to_N390_governance` handoff is explicit: `query_audit and retention_policy` -> 平台治理与模板质量
