---
name: audit-trail-design
description: design audit trail requirements from technical solution notes, vulnerability findings, schema drafts, permission constraints, data classification, and compliance context. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 审计留痕方案.md for n170 before task planning, implementation, special testing, or governance review.
---
# audit-trail-design

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 审计留痕方案」。

它是 **direct_result** 型技能：目标是把审计事件、append-only 保障、查询模式、访问控制与保留策略落成可交付的 **`审计留痕方案.md`**，而不是只写“关键操作要审计”。

### Boundary / 边界
- 负责定义审计事件 schema、事件目录、留痕范围、append-only 技术保障、访问控制与 retention。
- 负责把合规和事故追溯需求转成可查询、可治理的审计模型。
- 不替代安全威胁建模，但要为安全和合规提供审计控制证据。
- 不替代性能容量分析，但要暴露审计写入和查询带来的性能压力。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- `artifact_schema_version: n170.v2.0.0`
- stable ID following `AUDIT-###`
- `produced_event: produced.n170.audit_design.v2`
- `blocker_mapping: B06`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `schema_bootstrap`：从零开始设计统一审计 schema 与事件目录；默认模式。
- `gap_analysis`：审查现有系统哪些敏感操作缺少审计。
- `retention_planning`：重点输出保留、冷热分层与归档策略。

## Primary inputs / 主要输入
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `permissions(N070), state_machines(N070), data_flows(N160), tables(N160), compliance_requirements`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule / 独立使用规则
即使只有技术方案、schema 草案与敏感操作描述，也可以单独使用。

降级规则：
- 若没有现有事件目录，可先生成 provisional audit event catalog。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的事件、字段、访问控制与 retention。
- 不得用“会记录日志”代替真正的审计设计。

## Core output contract / 核心输出契约
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `审计留痕方案.md`
- primary output object: `audit_design`
- stable ID: `AUDIT-###`
- event: `produced.n170.audit_design.v2`
- blocker: `B06`
- stage: `technical_solution_design.advanced_design.audit_trail_design`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules / 设计规则
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: A01-A10 强制审计类别、统一 audit_event schema、append-only 4-tier、retention、PII 保护和 meta-audit.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R07 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B06` blocker signal.

## Execution workflow / 执行流程
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `audit_design`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_054_security, to_052_authorization, to_N190_service_draft, to_N230_test, to_N260_gate`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness / 动态完整度
- 单一流程：覆盖全部关键动作与追责路径
- 中型系统：覆盖全部高敏对象与主要 actor / target 查询路径
- 大型平台：聚焦核心合规域、导出风险、冷热分层与长期保留策略

## Quality bar / 质量门槛
合格结果应能让实现、合规和专项测试团队明确知道“记什么、怎么防篡改、谁能查、保留多久”。

## Reference files / 参考文件
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
