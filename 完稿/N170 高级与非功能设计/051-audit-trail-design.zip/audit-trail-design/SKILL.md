---
name: audit-trail-design
description: design audit trails covering a01-a10 categories, event schemas, append-only enforcement, and retention. triggers on 权限矩阵.csv.
---
# audit-trail-design

## A01-A10 mandatory audit category quick-reference
| ID | Category | Must capture | Example events |
|---|---|---|---|
| A01 | Authentication | all login/logout/token events | login_success, mfa_challenge, token_refresh |
| A02 | Authorization | access denials and privilege changes | permission_denied, role_assigned, sudo_used |
| A03 | Data access on sensitive fields | reads of PII/regulated data | customer_record_viewed, ssn_accessed |
| A04 | Data mutation | creates/updates/deletes on regulated objects | order_created, user_profile_updated |
| A05 | Administrative actions | config changes, user management | feature_flag_changed, user_suspended |
| A06 | Financial transactions | all money movements | payment_processed, refund_issued |
| A07 | System events | critical infra/system state changes | service_restart, deploy_completed |
| A08 | Integration/API calls | external system interactions | third_party_api_called, webhook_sent |
| A09 | Policy and compliance events | approval workflows, sign-offs | contract_approved, gdpr_consent_given |
| A10 | Security incidents | anomalies, alerts, breaches | brute_force_detected, ip_blocked |

## append-only 4-tier enforcement
| Tier | Method | When to use |
|---|---|---|
| T1: App-level | no DELETE/UPDATE exposed via API | baseline, always required |
| T2: DB-level | no UPDATE/DELETE grants on audit table | standard for all production |
| T3: Immutable storage | write-once object storage (S3 Object Lock) | compliance, regulated industries |
| T4: Cryptographic chaining | hash chain or blockchain anchor | highest assurance, forensic-grade |

## Retention quick-reference
| Data sensitivity | Minimum retention | Typical regulation |
|---|---|---|
| PII / financial | 5–7 years | GDPR, PCI-DSS, SOX |
| Authentication events | 1–3 years | SOC2, ISO27001 |
| System/infrastructure | 90 days–1 year | operational SLA |
| Security incidents | 7 years+ | HIPAA, financial regulation |


## Trigger conditions
Design audit trails when any of the following are present:
- `权限矩阵.csv` from N070 permission-matrix-extraction
- N130 technical solution with sensitive operations
- N160 schema drafts identifying regulated tables
- compliance requirements or explicit audit design requests

## Standalone rule
Use `selected_mode: schema_bootstrap` when building from scratch. A01-A10 must all be assessed even when most are `required: false`. Without upstream permissions, infer audit subjects from domain objects and actions.

## Role and boundary
本 skill 对齐 skills_workflow 中in the technical-solution-design -> 高级设计 -> 审计留痕方案」. It is a **direct_result** skill: the goal is to produce a concrete 审计事件、append-only 保障、查询模式、访问控制与保留策略落成可交付的 **`审计留痕方案.md`**，而不是只写“关键操作要审计”。

### Boundary
- 负责定义审计事件 schema、事件目录、留痕范围、append-only 技术保障、访问控制与 retention。
- 负责把合规和事故追溯需求转成可查询、可治理的审计模型。
- 不替代安全威胁建模，但要为安全和合规提供审计控制证据。
- 不替代性能容量分析，但要暴露审计写入和查询带来的性能压力。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- stable ID following `AUDIT-###`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `schema_bootstrap`：从零开始设计统一审计 schema 与事件目录；默认模式。
- `gap_analysis`：审查现有系统哪些敏感操作缺少审计。
- `retention_planning`：重点输出保留、冷热分层与归档策略。

## Primary inputs
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `permissions(N070), state_machines(N070), data_flows(N160), tables(N160), compliance_requirements`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule
即使只有技术方案、schema 草案与敏感操作描述，也可以单独使用。

降级规则：
- 若没有现有事件目录，可先生成 provisional audit event catalog。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的事件、字段、访问控制与 retention。
- 不得用“会记录日志”代替真正的审计设计。

## Core output contract
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `审计留痕方案.md`
- primary output object: `audit_design`
- stable ID: `AUDIT-###`
- event: `produced.n170.audit_design.v2`
- blocker: `B06`
- stage: `technical_solution_design.advanced_design.audit_trail_design`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: A01-A10 强制审计类别、统一 audit_event schema、append-only 4-tier、retention、PII 保护、meta-audit 和 audit-write durability（审计写相对业务提交的持久性耦合，emitted-event≠durable-record）.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R08 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B06` blocker signal.

## Execution workflow
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `audit_design`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_054_security, to_052_authorization, to_N190_service_draft, to_N230_test, to_N260_gate`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness
- 单一流程：覆盖全部关键动作与追责路径
- 中型系统：覆盖全部高敏对象与主要 actor / target 查询路径
- 大型平台：聚焦核心合规域、导出风险、冷热分层与长期保留策略

## Quality bar
合格结果应能让实现、合规和专项测试团队明确知道“记什么、怎么防篡改、谁能查、保留多久”。

## Reference files
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`

## v2 additions: N005 feedback signal and N070 upstream linkage

```yaml
feedback_signal_to_n005:
  signal_type: none | audit_gap_signal | compliance_incident_pattern
  summary: ""
  target_n070_skills:
  - 016-permission-matrix-extraction
  - 017-data-object-identification
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
```

### Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| 权限矩阵.csv (016) | perm_id, subject, action, compliance_flag, audit_level | mandatory_audit_categories.A02_authorization |
| 状态转移图.md (015) | SM-* transitions with audit_required side_effects | audit event catalog seeds |
| 数据对象目录.md (017) | constraint_tags: audit_required, pii, regulated | audit scope, retention policy |
| 业务规则清单.md (014) | rule_semantic: compliance, hardness=constraint | compliance-triggered audit events |

## v2 SKILL.md contract — inline rule_results (authoritative for N380 scanning)

Full rule definitions are in `references/v2-contract.md`.
This block exposes rule IDs and severity levels so N380 can aggregate without reading the reference file.

```yaml
artifact_schema_version: n170.v2.0.0
skill_name: audit-trail-design
produced_event: produced.n170.audit_design.v2
blocker_mapping: B06
rule_results:
  - rule_id: R01_all_10_categories_covered
    severity: reject
    check: "A01-A10 必须覆盖，A10 不适用时说明"
    result: pass | warn | reject | not_applicable
  - rule_id: R02_append_only_4_tier
    severity: reject
    check: "append-only 四层：应用层、AOP拦截、DB trigger、DB权限"
    result: pass | warn | reject | not_applicable
  - rule_id: R03_mandatory_fields_complete
    severity: reject
    check: "audit_event mandatory fields 必须完整"
    result: pass | warn | reject | not_applicable
  - rule_id: R04_retention_policy_explicit
    severity: reject
    check: "必须明示保留期并与合规最低要求对齐"
    result: pass | warn | reject | not_applicable
  - rule_id: R05_pii_in_audit_protected
    severity: reject
    check: "审计中的 PII/PCI 必须掩码、hash 或加密"
    result: pass | warn | reject | not_applicable
  - rule_id: R06_meta_audit_enabled
    severity: reject
    check: "查询 audit 本身必须记录 audit.queried"
    result: pass | warn | reject | not_applicable
  - rule_id: R07_break_glass_requires_alert
    severity: reject
    check: "break-glass 或 emergency_admin 必须告警和复核"
    result: pass | warn | reject | not_applicable
  - rule_id: R08_audit_write_durability
    severity: reject
    check: "每个强制审计动作声明审计写相对业务提交的持久性耦合（同事务/独立事务/依赖审计写的同步提交等，列举非穷尽）；解耦时必须有丢失检测 + 对账或重放，禁止业务提交成功而审计静默丢失且无检测"
    result: pass | warn | reject | not_applicable

route_back_to: none | n160 | n052
# none   — output complete; N180/N210/N260 may proceed
# n160   — data-model assumption fundamentally wrong; revise before task planning
# n130   — architectural choice incompatible with non-functional finding; escalate

eventbus_subscribers: [N330, N340]
# N330 → 技术与运维文档自动生成
# N340 → 协作知识沉淀
```
