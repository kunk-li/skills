---
name: concurrency-control-recommendation
description: design concurrency control strategies from technical solution notes, vulnerability findings, schema drafts, permission constraints, api contracts, data-flow evidence, or upstream nonfunctional analysis. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 并发控制建议.md for n170 before task planning, static review, special testing, or governance review.
---
# concurrency-control-recommendation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 并发控制建议」。

它是 **direct_result** 型技能：目标是把竞争、锁、隔离级别、顺序约束和 must-test 场景落成可交付的 **`并发控制建议.md`**，而不是只给几个泛化建议。

### Boundary / 边界
- 负责识别竞争热点、竞态场景、锁策略、序列化策略与事务保护方式。
- 负责比较乐观锁、悲观锁、队列化、版本控制、状态机守卫、分布式锁等方案。
- 不负责重放幂等语义本身；该职责交给 `idempotency-design-recommendation`。
- 不负责安全威胁建模、审计保留或性能容量建模，但要为这些技能提供并发假设与 blocker 信号。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- `artifact_schema_version: n170.v2.0.0`
- stable ID following `CON-###`
- `produced_event: produced.n170.concurrency_design.v2`
- `blocker_mapping: B01`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `scenario_checklist`：快速识别业务场景会命中哪些竞态类型；默认模式。
- `tech_pick`：在候选实现方案之间做技术选型与 trade-off。
- `workflow_hardening`：围绕关键流程输出完整的锁、隔离、顺序与失败恢复策略。

## Primary inputs / 主要输入
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `engineering_requirements(N120), data_flows/tables(N160), state_machines/business_rules(N070), api_specs(N150)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule / 独立使用规则
即使只有技术方案与业务描述，也可以单独使用。

降级规则：
- 若缺少明确流程或对象模型，可先输出 provisional race map。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的对象、操作、竞争关系。
- 没有真实吞吐或冲突率时，不得伪装成精确锁等待或性能结论。

## Core output contract / 核心输出契约
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `并发控制建议.md`
- primary output object: `concurrency_designs[]`
- stable ID: `CON-###`
- event: `produced.n170.concurrency_design.v2`
- blocker: `B01`
- stage: `technical_solution_design.advanced_design.concurrency_control`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules / 设计规则
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: S01-S12 场景分类、isolation + lock 组合、锁决策树、lease/fencing、死锁分析和 TC-CON 测试派生.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R07 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B01` blocker signal.

## Execution workflow / 执行流程
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `concurrency_designs[]`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_050_idempotency, to_053_performance, to_N210_code_review, to_N260_concurrency_test`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness / 动态完整度
- 单个 API / 单条流程：覆盖全部共享对象与状态迁移
- 中型业务流：覆盖全部高风险热点与关键交叉路径
- 大型系统：聚焦核心竞争域、热点流程、外部回调与批处理交汇点

## Quality bar / 质量门槛
合格结果应能直接指导实现、测试与专项门禁，而不需要再次解释“为什么这里会冲突”。

## Reference files / 参考文件
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
