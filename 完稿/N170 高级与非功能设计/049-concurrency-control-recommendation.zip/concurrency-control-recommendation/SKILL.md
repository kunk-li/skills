---
name: concurrency-control-recommendation
description: design concurrency control covering 12 scenario types, isolation levels, lock strategies, and deadlock analysis. triggers on 技术方案分析.md.
---
# concurrency-control-recommendation

## Lock strategy quick-reference
| Strategy | When to use | Caution |
|---|---|---|
| Optimistic lock (version field) | low conflict rate, short transactions | must handle conflict retry at app layer |
| Pessimistic lock (`SELECT ... FOR UPDATE`) | high conflict, critical sections | deadlock risk; always acquire in consistent order |
| Distributed lock (Redis / ZooKeeper) | cross-service coordination | lease TTL + fencing token required |
| Queue serialization | ordered processing per entity | throughput limited by consumer count |
| State machine guard | prevent invalid transitions | must be enforced at DB + app layer |
| MVCC (DB isolation) | read-heavy, snapshot consistency | does not prevent write conflicts |

## S01-S12 concurrency scenario quick-reference
| ID | Scenario | Primary control |
|---|---|---|
| S01 | inventory deduction | optimistic lock or queue |
| S02 | order status transition | state machine guard |
| S03 | balance debit/credit | pessimistic lock or queue |
| S04 | idempotent API replay | idempotency key (see 050) |
| S05 | scheduled job exclusive run | distributed lock |
| S06 | leader election | distributed lock + TTL |
| S07 | cache stampede | singleflight / local lock |
| S08 | batch processing partition | partition ownership |
| S09 | event consumer ordering | partition key assignment |
| S10 | saga step coordination | orchestrator + compensation |
| S11 | read-your-writes | sticky session or write-through |
| S12 | cross-tenant isolation | row-level or schema-level isolation |


## Deadlock detection and prevention quick-reference

### When to flag deadlock risk
Flag `deadlock_analysis.risk_level: high` when ALL of the following are true:
1. Multiple actors (threads/processes) acquire 2+ shared resources
2. Resource acquisition order is not enforced globally
3. Each actor can hold a resource while waiting for another

### Prevention rules (apply in priority order)
| Rule | How to apply |
|---|---|
| Fixed lock ordering | Sort resources by a canonical key (e.g. `table_name ASC, row_id ASC`) before acquiring |
| Lock timeout | Set `innodb_lock_wait_timeout` or app-level timeout; avoid infinite wait |
| Try-lock with backoff | Use `SELECT ... FOR UPDATE NOWAIT` or equivalent; retry with jitter |
| Single-resource atomicity | If only one resource is contested, deadlock is impossible |
| Queue serialization | Serialize access via queue instead of locks when order matters |

### TC-CON test derivation rules
Every `concurrency_design` must derive at least 2 test cases:

| Test type | What to verify | Tooling |
|---|---|---|
| Happy path concurrency | N actors, 1 succeeds, rest get correct conflict response | k6, custom goroutine test |
| Failure injection | lock holder crashes mid-transaction; verify cleanup | chaos tools or manual |
| Deadlock simulation | two actors acquire resources in reverse order | integration test |
| Lease expiry | distributed lock TTL expires while holder is alive | mock clock or sleep test |

```yaml
derived_test_scenarios:
  - test_id: TC-CON-001
    scenario: "100 concurrent POST /orders with same idempotency key"
    actors: 100
    expected_outcome: "1 order created; 99 receive cached result or 409 conflict"
    negative_case: "without UNIQUE constraint, duplicates appear"
    tooling: k6 or concurrent goroutine test
  - test_id: TC-CON-002
    scenario: "Order service crashes after DB write, before outbox relay"
    actors: 1 (crash simulation)
    expected_outcome: "outbox relay retries; idempotency prevents duplicate event"
    negative_case: "without outbox, event is lost permanently"
    tooling: process kill + replay test
```


## Trigger conditions
Design concurrency control when any of the following are present:
- N130 technical solution analysis
- N160 schema drafts (`表结构设计草案.sql`)
- N150 API contracts for state-transition operations
- explicit concurrency or race condition design requests

## Standalone rule
Use `selected_mode: scenario_checklist` as default. Without structured upstream, identify concurrency scenarios from domain language. Mark all inferred conflict rates as `confidence: inferred`.

## Role and boundary
本 skill 对齐 skills_workflow 中in the technical-solution-design -> 高级设计 -> 并发控制建议」. It is a **direct_result** skill: the goal is to produce a concrete 竞争、锁、隔离级别、顺序约束和 must-test 场景落成可交付的 **`并发控制建议.md`**，rather than returning generic advice。

### Boundary
- 负责识别竞争热点、竞态场景、锁策略、序列化策略与事务保护方式。
- 负责比较乐观锁、悲观锁、队列化、版本控制、状态机守卫、分布式锁等方案。
- 不负责重放幂等语义本身；该职责交给 `idempotency-design-recommendation`。
- 不负责安全威胁建模、审计保留或性能容量建模，但要为这些技能提供并发假设与 blocker 信号。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- stable ID following `CON-###`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `scenario_checklist`：快速识别业务场景会命中哪些竞态类型；默认模式。
- `tech_pick`：在候选实现方案之间做技术选型与 trade-off。
- `workflow_hardening`：围绕关键流程输出完整的锁、隔离、顺序与失败恢复策略。

## Primary inputs
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `engineering_requirements(N120), data_flows/tables(N160), state_machines/business_rules(N070), api_specs(N150)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule
即使只有技术方案与业务描述，也可以单独使用。

降级规则：
- 若缺少明确流程或对象模型，可先输出 provisional race map。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的对象、操作、竞争关系。
- 没有真实吞吐或冲突率时，不得伪装成精确锁等待或性能结论。

## Core output contract
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `并发控制建议.md`
- primary output object: `concurrency_designs[]`
- stable ID: `CON-###`
- event: `produced.n170.concurrency_design.v2`
- blocker: `B01`
- stage: `technical_solution_design.advanced_design.concurrency_control`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: S01-S12 场景分类、isolation + lock 组合、锁决策树、lease/fencing、死锁分析和 TC-CON 测试派生.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R07 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B01` blocker signal.

## Execution workflow
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `concurrency_designs[]`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_050_idempotency, to_053_performance, to_N210_code_review, to_N260_concurrency_test`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness
- 单个 API / 单条流程：覆盖全部共享对象与状态迁移
- 中型业务流：覆盖全部高风险热点与关键交叉路径
- 大型系统：聚焦核心竞争域、热点流程、外部回调与批处理交汇点

## Quality bar
合格结果应能直接指导实现、测试与专项门禁，而不需要再次解释“为什么这里会冲突”。

## Reference files
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`

## v2 additions: N005 feedback signal and N070 upstream linkage

Add `feedback_signal_to_n005` to every produced artifact metadata block:

```yaml
feedback_signal_to_n005:
  signal_type: none | concurrency_incident_pattern | lock_contention_signal
  summary: ""
  target_n070_skills:
  - 014-business-rule-extraction
  - 015-state-transition-mapping
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
```

### Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| 业务规则清单.md (014) | rule_semantic: concurrency/idempotency, condition_expr | scenario_classification S01-S12 seeds |
| 状态转移图.md (015) | SM-* transitions, trigger_kind=composite, blocked_by[] | S04_state_transition, S05_sequential_op |
| 权限矩阵.csv (016) | evaluation_algo, relational_constraint[] | S07_distributed_claim lock scope |
| 数据对象目录.md (017) | constraint_tags: append_only, write_heavy | S03_balance_adjustment, S07 detection |

## v2 SKILL.md contract — inline rule_results (authoritative for N380 scanning)

Full rule definitions are in `references/v2-contract.md`.
This block exposes rule IDs and severity levels so N380 can aggregate without reading the reference file.

```yaml
artifact_schema_version: n170.v2.0.0
skill_name: concurrency-control-recommendation
produced_event: produced.n170.concurrency_design.v2
blocker_mapping: B01
rule_results:
  - rule_id: R01_scenario_classified
    severity: reject
    check: "每个设计必须归入 S01-S12 之一"
    result: pass | warn | reject | not_applicable
  - rule_id: R02_isolation_and_lock_combo
    severity: reject
    check: "isolation + lock 必须组合声明，不能只写其一"
    result: pass | warn | reject | not_applicable
  - rule_id: R03_decision_tree_followed
    severity: reject
    check: "锁选型必须引用决策树并写 rationale"
    result: pass | warn | reject | not_applicable
  - rule_id: R04_distributed_lock_has_lease
    severity: reject
    check: "分布式锁必须有 lease_time、auto_renewal、fencing_token"
    result: pass | warn | reject | not_applicable
  - rule_id: R05_deadlock_analyzed_for_high_risk
    severity: reject
    check: "high 风险必须分析死锁环路和固定加锁顺序"
    result: pass | warn | reject | not_applicable
  - rule_id: R06_test_cases_derived
    severity: reject
    check: "每个关键设计至少派生 2 个 TC-CON 用例"
    result: pass | warn | reject | not_applicable
  - rule_id: R07_read_committed_justify_otherwise
    severity: warn
    check: "非默认隔离级别必须说明 db_default_vs_chosen"
    result: pass | warn | reject | not_applicable

route_back_to: none | n160 | n130
# none   — output complete; N180/N210/N260 may proceed
# n160   — data-model assumption fundamentally wrong; revise before task planning
# n130   — architectural choice incompatible with non-functional finding; escalate

eventbus_subscribers: [N330, N340]
# N330 → 技术与运维文档自动生成
# N340 → 协作知识沉淀
```
