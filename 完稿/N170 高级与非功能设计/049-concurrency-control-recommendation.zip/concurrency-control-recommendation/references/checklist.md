# V2 hard-gate checklist for concurrency-control-recommendation

Use this checklist before finalizing any N170 output. Treat `reject` failures as blocking unless the output is explicitly marked `readiness: blocked` with pending evidence.

## Required metadata

- [ ] `artifact_schema_version: n170.v2.0.0` is present.
- [ ] Design IDs follow `CON-###`.
- [ ] `produced_event: produced.n170.concurrency_design.v2` is present.
- [ ] `blocker_mapping: B01` is present.
- [ ] `confirmed / inferred / pending` evidence buckets are populated.

## Hard rules

- [ ] `R01_scenario_classified` (reject): 每个设计必须归入 S01-S12 之一
- [ ] `R02_isolation_and_lock_combo` (reject): isolation + lock 必须组合声明，不能只写其一
- [ ] `R03_decision_tree_followed` (reject): 锁选型必须引用决策树并写 rationale
- [ ] `R04_distributed_lock_has_lease` (reject): 分布式锁必须有 lease_time、auto_renewal 判断和 fencing_token
- [ ] `R05_deadlock_analyzed_for_high_risk` (reject): high 风险必须分析死锁环路和固定加锁顺序
- [ ] `R06_test_cases_derived` (reject): 每个关键设计必须派生至少 2 个 TC-CON 用例
- [ ] `R07_read_committed_is_default_justify_otherwise` (warn): 非默认隔离级别必须说明 db_default_vs_chosen

## Cross-skill handoff

- [ ] `to_050_idempotency` handoff is explicit: `concurrency_designs[].design_id, scenario_classification, locking_strategy, derived_test_scenarios` -> idempotency_designs[].derived_from.concurrency_design_refs and concurrent_same_key tests
- [ ] `to_053_performance` handoff is explicit: `locking_strategy, performance_impact, lock_contention_estimate` -> B08_concurrency_contention and capacity headroom
- [ ] `to_N210_code_review` handoff is explicit: `transaction boundary, lock scope, retry policy` -> CR checklist for thread safety/transaction boundary
- [ ] `to_N260_concurrency_test` handoff is explicit: `derived_test_scenarios` -> 并发专项测试点
