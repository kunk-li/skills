# V2 orchestration for concurrency-control-recommendation

## Execution modes

- Standalone: produce this skill artifact only. Use `readiness: provisional` when upstream fields are missing.
- N170 batch: use `references/n170-integration-map.md` and keep IDs stable across all six artifacts.
- Gate mode: emit reject/warn results from `references/v2-contract.md` rules and map them to the blocker ID.

## Input normalization

Normalize incoming file names into typed N170 evidence:

| field | required | from | purpose |
| --- | --- | --- | --- |
| `engineering_requirements` | required | N120 | TA-02_concurrency 的 ER |
| `data_flows` | required | N160/data-flow-mapping | 识别跨服务/跨事务边界 |
| `state_machines` | required | N070 | 状态迁移并发保护 |
| `tables` | required | N160 | 表/索引/唯一约束 |
| `api_specs` | required | N150 | 写接口/回调/批任务入口 |
| `business_rules` | required | N070 | rule_semantic == concurrency |

## Output event

```yaml
event:
  produced: produced.n170.concurrency_design.v2
  schema_version: n170.v2.0.0
  artifact: 并发控制建议.md
  blocker_mapping: B01
```

## Field-level handoff for this skill

| link | fields | downstream use |
| --- | --- | --- |
| `to_050_idempotency` | `concurrency_designs[].design_id, scenario_classification, locking_strategy, derived_test_scenarios` | idempotency_designs[].derived_from.concurrency_design_refs and concurrent_same_key tests |
| `to_053_performance` | `locking_strategy, performance_impact, lock_contention_estimate` | B08_concurrency_contention and capacity headroom |
| `to_N210_code_review` | `transaction boundary, lock scope, retry policy` | CR checklist for thread safety/transaction boundary |
| `to_N260_concurrency_test` | `derived_test_scenarios` | 并发专项测试点 |
