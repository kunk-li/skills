# Identity consistency for concurrency designs

Use this reference when an operation is guarded by a scoped business identity, lifecycle generation, or callback correlation tuple.

## Required comparison

1. Extract the authoritative identity and scope from requirement, state, API, and schema artifacts. Cite each component and distinguish confirmed from inferred fields.
2. Compare the same identity across scenario description, database uniqueness, lock/CAS predicate, guarded-field list, idempotency key, callback acceptance check, and downstream test handoff.
3. Keep business lifecycle generation separate from transport delivery retry, callback-attempt counters, and optimistic row versions. State the purpose and owner of each numeric value.
4. If the identity tuple differs between mechanisms, flag a design contradiction even when one mechanism is complete. State which race remains possible and what storage/application enforcement must use the complete tuple.
5. Preserve uncertainty: if database dialect, callback contract, or enforcement owner is unresolved, keep the design provisional and name the required decision. Do not invent final DDL or runtime evidence.

## Output matrix

| Scenario/resource | Authoritative source tuple and scope | Unique key | Lock/CAS guarded fields | Idempotency/callback predicate | Consistent? | Evidence or unresolved point |
|---|---|---|---|---|---|---|

The design is internally consistent only when all applicable enforcement paths preserve the same source-confirmed identity and scope. A correct callback predicate does not compensate for a weaker storage key, and a unique key does not compensate for a callback predicate that omits a lifecycle generation.
