# Concurrency scenario catalog — concurrency-control-recommendation

## S01-S12 full scenario classification

| ID | Scenario | Risk level | Default strategy |
|---|---|---|---|
| S01 | Single-entity optimistic lock (version field) | medium | `version` column, retry on conflict |
| S02 | Single-entity pessimistic lock (FOR UPDATE) | high | `SELECT ... FOR UPDATE`, short transaction |
| S03 | Cross-entity optimistic lock | high | canonical ID ordering, per-entity version |
| S04 | Cross-entity pessimistic lock | critical | strict lock ordering, deadlock detection |
| S05 | Distributed lock (Redis/ZooKeeper) | high | lease TTL + fencing token, no infinite wait |
| S06 | Queue serialization (single actor per entity) | medium | per-entity queue, ordered consumer |
| S07 | State machine guard (invalid transition prevention) | medium | DB + app layer enforcement |
| S08 | MVCC / snapshot isolation (read-heavy) | low | read replica, snapshot consistency |
| S09 | Long-running transaction (saga) | high | saga orchestration, compensation steps |
| S10 | Batch / bulk operation concurrency | medium | chunk-level locks, idempotent batch ID |
| S11 | Cache + DB dual-write race | high | write-through or outbox, not dual-write |
| S12 | External callback race (webhook/callback timing) | critical | idempotency key + state machine guard |

## Deadlock prevention catalog
| Deadlock pattern | Detection | Prevention |
|---|---|---|
| AB-BA lock order | Code review / load test | Canonical ID ordering: always acquire by `table ASC, id ASC` |
| Long transaction holds lock | Slow query log, lock_wait_timeout | Split into short transactions; use saga instead |
| Distributed lock with no TTL | System hangs post-crash | Always set TTL + fencing token |
| Nested FOR UPDATE in loop | EXPLAIN / SHOW ENGINE INNODB STATUS | Batch into single SET-based UPDATE |

## Test scenario derivation rules
| Scenario ID | Minimum test cases required |
|---|---|
| S01-S03 | Happy (1 wins), concurrent N actors, failure injection |
| S04-S05 | Deadlock simulation, lock timeout, fencing token expiry |
| S06-S07 | Invalid state transition, queue overflow, consumer crash |
| S08-S10 | Stale read window, batch partial failure, saga compensation |
| S11-S12 | Dual-write race, callback replay, callback-cancel race |
