# Scoring rubric for concurrency-control-recommendation v2.1

Use this rubric after applying `references/v2-contract.md`. The artifact is judged on concurrency correctness, hard-gate passability, and field-level handoff quality.

## Gate status override

Any `reject` in `rule_results[]` caps the artifact at **2 - partial** unless the artifact is explicitly marked `readiness: blocked` and the blocker is surfaced with owner, evidence, and remediation.

Any missing `contract_appendix`, missing stable ID, missing `produced_event`, or missing `blocker_mapping` caps the artifact at **3 - review ready**.

## 5 - v2 handoff ready
- All required v2 schema fields are present.
- Stable IDs follow the skill prefix and are referenced in `downstream_handoff`.
- `rule_results[]` covers R01-R07 with evidence.
- `blocker_signals[]` is empty or every signal has owner, severity, evidence, and remediation hint.
- Cross-skill handoff fields match `references/n170-integration-map.md`.
- The markdown explanation and machine-readable appendix are consistent.

## 4 - handoff ready with minor gaps
- Core design is implementable and testable.
- No reject rule is unresolved.
- Some optional evidence remains `pending`, but it is clearly marked and does not change the safe recommendation.

## 3 - review ready
- The analysis is useful, but at least one schema section, handoff field, or gate result needs follow-up before downstream automation can consume it.

## 2 - partial
- The output identifies relevant risks or controls but lacks stable IDs, rule evidence, or key v2 schema sections.

## 1 - weak
- The output is generic advice, lacks grounding in the provided workflow, and cannot be consumed by N170 downstream nodes.
