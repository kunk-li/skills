# Compatibility map — concurrency-control-recommendation v2 alignment

## Input artifact field mapping
| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 038 technical-solution-analysis | `architecture_three_states, fmea_analysis[]` | `scenario classification input` | FMEA failure modes seed S01-S12 scenarios |
| 046 table-schema-design-recommendation | `table_id, columns with version` | `optimistic lock targets` | versioned columns → S01/S02 optimistic lock candidates |
| 048 data-flow-mapping | `concurrent access paths` | `race condition identification` | concurrent flows feed scenario classification |

## Output artifact field mapping
| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 050 idempotency-design-recommendation | `design_id (CON-###), locking_strategy` | `derived_from.concurrency_design_refs` | 050 inherits CON IDs to avoid duplicate handling |
| 053 performance-risk-analysis | `lock_contention_estimate` | `B08_concurrency_contention` | contention estimate feeds B08 bottleneck analysis |
| N260 testing | `derived_test_scenarios (TC-CON-###)` | `concurrency test suite` | TC-CON scenarios become concurrent integration tests |

## v2 contract cross-reference
| v2 field | Purpose | Consumer |
|---|---|---|
| `produced_event` | Event bus trigger | N330, N340 |
| `blocker_mapping` | SLA queue key | N380 |
| `rule_results[]` | Gate pass/warn/reject | N380 |
| `route_back_to` | Return path on gap | Upstream skill |
