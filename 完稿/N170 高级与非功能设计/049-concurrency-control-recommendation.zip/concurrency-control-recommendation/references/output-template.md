# Output template: concurrency-control-recommendation v2

Start every answer with the following metadata block when producing a deliverable.

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: concurrency-control-recommendation
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.concurrency_control
  node_artifact_target: 并发控制建议.md
  design_id_pattern: "CON-\d{3,}"
  produced_event: produced.n170.concurrency_design.v2
  blocker_mapping: B01
  selected_mode: <mode>
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Required sections

- `concurrency_designs[].design_id: CON-\d{3,}`
- `scenario_classification: S01_create_unique | S02_update_same_record | S03_balance_adjustment | S04_state_transition | S05_sequential_op | S06_scheduled_batch | S07_distributed_claim | S08_cache_refresh | S09_leader_election | S10_resource_pool | S11_fan_out_fan_in | S12_external_callback_race`
- `isolation_level.chosen + anomalies_prevented + anomalies_tolerated + db_default_vs_chosen`
- `locking_strategy.primary_mechanism + fallback_mechanism + configuration`
- `deadlock_analysis.risk_level + potential_cycles + prevention_strategy + lock_ordering_convention`
- `derived_test_scenarios[]: TC-CON-<seq>, actors, expected_outcome, negative_case`
- `performance_impact + derived_from + decision_refs`

## Machine-readable appendix

At the end of the markdown report, include a compact YAML appendix containing stable IDs, rule results, blocker signals, and downstream handoff.

```yaml
contract_appendix:
  id_prefix: CON
  produced_event: produced.n170.concurrency_design.v2
  blocker_mapping: B01
  rule_results:
    - rule_id: R01
      status: pass | warn | reject | not_applicable
      evidence: []
  downstream_handoff: []
```
