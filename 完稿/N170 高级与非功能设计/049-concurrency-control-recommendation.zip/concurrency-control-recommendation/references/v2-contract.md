# N170 v2 contract: concurrency-control-recommendation

并发控制设计：12 类并发场景、隔离级别 + 锁策略组合、死锁分析、并发测试派生。

## Metadata contract

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: concurrency-control-recommendation
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.concurrency_control
  node_artifact_target: 并发控制建议.md
  design_id_pattern: "CON-\\d{3,}"
  produced_event: produced.n170.concurrency_design.v2
  blocker_mapping: B01
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Input schema with workflow sources

| field | required | from | purpose |
| --- | --- | --- | --- |
| `engineering_requirements` | required | N120 | TA-02_concurrency 的 ER |
| `data_flows` | required | N160/data-flow-mapping | 识别跨服务/跨事务边界 |
| `state_machines` | required | N070 | 状态迁移并发保护 |
| `tables` | required | N160 | 表/索引/唯一约束 |
| `api_specs` | required | N150 | 写接口/回调/批任务入口 |
| `business_rules` | required | N070 | rule_semantic == concurrency |

## Required output schema

- `concurrency_designs[].design_id: CON-\d{3,}`
- `scenario_classification: S01_create_unique | S02_update_same_record | S03_balance_adjustment | S04_state_transition | S05_sequential_op | S06_scheduled_batch | S07_distributed_claim | S08_cache_refresh | S09_leader_election | S10_resource_pool | S11_fan_out_fan_in | S12_external_callback_race`
- `isolation_level.chosen + anomalies_prevented + anomalies_tolerated + db_default_vs_chosen`
- `locking_strategy.primary_mechanism + fallback_mechanism + configuration`
- `deadlock_analysis.risk_level + potential_cycles + prevention_strategy + lock_ordering_convention`
- `derived_test_scenarios[]: TC-CON-<seq>, actors, expected_outcome, negative_case`
- `performance_impact + derived_from + decision_refs`

## Hard gate rules

| rule | check | on violation |
| --- | --- | --- |
| `R01_scenario_classified` | 每个设计必须归入 S01-S12 之一 | `reject` |
| `R02_isolation_and_lock_combo` | isolation + lock 必须组合声明，不能只写其一 | `reject` |
| `R03_decision_tree_followed` | 锁选型必须引用决策树并写 rationale | `reject` |
| `R04_distributed_lock_has_lease` | 分布式锁必须有 lease_time、auto_renewal 判断和 fencing_token | `reject` |
| `R05_deadlock_analyzed_for_high_risk` | high 风险必须分析死锁环路和固定加锁顺序 | `reject` |
| `R06_test_cases_derived` | 每个关键设计必须派生至少 2 个 TC-CON 用例 | `reject` |
| `R07_read_committed_is_default_justify_otherwise` | 非默认隔离级别必须说明 db_default_vs_chosen | `warn` |

## Algorithms and decision logic

- scenario_classification: write API + no existing row -> S01; UPDATE same PK -> S02; INCR/DECR -> S03/S07; state transition -> S04; scheduled trigger + multi-instance -> S06; external webhook racing user action -> S12.
- lock_decision_tree: S01 single service -> DB UNIQUE; S01 cross-service -> distributed lock + DB UNIQUE; S02 low conflict -> optimistic CAS; S02 high conflict -> pessimistic row; S03 -> pessimistic row or atomic counter; S06 -> distributed lock; S07 -> row lock with SKIP LOCKED + UNIQUE.
- deadlock_detection: build lock dependency graph, find cycles, then enforce table_name ASC + row_id ASC ordering or timeout_and_retry.

## Field-level handoff

| link | fields produced/consumed | downstream use |
| --- | --- | --- |
| `to_050_idempotency` | `concurrency_designs[].design_id, scenario_classification, locking_strategy, derived_test_scenarios` | idempotency_designs[].derived_from.concurrency_design_refs and concurrent_same_key tests |
| `to_053_performance` | `locking_strategy, performance_impact, lock_contention_estimate` | B08_concurrency_contention and capacity headroom |
| `to_N210_code_review` | `transaction boundary, lock scope, retry policy` | CR checklist for thread safety/transaction boundary |
| `to_N260_concurrency_test` | `derived_test_scenarios` | 并发专项测试点 |

## Blocker and event output

```yaml
blocker_signal:
  blocker_id: B01
  source_skill: concurrency-control-recommendation
  rule_id: Rxx
  severity: reject | warn
  evidence: []
  recommended_owner: product | engineering | qa | security | compliance
event:
  produced: produced.n170.concurrency_design.v2
  schema_version: n170.v2.0.0
```

## Minimal worked example

```yaml
design_id: CON-001
scenario_classification: S01_create_unique
scenario_description: 同 user + idempotency_key 并发创建订单，只能创建一条
isolation_level.chosen: read_committed
locking_strategy.primary_mechanism: db_unique_constraint
locking_strategy.configuration.db_unique_constraint.columns: [user_id, idempotency_key]
deadlock_analysis.risk_level: low
derived_test_scenarios:
  - test_id: TC-CON-001
    scenario: 100 actors POST same key
    expected_outcome: 1 success + 99 original-result/conflict responses
```

## Standalone behavior

When upstream evidence is missing, still produce a useful provisional artifact. Mark missing source fields as `pending`, inferred design as `inferred`, and hard-gate failures as `blocked` only when the missing evidence prevents a safe recommendation.