# Example I/O: concurrency-control-recommendation v2.1

## ex-001 · order creation concurrency design

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: concurrency-control-recommendation
  workflow_node: N170
  node_artifact_target: 并发控制建议.md
  selected_mode: workflow_hardening
  readiness: ready
  design_id_pattern: "CON-\\d{3,}"
  produced_event: produced.n170.concurrency_design.v2
  blocker_mapping: B01
  evidence_profile:
    confirmed: [API-ORDER-CREATE, orders table, UNIQUE(user_id,idempotency_key)]
    inferred: [expected conflict rate medium]
    pending: [real p99 lock wait metric]
concurrency_designs:
  - design_id: CON-001
    scenario_classification: S01_create_unique
    scenario_description: 同 user + idempotency_key 并发创建订单，只能创建一条
    affected_resources: [API-ORDER-CREATE, orders]
    expected_concurrency_level:
      qps: "2000"
      concurrent_actors_max: 100
    isolation_level:
      chosen: read_committed
      rationale: UNIQUE 约束兜底唯一性，RC 足够避免 dirty_read
      anomalies_prevented: [dirty_read]
      anomalies_tolerated: [non_repeatable_read, phantom_read]
      db_default_vs_chosen:
        db_default: repeatable_read
        chosen_differs: true
        justification: 唯一性由约束保证，不依赖 RR 间隙锁
    locking_strategy:
      primary_mechanism: db_unique_constraint
      fallback_mechanism: none
      configuration:
        db_unique_constraint:
          index_name: uk_orders_user_idempotency
          columns: [user_id, idempotency_key]
    deadlock_analysis:
      risk_level: low
      potential_cycles: []
      prevention_strategy: detect_and_abort
      lock_ordering_convention:
        rule: table_name ASC then row_id ASC
    derived_test_scenarios:
      - test_id: TC-CON-001
        scenario: 100 actors POST same key
        actors: 100
        expected_outcome: 1 order created + 99 original-result/conflict responses
        negative_case:
          description: without UNIQUE, duplicate orders appear
        tooling_hint: k6
      - test_id: TC-CON-002
        scenario: Redis unavailable, DB UNIQUE remains final guard
        actors: 50
        expected_outcome: still only one order
    performance_impact:
      expected_throughput: "limited by unique index write path"
      tail_latency_concern: medium
      lock_contention_estimate: hot when same user/key is retried aggressively
      mitigation: {sharding: false, read_replica: false, caching: false}
    derived_from:
      requirement_refs: [REQ-ORDER-001]
      rule_refs: [RULE-IDEMP-001]
      flow_refs: [FLOW-ORDER-CREATE]
      state_machine_refs: [SM-ORDER]
rule_results:
  - rule_id: R01_scenario_classified
    status: pass
    evidence: [CON-001.scenario_classification]
  - rule_id: R06_test_cases_derived
    status: pass
    evidence: [TC-CON-001, TC-CON-002]
blocker_signals:
  - blocker_id: B01
    source_skill: concurrency-control-recommendation
    rule_id: R07_read_committed_is_default_justify_otherwise
    severity: warn
    evidence: [db_default_vs_chosen]
    recommended_owner: engineering
contract_appendix:
  id_prefix: CON
  produced_event: produced.n170.concurrency_design.v2
  downstream_handoff:
    to_050_idempotency: [CON-001, S01_create_unique, db_unique_constraint, TC-CON-001]
    to_053_performance: [lock_contention_estimate, tail_latency_concern]
```

## Input notes
Use this shape when the user provides API specs, data flows, tables, state machines, or a partial technical solution. Mark missing upstream facts as `pending`, not as assumptions.

## ex-002 · deadlock scenario — S12 detection and prevention

```yaml
concurrency_designs:
  - design_id: CON-002
    scenario_classification: S12_external_callback_race
    scenario_description: "Payment callback and user cancel request arrive simultaneously for the same order"
    affected_resources: [API-PAYMENT-CALLBACK, API-ORDER-CANCEL, orders table]

    deadlock_analysis:
      risk_level: high
      potential_cycles:
        - cycle_id: DC-001
          description: "PaymentCallback holds orders row lock waiting for inventory lock; CancelRequest holds inventory lock waiting for orders lock"
          acquisition_order_violation: true
          detection: "Both transactions use SELECT ... FOR UPDATE in different order"
      prevention_strategy: "canonical lock ordering"
      lock_ordering_convention:
        rule: "Always acquire locks in this order: 1) orders (by order_id ASC) 2) inventory (by product_id ASC). Never reverse."
        enforcement: "Code review checklist item; integration test simulates reverse-order acquisition"
      fallback_when_deadlock_occurs:
        mechanism: "innodb_lock_wait_timeout = 5s; detect deadlock error code 1213; retry with exponential backoff"
        max_retries: 3
        retry_jitter_ms: [100, 200, 400]

    isolation_level:
      chosen: read_committed
      rationale: "RC avoids gap locks that increase deadlock probability; UNIQUE constraint handles duplicate prevention"

    derived_test_scenarios:
      - test_id: TC-CON-003
        scenario: "Simultaneous payment callback + cancel for order-id=42"
        actors: 2
        expected_outcome: "One transaction commits, other retries successfully within 3 attempts"
        negative_case:
          description: "Without canonical lock ordering, deadlock occurs 100% of the time in this scenario"
          reproduction: "Swap lock order in cancel handler; run concurrent test; observe deadlock error"
        tooling: "integration test with goroutines or k6 concurrent VUs"
      - test_id: TC-CON-004
        scenario: "Lease expiry simulation — distributed lock holder crashes mid-operation"
        actors: 1 (crash simulation)
        expected_outcome: "Lock auto-expires after TTL; next actor acquires lock and completes operation"
        negative_case:
          description: "Without TTL, crashed holder holds lock permanently — system stuck"
        tooling: "mock clock or process kill after acquiring lock"
```

## ex-003 · degraded — no schema evidence, scenario classification from domain only

```yaml
skill_name: concurrency-control-recommendation
readiness: provisional
selected_mode: scenario_checklist
evidence_profile:
  confirmed: []
  inferred: [all scenarios derived from PRD domain description]
  pending: [schema version columns, isolation level from DBA, actual conflict rates]

degraded_reason: "No 表结构设计草案.sql from 046 — cannot verify versioned columns or FK locking behavior"
degraded_impact: "Isolation level cannot be confirmed without schema; lock strategy is provisional"

concurrency_designs:
  - design_id: CON-001-PROVISIONAL
    scenario_classification: S01_single_entity_optimistic
    confidence: inferred
    inferred_from: "Domain: leave approval is a single-entity state transition"
    provisional_strategy:
      recommended: optimistic_lock
      key_assumption: "leave_tickets table will have a version column — confirm with 046"
      if_assumption_wrong: "Fall back to pessimistic lock (SELECT ... FOR UPDATE)"

pending_confirmations:
  - "Confirm version column exists in TBL-TICKET-001 (046)"
  - "Confirm isolation level with DBA — READ COMMITTED assumed"
  - "Measure actual concurrent approval rate in staging before finalizing strategy"
```

## ex-004 · blocked — no table schema to analyze locking strategy

```yaml
skill_name: concurrency-control-recommendation
readiness: blocked
blocker_mapping: B-N170-02
route_back_to: table-schema-design-recommendation

blockers:
  - blocker_id: BLK-CON-001
    type: missing_schema
    description: "Cannot analyze lock strategies without knowing column types and constraints in 046 schema. Version column presence determines whether optimistic locking is viable."
    impact: "S01 (optimistic) vs S02 (pessimistic) decision cannot be made — wrong choice causes either performance issues or deadlocks"
    resolution_required: "046 must confirm: (1) version column exists, (2) index on status+version, (3) isolation level target"
    unblock_evidence: "046 DDL for affected tables showing version column and relevant indexes"

  - blocker_id: BLK-CON-002
    type: missing_data_flow
    description: "Cannot identify race conditions (S11 cache-DB dual-write) without confirmed flow map from 048"
    impact: "Cache invalidation race conditions are the most common production concurrency bug — skipping this analysis is high risk"
    resolution_required: "048 must complete flow catalog before concurrency analysis"

provisional_scenarios:
  note: "Only domain-derived scenarios listed — schema verification required before implementation"
  - scenario: S07_state_machine_guard
    confidence: confirmed
    rationale: "State machine required regardless of schema — approval workflow has invalid transitions that must be prevented"
    recommendation: "Enforce at DB + app layer: UPDATE with WHERE status = 'SUBMITTED' AND id = ?"
```
