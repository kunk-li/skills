# Example I/O: concurrency-control-recommendation v2.1

## ex-001 · order creation concurrency design

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: concurrency-control-recommendation
  workflow_node: N170
  node_artifact_target: 并发控制建议.md
  selected_mode: workflow_hardening
  readiness: ready
  design_id_pattern: "CON-\\d{3,}"
  produced_event: produced.n170.concurrency_design.v2
  blocker_mapping: B01
  evidence_profile:
    confirmed: [API-ORDER-CREATE, orders table, UNIQUE(user_id,idempotency_key)]
    inferred: [expected conflict rate medium]
    pending: [real p99 lock wait metric]
concurrency_designs:
  - design_id: CON-001
    scenario_classification: S01_create_unique
    scenario_description: 同 user + idempotency_key 并发创建订单，只能创建一条
    affected_resources: [API-ORDER-CREATE, orders]
    expected_concurrency_level:
      qps: "2000"
      concurrent_actors_max: 100
    isolation_level:
      chosen: read_committed
      rationale: UNIQUE 约束兜底唯一性，RC 足够避免 dirty_read
      anomalies_prevented: [dirty_read]
      anomalies_tolerated: [non_repeatable_read, phantom_read]
      db_default_vs_chosen:
        db_default: repeatable_read
        chosen_differs: true
        justification: 唯一性由约束保证，不依赖 RR 间隙锁
    locking_strategy:
      primary_mechanism: db_unique_constraint
      fallback_mechanism: none
      configuration:
        db_unique_constraint:
          index_name: uk_orders_user_idempotency
          columns: [user_id, idempotency_key]
    deadlock_analysis:
      risk_level: low
      potential_cycles: []
      prevention_strategy: detect_and_abort
      lock_ordering_convention:
        rule: table_name ASC then row_id ASC
    derived_test_scenarios:
      - test_id: TC-CON-001
        scenario: 100 actors POST same key
        actors: 100
        expected_outcome: 1 order created + 99 original-result/conflict responses
        negative_case:
          description: without UNIQUE, duplicate orders appear
        tooling_hint: k6
      - test_id: TC-CON-002
        scenario: Redis unavailable, DB UNIQUE remains final guard
        actors: 50
        expected_outcome: still only one order
    performance_impact:
      expected_throughput: "limited by unique index write path"
      tail_latency_concern: medium
      lock_contention_estimate: hot when same user/key is retried aggressively
      mitigation: {sharding: false, read_replica: false, caching: false}
    derived_from:
      requirement_refs: [REQ-ORDER-001]
      rule_refs: [RULE-IDEMP-001]
      flow_refs: [FLOW-ORDER-CREATE]
      state_machine_refs: [SM-ORDER]
rule_results:
  - rule_id: R01_scenario_classified
    status: pass
    evidence: [CON-001.scenario_classification]
  - rule_id: R06_test_cases_derived
    status: pass
    evidence: [TC-CON-001, TC-CON-002]
blocker_signals:
  - blocker_id: B01
    source_skill: concurrency-control-recommendation
    rule_id: R07_read_committed_is_default_justify_otherwise
    severity: warn
    evidence: [db_default_vs_chosen]
    recommended_owner: engineering
contract_appendix:
  id_prefix: CON
  produced_event: produced.n170.concurrency_design.v2
  downstream_handoff:
    to_050_idempotency: [CON-001, S01_create_unique, db_unique_constraint, TC-CON-001]
    to_053_performance: [lock_contention_estimate, tail_latency_concern]
```

## Input notes
Use this shape when the user provides API specs, data flows, tables, state machines, or a partial technical solution. Mark missing upstream facts as `pending`, not as assumptions.
