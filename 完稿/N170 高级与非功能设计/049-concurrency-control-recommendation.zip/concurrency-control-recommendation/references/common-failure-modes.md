# Common failure modes for concurrency control recommendation

## F1: recommending a lock without defining the protected object
Symptom: the output says to lock but never says what key or object is serialized.
Fix: always name the shared object and the competing actors.

## F2: solving a duplicate-processing problem with locking only
Symptom: retries and redelivery exist, but the design ignores dedupe or idempotency.
Fix: combine concurrency control with idempotency rules when the same request may reappear.

## F3: treating ordering problems as simple race conditions
Symptom: the design focuses on mutual exclusion but ignores out-of-order callbacks or async completions.
Fix: add sequence numbers, version checks, or terminal-state guards.

## F4: selecting pessimistic locking for broad workflows by default
Symptom: long user-driven flows stay locked across network or approval delays.
Fix: prefer short critical sections, optimistic checks, or queue serialization.

## F5: missing failure-observability requirements
Symptom: the design has controls but no way to observe retries, deadlocks, queue lag, or conflict rates.
Fix: require metrics, logs, and alertable signals in must-test cases.

## V2.1 contract failure modes

## F6: using legacy RS taxonomy in v2 output
Symptom: the output uses `RS-01` style labels instead of `S01_create_unique` through `S12_external_callback_race`.
Fix: read `v2-contract.md` first and classify every design into exactly one S01-S12 scenario.

## F7: omitting rule_results
Symptom: the report has recommendations but no pass/warn/reject gate evidence.
Fix: emit `rule_results[]` for R01-R07 and map violations to B01 blocker signals.

## F8: breaking downstream idempotency handoff
Symptom: 050 cannot reference the concurrency design because no CON id or test scenario is produced.
Fix: expose `concurrency_designs[].design_id`, `scenario_classification`, `locking_strategy`, and `derived_test_scenarios`.

## F9: contract appendix drift
Symptom: the markdown narrative says one thing while `contract_appendix` exposes different IDs, rule results, or handoff fields.
Fix: reconcile narrative and appendix before finalizing; the appendix is what downstream automation consumes.

## F10: blocker without owner or remediation
Symptom: a warning or reject is emitted but no owner, evidence, or next action is named.
Fix: every `blocker_signals[]` item must include `recommended_owner`, evidence, and a remediation hint or pending evidence field.
