# CHANGELOG

## v4.1.0 (2026-06-17) — demand-pull systemic-defect rule

_skill: security-risk-analysis_

### Added
- R08_control_enforcement_verified (reject): a mitigation for a critical/high threat must be verified to actually enforce; a stub/placeholder/no-op/always-pass control counts as missing and goes to residual risk
- common-failure-modes F11: counting a stubbed or placeholder control as a real mitigation (sharpens F2)
- Required-output-schema field: control_enforcement_verification[]

### Changed
- rule_results range widened to R01-R08 in SKILL.md inline contract

---

## v4.0.0 (2026-04-30) — v10 final optimization

_skill: security-risk-analysis_

### Added
- Trigger conditions + Standalone rule sections
- Confidence discipline (confirmed/inferred/pending separation)
- Downstream handoff summary
- Compatibility-map.md with field-level input/output mapping
- blocked + degraded example-io scenarios

### Changed
- Description trimmed to ≤25 words
- Quick-reference tables expanded to ≥4 per skill
- rule_results expanded to R01-R08

### Fixed
- CHANGELOG format standardized to `# CHANGELOG` header
- Chinese/English section headers unified to English

---

## v3.0.0 (2026-04-30) — v5 optimization batch

### Added
- common-failure-modes.md with Symptom/Fix format (F1–F8)
- workflow-position.md
- compatibility-map.md
- CHANGELOG.md

### Changed
- Checklist rewritten with inline `- [ ]` items
- example-io.md expanded with concrete YAML examples
- Description word count reduced

---

## v2.0.0 (2026-01-15) — v2 contract migration

### Added
- artifact_schema_version header
- produced_event field
- blocker_mapping field
- rule_results[] with pass|warn|reject|not_applicable
- feedback_signal_to_n005 reverse governance channel

---

## v1.0.0 (2025-10-01) — initial release
