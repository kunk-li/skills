# CHANGELOG

## v4.3.0 (2026-06-24) — R08 扩 registration-fail-open + MFA channel-independence 两子型

_skill: security-risk-analysis_

### Changed
- R08_control_enforcement_verified / checklist / v2-contract / SKILL inline:present-but-inert 形态列表再补两子型——(1)注册/装配期 fail-open:安全强制点(拦截器/守卫/filter/PEP)的 wiring 被吞异常 try/catch 包裹或条件注册默认 off,依赖缺失时执行点根本未装入请求链而应用照常启动;须 fail-fast 拒启动或告警。(2)MFA 信道独立性:名义多因子的第二因子与第一因子/触发置于同一信道(同连接/同会话/信道由不可信请求方可控参数决定),双因子坍缩为单信道单因子(confused-deputy same-channel collapse)。两者均按未缓解、计入 residual risk。
- common-failure-modes 新增 F12(assembly-time 注册 fail-open,F11 的装配期延伸)+ F13(MFA 同信道坍缩,认证层 present-but-inert)。
- SKILL.md 新增「MFA channel-independence 信道独立性核对」镜头(Spoofing 的 derive-then-diff 落地,与 Audit-coverage 镜头并列);v2-contract stride_threat_enumeration 的 Spoofing 描述补 MFA 信道独立性核对。
- 来源:D-039 认证域验证循环反查「团队改了我没发现的」挖出的 skill 漏检盲区。注册 fail-open 的结构检测面配套落到 070 dead_guard 族新 finding_kind: registration_fail_open(交叉引用,不在 054 越层)。经对抗 verify 收窄:注册 fail-open 拆「054 残值核算面 + 070 结构检测面」,MFA 并入 R08 不新增编号(库恒 157)。

---

## v4.2.0 (2026-06-23) — R08 扩 proxy-substitution 子型

_skill: security-risk-analysis_

### Changed
- R08_control_enforcement_verified / F11 / checklist / v2-contract:present-but-inert 形态列表补「用可绕过代理代替权威查表」(以角色名或标志位字符串匹配、缓存值、客户端传参、session 标志冒充对权威态的实时核验)。现有 R08 偏重「不校验」(仅日志/恒真/空体/依赖缺失放行/TODO),proxy-substitution 是「看似在校验、实则校的是可被调用方伪造的代理」的隐蔽子型,最易被 review 放过。
- 来源:第 5 验证画像(present-but-inert benchmark)真实例——某控制以 uid.contains("L6") 字符串匹配代角色权威查表。经对抗 verify 收窄:原拟在质量门禁 skill 新建大段,核查发现 present-but-inert 主体已被本 R08 + 070 stub_control 覆盖,真增量仅此 proxy-substitution 一类,故并入现有 R08 而非新建条目(库恒 157)。

---

## v4.1.0 (2026-06-17) — demand-pull systemic-defect rule

_skill: security-risk-analysis_

### Added
- R08_control_enforcement_verified (reject): a mitigation for a critical/high threat must be verified to actually enforce; a stub/placeholder/no-op/always-pass control counts as missing and goes to residual risk
- common-failure-modes F11: counting a stubbed or placeholder control as a real mitigation (sharpens F2)
- Required-output-schema field: control_enforcement_verification[]

### Changed
- rule_results range widened to R01-R08 in SKILL.md inline contract

---

## v4.0.0 (2026-04-30) — v10 final optimization

_skill: security-risk-analysis_

### Added
- Trigger conditions + Standalone rule sections
- Confidence discipline (confirmed/inferred/pending separation)
- Downstream handoff summary
- Compatibility-map.md with field-level input/output mapping
- blocked + degraded example-io scenarios

### Changed
- Description trimmed to ≤25 words
- Quick-reference tables expanded to ≥4 per skill
- rule_results expanded to R01-R08

### Fixed
- CHANGELOG format standardized to `# CHANGELOG` header
- Chinese/English section headers unified to English

---

## v3.0.0 (2026-04-30) — v5 optimization batch

### Added
- common-failure-modes.md with Symptom/Fix format (F1–F8)
- workflow-position.md
- compatibility-map.md
- CHANGELOG.md

### Changed
- Checklist rewritten with inline `- [ ]` items
- example-io.md expanded with concrete YAML examples
- Description word count reduced

---

## v2.0.0 (2026-01-15) — v2 contract migration

### Added
- artifact_schema_version header
- produced_event field
- blocker_mapping field
- rule_results[] with pass|warn|reject|not_applicable
- feedback_signal_to_n005 reverse governance channel

---

## v1.0.0 (2025-10-01) — initial release
