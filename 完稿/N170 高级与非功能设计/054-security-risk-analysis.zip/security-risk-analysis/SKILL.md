---
name: security-risk-analysis
description: analyze security risks, threat models, control gaps, residual risks, severity sla, supply-chain issues, and compliance alignment from technical solution notes, vulnerability findings, schema drafts, permission constraints, api surfaces, and data classification. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 安全风险分析.md for n170 before task planning, implementation review, special testing, or governance review.
---
# security-risk-analysis

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 安全风险分析」。

它是 **direct_result** 型技能：目标是把威胁建模、控制项、残余风险、修复优先级与合规映射落成可交付的 **`安全风险分析.md`**，而不是只给散乱的风险点清单。

### Boundary / 边界
- 负责建立 STRIDE 为主的威胁模型、数据保护三要素、供应链安全、severity SLA 与合规映射。
- 负责识别入口、信任边界、敏感资产、提权路径与高风险依赖。
- 不输出攻击操作细节；保持在设计审查与控制建议层级。
- 不替代授权、审计或性能设计，但要消费这些设计并暴露跨切面 blocker。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- `artifact_schema_version: n170.v2.0.0`
- stable ID following `SEC-###`
- `produced_event: produced.n170.security_threat_model.v2`
- `blocker_mapping: B05`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `stride_workshop`：以 STRIDE 为主做结构化威胁建模；默认模式。
- `compliance_gap_analysis`：重点输出法规与控制项差距。
- `control_hardening`：重点输出控制缺口、severity、SLA 与修复优先级。

## Primary inputs / 主要输入
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `api_specs(N150), data_flows(N160), authorization_model(052), data_objects(N070), vulnerabilities_from_N100(optional), threat_intelligence(optional)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule / 独立使用规则
即使只有技术方案与敏感数据 / 动作描述，也可以单独使用。

降级规则：
- 若系统分层或 trust boundary 不完整，可先输出 provisional threat map。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的入口、控制、法规适用与风险等级。
- 没有依据时，不得擅自声称某法规必然适用。

## Core output contract / 核心输出契约
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `安全风险分析.md`
- primary output object: `threat_model`
- stable ID: `SEC-###`
- event: `produced.n170.security_threat_model.v2`
- blocker: `B05`
- stage: `technical_solution_design.advanced_design.security_risk_analysis`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules / 设计规则
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: STRIDE 六维、D1-D4 分域、data_flow_security、供应链 SBOM、IR playbooks、风险签收和 critical mitigation.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R07 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B05` blocker signal.

## Execution workflow / 执行流程
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `threat_model`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_051_audit, to_052_authorization, to_N210_code_review, to_N230_security_test, to_N260_security_gate`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness / 动态完整度
- 单一集成：覆盖全部入口、密钥、回调与敏感数据流
- 中型系统：覆盖所有关键组件、外部依赖与高权限路径
- 大型平台：聚焦核心 trust boundary、合规域与公开暴露面

## Quality bar / 质量门槛
合格结果应让团队明确知道“哪里最容易被打、当前有什么控制、还缺什么、多久必须修、哪些场景是 blocker”。

## Reference files / 参考文件
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
