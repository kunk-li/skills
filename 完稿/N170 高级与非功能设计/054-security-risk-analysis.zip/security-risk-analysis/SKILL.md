---
name: security-risk-analysis
description: Analyze STRIDE threats, D1-D4 domains, D5 untrusted-execution sandbox hardening (CI runners, plugin hosts, auto-run tools), supply chain, residual risks, and compliance alignment.
---
# security-risk-analysis

## STRIDE quick-reference
| Threat | Violates | Key controls |
|---|---|---|
| **S**poofing | Authentication | strong auth, MFA, token validation |
| **T**ampering | Integrity | input validation, HMAC, signed payloads |
| **R**epudiation | Non-repudiation | audit trail (see 051), signed audit events |
| **I**nformation disclosure | Confidentiality | encryption at rest/transit, PII masking |
| **D**enial of service | Availability | rate limiting, circuit breaker, autoscale |
| **E**levation of privilege | Authorization | PoLP, SoD, see 052 |


## SBOM and supply chain quick-reference
Every production system must satisfy R04_supply_chain_sbom or declare an explicit waiver.

| Requirement | What to capture | Tool examples |
|---|---|---|
| SBOM generation | List all direct + transitive dependencies with version and license | Syft, CycloneDX, FOSSA |
| Vulnerability scan | CVE scan against SBOM on every build | Grype, Trivy, Snyk |
| License compliance | Flag GPL/AGPL in commercial products | FOSSA, Black Duck |
| Build integrity | Signed build artifacts, provenance attestation | SLSA level 2+, Sigstore |
| Third-party SLA | Vendor security SLA for critical dependencies | Contract review |

**Waiver rule**: if SBOM is not yet generated, record `supply_chain_security.sbom_generated: false` with `waiver_reason` and `remediation_deadline`. This still satisfies R04 as long as a concrete plan exists.

## Compliance obligation mapping quick-reference
| Regulation | Key controls required | D-domain |
|---|---|---|
| GDPR | PII inventory, consent, right to erasure, DPA, 72h breach notification | D3 |
| PCI-DSS | Card data isolation, encryption, access logs, quarterly scan | D2 |
| SOC2 CC7 | Anomaly detection, incident response, change management | D2/D4 |
| HIPAA | PHI access logs, BAA, encryption at rest/transit | D2/D3 |
| ISO27001 | Risk register, ISMS, periodic review | D1/D4 |
| CCPA (California Consumer Privacy Act) | Consumer data disclosure rights, opt-out of sale, data deletion, no discrimination | D3 |
| PIPL / 中国个人信息保护法 | Consent for processing, cross-border transfer approval (CAC), data localization, 15-day breach notification, DPO appointment | D3 |
| LGPD (Brazil) | Consent, data subject rights, DPA registration, breach notification ≤2 working days | D3 |
| SOX (financial reporting) | Audit trail for financial data changes, access control logs, 7-year retention | D2/D4 |
| APRA CPS 234 (Australia) | Cyber resilience framework, incident notification within 72h, board accountability | D1/D4 |

**Compliance detection rules**:
- Has EU/UK users → GDPR mandatory
- Has California users or collects CA resident data → CCPA applicable
- Has China operations, stores Chinese user data, or transfers data to/from China → PIPL mandatory
- Processes card data → PCI-DSS mandatory
- Has Brazil operations → LGPD applicable
- Is a US public company or subsidiary → SOX for financial data
- Is an Australian-regulated entity → APRA CPS 234

## D1-D4 security domain quick-reference
| Domain | Scope | Key artifacts |
|---|---|---|
| D1: API & surface | all external-facing endpoints | rate limit, input validation, auth check |
| D2: Data | PII, financial, regulated data at rest and in transit | encryption, masking, data classification |
| D3: Identity & access | authentication, authorization, delegation | see 052 |
| D4: Supply chain | third-party libraries, services, infra | SBOM, vendor SLA, dependency CVE tracking |

## D5: Untrusted-execution sub-domain(系统的功能本身就是跑第三方/不可信代码)
触发 = CI runner / sandbox / plugin host / 自动跑验工具(如 RepoProbe)。此时**攻击者代码是输入、不是外部探测者** → 标准 STRIDE + D1-D4 不足(默认控制 MFA/SBOM/合规多不适用),改用本控制 catalog,按 STRIDE T/E/D/I 展开:

| 威胁面 (STRIDE) | 控制 catalog |
|---|---|
| 容器/沙箱逃逸 (T/E) | 非 root 运行 · `--cap-drop ALL`(按需再 add)· read-only rootfs · seccomp/AppArmor profile · `--security-opt no-new-privileges` · user namespace |
| 资源炸弹 (D) | `--pids-limit`(防 fork bomb)· cpu/内存上限 · wall-clock 超时 · 磁盘配额 |
| 出网外联 / exfil (I) | **默认 egress 锁定**(`--network none` 或仅白名单目的地)· DNS 限制 |
| 构建期任意执行 (T/E) | 构建也跑不可信代码(Dockerfile `RUN`)→ 同等限额 + 隔离;固定基础镜像 + 校验 |
| 产物/日志回显泄漏 (I) | 捕获的不可信输出**脱敏**(secret/PII)再入报告/日志 |
| 持久化/逃逸到宿主 (T/E) | 一次性容器(`--rm`)· 禁特权挂载 · 运行后 teardown 验无残留 |

**判据**:跑不可信代码 + egress 未锁 = **critical**;缺逃逸/资源/脱敏控制 = **high**。每条落成 `SEC-###` 控制项,缺失项进 residual risk。**来源**:RepoProbe 真建 + 054 dogfood 坐实(STATUS Signal #7 第 5 证据)。

## Audit-coverage 审计覆盖核对(Repudiation 的 derive-then-diff 落地 · 真用反哺 2026-06-08)
STRIDE 的 R(Repudiation)只说"要有审计";本镜头把它**落成可机械核对的求差**:枚举**敏感动作集**,对每个动作核**成功路径上是否真写了不可抵赖的审计记录**(不是只在失败/异常分支写)。实测某真实系统:多条敏感动作只在失败分支审计、成功路径只有普通日志 → **冒名/越权一旦得手反而查无痕迹**(doc-vs-doc 与单文件审查抓不到——需枚举动作集 + 逐条核成功路径)。
- **敏感动作集(逐条核成功路径有无审计)**:登录 / 会话签发(尤其免密 / 快捷 / 代登录)· 角色 / 权限授予与回收 · 资金审批 / 结算 / 发放 / 退款 · 凭据重置(密码 / TOTP / 密钥)· 账号启停 / 冻结 / 复活 · 配置开关翻转(尤其安全相关 flag)· 数据导出 / 批量操作 · 跨边界 / 特权调用。
- **判据**:敏感动作**成功路径**无审计 = **high**(可抵赖 + 取证盲区);**最危险那条**(可冒名任意账号 / 改钱 / 提权)成功无审计 = **critical**。**非对称陷阱**:很多系统失败分支有审计、成功分支没有 → 恰恰漏掉"得手"那次,逐条核成功路径才暴露。
- **fire-and-forget 审计静默丢失**:异步 / 旁路审计(`sync=false` / 后台线程 / 无 DLQ 兜底)在敏感动作上 = 审计可能静默丢 → critical 动作要求**同步 + 失败可观测**,否则计 medium-high。
- **access-completeness(配套核)**:鉴权拦截器 / HMAC 的**路径绑定集** vs **需保护端点集**求差——绑定没覆盖到的敏感端点 = 未鉴权裸奔(实测抓出一条:HMAC 只绑某前缀、另一前缀的内部端点裸奔)。
- **落成 `SEC-###`**,缺项进 residual risk;与 051(审计设计)互补:051 建审计能力,本镜头核**敏感动作是否都接上了**。

## MFA channel-independence 信道独立性核对(Spoofing 的 derive-then-diff 落地)
STRIDE 的 S(Spoofing)只说要 MFA;本镜头落成可机械核对:对任何声称用了多/双因子的认证或敏感动作确认流程,枚举第一因子/触发通道与第二因子通道,核两者是否真正独立。原则:第二因子通道必须独立于第一因子通道与触发通道。
- 枚举核对集:登录 MFA · 敏感动作 step-up 确认(改密/换绑/解绑/大额或高权操作)· 设备/会话信任建立 · 找回/重置二次验证 · 代登录/免密/快捷登录后的提权确认 · webhook/回调触发的带外确认。
- 判据:第二因子(验证码/确认/挑战)经与第一因子或触发请求同一信道送达/回收,或信道选择由请求方可控参数(传输/method/header)决定(可被强制选回同信道)= 双因子坍缩为单信道单因子 = 假双因子 → 该 MFA 按未生效计,等同单因子。对可绕过此 MFA 直达高权/改钱/冒名的动作记 critical,其余 high。要求第二因子走带外/独立信道(不同传输或不同端点设备),且信道选择不可由不可信请求方单方决定。
- 与 R08/F11 的关系:R08 核单控制是否 present-but-inert(授权层);本镜头核多因子两因子是否同信道坍缩(认证层)——名义配齐两因子却共信道,是认证层的 present-but-inert,落成 SEC-### 缺项进 residual risk,纳入 R08 同一裁决。

## Severity SLA quick-reference
| Severity | Fix SLA | Example |
|---|---|---|
| Critical | ≤ 24h | auth bypass, data exfiltration path |
| High | ≤ 7 days | IDOR, privilege escalation |
| Medium | ≤ 30 days | info leak, missing rate limit |
| Low | next sprint | verbose error messages, minor config drift |

**Output boundary**: emit design-level controls and residual risks only. Do not output exploit details, attack payloads, or penetration test procedures.


## Trigger conditions
Analyze security threats when any of the following are present:
- N130 technical solution with trust boundaries
- N070 permission matrices and data classifications
- N150 API surfaces for attack surface analysis
- 052 authorization controls for elevation-of-privilege analysis
- **system executes untrusted / third-party / user-supplied code**(CI runner / sandbox / plugin host / auto-run tool)→ 套用上面的 **D5 untrusted-execution 子域**
- **system has sensitive state-mutating actions**(登录 / 授权 / 资金 / 凭据 / 账号状态 / 配置开关)→ 套用上面的 **Audit-coverage 审计覆盖核对**(逐条核成功路径有无不可抵赖审计)

## Standalone rule
Use `selected_mode: stride_workshop` as default. All 6 STRIDE dimensions and D1-D4 domains must be assessed. Without explicit compliance requirements, infer applicable regulations from data classification (PII → GDPR, financial → PCI-DSS).

## Role and boundary
本 skill 对齐 skills_workflow 中in the technical-solution-design -> 高级设计 -> 安全风险分析」. It is a **direct_result** skill: the goal is to produce a concrete 威胁建模、控制项、残余风险、修复优先级与合规映射落成可交付的 **`安全风险分析.md`**，而不是只给散乱的风险点清单。

### Boundary
- 负责建立 STRIDE 为主的威胁模型、数据保护三要素、供应链安全、severity SLA 与合规映射。
- 负责识别入口、信任边界、敏感资产、提权路径与高风险依赖。
- 不输出攻击操作细节；保持在设计审查与控制建议层级。
- 不替代授权、审计或性能设计，但要消费这些设计并暴露跨切面 blocker。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- stable ID following `SEC-###`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `stride_workshop`：以 STRIDE 为主做结构化威胁建模；默认模式。
- `compliance_gap_analysis`：重点输出法规与控制项差距。
- `control_hardening`：重点输出控制缺口、severity、SLA 与修复优先级。

## Primary inputs
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `api_specs(N150), data_flows(N160), authorization_model(052), data_objects(N070), vulnerabilities_from_N100(optional), threat_intelligence(optional)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule
即使只有技术方案与敏感数据 / 动作描述，也可以单独使用。

降级规则：
- 若系统分层或 trust boundary 不完整，可先输出 provisional threat map。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的入口、控制、法规适用与风险等级。
- 没有依据时，不得擅自声称某法规必然适用。

## Core output contract
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `安全风险分析.md`
- primary output object: `threat_model`
- stable ID: `SEC-###`
- event: `produced.n170.security_threat_model.v2`
- blocker: `B05`
- stage: `technical_solution_design.advanced_design.security_risk_analysis`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: STRIDE 六维、D1-D4 分域、data_flow_security、供应链 SBOM、IR playbooks、风险签收、critical mitigation 和 control-enforcement verification(控制真生效非占位桩,present-but-inert 按 missing 计).

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R08 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B05` blocker signal.

## Execution workflow
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `threat_model`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_051_audit, to_052_authorization, to_N210_code_review, to_N230_security_test, to_N260_security_gate`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness
- 单一集成：覆盖全部入口、密钥、回调与敏感数据流
- 中型系统：覆盖所有关键组件、外部依赖与高权限路径
- 大型平台：聚焦核心 trust boundary、合规域与公开暴露面

## Quality bar
合格结果应让团队明确知道“哪里最容易被打、当前有什么控制、还缺什么、多久必须修、哪些场景是 blocker”。

## Reference files
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`

## v2 additions: N005 feedback signal and N070 upstream linkage

```yaml
feedback_signal_to_n005:
  signal_type: none | security_incident_pattern | threat_model_signal
  summary: ""
  target_n070_skills:
  - 016-permission-matrix-extraction
  - 017-data-object-identification
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
```

### Upstream linkage from N070 (primary source — consume first)

| upstream artifact | consume fields | maps to |
|---|---|---|
| 权限矩阵.csv (016) | PERM-* grain, channel, evaluation_algo, compliance_flag | STRIDE E_elevation_of_privilege, trust boundary mapping |
| 数据对象目录.md (017) | constraint_tags: pii, regulated, financial | data asset classification, spoofing/tampering targets |
| 业务规则清单.md (014) | rule_semantic: compliance, hardness=constraint | compliance control gap mapping |
| 状态转移图.md (015) | SM-* transitions accessible by external actors | attack surface, STRIDE S_spoofing vectors |

## v2 SKILL.md contract — inline rule_results (authoritative for N380 scanning)

Full rule definitions are in `references/v2-contract.md`.
This block exposes rule IDs and severity levels so N380 can aggregate without reading the reference file.

```yaml
artifact_schema_version: n170.v2.0.0
skill_name: security-risk-analysis
produced_event: produced.n170.security_threat_model.v2
blocker_mapping: B05
rule_results:
  - rule_id: R01_stride_6_letters_all
    severity: reject
    check: "STRIDE 6 个维度必须全扫"
    result: pass | warn | reject | not_applicable
  - rule_id: R02_compliance_obligations_mapped
    severity: reject
    check: "每个适用合规义务必须映射 control"
    result: pass | warn | reject | not_applicable
  - rule_id: R03_pii_inventory_complete
    severity: reject
    check: "PII/PCI/PHI 字段必须进入 inventory"
    result: pass | warn | reject | not_applicable
  - rule_id: R04_supply_chain_sbom
    severity: reject
    check: "生产系统必须要求 SBOM 或说明豁免"
    result: pass | warn | reject | not_applicable
  - rule_id: R05_ir_playbooks_for_critical
    severity: reject
    check: "每个 critical 威胁必须有 response playbook"
    result: pass | warn | reject | not_applicable
  - rule_id: R06_accepted_risk_signed
    severity: reject
    check: "accepted residual risk 必须 signer+rationale+expiry"
    result: pass | warn | reject | not_applicable
  - rule_id: R07_critical_threat_has_mitigation
    severity: reject
    check: "critical 威胁必须有 mitigation"
    result: pass | warn | reject | not_applicable
  - rule_id: R08_control_enforcement_verified
    severity: reject
    check: "每个缓解 critical/high 威胁的控制核实实现真强制执行而非占位桩(仅日志/无条件放行/空体/依赖缺失即放行/用可绕过代理代替权威查表:以角色名或标志位字符串匹配、缓存值、客户端传参、session 标志冒充对权威态的实时核验/注册装配代码被吞异常致安全强制点缺席而应用照常启动=注册期 fail-open 须 fail-fast 拒启动或告警/名义多因子第二因子与第一因子或触发同信道=双因子坍缩为单信道单因子 confused-deputy same-channel collapse),present-but-inert 按 missing 计入 residual risk"
    result: pass | warn | reject | not_applicable

route_back_to: none | n160 | n130
# none   — output complete; N180/N210/N260 may proceed
# n160   — data-model assumption fundamentally wrong; revise before task planning
# n130   — architectural choice incompatible with non-functional finding; escalate

eventbus_subscribers: [N330, N340]
# N330 → 技术与运维文档自动生成
# N340 → 协作知识沉淀
```
