# Example I/O: security-risk-analysis v2.1

## ex-001 · order API security threat model

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: security-risk-analysis
  workflow_node: N170
  node_artifact_target: 安全风险分析.md
  selected_mode: pre_launch_review
  readiness: ready
  model_id_pattern: "SEC-\\d{3,}"
  produced_event: produced.n170.security_threat_model.v2
  blocker_mapping: B05
  evidence_profile:
    confirmed: [AUTHZ-001, AUDIT-001, API-ORDER-CREATE, user_email pii]
    inferred: [public internet boundary]
    pending: [third-party vendor security review]
threat_model:
  model_id: SEC-001
  stride_analysis:
    S_spoofing:
      threats:
        - {threat_id: T-S-001, description: JWT 伪造冒充用户, attack_vector: weak signing or leaked key, likelihood: medium, impact: critical, mitigations: [{mitigation: RS256 + key rotation + short TTL, implemented: true}], residual_risk: low}
    T_tampering:
      threats:
        - {threat_id: T-T-001, description: audit_event 被篡改, attack_vector: DB update/delete, likelihood: low, impact: critical, mitigations: [{mitigation: AUDIT-001 append-only 4-tier, implemented: true}], residual_risk: low}
    R_repudiation:
      threats:
        - {threat_id: T-R-001, description: 操作方否认退款审批, attack_vector: missing audit reason, likelihood: medium, impact: high, mitigations: [{mitigation: mandatory audit reason + trace_id, implemented: true}], residual_risk: low}
    I_information_disclosure:
      threats:
        - {threat_id: T-I-001, description: IDOR 泄漏他人订单, attack_vector: modified order_id, likelihood: high, impact: high, mitigations: [{mitigation: AUTHZ-001 ownership ABAC check, implemented: true}], residual_risk: low}
    D_denial_of_service:
      threats:
        - {threat_id: T-D-001, description: repeated idempotency keys create Redis hot key, attack_vector: replay storm, likelihood: medium, impact: medium, mitigations: [{mitigation: rate limit + IDEM-001 conflict handling, implemented: true}], residual_risk: low}
    E_elevation_of_privilege:
      threats:
        - {threat_id: T-E-001, description: break-glass 权限被滥用, attack_vector: unreviewed elevation, likelihood: low, impact: critical, mitigations: [{mitigation: AUTHZ-001 dual approval + AUDIT-001 meta-audit, implemented: true}], residual_risk: low}
  domain_analysis:
    D1_compliance:
      regulations_applicable: [GDPR, SOC2]
      obligations: [{obligation: audit sensitive access, regulation_ref: SOC2 CC7, implementation_status: planned, evidence: AUDIT-001}]
    D2_security:
      controls: {authentication: JWT RS256, authorization: AUTHZ-001, encryption: {at_rest: true, in_transit: true, key_management: KMS}, input_validation: true, output_encoding: true}
    D3_privacy:
      pii_inventory:
        - {field: user_email, table: users, sensitivity: pii, purpose: notification, retention: 3years, subject_rights_supported: [access, delete, portability]}
      privacy_by_design: [data_minimization, purpose_limitation, storage_limitation, transparency]
    D4_operational:
      operational_security: {secret_management: KMS, patch_management: monthly + critical emergency, access_logging: true, incident_detection: SIEM, backup_recovery: tested quarterly, supply_chain: SBOM required}
  data_flow_security:
    - flow_ref: FLOW-ORDER-CREATE
      security_boundaries:
        - boundary_name: internet_to_api
          from_zone: internet
          to_zone: dmz
          crossing_controls: [{tls_version: TLS1.2+, mtls: false, authentication: JWT, rate_limit: per user + per IP}]
      data_classification_at_rest:
        at_each_step: [{step_number: 1, sensitivity: pii, protection: encrypted at rest + masked logs}]
  supply_chain_security:
    dependencies:
      third_party_libraries: {scanning_enabled: true, sca_tool: dependabot, update_policy: weekly, critical_cve_response: "< 24h"}
      base_images: {scanning_enabled: true, image_signing: true, registry_security: private registry}
      third_party_apis: [{vendor: payment_provider, security_review: false, contractual_obligations: [DPA], fallback_if_compromised: disable payment initiation}]
    build_security: {sbom_generated: true, signed_commits: true, protected_branches: true}
  incident_response:
    response_playbooks:
      - {incident_type: credential_leak, severity: p1, response_steps: [revoke tokens, rotate keys, investigate scope], communication_plan: legal + security + customer comms, recovery_steps: [force reset, deploy fixed config], post_mortem_required: true}
  risk_matrix:
    risks:
      - {threat_id: T-I-001, inherent_risk: high, mitigations_applied: [AUTHZ-001 ownership check], residual_risk: low, accepted_by: {signer: null, rationale: null, expiry: null}}
rule_results:
  - {rule_id: R01_stride_6_letters_all, status: pass, evidence: [S_spoofing, E_elevation_of_privilege]}
  - {rule_id: R04_supply_chain_sbom, status: pass, evidence: [sbom_generated]}
  - {rule_id: R06_accepted_risk_signed, status: not_applicable, evidence: [no accepted residual_risk]}
blocker_signals:
  - {blocker_id: B05, source_skill: security-risk-analysis, rule_id: R02_compliance_obligations_mapped, severity: warn, evidence: [payment_provider security_review: false], recommended_owner: security}
contract_appendix:
  id_prefix: SEC
  produced_event: produced.n170.security_threat_model.v2
  downstream_handoff:
    to_051_audit: [signature_mismatch, suspicious_activity, break_glass_invoked]
    to_N260_security_gate: [T-S-001, T-I-001, T-E-001]
```
