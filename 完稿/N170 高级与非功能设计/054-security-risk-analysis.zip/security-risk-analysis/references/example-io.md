# Example I/O: security-risk-analysis v2.1

## ex-001 · order API security threat model

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: security-risk-analysis
  workflow_node: N170
  node_artifact_target: 安全风险分析.md
  selected_mode: pre_launch_review
  readiness: ready
  model_id_pattern: "SEC-\\d{3,}"
  produced_event: produced.n170.security_threat_model.v2
  blocker_mapping: B05
  evidence_profile:
    confirmed: [AUTHZ-001, AUDIT-001, API-ORDER-CREATE, user_email pii]
    inferred: [public internet boundary]
    pending: [third-party vendor security review]
threat_model:
  model_id: SEC-001
  stride_analysis:
    S_spoofing:
      threats:
        - {threat_id: T-S-001, description: JWT 伪造冒充用户, attack_vector: weak signing or leaked key, likelihood: medium, impact: critical, mitigations: [{mitigation: RS256 + key rotation + short TTL, implemented: true}], residual_risk: low}
    T_tampering:
      threats:
        - {threat_id: T-T-001, description: audit_event 被篡改, attack_vector: DB update/delete, likelihood: low, impact: critical, mitigations: [{mitigation: AUDIT-001 append-only 4-tier, implemented: true}], residual_risk: low}
    R_repudiation:
      threats:
        - {threat_id: T-R-001, description: 操作方否认退款审批, attack_vector: missing audit reason, likelihood: medium, impact: high, mitigations: [{mitigation: mandatory audit reason + trace_id, implemented: true}], residual_risk: low}
    I_information_disclosure:
      threats:
        - {threat_id: T-I-001, description: IDOR 泄漏他人订单, attack_vector: modified order_id, likelihood: high, impact: high, mitigations: [{mitigation: AUTHZ-001 ownership ABAC check, implemented: true}], residual_risk: low}
    D_denial_of_service:
      threats:
        - {threat_id: T-D-001, description: repeated idempotency keys create Redis hot key, attack_vector: replay storm, likelihood: medium, impact: medium, mitigations: [{mitigation: rate limit + IDEM-001 conflict handling, implemented: true}], residual_risk: low}
    E_elevation_of_privilege:
      threats:
        - {threat_id: T-E-001, description: break-glass 权限被滥用, attack_vector: unreviewed elevation, likelihood: low, impact: critical, mitigations: [{mitigation: AUTHZ-001 dual approval + AUDIT-001 meta-audit, implemented: true}], residual_risk: low}
  domain_analysis:
    D1_compliance:
      regulations_applicable: [GDPR, SOC2]
      obligations: [{obligation: audit sensitive access, regulation_ref: SOC2 CC7, implementation_status: planned, evidence: AUDIT-001}]
    D2_security:
      controls: {authentication: JWT RS256, authorization: AUTHZ-001, encryption: {at_rest: true, in_transit: true, key_management: KMS}, input_validation: true, output_encoding: true}
    D3_privacy:
      pii_inventory:
        - {field: user_email, table: users, sensitivity: pii, purpose: notification, retention: 3years, subject_rights_supported: [access, delete, portability]}
      privacy_by_design: [data_minimization, purpose_limitation, storage_limitation, transparency]
    D4_operational:
      operational_security: {secret_management: KMS, patch_management: monthly + critical emergency, access_logging: true, incident_detection: SIEM, backup_recovery: tested quarterly, supply_chain: SBOM required}
  data_flow_security:
    - flow_ref: FLOW-ORDER-CREATE
      security_boundaries:
        - boundary_name: internet_to_api
          from_zone: internet
          to_zone: dmz
          crossing_controls: [{tls_version: TLS1.2+, mtls: false, authentication: JWT, rate_limit: per user + per IP}]
      data_classification_at_rest:
        at_each_step: [{step_number: 1, sensitivity: pii, protection: encrypted at rest + masked logs}]
  supply_chain_security:
    dependencies:
      third_party_libraries: {scanning_enabled: true, sca_tool: dependabot, update_policy: weekly, critical_cve_response: "< 24h"}
      base_images: {scanning_enabled: true, image_signing: true, registry_security: private registry}
      third_party_apis: [{vendor: payment_provider, security_review: false, contractual_obligations: [DPA], fallback_if_compromised: disable payment initiation}]
    build_security: {sbom_generated: true, signed_commits: true, protected_branches: true}
  incident_response:
    response_playbooks:
      - {incident_type: credential_leak, severity: p1, response_steps: [revoke tokens, rotate keys, investigate scope], communication_plan: legal + security + customer comms, recovery_steps: [force reset, deploy fixed config], post_mortem_required: true}
  risk_matrix:
    risks:
      - {threat_id: T-I-001, inherent_risk: high, mitigations_applied: [AUTHZ-001 ownership check], residual_risk: low, accepted_by: {signer: null, rationale: null, expiry: null}}
rule_results:
  - {rule_id: R01_stride_6_letters_all, status: pass, evidence: [S_spoofing, E_elevation_of_privilege]}
  - {rule_id: R04_supply_chain_sbom, status: pass, evidence: [sbom_generated]}
  - {rule_id: R06_accepted_risk_signed, status: not_applicable, evidence: [no accepted residual_risk]}
blocker_signals:
  - {blocker_id: B05, source_skill: security-risk-analysis, rule_id: R02_compliance_obligations_mapped, severity: warn, evidence: [payment_provider security_review: false], recommended_owner: security}
contract_appendix:
  id_prefix: SEC
  produced_event: produced.n170.security_threat_model.v2
  downstream_handoff:
    to_051_audit: [signature_mismatch, suspicious_activity, break_glass_invoked]
    to_N260_security_gate: [T-S-001, T-I-001, T-E-001]
```

## ex-002 · compliance_gap_analysis mode — GDPR + SOC2

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: security-risk-analysis
  selected_mode: compliance_gap_analysis
  readiness: provisional
  evidence_profile:
    confirmed: [AUTHZ-001, AUDIT-001, user_email_pii, order_amount_financial]
    inferred: [GDPR applicability — EU users inferred from product description]
    pending: [formal DPA review, penetration test results]

threat_model:
  model_id: SEC-002

  compliance_gap_analysis:
    GDPR:
      applicable: true
      rationale: "product serves EU customers; user_email is personal data"
      gaps:
        - gap_id: GDPR-GAP-001
          obligation: "Right to erasure (Art. 17) — user can request deletion of personal data"
          current_status: missing
          affected_tables: [users, audit_events]
          control_needed: "soft-delete + anonymization job; audit_events exempt (legitimate interest)"
          owner: backend-team
          remediation_deadline: Q2-2026
        - gap_id: GDPR-GAP-002
          obligation: "72h breach notification to supervisory authority"
          current_status: partial
          note: "incident playbook exists but does not mention DPA notification step"
          control_needed: "add DPA notification step to IR playbook"
          owner: compliance-team
          remediation_deadline: Q1-2026

    SOC2_CC7:
      applicable: true
      rationale: "enterprise customers require SOC2 Type II"
      gaps:
        - gap_id: SOC2-GAP-001
          obligation: "CC7.2 — system anomalies and security events are detected promptly"
          current_status: partial
          note: "SIEM configured but alert thresholds not tuned; AUDIT-001 events not yet forwarded to SIEM"
          control_needed: "forward audit_events to SIEM; tune alert thresholds for brute_force and privilege escalation"
          owner: sre-team
          remediation_deadline: Q1-2026

  supply_chain_security:
    sbom_generated: false
    waiver_reason: "SBOM tooling procurement in progress"
    remediation_deadline: Q2-2026
    current_state: "Dependabot enabled for direct dependency CVE alerts; transitive dependencies not tracked"
    action_plan: "Integrate Syft into CI pipeline; generate CycloneDX SBOM on every release build"

  risk_matrix:
    risks:
      - risk_id: RISK-001
        threat_id: T-I-001
        description: "IDOR — user accesses another user's order"
        inherent_risk: high
        mitigations: [AUTHZ-001 ownership ABAC]
        residual_risk: low
        accepted: false
      - risk_id: RISK-002
        threat_id: GDPR-GAP-001
        description: "GDPR right-to-erasure not implemented"
        inherent_risk: high
        mitigations: []
        residual_risk: high
        accepted: true
        accepted_by:
          signer: CTO
          rationale: "remediation in progress; low probability of enforcement action in Q1"
          expiry: 2026-06-30
```

## ex-003 · IR playbook — critical threat response

```yaml
# Required: every critical threat must have an IR playbook
incident_response:
  playbooks:
    - playbook_id: IR-001
      threat_ref: T-I-001   # IDOR — user accesses another user's order
      severity: critical
      detection:
        metric: "auth_denied_rate > 1% for 5 consecutive minutes OR anomalous_cross_user_access_detected"
        siem_rule: "correlation: same actor accessing >10 distinct order_ids not owned by actor within 1 minute"
        alert_destination: security-team PagerDuty + Slack #security-incidents

      response_steps:
        - step: 1
          action: "Immediately revoke all tokens for affected actor"
          owner: security-engineer on-call
          timeframe: "< 5 minutes after alert"
          command: "POST /admin/users/{actor_id}/revoke-all-tokens"

        - step: 2
          action: "Identify scope: query audit_events for all records accessed by actor in past 24h"
          owner: security-engineer on-call
          timeframe: "< 15 minutes"
          query: "SELECT DISTINCT target_id FROM audit_events WHERE actor_id = ? AND occurred_at > NOW() - INTERVAL 24 HOUR"

        - step: 3
          action: "Notify affected users via email that their data may have been accessed"
          owner: compliance-officer
          timeframe: "< 72 hours (GDPR Article 34 if personal data exposed)"
          template: gdpr_breach_notification_template_v2

        - step: 4
          action: "Post-mortem: identify how AUTHZ-001 ABAC check was bypassed; patch and regression test"
          owner: engineering-lead + security-engineer
          timeframe: "< 5 business days"

      communication_plan:
        internal: "Security incident channel + executive notification if >100 users affected"
        external: "GDPR supervisory authority if personal data exposed (72h deadline)"
        customer: "Direct email notification to affected users within 72h"

      post_mortem_required: true
      tabletop_exercise_frequency: quarterly
```

## ex-004 · negative cases — common threat model mistakes

```yaml
negative_cases:
  - case_id: NEG-054-001
    title: "Treating existing controls as complete without evidence"
    bad_pattern:
      stride_letter: I
      threat: "Information disclosure via API response"
      mitigation_claimed: "Authentication is implemented"
      problem: "Claiming auth 'is implemented' without evidence. IDOR can exist even with auth — different authenticated users can access each other's data."
    correct_pattern:
      stride_letter: I
      threat_id: T-I-001
      threat: "IDOR — authenticated user accesses another user's order via modified order_id"
      mitigation:
        - mitigation_id: M-001
          control: "AUTHZ-001 ownership ABAC check: subject.user_id == resource.owner_id"
          implemented: true
          evidence: "POL-001 in AUTHZ-001 with formal_expression verified by test TC-AUTHZ-001"
      residual_risk: low

  - case_id: NEG-054-002
    title: "Missing supply chain SBOM — violates R04"
    bad_pattern:
      supply_chain_security:
        sbom_generated: false
      problem: "No SBOM means no visibility into transitive dependency CVEs. R04 requires SBOM or explicit waiver."
    correct_pattern:
      supply_chain_security:
        sbom_generated: false
        waiver_reason: "SBOM tooling procurement approved but not yet deployed"
        remediation_deadline: "2026-06-30"
        current_mitigations: "Dependabot for direct deps; manual review for critical packages"
        action_plan: "Integrate Syft into CI by Q2 2026; generate CycloneDX SBOM on every release"
      rule_results:
        - {rule_id: R04_supply_chain_sbom, result: warn, evidence: "waiver accepted with deadline"}

  - case_id: NEG-054-003
    title: "Accepted residual risk without signer — violates R06"
    bad_pattern:
      risk_id: RISK-003
      residual_risk: high
      accepted: true
      problem: "High residual risk accepted but no signer, rationale, or expiry. Violates R06 — this becomes a permanent silent risk."
    correct_pattern:
      risk_id: RISK-003
      residual_risk: high
      accepted: true
      accepted_by:
        signer: CTO
        rationale: "GDPR right-to-erasure remediation in progress; low enforcement probability in Q1"
        expiry: "2026-06-30"
        review_trigger: "If enforcement action is initiated before expiry, immediately escalate"
```

## ex-005 · degraded — no authorization model, security analysis provisional

```yaml
skill_name: security-risk-analysis
readiness: provisional
selected_mode: stride_workshop
evidence_profile:
  confirmed: [TSA-001 architecture, API-001 through API-004 endpoints]
  inferred: [authorization controls assumed from domain — AUTHZ-001 not yet designed]
  pending: [052 authorization model, 051 audit schema, supply chain SBOM]

degraded_reason: "052 authorization-model-design not yet complete — E_elevation_of_privilege controls are inferred"
degraded_impact: "Elevation-of-privilege threats analyzed without confirmed authorization model; mitigations may change after 052 completes"

threat_model:
  stride_analysis:
    E_elevation_of_privilege:
      threats:
        - threat_id: T-E-001-PROVISIONAL
          description: "User accesses another user's leave ticket via modified ticket_id in URL"
          confidence: inferred
          assumed_control: "ABAC ownership check (assumed — not yet designed in 052)"
          risk_if_assumption_wrong: high
          note: "Re-assess after 052 authorization-model-design completes"

pending_confirmations:
  - "052 AUTHZ-001 design — E_elevation mitigations depend on it"
  - "051 audit schema — R_repudiation mitigations depend on append-only enforcement"
  - "SBOM generation — R04_supply_chain_sbom cannot be satisfied until SBOM tooling is deployed"

rule_results:
  - {rule_id: R01_stride_6_letters_all, result: pass}
  - {rule_id: R04_supply_chain_sbom, result: warn, evidence: "SBOM waiver active until Q2-2026"}
  - {rule_id: R05_ir_playbooks_for_critical, result: warn, evidence: "IR-001 provisional — finalize after 052"}
```

## ex-006 · blocked — architecture not stable enough for threat modeling

```yaml
skill_name: security-risk-analysis
readiness: blocked
blocker_mapping: B-N170-06
route_back_to: technical-solution-analysis

blockers:
  - blocker_id: BLK-SEC-001
    type: unstable_architecture
    description: "Technical solution analysis (038) has readiness: provisional with 3 unresolved FMEA items and architecture_three_states.to_be missing component boundaries"
    impact: "STRIDE requires stable trust boundaries (service A, service B, data store, external) — provisional architecture means threat model will need full rework after architecture is finalized"
    resolution_required: "038 must reach readiness: ready with stable component list before meaningful threat modeling"
    unblock_evidence: "038 output with readiness: ready and architecture_three_states.to_be.components fully defined"

  - blocker_id: BLK-SEC-002
    type: missing_data_classification
    description: "Cannot assess I_information_disclosure threats without knowing which fields contain PII, PCI, PHI"
    impact: "Information disclosure is one of 6 STRIDE dimensions — skipping it means R03_pii_inventory_complete will fail"
    resolution_required: "046 sensitivity classification OR DPO field inventory must be available"
    unblock_evidence: "pii_or_sensitive_fields[] from 046 OR DPO-provided field classification"

partial_output:
  stride_assessed: [S_spoofing, T_tampering, D_denial_of_service]
  stride_blocked: [I_information_disclosure (BLK-SEC-002), E_elevation (awaiting 052)]
  rule_results:
    - {rule_id: R01_stride_6_letters_all, result: reject, evidence: "I and E blocked"}
    - {rule_id: R03_pii_inventory_complete, result: reject, evidence: "BLK-SEC-002"}
```
