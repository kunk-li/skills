# V2 hard-gate checklist for security-risk-analysis

Use this checklist before finalizing any N170 output. Treat `reject` failures as blocking unless the output is explicitly marked `readiness: blocked` with pending evidence.

## Required metadata

- [ ] `artifact_schema_version: n170.v2.0.0` is present.
- [ ] Design IDs follow `SEC-###`.
- [ ] `produced_event: produced.n170.security_threat_model.v2` is present.
- [ ] `blocker_mapping: B05` is present.
- [ ] `confirmed / inferred / pending` evidence buckets are populated.

## Hard rules

- [ ] `R01_stride_6_letters_all` (reject): STRIDE 6 个维度必须全扫
- [ ] `R02_compliance_obligations_mapped` (reject): 每个适用合规义务必须映射 control
- [ ] `R03_pii_inventory_complete` (reject): PII/PCI/PHI 字段必须进入 inventory
- [ ] `R04_supply_chain_sbom` (reject): 生产系统必须要求 SBOM 或说明豁免
- [ ] `R05_ir_playbooks_for_critical` (reject): 每个 critical 威胁必须有 response playbook
- [ ] `R06_accepted_risk_signed` (reject): accepted residual risk 必须 signer + rationale + expiry
- [ ] `R07_critical_threat_has_mitigation` (reject): critical 威胁必须有 mitigation
- [ ] `R08_control_enforcement_verified` (reject): 每个缓解 critical/high 威胁的控制核实实现真强制执行而非占位桩(仅日志/无条件放行/空体/依赖缺失即放行/用可绕过代理代替权威查表:以角色名或标志位字符串匹配、缓存值、客户端传参、session 标志冒充对权威态的实时核验/注册装配被吞异常致执行点缺席仍照常启动=注册期 fail-open/名义多因子第二因子与第一因子或触发同信道致双因子坍缩为单信道单因子),present-but-inert 按 missing 计入 residual risk

## Cross-skill handoff

- [ ] `from_052_authorization` handoff is explicit: `authorization_model, SoD, break_glass, decision cache` -> E_elevation_of_privilege controls
- [ ] `from_051_audit` handoff is explicit: `append_only_enforcement, audit_event_schema, security events` -> R_repudiation and T_tampering mitigations
- [ ] `to_N230_security_test` handoff is explicit: `stride threats and risk_matrix` -> 攻击/安全测试场景
- [ ] `to_incident_response_team` handoff is explicit: `incident_response.response_playbooks` -> IR playbooks
