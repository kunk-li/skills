# Output template: security-risk-analysis v2

Start every answer with the following metadata block when producing a deliverable.

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: security-risk-analysis
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.security_risk_analysis
  node_artifact_target: 安全风险分析.md
  design_id_pattern: "SEC-\d{3,}"
  produced_event: produced.n170.security_threat_model.v2
  blocker_mapping: B05
  selected_mode: <mode>
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Required sections

- `threat_model.model_id: SEC-\d{3,}`
- `stride_analysis.S_spoofing through E_elevation_of_privilege, each with threats[].threat_id/likelihood/impact/mitigations/residual_risk`
- `domain_analysis.D1_compliance + D2_security + D3_privacy + D4_operational`
- `data_flow_security[]: flow_ref, security_boundaries, crossing_controls, data_classification_at_rest`
- `supply_chain_security.dependencies + build_security`
- `incident_response.detection + response_playbooks + tabletop_exercises`
- `risk_matrix.risks[] with inherent_risk, residual_risk, accepted_by.signer/rationale/expiry`
- `derived_from: vulnerabilities_ref, compliance_refs, decision_refs`

## Machine-readable appendix

At the end of the markdown report, include a compact YAML appendix containing stable IDs, rule results, blocker signals, and downstream handoff.

```yaml
contract_appendix:
  id_prefix: SEC
  produced_event: produced.n170.security_threat_model.v2
  blocker_mapping: B05
  rule_results:
    - rule_id: R01
      status: pass | warn | reject | not_applicable
      evidence: []
  downstream_handoff: []
```
