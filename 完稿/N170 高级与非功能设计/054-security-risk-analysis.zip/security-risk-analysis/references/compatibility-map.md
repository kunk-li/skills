# Compatibility map — security-risk-analysis v2 alignment

## Input artifact field mapping
| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 052 authorization-model-design | `authorization_model, SoD, break_glass, decision_cache` | `E_elevation_of_privilege controls` | authorization design → elevation threat controls |
| 051 audit-trail-design | `append_only_enforcement, audit_event_schema` | `R_repudiation, T_tampering controls` | audit controls → repudiation and tampering mitigations |
| 043 api-design-recommendation | `api_catalog[] with auth requirements` | `D2 security API surface` | API surface defines security threat entry points |

## Output artifact field mapping
| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| N230 security-test | `stride_threats, risk_matrix` | `security test scenarios` | STRIDE threats generate penetration and security test scenarios |
| incident response team | `response_playbooks` | `IR procedures` | playbooks delivered to on-call security team |
| N390 governance | `compliance_gap_analysis, risk_matrix` | `governance artifacts` | compliance gaps and residual risks feed platform governance |

## v2 contract cross-reference
| v2 field | Purpose | Consumer |
|---|---|---|
| `produced_event` | Event bus trigger | N330, N340 |
| `blocker_mapping` | SLA queue key | N380 |
| `rule_results[]` | Gate pass/warn/reject | N380 |
| `route_back_to` | Return path on gap | Upstream skill |
