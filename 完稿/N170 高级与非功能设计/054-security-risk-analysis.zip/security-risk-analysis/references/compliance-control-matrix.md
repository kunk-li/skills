# Compliance control matrix — security-risk-analysis

## Regulation × control × domain mapping

| Regulation | Scope trigger | Mandatory controls | D-domain | SLA / deadline |
|---|---|---|---|---|
| **GDPR** | EU/EEA persons' data | Lawful basis, consent, DPA, data subject rights, 72h breach notification | D3 | 72h breach → supervisory authority |
| **CCPA** | California residents' personal info | Right to know, right to delete, right to opt-out of sale, no discrimination | D3 | 45 days to respond to DSR |
| **PIPL** (中国个人信息保护法) | Chinese persons' data OR operations in China | Consent, purpose limitation, cross-border approval (CAC), data localization, DPO, 15-day breach | D3 | 15 days breach → CAC notification |
| **LGPD** (Brazil) | Brazilian persons' data | Consent, data subject rights, DPA, 2-day breach notification | D3 | 2 working days breach → ANPD |
| **PCI-DSS v4** | Card payment data | Network segmentation, encryption, access control, quarterly scan, penetration test | D2 | Annual assessment |
| **SOC 2 Type II** | SaaS / cloud services | CC7 anomaly detection, CC8 change management, CC9 risk mitigation | D2/D4 | Annual audit period |
| **HIPAA** | US health information | PHI encryption, BAA, access logs, breach notification <60d | D2/D3 | 60 days breach → HHS |
| **ISO 27001** | Information security management | Risk register, ISMS, periodic review, asset management | D1/D4 | Annual surveillance audit |
| **SOX** | US public companies / financial data | Audit trail for financial changes, access control, 7-year retention | D2/D4 | Annual external audit |
| **APRA CPS 234** | Australian regulated entities | Cyber resilience, board accountability, 72h incident notification | D1/D4 | 72h → APRA notification |

## Cross-border data transfer rules

| From / To | Mechanism required |
|---|---|
| EU → outside EU (non-adequate country) | SCCs (Standard Contractual Clauses), BCRs, or adequacy decision |
| China → outside China | CAC security assessment (>100k persons/year or sensitive data) |
| Brazil → outside Brazil | Equivalent protection + consent or contractual clauses |
| US (HIPAA) → outside US | BAA with recipient + equivalent safeguards |

## Breach notification decision tree

```
Data breach detected
├── Personal data involved?
│   ├── NO → internal incident only; no regulatory notification required
│   └── YES → Identify affected regulations:
│       ├── GDPR? → 72h to supervisory authority; notify users if high risk
│       ├── CCPA? → "expedient" notification (no hard deadline for authority); user notification required
│       ├── PIPL? → 15 days to CAC; immediate notification to affected persons
│       ├── HIPAA? → 60 days to HHS (if >500 affected, media notification too)
│       └── APRA? → 72h to APRA
└── Is it a "notifiable breach"?
    ├── GDPR: likely to result in risk to natural persons
    ├── CCPA: unencrypted + unauthorized access
    └── PIPL: causes or may cause harm to personal information rights
```

## Data subject rights response SLA

| Right | GDPR | CCPA | PIPL |
|---|---|---|---|
| Access / know | 1 month (extendable 2 more) | 45 days | 15 working days |
| Deletion | 1 month | 45 days | 15 working days |
| Portability | 1 month | N/A | 15 working days |
| Opt-out of sale | N/A | 15 business days (opt-out honored) | N/A |
