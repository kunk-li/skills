# N170 v2 integration map

Use this file whenever multiple N170 skills are executed together. N170 is not six isolated reports; it is one non-functional design package with typed handoffs.

## Run order

1. Run `concurrency-control-recommendation` and `authorization-model-design` first when their evidence exists.
2. Run `idempotency-design-recommendation` after concurrency, and `audit-trail-design` after authorization/data-flow evidence.
3. Run `performance-risk-analysis` after concurrency + idempotency assumptions are available.
4. Run `security-risk-analysis` last when possible, because it consumes authorization and audit controls.
5. If a required upstream skill is missing, mark the related fields as `inferred` or `pending`; do not fabricate references.

## Stable IDs

| skill | ID pattern | artifact | blocker |
| --- | --- | --- | --- |
| concurrency-control-recommendation | `CON-###` | `并发控制建议.md` | B01 |
| idempotency-design-recommendation | `IDEM-###` | `幂等设计建议.md` | B02 |
| authorization-model-design | `AUTHZ-###` | `权限模型设计.md` | B03 |
| performance-risk-analysis | `PERF-###` | `性能风险分析.md` | B04 |
| security-risk-analysis | `SEC-###` | `安全风险分析.md` | B05 |
| audit-trail-design | `AUDIT-###` | `审计留痕方案.md` | B06 |

## Field-level handoff contracts

| producer | consumer | producer fields | consumer fields |
| --- | --- | --- | --- |
| 049 concurrency | 050 idempotency | `concurrency_designs[].design_id`, `scenario_classification`, `locking_strategy`, `derived_test_scenarios` | `derived_from.concurrency_design_refs`, `concurrent_same_key`, `l1_down_l2_works` tests |
| 049 concurrency | 053 performance | `performance_impact`, `lock_contention_estimate`, `deadlock_analysis` | `bottleneck_analysis.B08_concurrency_contention`, `performance_test_plan` |
| 050 idempotency | 053 performance | `storage_strategy`, `ttl_decision`, `observability.metrics`, retry paths | `B05_database_bottleneck`, `B06_cache_bottleneck`, retry-storm capacity |
| 050 idempotency | 054 security | webhook replay windows, signature validation, key reuse behavior | replay threats, spoofing/tampering mitigations |
| 052 authorization | 051 audit | role assignment, permission denied/granted, delegation, break-glass | `mandatory_audit_categories.A02_authorization`, `access_control`, meta-audit |
| 052 authorization | 054 security | `authorization_model_type`, SoD, delegation, break-glass, decision cache | `E_elevation_of_privilege`, auth control gaps |
| 051 audit | 054 security | `append_only_enforcement`, `audit_event_schema`, security events | `T_tampering`, `R_repudiation`, forensic evidence controls |
| 054 security | 051 audit | security events and incident scenarios | `A07_security_events`, IR audit events |

## Aggregated N170 package

When the user asks for the whole N170 node output, aggregate artifacts in this order:

1. 并发控制设计 (049)
2. 幂等设计 (050)
3. 审计设计 (051)
4. 授权设计 (052)
5. 性能设计 (053)
6. 安全设计 (054)
7. Blocker 追溯矩阵: B01-B06, reject/warn rule failures, owner hints, and unresolved evidence.

## Event contract

Every N170 artifact should expose:

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  workflow_node: N170
  produced_event: produced.n170.<artifact_type>.v2
  blocker_mapping: B0x
  readiness: ready | provisional | blocked
```
