# Common failure modes for security risk analysis

## F1: mixing generic security advice with no threat frame
Symptom: the output lists random controls but never explains the actual threat categories.
Fix: choose a threat frame and apply it consistently.

## F2: treating existing controls as complete without evidence
Symptom: the design assumes auth, encryption, or logging already exist and work.
Fix: label controls as present, partial, assumed, or missing.

## F3: focusing only on prevention and ignoring detection and response
Symptom: the output lists controls but no incident scenarios or response needs.
Fix: add incident-response scenarios and detection hooks.

## F4: collapsing authorization and security into one vague section
Symptom: privilege boundaries are discussed loosely without naming the specific threat.
Fix: map privilege-escalation and bypass risks explicitly.

## F5: overclaiming compliance coverage
Symptom: the output states compliance is satisfied without input evidence.
Fix: speak only to alignment needs grounded in the provided materials.

## V2.1 contract failure modes

## F6: flat security checklist instead of STRIDE + D1-D4
Symptom: controls are listed without six STRIDE categories or four domain sections.
Fix: structure output under STRIDE and D1 compliance/D2 security/D3 privacy/D4 operational.

## F7: residual risk accepted without owner or expiry
Symptom: a high or accepted residual risk appears without signer, rationale, or expiry.
Fix: enforce R06; unsigned accepted risk becomes blocker B05.

## F8: ignoring 051/052 handoff
Symptom: privilege escalation or repudiation threats do not reference authorization and audit controls.
Fix: consume AUTHZ and AUDIT fields for elevation-of-privilege, tampering, and repudiation mitigations.

## F9: contract appendix drift
Symptom: the markdown narrative says one thing while `contract_appendix` exposes different IDs, rule results, or handoff fields.
Fix: reconcile narrative and appendix before finalizing; the appendix is what downstream automation consumes.

## F10: blocker without owner or remediation
Symptom: a warning or reject is emitted but no owner, evidence, or next action is named.
Fix: every `blocker_signals[]` item must include `recommended_owner`, evidence, and a remediation hint or pending evidence field.

## F11: counting a stubbed or placeholder control as a real mitigation
Symptom: a control named as a mitigation for a critical or high threat is, in the implementation, a stub — it only logs, returns pass/true/0 unconditionally, has an empty body, allows the action when a dependency is absent, is a TODO placeholder, or substitutes a bypassable proxy for an authoritative lookup (string-matching a role name or flag, trusting a cached value, a client-supplied parameter, or a session marker in place of a real-time check against the authoritative store) — so it enforces nothing real while appearing in the design as "present". The proxy-substitution variant is the most deceptive: the control looks like it validates (it has branching logic, is neither empty nor always-true), but it checks a signal the caller can forge rather than the authoritative state.
Fix: for every mitigation of a critical or high threat, verify the control actually enforces (rejects/blocks on the failure condition) rather than being present-but-inert; a stubbed, no-op, or always-pass control counts as missing and its threat is unmitigated — record it in residual risk, not as a satisfied control. This sharpens F2: "present" must mean "enforcing", not merely "exists in code".

## F12: a security enforcement point that silently fails to register at assembly time
Symptom: a control named as a mitigation for a critical/high threat (an auth/authz interceptor, guard, filter, or policy-enforcement point) is correct in its runtime logic, but its registration/wiring is allowed to silently fail — its dependency or component is resolved inside a swallowing try/catch (or a conditional-registration branch that defaults to "off" on missing dependency), so when that dependency is absent the enforcement point is never wired into the request path, yet the application still boots normally. The runtime check can be flawless and never run, because the object enforcing it does not exist in the chain. This is the assembly-time extension of F11: F11 catches a guard that is installed but inert; F12 catches a guard that is silently never installed while the app comes up green.
Fix: in risk accounting, treat a security enforcement point that is allowed to silently fail to register as missing, not present — its threat is unmitigated; record it in residual risk. Principle: a missing enforcement point at assembly time must crash startup or raise a loud, alarmed failure, never silently degrade to "skip and continue serving" (fail-fast, not fail-open). The structural detection of this pattern in code (auditing bootstrap/wiring for swallow-and-continue try/catch around enforcement-point registration) is the dead_guard family's domain — cross-reference it via the to_N210_code_review handoff rather than re-teaching the code scan here.

## F13: 名义多因子但第二因子与第一因子/触发同信道(假双因子)
Symptom: 设计声称 MFA/双因子,但第二因子(验证码/确认/挑战)经与第一因子或触发请求相同的信道送达/回收,或信道选择由不可信请求方可控参数(传输/method/header)决定——攻击者可强制走回同信道,两因子实际共用一条由同一方控制的信道,双因子坍缩为单信道单因子。
Fix: 第二因子必须走独立于第一因子与触发通道的带外信道(不同传输或不同端点),且信道选择不可由不可信请求方单方决定;否则该 MFA 按未生效计,等同单因子,记入 residual risk。F13 与 F11 同源——F11 是单控制 present-but-inert,F13 是多因子配齐却共信道、认证层的 present-but-inert。
