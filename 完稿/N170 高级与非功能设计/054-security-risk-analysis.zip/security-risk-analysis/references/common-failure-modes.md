# Common failure modes for security risk analysis

## F1: mixing generic security advice with no threat frame
Symptom: the output lists random controls but never explains the actual threat categories.
Fix: choose a threat frame and apply it consistently.

## F2: treating existing controls as complete without evidence
Symptom: the design assumes auth, encryption, or logging already exist and work.
Fix: label controls as present, partial, assumed, or missing.

## F3: focusing only on prevention and ignoring detection and response
Symptom: the output lists controls but no incident scenarios or response needs.
Fix: add incident-response scenarios and detection hooks.

## F4: collapsing authorization and security into one vague section
Symptom: privilege boundaries are discussed loosely without naming the specific threat.
Fix: map privilege-escalation and bypass risks explicitly.

## F5: overclaiming compliance coverage
Symptom: the output states compliance is satisfied without input evidence.
Fix: speak only to alignment needs grounded in the provided materials.

## V2.1 contract failure modes

## F6: flat security checklist instead of STRIDE + D1-D4
Symptom: controls are listed without six STRIDE categories or four domain sections.
Fix: structure output under STRIDE and D1 compliance/D2 security/D3 privacy/D4 operational.

## F7: residual risk accepted without owner or expiry
Symptom: a high or accepted residual risk appears without signer, rationale, or expiry.
Fix: enforce R06; unsigned accepted risk becomes blocker B05.

## F8: ignoring 051/052 handoff
Symptom: privilege escalation or repudiation threats do not reference authorization and audit controls.
Fix: consume AUTHZ and AUDIT fields for elevation-of-privilege, tampering, and repudiation mitigations.

## F9: contract appendix drift
Symptom: the markdown narrative says one thing while `contract_appendix` exposes different IDs, rule results, or handoff fields.
Fix: reconcile narrative and appendix before finalizing; the appendix is what downstream automation consumes.

## F10: blocker without owner or remediation
Symptom: a warning or reject is emitted but no owner, evidence, or next action is named.
Fix: every `blocker_signals[]` item must include `recommended_owner`, evidence, and a remediation hint or pending evidence field.

## F11: counting a stubbed or placeholder control as a real mitigation
Symptom: a control named as a mitigation for a critical or high threat is, in the implementation, a stub — it only logs, returns pass/true/0 unconditionally, has an empty body, allows the action when a dependency is absent, or is a TODO placeholder — so it enforces nothing while appearing in the design as "present".
Fix: for every mitigation of a critical or high threat, verify the control actually enforces (rejects/blocks on the failure condition) rather than being present-but-inert; a stubbed, no-op, or always-pass control counts as missing and its threat is unmitigated — record it in residual risk, not as a satisfied control. This sharpens F2: "present" must mean "enforcing", not merely "exists in code".
