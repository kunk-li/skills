# V2 orchestration for security-risk-analysis

## Execution modes

- Standalone: produce this skill artifact only. Use `readiness: provisional` when upstream fields are missing.
- N170 batch: use `references/n170-integration-map.md` and keep IDs stable across all six artifacts.
- Gate mode: emit reject/warn results from `references/v2-contract.md` rules and map them to the blocker ID.

## Input normalization

Normalize incoming file names into typed N170 evidence:

| field | required | from | purpose |
| --- | --- | --- | --- |
| `api_specs` | required | N150 | entrypoints and external exposure |
| `data_flows` | required | N160 | trust boundaries and data movement |
| `authorization_model` | required | 052 | 权限模型和提权面 |
| `data_objects` | required | N070 | PII/PCI/PHI tags |
| `vulnerabilities_from_N100` | optional | N100 | requirement vulnerability scan |
| `threat_intelligence` | optional | context | known threats or incident history |

## Output event

```yaml
event:
  produced: produced.n170.security_threat_model.v2
  schema_version: n170.v2.0.0
  artifact: 安全风险分析.md
  blocker_mapping: B05
```

## Field-level handoff for this skill

| link | fields | downstream use |
| --- | --- | --- |
| `from_052_authorization` | `authorization_model, SoD, break_glass, decision cache` | E_elevation_of_privilege controls |
| `from_051_audit` | `append_only_enforcement, audit_event_schema, security events` | R_repudiation and T_tampering mitigations |
| `to_N230_security_test` | `stride threats and risk_matrix` | 攻击/安全测试场景 |
| `to_incident_response_team` | `incident_response.response_playbooks` | IR playbooks |
