# N170 v2 contract: security-risk-analysis

安全风险：STRIDE 威胁建模、4 分域、data_flow_security、供应链安全、事故响应、残余风险签收。

## Metadata contract

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: security-risk-analysis
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.security_risk_analysis
  node_artifact_target: 安全风险分析.md
  design_id_pattern: "SEC-\\d{3,}"
  produced_event: produced.n170.security_threat_model.v2
  blocker_mapping: B05
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Input schema with workflow sources

| field | required | from | purpose |
| --- | --- | --- | --- |
| `api_specs` | required | N150 | entrypoints and external exposure |
| `data_flows` | required | N160 | trust boundaries and data movement |
| `authorization_model` | required | 052 | 权限模型和提权面 |
| `data_objects` | required | N070 | PII/PCI/PHI tags |
| `vulnerabilities_from_N100` | optional | N100 | requirement vulnerability scan |
| `threat_intelligence` | optional | context | known threats or incident history |

## Required output schema

- `threat_model.model_id: SEC-\d{3,}`
- `stride_analysis.S_spoofing through E_elevation_of_privilege, each with threats[].threat_id/likelihood/impact/mitigations/residual_risk`
- `domain_analysis.D1_compliance + D2_security + D3_privacy + D4_operational`
- `data_flow_security[]: flow_ref, security_boundaries, crossing_controls, data_classification_at_rest`
- `supply_chain_security.dependencies + build_security`
- `incident_response.detection + response_playbooks + tabletop_exercises`
- `risk_matrix.risks[] with inherent_risk, residual_risk, accepted_by.signer/rationale/expiry`
- `derived_from: vulnerabilities_ref, compliance_refs, decision_refs`
- `control_enforcement_verification[]: control_ref, enforcement_status (enforcing | stub_or_no_op | absent), evidence`（每个 critical/high 缓解控制核实真强制执行;stub_or_no_op 与 absent 一并计入 residual risk）

## Hard gate rules

| rule | check | on violation |
| --- | --- | --- |
| `R01_stride_6_letters_all` | STRIDE 6 个维度必须全扫 | `reject` |
| `R02_compliance_obligations_mapped` | 每个适用合规义务必须映射 control | `reject` |
| `R03_pii_inventory_complete` | PII/PCI/PHI 字段必须进入 inventory | `reject` |
| `R04_supply_chain_sbom` | 生产系统必须要求 SBOM 或说明豁免 | `reject` |
| `R05_ir_playbooks_for_critical` | 每个 critical 威胁必须有 response playbook | `reject` |
| `R06_accepted_risk_signed` | accepted residual risk 必须 signer + rationale + expiry | `reject` |
| `R07_critical_threat_has_mitigation` | critical 威胁必须有 mitigation | `reject` |
| `R08_control_enforcement_verified` | 每个用于缓解 critical/high 威胁的控制必须核实其实现真在强制执行而非占位/空操作/恒放行的桩(stub):仅记日志、无条件返回通过/真/0、空方法体、依赖缺失即放行、TODO 留空等都算未缓解;present-but-inert 的控制按 missing 计入 residual risk | `reject` |

## Algorithms and decision logic

- stride_threat_enumeration: for each asset/flow/boundary, enumerate S/T/R/I/D/E. Spoofing triggers on identity/token/session boundaries; Tampering on mutable state, audit, callbacks; Repudiation on approvals/financial/admin actions; Information disclosure on PII/PCI/PHI/export/search; Denial of service on hot endpoints, queues, locks, vendors; Elevation of privilege on role hierarchy, delegation, break-glass, policy bypass.
- domain_mapping_D1_D4: compliance obligations -> D1; authentication/authorization/encryption/validation/logging -> D2; PII inventory, purpose, retention, subject rights -> D3; secrets, patching, access logging, backup, supply chain -> D4.
- pii_discovery: data_objects + api_specs tags -> direct identifier/high, quasi identifier/medium, indirect/low; map purpose, retention and subject rights.
- residual_risk_calculation: inherent risk minus mitigation effectiveness; single control = low reduction, defense in depth = high reduction; accepted risk requires signer, rationale and expiry.
- incident_response_derivation: every critical threat must have detection metric, response playbook, communication plan, recovery steps and post-mortem requirement.

## Field-level handoff

| link | fields produced/consumed | downstream use |
| --- | --- | --- |
| `from_052_authorization` | `authorization_model, SoD, break_glass, decision cache` | E_elevation_of_privilege controls |
| `from_051_audit` | `append_only_enforcement, audit_event_schema, security events` | R_repudiation and T_tampering mitigations |
| `to_N230_security_test` | `stride threats and risk_matrix` | 攻击/安全测试场景 |
| `to_incident_response_team` | `incident_response.response_playbooks` | IR playbooks |

## Blocker and event output

```yaml
blocker_signal:
  blocker_id: B05
  source_skill: security-risk-analysis
  rule_id: Rxx
  severity: reject | warn
  evidence: []
  recommended_owner: product | engineering | qa | security | compliance
event:
  produced: produced.n170.security_threat_model.v2
  schema_version: n170.v2.0.0
```

## Minimal worked example

```yaml
model_id: SEC-001
stride_analysis.S_spoofing.threats[0].threat_id: T-S-001
stride_analysis.I_information_disclosure.threats[0].description: IDOR 泄漏他人订单
domain_analysis.D3_privacy.pii_inventory[0].field: user_email
data_flow_security[0].security_boundaries[0].crossing_controls.tls_version: TLS1.2+
supply_chain_security.build_security.sbom_generated: true
risk_matrix.risks[0].residual_risk: low
```

## Standalone behavior

When upstream evidence is missing, still produce a useful provisional artifact. Mark missing source fields as `pending`, inferred design as `inferred`, and hard-gate failures as `blocked` only when the missing evidence prevents a safe recommendation.