---
name: authorization-model-design
description: design authorization models with paradigm selection, pep/pdp architecture, sod, polp, and break-glass controls. triggers on 权限矩阵.csv.
---
# authorization-model-design


## PoLP quantification quick-reference
Least-privilege is not a principle unless it is measurable. Include these metrics in every AUTHZ output.

| Metric | Formula | Target | Action when exceeded |
|---|---|---|---|
| Permission density | `granted_permissions ÷ available_permissions` | < 0.3 for privileged roles | trigger access review |
| Dormant permission rate | `permissions unused > 90d ÷ total granted` | < 10% | quarterly auto-revoke |
| Role explosion index | count of custom roles | < 100 (warn), < 50 (ideal) | role consolidation review |
| SoD violation rate | active SoD conflicts ÷ total users | 0% | immediate revoke + audit |
| Over-privilege score | roles with > 2× median permissions | < 5% of users | role review |

## Policy combining algorithm quick-reference
When multiple policies or roles apply to a single request, the combining algorithm determines the outcome.

| Algorithm | Behavior | Use when |
|---|---|---|
| `deny_overrides` | any Deny wins regardless of Permit | security-critical; default for most systems |
| `permit_overrides` | any Permit wins regardless of Deny | permissive by default; rarely appropriate |
| `first_applicable` | first matching policy wins | ordered priority rules; predictable evaluation |
| `only_one_applicable` | exactly one policy must match | strict mode; errors on ambiguity |
| `priority_ordered` | policies evaluated by explicit priority number | fine-grained control over rule precedence |

**Recommendation**: use `deny_overrides` as default. Document any deviation as a policy exception with owner and rationale.

## Authorization paradigm quick-reference
| Model | Best for | Decision input | Complexity |
|---|---|---|---|
| RBAC | role-based org structure, simple permissions | subject's role → allowed actions | low |
| ABAC | context-aware, dynamic policies | subject + resource + environment attributes | medium |
| ReBAC | relationship graph, social/org hierarchy | subject → resource relationship path | high |
| PBAC | policy-as-code, audit-first | code-defined policy rules | medium–high |
| Hybrid | mixed requirements | combination of above | context-dependent |

**Selection rule**: start with RBAC; upgrade to ABAC when attribute-based conditions appear; use ReBAC when relationships determine access (e.g. "can edit if team member of resource owner").

## PDP/PEP/PIP/PAP architecture quick-reference
| Component | Role | Lives where |
|---|---|---|
| PEP (Policy Enforcement Point) | intercepts request, calls PDP | API gateway / service middleware |
| PDP (Policy Decision Point) | evaluates policy, returns permit/deny | centralized service or sidecar |
| PIP (Policy Information Point) | provides attributes to PDP | user service, resource service |
| PAP (Policy Administration Point) | manages policy definitions | admin UI / policy-as-code repo |

**PoLP rule**: every role/policy must declare the minimum required permissions. Quantify: `effective_permissions_count ÷ available_permissions_count` should be < 0.3 for privileged roles.

## Special controls quick-reference
| Control | Purpose | Required when |
|---|---|---|
| SoD (Separation of Duties) | prevent single actor from completing sensitive action | financial, compliance workflows |
| Break-glass | emergency override with mandatory audit | on-call, incident response |
| Delegation | grant subset of own permissions to another | approval workflows, temp access |
| TTL on delegation | automatic expiry of granted permissions | any time-limited access |


## Trigger conditions
Design authorization models when any of the following are present:
- `权限矩阵.csv` from N070
- N130 technical solution with access control requirements
- N150 API surfaces identifying protected operations
- explicit authorization model design requests

## Standalone rule
Use `selected_mode: paradigm_analyzer` as default — select RBAC/ABAC/ReBAC/PBAC/hybrid first before designing policies. Without permission matrix, infer roles from domain language and flag as `confidence: inferred`.

## Role and boundary
本 skill 对齐 skills_workflow 中in the technical-solution-design -> 高级设计 -> 权限模型设计」. It is a **direct_result** skill: the goal is to produce a concrete 角色、资源、动作、属性、裁决逻辑与策略生命周期落成可交付的 **`权限模型设计.md`**，而不是只给一个 RBAC 表格。

### Boundary
- 负责选择授权范式、定义策略裁决算法、划分 PDP / PEP / PIP / PAP、设计委托与策略生命周期。
- 负责把 `权限矩阵.csv` 与上下文约束转成可执行的授权模型。
- 不替代安全威胁建模，但要为权限提升、越权与代理授权提供结构化基础。
- 不替代审计留痕，但要指出哪些授权决策与策略变更必须入审计。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- stable ID following `AUTHZ-###`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `paradigm_analyzer`：优先决定 RBAC / ABAC / ReBAC / hybrid；默认模式。
- `policy_architecture`：重点输出 PDP / PEP / PIP / PAP 架构与裁决链路。
- `delegation_hardening`：重点处理委托、代理、临时权限和策略生命周期。

## Primary inputs
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `permissions(N070), business_rules(N070), state_machines(N070), data_flows(N160), organizational_structure(optional)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule
即使只有权限矩阵、角色说明与技术方案，也可以单独使用。

降级规则：
- 若资源或动作模型不完整，可先输出 provisional authorization matrix。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的角色、资源、属性与策略。
- 不得用“管理员全权限”掩盖未建模的权限边界。

## Core output contract
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `权限模型设计.md`
- primary output object: `authorization_model`
- stable ID: `AUTHZ-###`
- event: `produced.n170.authorization_model.v2`
- blocker: `B03`
- stage: `technical_solution_design.advanced_design.authorization_model_design`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: RBAC/ABAC/ReBAC/PBAC/hybrid 模型选择、SoD、delegation TTL、break-glass、PoLP 量化、授权性能目标、授予上限不变式（授出权限集合 ⊆ 授予方自身可授出集合，防越级自封提权）、主体终止/暂停态转换的全能力面原子吊销和资源实例级属主校验（can-call≠can-access-this-instance,防 IDOR/BOLA）.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R11 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B03` blocker signal.

## Execution workflow
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `authorization_model`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_051_audit, to_054_security, to_N190_controller, to_N200_dto, to_N230_permission_test`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness
- 单业务域：覆盖全部角色、资源、动作与关键属性
- 中型系统：覆盖多租户、字段可见性、关键代理场景
- 大型平台：聚焦策略裁决架构、委托治理与生命周期控制

## Quality bar
合格结果应让实现、测试与治理团队明确知道“谁能对什么做什么，在什么条件下做，以及策略如何演进”。

## Reference files
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`

## v2 additions: N005 feedback signal and N070 upstream linkage

```yaml
feedback_signal_to_n005:
  signal_type: none | privilege_escalation_signal | authorization_gap_pattern
  summary: ""
  target_n070_skills:
  - 016-permission-matrix-extraction
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
```

### Upstream linkage from N070 (primary source — consume before designing)

| upstream artifact | consume fields | maps to |
|---|---|---|
| 权限矩阵.csv (016) | PERM-* subject_kind, grain, channel, evaluation_algo, relational_constraint[], delegation | authorization model paradigm selection, policy rules, PEP/PDP design |
| 业务规则清单.md (014) | rule_semantic: compliance, deny priorities | deny-override rules, compliance policy layer |
| 状态转移图.md (015) | SM-* state-dependent transitions, actor | context-aware access rules |
| 数据对象目录.md (017) | constraint_tags: regulated, pii, constraint_tags: audit_required | resource sensitivity tiers |

## v2 SKILL.md contract — inline rule_results (authoritative for N380 scanning)

Full rule definitions are in `references/v2-contract.md`.
This block exposes rule IDs and severity levels so N380 can aggregate without reading the reference file.

```yaml
artifact_schema_version: n170.v2.0.0
skill_name: authorization-model-design
produced_event: produced.n170.authorization_model.v2
blocker_mapping: B03
rule_results:
  - rule_id: R01_model_type_justified
    severity: reject
    check: "模型选择必须有 rationale"
    result: pass | warn | reject | not_applicable
  - rule_id: R02_sod_constraints_declared
    severity: reject
    check: "敏感操作必须声明 SoD 约束或说明不适用"
    result: pass | warn | reject | not_applicable
  - rule_id: R03_delegation_has_ttl
    severity: reject
    check: "委托/代理必须有 ttl 或 valid_until"
    result: pass | warn | reject | not_applicable
  - rule_id: R04_break_glass_has_monitoring
    severity: reject
    check: "break-glass 必须监控、告警和 post-review"
    result: pass | warn | reject | not_applicable
  - rule_id: R05_polp_targets_set
    severity: reject
    check: "PoLP 必须有量化目标和清理周期"
    result: pass | warn | reject | not_applicable
  - rule_id: R06_role_hierarchy_depth_limit
    severity: warn
    check: "角色继承深度应小于 5，超过必须告警"
    result: pass | warn | reject | not_applicable
  - rule_id: R07_auth_perf_target
    severity: reject
    check: "授权决策必须有 p99 延迟目标和缓存失效策略"
    result: pass | warn | reject | not_applicable
  - rule_id: R08_grant_ceiling_enforced
    severity: reject
    check: "每个授予/改派/角色变更点声明授予上限不变式:授出权限集合 ⊆ 授予方自身可授出集合(等级/范围模型即授予方等级 ≥ 被授等级且被授范围 ⊆ 授予方范围,能力模型即仅授出自身显式持有且可再授的权限,列举非穷尽;端点 can-call 鉴权门不计入授予上限)并定义违反时的拒绝行为;本规则只管授予量级、资源端点实例属主校验属 R10"
    result: pass | warn | reject | not_applicable
  - rule_id: R09_lifecycle_full_revocation
    severity: reject
    check: "主体终止/暂停态转换必须枚举并原子吊销其全部能力面（例如次要/代理角色、已委托授出的授予、长期令牌/会话、二次验证登记、渠道访问 等，列举非穷尽）；任一终止态遗留任一、或可逆暂停态遗留具备写/资金/特权的能力面即 reject；可逆暂停态仅保留只读(无写/资金/特权)渠道不算遗留;范围门:终止吊销须是已 committed 需求才判缺陷,PRD 本期不做则 not_applicable 降底座残留"
    result: pass | warn | reject | not_applicable
  - rule_id: R10_resource_owner_enforcement
    severity: reject
    check: "每个针对具体资源实例的操作端点(读/改/删/取消/重试)校验调用者拥有或被授权访问该具体实例,而非仅能调用该操作类型(can-call≠can-access-this-instance);仅凭 id 取实例不比对 owner/租户/项目归属=IDOR/BOLA 越权"
    result: pass | warn | reject | not_applicable
  - rule_id: R11_default_deny_coverage
    severity: reject
    check: "授权边界的缺省裁决必须是 default-deny(allowlist 收口):无任何 allow 策略命中时一律拒绝。判定按『未列出端点的去向』而非数据结构名——某清单是否合规取决于不在清单内的端点最终是受约束(allowlist,合规)还是放行(default-allow,reject):依赖『端点须主动携带约束标记(注解/装饰器/配置项)才受限、缺标记即不受限』的 opt-in 收口,或『以黑名单/排除清单收口、未命中即放行』的 default-allow 反模式,均 reject;而在 permit 侧显式枚举的豁免(如显式 anonymous-allowed 列表放行某只读公开端点、写端点仍 default-deny)不算反模式。设计须给覆盖证明而非单点证明:列出全部可达的敏感/写/特权操作端点全集,证明其 ⊆ 受约束集合(覆盖率应 100%),并声明新增/改名端点默认落入受约束侧。本规则管『缺省方向 + 受约束集合是否覆盖全部该约束的端点』;『多条已匹配策略冲突谁赢』属 combining-algorithm,『单个约束实现是否正确/真生效』属 R08/R09/R10 与 054-R08,不在本规则。"
    result: pass | warn | reject | not_applicable

route_back_to: none | n150 | n130
# none   — output complete; N180/N210/N260 may proceed
# n160   — data-model assumption fundamentally wrong; revise before task planning
# n130   — architectural choice incompatible with non-functional finding; escalate

eventbus_subscribers: [N330, N340]
# N330 → 技术与运维文档自动生成
# N340 → 协作知识沉淀
```
