---
name: authorization-model-design
description: design authorization models from technical solution notes, vulnerability findings, schema drafts, permission matrices, api surfaces, and contextual access requirements. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 权限模型设计.md for n170 before task planning, implementation, permission testing, or governance review.
---
# authorization-model-design

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 权限模型设计」。

它是 **direct_result** 型技能：目标是把角色、资源、动作、属性、裁决逻辑与策略生命周期落成可交付的 **`权限模型设计.md`**，而不是只给一个 RBAC 表格。

### Boundary / 边界
- 负责选择授权范式、定义策略裁决算法、划分 PDP / PEP / PIP / PAP、设计委托与策略生命周期。
- 负责把 `权限矩阵.csv` 与上下文约束转成可执行的授权模型。
- 不替代安全威胁建模，但要为权限提升、越权与代理授权提供结构化基础。
- 不替代审计留痕，但要指出哪些授权决策与策略变更必须入审计。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- `artifact_schema_version: n170.v2.0.0`
- stable ID following `AUTHZ-###`
- `produced_event: produced.n170.authorization_model.v2`
- `blocker_mapping: B03`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `paradigm_analyzer`：优先决定 RBAC / ABAC / ReBAC / hybrid；默认模式。
- `policy_architecture`：重点输出 PDP / PEP / PIP / PAP 架构与裁决链路。
- `delegation_hardening`：重点处理委托、代理、临时权限和策略生命周期。

## Primary inputs / 主要输入
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `permissions(N070), business_rules(N070), state_machines(N070), data_flows(N160), organizational_structure(optional)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule / 独立使用规则
即使只有权限矩阵、角色说明与技术方案，也可以单独使用。

降级规则：
- 若资源或动作模型不完整，可先输出 provisional authorization matrix。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的角色、资源、属性与策略。
- 不得用“管理员全权限”掩盖未建模的权限边界。

## Core output contract / 核心输出契约
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `权限模型设计.md`
- primary output object: `authorization_model`
- stable ID: `AUTHZ-###`
- event: `produced.n170.authorization_model.v2`
- blocker: `B03`
- stage: `technical_solution_design.advanced_design.authorization_model_design`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules / 设计规则
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: RBAC/ABAC/ReBAC/PBAC/hybrid 模型选择、SoD、delegation TTL、break-glass、PoLP 量化和授权性能目标.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R07 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B03` blocker signal.

## Execution workflow / 执行流程
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `authorization_model`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_051_audit, to_054_security, to_N190_controller, to_N200_dto, to_N230_permission_test`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness / 动态完整度
- 单业务域：覆盖全部角色、资源、动作与关键属性
- 中型系统：覆盖多租户、字段可见性、关键代理场景
- 大型平台：聚焦策略裁决架构、委托治理与生命周期控制

## Quality bar / 质量门槛
合格结果应让实现、测试与治理团队明确知道“谁能对什么做什么，在什么条件下做，以及策略如何演进”。

## Reference files / 参考文件
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
