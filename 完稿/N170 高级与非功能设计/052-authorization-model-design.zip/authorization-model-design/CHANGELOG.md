# CHANGELOG

## v4.2.0 (2026-06-23) — R11_default_deny_coverage(default-deny 缺省姿态 + 覆盖完整性)

_skill: authorization-model-design_

### Added
- R11_default_deny_coverage (reject):授权边界缺省裁决须 default-deny/allowlist 收口,判定按未列出端点去向(非数据结构名),禁 opt-in-annotation 漏贴不受限与 blacklist 未命中放行两类 default-allow;须给覆盖证明(可达敏感写端点全集 ⊆ 受约束集)。落点:SKILL.md rule + v2-contract(Hard gate + output schema)+ checklist + common-failure F14。
- 来源:D-039 验证循环反查 OA 团队修改挖出的 skill 漏检盲区(@Scope 漏贴/黑名单收口);经对抗 verify 全库核过 R01-R10+combining-algorithm+054-R08 均不覆盖、真新颖,refine 收紧为 omission-direction 判定避免误伤 permit 侧豁免。

---


## v4.1.1 (2026-06-17) — cross-domain dogfood refinements (D-035)

_skill: authorization-model-design_

### Added
- R10_resource_owner_enforcement (reject): resource-instance operation endpoints must enforce instance-level ownership/authorization (can-call != can-access-this-instance) — IDOR/BOLA; surfaced by cross-domain dogfood validation
- common-failure-modes F13 (IDOR/BOLA)

### Changed
- R08_grant_ceiling narrowed to grant-magnitude only (resource-instance owner checks moved to R10)
- R09_lifecycle scope-gated (rule_not_applicable when PRD scopes the capability out-of-phase)
- rule_results range widened to R01-R10

---

## v4.1.0 (2026-06-17) — demand-pull systemic-defect rules

_skill: authorization-model-design_

### Added
- R08_grant_ceiling_enforced (reject): grant/reassign/role-change points must enforce a grant-ceiling invariant (granted privileges subset of grantor's own grantable set); the can-call gate and the what-can-be-granted ceiling are two separate checks
- R09_lifecycle_full_revocation (reject): terminal/suspended lifecycle-state transitions must atomically revoke every capability surface a subject holds
- common-failure-modes F11 (who-can-call != what-can-be-granted) and F12 (residual capability surfaces on termination)
- Required-output-schema fields: grant_operations[].grant_ceiling_invariant, lifecycle_revocation

### Changed
- rule_results range widened to R01-R09 in SKILL.md inline contract

---

## v4.0.0 (2026-04-30) — v10 final optimization

_skill: authorization-model-design_

### Added
- Trigger conditions + Standalone rule sections
- Confidence discipline (confirmed/inferred/pending separation)
- Downstream handoff summary
- Compatibility-map.md with field-level input/output mapping
- blocked + degraded example-io scenarios

### Changed
- Description trimmed to ≤25 words
- Quick-reference tables expanded to ≥4 per skill
- rule_results expanded to R01-R08

### Fixed
- CHANGELOG format standardized to `# CHANGELOG` header
- Chinese/English section headers unified to English

---

## v3.0.0 (2026-04-30) — v5 optimization batch

### Added
- common-failure-modes.md with Symptom/Fix format (F1–F8)
- workflow-position.md
- compatibility-map.md
- CHANGELOG.md

### Changed
- Checklist rewritten with inline `- [ ]` items
- example-io.md expanded with concrete YAML examples
- Description word count reduced

---

## v2.0.0 (2026-01-15) — v2 contract migration

### Added
- artifact_schema_version header
- produced_event field
- blocker_mapping field
- rule_results[] with pass|warn|reject|not_applicable
- feedback_signal_to_n005 reverse governance channel

---

## v1.0.0 (2025-10-01) — initial release
