# CHANGELOG

## v4.1.1 (2026-06-17) — cross-domain dogfood refinements (D-035)

_skill: authorization-model-design_

### Added
- R10_resource_owner_enforcement (reject): resource-instance operation endpoints must enforce instance-level ownership/authorization (can-call != can-access-this-instance) — IDOR/BOLA; surfaced by cross-domain dogfood validation
- common-failure-modes F13 (IDOR/BOLA)

### Changed
- R08_grant_ceiling narrowed to grant-magnitude only (resource-instance owner checks moved to R10)
- R09_lifecycle scope-gated (rule_not_applicable when PRD scopes the capability out-of-phase)
- rule_results range widened to R01-R10

---

## v4.1.0 (2026-06-17) — demand-pull systemic-defect rules

_skill: authorization-model-design_

### Added
- R08_grant_ceiling_enforced (reject): grant/reassign/role-change points must enforce a grant-ceiling invariant (granted privileges subset of grantor's own grantable set); the can-call gate and the what-can-be-granted ceiling are two separate checks
- R09_lifecycle_full_revocation (reject): terminal/suspended lifecycle-state transitions must atomically revoke every capability surface a subject holds
- common-failure-modes F11 (who-can-call != what-can-be-granted) and F12 (residual capability surfaces on termination)
- Required-output-schema fields: grant_operations[].grant_ceiling_invariant, lifecycle_revocation

### Changed
- rule_results range widened to R01-R09 in SKILL.md inline contract

---

## v4.0.0 (2026-04-30) — v10 final optimization

_skill: authorization-model-design_

### Added
- Trigger conditions + Standalone rule sections
- Confidence discipline (confirmed/inferred/pending separation)
- Downstream handoff summary
- Compatibility-map.md with field-level input/output mapping
- blocked + degraded example-io scenarios

### Changed
- Description trimmed to ≤25 words
- Quick-reference tables expanded to ≥4 per skill
- rule_results expanded to R01-R08

### Fixed
- CHANGELOG format standardized to `# CHANGELOG` header
- Chinese/English section headers unified to English

---

## v3.0.0 (2026-04-30) — v5 optimization batch

### Added
- common-failure-modes.md with Symptom/Fix format (F1–F8)
- workflow-position.md
- compatibility-map.md
- CHANGELOG.md

### Changed
- Checklist rewritten with inline `- [ ]` items
- example-io.md expanded with concrete YAML examples
- Description word count reduced

---

## v2.0.0 (2026-01-15) — v2 contract migration

### Added
- artifact_schema_version header
- produced_event field
- blocker_mapping field
- rule_results[] with pass|warn|reject|not_applicable
- feedback_signal_to_n005 reverse governance channel

---

## v1.0.0 (2025-10-01) — initial release
