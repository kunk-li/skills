# N170 v2 contract: authorization-model-design

授权模型：RBAC/ABAC/ReBAC/PBAC/hybrid 决策树、SoD、委托、Break-glass、PoLP 量化、授权性能目标。

## Metadata contract

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: authorization-model-design
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.authorization_model_design
  node_artifact_target: 权限模型设计.md
  design_id_pattern: "AUTHZ-\\d{3,}"
  produced_event: produced.n170.authorization_model.v2
  blocker_mapping: B03
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Input schema with workflow sources

| field | required | from | purpose |
| --- | --- | --- | --- |
| `permissions` | required | N070/permission-matrix-extraction | 角色/资源/动作矩阵 |
| `business_rules` | required | N070 | 授权规则和职责分离 |
| `state_machines` | required | N070 | 状态相关权限 |
| `data_flows` | required | N160 | 跨服务授权执行点 |
| `organizational_structure` | optional | context | 部门/层级/汇报关系 |

## Required output schema

- `authorization_model.design_id: AUTHZ-\d{3,}`
- `authorization_model_type.primary_model: rbac | abac | rebac | pbac | hybrid + auxiliary_models + model_justification`
- `rbac_design.roles + role_hierarchy + separation_of_duties_constraints`
- `abac_design.attribute_categories + policies`
- `rebac_design.enabled + object_types + tuples_example`
- `delegation_model.supported + delegation_types + token_based_delegation`
- `break_glass.supported + scenarios.activation + monitoring + deactivation`
- `principle_of_least_privilege.metrics + periodic_reviews`
- `authorization_evaluation.performance_target + caching_strategy + centralized_vs_distributed`
- `grant_operations[].grant_ceiling_invariant: granted_privileges ⊆ grantor_grantable_set`（等级/范围模型即 grantor_max_level >= granted_level AND granted_scope ⊆ grantor_scope；能力型模型即仅授出自身显式持有且可再授的权限，列举非穷尽） + on_violation_behavior: reject
- `lifecycle_revocation.capability_surfaces[] (non-exhaustive enumeration) + terminal_states[] + atomic_revocation_per_state`（枚举主体全部能力面，为每个终止/暂停态转换声明全部能力面被原子 all-or-nothing 吊销，无可遗留任一能力面的终止态）
- `resource_operations[].instance_level_ownership_check: enforced | missing`（每个 owner/租户/项目-scoped 资源的实例级操作端点须服务端强制实例属主/授权校验,can-call≠can-access-this-instance,防 IDOR/BOLA）

## Hard gate rules

| rule | check | on violation |
| --- | --- | --- |
| `R01_model_type_justified` | 模型选择必须有 rationale | `reject` |
| `R02_sod_constraints_declared` | 敏感操作必须声明 SoD 约束或说明不适用 | `reject` |
| `R03_delegation_has_ttl` | 委托/代理必须有 ttl 或 valid_until | `reject` |
| `R04_break_glass_has_monitoring` | break-glass 必须监控、告警和 post-review | `reject` |
| `R05_polp_targets_set` | PoLP 必须有量化目标和清理周期 | `reject` |
| `R06_role_hierarchy_depth_limit` | 角色继承深度应小于 5，超过必须告警 | `warn` |
| `R07_auth_perf_target` | 授权决策必须有 p99 延迟目标和缓存失效策略 | `reject` |
| `R08_grant_ceiling_enforced` | 每个授予/改派/角色变更点必须声明「授予上限不变式」——授出的权限集合 ⊆ 授予方自身可授出的权限集合（等级/范围型模型即「授予方等级 ≥ 被授等级 且 被授范围 ⊆ 授予方范围」，能力/授予选项型模型即「仅可授出自身显式持有且标记为可再授的权限」，列举非穷尽）——并定义违反时的拒绝行为（本规则只管授予的权限量级是否超授予方自身可授集;『资源操作端点是否校验调用者拥有该具体资源实例』属 R10_resource_owner_enforcement、不在本规则） | `reject` |
| `R09_lifecycle_full_revocation` | 必须枚举主体可持有的全部能力面（例如：次要/代理角色、本主体已委托授出的授予、长期令牌/会话、二次验证登记、特定渠道访问 等，列举非穷尽），并为每个终止/暂停生命周期态转换声明全部能力面被原子（all-or-nothing）吊销；任一终止态遗留某未吊销能力面、或任一可逆暂停态遗留具备写/资金/特权的未吊销能力面，即 reject；可逆暂停（非终止）态仅保留只读且不含写/资金/特权的渠道（如只读申诉/查询）不算遗留（范围门:仅当『主体终止须吊销该能力面』是已 committed 需求时才判缺陷;PRD 明示该协作/多主体/能力本期不实现则判 not_applicable 并降为底座残留、不当确诊） | `reject` |
| `R10_resource_owner_enforcement` | 每个针对具体资源实例的操作端点（读/改/删/取消/重试等）必须校验调用者拥有或被授权访问『该具体实例』、而非仅校验其能调用该操作类型（can-call ≠ can-access-this-instance）:仅凭 id 取实例操作而不比对实例 owner/租户/项目归属 = 越权访问（IDOR/BOLA）;owner-based 资源必须服务端强制实例级属主校验 | `reject` |

## Algorithms and decision logic

- model_selection_decision_tree: roles < 20 and relationships simple -> rbac; complex context/time/device -> abac or hybrid; collaboration/share graph -> rebac; policy-as-code/frequent regulation -> pbac; large system -> hybrid.
- sod_detection: patterns include approver != requester, initiator != verifier, cannot approve and execute same transaction.
- polp_audit: monthly/quarterly scan permissions top 20, >90-day dormant permissions, high-overlap roles and over-privileged users.

## Field-level handoff

| link | fields produced/consumed | downstream use |
| --- | --- | --- |
| `to_051_audit` | `role assignment, permission denied/granted, delegation, break_glass` | A02 authorization audit events |
| `to_054_security` | `authorization_model_type, SoD, break_glass, decision cache` | elevation_of_privilege threats and controls |
| `to_N200_dto` | `field-level policies and masking decisions` | DTO/VO response masking |
| `to_N260_permission_test` | `SoD/delegation/break-glass decision_examples` | 权限专项测试点 |

## Blocker and event output

```yaml
blocker_signal:
  blocker_id: B03
  source_skill: authorization-model-design
  rule_id: Rxx
  severity: reject | warn
  evidence: []
  recommended_owner: product | engineering | qa | security | compliance
event:
  produced: produced.n170.authorization_model.v2
  schema_version: n170.v2.0.0
```

## Minimal worked example

```yaml
design_id: AUTHZ-001
authorization_model_type.primary_model: hybrid
authorization_model_type.auxiliary_models: [rbac, abac]
rbac_design.roles[0].role_id: ROLE-CS-AGENT
abac_design.policies[0].formal_expression: subject.user_id == resource.owner_id
separation_of_duties_constraints[0].description: 审批人不可同时是申请人
break_glass.scenarios[0].activation.approval_required: dual_approver
principle_of_least_privilege.metrics.dormant_permissions.target: < 10%
```

## Standalone behavior

When upstream evidence is missing, still produce a useful provisional artifact. Mark missing source fields as `pending`, inferred design as `inferred`, and hard-gate failures as `blocked` only when the missing evidence prevents a safe recommendation.