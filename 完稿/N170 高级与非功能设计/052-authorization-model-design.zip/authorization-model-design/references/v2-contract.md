# N170 v2 contract: authorization-model-design

授权模型：RBAC/ABAC/ReBAC/PBAC/hybrid 决策树、SoD、委托、Break-glass、PoLP 量化、授权性能目标。

## Metadata contract

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: authorization-model-design
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.authorization_model_design
  node_artifact_target: 权限模型设计.md
  design_id_pattern: "AUTHZ-\\d{3,}"
  produced_event: produced.n170.authorization_model.v2
  blocker_mapping: B03
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Input schema with workflow sources

| field | required | from | purpose |
| --- | --- | --- | --- |
| `permissions` | required | N070/permission-matrix-extraction | 角色/资源/动作矩阵 |
| `business_rules` | required | N070 | 授权规则和职责分离 |
| `state_machines` | required | N070 | 状态相关权限 |
| `data_flows` | required | N160 | 跨服务授权执行点 |
| `organizational_structure` | optional | context | 部门/层级/汇报关系 |

## Required output schema

- `authorization_model.design_id: AUTHZ-\d{3,}`
- `authorization_model_type.primary_model: rbac | abac | rebac | pbac | hybrid + auxiliary_models + model_justification`
- `rbac_design.roles + role_hierarchy + separation_of_duties_constraints`
- `abac_design.attribute_categories + policies`
- `rebac_design.enabled + object_types + tuples_example`
- `delegation_model.supported + delegation_types + token_based_delegation`
- `break_glass.supported + scenarios.activation + monitoring + deactivation`
- `principle_of_least_privilege.metrics + periodic_reviews`
- `authorization_evaluation.performance_target + caching_strategy + centralized_vs_distributed`

## Hard gate rules

| rule | check | on violation |
| --- | --- | --- |
| `R01_model_type_justified` | 模型选择必须有 rationale | `reject` |
| `R02_sod_constraints_declared` | 敏感操作必须声明 SoD 约束或说明不适用 | `reject` |
| `R03_delegation_has_ttl` | 委托/代理必须有 ttl 或 valid_until | `reject` |
| `R04_break_glass_has_monitoring` | break-glass 必须监控、告警和 post-review | `reject` |
| `R05_polp_targets_set` | PoLP 必须有量化目标和清理周期 | `reject` |
| `R06_role_hierarchy_depth_limit` | 角色继承深度应小于 5，超过必须告警 | `warn` |
| `R07_auth_perf_target` | 授权决策必须有 p99 延迟目标和缓存失效策略 | `reject` |

## Algorithms and decision logic

- model_selection_decision_tree: roles < 20 and relationships simple -> rbac; complex context/time/device -> abac or hybrid; collaboration/share graph -> rebac; policy-as-code/frequent regulation -> pbac; large system -> hybrid.
- sod_detection: patterns include approver != requester, initiator != verifier, cannot approve and execute same transaction.
- polp_audit: monthly/quarterly scan permissions top 20, >90-day dormant permissions, high-overlap roles and over-privileged users.

## Field-level handoff

| link | fields produced/consumed | downstream use |
| --- | --- | --- |
| `to_051_audit` | `role assignment, permission denied/granted, delegation, break_glass` | A02 authorization audit events |
| `to_054_security` | `authorization_model_type, SoD, break_glass, decision cache` | elevation_of_privilege threats and controls |
| `to_N200_dto` | `field-level policies and masking decisions` | DTO/VO response masking |
| `to_N260_permission_test` | `SoD/delegation/break-glass decision_examples` | 权限专项测试点 |

## Blocker and event output

```yaml
blocker_signal:
  blocker_id: B03
  source_skill: authorization-model-design
  rule_id: Rxx
  severity: reject | warn
  evidence: []
  recommended_owner: product | engineering | qa | security | compliance
event:
  produced: produced.n170.authorization_model.v2
  schema_version: n170.v2.0.0
```

## Minimal worked example

```yaml
design_id: AUTHZ-001
authorization_model_type.primary_model: hybrid
authorization_model_type.auxiliary_models: [rbac, abac]
rbac_design.roles[0].role_id: ROLE-CS-AGENT
abac_design.policies[0].formal_expression: subject.user_id == resource.owner_id
separation_of_duties_constraints[0].description: 审批人不可同时是申请人
break_glass.scenarios[0].activation.approval_required: dual_approver
principle_of_least_privilege.metrics.dormant_permissions.target: < 10%
```

## Standalone behavior

When upstream evidence is missing, still produce a useful provisional artifact. Mark missing source fields as `pending`, inferred design as `inferred`, and hard-gate failures as `blocked` only when the missing evidence prevents a safe recommendation.