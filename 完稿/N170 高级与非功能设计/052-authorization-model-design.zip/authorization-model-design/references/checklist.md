# V2 hard-gate checklist for authorization-model-design

Use this checklist before finalizing any N170 output. Treat `reject` failures as blocking unless the output is explicitly marked `readiness: blocked` with pending evidence.

## Required metadata

- [ ] `artifact_schema_version: n170.v2.0.0` is present.
- [ ] Design IDs follow `AUTHZ-###`.
- [ ] `produced_event: produced.n170.authorization_model.v2` is present.
- [ ] `blocker_mapping: B03` is present.
- [ ] `confirmed / inferred / pending` evidence buckets are populated.

## Hard rules

- [ ] `R01_model_type_justified` (reject): 模型选择必须有 rationale
- [ ] `R02_sod_constraints_declared` (reject): 敏感操作必须声明 SoD 约束或说明不适用
- [ ] `R03_delegation_has_ttl` (reject): 委托/代理必须有 ttl 或 valid_until
- [ ] `R04_break_glass_has_monitoring` (reject): break-glass 必须监控、告警和 post-review
- [ ] `R05_polp_targets_set` (reject): PoLP 必须有量化目标和清理周期
- [ ] `R06_role_hierarchy_depth_limit` (warn): 角色继承深度应小于 5，超过必须告警
- [ ] `R07_auth_perf_target` (reject): 授权决策必须有 p99 延迟目标和缓存失效策略

## Cross-skill handoff

- [ ] `to_051_audit` handoff is explicit: `role assignment, permission denied/granted, delegation, break_glass` -> A02 authorization audit events
- [ ] `to_054_security` handoff is explicit: `authorization_model_type, SoD, break_glass, decision cache` -> elevation_of_privilege threats and controls
- [ ] `to_N200_dto` handoff is explicit: `field-level policies and masking decisions` -> DTO/VO response masking
- [ ] `to_N260_permission_test` handoff is explicit: `SoD/delegation/break-glass decision_examples` -> 权限专项测试点
