# V2 hard-gate checklist for authorization-model-design

Use this checklist before finalizing any N170 output. Treat `reject` failures as blocking unless the output is explicitly marked `readiness: blocked` with pending evidence.

## Required metadata

- [ ] `artifact_schema_version: n170.v2.0.0` is present.
- [ ] Design IDs follow `AUTHZ-###`.
- [ ] `produced_event: produced.n170.authorization_model.v2` is present.
- [ ] `blocker_mapping: B03` is present.
- [ ] `confirmed / inferred / pending` evidence buckets are populated.

## Hard rules

- [ ] `R01_model_type_justified` (reject): 模型选择必须有 rationale
- [ ] `R02_sod_constraints_declared` (reject): 敏感操作必须声明 SoD 约束或说明不适用
- [ ] `R03_delegation_has_ttl` (reject): 委托/代理必须有 ttl 或 valid_until
- [ ] `R04_break_glass_has_monitoring` (reject): break-glass 必须监控、告警和 post-review
- [ ] `R05_polp_targets_set` (reject): PoLP 必须有量化目标和清理周期
- [ ] `R06_role_hierarchy_depth_limit` (warn): 角色继承深度应小于 5，超过必须告警
- [ ] `R07_auth_perf_target` (reject): 授权决策必须有 p99 延迟目标和缓存失效策略
- [ ] `R08_grant_ceiling_enforced` (reject): 每个授予/改派/角色变更点声明授予上限不变式（授出权限集合 ⊆ 授予方自身可授出集合；等级/范围模型即授予方等级 ≥ 被授等级 且 被授范围 ⊆ 授予方范围，能力型模型即仅授出自身显式持有且可再授的权限，列举非穷尽）并定义违反时的拒绝行为（只管授予量级⊄自身可授集;资源端点实例属主校验属 R10）
- [ ] `R09_lifecycle_full_revocation` (reject): 主体终止/暂停态转换必须枚举并原子吊销其全部能力面（例如次要/代理角色、已委托授出的授予、长期令牌/会话、二次验证登记、渠道访问 等，列举非穷尽）；任一终止态遗留任一、或可逆暂停态遗留具备写/资金/特权的能力面即 reject；可逆暂停态仅保留只读（无写/资金/特权）渠道不算遗留（范围门:终止吊销须是已 committed 需求才判缺陷,PRD 本期不做则 not_applicable 降底座残留）
- [ ] `R10_resource_owner_enforcement` (reject): 每个针对具体资源实例的操作端点校验调用者拥有/被授权访问该具体实例（非仅能调用该操作类型,can-call≠can-access-this-instance）;仅凭 id 取实例不比对 owner/租户=IDOR/BOLA 越权

## Cross-skill handoff

- [ ] `to_051_audit` handoff is explicit: `role assignment, permission denied/granted, delegation, break_glass` -> A02 authorization audit events
- [ ] `to_054_security` handoff is explicit: `authorization_model_type, SoD, break_glass, decision cache` -> elevation_of_privilege threats and controls
- [ ] `to_N200_dto` handoff is explicit: `field-level policies and masking decisions` -> DTO/VO response masking
- [ ] `to_N260_permission_test` handoff is explicit: `SoD/delegation/break-glass decision_examples` -> 权限专项测试点
