# Authorization paradigm decision guide — authorization-model-design

## Paradigm selection decision tree

```
Does the system have clear role-based org structure?
├── YES → roles are stable and ≤50?
│   ├── YES → RBAC (simple, low complexity)
│   └── NO → role explosion risk → consider ABAC or hybrid
└── NO → Does access depend on resource attributes or context?
    ├── YES → Is the relationship graph (ownership, org hierarchy) the key?
    │   ├── YES → ReBAC (relationship-based)
    │   └── NO → ABAC (attribute-based)
    └── NO → Is policy-as-code and audit-first a requirement?
        ├── YES → PBAC (Open Policy Agent / Cedar)
        └── NO → Hybrid (RBAC for common cases + ABAC for exceptions)
```

## Protocol integration quick-reference

| Protocol | Use case | Integration point in PEP/PDP |
|---|---|---|
| OAuth 2.0 | Delegated authorization (third-party apps) | PEP validates access_token scope; PDP enriches with internal permissions |
| OIDC | Authentication + identity claims | PEP extracts `sub`, `email`, `groups` from ID token for PDP input |
| SAML 2.0 | Enterprise SSO (legacy IdP) | PEP validates assertion; PDP maps SAML attributes to internal roles |
| JWT (internal) | Service-to-service auth | PEP validates signature + expiry; PDP checks service permissions |
| mTLS | Infrastructure-level service identity | PEP validates client certificate; PDP checks service allowlist |
| SCIM | Provisioning sync (user lifecycle) | PIP syncs user attributes from IdP; PDP uses current state |

## SoD (Separation of Duties) catalog

| Conflict type | Example | Enforcement |
|---|---|---|
| Create + approve | User submits AND approves their own request | Two distinct roles required; DB constraint on approver ≠ requester |
| Record + audit | User records transaction AND writes audit event | Audit writes restricted to audit-only service account |
| Deploy + approve | Engineer deploys AND approves their own change | Four-eyes rule in CI/CD pipeline |
| Grant + use | Admin grants themselves elevated permissions | Privilege elevation requires dual-approval + break-glass audit |

## PoLP enforcement metrics + remediation

| Metric | Formula | Target | Remediation when exceeded |
|---|---|---|---|
| Permission density | granted ÷ available | < 0.3 for privileged roles | Quarterly access review; auto-revoke >90d unused |
| Role explosion | count of custom roles | < 50 warn, < 100 hard limit | Role consolidation sprint |
| SoD violation rate | active conflicts ÷ total users | 0% | Immediate revoke + audit + incident |
| Dormant permission | unused >90d ÷ total granted | < 10% | Quarterly auto-revoke with grace period |
| Break-glass frequency | break-glass activations per month | < 2/month per team | Investigate root cause; fix normal access path |
