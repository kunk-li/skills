# Example I/O: authorization-model-design v2.1

## ex-001 · hybrid order authorization model

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: authorization-model-design
  workflow_node: N170
  node_artifact_target: 权限模型设计.md
  selected_mode: enterprise_hybrid
  readiness: ready
  design_id_pattern: "AUTHZ-\\d{3,}"
  produced_event: produced.n170.authorization_model.v2
  blocker_mapping: B03
  evidence_profile:
    confirmed: [权限矩阵.csv, PERM-ORDER-READ-OWN, PERM-ORDER-REFUND]
    inferred: [ownership attribute available]
    pending: [org hierarchy source]
authorization_model:
  design_id: AUTHZ-001
  authorization_model_type:
    primary_model: hybrid
    auxiliary_models: [rbac, abac]
    model_justification: 角色清晰，但订单所有权、时间和 break-glass 需要属性判断
  rbac_design:
    roles:
      - role_id: ROLE-CUSTOMER
        role_name: Customer
        permissions: [PERM-ORDER-CREATE-OWN, PERM-ORDER-READ-OWN]
        hierarchy_parent: null
        role_assignment_rules: {who_can_assign: self_service_signup, assignment_audit_required: true}
      - role_id: ROLE-CS-MANAGER
        role_name: Customer Support Manager
        permissions: [PERM-ORDER-READ-ANY, PERM-ORDER-REFUND]
        hierarchy_parent: ROLE-CS-AGENT
        role_assignment_rules: {who_can_assign: IAM_ADMIN, assignment_audit_required: true}
    role_hierarchy:
      supports_inheritance: true
      depth_limit: 3
      diamond_inheritance: forbidden
    separation_of_duties_constraints:
      - sod_id: SOD-001
        description: 退款审批人不可同时是退款发起人
        incompatible_roles: [ROLE-REFUND-REQUESTER, ROLE-REFUND-APPROVER]
        static_or_dynamic: dynamic
  abac_design:
    attribute_categories:
      subject_attributes: [{attr_name: user_id, source: token_claim}, {attr_name: department, source: user_profile}]
      resource_attributes: [{attr_name: owner_id}, {attr_name: order_status}]
      action_attributes: [{attr_name: action}]
      environment_attributes: [{attr_name: network_zone}, {attr_name: time_of_day}]
    policies:
      - policy_id: POL-001
        policy_text: 用户只能读取自己的订单
        formal_expression: subject.user_id == resource.owner_id
        priority: 100
        effect: permit
        combining_algorithm: deny_overrides
  delegation_model:
    supported: true
    delegation_types:
      - delegation_kind: temporary_deputy
        constraints: {delegator_must_have_permission: true, sub_delegation_allowed: false, delegation_chain_max_depth: 1}
        revocation: {immediate: true, audit_on_revoke: true}
  break_glass:
    supported: true
    scenarios:
      - scenario: 生产故障恢复
        elevated_permission: ADMIN_OVERRIDE
        activation: {who_can_activate: on_call_engineer, justification_required: true, approval_required: dual_approver, time_limit: 1h}
        monitoring: {real_time_alert: true, alert_recipients: [security_team, compliance_officer], mandatory_post_review: true, review_window: 24h}
        deactivation: {auto_on_time_limit: true, manual_termination: true}
  principle_of_least_privilege:
    metrics:
      avg_permissions_per_user: {target: "< 20", measurement_method: monthly scan}
      dormant_permissions: {definition: "> 90 days unused", target: "< 10% of total", cleanup_schedule: quarterly}
      role_explosion: {definition: custom role count, threshold: "> 100 warning"}
    periodic_reviews: {frequency: quarterly, scope: [all_users, privileged_users], action_on_violation: [auto_revoke, notify_manager]}
  authorization_evaluation:
    performance_target: {p99_latency: "< 10ms", throughput: "10k req/s"}
    centralized_vs_distributed: hybrid
rule_results:
  - {rule_id: R01_model_type_justified, status: pass, evidence: [model_justification]}
  - {rule_id: R03_delegation_has_ttl, status: pass, evidence: [temporary_deputy]}
  - {rule_id: R04_break_glass_has_monitoring, status: pass, evidence: [real_time_alert, mandatory_post_review]}
blocker_signals: []
contract_appendix:
  id_prefix: AUTHZ
  produced_event: produced.n170.authorization_model.v2
  downstream_handoff:
    to_051_audit: [role_assigned, permission_denied, break_glass_invoked]
    to_054_security: [ADMIN_OVERRIDE, SoD constraints, policy evaluation path]
```
