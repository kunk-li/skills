# Example I/O: authorization-model-design v2.1

## ex-001 · hybrid order authorization model

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: authorization-model-design
  workflow_node: N170
  node_artifact_target: 权限模型设计.md
  selected_mode: enterprise_hybrid
  readiness: ready
  design_id_pattern: "AUTHZ-\\d{3,}"
  produced_event: produced.n170.authorization_model.v2
  blocker_mapping: B03
  evidence_profile:
    confirmed: [权限矩阵.csv, PERM-ORDER-READ-OWN, PERM-ORDER-REFUND]
    inferred: [ownership attribute available]
    pending: [org hierarchy source]
authorization_model:
  design_id: AUTHZ-001
  authorization_model_type:
    primary_model: hybrid
    auxiliary_models: [rbac, abac]
    model_justification: 角色清晰，但订单所有权、时间和 break-glass 需要属性判断
  rbac_design:
    roles:
      - role_id: ROLE-CUSTOMER
        role_name: Customer
        permissions: [PERM-ORDER-CREATE-OWN, PERM-ORDER-READ-OWN]
        hierarchy_parent: null
        role_assignment_rules: {who_can_assign: self_service_signup, assignment_audit_required: true}
      - role_id: ROLE-CS-MANAGER
        role_name: Customer Support Manager
        permissions: [PERM-ORDER-READ-ANY, PERM-ORDER-REFUND]
        hierarchy_parent: ROLE-CS-AGENT
        role_assignment_rules: {who_can_assign: IAM_ADMIN, assignment_audit_required: true}
    role_hierarchy:
      supports_inheritance: true
      depth_limit: 3
      diamond_inheritance: forbidden
    separation_of_duties_constraints:
      - sod_id: SOD-001
        description: 退款审批人不可同时是退款发起人
        incompatible_roles: [ROLE-REFUND-REQUESTER, ROLE-REFUND-APPROVER]
        static_or_dynamic: dynamic
  abac_design:
    attribute_categories:
      subject_attributes: [{attr_name: user_id, source: token_claim}, {attr_name: department, source: user_profile}]
      resource_attributes: [{attr_name: owner_id}, {attr_name: order_status}]
      action_attributes: [{attr_name: action}]
      environment_attributes: [{attr_name: network_zone}, {attr_name: time_of_day}]
    policies:
      - policy_id: POL-001
        policy_text: 用户只能读取自己的订单
        formal_expression: subject.user_id == resource.owner_id
        priority: 100
        effect: permit
        combining_algorithm: deny_overrides
  delegation_model:
    supported: true
    delegation_types:
      - delegation_kind: temporary_deputy
        constraints: {delegator_must_have_permission: true, sub_delegation_allowed: false, delegation_chain_max_depth: 1}
        revocation: {immediate: true, audit_on_revoke: true}
  break_glass:
    supported: true
    scenarios:
      - scenario: 生产故障恢复
        elevated_permission: ADMIN_OVERRIDE
        activation: {who_can_activate: on_call_engineer, justification_required: true, approval_required: dual_approver, time_limit: 1h}
        monitoring: {real_time_alert: true, alert_recipients: [security_team, compliance_officer], mandatory_post_review: true, review_window: 24h}
        deactivation: {auto_on_time_limit: true, manual_termination: true}
  principle_of_least_privilege:
    metrics:
      avg_permissions_per_user: {target: "< 20", measurement_method: monthly scan}
      dormant_permissions: {definition: "> 90 days unused", target: "< 10% of total", cleanup_schedule: quarterly}
      role_explosion: {definition: custom role count, threshold: "> 100 warning"}
    periodic_reviews: {frequency: quarterly, scope: [all_users, privileged_users], action_on_violation: [auto_revoke, notify_manager]}
  authorization_evaluation:
    performance_target: {p99_latency: "< 10ms", throughput: "10k req/s"}
    centralized_vs_distributed: hybrid
rule_results:
  - {rule_id: R01_model_type_justified, status: pass, evidence: [model_justification]}
  - {rule_id: R03_delegation_has_ttl, status: pass, evidence: [temporary_deputy]}
  - {rule_id: R04_break_glass_has_monitoring, status: pass, evidence: [real_time_alert, mandatory_post_review]}
blocker_signals: []
contract_appendix:
  id_prefix: AUTHZ
  produced_event: produced.n170.authorization_model.v2
  downstream_handoff:
    to_051_audit: [role_assigned, permission_denied, break_glass_invoked]
    to_054_security: [ADMIN_OVERRIDE, SoD constraints, policy evaluation path]
```

## ex-002 · delegation chain depth + PoLP metrics

```yaml
authorization_model:
  design_id: AUTHZ-002

  delegation_model:
    supported: true
    max_chain_depth: 2
    chain_depth_rationale: "Depth > 2 makes audit trail reconstruction complex and permission creep undetectable"
    delegation_types:
      - delegation_kind: manager_proxy
        max_duration: 5d
        constraints:
          delegator_must_have_permission: true
          sub_delegation_allowed: false   # depth limit enforced here
          delegation_chain_max_depth: 1   # delegatee cannot re-delegate
        revocation: {immediate: true, audit_on_revoke: true}

    negative_case:
      scenario: "Allow unlimited delegation chain depth"
      risk: "Alice delegates to Bob who delegates to Carol who delegates to Dave — permission origin untraceable; audit queries become O(n) recursive"
      mitigation: "Hard limit at depth=2; any delegation to an already-delegated permission is rejected with AUTHZ.DELEGATION.DEPTH_EXCEEDED"

  principle_of_least_privilege:
    current_metrics:
      avg_permissions_per_user:
        value: 23
        target: "< 20"
        status: warn
        action: "Run quarterly permission review; auto-revoke permissions unused > 90 days"
      dormant_permission_rate:
        value: "18%"
        target: "< 10%"
        status: warn
        action: "Identify 847 dormant permissions; bulk revoke with 14-day grace period notification"
      role_explosion_index:
        custom_role_count: 73
        target: "< 50"
        status: warn
        action: "Consolidate 73 custom roles to ≤ 30 by merging overlapping permission sets"
      sod_violation_rate:
        current: "0%"
        target: "0%"
        status: pass
    periodic_reviews:
      frequency: quarterly
      automated_checks:
        - "flag users with permission_density > 0.4"
        - "flag roles unused for > 60 days"
        - "detect new SoD conflicts after role assignments"
```

## ex-003 · blocked — permission matrix absent, paradigm selection blocked

```yaml
skill_name: authorization-model-design
readiness: blocked
blocker_mapping: B-N170-03
route_back_to: n070-permission-matrix-extraction

blockers:
  - blocker_id: BLK-AUTHZ-001
    type: missing_permission_matrix
    description: "Cannot select RBAC vs ABAC vs ReBAC without knowing the actual subject-resource-action combinations"
    impact: "Paradigm selection is the foundation — all downstream policy rules, PEP/PDP design, and SoD definitions depend on it"
    resolution_required: "N070-016 permission-matrix-extraction must complete"
    unblock_evidence: "권限矩阵.csv with at least: subject types, resource types, action types, and evaluation algorithm"

  - blocker_id: BLK-AUTHZ-002
    type: missing_api_surface
    description: "Cannot design PEP enforcement points without knowing which APIs need authorization checks"
    impact: "PEP integration with N150 APIs is undefined"
    resolution_required: "043 api-design-recommendation must identify auth requirements per API"
    unblock_evidence: "api_catalog[] with auth_baseline per endpoint"

provisional_paradigm_guess:
  likely_paradigm: RBAC
  reasoning: "Domain appears to have clear role hierarchy (employee, manager, admin) — RBAC is likely sufficient"
  confidence: inferred
  warning: "DO NOT implement based on this guess — confirm after 권限矩阵.csv is available"
```

## ex-004 · degraded — paradigm selection from domain only, no permission matrix

```yaml
skill_name: authorization-model-design
readiness: provisional
selected_mode: paradigm_analyzer
evidence_profile:
  confirmed: []
  inferred: [paradigm selection from domain description — 3 roles identified: employee/manager/admin]
  pending: [권限矩阵.csv, API auth requirements from 043, DPO data classification]

degraded_reason: "No 권힌矩阵.csv — paradigm selected from domain description only"
degraded_impact: "Policy rules, PEP integration points, and SoD constraints cannot be designed without confirmed permission matrix"

paradigm_selection:
  chosen: RBAC
  confidence: inferred
  rationale: "Domain description implies 3 clear roles (employee submits, manager approves, admin configures) — RBAC is appropriate for stable, small role sets"
  risk_if_wrong: "If attribute-based access control is needed (e.g., managers can only approve their direct reports' requests), ABAC would be required — significant rework"
  revisit_trigger: "Any requirement mentioning ownership, department, geography, or time-based access → switch to ABAC or hybrid"

provisional_roles:
  - role_id: ROLE-001
    name: employee
    confidence: inferred
    assumed_permissions: [leave.request.create, leave.request.read_own]
  - role_id: ROLE-002
    name: manager
    confidence: inferred
    assumed_permissions: [leave.approval.decide, leave.request.read_subordinate]

pending_confirmations:
  - "권힌矩阵.csv to confirm roles, resources, and action-level granularity"
  - "Confirm: can managers see all requests or only their direct reports'? (determines RBAC vs ABAC)"
  - "043 API surface to design PEP enforcement points"
```
