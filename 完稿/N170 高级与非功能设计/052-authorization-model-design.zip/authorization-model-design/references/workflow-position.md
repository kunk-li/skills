# Workflow position

## Node: N170
## Step order: 4_of_6

## Upstream inputs (feeds this skill)
- N120 permissions
- 038
- 043

## Downstream consumers (this skill feeds)
- 051
- 054
- N200
- N260

## When to use standalone vs in-workflow
- **Standalone**: when no structured upstream artifacts exist; start from raw requirements or PRD; output will be `readiness: provisional`.
- **In-workflow**: when upstream artifacts are available; inherit IDs and fields; output can reach `readiness: ready`.

## Minimum required inputs for `readiness: ready`
See `references/v2-contract.md` (N170 group) or `references/exact-contract.md` (N130/N140 group) for the typed input schema.
