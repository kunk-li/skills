# Output template: authorization-model-design v2

Start every answer with the following metadata block when producing a deliverable.

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: authorization-model-design
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.authorization_model_design
  node_artifact_target: 权限模型设计.md
  design_id_pattern: "AUTHZ-\d{3,}"
  produced_event: produced.n170.authorization_model.v2
  blocker_mapping: B03
  selected_mode: <mode>
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Required sections

- `authorization_model.design_id: AUTHZ-\d{3,}`
- `authorization_model_type.primary_model: rbac | abac | rebac | pbac | hybrid + auxiliary_models + model_justification`
- `rbac_design.roles + role_hierarchy + separation_of_duties_constraints`
- `abac_design.attribute_categories + policies`
- `rebac_design.enabled + object_types + tuples_example`
- `delegation_model.supported + delegation_types + token_based_delegation`
- `break_glass.supported + scenarios.activation + monitoring + deactivation`
- `principle_of_least_privilege.metrics + periodic_reviews`
- `authorization_evaluation.performance_target + caching_strategy + centralized_vs_distributed`

## Machine-readable appendix

At the end of the markdown report, include a compact YAML appendix containing stable IDs, rule results, blocker signals, and downstream handoff.

```yaml
contract_appendix:
  id_prefix: AUTHZ
  produced_event: produced.n170.authorization_model.v2
  blocker_mapping: B03
  rule_results:
    - rule_id: R01
      status: pass | warn | reject | not_applicable
      evidence: []
  downstream_handoff: []
```
