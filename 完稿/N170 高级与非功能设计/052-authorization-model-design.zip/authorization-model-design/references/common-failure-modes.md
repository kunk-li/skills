# Common failure modes for authorization model design

## F1: choosing pure rbac when the real business need is contextual
Symptom: roles exist, but channel, ownership, region, or scope conditions are ignored.
Fix: add abac or scoped rules where context truly matters.

## F2: defining field-level permissions without a trigger
Symptom: the output says a field is visible sometimes but never states when.
Fix: tie the field rule to role, status, channel, or ownership conditions.

## F3: ignoring ghost roles or invalid role codes
Symptom: the model assumes every supplied role identifier is valid.
Fix: define explicit rejection behavior for unknown roles.

## F4: describing caches without naming the source of truth
Symptom: the design speeds up access checks but never says what storage is authoritative.
Fix: define the authority and invalidation path.

## F5: failing to explain how multiple roles compose
Symptom: it is unclear whether privileges union, intersect, or require priority rules.
Fix: define composition behavior explicitly.

## V2.1 contract failure modes

## F6: missing v2 special controls
Symptom: the model lists roles but misses SoD, delegation TTL, break-glass, or PoLP metrics.
Fix: complete R02-R05 controls before marking the artifact ready.

## F7: ambiguous policy evaluation
Symptom: multiple roles or attributes combine without deny/permit priority.
Fix: state the combining algorithm and evaluation order.

## F8: weak audit/security handoff
Symptom: 051 and 054 cannot identify authorization events or privilege-escalation threats.
Fix: expose role assignment events, denied decisions, SoD constraints, break-glass flows, and policy evaluation paths.

## F9: contract appendix drift
Symptom: the markdown narrative says one thing while `contract_appendix` exposes different IDs, rule results, or handoff fields.
Fix: reconcile narrative and appendix before finalizing; the appendix is what downstream automation consumes.

## F10: blocker without owner or remediation
Symptom: a warning or reject is emitted but no owner, evidence, or next action is named.
Fix: every `blocker_signals[]` item must include `recommended_owner`, evidence, and a remediation hint or pending evidence field.

## F11: gating who-can-call but not what-can-be-granted
Symptom: an assignment, grant, or role-change point checks only that the caller is authorized to invoke the grant operation (a call-site authorization gate / can-call check), but never checks the ceiling of what may be granted; a lower-privileged subject can use the grant path to raise itself or others to privileges beyond its own — granting a higher level, a wider scope, or a privilege it does not hold.
Fix: declare a grant-ceiling invariant at every grant/reassign/role-change point — the granted privileges must be a subset of the grantor's own grantable set (of which level/scope dominance, i.e. grantor_max_level ≥ granted_level and granted_scope ⊆ grantor_scope, is one form; a capability/grant-option model expresses the same ceiling as "only privileges the grantor explicitly holds and that are marked re-grantable") — and define explicit reject behavior on violation. Treat the can-call gate and the what-can-be-granted ceiling as two separate, both-mandatory checks.

## F12: terminating a subject while leaving residual capability surfaces
Symptom: a subject moved to a terminated/suspended/frozen lifecycle state has its primary role cleared, but other capability surfaces survive — e.g. secondary or delegated-to roles, grants the subject had handed out, long-lived tokens or sessions, second-factor enrollments, or channel-specific access (illustrative, non-exhaustive) — so the terminated subject can still act.
Fix: enumerate every capability surface a subject can hold, and for each terminal/suspended lifecycle-state transition define atomic (all-or-nothing) revocation across all of them; the design must be such that no terminal state is specifiable that leaves any surface un-revoked. (Distinct from R03 delegation TTL, which only expires temporary delegations on a timer and does not cover full-surface revocation on subject termination; distinct from R05 periodic PoLP cleanup, which prunes dormant permissions on a recurring cycle in steady state rather than guaranteeing completeness on a lifecycle-terminal transition; and distinct from R07, which bounds authorization-decision latency and cache invalidation — R09 requires that a terminal-state revocation reach every surface at all, not that it propagate within a latency budget.) Scope: only a defect when subject-termination revocation is a committed requirement — if the PRD explicitly scopes the collaboration/multi-subject capability out of the current phase, judge rule_not_applicable and treat it as a backbone-residual note rather than a confirmed defect.

## F13: enforcing can-call but not can-access-this-instance (IDOR / BOLA)
Symptom: a resource-instance operation (get/update/delete/cancel/retry by id) checks only that the caller is authenticated and allowed to invoke that operation type, but never checks that the caller owns or is authorized for the specific instance addressed by the id; any logged-in caller who knows or enumerates another subject's resource id can read or act on it.
Fix: for every owner-scoped (or tenant/project-scoped) resource, enforce an instance-level ownership/authorization check server-side at every operation endpoint — the caller must own or be granted access to that specific instance, not merely be allowed to call the operation. Distinct from R08 grant-ceiling (which bounds the magnitude of what may be granted) and from R02 SoD (which separates duties within one transaction): R10 governs whether a caller may touch this particular instance at all.
