# Common failure modes for authorization model design

## F1: choosing pure rbac when the real business need is contextual
Symptom: roles exist, but channel, ownership, region, or scope conditions are ignored.
Fix: add abac or scoped rules where context truly matters.

## F2: defining field-level permissions without a trigger
Symptom: the output says a field is visible sometimes but never states when.
Fix: tie the field rule to role, status, channel, or ownership conditions.

## F3: ignoring ghost roles or invalid role codes
Symptom: the model assumes every supplied role identifier is valid.
Fix: define explicit rejection behavior for unknown roles.

## F4: describing caches without naming the source of truth
Symptom: the design speeds up access checks but never says what storage is authoritative.
Fix: define the authority and invalidation path.

## F5: failing to explain how multiple roles compose
Symptom: it is unclear whether privileges union, intersect, or require priority rules.
Fix: define composition behavior explicitly.

## V2.1 contract failure modes

## F6: missing v2 special controls
Symptom: the model lists roles but misses SoD, delegation TTL, break-glass, or PoLP metrics.
Fix: complete R02-R05 controls before marking the artifact ready.

## F7: ambiguous policy evaluation
Symptom: multiple roles or attributes combine without deny/permit priority.
Fix: state the combining algorithm and evaluation order.

## F8: weak audit/security handoff
Symptom: 051 and 054 cannot identify authorization events or privilege-escalation threats.
Fix: expose role assignment events, denied decisions, SoD constraints, break-glass flows, and policy evaluation paths.

## F9: contract appendix drift
Symptom: the markdown narrative says one thing while `contract_appendix` exposes different IDs, rule results, or handoff fields.
Fix: reconcile narrative and appendix before finalizing; the appendix is what downstream automation consumes.

## F10: blocker without owner or remediation
Symptom: a warning or reject is emitted but no owner, evidence, or next action is named.
Fix: every `blocker_signals[]` item must include `recommended_owner`, evidence, and a remediation hint or pending evidence field.
