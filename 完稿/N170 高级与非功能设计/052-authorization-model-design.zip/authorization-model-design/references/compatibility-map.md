# Compatibility map — authorization-model-design v2 alignment

## Input artifact field mapping
| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| N070 016 permission-matrix-extraction | `PERM-* subject, grain, evaluation_algo` | `authorization_model design basis` | permission matrix is primary design input |
| 038 technical-solution-analysis | `constraint_taxonomy.C2_regulatory` | `compliance requirements` | regulatory constraints shape authorization model |
| 043 api-design-recommendation | `api_catalog[].auth_baseline` | `PEP enforcement points` | API auth requirements define PEP integration points |

## Output artifact field mapping
| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 051 audit-trail-design | `role assignment events, break_glass flows` | `A02 audit categories` | authorization events must be captured in audit trail |
| 054 security-risk-analysis | `authorization_model, SoD, break_glass` | `E_elevation_of_privilege controls` | authorization design informs privilege escalation threat mitigations |
| N200 dto-design | `field-level policies, masking decisions` | `DTO masking` | field-level auth rules define DTO response masking |

## v2 contract cross-reference
| v2 field | Purpose | Consumer |
|---|---|---|
| `produced_event` | Event bus trigger | N330, N340 |
| `blocker_mapping` | SLA queue key | N380 |
| `rule_results[]` | Gate pass/warn/reject | N380 |
| `route_back_to` | Return path on gap | Upstream skill |
