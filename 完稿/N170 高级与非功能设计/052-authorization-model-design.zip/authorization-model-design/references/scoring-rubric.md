# Scoring Rubric v3.0 — authorization-model-design

**Scale: 1–10 per dimension. Total = sum ÷ 8 × 2 (normalized to 10).**


## Dimensions
| Dimension | Score |
|---|---|
| paradigm selection rationale (RBAC/ABAC/ReBAC/PBAC/hybrid) | /10 |
| PDP/PEP/PIP/PAP architecture | /10 |
| SoD definition | /10 |
| PoLP quantification | /10 |
| delegation TTL design | /10 |
| break-glass control with mandatory audit | /10 |
| downstream handoff (052→054→051) | /10 |
| v2 contract compliance | /10 |

## Score descriptors
| Score | Label | Meaning |
|---|---|---|
| 9–10 | exemplary | production-ready; all contract fields present; downstream can consume without rework |
| 7–8 | strong | decision-ready; minor gaps that don't block downstream use |
| 5–6 | usable | supports team discussion; notable gaps require follow-up before execution |
| 3–4 | weak | some useful content; major sections missing or unstructured |
| 1–2 | unusable | mostly narrative or missing; cannot feed downstream skills |

## Gate rules
- Any dimension scoring ≤ 2 blocks the artifact regardless of total.
- Unresolved `reject`-severity rule_results cap the total at 6/10.
- Missing `contract_appendix` or stable IDs cap the total at 7/10.
