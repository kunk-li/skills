# V2 orchestration for authorization-model-design

## Execution modes

- Standalone: produce this skill artifact only. Use `readiness: provisional` when upstream fields are missing.
- N170 batch: use `references/n170-integration-map.md` and keep IDs stable across all six artifacts.
- Gate mode: emit reject/warn results from `references/v2-contract.md` rules and map them to the blocker ID.

## Input normalization

Normalize incoming file names into typed N170 evidence:

| field | required | from | purpose |
| --- | --- | --- | --- |
| `permissions` | required | N070/permission-matrix-extraction | 角色/资源/动作矩阵 |
| `business_rules` | required | N070 | 授权规则和职责分离 |
| `state_machines` | required | N070 | 状态相关权限 |
| `data_flows` | required | N160 | 跨服务授权执行点 |
| `organizational_structure` | optional | context | 部门/层级/汇报关系 |

## Output event

```yaml
event:
  produced: produced.n170.authorization_model.v2
  schema_version: n170.v2.0.0
  artifact: 权限模型设计.md
  blocker_mapping: B03
```

## Field-level handoff for this skill

| link | fields | downstream use |
| --- | --- | --- |
| `to_051_audit` | `role assignment, permission denied/granted, delegation, break_glass` | A02 authorization audit events |
| `to_054_security` | `authorization_model_type, SoD, break_glass, decision cache` | elevation_of_privilege threats and controls |
| `to_N200_dto` | `field-level policies and masking decisions` | DTO/VO response masking |
| `to_N260_permission_test` | `SoD/delegation/break-glass decision_examples` | 权限专项测试点 |
