# Compatibility map — idempotency-design-recommendation v2 alignment

## Input artifact field mapping
| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 049 concurrency-control-recommendation | `design_id (CON-###), scenario_classification` | `derived_from.concurrency_design_refs` | CON IDs inherited for concurrent same-key handling |
| 043 api-design-recommendation | `api_catalog[] write endpoints, idempotency hints` | `operation scope (CH-01)` | API idempotency requirements from 043 |
| 038 technical-solution-analysis | `architecture_three_states, async patterns` | `channel identification` | architecture scope determines which channels need idempotency |

## Output artifact field mapping
| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 053 performance-risk-analysis | `storage_strategy, ttl_decision, retry paths` | `B05/B06 capacity` | Redis sizing and retry storm feed performance analysis |
| 054 security-risk-analysis | `webhook_timestamp_window, signature_validation` | `replay threat controls` | idempotency window informs replay protection design |
| N260 testing | `derived_test_scenarios (TC-IDEM-###)` | `idempotency test suite` | TC-IDEM scenarios become retry and dedup tests |

## v2 contract cross-reference
| v2 field | Purpose | Consumer |
|---|---|---|
| `produced_event` | Event bus trigger | N330, N340 |
| `blocker_mapping` | SLA queue key | N380 |
| `rule_results[]` | Gate pass/warn/reject | N380 |
| `route_back_to` | Return path on gap | Upstream skill |
