# Common failure modes for idempotency design recommendation

## F1: using only the business object id when the same object supports multiple distinct operations
Symptom: one key incorrectly dedupes different actions.
Fix: include operation identity, actor, or state context when needed.

## F2: treating retries and redelivery as identical
Symptom: the design handles client retries but ignores async callbacks or worker retries.
Fix: cover sync and async repeat paths separately.

## F3: defining a key without a duplicate outcome
Symptom: the design stores a dedupe key but never says whether the duplicate gets the old result, a rejection, or a no-op.
Fix: define the duplicate outcome explicitly.

## F4: choosing a retention window with no relation to business timing
Symptom: the key expires too early or lives forever.
Fix: tie retention to retry windows, callback delays, or business dispute windows.

## F5: ignoring replay-sensitive security edges
Symptom: tokens, signatures, or callbacks can be replayed even though the business operation is deduped.
Fix: call out replay protections and security dependencies.

## V2.1 contract failure modes

## F6: using legacy 3-case duplicate handling
Symptom: conflict behavior omits expired-key replay or in-progress behavior.
Fix: cover all four v2 cases: same key same payload, same key different payload, key in progress, key expired/recreated.

## F7: omitting dual-layer storage for critical writes
Symptom: Redis-only or DB-only protection is recommended for financial/create_unique flows.
Fix: use L1 Redis for speed and L2 DB UNIQUE for final correctness when critical.

## F8: ignoring 049 handoff
Symptom: concurrent same-key behavior is rediscovered inconsistently.
Fix: consume `CON-###` refs and reuse concurrency-derived test cases.

## F9: contract appendix drift
Symptom: the markdown narrative says one thing while `contract_appendix` exposes different IDs, rule results, or handoff fields.
Fix: reconcile narrative and appendix before finalizing; the appendix is what downstream automation consumes.

## F10: blocker without owner or remediation
Symptom: a warning or reject is emitted but no owner, evidence, or next action is named.
Fix: every `blocker_signals[]` item must include `recommended_owner`, evidence, and a remediation hint or pending evidence field.
