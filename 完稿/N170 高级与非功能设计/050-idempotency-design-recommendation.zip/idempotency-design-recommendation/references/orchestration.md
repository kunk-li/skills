# V2 orchestration for idempotency-design-recommendation

## Execution modes

- Standalone: produce this skill artifact only. Use `readiness: provisional` when upstream fields are missing.
- N170 batch: use `references/n170-integration-map.md` and keep IDs stable across all six artifacts.
- Gate mode: emit reject/warn results from `references/v2-contract.md` rules and map them to the blocker ID.

## Input normalization

Normalize incoming file names into typed N170 evidence:

| field | required | from | purpose |
| --- | --- | --- | --- |
| `api_specs` | required | N150 | 写接口/回调/事件发布入口 |
| `data_flows` | required | N160 | 跨服务/消息/回调链路 |
| `concurrency_designs` | required | 049_concurrency-control | 并发 same key / race 场景 |
| `business_rules` | required | N070 | rule_semantic == idempotency |
| `messaging_channels` | optional | runtime/context | delivery guarantee |

## Output event

```yaml
event:
  produced: produced.n170.idempotency_design.v2
  schema_version: n170.v2.0.0
  artifact: 幂等设计建议.md
  blocker_mapping: B02
```

## Field-level handoff for this skill

| link | fields | downstream use |
| --- | --- | --- |
| `from_049_concurrency` | `concurrency_designs[].design_id and same-key race tests` | derived_from.concurrency_design_refs |
| `to_053_performance` | `storage_strategy, ttl_decision, observability.metrics` | Redis/DB sizing, cache bottleneck and retry storm analysis |
| `to_054_security` | `webhook timestamp window, signature validation, replay-sensitive paths` | replay threat controls |
| `to_N260_idempotency_test` | `derived_test_scenarios` | 幂等专项测试点 |
