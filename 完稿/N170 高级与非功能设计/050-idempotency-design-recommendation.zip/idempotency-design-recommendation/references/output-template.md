# Output template: idempotency-design-recommendation v2

Start every answer with the following metadata block when producing a deliverable.

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: idempotency-design-recommendation
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.idempotency_design
  node_artifact_target: 幂等设计建议.md
  design_id_pattern: "IDEM-\d{3,}"
  produced_event: produced.n170.idempotency_design.v2
  blocker_mapping: B02
  selected_mode: <mode>
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Required sections

- `idempotency_designs[].design_id: IDEM-\d{3,}`
- `scope.api_refs + operation_type: create | update | delete | event_publish | event_consume | callback`
- `idempotency_key_pattern: P1_client_generated_uuid | P2_server_inferred_natural_key | P3_content_hash | P4_message_id | P5_event_sequence_number | P6_composite_key`
- `key_specification.pattern + generation_method + example_key + uniqueness_scope`
- `storage_strategy.layer_1_primary + layer_2_fallback with DB UNIQUE when critical`
- `ttl_decision.chosen_ttl + factors_considered + ttl_expiry_during_retry`
- `conflict_handling.case_1_same_key_same_payload through case_4_key_expired_recreated`
- `channel_coverage.http_api + message_consumer + webhook_receiver + scheduler + saga_compensate + event_publish`
- `observability + derived_test_scenarios + derived_from`

## Machine-readable appendix

At the end of the markdown report, include a compact YAML appendix containing stable IDs, rule results, blocker signals, and downstream handoff.

```yaml
contract_appendix:
  id_prefix: IDEM
  produced_event: produced.n170.idempotency_design.v2
  blocker_mapping: B02
  rule_results:
    - rule_id: R01
      status: pass | warn | reject | not_applicable
      evidence: []
  downstream_handoff: []
```
