# Idempotency pattern catalog — idempotency-design-recommendation

## P1-P6 full pattern specification

| Pattern | ID | Key format | Storage | TTL basis | Best for |
|---|---|---|---|---|---|
| Client-generated UUID | P1 | `X-Idempotency-Key: uuid-v4` | Redis (L1) + DB unique (L2) | Client retry window | API POST/PUT operations |
| Business identity hash | P2 | `hash(order_id + amount + timestamp_truncated)` | DB unique constraint | Dispute window (30d typical) | Payment / financial |
| Message ID | P3 | Kafka offset / SQS MessageId | Redis dedup set | Consumer restart window | Queue consumers |
| Job + attempt | P4 | `{job_type}-{job_id}-attempt-{n}` | DB job tracking | Job maximum lifetime | Scheduled / batch jobs |
| Saga step ID | P5 | `saga-{id}-step-{n}` | Saga state table | Saga maximum duration | Distributed transactions |
| Source + sequence | P6 | `{source_system}-{sequence_id}` | DB unique (source, seq) | Replay window | Integration / migration |

## 6-channel × 3-layer decision matrix

| Channel | Primary key pattern | L1 storage | L2 storage | Special concern |
|---|---|---|---|---|
| CH-01 HTTP API | P1 client UUID | Redis 24h | DB unique constraint | Response caching for 201→200 on replay |
| CH-02 Queue consumer | P3 message ID | Redis dedup set 7d | DB processed_ids | At-least-once: must handle duplicate delivery |
| CH-03 Saga step | P5 saga+step | Saga state DB | n/a | Compensation must also be idempotent |
| CH-04 Scheduled job | P4 job+attempt | DB job_runs unique | n/a | Cron overlap: single-instance lock |
| CH-05 Webhook | P6 provider event_id | Redis 24h | DB webhook_log unique | Validate HMAC signature before dedup |
| CH-06 Bulk import | P4 job+row_index | Redis 7d | DB import_tracking | Resume: skip already-processed rows |

## Conflict resolution × 4 states
| State | Meaning | Response |
|---|---|---|
| `processing` | First actor still running | Return 202 Accepted + polling URL |
| `completed` | First actor succeeded | Return cached 200/201 response |
| `failed` | First actor failed and gave up | Allow retry (new idempotency key) |
| `expired` | Key TTL exceeded | Treat as new request; log for audit |
