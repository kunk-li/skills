# Example I/O: idempotency-design-recommendation v2.1

## ex-001 · order creation idempotency design

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: idempotency-design-recommendation
  workflow_node: N170
  node_artifact_target: 幂等设计建议.md
  selected_mode: workflow_hardening
  readiness: ready
  design_id_pattern: "IDEM-\\d{3,}"
  produced_event: produced.n170.idempotency_design.v2
  blocker_mapping: B02
  evidence_profile:
    confirmed: [API-ORDER-CREATE, CON-001]
    inferred: [client can send X-Idempotency-Key]
    pending: [SDK retry max]
idempotency_designs:
  - design_id: IDEM-001
    scope:
      api_refs: [API-ORDER-CREATE]
      operation_type: create
    idempotency_key_pattern: P1_client_generated_uuid
    key_specification:
      pattern: P1_client_generated_uuid
      generation_method: client UUIDv4 in X-Idempotency-Key
      example_key: 550e8400-e29b-41d4-a716-446655440000
      uniqueness_scope: per_user
    storage_strategy:
      layer_1_primary:
        medium: redis
        ttl:
          value: 24h
          rationale: covers client retry, network duplicate window, and user retry window
        storage_schema:
          key_format: idemp:order:{user_id}:{idempotency_key}
          value_format: result_cached
          size_estimate: 1.5KB/key
        failure_mode: fall_back_to_L2
      layer_2_fallback:
        medium: database_unique
        db_unique_constraint:
          table: orders
          columns: [user_id, idempotency_key]
          cleanup_strategy: never
        activation_trigger: always
    ttl_decision:
      chosen_ttl: 24h
      rationale:
        factors_considered:
          - client_retry_window: pending
          - user_patience: 2h inferred
          - network_duplicate_window: 30min inferred
        chosen_reasoning: max known retry windows with conservative safety margin
      edge_cases:
        ttl_expiry_during_retry:
          behavior: treat as new request, DB UNIQUE may still prevent duplicate
          potential_duplicate: false
          mitigation: never cleanup order-level unique key
    conflict_handling:
      case_1_same_key_same_payload:
        action: return original result
        response_source: cache_full_response
        safety: idempotent
      case_2_same_key_diff_payload:
        action: return 409 Conflict
        error_code: IDEMPOTENCY_KEY_CONFLICT
        detail: Key already used with different payload
        safety: reject overwrite
      case_3_key_in_progress:
        action: return 409 or wait briefly
        behavior: reject
      case_4_key_expired_recreated:
        action: treat as new request
        risk: low with DB UNIQUE
        mitigation: permanent unique key on orders
    channel_coverage:
      http_api: {applicable: true, header: X-Idempotency-Key, required_on_methods: [POST]}
      message_consumer: {applicable: false}
      webhook_receiver: {applicable: false}
      scheduler: {applicable: false}
      saga_compensate: {applicable: false}
      event_publish: {applicable: true, outbox_pattern: true, dedup_on_consumer_side: true}
    derived_test_scenarios:
      - {test_id: TC-IDEM-001, scenario: retry_after_success, expected_outcome: same order_id returned}
      - {test_id: TC-IDEM-002, scenario: same_key_diff_payload, expected_outcome: 409 conflict}
      - {test_id: TC-IDEM-003, scenario: l1_down_l2_works, expected_outcome: DB UNIQUE blocks duplicate}
      - {test_id: TC-IDEM-004, scenario: concurrent_same_key, expected_outcome: 1 success + conflicts/original result}
      - {test_id: TC-IDEM-005, scenario: ttl_boundary_replay, expected_outcome: no duplicate due to DB UNIQUE}
    derived_from:
      api_refs: [API-ORDER-CREATE]
      flow_refs: [FLOW-ORDER-CREATE]
      rule_refs: [RULE-IDEMP-001]
      concurrency_design_refs: [CON-001]
rule_results:
  - {rule_id: R01_all_write_apis_have_idempotency, status: pass, evidence: [IDEM-001]}
  - {rule_id: R07_test_scenarios_min_5, status: pass, evidence: [TC-IDEM-001, TC-IDEM-002, TC-IDEM-003, TC-IDEM-004, TC-IDEM-005]}
blocker_signals: []
contract_appendix:
  id_prefix: IDEM
  produced_event: produced.n170.idempotency_design.v2
  downstream_handoff:
    to_053_performance: [redis_ttl_24h, db_unique_write_path]
    to_054_security: [same_key_diff_payload, replay_window]
```

## ex-002 · multi-channel coverage — webhook and batch

```yaml
idempotency_designs:
  # CH-05: Webhook callback from payment provider
  - design_id: IDEM-002
    scope:
      channel: CH-05_webhook_callback
      operation_type: receive_payment_callback
    idempotency_key_pattern: P6_source_plus_sequence
    key_specification:
      pattern: P6_source_plus_sequence
      generation_method: "payment_provider sends event_id in webhook body"
      example_key: "stripe_evt_1234567890"
      uniqueness_scope: per_provider_account
    storage_strategy:
      layer_1_primary:
        medium: redis
        ttl: {value: 24h, rationale: "Stripe retries webhooks for 24h; window covers all retry attempts"}
        key_format: "webhook:payment:{provider}:{event_id}"
        failure_mode: fall_back_to_L2
      layer_2_fallback:
        medium: database_unique
        db_unique_constraint: {table: payment_webhook_log, columns: [provider, event_id]}
    security:
      signature_validation: "Verify HMAC-SHA256 of payload using provider's signing secret BEFORE deduplication check"
      replay_window: "24h maximum — reject any webhook with timestamp > 24h ago"
      negative_case: "Without signature check, attacker can replay old webhook with modified amount"

  # CH-06: Bulk import job
  - design_id: IDEM-003
    scope:
      channel: CH-06_bulk_import
      operation_type: import_orders_from_csv
    idempotency_key_pattern: P4_job_plus_attempt
    key_specification:
      pattern: P4_job_plus_attempt
      example_key: "import-job-2024-03-01-attempt-2"
      row_level_key: "import:{job_id}:{row_index}:{row_hash}"
    storage_strategy:
      layer_1_primary:
        medium: redis
        ttl: {value: 7d, rationale: "Import jobs may be resumed within 7 days"}
      layer_2_fallback:
        medium: database_unique
        db_unique_constraint: {table: import_tracking, columns: [job_id, row_index]}
    resume_support:
      enabled: true
      mechanism: "Track last processed row_index; resume skips already-processed rows"
      negative_case: "Without row-level tracking, re-running a failed import creates duplicates for rows processed before failure"
    ttl_decision:
      chosen_ttl: 7d
      rationale: "Business dispute window for imports is 5 business days; 7d covers weekends"
```

## ex-003 · blocked — no API spec means channel coverage is impossible

```yaml
skill_name: idempotency-design-recommendation
readiness: blocked
blocker_mapping: B-N170-01
route_back_to: api-design-recommendation

blockers:
  - blocker_id: BLK-IDEM-001
    type: missing_api_spec
    description: "Cannot assess CH-01 (HTTP API channel) without confirmed API endpoints from 043"
    impact: "Primary idempotency channel undefined — cannot recommend key pattern or storage"
    resolution_required: "043 must complete api_catalog[] before idempotency design"
    unblock_evidence: "接口设计草案.yaml with write endpoints (POST/PUT) identified"

  - blocker_id: BLK-IDEM-002
    type: missing_flow_map
    description: "Cannot assess CH-02 (queue channel) or CH-03 (saga) without data flow map from 048"
    impact: "Async processing idempotency is the highest risk — blocking it leaves retry storms unaddressed"
    resolution_required: "048 must produce async flow definitions before queue idempotency design"
    unblock_evidence: "flow_catalog with at least one async consumer flow"

interim_assessment:
  ch_01_http: blocked
  ch_02_queue: blocked
  ch_03_saga: not_applicable_yet
  ch_04_scheduled: provisional
  note: "Only scheduled job idempotency can be provisionally designed without API or flow evidence"
```

## ex-004 · degraded — designing idempotency without confirmed channel scope

```yaml
skill_name: idempotency-design-recommendation
readiness: provisional
selected_mode: quick_design
evidence_profile:
  confirmed: [CON-001 concurrency design — optimistic lock via version column]
  inferred: [CH-01 HTTP API assumed from PRD description, CH-04 scheduled job assumed from nightly processing mention]
  pending: [043 api_catalog for CH-01 confirmation, 048 flow map for CH-02/CH-03 async scope]

degraded_reason: "No API spec (043) or flow map (048) — channels CH-02/CH-03/CH-05/CH-06 cannot be assessed"
degraded_impact: "Queue and saga idempotency — the highest risk channels — are deferred"

channel_assessment:
  CH-01_http_api:
    applicable: true
    confidence: inferred
    key_pattern: P1_client_uuid
    provisional_storage: {layer_1: redis_24h, layer_2: db_unique}
    note: "Endpoint list unknown — key pattern provisional until 043 completes"
  CH-02_queue_consumer:
    applicable: unknown
    confidence: pending
    blocked_by: "048 flow map not available — async consumers not yet identified"
  CH-03_saga:
    applicable: unknown
    confidence: pending
    blocked_by: "048 flow map not available — saga steps not yet defined"
  CH-04_scheduled_job:
    applicable: true
    confidence: inferred
    key_pattern: P4_job_plus_attempt
    inferred_from: "PRD mention of nightly batch processing"
  CH-05_webhook:
    applicable: unknown
    confidence: pending
    blocked_by: "No external integrations confirmed"
  CH-06_bulk_import:
    applicable: false
    confidence: inferred
    reason: "No import functionality mentioned in any upstream artifact"

pending_confirmations:
  - "043: identify write endpoints for CH-01 key application"
  - "048: identify async consumers for CH-02, saga steps for CH-03"
  - "Re-run after 043 and 048 complete to produce confirmed assessment"
```
