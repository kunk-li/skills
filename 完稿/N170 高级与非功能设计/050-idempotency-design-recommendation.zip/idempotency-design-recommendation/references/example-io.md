# Example I/O: idempotency-design-recommendation v2.1

## ex-001 · order creation idempotency design

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: idempotency-design-recommendation
  workflow_node: N170
  node_artifact_target: 幂等设计建议.md
  selected_mode: workflow_hardening
  readiness: ready
  design_id_pattern: "IDEM-\\d{3,}"
  produced_event: produced.n170.idempotency_design.v2
  blocker_mapping: B02
  evidence_profile:
    confirmed: [API-ORDER-CREATE, CON-001]
    inferred: [client can send X-Idempotency-Key]
    pending: [SDK retry max]
idempotency_designs:
  - design_id: IDEM-001
    scope:
      api_refs: [API-ORDER-CREATE]
      operation_type: create
    idempotency_key_pattern: P1_client_generated_uuid
    key_specification:
      pattern: P1_client_generated_uuid
      generation_method: client UUIDv4 in X-Idempotency-Key
      example_key: 550e8400-e29b-41d4-a716-446655440000
      uniqueness_scope: per_user
    storage_strategy:
      layer_1_primary:
        medium: redis
        ttl:
          value: 24h
          rationale: covers client retry, network duplicate window, and user retry window
        storage_schema:
          key_format: idemp:order:{user_id}:{idempotency_key}
          value_format: result_cached
          size_estimate: 1.5KB/key
        failure_mode: fall_back_to_L2
      layer_2_fallback:
        medium: database_unique
        db_unique_constraint:
          table: orders
          columns: [user_id, idempotency_key]
          cleanup_strategy: never
        activation_trigger: always
    ttl_decision:
      chosen_ttl: 24h
      rationale:
        factors_considered:
          - client_retry_window: pending
          - user_patience: 2h inferred
          - network_duplicate_window: 30min inferred
        chosen_reasoning: max known retry windows with conservative safety margin
      edge_cases:
        ttl_expiry_during_retry:
          behavior: treat as new request, DB UNIQUE may still prevent duplicate
          potential_duplicate: false
          mitigation: never cleanup order-level unique key
    conflict_handling:
      case_1_same_key_same_payload:
        action: return original result
        response_source: cache_full_response
        safety: idempotent
      case_2_same_key_diff_payload:
        action: return 409 Conflict
        error_code: IDEMPOTENCY_KEY_CONFLICT
        detail: Key already used with different payload
        safety: reject overwrite
      case_3_key_in_progress:
        action: return 409 or wait briefly
        behavior: reject
      case_4_key_expired_recreated:
        action: treat as new request
        risk: low with DB UNIQUE
        mitigation: permanent unique key on orders
    channel_coverage:
      http_api: {applicable: true, header: X-Idempotency-Key, required_on_methods: [POST]}
      message_consumer: {applicable: false}
      webhook_receiver: {applicable: false}
      scheduler: {applicable: false}
      saga_compensate: {applicable: false}
      event_publish: {applicable: true, outbox_pattern: true, dedup_on_consumer_side: true}
    derived_test_scenarios:
      - {test_id: TC-IDEM-001, scenario: retry_after_success, expected_outcome: same order_id returned}
      - {test_id: TC-IDEM-002, scenario: same_key_diff_payload, expected_outcome: 409 conflict}
      - {test_id: TC-IDEM-003, scenario: l1_down_l2_works, expected_outcome: DB UNIQUE blocks duplicate}
      - {test_id: TC-IDEM-004, scenario: concurrent_same_key, expected_outcome: 1 success + conflicts/original result}
      - {test_id: TC-IDEM-005, scenario: ttl_boundary_replay, expected_outcome: no duplicate due to DB UNIQUE}
    derived_from:
      api_refs: [API-ORDER-CREATE]
      flow_refs: [FLOW-ORDER-CREATE]
      rule_refs: [RULE-IDEMP-001]
      concurrency_design_refs: [CON-001]
rule_results:
  - {rule_id: R01_all_write_apis_have_idempotency, status: pass, evidence: [IDEM-001]}
  - {rule_id: R07_test_scenarios_min_5, status: pass, evidence: [TC-IDEM-001, TC-IDEM-002, TC-IDEM-003, TC-IDEM-004, TC-IDEM-005]}
blocker_signals: []
contract_appendix:
  id_prefix: IDEM
  produced_event: produced.n170.idempotency_design.v2
  downstream_handoff:
    to_053_performance: [redis_ttl_24h, db_unique_write_path]
    to_054_security: [same_key_diff_payload, replay_window]
```
