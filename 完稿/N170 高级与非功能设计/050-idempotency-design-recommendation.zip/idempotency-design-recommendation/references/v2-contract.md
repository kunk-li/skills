# N170 v2 contract: idempotency-design-recommendation

幂等设计：6 种 key pattern、Redis + DB 双层兜底、TTL 决策、4 态冲突、6 通道覆盖。

## Metadata contract

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: idempotency-design-recommendation
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.idempotency_design
  node_artifact_target: 幂等设计建议.md
  design_id_pattern: "IDEM-\\d{3,}"
  produced_event: produced.n170.idempotency_design.v2
  blocker_mapping: B02
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Input schema with workflow sources

| field | required | from | purpose |
| --- | --- | --- | --- |
| `api_specs` | required | N150 | 写接口/回调/事件发布入口 |
| `data_flows` | required | N160 | 跨服务/消息/回调链路 |
| `concurrency_designs` | required | 049_concurrency-control | 并发 same key / race 场景 |
| `business_rules` | required | N070 | rule_semantic == idempotency |
| `messaging_channels` | optional | runtime/context | delivery guarantee |

## Required output schema

- `idempotency_designs[].design_id: IDEM-\d{3,}`
- `scope.api_refs + operation_type: create | update | delete | event_publish | event_consume | callback`
- `idempotency_key_pattern: P1_client_generated_uuid | P2_server_inferred_natural_key | P3_content_hash | P4_message_id | P5_event_sequence_number | P6_composite_key`
- `key_specification.pattern + generation_method + example_key + uniqueness_scope`
- `storage_strategy.layer_1_primary + layer_2_fallback with DB UNIQUE when critical`
- `ttl_decision.chosen_ttl + factors_considered + ttl_expiry_during_retry`
- `conflict_handling.case_1_same_key_same_payload through case_4_key_expired_recreated`
- `channel_coverage.http_api + message_consumer + webhook_receiver + scheduler + saga_compensate + event_publish`
- `observability + derived_test_scenarios + derived_from`

## Hard gate rules

| rule | check | on violation |
| --- | --- | --- |
| `R01_all_write_apis_have_idempotency` | POST/PUT/PATCH/DELETE 必须有幂等判定或明确豁免 | `reject` |
| `R02_dual_layer_for_critical` | financial/create_unique 必须 Redis + DB UNIQUE 双层兜底 | `reject` |
| `R03_ttl_justified` | TTL 必须由重试窗口、重复窗口、合规或成本推导 | `reject` |
| `R04_conflict_handling_4_cases_all` | 4 态冲突处理必须完整 | `reject` |
| `R05_l1_failure_graceful` | L1 失败必须有 fallback/reject 策略 | `reject` |
| `R06_channel_specific_design` | 非 HTTP 通道必须独立设计，不能复用 HTTP 文案 | `reject` |
| `R07_test_scenarios_min_5` | 关键 API 至少 5 个 TC-IDEM 场景 | `warn` |

## Algorithms and decision logic

- key_pattern_selection: natural business key -> P2; client header available -> P1; queue consumer -> P4; stable payload -> P3; event sourcing -> P5; rule-defined composite scope -> P6.
- ttl_calculation: TTL = max(client_retry_max, compliance_min, duplicate_delivery_window) * 1.5 safety. Common defaults: payment/order 24h, notification 1h, audit event permanent.
- conflict_resolution_4_cases: case_1_same_key_same_payload -> return original result from cache or reconstructed state; case_2_same_key_diff_payload -> 409 IDEMPOTENCY_KEY_CONFLICT; case_3_key_in_progress -> reject 409 or wait briefly with bounded timeout; case_4_key_expired_recreated -> treat as new request only if L2 DB UNIQUE/business invariant cannot create duplicates.
- channel_coverage_routing: HTTP writes require header or natural key; message consumers use message_id/content_hash/business_key; webhook receivers require signature + timestamp replay window + event_id tracking; schedulers use run_id tracking; saga compensation has independent compensation key; event_publish should prefer outbox + consumer dedupe.

## Field-level handoff

| link | fields produced/consumed | downstream use |
| --- | --- | --- |
| `from_049_concurrency` | `concurrency_designs[].design_id and same-key race tests` | derived_from.concurrency_design_refs |
| `to_053_performance` | `storage_strategy, ttl_decision, observability.metrics` | Redis/DB sizing, cache bottleneck and retry storm analysis |
| `to_054_security` | `webhook timestamp window, signature validation, replay-sensitive paths` | replay threat controls |
| `to_N260_idempotency_test` | `derived_test_scenarios` | 幂等专项测试点 |

## Blocker and event output

```yaml
blocker_signal:
  blocker_id: B02
  source_skill: idempotency-design-recommendation
  rule_id: Rxx
  severity: reject | warn
  evidence: []
  recommended_owner: product | engineering | qa | security | compliance
event:
  produced: produced.n170.idempotency_design.v2
  schema_version: n170.v2.0.0
```

## Minimal worked example

```yaml
design_id: IDEM-001
scope.operation_type: create
idempotency_key_pattern: P1_client_generated_uuid
key_specification.uniqueness_scope: per_user
storage_strategy.layer_1_primary.medium: redis
storage_strategy.layer_1_primary.ttl.value: 24h
storage_strategy.layer_2_fallback.medium: database_unique
conflict_handling.case_2_same_key_diff_payload.action: 409 IDEMPOTENCY_KEY_CONFLICT
derived_from.concurrency_design_refs: [CON-001]
```

## Standalone behavior

When upstream evidence is missing, still produce a useful provisional artifact. Mark missing source fields as `pending`, inferred design as `inferred`, and hard-gate failures as `blocked` only when the missing evidence prevents a safe recommendation.