# V2 hard-gate checklist for idempotency-design-recommendation

Use this checklist before finalizing any N170 output. Treat `reject` failures as blocking unless the output is explicitly marked `readiness: blocked` with pending evidence.

## Required metadata

- [ ] `artifact_schema_version: n170.v2.0.0` is present.
- [ ] Design IDs follow `IDEM-###`.
- [ ] `produced_event: produced.n170.idempotency_design.v2` is present.
- [ ] `blocker_mapping: B02` is present.
- [ ] `confirmed / inferred / pending` evidence buckets are populated.

## Hard rules

- [ ] `R01_all_write_apis_have_idempotency` (reject): POST/PUT/PATCH/DELETE 必须有幂等判定或明确豁免
- [ ] `R02_dual_layer_for_critical` (reject): financial/create_unique 必须 Redis + DB UNIQUE 双层兜底
- [ ] `R03_ttl_justified` (reject): TTL 必须由重试窗口、重复窗口、合规或成本推导
- [ ] `R04_conflict_handling_4_cases_all` (reject): 4 态冲突处理必须完整
- [ ] `R05_l1_failure_graceful` (reject): L1 失败必须有 fallback/reject 策略
- [ ] `R06_channel_specific_design` (reject): 非 HTTP 通道必须独立设计，不能复用 HTTP 文案
- [ ] `R07_test_scenarios_min_5` (warn): 关键 API 至少 5 个 TC-IDEM 场景

## Cross-skill handoff

- [ ] `from_049_concurrency` handoff is explicit: `concurrency_designs[].design_id and same-key race tests` -> derived_from.concurrency_design_refs
- [ ] `to_053_performance` handoff is explicit: `storage_strategy, ttl_decision, observability.metrics` -> Redis/DB sizing, cache bottleneck and retry storm analysis
- [ ] `to_054_security` handoff is explicit: `webhook timestamp window, signature validation, replay-sensitive paths` -> replay threat controls
- [ ] `to_N260_idempotency_test` handoff is explicit: `derived_test_scenarios` -> 幂等专项测试点
