---
name: idempotency-design-recommendation
description: design idempotency strategies with key patterns, storage tiers, ttl derivation, and 6-channel coverage. triggers on 技术方案分析.md.
---
# idempotency-design-recommendation

## Idempotency key pattern quick-reference
| Pattern | Format example | Best for |
|---|---|---|
| P1: client-generated UUID | `X-Idempotency-Key: uuid-v4` | API requests |
| P2: business identity hash | `hash(order_id + amount + timestamp_truncated)` | payment/billing |
| P3: message ID | Kafka offset or SQS MessageId | queue consumers |
| P4: job + attempt | `export-job-{id}-attempt-{n}` | scheduled/batch jobs |
| P5: saga step ID | `saga-{id}-step-{n}` | distributed transactions |
| P6: source + sequence | `{source_system}-{sequence_id}` | integration replay |

## Storage strategy quick-reference
| Tier | Storage | TTL | Use when |
|---|---|---|---|
| Hot | Redis / in-memory | minutes–hours | high-frequency APIs, real-time dedup |
| Warm | DB table `idempotency_keys` | days–weeks | payment, financial, compliance |
| Cold | Archive / audit log | months–years | regulatory, long-running sagas |

**Dual-layer rule**: for financial or compliance operations, always use Redis (hot) + DB (warm) together. Redis handles speed; DB handles durability.

## 4-state conflict handling
| State | Meaning | Response |
|---|---|---|
| `processing` | in-flight | return 202 or queue status |
| `succeeded` | completed successfully | return cached success response |
| `failed` | terminal failure | return cached error; client must use new key |
| `expired` | TTL elapsed | treat as new request |


## 6-channel coverage quick-reference
Every channel type has different replay/retry characteristics. Design idempotency per channel, not globally.

| Channel | ID | Trigger for duplicate | Required control |
|---|---|---|---|
| HTTP API | CH-01 | client retry, network timeout | `X-Idempotency-Key` header + response cache |
| Message queue consumer | CH-02 | at-least-once delivery, consumer restart | message ID deduplication + idempotency store |
| Saga step | CH-03 | orchestrator retry after step failure | step-scoped idempotency key + state machine guard |
| Scheduled/batch job | CH-04 | job re-trigger, cron overlap | job + attempt ID; lock to prevent concurrent runs |
| Webhook/callback | CH-05 | provider retry on non-2xx response | event ID dedup + `window: 24h` |
| Bulk import/migration | CH-06 | re-run of partial import | row-level idempotency key + import job tracking table |

**Minimum coverage rule**: every skill output must explicitly assess CH-01 through CH-06. Channels not applicable to the system must be listed with `applicable: false` and a brief reason — not silently omitted.

## TTL derivation algorithm
TTL must be derived from business timing, not chosen arbitrarily.

```
TTL = max(
  client_retry_window,           -- e.g. SDK retries for up to 60min
  callback_delivery_retry_window, -- e.g. provider retries webhook for 24h
  user_patience_window,          -- e.g. user may re-submit within 2h
  dispute_window                 -- e.g. payment disputes within 30d
) + safety_margin (20%)
```

When evidence is missing, mark TTL as `inferred` and state the assumption:
```yaml
ttl_decision:
  chosen_ttl: 24h
  confidence: inferred
  assumption: "client retry window assumed ≤ 4h; webhook retry assumed ≤ 24h"
  pending_evidence: "confirm SDK retry policy with frontend team"
```


## Trigger conditions
Design idempotency strategies when any of the following are present:
- N130 technical solution or N150 API contracts
- callback or queue interface descriptions
- `concurrency_designs[]` from 049 (CON-### references)
- explicit idempotency or duplicate-handling design requests

## Standalone rule
Use `selected_mode: quick_design` as default. All 6 channels (CH-01 through CH-06) must be assessed even if most are `applicable: false`. Without upstream, derive operation scope from API names and flow descriptions.

## Role and boundary
本 skill 对齐 skills_workflow 中in the technical-solution-design -> 高级设计 -> 幂等设计建议」. It is a **direct_result** skill: the goal is to produce a concrete 重复请求、重试、重放、重复消费与去重策略落成可交付的 **`幂等设计建议.md`**，而不是停留在“加个幂等键”这类口号。

### Boundary
- 负责定义 operation 级幂等范围、key 生成方式、重复到达行为、存储策略与 TTL。
- 负责区分 API 幂等、消息消费幂等、Saga step 幂等、定时任务幂等。
- 不负责竞争资源序列化本身；该职责交给 `concurrency-control-recommendation`。
- 不负责错误码总表，但应为错误冲突、重复提交、重放冲突提供语义种子。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- stable ID following `IDEM-###`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `quick_design`：按 scope 快速给默认方案；默认模式。
- `analyzer`：审计现有方案是否真正幂等并指出缺口。
- `workflow_hardening`：对关键流程输出完整重试、重播、去重与降级策略。

## Primary inputs
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `api_specs(N150), data_flows(N160), concurrency_designs(049), business_rules(N070), messaging_channels(optional)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule
即使只有技术方案与 API / 流程描述，也可以单独使用。

降级规则：
- 若缺少实现细节，可先输出 provisional operation catalog。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的 scope、key、payload 规则。
- 不得假装系统已经具备 exactly-once 语义。

## Core output contract
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `幂等设计建议.md`
- primary output object: `idempotency_designs[]`
- stable ID: `IDEM-###`
- event: `produced.n170.idempotency_design.v2`
- blocker: `B02`
- stage: `technical_solution_design.advanced_design.idempotency_design`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: P1-P6 key pattern、双层 Redis + DB 兜底、TTL rationale、4 态冲突处理和 6 通道覆盖.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R07 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B02` blocker signal.

## Execution workflow
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `idempotency_designs[]`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_053_performance, to_054_security, to_N230_test, to_N260_idempotency_test`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness
- 单个 API：覆盖全部重试与重复提交路径
- 中型流程：覆盖 API、回调、消费与 Saga 关键步骤
- 大型系统：聚焦金融、合规、外部集成与高代价重复路径

## Quality bar
合格结果应让实现和测试团队明确知道“哪些操作必须幂等、用什么 key、重复来时怎么处理”。

## Reference files
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`

## v2 additions: N005 feedback signal and N070 upstream linkage

```yaml
feedback_signal_to_n005:
  signal_type: none | duplicate_incident_pattern | idempotency_gap_signal
  summary: ""
  target_n070_skills:
  - 014-business-rule-extraction
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
```

### Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| 业务规则清单.md (014) | `rule_semantic: idempotency`, `condition_expr`, `hardness=constraint` | idempotency scope, key generation strategy, conflict resolution rules |
| 业务规则清单.md (014) | temporal rules, `retry_window`, `rate_limit` rules | TTL decision, key expiry policy, retry-storm prevention |
| 状态转移图.md (015) | SM-* `recovery_note`, rollback transitions, `transition_kind=rollback` | saga step idempotency, compensation idempotency, rollback-safe key design |
| 状态转移图.md (015) | `trigger_kind=external`, callback transitions | webhook/callback idempotency key anchoring, replay detection |
| 权限矩阵.csv (016) | `subject_kind=delegated`, delegation TTL | delegation-aware idempotency scope (delegated ops need separate key namespace) |
| 数据对象目录.md (017) | `constraint_tags: financial`, `ddd_role: aggregate_root` | dual-layer idempotency (Redis + DB UNIQUE) for financial aggregates |


## v2 SKILL.md contract — inline rule_results (authoritative for N380 scanning)

Full rule definitions are in `references/v2-contract.md`.
This block exposes rule IDs and severity levels so N380 can aggregate without reading the reference file.

```yaml
artifact_schema_version: n170.v2.0.0
skill_name: idempotency-design-recommendation
produced_event: produced.n170.idempotency_design.v2
blocker_mapping: B02
rule_results:
  - rule_id: R01_all_write_apis_have_idempotency
    severity: reject
    check: "POST/PUT/PATCH/DELETE 必须有幂等判定或明确豁免"
    result: pass | warn | reject | not_applicable
  - rule_id: R02_dual_layer_for_critical
    severity: reject
    check: "financial/create_unique 必须 Redis + DB UNIQUE 双层兜底"
    result: pass | warn | reject | not_applicable
  - rule_id: R03_ttl_justified
    severity: reject
    check: "TTL 必须由重试窗口、重复窗口、合规或成本推导"
    result: pass | warn | reject | not_applicable
  - rule_id: R04_conflict_handling_4_cases_all
    severity: reject
    check: "4 态冲突处理必须完整"
    result: pass | warn | reject | not_applicable
  - rule_id: R05_l1_failure_graceful
    severity: reject
    check: "L1 失败必须有 fallback/reject 策略"
    result: pass | warn | reject | not_applicable
  - rule_id: R06_channel_specific_design
    severity: reject
    check: "非 HTTP 通道必须独立设计，不能复用 HTTP 文案"
    result: pass | warn | reject | not_applicable
  - rule_id: R07_test_scenarios_min_5
    severity: warn
    check: "关键 API 至少 5 个 TC-IDEM 场景"
    result: pass | warn | reject | not_applicable

route_back_to: none | n150 | n130
# none   — output complete; N180/N210/N260 may proceed
# n160   — data-model assumption fundamentally wrong; revise before task planning
# n130   — architectural choice incompatible with non-functional finding; escalate

eventbus_subscribers: [N330, N340]
# N330 → 技术与运维文档自动生成
# N340 → 协作知识沉淀
```
