---
name: idempotency-design-recommendation
description: design idempotency strategies from technical solution notes, vulnerability findings, schema drafts, permission constraints, api contracts, callback flows, or message-processing materials. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 幂等设计建议.md for n170 before task planning, implementation scaffolding, quality gates, or special testing.
---
# idempotency-design-recommendation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 幂等设计建议」。

它是 **direct_result** 型技能：目标是把重复请求、重试、重放、重复消费与去重策略落成可交付的 **`幂等设计建议.md`**，而不是停留在“加个幂等键”这类口号。

### Boundary / 边界
- 负责定义 operation 级幂等范围、key 生成方式、重复到达行为、存储策略与 TTL。
- 负责区分 API 幂等、消息消费幂等、Saga step 幂等、定时任务幂等。
- 不负责竞争资源序列化本身；该职责交给 `concurrency-control-recommendation`。
- 不负责错误码总表，但应为错误冲突、重复提交、重放冲突提供语义种子。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- `artifact_schema_version: n170.v2.0.0`
- stable ID following `IDEM-###`
- `produced_event: produced.n170.idempotency_design.v2`
- `blocker_mapping: B02`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `quick_design`：按 scope 快速给默认方案；默认模式。
- `analyzer`：审计现有方案是否真正幂等并指出缺口。
- `workflow_hardening`：对关键流程输出完整重试、重播、去重与降级策略。

## Primary inputs / 主要输入
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `api_specs(N150), data_flows(N160), concurrency_designs(049), business_rules(N070), messaging_channels(optional)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule / 独立使用规则
即使只有技术方案与 API / 流程描述，也可以单独使用。

降级规则：
- 若缺少实现细节，可先输出 provisional operation catalog。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的 scope、key、payload 规则。
- 不得假装系统已经具备 exactly-once 语义。

## Core output contract / 核心输出契约
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `幂等设计建议.md`
- primary output object: `idempotency_designs[]`
- stable ID: `IDEM-###`
- event: `produced.n170.idempotency_design.v2`
- blocker: `B02`
- stage: `technical_solution_design.advanced_design.idempotency_design`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules / 设计规则
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: P1-P6 key pattern、双层 Redis + DB 兜底、TTL rationale、4 态冲突处理和 6 通道覆盖.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R07 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B02` blocker signal.

## Execution workflow / 执行流程
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `idempotency_designs[]`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_053_performance, to_054_security, to_N230_test, to_N260_idempotency_test`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness / 动态完整度
- 单个 API：覆盖全部重试与重复提交路径
- 中型流程：覆盖 API、回调、消费与 Saga 关键步骤
- 大型系统：聚焦金融、合规、外部集成与高代价重复路径

## Quality bar / 质量门槛
合格结果应让实现和测试团队明确知道“哪些操作必须幂等、用什么 key、重复来时怎么处理”。

## Reference files / 参考文件
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
