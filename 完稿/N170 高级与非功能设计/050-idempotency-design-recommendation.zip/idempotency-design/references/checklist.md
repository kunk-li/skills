# V2 hard-gate checklist for idempotency-design-recommendation

Use this checklist before finalizing any N170 output. Treat `reject` failures as blocking unless the output is explicitly marked `readiness: blocked` with pending evidence.

## Required metadata

- [ ] `artifact_schema_version: n170.v2.0.0` is present.
- [ ] Design IDs follow `IDEM-###`.
- [ ] `produced_event: produced.n170.idempotency_design.v2` is present.
- [ ] `blocker_mapping: B02` is present.
- [ ] `confirmed / inferred / pending` evidence buckets are populated.

## Hard rules

- [ ] `R01_all_write_apis_have_idempotency` (reject): POST/PUT/PATCH/DELETE 必须有幂等判定或明确豁免
- [ ] `R02_dual_layer_for_critical` (reject): financial/create_unique 必须 Redis + DB UNIQUE 双层兜底
- [ ] `R03_ttl_justified` (reject): TTL 必须由重试窗口、重复窗口、合规或成本推导
- [ ] `R04_conflict_handling_4_cases_all` (reject): 4 态冲突处理必须完整
- [ ] `R05_l1_failure_graceful` (reject): L1 失败必须有 fallback/reject 策略
- [ ] `R06_channel_specific_design` (reject): 非 HTTP 通道必须独立设计，不能复用 HTTP 文案
- [ ] `R07_test_scenarios_min_5` (warn): 关键 API 至少 5 个 TC-IDEM 场景

## Cross-skill handoff

- [ ] `from_049_concurrency` handoff is explicit: `concurrency_designs[].design_id and same-key race tests` -> derived_from.concurrency_design_refs
- [ ] `to_053_performance` handoff is explicit: `storage_strategy, ttl_decision, observability.metrics` -> Redis/DB sizing, cache bottleneck and retry storm analysis
- [ ] `to_054_security` handoff is explicit: `webhook timestamp window, signature validation, replay-sensitive paths` -> replay threat controls
- [ ] `to_N260_idempotency_test` handoff is explicit: `derived_test_scenarios` -> 幂等专项测试点

- [ ] `R_ARCH_DECISION_COMMITTED` (reject): 本 skill 拥有的**架构决策**（幂等机制(幂等键载体/去重存储/CAS/token)）必须按**四步**拍定,绝不留 `pending`/`UNDETERMINED`/`BLOCKED-for-undefined`/空:① 查决策是否已存在(PRD/ADR/上游);② 查是否被订正(版本叠层);③ **有决策→遵循【现行】那个**(不照旧原文/不留空/不另套默认);④ 真无来源→用本 skill 工程默认(对声明需幂等的写接口配幂等键+唯一约束/去重表,不留无载体),标 `made_by=design_default`。留空是缺陷(本 skill 职责非可 defer 的 PRD 缺口;会被 026 误升 not_executable、下游推成 stub)。仅真正**产品输入**(风险偏好/业务阈值/外部基建)可留 `needs_decision`。
