# Performance bottleneck playbook — performance-risk-analysis

## B01-B10 investigation → mitigation playbook

### B01 CPU-bound
**Investigation**: `top`/`htop`, flame graph (async-profiler, py-spy), CPU usage per endpoint
**Root causes**: synchronous crypto, regex on hot path, N+1 DB queries returning large datasets, unbounded serialization
**Mitigations**:
- Move heavy computation to async background job
- Cache results of expensive computations (memoization)
- Optimize regex: pre-compile, avoid catastrophic backtracking
- Use SIMD-optimized libraries for bulk transforms

### B02 Memory-bound
**Investigation**: heap dump, GC log analysis, `jstat -gcutil`, RSS growth trend over 24h
**Root causes**: large in-memory caches without eviction, stream not closed, holding references in static maps
**Mitigations**:
- Set explicit cache bounds (max size + LRU eviction)
- Use streaming instead of loading entire dataset into memory
- Switch to off-heap storage for large caches (Redis, Memcached)

### B03 Disk I/O bound
**Investigation**: `iostat -x`, slow query log, `iowait` in `vmstat`, IOPS/throughput metrics
**Root causes**: full table scans (missing index), write-heavy workload on spinning disk, log file flooding
**Mitigations**:
- Add indexes → delegate to 047
- Switch to SSD/NVMe for high-IOPS workloads
- Separate write-heavy logs to dedicated disk/volume

### B04 Network I/O bound
**Investigation**: network utilization graph, per-hop latency via distributed tracing, TCP retransmit rate
**Root causes**: chatty microservices (many small calls), uncompressed payloads, cross-region calls on hot path
**Mitigations**:
- Batch API calls (GraphQL, gRPC streaming, or request coalescing)
- Enable gzip/br compression for large payloads
- Co-locate frequently-communicating services in same AZ

### B05 Database bottleneck
**Investigation**: `SHOW PROCESSLIST`, `SHOW ENGINE INNODB STATUS`, slow query log, connection pool metrics
**Root causes**: connection pool exhaustion, N+1 queries, missing indexes, table scans on large tables
**Mitigations**:
- Right-size connection pool (min/max per app instance)
- Add read replica for read-heavy endpoints
- Query plan optimization → delegate to 047

### B06 Cache bottleneck
**Investigation**: Redis `INFO stats` (hit rate, evicted_keys), hot key analysis (`redis-cli --hotkeys`)
**Root causes**: hot key (single key receiving >80% of traffic), cache stampede on TTL expiry, cache too small
**Mitigations**:
- Local L1 cache (in-process) + Redis L2 for hot keys
- Singleflight/coalesce to prevent stampede
- Random TTL jitter (TTL ± 10%) to spread expiry

### B07 External dependency bottleneck
**Investigation**: per-dependency p99 latency in tracing, timeout rate, dependency SLA dashboard
**Root causes**: third-party API slow, no circuit breaker, synchronous call on critical path
**Mitigations**:
- Circuit breaker (Resilience4j, Hystrix) with fallback
- Async outbox pattern → delegate to 048
- Shadow mode: async enrichment, return without waiting

### B08 Concurrency contention
**Investigation**: lock wait time (`SHOW ENGINE INNODB STATUS`), thread pool queue depth, deadlock rate
**Root causes**: lock ordering violations → deadlock, table-level locks, hotspot rows
**Mitigations**:
- Canonical lock ordering → delegate to 049
- Optimistic locking (version field) for low-conflict scenarios
- Queue serialization for high-contention entities

### B09 Queue backlog
**Investigation**: consumer lag (`kafka-consumer-groups.sh`), DLQ depth, processing time vs arrival rate
**Root causes**: consumer slower than producer, downstream dependency throttling consumers, single consumer
**Mitigations**:
- HPA on lag metric (KEDA for Kafka)
- Increase consumer count (partitions must be ≥ consumers)
- Priority queue for time-sensitive messages

### B10 GC pause
**Investigation**: GC log (`-Xloggc:`, `-XX:+PrintGCDetails`), JVM GC pause histogram, GC overhead %
**Root causes**: large object allocation in hot path, heap fragmentation, GC algorithm mismatch
**Mitigations**:
- Switch to G1GC (balanced) or ZGC/Shenandoah (low-pause)
- Tune heap: `-Xms` = `-Xmx` to avoid resize pauses
- Reduce allocation: object pooling, reuse buffers, avoid `String +` in loops

## Capacity planning formulas

| Estimate | Formula | Example |
|---|---|---|
| Peak QPS → instances | `ceil(peak_qps ÷ (qps_per_instance × 0.7))` | 2000 qps ÷ (500 × 0.7) = 6 instances |
| DB connections needed | `instances × pool_max_per_instance` | 6 × 10 = 60 connections |
| Redis memory needed | `avg_value_size × key_count × replication_factor` | 2KB × 1M × 3 = 6GB |
| Year-N QPS | `current_qps × growth_rate^n` | 800 × 2^3 = 6400 qps (3-year, 2× growth) |
