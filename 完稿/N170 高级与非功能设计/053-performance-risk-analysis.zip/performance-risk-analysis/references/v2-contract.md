# N170 v2 contract: performance-risk-analysis

性能风险：SLO 三态、10 类瓶颈 checklist、主动设计 hints、压测计划、3 年容量模型、降级策略。

## Metadata contract

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: performance-risk-analysis
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.performance_risk_analysis
  node_artifact_target: 性能风险分析.md
  design_id_pattern: "PERF-\\d{3,}"
  produced_event: produced.n170.performance_design.v2
  blocker_mapping: B04
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Input schema with workflow sources

| field | required | from | purpose |
| --- | --- | --- | --- |
| `api_specs` | required | N150 | nfr_targets and API criticality |
| `data_flows` | required | N160 | sync/async/batch/flow shape |
| `tables_and_indexes` | required | N160 | table/index hotspots |
| `concurrency_designs` | required | 049 | locks and contention assumptions |
| `volume_projections` | required | context | year_1 and year_3 projections |
| `existing_perf_data` | optional | runtime/context | baseline benchmark |

## Required output schema

- `performance_designs[].design_id: PERF-\d{3,}`
- `target_scope: API/flow/module`
- `slo_triplet.ideal + target + floor with latency_p99, throughput, availability, error_rate`
- `bottleneck_analysis.B01_cpu_bound through B10_gc_pause each with at_risk and mitigation`
- `proactive_design_hints: caching, read_write_separation, batch_processing, async_where_possible, connection_pooling, denormalization, lazy/eager, precomputation`
- `performance_test_plan: load, stress, spike, soak, breakpoint + tools + environment`
- `capacity_model: unit_of_work, current_capacity, projected_capacity.year_1/year_3, scaling_plan`
- `degradation_strategy.when_triggered + actions + derived_from`

## Hard gate rules

| rule | check | on violation |
| --- | --- | --- |
| `R01_slo_triplet_complete` | ideal/target/floor 三态必须完整 | `reject` |
| `R02_10_bottleneck_all_analyzed` | B01-B10 必须逐项扫描 | `reject` |
| `R03_capacity_projected_3y` | 容量规划至少包含 year_1 和 year_3 | `reject` |
| `R04_test_plan_derived` | 必须自动派生压测计划 | `reject` |
| `R05_degradation_strategy_required` | 每个性能设计必须有降级策略 | `reject` |
| `R06_critical_bottleneck_has_mitigation` | at_risk=true 必须有 mitigation | `reject` |
| `R07_assumption_marking` | 无 benchmark 的数值必须标为 assumption | `warn` |

## Algorithms and decision logic

- slo_derivation: ideal = target * 0.5 latency; target = nfr_targets; floor = target * 2 latency or agreed incident threshold.
- bottleneck_identification_B01_B10: CPU-heavy transformations -> B01; large objects/cache growth -> B02; random IO or index scans -> B03; cross-zone/vendor calls -> B04/B07; DB writes, slow queries, lock contention -> B05; hot keys/cache stampede -> B06; thread pools/locks/deadlock retries -> B08; message consumers and async fanout -> B09; JVM heap and stop-the-world pauses -> B10.
- at_risk_rule: every B01-B10 item must be present; when `at_risk: true`, mitigation is mandatory and must be testable or observable.
- capacity_projection: projected_qps = current_or_expected_qps * growth_rate^years; start linear, then define step thresholds for shards/replicas and include year_1 and year_3.
- test_plan_derivation: load test validates target; stress finds breaking point; spike validates burst/autoscale; soak validates leaks/GC; breakpoint is optional but must be explicit.

## Field-level handoff

| link | fields produced/consumed | downstream use |
| --- | --- | --- |
| `from_049_concurrency` | `locking_strategy, lock_contention_estimate` | B08_concurrency_contention |
| `from_050_idempotency` | `storage_strategy, ttl_decision, retry paths` | B05/B06 capacity and retry storm risk |
| `to_N230_performance_test` | `performance_test_plan` | 压测场景 |
| `to_N300_monitoring` | `slo_triplet and degradation_strategy` | SLI metrics and alerts |

## Blocker and event output

```yaml
blocker_signal:
  blocker_id: B04
  source_skill: performance-risk-analysis
  rule_id: Rxx
  severity: reject | warn
  evidence: []
  recommended_owner: product | engineering | qa | security | compliance
event:
  produced: produced.n170.performance_design.v2
  schema_version: n170.v2.0.0
```

## Minimal worked example

```yaml
design_id: PERF-001
target_scope: API-ORDER-CREATE
slo_triplet.target.metrics.latency_p99: 300ms
slo_triplet.floor.action_when_breached: alert + auto mitigation + incident
bottleneck_analysis.B05_database_bottleneck.at_risk: true
bottleneck_analysis.B08_concurrency_contention.at_risk: true
performance_test_plan.test_types.load_test.scenario: 2000 qps sustained for 1h
capacity_model.projected_capacity.year_3.expected_qps: 6000 qps
```

## Standalone behavior

When upstream evidence is missing, still produce a useful provisional artifact. Mark missing source fields as `pending`, inferred design as `inferred`, and hard-gate failures as `blocked` only when the missing evidence prevents a safe recommendation.