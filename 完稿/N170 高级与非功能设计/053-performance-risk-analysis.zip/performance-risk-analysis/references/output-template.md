# Output template: performance-risk-analysis v2

Start every answer with the following metadata block when producing a deliverable.

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: performance-risk-analysis
  workflow_node: N170
  stage_position: technical_solution_design.advanced_design.performance_risk_analysis
  node_artifact_target: 性能风险分析.md
  design_id_pattern: "PERF-\d{3,}"
  produced_event: produced.n170.performance_design.v2
  blocker_mapping: B04
  selected_mode: <mode>
  readiness: ready | provisional | blocked
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
```

## Required sections

- `performance_designs[].design_id: PERF-\d{3,}`
- `target_scope: API/flow/module`
- `slo_triplet.ideal + target + floor with latency_p99, throughput, availability, error_rate`
- `bottleneck_analysis.B01_cpu_bound through B10_gc_pause each with at_risk and mitigation`
- `proactive_design_hints: caching, read_write_separation, batch_processing, async_where_possible, connection_pooling, denormalization, lazy/eager, precomputation`
- `performance_test_plan: load, stress, spike, soak, breakpoint + tools + environment`
- `capacity_model: unit_of_work, current_capacity, projected_capacity.year_1/year_3, scaling_plan`
- `degradation_strategy.when_triggered + actions + derived_from`

## Machine-readable appendix

At the end of the markdown report, include a compact YAML appendix containing stable IDs, rule results, blocker signals, and downstream handoff.

```yaml
contract_appendix:
  id_prefix: PERF
  produced_event: produced.n170.performance_design.v2
  blocker_mapping: B04
  rule_results:
    - rule_id: R01
      status: pass | warn | reject | not_applicable
      evidence: []
  downstream_handoff: []
```
