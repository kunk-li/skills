# Example I/O: performance-risk-analysis v2.1

## ex-001 · order create performance design

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: performance-risk-analysis
  workflow_node: N170
  node_artifact_target: 性能风险分析.md
  selected_mode: deep_analysis
  readiness: provisional
  design_id_pattern: "PERF-\\d{3,}"
  produced_event: produced.n170.performance_design.v2
  blocker_mapping: B04
  evidence_profile:
    confirmed: [API-ORDER-CREATE, CON-001, IDEM-001]
    inferred: [year_3 growth 2x]
    pending: [baseline load test]
performance_designs:
  - design_id: PERF-001
    target_scope: API-ORDER-CREATE
    slo_triplet:
      ideal: {metrics: {latency_p99: 100ms, throughput: "3000 qps", availability: "99.99%", error_rate: "0.01%"}}
      target: {metrics: {latency_p99: 300ms, throughput: "2000 qps", availability: "99.95%", error_rate: "0.1%"}}
      floor:
        metrics: {latency_p99: 1000ms, throughput: "1000 qps", availability: "99.5%", error_rate: "1%"}
        action_when_breached: alert + auto mitigation + incident
    bottleneck_analysis:
      B01_cpu_bound: {at_risk: false, potential_hotspots: [], mitigation: monitor CPU saturation}
      B02_memory_bound: {at_risk: false, concerns: [heap_size, gc_pressure], mitigation: heap and GC dashboards}
      B03_io_bound_disk: {at_risk: false, concerns: [random_io], mitigation: index review}
      B04_io_bound_network: {at_risk: true, concerns: [latency_to_dependencies], mitigation: timeout and circuit breaker}
      B05_database_bottleneck: {at_risk: true, concerns: [connection_pool_exhaustion, lock_contention], mitigation: pool sizing and unique-index monitoring}
      B06_cache_bottleneck: {at_risk: true, concerns: [hot_key, cache_stampede], mitigation: local cache + singleflight}
      B07_external_dependency: {at_risk: true, concerns: [third_party_latency], mitigation: async outbox where possible}
      B08_concurrency_contention: {at_risk: true, concerns: [lock_wait, duplicate key conflicts], mitigation: CON-001 + IDEM-001 tests}
      B09_queue_backlog: {at_risk: true, concerns: [consumer_lag, dlq_growth], mitigation: lag alerts and worker autoscale}
      B10_gc_pause: {at_risk: false, concerns: [stop_the_world_events], mitigation: GC dashboard}
    performance_test_plan:
      test_types:
        load_test: {enabled: true, scenario: target QPS for 1h, success_criteria: p99 < 300ms and error_rate < 0.1%}
        stress_test: {enabled: true, scenario: increase QPS to breaking point, observe: degradation behavior}
        spike_test: {enabled: true, scenario: 0 to 3x target, observe: autoscale and queue backlog}
        soak_test: {enabled: true, scenario: 50% target for 24h, observe: memory leak and GC}
        breakpoint_test: {enabled: false, scenario: find system limit}
      tools: {recommended: k6}
    capacity_model:
      unit_of_work: 1 order create = DB insert + idempotency read/write + audit event
      current_capacity: {at_current_infra: {max_qps: pending, headroom_percentage: pending}}
      projected_capacity:
        year_1: {expected_qps: "3000", infra_needed: "+2 app nodes + DB pool increase", cost_estimate: pending}
        year_3: {expected_qps: "6000", infra_needed: "DB write scaling review", cost_estimate: pending}
      scaling_plan: {horizontal_scaling: {possible: true, mechanism: kubernetes_hpa, triggers: [CPU > 70% for 5m]}, sharding_strategy: {needed_at: "10M users", strategy: user_id shard}}
    degradation_strategy:
      when_triggered: floor breached
      actions:
        - {action: reject_low_priority, scope: non-critical exports, user_communication: retry later}
        - {action: circuit_breaker_open, scope: third-party enrichment, user_communication: degraded experience notice}
    derived_from:
      api_refs: [API-ORDER-CREATE]
      flow_refs: [FLOW-ORDER-CREATE]
      requirement_refs: [REQ-PERF-001]
rule_results:
  - {rule_id: R02_10_bottleneck_all_analyzed, status: pass, evidence: [B01_cpu_bound, B10_gc_pause]}
  - {rule_id: R03_capacity_projected_3y, status: pass, evidence: [year_1, year_3]}
  - {rule_id: R06_critical_bottleneck_has_mitigation, status: pass, evidence: [B05_database_bottleneck.mitigation]}
blocker_signals:
  - {blocker_id: B04, source_skill: performance-risk-analysis, rule_id: R03_capacity_projected_3y, severity: warn, evidence: [cost_estimate: pending], recommended_owner: engineering}
contract_appendix:
  id_prefix: PERF
  produced_event: produced.n170.performance_design.v2
  downstream_handoff:
    to_N260_performance_scenarios: [load_test, stress_test, spike_test, soak_test]
    to_N300_monitoring: [slo_triplet, degradation_strategy]
```

## ex-003 · capacity_planning mode — order service 3-year projection

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: performance-risk-analysis
  selected_mode: capacity_planning
  readiness: provisional
  evidence_profile:
    confirmed: [API-ORDER-CREATE, CON-001, current_monthly_orders_500k]
    inferred: [2x YoY growth, p99 latency 200ms current]
    pending: [actual DB IOPS measurement, cache hit rate]

performance_designs:
  - design_id: PERF-003
    target_scope: OrderService — full capacity model
    slo_triplet:
      target: {metrics: {latency_p99: 300ms, throughput: "2000 qps", availability: "99.95%"}}
      floor:  {metrics: {latency_p99: 1000ms, throughput: "1000 qps", availability: "99.5%"}}

    capacity_model:
      unit_of_work: "1 order create = 1 DB write (orders) + 1 idempotency read/write (Redis) + 1 outbox insert + 1 audit event"
      baseline_measurement:
        current_monthly_orders: 500_000
        current_peak_qps: 800
        current_infra: {app_nodes: 2, db: "single primary MySQL 8 r5.xlarge", redis: "3-node cluster m5.large"}

      projected_capacity:
        year_1:
          expected_monthly_orders: 1_000_000
          expected_peak_qps: 1600
          bottleneck_forecast: "DB write throughput approaches limit at ~1500 qps sustained"
          infra_delta:
            app_nodes: "+1 (3 total)"
            db: "add read replica for status queries"
            redis: "no change"
          cost_estimate_usd_monthly: "+$400 app node, +$300 replica = +$700/mo"
          action_required: "provision read replica before QPS exceeds 1200"

        year_3:
          expected_monthly_orders: 4_000_000
          expected_peak_qps: 6400
          bottleneck_forecast: "Single primary DB cannot sustain; sharding or write scaling required"
          infra_delta:
            app_nodes: "+4 (6 total via HPA)"
            db: "DB write scaling decision needed — options: PlanetScale, Vitess shard, or CQRS with event sourcing"
            redis: "upgrade to r6g.xlarge cluster"
          cost_estimate_usd_monthly: "DB scaling cost TBD (pending DB write scaling decision)"
          decision_gate: "DB write scaling architecture must be decided before monthly orders exceed 2M"

      scaling_plan:
        horizontal_scaling:
          possible: true
          mechanism: kubernetes_hpa
          trigger: "CPU > 70% for 5min OR p99 > 200ms for 2min"
        vertical_scaling:
          app: "not recommended — scale out preferred"
          db: "upgrade instance class before write scaling decision"
        sharding_strategy:
          trigger: "monthly orders > 2M sustained"
          candidate_key: order_id (hash-based)
          migration_complexity: high
          prerequisite: "resolve shared DB risk BRISK-001 first"

    proactive_design_hints:
      caching: "cache order status in Redis with 60s TTL; invalidate on state change"
      read_write_separation: "route status queries to read replica at year_1"
      async_where_possible: "audit event via outbox — already planned"
      connection_pooling: "DB pool: min=10, max=50 per app node; monitor active_connections metric"
      precomputation: "pre-aggregate daily order counts for analytics; do not query raw orders table"

    rule_results:
      - {rule_id: R03_capacity_projected_3y, status: pass, evidence: [year_1, year_3]}
      - {rule_id: R07_assumption_marking, status: warn, evidence: [DB_IOPS marked pending, cache_hit_rate marked inferred]}

    contract_appendix:
      id_prefix: PERF
      downstream_handoff:
        to_N260_performance_scenarios: [capacity_model.year_1.bottleneck_forecast]
        to_N300_monitoring: [scaling_plan.horizontal_scaling.trigger]
```

## ex-004 · SLO floor breach — degradation simulation

```yaml
# Negative case: floor breach without degradation strategy
floor_breach_negative_case:
  scenario: "B09_queue_backlog breaches floor: consumer lag > 10k messages, p99 latency > 1000ms"
  missing_control: "No degradation_strategy defined — system continues accepting requests at full rate"
  consequence: "Queue backlog grows unbounded; memory pressure causes OOM; full system outage"

  correct_degradation_response:
    when_triggered: "p99 > floor.metrics.latency_p99 (1000ms) OR queue_lag > 10000 messages for 2 consecutive minutes"
    actions:
      - action: reject_low_priority_requests
        scope: "non-critical bulk export endpoints"
        implementation: "Feature flag via LaunchDarkly; returns 503 with Retry-After header"
        user_communication: "Exports temporarily unavailable. Please retry in 15 minutes."
      - action: scale_consumers
        scope: "Order processing queue consumers"
        implementation: "Kubernetes HPA triggered by custom metric: kafka_consumer_lag > 5000"
        expected_recovery_time: "< 3 minutes for HPA to provision additional consumer pods"
      - action: circuit_breaker_open
        scope: "Third-party enrichment calls (non-critical)"
        implementation: "Resilience4j circuit breaker; returns cached or degraded response"
        user_communication: "Some product details may be temporarily unavailable."
    recovery_condition: "p99 < target (300ms) AND queue_lag < 1000 for 5 consecutive minutes"

  test_this_scenario:
    test_id: TC-PERF-DEGRADE-001
    tooling: k6
    scenario: "Inject 10x normal traffic for 5 minutes; verify degradation actions trigger; verify recovery"
    success_criteria:
      - "Degradation triggers within 2 minutes of threshold breach"
      - "Low-priority requests rejected with 503 (not 500)"
      - "System recovers to target SLO within 5 minutes after traffic normalizes"
```

## ex-005 · blocked — no NFR targets defined anywhere

```yaml
skill_name: performance-risk-analysis
readiness: blocked
blocker_mapping: B-N170-04
route_back_to: technical-solution-draft-generation

blockers:
  - blocker_id: BLK-PERF-001
    type: missing_nfr_targets
    description: "S6_non_functional_design in the solution draft is entirely 'status: to_confirm' — no latency targets, throughput targets, or availability SLA defined"
    impact: "Cannot produce SLO triplet (ideal/target/floor) without baseline NFR targets. All B01-B10 at_risk assessments require performance thresholds."
    resolution_required: "Product owner must define minimum NFR targets: p99 latency, throughput at peak, availability SLA"
    unblock_evidence: "S6 with at least: latency_p99 target, peak_qps estimate, availability percentage"

  - blocker_id: BLK-PERF-002
    type: missing_baseline_metrics
    description: "System is greenfield — no production baseline exists. Cannot confirm B01-B10 assumptions without load test data."
    impact: "All bottleneck assessments are speculative without baseline"
    resolution_required: "Run capacity planning exercise with product team, or accept provisional assessment with explicit assumptions"
    unblock_evidence: "Either: production baseline data, OR explicit product owner sign-off on assumed NFR targets"

provisional_slo:
  note: "Industry defaults used as provisional targets — require product owner approval before implementation"
  target:
    latency_p99: "500ms (industry default for internal CRUD operations)"
    throughput: "100 qps (estimated from 10k users × 1 action per 100s)"
    availability: "99.9% (3 nines — standard for non-financial internal tools)"
  confidence: inferred
  requires_approval: true
```
