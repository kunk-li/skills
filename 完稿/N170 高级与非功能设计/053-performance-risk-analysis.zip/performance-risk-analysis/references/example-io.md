# Example I/O: performance-risk-analysis v2.1

## ex-001 · order create performance design

```yaml
metadata:
  artifact_schema_version: n170.v2.0.0
  skill_id: performance-risk-analysis
  workflow_node: N170
  node_artifact_target: 性能风险分析.md
  selected_mode: deep_analysis
  readiness: provisional
  design_id_pattern: "PERF-\\d{3,}"
  produced_event: produced.n170.performance_design.v2
  blocker_mapping: B04
  evidence_profile:
    confirmed: [API-ORDER-CREATE, CON-001, IDEM-001]
    inferred: [year_3 growth 2x]
    pending: [baseline load test]
performance_designs:
  - design_id: PERF-001
    target_scope: API-ORDER-CREATE
    slo_triplet:
      ideal: {metrics: {latency_p99: 100ms, throughput: "3000 qps", availability: "99.99%", error_rate: "0.01%"}}
      target: {metrics: {latency_p99: 300ms, throughput: "2000 qps", availability: "99.95%", error_rate: "0.1%"}}
      floor:
        metrics: {latency_p99: 1000ms, throughput: "1000 qps", availability: "99.5%", error_rate: "1%"}
        action_when_breached: alert + auto mitigation + incident
    bottleneck_analysis:
      B01_cpu_bound: {at_risk: false, potential_hotspots: [], mitigation: monitor CPU saturation}
      B02_memory_bound: {at_risk: false, concerns: [heap_size, gc_pressure], mitigation: heap and GC dashboards}
      B03_io_bound_disk: {at_risk: false, concerns: [random_io], mitigation: index review}
      B04_io_bound_network: {at_risk: true, concerns: [latency_to_dependencies], mitigation: timeout and circuit breaker}
      B05_database_bottleneck: {at_risk: true, concerns: [connection_pool_exhaustion, lock_contention], mitigation: pool sizing and unique-index monitoring}
      B06_cache_bottleneck: {at_risk: true, concerns: [hot_key, cache_stampede], mitigation: local cache + singleflight}
      B07_external_dependency: {at_risk: true, concerns: [third_party_latency], mitigation: async outbox where possible}
      B08_concurrency_contention: {at_risk: true, concerns: [lock_wait, duplicate key conflicts], mitigation: CON-001 + IDEM-001 tests}
      B09_queue_backlog: {at_risk: true, concerns: [consumer_lag, dlq_growth], mitigation: lag alerts and worker autoscale}
      B10_gc_pause: {at_risk: false, concerns: [stop_the_world_events], mitigation: GC dashboard}
    performance_test_plan:
      test_types:
        load_test: {enabled: true, scenario: target QPS for 1h, success_criteria: p99 < 300ms and error_rate < 0.1%}
        stress_test: {enabled: true, scenario: increase QPS to breaking point, observe: degradation behavior}
        spike_test: {enabled: true, scenario: 0 to 3x target, observe: autoscale and queue backlog}
        soak_test: {enabled: true, scenario: 50% target for 24h, observe: memory leak and GC}
        breakpoint_test: {enabled: false, scenario: find system limit}
      tools: {recommended: k6}
    capacity_model:
      unit_of_work: 1 order create = DB insert + idempotency read/write + audit event
      current_capacity: {at_current_infra: {max_qps: pending, headroom_percentage: pending}}
      projected_capacity:
        year_1: {expected_qps: "3000", infra_needed: "+2 app nodes + DB pool increase", cost_estimate: pending}
        year_3: {expected_qps: "6000", infra_needed: "DB write scaling review", cost_estimate: pending}
      scaling_plan: {horizontal_scaling: {possible: true, mechanism: kubernetes_hpa, triggers: [CPU > 70% for 5m]}, sharding_strategy: {needed_at: "10M users", strategy: user_id shard}}
    degradation_strategy:
      when_triggered: floor breached
      actions:
        - {action: reject_low_priority, scope: non-critical exports, user_communication: retry later}
        - {action: circuit_breaker_open, scope: third-party enrichment, user_communication: degraded experience notice}
    derived_from:
      api_refs: [API-ORDER-CREATE]
      flow_refs: [FLOW-ORDER-CREATE]
      requirement_refs: [REQ-PERF-001]
rule_results:
  - {rule_id: R02_10_bottleneck_all_analyzed, status: pass, evidence: [B01_cpu_bound, B10_gc_pause]}
  - {rule_id: R03_capacity_projected_3y, status: pass, evidence: [year_1, year_3]}
  - {rule_id: R06_critical_bottleneck_has_mitigation, status: pass, evidence: [B05_database_bottleneck.mitigation]}
blocker_signals:
  - {blocker_id: B04, source_skill: performance-risk-analysis, rule_id: R03_capacity_projected_3y, severity: warn, evidence: [cost_estimate: pending], recommended_owner: engineering}
contract_appendix:
  id_prefix: PERF
  produced_event: produced.n170.performance_design.v2
  downstream_handoff:
    to_N260_performance_scenarios: [load_test, stress_test, spike_test, soak_test]
    to_N300_monitoring: [slo_triplet, degradation_strategy]
```
