# Common failure modes for performance risk analysis

## F1: listing generic bottlenecks with no business path
Symptom: the output says "database may be slow" without naming the affected flow.
Fix: tie every risk to a concrete path and affected slo.

## F2: focusing only on average load
Symptom: the design ignores bursts, batch windows, or callback storms.
Fix: include peak and abnormal patterns explicitly.

## F3: treating cache as a guaranteed fix
Symptom: the output recommends caching without addressing invalidation, cold starts, or stampedes.
Fix: mention cache limits and fallback behavior.

## F4: ignoring queue and worker backlog
Symptom: async work exists but queue depth and drain rate are never discussed.
Fix: include backlog, retry, and freshness lag in the analysis.

## F5: promising precise numbers without evidence
Symptom: exact latency or capacity claims appear without load data.
Fix: label inferred targets as assumptions and say what must be measured later.

## V2.1 contract failure modes

## F6: incomplete B01-B10 scan
Symptom: bottlenecks are listed selectively and omit cache, queue, or GC.
Fix: include all B01_cpu_bound through B10_gc_pause with `at_risk` and mitigation.

## F7: no floor-triggered degradation
Symptom: SLOs exist but the floor breach has no operational action.
Fix: set `floor.action_when_breached` and `degradation_strategy.actions[]`.

## F8: ignoring 049/050 costs
Symptom: lock contention, idempotency storage, and dedupe tests are absent from capacity planning.
Fix: consume CON/IDEM handoff fields and map them into B05/B06/B08 risks.

## F9: contract appendix drift
Symptom: the markdown narrative says one thing while `contract_appendix` exposes different IDs, rule results, or handoff fields.
Fix: reconcile narrative and appendix before finalizing; the appendix is what downstream automation consumes.

## F10: blocker without owner or remediation
Symptom: a warning or reject is emitted but no owner, evidence, or next action is named.
Fix: every `blocker_signals[]` item must include `recommended_owner`, evidence, and a remediation hint or pending evidence field.
