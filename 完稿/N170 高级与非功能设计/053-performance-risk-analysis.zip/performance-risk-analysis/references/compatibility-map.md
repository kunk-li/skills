# Compatibility map — performance-risk-analysis v2 alignment

## Input artifact field mapping
| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 049 concurrency-control-recommendation | `locking_strategy, lock_contention_estimate` | `B08_concurrency_contention` | lock contention feeds bottleneck B08 analysis |
| 050 idempotency-design-recommendation | `storage_strategy, ttl_decision, retry paths` | `B05/B06 Redis/DB sizing` | idempotency storage feeds cache and DB bottleneck analysis |
| 046 table-schema-design-recommendation | `table_id, volume estimates` | `B03/B05 bottleneck candidates` | table volume projections seed database bottleneck analysis |

## Output artifact field mapping
| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| N230 performance-test | `performance_test_plan (5 types)` | `test scenario specification` | test plan becomes performance test suite input |
| N300 monitoring | `slo_triplet, degradation_strategy` | `SLI metrics, alert thresholds` | SLO triplet becomes monitoring dashboard definition |
| N180 planning | `capacity_model.year_1/year_3` | `infrastructure planning` | capacity projections inform sprint and infrastructure planning |

## v2 contract cross-reference
| v2 field | Purpose | Consumer |
|---|---|---|
| `produced_event` | Event bus trigger | N330, N340 |
| `blocker_mapping` | SLA queue key | N380 |
| `rule_results[]` | Gate pass/warn/reject | N380 |
| `route_back_to` | Return path on gap | Upstream skill |
