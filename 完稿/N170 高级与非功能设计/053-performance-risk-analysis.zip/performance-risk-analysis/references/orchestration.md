# V2 orchestration for performance-risk-analysis

## Execution modes

- Standalone: produce this skill artifact only. Use `readiness: provisional` when upstream fields are missing.
- N170 batch: use `references/n170-integration-map.md` and keep IDs stable across all six artifacts.
- Gate mode: emit reject/warn results from `references/v2-contract.md` rules and map them to the blocker ID.

## Input normalization

Normalize incoming file names into typed N170 evidence:

| field | required | from | purpose |
| --- | --- | --- | --- |
| `api_specs` | required | N150 | nfr_targets and API criticality |
| `data_flows` | required | N160 | sync/async/batch/flow shape |
| `tables_and_indexes` | required | N160 | table/index hotspots |
| `concurrency_designs` | required | 049 | locks and contention assumptions |
| `volume_projections` | required | context | year_1 and year_3 projections |
| `existing_perf_data` | optional | runtime/context | baseline benchmark |

## Output event

```yaml
event:
  produced: produced.n170.performance_design.v2
  schema_version: n170.v2.0.0
  artifact: 性能风险分析.md
  blocker_mapping: B04
```

## Field-level handoff for this skill

| link | fields | downstream use |
| --- | --- | --- |
| `from_049_concurrency` | `locking_strategy, lock_contention_estimate` | B08_concurrency_contention |
| `from_050_idempotency` | `storage_strategy, ttl_decision, retry paths` | B05/B06 capacity and retry storm risk |
| `to_N230_performance_test` | `performance_test_plan` | 压测场景 |
| `to_N300_monitoring` | `slo_triplet and degradation_strategy` | SLI metrics and alerts |
