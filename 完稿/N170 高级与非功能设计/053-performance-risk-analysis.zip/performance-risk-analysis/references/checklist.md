# V2 hard-gate checklist for performance-risk-analysis

Use this checklist before finalizing any N170 output. Treat `reject` failures as blocking unless the output is explicitly marked `readiness: blocked` with pending evidence.

## Required metadata

- [ ] `artifact_schema_version: n170.v2.0.0` is present.
- [ ] Design IDs follow `PERF-###`.
- [ ] `produced_event: produced.n170.performance_design.v2` is present.
- [ ] `blocker_mapping: B04` is present.
- [ ] `confirmed / inferred / pending` evidence buckets are populated.

## Hard rules

- [ ] `R01_slo_triplet_complete` (reject): ideal/target/floor 三态必须完整
- [ ] `R02_10_bottleneck_all_analyzed` (reject): B01-B10 必须逐项扫描
- [ ] `R03_capacity_projected_3y` (reject): 容量规划至少包含 year_1 和 year_3
- [ ] `R04_test_plan_derived` (reject): 必须自动派生压测计划
- [ ] `R05_degradation_strategy_required` (reject): 每个性能设计必须有降级策略
- [ ] `R06_critical_bottleneck_has_mitigation` (reject): at_risk=true 必须有 mitigation
- [ ] `R07_assumption_marking` (warn): 无 benchmark 的数值必须标为 assumption
- [ ] `R08_resilience_stance_on_boundary_deps` (warn): 跨边界依赖 at_risk=true 时,mitigation 须就超时/重试(含刻意不重试)/级联保护(或 by-design 接受)/资源隔离(或非共享)四面各表立场;非 at_risk 或资源非共享标 not_applicable

## Cross-skill handoff

- [ ] `from_049_concurrency` handoff is explicit: `locking_strategy, lock_contention_estimate` -> B08_concurrency_contention
- [ ] `from_050_idempotency` handoff is explicit: `storage_strategy, ttl_decision, retry paths` -> B05/B06 capacity and retry storm risk
- [ ] `to_N230_performance_test` handoff is explicit: `performance_test_plan` -> 压测场景
- [ ] `to_N300_monitoring` handoff is explicit: `slo_triplet and degradation_strategy` -> SLI metrics and alerts
