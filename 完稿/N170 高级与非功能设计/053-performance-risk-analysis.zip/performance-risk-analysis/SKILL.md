---
name: performance-risk-analysis
description: analyze performance risks, hotspots, bottlenecks, capacity assumptions, and degradation plans from technical solution notes, vulnerability findings, schema drafts, permission constraints, api surfaces, and data-flow evidence. use when chatgpt works in technical solution design / advanced design and must produce the workflow-aligned 性能风险分析.md for n170 before task planning, implementation review, quality gates, or governance review.
---
# performance-risk-analysis

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> 高级设计 -> 性能风险分析」。

它是 **direct_result** 型技能：目标是把 SLO、热点、瓶颈、资源预算、降级策略与压测计划落成可交付的 **`性能风险分析.md`**，而不是只给“可能会慢”这类定性提醒。

### Boundary / 边界
- 负责建立 SLO 论证链、热点扫描、瓶颈判断、容量预算、降级矩阵与压测计划。
- 负责把 schema、数据流、接口与依赖关系转成性能风险清单。
- 不替代并发与幂等设计，但应消费它们的约束并暴露交汇风险。
- 不替代安全威胁建模，但要识别 DoS、滥用与依赖级雪崩的性能后果。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- `artifact_schema_version: n170.v2.0.0`
- stable ID following `PERF-###`
- `produced_event: produced.n170.performance_design.v2`
- `blocker_mapping: B04`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `hotspot_scan`：快速识别热点与瓶颈；默认模式。
- `capacity_planning`：重点输出资源预算与扩容余量。
- `perf_test_planning`：重点输出压测场景、环境与通过条件。

## Primary inputs / 主要输入
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `api_specs(N150), data_flows(N160), tables_and_indexes(N160), concurrency_designs(049), volume_projections, existing_perf_data(optional)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule / 独立使用规则
即使只有技术方案与粗略流量预期，也可以单独使用。

降级规则：
- 若没有真实 benchmark，只能给 `assumed SLO` 与容量估算。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的负载、SLO、资源与风险。
- 不得把设计推断写成生产承诺。

## Core output contract / 核心输出契约
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `性能风险分析.md`
- primary output object: `performance_designs[]`
- stable ID: `PERF-###`
- event: `produced.n170.performance_design.v2`
- blocker: `B04`
- stage: `technical_solution_design.advanced_design.performance_risk_analysis`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules / 设计规则
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: SLO 三态、B01-B10 瓶颈全扫、3 年容量、压测计划、降级策略和 at_risk mitigation.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R07 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B04` blocker signal.

## Execution workflow / 执行流程
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `performance_designs[]`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_N140_architecture, to_N230_performance_test, to_N260_performance_scenarios, to_N300_monitoring`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness / 动态完整度
- 单服务：覆盖全部关键路径与主要依赖
- 中型系统：覆盖 steady state + peak + batch / callback 热点
- 大型平台：聚焦高价值路径、热点表、关键依赖与容量 cliff

## Quality bar / 质量门槛
合格结果应让团队明确知道“慢在哪里、为什么慢、要准备多少资源、出问题时怎么降级、如何验证”。

## Reference files / 参考文件
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`
