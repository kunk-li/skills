---
name: performance-risk-analysis
description: analyze performance risks, slo triplets, b01-b10 bottlenecks, capacity, and test plans. triggers on 技术方案分析.md.
---
# performance-risk-analysis

## SLO triplet quick-reference
| State | Rule | Example |
|---|---|---|
| `ideal` | target × 0.5 latency; all else at ceiling | p99 = 150ms, throughput = 4000 qps |
| `target` | from NFR requirements | p99 = 300ms, throughput = 2000 qps |
| `floor` | target × 2 latency; breach triggers incident | p99 = 1000ms → alert + auto-mitigation |

## B01-B10 bottleneck quick-reference
Every bottleneck must be assessed with `at_risk: true/false`. When `at_risk: true`, mitigation is mandatory.

| ID | Bottleneck type | Primary detection signal | Capacity threshold | Common mitigation |
|---|---|---|---|---|
| B01 | CPU-bound | CPU saturation >80% sustained, slow transforms, high GC time | cores × 70% = headroom limit | async offload, batch processing, caching hot computations |
| B02 | Memory-bound | heap growth trend, GC pause >200ms, OOM kills | RSS > 75% of container limit | object pooling, stream processing, reduce in-memory aggregation |
| B03 | Disk I/O bound | iowait >20%, slow sequential reads, random IOPS at ceiling | disk IOPS at 80% of provisioned | index optimization → 047, SSD upgrade, read replica |
| B04 | Network I/O bound | inter-service latency >50ms, bandwidth saturation, TCP retransmits | sustained >70% of NIC capacity | connection pooling, compression, co-location, CDN |
| B05 | Database bottleneck | connection pool exhaustion, lock waits, slow query count rising | >80% connection pool utilization | read replica for queries, connection pool tuning, query index → 047 |
| B06 | Cache bottleneck | cache hit rate <80%, hot-key contention, cache stampede on expiry | hit rate <80% = re-evaluate strategy | local L1 cache + singleflight, cache warming, random TTL jitter |
| B07 | External dependency | p99 latency spike on third-party calls, timeout rate >1% | SLA breach on external vendor | async outbox where possible, circuit breaker, timeout + fallback |
| B08 | Concurrency contention | lock wait time >10ms, high deadlock rate, thread pool saturation | lock wait >5% of request time | lock order enforcement → 049, optimistic locking, queue serialization |
| B09 | Queue backlog | consumer lag growing, DLQ depth increasing, processing rate < arrival rate | lag >10k messages sustained 2min | consumer autoscale (HPA on lag metric), priority queue, DLQ alert |
| B10 | GC pause | stop-the-world pauses >200ms, GC overhead >10% of CPU, frequent full GC | GC pause >100ms p99 | reduce allocation rate, tune GC algorithm (G1/ZGC/Shenandoah), heap sizing |


## Trigger conditions
Analyze performance risks when any of the following are present:
- N130 technical solution analysis
- N160 schema and data-flow evidence
- N150 API surfaces with NFR targets
- 049 concurrency designs for B08 bottleneck analysis

## Standalone rule
Use `selected_mode: hotspot_scan` as default. All B01-B10 bottlenecks must be assessed even when `at_risk: false`. Without benchmark data, derive SLO targets from business requirements and mark as `assumption`.

## Role and boundary
本 skill 对齐 skills_workflow 中in the technical-solution-design -> 高级设计 -> 性能风险分析」. It is a **direct_result** skill: the goal is to produce a concrete  SLO、热点、瓶颈、资源预算、降级策略与压测计划落成可交付的 **`性能风险分析.md`**，而不是只给“可能会慢”这类定性提醒。

### Boundary
- 负责建立 SLO 论证链、热点扫描、瓶颈判断、容量预算、降级矩阵与压测计划。
- 负责把 schema、数据流、接口与依赖关系转成性能风险清单。
- 不替代并发与幂等设计，但应消费它们的约束并暴露交汇风险。
- 不替代安全威胁建模，但要识别 DoS、滥用与依赖级雪崩的性能后果。



## N170 v2 optimization contract
`references/v2-contract.md` is the authoritative contract for this skill. Apply it before producing any N170 deliverable.

Do **not** use legacy taxonomies, free-form output sections, or node-only downstream names when they conflict with the v2 contract. The canonical source of truth is:
- Input schema: `references/v2-contract.md` -> `Input schema with workflow sources`
- Output schema: `references/v2-contract.md` -> `Required output schema`
- Rules: `references/v2-contract.md` -> `Hard gate rules`
- Algorithms: `references/v2-contract.md` -> `Algorithms and decision logic`
- Handoff: `references/v2-contract.md` and `references/n170-integration-map.md`

Every deliverable must expose:
- stable ID following `PERF-###`
- `rule_results[]` with `pass | warn | reject | not_applicable`
- `contract_appendix.downstream_handoff` with field-level links

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `hotspot_scan`：快速识别热点与瓶颈；默认模式。输出 B01-B10 全扫描 + at_risk 标记 + mitigation。
- `capacity_planning`：重点输出资源预算与扩容余量。输出 unit_of_work、year_1/year_3 投影、scaling_plan。
- `perf_test_planning`：重点输出压测场景、环境与通过条件。每个 PERF-### 必须产出以下结构：

```yaml
performance_test_plan:
  target_api_or_flow: "<API-ID>"
  slo_under_test: {latency_p99: "<target>", throughput: "<target>", error_rate: "<target>"}
  test_types:
    load_test:    {enabled: true, scenario: "<target QPS> 持续 ≥30min", ramp_up: "5min", success_criteria: "p99 < <target>"}
    stress_test:  {enabled: true, scenario: "逐步加压至失败", observe: "降级行为、恢复时间"}
    spike_test:   {enabled: true, scenario: "0 → <3x QPS> 瞬间注入", success_criteria: "60s内恢复"}
    soak_test:    {enabled: true, scenario: "<50% QPS> 持续 24h", observe: "内存泄漏、GC压力"}
    breakpoint_test: {enabled: false, scenario: "加压至 error_rate > 5%，记录极限 QPS"}
  environment:  {target: "staging", data_volume: "<说明与生产比例>", dependencies: "<mock/real/replay>"}
  tools:        {recommended: "k6", rationale: "<选型理由>"}
  rollback_condition: "<何种情况中止，如 error_rate > 10% 持续 2min>"
  derived_from: {api_refs: [], flow_refs: [], concurrency_refs: [], requirement_refs: []}
```

## Primary inputs
Use the typed input schema in `references/v2-contract.md`; legacy filenames are only aliases for upstream artifacts and must not override the contract.

Canonical input summary: `api_specs(N150), data_flows(N160), tables_and_indexes(N160), concurrency_designs(049), volume_projections, existing_perf_data(optional)`.

When evidence is incomplete:
- map available files into the closest typed fields;
- mark missing typed fields in `evidence_profile.pending`;
- use `readiness: provisional` unless a reject rule makes the recommendation unsafe.

## Standalone rule
即使只有技术方案与粗略流量预期，也可以单独使用。

降级规则：
- 若没有真实 benchmark，只能给 `assumed SLO` 与容量估算。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的负载、SLO、资源与风险。
- 不得把设计推断写成生产承诺。

## Core output contract
Default output is Markdown plus a machine-readable YAML appendix. Use `references/output-template.md` for the report shape and `references/v2-contract.md` for required fields.

Canonical artifact:
- node target: `性能风险分析.md`
- primary output object: `performance_designs[]`
- stable ID: `PERF-###`
- event: `produced.n170.performance_design.v2`
- blocker: `B04`
- stage: `technical_solution_design.advanced_design.performance_risk_analysis`

The final section must be `contract_appendix` and include stable IDs, `rule_results[]`, `blocker_signals[]`, and field-level `downstream_handoff`. Do not stop at `workflow_downstream: N180/N210/N260/N390`; use the field-level handoff table.

## Design rules
Do not maintain a second design-rule taxonomy in `SKILL.md`. Load and follow the v2 rules in `references/v2-contract.md`.

This skill's hard-gate focus: SLO 三态、B01-B10 瓶颈全扫、3 年容量、压测计划、降级策略和 at_risk mitigation.

Before finalizing, run `references/checklist.md` and emit one `rule_results[]` entry per R01-R08 rule. Any `reject` must either be remediated or surfaced as `readiness: blocked` with a `B04` blocker signal.

## Execution workflow
1. Load `references/v2-contract.md` first and treat it as authoritative.
2. Normalize user-provided files into typed N170 evidence fields.
3. Select `selected_mode` and set `readiness` based on evidence sufficiency.
4. Build the required v2 output object: `performance_designs[]`.
5. Apply the decision logic and hard-gate rules from `v2-contract.md`.
6. Emit `rule_results[]`, `blocker_signals[]`, and `contract_appendix`.
7. Validate field-level handoffs using `references/n170-integration-map.md`; key links: `to_N140_architecture, to_N230_performance_test, to_N260_performance_scenarios, to_N300_monitoring`.
8. Use `references/common-failure-modes.md` and `references/scoring-rubric.md` for final review.

## Dynamic completeness
- 单服务：覆盖全部关键路径与主要依赖
- 中型系统：覆盖 steady state + peak + batch / callback 热点
- 大型平台：聚焦高价值路径、热点表、关键依赖与容量 cliff

## Quality bar
合格结果应让团队明确知道“慢在哪里、为什么慢、要准备多少资源、出问题时怎么降级、如何验证”。

## Reference files
- `references/v2-contract.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/scoring-rubric.md`
- `references/n170-integration-map.md`

## v2 additions: N005 feedback signal and N070 upstream linkage

```yaml
feedback_signal_to_n005:
  signal_type: none | performance_incident_pattern | capacity_risk_signal
  summary: ""
  target_n070_skills:
  - 017-data-object-identification
  - 014-business-rule-extraction
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
```

### Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| 数据对象目录.md (017) | constraint_tags: read_heavy, write_heavy, cache_friendly, relationships[].cardinality | hotspot scan candidates, join amplification risks |
| 业务规则清单.md (014) | rule_semantic: rate_limit, temporal rules | rate-limit SLO derivation, peak traffic windows |
| 状态转移图.md (015) | SM-* high-frequency transitions, scheduled triggers | batch job load estimation, state machine throughput |

## v2 SKILL.md contract — inline rule_results (authoritative for N380 scanning)

Full rule definitions are in `references/v2-contract.md`.
This block exposes rule IDs and severity levels so N380 can aggregate without reading the reference file.

```yaml
artifact_schema_version: n170.v2.0.0
skill_name: performance-risk-analysis
produced_event: produced.n170.performance_design.v2
blocker_mapping: B04
rule_results:
  - rule_id: R01_slo_triplet_complete
    severity: reject
    check: "ideal/target/floor 三态必须完整"
    result: pass | warn | reject | not_applicable
  - rule_id: R02_10_bottleneck_all_analyzed
    severity: reject
    check: "B01-B10 必须逐项扫描"
    result: pass | warn | reject | not_applicable
  - rule_id: R03_capacity_projected_3y
    severity: reject
    check: "容量规划至少包含 year_1 和 year_3"
    result: pass | warn | reject | not_applicable
  - rule_id: R04_test_plan_derived
    severity: reject
    check: "必须自动派生压测计划"
    result: pass | warn | reject | not_applicable
  - rule_id: R05_degradation_strategy_required
    severity: reject
    check: "每个性能设计必须有降级策略"
    result: pass | warn | reject | not_applicable
  - rule_id: R06_critical_bottleneck_has_mitigation
    severity: reject
    check: "at_risk=true 必须有 mitigation"
    result: pass | warn | reject | not_applicable
  - rule_id: R07_assumption_marking
    severity: warn
    check: "无 benchmark 的数值必须标为 assumption"
    result: pass | warn | reject | not_applicable
  - rule_id: R08_resilience_stance_on_boundary_deps
    severity: warn
    check: "跨边界依赖 at_risk=true 时,mitigation 须就超时/重试(含刻意不重试)/级联保护(或 by-design 接受)/资源隔离(或非共享)四面各表立场"
    result: pass | warn | reject | not_applicable

route_back_to: none | n160 | n130
# none   — output complete; N180/N210/N260 may proceed
# n160   — data-model assumption fundamentally wrong; revise before task planning
# n130   — architectural choice incompatible with non-functional finding; escalate

eventbus_subscribers: [N330, N340]
# N330 → 技术与运维文档自动生成
# N340 → 协作知识沉淀
```
