# Action Item Schema

Every action item should use these fields:

```yaml
action_item:
  action_id: ACTITEM-<artifact_id>-<nn>
  what: string
  who_role: string
  deadline: iso8601 | time_window | 待确认
  success_criteria: string | 待确认
  dependency: string | none | 待确认
  parent_meeting: string | null
  priority: critical | high | medium | low
  evidence_refs: [ref_id]
  risk_if_missed: string | null
  status_seed: not_started | in_progress | blocked | done | unknown
```

If `success_criteria` or `dependency` is unknown, mark it explicitly rather than omitting it.
