---
name: meeting-minutes-to-action-items
description: convert meeting notes, transcripts, chat summaries, sprint ceremonies, incident reviews, customer discussions, or workshops into structured action items for the n340 collaboration and knowledge node. use when ChatGPT must extract follow-up actions with role or team ownership, deadlines, success criteria, dependencies, evidence references, and downstream handoff fields while keeping the skill standalone and composable with weekly reports, faq, best practice, task initiation, and audit workflows.
---

# 会议纪要转行动项


## N340 v1.1.1 contract baseline
- contract_version: `n340-collaboration-v1.1.1`
- workflow node: `N340`
- packaging rule: this skill is self-contained; do not rely on node-level files, node-level tools, external matrices, or unbundled scripts.
- composition rule: exchange artifacts through `metadata`, `artifact_id`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Before producing the final artifact, consult `references/n340-shared-collaboration-contract.md` and `references/output-contract.yaml`. Use `references/blameless-collaboration-rules.md` whenever people, teams, decisions, incidents, or blockers are described.

## Role
把会议纪要、转写、聊天摘要或 workshop 材料转成可执行行动项，而不是复述会议内容。

## Selected modes
- `meeting_followup_actions`
- `incident_review_actions`
- `customer_followup_actions`
- `direct_notes_fallback`

## Primary inputs
- meeting notes, transcripts, or chat summaries
- decision lists, blocker notes, and risk lists
- incident review notes, customer discussion notes, and workshop outputs

## Standalone and composition role
```yaml
standalone_guarantee:
  minimum_viable_input: 一段会议记录、聊天摘要、转写片段或零散 bullet notes。
  partial_readiness_allowed: true
  degradation_behavior: 即使缺 owner/deadline，也产出 readiness=partial 的行动项清单，并显式列出待确认字段。
composition_role: action_commitment_extractor
function_bias: extract_followup_commitments_from_discussion
best_combines_with:
  - weekly-report-generation
  - faq-generation
  - best-practice-summary
join_keys:
  - artifact_family_id
  - artifact_id
  - cross_artifact_refs
  - topic_scope
  - source_time_window
  - evidence_refs
  - upstream_id_aliases
```

## Output contract
Follow `references/output-contract.yaml`. Every output must include:
- a `metadata` block using `n340-collaboration-v1.1.1`
- stable required sections for the selected mode
- compact `evidence_refs` rather than long pasted source material
- `downstream_handoff` with readiness, confidence, consumer, and next best checks

## Execution workflow
1. Read the shared contract and this skill's output contract.
2. Determine selected mode, audience, topic scope, and source time window.
3. Normalize source material into evidence refs with confidence and layer.
4. Produce the skill-specific artifact using the required sections.
5. Mark missing fields in `pending_clarifications` or `open_blockers` rather than inventing facts.
6. Add cross-artifact refs only when a sibling artifact is present or explicitly stubbed.
7. Complete downstream handoff for sibling skills or downstream nodes.
8. Run the quality checklist before finalizing.

## Design rules
- Keep the artifact useful when this skill is used alone.
- Make the artifact stronger when sibling artifacts exist by citing them through stable IDs.
- Use role/team owner placeholders instead of personal blame.
- Do not overstate readiness, maturity, or source certainty.
- Keep content reusable and searchable; avoid one-off local shorthand unless documented as an alias.

## Composition contract
Best combined with:
- `weekly-report-generation`
- `faq-generation`
- `best-practice-summary`

When combined, this skill must consume sibling artifacts by `artifact_id` and `evidence_refs` rather than copying their whole content.

## References
- `references/n340-shared-collaboration-contract.md`
- `references/output-contract.yaml`
- `references/blameless-collaboration-rules.md`
- `references/n340-cross-skill-handoffs.md`
- `references/meeting-minutes-to-action-items-quality-checklist.md`
- `references/action-item-schema.md`

## Example
See `examples/architecture-sync-action-items.md` for a complete v1.1.1-style artifact.
