# Action Type Classification Guide

Use this reference when assigning `action_type` to extracted action items.

## action_type values and definitions

| action_type | Definition | Examples |
|-------------|------------|---------|
| `task` | A concrete piece of work to be executed | "Implement auth module", "Write migration script", "Update config" |
| `decision` | A choice that needs to be made, with a decision owner | "Choose between Redis vs Memcached", "Decide on API versioning approach" |
| `follow_up` | A check-in or status update needed from someone | "Confirm with PM on feature scope", "Get sign-off from legal" |
| `blocker_resolution` | An action specifically aimed at removing a current blocker | "Auth team to deliver API spec", "Resolve merge conflict in shared module" |
| `external_commitment` | A promise made to someone outside the immediate team | "Deliver integration spec to Partner ABC", "Confirm SLA to customer" |

## Classification decision rules

1. If the action is promised TO an external party (partner, customer, regulator), classify as `external_commitment` regardless of what the action involves.
2. If the action is "decide X" or "choose between Y and Z", classify as `decision`.
3. If the action is "check with / confirm with / get from", classify as `follow_up`.
4. If the action is directly unblocking a stated blocker, classify as `blocker_resolution`.
5. Everything else: `task`.

## external_commitment escalation rules
When `action_type = external_commitment`:
- Priority must be `P0` — override any other priority assignment
- `commitment_to` field is required: who was the promise made to?
- `commitment_deadline` field is required: if not stated in meeting, flag as `open_blocker`
- Must appear in `downstream_handoff.external_commitments` list for tracking
- Must appear at the TOP of the action item list (before `task` items)

## decision classification rules
When `action_type = decision`:
- `decision_owner` role must be specified
- `decision_deadline` is required; default to end of current sprint if not stated
- If decision is not made by deadline, it becomes a `blocker` for downstream tasks — document this dependency
- List the options being decided between in the `what` field

## Example entries
```yaml
# external_commitment
action_id: AI-E-001
action_type: external_commitment
what: "向合作方 ABC 提供 OAuth 集成规范文档（v1 草稿）"
who_role: backend-lead
commitment_to: "ABC 集成团队"
commitment_deadline: "2025-06-30"
priority: P0

# decision
action_id: AI-D-001
action_type: decision
what: "决定购物车数量上限：无限制 vs 512 条 vs 可配置"
who_role: PM + ENG-lead
decision_deadline: "2025-06-12（联调开始前）"
priority: P1

# blocker_resolution
action_id: AI-B-001
action_type: blocker_resolution
what: "Auth 团队在 2025-06-14 前交付 OAuth callback spec v1"
who_role: auth-team
priority: P0
```
