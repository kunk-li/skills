# Meeting Minutes To Action Items Quality Checklist

Before finalizing this artifact, verify:

1. Metadata is present and uses the current contract version.
2. selected_mode matches the structure and reader/audience of the output.
3. artifact_id follows the skill-specific format or temporary fallback and aliases are recorded.
4. evidence_refs distinguish confirmed_fact, bounded_inference, and open_question.
5. cross_artifact_refs cite sibling artifacts by artifact_id, not file path.
6. open_blockers and pending_clarifications are explicit when evidence is missing.
7. owner_placeholders use role/team language rather than personal blame.
8. downstream_handoff contains handoff_id, producer, consumer, readiness, confidence, and next_best_checks.
9. freshness.as_of_date is filled or explicitly unknown.
10. The artifact remains useful standalone and improves when sibling artifacts are present.
11. Compare metadata key order, field naming, and section structure with the most relevant file under examples/. Differences are allowed but should be intentional.

Skill-specific checks:
- Only create action items for work that must happen after the meeting.
- Every action item has what, who_role, deadline, success_criteria, dependency, and evidence_refs.
- Use role/team owner placeholders rather than personal names.
- Represent vague timing as a bounded time window or pending clarification.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections are present even with placeholder content; no section is silently skipped.
- Missing evidence is recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined from available input use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- When meeting notes are fragmentary (bullet points only), still produce action items with `pending_clarifications` for missing owner/deadline.
- `action_type: external_commitment` items always appear, even if deadline is `待确认`.
- sprint_ceremony mode: carryover items are listed even if story reference is missing.

## Output structure completeness checks
- All 5 mandatory sections present.
- Every action item has `action_type` assigned (task/decision/follow_up/blocker_resolution/external_commitment).
- `external_commitment` items appear first, before other action types.
- `decision` type items have `decision_deadline` — `待确认` triggers open_blocker.
- Downstream handoff has `external_commitments` list if any external_commitment items exist.
## Mode-specific checks

### sprint_ceremony_actions mode
- Carryover items from prior sprint listed with original story_id reference
- New items listed separately from carryover
- `action_type` assigned to every item (no blanks)

### incident_review_actions mode
- All action items tied to a specific incident artifact_id
- `external_commitment` items with `commitment_to` and `commitment_deadline` appear first
