# External Commitment Protocol

Use this reference when classifying and handling `external_commitment` type action items.

## Definition

An **external commitment** is any promise made in a meeting to a party outside the immediate team:
- Commitment to a partner team, external vendor, client, or regulatory body
- Delivery of a specific artifact (spec, document, API, report) with an explicit or implied deadline
- A response or decision promised to an external stakeholder

## Required fields for external_commitment items

Every `external_commitment` item MUST include:
```yaml
action_type: external_commitment
what: "[specific deliverable or action, not vague]"
who_role: "[team or role responsible]"
commitment_to: "[party receiving the commitment]"
commitment_deadline: "[specific date or '待确认']"
evidence_ref: "[meeting:meeting-id#item:N]"
```

If `commitment_deadline` is `待确认`, it automatically becomes an `open_blocker`.

## Placement rule

External commitments MUST appear **first** in the action item list, before all other action types. This ensures they are visible to downstream consumers (#132 weekly report, N360 review).

## Downstream propagation

1. #131 → #132: `external_commitments` list in downstream_handoff
2. #132 → #139/#141: unresolved external commitments as `pending_decisions`
3. #141 → release-owner: scope impact of external commitments

## Anti-patterns

**Vague commitment**: `what: "配合 ABC 团队做接入"` — rejected. Must specify: what exactly (OAuth spec v1 document), by when (2025-06-19), in what format (PDF + Confluence page).

**Missing commitment_to**: every external commitment must name the receiving party. "Team" is not specific enough; use "ABC 集成团队的 TL".

**Unmarked external commitment**: treating a promise to an external team as a generic `task` — always classify as `external_commitment` to ensure visibility and priority.
