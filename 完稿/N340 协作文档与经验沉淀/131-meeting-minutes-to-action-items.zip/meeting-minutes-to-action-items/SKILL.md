---
name: meeting-minutes-to-action-items
description: 将会议纪要转为行动项（结构化行动清单）用于 n340 协作文档节点。triggered when the assistant must extract follow-up actions with role or team ownership, deadlines, success criteria, dependencies, and evidence references from meeting notes, transcripts, chat summaries, sprint ceremonies, incident reviews, or customer discussions. use sprint_ceremony_actions mode for retrospectives and reviews. do not use for task status tracking (→ n350 #136), risk assessment (→ n350 #138), or postmortem root-cause analysis (→ n320 #124).
---

# 会议纪要转行动项

## N340 contract baseline (n340-collaboration-v1.1.2)

- contract_version: `n340-collaboration-v1.1.2`
- workflow node: N340
- skill_id: 131
- artifact_family_id: `n340-collaboration-suite`
- primary artifact: `行动项清单.md / action-items.csv`
- downstream nodes: N340 #132 (weekly report), N350 #135 (task initiation), N350 #136 (status tracking)
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through `artifact_id`, `action_item_id`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Before producing the final artifact, consult `references/n340-shared-collaboration-contract.md` and `references/output-contract.yaml`. Use `references/blameless-collaboration-rules.md` whenever people, teams, decisions, incidents, or blockers are described.

## Role

把会议纪要、转写、聊天摘要或 workshop 材料转成**可执行行动项**，而不是复述会议内容。

具体职责：
- 识别并分类 5 种 action_type（task/decision/external_commitment/blocker_signal/risk_signal）
- 保证每条行动项满足"四元素"：what（具体行动）+ who_role（角色）+ deadline + success_criteria
- 将 external_commitment 条目置顶，确保对外承诺不被埋没
- 产出结构化 artifact 供 #132 周报和 N350 任务追踪消费
- 区分"反复出现的会议问题"（→ N340 #133 FAQ）与"单次 follow-up"（留在本 skill）

**不负责**：任务状态跟踪（→ N350 #136）、风险评估（→ N350 #138）、周报撰写（→ #132）、复述会议内容、FAQ 生成（→ #133）。

## When NOT to use this skill

- **Not a weekly report**: action items extracted here feed into #132; do not duplicate weekly summaries in the action item artifact.
- **Not a risk register**: risk signals mentioned in meetings become inputs to N350 #138; only concrete decisions and actions go into #131 output.
- **Not a postmortem**: incident review action items are extracted here but root cause analysis belongs in N320 #124.
- **Not a project plan**: #131 extracts commitments from discussions; it does not create new tasks without source discussion evidence.
- **Not an FAQ tool**: when a question recurs across multiple meetings, route it to #133; #131 handles single-meeting follow-ups only.

## Standalone and composition role

```yaml
standalone_goal: extract structured, executable action items from any discussion material
minimum_viable_input:
  any_of:
    - 会议纪要或转写文本
    - 聊天摘要或讨论 thread
    - 决策清单或阻塞笔记
    - 故障复盘会议记录
    - 客户讨论记录或 workshop 产出
    - 零散 bullet notes（direct_notes_fallback 模式）
partial_readiness_allowed: true
degradation_behavior: >
  Even if owner or deadline is missing, produce readiness=partial action item list
  and explicitly list unconfirmed fields (who_role/deadline/success_criteria) as
  open_blockers. Do not block on completeness. external_commitment items must always
  be surfaced even when incomplete.
composition_role: action_commitment_extractor
function_bias: extract_followup_commitments_from_discussion
best_combines_with:
  - weekly-report-generation
  - faq-generation
  - best-practice-summary
join_keys:
  - artifact_family_id
  - artifact_id
  - cross_artifact_refs
  - topic_scope
  - source_time_window
  - evidence_refs
  - upstream_id_aliases
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `meeting_followup_actions`: 通用会议行动项提取。
- `incident_review_actions`: 故障复盘后的行动项，要求标注预防类型（detection/prevention/recovery）。
- `customer_followup_actions`: 客户讨论后的行动项，要求标注对外承诺与内部任务的区别。
- `direct_notes_fallback`: 输入为零散 bullet notes，先做结构化再提取行动项。
- **`sprint_ceremony_actions`**: 专用于 Sprint Review / Retrospective，区分"本 Sprint 遗留项"与"下 Sprint 新增项"，保留 story 引用。Sprint Review 重点：已完成 vs 未完成 story；Sprint Retro 重点：process improvement actions（标注 retro_category: start/stop/continue）。

**Default routing**: sprint ceremony → `sprint_ceremony_actions`. Customer meeting → `customer_followup_actions`. Raw notes → `direct_notes_fallback`. Post-incident review → `incident_review_actions`.

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | Metadata | Always | artifact_id, selected_mode, source_time_window, readiness |
| 2 | External commitments (置顶) | Always | Even if none: "本次会议无对外承诺" |
| 3 | Action items by type | Always | task / decision / blocker_signal / risk_signal |
| 4 | Unconfirmed fields | Always | List every missing who_role / deadline / success_criteria |
| 5 | Downstream handoff | Always | Pass to #132 and N350 #135; include action_item_ids |

> Legend: Always = required in every mode.

**Action item four-element test** (every item must pass):

| Element | Requirement | Anti-pattern |
|---------|-------------|--------------|
| `what` | Specific, verifiable deliverable | "推进讨论" |
| `who_role` | Role or team, not individual name | "张三" |
| `deadline` | Absolute date or sprint reference | "尽快" |
| `success_criteria` | Measurable confirmation | "完成后通知" |

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: weekly-report-generation / N350/task-initiation
  action_item_ids: [AI-001, AI-002, AI-003]
  external_commitment_ids: [EC-001]
  open_blockers: ["who_role missing on AI-003", "deadline unconfirmed on AI-002"]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all items have four-element data) / `partial` (some fields unconfirmed — listed in open_blockers) / `degraded` (extreme input sparsity; output is structural skeleton only — downstream consumers must treat all fields as provisional).

## Input conflict resolution

When the same action item appears across multiple sources (e.g., a follow-up task mentioned in both meeting notes and a chat summary) with different owner or deadline values:
- Prefer the source with the **later timestamp** (more recent assignment takes precedence).
- Flag the discrepancy in `open_blockers`: `"AI-00x owner conflict: [source A] vs [source B] — confirm with stakeholders"`.
- Never silently pick one version; always surface the conflict.

## Workflow position

```
Meeting notes / chat / sprint ceremony / incident review
  ↓ #131 (action item extraction → 行动项清单.md / action-items.csv)
  ↓ #132 (weekly report synthesis → 周报.md)
  ↓ N350 #135 (task register creation → 任务清单.csv)
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** 复述会议内容而非提取行动项 → 每条输出必须是可执行 action，不是摘要段落。量化检验：action items 节中，没有明确 who_role/deadline/what 三要素、仅为叙述性总结段落的条目数 = FAIL 数（行动项必须有具体执行主体和截止）。
- **AP-2** external_commitment 没有置顶 → 对外承诺条目必须在 Section 2 单独列出，不能埋在其他 action items 中。量化检验：external_commitment 类型条目若未出现在 Section 2（置顶节），而仅出现在 Section 3，则计入违例；Section 2 字符数 < 20 且有对外承诺时视为违例。
- **AP-3** 行动项使用个人名字（归责到人）→ 必须改为角色或团队；参考 `references/blameless-collaboration-rules.md`。量化检验：action item 的 who_role 字段中出现个人姓名（正则检测）的条目数 = open_blocker 数。
- **AP-4** `sprint_ceremony_actions` 模式下混淆"本 Sprint 遗留项"与"下 Sprint 新增项" → 必须显式分组，并保留 story 引用（story_id）。量化检验：sprint_ceremony_actions 模式下，「本 Sprint 遗留项」分组和「下 Sprint 新增项」分组必须同时出现；任一分组缺失则 FAIL。

## References

Read only when relevant to the request:
- `../../../_fixtures/n320-n360-end-to-end/README.md` — cross-skill end-to-end test fixture; read when verifying cross-node artifact handoffs
- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming IDs across skills
- `references/n340-shared-collaboration-contract.md` — shared metadata, handoff schema, composition rules
- `references/n340-composition-guide.md` — how #131–#134 compose and when to combine
- `references/n340-cross-skill-handoffs.md` — cross-skill handoff field mapping
- `references/n340-input-validation-rules.md` — when input quality is uncertain
- `references/action-type-classification.md` — when classifying action_type
- `references/action-item-schema.md` — action item field schema
- `references/external-commitment-protocol.md` — when handling external commitments
- `references/blameless-collaboration-rules.md` — when drafting or checking tone
- `references/meeting-minutes-to-action-items-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/architecture-sync-action-items.md` — meeting_followup_actions with technical decisions
- `examples/customer-followup-actions.md` — customer_followup_actions with external commitment surfaced
- `examples/sprint-ceremony-action-items.md` — sprint_ceremony_actions with Sprint Review + Retro split
