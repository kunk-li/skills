# Example: Meeting Minutes → Action Items — Sprint Ceremony Mode

Demonstrates `sprint_ceremony_actions` mode: separating carryover items (with story reference) from new items.

```yaml
metadata:
  contract_version: n340-collaboration-v1.1.2
  skill_id: "131"
  selected_mode: sprint_ceremony_actions
  artifact_id: ACTION-N340-S24-PLANNING
  source_meeting: sprint-planning-2025-06-16
  readiness: complete
```

## Action Items

### 🔴 External Commitments (P0)
| action_id | what | who_role | commitment_to | deadline | evidence_ref |
|-----------|------|----------|--------------|---------|-------------|
| AI-S24-001 | 提供 OAuth callback spec v1 草稿（书面确认格式） | backend-lead | ABC 集成团队 | 2025-06-30 | meeting:sprint-planning-2025-06-16#item:2 |

### 🟡 Carryover Items (来自上一 Sprint，含原 story 引用)

| action_id | what | who_role | deadline | status | original_story | evidence_ref |
|-----------|------|----------|---------|--------|---------------|-------------|
| AI-S23-009 | 完成 Redis warm-up 集成到 CD pipeline | platform-team | 2025-07-01 | IN_PROGRESS(stale) | STORY-S23-015 (warmup-gate) | artifact:TASK-REG-S23#T-033 |
| AI-S23-012 | 更新购物车 API 文档，补充 512 上限说明 | backend-team | 2025-06-20 | TODO | STORY-S23-021 (cart-limit-docs) | artifact:TASK-REG-S23#T-028 |

> `AI-S23-009` 状态为 stale（见 STATUS-S23-W25）——本 sprint 需在第一周确认是否继续推进或转为 blocked。

### 🟢 New Items (本 Sprint 新增)

| action_id | action_type | what | who_role | deadline | success_criteria | evidence_ref |
|-----------|-------------|------|----------|---------|-----------------|-------------|
| AI-S24-002 | decision | 决定购物车数量上限策略（无限制 vs 512 vs 可配置）| PM + ENG-lead | 2025-06-20 | 书面决策记录发布至 Confluence，并同步 backend-team 实施计划 | meeting:sprint-planning-2025-06-16#item:5 |
| AI-S24-003 | task | 实现 POST /cart/add 513+ 条时的友好错误提示（返回 200+限制提示而非 500）| backend-team | 2025-06-25 | Staging 环境 QA 验证通过，POST /cart/add 第513条返回 {limited:true, current_count:512} | meeting:sprint-planning-2025-06-16#item:6 |
| AI-S24-004 | follow_up | 向 auth-team 确认 OAuth spec 延期影响范围 | PM | 2025-06-17 | 收到 auth-team 书面回复，明确延期天数 | meeting:sprint-planning-2025-06-16#item:8 |

## Pending Clarifications

- AI-S24-002 的"可配置"方案：需 ENG-lead 在 2025-06-18 前提供技术可行性评估，方可进入实施
- AI-S23-009 stale 状态：platform-team TL 需在 2025-06-17 standup 前确认阻塞原因

## Downstream Handoff

```yaml
handoff_id: ACTION-HANDOFF-S24-PLANNING
producer_skill: meeting-minutes-to-action-items
consumer_skill_or_node: task-initiation|weekly-report-generation
cross_artifact_refs:
  - artifact_id: TASK-REG-S23
    relationship: carryover_source
    producer_skill: task-initiation
external_commitments: [AI-S24-001]
pending_decisions: [AI-S24-002]
carryover_items: [AI-S23-009, AI-S23-012]
new_items: [AI-S24-003, AI-S24-004]
readiness: complete
confidence: high
next_best_checks:
  - "task-initiation: create T-xxx entries for AI-S24-003 (new task)"
  - "weekly-report: reference AI-S24-001 in external commitments section"
  - "Confirm AI-S23-009 stale status by 2025-06-17 standup"
```
