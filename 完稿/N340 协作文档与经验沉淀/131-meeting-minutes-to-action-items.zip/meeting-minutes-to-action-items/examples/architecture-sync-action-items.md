# 会议行动项清单示例

```yaml
metadata:
  contract_version: n340-collaboration-v1.1.2
  workflow_node: N340
  skill_id: 131
  skill_name: meeting-minutes-to-action-items
  artifact_family_id: n340-collaboration-suite
  artifact_id: ACT-platform-202619-01
  selected_mode: meeting_followup_actions
  readiness: ready
  source_time_window:
    start: 2026-05-01T00:00:00+09:00
    end: 2026-05-07T23:59:59+09:00
    timezone: Asia/Tokyo
  audience_scope: [engineering, product, operations]
  topic_scope: [platform-doc-family]
  source_artifacts: [sample-input]
  upstream_id_aliases: []
  evidence_refs: [EV-N340-SAMPLE-01]
  cross_artifact_refs: []
  pending_clarifications: []
  open_blockers: []
  owner_placeholders: [platform-team, product-team]
  confidentiality_level: public_internal
  confidence: high
  composition_role: action_commitment_extractor
  function_bias: extract_followup_commitments_from_discussion
  stage_position: collaboration_knowledge.action_extraction
  node_artifact_target: 会议行动项清单.md | action_items.csv
  freshness:
    as_of_date: 2026-05-07
    source_commit: null
    expected_review_window: weekly
```

## source_summary
平台文档族对齐会议确认需要先补模块边界、再补 API 与数据字典，最后完成开发文档、部署文档和维护手册。

## decision_context
- confirmed_fact: 模块设计文档作为服务卡片 source of truth。
- confirmed_fact: API 与数据字典必须引用同一组 `API-*` 与 `FLD-*` aliases。

## action_items
| action_id | what | who_role | deadline | success_criteria | dependency | evidence_refs | status_seed |
|---|---|---|---|---|---|---|---|
| ACTITEM-ACT-platform-202619-01-01 | 补齐服务卡片并生成 127 模块设计草稿 | architecture-team | 2026-05-10 | 6 字段服务卡片完整并可被 126/128 引用 | none | EV-N340-SAMPLE-01 | not_started |
| ACTITEM-ACT-platform-202619-01-02 | 基于服务卡生成 API 文档和数据字典草稿 | api-team | 2026-05-12 | `API-*` 与 `FLD-*` 均进入 upstream_id_aliases | ACTITEM-ACT-platform-202619-01-01 | EV-N340-SAMPLE-01 | not_started |

## dependency_and_risk_notes
- bounded_inference: 如果服务卡片延期，后续 126/128/125 会出现 cross_doc_refs stub。

```yaml
downstream_handoff:
  contract_version: n340-collaboration-v1.1.2
  handoff_id: HO-N340-ACT-platform-202619-01-001
  producer_skill: meeting-minutes-to-action-items
  consumer_skill_or_node: weekly-report-generation
  artifact_family_id: n340-collaboration-suite
  artifact_id: ACT-platform-202619-01
  required_fields: [artifact_id, topic_scope, evidence_refs]
  cross_artifact_refs: []
  pending_clarifications: []
  readiness: ready
  confidence: high
  next_best_checks: [review with owning team before publishing]
```
