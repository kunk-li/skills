# Example: Meeting Minutes → Action Items — Customer Followup Mode

Demonstrates `customer_followup_actions` mode: extracting action items from a customer-facing meeting with explicit external commitment tracking.

```yaml
metadata:
  skill_id: "131"
  selected_mode: customer_followup_actions
  artifact_id: ACTION-N340-CUST-ABC-2025-W24
  contract_version: n340-collaboration-v1.1.2
  readiness: complete
```

## External Commitments (置顶)

| action_id | action_type | what | who_role | commitment_to | commitment_deadline | evidence_ref |
|-----------|------------|------|----------|--------------|-------------------|-------------|
| AI-CUST-001 | external_commitment | Send revised SLA proposal (uptime 99.95% + P1 response ≤15min) | PM-role | ABC Corp — procurement lead | 2025-06-20 | meeting:cust-abc-20250618#item:3 |
| AI-CUST-002 | external_commitment | Provide API sandbox credentials for ABC integration team | ENG-lead | ABC Corp — integration team | 2025-06-18 | meeting:cust-abc-20250618#item:5 |

## Internal Action Items

| action_id | action_type | what | who_role | deadline | success_criteria | evidence_ref |
|-----------|------------|------|----------|----------|-----------------|-------------|
| AI-CUST-003 | task | Draft SLA proposal with legal review | PM-role + Legal | 2025-06-19 | Legal-approved draft shared with PM before EOD | meeting:cust-abc-20250618#item:3 |
| AI-CUST-004 | task | Provision sandbox environment with test data | ENG-lead | 2025-06-17 | Sandbox URL + credentials sent to ABC integration team | meeting:cust-abc-20250618#item:5 |
| AI-CUST-005 | decision | ABC integration timeline: 3-week vs 6-week options presented | PM-role | 待确认 (next meeting 2025-06-25) | Decision recorded in meeting notes | meeting:cust-abc-20250618#item:7 |

## Downstream Handoff

```yaml
handoff_id: ACTION-N340-CUST-ABC-2025-W24-HANDOFF
producer_skill: meeting-minutes-to-action-items
consumer_skill_or_node: weekly-report-generation
external_commitments:
  - AI-CUST-001: SLA proposal to ABC Corp (deadline 2025-06-20)
  - AI-CUST-002: API sandbox credentials to ABC Corp (deadline 2025-06-18)
pending_decisions:
  - AI-CUST-005: integration timeline 3-week vs 6-week (decision by 2025-06-25)
new_items: [AI-CUST-001, AI-CUST-002, AI-CUST-003, AI-CUST-004, AI-CUST-005]
readiness: complete
```
