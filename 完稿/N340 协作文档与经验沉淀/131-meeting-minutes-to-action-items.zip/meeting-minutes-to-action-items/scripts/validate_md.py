#!/usr/bin/env python3
"""validate_md.py for skill #131 meeting-minutes-to-action-items (n340-collaboration-v1.1.2)

Validates mandatory sections, never-empty constraints, and business rules.

Usage:
    python scripts/validate_md.py <output.md> [--strict]
"""
import re, sys
from pathlib import Path

SCHEMA = "n340-collaboration-v1.1.2 / #131 meeting-minutes-to-action-items"
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}
FOUR_ELEMENTS = ["what", "who_role", "deadline", "success_criteria"]

REQUIRED_HEADINGS = [
    ("metadata",            re.compile(r"##\s*\d*\.?\s*Metadata|^```yaml[\s\S]*?\bmetadata:\b", re.I | re.MULTILINE)),
    ("external_commitments",re.compile(r"##\s*\d*\.?\s*[^\n]*?(External [Cc]ommitments?|对外承诺)", re.I)),
    ("action_items",        re.compile(r"##\s*\d*\.?\s*[^\n]*?(Action [Ii]tems?|行动项)", re.I)),
    ("unconfirmed",         re.compile(r"##\s*\d*\.?\s*[^\n]*?(Unconfirmed|Pending [Cc]larification|待确认)", re.I)),
    ("downstream_handoff",  re.compile(r"##\s*\d*\.?\s*[^\n]*?(Downstream [Hh]andoff|下游交接)", re.I)),
]

NEVER_EMPTY_SECTIONS = [
    ("external_commitments", re.compile(r"##\s*\d*\.?\s*[^\n]*?(External [Cc]ommitments?|对外承诺)", re.I)),
    ("action_items",         re.compile(r"##\s*\d*\.?\s*[^\n]*?(Action [Ii]tems?|行动项)", re.I)),
]


def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0


def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_md.py <output.md> [--strict]")
        return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists():
        return fail(f"file not found: {path}")
    text = path.read_text(encoding="utf-8")
    errors = 0; warnings = 0

    # Light check for example/flow files
    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    if _is_example and _has_any_heading:
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness value '{_rm.group(1)}' not in {VALID_READINESS}")
            return 1
        if "downstream_handoff" not in text.lower() and "downstream" not in text.lower():
            warn("example may be missing downstream_handoff section")
        return ok(f"{SCHEMA} example validation passed (light-check mode)")

    # Required headings
    found = {}
    for key, pat in REQUIRED_HEADINGS:
        m = pat.search(text)
        if m:
            found[key] = m.start()
        else:
            print(f"[FAIL] missing required section: {key}")
            errors += 1

    # NEVER_EMPTY checks (≥ 20 chars of content)
    for key, pat in NEVER_EMPTY_SECTIONS:
        m = pat.search(text)
        if m:
            rest = text[m.end():]
            next_h = re.search(r'\n## ', rest)
            section_body = rest[:next_h.start()].strip() if next_h else rest.strip()
            lines = [l for l in section_body.split('\n') if l.strip() and not l.startswith('##')]
            content = '\n'.join(lines).strip()
            if len(content) < 20:
                print(f"[FAIL] section '{key}' is never-empty but appears empty (< 20 chars) — write '本次会议无对外承诺' if none")
                errors += 1

    # Four-element check in action items
    if "action_items" in found:
        ai_pos = found["action_items"]
        next_pos = min((v for k, v in found.items() if v > ai_pos), default=len(text))
        snippet = text[ai_pos:next_pos]
        missing = [e for e in FOUR_ELEMENTS if e not in snippet]
        if missing:
            msg = f"action_items section missing four-element fields: {missing}"
            if strict:
                print(f"[FAIL] {msg}"); errors += 1
            else:
                warn(msg); warnings += 1

    # Readiness check
    rm = re.search(r"readiness:\s*([\w]+)", text)
    if rm and rm.group(1) not in VALID_READINESS:
        print(f"[FAIL] readiness '{rm.group(1)}' not in {VALID_READINESS}"); errors += 1

    # downstream_handoff action_item_ids
    if "downstream_handoff" in found:
        snippet = text[found["downstream_handoff"]:found["downstream_handoff"]+500]
        if "action_item_ids" not in snippet:
            warn("downstream_handoff missing action_item_ids"); warnings += 1

    if errors > 0:
        return fail(f"{SCHEMA} FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} passed — {warnings} warning(s)")


if __name__ == "__main__":
    raise SystemExit(main())
