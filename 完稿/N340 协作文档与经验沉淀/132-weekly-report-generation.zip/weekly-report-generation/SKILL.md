---
name: weekly-report-generation
description: 生成周报（周进展汇报）用于 n340 协作文档节点。triggered when the assistant should consolidate task status, meeting action items, risks, blockers, and milestone outcomes into a stakeholder-ready weekly report. select reader mode (tl_weekly/pm_weekly/l6_weekly/crisis_weekly) based on the intended audience. do not use as a task tracker (→ n350 #136), meeting minutes extractor (→ #131), postmortem (→ n320 #124), or decision log.
---

# 周报生成

## N340 contract baseline (n340-collaboration-v1.1.2)

- contract_version: `n340-collaboration-v1.1.2`
- workflow node: N340
- skill_id: 132
- artifact_family_id: `n340-collaboration-suite`
- primary artifact: `周报.md`
- downstream nodes: N340 #133 (FAQ via repeated_questions_observed), N360 #142 (milestone tracking upstream)
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through `artifact_id`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Before producing the final artifact, consult `references/n340-shared-collaboration-contract.md` and `references/output-contract.yaml`. Use `references/blameless-collaboration-rules.md` whenever people, teams, decisions, incidents, or blockers are described.

## Role

把任务状态、会议行动项、风险、阻塞和阶段结果收敛成**可直接汇报的周报**。

具体职责：
- 按 reader mode（tl_weekly/pm_weekly/l6_weekly/crisis_weekly）调整侧重点和详细程度（见差异矩阵）
- 外部承诺跟踪节永不省略，即使本周无对外承诺
- 通过 `repeated_questions_observed` 字段将高频问题传递给 #133
- 供管理层、项目干系人直接阅读；不面向技术执行层

**不负责**：行动项提取（→ #131）、FAQ 积累（→ #133）、任务状态跟踪（→ N350 #136）、事故分析（→ N320）、项目里程碑预测（→ N360 #142）。

## When NOT to use this skill

- **Not a task tracker**: do not use #132 to create or update task registers — use N350 #135/#136 instead.
- **Not a meeting minutes tool**: use #131 first to extract action items, then feed into #132.
- **Not a postmortem**: incident root cause analysis belongs in N320 #124; reference the postmortem artifact_id in the weekly risk section.
- **Not a decision log**: decisions are referenced by action_id from #131, not re-documented from scratch in #132.
- **Not a project plan**: do not forecast future milestones beyond current sprint scope — that belongs to N360 #142.

## Standalone and composition role

```yaml
standalone_goal: consolidate weekly status into a stakeholder-ready report for the specified reader mode
minimum_viable_input:
  any_of:
    - 状态更新或任务列表
    - 本周行动项或会议决策（来自 #131）
    - 发版、验证、事故或项目进展笔记
    - 阻塞项或风险条目（来自 N350 #137/#138）
partial_readiness_allowed: true
degradation_behavior: >
  If data is incomplete, output readiness=partial report.
  Clearly separate "confirmed facts" from "open gaps" in each section.
  External commitment section must still appear — write "本周无对外承诺" if none.
  repeated_questions_observed can be empty but must be present for #133 handoff.
composition_role: weekly_status_synthesizer
function_bias: aggregate_weekly_status_for_reader_context
best_combines_with:
  - meeting-minutes-to-action-items
  - faq-generation
  - best-practice-summary
join_keys:
  - artifact_family_id
  - artifact_id
  - cross_artifact_refs
  - topic_scope
  - source_time_window
  - evidence_refs
  - upstream_id_aliases
```


## Mandatory output sections

| # | Section | Required | Placeholder when missing |
|---|---------|----------|--------------------------|
| 1 | Metadata (artifact_id, selected_mode, readiness) | Always | — |
| 2 | 外部承诺跟踪 | **Always — never omit** | "本周无对外承诺" if none |
| 3 | 核心进展摘要 | Always | Per reader mode (tl_weekly/pm_weekly/l6_weekly/crisis_weekly) |
| 4 | incident_id + escalation_path | Always in crisis_weekly | — |
| 5 | Downstream handoff (repeated_questions_observed → #133) | Always | — |

> Legend: Always = required in every mode; crisis_weekly adds incident_id and escalation_path as mandatory fields.

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `tl_weekly`: 技术负责人视角，侧重技术决策、架构进展、团队间依赖。
- `pm_weekly`: 项目经理视角，侧重里程碑、交付风险、客户/外部承诺。
- `l6_weekly`: 高层管理视角，侧重业务影响、关键决策请示、资源需求。
- `crisis_weekly`: 危机周期专用，必须包含 `incident_id` 引用、`escalation_path` 字段、当前状态（containment/recovery/post-incident）、以及与常规章节的差异标注。
- `neutral_summary_fallback`: 不指定读者时使用，输出中立摘要，分层标注"决策者需关注"与"执行层细节"。

**Default routing**: TL audience → `tl_weekly`. PM/delivery → `pm_weekly`. Executive → `l6_weekly`. Active incident → `crisis_weekly`. Audience unknown → `neutral_summary_fallback`.

**各模式内容差异矩阵**:

| 章节 | tl_weekly | pm_weekly | l6_weekly | crisis_weekly |
|------|-----------|-----------|-----------|---------------|
| 技术债与架构决策 | 必填 | 可选 | 摘要 | 暂停（危机期间） |
| 里程碑与交付进度 | 摘要 | 必填 | 必填 | 受影响里程碑 |
| 资源/预算风险 | 可选 | 必填 | 必填 | 可选 |
| 外部承诺状态 | 可选 | 必填 | 必填 | 必填 |
| 团队间依赖阻塞 | 必填 | 必填 | 摘要 | 必填 |
| incident_id 引用 | 可选 | 可选 | 可选 | **必填** |
| escalation_path | 不需要 | 不需要 | 不需要 | **必填** |

## References
- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

使用方式：`see references/tl-weekly-template.md` (tl_weekly 模式) · `pm-weekly-template.md` (pm_weekly) · `l6-weekly-template.md` (l6_weekly) · `crisis-weekly-guide.md` (crisis_weekly)，根据 selected_mode 选择对应文件，不要同时加载所有模板。

Read only when relevant to the request:
- `references/n340-shared-collaboration-contract.md` — shared contract and handoff schema
- `references/n340-composition-guide.md` — composition guide
- `references/n340-cross-skill-handoffs.md` — cross-skill handoff mapping
- `references/n340-input-validation-rules.md` — when input quality is uncertain
- `references/tl-weekly-template.md` — when selected_mode is tl_weekly
- `references/pm-weekly-template.md` — when selected_mode is pm_weekly
- `references/l6-weekly-template.md` — when selected_mode is l6_weekly
- `references/crisis-weekly-guide.md` — when selected_mode is crisis_weekly
- `references/weekly-template-per-role.md` — mode selection decision guide
- `references/blameless-collaboration-rules.md` — when describing people, teams, incidents
- `references/weekly-report-generation-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: faq-generation / N360/project-rhythm-tracking
  repeated_questions_observed: ["Q: 为什么 CI 总是在周五失败？", "Q: hotfix 流程是什么？"]
  milestone_signals: [MILESTONE-001]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all sections confirmed) / `partial` (some data gaps noted) / `degraded` (minimal data only — output is structural skeleton; downstream consumers should validate all figures).

## Input conflict resolution

When status data conflicts across sources (e.g., task appears DONE in one report but IN_PROGRESS in standup notes):
- Prefer the **most recent source** (later timestamp).
- Note the discrepancy inline: `"Status conflict on TASK-001: done per weekly report vs in_progress per standup — validate with owner"`.
- Never silently resolve by picking one version.

## Workflow position

```
Task status / action items / blockers / risks / milestone data
  ↓ #132 (weekly report synthesis → 周报.md)
  ↓ #133 (repeated questions → FAQ.md)
  ↓ N360 #142 (milestone signals → project-rhythm-tracking)
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** 外部承诺跟踪节省略 → 永远必填；无承诺时写"本周无对外承诺"。量化检验：外部承诺跟踪节字符数 < 10 时视为违例；整节缺失则 FAIL。
- **AP-2** 把 #131 的行动项重新列一遍（未引用 action_id）→ 应通过 action_id 引用，不重复抄写。量化检验：周报正文中 action item 文本（what/who/deadline）逐字重复出现（而非通过 action_id 引用）的段落数视为违例数。
- **AP-3** `crisis_weekly` 模式缺少 `incident_id` 或 `escalation_path` → 两字段在危机模式下为必填。量化检验：crisis_weekly 模式下，`incident_id` 和 `escalation_path` 字段各自缺失时计 1 个 FAIL。
- **AP-4** 在周报中做根因分析 → 根因属于 N320 #124；周报只引用 postmortem artifact_id 和 action_item 状态。量化检验：周报中出现「L3」/「L4」/「Five Whys」/「根因」等根因分析专用词时，需确认其在引用上下文（postmortem artifact_id 引用）中，否则计入违例。

## Examples

- `examples/team-weekly-report.md` — tl_weekly with architecture decisions and dependency blockers
- `examples/crisis-weekly-report.md` — crisis_weekly with incident_id, escalation_path, and status
- `examples/n340-composition-flow.md` — how #131 → #132 → #133 → #134 compose across a sprint
