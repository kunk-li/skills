# Crisis Weekly Report Guide

Use this reference when producing a `crisis_weekly` mode artifact during or immediately after an incident.

## When to use crisis_weekly mode

Trigger criteria (any one):
- Active P0/P1 incident in progress
- Incident resolved within the past 24 hours and stakeholders need immediate status
- Release blocked by critical issue requiring executive visibility

## crisis_weekly structure (extreme-minimal)

```markdown
# [INCIDENT STATUS] [Service] Crisis Update — [Date HH:MM TZ]

## 事故状态
OPEN | MITIGATED | RESOLVED

## 关键时间线（最近3个节点）
- T+0: [触发信号]
- T+N: [关键操作]
- T+M: [当前状态]

## 正在进行的行动
- [ ] [负责人]: [具体行动] → 预计完成: [时间]

## 下一个决策点
[时间]: [需要谁决策什么]
```

## Anti-patterns for crisis_weekly

**Do NOT** include: background context, history, metrics dashboards (link instead), team morale updates
**DO** include: only actionable facts, owners, and deadlines

## Staleness rule

crisis_weekly reports are typically valid for 1-4 hours only. Always include `as_of: [timestamp]` in metadata.

## Transition to normal weekly

Once incident is RESOLVED and post-incident review is scheduled, switch back to tl_weekly/pm_weekly mode for the next regular weekly report. The postmortem (N320 #124) owns the detailed analysis.

## Downstream handoff in crisis

```yaml
downstream_handoff:
  consumer_skill_or_node: production-incident-postmortem|N320
  incident_status: OPEN | MITIGATED | RESOLVED
  next_update_by: "[timestamp]"
  readiness: partial  # crisis reports are always partial
```
