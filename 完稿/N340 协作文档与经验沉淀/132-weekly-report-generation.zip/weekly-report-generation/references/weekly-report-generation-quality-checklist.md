# Weekly Report Generation Quality Checklist

Before finalizing this artifact, verify:

1. Metadata is present and uses the current contract version.
2. selected_mode matches the structure and reader/audience of the output.
3. artifact_id follows the skill-specific format or temporary fallback and aliases are recorded.
4. evidence_refs distinguish confirmed_fact, bounded_inference, and open_question.
5. cross_artifact_refs cite sibling artifacts by artifact_id, not file path.
6. open_blockers and pending_clarifications are explicit when evidence is missing.
7. owner_placeholders use role/team language rather than personal blame.
8. downstream_handoff contains handoff_id, producer, consumer, readiness, confidence, and next_best_checks.
9. freshness.as_of_date is filled or explicitly unknown.
10. The artifact remains useful standalone and improves when sibling artifacts are present.
11. Compare metadata key order, field naming, and section structure with the most relevant file under examples/. Differences are allowed but should be intentional.

Skill-specific checks:
- Separate progress, blockers, risks, and decisions; do not merge them into vague updates.
- Match the selected reader mode: TL, PM, L6, or neutral fallback.
- Report facts and confidence labels rather than blame or subjective evaluation.
- Include data_basis_and_gaps so readers know what was included or missing.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections are present even with placeholder content; no section is silently skipped.
- Missing evidence is recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined from available input use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- When only partial task status is available, output uses `readiness: partial` and explicitly separates confirmed_facts from open_gaps in each section.
- `外部承诺跟踪` section is always present, even if content is "本周无对外承诺".
- Mode-specific sections marked as "必填" in the content matrix are never omitted; they contain "待补充" if data is missing.

## Output structure completeness checks
- All sections from the mode-specific mandatory section table are present.
- Section 5 (外部承诺跟踪) present even if "本周无对外承诺".
- Section 4 (关键决策) shows both decided AND pending decisions with deadlines.
- `selected_mode` explicitly stated; mode-specific sections match the matrix table.
- Role-specific template (`references/{role}-weekly-template.md`) used when applicable.
