# Example: Weekly Report — Crisis Mode

Demonstrates `crisis_weekly` mode: minimal stakeholder update during an active P1 incident.

```yaml
metadata:
  skill_id: "132"
  selected_mode: crisis_weekly
  artifact_id: WEEKLY-N340-CRISIS-2025-W24
  contract_version: n340-collaboration-v1.1.2
  as_of: "2025-06-18T14:35 UTC"
  readiness: partial
```

# [INCIDENT STATUS: MITIGATED] Payments Service — Crisis Update 2025-06-18 14:35 UTC

## 事故状态
**MITIGATED** — error rate降至 0.08%（SLA 阈值以下）；完全恢复预计 15:00 UTC

## 关键时间线（最近3个节点）
- **T+0 (13:41 UTC)**: 告警触发，payments-service P99 latency > 5s，error rate 3.2%
- **T+22m (14:03 UTC)**: 根因定位 — Redis 分片迁移脚本未完成，热点 key 集中在单节点
- **T+54m (14:35 UTC)**: 特性开关切换至降级模式（同步 → 异步队列），error rate 降至 0.08%

## 正在进行的行动
- [ ] **ENG-lead**: 完成 Redis 分片重新平衡 → 预计完成 15:00 UTC
- [ ] **SRE on-call**: 监控 error rate 15 分钟稳定后关闭降级模式

## 下一个决策点
**15:00 UTC**: 若 error rate 维持 < 0.1%，关闭降级模式并恢复正常流量

## Downstream Handoff

```yaml
handoff_id: WEEKLY-CRISIS-2025-W24-HANDOFF
producer_skill: weekly-report-generation
consumer_skill_or_node: production-incident-postmortem|N320
incident_status: MITIGATED
next_update_by: "2025-06-18T15:00 UTC"
repeated_questions_observed: []
readiness: partial
note: crisis reports are always partial — postmortem (N320 #124) owns full analysis
```
