# 周报示例

```yaml
metadata:
  contract_version: n340-collaboration-v1.1.2
  workflow_node: N340
  skill_id: 132
  skill_name: weekly-report-generation
  artifact_family_id: n340-collaboration-suite
  artifact_id: WR-platform-202619
  selected_mode: tl_weekly
  readiness: ready
  source_time_window:
    start: 2026-05-01T00:00:00+09:00
    end: 2026-05-07T23:59:59+09:00
    timezone: Asia/Tokyo
  audience_scope: [engineering, product, operations]
  topic_scope: [platform-doc-family]
  source_artifacts: [sample-input]
  upstream_id_aliases: []
  evidence_refs: [EV-N340-SAMPLE-01]
  cross_artifact_refs: [ACT-platform-202619-01]
  pending_clarifications: []
  open_blockers: []
  owner_placeholders: [platform-team, product-team]
  confidentiality_level: public_internal
  confidence: high
  composition_role: weekly_status_synthesizer
  function_bias: aggregate_weekly_status_for_reader_context
  stage_position: collaboration_knowledge.status_synthesis
  node_artifact_target: 周报.md
  freshness:
    as_of_date: 2026-05-07
    source_commit: null
    expected_review_window: weekly
```

## weekly_overview
本周完成 N340 文档族工程化基线设计，行动项已形成，下一步进入 127→126→128→125→129→130 主链补齐。

## core_progress
- 127 服务卡片规则已确认。
- 126 API 文档粒度规则已确认。
- 128 数据字典对象覆盖度检查已确认。

## blockers_and_risks
| type | item | status | next_action |
|---|---|---|---|
| risk | 部分文档缺真实 upstream ID | open | 使用 temporary aliases 并进入 pending_id_backfill |

## next_week_focus
1. 完成 6 份 family-aligned examples。
2. 用 examples 验证 N340→N350/N390 handoff。

## coordination_or_decisions_needed
- 需要 architecture-team 确认 service card 是否作为 source of truth。

## data_basis_and_gaps
- confirmed_fact: 来自会议行动项示例。
- open_question: 真实 project_id 待替换。

```yaml
downstream_handoff:
  contract_version: n340-collaboration-v1.1.2
  handoff_id: HO-N340-WR-platform-202619-001
  producer_skill: weekly-report-generation
  consumer_skill_or_node: faq-generation
  artifact_family_id: n340-collaboration-suite
  artifact_id: WR-platform-202619
  required_fields: [artifact_id, topic_scope, evidence_refs]
  cross_artifact_refs: [ACT-platform-202619-01]
  pending_clarifications: []
  readiness: ready
  confidence: high
  next_best_checks: [review with owning team before publishing]
```
