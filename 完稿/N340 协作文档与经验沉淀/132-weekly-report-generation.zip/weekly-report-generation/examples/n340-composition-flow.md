# Example: N340 Cross-Skill Composition Flow

Demonstrates how skills #131 → #132 → #133 → #134 compose into a unified weekly knowledge cycle.

**Scenario**: Platform team Sprint 23 week ending 2025-06-13. Arch sync meeting on Tuesday produced action items; these flow into weekly report, surface FAQ themes, and crystallize a validated best practice.

---

## Step 1 — #131 Meeting Minutes → Action Items

**Input**: arch-sync-2025-06-10 meeting notes  
**Artifact**: `ACTION-N340-2025-W24`

Key output (excerpt):

```yaml
artifact_id: ACTION-N340-2025-W24
selected_mode: meeting_followup_actions
source_time_window: {meeting: arch-sync-2025-06-10}

action_items:
  - action_id: AI-W24-001
    action_type: external_commitment
    what: "向合作方 ABC 提供 OAuth callback spec v1 草稿"
    who_role: backend-lead
    commitment_to: "ABC 集成团队"
    commitment_deadline: "2025-06-30"
    priority: P0
    evidence_ref: "meeting:arch-sync-2025-06-10#action:2"

  - action_id: AI-W24-002
    action_type: decision
    what: "决定购物车数量上限策略（无限制 vs 512条 vs 可配置）"
    who_role: PM|ENG-lead
    deadline: "2025-06-17"
    priority: P1
    evidence_ref: "meeting:arch-sync-2025-06-10#action:5"

  - action_id: AI-W24-003
    action_type: task
    what: "完成 Redis warm-up 步骤集成到 CD pipeline（来自 INC-2025-0612 AI-001-001）"
    who_role: platform-team
    deadline: "2025-07-01"
    success_criteria: "连续 3 次含缓存变更的 deploy 零 503；warm-up 步骤出现在 deploy 日志"
    priority: P1
    evidence_ref: "postmortem:PM-INC-2025-0612-001#AI-001-001"

downstream_handoff:
  consumer_skill_or_node: weekly-report-generation
  cross_artifact_refs: [ACTION-N340-2025-W24]
  external_commitments: [AI-W24-001]
  readiness: complete
```

---

## Step 2 — #132 Weekly Report Generation

**Input**: `ACTION-N340-2025-W24` + sprint task status  
**Artifact**: `WEEKLY-N340-2025-W24` (pm_weekly mode)

Key output (excerpt):

```markdown
# 周报 — PM 视角 | Sprint 23 | 2025-06-09 ~ 2025-06-13

## 本周摘要
M3 联调进度正常，购物车上限策略决策待定（截止 2025-06-17）；对外承诺 OAuth spec 按期推进，无风险。

## 里程碑与交付进度
| 里程碑 | 计划日期 | 当前预测 | 状态 |
|-------|---------|---------|------|
| M3 联调完成 | 2025-06-20 | 2025-06-20 | ON_TRACK |
| Redis warm-up 集成 | 2025-07-01 | 2025-07-01 | ON_TRACK |

## 关键决策
- 待决：购物车上限策略 (AI-W24-002) — 截止 2025-06-17，PM|ENG-lead 决策

## 外部承诺跟踪（必填）
| 承诺内容 | 承诺对象 | 原定日期 | 当前状态 |
|--------|--------|---------|---------|
| OAuth callback spec v1 草稿 | ABC 集成团队 | 2025-06-30 | ON_TRACK |
```

Consumed `ACTION-N340-2025-W24` by `artifact_id`, cited action items by `action_id` — did not copy full artifact.

```yaml
downstream_handoff:
  consumer_skill_or_node: faq-generation
  cross_artifact_refs: [ACTION-N340-2025-W24, WEEKLY-N340-2025-W24]
  repeated_questions_observed:
    - "购物车上限为什么有 512 条限制？"
    - "Redis warm-up 是什么，为什么以前没有？"
```

---

## Step 3 — #133 FAQ Generation

**Input**: `WEEKLY-N340-2025-W24` repeated questions + INC-2025-0612 postmortem  
**Artifact**: `FAQ-N340-PLATFORM-2025-W24`

```yaml
faq_entries:
  - faq_id: FAQ-P-042
    question: "购物车数量上限是多少？为什么有这个限制？"
    answer: "目前技术约束为 512 条（Redis 单 key 限制）。产品与研发正在讨论可配置上限方案，决策截止 2025-06-17（见 PEA-003）。"
    category: product-engineering-gap
    staleness_risk: high
    review_by: "2025-07-01 (post-decision)"
    source_refs: ["PEA-003", "WEEKLY-N340-2025-W24"]

  - faq_id: FAQ-P-043
    question: "Redis cache warm-up 是什么？为什么之前没有？"
    answer: "Cache warm-up 指在 deploy 切流前预先填充热点缓存 key，避免冷启动导致数据库瞬时高负载。之前未加入是因为 deploy pipeline 未将缓存状态作为 gate，INC-2025-0612 事故后已列为 AI-001-001 改进项。"
    category: ops-incident-learning
    staleness_risk: medium
    review_by: "2025-09-01"
    source_refs: ["PM-INC-2025-0612-001", "AI-001-001"]
    related_faq_ids: []
```

```yaml
downstream_handoff:
  consumer_skill_or_node: best-practice-summary
  cross_artifact_refs: [FAQ-N340-PLATFORM-2025-W24]
  pattern_candidates:
    - "FAQ-P-043 repeated across 2 incidents — may be canonical anti-pattern"
```

---

## Step 4 — #134 Best Practice Summary

**Input**: `FAQ-N340-PLATFORM-2025-W24` pattern_candidate + 2 incident postmortems  
**Artifact**: `BP-N340-CACHE-WARM-2025`

```yaml
pattern_id: BP-CACHE-001
name: "在含缓存清空的 deploy 前添加 cache warm-up gate"
context: "服务依赖 Redis 热点缓存，deploy 会清空缓存 key（全量替换或 flush）"
problem: |
  未 warm-up 时，deploy 后第一波流量全部穿透到数据库，
  导致 DB 连接池耗尽、P99 延迟爆炸。INC-2024-031 和 INC-2025-0612 均为此模式。
solution: |
  在 CD pipeline traffic-routing gate 前插入 cache-warm-up step：
  1. 运行 warm-up 脚本（预填充 top-N 热点 key）
  2. 验证 hit-rate > 阈值（推荐 60%）
  3. 通过后再切流
consequences:
  doing_it_wrong: "P1 可用性事故，DB 过载，RTO 30-60 分钟（两次实测）"
  doing_it_right: "cold-start 期间 hit-rate 可维持 >60%，数据库负载平稳"
anti_pattern: "deploy 后立即切 100% 流量，不预热缓存，不在 pipeline 中验证 hit-rate"
evidence_refs: ["INC-2024-031", "INC-2025-0612", "FAQ-P-043"]
maturity: validated
applicable_team_scope: cross-team
adoption_effort: medium
```

**Maturity**: `validated` — two independent incidents with same root cause pattern confirm this.

---

## Composition Summary

```
arch-sync-meeting
      ↓ #131 (meeting_followup_actions)
ACTION-N340-2025-W24  ──→  external_commitments tracked
      ↓ consumed by #132 (pm_weekly)
WEEKLY-N340-2025-W24  ──→  repeated questions surfaced
      ↓ consumed by #133 (ops_faq + onboarding_faq)  
FAQ-N340-PLATFORM-2025-W24  ──→  pattern candidate identified
      ↓ consumed by #134 (incident_lesson_pattern)
BP-CACHE-001  ──→  validated best practice, maturity=validated
      ↓ feeds back into
WEEKLY next sprint: "cache warm-up gate rollout" tracked as milestone
```

All artifacts cite each other by `artifact_id` only. No full content copying across skills.

## Downstream Handoff

```yaml
handoff_id: WEEKLY-HANDOFF-2025-W24
producer_skill: weekly-report-generation
consumer_skill_or_node: faq-generation
cross_artifact_refs:
  - artifact_id: ACTION-N340-2025-W24
    consumed_fields: [action_items, external_commitments]
repeated_questions_observed:
  - "Redis warm-up 是什么？为什么之前没有？"
  - "OAuth callback spec 什么时候能好？"
readiness: complete
confidence: high
next_best_checks:
  - "faq-generation: create entries for repeated questions above"
  - "best-practice-summary: cache warm-up pattern approaching validated threshold"
```
