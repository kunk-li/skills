#!/usr/bin/env python3
"""validate_md.py for skill #132 weekly-report-generation (n340-collaboration-v1.1.2)"""
import re, sys
from pathlib import Path

SCHEMA = "n340-collaboration-v1.1.2 / #132 weekly-report-generation"
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}
VALID_MODES = {"tl_weekly", "pm_weekly", "l6_weekly", "crisis_weekly", "neutral_summary_fallback"}

REQUIRED_HEADINGS = [
    ("metadata",        re.compile(r"##\s*\d*\.?\s*Metadata|^```yaml[\s\S]*?\bmetadata:\b", re.I | re.MULTILINE)),
    ("ext_commitments", re.compile(r"##\s*\d*\.?\s*(外部承诺|External [Cc]ommitment)", re.I)),
    ("downstream",      re.compile(r"##\s*\d*\.?\s*(Downstream [Hh]andoff|下游交接)", re.I)),
]

NEVER_EMPTY_SECTIONS = [
    ("ext_commitments", re.compile(r"##\s*\d*\.?\s*(外部承诺|External [Cc]ommitment)", re.I)),
]


def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0


def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_md.py <output.md> [--strict]"); return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists(): return fail(f"file not found: {path}")
    text = path.read_text(encoding="utf-8")
    errors = 0; warnings = 0

    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    if _is_example and _has_any_heading:
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness '{_rm.group(1)}' not in {VALID_READINESS}"); return 1
        return ok(f"{SCHEMA} example validation passed (light-check mode)")

    found = {}
    for key, pat in REQUIRED_HEADINGS:
        m = pat.search(text)
        if m: found[key] = m.start()
        else: print(f"[FAIL] missing section: {key}"); errors += 1

    # NEVER_EMPTY checks
    for key, pat in NEVER_EMPTY_SECTIONS:
        m = pat.search(text)
        if m:
            rest = text[m.end():]
            next_h = re.search(r'\n## ', rest)
            section_body = rest[:next_h.start()].strip() if next_h else rest.strip()
            lines = [l for l in section_body.split('\n') if l.strip() and not l.startswith('##')]
            content = '\n'.join(lines).strip()
            if len(content) < 20:
                print(f"[FAIL] section '{key}' is never-empty — write '本周无对外承诺' if none")
                errors += 1

    # Mode check
    mm = re.search(r"selected_mode[:\s]+[`\"']?(\w+)", text)
    if mm and mm.group(1) not in VALID_MODES:
        warn(f"selected_mode '{mm.group(1)}' not in known modes"); warnings += 1

    # Crisis weekly checks
    if mm and mm.group(1) == "crisis_weekly":
        if "incident_id" not in text:
            print("[FAIL] crisis_weekly missing incident_id"); errors += 1
        if "escalation_path" not in text:
            print("[FAIL] crisis_weekly missing escalation_path"); errors += 1

    # Readiness
    rm = re.search(r"readiness:\s*([\w]+)", text)
    if rm and rm.group(1) not in VALID_READINESS:
        print(f"[FAIL] readiness '{rm.group(1)}' not in {VALID_READINESS}"); errors += 1

    # repeated_questions_observed in downstream
    if "downstream" in found:
        snippet = text[found["downstream"]:found["downstream"]+500]
        if "repeated_questions_observed" not in snippet:
            warn("downstream_handoff missing repeated_questions_observed (for #133)"); warnings += 1

    if errors > 0: return fail(f"{SCHEMA} FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} passed — {warnings} warning(s)")


if __name__ == "__main__":
    raise SystemExit(main())
