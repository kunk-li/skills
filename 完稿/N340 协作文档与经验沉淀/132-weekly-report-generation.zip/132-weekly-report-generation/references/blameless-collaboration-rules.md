# N340 Blameless Collaboration Rules

- Describe work by role, team, system, artifact, or decision context; do not blame named individuals.
- Convert ambiguous commitments into explicit actions with owner role, deadline or review window, success criteria, and dependency.
- Separate confirmed facts from bounded inferences and open questions.
- Preserve blockers and tradeoffs without assigning personal fault.
