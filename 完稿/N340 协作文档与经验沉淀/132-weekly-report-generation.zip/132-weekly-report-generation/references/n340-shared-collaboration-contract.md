# N340 Shared Collaboration Knowledge Contract

## Contract version
`n340-collaboration-v1.1.1`

## Node scope
N340 turns collaboration materials and knowledge signals into a self-contained family of reusable collaboration artifacts:
- 131: meeting action items
- 132: weekly reports
- 133: FAQ entries
- 134: best-practice patterns

Each skill must be useful alone and stronger when combined with sibling artifacts.

## Encapsulation governance
Each N340 skill package is self-contained. All shared rules required by the skill are packaged in that skill's `references/` folder. Do not require files, scripts, directories, hidden registries, or services outside the skill package.

## Release consistency rule
A valid N340 release keeps the same `contract_version` in `SKILL.md`, `references/output-contract.yaml`, and this shared contract. The four skill-local copies of this contract should remain byte-identical before packaging.

## Shared metadata schema
Every N340 output must begin with a compact `metadata` block using these fields:

```yaml
metadata:
  contract_version: n340-collaboration-v1.1.1
  workflow_node: N340
  skill_id: 131 | 132 | 133 | 134
  skill_name: meeting-minutes-to-action-items | weekly-report-generation | faq-generation | best-practice-summary
  artifact_family_id: n340-collaboration-suite
  artifact_id: string
  selected_mode: string
  readiness: draft | partial | ready | blocked
  source_time_window:
    start: iso8601 | unknown
    end: iso8601 | unknown
    timezone: string
  audience_scope: [string]
  topic_scope: [string]
  source_artifacts: [string]
  upstream_id_aliases: [string]
  evidence_refs: [ref_id]
  cross_artifact_refs: [artifact_id]
  pending_clarifications: [string]
  open_blockers: [string]
  owner_placeholders: [string]
  confidentiality_level: public_internal | restricted_internal | confidential
  confidence: high | medium | low
  composition_role: string
  function_bias: string
  stage_position: collaboration_knowledge.<sub_stage>
  node_artifact_target: string
  freshness:
    as_of_date: iso8601 | unknown
    source_commit: string | null
    expected_review_window: string
```

## Metadata enums
- `readiness`: `draft` means initial but structurally valid; `partial` means missing evidence is visible; `ready` means suitable for handoff; `blocked` means output cannot be safely used without named blockers.
- `confidentiality_level`: use `public_internal` for normal team knowledge, `restricted_internal` for sensitive project/partner information, and `confidential` for content needing explicit access controls.
- `owner_placeholders`: use role/team only, never individual blame or personal ownership unless the source system already requires a named accountable person.

## Artifact id and family rules
Use stable IDs so sibling skills and downstream nodes can join artifacts without relying on filenames.

| skill_id | artifact target | artifact_id format |
|---|---|---|
| 131 | 会议行动项清单.md | `ACT-<project_or_topic>-<yyyyww_or_nn>` |
| 132 | 周报.md | `WR-<project_or_topic>-<yyyyww_or_nn>` |
| 133 | faq.md | `FAQ-<project_or_topic>-<yyyyww_or_nn>` |
| 134 | best_practices.md | `PAT-<project_or_topic>-<yyyyww_or_nn>` |

Use the exact pattern declared in each skill-local `references/output-contract.yaml`.

A standalone run may create a temporary ID with `TEMP-N340-<date>-<source>`. Put temporary or conflicting upstream IDs in `upstream_id_aliases` or `pending_clarifications`; never silently rename them.

## Evidence reference schema
Use compact evidence references instead of copying large transcripts, chats, docs, or tickets.

```yaml
evidence_ref:
  ref_id: string
  source_family: meeting_transcript | meeting_notes | chat | task_status | weekly_status | doc | faq | postmortem | incident | support_ticket | manual_note
  source_name: string
  excerpt_or_pointer: string
  source_time_window: string
  topic_scope: [string]
  upstream_artifact: string
  confidence: high | medium | low
  layer: confirmed_fact | bounded_inference | open_question
```

`confirmed_fact` is directly supported by source material. `bounded_inference` is a reasonable synthesis that must be labeled. `open_question` is a known gap or pending clarification.

## Cross-artifact join keys
Composed N340 runs join artifacts by:
- `artifact_family_id`
- `artifact_id`
- `cross_artifact_refs`
- `topic_scope`
- `source_time_window`
- `evidence_refs`
- `upstream_id_aliases`

Later skills should cite earlier artifacts by `artifact_id` and `evidence_refs` instead of redoing their analysis.

## Standard composition paths
### Meeting-to-execution
`meeting-minutes-to-action-items -> weekly-report-generation -> faq-generation -> best-practice-summary`

Use when meeting discussions produce action commitments, weekly status, repeated questions, and reusable patterns.

### Weekly-to-knowledge
`weekly-report-generation -> faq-generation -> best-practice-summary`

Use when weekly risks, blockers, or decisions reveal repeated information gaps or reusable operating patterns.

### FAQ-to-practice
`faq-generation -> best-practice-summary -> weekly-report-generation`

Use when repeated questions become mature knowledge patterns and then feed management reporting.

### Incident-learning
`meeting-minutes-to-action-items -> faq-generation -> best-practice-summary`

Use after incident reviews, postmortems, or customer escalations to turn follow-up actions and repeated questions into reusable lessons.

### Standalone fallback
Any one skill may run alone when only its minimum viable input exists. It must still emit valid metadata, evidence_refs, readiness, and downstream_handoff.

## Standalone guarantee
- A skill must run with its own minimum viable input and no sibling artifacts.
- A skill must produce its target artifact with stable required sections even when readiness is partial.
- A skill must list missing evidence and next best checks rather than blocking on unavailable sibling signals.
- A skill must avoid pretending uncertain inference is confirmed fact.
- A skill must preserve role/team ownership and blame-less language.
- A skill must emit a valid downstream_handoff even when the only consumer is `knowledge_base` or `N390`.

## Composition guarantee
- 131 owns action commitments extracted from discussion.
- 132 owns weekly status synthesis and reader-specific reporting.
- 133 owns FAQ taxonomy, semantic deduplication, and concise answers.
- 134 owns reusable patterns, maturity, and anti-patterns.
- Sibling skills exchange only artifacts and handoff fields, not hidden state.
- Conflicting evidence remains visible with confidence labels.
- Cross-links use `artifact_id` and `evidence_refs`, not local file paths.

## Downstream handoff schema
Every N340 artifact should end with a `downstream_handoff` block:

```yaml
downstream_handoff:
  contract_version: n340-collaboration-v1.1.1
  handoff_id: HO-N340-<artifact_id>-<seq>
  producer_skill: meeting-minutes-to-action-items | weekly-report-generation | faq-generation | best-practice-summary
  consumer_skill_or_node: sibling_skill | N350 | N360 | N390 | knowledge_base | training | management_review
  artifact_family_id: n340-collaboration-suite
  artifact_id: string
  required_fields: [artifact_id, topic_scope, evidence_refs]
  cross_artifact_refs: [artifact_id]
  pending_clarifications: [string]
  readiness: draft | partial | ready | blocked
  confidence: high | medium | low
  next_best_checks: [string]
```

## Common execution workflow
1. Identify source type, audience, selected mode, and artifact target.
2. Normalize source evidence into `evidence_refs` with confidence and layer.
3. Create or preserve stable `artifact_id` and upstream aliases.
4. Build the skill-specific artifact using the output contract.
5. Separate confirmed facts, bounded inferences, and open questions.
6. Add cross_artifact_refs only when the referenced artifact is present or explicitly stubbed.
7. Complete downstream_handoff with required fields and next best checks.
8. Run the skill-specific quality checklist before finalizing.

## Common input handling
When input is incomplete, do not invent missing source facts. Produce a bounded draft, mark readiness as `partial`, fill `pending_clarifications`, and include next best checks. When input contains personal names in meeting or chat materials, convert them to role/team owner placeholders unless the final system specifically requires named owners.

## Common self-check
Before returning an artifact, verify:
1. Metadata exists and uses the current contract version.
2. `selected_mode` matches the artifact structure.
3. `artifact_id` follows the skill-specific format or temporary fallback.
4. `evidence_refs` distinguish confirmed facts from inference and open questions.
5. `owner_placeholders` contain role/team language.
6. `cross_artifact_refs` reference sibling artifacts by stable IDs.
7. The artifact is useful standalone even without sibling outputs.
8. The artifact becomes stronger when sibling artifacts exist.
9. Handoff has `handoff_id`, producer, consumer, readiness, confidence, and next_best_checks.
10. Open blockers and pending clarifications are visible.
11. The output follows the relevant quality checklist and example style unless intentionally different.

## Tone and content rules
- Use clear, concise, reusable language.
- Prefer role/team ownership, not personal blame.
- Keep knowledge artifacts searchable and maintainable.
- Do not overstate maturity or completeness.
- Preserve source uncertainty with confidence labels.
