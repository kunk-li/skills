# Weekly Template Per Role

## TL weekly
Focus on delivery progress, technical risk, resource coordination, and blockers.

## PM weekly
Focus on scope, milestones, dependencies, risk burn-down, and cross-team coordination.

## L6 weekly
Focus on overall status, major risks, business or user impact, and decisions needed.

## Neutral fallback
Use when the reader is unknown. Keep facts concise and call out missing audience assumptions.
