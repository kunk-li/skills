# N340 Cross-Skill Handoffs

All N340 skills exchange artifacts through metadata, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff`.

## Primary handoff routes
- 131 action items -> 132 weekly report: action status, blockers, and decisions.
- 132 weekly report -> 133 FAQ: repeated questions, unclear concepts, and missing explanations.
- 133 FAQ -> 134 best practice: stable repeated questions and reusable answers become pattern candidates.
- 134 best practice -> 132 weekly report: mature patterns may be highlighted as process improvements.

## Join keys
- `artifact_family_id: n340-collaboration-suite`
- `artifact_id`
- `topic_scope`
- `source_time_window`
- `evidence_refs`
- `cross_artifact_refs`

## Rule
Do not copy an entire sibling artifact into another artifact. Cite by `artifact_id`, summarize only the relevant part, and keep the source confidence visible.
