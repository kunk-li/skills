---
name: weekly-report-generation
description: generate weekly reports for the n340 collaboration and knowledge node. use when ChatGPT must summarize weekly progress, blockers, risks, decisions, action status, and next steps from task lists, status updates, meeting action items, release notes, or mixed project materials for tl, pm, l6, or neutral reporting views while preserving facts, open blockers, and downstream knowledge handoffs.
---

# 周报生成


## N340 v1.1.1 contract baseline
- contract_version: `n340-collaboration-v1.1.1`
- workflow node: `N340`
- packaging rule: this skill is self-contained; do not rely on node-level files, node-level tools, external matrices, or unbundled scripts.
- composition rule: exchange artifacts through `metadata`, `artifact_id`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Before producing the final artifact, consult `references/n340-shared-collaboration-contract.md` and `references/output-contract.yaml`. Use `references/blameless-collaboration-rules.md` whenever people, teams, decisions, incidents, or blockers are described.

## Role
把任务状态、会议行动项、风险、阻塞和阶段结果收敛成可直接汇报的周报。

## Selected modes
- `tl_weekly`
- `pm_weekly`
- `l6_weekly`
- `neutral_summary_fallback`

## Primary inputs
- status updates, task lists, and blocker lists
- meeting action items and decisions
- release, validation, incident, or project progress notes

## Standalone and composition role
```yaml
standalone_guarantee:
  minimum_viable_input: 一组状态更新、任务列表、行动项或本周事件摘要。
  partial_readiness_allowed: true
  degradation_behavior: 即使数据不完整，也输出 readiness=partial 的周报，并区分 confirmed facts 和 open gaps。
composition_role: weekly_status_synthesizer
function_bias: aggregate_weekly_status_for_reader_context
best_combines_with:
  - meeting-minutes-to-action-items
  - faq-generation
  - best-practice-summary
join_keys:
  - artifact_family_id
  - artifact_id
  - cross_artifact_refs
  - topic_scope
  - source_time_window
  - evidence_refs
  - upstream_id_aliases
```

## Output contract
Follow `references/output-contract.yaml`. Every output must include:
- a `metadata` block using `n340-collaboration-v1.1.1`
- stable required sections for the selected mode
- compact `evidence_refs` rather than long pasted source material
- `downstream_handoff` with readiness, confidence, consumer, and next best checks

## Execution workflow
1. Read the shared contract and this skill's output contract.
2. Determine selected mode, audience, topic scope, and source time window.
3. Normalize source material into evidence refs with confidence and layer.
4. Produce the skill-specific artifact using the required sections.
5. Mark missing fields in `pending_clarifications` or `open_blockers` rather than inventing facts.
6. Add cross-artifact refs only when a sibling artifact is present or explicitly stubbed.
7. Complete downstream handoff for sibling skills or downstream nodes.
8. Run the quality checklist before finalizing.

## Design rules
- Keep the artifact useful when this skill is used alone.
- Make the artifact stronger when sibling artifacts exist by citing them through stable IDs.
- Use role/team owner placeholders instead of personal blame.
- Do not overstate readiness, maturity, or source certainty.
- Keep content reusable and searchable; avoid one-off local shorthand unless documented as an alias.

## Composition contract
Best combined with:
- `meeting-minutes-to-action-items`
- `faq-generation`
- `best-practice-summary`

When combined, this skill must consume sibling artifacts by `artifact_id` and `evidence_refs` rather than copying their whole content.

## References
- `references/n340-shared-collaboration-contract.md`
- `references/output-contract.yaml`
- `references/blameless-collaboration-rules.md`
- `references/n340-cross-skill-handoffs.md`
- `references/weekly-report-generation-quality-checklist.md`
- `references/weekly-template-per-role.md`

## Example
See `examples/team-weekly-report.md` for a complete v1.1.1-style artifact.
