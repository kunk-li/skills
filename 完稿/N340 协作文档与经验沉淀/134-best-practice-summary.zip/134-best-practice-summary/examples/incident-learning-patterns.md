# 最佳实践示例

```yaml
metadata:
  contract_version: n340-collaboration-v1.1.1
  workflow_node: N340
  skill_id: 134
  skill_name: best-practice-summary
  artifact_family_id: n340-collaboration-suite
  artifact_id: PAT-doc-family-01
  selected_mode: process_pattern_summary
  readiness: ready
  source_time_window:
    start: 2026-05-01T00:00:00+09:00
    end: 2026-05-07T23:59:59+09:00
    timezone: Asia/Tokyo
  audience_scope: [engineering, product, operations]
  topic_scope: [doc-family-governance]
  source_artifacts: [sample-input]
  upstream_id_aliases: []
  evidence_refs: [EV-N340-SAMPLE-01]
  cross_artifact_refs: [FAQ-platform-docs-01, WR-platform-202619, ACT-platform-202619-01]
  pending_clarifications: []
  open_blockers: []
  owner_placeholders: [platform-team, product-team]
  confidentiality_level: public_internal
  confidence: high
  composition_role: reusable_pattern_extractor
  function_bias: turn_repeated_evidence_into_mature_practice_patterns
  stage_position: collaboration_knowledge.pattern_extraction
  node_artifact_target: best_practices.md | pattern_library.md
  freshness:
    as_of_date: 2026-05-07
    source_commit: null
    expected_review_window: weekly
```

## pattern_summary
本示例提炼“先定义 source-of-truth，再生成下游文档”的文档族实践。

## pattern_entries
| pattern_id | context | problem | solution | consequences | anti_pattern | evidence | maturity |
|---|---|---|---|---|---|---|---|
| PAT-doc-family-01-001 | 多份技术/运维文档需要组合发布 | 如果每份文档单独写，会出现 ID 漂移和重复定义 | 先由 127 定义服务卡与边界，再让 126/128/125/129/130 复用 stable IDs | 降低重复定义，提升下游 join 稳定性 | 每份文档各自定义服务边界 | EV-N340-SAMPLE-01 | validated |

## maturity_assessment
- maturity: validated
- rationale: 已由 6 份 N340 examples 形成完整主链闭环。

## anti_patterns
- 直接复制兄弟文档内容而不是引用 artifact_id。
- 把一次会议中的建议写成 canonical practice。

## evidence_and_cross_links
- FAQ-platform-docs-01
- WR-platform-202619
- ACT-platform-202619-01

```yaml
downstream_handoff:
  contract_version: n340-collaboration-v1.1.1
  handoff_id: HO-N340-PAT-doc-family-01-001
  producer_skill: best-practice-summary
  consumer_skill_or_node: N390 templates
  artifact_family_id: n340-collaboration-suite
  artifact_id: PAT-doc-family-01
  required_fields: [artifact_id, topic_scope, evidence_refs]
  cross_artifact_refs: [FAQ-platform-docs-01, WR-platform-202619, ACT-platform-202619-01]
  pending_clarifications: []
  readiness: ready
  confidence: high
  next_best_checks: [review with owning team before publishing]
```
