# Pattern Maturity Rubric

## proposed
Supported by one incident, one example, or bounded inference. Useful as a candidate, not as policy.

## validated
Supported by repeated evidence, multiple teams, or successful reuse in a similar context.

## canonical
Approved or repeatedly validated enough to become default guidance. Must include counterexamples or anti-patterns.

Rules:
- No evidence means maturity must be `proposed`.
- Maturity can be downgraded when evidence conflicts.
- Keep anti-pattern explicit to avoid promotional prose.
