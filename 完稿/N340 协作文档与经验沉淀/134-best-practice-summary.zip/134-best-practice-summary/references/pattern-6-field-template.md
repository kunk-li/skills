# Pattern 6-Field Template

Each pattern entry must include:

```yaml
pattern:
  pattern_id: PAT-<topic>-<nn>
  context: string
  problem: string
  solution: string
  consequences: string
  anti_pattern: string
  evidence: [ref_id]
  maturity: proposed | validated | canonical
```

Do not label a pattern as canonical unless repeated evidence supports it.
