---
name: best-practice-summary
description: summarize reusable best practices for the n340 collaboration and knowledge node. use when ChatGPT must turn repeated wins, repeated failures, postmortem lessons, faq themes, architecture patterns, process learnings, or operating experience into structured pattern library entries with context, problem, solution, consequences, anti-pattern, evidence, maturity, cross-links, and handoffs for templates, training, and future project bootstrap.
---

# 最佳实践总结


## N340 v1.1.1 contract baseline
- contract_version: `n340-collaboration-v1.1.1`
- workflow node: `N340`
- packaging rule: this skill is self-contained; do not rely on node-level files, node-level tools, external matrices, or unbundled scripts.
- composition rule: exchange artifacts through `metadata`, `artifact_id`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Before producing the final artifact, consult `references/n340-shared-collaboration-contract.md` and `references/output-contract.yaml`. Use `references/blameless-collaboration-rules.md` whenever people, teams, decisions, incidents, or blockers are described.

## Role
把历史事件、成熟做法、FAQ 主题和反复验证的经验整理为可复用 pattern，而不是一次性经验描述。

## Selected modes
- `incident_lesson_pattern`
- `architecture_pattern_summary`
- `process_pattern_summary`
- `evidence_limited_candidate`

## Primary inputs
- postmortems, timelines, FAQ entries, and weekly reports
- historical success/failure examples and process improvements
- architecture or operations guidelines, runbooks, and training notes

## Standalone and composition role
```yaml
standalone_guarantee:
  minimum_viable_input: 至少一个案例、复盘、FAQ 主题、周报重复信号或方法片段。
  partial_readiness_allowed: true
  degradation_behavior: 证据不足时输出 maturity=proposed 的 pattern candidate，不把推演性建议写成 canonical。
composition_role: reusable_pattern_extractor
function_bias: turn_repeated_evidence_into_mature_practice_patterns
best_combines_with:
  - faq-generation
  - weekly-report-generation
  - meeting-minutes-to-action-items
join_keys:
  - artifact_family_id
  - artifact_id
  - cross_artifact_refs
  - topic_scope
  - source_time_window
  - evidence_refs
  - upstream_id_aliases
```

## Output contract
Follow `references/output-contract.yaml`. Every output must include:
- a `metadata` block using `n340-collaboration-v1.1.1`
- stable required sections for the selected mode
- compact `evidence_refs` rather than long pasted source material
- `downstream_handoff` with readiness, confidence, consumer, and next best checks

## Execution workflow
1. Read the shared contract and this skill's output contract.
2. Determine selected mode, audience, topic scope, and source time window.
3. Normalize source material into evidence refs with confidence and layer.
4. Produce the skill-specific artifact using the required sections.
5. Mark missing fields in `pending_clarifications` or `open_blockers` rather than inventing facts.
6. Add cross-artifact refs only when a sibling artifact is present or explicitly stubbed.
7. Complete downstream handoff for sibling skills or downstream nodes.
8. Run the quality checklist before finalizing.

## Design rules
- Keep the artifact useful when this skill is used alone.
- Make the artifact stronger when sibling artifacts exist by citing them through stable IDs.
- Use role/team owner placeholders instead of personal blame.
- Do not overstate readiness, maturity, or source certainty.
- Keep content reusable and searchable; avoid one-off local shorthand unless documented as an alias.

## Composition contract
Best combined with:
- `faq-generation`
- `weekly-report-generation`
- `meeting-minutes-to-action-items`

When combined, this skill must consume sibling artifacts by `artifact_id` and `evidence_refs` rather than copying their whole content.

## References
- `references/n340-shared-collaboration-contract.md`
- `references/output-contract.yaml`
- `references/blameless-collaboration-rules.md`
- `references/n340-cross-skill-handoffs.md`
- `references/best-practice-summary-quality-checklist.md`
- `references/pattern-6-field-template.md`
- `references/pattern-maturity-rubric.md`

## Example
See `examples/incident-learning-patterns.md` for a complete v1.1.1-style artifact, and `examples/incident-pattern-from-n320.md` for an N320 incident-derived pattern example.
