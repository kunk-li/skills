# Example: Best Practice Summary — Process Pattern Summary Mode

Demonstrates `process_pattern_summary` mode: operational and collaboration patterns from weekly reports and retrospectives.

```yaml
metadata:
  contract_version: n340-collaboration-v1.1.2
  skill_id: "134"
  selected_mode: process_pattern_summary
  artifact_id: BP-N340-PROCESS-2025-Q2
  pattern_count: 3
  readiness: complete
```

## Maturity Index

| Maturity | Count |
|----------|-------|
| canonical | 0 |
| validated | 1 |
| proposed | 2 |

---

## Pattern Entries

### BP-PROC-001: 每次 Sprint Planning 前锁定外部依赖确认状态

```yaml
pattern_id: BP-PROC-001
name: "Sprint Planning 前完成所有外部依赖确认，不接受'会来'作为承诺"
context: "跨团队协作项目，Sprint 目标依赖外部团队交付（如第三方 API spec、平台能力就绪）"
problem: |
  Sprint 开始时外部依赖状态不明确，导致第 2-3 天出现大范围任务阻塞。
  S22、S23 均出现 auth-team spec 延期导致联调无法启动的情况（各延期 3 天）。
solution: |
  Planning 前 T-2 天，PM 向所有外部依赖方发出书面确认请求，要求给出：
  1. 交付日期（非"尽快"）
  2. 交付物格式（文档/接口/环境）
  3. 若不能交付，替代方案或影响评估
  Planning 当天将外部依赖状态纳入 Sprint goal 的前提条件。
consequences:
  doing_it_wrong: "Sprint 第2天出现阻塞，团队被迫临时调整计划（S22/S23 实测各延期3天）"
  doing_it_right: "S24 Planning 前2天完成确认，依赖延期提前纳入 Sprint scope 调整，无突发阻塞"
anti_pattern: "Planning 会上接受'auth-team 应该能在本 Sprint 交付'作为依赖状态，不要求书面确认日期"
evidence_refs: ["WEEKLY-N340-2025-W22", "WEEKLY-N340-2025-W24", "ACTION-N340-S24-PLANNING#AI-S24-004"]
maturity: validated
applicable_team_scope: cross-team
adoption_effort: low
```

---

### BP-PROC-002: 高危风险任务在 daily standup 中优先汇报

```yaml
pattern_id: BP-PROC-002
name: "risk_score ≥ 15 的任务在 standup 中排在所有 'IN_PROGRESS' 更新之前"
context: "团队规模 6-10 人，standup 时间 15 分钟，高风险任务容易被日常更新淹没"
problem: |
  RISK-007（score=16）在连续两个 standup 中被推迟到最后讨论，
  当决定升级时已损失 2 天缓冲时间（见 RISK-S23-W24）。
solution: |
  Standup 议程顺序：
  1. 高危风险更新（risk_score ≥ 15）— 每个 ≤2 分钟
  2. 阻塞项更新 — 每个 ≤2 分钟
  3. 正常进展（按重要性）
  Scrum Master 在 standup 前查阅当日 RISK-* artifact 确认优先顺序。
consequences:
  doing_it_wrong: "高风险任务在 standup 末尾匆忙处理，升级决策延误"
  doing_it_right: "高危风险在 standup 前 3 分钟内明确，当天可升级到 EM"
anti_pattern: "Standup 按 Jira 看板顺序汇报，所有 IN_PROGRESS 任务平等对待"
evidence_refs: ["RISK-S23-W24#RISK-007"]
maturity: proposed
applicable_team_scope: team
adoption_effort: low
```

---

### BP-PROC-003: FAQ 维护周期与 Sprint 发版节奏对齐

```yaml
pattern_id: BP-PROC-003
name: "每个 Sprint 结束时，将 staleness_risk: high 的 FAQ 条目发送到对应技术负责人复核"
context: "团队维护技术 FAQ 库，内容随版本迭代腐化"
problem: |
  FAQ-P-042（购物车上限说明）在 PEA-003 决策后变成错误信息，
  但未触发任何复核流程，持续被新人引用（见 FAQ-N340-PLATFORM-2025-W24）。
solution: |
  每 Sprint 结束时，FAQ 负责人运行 staleness_risk 过滤，
  将所有 `staleness_risk: high` 且 `review_by` 已到期的条目打包发送给 `faq_owner`。
  复核结果在下一 Sprint 第一个 standup 前更新完毕。
consequences:
  doing_it_wrong: "过期 FAQ 被引用导致新成员方向错误"
  doing_it_right: "FAQ 准确率维持 >95%（每 Sprint 复核一次）"
anti_pattern: "建立 FAQ 后不设 review 周期，靠自觉更新"
evidence_refs: ["FAQ-N340-PLATFORM-2025-W24#FAQ-P-042"]
maturity: proposed
applicable_team_scope: team
adoption_effort: medium
```

## Downstream Handoff

```yaml
handoff_id: BP-HANDOFF-PROCESS-2025-Q2
producer_skill: best-practice-summary
consumer_skill_or_node: weekly-report-generation|training-materials
cross_artifact_refs:
  - artifact_id: WEEKLY-N340-2025-W22
  - artifact_id: RISK-S23-W24
  - artifact_id: FAQ-N340-PLATFORM-2025-W24
pattern_ids_promoted: [BP-PROC-001]
readiness: complete
confidence: high
next_best_checks:
  - "weekly-report: include BP-PROC-001 as process improvement in Sprint 24 TL weekly"
  - "Monitor BP-PROC-002 adoption in Sprint 24 standup — eligible for maturity upgrade if effective"
```
