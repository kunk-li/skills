# N320 事件复盘衍生最佳实践示例

```yaml
metadata:
  contract_version: n340-collaboration-v1.1.2
  workflow_node: N340
  skill_id: 134
  skill_name: best-practice-summary
  artifact_family_id: n340-collaboration-suite
  artifact_id: PAT-platform-incident-202619
  selected_mode: incident_lesson_pattern
  readiness: ready
  source_time_window:
    start: 2026-05-01T00:00:00+09:00
    end: 2026-05-07T23:59:59+09:00
    timezone: Asia/Tokyo
  audience_scope: [engineering, operations, new_hire]
  topic_scope: [incident-learning, operational-readiness, postmortem-followup]
  source_artifacts: [线上问题复盘.md, 故障时间线.md]
  upstream_id_aliases:
    - INC-2026-0507-AVAIL-001
    - ANCHOR-N320-INC-2026-0507-AVAIL-001-detection
    - ANCHOR-N320-INC-2026-0507-AVAIL-001-mitigation
  evidence_refs:
    - EV-N320-POSTMORTEM-001
    - EV-N320-TIMELINE-001
  cross_artifact_refs:
    - FAQ-platform-incident-202619
    - WR-platform-202619
    - ACT-platform-202619-01
  pending_clarifications: []
  open_blockers: []
  owner_placeholders: [operations-team, platform-team]
  confidentiality_level: restricted_internal
  confidence: high
  composition_role: reusable_pattern_extractor
  function_bias: turn_repeated_evidence_into_mature_practice_patterns
  stage_position: collaboration_knowledge.pattern_extraction
  node_artifact_target: best_practices.md | pattern_library.md
  freshness:
    as_of_date: 2026-05-07
    source_commit: null
    expected_review_window: after incident follow-up review
```

## pattern_summary
本示例把 N320 复盘中的 `incident_id` 与 `timeline_anchor_ref` 转化为可复用的运维 readiness pattern。

## pattern_entries
| pattern_id | context | problem | solution | consequences | anti_pattern | evidence | maturity |
|---|---|---|---|---|---|---|---|
| PAT-platform-incident-202619-001 | 可用性事件复盘后，团队需要把经验转成长期可复用流程 | 只在复盘中记录结论，未把检测、缓解、验证锚点固化为运维检查项 | 从 N320 复盘复用 `incident_id` 和 timeline anchors，沉淀为发布前 readiness checklist 与维护手册 scenario | 后续类似事件可直接引用 pattern 和 runbook，减少知识丢失 | 复盘结束后只写行动项，不沉淀 pattern | EV-N320-POSTMORTEM-001; EV-N320-TIMELINE-001 | validated |

## maturity_assessment
- maturity: validated
- rationale: pattern 来自 N320 复盘与时间线证据，并且包含 detection / mitigation 两个生命周期锚点。

## anti_patterns
- 把一次事故的临时处理办法直接标记为 canonical。
- 改写上游 `incident_id` 或 timeline anchor，导致 N320 与 N340 无法 join。
- 只引用复盘结论，不引用支撑该结论的 timeline anchor。

## evidence_and_cross_links
```yaml
evidence_refs:
  - ref_id: EV-N320-POSTMORTEM-001
    source_family: postmortem
    source_name: 线上问题复盘.md
    excerpt_or_pointer: incident_id=INC-2026-0507-AVAIL-001; section=action_items_and_learning
    source_time_window: 2026-05-07T00:00:00+09:00/2026-05-07T23:59:59+09:00
    topic_scope: [availability, operational-readiness]
    upstream_artifact: 线上问题复盘.md
    confidence: high
    layer: confirmed_fact
  - ref_id: EV-N320-TIMELINE-001
    source_family: postmortem
    source_name: 故障时间线.md
    excerpt_or_pointer: timeline_anchor_ref=[ANCHOR-N320-INC-2026-0507-AVAIL-001-detection, ANCHOR-N320-INC-2026-0507-AVAIL-001-mitigation]
    source_time_window: 2026-05-07T00:00:00+09:00/2026-05-07T23:59:59+09:00
    topic_scope: [detection, mitigation, verification]
    upstream_artifact: 故障时间线.md
    confidence: high
    layer: confirmed_fact
```

```yaml
downstream_handoff:
  contract_version: n340-collaboration-v1.1.2
  handoff_id: HO-N340-PAT-platform-incident-202619-001
  producer_skill: best-practice-summary
  consumer_skill_or_node: N390 templates
  artifact_family_id: n340-collaboration-suite
  artifact_id: PAT-platform-incident-202619
  required_fields: [artifact_id, topic_scope, evidence_refs, upstream_id_aliases]
  cross_artifact_refs: [FAQ-platform-incident-202619, WR-platform-202619, ACT-platform-202619-01]
  pending_clarifications: []
  readiness: ready
  confidence: high
  next_best_checks: [confirm owning teams before promoting maturity to canonical]
```
