# Best Practice Summary Quality Checklist

Before finalizing this artifact, verify:

1. Metadata is present and uses the current contract version.
2. selected_mode matches the structure and reader/audience of the output.
3. artifact_id follows the skill-specific format or temporary fallback and aliases are recorded.
4. evidence_refs distinguish confirmed_fact, bounded_inference, and open_question.
5. cross_artifact_refs cite sibling artifacts by artifact_id, not file path.
6. open_blockers and pending_clarifications are explicit when evidence is missing.
7. owner_placeholders use role/team language rather than personal blame.
8. downstream_handoff contains handoff_id, producer, consumer, readiness, confidence, and next_best_checks.
9. freshness.as_of_date is filled or explicitly unknown.
10. The artifact remains useful standalone and improves when sibling artifacts are present.
11. Compare metadata key order, field naming, and section structure with the most relevant file under examples/. Differences are allowed but should be intentional.

Skill-specific checks:
- Every pattern has context, problem, solution, consequences, anti_pattern, evidence, and maturity.
- Do not label a pattern canonical unless repeated evidence supports it.
- Keep anti_pattern explicit so the pattern is not promotional prose.
- Cross-link evidence to FAQ, postmortem, weekly report, or action item sources.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections are present even with placeholder content; no section is silently skipped.
- Missing evidence is recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined from available input use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- When evidence supports only one case, `maturity` is `proposed` — never `validated` or `canonical` with single-case evidence.
- `anti_pattern_catalog` mode: every entry has a concrete replacement, never just "don't do X".
- `applicable_team_scope` and `adoption_effort` are always assigned, even if estimated.

## Output structure completeness checks
- All required sections present per mandatory section table.
- Section 3 (Maturity index) shows count per level: proposed/validated/canonical.
- `anti_pattern_catalog` mode: every entry has `anti_pattern` (exact thing to avoid) AND `solution` (concrete alternative).
- `maturity: validated` entries have ≥2 items in `evidence_refs`.
- `maturity: canonical` entries have an `adoption_status` field.
## Mode-specific checks

### anti_pattern_catalog mode
- Every entry has `anti_pattern` (exact behavior to avoid) AND `solution` (concrete replacement)
- `adoption_effort` and `applicable_team_scope` assigned to every pattern

### evidence_limited_candidate mode
- `maturity: proposed` only; never `validated` without ≥2 evidence refs
- `pending_evidence` field lists what evidence is needed
