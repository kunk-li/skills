# Anti-Pattern Catalog Guide

Use this reference when `anti_pattern_catalog` mode is selected.

## What an anti-pattern entry must contain
Each anti-pattern entry follows the 6-field template with these constraints:

```yaml
pattern_id: AP-001
name: "[Anti-Pattern Name] — written as a dangerous action, not a neutral label"
# Good: "直接在生产库运行 ALTER TABLE"
# Bad: "数据库变更反模式" (too vague)

context: "In what circumstances does this anti-pattern appear? Who tends to do it?"

problem: |
  What goes wrong when this anti-pattern is followed?
  Be specific: cite incident IDs, error types, or business impacts.
  Avoid vague statements like "causes issues".

solution: |
  The specific replacement practice.
  Must be a concrete alternative action, not advice like "be careful" or "plan ahead".

consequences:
  doing_it_wrong: "Specific failure mode: database lock, data loss, security breach, etc."
  doing_it_right: "Specific benefit: zero-downtime migration, 40% faster deploy, etc."

anti_pattern: "The exact action to avoid, phrased as a command or pattern"
# Example: "直接 ALTER TABLE 在超过 100 万行的表上，不使用在线 schema change 工具"

evidence_refs: ["INC-2024-018", "INC-2024-031"]
maturity: proposed | validated | canonical
applicable_team_scope: individual | team | cross-team | org
adoption_effort: low | medium | high
```

## Formatting rules for anti_pattern_catalog mode
1. **Lead with the anti-pattern name** — the reader should immediately know what NOT to do
2. **Name anti-patterns as dangerous actions**: use imperative form ("Run X without Y"), not neutral nouns ("X issue")
3. **Never mix positive and negative patterns** in the same entry — one entry = one anti-pattern
4. **Always provide a concrete replacement** — "don't do X" without "instead do Y" is incomplete
5. **Cite evidence**: at least one incident ID, postmortem reference, or verified failure case

## Maturity escalation path for anti-patterns
- `proposed`: One team observed this failure; one incident cited
- `validated`: Two or more independent teams or incidents confirm the same failure
- `canonical`: Written into official engineering standards, runbooks, or mandatory review checklists

## adoption_effort meaning for anti-patterns
- `low`: Team can stop the anti-pattern immediately with no tooling change (behavior change only)
- `medium`: Requires process change, new tooling, or review gate modification
- `high`: Requires architectural change, organizational policy, or multi-team coordination

## Example entry
```yaml
pattern_id: AP-003
name: "在高并发服务中使用数据库行锁实现分布式锁"
context: "团队急需分布式锁方案，数据库唾手可得，Redis/ZooKeeper 未部署"
problem: |
  行锁在高并发下造成严重锁争用，P99 延迟从 50ms 升至 8s（INC-2024-052）。
  锁持有方崩溃时，锁不会自动释放，需人工干预。
solution: |
  使用专用分布式锁服务：Redis SET NX PX（毫秒级 TTL）或 Redisson 封装。
  若 Redis 不可用：评估 etcd 或数据库乐观锁（带版本号）。
consequences:
  doing_it_wrong: "数据库线程池耗尽，全站超时（INC-2024-052）"
  doing_it_right: "锁争用从毫秒级降至微秒级，自动 TTL 防止死锁"
anti_pattern: "INSERT INTO locks (key) VALUES (?) ON DUPLICATE KEY UPDATE — 用于高频分布式锁"
evidence_refs: ["INC-2024-052", "postmortem:PM-2024-Q3-07"]
maturity: validated
applicable_team_scope: cross-team
adoption_effort: medium
```
