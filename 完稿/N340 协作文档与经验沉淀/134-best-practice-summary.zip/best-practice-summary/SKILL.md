---
name: best-practice-summary
description: Distill recurring lessons, wins, or failure patterns across incidents, sprints, or teams into reusable best-practice (BP) or anti-pattern (AP) records.
---

# 最佳实践总结

## N340 contract baseline (n340-collaboration-v1.1.2)

- contract_version: `n340-collaboration-v1.1.2`
- workflow node: N340
- skill_id: 134
- artifact_family_id: `n340-collaboration-suite`
- primary artifact: `最佳实践库.md`
- upstream: N320 #124 (postmortem lessons), N340 #133 (pattern_candidates), N340 #132 (weekly repeat signals)
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through `artifact_id`, `pattern_id`, `anti_pattern_id`, `evidence_refs`, and `downstream_handoff`.

Before producing the final artifact, consult `references/n340-shared-collaboration-contract.md` and `references/output-contract.yaml`. Use `references/blameless-collaboration-rules.md` whenever people, teams, decisions, incidents, or blockers are described.

## Role

把历史事件、成熟做法、FAQ 主题和反复验证的经验整理为**可复用 pattern**，而不是一次性经验描述。

具体职责：
- 从 postmortem、FAQ、周报中提取可跨项目/版本复用的结构性规律
- 将 pattern 按成熟度分级（proposed → validated → canonical），防止过度泛化
- 为每个 anti-pattern 使用 `AP-xxx` ID 命名（与 best-practice pattern_id 的 `BP-xxx` 区分）
- 维护反模式目录（anti_pattern_catalog），提供"不应该做什么 + 为什么 + 正确替代方案"

**不负责**：单次事件的 root cause 分析（→ N320 #124）、单次问题的 FAQ 条目（→ #133）、项目计划（不在 N340 范围）。

## When NOT to use this skill

- **Not a project plan or checklist**: #134 documents reusable structural patterns, not one-time project steps.
- **Not a postmortem**: incident root cause analysis belongs in N320 #124; #134 extracts reusable patterns FROM postmortems, not replaces them.
- **Not an FAQ**: single-question answers belong in #133; a best practice entry should be applicable to multiple contexts.
- **Not a decision record (ADR)**: individual architecture decisions belong in ADR systems; #134 documents the structural patterns that emerge from multiple decisions.
- **Maturity boundary**: do not produce `maturity: canonical` without team-level sign-off or official engineering standards reference. `validated` requires ≥2 independent evidence sources.

## Standalone and composition role

```yaml
standalone_goal: extract reusable structural patterns from repeated evidence across incidents, FAQs, and team experience
minimum_viable_input:
  any_of:
    - 至少一个案例、复盘或 FAQ 主题
    - #133 传递的 pattern_candidates
    - 周报中的重复信号（#132 repeated patterns）
    - 历史成功/失败示例或方法片段
    - 架构或运维指引、runbook、培训笔记
partial_readiness_allowed: true
degradation_behavior: >
  If evidence is limited, output maturity=proposed pattern candidates only.
  Do not promote to validated or canonical without ≥2 independent evidence sources.
  Do not write speculative recommendations as canonical patterns.
composition_role: reusable_pattern_extractor
function_bias: turn_repeated_evidence_into_mature_practice_patterns
best_combines_with:
  - faq-generation
  - weekly-report-generation
  - meeting-minutes-to-action-items
join_keys:
  - artifact_family_id
  - artifact_id
  - cross_artifact_refs
  - topic_scope
  - source_time_window
  - evidence_refs
  - upstream_id_aliases
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `incident_lesson_pattern`: 从 incident 或复盘中提取防御性 pattern。
- `architecture_pattern_summary`: 架构决策或技术选型中归纳出的结构性 pattern。
- `process_pattern_summary`: 流程优化、协作改进中归纳的操作性 pattern。
- `evidence_limited_candidate`: 证据不足，输出 maturity=proposed 的候选 pattern。
- **`anti_pattern_catalog`**: 专门记录反面案例，输出"不应该做什么 + 为什么 + 正确替代方案"，每条使用 `AP-xxx` ID。适合新成员培训和架构评审前准备。

**Default routing**: from postmortems → `incident_lesson_pattern`. From architecture decisions → `architecture_pattern_summary`. Limited evidence → `evidence_limited_candidate`. Anti-example training → `anti_pattern_catalog`.

## Pattern and anti-pattern ID conventions

- Best-practice patterns: `BP-xxx` (e.g., BP-001, BP-002)
- Anti-patterns: `AP-xxx` (e.g., AP-001, AP-002) — distinct namespace to avoid confusion in cross-references
- Both are citable from #131 action items, #133 FAQ entries, and #132 weekly reports

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | Metadata | Always | artifact_id, selected_mode, source_time_window, readiness |
| 2 | Pattern entries (BP-xxx) | Always in non-anti_pattern modes | Each: context + problem + solution + consequences + evidence + maturity |
| 3 | Anti-pattern entries (AP-xxx) | Always in anti_pattern_catalog; optional in other modes | Each: what not to do + why + correct alternative |
| 4 | Maturity justification | Always | Why each pattern is at its current maturity level |
| 5 | Cross-links to source artifacts | Always | Reference postmortem IDs, FAQ IDs, or action IDs |

> Legend: Always = required in every mode.

**Maturity rules**:
- `proposed`: single evidence source or speculative inference
- `validated`: ≥2 independent evidence sources (incidents, teams, time periods)
- `canonical`: team sign-off or official engineering standards reference required

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: knowledge-base / engineering-standards
  promoted_patterns: [BP-001, BP-002]
  promoted_anti_patterns: [AP-001]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (patterns have ≥2 evidence sources and maturity justified) / `partial` (maturity=proposed patterns only) / `degraded` (skeleton candidates with single-source evidence — downstream consumers must not treat as canonical).

## Workflow position

```
Postmortem lessons (N320 #124) / FAQ pattern_candidates (#133) / Weekly repeat signals (#132)
  ↓ #134 (pattern library → 最佳实践库.md)
  ↓ Knowledge base / engineering standards / team wiki
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** 单次事件直接提升为 canonical → 必须从 proposed 经过 validated；canonical 需要团队确认或官方标准引用。量化检验：maturity=canonical 的 pattern 数必须 ≤ 带有「team sign-off」/「engineering standard」/「官方标准」引用的证据条目数；不满足时 FAIL。
- **AP-2** anti-pattern 条目缺少 `AP-xxx` ID → 必须使用独立的 AP-xxx 命名空间，与 BP-xxx 区分。量化检验：anti-pattern 条目 ID 格式必须匹配 `AP-\d{3}`；使用 BP- 前缀的 anti-pattern 计入违例。
- **AP-3** pattern 描述太通用，无法区分"这个项目"与"所有项目" → 每个 pattern 必须有 context 限定其适用范围。量化检验：pattern 条目中，context 字段为空或 < 10 字符的条目数 = open_blocker 数。
- **AP-4** `anti_pattern_catalog` 模式只列问题不给替代方案 → 每条 anti-pattern 必须包含"正确替代方案"字段。量化检验：anti_pattern_catalog 模式下，缺少「correct_alternative」/「正确替代方案」字段的 AP 条目数 = FAIL 数。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n340-shared-collaboration-contract.md` — shared contract and handoff schema
- `references/n340-composition-guide.md` — composition guide
- `references/n340-cross-skill-handoffs.md` — cross-skill handoff mapping
- `references/n340-input-validation-rules.md` — when input quality is uncertain
- `references/pattern-6-field-template.md` — 6-field pattern entry format
- `references/pattern-maturity-rubric.md` — when assessing maturity level
- `references/anti-pattern-catalog-guide.md` — when using anti_pattern_catalog mode
- `references/blameless-collaboration-rules.md` — when describing people, teams, incidents
- `references/best-practice-summary-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/incident-pattern-from-n320.md` — incident_lesson_pattern from postmortem evidence
- `examples/process-pattern-summary.md` — process_pattern_summary from sprint retrospectives
- `examples/incident-learning-patterns.md` — multiple patterns from a series of related incidents
