# FAQ Generation Quality Checklist

Before finalizing this artifact, verify:

1. Metadata is present and uses the current contract version.
2. selected_mode matches the structure and reader/audience of the output.
3. artifact_id follows the skill-specific format or temporary fallback and aliases are recorded.
4. evidence_refs distinguish confirmed_fact, bounded_inference, and open_question.
5. cross_artifact_refs cite sibling artifacts by artifact_id, not file path.
6. open_blockers and pending_clarifications are explicit when evidence is missing.
7. owner_placeholders use role/team language rather than personal blame.
8. downstream_handoff contains handoff_id, producer, consumer, readiness, confidence, and next_best_checks.
9. freshness.as_of_date is filled or explicitly unknown.
10. The artifact remains useful standalone and improves when sibling artifacts are present.
11. Compare metadata key order, field naming, and section structure with the most relevant file under examples/. Differences are allowed but should be intentional.

Skill-specific checks:
- Every FAQ entry has question, answer, and example_or_link.
- Deduplicate semantically equivalent questions before writing entries.
- Use the official taxonomy unless a fallback category is explicitly justified.
- Keep answers concise and source-backed rather than tutorial-length.
