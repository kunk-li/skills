---
name: faq-generation
description: generate faq content for the n340 collaboration and knowledge node. use when ChatGPT must turn repeated questions from docs, onboarding notes, support interactions, team discussions, incident reviews, or release work into a structured taxonomy with concise answers, examples or links, semantic deduplication, source references, maintenance notes, and handoffs to best practice or knowledge base workflows.
---

# FAQ 生成


## N340 v1.1.1 contract baseline
- contract_version: `n340-collaboration-v1.1.1`
- workflow node: `N340`
- packaging rule: this skill is self-contained; do not rely on node-level files, node-level tools, external matrices, or unbundled scripts.
- composition rule: exchange artifacts through `metadata`, `artifact_id`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Before producing the final artifact, consult `references/n340-shared-collaboration-contract.md` and `references/output-contract.yaml`. Use `references/blameless-collaboration-rules.md` whenever people, teams, decisions, incidents, or blockers are described.

## Role
把重复问答、散碎答疑和文档盲区收敛为可搜索、可维护的 FAQ。

## Selected modes
- `onboarding_faq`
- `technical_support_faq`
- `operations_faq`
- `taxonomy_fallback`

## Primary inputs
- existing docs, onboarding notes, and support tickets
- chat Q&A, repeated meeting questions, and issue comments
- weekly reports, action items, postmortems, and maintenance manuals

## Standalone and composition role
```yaml
standalone_guarantee:
  minimum_viable_input: 一组问题、答疑片段、知识库草稿或文档缺口。
  partial_readiness_allowed: true
  degradation_behavior: 没有正式分类时，先做 taxonomy draft 和 duplicate grouping，再输出 readiness=partial FAQ。
composition_role: question_taxonomy_curator
function_bias: deduplicate_repeated_questions_into_reusable_answers
best_combines_with:
  - weekly-report-generation
  - best-practice-summary
  - meeting-minutes-to-action-items
join_keys:
  - artifact_family_id
  - artifact_id
  - cross_artifact_refs
  - topic_scope
  - source_time_window
  - evidence_refs
  - upstream_id_aliases
```

## Output contract
Follow `references/output-contract.yaml`. Every output must include:
- a `metadata` block using `n340-collaboration-v1.1.1`
- stable required sections for the selected mode
- compact `evidence_refs` rather than long pasted source material
- `downstream_handoff` with readiness, confidence, consumer, and next best checks

## Execution workflow
1. Read the shared contract and this skill's output contract.
2. Determine selected mode, audience, topic scope, and source time window.
3. Normalize source material into evidence refs with confidence and layer.
4. Produce the skill-specific artifact using the required sections.
5. Mark missing fields in `pending_clarifications` or `open_blockers` rather than inventing facts.
6. Add cross-artifact refs only when a sibling artifact is present or explicitly stubbed.
7. Complete downstream handoff for sibling skills or downstream nodes.
8. Run the quality checklist before finalizing.

## Design rules
- Keep the artifact useful when this skill is used alone.
- Make the artifact stronger when sibling artifacts exist by citing them through stable IDs.
- Use role/team owner placeholders instead of personal blame.
- Do not overstate readiness, maturity, or source certainty.
- Keep content reusable and searchable; avoid one-off local shorthand unless documented as an alias.

## Composition contract
Best combined with:
- `weekly-report-generation`
- `best-practice-summary`
- `meeting-minutes-to-action-items`

When combined, this skill must consume sibling artifacts by `artifact_id` and `evidence_refs` rather than copying their whole content.

## References
- `references/n340-shared-collaboration-contract.md`
- `references/output-contract.yaml`
- `references/blameless-collaboration-rules.md`
- `references/n340-cross-skill-handoffs.md`
- `references/faq-generation-quality-checklist.md`
- `references/faq-taxonomy.md`
- `references/faq-quality-rubric.md`

## Example
See `examples/onboarding-faq-from-docs.md` for a complete v1.1.1-style artifact.
