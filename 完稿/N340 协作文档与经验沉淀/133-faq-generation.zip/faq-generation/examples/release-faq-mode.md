# Example: FAQ Generation — Release FAQ Mode

Demonstrates `release_faq` mode: FAQ entries specifically for a release cycle, covering common questions from QA, support, and external users.

```yaml
metadata:
  contract_version: n340-collaboration-v1.1.2
  skill_id: "133"
  selected_mode: release_faq
  artifact_id: FAQ-V24-RELEASE-2025-0612
  topic_scope: Platform v2.4 release
  target_audience: [qa-team, support-team, external-users]
  readiness: complete
```

## FAQ 条目

### 类别: 功能变更

#### FAQ-REL-001: v2.4 购物车数量上限有何变化？
- **question**: "v2.4 购物车商品数量上限是 512 还是可以更多？"
- **answer**: "v2.4 购物车上限保持 512 件。超过时 API 返回 HTTP 200 并携带 `{limited: true, current_count: 512}`，不再返回 500 错误（这是 v2.3.1 的 bug fix）。"
- **category**: feature-change
- **staleness_risk**: low（功能已确定，不依赖外部变更）
- **review_by**: 2025-09-01
- **source_refs**: ["artifact_id:API-PAY-AUDIT-V24", "postmortem:PM-INC-2025-0612"]
- **pattern_candidate**: false

#### FAQ-REL-002: OAuth 登录在 v2.4 支持哪些提供商？
- **question**: "v2.4 支持 Apple 登录吗？"
- **answer**: "v2.4 仅支持 Google OAuth 登录。Apple 登录推迟至 v2.4.1 patch 发布。如需 Apple 登录，请关注 v2.4.1 发布计划。"
- **category**: feature-scope
- **staleness_risk**: high（v2.4.1 发布后需更新）
- **review_by**: 2025-07-15（v2.4.1 预计发布日）
- **source_refs**: ["artifact_id:PE-ALIGN-PRERELEASE-V24"]
- **pattern_candidate**: false

### 类别: API 变更

#### FAQ-REL-003: 旧版 legacy_id 字段还能用吗？
- **question**: "我们代码里用了 checkout 接口返回的 legacy_id，v2.4 还有吗？"
- **answer**: "不。v2.4 正式移除 `legacy_id` 字段。请改用从 v2.1 起同时返回的 `order_ref` 字段，两者语义等价。迁移步骤：将 `.legacy_id` 替换为 `.order_ref`，无其他变更。"
- **category**: api-breaking-change
- **staleness_risk**: low（已移除，不会再变）
- **review_by**: 2026-01-01
- **source_refs**: ["artifact_id:API-PAY-AUDIT-V24#API-PAY-002"]
- **alias_for**: null

#### FAQ-REL-004: 如何完成 OAuth 认证迁移？
- **question**: "v2.4 的认证方式变了，我需要怎么更新我的客户端代码？"
- **answer**: "1. 向 auth-service 申请 client_id 和 client_secret（联系 platform-team）。2. POST /v2/auth/token 获取 access_token。3. 所有 API 请求 Header 改为 `Authorization: Bearer {access_token}`。旧 Bearer token 格式在 v2.4 起不再接受（返回 401）。"
- **category**: api-migration
- **staleness_risk**: medium（OAuth 细节可能随 auth-service 版本变化）
- **review_by**: 2025-10-01
- **source_refs**: ["artifact_id:API-PAY-AUDIT-V24#API-PAY-003"]
- **pattern_candidate**: false

---

## Taxonomy Index

| category | count |
|---------|-------|
| feature-change | 1 |
| feature-scope | 1 |
| api-breaking-change | 1 |
| api-migration | 1 |

## Duplicate Group Log

- 无语义重复问题（4条问题领域各不同）

## Staleness Summary

| faq_id | staleness_risk | review_by |
|--------|---------------|-----------|
| FAQ-REL-002 | **high** | 2025-07-15（v2.4.1 发布后须更新）|
| FAQ-REL-004 | medium | 2025-10-01 |

## Pattern Candidates

无（本轮 release FAQ 条目均为一次性发版说明，不具备跨版本可复用性）

## Downstream Handoff

```yaml
handoff_id: FAQ-V24-RELEASE-HANDOFF
producer_skill: faq-generation
consumer_skill_or_node: best-practice-summary|weekly-report-generation
staleness_alerts:
  - faq_id: FAQ-REL-002
    staleness_risk: high
    review_by: "2025-07-15"
    action: "Update after v2.4.1 release"
pattern_candidates: []
readiness: complete
confidence: high
next_best_checks:
  - "Update FAQ-REL-002 after v2.4.1 Apple login release"
  - "Share FAQ-REL-003/004 with customer-facing support team before v2.4 go-live"
  - "Add to developer portal knowledge base"
```
