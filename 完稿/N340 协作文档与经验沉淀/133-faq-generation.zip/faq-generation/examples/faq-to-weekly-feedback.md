# Example: FAQ → Weekly Report Feedback Loop

Demonstrates #133 → #132 reverse composition: FAQ mature entries feeding back into weekly report as process improvements.

**Context**: FAQ-P-043 (Redis warm-up) reaches `maturity: validated` after second incident. This becomes a weekly highlight.

---

## #133 Output: FAQ-P-043 status update

```yaml
faq_id: FAQ-P-043
question: "Redis cache warm-up 是什么？为什么之前没有？"
answer: "Cache warm-up 指 deploy 前预热热点缓存 key，避免冷启动穿透数据库。之前未加入因 deploy pipeline 无缓存状态 gate。INC-2025-0612 后列为改进项 AI-001-001，现已并入 CD pipeline。"
category: ops-incident-learning
staleness_risk: low  # now stable — the fix is deployed
review_by: "2025-12-01"
source_refs: ["PM-INC-2025-0612-001", "PM-INC-2024-031", "AI-001-001"]
related_faq_ids: []
pattern_candidate: true  # triggered by second incident confirmation
```

Downstream handoff from #133:
```yaml
downstream_handoff:
  consumer_skill_or_node: best-practice-summary
  pattern_candidates:
    - faq_id: FAQ-P-043
      pattern_note: "Two incidents confirm this pattern — ready for maturity=validated upgrade"
      cross_incident_refs: [INC-2024-031, INC-2025-0612]
```

---

## #134 Output: BP-CACHE-001 upgraded

Receives FAQ-P-043 as second evidence case.

```yaml
pattern_id: BP-CACHE-001
maturity: validated  # upgraded from proposed (one incident) to validated (two incidents)
evidence_refs: [INC-2024-031, INC-2025-0612, FAQ-P-043]
adoption_status: in_progress  # AI-001-001 merged into CD pipeline
```

---

## #132 Feedback: Week 26 TL Weekly — Process Improvement Highlight

```markdown
## 技术决策与架构进展

| 决策/进展 | 结论/状态 | 影响模块 | 证据引用 |
|---------|---------|---------|---------|
| Redis warm-up gate 集成完成 | BP-CACHE-001 升至 validated，CD pipeline 已更新 | all-services-with-redis | artifact_id:BP-CACHE-001 |
```

**Note**: #132 references BP-CACHE-001 by `artifact_id` only — does not repeat the full pattern content. This is the correct consumption pattern.

---

## Composition chain demonstrated

```
INC-2025-0612 postmortem (N320 #124)
    ↓ action items: AI-001-001
N340 #131 (meeting-minutes → action items)
    ↓ ACTION-N340-W24 with AI-001-001
N340 #132 (weekly report)
    ↓ repeated_questions_observed: "warm-up 是什么？"
N340 #133 (FAQ generation)
    FAQ-P-043 created, staleness_risk: medium
    ↓ second incident confirms → pattern_candidate: true
N340 #134 (best-practice-summary)
    BP-CACHE-001 maturity upgraded to validated
    ↓ pattern reference
N340 #132 (weekly report, next sprint)
    "Redis warm-up gate 集成完成" as process improvement highlight
    ↓ referenced by artifact_id:BP-CACHE-001
```

This demonstrates the full N340 knowledge cycle: incident → action → FAQ → pattern → weekly improvement.

## Downstream Handoff

```yaml
handoff_id: FAQ-WEEKLY-HANDOFF-2025-W23
producer_skill: faq-generation
consumer_skill_or_node: best-practice-summary
pattern_candidates:
  - faq_id: FAQ-OPS-003
    pattern_note: "Third incident confirms Redis warm-up is a cross-service pattern"
    cross_incident_refs: [INC-2024-031, INC-2025-0612, INC-2025-0203]
staleness_alerts:
  - faq_id: FAQ-OPS-002
    staleness_risk: high
    review_by: "2025-08-01"
readiness: complete
confidence: high
next_best_checks:
  - "#134: FAQ-OPS-003 has 3 cross-incident refs — ready for maturity:validated promotion"
  - "Update FAQ-OPS-002 after Redis v8 upgrade"
```
