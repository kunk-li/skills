# FAQ 示例

```yaml
metadata:
  contract_version: n340-collaboration-v1.1.2
  workflow_node: N340
  skill_id: 133
  skill_name: faq-generation
  artifact_family_id: n340-collaboration-suite
  artifact_id: FAQ-platform-docs-01
  selected_mode: onboarding_faq
  readiness: ready
  source_time_window:
    start: 2026-05-01T00:00:00+09:00
    end: 2026-05-07T23:59:59+09:00
    timezone: Asia/Tokyo
  audience_scope: [engineering, product, operations]
  topic_scope: [platform-doc-family]
  source_artifacts: [sample-input]
  upstream_id_aliases: []
  evidence_refs: [EV-N340-SAMPLE-01]
  cross_artifact_refs: [WR-platform-202619]
  pending_clarifications: []
  open_blockers: []
  owner_placeholders: [platform-team, product-team]
  confidentiality_level: public_internal
  confidence: high
  composition_role: question_taxonomy_curator
  function_bias: deduplicate_repeated_questions_into_reusable_answers
  stage_position: collaboration_knowledge.question_answer_curation
  node_artifact_target: faq.md | faq.csv
  freshness:
    as_of_date: 2026-05-07
    source_commit: null
    expected_review_window: weekly
```

## taxonomy_summary
- development: 文档族如何组织。
- process_and_governance: ID 与 cross link 如何维护。

## deduplication_notes
重复问题“先写哪个文档”和“服务卡片是谁维护”合并到同一组 `DUP-platform-doc-order`。

## faq_entries
| faq_id | faq_category | question | answer | example_or_link | source_refs | duplicate_group |
|---|---|---|---|---|---|---|
| FAQ-platform-docs-01-001 | development | N340 文档族应该先写哪份？ | 先写 127 模块设计，因为它拥有服务卡片和模块边界。 | related artifact: DOC-127-platform-01 | EV-N340-SAMPLE-01 | DUP-platform-doc-order |
| FAQ-platform-docs-01-002 | process_and_governance | 临时 ID 怎么处理？ | 使用 `TEMP-N340-*`，并把正式回填任务写入 pending_clarifications 或 pending_id_backfill。 | see shared contract artifact id rules | EV-N340-SAMPLE-01 | DUP-id-backfill |

## source_gaps_and_maintenance_notes
- FAQ 应在每次文档族更新后复查。

```yaml
downstream_handoff:
  contract_version: n340-collaboration-v1.1.2
  handoff_id: HO-N340-FAQ-platform-docs-01-001
  producer_skill: faq-generation
  consumer_skill_or_node: best-practice-summary
  artifact_family_id: n340-collaboration-suite
  artifact_id: FAQ-platform-docs-01
  required_fields: [artifact_id, topic_scope, evidence_refs]
  cross_artifact_refs: [WR-platform-202619]
  pending_clarifications: []
  readiness: ready
  confidence: high
  next_best_checks: [review with owning team before publishing]
```
