#!/usr/bin/env python3
"""validate_md.py for skill #133 faq-generation (n340-collaboration-v1.1.2)"""
import re, sys
from pathlib import Path

SCHEMA = "n340-collaboration-v1.1.2 / #133 faq-generation"
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}

REQUIRED_HEADINGS = [
    ("metadata",    re.compile(r"##\s*\d*\.?\s*Metadata|^```yaml[\s\S]*?\bmetadata:\b", re.I | re.MULTILINE)),
    ("taxonomy",    re.compile(r"##\s*\d*\.?\s*(FAQ [Tt]axonomy|分类索引)", re.I)),
    ("faq_entries", re.compile(r"##\s*\d*\.?\s*(FAQ [Ee]ntries?|FAQ 条目)", re.I)),
    ("dedup_log",   re.compile(r"##\s*\d*\.?\s*(Deduplication|去重)", re.I)),
    ("patterns",    re.compile(r"##\s*\d*\.?\s*(Pattern [Cc]andidates?|经验候选)", re.I)),
    ("downstream",  re.compile(r"##\s*\d*\.?\s*(Downstream [Hh]andoff|下游交接)", re.I)),
]

NEVER_EMPTY_SECTIONS = [
    ("faq_entries", re.compile(r"##\s*\d*\.?\s*(FAQ [Ee]ntries?|FAQ 条目)", re.I)),
    ("dedup_log",   re.compile(r"##\s*\d*\.?\s*(Deduplication|去重)", re.I)),
]


def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0


def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_md.py <output.md> [--strict]"); return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists(): return fail(f"file not found: {path}")
    text = path.read_text(encoding="utf-8")
    errors = 0; warnings = 0

    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    if _is_example and _has_any_heading:
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness '{_rm.group(1)}' not in {VALID_READINESS}"); return 1
        return ok(f"{SCHEMA} example validation passed (light-check mode)")

    found = {}
    for key, pat in REQUIRED_HEADINGS:
        m = pat.search(text)
        if m: found[key] = m.start()
        else: print(f"[FAIL] missing section: {key}"); errors += 1

    # NEVER_EMPTY checks
    for key, pat in NEVER_EMPTY_SECTIONS:
        m = pat.search(text)
        if m:
            rest = text[m.end():]
            next_h = re.search(r'\n## ', rest)
            section_body = rest[:next_h.start()].strip() if next_h else rest.strip()
            lines = [l for l in section_body.split('\n') if l.strip() and not l.startswith('##')]
            content = '\n'.join(lines).strip()
            if len(content) < 20:
                print(f"[FAIL] section '{key}' is never-empty but appears empty (< 20 chars)")
                errors += 1

    # staleness_risk=high must have review_by
    for i, line in enumerate(text.split('\n')):
        if 'staleness_risk' in line and 'high' in line:
            context = '\n'.join(text.split('\n')[max(0,i-3):i+8])
            if 'review_by' not in context:
                msg = f"staleness_risk=high entry missing review_by near line {i+1}"
                if strict: print(f"[FAIL] {msg}"); errors += 1
                else: warn(msg); warnings += 1

    rm = re.search(r"readiness:\s*([\w]+)", text)
    if rm and rm.group(1) not in VALID_READINESS:
        print(f"[FAIL] readiness '{rm.group(1)}' not in {VALID_READINESS}"); errors += 1

    if errors > 0: return fail(f"{SCHEMA} FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} passed — {warnings} warning(s)")


if __name__ == "__main__":
    raise SystemExit(main())
