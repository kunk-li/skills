---
name: faq-generation
description: 生成 FAQ（可维护的常见问题库）用于 n340 协作文档节点。triggered when the assistant must turn questions that have appeared repeatedly (across multiple meetings, onboarding sessions, support tickets, or release cycles) into a structured taxonomy with concise answers, semantic deduplication, staleness tracking, and handoffs to best-practice workflows. a question must have occurred more than once to qualify — single-occurrence questions should be answered directly, not turned into a FAQ entry. use release_faq mode during release cycles. do not use for single-question immediate answers, technical design documents (→ n330), task tracking (→ n350 #135), or extracting reusable cross-project patterns (→ n340 #134).
---

# FAQ 生成

## N340 contract baseline (n340-collaboration-v1.1.2)

- contract_version: `n340-collaboration-v1.1.2`
- workflow node: N340
- skill_id: 133
- artifact_family_id: `n340-collaboration-suite`
- primary artifact: `FAQ.md`
- upstream: #132 (repeated_questions_observed), #131 (recurring meeting questions)
- downstream nodes: N340 #134 (pattern_candidates handoff)
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through `artifact_id`, `faq_item_id`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Before producing the final artifact, consult `references/n340-shared-collaboration-contract.md` and `references/output-contract.yaml`. Use `references/blameless-collaboration-rules.md` whenever people, teams, decisions, incidents, or blockers are described.

## Role

把重复问答、散碎答疑和文档盲区收敛为**可搜索、可维护的 FAQ**。

具体职责：
- 接收 #132 传递的 `repeated_questions_observed` 并转化为结构化 FAQ 条目
- 维护 `staleness_risk`（low/medium/high/unknown）；高风险条目必须有 `review_by` 日期
- 去重：语义相似问题合并，保留最佳答案；记录合并历史
- 每条 FAQ 条目字数自检：超过 500 字时在 open_blockers 中标注"建议转为专项文档"
- 识别 `pattern_candidates`，传递给 #134 进行经验提炼
- 区分"反复出现的会议问题"（本 skill 处理）与"单次 follow-up"（→ #131）

**不负责**：单次问答的即时回复（直接答复即可）、技术文档撰写（→ N330）、任务追踪（→ N350）。

## When NOT to use this skill

- **Not a documentation generator**: do not use #133 to produce design documents, API references, or runbooks — use N330 skills instead.
- **Not a postmortem**: do not use #133 for incident analysis — use N320 #124; FAQ entries may reference postmortem artifact_ids.
- **Not a training manual**: FAQ entries should be concise Q&A pairs, not tutorial-length explanations. If an answer needs >500 words, it belongs in a dedicated document.
- **Not a decision record**: decisions made in meetings belong in #131 action items; only recurring confusing decisions warrant a standing FAQ entry.
- **Not for single-occurrence questions**: if a question has only appeared once, do not create a FAQ entry — handle it as a direct answer.

## Standalone and composition role

```yaml
standalone_goal: turn repeated questions into a searchable, maintainable FAQ with deduplication and staleness tracking
minimum_viable_input:
  any_of:
    - 重复出现的问题集合或答疑片段
    - #132 传递的 repeated_questions_observed
    - 知识库草稿或文档缺口
    - onboarding notes 或 support tickets
    - 发版说明或 FAQ 草稿
partial_readiness_allowed: true
degradation_behavior: >
  If inputs are sparse, output a taxonomy draft with grouped question clusters.
  Mark readiness=partial. All entries can have placeholder answers
  with "待确认" — do not invent answers without source evidence.
  staleness_risk for all partial entries defaults to "unknown".
composition_role: question_taxonomy_curator
function_bias: deduplicate_repeated_questions_into_reusable_answers
best_combines_with:
  - weekly-report-generation
  - best-practice-summary
  - meeting-minutes-to-action-items
join_keys:
  - artifact_family_id
  - artifact_id
  - cross_artifact_refs
  - topic_scope
  - source_time_window
  - evidence_refs
  - upstream_id_aliases
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `onboarding_faq`: 面向新成员，覆盖环境搭建、流程、工具和高频问题。
- `technical_support_faq`: 面向技术支持，覆盖排障步骤、已知缺陷和临时方案。
- `operations_faq`: 面向运维值班，覆盖告警处理、常见操作和升级路径，与 N330 #130 互补。
- `taxonomy_fallback`: 没有明确分类时，先做 taxonomy draft 再出条目。
- **`release_faq`**: 发版周期专用，覆盖 breaking changes、迁移步骤、功能变更说明，面向 QA/support/外部用户。staleness_risk 默认 high（发版后必须复核）。

**Default routing**: new member onboarding → `onboarding_faq`. Release cycle → `release_faq`. Ops on-call → `operations_faq`. Unknown audience → `taxonomy_fallback`.

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | Metadata | Always | artifact_id, selected_mode, source_time_window, readiness |
| 2 | FAQ taxonomy (分类索引) | Always | Top-level categories with entry counts |
| 3 | FAQ entries | Always | Each entry: faq_item_id + Q + A + staleness_risk + review_by (if high) |
| 4 | Deduplication log | Always | Which questions were merged and why |
| 5 | Pattern candidates | Always | Questions suitable for promotion to #134; empty list if none |
| 6 | Downstream handoff | Always | Pass pattern_candidates to #134 |

> Legend: Always = required in every mode.

**Length self-check rule**: if any FAQ entry exceeds 500 words, add an open_blocker: "Entry [faq_item_id] exceeds 500 words — consider converting to a dedicated document in N330."

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: best-practice-summary
  pattern_candidates: ["FQ-003: 每次 hotfix 后需要单独冒烟测试", "FQ-007: ORM 更新需要先清 L2 缓存"]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (taxonomy and entries complete) / `partial` (some entries have placeholder answers) / `degraded` (skeleton taxonomy only — no validated answers yet).

## Workflow position

```
Repeated questions from docs / onboarding / support / release work
  ↑ #132 repeated_questions_observed / #131 recurring meeting questions
  ↓ #133 (FAQ taxonomy + entries → FAQ.md)
  ↓ #134 (pattern_candidates → 最佳实践库.md)
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** 为只出现一次的问题创建 FAQ 条目 → FAQ 只处理重复出现的问题；单次问题直接回答。量化检验：FAQ 条目来源字段中，occurrence_count < 2 的条目数 = open_blocker 数。
- **AP-2** `staleness_risk: high` 条目缺少 `review_by` 日期 → 高风险条目必须有复核日期；`release_faq` 模式下所有条目默认 high。量化检验：staleness_risk=high 条目数必须 = review_by 字段非空的条目数；不等时 FAIL。
- **AP-3** 单条 FAQ 超过 500 字未触发 open_blocker → 必须在 open_blockers 中标注建议转专项文档。量化检验：字数 > 500 的 FAQ 条目数必须 ≤ open_blockers 中「建议转专项文档」标注的条目数。
- **AP-4** 去重时静默删除问题而不记录合并历史 → Section 4 (deduplication log) 必须记录每次合并的原始问题和合并理由。量化检验：发生合并时，dedup_log 中的合并记录数必须 = 实际合并操作数；Section 4 字符数 < 10 且声称有合并时 FAIL。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n340-shared-collaboration-contract.md` — shared contract and handoff schema
- `references/n340-composition-guide.md` — composition guide
- `references/n340-cross-skill-handoffs.md` — cross-skill handoff mapping (including #132 → #133 repeated_questions_observed)
- `references/n340-input-validation-rules.md` — when input quality is uncertain
- `references/faq-staleness-rules.md` — when setting staleness_risk and review_by
- `references/faq-taxonomy.md` — when building or refining the taxonomy
- `references/faq-quality-rubric.md` — when evaluating FAQ entry quality
- `references/blameless-collaboration-rules.md` — when describing people, teams, incidents
- `references/faq-generation-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/onboarding-faq-from-docs.md` — onboarding_faq with taxonomy and deduplication log
- `examples/release-faq-mode.md` — release_faq with breaking changes and high staleness_risk
- `examples/faq-to-weekly-feedback.md` — #133 → #132 feedback loop via repeated_questions_observed
