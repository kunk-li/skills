# FAQ Quality Rubric

A good FAQ entry must include:
- `question`: phrased the way a user might ask it.
- `answer`: concise, source-backed, and directly useful.
- `example_or_link`: example, verification step, or related artifact link.
- `faq_category`: from the official taxonomy.
- `source_refs`: evidence refs or source artifact IDs.
- `duplicate_group`: group semantically equivalent questions before final output.
