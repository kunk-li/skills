# FAQ Taxonomy

Use these categories by default:
1. onboarding
2. development
3. api_and_integration
4. operations_and_deployment
5. incident_and_troubleshooting
6. process_and_governance
7. security_and_compliance
8. release_and_change_management
9. data_and_dictionary
10. business_and_product_usage

Use `taxonomy_fallback` only when a question truly does not fit an existing category.
