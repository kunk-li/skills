# FAQ Staleness Rules

Use this reference when assigning `staleness_risk` and `review_by` to FAQ entries.

## staleness_risk rating criteria

| Rating | Criteria | Examples |
|--------|----------|---------|
| `high` | Answer contains version numbers, specific API endpoints, prices, deadlines, or references to systems that change frequently | "Which version of X is supported?", "What is the API endpoint for Y?", "How much does Z cost?" |
| `medium` | Answer references processes, team structures, or tools that are relatively stable but do change over time | "How do I request access to system X?", "Who is responsible for Y?" |
| `low` | Answer reflects fundamental principles, design decisions, or stable technical concepts | "Why was approach X chosen?", "What does architecture Y mean?" |

## review_by rules
- `staleness_risk: high` → `review_by` is **required**, set to `entry_date + 3 months` by default, or sooner if the referenced version/deadline is known
- `staleness_risk: medium` → `review_by` is recommended, set to `entry_date + 6 months`
- `staleness_risk: low` → `review_by` is optional, set to `entry_date + 12 months` if assigned

## Semantic deduplication procedure

1. **Grouping step**: Before finalizing, scan all questions for semantic similarity (same intent, different phrasing).
2. **Canonical selection**: Choose the phrasing closest to how users actually ask it. More specific > more vague.
3. **Alias assignment**: All non-canonical phrasings become entries with `alias_for: FAQ-NNN` format.
4. **Forbidden**: Two entries with the same `answer` content — always merge.

```yaml
# Canonical entry
faq_id: FAQ-001
question: "如何重置密码？"
answer: "访问登录页，点击「忘记密码」，输入注册邮箱，查收重置邮件。"
staleness_risk: medium
review_by: "2025-12-01"

# Alias entry  
faq_id: FAQ-015
alias_for: FAQ-001
question: "忘记密码怎么办？"
# alias entries do not have answer field — they redirect only
```

## High-risk content triggers (auto-escalate to staleness_risk: high)
- Any mention of a software version number
- Any reference to a specific date or deadline
- Any mention of pricing or commercial terms
- Any endpoint URL (may change across environments or versions)
- Any reference to a named person (they may change roles)
- Any SLA or performance target number

## Maintenance workflow
When `review_by` date passes:
1. Re-verify the answer is still accurate
2. Update `last_verified` field
3. If answer changed substantially, increment the entry and document the change
4. If answer is no longer relevant, mark `status: deprecated` and point to replacement
