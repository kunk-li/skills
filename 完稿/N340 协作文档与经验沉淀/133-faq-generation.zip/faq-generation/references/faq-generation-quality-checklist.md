# FAQ Generation Quality Checklist

Before finalizing this artifact, verify:

1. Metadata is present and uses the current contract version.
2. selected_mode matches the structure and reader/audience of the output.
3. artifact_id follows the skill-specific format or temporary fallback and aliases are recorded.
4. evidence_refs distinguish confirmed_fact, bounded_inference, and open_question.
5. cross_artifact_refs cite sibling artifacts by artifact_id, not file path.
6. open_blockers and pending_clarifications are explicit when evidence is missing.
7. owner_placeholders use role/team language rather than personal blame.
8. downstream_handoff contains handoff_id, producer, consumer, readiness, confidence, and next_best_checks.
9. freshness.as_of_date is filled or explicitly unknown.
10. The artifact remains useful standalone and improves when sibling artifacts are present.
11. Compare metadata key order, field naming, and section structure with the most relevant file under examples/. Differences are allowed but should be intentional.

Skill-specific checks:
- Every FAQ entry has question, answer, and example_or_link.
- Deduplicate semantically equivalent questions before writing entries.
- Use the official taxonomy unless a fallback category is explicitly justified.
- Keep answers concise and source-backed rather than tutorial-length.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections are present even with placeholder content; no section is silently skipped.
- Missing evidence is recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined from available input use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- When source material is limited, output `readiness: partial` FAQ with `taxonomy_fallback` mode and explicit duplicate grouping.
- `staleness_risk` and `review_by` are assigned to every entry, even if `staleness_risk: unknown` (which triggers open_blocker).
- `alias_for` entries are created for every semantically duplicate question found.

## Output structure completeness checks
- All 7 mandatory sections present.
- Section 5 (Staleness summary) lists all `staleness_risk: high` entries with their `review_by` dates.
- Section 4 (Duplicate group log) present with "无重复问题" if none.
- `staleness_risk` assigned to every entry — `unknown` triggers open_blocker.
- `review_by` present for all `staleness_risk: high` entries.

## Mode-specific degradation checks

### release_faq mode
- Every breaking-change FAQ entry has a `source_refs` pointing to the specific API change (never invented)
- `staleness_risk: high` assigned to all entries that describe v-specific behavior (default for release_faq)
- `review_by` date set for all `staleness_risk: high` entries (typically the next major version release date)
- Migration path entries (e.g., "how to migrate from X to Y") are validated against the actual breaking change artifact_id

### ops_faq mode
- Every alert-handling entry references the specific alert name (matches `references/false-positive-suppression-rules.md` if available)
- `staleness_risk` assigned based on how frequently the underlying system/alert changes
- Entries without runbook links note `related_runbook: 待补充` rather than leaving blank

### onboarding_faq mode
- Environment setup entries verified against current tech stack (not assumed)
- Tool links are explicit URLs or artifact_ids, never "see documentation"
