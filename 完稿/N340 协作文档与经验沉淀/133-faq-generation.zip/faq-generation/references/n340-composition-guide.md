# N340 Document Family Composition Guide

Use this reference when producing N340 collaboration artifacts or linking within the N340 chain.

## N340 chain composition order

```
Meeting / discussion input
  ↓ #131 (extract structured commitments)
ACTION-N340-* artifacts
  ↓ referenced by artifact_id (never copied)
  ↓ #132 (synthesize weekly report per reader mode)
WEEKLY-N340-* artifacts
  ├─ repeated_questions_observed → #133
  └─ pattern promotion signals → #134 (via #133)
  ↓ #133 (FAQ from repeated questions)
FAQ-N340-* artifacts
  ↓ pattern_candidates → #134
  ↓ #134 (best practices from validated patterns)
BP-N340-* artifacts → governance_kb
```

## Cross-linking field conventions

| Field | Format | Purpose |
|-------|--------|---------|
| `artifact_id` | `ACTION-N340-{sprint_id}` | Stable reference for #132 |
| `cross_artifact_refs` | list of artifact_ids | References to upstream artifacts |
| `repeated_questions_observed` | string list | #132 → #133 handoff |
| `pattern_candidates` | list with faq_id + evidence | #133 → #134 handoff |
| `pattern_ids_promoted` | list of BP-* IDs | #134 → governance_kb handoff |

## Cite-by-reference rule

**Never copy** action items from #131 into #132. Always reference by `artifact_id`:
- ✓ `see ACTION-N340-S24-PLANNING#AI-S24-001`
- ✗ Copying the full action item text into the weekly report body

## Minimum viable handoff per skill

| Skill | Must include in downstream_handoff |
|-------|----------------------------------|
| #131 | `external_commitments`, `pending_decisions`, `new_items` |
| #132 | `repeated_questions_observed` (even if empty list) |
| #133 | `pattern_candidates` (even if empty list), `staleness_alerts` |
| #134 | `pattern_ids_promoted` (patterns that changed maturity this cycle) |

## when to produce the full chain vs individual

| Scenario | Approach |
|---------|---------|
| Sprint planning meeting | #131 first → #132 for weekly → #133 for FAQ if repeated questions |
| Incident review | #131 to extract action items → N320 #124 also gets action items |
| Weekly standing | #132 standalone using inputs from Slack/task system |
| Post-incident FAQ spike | #133 standalone to capture sudden FAQ volume |
