# N340 Cross-Skill Handoffs v1.2

All N340 skills exchange artifacts through `metadata`, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff`.

## Primary handoff routes

| From | To | What is passed | How to reference |
|------|----|---------------|-----------------|
| #131 action items | #132 weekly report | Action status, open external commitments, blockers | `artifact_id: ACTION-N340-*` in cross_artifact_refs |
| #132 weekly report | #133 FAQ | Repeated questions observed in the week | `repeated_questions_observed` field in downstream_handoff |
| #133 FAQ | #134 best practice | Stable repeated questions become pattern candidates | `pattern_candidates` field in downstream_handoff |
| #134 best practice | #132 weekly report | Mature patterns highlighted as process improvements | `pattern_ids` in cross_artifact_refs |
| #131 action items | N350 #135 | Action items that need task tracking | `action_id` cross-referenced as `parent_ref` in task CSV |
| N320 postmortem | #131 | Action items from incident review | `evidence_ref: postmortem:<id>#<action_item_id>` |

## Composition protocol

### When consuming a sibling artifact
1. Reference by `artifact_id` in `cross_artifact_refs` — do NOT copy the full artifact content
2. Cite only the relevant section or action_id, not the full list
3. Keep the source confidence visible (e.g., `confidence: medium` from #131 stays medium in #132)

### When producing for downstream
Every artifact must emit `downstream_handoff` with:
- `consumer_skill_or_node`: who consumes this next
- `cross_artifact_refs`: which upstream artifacts were consumed
- `readiness`: complete | partial | draft
- `confidence`: high | medium | low

### Composition example
```yaml
# In #132 WEEKLY artifact downstream_handoff:
downstream_handoff:
  handoff_id: WEEKLY-HANDOFF-2025-W24
  consumer_skill_or_node: faq-generation
  cross_artifact_refs:
    - artifact_id: ACTION-N340-2025-W24
      consumed_fields: [action_items, external_commitments]
      producer_skill: meeting-minutes-to-action-items
  repeated_questions_observed:
    - "Redis warm-up 是什么，为什么以前没有？"
    - "购物车上限为什么是 512 条？"
  readiness: complete
  confidence: high
```

## Join keys (all N340 skills)
- `artifact_family_id: n340-collaboration-suite`
- `artifact_id` (format: `{TYPE}-N340-{YYYY}-{SCOPE}`)
- `topic_scope`
- `source_time_window`
- `evidence_refs`
- `cross_artifact_refs`

## Anti-patterns (do not do these)
- **Full copy**: copying an entire action item list from #131 into #132 body — cite by artifact_id instead
- **Silent consumption**: consuming a sibling artifact without listing it in cross_artifact_refs
- **Confidence escalation**: a `confidence: low` source cannot become `confidence: high` downstream without additional evidence
- **Skipping handoff**: producing an artifact without downstream_handoff when the next skill in the chain exists

## Full pipeline example
See `examples/n340-composition-flow.md` in skill #132 for a complete end-to-end example showing #131→#132→#133→#134 artifact chain.
