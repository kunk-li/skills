# N340 Input Validation Rules

Use this reference when input quality is uncertain or when handling partial collaboration artifacts.

## Minimum viable input per skill

| Skill | Minimum | Degradation behavior |
|-------|---------|---------------------|
| #131 meeting-minutes | Any meeting notes, transcript fragment, or chat export | `direct_notes_fallback`; items without owner get `待确认` |
| #132 weekly-report | Any status update, task list, or action item list | `neutral_summary_fallback`; sections with no data get placeholder |
| #133 faq-generation | Any Q&A fragments, repeated questions, or doc gaps | `taxonomy_fallback`; output `readiness: partial` FAQ draft |
| #134 best-practice | Any single case, postmortem, or FAQ theme | `evidence_limited_candidate`; `maturity: proposed` only |

## Input quality tiers

**tier-1 (structured)**: artifact_id-referenced sibling artifacts, formatted meeting transcripts  
**tier-2 (semi-structured)**: bullet notes, chat exports, email threads  
**tier-3 (unstructured)**: verbal descriptions, rough notes, single-sentence summaries  

Lower tiers → lower `confidence` in output → must be stated in downstream_handoff.

## Partial input handling

When critical information is missing:
1. State it in `pending_clarifications` at the artifact level
2. Use `待确认` for missing owner/deadline fields — never omit the field
3. Set `readiness: partial` in metadata
4. List minimum additional input needed in `downstream_handoff.next_best_checks`

## Evidence ref minimum standard

Every action item, FAQ entry, or pattern must have at least one of:
- `meeting:<meeting_id>#item:<n>` — traced to a meeting
- `doc:<doc_id>#section:<anchor>` — traced to a document
- `artifact_id:<id>` — traced to a sibling N340 artifact
- `待核对` — explicitly deferred (triggers open_blocker)

Never produce an entry with an empty `evidence_ref`.

## Anti-patterns for partial input

- **Do NOT**: produce a full weekly report section with invented status updates
- **Do NOT**: create FAQ entries from memory without a source_ref
- **Do NOT**: assign action_type: external_commitment without naming the commitment_to party
- **DO**: produce a partial artifact with explicit gaps rather than a complete-looking artifact with invented content
