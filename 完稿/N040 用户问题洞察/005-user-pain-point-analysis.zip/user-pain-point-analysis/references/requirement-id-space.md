# Requirement-definition id space

## Artifact id

Use `PAIN-ARTIFACT-<scope>-<yyyymm>` for sidecar `artifact_id`.

Example: `PAIN-ARTIFACT-checkout-202605`.

## Row or section id

Primary id field: `pain_id`.
Expected pattern: `^PAIN-[a-z0-9_]+-\d{3,}$`.
Example: `PAIN-checkout-001`.

## Multi-value cells

Use `|` as the delimiter in CSV multi-value cells. Do not use bare commas inside machine-readable id lists.
