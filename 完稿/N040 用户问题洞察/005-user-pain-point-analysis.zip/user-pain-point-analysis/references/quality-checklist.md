# Quality checklist

First apply the common checklist in `shared-requirement-definition-contract.md`.

## Skill-specific checks

- Pain statements are problems, not features.
- Role, task, friction, and consequence are visible.
- Evidence strength is labeled.

- Metadata `workflow_node` is a real host workflow identifier, not a placeholder.
- Anti-patterns AP-01 through AP-10 and the five skill-specific AP rows have been checked.
