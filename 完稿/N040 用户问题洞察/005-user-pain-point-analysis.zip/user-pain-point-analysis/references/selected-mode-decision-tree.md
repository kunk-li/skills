# Selected-mode decision tree

Choose exactly one selected_mode:

- `context_to_pain_cards`: use when context to pain cards is the closest operating mode.
- `feedback_to_pain_cards`: use when feedback to pain cards is the closest operating mode.
- `interview_pain_analysis`: use when interview pain analysis is the closest operating mode.
- `ticket_pain_analysis`: use when ticket pain analysis is the closest operating mode.
- `low_evidence_candidate_pains`: use when low evidence candidate pains is the closest operating mode.

Validation rule: metadata `selected_mode` must match one of the modes above and the schema enum.
