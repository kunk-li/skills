# Output template

Produce `user-pain-point-cards.md` as Markdown.

# User Pain Point Analysis Output

artifact id: <artifact_id>  
pain_id: <id>

## Pain Overview

- confirmed facts:
- reasonable assumptions:
- open questions:

## Pain Cards

- confirmed facts:
- reasonable assumptions:
- open questions:

## Impact And Consequence

- confirmed facts:
- reasonable assumptions:
- open questions:

## Possible Root Causes

- confirmed facts:
- reasonable assumptions:
- open questions:

## Evidence And Uncertainty

- confirmed facts:
- reasonable assumptions:
- open questions:

## Open Questions

- confirmed facts:
- reasonable assumptions:
- open questions:


Keep evidence labels visible. Do not write unsupported conclusions as facts.
