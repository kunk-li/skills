# Real Examples / 真实示例参考

These examples illustrate correctly formed pain cards and common edge cases. Use them as regression seeds alongside the bundled `examples/` files.

---

## Example 1: Feedback to pain cards — feature request reframed as pain

**Input**: A product manager writes "We should add a bulk download button to the invoice page."

**Correct pattern**:
```
pain_id: PAIN-invoice-001
affected_role: finance_admin
pain_statement: Finance admins cannot retrieve multiple invoices at once for offline archiving.
trigger: user selects multiple invoices and looks for a batch action
consequence: must download each invoice individually; takes 20+ minutes for monthly reconciliation batches
frequency_hint: high
severity_hint: high
evidence_status: reasonable_assumption
open_questions: Is the manual download step confirmed by a support ticket or NPS comment? Frequency estimate needs analytics validation.
confidence: medium
```

**Anti-pattern to avoid (AP-PAIN-01)**: Writing `pain_statement: The bulk download button is missing` — this records a solution absence, not a user pain.

---

## Example 2: Interview pain analysis — root cause labeled as hypothesis

**Input**: Interview note: "Every time I update the billing address, the invoice title disappears. I think it's a cache bug."

**Correct pattern**:
```
pain_id: PAIN-invoice-002
affected_role: buyer
pain_statement: Buyers lose their invoice title after editing the billing address, forcing them to re-enter it.
trigger: user edits billing address during checkout
consequence: invoice title field is cleared; user must retype company name before submitting
frequency_hint: high
severity_hint: high
evidence_status: confirmed
open_questions: none
confidence: high
notes: Interviewee suggested "cache bug" as root cause — labeled as hypothesis; do not assert technical cause without engineering review. (AP-PAIN-02)
```

---

## Example 3: Low-evidence candidate pains — sparse input

**Input**: An NPS comment says "the dashboard is confusing." No additional context.

**Correct pattern**:
```
pain_id: PAIN-dashboard-001
affected_role: general_user
pain_statement: Users find the dashboard layout confusing and cannot locate the features they need quickly.
trigger: user lands on dashboard after login
consequence: increased time-to-task; may abandon session or contact support
frequency_hint: unknown
severity_hint: medium
evidence_status: open_question
open_questions: Which dashboard elements are confusing? Which user segment submitted this comment? Is this a one-off or repeated theme?
confidence: low
```

**Anti-pattern to avoid (AP-04)**: Assigning `confidence: high` and `frequency_hint: high` based on a single vague NPS comment.
