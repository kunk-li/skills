#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
CONFIG={'display': 'User Pain Point Analysis', 'cn': '用户痛点分析', 'family_role': 'pain', 'artifact_type': 'markdown', 'primary_artifact': 'user-pain-point-cards.md', 'schema': 'user.pain-point.v4', 'id_field': 'pain_id', 'id_re': '^PAIN-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['pain overview', 'pain cards', 'impact and consequence', 'possible root causes', 'evidence and uncertainty', 'open questions'], 'modes': ['context_to_pain_cards', 'feedback_to_pain_cards', 'interview_pain_analysis', 'ticket_pain_analysis', 'low_evidence_candidate_pains'], 'description': 'turn requirement context, feedback, interviews, support tickets, or behavior descriptions into evidence-backed user pain statements, affected roles, impact scope, and uncertainty. use when demand needs to be reframed as user problems and consequences for journey mapping, value assessment, prioritization, or solution discussion. not for proposing features, assigning roadmap priority, or treating internal complaints as user pain without evidence.', 'route_tokens': ['journey_analysis', 'value_assessment', 'prioritization', 'human_review'], 'composable': ['requirement-context-enrichment', 'user-journey-analysis', 'requirement-deduplication-and-clustering'], 'not_for': ['solution design', 'feature list generation', 'priority ranking'], 'skill_id': 'user-pain-point-analysis', 'contract_version': 'requirement-definition-suite-v1.3.0'}

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    d=Path(ap.parse_args().skill_dir)
    errors=[]
    dt=d/'references/selected-mode-decision-tree.md'
    ms=d/'references/metadata-schema.json'
    sm=d/'SKILL.md'
    if not dt.exists(): errors.append('selected-mode-decision-tree.md missing')
    else:
        text=dt.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if f'`{m}`' not in text: errors.append(f'mode {m} missing from decision tree')
    if ms.exists():
        meta=json.loads(ms.read_text(encoding='utf-8'))
        enum=meta.get('properties',{}).get('selected_mode',{}).get('enum',[])
        if set(enum)!=set(CONFIG['modes']): errors.append('metadata selected_mode enum mismatch')
    else: errors.append('metadata-schema.json missing')
    if sm.exists():
        s=sm.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if m not in s: errors.append(f'mode {m} missing from SKILL.md')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: selected-mode decision tree aligned for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
