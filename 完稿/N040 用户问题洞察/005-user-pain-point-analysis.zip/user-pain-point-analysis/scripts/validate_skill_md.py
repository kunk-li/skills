#!/usr/bin/env python3
import re, sys
from pathlib import Path
CONFIG={'display': 'User Pain Point Analysis', 'cn': '用户痛点分析', 'family_role': 'pain', 'artifact_type': 'markdown', 'primary_artifact': 'user-pain-point-cards.md', 'schema': 'user.pain-point.v4', 'id_field': 'pain_id', 'id_re': '^PAIN-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['pain overview', 'pain cards', 'impact and consequence', 'possible root causes', 'evidence and uncertainty', 'open questions'], 'modes': ['context_to_pain_cards', 'feedback_to_pain_cards', 'interview_pain_analysis', 'ticket_pain_analysis', 'low_evidence_candidate_pains'], 'description': 'turn requirement context, feedback, interviews, support tickets, or behavior descriptions into evidence-backed user pain statements, affected roles, impact scope, and uncertainty. use when demand needs to be reframed as user problems and consequences for journey mapping, value assessment, prioritization, or solution discussion. not for proposing features, assigning roadmap priority, or treating internal complaints as user pain without evidence.', 'route_tokens': ['journey_analysis', 'value_assessment', 'prioritization', 'human_review'], 'composable': ['requirement-context-enrichment', 'user-journey-analysis', 'requirement-deduplication-and-clustering'], 'not_for': ['solution design', 'feature list generation', 'priority ranking'], 'skill_id': 'user-pain-point-analysis', 'contract_version': 'requirement-definition-suite-v1.3.0'}
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")
RETIRED_VERSION_TOKENS = (
    "requirement-definition-suite-v" + "1.1.0",
    "requirement-definition-suite-v" + "1.2.0",
    "requirement.collection.v" + "2", "requirement.collection.v" + "3",
    "requirement.deduplication.v" + "2", "requirement.deduplication.v" + "3",
    "requirement.context.v" + "2", "requirement.context.v" + "3",
    "user.pain-point.v" + "2", "user.pain-point.v" + "3",
    "user.journey.v" + "2", "user.journey.v" + "3",
)

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    args=ap.parse_args(); d=Path(args.skill_dir); p=d/'SKILL.md'
    errors=[]
    if not p.exists(): errors.append('SKILL.md missing')
    else:
        text=p.read_text(encoding='utf-8')
        if not text.startswith('---'): errors.append('missing YAML frontmatter')
        if f"name: {CONFIG['skill_id']}" not in text: errors.append('frontmatter name mismatch')
        if 'description:' not in text: errors.append('frontmatter description missing')
        if 'TODO' in text or '[TODO' in text: errors.append('TODO placeholder remains')
        if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in SKILL.md')
        for token in RETIRED_VERSION_TOKENS:
            if token in text:
                errors.append(f'retired contract or schema token remains in SKILL.md: {token}')
        forbidden=['depends' + '_on','blo' + 'cks']
        for word in forbidden:
            if re.search(rf"(^|[\s`'\"]){word}(\s*:|[`'\"])", text, re.I): errors.append(f'forbidden order field {word!r}')
        for req in ['references/shared-requirement-definition-contract.md','scripts/validate_artifact.py','scripts/validate_metadata.py']:
            if req not in text: errors.append(f'SKILL.md does not reference {req}')
    for rel in ['agents/openai.yaml','references/metadata-schema.json','references/anti-patterns.md','scripts/validate_release_consistency.py']:
        if not (d/rel).exists(): errors.append(f'missing {rel}')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: SKILL.md baseline for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
