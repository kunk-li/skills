#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
CONFIG = {'display': 'User Pain Point Analysis', 'cn': '用户痛点分析', 'family_role': 'pain', 'artifact_type': 'markdown', 'primary_artifact': 'user-pain-point-cards.md', 'schema': 'user.pain-point.v4', 'id_field': 'pain_id', 'id_re': '^PAIN-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['pain overview', 'pain cards', 'impact and consequence', 'possible root causes', 'evidence and uncertainty', 'open questions'], 'modes': ['context_to_pain_cards', 'feedback_to_pain_cards', 'interview_pain_analysis', 'ticket_pain_analysis', 'low_evidence_candidate_pains'], 'description': 'turn requirement context, feedback, interviews, support tickets, or behavior descriptions into evidence-backed user pain statements, affected roles, impact scope, and uncertainty. use when demand needs to be reframed as user problems and consequences for journey mapping, value assessment, prioritization, or solution discussion. not for proposing features, assigning roadmap priority, or treating internal complaints as user pain without evidence.', 'route_tokens': ['journey_analysis', 'value_assessment', 'prioritization', 'human_review'], 'composable': ['requirement-context-enrichment', 'user-journey-analysis', 'requirement-deduplication-and-clustering'], 'not_for': ['solution design', 'feature list generation', 'priority ranking'], 'skill_id': 'user-pain-point-analysis', 'contract_version': 'requirement-definition-suite-v1.3.0'}
PLACEHOLDERS = {'tbd','todo','host-workflow','待确认','<host-workflow>','<由 host workflow 注入>'}
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")

def parse_scalar(v):
    v=v.strip()
    if not v: return ''
    if v.startswith('[') and v.endswith(']'):
        body=v[1:-1].strip()
        if not body: return []
        return [x.strip().strip('"\'') for x in body.split(',')]
    return v.strip('"\'')

def load_yaml_like(path):
    data={}
    current=None
    for raw in path.read_text(encoding='utf-8').splitlines():
        line=raw.rstrip()
        if not line.strip() or line.lstrip().startswith('#'): continue
        if not line.startswith(' ') and ':' in line:
            k,v=line.split(':',1); k=k.strip(); v=v.strip()
            if v=='':
                data[k]=[]; current=k
            else:
                data[k]=parse_scalar(v); current=None
        elif current and line.strip().startswith('- '):
            data[current].append(parse_scalar(line.strip()[2:]))
    return data

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('metadata')
    args=ap.parse_args(); path=Path(args.metadata)
    if not path.exists(): print(f"ERROR: metadata not found: {path}", file=sys.stderr); return 2
    data = json.loads(path.read_text(encoding='utf-8')) if path.suffix.lower()=='.json' else load_yaml_like(path)
    errors=[]
    required=['artifact_id','skill_id','contract_version','schema','workflow_node','selected_mode','readiness','confidence','source_artifacts','evidence_refs','downstream_routes']
    for f in required:
        if f not in data or data[f] in ('',[],None): errors.append(f"missing metadata.{f}")
    allowed_keys=set(required)|{'cross_artifact_refs','notes'}
    for k in data:
        if k not in allowed_keys: errors.append(f"unexpected metadata field {k!r}")
    if data.get('skill_id') != CONFIG['skill_id']: errors.append(f"skill_id must be {CONFIG['skill_id']}")
    if data.get('contract_version') != CONFIG['contract_version']: errors.append(f"contract_version must be {CONFIG['contract_version']}")
    if data.get('schema') != CONFIG['schema']: errors.append(f"schema must be {CONFIG['schema']}")
    if data.get('selected_mode') not in CONFIG['modes']: errors.append('selected_mode not in allowed modes')
    if data.get('readiness') not in ['ready','needs_human_review','blocked']: errors.append('readiness invalid')
    if data.get('confidence') not in ['high','medium','low','needs_human_review']: errors.append('confidence invalid')
    for field in ['source_artifacts','evidence_refs','downstream_routes','cross_artifact_refs']:
        if field in data and not isinstance(data[field], list): errors.append(f"metadata.{field} must be a list")
    for r in data.get('downstream_routes',[]) if isinstance(data.get('downstream_routes'),list) else []:
        if r not in set(CONFIG['route_tokens'])|{'human_review','monitor_only'}: errors.append(f"unknown downstream route {r!r}")
    text='\n'.join(f'{k}: {v}' for k,v in data.items())
    if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in metadata')
    if str(data.get('artifact_id','')).lower() in PLACEHOLDERS: errors.append('artifact_id is a placeholder')
    if str(data.get('workflow_node','')).lower() in PLACEHOLDERS: errors.append('workflow_node is a placeholder')
    if not str(data.get('workflow_node','')).strip(): errors.append('workflow_node is required')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: metadata valid for {CONFIG['skill_id']} ({path.name})")
    return 0
if __name__=='__main__': sys.exit(main())
