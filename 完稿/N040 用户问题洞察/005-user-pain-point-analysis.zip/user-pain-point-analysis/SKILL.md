---
name: user-pain-point-analysis
description: turn requirement context, feedback, interviews, support tickets, or behavior descriptions into evidence-backed user pain statements, affected roles, impact scope, and uncertainty. use when demand needs to be reframed as user problems and consequences for journey mapping, value assessment, prioritization, or solution discussion. not for proposing features, assigning roadmap priority, or treating internal complaints as user pain without evidence.
---

# User Pain Point Analysis

## Contract baseline

- contract_version: `requirement-definition-suite-v1.3.0`
- skill_id: `user-pain-point-analysis`
- schema: `user.pain-point.v4`
- artifact_target: `user-pain-point-cards.md`
- selected_mode: `context_to_pain_cards / feedback_to_pain_cards / interview_pain_analysis / ticket_pain_analysis / low_evidence_candidate_pains`
- composable_with: `requirement-context-enrichment, user-journey-analysis, requirement-deduplication-and-clustering`
- downstream_route_tokens: `journey_analysis, value_assessment, prioritization, human_review`

This skill is self-contained and can run directly on partial input. It may compose with sibling skills, but it must not require them as prerequisites or encode private workflow node ids.

## Use this skill to

- Convert messy input into the skill's contracted deliverable while keeping source traceability.
- Preserve uncertainty, conflict, missing context, and evidence boundaries.
- Produce artifacts that can be validated locally before handoff.

## Do not use this skill to

- solution design; feature list generation; priority ranking.
- Invent facts, user needs, source ids, evidence, priorities, or delivery commitments.
- Replace downstream planning, technical design, quality gates, or final approval.

## Required output

Produce `user-pain-point-cards.md` as Markdown using `references/output-template.md`; keep required sections and evidence labels.

Always produce a sidecar metadata file with the same basename and `.metadata.yaml` suffix. Metadata must include `artifact_id`, `skill_id`, `contract_version`, `schema`, `workflow_node`, `selected_mode`, `readiness`, `confidence`, `source_artifacts`, `evidence_refs`, and `downstream_routes`.

## Workflow

1. Identify source materials, evidence anchors, roles, scope, dates, and uncertainty.
2. Select one `selected_mode` using `references/selected-mode-decision-tree.md`.
3. Read `references/anti-patterns.md` and avoid the listed failure modes.
4. Produce the required artifact using `references/output-template.md` and `references/field-contract.yaml` where applicable.
5. Produce sidecar metadata using `references/metadata-schema.json`.
6. Run `python3 scripts/validate_artifact.py <artifact.md>` and `python3 scripts/validate_metadata.py <artifact.metadata.yaml>`.
7. Run `python3 scripts/validate_release_consistency.py .` before packaging or final handoff when working inside the skill directory.

## References

Consult these files only when needed:

- `references/shared-requirement-definition-contract.md` for common contract, route tokens, and quality baseline.
- `references/requirement-id-space.md` for artifact and row id naming.
- `references/field-contract.yaml` for row/schema fields.
- `references/output-template.md` for default deliverable structure.
- `references/metadata-schema.json` for metadata sidecar contract.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and correct patterns.
- `references/common-failure-modes.md` for debugging weak outputs.
- `examples/upstream/` for generic upstream cascade samples when testing intake from feedback-loop artifacts.
- `references/quality-checklist.md` for final self-check.

## Boundary rules

- Use `composable_with` to describe optional sibling composition; do not use prerequisite/order fields.
- Use semantic route tokens such as `deduplication`, `context_enrichment`, `pain_analysis`, `journey_analysis`, `planning_intake`, or `human_review`.
- Keep private host workflow mappings outside the skill package.
- Prefer a partial but well-labeled result over an overconfident complete-looking artifact.
