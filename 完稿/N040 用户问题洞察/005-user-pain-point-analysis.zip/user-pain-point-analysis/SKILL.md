---
name: user-pain-point-analysis
display_name: 用户问题洞察 / User Pain Point Analysis
description: turn requirement context, feedback, interviews, or support tickets into evidence-backed user pain statements with affected roles, impact scope, and uncertainty. use when demand needs reframing as user problems for journey mapping, value assessment, or prioritization. not for feature proposals, roadmap priority assignment, or treating internal complaints as user pain without evidence.
---

# User Pain Point Analysis / 用户问题洞察

## Contract baseline

- contract_version: `requirement-definition-suite-v1.3.0`
- skill_id: `user-pain-point-analysis`
- schema: `user.pain-point.v4`
- artifact_target: `user-pain-point-cards.md`
- selected_mode: `context_to_pain_cards / feedback_to_pain_cards / interview_pain_analysis / ticket_pain_analysis / low_evidence_candidate_pains`
- composable_with: `requirement-context-enrichment, user-journey-analysis, requirement-deduplication-and-clustering`
- downstream_route_tokens: `journey_analysis, value_assessment, prioritization, human_review`

This skill is self-contained and can run directly on partial input. It may compose with sibling skills, but it must not require them as prerequisites or encode private workflow node ids.

## Use this skill to

- Convert messy input into the skill's contracted deliverable while keeping source traceability.
- Preserve uncertainty, conflict, missing context, and evidence boundaries.
- Produce artifacts that can be validated locally before handoff.

## Do not use this skill to

- solution design; feature list generation; priority ranking.
- Invent facts, user needs, source ids, evidence, priorities, or delivery commitments.
- Replace downstream planning, technical design, quality gates, or final approval.

## Required pain card structure

Each pain card in `user-pain-point-cards.md` must include the following fields. Use `[evidence: assumption]` or `[evidence: open question]` for unconfirmed items.

| field | required | format |
| --- | --- | --- |
| `pain_id` | required | `PAIN-<scope>-<nnn>` |
| `affected_role` | required | user role or segment |
| `pain_statement` | required | one-sentence problem statement in user terms |
| `trigger` | required | what causes the pain to occur |
| `consequence` | required | observable impact on the user |
| `frequency_hint` | required | `high\|medium\|low\|unknown` |
| `severity_hint` | required | `critical\|high\|medium\|low` |
| `evidence_refs` | required | source anchors or evidence references |
| `evidence_status` | required | `confirmed\|reasonable_assumption\|open_question` |
| `confidence` | required | `high\|medium\|low\|needs_human_review` |
| `open_questions` | required | free text or `none` |
| `related_requirement_ids` | recommended | `\|`-separated `REQ-*` ids |
| `related_journey_steps` | recommended | journey stage where pain occurs |

## Required output

Produce `user-pain-point-cards.md` as Markdown using `references/output-template.md`; keep required sections and evidence labels.

Always produce a sidecar metadata file with the same basename and `.metadata.yaml` suffix. Metadata must include `artifact_id`, `skill_id`, `contract_version`, `schema`, `workflow_node`, `selected_mode`, `readiness`, `confidence`, `source_artifacts`, `evidence_refs`, and `downstream_routes`.

## Workflow

1. Identify source materials, evidence anchors, roles, scope, dates, and uncertainty.
2. Select one `selected_mode` using `references/selected-mode-decision-tree.md`.
3. Read `references/anti-patterns.md` and avoid the listed failure modes.
4. Produce `user-pain-point-cards.md` using the Required pain card structure table above and `references/output-template.md`.
5. Produce sidecar metadata using `references/metadata-schema.json`.
6. Run `python3 scripts/validate_artifact.py <artifact.md>` and `python3 scripts/validate_metadata.py <artifact.metadata.yaml>`.
7. Run `python3 scripts/check_node_neutrality.py <artifact.md>` and `python3 scripts/check_order_neutrality.py <artifact.md>`.
8. Run `python3 scripts/validate_release_consistency.py .` before packaging
9. To validate the full 5-skill requirement-definition chain, run `python3 scripts/validate_requirement_definition_chain.py --collection ../002-requirement-collection-consolidation/examples/integration/requirement-collection.metadata.yaml --dedup ../003-requirement-deduplication-and-clustering/examples/integration/requirement-clusters.metadata.yaml --context ../004-requirement-context-enrichment/examples/integration/requirement-context-brief.metadata.yaml --pain ../005-user-pain-point-analysis/examples/integration/user-pain-point-cards.metadata.yaml --journey ../006-user-journey-analysis/examples/integration/user-journey-breakpoints.metadata.yaml`. See `examples/integration/README.md` for a ready-made checkout example. or final handoff when working inside the skill directory.

## Mode selection quick guide

| signal in input | recommended mode |
| --- | --- |
| Enriched context brief as primary input | `context_to_pain_cards` |
| User feedback or NPS comments | `feedback_to_pain_cards` |
| User interview notes | `interview_pain_analysis` |
| Support ticket batch | `ticket_pain_analysis` |
| Sparse evidence, no confirmed data | `low_evidence_candidate_pains` |

## References

Consult these files only when needed:

- `references/shared-requirement-definition-contract.md` for common contract, route tokens, and quality baseline.
- `references/requirement-id-space.md` for artifact and row id naming.
- `references/field-contract.yaml` for row/schema fields.
- `references/output-template.md` for default deliverable structure.
- `references/metadata-schema.json` for metadata sidecar contract.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and correct patterns.
- `references/common-failure-modes.md` for debugging weak outputs.
- `examples/upstream/` for generic upstream cascade samples when testing intake from feedback-loop artifacts.
- `references/quality-checklist.md` for final self-check.

## Cross-artifact composition

When producing a final artifact in a multi-skill run, reference sibling artifacts through `cross_artifact_refs` in the sidecar metadata rather than duplicating their content. Use the sibling's `artifact_id` as the reference key and include the relationship type (`upstream`, `peer`, or `downstream`).

Example:
```yaml
cross_artifact_refs:
  - artifact_id: REQ-COL-scope-202506
    relationship: upstream
  - artifact_id: REQ-DED-scope-202506
    relationship: peer
```

This keeps each skill's artifact self-contained while preserving full traceability across the chain.

## Boundary rules

- Use `composable_with` to describe optional sibling composition; do not use prerequisite/order fields.
- Use semantic route tokens such as `deduplication`, `context_enrichment`, `pain_analysis`, `journey_analysis`, `planning_intake`, or `human_review`.
- Keep private host workflow mappings outside the skill package.
- Prefer a partial but well-labeled result over an overconfident complete-looking artifact.
