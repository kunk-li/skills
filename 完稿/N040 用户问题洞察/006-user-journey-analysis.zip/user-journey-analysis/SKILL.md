---
name: user-journey-analysis
display_name: 用户旅程分析 / User Journey Analysis
description: map a user journey from entry to goal completion using requirement context, flow descriptions, screenshots, service records, or research notes, then identify stages, goals, actions, touchpoints, blockers, and breakpoints. use when the user needs a structured journey view for solution design, value assessment, prioritization, or pain analysis. not for idealized future-state design, ui specification, or roadmap ranking.
---

# User Journey Analysis / 用户旅程分析

## Contract baseline

- contract_version: `requirement-definition-suite-v1.3.0`
- skill_id: `user-journey-analysis`
- schema: `user.journey.v4`
- artifact_target: `user-journey-breakpoints.md`
- selected_mode: `single_journey_mapping / multi_role_journey_mapping / breakpoint_analysis / screenshot_or_flow_reconstruction / low_evidence_skeleton_journey`
- composable_with: `requirement-context-enrichment, user-pain-point-analysis, requirement-deduplication-and-clustering`
- downstream_route_tokens: `pain_analysis, value_assessment, prioritization, solution_discovery`

This skill is self-contained and can run directly on partial input. It may compose with sibling skills, but it must not require them as prerequisites or encode private workflow node ids.

## Use this skill to

- Convert messy input into the skill's contracted deliverable while keeping source traceability.
- Preserve uncertainty, conflict, missing context, and evidence boundaries.
- Produce artifacts that can be validated locally before handoff.

## Do not use this skill to

- ui design specification; final process redesign; technical implementation plan.
- Invent facts, user needs, source ids, evidence, priorities, or delivery commitments.
- Replace downstream planning, technical design, quality gates, or final approval.

## Required output sections

The `user-journey-breakpoints.md` must contain these sections. Mark content as `[evidence: assumption]` or `[evidence: open question]` when not confirmed.

| section | required | content |
| --- | --- | --- |
| `## Journey overview` | required | artifact id, journey_id (`JNY-<scope>-<nnn>`), role, goal, evidence status summary |
| `## Journey table` | required | stage, stage goal, user action, system touchpoint or feedback, blocker, evidence status |
| `## High-impact breakpoints` | required | breakpoint_id, stage, trigger, consequence, affected role |
| `## Evidence and assumptions` | required | confirmed facts, reasonable assumptions, open questions |
| `## Open questions` | required | unresolved questions before handoff |
| `## Downstream handoff` | required | route tokens and next recommended skill |

## Low-evidence skeleton journey rules

When `selected_mode: low_evidence_skeleton_journey` is chosen because evidence is sparse:

- Set `readiness: needs_human_review` and `confidence: low` in metadata.
- Mark every journey table row's `evidence_status` as `reasonable_assumption` or `open_question`.
- Add at least three entries under `## Open questions` describing what must be confirmed before treating the journey as validated.
- Do not produce breakpoints with `evidence_status: confirmed_facts` unless at least one source anchor supports the claim.
- Route downstream to `human_review` first; do not route directly to `prioritization` or `solution_discovery`.

## Required output

Produce `user-journey-breakpoints.md` as Markdown using `references/output-template.md`; keep required sections and evidence labels.

Always produce a sidecar metadata file with the same basename and `.metadata.yaml` suffix. Metadata must include `artifact_id`, `skill_id`, `contract_version`, `schema`, `workflow_node`, `selected_mode`, `readiness`, `confidence`, `source_artifacts`, `evidence_refs`, and `downstream_routes`.

## Workflow

1. Identify source materials, evidence anchors, roles, scope, dates, and uncertainty.
2. Select one `selected_mode` using `references/selected-mode-decision-tree.md`. If evidence is sparse or source is a single unverified claim, choose `low_evidence_skeleton_journey`.
3. Read `references/anti-patterns.md`; pay special attention to AP-JNY-01 through AP-JNY-05 and the new AP-JNY-06 through AP-JNY-08 below.
4. Produce `user-journey-breakpoints.md` using the Required output sections table and `references/output-template.md`.
5. Produce sidecar metadata using `references/metadata-schema.json`.
6. Run `python3 scripts/validate_artifact.py <artifact.md>` and `python3 scripts/validate_metadata.py <artifact.metadata.yaml>`.
7. Run `python3 scripts/check_node_neutrality.py <artifact.md>` and `python3 scripts/check_order_neutrality.py <artifact.md>`.
8. Run `python3 scripts/validate_release_consistency.py .` before packaging
9. To validate the full 5-skill requirement-definition chain, run `python3 scripts/validate_requirement_definition_chain.py --collection <002.metadata.yaml> --dedup <003.metadata.yaml> --context <004.metadata.yaml> --pain <005.metadata.yaml> --journey <006.metadata.yaml>`. See `examples/integration/README.md` for a ready-made checkout example. or final handoff when working inside the skill directory.

## Mode selection quick guide

| signal in input | recommended mode |
| --- | --- |
| Single user role, clear start-to-end flow | `single_journey_mapping` |
| Multiple roles interact in the same flow | `multi_role_journey_mapping` |
| Known friction points, need root cause | `breakpoint_analysis` |
| Screenshots, UI flows, or recorded sessions | `screenshot_or_flow_reconstruction` |
| Sparse evidence, inferred journey only | `low_evidence_skeleton_journey` |

## Additional anti-patterns (AP-JNY-06 to AP-JNY-08)

These complement AP-JNY-01 through AP-JNY-05 in `references/anti-patterns.md`:

| id | anti-pattern | why harmful | correct pattern |
| --- | --- | --- | --- |
| AP-JNY-06 | using `low_evidence_skeleton_journey` mode but setting `readiness: ready` | falsely signals the journey is validated | always set `readiness: partial` and `confidence: low` in low-evidence mode |
| AP-JNY-07 | producing breakpoints without a trigger and consequence | downstream cannot test or mitigate the friction | every breakpoint must have both `trigger` and `consequence` |
| AP-JNY-08 | routing low-evidence skeleton journey directly to `prioritization` | unsupported journey becomes roadmap input | route to `human_review` first; let a human confirm before escalating |

## References

Consult these files only when needed:

- `references/shared-requirement-definition-contract.md` for common contract, route tokens, and quality baseline.
- `references/requirement-id-space.md` for artifact and row id naming.
- `references/field-contract.yaml` for row/schema fields.
- `references/output-template.md` for default deliverable structure.
- `references/metadata-schema.json` for metadata sidecar contract.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for AP-01 through AP-10 and AP-JNY-01 through AP-JNY-05.
- `references/common-failure-modes.md` for debugging weak outputs.
- `examples/upstream/` for generic upstream cascade samples when testing intake from feedback-loop artifacts.
- `examples/low-evidence-skeleton-journey-example.md` for a worked low-evidence example.
- `references/quality-checklist.md` for final self-check.

## Boundary rules

- Use `composable_with` to describe optional sibling composition; do not use prerequisite/order fields.
- Use semantic route tokens such as `deduplication`, `context_enrichment`, `pain_analysis`, `journey_analysis`, `planning_intake`, or `human_review`.
- Keep private host workflow mappings outside the skill package.
- Prefer a partial but well-labeled result over an overconfident complete-looking artifact.
