#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
CONFIG = {'display': 'User Journey Analysis', 'cn': '用户旅程分析', 'family_role': 'journey', 'artifact_type': 'markdown', 'primary_artifact': 'user-journey-breakpoints.md', 'schema': 'user.journey.v4', 'id_field': 'journey_id', 'id_re': '^JNY-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['journey overview', 'journey table', 'high-impact breakpoints', 'evidence and assumptions', 'open questions'], 'modes': ['single_journey_mapping', 'multi_role_journey_mapping', 'breakpoint_analysis', 'screenshot_or_flow_reconstruction', 'low_evidence_skeleton_journey'], 'description': 'map a user journey from entry to goal completion using requirement context, flow descriptions, screenshots, service records, or research notes, then identify stages, goals, actions, touchpoints, blockers, and breakpoints. use when the user needs a structured journey view for solution design, value assessment, prioritization, or pain analysis. not for idealized future-state design, ui specification, or roadmap ranking.', 'route_tokens': ['pain_analysis', 'value_assessment', 'prioritization', 'solution_discovery'], 'composable': ['requirement-context-enrichment', 'user-pain-point-analysis', 'requirement-deduplication-and-clustering'], 'not_for': ['ui design specification', 'final process redesign', 'technical implementation plan'], 'skill_id': 'user-journey-analysis', 'contract_version': 'requirement-definition-suite-v1.3.0'}
PLACEHOLDERS = {'tbd','todo','host-workflow','待确认','<host-workflow>','<由 host workflow 注入>'}
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")

def parse_scalar(v):
    v=v.strip()
    if not v: return ''
    if v.startswith('[') and v.endswith(']'):
        body=v[1:-1].strip()
        if not body: return []
        return [x.strip().strip('"\'') for x in body.split(',')]
    return v.strip('"\'')

def load_yaml_like(path):
    data={}
    current=None
    for raw in path.read_text(encoding='utf-8').splitlines():
        line=raw.rstrip()
        if not line.strip() or line.lstrip().startswith('#'): continue
        if not line.startswith(' ') and ':' in line:
            k,v=line.split(':',1); k=k.strip(); v=v.strip()
            if v=='':
                data[k]=[]; current=k
            else:
                data[k]=parse_scalar(v); current=None
        elif current and line.strip().startswith('- '):
            data[current].append(parse_scalar(line.strip()[2:]))
    return data

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('metadata')
    args=ap.parse_args(); path=Path(args.metadata)
    if not path.exists(): print(f"ERROR: metadata not found: {path}", file=sys.stderr); return 2
    data = json.loads(path.read_text(encoding='utf-8')) if path.suffix.lower()=='.json' else load_yaml_like(path)
    errors=[]
    required=['artifact_id','skill_id','contract_version','schema','workflow_node','selected_mode','readiness','confidence','source_artifacts','evidence_refs','downstream_routes']
    for f in required:
        if f not in data or data[f] in ('',[],None): errors.append(f"missing metadata.{f}")
    allowed_keys=set(required)|{'cross_artifact_refs','notes'}
    for k in data:
        if k not in allowed_keys: errors.append(f"unexpected metadata field {k!r}")
    if data.get('skill_id') != CONFIG['skill_id']: errors.append(f"skill_id must be {CONFIG['skill_id']}")
    if data.get('contract_version') != CONFIG['contract_version']: errors.append(f"contract_version must be {CONFIG['contract_version']}")
    if data.get('schema') != CONFIG['schema']: errors.append(f"schema must be {CONFIG['schema']}")
    if data.get('selected_mode') not in CONFIG['modes']: errors.append('selected_mode not in allowed modes')
    if data.get('readiness') not in ['ready','needs_human_review','blocked']: errors.append('readiness invalid')
    if data.get('confidence') not in ['high','medium','low','needs_human_review']: errors.append('confidence invalid')
    for field in ['source_artifacts','evidence_refs','downstream_routes','cross_artifact_refs']:
        if field in data and not isinstance(data[field], list): errors.append(f"metadata.{field} must be a list")
    for r in data.get('downstream_routes',[]) if isinstance(data.get('downstream_routes'),list) else []:
        if r not in set(CONFIG['route_tokens'])|{'human_review','monitor_only'}: errors.append(f"unknown downstream route {r!r}")
    text='\n'.join(f'{k}: {v}' for k,v in data.items())
    if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in metadata')
    if str(data.get('artifact_id','')).lower() in PLACEHOLDERS: errors.append('artifact_id is a placeholder')
    if str(data.get('workflow_node','')).lower() in PLACEHOLDERS: errors.append('workflow_node is a placeholder')
    if not str(data.get('workflow_node','')).strip(): errors.append('workflow_node is required')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: metadata valid for {CONFIG['skill_id']} ({path.name})")
    return 0
if __name__=='__main__': sys.exit(main())
