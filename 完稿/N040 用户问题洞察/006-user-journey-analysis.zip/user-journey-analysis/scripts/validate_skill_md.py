#!/usr/bin/env python3
import re, sys
from pathlib import Path
CONFIG={'display': 'User Journey Analysis', 'cn': '用户旅程分析', 'family_role': 'journey', 'artifact_type': 'markdown', 'primary_artifact': 'user-journey-breakpoints.md', 'schema': 'user.journey.v4', 'id_field': 'journey_id', 'id_re': '^JNY-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['journey overview', 'journey table', 'high-impact breakpoints', 'evidence and assumptions', 'open questions'], 'modes': ['single_journey_mapping', 'multi_role_journey_mapping', 'breakpoint_analysis', 'screenshot_or_flow_reconstruction', 'low_evidence_skeleton_journey'], 'description': 'map a user journey from entry to goal completion using requirement context, flow descriptions, screenshots, service records, or research notes, then identify stages, goals, actions, touchpoints, blockers, and breakpoints. use when the user needs a structured journey view for solution design, value assessment, prioritization, or pain analysis. not for idealized future-state design, ui specification, or roadmap ranking.', 'route_tokens': ['pain_analysis', 'value_assessment', 'prioritization', 'solution_discovery'], 'composable': ['requirement-context-enrichment', 'user-pain-point-analysis', 'requirement-deduplication-and-clustering'], 'not_for': ['ui design specification', 'final process redesign', 'technical implementation plan'], 'skill_id': 'user-journey-analysis', 'contract_version': 'requirement-definition-suite-v1.3.0'}
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")
RETIRED_VERSION_TOKENS = (
    "requirement-definition-suite-v" + "1.1.0",
    "requirement-definition-suite-v" + "1.2.0",
    "requirement.collection.v" + "2", "requirement.collection.v" + "3",
    "requirement.deduplication.v" + "2", "requirement.deduplication.v" + "3",
    "requirement.context.v" + "2", "requirement.context.v" + "3",
    "user.pain-point.v" + "2", "user.pain-point.v" + "3",
    "user.journey.v" + "2", "user.journey.v" + "3",
)

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    args=ap.parse_args(); d=Path(args.skill_dir); p=d/'SKILL.md'
    errors=[]
    if not p.exists(): errors.append('SKILL.md missing')
    else:
        text=p.read_text(encoding='utf-8')
        if not text.startswith('---'): errors.append('missing YAML frontmatter')
        if f"name: {CONFIG['skill_id']}" not in text: errors.append('frontmatter name mismatch')
        if 'description:' not in text: errors.append('frontmatter description missing')
        if 'TODO' in text or '[TODO' in text: errors.append('TODO placeholder remains')
        if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in SKILL.md')
        for token in RETIRED_VERSION_TOKENS:
            if token in text:
                errors.append(f'retired contract or schema token remains in SKILL.md: {token}')
        forbidden=['depends' + '_on','blo' + 'cks']
        for word in forbidden:
            if re.search(rf"(^|[\s`'\"]){word}(\s*:|[`'\"])", text, re.I): errors.append(f'forbidden order field {word!r}')
        for req in ['references/shared-requirement-definition-contract.md','scripts/validate_artifact.py','scripts/validate_metadata.py']:
            if req not in text: errors.append(f'SKILL.md does not reference {req}')
    for rel in ['agents/openai.yaml','references/metadata-schema.json','references/anti-patterns.md','scripts/validate_release_consistency.py']:
        if not (d/rel).exists(): errors.append(f'missing {rel}')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: SKILL.md baseline for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
