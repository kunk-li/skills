#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
CONFIG={'display': 'User Journey Analysis', 'cn': '用户旅程分析', 'family_role': 'journey', 'artifact_type': 'markdown', 'primary_artifact': 'user-journey-breakpoints.md', 'schema': 'user.journey.v4', 'id_field': 'journey_id', 'id_re': '^JNY-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['journey overview', 'journey table', 'high-impact breakpoints', 'evidence and assumptions', 'open questions'], 'modes': ['single_journey_mapping', 'multi_role_journey_mapping', 'breakpoint_analysis', 'screenshot_or_flow_reconstruction', 'low_evidence_skeleton_journey'], 'description': 'map a user journey from entry to goal completion using requirement context, flow descriptions, screenshots, service records, or research notes, then identify stages, goals, actions, touchpoints, blockers, and breakpoints. use when the user needs a structured journey view for solution design, value assessment, prioritization, or pain analysis. not for idealized future-state design, ui specification, or roadmap ranking.', 'route_tokens': ['pain_analysis', 'value_assessment', 'prioritization', 'solution_discovery'], 'composable': ['requirement-context-enrichment', 'user-pain-point-analysis', 'requirement-deduplication-and-clustering'], 'not_for': ['ui design specification', 'final process redesign', 'technical implementation plan'], 'skill_id': 'user-journey-analysis', 'contract_version': 'requirement-definition-suite-v1.3.0'}

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    d=Path(ap.parse_args().skill_dir)
    errors=[]
    dt=d/'references/selected-mode-decision-tree.md'
    ms=d/'references/metadata-schema.json'
    sm=d/'SKILL.md'
    if not dt.exists(): errors.append('selected-mode-decision-tree.md missing')
    else:
        text=dt.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if f'`{m}`' not in text: errors.append(f'mode {m} missing from decision tree')
    if ms.exists():
        meta=json.loads(ms.read_text(encoding='utf-8'))
        enum=meta.get('properties',{}).get('selected_mode',{}).get('enum',[])
        if set(enum)!=set(CONFIG['modes']): errors.append('metadata selected_mode enum mismatch')
    else: errors.append('metadata-schema.json missing')
    if sm.exists():
        s=sm.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if m not in s: errors.append(f'mode {m} missing from SKILL.md')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: selected-mode decision tree aligned for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
