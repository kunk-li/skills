# Real Examples / 真实示例参考

These examples illustrate correctly formed journey tables, breakpoint entries, and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Single journey mapping — evidence status per row

**Input**: Checkout flow described in a PRD; confirmed by two user interviews.

**Correct pattern for a journey table row**:
```
| Payment entry | Enter payment details | Types card number and expiry | Form validates in real time | None confirmed | confirmed_facts |
```

**Anti-pattern to avoid (AP-JNY-01)**: Writing every row as `confirmed_facts` when only the PRD is available — the PRD describes intended behavior, not observed user behavior. Mark PRD-only rows as `reasonable_assumption`.

---

## Example 2: Breakpoint analysis — trigger and consequence both required

**Input**: Users drop off at the OTP verification step in mobile login.

**Correct pattern**:
```
breakpoint_id: BP-login-001
stage: otp_verification
trigger: OTP SMS arrives more than 60 seconds after the 30-second countdown expires
consequence: user sees an expired-code error and must restart the entire login flow from the beginning
affected_role: mobile_user
evidence_status: confirmed_facts
evidence_refs: SRC-analytics-dropout-001
```

**Anti-pattern to avoid (AP-JNY-07)**: Writing `trigger: OTP issue` and `consequence: user frustrated` — vague trigger and consequence cannot be tested, mitigated, or handed off to engineering.

---

## Example 3: Low-evidence skeleton journey — open questions section required

**Input**: A single support ticket says "I couldn't finish setting up my account."

**Correct pattern**:
```
selected_mode: low_evidence_skeleton_journey
readiness: needs_human_review
confidence: low

## Open Questions (minimum three required in low-evidence mode)
1. Which step in account setup caused the failure — email confirmation, profile completion, or payment entry?
2. Is this a mobile or desktop flow?
3. How many users reported this vs. completed setup successfully?
```

**Anti-pattern to avoid (AP-JNY-06 + AP-JNY-08)**: Setting `readiness: ready` on a skeleton journey built from one ticket, then routing directly to `prioritization`. Always route to `human_review` first.
