# Quality checklist

First apply the common checklist in `shared-requirement-definition-contract.md`.

## Skill-specific checks

- Journey stages follow user time order.
- User actions and system feedback are separate.
- Breakpoints include trigger and consequence.

- Metadata `workflow_node` is a real host workflow identifier, not a placeholder.
- Anti-patterns AP-01 through AP-10 and the five skill-specific AP rows have been checked.
