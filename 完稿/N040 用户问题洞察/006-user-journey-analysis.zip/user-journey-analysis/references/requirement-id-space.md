# Requirement-definition id space

## Artifact id

Use `JOURNEY-ARTIFACT-<scope>-<yyyymm>` for sidecar `artifact_id`.

Example: `JOURNEY-ARTIFACT-checkout-202605`.

## Row or section id

Primary id field: `journey_id`.
Expected pattern: `^JNY-[a-z0-9_]+-\d{3,}$`.
Example: `JNY-checkout-001`.

## Multi-value cells

Use `|` as the delimiter in CSV multi-value cells. Do not use bare commas inside machine-readable id lists.
