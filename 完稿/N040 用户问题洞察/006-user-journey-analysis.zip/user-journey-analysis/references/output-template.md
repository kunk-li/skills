# Output template

Produce `user-journey-breakpoints.md` as Markdown.

# User Journey Analysis Output

artifact id: <artifact_id>  
journey_id: <id>

## Journey Overview

- confirmed facts:
- reasonable assumptions:
- open questions:

## Journey Table

- confirmed facts:
- reasonable assumptions:
- open questions:

## High-Impact Breakpoints

- confirmed facts:
- reasonable assumptions:
- open questions:

## Evidence And Assumptions

- confirmed facts:
- reasonable assumptions:
- open questions:

## Open Questions

- confirmed facts:
- reasonable assumptions:
- open questions:


Keep evidence labels visible. Do not write unsupported conclusions as facts.
