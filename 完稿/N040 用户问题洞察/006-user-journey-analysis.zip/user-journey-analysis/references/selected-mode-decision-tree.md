# Selected-mode decision tree

Choose exactly one selected_mode:

- `single_journey_mapping`: use when single journey mapping is the closest operating mode.
- `multi_role_journey_mapping`: use when multi role journey mapping is the closest operating mode.
- `breakpoint_analysis`: use when breakpoint analysis is the closest operating mode.
- `screenshot_or_flow_reconstruction`: use when screenshot or flow reconstruction is the closest operating mode.
- `low_evidence_skeleton_journey`: use when low evidence skeleton journey is the closest operating mode.

Validation rule: metadata `selected_mode` must match one of the modes above and the schema enum.
