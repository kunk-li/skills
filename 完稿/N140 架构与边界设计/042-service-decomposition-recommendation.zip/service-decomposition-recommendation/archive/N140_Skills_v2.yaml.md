# N140 · 优化后 Skills(2 个 · 完整版)

> **节点**:N140 架构与边界设计
> **版本**:v2.0.0
> **格式**:完整 YAML 定义 · 含所有必需段落

---

## SKILL-041 · `module-boundary-identification` v2.0.0

```yaml
skill_id: module-boundary-identification
version: 2.0.0
category: 架构 / 模块边界
status: active
replaces: v1.x

# =============== 定位 ===============
purpose: |
  识别系统模块边界 · 量化 cohesion / coupling / stability 指标 · 
  区分 necessary vs designed vs shared 耦合 · 标注 co_change hints
  · 支持 5 种 module_scale(code_package → bounded_context → component → service → system)
  从定性架构讨论转向可度量 · 防止"谁都说有道理"的无效争论

# =============== 输入 ===============
input_schema:
  engineering_requirements:
    required: true
    from: N120
  
  api_intents:
    required: true
    from: N120
  
  data_objects:
    required: true
    from: N070/data-object-identification
  
  solution_draft:
    required: false
    from: N130/technical-solution-draft
  
  existing_codebase_context:
    required: false
    type: object
    properties:
      existing_modules: array
      git_history_months: integer     # 用于 co-change 分析
      loc_by_module: object
  
  target_scale:
    required: true
    type: enum
    values: [code_package, bounded_context, component, service, system]
    default: bounded_context

# =============== 输出 Schema ===============
output_schema:
  modules[]:
    module_id:
      pattern: "MOD-[A-Z]+-\\d{3,}"
    
    name: string
    description: string
    
    # -------- 5 种 module_scale --------
    module_scale:
      required: true
      type: enum
      values:
        code_package:
          meaning: "代码包 / namespace"
          abstraction: lowest
          example: "com.company.order.service"
        bounded_context:
          meaning: "DDD 限界上下文"
          abstraction: low
          example: "Order Management Context"
        component:
          meaning: "进程内组件"
          abstraction: medium
          example: "OrderComponent"
        service:
          meaning: "独立部署服务"
          abstraction: high
          example: "order-service (独立微服务)"
        system:
          meaning: "子系统"
          abstraction: highest
          example: "订单交易子系统"
    
    # -------- 职责 --------
    responsibilities:
      type: array
      items:
        responsibility: string
        strength:
          enum: [primary, secondary, shared]
    
    # -------- 所拥有的资源 --------
    owned_resources:
      entities:
        type: array
        items: string                  # OBJ-xxx
      apis:
        type: array
        items: string                  # API-xxx
      data_tables:
        type: array
        items: string
      events_published:
        type: array
        items: string
    
    # -------- 定量指标 --------
    metrics:
      cohesion:
        description: "内聚性(模块内元素关系紧密度)"
        score: integer                 # 0-100
        calculation: "LCOM-like · 基于职责共享变量"
        interpretation:
          > 80: "强内聚(好)"
          50-80: "中等"
          < 50: "弱内聚(考虑拆分)"
      
      coupling:
        afferent:                      # 入耦合 · 依赖我的模块数
          count: integer
          classification:
            high: "> 5"
        efferent:                      # 出耦合 · 我依赖的模块数
          count: integer
          classification:
            high: "> 5"
        coupling_ratio:                # efferent / (afferent + efferent)
          score: float
          interpretation:
            > 0.7: "高依赖(不稳定)"
            0.3-0.7: "平衡"
            < 0.3: "被大量依赖(stable)"
      
      stability:
        score: float                   # 0-1 · Martin 稳定性指标
        calculation: "I = Ce / (Ca + Ce)"
        interpretation:
          0: "完全稳定(被依赖多 · 不应频繁改)"
          1: "完全不稳定(依赖多 · 可频繁改)"
      
      abstractness:
        score: float                   # 0-1
        interpretation: "抽象接口 vs 具体实现的比"
      
      distance_from_main_sequence:
        score: float                   # |A + I - 1|
        interpretation:
          < 0.2: "健康(抽象+稳定平衡)"
          > 0.5: "问题(painful zone 或 useless zone)"
    
    # -------- 耦合点详细分析 --------
    coupling_points:
      type: array
      items:
        with_module: string            # 另一模块 ID
        coupling_kind:
          enum:
            data:                      # 数据耦合
              description: "通过数据交换"
              strength: weakest
              example: "传 DTO"
            stamp:                     # 印记耦合
              description: "传复合对象但只用部分字段"
              strength: weak
              example: "传 User 对象 · 只用 userId"
            control:                   # 控制耦合
              description: "传 flag 控制行为"
              strength: medium
              example: "method(flag: boolean)"
            external:                  # 外部耦合
              description: "共享外部格式"
              strength: medium
              example: "共享 CSV 格式"
            common:                    # 公共耦合
              description: "共享全局数据"
              strength: strong
              example: "共享 singleton state"
            content:                   # 内容耦合
              description: "直接访问另一模块内部"
              strength: strongest
              example: "跨边界修改内部字段"
        
        coupling_necessity:
          enum:
            necessary:                 # 业务必须
              description: "业务或技术必须耦合"
              rationale_required: true
            designed:                  # 设计选择 · 可解耦
              description: "当前选择 · 但可改"
              refactoring_hint: string
            shared:                    # 共享基础设施
              description: "共享 infra · 可接受"
              example: "共用 Redis"
        
        interaction_pattern:
          enum:
            sync_call: "同步调用"
            async_event: "异步事件"
            shared_db: "共享 DB(反模式警告)"
            shared_cache: "共享缓存"
            message_queue: "消息队列"
            file_exchange: "文件交换"
        
        contract_formalized:           # 契约已形式化?
          bool: true
          contract_ref: string | null
    
    # -------- Co-change hints --------
    co_change_hints:
      description: "基于 git history · 识别常一起变化的模块"
      required: false
      items:
        type: array
        items:
          with_module: string
          co_change_frequency: float   # 0-1
          co_change_count: integer
          within_period: duration
          recommendation:
            enum:
              merge: "co_change > 0.8 · 建议合并"
              strengthen_contract: "co_change 0.5-0.8 · 加强契约"
              acceptable: "co_change < 0.5"
    
    # -------- 变更频率(stability tracking)--------
    change_frequency:
      description: "模块变更频率"
      commits_last_90d: integer
      authors_last_90d: integer
      tier:
        enum: [stable, moderate, volatile]
        rule:
          stable: "< 10 commits / 90d"
          moderate: "10-50 commits"
          volatile: "> 50 commits"
  
  # -------- 反模式检测 --------
  anti_patterns_detected:
    type: array
    items:
      pattern:
        enum:
          god_module: "职责过多 · 内聚低"
          feature_envy: "频繁调另一模块的数据(应重新分配职责)"
          shotgun_surgery: "一个变更需改 N 个模块"
          chatty_interface: "两模块频繁小调用(性能 + 耦合问题)"
          cyclic_dependency: "循环依赖"
          inappropriate_intimacy: "两模块知道太多彼此细节"
          shared_database_anti_pattern: "多服务共用 DB(边界破坏)"
      
      severity:
        enum: [critical, high, medium, low]
      
      affected_modules:
        type: array
        items: string
      
      evidence: string
      
      remediation_suggestions:
        type: array
        items:
          action: string
          estimated_effort: duration
  
  # -------- 整体评估 --------
  overall_assessment:
    healthy_modules_count: integer
    problematic_modules_count: integer
    cycles_detected: integer
    anti_patterns_count_by_severity:
      critical: integer
      high: integer
      medium: integer
      low: integer
    architecture_health_score: integer  # 0-100

# =============== 规则 ===============
rules:
  R01_scale_declared:
    description: "module_scale 必标(不同 scale 分析方法不同)"
    on_violation: reject
  
  R02_responsibilities_require_strength:
    description: "每 responsibility 必标 primary/secondary/shared"
    on_violation: reject
  
  R03_metrics_calculated_if_codebase_available:
    description: "有 existing_codebase_context 时 · 必算定量指标"
    on_violation: warn
  
  R04_coupling_necessity_required:
    description: "每 coupling_point 必标 necessity"
    on_violation: reject
  
  R05_content_coupling_forbidden:
    description: "content 耦合属反模式 · 必 flag"
    on_violation: raise_anti_pattern
  
  R06_cyclic_dependency_blocking:
    description: "循环依赖必须解除 · 除非显式接受(签字)"
    on_violation: block
  
  R07_shared_db_anti_pattern:
    description: "service 级共享 DB 需显式 rationale"
    on_violation: raise_anti_pattern
  
  R08_co_change_high_requires_action:
    description: "co_change > 0.8 必须给出行动(合并 / 强契约)"
    on_violation: reject

# =============== 算法 ===============
algorithms:
  cohesion_calculation:
    description: "LCOM-like 内聚度"
    method: |
      找模块内所有'职责单元' · 计算共享的资源 / 数据 / 交互
      共享多 → 高内聚 · 共享少 → 低内聚
    formula: "1 - (unique_resource_sets / total_responsibilities)"
  
  coupling_measurement:
    afferent_coupling: "统计依赖该模块的其他模块数"
    efferent_coupling: "统计该模块依赖的其他模块数"
    sources:
      - import / require 语句
      - API 调用
      - 共享数据表 / 事件
  
  stability_calculation:
    formula: "I = Ce / (Ca + Ce)"
    interpretation:
      I == 0: 完全稳定
      I == 1: 完全不稳定
  
  abstractness_calculation:
    formula: "A = abstract_classes / total_classes"
    note: "在高级 scale 上 · 可泛化为'接口 / 总组件数'"
  
  cycle_detection:
    algorithm: "Tarjan 强连通分量"
    output: "cycles 清单 · 含涉及的模块"
  
  co_change_analysis:
    description: "从 git history 统计"
    algorithm: |
      for each commit:
        modules_changed = set of modules affected
        for each pair (A, B) in modules_changed:
          co_change_count[A,B] += 1
      co_change_frequency[A,B] = co_change_count[A,B] / total_commits
  
  anti_pattern_detection_rules:
    god_module: "responsibilities.length > 7 AND cohesion < 50"
    feature_envy: "模块 A 频繁读模块 B 的数据(> 50% 调用)"
    shotgun_surgery: "git history 显示某类 change 总触达 > 5 模块"
    chatty_interface: "模块 A → 模块 B 平均每业务流程 > 10 次调用"
    cyclic_dependency: "从 cycle_detection 识别"
    shared_database_anti_pattern: "同 DB 被 > 1 个 service 写"

# =============== 示例 ===============
examples:
  - example_id: ex-001
    description: "订单模块边界分析"
    module_id: MOD-ORDER-001
    name: order-context
    description: "订单限界上下文"
    module_scale: bounded_context
    
    responsibilities:
      - responsibility: "订单生命周期管理"
        strength: primary
      - responsibility: "订单金额计算"
        strength: primary
      - responsibility: "订单状态机"
        strength: secondary
    
    owned_resources:
      entities: [OBJ-ORDER-001, OBJ-ORDER-ITEM-001]
      apis: [API-ORDER-CREATE, API-ORDER-GET, API-ORDER-LIST]
      data_tables: [orders, order_items]
      events_published: [order.created, order.cancelled]
    
    metrics:
      cohesion:
        score: 85
        interpretation: "强内聚"
      coupling:
        afferent:
          count: 3                     # 被 3 个模块依赖
        efferent:
          count: 2                     # 依赖 2 个模块
        coupling_ratio: 0.40           # 平衡
      stability:
        score: 0.40
        interpretation: "偏稳定"
      abstractness:
        score: 0.30
      distance_from_main_sequence:
        score: 0.30
        interpretation: "健康"
    
    coupling_points:
      - with_module: MOD-PAYMENT-001
        coupling_kind: data
        coupling_necessity: necessary
        interaction_pattern: sync_call
        contract_formalized: true
        contract_ref: API-PAYMENT-CHARGE
      - with_module: MOD-USER-001
        coupling_kind: stamp
        coupling_necessity: necessary
        interaction_pattern: sync_call
        contract_formalized: true
        contract_ref: API-USER-GET
      - with_module: MOD-AUDIT-001
        coupling_kind: data
        coupling_necessity: necessary
        interaction_pattern: async_event
        contract_formalized: true
        contract_ref: EVENT-ORDER-CREATED
    
    co_change_hints:
      - with_module: MOD-PAYMENT-001
        co_change_frequency: 0.35
        co_change_count: 12
        within_period: 90d
        recommendation: acceptable
    
    change_frequency:
      commits_last_90d: 28
      authors_last_90d: 4
      tier: moderate
  
  - example_id: ex-002
    description: "反模式检测 · 共享 DB"
    anti_patterns_detected:
      - pattern: shared_database_anti_pattern
        severity: high
        affected_modules: [order-service, payment-service]
        evidence: "两服务直接 SELECT orders 表 · 违反微服务边界"
        remediation_suggestions:
          - action: "payment-service 通过 order-service API 获取订单数据"
            estimated_effort: 5d
          - action: "短期用事件同步 · payment 维护自己的投影"
            estimated_effort: 7d

# =============== 独立使用模式 ===============
standalone_modes:
  static_analysis:
    description: "仅基于 ER + API · 产出理论边界"
    use_case: "greenfield 项目"
  
  codebase_informed:
    description: "结合 existing_codebase · 含定量指标"
    use_case: "重构现有系统"
  
  co_change_focused:
    description: "专项 co-change 分析"
    use_case: "决定拆 / 合模块"
  
  anti_pattern_scan:
    description: "仅扫反模式"
    use_case: "架构体检"

# =============== 自检 ===============
self_check:
  - module_scale 已标
  - responsibilities 有 strength
  - coupling necessity 已标
  - 循环依赖已检测
  - 反模式已扫
  - 若有 codebase · 指标已算
  - co_change > 0.8 有 action

# =============== 下游契约 ===============
downstream_contract:
  to_042_service_decomposition:
    output_consumed: "modules + coupling → 服务拆分建议"
  
  to_N190_code_scaffold:
    output_consumed: "module_scale + boundary → 代码包结构"
  
  to_N180_planning:
    output_consumed: "module ↔ task mapping"
  
  to_N210_code_review:
    output_consumed: "反模式 · coupling 高的点 → CR 重点"
  
  to_architect_dashboard:
    output_consumed: "architecture_health_score → 架构治理指标"
```

---

## SKILL-042 · `service-decomposition-recommendation` v2.0.0

```yaml
skill_id: service-decomposition-recommendation
version: 2.0.0
category: 架构 / 服务拆分
status: active

# =============== 定位 ===============
purpose: |
  基于模块边界 · 建议服务数量与拆分方式 · 8 种 decomposition_driver 明示
  · cost_analysis 全面评估拆分代价 · Conway 法则对齐检查
  · 共享组件治理策略 · 演进路径(strangler / big-bang / hybrid)
  防止"微服务泛滥"或"单体过重"两极

# =============== 输入 ===============
input_schema:
  modules:
    required: true
    from: 041_module-boundary-identification
  
  organizational_context:
    required: true
    type: object
    properties:
      team_structure:
        type: array
        items:
          team_name: string
          size: integer
          domain: string
      total_engineers: integer
      ops_maturity:
        enum: [low, medium, high]     # 运维成熟度
  
  business_context:
    required: true
    type: object
    properties:
      peak_qps_estimate: string
      availability_sla: string
      growth_projection: enum[flat, steady, rapid, explosive]
      regulatory_zones: array
  
  existing_deployment:
    required: false                    # 迁移场景
    type: object

# =============== 输出 Schema ===============
output_schema:
  decomposition_recommendation:
    recommendation_id:
      pattern: "DEC-\\d{3,}"
    
    # -------- 推荐架构 --------
    recommended_architecture:
      style:
        enum: [monolith, modular_monolith, microservices, serverless, hybrid]
      
      service_count: integer
      
      services:
        type: array
        items:
          service_id: "SVC-\\d+"
          service_name: string
          contains_modules:
            type: array
            items: string              # MOD-xxx
          
          # -------- 8 种 Decomposition Driver --------
          decomposition_drivers:
            type: array
            items:
              driver:
                enum:
                  D1_business_subdomain:
                    meaning: "DDD subdomain · 独立业务领域"
                    weight: high
                  D2_scalability:
                    meaning: "扩容需求差异大"
                    weight: high
                  D3_availability:
                    meaning: "可用性 SLA 不同"
                    weight: medium
                  D4_compliance:
                    meaning: "合规隔离"
                    weight: high
                  D5_reusability:
                    meaning: "被多方复用"
                    weight: medium
                  D6_team_autonomy:
                    meaning: "不同团队独立演进"
                    weight: high
                  D7_technology_diversity:
                    meaning: "技术栈不同"
                    weight: low
                  D8_change_cadence:
                    meaning: "变更频率差异"
                    weight: medium
              rationale: string
              evidence: string
          
          ownership:
            owner_team: string
            on_call_team: string
          
          characteristics:
            expected_qps: string
            availability_target: string
            data_ownership: "own_db / shared_with_x"
            
          estimated_size:
            loc_estimate: integer
            engineer_count: integer
          
          deployment_strategy:
            enum: [shared_k8s, dedicated_k8s, serverless, vm]
          
          first_release_phase: integer # 1, 2, 3 ...
      
      shared_components:
        type: array
        items:
          component_name: string
          component_type:
            enum:
              utility_library: "共享工具库"
              sdk: "客户端 SDK"
              platform_service: "平台服务(如 notification)"
              shared_infrastructure: "共享基础设施"
          ownership_model:
            enum:
              inner_source: "内部开源 · 各服务可贡献"
              dedicated_team: "专门团队维护"
              rotating_owner: "轮值维护"
          versioning_policy: string
          deprecation_policy: string
    
    # -------- Cost Analysis --------
    cost_analysis:
      development_cost:
        initial_setup_pd: integer      # 基础设施搭建
        per_service_overhead_pd: integer
        total_estimated_pd: integer
      
      operational_cost:
        infrastructure_monthly: "$ amount"
        monitoring_overhead: "% of engineer time"
        on_call_burden: enum[low, medium, high]
      
      productivity_cost:
        local_dev_complexity:
          enum: [simple, moderate, complex]
        debugging_complexity:
          enum: [easy, medium, hard]
        cross_service_change_cost:
          enum: [low, medium, high]
      
      risk_cost:
        distributed_system_bugs: enum[rare, occasional, frequent]
        cascading_failures: enum[isolated, possible, likely]
        data_consistency_issues: enum[low, medium, high]
    
    # -------- Conway 对齐检查 --------
    conway_alignment:
      current_team_structure_map:
        type: array
        items:
          team: string
          currently_owns: array        # 现状拥有哪些模块
      
      proposed_service_to_team_map:
        type: array
        items:
          service_id: string
          proposed_owner: string
          alignment_quality:
            enum:
              aligned: "团队边界 = 服务边界"
              partially_aligned: "部分对齐"
              misaligned: "跨团队拥有"
          remediation_if_misaligned: string
      
      inverse_conway_maneuver:         # 是否需要反向康威
        required: bool
        description: "先调团队再拆服务"
        feasibility: enum[easy, medium, hard]
        time_to_realign: duration
    
    # -------- 演进路径 --------
    evolution_roadmap:
      strategy:
        enum:
          strangler_fig: "逐步替换 · 老系统渐弃"
          big_bang: "一次性切换(高风险)"
          hybrid: "核心 strangler · 边缘 big_bang"
          parallel_run: "新旧并行运行一段"
      
      phases:
        type: array
        items:
          phase_number: integer
          phase_name: string
          duration: duration
          scope: string
          
          deliverables:
            services_to_extract: array
            services_to_create: array
          
          validation_gates:
            type: array
            items: string
          
          rollback_possible: bool
          rollback_window: duration
          
          risks:
            type: array
            items:
              risk: string
              mitigation: string
    
    # -------- 决策树(何时选何种)--------
    decision_tree_reference:
      when_monolith:
        - "团队 < 5 人"
        - "业务领域未清晰"
        - "流量 < 100 QPS"
      
      when_modular_monolith:
        - "团队 5-20 人"
        - "单一业务领域"
        - "希望保留未来拆分灵活性"
      
      when_microservices:
        - "团队 > 20 人"
        - "明确的业务子域"
        - "不同服务 QPS / SLA 差异大"
        - "ops 成熟度高"
      
      when_serverless:
        - "事件驱动主导"
        - "流量突发且低均值"
        - "不想管基础设施"
    
    # -------- 组织前提 --------
    organizational_prerequisites:
      must_have_before_microservices:
        - "CI/CD 自动化成熟"
        - "监控 / 日志 / 链路追踪 就绪"
        - "on-call 体系"
        - "容器编排能力"
      
      current_readiness_score: integer  # 0-100
      gaps: array
      
      investment_needed_before_split:
        total_pd: integer
        timeline: duration

# =============== 规则 ===============
rules:
  R01_drivers_required_for_each_service:
    description: "每服务拆分必须声明 ≥ 1 decomposition_driver"
    on_violation: reject
  
  R02_cost_analysis_mandatory:
    description: "必做 cost_analysis · 防止'微服务泛滥'"
    on_violation: reject
  
  R03_conway_alignment_analyzed:
    description: "必分析 Conway 对齐 · misaligned 必给 remediation"
    on_violation: reject
  
  R04_prerequisites_checked_before_microservices:
    description: "推荐 microservices 前 · 必检查 organizational_prerequisites"
    on_violation:
      action: warn
      detail: "强烈建议先补足 prerequisites"
  
  R05_shared_components_have_ownership:
    description: "每 shared_component 必有 ownership_model"
    on_violation: reject
  
  R06_evolution_phases_have_rollback:
    description: "每 phase 必标 rollback_possible"
    on_violation: reject
  
  R07_avoid_premature_split:
    description: "若团队 < 10 人 · 建议先 modular_monolith"
    on_violation: warn

# =============== 算法 ===============
algorithms:
  service_count_estimation:
    description: "服务数量经验公式"
    guideline: |
      service_count ≈ engineer_count / 5 (±2)
      若 ops 成熟度低 · 减少 30%
      若业务领域清晰 · 可多
    constraints:
      min: 1
      max: engineer_count / 2          # 每人不超过 2 服务
  
  decomposition_driver_weighing:
    description: "多 driver 加权决定是否独立"
    scoring:
      D1_business_subdomain: 3
      D2_scalability: 3
      D3_availability: 2
      D4_compliance: 3
      D5_reusability: 2
      D6_team_autonomy: 3
      D7_technology_diversity: 1
      D8_change_cadence: 2
    threshold: "total_weight ≥ 6 · 考虑独立服务"
  
  conway_alignment_scoring:
    formula: |
      for each service:
        owners = teams_owning_modules_of_this_service
        alignment_score = 1 if len(owners) == 1 else 1/len(owners)
      overall = mean(alignment_scores)
  
  readiness_scoring:
    factors:
      ci_cd: 20
      monitoring: 20
      on_call: 15
      container_orchestration: 15
      distributed_tracing: 10
      service_mesh: 10
      feature_flagging: 10
  
  cost_estimation:
    per_service_overhead:
      base_infra: 30 pd
      monitoring_setup: 10 pd
      ci_cd_pipeline: 5 pd
      documentation: 5 pd
      team_onboarding: 10 pd
    ongoing_annual:
      infra_cost: varies_by_cloud
      on_call_burden: "5-15% engineer time per service"

# =============== 示例 ===============
examples:
  - example_id: ex-001
    description: "订单系统微服务拆分"
    recommendation_id: DEC-001
    
    recommended_architecture:
      style: microservices
      service_count: 5
      
      services:
        - service_id: SVC-001
          service_name: order-service
          contains_modules: [MOD-ORDER-001]
          decomposition_drivers:
            - driver: D1_business_subdomain
              rationale: "订单是独立业务领域"
              evidence: "DDD bounded context"
            - driver: D2_scalability
              rationale: "订单创建峰值 5x 平均 · 需独立扩容"
              evidence: "历史流量数据"
          ownership:
            owner_team: order_team
            on_call_team: order_team
          characteristics:
            expected_qps: "2000 peak"
            availability_target: "99.95%"
            data_ownership: own_db
          estimated_size:
            loc_estimate: 15000
            engineer_count: 4
          deployment_strategy: shared_k8s
          first_release_phase: 1
        
        - service_id: SVC-002
          service_name: payment-service
          contains_modules: [MOD-PAYMENT-001]
          decomposition_drivers:
            - driver: D4_compliance
              rationale: "PCI-DSS 隔离要求"
              evidence: "合规评审"
            - driver: D3_availability
              rationale: "支付 99.99% SLA · 高于订单"
          ownership:
            owner_team: payment_team
          first_release_phase: 1
        
        - service_id: SVC-003
          service_name: audit-service
          decomposition_drivers:
            - driver: D4_compliance
            - driver: D5_reusability
          first_release_phase: 2
        
        - service_id: SVC-004
          service_name: notification-service
        - service_id: SVC-005
          service_name: user-service
      
      shared_components:
        - component_name: common-dto
          component_type: utility_library
          ownership_model: inner_source
          versioning_policy: "semver · 每服务独立升级"
          deprecation_policy: "6 month deprecation window"
        
        - component_name: auth-sdk
          component_type: sdk
          ownership_model: dedicated_team
          versioning_policy: "semver · 强制升级 major 版本 3 月内"
    
    cost_analysis:
      development_cost:
        initial_setup_pd: 30
        per_service_overhead_pd: 10
        total_estimated_pd: 80
      operational_cost:
        infrastructure_monthly: "$8000"
        monitoring_overhead: "10% engineer time"
        on_call_burden: medium
      productivity_cost:
        local_dev_complexity: moderate
        debugging_complexity: medium
        cross_service_change_cost: medium
      risk_cost:
        distributed_system_bugs: occasional
        cascading_failures: possible
        data_consistency_issues: medium
    
    conway_alignment:
      proposed_service_to_team_map:
        - service_id: SVC-001
          proposed_owner: order_team
          alignment_quality: aligned
        - service_id: SVC-002
          proposed_owner: payment_team
          alignment_quality: aligned
        - service_id: SVC-004
          proposed_owner: platform_team
          alignment_quality: partially_aligned
          remediation_if_misaligned: "短期 platform 团队维护 · 6 个月后考虑专门团队"
      
      inverse_conway_maneuver:
        required: false
    
    evolution_roadmap:
      strategy: strangler_fig
      phases:
        - phase_number: 1
          phase_name: "Extract order + payment"
          duration: 8w
          scope: "从单体拆 2 个核心服务"
          deliverables:
            services_to_extract: [order-service, payment-service]
          validation_gates:
            - "API 契约测试全过"
            - "数据迁移 dry-run"
            - "灰度 10% 流量无异常"
          rollback_possible: true
          rollback_window: 2w
          risks:
            - risk: "数据迁移不一致"
              mitigation: "dual-write 4 周 + 对账"
        
        - phase_number: 2
          phase_name: "Add audit + user"
          duration: 6w
          rollback_possible: true
        
        - phase_number: 3
          phase_name: "Add notification"
          duration: 4w
    
    organizational_prerequisites:
      must_have_before_microservices:
        - "CI/CD 已就绪"
        - "监控体系 · 基本"
        - "on-call 流程"
      current_readiness_score: 75
      gaps:
        - "分布式追踪未覆盖"
        - "service mesh 无"
      investment_needed_before_split:
        total_pd: 20
        timeline: 4w

# =============== 独立使用模式 ===============
standalone_modes:
  advisory:
    description: "给建议 · 不决定"
    use_case: "架构评审输入"
  
  decision_support:
    description: "辅助具体决策"
    use_case: "CTO / 架构师决策会"
  
  migration_planning:
    description: "从单体迁到微服务的完整计划"
    use_case: "遗留系统改造"
  
  readiness_check:
    description: "仅评估组织 readiness"
    use_case: "决定是否启动拆分"

# =============== 自检 ===============
self_check:
  - 每服务有 decomposition_drivers
  - cost_analysis 完整
  - Conway 对齐分析
  - 组织 prerequisites 已检查
  - shared_components 有 ownership
  - evolution phases 有 rollback
  - 避免过早拆分(< 10 人 warn)

# =============== 下游契约 ===============
downstream_contract:
  to_N160_data_model:
    output_consumed: "service 边界 → DB 所有权"
  
  to_N170_nfr:
    output_consumed: "each service 的 NFR 目标"
  
  to_N180_planning:
    output_consumed: "evolution_phases → 项目规划"
  
  to_N280_deployment:
    output_consumed: "deployment_strategy → 部署编排"
  
  to_organization_development:
    output_consumed: "team alignment gaps → HR 调整"
```

---

## N140 节点契约

```yaml
node_level:
  shared_module_registry:
    description: "模块边界定义 · 跨 N140 / N190 / N210 共享"
  
  architecture_decision_records:
    adr_output: true
    format: "markdown · 归档到 docs/arch/"
  
  conway_alignment_as_constraint:
    description: "Conway alignment 影响到 N180 任务分派"
  
  aggregated_outputs:
    N140_architecture_plan.md:
      sections:
        - 1. 模块清单与指标
        - 2. 服务拆分建议
        - 3. Conway 对齐矩阵
        - 4. 成本分析
        - 5. 演进路线图
        - 6. 组织 readiness
```

---

**签发**:Claude · N140 · 2 skill 完整版 · 生产可用
