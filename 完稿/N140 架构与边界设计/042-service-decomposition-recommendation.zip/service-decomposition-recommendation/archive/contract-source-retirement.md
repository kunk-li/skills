# archived source note

The old `N140_Skills_v2.md` YAML-style design is historical input, not a live contract source. The live contract source for this package is `references/exact-contract.md`; shared N140 conventions live in `references/v2-alignment.md`, `references/downgrade-templates.md`, and `references/orchestration.md`.
