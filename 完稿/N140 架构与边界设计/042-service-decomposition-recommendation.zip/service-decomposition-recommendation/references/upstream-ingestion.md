# upstream ingestion: 042

Use this guide when 041, N130, or other structured upstream artifacts are present.

## Required behavior

Prefer 041 boundary facts over reconstructing boundaries. Preserve N130 ids and constraints so service decisions remain traceable.

## N130 and 041 to 042 mapping

| Upstream field | 042 target |
|---|---|
| N130 `analysis_id` | `derived_from.analysis_ref` |
| N130 `solution_id` | `derived_from.solution_ref` |
| 041 artifact id | `derived_from.boundary_artifact_ref` |
| N130 `decision_refs` | root `decision_refs`, preserving upstream ids |
| 041 `module_catalog` | `baseline_module_catalog` |
| 041 `coupling_inventory` | `communication_paths` and distributed cost |
| 041 `anti_split_constraints` | `constraints.anti_split_constraints` and `anti_split_warnings` |
| 041 `shared_component_candidates` | `shared_components_governance` |
| N130 `constraints_taxonomy` | hard constraints and driver evidence |
| N130 `assumptions_to_verify` | risk and readiness caveats |
| N130 `failure_modes_to_carry_forward` | risk cost and roadmap validation gates |
| N130 `defect_items_to_carry_forward` | downstream carry-forward |


## 041/N130 availability matrix

| 041 boundary map | N130 handoff | `derived_from.analysis_ref` | `derived_from.boundary_artifact_ref` | Readiness floor | Required handling |
|---|---|---|---|---|---|
| present | present | preserve N130 `analysis_id` | preserve 041 artifact id | constrained | consume 041 facts and N130 hard constraints; route back if the two conflict unsafely |
| present | absent | `null` | preserve 041 artifact id | constrained | set `external_context.enabled: true` with `reason_no_boundary_map` unused; explain that N130 traceability is unavailable |
| absent | present | preserve N130 `analysis_id` | `null` | provisional | create provisional `baseline_module_catalog` from N130 components and mark split decisions advisory |
| absent | absent | `null` | `null` | provisional | create provisional baseline from external context; do not exceed `provisional` unless strong code/runtime evidence exists |

## Conflict handling

Hard N130 constraints win over 041 soft hints, but preserve both. If a hard constraint requires splitting where 041 warns against split, recommend a staged or constrained roadmap and record the conflict.
