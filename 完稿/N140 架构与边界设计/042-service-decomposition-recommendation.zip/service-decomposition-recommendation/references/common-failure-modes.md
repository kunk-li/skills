# common failure modes

- Rebuilding boundaries instead of consuming 041. Fix by using `baseline_module_catalog` from 041 when available.
- Recommending microservices because drivers exist but ignoring costs. Fix by requiring full cost analysis.
- Treating Conway alignment as optional. Fix by declaring team fit and remediation.
- Ignoring anti-split constraints. Fix by applying S-R5.
- Hiding boundary defects. Fix by setting `route_back_to: boundary_analysis`.
- Keeping old `workflow_node` as the canonical route key. Fix by using `step_order` and `node_context`.
