# Common failure modes — service-decomposition-recommendation

## F1: rebuilding boundaries from scratch
Symptom: 041 output exists but the recommendation invents different module groupings without consuming or citing the boundary map.
Fix: always consume 041 output via `references/upstream-ingestion.md`. Use `baseline_module_catalog` from 041 as the starting point; divergence from it requires explicit rationale.

## F2: microservices recommended by default
Symptom: the recommendation jumps to microservices because "we should be cloud-native" without full cost analysis.
Fix: modular monolith or hybrid may be better. Every recommendation must complete all eight cost dimensions before concluding. The default is "stay" unless split drivers outweigh costs.

## F3: no anti-recommendation
Symptom: the output recommends OPT-A without stating which option was rejected and why.
Fix: `anti_recommendation` is mandatory. State the rejected option, the specific reason it was rejected, and the constraint that made it unsafe.

## F4: Conway alignment skipped
Symptom: services are defined without mapping them to teams, ownership, or organizational change.
Fix: every option must include `conway_alignment` assessment. A service with no clear owner cannot be recommended.

## F5: shared DB warnings hidden
Symptom: the design proposes two services that still write to the same database tables, but no warning is emitted.
Fix: shared DB writes across service boundaries require explicit `shared_db_risk` warnings and a staged migration plan. Accepting the risk is allowed; hiding it is not.

## F6: boundary defects not routed back
Symptom: 041 identified boundary defects (e.g., BRISK-001 shared DB) but the recommendation proceeds without resolving or explicitly accepting them.
Fix: set `route_back_to: boundary_analysis` when boundary defects make the recommendation unsafe. Only proceed when defects are resolved or explicitly accepted with rationale.

## F7: rollback conditions missing
Symptom: the evolution roadmap has phases but no phase states what triggers a rollback or hold.
Fix: every phase must have a `rollback_condition` — at minimum a feature flag or traffic routing mechanism that can revert to the previous state.

## F8: data ownership ambiguous
Symptom: services are defined but it is unclear which service owns which tables or aggregates.
Fix: every service recommendation must include explicit `data_ownership` — which tables, topics, or aggregates belong to that service and which are consumed read-only from others.
