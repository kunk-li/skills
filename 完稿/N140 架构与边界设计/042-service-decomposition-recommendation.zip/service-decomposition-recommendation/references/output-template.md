# output template: service decomposition recommendation

```yaml
artifact_header:
  artifact_id: "N140-ART-042-001"
  artifact_type: "service_decomposition_recommendation"
  schema_version: "n140.v2"
  producer_skill: "service-decomposition-recommendation"
  producer_version: "3.1.0"
  node_context: "n140"
  step_order: "2_of_2"
  readiness: "constrained"
  contract_status: "draft"
  route_back_to: "none"
  mode: "comparison"
  generated_at: "YYYY-MM-DDThh:mm:ssZ"
  derived_from: {}
  decision_refs: []
```

## 1. Decision summary

State split, delay, modular monolith, hybrid, or microservices recommendation.

## 2. Baseline and constraints

Show inherited 041 modules and N130 constraints.

## 3. Candidate options

Compare conservative, balanced, and aggressive options when possible.

## 4. Recommended architecture

List services, owned modules, drivers, ownership, data ownership, and communication paths.

## 5. Cost and Conway alignment

Evaluate development, deployment, operational, and distributed-complexity cost plus team fit.

## 6. Roadmap and gates

Provide phases, validation gates, rollback or hold conditions, and prerequisites.

## 7. Route-back, downstream handoff, and event payload

If boundary analysis must change, set route-back; otherwise provide downstream payloads.
