# n140 orchestration

This file is intentionally byte-identical in the 041 and 042 packages. It defines how the two skills operate alone and together.

## Node chain

- 041 `module-boundary-identification` is step `1_of_2` when producing a boundary map for N140.
- 042 `service-decomposition-recommendation` is step `2_of_2` when consuming a boundary map.
- Either skill may run as `standalone` when used outside N140.

## Standalone rule

Each skill must produce a useful artifact without the other skill. Standalone outputs must include an artifact header, explicit evidence profile, assumptions, readiness, and carry-forward items.

## Composition rule

When both skills are used:

1. Run 041 first and treat its boundary facts as the source of truth.
2. Pass 041 module catalog, owned resources, coupling inventory, risks, anti-split constraints, and confidence to 042.
3. 042 may recommend service grouping, but it must not silently override 041 boundary facts.
4. If 042 finds boundary defects, it must set `route_back_to: boundary_analysis` and provide return items instead of hiding the inconsistency.
5. If 041 is `provisional`, 042 cannot be stronger than `constrained` unless it adds independent evidence.

## Merge strategy

Do not add a third merger skill by default. Keep separate artifacts unless the caller asks for a single `N140_architecture_plan.md`. In that case, merge by sections:

1. executive decision summary from 042,
2. module map and evidence from 041,
3. service options and cost from 042,
4. return items and carry-forward risks from both,
5. downstream handoff for N150/N160/N170/N180/N190/N210/N280/N330.

## Route-back

`route_back_to` may be `none` or `boundary_analysis`. When it is `boundary_analysis`, include a non-empty return item with target artifact id, conflict summary, severity, and recommended action.

## Downstream discipline

N140 must declare downstream targets even when the immediate workflow edge is only N180. Event subscribers such as documentation, governance, and task management need the artifact contract to react without scraping report prose.
