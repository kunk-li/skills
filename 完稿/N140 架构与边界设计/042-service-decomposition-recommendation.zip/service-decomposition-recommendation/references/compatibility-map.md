# Compatibility map — service-decomposition-recommendation v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 041 module-boundary-identification | `decomposition_ready_handoff, anti_split_constraints[]` | `baseline_module_catalog` | must consume 041 output when present |
| 038 technical-solution-analysis | `constraint_taxonomy_summary, fmea_analysis[]` | `hard_constraints[], risk_inputs` | N130 constraints override 041 anti-split hints |
| N070 016 permission-matrix-extraction | `subject_kind, evaluation_algo` | `conway_alignment — team ownership` | team ownership → Conway alignment assessment |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| N180 planning | `evolution_roadmap, recommendation` | `delivery phases` | roadmap phases become sprint planning input |
| N330 documentation | `recommendation, anti_recommendation, cost_analysis` | `service decomposition document` | full recommendation consumed by N330 |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
