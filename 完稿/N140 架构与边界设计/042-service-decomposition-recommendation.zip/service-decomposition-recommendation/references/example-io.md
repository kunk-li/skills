# Example I/O

## Example input
Module boundary map from 041 with MOD-ORDER-001 and MOD-PAY-001, plus shared DB risk BRISK-001.

## Good output sketch

```yaml
metadata:
  artifact_schema_version: n140.v2.1.0
  skill_name: service-decomposition-recommendation
  input_mode: assessment
  readiness: constrained

baseline_module_catalog:
  consumed_from: 041
  modules: [MOD-ORDER-001, MOD-PAY-001]
  boundary_defects_present: [BRISK-001]

constraints:
  hard:
    - constraint: shared DB write transactions cannot span services
      source: BRISK-001
      effect: blocks immediate microservice split
  soft:
    - constraint: team size is 8 engineers
      effect: operational cost of microservices is high

candidate_options:
  - option_id: OPT-A
    name: modular monolith
    architecture_style: modular_monolith
    service_count: 1
    rationale: team size, shared DB, and unresolved boundary defects favor staying monolith with internal module isolation
    cost_analysis:
      development: low
      deployment: low
      operations: low
      local_dev: easy
      debugging: easy
      cross_service_change: n/a (same repo)
      on_call: single service to monitor
      distributed_system_risk: none

  - option_id: OPT-B
    name: extract payment as separate service (after DB split)
    architecture_style: service_extraction
    service_count: 2
    prerequisite: BRISK-001 must be resolved first (DB schema separation)
    cost_analysis:
      development: medium
      operations: higher on-call surface
      distributed_system_risk: payment saga complexity

  - option_id: OPT-C
    name: full microservices now
    architecture_style: microservices
    service_count: 4
    cost_analysis:
      distributed_system_risk: very high
      local_dev: docker-compose complexity

recommendation:
  chosen: OPT-A
  rationale: BRISK-001 blocks safe split; team size makes operations cost prohibitive; modular monolith allows domain isolation now with extraction path later.
  anti_recommendation:
    rejected: OPT-C
    reason: Distributed system risk is too high with unresolved shared DB and team of 8.

evolution_roadmap:
  - phase: 1
    name: resolve shared DB
    gate: BRISK-001 closed — payment tables in separate schema
    rollback_condition: if schema migration fails, revert via blue-green swap
  - phase: 2
    name: extract payment service
    gate: 3 months stable operation of phase 1
    rollback_condition: feature flag to route payment calls back to monolith

conway_alignment:
  current_team_structure: single cross-functional team
  target_match: modular monolith matches one-team ownership
```

## What makes this good
- Three options are compared — conservative, balanced, aggressive.
- Mandatory `anti_recommendation` explicitly names and justifies the rejected option.
- All 8 cost dimensions are assessed.
- Evolution roadmap has rollback conditions for each phase.
- `conway_alignment` connects team structure to the recommendation.

## ex-002 · anti-recommendation — why NOT to split now

```yaml
# Context: team of 6 engineers, boundary defect BRISK-001 (shared DB) unresolved
anti_recommendation:
  rejected_option: OPT-C  # full microservices now
  rejection_reason: "Three hard blockers prevent safe split at this time"
  blocking_factors:
    - factor: BRISK-001
      description: "Payment and Order share a DB write transaction — distributed transaction risk is unacceptable"
      resolution_required: "DB schema separation must complete before split"
    - factor: team_size
      description: "6 engineers cannot sustain two separate on-call rotations and two CI/CD pipelines simultaneously"
      resolution_required: "Team must grow to ≥10 before operational cost is acceptable"
    - factor: no_baseline_metrics
      description: "No production performance data — cannot justify scale-driven split"
      resolution_required: "Operate modular monolith for 6 months to gather baseline data"

  when_to_revisit:
    trigger_conditions:
      - "BRISK-001 resolved AND monthly orders > 1M AND team size ≥ 10"
    estimated_timeline: "Q3 2026 earliest"

# Negative case — what happens if we split anyway:
split_risk_simulation:
  scenario: "Force payment service extraction with shared DB still in place"
  consequences:
    - "Distributed transaction between OrderService and PaymentService — no ACID guarantee"
    - "Saga compensation complexity doubles development effort for 3 months"
    - "On-call incidents increase: 2 services to debug instead of 1"
    - "DB connection pool contention: both services compete for same DB resources"
  risk_level: critical
  recommendation: "Do not proceed. Stay with modular monolith until blockers resolved."
```

## ex-003 · constrained assessment with stable IDs

```yaml
metadata:
  artifact_schema_version: n140.v2.1.0
  skill_name: service-decomposition-recommendation
  selected_mode: assessment
  readiness: constrained
  step_order: 2_of_2

baseline_module_catalog:
  consumed_from_041: true
  modules:
    - module_id: MOD-ORDER-001
      name: OrderCore
      boundary_defects: [BRISK-001]
    - module_id: MOD-PAY-001
      name: PaymentGateway
      boundary_defects: [BRISK-001]

constraints:
  hard:
    - constraint_id: C-001
      constraint: "BRISK-001: shared DB write transaction blocks safe split"
      source: MOD-ORDER-001 + MOD-PAY-001
      resolution_required: true

recommendation:
  chosen_option: OPT-A  # modular monolith
  option_id: OPT-A
  rationale: "BRISK-001 unresolved; team size 6; no production metrics"
  readiness: constrained

anti_recommendation:
  rejected_option: OPT-B
  option_id: OPT-B
  rejection_reason: "BRISK-001 creates distributed transaction risk; team cannot sustain 2 on-call rotations"
  constraining_factor: C-001

rule_results:
  - {rule_id: R01_recommendation_has_anti_recommendation, severity: reject, result: pass}
  - {rule_id: R02_every_service_has_owner_and_data_ownership, severity: reject, result: not_applicable}
  - {rule_id: R03_cost_evaluated_across_eight_dimensions, severity: reject, result: pass}
  - {rule_id: R06_041_boundary_defects_routed_back_before_recommending, severity: warn, result: warn,
     evidence: "BRISK-001 present; recommendation constrained not blocked — monolith avoids the risk"}

contract_appendix:
  id_prefix: DECOMP
  produced_event: produced.n140.service_decomposition_recommendation.v2
  downstream_handoff:
    to_N180_planning: [recommendation.chosen_option, evolution_roadmap]
```

## ex-004 · blocked — boundary defects prevent safe recommendation

```yaml
skill_name: service-decomposition-recommendation
readiness: blocked
blocker_mapping: B-N140-02
route_back_to: module-boundary-identification

blockers:
  - blocker_id: BLK-DECOMP-001
    type: unresolved_boundary_defect
    defect_ref: BRISK-001
    description: "BRISK-001 (shared DB write across ORDER and PAYMENT) not resolved by 041 — any service split with this defect creates distributed transaction risk"
    impact: "Cannot recommend service split; any option would require saga + compensation that the team cannot yet support"
    resolution_required: "BRISK-001 must be resolved before decomposition is safe"
    unblock_evidence: "Updated 041 output showing BRISK-001 resolved: separate schemas + outbox pattern designed"

  - blocker_id: BLK-DECOMP-002
    type: team_readiness
    description: "Team size is 4 engineers. Minimum viable team for 2-service architecture with independent on-call is 8."
    impact: "All decomposition options require team growth that is not planned in current roadmap"
    resolution_required: "Either delay split until team grows, or accept modular monolith with explicit timeline for revisit"
    unblock_evidence: "Product owner decision: accept delay or approve team growth investment"

recommendation_blocked: true
interim_guidance: "Maintain modular monolith until blockers resolved. Use module boundaries from 041 as internal package structure."
```
