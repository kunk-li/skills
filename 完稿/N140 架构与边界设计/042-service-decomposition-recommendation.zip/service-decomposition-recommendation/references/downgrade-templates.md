# n140 downgrade templates

This file is intentionally byte-identical in the 041 and 042 packages. It defines how to degrade gracefully without breaking downstream consumers.

## Readiness selection

Use `pass` only when the artifact has enough evidence, references, and internal consistency for downstream execution. Use `constrained` when the artifact is usable but bounded by known caveats. Use `provisional` when operating from weak or external context. Use `blocked` when the result would mislead downstream execution.

## Template: pass

```yaml
artifact_header:
  readiness: pass
  contract_status: review_ready
  route_back_to: none
quality_gate:
  status: pass
  blocking_items: []
  carry_forward_items: []
```

## Template: constrained

```yaml
artifact_header:
  readiness: constrained
  contract_status: draft
  route_back_to: none
quality_gate:
  status: constrained
  constraints:
    - id: "CONSTRAINT-001"
      impact: "what downstream must preserve"
      owner_or_evidence_needed: "who or what can remove it"
  carry_forward_items: []
```

## Template: provisional

```yaml
artifact_header:
  readiness: provisional
  contract_status: draft
  route_back_to: none
quality_gate:
  status: provisional
  missing_evidence:
    - "structured N130 handoff, codebase evidence, runtime data, or ownership evidence"
  assumptions:
    - id: "ASSUMP-001"
      statement: "clearly label inferred content"
      verification: "how to validate it later"
```

## Template: blocked

```yaml
artifact_header:
  readiness: blocked
  contract_status: blocked
  route_back_to: none
quality_gate:
  status: blocked
  blocking_items:
    - id: "BLOCK-001"
      reason: "why downstream use is unsafe"
      minimum_unblock_evidence: "the smallest evidence needed to continue"
```

## External context fallback

When no N130 artifact is available, set `node_context: external`, set `step_order: standalone`, populate `external_context`, and reduce readiness to `provisional` unless strong code/runtime evidence exists. External context may include PRD snippets, ADRs, code trees, architecture diagrams, incidents, postmortems, git history, or meeting notes.

## Promotion rules

- `provisional` may become `constrained` when at least one structured upstream source or concrete code/runtime source validates the key assumptions.
- `constrained` may become `pass` only when all reject-level consistency rules pass or are explicitly accepted with rationale.
- `blocked` may only be promoted after the named blocking item is resolved, not by rephrasing the conclusion.
