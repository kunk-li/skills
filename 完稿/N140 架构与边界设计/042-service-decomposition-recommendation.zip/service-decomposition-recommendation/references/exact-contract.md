# exact contract: service-decomposition-recommendation

Version: 3.1.0
Schema version: n140.v2
Artifact type: service_decomposition_recommendation
Canonical source: this file

## Canonical ids and patterns

- Service id: `SVC-[0-9]{3,}`.
- Decision id: preserve upstream ids; append local ids as `N140-042-DEC-[0-9]{3,}`.
- Recommendation id: `DEC-[0-9]{3,}`.
- Roadmap phase id: `PHASE-[0-9]{3,}`.

## Canonical enums

`architecture_style` values:

- `monolith`
- `modular_monolith`
- `microservices`
- `serverless`
- `hybrid`

`decomposition_driver` values:

- `D1_business_domain`
- `D2_scalability`
- `D3_availability`
- `D4_compliance`
- `D5_reusability`
- `D6_team_ownership`
- `D7_technology_diversity`
- `D8_deployment_cadence`

`route_back_to` values:

- `none`
- `boundary_analysis`

## Required artifact shape

```yaml
artifact_header: {} # use references/v2-alignment.md exactly; mirror `route_back_to` at root for backward compatibility

derived_from:
  analysis_ref: "TSA-001 | null"
  solution_ref: "SOL-001 | null"
  boundary_artifact_ref: "N140-041 artifact id | null"
  review_pack_ref: "REVIEW-001 | null"
  upstream_artifact_refs: []
  rule: "analysis_ref and boundary_artifact_ref are required when structured inputs exist; null is allowed only when external_context is populated"

external_context:
  enabled: false
  sources: []
  reason_no_boundary_map: null
  readiness_floor: provisional

decision_refs: []

baseline_module_catalog:
  source: "041 | provisional | mixed"
  inherited_module_ids: []
  provisional_module_ids: []
  rule: "when 041 is present, inherited_module_ids must be a complete or explicitly justified subset of 041.module_catalog; when 041 is absent, provisional_module_ids must be non-empty unless readiness is blocked"

constraints:
  compliance: []
  data_ownership: []
  transactions: []
  availability: []
  team_capacity: []
  deployment: []
  anti_split_constraints: []

candidate_options:
  - option_id: "OPT-001"
    label: "conservative | balanced | aggressive | custom"
    architecture_style: "modular_monolith"
    service_count: 1
    services: []
    benefits: []
    costs: []
    confidence: "high | medium | low"

recommended_architecture:
  recommendation_id: "DEC-001"
  style: "modular_monolith"
  service_count: 1
  services:
    - service_id: "SVC-001"
      service_name: "example-service"
      owned_modules: []
      decomposition_drivers:
        - driver: "D1_business_domain"
          rationale: "why this service may stand alone"
          evidence_refs: []
      owner_team: null
      on_call_team: null
      data_ownership: "own_db | shared_with_rationale | no_db"
      communication_paths: []
      availability_target: null
      deployment_strategy: null
      first_release_phase: null

service_cost_analysis:
  development: []
  deployment: []
  operational: []
  distributed_complexity: []
  productivity: []
  risk: []

conway_alignment:
  team_map: []
  alignment_quality: "aligned | partially_aligned | misaligned | unknown"
  inverse_conway_required: false
  remediation_items: []

shared_components_governance: []

anti_split_warnings: []

route_back_to: "none" # compatibility mirror of artifact_header.route_back_to
boundary_analysis_return_items: []

evolution_roadmap:
  strategy: "strangler_fig | big_bang | hybrid | parallel_run | hold"
  phases:
    - phase_id: "PHASE-001"
      name: "phase name"
      scope: "scope"
      validation_gates: []
      rollback_possible: true
      rollback_rationale: null
      hold_conditions: []

anti_recommendation:
  what_not_to_do: []
  rationale: []

downstream_targets:
  - N150
  - N160
  - N170
  - N180
  - N280
  - N330

downstream_handoff:
  to_N150: []
  to_N160: []
  to_N170: []
  to_N180: []
  to_N280: []
  to_N330: []
  defect_items_to_carry_forward: []

produced_events:
  - produced.service_decomposition.v1
  - produced.service_decomposition_return.v1

subscribed_events:
  - produced.module_boundary_map.v1
  - produced.solution_review_pack.v1
  - produced.defect_found.v1

adjacent_nodes_to_notify:
  - N150
  - N160
  - N170
  - N180
  - N280
  - N330

consistency_check:
  status: "pass | constrained | provisional | blocked"
  rule_results: []

event_payload: {} # use references/v2-alignment.md
```

## Schema rules

- Every serious option must include drivers, cost, owner evidence or owner gap, data ownership, and communication implications.
- Every recommended service must include at least one decomposition driver with rationale and evidence.
- Cost analysis must cover development, deployment, operational, and distributed-complexity dimensions.
- Every roadmap phase must declare rollback or an explicit rationale for no rollback.
- If route back is needed, both `artifact_header.route_back_to` and root `route_back_to` must be `boundary_analysis`, and `boundary_analysis_return_items` must be non-empty.
- When 041 output is present, `baseline_module_catalog.inherited_module_ids` must preserve 041 module ids or explicitly justify exclusions; when 041 is absent, `baseline_module_catalog.provisional_module_ids` must be non-empty unless readiness is `blocked`.
- Upstream `decision_refs`, `assumptions_to_verify`, `failure_modes_to_carry_forward`, and `defect_items_to_carry_forward` must survive in this artifact or be listed as unresolved carry-forward items.
