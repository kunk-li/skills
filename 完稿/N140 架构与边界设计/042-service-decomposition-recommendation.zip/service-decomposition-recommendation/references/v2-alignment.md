# n140 shared v2 alignment

This file is intentionally byte-identical in the 041 and 042 packages. Keep it synchronized with the N140 node family before packaging.

## Contract single-source rule

- `SKILL.md` is the flow/control plane.
- `references/exact-contract.md` is the schema/control point for each skill.
- `references/v2-alignment.md`, `references/downgrade-templates.md`, and `references/orchestration.md` are shared N140 node conventions and must be byte-identical across 041 and 042.
- Do not maintain an independent YAML design source. If an old YAML document exists, treat it as archived historical input and point readers to `references/exact-contract.md`.

## Shared artifact header

Every N140 artifact must start with this 14-field header before any narrative content:

```yaml
artifact_header:
  artifact_id: "N140-ART-<short-id>"
  artifact_type: "<skill-specific-type>"
  schema_version: "n140.v2"
  producer_skill: "<skill-id>"
  producer_version: "<semver>"
  node_context: "n140 | external"
  step_order: "1_of_2 | 2_of_2 | standalone"
  readiness: "pass | constrained | provisional | blocked"
  contract_status: "draft | review_ready | blocked"
  route_back_to: "none | boundary_analysis"
  mode: "<skill-specific-mode>"
  generated_at: "<iso-8601>"
  derived_from: {}
  decision_refs: []
```

## Readiness and contract status

- `pass`: artifact is complete enough for downstream machine-readable use.
- `constrained`: artifact is usable but has explicit limits that downstream consumers must carry.
- `provisional`: artifact is useful as advisory output but lacks upstream structure or evidence.
- `blocked`: artifact cannot be safely consumed until named missing evidence or conflicts are resolved.

Map `contract_status` from readiness unless there is a stronger local reason:

- readiness `pass` -> `contract_status: review_ready`
- readiness `constrained` or `provisional` -> `contract_status: draft`
- readiness `blocked` -> `contract_status: blocked`

Use `route_back_to: none` for normal 041 output and normal 042 output. Use `route_back_to: boundary_analysis` only when 042 requires 041 to revise boundary analysis before the service recommendation can be safely consumed.

## Event naming

N140 declares events even when no physical event bus is available. The declaration is part of the contract and can be activated later by workflow infrastructure.

- `produced.module_boundary_map.v1`: emitted by 041 after producing a boundary map.
- `produced.service_decomposition.v1`: emitted by 042 after producing a service recommendation.
- `produced.service_decomposition_return.v1`: emitted by 042 when `route_back_to` asks 041 to revise boundary analysis.
- `exception.boundary_constraint_violated.v1`: emitted when a critical boundary consistency rule fails.

Minimum event payload:

```yaml
event_payload:
  event_name: "<event-name>"
  artifact_id: "<artifact_header.artifact_id>"
  schema_version: "n140.v2"
  readiness: "<artifact_header.readiness>"
  artifact_path: "<path-or-title>"
  derived_from: {}
  affected_nodes: []
  return_items: []
```

`affected_nodes` is the event-bus routing subset derived from `adjacent_nodes_to_notify`; `adjacent_nodes_to_notify` remains the artifact-level documentation field. Use `affected_nodes` for event filtering and use `adjacent_nodes_to_notify` for human-readable and downstream handoff visibility.

## Deprecation note

Use `step_order` and `node_context` for generic reuse. Do not require `workflow_node` in newly produced artifacts. If an old consumer still expects `workflow_node`, provide it only as a deprecated compatibility alias in narrative notes, not as the canonical header key.
