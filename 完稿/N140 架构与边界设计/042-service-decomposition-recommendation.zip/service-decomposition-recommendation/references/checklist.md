# checklist

Before finalizing 042 output:

- The artifact starts with the shared 14-field header.
- `schema_version` is `n140.v2`.
- `step_order` is `2_of_2` or `standalone`.
- The live schema source is `references/exact-contract.md`.
- 041 boundary facts are consumed when present.
- Each option has drivers, cost, data ownership, communication paths, and owner evidence or owner gap.
- Conway alignment and operational readiness are assessed.
- Anti-split constraints survive as warnings or explicit overrides.
- SU-R1, SU-R2, and S-R1 through S-R6 are evaluated.
- Route-back is populated when boundary analysis must change.
- Event payload and downstream targets are present.
