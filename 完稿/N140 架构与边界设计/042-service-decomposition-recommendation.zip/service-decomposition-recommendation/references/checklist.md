# Delivery checklist — service-decomposition-recommendation

## A. artifact header
- [ ] Shared 14-field header from `v2-alignment.md`
- [ ] `schema_version: n140.v2`
- [ ] `step_order: 2_of_2` or `standalone`
- [ ] `selected_mode` declared at top

## B. baseline consumption
- [ ] 041 output consumed when present (baseline_module_catalog from 041)
- [ ] If 041 is provisional, this recommendation is at most `constrained`
- [ ] Boundary defects from 041 explicitly addressed or `route_back_to: boundary_analysis` set

## C. candidate options
- [ ] At least conservative, balanced, and aggressive options in `comparison` mode
- [ ] Each option has: `architecture_style`, `service_count`, `owned_modules[]`, `data_ownership`, `communication_paths[]`, `owner`, `cost_analysis`, `readiness`, `risks[]`

## D. eight-dimension cost analysis
All eight cost dimensions assessed for the recommended option:
- [ ] `development` cost delta
- [ ] `deployment` complexity delta
- [ ] `operations` on-call surface delta
- [ ] `local_dev` setup complexity
- [ ] `debugging` cross-service trace overhead
- [ ] `cross_service_change` coordination cost
- [ ] `on_call` rotation burden
- [ ] `distributed_system_risk` (saga, eventual consistency, network partition)

## E. recommendation + anti-recommendation
- [ ] `recommendation` names chosen option with rationale
- [ ] `anti_recommendation` explicitly names rejected option, rejection reason, and constraining factor

## F. Conway alignment
- [ ] Team structure mapped to service ownership
- [ ] Gaps between current teams and required ownership called out
- [ ] Remediation plan for Conway misalignment stated

## G. evolution roadmap
- [ ] Phases defined with: name, prerequisite gates, validation criteria
- [ ] Every phase has a `rollback_condition`
- [ ] Hold conditions (when to stop and reassess) stated

## H. v2 contract
- [ ] `produced_event: produced.n140.service_decomposition_recommendation.v2`
- [ ] `blocker_mapping: B-N140-02`
- [ ] `rule_results[]` covers R01-R06
- [ ] `feedback_signal_to_n005` populated

## One-vote rejection items
- [ ] `anti_recommendation` absent
- [ ] Eight-dimension cost incomplete (any dimension missing)
- [ ] Evolution roadmap without rollback conditions
- [ ] Data ownership not assigned per service
