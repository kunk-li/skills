# scoring rubric

Score each output from 0 to 100.

- Contract compliance: 20
- Boundary consumption: 15
- Candidate and driver quality: 20
- Cost and readiness analysis: 20
- Conway and governance quality: 15
- Roadmap and rollback quality: 10

## Readiness mapping

Use the score as a ceiling, then downgrade further for unresolved reject-level rules.

| Score range | Maximum readiness | Contract status | Notes |
|---|---|---|---|
| 85-100 | pass | review_ready | Recommendation is execution-grade; drivers, cost, ownership, roadmap, and rollback are all complete. |
| 70-84 | constrained | draft | Recommendation is usable with named constraints, staged mitigations, or explicit anti-split warnings. |
| 50-69 | provisional | draft | Advisory only; boundary evidence, ownership, or operational readiness is incomplete. |
| 0-49 | blocked | blocked | Unsafe for downstream consumption unless the user explicitly requests a rough brainstorm. |

If `route_back_to: boundary_analysis` is set, readiness cannot exceed `constrained`. If baseline modules are provisional and no independent evidence closes the gap, readiness cannot exceed `provisional`.
