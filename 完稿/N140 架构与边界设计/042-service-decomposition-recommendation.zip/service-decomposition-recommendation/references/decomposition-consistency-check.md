# decomposition consistency check

Run these checks before finalizing 042 output. Each rule must appear in `consistency_check.rule_results`.

## Upstream handoff rules

| Rule | Check | Violation |
|---|---|---|
| SU-R1 | If a service uses a compliance driver, evidence must reference a concrete upstream compliance or operational constraint id when available. | reject |
| SU-R2 | Every upstream defect carry-forward item must appear in service rationale, cost analysis, anti-split warning, roadmap gate, downstream handoff, or unresolved item. | reject |

## Internal rules

| Rule | Check | Violation |
|---|---|---|
| S-R1 | Each recommended service owned module must exist in 041 module catalog, or in 042 provisional baseline when 041 is absent. | reject |
| S-R2 | Every recommended service must include at least one driver with non-empty rationale and evidence. | reject |
| S-R3 | Every candidate option must include development, deployment, operational, and distributed-complexity cost signals. | reject |
| S-R4 | Every roadmap phase must declare `rollback_possible`; if false, include rationale. | reject |
| S-R5 | Each 041 anti-split constraint must appear in 042 anti-split warnings unless explicitly overridden with rationale. | reject |
| S-R6 | When 041 is present, `baseline_module_catalog.inherited_module_ids` must preserve 041 module ids or explicitly justify exclusions; when 041 is absent, `baseline_module_catalog.provisional_module_ids` must be non-empty unless readiness is blocked. | reject |

## Route-back rule

If S-R1 or S-R5 fails because 041 is internally inconsistent, set `route_back_to: boundary_analysis` and populate `boundary_analysis_return_items` instead of making a stronger recommendation.
