#!/usr/bin/env python3
"""Validate N140 reference synchronization for one skill package.

Checks implemented from v3.1.1 governance:
- G-NEW-1: rule-id references in references/*.md resolve to a consistency-check definition.
- G-NEW-2: all "N-field header" mentions match the authoritative header in v2-alignment.md.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ID_PATTERN = re.compile(r"\b(?:B-R|S-R|SU-R)\d+\b")
RANGE_PATTERN = re.compile(
    r"\b(?P<prefix>B-R|S-R|SU-R)(?P<start>\d+)\s*(?:through|to|~|-)\s*(?:(?P=prefix))?(?P<end>\d+)\b"
)
HEADER_MENTION_PATTERN = re.compile(r"\b(?P<count>\d+)-field header\b")
HEADER_FIELD_PATTERN = re.compile(r"^\s{2}([A-Za-z_][A-Za-z0-9_]*)\s*:", re.MULTILINE)


def expand_rule_ids(text: str) -> set[str]:
    ids = set(ID_PATTERN.findall(text))
    for match in RANGE_PATTERN.finditer(text):
        prefix = match.group('prefix')
        start = int(match.group('start'))
        end = int(match.group('end'))
        lo, hi = sorted((start, end))
        ids.update(f"{prefix}{idx}" for idx in range(lo, hi + 1))
    return ids


def load_authoritative_header_count(alignment_path: Path) -> int:
    text = alignment_path.read_text(encoding='utf-8')
    declared_match = re.search(r"this\s+(\d+)-field header", text)
    if not declared_match:
        raise ValueError(f"Cannot find declared header count in {alignment_path}")
    declared = int(declared_match.group(1))

    block_match = re.search(r"artifact_header:\n(?P<body>.*?)(?:\n```)", text, flags=re.DOTALL)
    if not block_match:
        raise ValueError(f"Cannot find artifact_header YAML block in {alignment_path}")
    fields = HEADER_FIELD_PATTERN.findall(block_match.group('body'))
    actual = len(fields)
    if declared != actual:
        raise ValueError(
            f"Header count mismatch in {alignment_path}: declared {declared}, actual {actual} ({fields})"
        )
    return declared


def main() -> int:
    skill_root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    refs = skill_root / 'references'
    if not refs.is_dir():
        print(f"ERROR: references directory not found: {refs}", file=sys.stderr)
        return 2

    alignment = refs / 'v2-alignment.md'
    if not alignment.exists():
        print(f"ERROR: v2-alignment.md not found: {alignment}", file=sys.stderr)
        return 2

    failures: list[str] = []
    try:
        header_count = load_authoritative_header_count(alignment)
    except Exception as exc:  # noqa: BLE001 - CLI validator should report all context clearly
        failures.append(str(exc))
        header_count = None

    consistency_files = sorted(refs.glob('*consistency-check.md'))
    definitions: set[str] = set()
    for path in consistency_files:
        definitions.update(expand_rule_ids(path.read_text(encoding='utf-8')))

    if not definitions:
        failures.append('No rule definitions found in *consistency-check.md')

    for path in sorted(refs.glob('*.md')):
        text = path.read_text(encoding='utf-8')
        for mentioned in HEADER_MENTION_PATTERN.finditer(text):
            if header_count is not None and int(mentioned.group('count')) != header_count:
                failures.append(
                    f"{path.relative_to(skill_root)} mentions {mentioned.group('count')}-field header; expected {header_count}-field header"
                )
        for rule_id in sorted(expand_rule_ids(text)):
            if rule_id not in definitions:
                failures.append(
                    f"{path.relative_to(skill_root)} references undefined rule id {rule_id}"
                )

    if failures:
        print('N140 reference validation failed:')
        for item in failures:
            print(f"- {item}")
        return 1

    print(f"N140 reference validation passed: {len(definitions)} rule ids, {header_count}-field header")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
