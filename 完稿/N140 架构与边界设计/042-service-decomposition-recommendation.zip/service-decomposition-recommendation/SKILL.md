---
name: service-decomposition-recommendation
description: recommend service decomposition with anti-recommendations, conway alignment, and eight-dimension cost assessment. triggers on 模块边界分析.md.
---
# service-decomposition-recommendation


## Trigger conditions
Recommend service decomposition when any of the following are present:
- output from `module-boundary-identification` (`模块边界分析.md`)
- N130 solution analysis with architecture decisions
- explicit 'should we split?' or 'extract this service' requests
- migration from monolith requests

## Standalone rule
Use `input_mode: assessment`. If 041 output is absent, create a provisional `baseline_module_catalog` from available evidence and cap `readiness: provisional` or `constrained`.

## Purpose

Recommend service decomposition as a general-purpose architecture decision skill. It must work alone and become stronger when it consumes a `module-boundary-identification` boundary map.

The skill answers: should we split, which option is safest, what cost and readiness constraints matter, how should ownership align, and what roadmap should downstream planning consume?


## Option comparison quick-reference
Use this matrix template in every `comparison` mode output.

| Dimension | Modular monolith | Service extraction | Full microservices |
|---|---|---|---|
| Development cost | low | medium (+30%) | high (+80%) |
| Deployment complexity | low (single artifact) | medium (2 pipelines) | high (N pipelines) |
| Operations on-call | low (1 service) | medium (2 services) | high (N services) |
| Local dev setup | easy (1 process) | medium (docker-compose) | hard (service mesh) |
| Debugging | easy (single trace) | medium (2-hop trace) | hard (distributed trace) |
| Cross-service change | n/a (same repo) | medium (contract change) | hard (API versioning) |
| On-call rotation | 1 team | 1-2 teams | 1 team per service |
| Distributed system risk | none | saga/outbox for 1 boundary | full distributed risk |

**Decision rule**: choose `modular monolith` unless at least 3 of these are true:
1. Different scaling requirements per domain
2. Different deployment cadences per team
3. Team size ≥ 10 with clear ownership split
4. Boundary defects (shared DB) already resolved
5. Production metrics show specific bottleneck requiring independent scaling

## Split/stay decision quick-reference
Use before generating options to pre-classify the recommendation direction.

| Signal | Indication |
|---|---|
| Different release cadences, clear team ownership split | candidate for split |
| Shared mutable database with cross-domain writes | stay modular-monolith or fix data ownership first |
| Single team owns all modules | modular-monolith preferred; split only for scale |
| Distributed transactions required between services | hard constraint against split |
| Clear bounded contexts with stable contracts | split viable |
| Org < 20 engineers | microservices cost likely exceeds benefit |

**Eight cost dimensions** (must assess all): development · deployment · operations · local-dev · debugging · cross-service-change · on-call · distributed-system-risk

**Anti-recommendation rule**: every recommendation MUST include an explicit `anti_recommendation` stating which option was rejected and why.


## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

Default mode: `assessment` when called without explicit mode instruction.

允许的模式：
- `readiness_check`: decide whether the organization and architecture are ready for a split before generating options
- `assessment`: decide split, delay, or stay modular-monolith — default mode
- `comparison`: compare conservative, balanced, and aggressive options with full cost analysis
- `planning`: produce a staged roadmap for a selected target with validation gates
- `migration_roadmap`: plan extraction from a monolith or legacy service set with strangler-fig or big-bang options

## Contract discipline

- Use `references/exact-contract.md` as the only skill-specific schema source.
- Use `references/v2-alignment.md` for the shared N140 artifact header and event conventions.
- Use `references/downgrade-templates.md` for four-level readiness handling.
- Use `references/orchestration.md` for standalone versus composed execution.
- Do not repeat canonical enum definitions from `exact-contract.md` in generated prose unless needed for the actual artifact.

## Input modes

Choose one mode and write it in the artifact header:

- `readiness_check`: decide whether the organization and architecture are ready for a split.
- `assessment`: decide split, delay, or stay modular-monolith.
- `comparison`: compare conservative, balanced, and aggressive options.
- `planning`: produce a staged roadmap for a selected target.
- `migration_roadmap`: plan extraction from a monolith or legacy service set.

## Core workflow

1. Start with the shared artifact header from `v2-alignment.md`.
2. Consume 041 output when present; otherwise create a provisional baseline and reduce readiness.
3. Ingest N130-derived constraints and ids when available using `upstream-ingestion.md`.
4. Identify hard constraints: compliance, data ownership, transactions, availability, team capacity, deployment limits, and anti-split constraints.
5. Generate options. In comparison mode, include conservative, balanced, and aggressive candidates.
6. For each candidate, define architecture style, service count, owned modules, data ownership, communication paths, ownership, cost, readiness, and risks.
7. Assign decomposition drivers with rationale and evidence.
8. Evaluate cost across development, deployment, operations, local development, debugging, cross-service change, on-call, and distributed-system risk.
9. Evaluate Conway alignment and shared-component governance.
10. Choose the recommendation and an explicit anti-recommendation.
11. Build an evolution roadmap with phases, validation gates, rollback or hold conditions, and prerequisites.
12. Run `decomposition-consistency-check.md`; route back to 041 if boundary defects make the recommendation unsafe.


## Confidence discipline
Every cost estimate, driver, and constraint must declare its epistemic status:
- `confidence: confirmed` — backed by production metrics, team ownership, or contractual obligation
- `confidence: inferred` — estimated from team size, system complexity, or past incidents
- `confidence: pending` — requires data collection before the recommendation can be strengthened

Separate confirmed and inferred evidence. A recommendation with mostly inferred evidence cannot exceed `readiness: constrained`.
## Design rules

- Do not recommend microservices by default; modular monolith or hybrid may be better.
- Never recommend a service without owner, data ownership, communication path, cost signal, and operational implication.
- If 041 is provisional, this recommendation cannot be stronger than constrained unless independent evidence closes the gap.
- Hard N130 constraints override 041 anti-split hints when they conflict; preserve both and explain the decision.
- Shared database writes across services require explicit warning and mitigation.
- Return a useful partial recommendation when blocked, with minimum unblock evidence.

## Output

Default to Markdown with a machine-readable YAML block at the top. Use `references/output-template.md` for a full report.

Required high-level sections:

1. artifact header,
2. upstream or external context,
3. baseline module catalog,
4. constraints,
5. candidate options,
6. recommended architecture,
7. drivers and evidence,
8. cost analysis,
9. Conway alignment,
10. shared-component governance,
11. anti-split warnings,
12. evolution roadmap,
13. downstream handoff,
14. consistency check and event payload.

## References

- `references/exact-contract.md`
- `references/v2-alignment.md`
- `references/downgrade-templates.md`
- `references/orchestration.md`
- `references/upstream-ingestion.md`
- `references/decomposition-consistency-check.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/scoring-rubric.md`

## v2 artifact contract additions

Add these fields to the shared artifact header from `v2-alignment.md`:

```yaml
artifact_schema_version: n140.v2.1.0
skill_name: service-decomposition-recommendation
produced_event: produced.n140.service_decomposition_recommendation.v2
blocker_mapping: B-N140-02
rule_results:
  - rule_id: R01_recommendation_has_anti_recommendation
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_every_service_has_owner_and_data_ownership
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R03_cost_evaluated_across_eight_dimensions
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R04_conway_alignment_assessed
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R05_evolution_roadmap_has_rollback_conditions
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R06_041_boundary_defects_routed_back_before_recommending
    severity: warn
    result: pass | warn | reject | not_applicable
feedback_signal_to_n005:
  signal_type: none | decomposition_risk_signal | org_constraint_pattern
  summary: ""
  target_n070_skills:
  - 013-requirement-breakdown
  - 016-permission-matrix-extraction
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
route_back_to: none | boundary_analysis | n130
# none             — recommendation complete; N180 may proceed
# boundary_analysis — service boundary conflicts with 041 module map; return to 041
# n130             — decomposition reveals architectural choice in 038 must be revised
eventbus_subscribers: [N330, N350]
# N330 → 服务拆分文档自动生成
# N350 → 协同任务发起（服务归属跨团队确认）
```

## Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| `需求结构拆解.md` (013) | domain boundaries | service candidate scope |
| `权限矩阵.md` (016) | subject_kind, evaluation_algo | conway alignment — team ownership |
| `数据对象目录.md` (017) | owner_module, ddd_role, source_of_truth | data ownership per service |
| `需求变更影响分析.md` (033) | impact_radius, rework estimates | cost and readiness constraints |
