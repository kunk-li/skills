---
name: service-decomposition-recommendation
description: recommend whether and how modules, bounded contexts, components, or existing services should become deployable services using boundary evidence, decomposition drivers, cost analysis, conway alignment, team ownership, operational readiness, data ownership, communication paths, shared-component governance, and staged evolution. use for standalone service split decisions, n140 service decomposition, migration planning, readiness checks, or composition after module-boundary-identification.
---
# service-decomposition-recommendation

## Purpose

Recommend service decomposition as a general-purpose architecture decision skill. It must work alone and become stronger when it consumes a `module-boundary-identification` boundary map.

The skill answers: should we split, which option is safest, what cost and readiness constraints matter, how should ownership align, and what roadmap should downstream planning consume?

## Contract discipline

- Use `references/exact-contract.md` as the only skill-specific schema source.
- Use `references/v2-alignment.md` for the shared N140 artifact header and event conventions.
- Use `references/downgrade-templates.md` for four-level readiness handling.
- Use `references/orchestration.md` for standalone versus composed execution.
- Do not repeat canonical enum definitions from `exact-contract.md` in generated prose unless needed for the actual artifact.

## Input modes

Choose one mode and write it in the artifact header:

- `readiness_check`: decide whether the organization and architecture are ready for a split.
- `assessment`: decide split, delay, or stay modular-monolith.
- `comparison`: compare conservative, balanced, and aggressive options.
- `planning`: produce a staged roadmap for a selected target.
- `migration_roadmap`: plan extraction from a monolith or legacy service set.

## Core workflow

1. Start with the shared artifact header from `v2-alignment.md`.
2. Consume 041 output when present; otherwise create a provisional baseline and reduce readiness.
3. Ingest N130-derived constraints and ids when available using `upstream-ingestion.md`.
4. Identify hard constraints: compliance, data ownership, transactions, availability, team capacity, deployment limits, and anti-split constraints.
5. Generate options. In comparison mode, include conservative, balanced, and aggressive candidates.
6. For each candidate, define architecture style, service count, owned modules, data ownership, communication paths, ownership, cost, readiness, and risks.
7. Assign decomposition drivers with rationale and evidence.
8. Evaluate cost across development, deployment, operations, local development, debugging, cross-service change, on-call, and distributed-system risk.
9. Evaluate Conway alignment and shared-component governance.
10. Choose the recommendation and an explicit anti-recommendation.
11. Build an evolution roadmap with phases, validation gates, rollback or hold conditions, and prerequisites.
12. Run `decomposition-consistency-check.md`; route back to 041 if boundary defects make the recommendation unsafe.

## Design rules

- Do not recommend microservices by default; modular monolith or hybrid may be better.
- Never recommend a service without owner, data ownership, communication path, cost signal, and operational implication.
- If 041 is provisional, this recommendation cannot be stronger than constrained unless independent evidence closes the gap.
- Hard N130 constraints override 041 anti-split hints when they conflict; preserve both and explain the decision.
- Shared database writes across services require explicit warning and mitigation.
- Return a useful partial recommendation when blocked, with minimum unblock evidence.

## Output

Default to Markdown with a machine-readable YAML block at the top. Use `references/output-template.md` for a full report.

Required high-level sections:

1. artifact header,
2. upstream or external context,
3. baseline module catalog,
4. constraints,
5. candidate options,
6. recommended architecture,
7. drivers and evidence,
8. cost analysis,
9. Conway alignment,
10. shared-component governance,
11. anti-split warnings,
12. evolution roadmap,
13. downstream handoff,
14. consistency check and event payload.

## References

- `references/exact-contract.md`
- `references/v2-alignment.md`
- `references/downgrade-templates.md`
- `references/orchestration.md`
- `references/upstream-ingestion.md`
- `references/decomposition-consistency-check.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/scoring-rubric.md`
