---
name: module-boundary-identification
description: identify module boundaries, responsibilities, coupling, and cycle risks from n130 inputs. always precedes service-decomposition-recommendation.
---
# module-boundary-identification


## Trigger conditions
Identify module boundaries when any of the following are present:
- structured N130 artifacts (`技术方案分析.md`, `技术方案初稿.md`)
- raw requirements, diagrams, ADRs, or PRD snippets
- explicit boundary analysis or module decomposition requests
- code repositories or architecture diagrams for reverse analysis

## Standalone rule
Use `input_mode: standalone_static` and set `readiness: provisional`. Map available evidence to the closest typed fields. All metrics without code evidence must be `fact_status: inferred`.

## Purpose

Identify module boundaries as a general-purpose architecture skill. It must work alone and become stronger when followed by `service-decomposition-recommendation`.

The skill answers: what are the responsibility boundaries, what evidence supports them, what coupling exists, what risks or anti-patterns are present, and what should downstream skills consume?

## Key enums quick-reference
`exact-contract.md` is authoritative; this section avoids a round-trip for common cases.

**`module_scale`**: `code_package` · `bounded_context` · `component` · `service` · `system`

**`coupling_necessity`**: `necessary` (unavoidable) · `designed` (intentional) · `shared` (incidental)

**`fact_status`**: `confirmed` (explicit evidence) · `inferred` (reasoned, must cite assumption) · `pending` (known gap, must resolve before stronger use)

**Key anti-patterns**: `god_module` · `feature_envy` · `circular_dependency` · `shared_mutable_state` · `distributed_monolith`

## Boundary decision quick-reference
| Signal | Likely boundary decision |
|---|---|
| Same state machine + same owning team | same module |
| Different deployment cadence + different team | separate module |
| Shared DB table with cross-domain joins | boundary risk — flag `shared_db_risk` |
| Cycle that cannot break without interface inversion | `constrained` — accept with rationale or block |
| High co-change rate AND same bounded context | consider merge |
| Low coupling + separate release cycle | candidate for split (decision deferred to 042) |

## Readiness downgrade quick-reference
| Evidence state | Max readiness | contract_status |
|---|---|---|
| Structured N130 artifacts present | pass | review_ready |
| Requirements or PRD only | constrained | draft |
| No structured upstream source | provisional | draft |
| Unresolved reject-level rule | blocked | blocked |


## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

Default mode: `upstream_assisted` when called without explicit mode instruction.

允许的模式：
- `standalone_static`: raw requirements, diagrams, ADRs, PRD snippets, or meeting notes only
- `upstream_assisted`: structured N130 artifacts or technical-solution artifacts available — default mode when N130 output exists
- `evidence_enriched`: code tree, dependency graph, runtime traces, git history, API/table ownership, or incident evidence available
- `co_change_focused`: main task is deciding merge, split, or contract-strengthening actions
- `anti_pattern_scan`: main task is a boundary smell scan to detect god_module, circular_dependency, or distributed_monolith patterns

## Contract discipline

- Use `references/exact-contract.md` as the only skill-specific schema source.
- Use `references/v2-alignment.md` for the shared N140 artifact header and event conventions.
- Use `references/downgrade-templates.md` for four-level readiness handling.
- Use `references/orchestration.md` for standalone versus composed execution.
- Do not repeat canonical enum definitions from `exact-contract.md` in generated prose unless needed for the actual artifact.

## Input modes

Choose one mode and write it in the artifact header:

- `standalone_static`: raw requirements, diagrams, ADRs, PRD snippets, or meeting notes only.
- `upstream_assisted`: structured N130 artifacts or technical-solution artifacts are available.
- `evidence_enriched`: code tree, dependency graph, runtime traces, git history, API/table ownership, or incident evidence is available.
- `co_change_focused`: the main task is deciding merge, split, or contract-strengthening actions.
- `anti_pattern_scan`: the main task is a boundary smell scan.

## Core workflow

1. Start with the shared artifact header from `v2-alignment.md`.
2. Ingest upstream N130 fields using `upstream-ingestion.md` when available.
3. If no upstream artifact exists, populate `external_context` and reduce readiness according to `downgrade-templates.md`.
4. Select one primary module scale and model mixed scales with parent/child relationships instead of flattening them.
5. Extract candidate modules from capabilities, state ownership, APIs, data objects, code structure, runtime interactions, team ownership, and change evidence.
6. For every module, define responsibilities, owned resources, in-boundary rules, out-of-boundary rules, confidence, and evidence.
7. Build the coupling inventory. Separate necessary, designed, and shared coupling, and attach evidence and contract status.
8. Calculate metrics only when evidence supports them. Mark heuristic metrics as inferred.
9. Detect boundary anti-patterns and carry forward upstream assumptions, failures, and defect items.
10. Produce `decomposition_ready_handoff` for 042 and `downstream_handoff` for N180/N190/N210/N330.
11. Run `boundary-consistency-check.md`; set readiness to the weakest justified level.

## Design rules

- Do not make final deployable service decisions. Provide constraints and handoff facts for 042.
- Preserve N130 ids when present, including decisions, assumptions, failure modes, and defects.
- Treat shared databases at service scale as a boundary risk unless there is explicit rationale and governance.
- Treat cycles as constrained or blocked unless explicitly accepted with rationale.
- Use the canonical `fact_status` field (`confirmed`, `inferred`, or `pending`) for facts that downstream consumers may rely on.
- Keep the artifact useful even when blocked: return the best partial map plus the minimum unblock evidence.

## Output

Default to Markdown with a machine-readable YAML block at the top. Use `references/output-template.md` for a full report.

Required high-level sections:

1. artifact header,
2. upstream or external context,
3. module catalog,
4. owned resources,
5. coupling inventory,
6. metrics and co-change hints,
7. boundary risks and anti-patterns,
8. anti-split constraints,
9. decomposition-ready handoff,
10. downstream handoff,
11. consistency check and event payload.

## References

- `references/exact-contract.md`
- `references/v2-alignment.md`
- `references/downgrade-templates.md`
- `references/orchestration.md`
- `references/upstream-ingestion.md`
- `references/boundary-consistency-check.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/scoring-rubric.md`

## v2 artifact contract additions

Add these fields to the shared artifact header from `v2-alignment.md`:

```yaml
artifact_schema_version: n140.v2.1.0
skill_name: module-boundary-identification
produced_event: produced.n140.module_boundary_map.v2
blocker_mapping: B-N140-01
rule_results:
  - rule_id: R01_every_module_has_responsibilities
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_coupling_inventory_complete
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R03_cycles_accepted_or_blocked
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R04_n130_ids_preserved
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R05_decomposition_ready_handoff_present
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R06_shared_db_risk_noted
    severity: warn
    result: pass | warn | reject | not_applicable
feedback_signal_to_n005:
  signal_type: none | boundary_smell_detected | coupling_pattern_signal
  summary: ""
  target_n070_skills:
  - 013-requirement-breakdown
  - 017-data-object-identification
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
route_back_to: none | boundary_analysis
# none             — boundary map is complete; 042 may proceed
# boundary_analysis — 042 found that boundary assumptions need revision; return to 041
eventbus_subscribers: [N330, N350]
# N330 → 模块设计说明文档自动生成
# N350 → 协同任务发起（模块归属变更需跨团队对齐）
```

## Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| `需求结构拆解.md` (013) | L1 domain, L2 capability | module candidate extraction |
| `业务规则清单.md` (014) | RULE-* cross-domain refs | coupling inventory evidence |
| `数据对象目录.md` (017) | OBJ-* owner_module, ddd_role, relationships[] | boundary.same_service, consistency_mode |
| `需求变更影响分析.md` (033) | impact dimensions | boundary risk notes |
