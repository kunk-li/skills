---
name: module-boundary-identification
description: identify reusable module, component, bounded context, service, or system boundaries from requirements, technical solution artifacts, code structure, architecture diagrams, runtime evidence, ownership context, or legacy-system notes. use when you need a standalone boundary map, n140 architecture boundary analysis, anti-pattern detection, co-change reasoning, decomposition-ready handoff, or upstream n130 technical-solution handoff preservation before service decomposition.
---
# module-boundary-identification

## Purpose

Identify module boundaries as a general-purpose architecture skill. It must work alone and become stronger when followed by `service-decomposition-recommendation`.

The skill answers: what are the responsibility boundaries, what evidence supports them, what coupling exists, what risks or anti-patterns are present, and what should downstream skills consume?

## Contract discipline

- Use `references/exact-contract.md` as the only skill-specific schema source.
- Use `references/v2-alignment.md` for the shared N140 artifact header and event conventions.
- Use `references/downgrade-templates.md` for four-level readiness handling.
- Use `references/orchestration.md` for standalone versus composed execution.
- Do not repeat canonical enum definitions from `exact-contract.md` in generated prose unless needed for the actual artifact.

## Input modes

Choose one mode and write it in the artifact header:

- `standalone_static`: raw requirements, diagrams, ADRs, PRD snippets, or meeting notes only.
- `upstream_assisted`: structured N130 artifacts or technical-solution artifacts are available.
- `evidence_enriched`: code tree, dependency graph, runtime traces, git history, API/table ownership, or incident evidence is available.
- `co_change_focused`: the main task is deciding merge, split, or contract-strengthening actions.
- `anti_pattern_scan`: the main task is a boundary smell scan.

## Core workflow

1. Start with the shared artifact header from `v2-alignment.md`.
2. Ingest upstream N130 fields using `upstream-ingestion.md` when available.
3. If no upstream artifact exists, populate `external_context` and reduce readiness according to `downgrade-templates.md`.
4. Select one primary module scale and model mixed scales with parent/child relationships instead of flattening them.
5. Extract candidate modules from capabilities, state ownership, APIs, data objects, code structure, runtime interactions, team ownership, and change evidence.
6. For every module, define responsibilities, owned resources, in-boundary rules, out-of-boundary rules, confidence, and evidence.
7. Build the coupling inventory. Separate necessary, designed, and shared coupling, and attach evidence and contract status.
8. Calculate metrics only when evidence supports them. Mark heuristic metrics as inferred.
9. Detect boundary anti-patterns and carry forward upstream assumptions, failures, and defect items.
10. Produce `decomposition_ready_handoff` for 042 and `downstream_handoff` for N180/N190/N210/N330.
11. Run `boundary-consistency-check.md`; set readiness to the weakest justified level.

## Design rules

- Do not make final deployable service decisions. Provide constraints and handoff facts for 042.
- Preserve N130 ids when present, including decisions, assumptions, failure modes, and defects.
- Treat shared databases at service scale as a boundary risk unless there is explicit rationale and governance.
- Treat cycles as constrained or blocked unless explicitly accepted with rationale.
- Use the canonical `fact_status` field (`confirmed`, `inferred`, or `pending`) for facts that downstream consumers may rely on.
- Keep the artifact useful even when blocked: return the best partial map plus the minimum unblock evidence.

## Output

Default to Markdown with a machine-readable YAML block at the top. Use `references/output-template.md` for a full report.

Required high-level sections:

1. artifact header,
2. upstream or external context,
3. module catalog,
4. owned resources,
5. coupling inventory,
6. metrics and co-change hints,
7. boundary risks and anti-patterns,
8. anti-split constraints,
9. decomposition-ready handoff,
10. downstream handoff,
11. consistency check and event payload.

## References

- `references/exact-contract.md`
- `references/v2-alignment.md`
- `references/downgrade-templates.md`
- `references/orchestration.md`
- `references/upstream-ingestion.md`
- `references/boundary-consistency-check.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/scoring-rubric.md`
