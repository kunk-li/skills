# Delivery checklist — module-boundary-identification

## A. artifact header
- [ ] Shared 14-field header present from `v2-alignment.md`
- [ ] `schema_version: n140.v2`
- [ ] `step_order: 1_of_2` or `standalone`
- [ ] `selected_mode` declared at top

## B. module catalog
- [ ] Every module has: `module_id`, `scale`, `responsibilities[]`, `in_boundary[]`, `out_of_boundary[]`, `owned_resources`, `confidence`, `evidence[]`
- [ ] `fact_status` (`confirmed/inferred/pending`) used for all facts downstream skills rely on
- [ ] Mixed scales use parent/child, not flat list

## C. coupling inventory
- [ ] Every coupling edge has: `from`, `to`, `coupling_type`, `necessity`, `contract_status`, `evidence[]`
- [ ] `necessity` uses canonical enum: `necessary | designed | shared`
- [ ] Shared DB at service scale is always listed as a risk
- [ ] Any cross-boundary coupling marked contract-less / stub-only carries a cited contract-surface inventory (exported api/contract modules, same-process injectable services, existing cross-boundary invocation idioms — all three searched); see `common-failure-modes.md` F9

## D. cycle handling
- [ ] All cycles explicitly `constrained` (with rationale + governance) or `blocked`
- [ ] No cycle passes silently without a decision

## E. upstream ID preservation
- [ ] N130 decision IDs, assumption IDs, and FMEA IDs referenced in `evidence[]` when present
- [ ] Defect items carried forward as boundary risk notes

## F. decomposition-ready handoff
- [ ] `decomposition_ready_handoff` present with: `anti_split_constraints[]`, `candidate_split_evidence[]`, `boundary_defects[]`
- [ ] `downstream_handoff` includes targets for N180, N190, N210, N330

## G. consistency check
- [ ] B-R1 through B-R6 (or B-R11) evaluated from `references/boundary-consistency-check.md`
- [ ] `rule_results[]` populated with `pass | warn | reject | not_applicable`
- [ ] `blocker_mapping: B-N140-01` present when readiness is blocked

## One-vote rejection items
- [ ] Any module missing responsibilities, confidence, or evidence
- [ ] Cycle not explicitly decided
- [ ] `decomposition_ready_handoff` absent
