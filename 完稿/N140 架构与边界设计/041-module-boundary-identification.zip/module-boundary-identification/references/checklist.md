# checklist

Before finalizing 041 output:

- The artifact starts with the shared 14-field header.
- `schema_version` is `n140.v2`.
- `step_order` is `1_of_2` or `standalone`.
- The live schema source is `references/exact-contract.md`.
- N130 ids are preserved when present.
- Every module has scale, responsibilities, in-boundary, out-of-boundary, owned resources, confidence, and evidence.
- Coupling is classified with necessity and handling path.
- Defects, assumptions, failures, and constraints are carried forward.
- B-R1 through B-R11 are evaluated.
- Event payload and downstream targets are present.
