# Workflow position

## Node: N140
## Step order: 1_of_2

## Upstream inputs (feeds this skill)
- 038
- 039

## Downstream consumers (this skill feeds)
- 042
- N180 planning

## When to use standalone vs in-workflow
- **Standalone**: when no structured upstream artifacts exist; start from raw requirements or PRD; output will be `readiness: provisional`.
- **In-workflow**: when upstream artifacts are available; inherit IDs and fields; output can reach `readiness: ready`.

## Minimum required inputs for `readiness: ready`
See `references/v2-contract.md` (N170 group) or `references/exact-contract.md` (N130/N140 group) for the typed input schema.
