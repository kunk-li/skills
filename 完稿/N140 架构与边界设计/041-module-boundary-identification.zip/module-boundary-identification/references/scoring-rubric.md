# scoring rubric

Score each output from 0 to 100.

- Contract compliance: 20
- Upstream traceability: 15
- Boundary clarity: 20
- Coupling and risk analysis: 20
- Downstream handoff quality: 15
- Uncertainty handling: 10

## Readiness mapping

Use the score as a ceiling, then downgrade further for unresolved reject-level rules.

| Score range | Maximum readiness | Contract status | Notes |
|---|---|---|---|
| 85-100 | pass | review_ready | All reject-level rules pass; warn-level items are either resolved or explicitly carried forward. |
| 70-84 | constrained | draft | Usable downstream with named caveats, missing evidence, or warn-level rule results. |
| 50-69 | provisional | draft | Advisory only; insufficient upstream structure or evidence for execution-grade use. |
| 0-49 | blocked | blocked | Unsafe for downstream consumption unless the user explicitly requests a rough brainstorm. |

A reject-level consistency failure caps readiness at `blocked` unless explicitly accepted with rationale and downgraded to `constrained`; a missing structured upstream source caps readiness at `provisional` unless code/runtime evidence closes the gap.
