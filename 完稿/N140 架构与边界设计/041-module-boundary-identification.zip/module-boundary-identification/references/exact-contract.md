# exact contract: module-boundary-identification

Version: 3.1.0
Schema version: n140.v2
Artifact type: module_boundary_map
Canonical source: this file

## Canonical ids and patterns

- Module id: `MOD-[A-Z0-9]+-[0-9]{3,}`.
- Decision id: preserve upstream ids; append local ids as `N140-041-DEC-[0-9]{3,}`.
- Assumption id: preserve upstream `ASSUMP-*`; append local ids as `N140-041-ASSUMP-[0-9]{3,}`.
- Boundary risk id: `N140-041-BRISK-[0-9]{3,}`.
- Anti-pattern id: `N140-041-AP-[0-9]{3,}`.
- Fact id: `N140-041-FACT-[0-9]{3,}`.

## Canonical enums

`module_scale` values:

- `code_package`
- `bounded_context`
- `component`
- `service`
- `system`

Use code-view coupling for `code_package`, `bounded_context`, and `component` unless the user explicitly requests deployable-service analysis:

- `data`
- `stamp`
- `control`
- `external`
- `common`
- `content`

Use service-view coupling for `service` and `system`:

- `sync_rpc`
- `async_event`
- `shared_data`
- `shared_library`
- `shared_config`
- `shared_runtime`

`coupling_necessity` values:

- `necessary`
- `designed`
- `shared`

`fact_status` values:

- `confirmed`: supported by explicit upstream, code, runtime, ownership, or review evidence.
- `inferred`: reasoned from partial or indirect evidence and must carry evidence refs or assumptions.
- `pending`: known gap that must be validated before stronger downstream use.

`anti_pattern` values:

- `god_module`
- `feature_envy`
- `shotgun_surgery`
- `chatty_interface`
- `cyclic_dependency`
- `inappropriate_intimacy`
- `shared_database_anti_pattern`

## Required artifact shape

```yaml
artifact_header: {} # use references/v2-alignment.md exactly; 041 normally uses route_back_to: none

derived_from:
  analysis_ref: "TSA-001 | null"
  solution_ref: "SOL-001 | null"
  review_pack_ref: "REVIEW-001 | null"
  upstream_artifact_refs: []
  rule: "analysis_ref is required when N130 input exists; null is allowed only when external_context is populated"

external_context:
  enabled: false
  sources: []
  reason_no_n130: null
  readiness_floor: provisional

decision_refs: []

divergence_from_upstream: []

module_catalog:
  - module_id: "MOD-EXAMPLE-001"
    name: "example-module"
    module_scale: "bounded_context"
    parent_module_id: null
    contains_module_ids: []
    responsibilities:
      - statement: "primary responsibility"
        strength: "primary | secondary | shared"
        requirement_refs: []
        evidence_refs: []
        fact_status: "confirmed | inferred | pending"
    in_boundary: []
    out_of_boundary: []
    owner_hint: null
    confidence: "high | medium | low"
    fact_status: "confirmed | inferred | pending"

owned_resources:
  - module_id: "MOD-EXAMPLE-001"
    entities: []
    apis: []
    data_tables: []
    events_published: []
    configs: []
    libraries: []
    external_systems: []
    fact_status: "confirmed | inferred | pending"

coupling_inventory:
  - coupling_id: "N140-041-COUP-001"
    from_module: "MOD-A-001"
    to_module: "MOD-B-001"
    coupling_kind: "data"
    coupling_view: "code_view | service_view"
    interaction_pattern: null
    necessity: "necessary"
    volume_or_frequency: null
    contract_ref: null
    evidence_refs: []
    fact_status: "confirmed | inferred | pending"
    rationale: "why this coupling exists"
    elimination_path: null
    governance_hint: null

boundary_metrics:
  - module_id: "MOD-EXAMPLE-001"
    cohesion: null
    afferent_coupling: null
    efferent_coupling: null
    stability: null
    abstractness: null
    distance_from_main_sequence: null
    change_frequency: null
    metric_source: "observed | inferred | unavailable"

co_change_hints: []

boundary_risks:
  - risk_id: "N140-041-BRISK-001"
    upstream_refs: []
    affected_modules: []
    impact: "boundary risk impact"
    mitigation: "how to reduce risk"
    fact_status: "confirmed | inferred | pending"

anti_patterns_detected: []

anti_split_constraints:
  - constraint_id: "N140-041-ANTI-SPLIT-001"
    affected_modules: []
    reason: "why splitting now is unsafe"
    strength: "hard | soft"
    evidence_refs: []
    fact_status: "confirmed | inferred | pending"

decomposition_ready_handoff:
  module_catalog_ref: "this.module_catalog"
  coupling_inventory_ref: "this.coupling_inventory"
  anti_split_constraints_ref: "this.anti_split_constraints"
  confidence_by_module: []
  defect_items_to_carry_forward: []

downstream_targets:
  - N140_042
  - N180
  - N190
  - N210
  - N330

downstream_handoff:
  to_N140_042: []
  to_N180: []
  to_N190: []
  to_N210: []
  to_N330: []
  defect_items_to_carry_forward: []

produced_events:
  - produced.module_boundary_map.v1

subscribed_events:
  - produced.solution_review_pack.v1
  - produced.defect_found.v1
  - produced.service_decomposition_return.v1

adjacent_nodes_to_notify:
  - N140_042
  - N180
  - N190
  - N210
  - N330

consistency_check:
  status: "pass | constrained | provisional | blocked"
  rule_results: []

event_payload: {} # use references/v2-alignment.md
```

## Schema rules

- `module_catalog` must not be empty unless readiness is `blocked`.
- Every module must include at least one `out_of_boundary` rule.
- Every coupling must identify both modules, coupling kind, necessity, fact status, and evidence or explicit assumption.
- Every `owned_resources.module_id` must exist in `module_catalog`.
- `confirmed`, `inferred`, and `pending` facts must use the canonical `fact_status` field, not only prose labels.
- `designed` coupling requires `elimination_path`.
- `shared` coupling requires `governance_hint`.
- Upstream `decision_refs`, `assumptions_to_verify`, `failure_modes_to_carry_forward`, and `defect_items_to_carry_forward` must survive in this artifact or be listed as unresolved carry-forward items.
