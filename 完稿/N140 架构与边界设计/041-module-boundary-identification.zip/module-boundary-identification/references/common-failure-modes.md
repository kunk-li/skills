# common failure modes

- Treating `technical-solution-analysis.md` as a filename instead of extracting structured refs. Fix by applying `upstream-ingestion.md`.
- Mixing code package, bounded context, and service scale in one flat module list. Fix with parent/child relationships.
- Inventing metrics without evidence. Fix by marking metric source as inferred or unavailable.
- Making service deployment decisions in 041. Fix by converting them into anti-split constraints or handoff hints.
- Dropping upstream defect items. Fix by applying B-R4.
- Keeping old `workflow_node` as the canonical route key. Fix by using `step_order` and `node_context`.
