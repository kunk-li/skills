# Common failure modes — module-boundary-identification

## F1: scale mixing
Symptom: code packages, bounded contexts, and services appear in the same flat module list with no hierarchy.
Fix: choose one primary `module_scale`; model mixed scales with parent/child relationships. A service contains bounded contexts, which contain code packages — never flatten these.

## F2: metrics without evidence
Symptom: coupling strength numbers, co-change ratios, or cyclomatic metrics appear but no code analysis, git history, or runtime trace is cited.
Fix: mark heuristic metrics as `fact_status: inferred` with the assumption stated. Only emit `confirmed` metrics when evidence is cited.

## F3: service decisions made too early
Symptom: the output recommends deploying specific microservices, recommends Kubernetes namespaces, or assigns domain names to services.
Fix: 041's job is to identify boundaries and hand off to 042. Convert premature service decisions to `anti_split_constraints` or `decomposition_ready_handoff` hints for 042.

## F4: cycles silently accepted
Symptom: a circular dependency between MOD-A → MOD-B → MOD-A appears but no decision is logged.
Fix: every cycle must be either `constrained` (accepted with rationale and governance) or `blocked`. Silent pass is a reject-level violation of R03.

## F5: upstream IDs dropped
Symptom: N130 decision IDs, assumption IDs, or FMEA IDs are not referenced in the boundary map.
Fix: apply `references/upstream-ingestion.md`. Preserve upstream IDs in `evidence[]` and carry forward failure modes as boundary risk notes.

## F6: shared DB not flagged
Symptom: two modules read and write the same database tables but no `shared_db_risk` is logged.
Fix: every cross-module shared write at service scale is a boundary risk. Log it under `boundary_risks[]` even if it is accepted with rationale.

## F7: empty coupling inventory
Symptom: the coupling section exists but contains no entries, or lists only "module A talks to module B" without type, necessity, or contract status.
Fix: every coupling edge must have `coupling_type`, `necessity` (necessary/designed/shared), and `contract_status`. Evidence must be cited.

## F8: blocked artifact is unusable
Symptom: readiness is `blocked` but no partial map, no minimum unblock evidence, and no route-back action is provided.
Fix: even a blocked artifact must return the best partial module map plus the specific evidence needed to unblock. Never return empty output.

## F9: integration marked contract-less without a contract-surface inventory
Symptom: a cross-boundary coupling to an external capability is recorded with `contract_status` absent/none, or the downstream plan mocks or stubs it behind a newly invented facade, without evidence that the target's already-published contract surface was searched.
Fix: before setting `contract_status` to absent or planning a stub, inventory three sources in the target codebase and cite what you searched — (1) exported api/contract/SPI modules or already-published interfaces; (2) same-module / same-process injectable services; (3) existing cross-boundary invocation idioms other consumers already use (dependency injection, facade, container-lookup + reflection to dodge a compile-time dependency, events). Only record a capability as contract-less after a cited search of all three fails. Reusing an existing published contract always beats inventing a new facade to stub. Anti-pattern: treating "crosses a boundary" as "unreachable → invent a facade and stub it." Corollary: any value a rule can derive from data already in hand (inputs, session, the aggregate under construction) is in-boundary logic, not an external integration to stub.
