# output template: module boundary map

```yaml
artifact_header:
  artifact_id: "N140-ART-041-001"
  artifact_type: "module_boundary_map"
  schema_version: "n140.v2"
  producer_skill: "module-boundary-identification"
  producer_version: "3.1.0"
  node_context: "n140"
  step_order: "1_of_2"
  readiness: "constrained"
  contract_status: "draft"
  route_back_to: "none"
  mode: "upstream_assisted"
  generated_at: "YYYY-MM-DDThh:mm:ssZ"
  derived_from: {}
  decision_refs: []
```

## 1. Evidence and inheritance

Summarize upstream N130 refs, external context, and confidence.

## 2. Module catalog

List modules with responsibilities, in-boundary, out-of-boundary, owned resources, evidence, and confidence.

## 3. Coupling inventory

List coupling, necessity, evidence, mitigation, and contract status.

## 4. Metrics and co-change hints

Separate observed metrics from inferred metrics.

## 5. Boundary risks and anti-patterns

Carry upstream assumptions, failures, and defects forward.

## 6. Decomposition-ready handoff

Provide exactly what 042 should consume.

## 7. Downstream handoff and event payload

List downstream targets, adjacent nodes, consistency status, and event payload.
