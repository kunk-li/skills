# Example I/O

## Example input
N130 technical solution analysis for an order management system with modules: order creation, payment, inventory, notification, and audit.

## Good output sketch

```yaml
metadata:
  artifact_schema_version: n140.v2.1.0
  skill_name: module-boundary-identification
  input_mode: upstream_assisted
  readiness: constrained

module_catalog:
  - module_id: MOD-ORDER-001
    name: OrderCore
    scale: bounded_context
    responsibilities:
      - owns order lifecycle state machine (draft → submitted → approved → fulfilled → cancelled)
      - validates order business rules (stock check, price calculation)
    in_boundary: [order state transitions, order validation rules]
    out_of_boundary: [payment processing, inventory reservation, notification delivery]
    owned_resources:
      tables: [orders, order_items, order_history]
      topics_produced: [order.created, order.cancelled]
    confidence: confirmed
    evidence: [SM-ORDER, OBJ-ORDER, API-ORDER-CREATE]

  - module_id: MOD-PAY-001
    name: PaymentGateway
    scale: bounded_context
    responsibilities:
      - processes payment authorization and capture
      - manages refund workflow
    owned_resources:
      tables: [payments, refunds]
      topics_consumed: [order.created]
      topics_produced: [payment.authorized, payment.failed]
    confidence: inferred
    evidence: [N130 solution analysis section 3.2]

coupling_inventory:
  - from: MOD-ORDER-001
    to: MOD-PAY-001
    coupling_type: async_event
    necessity: necessary
    contract_status: draft
    evidence: [order.created event triggers payment authorization]

boundary_risks:
  - risk_id: N140-041-BRISK-001
    description: orders and payments share the same database in current architecture
    risk_type: shared_data
    severity: high
    recommendation: extract payment tables to dedicated schema or DB before service split

decomposition_ready_handoff:
  for_042:
    anti_split_constraints:
      - MOD-ORDER-001 and MOD-PAY-001 must not share a DB write transaction
    candidate_split_evidence:
      - separate bounded contexts with clear event contracts
    boundary_defects: [BRISK-001 shared DB must be resolved before split]
```

## What makes this good
- Every module has `in_boundary` and `out_of_boundary` — not just responsibilities.
- Coupling inventory has `coupling_type` and `contract_status`, not just "they talk to each other".
- `boundary_risks` identify the shared DB anti-pattern explicitly.
- `decomposition_ready_handoff` gives 042 the anti-split constraint it needs.
- `confidence: inferred` on MOD-PAY-001 because details came from prose, not structured upstream.

## ex-002 · cycle detection — constrained vs blocked

```yaml
# Scenario: OrderModule and InventoryModule reference each other

coupling_inventory:
  - from: MOD-ORDER-001
    to: MOD-INV-001
    coupling_type: sync_rpc
    necessity: necessary
    purpose: "Order validates stock availability before confirming"
    contract_status: draft
    evidence: [API-ORDER-CREATE calls InventoryService.checkStock]

  - from: MOD-INV-001
    to: MOD-ORDER-001
    coupling_type: async_event
    necessity: designed
    purpose: "Inventory publishes stock_depleted event; Order subscribes to cancel pending orders"
    contract_status: draft
    evidence: [FLOW-STOCK-DEPLETION event consumer in OrderService]

cycle_analysis:
  cycle_id: CYC-001
  participants: [MOD-ORDER-001, MOD-INV-001]
  cycle_type: bidirectional_coupling
  decision: constrained   # NOT blocked — cycle is accepted with rationale
  rationale: "Coupling directions are different: sync_rpc for validation (necessary) vs async_event for notification (designed). Different protocols prevent distributed transaction risk."
  governance:
    contract_freeze: "Interface between modules must not change without joint review"
    monitoring: "Circular dependency in tests must be broken via mock; alert if runtime call depth > 2"
  alternative_considered:
    option: "Extract StockValidationService to break cycle"
    rejected_because: "Team size (6) cannot sustain a third service; revisit at year_1 when orders > 2M/month"

# BLOCKED example (cycle that should NOT proceed):
boundary_risks:
  - risk_id: N140-041-BRISK-002
    description: "OrderModule and PaymentModule share a write transaction via shared DB"
    risk_type: shared_data
    cycle_decision: blocked
    blocking_reason: "Shared write transaction prevents independent deployment and violates C3_technical constraint from 038"
    unblock_evidence_needed: "Separate payment tables into dedicated schema OR implement outbox pattern for cross-service write"
```

## ex-003 · blocked — boundary defect prevents handoff to 042

```yaml
skill_name: module-boundary-identification
readiness: blocked
blocker_mapping: B-N140-01
route_back_to: technical-solution-analysis

blockers:
  - blocker_id: BLK-MOD-001
    type: unresolvable_cycle
    cycle_id: CYC-001
    participants: [MOD-ORDER-001, MOD-PAYMENT-001, MOD-INVENTORY-001]
    description: "Three-way circular dependency: Order writes Payment, Payment updates Inventory, Inventory triggers Order rebalance. Cannot be broken without architectural change."
    impact: "decomposition_ready_handoff cannot be produced; 042 cannot proceed"
    resolution_required: "Architecture revision needed — introduce event-driven decoupling or extract a Coordinator module"
    unblock_evidence: "Revised architecture from 039 with explicit decoupling strategy"

  - blocker_id: BLK-MOD-002
    type: shared_data_write
    description: "MOD-BILLING-001 and MOD-ORDER-001 both write to the same 'invoices' table without a clear owner"
    impact: "Dual ownership prevents safe service extraction; 042 cannot assign data_ownership"
    resolution_required: "Single write owner must be assigned; the other becomes read-only consumer via API"
    unblock_evidence: "Updated 039 architecture explicitly assigning invoice ownership to one module"

partial_output:
  modules_mapped: 3
  modules_blocked: 2
  completed: [MOD-USER-001, MOD-NOTIFICATION-001, MOD-AUDIT-001]
  blocked: [MOD-ORDER-001, MOD-BILLING-001]
  decomposition_ready_handoff: null
```
