# boundary consistency check

Run these checks before finalizing 041 output. Each rule must appear in `consistency_check.rule_results`.

## Upstream handoff rules

| Rule | Check | Violation |
|---|---|---|
| B-R1 | When N130 S3 components exist, each 041 module must trace to an upstream component or appear in `divergence_from_upstream`. | warn |
| B-R2 | When upstream assumptions or failure modes exist, `boundary_risks` must reference at least one relevant upstream id or explain why none apply. | warn |
| B-R3 | If 041 identifies a compliance-driven boundary risk, the evidence must reference a concrete upstream constraint id when available. | reject |
| B-R4 | Every upstream defect carry-forward item must appear in module responsibility, coupling rationale, boundary risk, anti-pattern, anti-split constraint, or unresolved item. | reject |

## Internal rules

| Rule | Check | Violation |
|---|---|---|
| B-R5 | `coupling_inventory.from_module` and `to_module` must exist in `module_catalog`. | reject |
| B-R6 | Shared component dependent modules must exist in `module_catalog`. | reject |
| B-R7 | Anti-pattern affected modules must exist in `module_catalog`. | reject |
| B-R8 | Refactorable designed coupling must include an elimination path. | reject |
| B-R9 | Shared coupling must include governance hint. | reject |
| B-R10 | Cyclic dependency makes readiness constrained or blocked unless explicitly accepted with rationale. | reject |
| B-R11 | Every `owned_resources.module_id` must exist in `module_catalog`. | reject |

## Output status rule

The artifact readiness cannot be stronger than the worst unresolved reject-level rule. Warn-level violations may still allow `constrained` when they are carried forward.
