# upstream ingestion: 041

Use this guide when N130 or other structured upstream artifacts are present.

## Required behavior

Do not only read a file name such as `technical-solution-analysis.md`. Extract and preserve machine-readable ids and references.

## N130 to 041 mapping

| Upstream field | 041 target |
|---|---|
| `analysis_id` | `derived_from.analysis_ref` |
| `solution_id` | `derived_from.solution_ref` |
| `decision_refs` | root `decision_refs`, preserving upstream ids |
| `architecture_three_states.to_be.key_components` | seed `module_catalog` |
| `assumptions_to_verify` | seed `boundary_risks`, preserving ids |
| `failure_modes_to_carry_forward` | seed `boundary_risks` and `anti_patterns_detected`, preserving ids |
| `defect_items_to_carry_forward` | root carry-forward and downstream handoff |
| `requirement_coverage_matrix` | validate module responsibility coverage |
| `S3.components` | seed modules and owned resources |
| `S4.api_contracts` | seed owned APIs |
| `event_contracts` | seed published or consumed events |
| `analysis_return_items` or `draft_return_items` | treat boundary-related items as input defects |

## Conflict handling

When upstream facts and local boundary inference conflict, do not overwrite either. Write a `divergence_from_upstream` item with the upstream ref, local finding, severity, and recommendation.
