# Compatibility map — module-boundary-identification v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 038 technical-solution-analysis | `components[], architecture_three_states` | `module candidate extraction` | proposed components seed module catalog |
| 039 technical-solution-draft-generation | `S3_proposed_architecture` | `upstream_assisted input` | draft architecture provides module boundary hints |
| N070 017 data-object-identification | `OBJ-* owner_module, ddd_role` | `boundary.same_service, consistency_mode` | data object ownership defines module boundaries |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 042 service-decomposition-recommendation | `decomposition_ready_handoff, anti_split_constraints[]` | `baseline_module_catalog` | boundary map is primary input for decomposition |
| N180 planning | `downstream_handoff.to_N180` | `architecture delivery plan` | module boundaries inform sprint planning |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
