# CHANGELOG

## [3.1.1] - 2026-04-24

Type: non-schema

- Updated checklist references from 12-field to 14-field shared header.
- Updated checklist rule coverage references to the v3.1.0 canonical rule ids.
- Added `scripts/validate_n140_references.py` to catch rule-id and header-count drift across reference files.

## [3.1.0] - 2026-04-24

Type: schema-additive

- Added `route_back_to` and `contract_status` to the shared artifact header.
- Added canonical `fact_status: confirmed | inferred | pending` fields for machine-readable fact provenance.
- Added B-R11 to validate `owned_resources.module_id` references.
- Clarified event payload `affected_nodes` versus artifact-level `adjacent_nodes_to_notify`.
- Added physical archive copy of the retired N140 YAML design source.
- Formalized four-level scoring-to-readiness mapping.

## [3.0.0] - 2026-04-24

Type: schema-breaking

- Replaced canonical `workflow_node` routing with `step_order` and `node_context` to make the skill usable standalone or inside N140.
- Kept N140 as context, not as a hard dependency.
- Added `external_context` fallback rules for non-N130 usage.

## [2.4.0] - 2026-04-24

Type: schema-additive

- Added `downstream_targets`, `produced_events`, `subscribed_events`, and `adjacent_nodes_to_notify`.
- Added event payload conventions for N140 event-driven workflow activation.

## [2.3.0] - 2026-04-24

Type: schema-additive

- Added machine-readable consistency checks.
- Added route-back protocol for boundary-analysis revisions.

## [2.2.0] - 2026-04-24

Type: schema-additive

- Added N130 handoff ingestion, `derived_from`, `decision_refs`, and defect carry-forward handling.

## [2.1.0] - 2026-04-24

Type: schema-additive

- Added shared N140 artifact header, `schema_version: n140.v2`, four-level readiness, downgrade templates, and shared orchestration conventions.

## [2.0.0] - 2026-04-24

Type: schema-breaking

- Locked canonical contract source as `references/exact-contract.md`.
- Retired independent YAML design as the live schema source.
- Locked coupling, driver, and anti-pattern naming inside each exact contract.
