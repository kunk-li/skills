# CHANGELOG

## v4.1.0 (2026-07-02) — contract-surface inventory before stubbing

_skill: module-boundary-identification_

### Added
- F9 (common-failure-modes): integration marked contract-less / stubbed without inventorying the target's published contract surface (exported api/contract modules, same-process injectable services, existing cross-boundary invocation idioms). Corollary: in-hand derivable values are in-boundary logic, not external stubs.
- Checklist C: cross-boundary coupling marked contract-less/stub-only must carry a cited contract-surface inventory
- SKILL.md step 7: inventory published contract surface before recording a coupling as contract-less or stubbing it

### Evidence
- Folded from a pre-registered PRE/POST A/B (n=5 no-intervention vs n=4 with-intervention) on a bounded full-feature implementation task: reachable-integration wiring rose from mean 0.7/3 to 2.6/3 with clean separation (max PRE < min POST). Effect is single-module, single-dimension; wording kept project-agnostic.

---

## v4.0.0 (2026-04-30) — v10 final optimization

_skill: module-boundary-identification_

### Added
- Trigger conditions + Standalone rule sections
- Confidence discipline (confirmed/inferred/pending separation)
- Downstream handoff summary
- Compatibility-map.md with field-level input/output mapping
- blocked + degraded example-io scenarios

### Changed
- Description trimmed to ≤25 words
- Quick-reference tables expanded to ≥4 per skill
- rule_results expanded to R01-R08

### Fixed
- CHANGELOG format standardized to `# CHANGELOG` header
- Chinese/English section headers unified to English

---

## v3.0.0 (2026-04-30) — v5 optimization batch

### Added
- common-failure-modes.md with Symptom/Fix format (F1–F8)
- workflow-position.md
- compatibility-map.md
- CHANGELOG.md

### Changed
- Checklist rewritten with inline `- [ ]` items
- example-io.md expanded with concrete YAML examples
- Description word count reduced

---

## v2.0.0 (2026-01-15) — v2 contract migration

### Added
- artifact_schema_version header
- produced_event field
- blocker_mapping field
- rule_results[] with pass|warn|reject|not_applicable
- feedback_signal_to_n005 reverse governance channel

---

## v1.0.0 (2025-10-01) — initial release
