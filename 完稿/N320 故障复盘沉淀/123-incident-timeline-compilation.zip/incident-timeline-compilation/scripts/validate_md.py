#!/usr/bin/env python3
"""validate_md.py for skill #123 incident-timeline-compilation (n320-postmortem-v1.3.2)

Checks that a generated 故障时间线.md output satisfies the mandatory section
contract defined in SKILL.md and n320-shared-postmortem-contract.md.

Usage:
    python scripts/validate_md.py <output.md> [--strict]
"""
import re
import sys
from pathlib import Path

SCHEMA = "n320-postmortem-v1.3.2 / #123 incident-timeline-compilation"

REQUIRED_HEADINGS = [
    ("metadata",            re.compile(r"##\s*\d*\.?\s*Metadata|^```yaml[\s\S]*?\bmetadata:\b", re.I | re.MULTILINE)),
    ("evidence_inventory",  re.compile(r"##\s*\d*\.?\s*(Evidence [Ii]nventory|证据清单|证据台账)", re.I)),
    ("timezone_rules",      re.compile(r"##\s*\d*\.?\s*(Timezone|[Tt]ime.*[Nn]ormali[sz]|时区|时间归一)", re.I)),
    ("timeline_table",      re.compile(r"##\s*\d*\.?\s*(Timeline [Tt]able|Timeline|时间线|故障时间线)", re.I)),
    ("lifecycle_anchor",    re.compile(r"##\s*\d*\.?\s*(Lifecycle [Aa]nchor|生命周期锚点|关键时间戳)", re.I)),
    ("evidence_gaps",       re.compile(r"##\s*\d*\.?\s*(Evidence [Gg]aps|Unresolved [Ii]tems|证据缺口|待确认|未解决)", re.I)),
    ("downstream_handoff",  re.compile(r"##\s*\d*\.?\s*(Downstream [Hh]andoff|下游交接)", re.I)),
]
NEVER_EMPTY_SECTIONS = ["evidence_gaps", "downstream_handoff"]
REQUIRED_METADATA_FIELDS = ["artifact_id", "selected_mode", "incident_type_branch"]
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}
VALID_MODES = {"fragment_reconstruction", "audit_safe_chronology", "handoff_timeline", "conflict_reconciliation"}

def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0

def main():
    if len(sys.argv) < 2:
        print(f"usage: python scripts/validate_md.py <output.md> [--strict]")
        return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists():
        return fail(f"file not found: {path}")

    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    errors = 0; warnings = 0

    # === Example/light-check mode ===
    # When validating example files, only check: readiness value + downstream_handoff presence
    # Full section checks require production output format with ## Metadata heading
    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    if _is_example and _has_any_heading:
        # Check readiness value if present
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness value '{_rm.group(1)}' not in {VALID_READINESS}")
            return 1
        # Check downstream_handoff exists
        if "downstream_handoff" not in text.lower() and "downstream" not in text.lower():
            print(f"[WARN] example may be missing downstream_handoff section")
        return ok(f"{SCHEMA} example validation passed (light-check mode)")



    # 1. Check required headings
    found_sections = {}
    for key, pat in REQUIRED_HEADINGS:
        match = pat.search(text)
        if match:
            found_sections[key] = match.start()
        else:
            print(f"[FAIL] missing required section: {key}")
            errors += 1

    # 2. Check downstream_handoff block exists and has readiness
    if "downstream_handoff" in found_sections:
        dh_pos = found_sections["downstream_handoff"]
        snippet = text[dh_pos:dh_pos+800]
        if "readiness:" not in snippet:
            print("[FAIL] downstream_handoff block missing 'readiness:' field")
            errors += 1
        else:
            rm = re.search(r"readiness:\s*([\w]+)", snippet)
            if rm and rm.group(1) not in VALID_READINESS:
                print(f"[FAIL] readiness value '{rm.group(1)}' not in {VALID_READINESS}")
                errors += 1
        if "timeline_anchor_ref:" not in snippet and "unresolved_gaps:" not in snippet:
            warn("downstream_handoff may be missing timeline_anchor_ref or unresolved_gaps")
            warnings += 1

    # 3. Check metadata fields
    if "metadata" in found_sections:
        meta_pos = found_sections["metadata"]
        snippet = text[meta_pos:meta_pos+600]
        for field in REQUIRED_METADATA_FIELDS:
            if field not in snippet:
                print(f"[FAIL] metadata section missing field: {field}")
                errors += 1
        # selected_mode value check
        mm = re.search(r"selected_mode[:\s]+[`\"']?(\w+)", snippet)
        if mm and mm.group(1) not in VALID_MODES:
            warn(f"selected_mode '{mm.group(1)}' not in known modes {VALID_MODES}")
            warnings += 1

    # 4. Timeline table: check ≥3 data rows
    table_blocks = re.findall(r"\|[^\n]+\|", text)
    # count rows that look like timeline entries (have | in them and are not headers)
    data_rows = [r for r in table_blocks if not re.search(r"[-:]{3,}", r)]
    if "timeline_table" in found_sections and len(data_rows) < 4:  # 1 header + 3 data
        msg = f"timeline table appears to have fewer than 3 data rows (found {max(0,len(data_rows)-1)})"
        if strict:
            print(f"[FAIL] {msg}"); errors += 1
        else:
            warn(msg); warnings += 1

    # 5. evidence_refs present in timeline section
    if "evidence_refs" not in text:
        print("[FAIL] no 'evidence_refs' found — every timeline row must have evidence_refs")
        errors += 1

    # 6. layer field present
    if not re.search(r"layer\s*[:=]\s*(confirmed|inferred|open_question)", text, re.I):
        warn("no 'layer' field found (confirmed/inferred/open_question) — required on every timeline row")
        warnings += 1

    # 7. Blame-less check: personal name patterns
    blame_pattern = re.compile(r"\b(张[三四五]|李[四五六]|王[五六七])\b")
    if blame_pattern.search(text):
        print("[FAIL] possible personal name found — use role/team names only (blameless rule)")
        errors += 1

    # Summary
    if errors > 0:
        return fail(f"{SCHEMA} validation FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} validation passed — {warnings} warning(s)")

if __name__ == "__main__":
    raise SystemExit(main())
