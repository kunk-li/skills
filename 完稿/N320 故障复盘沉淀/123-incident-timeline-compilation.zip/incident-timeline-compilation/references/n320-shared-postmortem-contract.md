# N320 Shared Postmortem Contract

This contract is packaged inside each N320 skill. No files, scripts, directories, or services outside the skill package are required.

## Contract version
`n320-postmortem-v1.3.2`

## Node scope
N320 turns incident evidence into post-incident learning artifacts:
- `incident-timeline-compilation` owns a factual, blame-less chronology: what happened, when, and based on which evidence.
- `production-incident-postmortem` owns causal learning and commitments: why it happened, what must change, and how follow-up will be tracked.

Do not perform live incident mitigation, execute fixes, or make deployment approvals here. Those belong to N310 or other operational workflows. N320 may describe actions already taken and recommend follow-up commitments.

## Encapsulation governance
Each N320 skill is self-contained. Store shared rules inside each skill's `references/` folder. Do not require node-level files, node-level scripts, external matrices, or hidden registries.

## Release consistency rule
A valid N320 release keeps the same `contract_version` in `SKILL.md`, `references/output-contract.yaml`, and this shared contract. The two skill-local shared contract files should remain byte-identical before packaging.

## Shared metadata schema
Every N320 output must keep these fields in `metadata`:

```yaml
metadata:
  contract_version: n320-postmortem-v1.3.2
  workflow_node: N320
  skill_id: string                    # 123 | 124
  skill_name: string                  # incident-timeline-compilation | production-incident-postmortem
  selected_mode: string
  readiness: draft | partial | ready | blocked
  incident_id: string
  incident_id_aliases: [string]
  source_time_window:
    start: iso8601 | unknown
    end: iso8601 | unknown
    timezone: string
  service_scope: [string]
  incident_type_branch: availability | performance | data_consistency | compliance | security | capacity | user_experience
  secondary_branches: [string]
  evidence_profile: timeline_only | rca_evidence_only | multi_source | historical_enriched | assumption_only
  confidence: high | medium | low
  composition_role: string
  function_bias: string
  stage_position: operations_governance.postmortem_consolidation.<sub-stage>
  node_artifact_target: 故障时间线.md | 线上问题复盘.md
  open_blockers: [string]
  owner_placeholders: [string]
  severity_classification:
    compliance_impact: none | review | breach
    user_impact: isolated | partial | widespread | systemic
    reversibility: easy | controlled | hard | irreversible
    recurrence: first_occurrence | similar_incident_within_90d | same_root_cause_within_90d
    total_score: integer | unknown
    severity_class: Critical | Major | Minor | unknown
    target_min_why_depth: L2 | L3 | L4 | L5 | unknown
    achieved_why_depth: L1 | L2 | L3 | L4 | L5 | unknown
    why_depth_gap_explained: string | null
  tool_collaboration_mode: unified_review_pass | single_incident_postmortem | batch_recurrence_review
  cause_category_disagreement:
    first_cut_suspect: string | null
    final_category: string | null
    explanation: string | null
```

If an input field is unknown, use `unknown`, `[]`, or `null`; do not omit required metadata fields.

## Incident id rule
- Preserve an existing official `incident_id` from N300 / N310 / N005 handoff when present.
- If multiple upstream artifacts use different ids for the same incident, choose the most authoritative value as `incident_id` and put the rest in `incident_id_aliases`.
- A skill running standalone may create a temporary id using `TEMP-N320-<date>-<source>` and mark it as provisional in `incident_id_aliases`.
- Never silently rename an upstream `incident_id` once chosen.

## Tool collaboration mode
Use exactly one value:
- `single_incident_postmortem`: one incident, one timeline plus one postmortem. Use this as the default for most incidents.
- `unified_review_pass`: the same incident is reviewed in one combined session, with both N320 skills sharing draft state; `downstream_handoff` is internal rather than a hard skill boundary.
- `batch_recurrence_review`: multiple related incidents are reviewed together to surface a repeated pattern; the postmortem produces one cross-incident learning artifact and `severity_classification.recurrence` becomes mandatory.

## Severity classification in timeline artifacts
`severity_classification` is always required in `production-incident-postmortem`. In `incident-timeline-compilation`, it is required for `selected_mode: handoff_timeline`; other timeline modes may keep the field with `unknown` values when severity analysis is not part of the timeline task.

## Incident type branch rule
When an N310 handoff exists, mirror N310 `event_type_branch` into N320 `incident_type_branch` without silently relabeling. If the incident spans multiple domains, name one primary `incident_type_branch` and place others in `secondary_branches`.

Allowed primary branches:
- `availability`
- `performance`
- `data_consistency`
- `compliance`
- `security`
- `capacity`
- `user_experience`

## Readiness and evidence profile enums
Use these values exactly:
- `readiness`: `draft`, `partial`, `ready`, `blocked`
- `evidence_profile`: `timeline_only`, `rca_evidence_only`, `multi_source`, `historical_enriched`, `assumption_only`

Definitions:
- `draft`: usable structure exists but important sections or evidence are incomplete.
- `partial`: required sections exist and can be reviewed, but gaps remain.
- `ready`: artifact is complete enough for the intended review or handoff.
- `blocked`: cannot produce a meaningful artifact without a named missing input.

## Shared join keys
Use these keys when artifacts are combined:
- `incident_id`: stable incident identifier; create a temporary `TEMP-N320-<date>-<source>` id when absent and mark it provisional.
- `source_time_window`: the observed or reconstructed incident window.
- `service_scope`: affected service, workflow, region, tenant, or product slice.
- `incident_type_branch`: primary incident class that should remain stable across N310 and N320.
- `evidence_refs`: structured evidence references using the schema below.
- `timeline_anchor_ref`: postmortem references to timeline rows produced by `incident-timeline-compilation`.
- `action_item_id`: stable id for postmortem follow-up items.

## Evidence reference schema
Use compact evidence references instead of copying long raw logs, traces, or chat fragments. Both timeline and postmortem skills must conform.

```yaml
evidence_ref:
  ref_id: string                     # stable id reusable across timeline rows and postmortem sections
  source_family: metric | log | trace | alert | deployment | test | user_report | manual_note | chat | ticket | rca_artifact | response_artifact
  source_name: string
  query_or_source: string
  time_window: string
  service_scope: [string]
  trace_id_refs: [string]
  upstream_artifact: string          # 日志分析.md | 告警归因.md | 根因定位建议.md | 影响范围分析.md | 修复方案建议.md | 故障时间线.md
  confidence: high | medium | low
  layer: confirmed_fact | bounded_inference | open_question
```

Use `layer` to keep blame-less evidence boundaries clear:
- `confirmed_fact`: directly supported by evidence.
- `bounded_inference`: plausible interpretation with named limits.
- `open_question`: important but unresolved.

## Timeline anchor reference schema
`production-incident-postmortem` cites timeline rows by `timeline_anchor_ref`:

```yaml
timeline_anchor_ref:
  anchor_id: string                  # produced by incident-timeline-compilation
  lifecycle_anchor: detection | triage | escalation | diagnosis | mitigation | verification | remediation | recovery | communication | archival
  timestamp: iso8601 | unknown
  evidence_refs: [ref_id]
```

When `production-incident-postmortem` consumes a timeline, it must reuse `anchor_id` rather than rebuilding chronology.

## Standalone guarantee
Every N320 skill must be useful alone:
- Run with its own minimum viable input and no sibling artifacts.
- Produce the target artifact with stable required sections even when evidence is partial.
- Mark missing evidence, unresolved intervals, low-confidence claims, and next best checks instead of inventing facts.
- Preserve a blame-less tone and use role/team ownership instead of personal blame.
- Keep all required metadata fields even if some values are unknown.

## Composition guarantee
Multiple N320 skills should be stronger together:
- Later skills must cite earlier artifacts through `evidence_refs`, `timeline_anchor_ref`, or `downstream_handoff` instead of redoing analysis.
- `incident-timeline-compilation` should provide factual chronology for `production-incident-postmortem`.
- `production-incident-postmortem` should provide causal conclusions, action commitments, and governance learning without rewriting the timeline.
- Conflicting evidence must stay visible with confidence labels.
- The combined output should separate facts, bounded inferences, root causes, and commitments.

## Downstream handoff schema
When producing a handoff, use this shape in prose or YAML-like structure:

```yaml
downstream_handoff:
  contract_version: n320-postmortem-v1.3.2
  handoff_id: HO-N320-<incident_id>-<seq>
  producer_skill: incident-timeline-compilation | production-incident-postmortem
  consumer_skill_or_node: production-incident-postmortem | incident-timeline-compilation | N340 | N390 | governance_kb
  incident_id: <id or provisional id>
  incident_type_branch: <primary branch>
  source_time_window: <window or unknown>
  service_scope: <scope or unknown>
  artifact_target: 故障时间线.md | 线上问题复盘.md
  artifact: <artifact name>
  readiness: draft | partial | ready | blocked
  handoffs:
    - consumer: <sibling skill or downstream node>
      handoff_type: chronology | causal_context | action_commitments | governance_learning | timeline_cleanup
      required_fields: [incident_id, incident_type_branch, evidence_refs]
      evidence_refs: []
      timeline_anchor_refs: []
      missing_evidence: []
      confidence: high | medium | low
      next_best_checks: []
```

## N320 composition paths
### Timeline-first
`incident-timeline-compilation -> production-incident-postmortem`
Use when incident evidence is fragmented and chronology must be reconstructed before RCA and action items.

### Postmortem-first
`production-incident-postmortem -> incident-timeline-compilation`
Use when a draft postmortem exists but the factual chronology needs cleanup, evidence anchors, and blame-less normalization.

### Evidence-only timeline
`incident-timeline-compilation`
Use when the user only needs an audit-safe or regulator-safe factual timeline.

### Learning-only postmortem
`production-incident-postmortem`
Use when the user already has sufficient RCA notes and only needs the final postmortem artifact.

## Common execution workflow
1. Classify available evidence and select mode.
2. Create or normalize `incident_id` and `incident_type_branch`.
3. Populate full metadata using the shared metadata schema.
4. Inventory evidence with structured `evidence_ref` records.
5. Produce the skill-specific artifact sections.
6. Identify missing evidence, open blockers, and owner placeholders.
7. Emit `downstream_handoff` if a sibling skill or downstream node can use the artifact.
8. Run common self-check and skill-specific checks.

## Common input handling
Prefer structured upstream artifacts when present, but never block on them. If only raw notes exist, produce `readiness: partial` and name missing evidence. When N310 handoff fields exist, preserve `incident_id`, `event_type_branch`, service scope, severity, remediation notes, and hotfix/risk context.

## Common self-check
Before finalizing, verify:
1. `contract_version` is `n320-postmortem-v1.3.2` everywhere.
2. `metadata` contains all required fields.
3. `incident_type_branch` mirrors upstream N310 `event_type_branch` when available.
4. `readiness` and `evidence_profile` use allowed enum values.
5. Each major claim has an `evidence_ref` or is labeled as open question.
6. Handoff includes `handoff_id`, producer, consumer, artifact target, required fields, confidence, missing evidence, and next checks.
7. Owner values are roles or teams, not personal names.
8. Severity classification is present, and any why-depth gap is explained.
9. Timeline anchors are reused rather than rebuilt when consuming timeline artifacts.
10. Action items have measurable success criteria when this skill owns action commitments.
11. No files, scripts, directories, or services outside the skill package are required.

## Tone and evidence rules
- Do not name individual people as owners; use role, team, system, process, or mechanism.
- Distinguish confirmed facts, bounded inferences, and open questions.
- Preserve timestamps, evidence anchors, and confidence labels.
- Do not turn an unsupported hypothesis into a root-cause statement.
- Action items must be executable, measurable, and assignable to a role or team.
