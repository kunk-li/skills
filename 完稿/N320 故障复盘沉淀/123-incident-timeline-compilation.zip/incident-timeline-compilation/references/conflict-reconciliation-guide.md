# Conflict Reconciliation Guide

Use this guide when `conflict_reconciliation` mode is selected or when two or more evidence sources disagree.

## When to trigger conflict reconciliation
- Two sources give different timestamps for the same event (difference > 1 minute)
- Two sources describe the same action with different actors or outcomes
- Alert logs and chat logs disagree on detection time
- A responder account contradicts a system log entry

## Conflict entry structure
Every conflict must be recorded in a `## Conflicts` section with this schema:

```yaml
conflict_id: CG-001
conflicting_sources:
  - source_a: "chat-log-2024-06-10, msg 14:32"
  - source_b: "pagerduty-alert, fired 14:27"
conflicting_claims:
  - source_a_claim: "First alert noticed by on-call at 14:32"
  - source_b_claim: "PagerDuty alert fired at 14:27, page sent immediately"
time_gap_minutes: 5
resolution_status: unresolved  # unresolved | resolved_with_evidence | resolved_by_consensus
resolution_note: "Gap likely due to mobile notification delay; exact receipt time unknown"
postmortem_action: "Request on-call engineer to clarify receipt time in postmortem interview"
```

## Resolution status rules
- `unresolved`: Keep both timeline rows with `conflict_group: CG-001` tag. Add to `open_blockers`.
- `resolved_with_evidence`: Only mark resolved when a third authoritative source (log, trace, database timestamp) settles the claim. Cite the settling source.
- `resolved_by_consensus`: Acceptable when all parties involved explicitly agree on the reconciled version. Document who agreed.

## Timeline table handling
For each conflict, insert TWO rows (one per version) with:
- same `lifecycle_anchor`
- different `timestamp`, `evidence_refs`, `confidence`
- shared `conflict_group` tag
- `note` referencing `CG-<id>`

Do NOT average timestamps. Do NOT silently pick one version.

## Escalation to postmortem
All `unresolved` conflicts become `open_blockers` in `downstream_handoff`. The postmortem skill must address each one explicitly — either resolving it or documenting that it remains ambiguous.

## Common false conflicts
- Timezone differences: normalize first before declaring a conflict
- Log propagation delay: system logs often lag 5–30 seconds behind real events; note as `bounded_inference` not conflict
- Rounding: if one source says "~14:30" and another says "14:31", this is not a conflict unless the difference matters causally
