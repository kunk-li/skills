# Timeline Quality Checklist v1.3.2

Before finalizing `故障时间线.md`, verify all items:

## Structure checks
1. Metadata includes every required field from the shared metadata schema.
2. `incident_type_branch` mirrors N310 `event_type_branch` when provided.
3. `selected_mode` is explicitly stated in metadata.
4. At least one detection, mitigation/remediation, recovery, and communication/archival anchor is present — or the missing anchor is named in `open_blockers`.
5. Every major timeline row has `evidence_refs`, `confidence`, and `actor_role` or system name.
6. `evidence_ref` objects follow the shared schema format.

## Conflict checks (new in v1.3.2)
7. All timestamp conflicts between sources are recorded as `conflict_group` entries — none resolved silently.
8. Each conflict has `conflict_id`, `conflicting_sources`, `conflicting_claims`, `resolution_status`, and `resolution_note`.
9. `unresolved` conflicts appear in `open_blockers` and `downstream_handoff`.
10. No timeline row with `conflict_group` tag is the sole representation of that event — both versions must appear.
11. Consult `references/conflict-reconciliation-guide.md` if unsure how to handle a conflict.

## Content quality checks
12. Unknown time intervals are explicit (e.g., `"interval unknown, estimated 3–8 min"`).
13. Owner fields use role/team placeholders only — no personal names, emails, or handles.
14. No root-cause claim is introduced as a timeline fact.
15. Confirmed facts, bounded inferences, and open questions use the `layer` field to distinguish.

## Handoff checks
16. `downstream_handoff` includes `handoff_id`, `timeline_anchor_ref`, `evidence_refs`, `incident_type_branch`, and unresolved gaps.
17. Compare output structure against the closest `examples/` file; differences are intentional.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- `conflict_reconciliation` mode: `## Conflicts` section always present with ≥1 conflict_id entry.
- Every `conflict_group` tag in the timeline has a corresponding entry in `## Conflicts` section.
- `unresolved` conflicts always appear in `downstream_handoff.open_gaps`.

## Output structure completeness checks
- Timeline table has ≥3 anchor rows (detecting_signal + first_responder_action + resolved_or_mitigated)
- Evidence gaps section present; "无证据缺口" when none
- downstream_handoff has `unresolved_gaps` field

## Mode-specific checks

### conflict_reconciliation mode
- `## Conflicts` section with ≥1 conflict_group entry
- Both timestamp versions preserved in timeline (not silently chosen)
- `resolution_status: unresolved` entries in downstream_handoff.unresolved_gaps

### audit_safe_chronology mode
- All times in UTC with offset
- No causal language in timeline entries ("caused by" → not allowed)
- Only admissible evidence sources cited (no internal speculation)
