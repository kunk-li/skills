# Timeline Quality Checklist

Before finalizing `故障时间线.md`, verify:

1. Metadata includes every required field from the shared metadata schema.
2. `incident_type_branch` mirrors N310 `event_type_branch` when provided.
3. At least one detection, mitigation or remediation, recovery, and communication or archival anchor is present, or the missing anchor is named.
4. Every major timeline row has evidence, confidence, and actor role or system.
5. `evidence_ref` objects follow the shared schema.
6. Conflicting evidence is preserved rather than silently resolved.
7. Unknown intervals are explicit.
8. Owner fields use role/team placeholders only.
9. `downstream_handoff` includes `handoff_id` when the postmortem skill or downstream node should consume the timeline.
10. No root-cause claim is introduced as a timeline fact.
11. Compare the produced timeline's metadata key order, field naming,
    and section structure against the most relevant file under
    `examples/`. Differences are allowed but should be intentional.
