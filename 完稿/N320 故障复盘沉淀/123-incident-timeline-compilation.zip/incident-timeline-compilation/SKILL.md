---
name: incident-timeline-compilation
description: 编译事实性、免责式事故时间线（故障时间线）用于 n320 故障沉淀。triggered when you need to reconstruct what happened during an incident from logs, alerts, chat exports, or on-call notes. use conflict_reconciliation mode when timestamps conflict; use audit_safe_chronology when compliance is required. do not use for root cause analysis (→ #124), action item extraction (→ n340 #131), or risk assessment (→ n350 #138).
---

# Incident Timeline Compilation

## N320 contract baseline (n320-postmortem-v1.3.2)

- contract_version: `n320-postmortem-v1.3.2`
- workflow node: N320
- skill_id: 123
- primary artifact: `故障时间线.md`
- sibling skill: `production-incident-postmortem` (#124)
- downstream nodes: N340 #131, N390, audit/governance knowledge bases when requested
- packaging rule: self-contained; do not rely on node-level files or hidden registries outside this skill package.
- composition rule: exchange artifacts through `downstream_handoff` using `timeline_anchor_ref`, `evidence_refs`, `incident_type_branch`, and `unresolved_gaps`.

## Role

作为 N320 故障沉淀层的**事故时间线编译器**，从分散的日志、告警、聊天记录和操作记录中重建事实性时间线。

具体职责：
- 只记录**发生了什么、什么时间、谁操作**——不写因果判断（因果分析属于 #124）
- 冲突时间戳进入 `conflict_reconciliation` 模式，双版本都保留，不静默选择
- 每条 timeline 行必须有 `evidence_refs`；无法确认时标 `待核对`
- 每条证据使用 `layer` 字段区分：`confirmed`（已确认事实）/ `inferred`（有根据推断）/ `open_question`（待核实）
- 为 #124 提供 `timeline_anchor_ref` 和 `unresolved_gaps`

**不负责**：根因分析（→ #124）、行动项提取（→ N340 #131）、风险评估（→ N350 #138）、会议内容复述。

## When NOT to use this skill

- **Not a root cause analysis**: the timeline owns chronology, not causation; route causal analysis to #124.
- **Not a postmortem**: #123 owns "what happened and when"; #124 owns "why it happened and what changes".
- **Not an action item tracker**: action items from incidents flow to #124 downstream_handoff → N340 #131.
- **Not a risk register**: forward-looking risks belong in N350 #138; #123 documents what already occurred.

## Standalone and composition role

```yaml
standalone_goal: reconstruct a trustworthy incident timeline from partial or complete evidence
minimum_viable_input:
  any_of:
    - alert or monitoring events
    - log excerpts or trace snippets
    - incident chat notes or ticket updates
    - N310 response, remediation, or hotfix handoff notes
    - responder notes, rollback notes, or communications
partial_readiness_allowed: true
degradation_behavior: >
  If evidence is sparse, output a skeleton timeline with ≥3 anchor rows using whatever
  is available. Mark each row with layer=open_question and list all missing sources in
  Section 2. Pass unresolved_gaps to #124 — do not block on completeness.
composition_role: factual_chronology_builder
function_bias: chronology_first_evidence_normalization
best_combines_with:
  - production-incident-postmortem
join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - incident_type_branch
  - evidence_refs
  - timeline_anchor_ref
strengthens:
  production-incident-postmortem: supplies factual chronology, evidence anchors, timeline_anchor_ref, branch preservation, and unresolved timeline gaps
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `fragment_reconstruction`: evidence is scattered across logs, chats, screenshots, or tickets.
- `audit_safe_chronology`: timeline must be factual, regulator-safe, or compliance-safe.
- `handoff_timeline`: main goal is to feed `production-incident-postmortem`; optimize for join-key completeness.
- `conflict_reconciliation`: timestamps, accounts, or evidence fragments disagree — **preserve all conflicting versions; never silently discard one side.**

**Default routing**: if two or more sources give contradicting timestamps → `conflict_reconciliation`. If N310 upstream exists → `handoff_timeline`. Otherwise → `fragment_reconstruction`.

Always set `incident_type_branch`. When N310 provides `event_type_branch`, copy it into `incident_type_branch` and preserve through `downstream_handoff`.

## Primary inputs

Prefer these inputs when available:
- `日志分析.md`, `告警归因.md`, `Trace分析.md`
- `根因定位建议.md` — use only as late conclusion reference, not as timeline fact
- N310 `值班处置建议.md`, `修复方案建议.md`, `热修风险评估.md`
- alert records, log excerpts, trace snapshots, ticket updates, chat notes, monitoring screenshots, rollback notes

Also accept partial fragments, raw notes, or mixed evidence.

**Input conflict resolution**: when prior snapshot and new input disagree on the same event, prefer the source with the earlier timestamp and higher `layer` certainty. Record the conflict explicitly — never silently override.

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | Metadata (artifact_id, selected_mode, incident_type_branch) | Always | — |
| 2 | Evidence inventory and missing sources | Always | List every source checked; mark unavailable as `缺失` |
| 3 | Timezone and normalization rules | Always | State chosen timezone; list per-source offsets |
| 4 | Timeline table | Always | Min 3 anchor rows; each row has evidence_refs + layer |
| 5 | Lifecycle anchor summary | Always | Condensed key timestamps extracted from timeline |
| 6 | Conflicts section | Always in conflict_reconciliation; conditional otherwise | conflict_group + both versions + resolution_status |
| 7 | Evidence gaps and unresolved items | Always | "无证据缺口" if none; never omit |
| 8 | Downstream handoff | Always | Pass to #124; include unresolved_gaps |

> Legend: Always = required in every mode; Conditional = required when evidence or mode triggers it.

Each timeline entry should include: `anchor_id` · `timestamp` · `timezone` · `lifecycle_anchor` · `layer` · `actor_role` · `signal` · `action` · `state_change` · `evidence_refs` · `confidence` · `note`

## Design rules

- Own what happened and when. Do not own why it happened or what must change.
- Keep the timeline factual. Never embed root-cause conclusions unless explicitly framed as later conclusions with evidence.
- Use `layer` field on every evidence reference: `confirmed` / `inferred` / `open_question`.
- Normalize timestamps to one timezone and state it explicitly.
- Use a blame-less style at all times. Owners must be roles or teams, not individuals.
- **Conflict handling**: if multiple fragments conflict, keep BOTH versions as separate rows with `conflict_group` tag and `conflict_note`. Do not silently discard one version. Add a resolution row only when definitively resolved with evidence.

## Conflict reconciliation guidance

When using `conflict_reconciliation` mode:
- Open a `## Conflicts` section with: `conflict_id`, `conflicting_sources`, `conflicting_claims`, `resolution_status` (`unresolved` / `resolved_with_evidence` / `resolved_by_consensus`), `resolution_note`.
- Unresolved conflicts become `open_blockers` in downstream_handoff for #124.
- Never pick one version and discard the other without documented evidence.

## Execution workflow

1. Inventory available evidence; list missing sources.
2. Normalize timestamps, timezone, system names, role labels.
3. Create metadata: `incident_type_branch`, `readiness`, `evidence_profile`, `open_blockers`, `owner_placeholders`.
4. Convert raw sources into structured `evidence_ref` records with `layer` tags.
5. Extract event candidates; map each to the narrowest valid lifecycle anchor.
6. Build chronology in timestamp order; assign stable `anchor_id` values.
7. **Detect and record conflicts**: every disagreement across sources → `conflict_group` entry.
8. Populate Conflicts section; update resolution_status for each conflict.
9. Add unresolved items for postmortem investigation.
10. Emit `downstream_handoff` for #124.
11. Self-check: run `references/timeline-quality-checklist.md` before finalizing.

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: production-incident-postmortem
  timeline_anchor_ref: TL-INC-*-001
  evidence_refs: [chat:slack-incident, log:payment-service-20250612]
  incident_type_branch: cache_stampede
  unresolved_gaps: ["T+23m to T+31m 无操作记录"]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all major anchors covered) / `partial` (some gaps but usable) / `degraded` (skeleton only — serious evidence shortage; #124 must note gaps explicitly).

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** 时间戳存在冲突但直接选择一个版本 → 必须使用 `conflict_reconciliation` 模式，两个版本都保留在 timeline 表中，并在 `## Conflicts` 节记录 `resolution_status`。量化检验：当两个时间源对同一事件时间差 > 5min，conflict_group 数必须 ≥ 1，否则视为违例。
- **AP-2** 在时间线中直接写因果判断（"因为 X 导致 Y"）→ timeline 只记录事实；因果分析属于 postmortem #124。量化检验：正则 `(因为|导致|所以|because|caused by)` 出现在非 evidence_refs 字段时计入违例。
- **AP-3** `evidence_refs` 留空 → 每条 timeline 行必须有可追溯来源；无法确认时写 `待核对`，layer 设为 `open_question`。量化检验：timeline 表中 evidence_refs 为空的行数 = open_blocker 数，且不得为 0（至少每行都有占位）。
- **AP-4** 把推断（inferred）当作确认事实（confirmed）输出 → 必须在 `layer` 字段区分；推断行加明确标注。量化检验：包含 `layer: confirmed` 的行中，出现 `推测`/`可能`/`estimated`/`assumed` 等词语的行数必须 = 0。

## References

Read only when relevant to the request:
- `../../../_fixtures/n320-n360-end-to-end/README.md` — cross-skill end-to-end test fixture; read when verifying cross-node artifact handoffs
- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming IDs across skills
- `references/n320-shared-postmortem-contract.md` — shared metadata, evidence, branch, handoff, composition rules
- `references/n320-incident-type-branches.md` — when classifying incident_type_branch
- `references/n320-severity-classification-rubric.md` — when severity or recurrence affects emphasis
- `references/tl-blame-less-rules.md` — when drafting or checking tone
- `references/timeline-anchor-guide.md` — when deciding lifecycle anchors
- `references/conflict-reconciliation-guide.md` — when using conflict_reconciliation mode
- `references/timeline-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing (v1.3.2)
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Workflow position

```
Raw evidence (logs, chat, alerts, N310 handoff notes)
  ↓ #123 (factual chronology → 故障时间线.md)
  ↓ #124 (causal analysis + action items → 线上问题复盘.md)
  ↓ N340 #131 (action items → 行动项清单.csv)
```

## Examples

- `examples/availability-handoff-timeline.md` — handoff_timeline mode with N310 upstream
- `examples/compliance-audit-safe-chronology.md` — audit_safe_chronology for regulator-safe framing
- `examples/conflict-reconciliation-cache-stampede.md` — conflict_reconciliation with CG-001 unresolved conflict preserved
