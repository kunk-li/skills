---
name: incident-timeline-compilation
description: compile factual, blame-less incident timelines for n320 postmortem work. use when chatgpt must reconstruct what happened and when from alerts, logs, traces, tickets, chat notes, monitoring screenshots, responder notes, n310 response handoffs, or partial incident fragments. produces 故障时间线.md with required metadata, incident_type_branch, structured evidence_refs, lifecycle anchors, conflicts, confidence labels, and downstream handoff for production-incident-postmortem.
---

# Incident Timeline Compilation

## Role
Produce a fact-first, blame-less incident timeline for the N320 node. Convert scattered operational evidence into a chronology that humans and sibling skills can trust.

## N320 encapsulation baseline
This skill package is self-contained. Standalone execution and multi-skill composition rely only on files packaged inside this skill plus artifacts exchanged through `downstream_handoff`. Do not require node-level files, external tools, or hidden registries.

## Stage position
- workflow node: N320
- node goal: 整理故障时间线并输出线上问题复盘
- primary artifact: `故障时间线.md`
- sibling skill: `production-incident-postmortem`
- downstream nodes: N340, N390, audit/governance knowledge bases when requested

## Standalone and composition role
```yaml
contract_version: n320-postmortem-v1.3.1
skill_id: 123
skill_name: incident-timeline-compilation
composition_role: factual_chronology_builder
function_bias: chronology_first_evidence_normalization
stage_position: operations_governance.postmortem_consolidation.timeline
standalone_goal: reconstruct a trustworthy incident timeline from partial or complete evidence
minimum_viable_input:
  any_of:
    - alert or monitoring events
    - log excerpts or trace snippets
    - incident chat notes or ticket updates
    - N310 response, remediation, or hotfix handoff notes
    - responder notes, rollback notes, or communications
stable_artifact: 故障时间线.md
best_combines_with:
  - production-incident-postmortem
join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - incident_type_branch
  - evidence_refs
  - timeline_anchor_ref
strengthens:
  production-incident-postmortem: supplies factual chronology, evidence anchors, timeline_anchor_ref values, branch preservation, and unresolved timeline gaps
```

## Mode selection
Choose one mode and state it in metadata `selected_mode`:
- `fragment_reconstruction`: use when evidence is scattered across logs, chats, screenshots, or tickets.
- `audit_safe_chronology`: use when the timeline must be factual, regulator-safe, or compliance-safe.
- `handoff_timeline`: use when the main goal is to feed `production-incident-postmortem`.
- `conflict_reconciliation`: use when timestamps, accounts, or evidence fragments disagree.

Always set `incident_type_branch`. When N310 provides `event_type_branch`, copy it into `incident_type_branch` and preserve it through `downstream_handoff`.

## Primary inputs
Prefer these inputs when available:
- `日志分析.md`
- `告警归因.md`
- `Trace分析.md`
- `根因定位建议.md` only as a late conclusion reference, not as timeline fact
- N310 `值班处置建议.md`, `修复方案建议.md`, `热修风险评估.md`
- alert records, log excerpts, trace snapshots, ticket updates, chat notes, monitoring screenshots, rollback notes

Also accept partial fragments, raw notes, or mixed evidence.

## Output structure
Default output can be saved as `故障时间线.md`.

Use this structure:
1. metadata
2. evidence inventory and missing sources
3. timezone and normalization rules
4. timeline table
5. lifecycle anchor summary
6. conflicts and uncertainty
7. unresolved items for postmortem
8. downstream handoff

Each timeline entry should prefer these fields:
- `anchor_id`
- `timestamp`
- `timezone`
- `lifecycle_anchor`
- `actor_role`
- `signal`
- `action`
- `state_change`
- `evidence_refs`
- `owner_role`
- `escalation`
- `communication`
- `confidence`
- `note`

## Design rules
- Own what happened and when. Do not own why it happened or what must change.
- Keep the timeline factual. Do not embed root-cause conclusions unless explicitly framed as later conclusions with evidence.
- Separate confirmed fact, bounded inference, and open question using the `layer` field in evidence references.
- Normalize timestamps to one timezone if possible and state the timezone.
- Preserve evidence anchors. Every major event should point to structured `evidence_ref` records.
- Use a blame-less style at all times. Owners must be roles or teams, not individuals.
- If multiple fragments conflict, keep both with a conflict note instead of silently choosing one.
- If the incident involves a sensitive operating window, describe it generically such as `compliance-sensitive-window`.
- Apply severity classification if severity or recurrence evidence is available, but do not invent missing severity facts.

## Reference files
Read these bundled files only when relevant:
- `references/n320-shared-postmortem-contract.md` for shared metadata, evidence, branch, handoff, and composition rules.
- `references/n320-incident-type-branches.md` when classifying or preserving incident type branch.
- `references/n320-severity-classification-rubric.md` when severity or recurrence affects timeline emphasis.
- `references/tl-blame-less-rules.md` when drafting or checking tone.
- `references/timeline-anchor-guide.md` when deciding lifecycle anchors.
- `references/timeline-quality-checklist.md` before finalizing timeline quality.
- `references/output-contract.yaml` when a machine-readable artifact contract is needed.

## Execution workflow
1. Inventory available evidence and list missing sources.
2. Normalize timestamps, timezone, system names, and role labels.
3. Create full metadata, including `incident_type_branch`, `readiness`, `evidence_profile`, `open_blockers`, and `owner_placeholders`.
4. Convert raw sources into structured `evidence_ref` records.
5. Extract event candidates and map each to the narrowest valid lifecycle anchor.
6. Build the chronology in timestamp order and assign stable `anchor_id` values.
7. Separate confirmed facts from bounded inference and open questions.
8. Add unresolved items for postmortem investigation.
9. Emit `downstream_handoff` for `production-incident-postmortem` when useful.
10. Run the shared common self-check and timeline quality checklist.

## Dynamic completeness
At minimum, include:
- earliest detection point
- first responder or triage action
- decisive mitigation, rollback, or containment step
- restoration or verification point
- communication or archival endpoint

If data is richer, expand to a full anchor-by-anchor timeline.

## Quality bar
A good result:
- reads as a trustworthy chronology rather than an opinion piece
- contains no personal blame framing
- can be handed directly to `production-incident-postmortem` without reformatting
- makes missing evidence visible
- preserves `incident_type_branch` and structured evidence references
- distinguishes action taken from state change observed

## Composition contract
When `production-incident-postmortem` is also used:
- this skill owns factual chronology
- the postmortem skill owns causal analysis and improvement commitments
- pass `timeline_anchor_ref`, `evidence_refs`, `incident_type_branch`, `source_time_window`, and unresolved gaps through `downstream_handoff`
- do not pre-fill root-cause claims into the timeline
## Examples
Consult these packaged examples only when a concrete output pattern is helpful:
- `examples/availability-handoff-timeline.md`
- `examples/compliance-audit-safe-chronology.md`

