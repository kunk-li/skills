# Example: Availability Handoff Timeline

```yaml
metadata:
  contract_version: n320-postmortem-v1.3.2
  workflow_node: N320
  skill_id: "123"
  skill_name: incident-timeline-compilation
  selected_mode: handoff_timeline
  readiness: ready
  incident_id: INC-2026-0507-AVAIL-001
  incident_id_aliases: []
  source_time_window:
    start: 2026-05-07T09:10:00+09:00
    end: 2026-05-07T10:05:00+09:00
    timezone: Asia/Tokyo
  service_scope: [checkout-api, payment-callback]
  incident_type_branch: availability
  secondary_branches: [performance]
  evidence_profile: multi_source
  confidence: medium
  composition_role: factual_chronology_builder
  function_bias: chronology_first_evidence_normalization
  stage_position: operations_governance.postmortem_consolidation.timeline
  node_artifact_target: 故障时间线.md
  open_blockers: []
  owner_placeholders: [sre_on_call, checkout_service_owner]
  severity_classification:
    compliance_impact: none
    user_impact: widespread
    reversibility: hard
    recurrence: first_occurrence
    total_score: 5
    severity_class: Major
    target_min_why_depth: L3
    achieved_why_depth: unknown
    why_depth_gap_explained: null
  tool_collaboration_mode: single_incident_postmortem
```

## Evidence inventory and missing sources
- EV-001 alert checkout availability dropped below SLO.
- EV-002 N310 修复方案建议.md reports event_type_branch=availability.
- EV-003 responder notes confirm rollback started at 09:42 JST.
- Missing: final customer impact count by segment.

## Timeline table
| anchor_id | timestamp | lifecycle_anchor | actor_role | signal | action | state_change | evidence_refs | confidence |
|---|---|---|---|---|---|---|---|---|
| TA-001 | 2026-05-07T09:10:00+09:00 | detection | monitoring_system | availability alert fired | routed to sre_on_call | incident opened | [EV-001] | high |
| TA-002 | 2026-05-07T09:21:00+09:00 | diagnosis | sre_on_call | error surge after deploy | compared deploy window | rollback candidate found | [EV-002] | medium |
| TA-003 | 2026-05-07T09:42:00+09:00 | mitigation | release_engineering | rollback approved | rollback started | error rate began falling | [EV-003] | medium |
| TA-004 | 2026-05-07T10:05:00+09:00 | recovery | sre_on_call | SLO recovered | monitored for 20 minutes | incident stable | [EV-001, EV-003] | medium |

## Unresolved items for postmortem
- Verify whether feature flag fallback should have prevented full checkout unavailability.
- Confirm exact user segment impact before final severity statement.

## Downstream handoff
```yaml
downstream_handoff:
  contract_version: n320-postmortem-v1.3.2
  handoff_id: HO-N320-INC-2026-0507-AVAIL-001-001
  producer_skill: incident-timeline-compilation
  consumer_skill_or_node: production-incident-postmortem
  incident_id: INC-2026-0507-AVAIL-001
  incident_type_branch: availability
  artifact_target: 故障时间线.md
  readiness: ready
  handoffs:
    - consumer: production-incident-postmortem
      handoff_type: chronology
      required_fields: [incident_id, incident_type_branch, evidence_refs]
      timeline_anchor_refs: [TA-001, TA-002, TA-003, TA-004]
      missing_evidence: [customer impact segment count]
      confidence: medium
      next_best_checks: [verify fallback behavior, confirm impact count]
```
