# Example: Cache Stampede — Conflict Reconciliation Timeline

Demonstrates `conflict_reconciliation` mode: two conflicting detection timestamps preserved, neither discarded.

```yaml
metadata:
  contract_version: n320-postmortem-v1.3.2
  skill_id: "123"
  selected_mode: conflict_reconciliation
  incident_id: INC-2025-0612-CACHE-001
  incident_type_branch: cache_stampede
  readiness: partial
  open_blockers:
    - "CG-001 unresolved: engineer receipt time differs 5 min across sources"
  source_time_window: {start: "2025-06-12T14:20:00+09:00", end: "2025-06-12T15:45:00+09:00", timezone: Asia/Tokyo}
```

## Evidence Inventory

| evidence_id | source | confidence | layer |
|-------------|--------|------------|-------|
| EV-001 | pagerduty-alert-log | high | confirmed_fact |
| EV-002 | on-call-chat-export | medium | bounded_inference |
| EV-003 | redis-metrics-grafana | high | confirmed_fact |
| EV-004 | app-log-order-service | high | confirmed_fact |

## Timeline Table

| anchor_id | timestamp | lifecycle_anchor | actor_role | signal | action | state_change | evidence_refs | confidence | conflict_group | note |
|-----------|-----------|-----------------|------------|--------|--------|--------------|---------------|------------|----------------|------|
| TL-001 | 14:27:03 | detection | monitoring-system | Redis hit-rate <5% | PagerDuty alert fired | Cache miss rate critical | EV-001 | high | — | Confirmed by PD log |
| TL-002a | 14:27 | detection | on-call-engineer | Page received | Engineer acknowledges | Response initiated | EV-001 | high | CG-001 | Version A: PD shows page sent 14:27 |
| TL-002b | 14:32 | detection | on-call-engineer | "saw the alert" in chat | Engineer first mentions incident | Response initiated | EV-002 | medium | CG-001 | Version B: Chat log 14:32 |
| TL-003 | 14:35 | triage | on-call-engineer | Redis KEYS shows 0 hot entries | Cold cache confirmed after 14:31 deploy | Root cause hypothesis | EV-003,EV-004 | high | — | Cache cleared by deploy, not traffic |
| TL-004 | 14:52 | mitigation | on-call-engineer | Runbook warm-up script | Ran cache warm-up | Hit rate recovering | EV-004 | high | — | |
| TL-005 | 15:01 | recovery | monitoring-system | Redis hit-rate >90% | Recovery confirmed | Service restored | EV-003 | high | — | |
| TL-006 | 15:12 | communication | incident-commander | Summary drafted | Summary sent | Incident closed | EV-002 | medium | — | |

## Conflicts

### CG-001: On-call engineer detection time

```yaml
conflict_id: CG-001
conflicting_sources:
  - source_a: "EV-001 (PagerDuty log)"
  - source_b: "EV-002 (chat export)"
conflicting_claims:
  - source_a_claim: "Page sent at 14:27"
  - source_b_claim: "Engineer first mentioned alert at 14:32 in chat"
time_gap_minutes: 5
resolution_status: unresolved
resolution_note: "Mobile notification delay likely. Neither source authoritative for exact receipt time."
postmortem_action: "Request engineer to clarify receipt time; check PD mobile delivery log"
```

Both TL-002a and TL-002b preserved in timeline. Not averaged, not silently resolved.

## Unresolved Items for Postmortem

1. CG-001: Exact MTTA — affects whether alert routing was adequate
2. 14:31 deploy trigger: who initiated, was it the root cause of cache clear?

## Downstream Handoff

```yaml
handoff_id: TL-INC-2025-0612-001
producer_skill: incident-timeline-compilation
consumer_skill_or_node: production-incident-postmortem
incident_type_branch: cache_stampede
open_gaps:
  - "CG-001: engineer detection time unresolved"
  - "14:31 deploy initiator unknown"
readiness: partial
confidence: medium
```
