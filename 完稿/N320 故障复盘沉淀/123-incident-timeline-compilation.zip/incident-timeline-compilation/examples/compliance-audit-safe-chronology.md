# Example: Compliance Audit-Safe Chronology

```yaml
metadata:
  contract_version: n320-postmortem-v1.3.1
  workflow_node: N320
  skill_id: "123"
  skill_name: incident-timeline-compilation
  selected_mode: audit_safe_chronology
  readiness: partial
  incident_id: TEMP-N320-2026-0507-audit-note
  incident_id_aliases: [provisional]
  source_time_window:
    start: 2026-05-07T14:00:00+09:00
    end: unknown
    timezone: Asia/Tokyo
  service_scope: [account-export]
  incident_type_branch: compliance
  secondary_branches: []
  evidence_profile: assumption_only
  confidence: low
  composition_role: factual_chronology_builder
  function_bias: chronology_first_evidence_normalization
  stage_position: operations_governance.postmortem_consolidation.timeline
  node_artifact_target: 故障时间线.md
  open_blockers: [official incident id, audit log export, privacy reviewer signoff]
  owner_placeholders: [privacy_review_role, service_owner]
  severity_classification:
    compliance_impact: review
    user_impact: isolated
    reversibility: controlled
    recurrence: first_occurrence
    total_score: unknown
    severity_class: unknown
    target_min_why_depth: unknown
    achieved_why_depth: unknown
    why_depth_gap_explained: severity review not complete
  tool_collaboration_mode: single_incident_postmortem
```

## Timeline table
| anchor_id | timestamp | lifecycle_anchor | actor_role | signal | action | state_change | evidence_refs | confidence |
|---|---|---|---|---|---|---|---|---|
| TA-001 | 2026-05-07T14:00:00+09:00 | detection | support_role | user reported unexpected export visibility | ticket opened | compliance review started | [EV-001] | low |
| TA-002 | unknown | triage | privacy_review_role | audit log unavailable | requested log export | blocker recorded | [EV-002] | low |

## Conflicts and uncertainty
- The exact first exposure time is unknown.
- No personal owner names are used; only role placeholders are retained.

## Downstream handoff
`readiness: partial`; next best check is to obtain audit log export before any postmortem claims become confirmed facts.
