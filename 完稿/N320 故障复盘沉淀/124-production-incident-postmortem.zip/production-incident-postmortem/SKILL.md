---
name: production-incident-postmortem
description: produce blame-less production incident postmortems for n320 postmortem work. use when chatgpt must turn timelines, rca notes, impact analysis, remediation notes, rollback records, n310 response handoffs, communications, or raw incident evidence into 线上问题复盘.md with metadata schema, incident_type_branch, severity-classified why-depth, structured evidence_refs, root causes, action items, and governance learning.
---

# Production Incident Postmortem

## Role
Produce a blame-less, evidence-backed postmortem for the N320 node. Turn incident evidence into a reusable explanation of what happened, why it happened, and what must change.

## N320 encapsulation baseline
This skill package is self-contained. Standalone execution and multi-skill composition rely only on files packaged inside this skill plus artifacts exchanged through `downstream_handoff`. Do not require node-level files, external tools, or hidden registries.

## Stage position
- workflow node: N320
- node goal: 整理故障时间线并输出线上问题复盘
- primary artifact: `线上问题复盘.md`
- sibling skill: `incident-timeline-compilation`
- downstream nodes: N340, N390, audit/governance knowledge bases when requested

## Standalone and composition role
```yaml
contract_version: n320-postmortem-v1.3.1
skill_id: 124
skill_name: production-incident-postmortem
composition_role: causal_learning_and_action_commitment
function_bias: systemic_learning_action_commitments
stage_position: operations_governance.postmortem_consolidation.postmortem
standalone_goal: produce a blame-less postmortem from timeline, rca, impact, remediation, or raw incident evidence
minimum_viable_input:
  any_of:
    - incident timeline or chronology notes
    - root-cause analysis notes
    - impact-scope analysis or customer impact notes
    - N310 response, remediation, or hotfix handoff notes
    - remediation, rollback, or incident communication notes
stable_artifact: 线上问题复盘.md
best_combines_with:
  - incident-timeline-compilation
join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - incident_type_branch
  - evidence_refs
  - timeline_anchor_ref
strengthens:
  incident-timeline-compilation: can request timeline gap clarification and cite chronology anchors instead of rebuilding the timeline
```

## Mode selection
Choose one mode and state it in metadata `selected_mode`:
- `timeline_backed_postmortem`: use when `故障时间线.md` or structured chronology is available.
- `rca_notes_to_postmortem`: use when RCA notes exist but no polished postmortem exists.
- `evidence_limited_postmortem`: use when evidence is partial and gaps must be explicit.
- `action_commitment_review`: use when the user mainly needs follow-up actions, owners, deadlines, and success criteria.

Always set `incident_type_branch`. Use `references/n320-severity-classification-rubric.md` to determine `severity_classification` and target why-depth.

## Primary inputs
Prefer these inputs when available:
- `故障时间线.md`
- `根因定位建议.md`
- `影响范围分析.md`
- `修复方案建议.md`
- N310 `值班处置建议.md`, `修复方案建议.md`, `热修风险评估.md`
- remediation notes, rollback notes, incident communications, decision logs

If no timeline exists, proceed from incident evidence, but mark the chronology as incomplete and list timeline gaps.

## Output structure
Default output can be saved as `线上问题复盘.md`.

Use this structure:
1. metadata
2. executive summary
3. business and technical impact
4. factual chronology reference
5. five-whys analysis
6. contributing factor categories
7. root cause statement with confidence
8. containment and remediation already taken
9. action items
10. follow-up risks and learning
11. evidence gaps or unanswered questions
12. downstream handoff

## Design rules
- Own why it happened and what must change. Do not own full chronology reconstruction when `incident-timeline-compilation` has produced one.
- Keep the tone blame-less. Talk about systems, signals, controls, handoffs, and process gaps instead of blaming people.
- Separate symptom, near cause, systemic cause, organizational cause, and strategic cause.
- Use severity classification to set target why-depth.
- Use five-whys and push the analysis to the target why-depth unless evidence does not support it.
- Organize causes across role clarity, process/review flow, technology/system behavior, monitoring/observability, and governance/mechanism categories.
- If evidence only supports a hypothesis, label it as hypothesis and attach confidence.
- Convert lessons into concrete action items. Avoid vague actions such as "improve awareness" unless converted into measurable work.
- Preserve timeline anchors and evidence refs instead of rewriting the timeline.
- Use `open_blockers` for unresolved evidence gaps and `owner_placeholders` for role/team owners.

## Reference files
Read these bundled files only when relevant:
- `references/n320-shared-postmortem-contract.md` for shared metadata, evidence, branch, handoff, and composition rules.
- `references/n320-incident-type-branches.md` when preserving N310 branch intent or classifying incidents.
- `references/n320-severity-classification-rubric.md` before deciding why-depth.
- `references/tl-blame-less-rules.md` before finalizing tone.
- `references/why-depth-rubric.md` when checking RCA depth.
- `references/cause-category-rubric.md` when classifying contributing factors.
- `references/action-item-contract.md` when shaping corrective actions.
- `references/postmortem-quality-checklist.md` before finalizing postmortem quality.
- `references/output-contract.yaml` when a machine-readable artifact contract is needed.

## Execution workflow
1. Consolidate the incident summary from timeline and source evidence.
2. Create full metadata, including `incident_type_branch`, `severity_classification`, `readiness`, `evidence_profile`, `open_blockers`, and `owner_placeholders`.
3. State impact in user, service, data, compliance, and operational terms when possible.
4. Reuse timeline anchors if available; otherwise mark chronology as evidence-limited.
5. Build the five-whys chain and push until target why-depth or evidence limit.
6. Classify contributing factors across the five cause categories.
7. Draft a root-cause statement supported by evidence, not intuition.
8. Convert lessons into action items with required execution fields.
9. Run blame-less, severity, why-depth, action-item, and quality checks.
10. Emit `downstream_handoff` for governance, knowledge, or timeline cleanup when useful.

## Why-depth expectations
Use these depth levels:
- `L1 symptom`: what visibly failed
- `L2 near_cause`: the immediate technical or procedural trigger
- `L3 systemic_cause`: missing guardrail, review, ownership, validation, or design rule
- `L4 organizational_cause`: recurring cross-team or operating-model weakness
- `L5 strategic_cause`: incentives, values, or long-term structural choices

Set target depth using the severity rubric. If stopping earlier, explain why in `severity_classification.why_depth_gap_explained`.

## Action item contract
Every action item should include:
- `action_item_id`
- `what`
- `who_role`
- `deadline`
- `success_criteria`
- `dependency`
- `verification_method`
- `prevention_type`
- `decision_weight_profile` when prioritization is needed

## Dynamic completeness
At minimum, include:
- concise incident summary
- impact statement
- one five-whys chain
- supported root-cause statement
- action-item table with owners and deadlines
- evidence gap list

When evidence is richer, expand to a full postmortem package.

## Quality bar
A good result:
- is clearly blame-less
- reaches severity-appropriate systemic depth instead of stopping at surface causes
- makes confidence and evidence visible
- turns lessons into actions that can be tracked
- preserves N310 branch intent through `incident_type_branch`
- can be consumed directly by audit, governance, or best-practice documentation

## Composition contract
When `incident-timeline-compilation` is also used:
- reuse timeline anchors and evidence refs instead of rebuilding chronology
- cite chronology gaps as evidence gaps rather than hiding them
- return action commitments and causal conclusions through `downstream_handoff`
- request timeline clarification only for missing facts that affect root cause or action quality
## Examples
Consult these packaged examples only when a concrete output pattern is helpful:
- `examples/availability-full-postmortem.md`
- `examples/batch-recurrence-review.md`

