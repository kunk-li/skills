---
name: production-incident-postmortem
description: Turn a completed incident timeline into a blameless postmortem with why-chain (>=L3), action items, and recurrence analysis; recurrence_pattern_postmortem mode.
---

# Production Incident Postmortem

## N320 contract baseline (n320-postmortem-v1.3.2)

- contract_version: `n320-postmortem-v1.3.2`
- workflow node: N320
- skill_id: 124
- primary artifact: `线上问题复盘.md`
- sibling skill: `incident-timeline-compilation` (#123)
- downstream nodes: N340 #131, N390, audit/governance knowledge bases when requested
- packaging rule: self-contained; do not rely on node-level files or hidden registries outside this skill package.
- composition rule: exchange artifacts through `downstream_handoff` using `incident_id`, `action_item_id`, `evidence_refs`, and `timeline_anchor_ref`.

## Role

作为 N320 故障沉淀层的**生产事故复盘生成器**，在 #123 时间线基础上进行因果分析和系统性改进。

具体职责：
- Why-chain 深度 ≥L3（不允许在 L2 停止，除非有明确证据缺口说明）
- Action item specificity test：每条行动项必须通过 what + who_role + when + verify 四元素检验
- `recurrence_pattern_postmortem` 模式：必须审计历史同类事故的 action item 完成状态
- 产出 action_items 供 N340 #131 结构化追踪

**不负责**：时间线编译（→ #123）、任务追踪（→ N350 #135/#136）、治理决策（→ N380）、FAQ 积累（→ N340 #133）。

## When NOT to use this skill

- **Not a timeline compiler**: if the primary task is reconstructing "what happened and when", use #123 first; #124 builds on the timeline.
- **Not a task tracker**: action items are produced here but tracked in N350 #135/#136; cite by `action_item_id`.
- **Not a governance decision maker**: #124 recommends; final governance decisions belong to N380 or the designated decision body.
- **Not an FAQ generator**: recurring questions from postmortems belong in N340 #133; #124 identifies them, not documents them.

## Standalone and composition role

```yaml
standalone_goal: produce a blame-less postmortem from timeline, rca, impact, remediation, or raw incident evidence
minimum_viable_input:
  any_of:
    - incident timeline or chronology notes (故障时间线.md preferred)
    - root-cause analysis notes
    - impact-scope analysis or customer impact notes
    - N310 response, remediation, or hotfix handoff notes
    - remediation, rollback, or incident communication notes
partial_readiness_allowed: true
degradation_behavior: >
  If no timeline artifact exists, proceed from incident evidence but mark Section 4
  (chronology) as "incomplete — timeline gaps listed". Output evidence_limited_postmortem
  mode. Do not block on timeline absence; explicitly list what is missing for reviewers.
  Why-chain may stop at L2 ONLY when a specific evidence gap is documented and named.
composition_role: causal_learning_and_action_commitment
function_bias: systemic_learning_action_commitments
best_combines_with:
  - incident-timeline-compilation
join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - incident_type_branch
  - evidence_refs
  - timeline_anchor_ref
strengthens:
  incident-timeline-compilation: can request timeline gap clarification and cite chronology anchors instead of rebuilding timeline
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `timeline_backed_postmortem`: `故障时间线.md` or structured chronology is available.
- `rca_notes_to_postmortem`: RCA notes exist but no polished postmortem.
- `evidence_limited_postmortem`: evidence is partial; gaps must be explicit in every section. Why-chain depth may be limited by evidence — document the constraint.
- `action_commitment_review`: user mainly needs follow-up actions, owners, deadlines, and success criteria.
- **`recurrence_pattern_postmortem`**: this is a repeat incident or the same category has appeared before. Add `## Recurrence Analysis` section cross-referencing prior incident IDs, comparing why-chains, and explicitly stating whether prior action items were completed.

**Default routing**: `故障时间线.md` exists → `timeline_backed_postmortem`. RCA notes only → `rca_notes_to_postmortem`. Sparse evidence → `evidence_limited_postmortem`. Repeat category → `recurrence_pattern_postmortem`.

Always set `incident_type_branch` using `references/n320-severity-classification-rubric.md`.

## Primary inputs

Prefer these inputs when available:
- `故障时间线.md` (from #123)
- `根因定位建议.md`, `影响范围分析.md`, `修复方案建议.md`
- N310 `值班处置建议.md`, `修复方案建议.md`, `热修风险评估.md`
- remediation notes, rollback notes, incident communications, decision logs

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | Metadata | Always | artifact_id, selected_mode, incident_type_branch, severity |
| 2 | Executive summary | Always | ≤5 sentences; time-to-detect, time-to-resolve, customer impact |
| 3 | Business and technical impact | Always | Scope, SLA breach, affected users/services |
| 4 | Factual chronology reference | Always | Reference TL-INC-* if available; or inline with "incomplete" flag |
| 5 | Why-chain (Five Whys) | Always | ≥L3 depth; document evidence gap if stopping at L2 |
| 6 | Contributing factor categories | Always | Use references/cause-category-rubric.md |
| 7 | Root cause statement with confidence | Always | confidence: high / medium / low + rationale |
| 8 | Containment and remediation already taken | Always | What was done, not what should be done |
| 9 | Action items | Always | Each item: what + who_role + when + verify (four-element test) |
| 10 | Follow-up risks and learning | Always | Forward-looking; flag scope_trim_candidates for N360 |
| 11 | Recurrence Analysis | Always in recurrence_pattern_postmortem | Prior incident IDs + prior action item completion status |
| 12 | Evidence gaps or unanswered questions | Always | "无待确认项" if none; never omit |

> Legend: Always = required in every mode.

## Action item quality gate

Every action item must pass the **four-element test**:

| Element | Requirement | Anti-pattern |
|---------|-------------|--------------|
| `what` | Specific, verifiable deliverable | "改善监控" (too vague) |
| `who_role` | Role or team, not individual name | "张三" (personal blame) |
| `when` | Absolute date or sprint reference | "尽快" / "ASAP" |
| `verify` | How completion is confirmed | empty or "完成后通知" |

## Why-chain depth rules

- L3 minimum: do not stop at "operator error" or "config mistake" — ask why the system allowed it.
- L4–L5 when systemic issues are present (missing alerting, absent playbook, inadequate review gates).
- If evidence prevents going deeper than L2, write: `"why-chain stopped at L2: [specific gap name] — evidence required from [source]"`.

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: N340/meeting-minutes-to-action-items
  action_items:
    - action_item_id: AI-INC-*-001
      what: "..."
      who_role: "..."
      deadline: "YYYY-MM-DD"
      verify: "..."
  incident_type_branch: cache_stampede
  recurrence_signal: true | false
  readiness: complete | partial | degraded
```

`readiness` values: `complete` / `partial` / `degraded` (sparse evidence; reviewers must validate assumptions).

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** Why-chain stops at L2 without documenting the evidence gap → must name the missing evidence and mark as open_blocker. 量化检验：L-depth 数字（L1/L2/L3…）在 why-chain 节的最大值必须 ≥ 3；若无 L-depth 标注，视为 L1 停止（违例）。
- **AP-2** Action item 缺少 four-element 中的任意一个 → 拒绝输出；在 open_blockers 中标注"待补充 [缺失元素]"。量化检验：action item 条目中，what/who_role/when/verify 四个字段缺失任意一个的条目数必须 = 0（严格模式）。
- **AP-3** 在 action item 中使用个人名字（人身归责）→ 必须改为角色或团队名称；参考 `references/tl-blame-less-rules.md`。量化检验：正则 `[张李王赵陈刘][a-zA-Z一-鿿]{1,2}\b` 匹配到非引用上下文时计入违例。
- **AP-4** `recurrence_pattern_postmortem` 模式下未审计历史 action item 完成状态 → Recurrence Analysis 节必须包含先前 action item 的 completed/overdue/cancelled 状态。量化检验：recurrence_pattern_postmortem 模式下，Recurrence Analysis 节必须包含 `completed`/`overdue`/`cancelled` 三种状态关键词各至少一处（或写明无历史 action）。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n320-shared-postmortem-contract.md` — shared metadata, evidence, branch, handoff, composition rules
- `references/n320-incident-type-branches.md` — when classifying incident_type_branch
- `references/n320-severity-classification-rubric.md` — when determining severity and why-depth target
- `references/tl-blame-less-rules.md` — when drafting or checking tone
- `references/why-depth-rubric.md` — when assessing L-depth adequacy
- `references/cause-category-rubric.md` — when categorizing contributing factors
- `references/action-item-contract.md` — when validating action item four-element compliance
- `references/recurrence-analysis-guide.md` — when using recurrence_pattern_postmortem mode
- `references/postmortem-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing (v1.3.2)
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Workflow position

```
Raw evidence (logs, chat, alerts, N310 handoff notes)
  ↓ #123 (factual chronology → 故障时间线.md)
  ↓ #124 (causal analysis + action items → 线上问题复盘.md)
  ↓ N340 #131 (action items → 行动项清单.csv)
  ↓ N350 #135/#136 (task tracking → 任务清单.csv)
```

## Examples

- `examples/availability-full-postmortem.md` — timeline_backed_postmortem with L4 why-chain
- `examples/recurrence-postmortem-cache-stampede.md` — recurrence_pattern_postmortem with prior action item audit
- `examples/batch-recurrence-review.md` — batch review of multiple recurrence signals
