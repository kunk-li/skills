# Example: Cache Stampede Recurrence Postmortem

Demonstrates `recurrence_pattern_postmortem` mode. Links to prior incident INC-2024-031.

```yaml
metadata:
  contract_version: n320-postmortem-v1.3.2
  skill_id: "124"
  selected_mode: recurrence_pattern_postmortem
  incident_id: INC-2025-0612-CACHE-001
  incident_type_branch: cache_stampede
  severity_classification:
    level: P1
    why_depth_target: L3
    recurrence_severity: systemic
  readiness: complete
```

## Executive Summary

Order-service experienced a cold-cache event on 2025-06-12 14:27 JST after a deploy cleared the Redis cache without a warm-up gate. Recovery took 34 minutes. This is the **second occurrence** of `cache_stampede` in 9 months; the prior action item (AI-031-001, add jitter to TTL) was completed, but the deploy-triggered cache-clear pathway was not addressed.

## Business and Technical Impact

- Duration: 14:27–15:01 (34 min)
- Affected users: ~12,000 checkout attempts returned 503
- Revenue impact: estimated ¥4.2M lost orders during window
- SLA breach: 99.5% monthly SLA now at risk

## Factual Chronology Reference

See `故障时间线.md` artifact TL-INC-2025-0612-001. Key anchors:
- TL-001: Alert fired 14:27
- TL-003: Cold cache confirmed 14:35 (post-deploy)
- TL-004: Warm-up executed 14:52
- TL-005: Recovery 15:01

Open gap from timeline: engineer receipt time unresolved (CG-001).

## Five-Whys Analysis

**L1 Symptom**: Order service returned 503 for 34 minutes  
**L2 Near Cause**: Redis cache cold after deploy flushed all keys  
**L3 Systemic Cause**: Deploy pipeline had no gate requiring cache warm-up before traffic routing; deploy-triggered flush was not in the runbook or pre-deploy checklist  

Why-depth target L3 reached. L4 not supported by current evidence.

## Contributing Factors

| category | description |
|----------|-------------|
| process/review_flow | Deploy checklist did not include cache state validation |
| technology/system | No automatic warm-up step in CD pipeline |
| monitoring/observability | Hit-rate alert fired correctly but warm-up runbook not linked from alert |

## Root Cause Statement

**Root cause (confidence: high)**: The CD pipeline does not validate or restore cache state before shifting traffic. When a deploy clears Redis keys, the service immediately receives full production traffic against an empty cache, causing thundering-herd load on the database.

## Action Items

| action_item_id | what | who_role | deadline | success_criteria | verification_method | prevention_type |
|----------------|------|----------|----------|-----------------|--------------------|----|
| AI-001-001 | Add cache-warm-up step to CD pipeline: run warm-up script before traffic routing gate passes | platform-team | 2025-07-01 | Zero 503 errors during next 3 deploys that include cache changes; warm-up step visible in deploy log | Deploy log review by SRE + 30-day monitoring | near_cause |
| AI-001-002 | Add "cache state: warm" as required pre-deploy gate in release checklist | release-manager | 2025-06-25 | Checklist updated; 100% of next 5 deploys include cache check confirmation | Checklist audit by QA | process/review_flow |
| AI-001-003 | Link warm-up runbook directly from Redis hit-rate PagerDuty alert body | sre-team | 2025-06-20 | Alert body contains direct runbook link; on-call confirms link visible in next drill | PD alert template review | monitoring |

## Recurrence Analysis

### Prior incidents in same branch

| incident_id | date | severity | root_cause_summary |
|-------------|------|----------|--------------------|
| INC-2024-031 | 2024-09-12 | P1 | Missing thundering-herd protection: no TTL jitter on hot keys |

### Prior action items — completion status

| action_item_id | what | owner_role | deadline | status | evidence |
|----------------|------|------------|----------|--------|----------|
| AI-031-001 | Add jitter to cache TTL (±30% randomization) | platform-team | 2024-10-01 | COMPLETED | PR #1842 merged 2024-10-28, confirmed in config |
| AI-031-002 | Add circuit breaker on order-service DB calls | backend-team | 2024-11-01 | COMPLETED | PR #1901 merged 2024-11-15 |
| AI-031-003 | Add warm-up runbook to on-call documentation | sre-team | 2024-10-15 | PARTIALLY_COMPLETED | Runbook exists but not linked from alert |

### Recurrence pattern conclusion

- **Pattern**: Cache cold starts from external events (traffic spike in INC-2024-031; deploy in INC-2025-0612) continue to cause P1 outages despite TTL-level fixes.
- **Why prior actions were insufficient**: AI-031-001 and AI-031-002 addressed the thundering-herd propagation path, but not the upstream cause (cache being cleared). AI-031-003 was partially done — runbook existed but unreachable from the alert context when needed.
- **New actions must address**: The deploy pipeline itself (L3 systemic gap not addressed in 2024) and the runbook discoverability gap (AI-031-003 partial completion now causes real impact).
- **Structural difference**: AI-001-001 targets CD pipeline integration (new causal layer); AI-001-003 closes the discoverability gap left by partial AI-031-003.

## Evidence Gaps

1. CG-001 (from timeline): Exact MTTA undetermined — does not affect root cause but affects SLA reporting
2. Exact volume of cache keys cleared by deploy — not yet measured

## Downstream Handoff

```yaml
handoff_id: PM-INC-2025-0612-001
producer_skill: production-incident-postmortem
consumer_skill_or_node: N340
action_items: [AI-001-001, AI-001-002, AI-001-003]
incident_type_branch: cache_stampede
recurrence_severity: systemic
readiness: complete
confidence: high
next_best_checks:
  - Track AI-001-001 completion in weekly report
  - Add cache_stampede to best-practice anti-pattern catalog (skill #134)
```

## Downstream Handoff

```yaml
handoff_id: PM-INC-2025-0612-CACHE-001
producer_skill: production-incident-postmortem
consumer_skill_or_node: N340
cross_artifact_refs:
  - artifact_id: TL-INC-2025-0612-001
    producer_skill: incident-timeline-compilation
    consumed_fields: [timeline_anchor_ref, evidence_refs, open_gaps]
action_items: [AI-001-001, AI-001-002, AI-001-003]
incident_type_branch: cache_stampede
recurrence_severity: systemic
readiness: complete
confidence: high
next_best_checks:
  - "N340 #131: create action items from AI-001-001/002/003 for sprint tracking"
  - "N340 #134: evaluate cache warm-up pattern for maturity=validated upgrade"
  - "N320: monitor for third occurrence — triggers systemic review if pattern repeats"
```
