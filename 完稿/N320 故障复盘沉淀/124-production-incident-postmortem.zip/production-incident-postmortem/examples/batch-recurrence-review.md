# Example: Batch Recurrence Review

```yaml
metadata:
  contract_version: n320-postmortem-v1.3.1
  workflow_node: N320
  skill_id: "124"
  skill_name: production-incident-postmortem
  selected_mode: action_commitment_review
  readiness: partial
  incident_id: INC-BATCH-2026-Q2-CHECKOUT-RETRY
  incident_id_aliases: [INC-2026-0403-RETRY-001, INC-2026-0507-AVAIL-001]
  source_time_window:
    start: 2026-04-03T00:00:00+09:00
    end: 2026-05-07T23:59:59+09:00
    timezone: Asia/Tokyo
  service_scope: [checkout-api]
  incident_type_branch: availability
  secondary_branches: [performance]
  evidence_profile: historical_enriched
  confidence: medium
  composition_role: causal_learning_and_action_commitment
  function_bias: systemic_learning_action_commitments
  stage_position: operations_governance.postmortem_consolidation.postmortem
  node_artifact_target: 线上问题复盘.md
  open_blockers: [full trace sample for April incident]
  owner_placeholders: [checkout_service_owner, sre]
  severity_classification:
    compliance_impact: none
    user_impact: widespread
    reversibility: hard
    recurrence: similar_incident_within_90d
    total_score: 7
    severity_class: Critical
    target_min_why_depth: L4
    achieved_why_depth: L3
    why_depth_gap_explained: organizational control review still open
  tool_collaboration_mode: batch_recurrence_review
```

## Recurrence summary
Two availability incidents involved checkout retry or fallback behavior within 90 days. Recurrence override upgrades the learning depth target to L4.

## Follow-up risks and learning
- Treat retry/fallback controls as a governance mechanism, not only a service-level implementation detail.
- Require cross-incident owner role to validate control coverage across all checkout dependencies.
