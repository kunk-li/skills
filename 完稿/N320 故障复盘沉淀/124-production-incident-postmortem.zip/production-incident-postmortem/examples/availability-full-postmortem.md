# Example: Availability Full Postmortem

```yaml
metadata:
  contract_version: n320-postmortem-v1.3.2
  workflow_node: N320
  skill_id: "124"
  skill_name: production-incident-postmortem
  selected_mode: timeline_backed_postmortem
  readiness: ready
  incident_id: INC-2026-0507-AVAIL-001
  incident_id_aliases: []
  source_time_window:
    start: 2026-05-07T09:10:00+09:00
    end: 2026-05-07T10:05:00+09:00
    timezone: Asia/Tokyo
  service_scope: [checkout-api, payment-callback]
  incident_type_branch: availability
  secondary_branches: [performance]
  evidence_profile: multi_source
  confidence: medium
  composition_role: causal_learning_and_action_commitment
  function_bias: systemic_learning_action_commitments
  stage_position: operations_governance.postmortem_consolidation.postmortem
  node_artifact_target: 线上问题复盘.md
  open_blockers: [customer impact segment count]
  owner_placeholders: [checkout_service_owner, release_engineering]
  severity_classification:
    compliance_impact: none
    user_impact: widespread
    reversibility: hard
    recurrence: first_occurrence
    total_score: 5
    severity_class: Major
    target_min_why_depth: L3
    achieved_why_depth: L3
    why_depth_gap_explained: null
  tool_collaboration_mode: single_incident_postmortem
```

## Executive summary
Checkout availability dropped after a release and recovered after rollback. The branch-to-cause first cut begins with `technology_system_behavior`, with `change_and_release` as second suspect.

## Factual chronology reference
Use timeline anchors TA-001 through TA-004 from `故障时间线.md`; do not rebuild chronology.

## Five-whys analysis
| why_level | question | answer | evidence_refs | confidence | layer | gap_if_any |
|---|---|---|---|---|---|---|
| L1 | Why did users fail checkout? | checkout-api returned elevated errors after release | [EV-001, TA-001] | high | confirmed_fact | null |
| L2 | Why did the release trigger errors? | fallback behavior did not isolate payment-callback failure | [EV-002, TA-002] | medium | bounded_inference | fallback test result missing |
| L3 | Why was fallback not caught before release? | release gate lacked failure-mode rehearsal evidence | [EV-003] | medium | bounded_inference | need release checklist sample |

## Action items
```yaml
action_items:
  - action_item_id: AI-001
    what: add rollback rehearsal evidence to checkout release checklist
    who_role: release_engineering
    deadline: next release train
    success_criteria: three consecutive checkout releases include rehearsal evidence links
    dependency: pipeline checklist update
    verification_method: inspect release checklist artifacts
    prevention_type: prevention
    decision_weight_profile:
      regulatory: 0.0
      user_impact: 0.8
      recurrence: 0.4
      control_coverage: 0.9
      total_weight: 0.7
      rationale: prevents recurrence in a user-visible checkout flow
```

## Downstream Handoff

```yaml
handoff_id: PM-INC-2025-AVAIL-001
producer_skill: production-incident-postmortem
consumer_skill_or_node: meeting-minutes-to-action-items|N340
cross_artifact_refs:
  - artifact_id: TL-INC-2025-AVAIL-001
    producer_skill: incident-timeline-compilation
    consumed_fields: [timeline_anchor_ref, evidence_refs]
action_items: [AI-AVAIL-001, AI-AVAIL-002, AI-AVAIL-003]
incident_type_branch: availability
readiness: complete
confidence: high
next_best_checks:
  - "N340 #131: create sprint tasks from AI-AVAIL-001/002/003"
  - "N340 #134: evaluate cache pre-warm pattern for best-practice promotion"
```
