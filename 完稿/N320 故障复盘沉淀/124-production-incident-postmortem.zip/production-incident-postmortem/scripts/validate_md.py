#!/usr/bin/env python3
"""validate_md.py for skill #124 production-incident-postmortem (n320-postmortem-v1.3.2)

Validates that a generated 线上问题复盘.md satisfies the mandatory section
contract defined in SKILL.md and n320-shared-postmortem-contract.md.

Usage:
    python scripts/validate_md.py <postmortem.md> [--strict]
"""
import re
import sys
from pathlib import Path

SCHEMA = "n320-postmortem-v1.3.2 / #124 production-incident-postmortem"

REQUIRED_HEADINGS = [
    ("metadata",            re.compile(r"##\s*\d*\.?\s*Metadata|^```yaml[\s\S]*?\bmetadata:\b", re.I | re.MULTILINE)),
    ("executive_summary",   re.compile(r"##\s*\d*\.?\s*[^\n]*?(Executive summary|执行摘要|概述)", re.I)),
    ("impact",              re.compile(r"##\s*\d*\.?\s*[^\n]*?(Business.*impact|影响|影响范围)", re.I)),
    ("chronology",          re.compile(r"##\s*\d*\.?\s*[^\n]*?(Factual chronology|事件经过|时间线)", re.I)),
    ("why_chain",           re.compile(r"##\s*\d*\.?\s*[^\n]*?(Why.chain|Five Whys|根因|为什么)", re.I)),
    ("contributing_factors",re.compile(r"##\s*\d*\.?\s*[^\n]*?(Contributing factor|根因分类|影响因素)", re.I)),
    ("root_cause",          re.compile(r"##\s*\d*\.?\s*[^\n]*?(Root cause|根本原因)", re.I)),
    ("remediation",         re.compile(r"##\s*\d*\.?\s*[^\n]*?(Containment|Remediation|修复|已采取)", re.I)),
    ("action_items",        re.compile(r"##\s*\d*\.?\s*[^\n]*?(Action [Ii]tems?|行动项)", re.I)),
    ("followup",            re.compile(r"##\s*\d*\.?\s*[^\n]*?(Follow.up|后续|学习|learning)", re.I)),
    ("evidence_gaps",       re.compile(r"##\s*\d*\.?\s*[^\n]*?(Evidence gaps|待确认|未解决)", re.I)),
]
REQUIRED_METADATA_FIELDS = ["artifact_id", "selected_mode", "incident_type_branch", "severity"]
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}
VALID_MODES = {
    "timeline_backed_postmortem", "rca_notes_to_postmortem",
    "evidence_limited_postmortem", "action_commitment_review", "recurrence_pattern_postmortem"
}
ACTION_ITEM_ELEMENTS = ["what", "who_role", "when", "verify"]

def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0

def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_md.py <postmortem.md> [--strict]")
        return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists():
        return fail(f"file not found: {path}")

    text = path.read_text(encoding="utf-8")
    errors = 0; warnings = 0

    # === Example/light-check mode ===
    # When validating example files, only check: readiness value + downstream_handoff presence
    # Full section checks require production output format with ## Metadata heading
    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    if _is_example and _has_any_heading:
        # Check readiness value if present
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness value '{_rm.group(1)}' not in {VALID_READINESS}")
            return 1
        # Check downstream_handoff exists
        if "downstream_handoff" not in text.lower() and "downstream" not in text.lower():
            print(f"[WARN] example may be missing downstream_handoff section")
        return ok(f"{SCHEMA} example validation passed (light-check mode)")



    # 1. Required headings
    found = {}
    for key, pat in REQUIRED_HEADINGS:
        m = pat.search(text)
        if m:
            found[key] = m.start()
        else:
            print(f"[FAIL] missing required section: {key}")
            errors += 1

    # 2. Why-chain depth ≥ L3
    if "why_chain" in found:
        snippet = text[found["why_chain"]:found["why_chain"]+1500]
        depth_matches = re.findall(r"\bL([0-9]+)\b", snippet)
        max_depth = max((int(d) for d in depth_matches), default=0)
        if max_depth < 3:
            msg = f"why-chain max depth appears to be L{max_depth} (minimum L3 required)"
            if strict:
                print(f"[FAIL] {msg}"); errors += 1
            else:
                warn(msg); warnings += 1

    # 3. Action items four-element check
    if "action_items" in found:
        ai_pos = found["action_items"]
        next_section = min(
            (v for k, v in found.items() if v > ai_pos),
            default=len(text)
        )
        ai_snippet = text[ai_pos:next_section]
        missing_elements = [e for e in ACTION_ITEM_ELEMENTS if e not in ai_snippet]
        if missing_elements:
            print(f"[FAIL] action_items section missing four-element fields: {missing_elements}")
            errors += 1

    # 4. Metadata fields
    if "metadata" in found:
        snippet = text[found["metadata"]:found["metadata"]+1000]
        for field in REQUIRED_METADATA_FIELDS:
            if field not in snippet:
                print(f"[FAIL] metadata missing: {field}")
                errors += 1
        mm = re.search(r"selected_mode[:\s]+[`\"']?(\w+)", snippet)
        if mm and mm.group(1) not in VALID_MODES:
            warn(f"selected_mode '{mm.group(1)}' not in known modes")
            warnings += 1

    # 5. downstream_handoff + readiness
    if "downstream_handoff:" not in text and "downstream_handoff" not in text:
        print("[FAIL] missing downstream_handoff block")
        errors += 1
    else:
        rm = re.search(r"readiness:\s*([\w]+)", text)
        if rm and rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness value '{rm.group(1)}' not in {VALID_READINESS}")
            errors += 1

    # 6. confidence field in root_cause
    if "root_cause" in found:
        snippet = text[found["root_cause"]:found["root_cause"]+600]
        if "confidence:" not in snippet and "confidence" not in snippet.lower():
            warn("root_cause section missing confidence field (high/medium/low)")
            warnings += 1

    # 7. Blame-less check
    if re.search(r"\b(张[三四五]|李[四五六]|王[五六七])\b", text):
        print("[FAIL] possible personal name found — use role/team names only")
        errors += 1

    # 8. evidence_gaps never empty
    if "evidence_gaps" in found:
        eg_pos = found["evidence_gaps"]
        next_pos = min((v for k,v in found.items() if v > eg_pos), default=len(text))
        eg_content = text[eg_pos:next_pos].strip()
        if len(eg_content) < 30:
            warn("evidence_gaps section appears very short — ensure it is not silently omitted")
            warnings += 1

    if errors > 0:
        return fail(f"{SCHEMA} validation FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} validation passed — {warnings} warning(s)")

if __name__ == "__main__":
    raise SystemExit(main())
