# Action Item Contract

Every action item must be concrete enough to track.

## Required fields
- `action_item_id`: stable id such as `AI-001`
- `what`: the exact change or deliverable
- `who_role`: team or role, never a person name
- `deadline`: target date or time window
- `success_criteria`: measurable evidence that the action worked
- `dependency`: prerequisite task, approval, rollout, or resource
- `verification_method`: how completion will be checked
- `prevention_type`: detection | prevention | mitigation | recovery | governance
- `decision_weight_profile`: optional weighted rationale when ranking actions

## Decision weight profile
Use when prioritizing multiple action items:
```yaml
decision_weight_profile:
  regulatory: 0.0-1.0
  user_impact: 0.0-1.0
  recurrence: 0.0-1.0
  control_coverage: 0.0-1.0
  total_weight: 0.0-1.0
  rationale: string
```

Use 0.0 for no decision weight and 1.0 for maximum decision weight. Aligns with N310 remediation-plan-recommendation decision weight ranges so response and postmortem commitments can be compared across nodes.

## Good examples
- `what`: add a release gate that blocks if rollback rehearsal evidence is missing
  `who_role`: release_engineering
  `deadline`: 2026-06-15
  `success_criteria`: all production releases include rehearsal evidence links in the checklist
  `dependency`: pipeline rule update approved by sre
  `verification_method`: inspect release checklist artifacts for three consecutive releases
  `prevention_type`: prevention

- `what`: standardize incident alert routing for database saturation alerts
  `who_role`: sre
  `deadline`: next sprint
  `success_criteria`: database saturation alerts route only to dba+sre and duplicate cascades drop by 80 percent
  `dependency`: alert routing table review
  `verification_method`: compare alert fanout before and after routing change
  `prevention_type`: mitigation

## Reject vague action items
Rewrite or reject items such as:
- strengthen awareness
- improve communication
- be more careful
- pay more attention
