# N320 Incident Type Branches

Use exactly one primary `incident_type_branch` per N320 artifact. If the incident spans multiple domains, name one primary branch and list the others in `metadata.secondary_branches`. Mirror the upstream N310 `event_type_branch` when a handoff exists; do not silently relabel.

## availability
Service or critical capability unavailable, unstable, repeatedly failing, or producing user-visible outage.
- timeline emphasis: detection -> mitigation -> recovery anchors
- postmortem emphasis: missing fallback, propagation, recovery rehearsal

## performance
Latency regression, throughput collapse, queue buildup, resource saturation, or degradation without correctness breach.
- timeline emphasis: diagnosis -> mitigation, capacity baselines
- postmortem emphasis: capacity guardrails, throttling, baseline drift

## data_consistency
Duplicate writes, stale reads, lost updates, replay, irreversible business-state corruption.
- timeline emphasis: detection point of corruption, mitigation reversibility
- postmortem emphasis: write protection, reconciliation gaps, schema/contract drift

## compliance
Audit, authorization, privacy, regulatory, or policy violation.
- timeline emphasis: must mark `compliance-sensitive-window`
- postmortem emphasis: notification timeliness, evidence preservation, signoff
- minimum why-depth: L3 (systemic_cause) regardless of size

## security
Credential exposure, intrusion, data exfiltration, or trust-chain compromise.
- timeline emphasis: detection latency, containment perimeter
- postmortem emphasis: detection coverage, blast-radius limit, key/secret rotation

## capacity
Resource exhaustion not classified as performance regression (license seats, quota, fleet headroom, queue capacity).
- timeline emphasis: saturation point and prior warnings
- postmortem emphasis: forecast accuracy, autoscaling rule, lead-time gap

## user_experience
User-facing degradation that does not cleanly fit availability or performance (UX regression, broken flow, accessibility break).
- timeline emphasis: user reports vs telemetry alignment
- postmortem emphasis: synthetic check coverage, regression gates

## Mapping back to N310 event_type_branch
| N310 event_type_branch | N320 incident_type_branch |
|---|---|
| availability | availability |
| performance | performance |
| data_consistency | data_consistency |
| compliance | compliance |
| (N310 not used) | security / capacity / user_experience |

When N310 hands off, copy its `event_type_branch` value to N320 `incident_type_branch` directly.
