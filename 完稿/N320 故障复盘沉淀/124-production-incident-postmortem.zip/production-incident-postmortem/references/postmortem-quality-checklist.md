# Postmortem Quality Checklist v1.3.2

Before finalizing `线上问题复盘.md`, verify all items:

## Structure checks
1. Metadata includes `incident_type_branch`, `severity_classification`, `selected_mode`, `readiness`, `evidence_profile`, and `open_blockers`.
2. Executive summary is 3–5 sentences and readable without technical context.
3. Impact is stated in user, service, data, compliance, and operational terms where evidence exists.
4. Chronology references timeline anchors rather than rebuilding the full timeline.

## RCA depth checks
5. Five-whys chain reaches the severity-appropriate depth from `references/n320-severity-classification-rubric.md`.
6. If why-depth falls short, `severity_classification.why_depth_gap_explained` is populated.
7. Root cause statement is supported by evidence, not intuition. Hypotheses are labeled as such with confidence.
8. Contributing factors are organized across the five cause categories (role clarity, process/review flow, technology behavior, monitoring/observability, governance/mechanism).

## Action item quality checks (new in v1.3.2)
9. Every action item passes the specificity test: **what + who_role + deadline + success_criteria + verification_method**.
10. `success_criteria` is a measurable outcome, not a process step. Words like "complete", "improve", "review" are only acceptable when followed by a concrete measurable target.
11. Vague verbs ("improve monitoring", "enhance process") are rejected unless converted to specific, measurable work.
12. Action items include `prevention_type` to classify whether each prevents detection failure, near cause, systemic cause, or organizational cause.

## Recurrence checks (new in v1.3.2)
13. If `incident_type_branch` matches a prior incident, `## Recurrence Analysis` section is present.
14. Recurrence analysis includes prior incident IDs, prior action item completion status, and pattern conclusion.
15. New action items are structurally different from prior ones, or the postmortem explicitly explains why the same action is proposed again.
16. Consult `references/recurrence-analysis-guide.md` for recurrence analysis structure.

## Tone and handoff checks
17. No personal blame framing anywhere in the document.
18. `downstream_handoff` includes action commitments and causal conclusions for governance and knowledge nodes.
19. Compare output structure against closest `examples/` file; differences are intentional.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- `recurrence_pattern_postmortem` mode: `## Recurrence Analysis` section always present; prior incidents table always has ≥1 row.
- Prior action items completion status: all prior action items listed with COMPLETED/PARTIALLY_COMPLETED/NOT_COMPLETED/UNKNOWN.
- `recurrence_severity: systemic` set when same branch appears ≥3 times.

## Output structure completeness checks
- Why-chain reaches ≥L3; if stopped earlier, evidence gap must be documented
- action_items list non-empty; specificity test (what+who+when+verify) passed for each
- downstream_handoff has action_items list and incident_type_branch

## Mode-specific checks

### recurrence_pattern_postmortem mode
- `## Recurrence Analysis` section present
- Prior incidents table with ≥1 row and action_item completion status column
- `recurrence_severity: systemic | isolated` declared
