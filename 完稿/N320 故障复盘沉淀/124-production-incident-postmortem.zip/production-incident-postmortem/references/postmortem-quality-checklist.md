# Postmortem Quality Checklist

Before finalizing `线上问题复盘.md`, verify:

1. Metadata includes every required field from the shared metadata schema.
2. Severity classification is present and drives target why-depth.
3. Any N310 `event_type_branch` is preserved as `incident_type_branch`.
4. Timeline facts are cited through `timeline_anchor_ref` when available.
5. Five-whys analysis reaches target depth or explains the gap.
6. Root-cause statements cite evidence and confidence.
7. Action items use the action item contract and avoid vague awareness-only work.
8. `owner_placeholders` contains only roles or teams.
9. `open_blockers` names unresolved facts, approvals, or evidence gaps.
10. `downstream_handoff` includes `handoff_id`, consumer, artifact target, confidence, and next checks.
11. Compare the produced postmortem's metadata key order, field naming,
    and section structure against the most relevant file under
    `examples/`. Differences are allowed but should be intentional.
