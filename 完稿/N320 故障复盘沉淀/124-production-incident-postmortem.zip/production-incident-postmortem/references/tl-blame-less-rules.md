# Blame-less Rules for Incident Documentation

Use this rule set whenever drafting N320 timelines or postmortems.

## Core principle
Describe systems, signals, decisions, handoffs, constraints, controls, and missing safeguards. Do not attribute fault to an individual person.

## Preferred subject forms
- team names: `sre`, `api_team`, `compliance`, `database_team`
- role names: `on_call_engineer`, `incident_commander`, `release_manager`, `tech_lead`
- system names: `api_gateway`, `order_service`, `mysql_primary`, `prometheus`
- process or mechanism names: `escalation_policy`, `rollout_checklist`, `timeout_policy`, `canary_gate`

## Avoid
- personal names, emails, or chat handles as owners
- moral judgment language such as careless, negligent, forgot, should have known
- phrases that make one person the root cause

## Rewrite patterns
- "alice misconfigured the alert" -> "the alert configuration changed without the expected review gate"
- "bob forgot to rotate the key" -> "the key-rotation process did not trigger before expiry"
- "charlie deployed the bad build" -> "the release pipeline promoted a build without blocking on the missing check"

## Owner field policy
Owner fields must use a role or team, never a person.
Examples:
- `owner_role: sre`
- `owner_role: compliance_officer`
- `owner_role: order_service_team`

## Owner placeholders array
Every output should use `metadata.owner_placeholders` to list roles or teams that require follow-up. Do not list personal names, emails, or handles.

## Blame-less checker
Before finalizing, scan the draft and `owner_placeholders` for:
- `@` mentions
- personal email patterns
- direct blame verbs near a personal name
- statements that imply intent or negligence without evidence

Rewrite around role, team, system, process, or mechanism.
