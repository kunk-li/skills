# Cause Category Rubric

Use these categories when organizing contributing factors in `线上问题复盘.md`.

## role_clarity
Signals that ownership, escalation, approval, or handoff boundaries were unclear.
Examples: alert routed to no owning team; release approval had no backup role; incident commander role unclear.

## process_review_flow
Signals that a checklist, review, rollback, or approval process did not prevent or detect the issue.
Examples: rollback rehearsal omitted; change review skipped a risk class; release checklist lacked evidence links.

## technology_system_behavior
Signals that architecture, dependency behavior, state handling, resource policy, or failure mode created the incident.
Examples: retry storm amplified latency; stale cache exposed incorrect state; timeout exceeded upstream SLO.

## monitoring_observability
Signals that detection, alert routing, dashboards, logging, traces, or synthetic checks failed to reveal the issue early enough.
Examples: metric existed but no alert; trace_id missing; alert storm hid primary signal.

## governance_mechanism
Signals that policies, compliance gates, standards, recurring review, or organizational controls were missing or weak.
Examples: recurring incident without owner; compliance-sensitive window not marked; no governance review for repeated root cause.

## Branch-to-cause first-cut mapping

When starting five-whys, use the upstream `incident_type_branch` as a
first-cut suspect, but **do not stop investigating other categories**.
Evidence drives the final classification; the table below only sets the
search starting point.

| incident_type_branch | first-cut suspect | second suspect |
|---|---|---|
| availability | technology_system_behavior | change_and_release |
| performance | technology_system_behavior | external_environment |
| data_consistency | change_and_release | governance_mechanism |
| compliance | governance_mechanism | human_collaboration |
| security | governance_mechanism | technology_system_behavior |
| capacity | technology_system_behavior | governance_mechanism |
| user_experience | change_and_release | human_collaboration |

If the final identified cause category disagrees with the first-cut
suspect, record it explicitly in `metadata.cause_category_disagreement`
and explain the disagreement in the postmortem narrative.

