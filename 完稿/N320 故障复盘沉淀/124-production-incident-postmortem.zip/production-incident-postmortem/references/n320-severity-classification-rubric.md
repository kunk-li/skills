# N320 Severity Classification Rubric

Use this rubric to set the target why-depth for any postmortem. It mirrors the N310 tier rubric so N310 -> N320 handoffs preserve severity intent.

## Three primary factors

### compliance_impact
- `none` = 0
- `review` = 2
- `breach` = 4

### user_impact
- `isolated` = 1
- `partial` = 2
- `widespread` = 3
- `systemic` = 4

### reversibility
- `easy` = 0
- `controlled` = 1
- `hard` = 2
- `irreversible` = 3

## N320-specific factor

### recurrence (90-day window)
- `first_occurrence` = 0
- `similar_incident_within_90d` = +2 (escalates one severity class)
- `same_root_cause_within_90d` = +3 (forces Critical class)

## Severity class
| total_score | severity_class | recommended_min_why_depth |
|---|---|---|
| any compliance breach OR reversibility=irreversible | Critical | L4 |
| total >= 8 | Critical | L4 |
| total 5-7 | Major | L3 |
| total 3-4 | Minor | L2 (may stop here if evidence limited) |
| total <= 2 | Minor | L2 |

## Recurrence override
If `recurrence != first_occurrence`, upgrade `severity_class` by one level (Minor -> Major, Major -> Critical). Recurring incidents must reach at least L4 (organizational_cause) to qualify as a complete postmortem.

## How to declare in metadata
```yaml
metadata:
  severity_classification:
    compliance_impact: none|review|breach
    user_impact: isolated|partial|widespread|systemic
    reversibility: easy|controlled|hard|irreversible
    recurrence: first_occurrence|similar_incident_within_90d|same_root_cause_within_90d
    total_score: <integer>
    severity_class: Critical|Major|Minor
    target_min_why_depth: L2|L3|L4|L5
    achieved_why_depth: L1|L2|L3|L4|L5
    why_depth_gap_explained: string|null
```
