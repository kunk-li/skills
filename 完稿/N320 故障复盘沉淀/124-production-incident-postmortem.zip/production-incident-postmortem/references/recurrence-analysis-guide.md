# Recurrence Analysis Guide

Use this guide when `incident_type_branch` matches a prior incident, or when `recurrence_pattern_postmortem` mode is selected.

## When to trigger recurrence analysis
- `incident_type_branch` value appears in a prior postmortem (any version)
- The same service, component, or mechanism failed in the same way before
- A prior postmortem's action items are referenced in the current incident
- The word "again" or "third time" appears in incident descriptions

## Required `## Recurrence Analysis` section structure

```markdown
## Recurrence Analysis

### Prior incidents in same branch
| incident_id | date | incident_type_branch | severity | root_cause_summary |
|-------------|------|---------------------|----------|--------------------|
| INC-2024-031 | 2024-09-12 | cache_stampede | P1 | Missing thundering-herd protection on cold cache |

### Prior action items — completion status
| action_item_id | what | owner_role | deadline | status | evidence |
|----------------|------|------------|----------|--------|----------|
| AI-031-001 | Add jitter to cache TTL | platform-team | 2024-10-01 | NOT COMPLETED | No PR found in repo |
| AI-031-002 | Add circuit breaker | backend-team | 2024-11-01 | COMPLETED | PR #1842 merged 2024-10-28 |

### Recurrence pattern conclusion
- **Pattern**: [describe what keeps recurring]
- **Why prior actions were insufficient**: [explicit explanation]
- **New actions must address**: [what is structurally different this time]
```

## Completion status determination
- `COMPLETED`: evidence of deployment/merge/policy update exists
- `PARTIALLY_COMPLETED`: some sub-items done, others not
- `NOT_COMPLETED`: no evidence of completion found
- `UNKNOWN`: cannot verify without access to internal systems — mark as `open_blocker`

## What "structurally different" means
A new action item is only meaningfully different from a prior one if it:
1. Targets a different causal layer (e.g., prior action was L2, new action is L3)
2. Has a different owner role
3. Has a verifiable success criterion the prior action lacked
4. Addresses a dependency the prior action assumed but did not enforce

If new action items are essentially the same as prior ones, the recurrence analysis must say so explicitly and explain why the team is proposing them again.

## Recurrence escalation
If the same `incident_type_branch` appears 3 or more times:
- Flag `recurrence_severity: systemic` in metadata
- Escalate action items to L4 organizational or L5 strategic why-depth
- Recommend governance/postmortem review across incidents as a body
