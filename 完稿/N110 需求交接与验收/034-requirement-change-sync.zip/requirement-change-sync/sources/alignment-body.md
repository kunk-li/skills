## Sync-specific behavior
- keep notice-surface and execution-surface outputs separate
- represent feature-flag delivery as `T6a_config_deploy` and `T6b_flag_switch`
- keep T10 naming aligned to `T10_security_compliance_review`
