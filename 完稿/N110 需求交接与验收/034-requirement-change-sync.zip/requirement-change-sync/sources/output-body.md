## 3. Sync notice
- sync_notice:
- audience_impact:
- key_dates:
- contact_points:

## 4. Companion execution plan
- companion_artifacts: [需求变更同步计划.yaml]
- execution_stage_summary:
- verification_summary:
- rollback_summary:

## 5. Delivery notes
- environment_schedule:
- revision_log:
- next_skill_hints:
