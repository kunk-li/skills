---
name: requirement-change-sync
description: "generate n110-compatible requirement change sync artifacts that stay standalone and composable. use when chatgpt needs to turn a confirmed change or impact analysis into a stakeholder-facing change notice, refresh checklist, and regression reminder. emit a schema-versioned artifact contract, canonical output name, gate status, event fields, sla fields, sync targets, verification blocks, and environment-aware refresh guidance. keep the primary scope on stakeholder communication and advisory coordination, and do not replace release execution or environment mutation."
---
# requirement-change-sync

Create a workflow-v2-compatible N110 artifact that is independently usable and composable with sibling skills.

## Primary workflow identity
- Workflow stage: 协同交接
- Workflow node: N110
- Registry category: 协同交接
- Registry subcategory: 变更管理
- Registry function: 同步输出
- Canonical output name: `需求变更同步通知.md`
- Primary goal: 生成面向相关方的变更说明和回归提醒

Follow both `references/interoperability-contract.md` and `references/workflow-v2-alignment.md` on every run. Reuse `references/n110-artifact-registry.md` when sibling artifacts already exist.

## Boundary
- Stay inside the total-table boundary for this skill.
- Accept standalone use in any requirement-to-execution scenario, but still emit an N110-compatible artifact contract so the output can be composed later.
- Do not silently expand into neighboring skills just because adjacent information is present.

## Operating contexts
- `standalone`: the user needs this skill's artifact even if sibling artifacts do not exist yet.
- `composed`: one or more sibling artifacts already exist and should be linked, refreshed, or inherited instead of re-derived.

## Execution modes
Choose exactly one:
- `inventory_mode`: identify likely sync targets and stakeholders.
- `check_only_mode`: compare expected and current sync state without issuing final notice.
- `final_sync_mode`: issue the stakeholder-facing sync notice with refresh and regression reminders.
- `blocked_mode`: explain what source change information is missing.

## Required minimum input
A standalone run may start from any one of:
- a confirmed change description or impact analysis
- at least one audience or stakeholder group

A composed run should also absorb these when available:
- impact artifact
- handover artifact
- acceptance artifact
- engineering feedback artifact

## Required artifact contract fields
Every non-blocked output must declare:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `contract_version`
- `canonical_output_name`
- `workflow_stage`
- `workflow_node`
- `gate_status`
- `gate_checks[]`
- `produced_event`
- `state_event`
- `exception_event`
- `sla_event`
- `priority`
- `sla_level`
- `auto_escalate_after`
- `routing_aliases[]`
- `consumed_by_nodes[]`
- `downstream_artifacts[]`

## Gate rules
Always perform these checks before finalizing the artifact:
- contract fields present
- canonical output name preserved
- required inputs either present or explicitly blocked
- boundary respected
- downstream consumability described
- this skill specific checks: impact_source_present_or_explained, target_selection_complete, verification_method_present, primary_scope_respected, stakeholder_notice_ready

When evidence is incomplete, use `passed_with_gaps`, `blocked`, or `refresh_required` instead of implying full readiness.

## Workflow-v2 behavior
- Use schema version `1.0.0` and contract version `1.0.0` unless the output shape changes.
- Preserve `revision_log[]` so downstream consumers can see what changed between iterations.
- Emit workflow-v2-compatible event names.
- Carry an explicit SLA policy even in standalone runs.
- Prefer stable ids and trace anchors over free-text references.

## Extra behavior for this skill
- Keep `primary_scope: stakeholder_sync` in every non-blocked artifact.
- Advanced sync order, verification, rollback, and environment schedule remain advisory support sections; do not let the skill drift into release execution.

## Recommended workflow
1. Determine whether the request is standalone or composed.
2. Select the execution mode that fits the available evidence.
3. Load the workflow alignment and artifact registry references.
4. Produce the artifact using `references/output-template.md`.
5. Fill gate, event, SLA, and downstream-consumption sections before finalizing.
6. End with `next_skill_hints[]`, `refresh_triggers[]`, and `revision_log[]`.

## Required behavior
- Prefer compact structured sections over long prose.
- Distinguish `confirmed`, `inferred`, and `blocked` content.
- Do not fabricate missing upstream decisions.
- Do not upgrade inherited readiness.
- Reuse existing ids whenever sibling artifacts are available.
- If a change affects many technical surfaces but only a few stakeholder audiences, optimize the artifact for audience clarity, not implementation detail volume.
- Keep rollback and environment sections clearly labeled as advisory support for the sync artifact.

## Phase 2 optimization notes
- In `final_sync_mode`, emit both the stakeholder-facing notice and the companion `需求变更同步计划.yaml` when execution ordering matters.
- Keep `T6a_config_deploy` and `T6b_flag_switch` distinct in sync targets.

## Engineering source-of-truth
- Treat `MASTER.yaml` as the engineering source of truth for contract-bearing fields.
- Regenerate `references/output-template.md` and `references/workflow-v2-alignment.md` with `python3 scripts/generate_from_master.py --package-root .` after editing `MASTER.yaml` or `sources/*.md`.
- Keep sibling skill ids numeric in `sibling_skills_affected[]` and keep node consumers in `consumed_by_nodes[]`.
