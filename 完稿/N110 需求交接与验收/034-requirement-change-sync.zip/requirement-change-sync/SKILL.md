---
name: requirement-change-sync
description: Turn a confirmed change or impact analysis into a stakeholder change notice, refresh checklist, regression reminder, sync targets, and environment-aware refresh guidance.
---
# requirement-change-sync

Create a workflow-v2-compatible N110 artifact that is independently usable and composable with sibling skills.

## Role / 角色定位
- Workflow stage: 协同交接
- Workflow node: N110
- Registry category: 协同交接
- Registry subcategory: 变更管理
- Registry function: 同步输出
- Canonical output name: `需求变更同步通知.md`
- Primary goal: 生成面向相关方的变更说明和回归提醒

Follow both `references/interoperability-contract.md` and `references/workflow-v2-alignment.md` on every run. Reuse `references/n110-artifact-registry.md` when sibling artifacts already exist.

## N110 入场校验 / N110 Intake

034 的触发场景来自 N100 或 033（变更影响分析）。启动前确认：

```yaml
n110_intake:
  # 来自 031 或 030 的上游 gate 信息
  upstream_gate_status: go | conditional-go | no-go | unknown
  change_source:                    # confirmed_change_description | 033_impact_artifact
  impact_radius_known: true | false # 033 的 impact_radius 是否可用
  p0_targets_identified: true | false

  # 034 在 N110 流程中的触发条件（来自 handoff-to-n110.md §5）
  trigger_condition: >
    当 N100 发现 new_gap（new_gap: true）触发 PRD 修订后，
    033（change-impact）完成 → 触发 034（change-sync）。
    或：PM/工程侧主动发起变更通知流程。
```

若 `change_source` 缺失 → 强制进入 `blocked_mode`，说明缺少哪项输入。
若 `upstream_gate_status = no-go` 且 PM 未明确授权继续 → 强制进入 `blocked_mode`。

## Boundary rules / 边界规则
- Stay inside the total-table boundary for this skill.
- Accept standalone use in any requirement-to-execution scenario, but still emit an N110-compatible artifact contract.
- Do not silently expand into neighboring skills just because adjacent information is present.
- Keep `primary_scope: stakeholder_sync` in every non-blocked artifact; rollback, environment schedule, and execution ordering are **advisory support sections only**.

## Operating contexts
- `standalone`: the user needs this skill's artifact even if sibling artifacts do not exist yet.
- `composed`: one or more sibling artifacts already exist and should be linked, refreshed, or inherited instead of re-derived.

## Execution modes
Choose exactly one. Verify promotion preconditions before selecting:

| mode | when to use | minimum required input |
|---|---|---|
| `inventory_mode` | identify likely sync targets; no notice issued yet | change description or impact summary |
| `check_only_mode` | sync expectation exists but P0 targets not yet confirmed | 033 impact artifact or equivalent |
| `final_sync_mode` | all P0 targets confirmed; PM or TL approval exists | approved change + P0 confirmation |
| `blocked_mode` | source info missing OR N100 gate = no-go without PM override | — |

### Mode promotion rules
```
inventory_mode → check_only_mode:
  all P0 targets identified
  + 033 impact_radius is known

check_only_mode → final_sync_mode:
  all P0 targets confirmed notified
  + change approved by PM or TL
  + sync_completeness_score ≥ 90

any mode → blocked_mode (forced):
  N100 gate = no-go AND PM has not explicitly authorized continuation
  OR change_source is missing
```

If promotion is blocked, state which precondition is missing; do not silently downgrade to a weaker mode.

## Sync target selection
Run the T1–T8 decision tree in `references/sync-target-rules.md`. Inline summary:

| target_id | notify when | priority |
|---|---|---|
| `T1_pm_owner` | always | P0 |
| `T2_tech_lead` | impact_radius ≥ moderate OR DIM-3 api_breaking_change | P0 |
| `T3_qa_owner` | DIM-1 functional change OR DIM-2 schema change | P1 |
| `T4_design_owner` | DIM-1 + user-visible UI change | P1 |
| `T5_downstream_teams` | DIM-3 consumer_notification_required = true | P0 |
| `T6a_config_deploy` | DIM-2 migration_required = yes | P1 |
| `T6b_flag_switch` | change involves feature flag | P1 |
| `T7_compliance` | DIM-4 compliance_flag = true OR categories include compliance/security/data-privacy | P0 |
| `T8_stakeholder_business` | user-visible scope change + impact_radius ≥ major | P2 |

Keep `T6a_config_deploy` and `T6b_flag_switch` as **separate** entries; never merge them.

Gate check `target_selection_complete` = passed only when:
- T1_pm_owner present
- T5_downstream_teams present when any DIM-3 api_breaking_change is non-empty
- T7_compliance present when compliance_flag = true
- Every target has a `rationale` traceable to a DIM or change_category

## change_ref traceability / 变更溯源字段

每个 034 artifact 必须携带 `change_ref`，用于与 033 impact artifact 和 N100 new_gap 条目对齐：

```yaml
change_ref:
  source_type: n100_new_gap | prd_revision | pm_decision | engineering_feedback
  source_id: GAP-013            # 来自 030 cross_node_trace.remediation_plan 时
  source_skill: "023" | "030" | "033"
  prd_sections_affected: [PRD-07, PRD-11]
  impact_artifact_id:           # 033 的 artifact_id（若有）
  approved_by: PM | TL
  approved_at:
```

当 `source_type = n100_new_gap` 时，`source_id` 必须与 030 `cross_node_trace.remediation_plan` 中的 GAP ID 一致，确保全链路可追溯。

## Inputs / 允许输入
A standalone run may start from any one of:
- a confirmed change description or impact analysis
- at least one audience or stakeholder group

A composed run should also absorb these when available:
- impact artifact (033) — 提供 impact_radius + DIM 分析
- handover artifact (031) — 提供 open_questions 和 accepted readiness
- acceptance artifact (032)
- engineering feedback artifact (035)

## Output / 默认输出契约
Every non-blocked output must declare:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `contract_version`
- `canonical_output_name`
- `workflow_stage`
- `workflow_node`
- `gate_status`
- `gate_checks[]`
- `produced_event`
- `state_event`
- `exception_event`
- `sla_event`
- `priority`
- `sla_level`
- `auto_escalate_after`
- `routing_aliases[]`
- `consumed_by_nodes[]`
- `downstream_artifacts[]`
- `change_ref` ← **新增：必填，见 change_ref traceability 节**

### final_sync_mode output structure
In `final_sync_mode`, produce both:

**1. `需求变更同步通知.md`** — stakeholder-facing notice（see `references/output-template.md` sections 0–5）

**2. `需求变更同步计划.yaml`** — companion execution plan when execution ordering matters:

```yaml
sync_plan_id:
change_ref:             # 与通知主体保持一致
generated_at:
approval_ref:           # PM or TL approval signal
sync_stages:
  - stage: P0
    targets: [T1_pm_owner, T2_tech_lead]
    notification_due: immediately
    confirmed: false
  - stage: P1
    targets: [T3_qa_owner, T4_design_owner]
    notification_due: before_sprint_end
    confirmed: false
  - stage: P2
    targets: [T8_stakeholder_business]
    notification_due: at_release_note
    confirmed: false
verification_summary:
rollback_note:          # advisory only — 不得替代实际发布操作
```

### check_only_mode output structure
Produce a sync readiness table:
- 每个 target_id 的当前通知状态（confirmed / pending / missing）
- `sync_completeness_score`（公式见 `references/sync-target-rules.md`）
- `mode_promotion_verdict`: `ready_to_promote` 或 `blocked_by: [缺失的前置条件]`

Do not issue the stakeholder-facing notice in `check_only_mode`.

### inventory_mode output structure
Produce at minimum:

```yaml
sync_targets:
  - target_id: T1_pm_owner
    priority: P0
    notification_due: immediately
    rationale: "default required for all changes"
  - target_id: <derived from decision tree>
    priority: <P0/P1/P2>
    notification_due: <immediately | before_sprint_end | at_release_note>
    rationale: "<DIM or category that triggered>: <brief reason>"
evidence_gaps:
  - "<target where 033 impact analysis is incomplete>"
```

### blocked_mode output structure
State clearly:
- `blocked_reason`: 缺少哪项必要输入，或 gate 阻断原因
- `unblock_actions[]`: 解除阻断所需的最小动作清单
- `partial_inventory`: 若已知部分 target，可列出作为参考（标注 `provisional: true`）

## Gate rules
Always perform these checks before finalizing:
- `contract_fields_present`
- `canonical_output_name_preserved`
- `required_inputs_present_or_blocked`
- `boundary_respected`
- `downstream_consumability_declared`
- `change_ref_present_and_traceable` ← **新增**
- `impact_source_present_or_explained`
- `target_selection_complete`
- `verification_method_present`
- `primary_scope_respected`
- `mode_promotion_preconditions_met` ← **新增：当前 mode 的前置条件已满足**
- `stakeholder_notice_ready`（final_sync_mode only）
- `companion_yaml_present`（final_sync_mode only，当执行顺序 matters 时）

When evidence is incomplete, use `passed_with_gaps`, `blocked`, or `refresh_required`. Never imply full readiness.

## Workflow-v2 behavior
- Use schema version `1.1.0` and contract version `1.1.0`.
- Preserve `revision_log[]` so downstream consumers can see what changed between iterations.
- Emit workflow-v2-compatible event names.
- Carry an explicit SLA policy even in standalone runs.
- Prefer stable ids and trace anchors over free-text references.

## Workflow / 执行流程
1. 执行 N110 入场校验（`n110_intake`）；确定触发条件和上游 gate 状态。
2. 选择执行模式，验证 mode promotion 前置条件。
3. 运行 T1–T8 目标选择；执行 `target_selection_complete` gate check。
4. 填写 `change_ref`，追溯到 N100 new_gap / 033 impact / PM 决策。
5. 载入 `references/workflow-v2-alignment.md` 和 `references/n110-artifact-registry.md`。
6. 按 `references/output-template.md` 产出 artifact。
7. `final_sync_mode` 下：同时产出 `需求变更同步计划.yaml`。
8. 填写 gate、event、SLA、downstream 消费节。
9. 结尾输出 `next_skill_hints[]`、`refresh_triggers[]`、`revision_log[]`。

## Required behavior
- Prefer compact structured sections over long prose.
- Distinguish `confirmed`, `inferred`, and `blocked` content explicitly.
- Do not fabricate missing upstream decisions.
- Do not upgrade inherited readiness.
- Reuse existing ids whenever sibling artifacts are available.
- If a change affects many technical surfaces but few stakeholder audiences, optimize for audience clarity, not implementation detail volume.
- Keep rollback and environment sections clearly labeled as advisory support.

## Engineering source-of-truth
- Treat `MASTER.yaml` as the engineering source of truth for contract-bearing fields.
- Regenerate `references/output-template.md` and `references/workflow-v2-alignment.md` with `python3 scripts/generate_from_master.py --package-root .` after editing `MASTER.yaml` or `sources/*.md`.
- Keep sibling skill ids numeric in `sibling_skills_affected[]` and node consumers in `consumed_by_nodes[]`.

## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认：
- `n110_intake` 已填写，触发条件和上游 gate 状态已确认
- `change_ref` 已填写且可追溯到 N100 new_gap / 033 / PM 决策
- mode 已按 promotion rules 验证，当前 mode 的前置条件已满足；若未满足，已说明哪项缺失
- `target_selection_complete` gate 已计算，T1 / T5（DIM-3 触发时）/ T7（合规触发时）强制项已确认
- `final_sync_mode` 下：`需求变更同步计划.yaml` 已产出（若执行顺序 matters）
- `check_only_mode` 下：sync readiness table + `mode_promotion_verdict` 已输出
- `blocked_mode` 下：`blocked_reason` + `unblock_actions[]` 已输出
- artifact contract header 完整（artifact_type, schema_version, produced_event_name）
- gate_checks[] 已填写且无遗漏
- `consumed_by_nodes[]`, `sibling_skills_affected[]`, `refresh_effects[]` 已分离填写
- 按 `references/scoring-rubric.md` 做质量自评（0=blocked / 1=partial / 2=complete for mode）

## Key references
- `../../031-handover-package-generation/handover-package-generation/references/node-guide.md`：**N110 节点导航（必读，见 031）**
- `../../030-requirement-quality-review/requirement-quality-review/references/handoff-to-n110.md`：**N100→N110 节点交接协议（gate→mode 映射 + 034 触发条件 + change_ref 溯源规则）（必读，见 030）**
- `references/sync-target-rules.md`：**同步目标选择决策树（T1-T8）+ mode 晋升条件 + sync_completeness_score 公式 + 边界 case 表（必读）**
- `references/mode-guide.md`：**三档执行模式定义（必读）**
- `references/scoring-rubric.md`：输出质量评分（0=blocked / 1=partial / 2=complete for mode）
- `references/output-template.md`：sync 通知 artifact 输出结构（含 companion YAML 格式）
- `references/interoperability-contract.md`：N110 跨 skill 互操作契约
- `references/n110-artifact-registry.md`：N110 所有 artifact 注册表
- `references/refresh-matrix.md`：refresh 决策矩阵
- `references/circuit-breaker.md`：防止无限 refresh 循环的熔断规则
