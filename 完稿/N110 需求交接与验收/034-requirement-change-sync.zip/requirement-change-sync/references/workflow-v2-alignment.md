<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Workflow-v2 Alignment

## Identity
- skill_id: 034
- skill_name: requirement-change-sync
- workflow_node: N110
- engineering_release: r4-v3

## Downstream contract
- consumed_by_nodes: [N270, N280, N290, N300, N350, N360]
- sibling_skills_affected: []
- refresh_effects:
  - execution-surface downstream artifact with no sibling refresh ownership
  - when change impact is major or mega, final_sync_mode becomes mandatory

## Event contract
- produced_event: produced.n110.requirement-change-sync.v1
- state_event: state.n110.requirement-change-sync.v1
- exception_event: exception.n110.requirement-change-sync.v1
- sla_event: sla.n110.requirement-change-sync.v1
- recommended_subscribers: [N270, N280, N300, N330, N350, N360, N390]

## Shared state contract
- reads: [changes, impact_analyses, handover_packages, acceptance_criteria, feedbacks]
- writes: [sync_logs, artifact_index, trace_index]
- join_keys: [artifact_id, normalized_role, change_id]

## Source-of-truth references
- interoperability_contract: references/interoperability-contract.md
- workflow_alignment: references/workflow-v2-alignment.md
- artifact_registry: references/n110-artifact-registry.md
- refresh_matrix: references/refresh-matrix.md

## Sync-specific behavior
- keep notice-surface and execution-surface outputs separate
- represent feature-flag delivery as `T6a_config_deploy` and `T6b_flag_switch`
- keep T10 naming aligned to `T10_security_compliance_review`
