<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Output Template

# 需求变更同步通知.md

## 0. Artifact contract
- artifact_id:
- artifact_type: n110.requirement-change-sync
- schema_version: 1.1.0
- contract_version: 1.1.0
- canonical_output_name: 需求变更同步通知.md
- skill_id: 034
- skill_name: requirement-change-sync
- workflow_node: N110
- package_version: 3.0.0
- engineering_release: r4-v3
- operating_context: standalone / composed
- execution_mode: inventory_mode / check_only_mode / final_sync_mode / blocked_mode
- generated_at:
- consumed_by_nodes: [N270, N280, N290, N300, N350, N360]
- sibling_skills_affected: []
- refresh_effects:
  - execution-surface downstream artifact with no sibling refresh ownership
  - when change impact is major or mega, final_sync_mode becomes mandatory
- downstream_artifacts: [任务状态同步.md, 风险项清单.csv, 产品研发对齐摘要.md, 需求变更同步计划.yaml]
- shared_state_reads: [changes, impact_analyses, handover_packages, acceptance_criteria, feedbacks]
- shared_state_writes: [sync_logs, artifact_index, trace_index]

## 1. Gate and readiness
- gate_status: passed / passed_with_gaps / blocked / refresh_required
- gate_checks: [contract_fields_present, canonical_output_name_preserved, boundary_respected, downstream_consumability_declared, sibling_boundary_clean]
- confidence:
- readiness_note:
- blocker_ids:

## 2. Event and SLA
- produced_event: produced.n110.requirement-change-sync.v1
- state_event: state.n110.requirement-change-sync.v1
- exception_event: exception.n110.requirement-change-sync.v1
- sla_event: sla.n110.requirement-change-sync.v1
- recommended_subscribers: [N270, N280, N300, N330, N350, N360, N390]
- priority: P1
- sla_level: P1
- auto_escalate_after: 1d
- escalation_target: change_owner_or_release_coordinator
- circuit_breaker_state:

## 3. Sync notice
- sync_notice:
- audience_impact:
- key_dates:
- contact_points:

## 4. Companion execution plan
- companion_artifacts: [需求变更同步计划.yaml]
- execution_stage_summary:
- verification_summary:
- rollback_summary:

## 5. Delivery notes
- environment_schedule:
- revision_log:
- next_skill_hints:
