# Sync Target Selection Rules / 同步目标选择规则

本文件定义 `requirement-change-sync` 在三档模式下如何**判断向哪些对象发送同步通知**，以及**按什么顺序**执行同步。

---

## 1. 同步目标分类 / Target Taxonomy

| target_id | 目标类型 | 触发条件 | 通知优先级 |
|---|---|---|---|
| `T1_pm_owner` | PM / 需求 owner | 任何需求变更 | P0（必须） |
| `T2_tech_lead` | 技术负责人 / TL | impact_radius ≥ moderate 或 DIM-3 api_breaking_change 存在 | P0 |
| `T3_qa_owner` | QA 负责人 | 功能变更（DIM-1 受影响）或 DIM-2 schema_changes 存在 | P1 |
| `T4_design_owner` | 设计师 | DIM-1 受影响 + 有用户可见 UI 变化 | P1 |
| `T5_downstream_teams` | 依赖本模块的下游团队 | DIM-3 consumer_notification_required = true 或 api_breaking_changes 非空 | P0 |
| `T6a_config_deploy` | 配置/运维 | DIM-2 migration_required = yes 或 有部署步骤变更 | P1 |
| `T6b_flag_switch` | 功能开关管理方 | 变更涉及 feature flag 开关 | P1 |
| `T7_compliance` | 合规/法务 | DIM-4 compliance_flag = true 或 change_categories 含 compliance / security / data-privacy | P0 |
| `T8_stakeholder_business` | 业务侧 stakeholder | 影响外部用户体验的 scope/flow 变更，且 impact_radius ≥ major | P2 |

---

## 2. 目标选择决策树 / Selection Decision Tree

```
Step 1: 始终选 T1_pm_owner

Step 2: 根据 impact_radius 决定 T2_tech_lead
  impact_radius in {moderate, major, catastrophic} → 选 T2_tech_lead
  impact_radius = minor → T2_tech_lead 可选（建议告知）

Step 3: 根据受影响维度扩展目标
  DIM-1 functional_impact 受影响 →
    + T3_qa_owner（功能变更需要更新测试用例）
    + T4_design_owner（若有 UI 变化）

  DIM-2 data_impact 受影响 →
    + T3_qa_owner（数据校验用例需更新）
    + T6a_config_deploy（若 migration_required = yes）

  DIM-3 api_integration_impact 受影响 →
    + T2_tech_lead（必选）
    + T5_downstream_teams（consumer_notification_required = true 时）

  DIM-4 permission_impact 受影响 →
    + T7_compliance（若 compliance_flag = true）
    + T2_tech_lead

  DIM-5 downstream_dependency 受影响 →
    + 对应的 N110 sibling skill owner（由 stale_artifacts[] 推导）

Step 4: 根据 change_categories 强制添加
  含 compliance / security / data-privacy → + T7_compliance（P0）
  含 ux → + T4_design_owner
  含 cost → + T8_stakeholder_business（若 impact_radius ≥ major）

Step 5: 根据 feature flag 存在 → + T6b_flag_switch
```

---

## 3. 通知优先级与顺序 / Notification Ordering

```
Priority P0（must notify before work starts）:
  T1_pm_owner → T7_compliance（若触发）→ T2_tech_lead → T5_downstream_teams

Priority P1（notify before sprint ends）:
  T3_qa_owner → T4_design_owner → T6a_config_deploy → T6b_flag_switch

Priority P2（notify at sprint review / release note）:
  T8_stakeholder_business
```

P0 目标中任一未确认通知 → `check_only_mode` 不得晋升为 `final_sync_mode`。

---

## 4. inventory_mode 的最低输出

在 `inventory_mode` 下，至少输出：

```yaml
sync_targets:
  - target_id: T1_pm_owner
    priority: P0
    notification_due: immediately
    rationale: "default required for all changes"
  - target_id: <derived from decision tree above>
    priority: <P0/P1/P2>
    notification_due: <immediately / before_sprint_end / at_release_note>
    rationale: "<dim or category that triggered>: <brief reason>"
  ...
evidence_gaps:
  - "<any target where 033 impact analysis is incomplete>"
```

---

## 5. target_selection_complete 门禁判断

Gate check `target_selection_complete` 判定为 passed 的条件：
- T1_pm_owner 必须出现
- 所有 DIM-3 api_breaking_changes 非空时，T5_downstream_teams 必须出现
- 所有 compliance_flag = true 时，T7_compliance 必须出现
- 每个 target 必须有 `rationale`（可溯源到 DIM-* 或 change_categories）

未达到以上条件 → gate 标记为 `target_selection_incomplete`，并列出缺失 target。

---

## 6. mode 晋升条件（补充 mode-guide.md）

| 从 | 到 | 前置条件 |
|---|---|---|
| `inventory_mode` | `check_only_mode` | 所有 P0 target 已识别；033 分析已提供 impact_radius |
| `check_only_mode` | `final_sync_mode` | 所有 P0 target 已确认通知；change 已经过 PM 或 TL approve |
| 任意 → `blocked` | 强制 | N100 gate = no-go 且 PM 未明确批准继续同步 |

---

## 同步完整性量化评分 / Sync Completeness Scoring

```
sync_completeness_score = 100 - (
  p0_target_not_notified × 30 +    # P0 目标未收到通知
  p1_target_not_notified × 10 +    # P1 目标未收到通知
  no_rationale_on_target × 8 +     # target 条目无 rationale（无法溯源到触发维度）
  target_selection_incomplete × 20 + # gate check 未通过（T1 缺失 / compliance 缺失）
  mode_not_upgraded × 15           # 满足晋升条件但 mode 未升级
)
clip to [0, 100]
```

| sync_completeness_score | 等级 |
|---:|---|
| ≥ 90 | complete（可作为 final_sync 证据） |
| 70–89 | partial（P1 有遗漏，可并行推进） |
| < 70 | incomplete（P0 有遗漏，须补全后继续） |

## 边界 Case 对照表

| 场景 | 正确处理 | 常见误判 |
|---|---|---|
| 变更只影响 DIM-2（数据），无 API breaking change | T1+T3+T6a（若 migration）；不需 T5 | 错误添加 T5（下游团队），因 DIM-3 未受影响 |
| compliance_flag=true 但评估者认为影响小 | T7（compliance）必须添加，P0 | 省略 T7 因为"影响不大" |
| 已在 check_only_mode，T5 下游未确认 | 不得晋升 final_sync | 强行晋升 final_sync |
| 变更涉及 feature flag 但无 T6b | 添加 T6b，P1 | 遗漏 flag switch 负责人 |
| 多版本同时同步（hotfix + main） | 每个版本分别产出 sync 条目 | 合并为一条混合 sync |
