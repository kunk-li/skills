# Mode Guide

## inventory_mode
Use when you need to identify likely targets, audiences, and evidence gaps.

## check_only_mode
Use when a sync expectation exists but final stakeholder notice is not yet safe.

## final_sync_mode
Requires an approved change or equivalent decision signal.
Produce the notice and include the companion `需求变更同步计划.yaml` when execution ordering matters.
