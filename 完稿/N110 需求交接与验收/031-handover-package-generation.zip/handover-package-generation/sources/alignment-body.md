## Handover-specific behavior
- act as the aggregation owner for `N110_handover_report.md`
- preserve `baseline_hash` and refresh when it no longer matches the current baseline
- keep recipient view logic separate from downstream engineering execution
