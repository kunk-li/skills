## 3. Package summary
- package_id:
- handover_mode: initial / incremental / emergency
- baseline_version:
- baseline_hash:
- valid_until:
- handover_readiness_score:
- revision_log:

## 4. Recipient views
- recipient_views:
- acknowledgement_protocol:
- risk_signals:
- open_questions:

## 5. Aggregation notes
- node_aggregation_owner: true
- aggregated_sections:
- related_change_ids:
- next_skill_hints:
