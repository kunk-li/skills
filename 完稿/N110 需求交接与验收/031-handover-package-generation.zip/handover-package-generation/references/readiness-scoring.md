# Handover Readiness Score / 交接就绪度评分

本文件定义 `handover_readiness_score` 的量化计算公式及 N100 gate_status → execution_mode 的映射规则。

---

## 1. handover_readiness_score 计算公式

### 四个子维度评分（各 0–100）

#### 1.1 Package Completeness / 包完整性（权重 0.35）

```
completeness_score = 100 - (
  missing_required_sections × 15 +    # 缺失必须章节（如 scope、recipient_views）
  blocked_sections × 8 +              # 有章节但内容被标记为 blocked
  missing_trace_links × 3             # 缺少到 N090 PRD 的溯源链接
)
clip to [0, 100]
```

必须章节（缺一扣 15 分）：
- scope_summary
- recipient_views[]（至少 1 个）
- gate_status
- open_questions[]（可为空列表，但必须存在）
- next_skill_hints[]（可为空列表，但必须存在）

#### 1.2 Traceability / 溯源可追溯性（权重 0.25）

```
traceability_score = 100 - (
  requirements_without_prd_anchor × 10 +   # 需求项无 PRD-XX 锚点
  decisions_without_ref × 5 +              # 决策无 decision_ref
  blockers_without_source × 5             # 阻断项无来源 skill 引用
)
clip to [0, 100]
```

#### 1.3 Acknowledgement Progress / 接收方确认进度（权重 0.25）

```
ack_score = (confirmed_recipients / total_required_recipients) × 100

若 total_required_recipients == 0（未定义接收方）：ack_score = 50（中性）
```

#### 1.4 Blocker Status / 阻断项状态（权重 0.15）

```
blocker_score = 100 - (
  unresolved_p0_blockers × 30 +    # 未解决的 P0 阻断（来自 N100）
  unresolved_p1_blockers × 10 +   # 未解决的 P1 阻断
  open_questions_blocking × 5     # 标记为 blocking=true 的未决项
)
clip to [0, 100]
```

### 综合评分

```
handover_readiness_score = (
  0.35 × completeness_score +
  0.25 × traceability_score +
  0.25 × ack_score +
  0.15 × blocker_score
)
```

### pass_readiness 映射

| handover_readiness_score | pass_readiness | 含义 |
|---:|---|---|
| ≥ 90 | ready | 可直接交接，无需额外确认 |
| 75–89 | conditional_ready | 有小项待确认，可并行推进 |
| 60–74 | needs_action | 需完成特定动作后才可交接 |
| < 60 | not_ready | 存在重大缺失，不应推进交接 |

---

## 2. N100 gate_status → execution_mode 映射

### 映射规则表

| N100 gate_status | 允许的 execution_mode | 默认 execution_mode | 附加条件 |
|---|---|---|---|
| `go` | formal_mode, minimal_mode | formal_mode | 无 |
| `conditional-go` | formal_mode（带 warnings）, refresh_mode | formal_mode | 必须在输出中包含 `conditional_go_conditions[]` 列表 |
| `no-go` | blocked_mode | blocked_mode | 必须在 `gate_checks[]` 中列出每个 no-go 原因 |
| 未提供 N100 输出 | minimal_mode | minimal_mode | 必须标注 `upstream_gate_status: unknown` |

### execution_mode 定义

| execution_mode | 含义 | 适用场景 |
|---|---|---|
| `formal_mode` | 完整交接包，包含所有视图和 SLA | go 或 conditional-go |
| `minimal_mode` | 精简交接包，核心字段 + 开放问题清单 | 无 N100 输入或快速推进 |
| `refresh_mode` | 在现有包基础上做局部刷新 | 已有包但上游变更或反馈到达 |
| `blocked_mode` | 说明阻断原因，不产出完整包 | no-go 或关键输入缺失 |

### 示例：conditional-go 时的输出要求

```yaml
gate_status: conditional_ready
n100_gate_status: conditional-go
execution_mode: formal_mode
conditional_go_conditions:
  - "025 completeness_score 为 72，需在交接后 3 个工作日内完成 D6 缺口补充"
  - "029 有 2 个 deferred_to_version 待确认，由 PM owner 在 sprint 启动前决策"
```

---

## 3. readiness_score 的声明要求

每次输出必须包含：

```yaml
handover_readiness_score: <number 0-100>
handover_readiness_breakdown:
  completeness_score: <number>
  traceability_score: <number>
  ack_score: <number>
  blocker_score: <number>
pass_readiness: <ready | conditional_ready | needs_action | not_ready>
readiness_gap_summary: <若 pass_readiness != ready，说明主要缺失>
```

---

## 交接模式选择决策树 / Execution Mode Decision Tree

```
Q1: N100 的 gate_status 是什么？
    go             → formal_mode（完整交接包）
    conditional-go → formal_mode（带 warnings）+ conditional_go_conditions[]
    no-go          → blocked_mode（说明阻断原因，不产出完整包）
    未提供          → minimal_mode（标注 upstream_gate_status: unknown）

Q2（formal_mode 下）: 是否已有该需求包的历史交接包？
    YES 且有增量变更 → refresh_mode（在现有包基础上局部更新）
    YES 无变更      → 直接复用，不需重新生成
    NO             → 正式生成 formal_mode 包

Q3: handover_readiness_score 是多少？
    ≥ 90 → pass_readiness = ready
    75–89 → pass_readiness = conditional_ready
    60–74 → pass_readiness = needs_action（通知 PM，列出必须完成的 actions）
    < 60  → pass_readiness = not_ready（不应推进交接）
```

## 必须章节与 recipient_views 决策规则

```
formal_mode 必须包含的最小视图组合：

if 存在工程接收方（dev/backend/frontend）：
  → 添加 engineering_view（功能需求 + 业务规则 + 验收标准）

if 存在 QA 接收方：
  → 添加 qa_view（验收标准 + 边界场景 + 测试数据来源）

if 存在产品/PM 接收方：
  → 添加 pm_view（范围确认 + 未决项 + 风险说明）

if 存在外部团队/第三方：
  → 添加 external_view（API 契约 + 集成点说明）
```

## 边界 Case 对照表

| 场景 | execution_mode | 常见误判 | 处理要点 |
|---|---|---|---|
| gate=go 但 readiness_score=55 | formal_mode → needs_action | blocked_mode | gate 通过但包质量不足，用 needs_action 标注 |
| gate=conditional-go 且有 2 个 P0 blocker | formal_mode with warnings | blocked_mode | conditional-go 不等于 no-go，但必须列 conditions |
| gate=no-go 但 PM 批准继续推进 | blocked_mode + PM override 文档 | 强行 formal_mode | 必须记录 override，不可静默改为 formal |
| 已有包但 N100 发现新 P0 | refresh_mode → needs_action | formal_mode 重建 | 优先 refresh，仅影响的章节更新 |
| ack_score=0（无接收方确认） | conditional_ready | not_ready | 未定义接收方时 ack_score=50（中性），不影响 ready |
