# N110 需求交接与验收 — 节点导航

> **节点定位**：以 N100 的 gate 决策为输入，生成工程可用的交接包，并处理后续的变更影响、同步和工程反馈。N110 是整个需求链的出口节点，也是最复杂的节点（每个 skill 有 20+ 个 reference 文件）。

---

## Skills 一览

| ID | Skill | 主要输出 | 触发时机 |
|---|---|---|---|
| 031 | handover-package-generation | handover package + readiness_score | N100 gate 通过后首次交接 |
| 032 | acceptance-criteria-generation | AC 清单（Given-When-Then 格式）| 与 031 同步，或独立生成验收标准 |
| 033 | requirement-change-impact-analysis | 五维度影响矩阵 + impact_radius | 需求变更到达时 |
| 034 | requirement-change-sync | sync_plan 同步方案 | 033 分析完成后需要更新下游 artifacts |
| 035 | engineering-feedback-return | feedback_resolution + PRD 修订建议 | 工程侧反馈到达时 |

---

## 推荐执行顺序

**首次交接**：
```
N100 gate → 031（主包）→ 032（验收标准）
```

**需求变更**：
```
变更请求 → 033（影响分析）→ 034（同步方案）→ 031 refresh → 032 refresh
```

**工程反馈**：
```
工程反馈 → 035（决策裁决）→ 033（若需要重做影响分析）→ 034 → 031 refresh
```

---

## 031 特别说明：readiness_score 公式

**必须阅读 `references/readiness-scoring.md`**

```
handover_readiness_score =
  0.35 × completeness_score +    # 缺失必须章节（-15/个）；缺溯源链接（-3/个）
  0.25 × traceability_score +    # 无 PRD-XX 锚点（-10）；无 decision_ref（-5）
  0.25 × ack_score +             # confirmed_recipients / total_required_recipients × 100
  0.15 × blocker_score           # P0 blocker（-30）；P1 blocker（-10）；blocking open_question（-5）

pass_readiness 映射：
  ≥90 → ready
  75-89 → conditional_ready
  60-74 → needs_action
  <60 → not_ready
```

**N100 gate_status → execution_mode 映射**（在 readiness-scoring.md 中定义）：

| gate_status | execution_mode |
|---|---|
| go | formal_mode |
| conditional-go | formal_mode（with warnings）+ conditional_go_conditions[] |
| no-go | blocked_mode |
| 未提供 | minimal_mode |

---

## 033 特别说明：五维度分析框架

**必须阅读 `references/five-dimension-model.md`**

| 维度 | 分析重点 | 核心输出字段 |
|---|---|---|
| DIM-1 功能影响 | 功能变化、业务流程中断 | affected_features[], flow_breaks[] |
| DIM-2 数据影响 | 字段/对象变更、数据迁移 | schema_changes[], migration_required |
| DIM-3 接口影响 | API breaking change、事件格式 | api_breaking_changes[], event_schema_changes[] |
| DIM-4 权限影响 | 角色变化、合规边界 | permission_delta[], compliance_flag |
| DIM-5 下游依赖影响 | 已生成 artifacts 失效 | stale_artifacts[], refresh_urgency |

**impact_radius 评分**：
```
dim_coverage = 受影响维度数 / 5
catastrophic: dim_coverage=1.0 且 severity_max=critical
major: dim_coverage≥0.6 或 any severity=critical
moderate: dim_coverage≥0.4 或 any severity=major
minor: 其余
```

**five_dimension_scan_present gate check**：
- full_impact 模式：5 个维度均有 status（analyzed/not_applicable/blocked）
- quick_impact 模式：≥2 个 analyzed，其余明确注明 not_applicable 理由

---

## 共享工程设施（031-035 共用）

N110 的 5 个 skill 共享以下文件（每个 skill 目录内各有一份）：
- `references/workflow-v2-alignment.md`：字段版本对齐规范
- `references/n110-artifact-registry.md`：N110 所有 artifact 的注册表
- `references/interoperability-contract.md`：N110 跨 skill 互操作契约
- `references/refresh-matrix.md`：决定哪些 artifact 需要 refresh 的决策矩阵
- `references/circuit-breaker.md`：防止无限 refresh 循环的熔断规则
- `MASTER.yaml + scripts/generate_from_master.py`：从 MASTER.yaml 生成多个输出文件

修改 skill 定义时，先编辑 `MASTER.yaml` 和 `sources/*.md`，再运行 generate 脚本。

---

## 跨节点交接协议

参见 `transitions/N100-N110-transition.md`，该文件定义：

- 030 gate → 031 execution_mode 的完整映射（含 conditional_go_conditions[] 格式）
- N100 issue 在 031 open_questions[] 中的继承格式（含 source_type / source_id）
- handover_readiness_score 与 N100 unresolved_blockers 的关联公式
- N110 兄弟 skill（032/033/034/035）的触发规则

## 常见误用

| 误用 | 正确做法 |
|---|---|
| 031 的 execution_mode 不基于 N100 gate_status | 使用 readiness-scoring.md 的映射表（go→formal, no-go→blocked 等）|
| 033 只分析"显而易见的"功能影响 | 必须过五维度 checklist；quick_impact 模式也要明确说明跳过哪些维度及理由 |
| 035 的工程反馈直接写入 PRD，不经过 033/034 | 先用 035 做决策裁决，影响范围大的进 033 重新做影响分析 |
| 不写 `handover_readiness_breakdown` | 每次输出必须包含四个子维度分数以供审计 |
| 034 的 sync_plan 不说明同步目标选择理由 | 同步目标的选择依据必须写明（基于 033 的 stale_artifacts[] 和 refresh_urgency）|
