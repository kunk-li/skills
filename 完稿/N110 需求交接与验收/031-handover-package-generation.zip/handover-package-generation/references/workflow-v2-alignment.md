<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Workflow-v2 Alignment

## Identity
- skill_id: 031
- skill_name: handover-package-generation
- workflow_node: N110
- engineering_release: r4-v3

## Downstream contract
- consumed_by_nodes: [N120, N350, N360]
- sibling_skills_affected: []
- refresh_effects:
  - acts as the node aggregation owner for N110 handover outputs
  - refresh when approved change, accepted feedback, or stale snapshot invalidates the package

## Event contract
- produced_event: produced.n110.handover-package.v1
- state_event: state.n110.handover-package.v1
- exception_event: exception.n110.handover-package.v1
- sla_event: sla.n110.handover-package.v1
- recommended_subscribers: [N330, N340, N350, N370, N390]

## Shared state contract
- reads: [changes, feedbacks, decision_registry, impact_analyses, acceptance_criteria]
- writes: [handover_packages, artifact_index, trace_index]
- join_keys: [artifact_id, normalized_role, change_id]

## Source-of-truth references
- interoperability_contract: references/interoperability-contract.md
- workflow_alignment: references/workflow-v2-alignment.md
- artifact_registry: references/n110-artifact-registry.md
- refresh_matrix: references/refresh-matrix.md

## Handover-specific behavior
- act as the aggregation owner for `N110_handover_report.md`
- preserve `baseline_hash` and refresh when it no longer matches the current baseline
- keep recipient view logic separate from downstream engineering execution
