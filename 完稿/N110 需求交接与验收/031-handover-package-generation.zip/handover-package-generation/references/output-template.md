<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Output Template

# 需求交接包.zip

## 0. Artifact contract
- artifact_id:
- artifact_type: n110.handover-package
- schema_version: 1.1.0
- contract_version: 1.1.0
- canonical_output_name: 需求交接包.zip
- skill_id: 031
- skill_name: handover-package-generation
- workflow_node: N110
- package_version: 3.0.0
- engineering_release: r4-v3
- operating_context: standalone / composed
- execution_mode: minimal_mode / formal_mode / refresh_mode / blocked_mode
- generated_at:
- consumed_by_nodes: [N120, N350, N360]
- sibling_skills_affected: []
- refresh_effects:
  - acts as the node aggregation owner for N110 handover outputs
  - refresh when approved change, accepted feedback, or stale snapshot invalidates the package
- downstream_artifacts: [开发需求解析.md, 任务清单.csv, 产品研发对齐摘要.md]
- shared_state_reads: [changes, feedbacks, decision_registry, impact_analyses, acceptance_criteria]
- shared_state_writes: [handover_packages, artifact_index, trace_index]

## 1. Gate and readiness
- gate_status: passed / passed_with_gaps / blocked / refresh_required
- gate_checks: [contract_fields_present, canonical_output_name_preserved, boundary_respected, downstream_consumability_declared, sibling_boundary_clean]
- confidence:
- readiness_note:
- blocker_ids:

## 2. Event and SLA
- produced_event: produced.n110.handover-package.v1
- state_event: state.n110.handover-package.v1
- exception_event: exception.n110.handover-package.v1
- sla_event: sla.n110.handover-package.v1
- recommended_subscribers: [N330, N340, N350, N370, N390]
- priority: P0
- sla_level: P0
- auto_escalate_after: 4h
- escalation_target: product_or_delivery_owner
- circuit_breaker_state:

## 3. Package summary
- package_id:
- handover_mode: initial / incremental / emergency
- baseline_version:
- baseline_hash:
- valid_until:
- handover_readiness_score:
- revision_log:

## 4. Recipient views
- recipient_views:
- acknowledgement_protocol:
- risk_signals:
- open_questions:

## 5. Aggregation notes
- node_aggregation_owner: true
- aggregated_sections:
- related_change_ids:
- next_skill_hints:
