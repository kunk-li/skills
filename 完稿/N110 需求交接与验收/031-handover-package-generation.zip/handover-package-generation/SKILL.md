---
name: handover-package-generation
description: "generate n110-compatible handover packages that stay standalone and composable. use when chatgpt needs to turn a prd, reviewed baseline, or requirement-quality output into a product-to-engineering handoff package. emit a schema-versioned artifact contract, canonical output name, gate status, event fields, sla fields, recipient views, snapshot binding, trace links, and acknowledgement flow. stay within handover scope: create the package, risks, and open questions, but do not replace engineering design, testing, or release execution."
---
# handover-package-generation

Create a workflow-v2-compatible N110 artifact that is independently usable and composable with sibling skills.

## Primary workflow identity
- Workflow stage: 协同交接
- Workflow node: N110
- Registry category: 协同交接
- Registry subcategory: 产品到研发
- Registry function: 交接包输出
- Canonical output name: `需求交接包.zip`
- Primary goal: 输出给研发的交接材料、风险点和待确认项

Follow both `references/interoperability-contract.md` and `references/workflow-v2-alignment.md` on every run. Reuse `references/n110-artifact-registry.md` when sibling artifacts already exist.

## Boundary
- Stay inside the total-table boundary for this skill.
- Accept standalone use in any requirement-to-execution scenario, but still emit an N110-compatible artifact contract so the output can be composed later.
- Do not silently expand into neighboring skills just because adjacent information is present.

## Operating contexts
- `standalone`: the user needs this skill's artifact even if sibling artifacts do not exist yet.
- `composed`: one or more sibling artifacts already exist and should be linked, refreshed, or inherited instead of re-derived.

## Execution modes
Choose exactly one:
- `minimal_mode`: fast handover with the smallest safe package.
- `formal_mode`: full handover with role views, acknowledgement, and snapshot control.
- `refresh_mode`: rebuild an existing package after confirmed change, new feedback, or stale snapshot.
- `blocked_mode`: do not issue a handover package; issue only the safe blocked artifact.

## Required minimum input
A standalone run may start from any one of:
- reviewed baseline
- prd or equivalent source of truth
- structured requirement notes
- approved decision log

A composed run should also absorb these when available:
- acceptance criteria artifact
- change impact artifact
- change sync artifact
- engineering feedback artifact
- readiness review artifact

## Required artifact contract fields
Every non-blocked output must declare:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `contract_version`
- `canonical_output_name`
- `workflow_stage`
- `workflow_node`
- `gate_status`
- `gate_checks[]`
- `produced_event`
- `state_event`
- `exception_event`
- `sla_event`
- `priority`
- `sla_level`
- `auto_escalate_after`
- `routing_aliases[]`
- `consumed_by_nodes[]`
- `downstream_artifacts[]`

## Gate rules
Always perform these checks before finalizing the artifact:
- contract fields present
- canonical output name preserved
- required inputs either present or explicitly blocked
- boundary respected
- downstream consumability described
- this skill specific checks: required_contents_matrix_complete, recipient_views_present, snapshot_binding_present, traceability_present, acknowledgement_protocol_present

When evidence is incomplete, use `passed_with_gaps`, `blocked`, or `refresh_required` instead of implying full readiness.

## Workflow-v2 behavior
- Use schema version `1.0.0` and contract version `1.0.0` unless the output shape changes.
- Preserve `revision_log[]` so downstream consumers can see what changed between iterations.
- Emit workflow-v2-compatible event names.
- Carry an explicit SLA policy even in standalone runs.
- Prefer stable ids and trace anchors over free-text references.

## Extra behavior for this skill
- Always compute `handover_readiness_score` and explain what prevents full readiness.
- Use `refresh_mode` when feedback, change, or staleness invalidates the existing package.

## Recommended workflow
1. Determine whether the request is standalone or composed.
2. Select the execution mode that fits the available evidence.
3. Load the workflow alignment and artifact registry references.
4. Produce the artifact using `references/output-template.md`.
5. Fill gate, event, SLA, and downstream-consumption sections before finalizing.
6. End with `next_skill_hints[]`, `refresh_triggers[]`, and `revision_log[]`.

## Required behavior
- Prefer compact structured sections over long prose.
- Distinguish `confirmed`, `inferred`, and `blocked` content.
- Do not fabricate missing upstream decisions.
- Do not upgrade inherited readiness.
- Reuse existing ids whenever sibling artifacts are available.
- `handover_readiness_score` should reflect package completeness, traceability, acknowledgement progress, and unresolved blockers.
- When the package is stale, prefer `refresh_required` over pretending the package is still current.

## Phase 2 optimization notes
- Treat this skill as the node-level aggregation owner for `N110_handover_report.md` when sibling artifacts are available.
- Keep `consumed_by_nodes[]`, `sibling_skills_affected[]`, and `refresh_effects[]` separate.

## Engineering source-of-truth
- Treat `MASTER.yaml` as the engineering source of truth for contract-bearing fields.
- Regenerate `references/output-template.md` and `references/workflow-v2-alignment.md` with `python3 scripts/generate_from_master.py --package-root .` after editing `MASTER.yaml` or `sources/*.md`.
- Keep sibling skill ids numeric in `sibling_skills_affected[]` and keep node consumers in `consumed_by_nodes[]`.
