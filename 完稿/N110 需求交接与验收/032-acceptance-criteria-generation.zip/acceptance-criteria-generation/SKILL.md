---
name: acceptance-criteria-generation
description: "generate n110-compatible acceptance criteria that stay standalone and composable. use when chatgpt needs to turn requirement structure, business rules, or a reviewed requirement package into a test-ready acceptance artifact. emit a schema-versioned artifact contract, canonical output name, gate status, event fields, sla fields, criterion patterns, negative cases, dependency links, and downstream test-consumer hints. stay within acceptance scope and do not replace full test execution or release validation."
---
# acceptance-criteria-generation

Create a workflow-v2-compatible N110 artifact that is independently usable and composable with sibling skills.

## Role / 角色定位
- Workflow stage: 协同交接
- Workflow node: N110
- Registry category: 协同交接
- Registry subcategory: 产品到测试
- Registry function: 验收统一
- Canonical output name: `验收标准.md`
- Primary goal: 生成功能、异常、权限、数据一致性验收清单

Follow both `references/interoperability-contract.md` and `references/workflow-v2-alignment.md` on every run. Reuse `references/n110-artifact-registry.md` when sibling artifacts already exist.

## Boundary rules / 边界规则
- Stay inside the total-table boundary for this skill.
- Accept standalone use in any requirement-to-execution scenario, but still emit an N110-compatible artifact contract so the output can be composed later.
- Do not silently expand into neighboring skills just because adjacent information is present.

## Operating contexts
- `standalone`: the user needs this skill's artifact even if sibling artifacts do not exist yet.
- `composed`: one or more sibling artifacts already exist and should be linked, refreshed, or inherited instead of re-derived.

## Execution modes
Choose exactly one:
- `seed_mode`: generate a safe starter set from a short requirement and rules.
- `refine_mode`: normalize or improve an existing acceptance set.
- `formal_mode`: full acceptance set with patterns, negatives, dependencies, and downstream hints.
- `blocked_mode`: explain what evidence is missing before meaningful acceptance criteria can be issued.

## Inputs / 允许输入
A standalone run may start from any one of:
- requirement structure or requirement notes
- business rules or equivalent policy notes
- reviewed requirement package or quality review

A composed run should also absorb these when available:
- handover artifact
- change impact artifact
- engineering feedback artifact
- readiness review artifact

## Output / 默认输出契约
Every non-blocked output must declare:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `contract_version`
- `canonical_output_name`
- `workflow_stage`
- `workflow_node`
- `gate_status`
- `gate_checks[]`
- `produced_event`
- `state_event`
- `exception_event`
- `sla_event`
- `priority`
- `sla_level`
- `auto_escalate_after`
- `routing_aliases[]`
- `consumed_by_nodes[]`
- `downstream_artifacts[]`

## Gate rules
Always perform these checks before finalizing the artifact:
- contract fields present
- canonical output name preserved
- required inputs either present or explicitly blocked
- boundary respected
- downstream consumability described
- this skill specific checks: criterion_pattern_selected, negative_cases_present, testability_tier_present, ac_kind_present, acyclic_dependencies_or_explained

When evidence is incomplete, use `passed_with_gaps`, `blocked`, or `refresh_required` instead of implying full readiness.

## Workflow-v2 behavior
- Use schema version `1.0.0` and contract version `1.0.0` unless the output shape changes.
- Preserve `revision_log[]` so downstream consumers can see what changed between iterations.
- Emit workflow-v2-compatible event names.
- Carry an explicit SLA policy even in standalone runs.
- Prefer stable ids and trace anchors over free-text references.

## Extra behavior for this skill
- Always list `downstream_test_consumers[]` so N230, N240, N260, and N290 can consume the artifact predictably.
- Keep functional and non-functional acceptance items separate when both exist.

## Workflow / 执行流程
1. Determine whether the request is standalone or composed.
2. Select the execution mode that fits the available evidence.
3. Load the workflow alignment and artifact registry references.
4. Produce the artifact using `references/output-template.md`.
5. Fill gate, event, SLA, and downstream-consumption sections before finalizing.
6. End with `next_skill_hints[]`, `refresh_triggers[]`, and `revision_log[]`.

## Required behavior
- Prefer compact structured sections over long prose.
- Distinguish `confirmed`, `inferred`, and `blocked` content.
- Do not fabricate missing upstream decisions.
- Do not upgrade inherited readiness.
- Reuse existing ids whenever sibling artifacts are available.
- For business, security, and compliance criteria, require at least two negative cases unless the artifact explicitly explains why not.
- If non-functional criteria exist, keep them visible as their own acceptance kind rather than burying them in functional prose.

## Phase 2 optimization notes
- Allow `business_critical` as an explicit acceptance kind when the stricter negative-case rule is needed.
- Keep `consumed_by_nodes[]`, `sibling_skills_affected[]`, and `refresh_effects[]` separate.

## Engineering source-of-truth
- Treat `MASTER.yaml` as the engineering source of truth for contract-bearing fields.
- Regenerate `references/output-template.md` and `references/workflow-v2-alignment.md` with `python3 scripts/generate_from_master.py --package-root .` after editing `MASTER.yaml` or `sources/*.md`.
- Keep sibling skill ids numeric in `sibling_skills_affected[]` and keep node consumers in `consumed_by_nodes[]`.


## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认。确认：
- artifact contract header 完整（artifact_type, schema_version, produced_event_name）
- gate_checks[] 已填写且无遗漏
- consumed_by_nodes[], sibling_skills_affected[], refresh_effects[] 已分离填写
- 按 `references/scoring-rubric.md` 做质量自评（0=blocked / 1=partial / 2=complete for mode）

## Key references
- `../031-handover-package-generation/handover-package-generation/references/node-guide.md`：**N110 节点导航——5 个 skill 执行顺序、readiness_score 公式速查（必读，见 031）**
- `../030-requirement-quality-review/requirement-quality-review/references/handoff-to-n110.md`：**N100→N110 节点交接协议——gate→mode 映射 + open_questions 继承（必读，见 030）**

- `references/ac-writing-guide.md`：**AC 完整性量化公式（100 - 缺失项扣分）+ AC 类型选择决策树 + 边界 case 表（必读）**
- `references/scoring-rubric.md`：输出质量评分（0=blocked / 1=partial / 2=complete for mode）
- `references/output-template.md`：artifact 输出结构
- `references/interoperability-contract.md`：N110 跨 skill 互操作契约
- `references/workflow-v2-alignment.md`：workflow v2 字段对齐
- `references/n110-artifact-registry.md`：N110 所有 artifact 注册表
- `references/refresh-matrix.md`：决定哪些 artifact 需要 refresh
