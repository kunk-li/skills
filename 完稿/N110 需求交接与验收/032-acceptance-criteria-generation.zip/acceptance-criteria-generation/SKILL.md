---
name: acceptance-criteria-generation
description: Turn requirement structure and business rules into a test-ready acceptance artifact: criterion patterns, negative cases, and machine-verifiable acceptance hooks (AH-) with check_method, target, and source.
---
# acceptance-criteria-generation

Create a workflow-v2-compatible N110 artifact that is independently usable and composable with sibling skills.

## Role / 角色定位
- Workflow stage: 协同交接
- Workflow node: N110
- Registry category: 协同交接
- Registry subcategory: 产品到测试
- Registry function: 验收统一
- Canonical output name: `验收标准.md`
- Primary goal: 生成功能、异常、权限、数据一致性验收清单

Follow both `references/interoperability-contract.md` and `references/workflow-v2-alignment.md` on every run. Reuse `references/n110-artifact-registry.md` when sibling artifacts already exist.

## Boundary rules / 边界规则
- Stay inside the total-table boundary for this skill.
- Accept standalone use in any requirement-to-execution scenario, but still emit an N110-compatible artifact contract so the output can be composed later.
- Do not silently expand into neighboring skills just because adjacent information is present.

## Operating contexts
- `standalone`: the user needs this skill's artifact even if sibling artifacts do not exist yet.
- `composed`: one or more sibling artifacts already exist and should be linked, refreshed, or inherited instead of re-derived.

## Execution modes
Choose exactly one:
- `seed_mode`: generate a safe starter set from a short requirement and rules.
- `refine_mode`: normalize or improve an existing acceptance set.
- `formal_mode`: full acceptance set with patterns, negatives, dependencies, and downstream hints.
- `blocked_mode`: explain what evidence is missing before meaningful acceptance criteria can be issued.

## Inputs / 允许输入
A standalone run may start from any one of:
- requirement structure or requirement notes
- business rules or equivalent policy notes
- reviewed requirement package or quality review

A composed run should also absorb these when available:
- handover artifact
- change impact artifact
- engineering feedback artifact
- readiness review artifact

## Output / 默认输出契约
Every non-blocked output must declare:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `contract_version`
- `canonical_output_name`
- `workflow_stage`
- `workflow_node`
- `gate_status`
- `gate_checks[]`
- `produced_event`
- `state_event`
- `exception_event`
- `sla_event`
- `priority`
- `sla_level`
- `auto_escalate_after`
- `routing_aliases[]`
- `consumed_by_nodes[]`
- `downstream_artifacts[]`
- `acceptance_hooks[]`  # G2 校准:红线项的可机械核对断言,见 §Verifiable acceptance hooks (AH-)

## Gate rules
Always perform these checks before finalizing the artifact:
- contract fields present
- canonical output name preserved
- required inputs either present or explicitly blocked
- boundary respected
- downstream consumability described
- this skill specific checks: criterion_pattern_selected, negative_cases_present, testability_tier_present, ac_kind_present, acyclic_dependencies_or_explained, **redline_criteria_have_verifiable_AH**(G2 校准:红线类验收项须有可机械核对 `AH-`)

When evidence is incomplete, use `passed_with_gaps`, `blocked`, or `refresh_required` instead of implying full readiness.

## Workflow-v2 behavior
- Use schema version `1.1.0` / contract version `1.1.0`(G2 校准:新增 `acceptance_hooks[]`;AH- 为附加字段,旧消费者按 1.0.0 兼容)。
- Preserve `revision_log[]` so downstream consumers can see what changed between iterations.
- Emit workflow-v2-compatible event names.
- Carry an explicit SLA policy even in standalone runs.
- Prefer stable ids and trace anchors over free-text references.

## Extra behavior for this skill
- Always list `downstream_test_consumers[]` so N230, N240, N260, and N290 can consume the artifact predictably.
- Keep functional and non-functional acceptance items separate when both exist.

## Verifiable acceptance hooks (AH-) / 可机械核对的验收断言(G2 校准 · 见平台 D-018/D-019)
验收标准若不可机械核对,就只能"读文档判过没过",无法对照 built 产品验证——这正是 spec↔reality 脱节(D-003)的根因。**优化**:**红线类**验收项(资金/安全/权限/不可逆操作)必须额外表达为 `AH-{module}-{nn}` 断言,每条含:
- `assertion`:**单条、可观测、可判真假**的陈述(例:`room.status=occupied 时"预订"按钮 disabled 且显示占用人`)。禁止"界面应友好"这类不可证伪句。
- `check_method`:`dom`(元素/状态)/ `behavior`(动作→响应)/ `api`(请求/响应)/ `state`(状态迁移)。
- `targets`:被核对的页面/组件/动作/端点(复用上游 ID)。
- `source`:背书断言的规则(business rule / constraint / 状态机边)。
- `confidence`:confirmed / stable_inference / needs_confirmation。
- `verify_locus`:`static_verifiable`(读代码 / 制品即可静态判定)/ `runtime_required`(必须运行系统或跑测试才能判定)。**与 `confidence` 正交**——confidence 说"这条红线断言对不对",verify_locus 说"用什么手段核它"。纯需求阶段(无运行环境)产出的 AH-,凡需运行才能判的一律标 `runtime_required`,不臆断运行结果(D-018)。
- `verified_in_module`:模块化系统里,断言实际由**哪个模块**实现 / 可核(可能 ≠ 声明它的需求所在模块),供下游路由到正确的核验位置。
- `ah_kind`:`spec_conformance`(核实现是否**符合**该断言——默认)/ `defect_probe`(断言描述一个**已知缺陷**,核它**真不真存在**——代码在、行为是 bug)/ `unimplemented_redline`(红线**根本没代码**可核 = backlog 缺口,非"不符合")。**与 confidence/verify_locus 正交**,让下游 `093` 区分三种核法:conformance 比对、defect 复现、unimplemented 标缺口而非当 fail(实测某真实资金模块:崩溃漏记=defect_probe、预算超限拦=unimplemented_redline、混币种拒=spec_conformance,三者混在 confidence 里会误导门禁)。

**为什么**:① 让下游 built-vs-spec 核对(N260 `093` 的 `built_vs_spec` 维度)能逐条对照真实代码/运行——`verify_locus` 进一步告诉门禁哪些 AH- 现在就能对静态代码机械核(`static_verifiable`)、哪些必须留到运行/测试阶段(`runtime_required`),`verified_in_module` 告诉它去哪个模块核;② 确认后**沉淀成确定性测试/lint**(实测:某真实全栈项目用 14 个集成测试覆盖对账/退款/落库——D-018)。
**纪律**:`AH-` 是验收标准的"可执行投影",不替代验收标准本身;不可机械核对的项保留为普通 AC 并标注;**运行时/并发类断言交执行端验,生成时标 `needs_confirmation`,不臆断运行时结果**(D-018 教训)。

## Workflow / 执行流程
1. Determine whether the request is standalone or composed.
2. Select the execution mode that fits the available evidence.
3. Load the workflow alignment and artifact registry references.
4. Produce the artifact using `references/output-template.md`.
5. Fill gate, event, SLA, and downstream-consumption sections before finalizing.
6. End with `next_skill_hints[]`, `refresh_triggers[]`, and `revision_log[]`.

## Required behavior
- Prefer compact structured sections over long prose.
- Distinguish `confirmed`, `inferred`, and `blocked` content.
- Do not fabricate missing upstream decisions.
- Do not upgrade inherited readiness.
- Reuse existing ids whenever sibling artifacts are available.
- For business, security, and compliance criteria, require at least two negative cases unless the artifact explicitly explains why not.
- If non-functional criteria exist, keep them visible as their own acceptance kind rather than burying them in functional prose.

## Phase 2 optimization notes
- Allow `business_critical` as an explicit acceptance kind when the stricter negative-case rule is needed.
- Keep `consumed_by_nodes[]`, `sibling_skills_affected[]`, and `refresh_effects[]` separate.

## Engineering source-of-truth
- Treat `MASTER.yaml` as the engineering source of truth for contract-bearing fields.
- Regenerate `references/output-template.md` and `references/workflow-v2-alignment.md` with `python3 scripts/generate_from_master.py --package-root .` after editing `MASTER.yaml` or `sources/*.md`.
- Keep sibling skill ids numeric in `sibling_skills_affected[]` and keep node consumers in `consumed_by_nodes[]`.
- **G2 校准(2026-06-02)**:`acceptance_hooks[]`(AH-)已加入;打包时须把该字段 + §Verifiable acceptance hooks 同步进 `MASTER.yaml` 并重生成 `output-template.md`(schema/contract → 1.1.0)。
- **brownfield 校准(2026-06-09)**:AH- 增 `verify_locus`(static_verifiable / runtime_required)+ `verified_in_module`;打包时一并同步进 `MASTER.yaml`。


## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认。确认：
- artifact contract header 完整（artifact_type, schema_version, produced_event_name）
- gate_checks[] 已填写且无遗漏
- consumed_by_nodes[], sibling_skills_affected[], refresh_effects[] 已分离填写
- 按 `references/scoring-rubric.md` 做质量自评（0=blocked / 1=partial / 2=complete for mode）

## Key references
- `../031-handover-package-generation/handover-package-generation/references/node-guide.md`：**N110 节点导航——5 个 skill 执行顺序、readiness_score 公式速查（必读，见 031）**
- `../030-requirement-quality-review/requirement-quality-review/references/handoff-to-n110.md`：**N100→N110 节点交接协议——gate→mode 映射 + open_questions 继承（必读，见 030）**

- `references/ac-writing-guide.md`：**AC 完整性量化公式（100 - 缺失项扣分）+ AC 类型选择决策树 + 边界 case 表（必读）**
- `references/scoring-rubric.md`：输出质量评分（0=blocked / 1=partial / 2=complete for mode）
- `references/output-template.md`：artifact 输出结构
- `references/interoperability-contract.md`：N110 跨 skill 互操作契约
- `references/workflow-v2-alignment.md`：workflow v2 字段对齐
- `references/n110-artifact-registry.md`：N110 所有 artifact 注册表
- `references/refresh-matrix.md`：决定哪些 artifact 需要 refresh
