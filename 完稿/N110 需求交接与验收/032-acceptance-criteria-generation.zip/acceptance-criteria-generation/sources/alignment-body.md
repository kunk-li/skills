## Acceptance-specific behavior
- keep `business_critical` explicit when the rule set depends on higher negative coverage
- declare downstream test consumers clearly so N230, N240, N260, and N290 can consume the artifact without guesswork
