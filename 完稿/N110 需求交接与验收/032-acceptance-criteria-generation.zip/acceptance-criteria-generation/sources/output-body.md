## 3. Acceptance summary
- requirement_refs:
- ac_count:
- completion_status:
- downstream_test_consumers:
- revision_log:

## 4. Acceptance criteria set
- business_critical:
- negative_cases:
- testability_tier:
- traceability_links:

## 5. Refresh notes
- accepted_feedback_impacts:
- change_delta_scope:
- next_skill_hints:
