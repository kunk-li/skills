# Role Model

Use one normalized role model across the five N110 skills.

## Core view roles
- architect
- developer
- tester
- dba
- devops
- compliance

## Workflow roles
- architect
- developer
- tester
- dba
- devops
- compliance
- pm

## Alias mapping
| Incoming role | Normalized role |
|---|---|
| pm | developer |
| external_team | developer |
| external | developer |
| business | developer |
| qa | tester |
| ops | devops |
| sre | devops |
| security | compliance |

Always persist `normalized_role` when feedback, acknowledgement, or change-linked records enter shared state.
