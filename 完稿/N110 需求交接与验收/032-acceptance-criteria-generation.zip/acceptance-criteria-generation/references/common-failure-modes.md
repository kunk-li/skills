# Common Failure Modes

## Overstating readiness
Problem: the output implies execution, rollout, or formal handoff even though the inherited readiness is constrained or blocked.
Fix: restate the inherited readiness, downgrade the mode, and move any speculative action into blocked scope or next-step guidance.

## Fabricated specifics
Problem: invented actors, permissions, error responses, dates, owners, or changed scope.
Fix: remove fabricated details and replace them with an explicit missing-evidence note.

## Mixed fact and interpretation
Problem: confirmed evidence and product-side inference are blended together.
Fix: separate confirmed facts, inferred framing, and unresolved decisions into distinct sections.

## Missing trace anchors
Problem: important conclusions are not linked to upstream issue ids, PRD sections, or named artifacts.
Fix: add trace anchors for every blocker, prerequisite, and major recommendation.

## Pseudo-completeness
Problem: the output contains all headings but several sections are empty or generic.
Fix: collapse thin sections, mark them partial, and say exactly which artifact or decision is missing.

## D6 boundary mixing
Problem: node ids, sibling skill names, and free-text refresh explanations are mixed into one field.
Fix: keep them separated as `consumed_by_nodes[]`, `sibling_skills_affected[]`, and `refresh_effects[]`.

## Unnormalized roles
Problem: alias roles such as `qa`, `ops`, or `security` are written directly into shared state.
Fix: normalize roles first and store only `normalized_role` in shared state.
