<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Output Template

# 验收标准.md

## 0. Artifact contract
- artifact_id:
- artifact_type: n110.acceptance-criteria
- schema_version: 1.1.0
- contract_version: 1.1.0
- canonical_output_name: 验收标准.md
- skill_id: 032
- skill_name: acceptance-criteria-generation
- workflow_node: N110
- package_version: 3.0.0
- engineering_release: r4-v3
- operating_context: standalone / composed
- execution_mode: seed_mode / refine_mode / formal_mode / blocked_mode
- generated_at:
- consumed_by_nodes: [N230, N240, N260, N290]
- sibling_skills_affected: []
- refresh_effects:
  - refresh on approved change or accepted feedback that changes testable scope
  - keep downstream test consumers explicitly declared
- downstream_artifacts: [测试点清单.csv, 测试用例集.xlsx, 回归测试清单.csv, 上线验收记录.md]
- shared_state_reads: [handover_packages, changes, feedbacks, decision_registry]
- shared_state_writes: [acceptance_criteria, artifact_index, trace_index]

## 1. Gate and readiness
- gate_status: passed / passed_with_gaps / blocked / refresh_required
- gate_checks: [contract_fields_present, canonical_output_name_preserved, boundary_respected, downstream_consumability_declared, sibling_boundary_clean]
- confidence:
- readiness_note:
- blocker_ids:

## 2. Event and SLA
- produced_event: produced.n110.acceptance-criteria.v1
- state_event: state.n110.acceptance-criteria.v1
- exception_event: exception.n110.acceptance-criteria.v1
- sla_event: sla.n110.acceptance-criteria.v1
- recommended_subscribers: [N230, N240, N260, N330, N340, N350, N390]
- priority: P0
- sla_level: P0
- auto_escalate_after: 4h
- escalation_target: qa_or_requirement_owner
- circuit_breaker_state:

## 3. Acceptance summary
- requirement_refs:
- ac_count:
- completion_status:
- downstream_test_consumers:
- revision_log:

## 4. Acceptance criteria set
- business_critical:
- negative_cases:
- testability_tier:
- traceability_links:

## 5. Refresh notes
- accepted_feedback_impacts:
- change_delta_scope:
- next_skill_hints:
