# Interoperability Contract

Use this contract whenever the skill runs alone or with sibling skills.

## Universal artifact header
Every output should begin with a compact header or metadata block containing:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `contract_version`
- `canonical_output_name`
- `skill_name`
- `workflow_stage`
- `workflow_node`
- `registry_category`
- `registry_subcategory`
- `operating_context`
- `execution_mode`
- `generated_at`
- `source_artifacts[]`
- `related_artifacts[]`
- `trace_anchors[]`
- `routing_aliases[]`
- `consumed_by_nodes[]`
- `sibling_skills_affected[]`
- `refresh_effects[]`
- `downstream_artifacts[]`
- `shared_state_reads[]`
- `shared_state_writes[]`

## Boundary rules
- `consumed_by_nodes[]` may contain node ids only.
- `sibling_skills_affected[]` may contain sibling skill names only.
- `refresh_effects[]` is the only place for free-text refresh explanations.
- Role aliases must be normalized using `references/role-model.md` before shared-state write-back.

## Gate and readiness envelope
Every output should also declare:
- `gate_status`: `passed`, `passed_with_gaps`, `blocked`, or `refresh_required`
- `gate_checks[]`: exact checks this skill performed
- `inherited_gate`
- `inherited_readiness`
- `blocker_ids[]`
- `readiness_note`
- `confidence`

When no readiness artifact exists, write `readiness_note: provisional because no upstream readiness artifact was supplied`.
Compute confidence using `references/confidence-computation.md`.

## Event contract
When the artifact is not blocked, declare:
- `produced_event`
- `state_event`
- `exception_event`
- `sla_event`
- `recommended_subscribers[]`

Use workflow-v2-compatible event names in the shape `produced.n110.<artifact>.v1`, `state.n110.<artifact>.v1`, `exception.n110.<artifact>.v1`, and `sla.n110.<artifact>.v1`.

## SLA and circuit-breaker contract
Every output should declare:
- `priority`
- `sla_level`
- `auto_escalate_after`
- `escalation_target`
- `recommended_action_if_sla_breaches`
- `circuit_breaker_state`

Apply `references/circuit-breaker.md` when refresh loops or repeated reruns appear.

## Composition signals
Every output should end with:
- `next_skill_hints[]`
- `open_questions[]`
- `revision_log[]`
- `refresh_triggers[]`

## Standalone rule
A standalone run must still produce a complete artifact for the current skill, even if some upstream or sibling artifacts are missing. Missing context should move into `open_questions[]`, `prerequisites`, or blocked sections, not into fabricated content.

## Composed rule
A composed run should reuse existing ids, anchors, and decisions instead of reinterpreting them. It should add only the minimum new structure needed for the current skill.
