# Confidence Computation

```yaml
confidence = 0.4 * input_completeness
           + 0.3 * inherited_readiness_weight
           + 0.3 * evidence_density
           - sum(blocker_penalty × 0.1)
clamp to [0, 1]

thresholds:
  >= 0.85: high
  0.60~0.85: medium
  < 0.60: low
```

Use the numeric score and its label together.
