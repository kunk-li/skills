# Mode Taxonomy

Use three buckets consistently:
- `generative`: create a fresh artifact
- `refresh`: update an existing artifact using shared state and sibling outputs
- `blocked`: explain why the artifact cannot be emitted safely

Never mix sibling skill identifiers into node-consumer fields.
