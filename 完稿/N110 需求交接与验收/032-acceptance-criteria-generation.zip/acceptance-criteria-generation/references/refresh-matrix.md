# Refresh Matrix

Use this matrix to decide whether a sibling skill should be refreshed, not regenerated blindly.

```yaml
refresh_matrix:
  - trigger: "feedback.state.decided AND decision.resolution == accepted"
    effects:
      - skill_id: '031'
        skill_name: handover-package-generation
        action: refresh_mode
        sla: 4h
        reason: accepted feedback changed handover assumptions
      - skill_id: '032'
        skill_name: acceptance-criteria-generation
        action: refine_mode
        sla: 4h
        reason: accepted feedback changed acceptance scope
      - skill_id: '033'
        skill_name: requirement-change-impact-analysis
        action: quick_impact
        sla: 1d
        reason: accepted feedback may alter impact radius
  - trigger: "change.state.approved"
    effects:
      - skill_id: '031'
        skill_name: handover-package-generation
        action: refresh_mode
        sla: 4h
        reason: approved delta requires a refreshed handover package
      - skill_id: '032'
        skill_name: acceptance-criteria-generation
        action: refine_mode
        sla: 4h
        reason: approved delta requires acceptance refresh
      - skill_id: '034'
        skill_name: requirement-change-sync
        action: final_sync_mode
        sla: 1d
        reason: approved delta requires audience sync
  - trigger: "handover.ack.stage_timeout"
    effects:
      - node: N350
        action: create_risk_item
        priority: P1_or_P0
      - node: N380
        action: human_confirmation_needed
        sla: 2d
  - trigger: "impact.criticality IN [major, mega]"
    effects:
      - skill_id: '034'
        skill_name: requirement-change-sync
        action: final_sync_mode
        mandatory: true
      - node: N370
        action: escalate_to_change_control_board
  - trigger: "circuit_breaker.tripped"
    effects:
      - node: N380
        action: human_takeover
        priority: P0
```

## Boundary rule
- `consumed_by_nodes[]` describes node consumers only.
- `sibling_skills_affected[]` describes sibling skill ids only.
- `refresh_effects[]` explains why a sibling refresh exists.
Never mix the three in one field.
