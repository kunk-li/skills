# Checklist

Use this checklist before finalizing the skill output.

## Readiness and source control
- [ ] Imported readiness, gate, and blocker ids from `requirement-quality-review` when available.
- [ ] Stated clearly when readiness is provisional because the upstream review is missing.
- [ ] Did not create a stronger readiness verdict than the inherited one.

## Evidence quality
- [ ] Every major section is backed by explicit facts, rules, states, roles, or decisions.
- [ ] Empty sections were replaced with a bounded note such as `Insufficient evidence` or `No evidence-backed checks available yet.`
- [ ] Placeholder phrases were not used as if they were real content.

## Traceability
- [ ] Referenced upstream ids, PRD sections, GAP ids, question ids, or baseline anchors when they explain scope.
- [ ] Kept section labels stable so sibling skills or downstream work can cite them.

## Output fitness
- [ ] Chosen mode matches both the inherited readiness and the evidence actually available.
- [ ] Blocked scope is explicitly separated from usable scope.
- [ ] Final verdict or completion label does not exceed the inherited readiness.

## Cross-skill hygiene
- [ ] `consumed_by_nodes[]` contains node ids only.
- [ ] `sibling_skills_affected[]` contains sibling skill names only.
- [ ] `refresh_effects[]` carries prose and is not mixed into consumer lists.
- [ ] Registry, output template, and MASTER contract agree on the same downstream boundary.
- [ ] Role aliases are normalized before shared-state write-back.

## Engineering generation hygiene
- Regenerate contract-bearing references from `MASTER.yaml` before packaging.
- Confirm `generated/build-manifest.json` exists and reflects the current package contents.
- Confirm `sibling_skills_affected[]` uses numeric skill ids only.
