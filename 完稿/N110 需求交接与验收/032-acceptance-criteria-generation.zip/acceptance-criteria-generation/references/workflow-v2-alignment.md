<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Workflow-v2 Alignment

## Identity
- skill_id: 032
- skill_name: acceptance-criteria-generation
- workflow_node: N110
- engineering_release: r4-v3

## Downstream contract
- consumed_by_nodes: [N230, N240, N260, N290]
- sibling_skills_affected: []
- refresh_effects:
  - refresh on approved change or accepted feedback that changes testable scope
  - keep downstream test consumers explicitly declared

## Event contract
- produced_event: produced.n110.acceptance-criteria.v1
- state_event: state.n110.acceptance-criteria.v1
- exception_event: exception.n110.acceptance-criteria.v1
- sla_event: sla.n110.acceptance-criteria.v1
- recommended_subscribers: [N230, N240, N260, N330, N340, N350, N390]

## Shared state contract
- reads: [handover_packages, changes, feedbacks, decision_registry]
- writes: [acceptance_criteria, artifact_index, trace_index]
- join_keys: [artifact_id, normalized_role, change_id]

## Source-of-truth references
- interoperability_contract: references/interoperability-contract.md
- workflow_alignment: references/workflow-v2-alignment.md
- artifact_registry: references/n110-artifact-registry.md
- refresh_matrix: references/refresh-matrix.md

## Acceptance-specific behavior
- keep `business_critical` explicit when the rule set depends on higher negative coverage
- declare downstream test consumers clearly so N230, N240, N260, and N290 can consume the artifact without guesswork
