# Shared State Schema

Use a single optional state file named `change_management_db.json`.

Required top-level arrays:
- `changes[]`
- `acknowledgements[]`
- `feedbacks[]`
- `sync_logs[]`
- `handover_packages[]`
- `acceptance_criteria[]`
- `impact_analyses[]`
- `decision_registry[]`
- `trace_index[]`
- `artifact_index[]`

Shared join keys:
- `artifact_id`
- `change_id`
- `normalized_role`
