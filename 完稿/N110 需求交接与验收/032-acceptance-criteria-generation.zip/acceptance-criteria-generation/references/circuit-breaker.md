# Circuit Breaker

Use these defaults whenever repeated refreshes or regeneration loops appear.

```yaml
max_refresh: 3
current_refresh_count: 0
cooldown: 30m
escalation_after_max_refresh: escalate_to_pm_and_halt
```

When the breaker trips:
- emit `gate_status: blocked`
- emit an `sla_event` with priority `P0`
- stop auto-refresh until a human re-opens the flow
