# Example I/O

This file shows the minimum shape of a valid run.

## Example input
- PRD section: order approval requires requester, approver, and finance review above a threshold.
- State baseline: `draft -> pending_manager -> pending_finance -> approved`.
- Permission baseline: requester may edit only in `draft`; finance may approve only above threshold.
- Readiness review: `test_prep_with_constraints`, blocker `ACC-003` for missing rejection copy.

## Example output expectation
- The output should inherit `test_prep_with_constraints`.
- It should produce the skill-specific formal or constrained artifact without inventing missing copy.
- Any missing rejection path details should be listed as blocked scope or prerequisites, not silently filled in.
