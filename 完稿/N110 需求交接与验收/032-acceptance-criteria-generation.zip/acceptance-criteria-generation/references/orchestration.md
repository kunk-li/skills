# Orchestration

Use this sequence when the N110 package is being produced as a set:

1. Read or import N100 `requirement-quality-review` first.
2. Build or refresh `handover-package-generation` for the current baseline.
3. Generate or refresh `acceptance-criteria-generation` for the evidence-backed scope.
4. If an explicit delta exists, run `requirement-change-impact-analysis`.
5. If the delta is confirmed and audience scope is known, run `requirement-change-sync`.
6. When engineering comments arrive, run `engineering-feedback-return` and feed approved decisions back into the change or handoff artifacts.

## Refresh-aware shared contract
- Reuse the same issue ids, blocker ids, PRD anchors, and section names across all sibling outputs.
- Do not let any downstream skill silently override the inherited readiness.
- When two sibling outputs disagree, prefer the stronger evidence source and call out the mismatch explicitly.
- Use `references/refresh-matrix.md` to decide refresh, not free-text intuition.
- Keep node consumers, sibling impacts, and refresh explanations in separate fields.
