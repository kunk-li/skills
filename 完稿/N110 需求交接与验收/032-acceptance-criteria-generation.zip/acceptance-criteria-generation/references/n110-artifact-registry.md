# N110 Artifact Registry

Use this registry when composing the five N110 skills. The registry keeps each skill independently usable while preserving a stable shared contract.

## Shared state object
When cross-skill state is available, prefer a single optional file named `change_management_db.json` with these top-level keys:
- `changes[]`
- `acknowledgements[]`
- `feedbacks[]`
- `sync_logs[]`
- `handover_packages[]`
- `acceptance_criteria[]`
- `impact_analyses[]`
- `decision_registry[]`
- `trace_index[]`
- `artifact_index[]`

A skill must not require the shared state file in order to run. When it exists, reuse ids from it instead of minting conflicting new ids.

## N110 output set
| Skill ID | Skill | Output | Artifact type | Consumed by nodes | Sibling skills affected | Refresh effects |
|---|---|---|---|---|---|---|
| 031 | handover-package-generation | 需求交接包.zip | n110.handover-package | N120, N350, N360 | — | acts as the node aggregation owner for N110 handover outputs; refresh when approved change, accepted feedback, or stale snapshot invalidates the package |
| 032 | acceptance-criteria-generation | 验收标准.md | n110.acceptance-criteria | N230, N240, N260, N290 | — | refresh on approved change or accepted feedback that changes testable scope; keep downstream test consumers explicitly declared |
| 033 | requirement-change-impact-analysis | 需求变更影响分析.md | n110.requirement-change-impact | N350, N360 | 034 | major or mega impact makes 034 final_sync_mode mandatory; approved impact may trigger sync regeneration and downstream risk updates |
| 034 | requirement-change-sync | 需求变更同步通知.md + 需求变更同步计划.yaml | n110.requirement-change-sync | N270, N280, N290, N300, N350, N360 | — | execution-surface downstream artifact with no sibling refresh ownership; when change impact is major or mega, final_sync_mode becomes mandatory |
| 035 | engineering-feedback-return | 研发反馈回传单.md | n110.engineering-feedback-return | N110, N340, N360 | 031, 032, 033 | accepted feedback may trigger 031, 032, and 033 refresh per refresh matrix; write normalized_role before storing or forwarding feedback records |

## Shared id conventions
- handover items: `HO-*`
- acceptance criteria: `AC-*`
- changes: `CHG-*`
- sync items: `SYNC-*`
- feedback items: `FB-*`
- requirements: `REQ-*`
- rules: `RULE-*`
- decisions: `DEC-*`
