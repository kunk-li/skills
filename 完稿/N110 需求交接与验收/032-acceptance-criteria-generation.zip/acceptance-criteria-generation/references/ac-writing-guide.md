# Acceptance Criteria Writing Guide

Use this guide when the source evidence is strong enough to write testable criteria.

## Default structure
Prefer a compact form with these fields:
- actor
- precondition, when known
- trigger
- expected result
- failure or denial result, when explicitly specified
- evidence anchor

## Given / When / Then usage
Use Given / When / Then only when the evidence supports all three parts.

Example:
- Given the request amount is above the finance threshold
- When the finance approver rejects the request
- Then the request returns to `draft` and records the rejection reason

If any part is unknown, do not guess. Use a tabular criterion and move the missing element into prerequisites.

## Avoid
- vague steps like `system behaves correctly`
- fake error messages or codes
- missing actor ownership
- unnamed source or target states
