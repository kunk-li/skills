# Acceptance Criteria Writing Guide

Use this guide when the source evidence is strong enough to write testable criteria.

## Default structure
Prefer a compact form with these fields:
- actor
- precondition, when known
- trigger
- expected result
- failure or denial result, when explicitly specified
- evidence anchor

## Given / When / Then usage
Use Given / When / Then only when the evidence supports all three parts.

Example:
- Given the request amount is above the finance threshold
- When the finance approver rejects the request
- Then the request returns to `draft` and records the rejection reason

If any part is unknown, do not guess. Use a tabular criterion and move the missing element into prerequisites.

## Avoid
- vague steps like `system behaves correctly`
- fake error messages or codes
- missing actor ownership
- unnamed source or target states

---

## AC 完整性量化评分 / AC Completeness Scoring

### 量化公式

```
ac_completeness_score = 100 - (
  missing_actor × 15 +          # AC 无明确主体
  missing_trigger × 10 +        # AC 无明确触发条件
  missing_outcome × 20 +        # AC 无可验证的预期结果
  vague_outcome × 10 +          # 结果描述为"正确""成功"等无法验证的词汇
  missing_failure_case × 8 +    # 失败/拒绝路径未覆盖（当明显有失败路径时）
  no_evidence_anchor × 5        # 无溯源到 PRD-XX 或 REQ-* 的锚点
)
clip to [0, 100]
```

| ac_completeness_score | 等级 | 含义 |
|---:|---|---|
| ≥ 90 | excellent | 可直接用于 QA 测试用例设计 |
| 70–89 | usable | 可用但需补充细节 |
| 50–69 | needs_action | 关键信息缺失，需补全后才可用 |
| < 50 | blocked | 无法基于此 AC 进行测试 |

### AC 类型选择决策树

```
Q1: 是否能明确写出"Given（前提）、When（触发）、Then（结果）"三部分？
    YES（三部分都有证据支撑）→ 使用 Given/When/Then 格式
    NO（任一部分不确定）→ Q2

Q2: 能否明确写出 actor（主体）和 expected_result（预期结果）？
    YES → 使用紧凑格式（actor + trigger + expected_result）
    NO  → 不应强制写 AC；记录为 missing_acceptance_criteria gap

Q3: 是否需要覆盖失败/拒绝路径？
    YES（当条件不满足时有明确的拒绝行为）→ 添加 failure_or_denial_result 字段
    NO（操作无失败路径）→ 可省略
```

### 边界 Case 对照表

| 场景 | 正确处理 | 常见误判 |
|---|---|---|
| "系统响应时间 < 200ms" | AC 条目，类型=nfr，测量方式需明确 | 不写 AC，视为非功能不可测 |
| "管理员可以删除用户" | 需补充：删除后数据状态 + 是否通知用户 | 只写权限，不写结果状态 |
| 状态机转移（approved→processing） | AC 覆盖触发条件 + 转移后状态 + 禁止的反向转移 | 只写"审批通过进入处理中" |
| 计算类功能（总价=数量×单价） | AC 包含边界值（数量=0、负数、最大值） | 只验证正常路径 |
| 异步操作（发送邮件） | AC 分拆：触发异步任务（同步）+ 邮件发送成功（异步，需等待）| 合并为一条 AC |
