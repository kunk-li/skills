# Versioning Policy

Use semantic versioning at two layers:
- `schema_version`: output shape changes
- `contract_version`: downstream interaction changes

Rules:
- patch: examples, prose, comments
- minor: additive backward-compatible fields
- major: renamed fields, removed fields, or semantic shifts

Shared contract artifacts should evolve together. Individual skill schemas may evolve independently if they remain compatible with the shared contract and shared state schema.
