# Master Schema Specification

`MASTER.yaml` is the engineering source of truth for each skill.

Minimum top-level sections:
- `identity`
- `purpose`
- `boundary`
- `operating_contexts`
- `execution_modes`
- `input_schema`
- `output_contract`
- `gate_checks`
- `event_contract`
- `sla_contract`
- `downstream_contract`
- `shared_state_contract`
- `references`
- `validation`

Regenerate contract-bearing references from `MASTER.yaml` after edits.
