# Scoring Rubric

Use this rubric to judge whether the output is complete enough for the selected mode.

## 0 - blocked
- Required input for the chosen mode is missing.
- Readiness or gate prevents the requested output.
- Major sections would be mostly empty without fabrication.

## 1 - partial
- Some sections are usable, but blockers, missing decisions, or missing artifacts still constrain the output.
- The result is safe to share only as a bounded working draft or prerequisite note.
- Cross-skill boundaries are declared but one or more refresh or sibling links remain provisional.

## 2 - complete for mode
- All required sections for the selected mode are populated with evidence-backed content.
- Trace anchors and blocker ids are present where needed.
- Final verdict or completion label is consistent with the inherited readiness.
- `consumed_by_nodes[]`, `sibling_skills_affected[]`, and `refresh_effects[]` are cleanly separated.
