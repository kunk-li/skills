#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import yaml

AUTO = '<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->'


def read(path: Path) -> str:
    return path.read_text(encoding='utf-8') if path.exists() else ''


def yaml_list(values):
    if not values:
        return '[]'
    return '[' + ', '.join(str(v) for v in values) + ']'


def render_output_template(master: dict, output_body: str) -> str:
    ident = master['identity']
    out = master['output_contract']
    down = master['downstream_contract']
    event = master['event_contract']
    sla = master['sla_contract']
    shared = master['shared_state_contract']
    text = f"""{AUTO}
# Output Template

# {out['canonical_output_name']}

## 0. Artifact contract
- artifact_id:
- artifact_type: {out['artifact_type']}
- schema_version: {out['schema_version']}
- contract_version: {out['contract_version']}
- canonical_output_name: {out['canonical_output_name']}
- skill_id: {ident['skill_id']}
- skill_name: {ident['name']}
- workflow_node: {ident['workflow_node']}
- package_version: {ident['version']}
- engineering_release: {master.get('engineering_release', {}).get('suite_release', 'r4-v3')}
- operating_context: {' / '.join(master['operating_contexts'])}
- execution_mode: {' / '.join(master['execution_modes'])}
- generated_at:
- consumed_by_nodes: {yaml_list(down['consumed_by_nodes'])}
- sibling_skills_affected: {yaml_list(down['sibling_skills_affected'])}
- refresh_effects:
"""
    for item in down['refresh_effects']:
        text += f"  - {item}\n"
    text += f"""- downstream_artifacts: {yaml_list(down.get('downstream_artifacts', []))}
- shared_state_reads: {yaml_list(shared.get('reads', []))}
- shared_state_writes: {yaml_list(shared.get('writes', []))}

## 1. Gate and readiness
- gate_status: passed / passed_with_gaps / blocked / refresh_required
- gate_checks: {yaml_list(master['gate_checks'])}
- confidence:
- readiness_note:
- blocker_ids:

## 2. Event and SLA
- produced_event: {event['produced_event']}
- state_event: {event['state_event']}
- exception_event: {event['exception_event']}
- sla_event: {event['sla_event']}
- recommended_subscribers: {yaml_list(event['recommended_subscribers'])}
- priority: {sla['priority']}
- sla_level: {sla['sla_level']}
- auto_escalate_after: {sla['auto_escalate_after']}
- escalation_target: {sla['escalation_target']}
- circuit_breaker_state:

"""
    text += output_body.strip() + '\n'
    return text


def render_alignment(master: dict, alignment_body: str) -> str:
    ident = master['identity']
    down = master['downstream_contract']
    event = master['event_contract']
    shared = master['shared_state_contract']
    refs = master['references']
    text = f"""{AUTO}
# Workflow-v2 Alignment

## Identity
- skill_id: {ident['skill_id']}
- skill_name: {ident['name']}
- workflow_node: {ident['workflow_node']}
- engineering_release: {master.get('engineering_release', {}).get('suite_release', 'r4-v3')}

## Downstream contract
- consumed_by_nodes: {yaml_list(down['consumed_by_nodes'])}
- sibling_skills_affected: {yaml_list(down['sibling_skills_affected'])}
- refresh_effects:
"""
    for item in down['refresh_effects']:
        text += f"  - {item}\n"
    text += f"""
## Event contract
- produced_event: {event['produced_event']}
- state_event: {event['state_event']}
- exception_event: {event['exception_event']}
- sla_event: {event['sla_event']}
- recommended_subscribers: {yaml_list(event['recommended_subscribers'])}

## Shared state contract
- reads: {yaml_list(shared.get('reads', []))}
- writes: {yaml_list(shared.get('writes', []))}
- join_keys: {yaml_list(shared.get('join_keys', []))}

## Source-of-truth references
- interoperability_contract: {refs['interoperability_contract']}
- workflow_alignment: {refs['workflow_alignment']}
- artifact_registry: {refs['artifact_registry']}
- refresh_matrix: {refs['refresh_matrix']}

"""
    text += alignment_body.strip() + '\n'
    return text


def main() -> int:
    parser = argparse.ArgumentParser(description='Generate contract-bearing references from MASTER.yaml')
    parser.add_argument('--package-root', default='.', help='skill package root')
    args = parser.parse_args()
    root = Path(args.package_root).resolve()
    master = yaml.safe_load((root / 'MASTER.yaml').read_text(encoding='utf-8'))
    output_body = read(root / 'sources' / 'output-body.md')
    alignment_body = read(root / 'sources' / 'alignment-body.md')
    out_text = render_output_template(master, output_body)
    align_text = render_alignment(master, alignment_body)
    (root / 'references' / 'output-template.md').write_text(out_text, encoding='utf-8')
    (root / 'references' / 'workflow-v2-alignment.md').write_text(align_text, encoding='utf-8')
    generated = root / 'generated'
    generated.mkdir(exist_ok=True)
    manifest = {
        'skill_id': master['identity']['skill_id'],
        'skill_name': master['identity']['name'],
        'generated_files': {
            'references/output-template.md': hashlib.md5(out_text.encode('utf-8')).hexdigest(),
            'references/workflow-v2-alignment.md': hashlib.md5(align_text.encode('utf-8')).hexdigest(),
        },
    }
    (generated / 'build-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'ok': True, 'manifest': manifest}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
