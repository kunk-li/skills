#!/usr/bin/env python3
from __future__ import annotations

import argparse, hashlib, json, re
from pathlib import Path
import yaml

NODE_RE = re.compile(r'^N\d{3}$')
SKILL_ID_RE = re.compile(r'^\d{3}$')
REQUIRED_SHARED_REFERENCES = [
    'references/role-model.md',
    'references/circuit-breaker.md',
    'references/confidence-computation.md',
    'references/refresh-matrix.md',
    'references/versioning-policy.md',
    'references/shared-state-schema.md',
    'references/end-to-end-examples.md',
    'references/mode-taxonomy.md',
    'references/master-schema-specification.md',
    'references/interoperability-contract.md',
    'references/n110-artifact-registry.md',
    'references/workflow-v2-alignment.md',
    'references/output-template.md',
    'references/checklist.md',
]


def load_master(root: Path) -> dict:
    return yaml.safe_load((root / 'MASTER.yaml').read_text(encoding='utf-8'))


def validate_package(root: Path) -> list[str]:
    errors: list[str] = []
    if not (root / 'SKILL.md').exists():
        errors.append('missing SKILL.md')
    if not (root / 'agents' / 'openai.yaml').exists():
        errors.append('missing agents/openai.yaml')
    if not (root / 'MASTER.yaml').exists():
        errors.append('missing MASTER.yaml')
    if not (root / 'scripts' / 'generate_from_master.py').exists():
        errors.append('missing scripts/generate_from_master.py')
    if not (root / 'generated' / 'build-manifest.json').exists():
        errors.append('missing generated/build-manifest.json; run generate_from_master.py')
    for rel in REQUIRED_SHARED_REFERENCES:
        if not (root / rel).exists():
            errors.append(f'missing {rel}')
    if root.name == 'requirement-change-sync' and not (root / 'references' / 'output-template-plan.md').exists():
        errors.append('requirement-change-sync missing companion plan template')

    master = load_master(root)
    down = master.get('downstream_contract', {})
    for node in down.get('consumed_by_nodes', []):
        if not NODE_RE.match(str(node)):
            errors.append(f'consumed_by_nodes contains non-node id: {node}')
    for sid in down.get('sibling_skills_affected', []):
        if not SKILL_ID_RE.match(str(sid)):
            errors.append(f'sibling_skills_affected contains non-skill-id: {sid}')

    template = (root / 'references' / 'output-template.md').read_text(encoding='utf-8')
    for marker in ('consumed_by_nodes:', 'sibling_skills_affected:', 'refresh_effects:'):
        if marker not in template:
            errors.append(f'output-template missing {marker}')
    if re.search(r'sibling_skills_affected:\s*\[[^\]]*(handover-package-generation|acceptance-criteria-generation|requirement-change-impact-analysis|requirement-change-sync|engineering-feedback-return)', template):
        errors.append('output-template uses skill names instead of skill ids in sibling_skills_affected')

    registry = (root / 'references' / 'n110-artifact-registry.md').read_text(encoding='utf-8')
    if 'Consumed by nodes' not in registry or 'Sibling skills affected' not in registry or 'Refresh effects' not in registry:
        errors.append('registry missing structured downstream columns')
    if 'requirement-change-sync' in registry and '| 033 |' not in registry and 'Sibling skills affected' in registry:
        pass

    checklist = (root / 'references' / 'checklist.md').read_text(encoding='utf-8')
    if '## Cross-skill hygiene' not in checklist:
        errors.append('checklist missing Cross-skill hygiene section')

    return errors


def validate_artifact(root: Path, artifact_path: Path) -> list[str]:
    errors: list[str] = []
    master = load_master(root)
    required_markers = master.get('validation', {}).get('required_template_markers', [])
    text = artifact_path.read_text(encoding='utf-8')
    for marker in required_markers:
        if marker not in text:
            errors.append(f'artifact missing required marker: {marker}')
    if re.search(r'consumed_by_nodes:\s*\[[^\]]*(handover-package-generation|acceptance-criteria-generation|requirement-change-impact-analysis|requirement-change-sync|engineering-feedback-return)', text):
        errors.append('consumed_by_nodes mixes skill names into node list')
    if re.search(r'sibling_skills_affected:\s*\[[^\]]*(handover-package-generation|acceptance-criteria-generation|requirement-change-impact-analysis|requirement-change-sync|engineering-feedback-return)', text):
        errors.append('sibling_skills_affected mixes skill names into sibling skill ids')
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description='Validate the N110 engineering package and optionally a generated artifact.')
    parser.add_argument('artifact', nargs='?', help='optional artifact file to validate')
    parser.add_argument('--package-root', default='.', help='skill package root')
    parser.add_argument('--report', help='write a json report to this path')
    args = parser.parse_args()

    root = Path(args.package_root).resolve()
    errors = validate_package(root)
    if args.artifact:
        errors.extend(validate_artifact(root, Path(args.artifact).resolve()))
    report = {'ok': not errors, 'errors': errors}
    if args.report:
        Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == '__main__':
    raise SystemExit(main())
