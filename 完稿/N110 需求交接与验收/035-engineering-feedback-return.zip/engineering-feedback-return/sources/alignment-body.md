## Feedback-specific behavior
- always normalize incoming roles before writing feedback into shared state
- preserve the 9-state lifecycle explicitly when feedback progresses
- use sibling refresh hints only for 031, 032, and 033 when feedback is accepted
