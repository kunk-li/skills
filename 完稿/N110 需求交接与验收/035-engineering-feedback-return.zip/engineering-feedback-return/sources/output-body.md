## 3. Feedback intake
- feedback_batch_id:
- normalized_role:
- state_machine_reference:
- closure_status:
- accepted_feedback_refresh_candidates:

## 4. Feedback records
- feedback_items:
- mandatory_prompt_completion:
- deduplication_summary:
- revision_log:

## 5. Refresh notes
- accepted_feedback_impacts:
- next_skill_hints:
