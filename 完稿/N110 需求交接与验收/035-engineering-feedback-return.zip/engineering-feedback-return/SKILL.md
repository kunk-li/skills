---
name: engineering-feedback-return
description: Turn developer, architect, QA, or delivery feedback into a product-facing artifact about technical limits, effort, timing risk, objections, and scope tradeoffs, with closure states.
---
# engineering-feedback-return

Create a workflow-v2-compatible N110 artifact that is independently usable and composable with sibling skills.

## Role / 角色定位
- Workflow stage: 协同交接
- Workflow node: N110
- Registry category: 协同交接
- Registry subcategory: 研发反馈
- Registry function: 回传输出
- Canonical output name: `研发反馈回传单.md`
- Primary goal: 将技术限制、工期与风险反馈给产品

Follow both `references/interoperability-contract.md` and `references/workflow-v2-alignment.md` on every run. Reuse `references/n110-artifact-registry.md` when sibling artifacts already exist.

## Boundary rules / 边界规则
- Stay inside the total-table boundary for this skill.
- Accept standalone use in any requirement-to-execution scenario, but still emit an N110-compatible artifact contract so the output can be composed later.
- Do not silently expand into neighboring skills just because adjacent information is present.

## Operating contexts
- `standalone`: the user needs this skill's artifact even if sibling artifacts do not exist yet.
- `composed`: one or more sibling artifacts already exist and should be linked, refreshed, or inherited instead of re-derived.

## Execution modes
Choose exactly one:
- `live_mode`: capture feedback during a session.
- `async_mode`: collect distributed feedback with mandatory prompts.
- `summary_mode`: consolidate existing feedback into decisions and actions.
- `blocked_mode`: explain why no reliable feedback-return artifact can yet be issued.

## Inputs / 允许输入
A standalone run may start from any one of:
- raw engineering feedback or review notes
- at least one target area, decision, or requirement

A composed run should also absorb these when available:
- handover artifact
- acceptance artifact
- impact artifact
- sync artifact
- engineering parsing or solution analysis

## Output / 默认输出契约
Every non-blocked output must declare:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `contract_version`
- `canonical_output_name`
- `workflow_stage`
- `workflow_node`
- `gate_status`
- `gate_checks[]`
- `produced_event`
- `state_event`
- `exception_event`
- `sla_event`
- `priority`
- `sla_level`
- `auto_escalate_after`
- `routing_aliases[]`
- `consumed_by_nodes[]`
- `downstream_artifacts[]`

## Gate rules
Always perform these checks before finalizing the artifact:
- contract fields present
- canonical output name preserved
- required inputs either present or explicitly blocked
- boundary respected
- downstream consumability described
- this skill specific checks: feedback_metadata_present, state_machine_applied, product_facing_summary_present, decision_needed_present_or_not_applicable, deduplication_or_explanation_present

When evidence is incomplete, use `passed_with_gaps`, `blocked`, or `refresh_required` instead of implying full readiness.

## Workflow-v2 behavior
- Use schema version `1.0.0` and contract version `1.0.0` unless the output shape changes.
- Preserve `revision_log[]` so downstream consumers can see what changed between iterations.
- Emit workflow-v2-compatible event names.
- Carry an explicit SLA policy even in standalone runs.
- Prefer stable ids and trace anchors over free-text references.

## Extra behavior for this skill
- Keep `primary_mode: product_facing_engineering_feedback` in every non-blocked artifact.
- Broader review comments are allowed only after mapping them to product-relevant constraints, timing, risk, or decision needs.

## Workflow / 执行流程
1. Determine whether the request is standalone or composed.
2. Select the execution mode that fits the available evidence.
3. Load the workflow alignment and artifact registry references.
4. Produce the artifact using `references/output-template.md`.
5. Fill gate, event, SLA, and downstream-consumption sections before finalizing.
6. End with `next_skill_hints[]`, `refresh_triggers[]`, and `revision_log[]`.

## Required behavior
- Prefer compact structured sections over long prose.
- Distinguish `confirmed`, `inferred`, and `blocked` content.
- Do not fabricate missing upstream decisions.
- Do not upgrade inherited readiness.
- Reuse existing ids whenever sibling artifacts are available.
- Silence is not approval. When prompts are unanswered, say so explicitly.
- Keep quoted engineering input separate from the product-facing interpretation.

## Phase 2 optimization notes
- Normalize alias roles before shared-state write-back and expose `normalized_role` in structured outputs.
- Use the 9-state lifecycle: received, triaged, clarifying, decided, rejected, acting, verified, closed, escalated.

## Engineering source-of-truth
- Treat `MASTER.yaml` as the engineering source of truth for contract-bearing fields.
- Regenerate `references/output-template.md` and `references/workflow-v2-alignment.md` with `python3 scripts/generate_from_master.py --package-root .` after editing `MASTER.yaml` or `sources/*.md`.
- Keep sibling skill ids numeric in `sibling_skills_affected[]` and keep node consumers in `consumed_by_nodes[]`.


## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认。确认：
- artifact contract header 完整（artifact_type, schema_version, produced_event_name）
- gate_checks[] 已填写且无遗漏
- consumed_by_nodes[], sibling_skills_affected[], refresh_effects[] 已分离填写
- 按 `references/scoring-rubric.md` 做质量自评（0=blocked / 1=partial / 2=complete for mode）

## Key references
- `../031-handover-package-generation/handover-package-generation/references/node-guide.md`：**N110 节点导航（必读，见 031）**
- `../030-requirement-quality-review/requirement-quality-review/references/handoff-to-n110.md`：**N100→N110 节点交接协议（必读，见 030）**

- `references/lifecycle-sla.md`：**9 状态 SLA 定义表 + 优先级修正系数 + 计时复位规则 + escalation 处理规则（必读）**
- `references/intake-template.md`：**工程反馈录入模板 + 反馈路由决策树（Q1-Q5）+ 边界 case 表（必读）**
- `references/scoring-rubric.md`：输出质量评分（0=blocked / 1=partial / 2=complete for mode）
- `references/output-template.md`：feedback_resolution artifact 输出结构
- `references/interoperability-contract.md`：N110 跨 skill 互操作契约
- `references/n110-artifact-registry.md`：N110 所有 artifact 注册表
- `references/circuit-breaker.md`：熔断规则（防止工程反馈无限循环）
