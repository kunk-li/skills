---
name: engineering-feedback-return
description: "return n110-compatible engineering feedback to product in a way that stays standalone and composable. use when chatgpt needs to turn developer, architect, qa, or delivery feedback into a product-facing artifact about technical limits, effort, timing risk, implementation objections, or scope tradeoffs. emit a schema-versioned artifact contract, canonical output name, gate status, event fields, sla fields, feedback metadata, closure states, mandatory prompts, deduplication, and decision-needed summaries. keep the primary mode on product-facing engineering feedback, not general review administration."
---
# engineering-feedback-return

Create a workflow-v2-compatible N110 artifact that is independently usable and composable with sibling skills.

## Primary workflow identity
- Workflow stage: 协同交接
- Workflow node: N110
- Registry category: 协同交接
- Registry subcategory: 研发反馈
- Registry function: 回传输出
- Canonical output name: `研发反馈回传单.md`
- Primary goal: 将技术限制、工期与风险反馈给产品

Follow both `references/interoperability-contract.md` and `references/workflow-v2-alignment.md` on every run. Reuse `references/n110-artifact-registry.md` when sibling artifacts already exist.

## Boundary
- Stay inside the total-table boundary for this skill.
- Accept standalone use in any requirement-to-execution scenario, but still emit an N110-compatible artifact contract so the output can be composed later.
- Do not silently expand into neighboring skills just because adjacent information is present.

## Operating contexts
- `standalone`: the user needs this skill's artifact even if sibling artifacts do not exist yet.
- `composed`: one or more sibling artifacts already exist and should be linked, refreshed, or inherited instead of re-derived.

## Execution modes
Choose exactly one:
- `live_mode`: capture feedback during a session.
- `async_mode`: collect distributed feedback with mandatory prompts.
- `summary_mode`: consolidate existing feedback into decisions and actions.
- `blocked_mode`: explain why no reliable feedback-return artifact can yet be issued.

## Required minimum input
A standalone run may start from any one of:
- raw engineering feedback or review notes
- at least one target area, decision, or requirement

A composed run should also absorb these when available:
- handover artifact
- acceptance artifact
- impact artifact
- sync artifact
- engineering parsing or solution analysis

## Required artifact contract fields
Every non-blocked output must declare:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `contract_version`
- `canonical_output_name`
- `workflow_stage`
- `workflow_node`
- `gate_status`
- `gate_checks[]`
- `produced_event`
- `state_event`
- `exception_event`
- `sla_event`
- `priority`
- `sla_level`
- `auto_escalate_after`
- `routing_aliases[]`
- `consumed_by_nodes[]`
- `downstream_artifacts[]`

## Gate rules
Always perform these checks before finalizing the artifact:
- contract fields present
- canonical output name preserved
- required inputs either present or explicitly blocked
- boundary respected
- downstream consumability described
- this skill specific checks: feedback_metadata_present, state_machine_applied, product_facing_summary_present, decision_needed_present_or_not_applicable, deduplication_or_explanation_present

When evidence is incomplete, use `passed_with_gaps`, `blocked`, or `refresh_required` instead of implying full readiness.

## Workflow-v2 behavior
- Use schema version `1.0.0` and contract version `1.0.0` unless the output shape changes.
- Preserve `revision_log[]` so downstream consumers can see what changed between iterations.
- Emit workflow-v2-compatible event names.
- Carry an explicit SLA policy even in standalone runs.
- Prefer stable ids and trace anchors over free-text references.

## Extra behavior for this skill
- Keep `primary_mode: product_facing_engineering_feedback` in every non-blocked artifact.
- Broader review comments are allowed only after mapping them to product-relevant constraints, timing, risk, or decision needs.

## Recommended workflow
1. Determine whether the request is standalone or composed.
2. Select the execution mode that fits the available evidence.
3. Load the workflow alignment and artifact registry references.
4. Produce the artifact using `references/output-template.md`.
5. Fill gate, event, SLA, and downstream-consumption sections before finalizing.
6. End with `next_skill_hints[]`, `refresh_triggers[]`, and `revision_log[]`.

## Required behavior
- Prefer compact structured sections over long prose.
- Distinguish `confirmed`, `inferred`, and `blocked` content.
- Do not fabricate missing upstream decisions.
- Do not upgrade inherited readiness.
- Reuse existing ids whenever sibling artifacts are available.
- Silence is not approval. When prompts are unanswered, say so explicitly.
- Keep quoted engineering input separate from the product-facing interpretation.

## Phase 2 optimization notes
- Normalize alias roles before shared-state write-back and expose `normalized_role` in structured outputs.
- Use the 9-state lifecycle: received, triaged, clarifying, decided, rejected, acting, verified, closed, escalated.

## Engineering source-of-truth
- Treat `MASTER.yaml` as the engineering source of truth for contract-bearing fields.
- Regenerate `references/output-template.md` and `references/workflow-v2-alignment.md` with `python3 scripts/generate_from_master.py --package-root .` after editing `MASTER.yaml` or `sources/*.md`.
- Keep sibling skill ids numeric in `sibling_skills_affected[]` and keep node consumers in `consumed_by_nodes[]`.
