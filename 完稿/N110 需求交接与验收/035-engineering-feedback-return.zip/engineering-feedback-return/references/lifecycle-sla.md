# Engineering Feedback Lifecycle SLA / 生命周期 SLA 规范

本文件为 `engineering-feedback-return` 的 9 状态生命周期定义**每个状态的最大停留时长、升级规则和计时复位条件**。

---

## 1. 9 状态 SLA 定义表

| 状态 | 含义 | 最大停留时长 | 到期后升级至 | 计时起点 |
|---|---|---|---|---|
| `received` | 已收到工程反馈，尚未分类 | 24 小时（工作日） | `escalated` | 反馈录入时间 |
| `triaged` | 已分类（type/priority 已赋值），等待决策启动 | 48 小时（工作日） | `escalated` | 分类完成时间 |
| `clarifying` | 正在向提出方或产品 owner 确认细节 | 3 个工作日 | `escalated` | 进入 clarifying 时间 |
| `decided` | 产品 owner 已做出 ACCEPTED/REJECTED/DEFERRED 决策 | — | — | 决策时间（终态前置） |
| `rejected` | 明确拒绝（含理由） | — | — | 终态，无 SLA |
| `acting` | 需求修订或 PRD 更新进行中 | 由 sprint 计划决定（最长 1 sprint） | `escalated` | 进入 acting 时间 |
| `verified` | 变更已落入 PRD/handover，工程侧已确认 | 2 个工作日（确认窗口） | `escalated` | 进入 verified 时间 |
| `closed` | 闭环完成 | — | — | 终态，无 SLA |
| `escalated` | 超时或争议无法解决，升级至 PM lead / Arch | 5 个工作日内必须再次进入决策 | `closed`（若仍无决策）→ 记录为 `unresolved_at_release` | 升级时间 |

---

## 2. 优先级对 SLA 的影响 / Priority Modifier

| feedback type | 默认优先级 | SLA 系数 |
|---|---|---|
| `blocker`（阻塞交付） | P0 | 所有状态 SLA × 0.5（减半） |
| `major`（影响设计/AC） | P1 | 所有状态 SLA × 1.0（标准） |
| `minor`（文字/格式/建议） | P2 | 所有状态 SLA × 2.0（放宽） |
| `question`（仅需澄清） | P2 | `clarifying` SLA × 0.5；其余 × 2.0 |

> P0 的 `received → triaged` 最大停留时间 = 24h × 0.5 = 12h（工作日）。

---

## 3. 计时复位规则 / Timer Reset Conditions

以下事件发生时，当前状态的计时器**重置**（不累计）：

| 事件 | 复位状态 |
|---|---|
| 反馈提出方补充了新的证据或截图 | `clarifying` |
| 产品 owner 从 `escalated` 状态重新进入流程 | `triaged` |
| sprint 计划变更导致 `acting` 期限延后（PM 显式批准） | `acting` |
| 外部依赖（第三方 API / 合规意见）导致等待 | `clarifying`（需在 feedback 中记录 `blocked_by_external: true`） |

复位必须在 feedback item 的 `lifecycle_events[]` 中记录 `{event: timer_reset, reason: ..., timestamp: ...}`。

---

## 4. escalated 状态处理规则

进入 `escalated` 后：

```
escalation_owner = PM lead（默认）
               or Architecture owner（若 blocker 涉及设计冲突）
               or Compliance officer（若 blocker 含合规条目）

escalation_resolution_due = escalated_at + 5 个工作日

若 escalation_resolution_due 到期仍无决策：
  → 状态置为 closed
  → 在 release_note 中记录 unresolved_at_release: true
  → 在 031 handover package 的 open_questions[] 中追加该 item
```

---

## 5. SLA 计量的输出要求

每个 feedback item 必须输出：

```yaml
lifecycle_sla:
  current_state: triaged
  state_entered_at: "2026-04-22T10:00:00"
  state_due_at: "2026-04-24T10:00:00"   # 按 SLA 表计算，工作日
  priority: P1
  sla_modifier: 1.0
  timer_resets: []
  overdue: false   # true 若当前时间 > state_due_at
  escalation_owner: null   # 若在 escalated 状态则填写
```

`overdue: true` 的 item 必须在输出的 `overdue_items[]` 中聚合列出，供 PM 快速处理。

---

## 6. SLA 门禁判断 / Gate Check

`sla_policy_present` gate check 判定为 passed 的条件：
- 每个 feedback item 有 `lifecycle_sla` 块
- `current_state` 合法（属于 9 状态之一）
- `state_due_at` 非空（`closed` / `rejected` 终态除外）
- `priority` 与 `sla_modifier` 一致

未满足 → gate = `sla_policy_missing`，必须在 open_questions[] 中列出哪些 item 缺失。

---

## 边界 Case 对照表 / Boundary Cases

| Case | 描述 | 正确处理 | 常见误判 |
|---|---|---|---|
| P0 反馈收到但 triaged SLA 超时 | P0 的 triaged SLA = 24h × 0.5 = 12h | 升级为 escalated，escalation_owner = PM lead | 按 P1 标准 24h 等待 |
| 工程方补充了新信息 | 在 clarifying 状态下新增了证据 | timer_reset，在 lifecycle_events 中记录 | 不复位计时器 |
| 外部依赖（第三方确认）导致等待 | 记录 blocked_by_external: true | timer_reset + 增加 lifecycle_events 记录 | 按超时处理升级 |
| 决策为 DEFERRED 但无版本号 | deferred 状态 + 扣分（无 deferred_to_version） | 在 lifecycle_events 中记录 deferred 动作，PM 指定版本 | 直接 closed |
| 同一 feedback 被重复提交 | 发现 duplicate_of → 合并计分 | 合并为主条目，引用方标注 duplicate_of | 两条都独立计分 |
