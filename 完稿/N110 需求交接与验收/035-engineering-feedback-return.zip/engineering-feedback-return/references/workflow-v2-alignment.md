<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Workflow-v2 Alignment

## Identity
- skill_id: 035
- skill_name: engineering-feedback-return
- workflow_node: N110
- engineering_release: r4-v3

## Downstream contract
- consumed_by_nodes: [N110, N340, N360]
- sibling_skills_affected: [031, 032, 033]
- refresh_effects:
  - accepted feedback may trigger 031, 032, and 033 refresh per refresh matrix
  - write normalized_role before storing or forwarding feedback records

## Event contract
- produced_event: produced.n110.engineering-feedback-return.v1
- state_event: state.n110.engineering-feedback-return.v1
- exception_event: exception.n110.engineering-feedback-return.v1
- sla_event: sla.n110.engineering-feedback-return.v1
- recommended_subscribers: [N110, N340, N360, N370, N390]

## Shared state contract
- reads: [handover_packages, acceptance_criteria, impact_analyses, sync_logs]
- writes: [feedbacks, artifact_index, trace_index]
- join_keys: [artifact_id, normalized_role, change_id]

## Source-of-truth references
- interoperability_contract: references/interoperability-contract.md
- workflow_alignment: references/workflow-v2-alignment.md
- artifact_registry: references/n110-artifact-registry.md
- refresh_matrix: references/refresh-matrix.md

## Feedback-specific behavior
- always normalize incoming roles before writing feedback into shared state
- preserve the 9-state lifecycle explicitly when feedback progresses
- use sibling refresh hints only for 031, 032, and 033 when feedback is accepted
