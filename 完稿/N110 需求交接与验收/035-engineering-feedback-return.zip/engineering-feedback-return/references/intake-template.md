# Engineering Feedback Intake Template

## Source
- Meeting / thread / review link:
- Date:
- Participants:

## Feedback items
| ID | Raw engineering feedback | Source role | Normalized role | Type | Impacted requirement area | Product implication | Proposed action | Owner |
|---|---|---|---|---|---|---|---|---|

## Decision requests
- [decision needed]

## Role normalization reminder
Normalize `qa`, `ops`, `sre`, `security`, `business`, and `external` before write-back.
