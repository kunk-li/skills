# Engineering Feedback Intake Template

## Source
- Meeting / thread / review link:
- Date:
- Participants:

## Feedback items
| ID | Raw engineering feedback | Source role | Normalized role | Type | Impacted requirement area | Product implication | Proposed action | Owner |
|---|---|---|---|---|---|---|---|---|

## Decision requests
- [decision needed]

## Role normalization reminder
Normalize `qa`, `ops`, `sre`, `security`, `business`, and `external` before write-back.

---

## 反馈路由决策树 / Feedback Routing Decision Tree

```
Q1: 工程反馈是否表明当前需求**不可实现**（技术约束/架构限制）？
    YES → type = technical_constraint，blocking = true
           → 触发 033 变更影响分析，评估是否需要修改需求
    NO  → Q2

Q2: 工程反馈是否只是**澄清需求细节**（需要 PM 确认但不改变方向）？
    YES → type = clarification_request，source_kind = decision_pending
           → 进入 029 pending-items 流程处理
    NO  → Q3

Q3: 工程反馈是否提出**更好的实现方式**（可能影响 PRD 描述）？
    YES → type = implementation_suggestion，blocking = false
           → PM 评估后决定是否触发 023 prd-completion 补全
    NO  → Q4

Q4: 工程反馈是否发现**需求中的错误或遗漏**（影响交付范围）？
    YES → type = scope_gap，blocking = true
           → 触发 023 gap 分析 + 031 refresh
    NO  → type = general_comment，blocking = false

Q5（决策路由）: 035 的决策结果是什么？
    ACCEPTED         → 需求不变，工程按需求实现
    ACCEPTED_WITH_CHANGE → 需求局部修订，触发 022 repair-loop
    REJECTED         → 工程反馈被拒绝，记录理由
    DEFERRED         → 推迟到下个版本，在 029 中创建 deferred pending item
```

## 边界 Case 对照表

| 反馈内容 | type | blocking | 决策路由 |
|---|---|---|---|
| "这个接口性能达不到要求" | technical_constraint | true | 触发 033 影响分析 |
| "PRD 里写的状态机有环路" | scope_gap | true | 触发 023 gap + 022 repair |
| "建议用事件驱动替代轮询" | implementation_suggestion | false | PM 评估，可能 ACCEPTED_WITH_CHANGE |
| "字段名拼写错误" | clarification_request | false | 直接 ACCEPTED，更新 PRD 字段名 |
| "这个需求本 sprint 来不及做" | — | false | 不属于 035 范畴，应通过 sprint 计划处理 |
| "合规要求我们没有说明如何处理" | scope_gap | true | 触发 023 missing_compliance gap |
