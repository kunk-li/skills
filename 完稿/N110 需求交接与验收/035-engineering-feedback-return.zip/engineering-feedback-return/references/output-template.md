<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Output Template

# 研发反馈回传单.md

## 0. Artifact contract
- artifact_id:
- artifact_type: n110.engineering-feedback-return
- schema_version: 1.1.0
- contract_version: 1.1.0
- canonical_output_name: 研发反馈回传单.md
- skill_id: 035
- skill_name: engineering-feedback-return
- workflow_node: N110
- package_version: 3.0.0
- engineering_release: r4-v3
- operating_context: standalone / composed
- execution_mode: live_mode / async_mode / summary_mode / blocked_mode
- generated_at:
- consumed_by_nodes: [N110, N340, N360]
- sibling_skills_affected: [031, 032, 033]
- refresh_effects:
  - accepted feedback may trigger 031, 032, and 033 refresh per refresh matrix
  - write normalized_role before storing or forwarding feedback records
- downstream_artifacts: [产品研发对齐摘要.md, 需求交接包.zip]
- shared_state_reads: [handover_packages, acceptance_criteria, impact_analyses, sync_logs]
- shared_state_writes: [feedbacks, artifact_index, trace_index]

## 1. Gate and readiness
- gate_status: passed / passed_with_gaps / blocked / refresh_required
- gate_checks: [contract_fields_present, canonical_output_name_preserved, boundary_respected, downstream_consumability_declared, sibling_boundary_clean]
- confidence:
- readiness_note:
- blocker_ids:

## 2. Event and SLA
- produced_event: produced.n110.engineering-feedback-return.v1
- state_event: state.n110.engineering-feedback-return.v1
- exception_event: exception.n110.engineering-feedback-return.v1
- sla_event: sla.n110.engineering-feedback-return.v1
- recommended_subscribers: [N110, N340, N360, N370, N390]
- priority: P1
- sla_level: P1
- auto_escalate_after: 1d
- escalation_target: product_or_tech_owner
- circuit_breaker_state:

## 3. Feedback intake
- feedback_batch_id:
- normalized_role:
- state_machine_reference:
- closure_status:
- accepted_feedback_refresh_candidates:

## 4. Feedback records
- feedback_items:
- mandatory_prompt_completion:
- deduplication_summary:
- revision_log:

## 5. Refresh notes
- accepted_feedback_impacts:
- next_skill_hints:
