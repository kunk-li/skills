## 3. Change summary
- change_id:
- change_type: add / modify / remove / split / merge
- change_categories: [compliance, security, performance, data-privacy, cost, ux, other]
- baseline_before:
- proposed_or_approved_after:
- comparison_note:

## 4. Impact analysis matrix
- impact_matrix:
- cost_comparison:
- impact_radius:
- affected_downstream_nodes:

## 5. Impact recommendation
- recommendation:
- rationale:
- revision_log:
- next_skill_hints:
