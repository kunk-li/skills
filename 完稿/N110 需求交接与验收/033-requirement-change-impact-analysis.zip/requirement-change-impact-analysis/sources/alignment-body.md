## Impact-analysis-specific behavior
- keep `change_type` and `change_categories` separate because one models the operation and the other models the domain tag
- when impact is `major` or `mega`, signal 034 through sibling refresh hints and the refresh matrix
