---
name: requirement-change-impact-analysis
description: "analyze n110-compatible requirement changes so the result stays standalone and composable. use when chatgpt needs to compare a proposed or approved change against the current handover, acceptance, or task context and explain the impact on engineering, testing, and version scope. emit a schema-versioned artifact contract, canonical output name, gate status, event fields, sla fields, five-dimension impact analysis, rework estimates, impact radius, and downstream refresh hints. stay within advisory analysis scope and do not directly edit implementation or schedules."
---
# requirement-change-impact-analysis

Create a workflow-v2-compatible N110 artifact that is independently usable and composable with sibling skills.

## Primary workflow identity
- Workflow stage: 协同交接
- Workflow node: N110
- Registry category: 协同交接
- Registry subcategory: 变更管理
- Registry function: 影响分析
- Canonical output name: `需求变更影响分析.md`
- Primary goal: 分析需求变更对研发、测试和版本范围的影响

Follow both `references/interoperability-contract.md` and `references/workflow-v2-alignment.md` on every run. Reuse `references/n110-artifact-registry.md` when sibling artifacts already exist.

## Boundary
- Stay inside the total-table boundary for this skill.
- Accept standalone use in any requirement-to-execution scenario, but still emit an N110-compatible artifact contract so the output can be composed later.
- Do not silently expand into neighboring skills just because adjacent information is present.

## Operating contexts
- `standalone`: the user needs this skill's artifact even if sibling artifacts do not exist yet.
- `composed`: one or more sibling artifacts already exist and should be linked, refreshed, or inherited instead of re-derived.

## Execution modes
Choose exactly one:
- `quick_impact`: fast triage using the highest-signal dimensions only.
- `full_impact`: full five-dimension analysis with rework and cost comparison.
- `what_if_mode`: compare multiple change options side by side.
- `blocked_mode`: explain why a meaningful impact judgment cannot yet be made.

## Required minimum input
A standalone run may start from any one of:
- baseline before state
- proposed or approved after state
- at least one comparison source such as handover, acceptance, task plan, or design note

A composed run should also absorb these when available:
- handover artifact
- acceptance artifact
- development task breakdown
- sync artifact
- engineering feedback artifact

## Required artifact contract fields
Every non-blocked output must declare:
- `artifact_id`
- `artifact_type`
- `schema_version`
- `contract_version`
- `canonical_output_name`
- `workflow_stage`
- `workflow_node`
- `gate_status`
- `gate_checks[]`
- `produced_event`
- `state_event`
- `exception_event`
- `sla_event`
- `priority`
- `sla_level`
- `auto_escalate_after`
- `routing_aliases[]`
- `consumed_by_nodes[]`
- `downstream_artifacts[]`

## Gate rules
Always perform these checks before finalizing the artifact:
- contract fields present
- canonical output name preserved
- required inputs either present or explicitly blocked
- boundary respected
- downstream consumability described
- this skill specific checks: five_dimension_scan_present, rework_impact_present_or_not_applicable, cost_comparison_present, impact_radius_scored, downstream_refresh_hints_present

When evidence is incomplete, use `passed_with_gaps`, `blocked`, or `refresh_required` instead of implying full readiness.

## Workflow-v2 behavior
- Use schema version `1.0.0` and contract version `1.0.0` unless the output shape changes.
- Preserve `revision_log[]` so downstream consumers can see what changed between iterations.
- Emit workflow-v2-compatible event names.
- Carry an explicit SLA policy even in standalone runs.
- Prefer stable ids and trace anchors over free-text references.

## Extra behavior for this skill
- Always list `affected_downstream_nodes[]` and `affected_sibling_artifacts[]`.
- When evidence is thin, downgrade confidence rather than hiding uncertainty.

## Recommended workflow
1. Determine whether the request is standalone or composed.
2. Select the execution mode that fits the available evidence.
3. Load the workflow alignment and artifact registry references.
4. Produce the artifact using `references/output-template.md`.
5. Fill gate, event, SLA, and downstream-consumption sections before finalizing.
6. End with `next_skill_hints[]`, `refresh_triggers[]`, and `revision_log[]`.

## Required behavior
- Prefer compact structured sections over long prose.
- Distinguish `confirmed`, `inferred`, and `blocked` content.
- Do not fabricate missing upstream decisions.
- Do not upgrade inherited readiness.
- Reuse existing ids whenever sibling artifacts are available.
- When there is not enough evidence to score impact radius precisely, still provide a bounded estimate and mark the confidence.
- If the change only affects one area, say so explicitly instead of forcing equal detail across all five dimensions.

## Phase 2 optimization notes
- Keep `change_type` and `change_categories[]` separate: one is operation type, the other is domain tag.
- Use `sibling_skills_affected[]` for refreshable sibling skills; never place sibling skill names in `consumed_by_nodes[]`.

## Engineering source-of-truth
- Treat `MASTER.yaml` as the engineering source of truth for contract-bearing fields.
- Regenerate `references/output-template.md` and `references/workflow-v2-alignment.md` with `python3 scripts/generate_from_master.py --package-root .` after editing `MASTER.yaml` or `sources/*.md`.
- Keep sibling skill ids numeric in `sibling_skills_affected[]` and keep node consumers in `consumed_by_nodes[]`.
