<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Output Template

# 需求变更影响分析.md

## 0. Artifact contract
- artifact_id:
- artifact_type: n110.requirement-change-impact
- schema_version: 1.1.0
- contract_version: 1.1.0
- canonical_output_name: 需求变更影响分析.md
- skill_id: 033
- skill_name: requirement-change-impact-analysis
- workflow_node: N110
- package_version: 3.0.0
- engineering_release: r4-v3
- operating_context: standalone / composed
- execution_mode: quick_impact / full_impact / what_if_mode / blocked_mode
- generated_at:
- consumed_by_nodes: [N350, N360]
- sibling_skills_affected: [034]
- refresh_effects:
  - major or mega impact makes 034 final_sync_mode mandatory
  - approved impact may trigger sync regeneration and downstream risk updates
- downstream_artifacts: [风险项清单.csv, 需求变更同步通知.md, 产品研发对齐摘要.md]
- shared_state_reads: [changes, acceptance_criteria, handover_packages, feedbacks, decision_registry]
- shared_state_writes: [impact_analyses, artifact_index, trace_index]

## 1. Gate and readiness
- gate_status: passed / passed_with_gaps / blocked / refresh_required
- gate_checks: [contract_fields_present, canonical_output_name_preserved, boundary_respected, downstream_consumability_declared, sibling_boundary_clean]
- confidence:
- readiness_note:
- blocker_ids:

## 2. Event and SLA
- produced_event: produced.n110.requirement-change-impact.v1
- state_event: state.n110.requirement-change-impact.v1
- exception_event: exception.n110.requirement-change-impact.v1
- sla_event: sla.n110.requirement-change-impact.v1
- recommended_subscribers: [N120, N180, N270, N330, N350, N360, N390]
- priority: P1
- sla_level: P1
- auto_escalate_after: 1d
- escalation_target: change_owner_or_pm
- circuit_breaker_state:

## 3. Change summary
- change_id:
- change_type: add / modify / remove / split / merge
- change_categories: [compliance, security, performance, data-privacy, cost, ux, other]
- baseline_before:
- proposed_or_approved_after:
- comparison_note:

## 4. Impact analysis matrix
- impact_matrix:
- cost_comparison:
- impact_radius:
- affected_downstream_nodes:

## 5. Impact recommendation
- recommendation:
- rationale:
- revision_log:
- next_skill_hints:
