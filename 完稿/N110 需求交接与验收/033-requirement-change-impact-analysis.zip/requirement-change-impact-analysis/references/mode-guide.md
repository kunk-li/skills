# Mode Guide

## quick_impact
Use when an explicit delta exists but a same-day directional answer is more valuable than a full matrix.
Always keep `change_type` and `change_categories[]` distinct.

## full_impact
Use when rework, external coordination, and cost comparison all matter.
Populate all five matrix dimensions and call out any sibling refresh impact.

## what_if_mode
Use when the change is not yet approved.
Keep approval-sensitive conclusions clearly bounded as conditional.
