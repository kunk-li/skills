<!-- AUTO-GENERATED FROM MASTER.yaml. EDIT MASTER.yaml OR sources/*.md, THEN REBUILD. -->
# Workflow-v2 Alignment

## Identity
- skill_id: 033
- skill_name: requirement-change-impact-analysis
- workflow_node: N110
- engineering_release: r4-v3

## Downstream contract
- consumed_by_nodes: [N350, N360]
- sibling_skills_affected: [034]
- refresh_effects:
  - major or mega impact makes 034 final_sync_mode mandatory
  - approved impact may trigger sync regeneration and downstream risk updates

## Event contract
- produced_event: produced.n110.requirement-change-impact.v1
- state_event: state.n110.requirement-change-impact.v1
- exception_event: exception.n110.requirement-change-impact.v1
- sla_event: sla.n110.requirement-change-impact.v1
- recommended_subscribers: [N120, N180, N270, N330, N350, N360, N390]

## Shared state contract
- reads: [changes, acceptance_criteria, handover_packages, feedbacks, decision_registry]
- writes: [impact_analyses, artifact_index, trace_index]
- join_keys: [artifact_id, normalized_role, change_id]

## Source-of-truth references
- interoperability_contract: references/interoperability-contract.md
- workflow_alignment: references/workflow-v2-alignment.md
- artifact_registry: references/n110-artifact-registry.md
- refresh_matrix: references/refresh-matrix.md

## Impact-analysis-specific behavior
- keep `change_type` and `change_categories` separate because one models the operation and the other models the domain tag
- when impact is `major` or `mega`, signal 034 through sibling refresh hints and the refresh matrix
