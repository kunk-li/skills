# Five-Dimension Impact Analysis Model / 五维度变更影响分析模型

这是 SKILL.md 中 `five_dimension_scan_present` gate check 及 `full_impact` 模式所要求的五个分析维度的正式定义。

每次 `full_impact` 分析必须覆盖所有五个维度，并在 `impact_matrix` 中逐维输出。
`quick_impact` 模式至少覆盖与变更直接相关的维度，并说明哪些维度跳过及理由。

---

## 五个维度

### DIM-1：功能影响 / Functional Impact

**定义**：变更对产品功能范围、用户行为路径和业务流程的影响。

**核心问题**：
- 变更新增、修改或删除了哪些用户可见功能？
- 现有业务流程（含审批链、工单流、结算流）是否被打断或改变？
- 新增了哪些 edge case 或例外路径？

**输出字段**：
- `affected_features[]`：受影响的 L3 功能 ID 列表
- `new_edge_cases[]`：变更引入的新边界条件
- `flow_breaks[]`：被打断的业务流程节点

---

### DIM-2：数据影响 / Data Impact

**定义**：变更对数据模型、字段定义、对象关系和数据生命周期的影响。

**核心问题**：
- 是否新增、修改或删除了字段/对象/枚举值？
- 历史数据是否需要迁移或补填？
- 数据所有权或留存策略是否变化？

**输出字段**：
- `schema_changes[]`：受影响的对象/字段列表及变化类型（add/modify/remove）
- `migration_required`：`yes / no / tbd`
- `migration_scope`：如需迁移，影响的数据量级/时间窗口估计
- `data_owner_changes[]`：数据主权变更（如从 A 服务迁到 B 服务）

---

### DIM-3：接口与集成影响 / API & Integration Impact

**定义**：变更对 API 契约、事件发布、外部系统集成和内部跨模块调用的影响。

**核心问题**：
- 是否有 breaking change（字段删除/类型变更/端点移除）？
- 是否新增了对外依赖或改变了已有依赖的调用方式？
- 事件/消息格式是否变化？

**输出字段**：
- `api_breaking_changes[]`：破坏性变更列表（endpoint, field, type）
- `new_dependencies[]`：新引入的外部系统或服务
- `event_schema_changes[]`：受影响的事件或消息格式
- `consumer_notification_required`：是否需要通知下游消费方

---

### DIM-4：权限影响 / Permission Impact

**定义**：变更对角色权限、操作授权、数据可见性和安全边界的影响。

**核心问题**：
- 是否有新的角色、权限点或资源访问规则被引入？
- 现有角色的权限是否被扩大或收窄？
- 是否影响审计日志、操作留痕或合规控制？

**输出字段**：
- `affected_roles[]`：受影响的角色或权限主体
- `permission_delta[]`：权限变化列表（role, resource, action, before, after）
- `audit_log_impact`：审计日志是否需要同步更新
- `compliance_flag`：是否涉及合规或监管要求的权限

---

### DIM-5：下游依赖影响 / Downstream Dependency Impact

**定义**：变更对本模块下游的文档、任务、验收、交接和工程执行计划的影响。

**核心问题**：
- 已生成的 handover 包、acceptance criteria、task breakdown 是否失效？
- 哪些 N110 sibling artifacts 需要 refresh？
- 工程侧的时间估算是否需要重做？

**输出字段**：
- `stale_artifacts[]`：因本次变更失效的 artifact 列表（id + 失效原因）
- `refresh_urgency`：`immediate / before_next_sprint / low_priority`
- `rework_cost_estimate`：预估工程返工代价（如：S/M/L 或人天）
- `downstream_refresh_hints[]`：给 034（sync）提供的刷新建议

---

## impact_radius 评分规则

基于五个维度的覆盖情况计算 `impact_radius`：

```
dim_coverage = 受影响维度数 / 5
severity_max = max(DIM-1..DIM-5 中每维度的 severity)

impact_radius =
  if dim_coverage == 1.0 and severity_max == critical:
    catastrophic       # 五维度全影响 + 最高严重度
  elif dim_coverage >= 0.6 or severity_max == critical:
    major              # ≥3 维度受影响 或 任一维度为 critical
  elif dim_coverage >= 0.4 or severity_max == major:
    moderate           # ≥2 维度受影响 或 任一维度为 major
  else:
    minor              # 仅 1 维度受影响且 severity ≤ minor
```

每个维度的 severity 取值：`critical / major / minor / none`

---

## five_dimension_scan_present 门禁判断规则

Gate check `five_dimension_scan_present` 判定为 passed 的条件：
- `full_impact` 模式：五个维度均有 `status`（`analyzed / not_applicable / blocked`）
- `quick_impact` 模式：至少 2 个维度有 `analyzed`，其余有明确的 `not_applicable` 理由
- `what_if_mode`：每个 what-if 选项均有独立的维度覆盖

未达到上述条件时：gate 标记为 `passed_with_gaps`，并在 `gate_checks[]` 中说明哪些维度缺失。

---

## 分析模式选择决策树 / Analysis Mode Decision Tree

```
Q1: 是否有完整的变更描述（change_type + baseline_before + proposed_after）？
    NO → 先运行 inventory_mode，收集变更信息，再触发正式分析
    YES → Q2

Q2: 变更影响是否仅限于单一功能/字段，且确认无 API/权限/数据影响？
    YES → quick_impact 模式（至少 2 个维度，其余标注 not_applicable + 理由）
    NO → Q3

Q3: 是否需要对多个假设方案分别评估影响？
    YES → what_if 模式（每个方案独立过五维度）
    NO → full_impact 模式（5 个维度全部分析）

Q4（five_dimension_scan_present gate check）:
    full_impact: 5 个维度均有 status（analyzed/not_applicable/blocked）→ passed
    quick_impact: ≥ 2 个 analyzed + 其余有明确 not_applicable 理由 → passed
    otherwise → passed_with_gaps（在 gate_checks[] 中说明缺失维度）
```

## 边界 Case 对照表

| 变更场景 | 影响维度 | impact_radius | 常见误判 |
|---|---|---|---|
| 修改一个字段的枚举值 | DIM-2（数据）| moderate（≥2维 → 数据+可能影响 DIM-3） | 只分析 DIM-2，忽略下游 API 消费方 |
| 删除一个 API endpoint | DIM-3（接口）+ DIM-5（下游） | major（≥3维或 critical） | 只标 DIM-3，忽略 DIM-5 stale_artifacts |
| 角色权限范围缩小 | DIM-4（权限）+ DIM-1（功能） | major | 只填 DIM-4，忽略功能可用性影响 |
| 数据迁移（字段改名） | DIM-2（数据）+ DIM-3（接口） | major | migration_required=tbd，未给出迁移策略 |
| 增加新 webhook 事件 | DIM-3（接口）| minor 或 moderate | 低估下游订阅方的影响（DIM-5） |
| 合规条款变更 | DIM-4（权限）+ DIM-1（功能） | major 或 catastrophic | 未触发 compliance_flag |
