# Real Examples / 真实示例参考

These examples illustrate correctly formed orchestration pipeline artifacts and common edge cases. Use them alongside the bundled `examples/` files and `examples/integration/`.

---

## Example 1: Step dependency must use depends_on list, not blocking fields

**Input**: STEP-02 should only run after STEP-01 completes.

**Correct pattern**:
```yaml
- step_id: STEP-02
  depends_on: [STEP-01]
```

**Anti-pattern**: Adding a field like `blocks: STEP-01` or `prerequisite: STEP-01` — order-binding fields violate the standalone use contract and are rejected by `check_order_neutrality.py`.

---

## Example 2: Compensation is required for every step

**Input**: A pipeline step may fail mid-execution; the recovery path must be defined in advance.

**Correct pattern**:
```yaml
- step_id: STEP-02
  fallback:
    on_failure: [keep prior route-rules.yaml; mark changed routes as pending_clarification]
  compensation: [emit partial route-rules with changed_routes flagged as needs_review]
```

**Anti-pattern**: Omitting `compensation` — without a defined compensation path, a failed step leaves the pipeline in an unrecoverable state with no audit record of what was attempted.

---

## Example 3: Incremental mode — only changed artifacts should be inputs

**Input**: A weekly delta refresh should not re-process the full pipeline.

**Correct pattern**:
```yaml
pipeline_name: invoice-incremental-refresh-pipeline
goal: refresh only the route and state artifacts affected by new delta signals
steps:
  - step_id: STEP-01
    inputs: [SNAP-invoice-20260514-01, delta-signal-pack.json]
    outputs: [context-snapshot-delta.yaml]
```

**Rule**: Incremental mode pipelines should scope their inputs to the delta artifacts plus the prior snapshot. Including unchanged full artifacts as inputs unnecessarily increases processing scope and may trigger full recomputation.
