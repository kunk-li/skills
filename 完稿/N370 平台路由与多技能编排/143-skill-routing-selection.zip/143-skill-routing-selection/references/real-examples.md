# Real Examples / 真实示例参考

These examples illustrate correctly formed route-rules artifacts and common edge cases. Use them alongside the bundled `examples/` files and `examples/integration/`.

---

## Example 1: Decision mode — condition_dsl must use only allowed functions

**Input**: Route context shows both a blocking signal and a ready signal; the routing engine must choose.

**Correct condition_dsl**:
```yaml
condition_dsl: has(pipeline_blocked) and count(open_blockers) > 0
```

**Anti-pattern**: Writing `pipeline_blocked == true` — the AST whitelist only permits `has()`, `contains()`, and `count()`. Equality operators are not in the allowed set.

---

## Example 2: Incremental refresh mode — prior route must be referenced

**Input**: Weekly delta refresh; only two of eight routes have changed signals.

**Correct pattern**:
```yaml
route_id: N370.PL-invoice-202621.ST-02.R01
trigger_type: scheduled
condition_dsl: has(prior_route_id) and count(changed_signals) > 0
rationale: incremental refresh re-evaluates only routes with changed_signals; unchanged routes preserved via cross_artifact_refs
```

**Anti-pattern**: Omitting `prior_route_id` check — without it, incremental refresh cannot distinguish "no new signal" from "cold start", and may incorrectly recompute all routes.

---

## Example 3: Quick view mode — partial readiness is valid

**Input**: A stakeholder needs a fast view of current routing without a full pipeline build.

**Correct pattern**:
```yaml
selected_mode: quick_view_mode
readiness: partial
pending_clarifications:
  - confirm whether full orchestration is needed or quick view is sufficient for this decision
```

**Rule**: `quick_view_mode` artifacts should always set `readiness: partial` and explicitly list what must be confirmed before the artifact can be promoted to `ready`. Routing a partial artifact to `N380` without confirmation risks a gate failure.
