---
name: skill-routing-selection
display_name: 平台路由选择 / Skill Routing Selection
description: select platform skills, routes, fallback chains, and handoff targets from mixed workflow context. use when chatgpt needs machine-consumable routing rules, condition dsl, stable pipeline and state ids, route test cases, or handoffs into multi-skill orchestration and state mapping.
---

# Skill Routing Selection

## N370 v1.1.0 contract baseline
- contract_version: `n370-platform-v1.1.1`
- workflow node: `N370`
- skill_id: `143`
- schema: `n370.skill-routing-selection.v2`
- artifact target: `route-rules.yaml`
- composition_role: `route_decision_owner`
- function_bias: `routing`
- dsl_used: `condition_dsl`

This skill is self-contained. It can run alone with partial evidence, and it becomes stronger when composed with the other N370 skills through `pipeline_scope`, stable IDs, `cross_artifact_refs`, and `downstream_handoff`.

## References
Read these files when their rules are relevant:
- `references/n370-shared-platform-contract.md`
- `references/n370-id-space.md`
- `references/output-contract.yaml`
- `references/skill-routing-selection-quality-checklist.md`
- `references/route-schema.md`
- `references/test-harness.md`

## Standalone and composition role
Standalone use:
- Produce `route-rules.yaml` from the user's provided context, even if sibling N370 artifacts are missing.
- When evidence is incomplete, keep the output usable by setting `readiness: partial`, adding `pending_clarifications`, and preserving stable upstream IDs.

Composition use:
- 143 owns route selection and fallback chain.
- 144 owns cold-start memory and stable snapshot continuity.
- 145 owns multi-skill execution order, timeouts, fallback, and compensation.
- 146 owns state and transition definitions.
- Do not duplicate a sibling artifact; reference it with `cross_artifact_refs`.

## Selected modes
Use one of these modes and write it in metadata:
- `decision_mode`
- `ruleset_mode`
- `quick_view_mode`
- `incremental_refresh_mode`

## Output contract
When the result will be reused by another skill, engine, or reviewer, emit:
1. the canonical YAML artifact matching `n370.skill-routing-selection.v2`;
2. a sidecar `.metadata.yaml` following `references/n370-shared-platform-contract.md`;
3. `downstream_handoff` when a sibling skill, N380, N390, or a governance engine should consume it.

## Workflow
1. Identify the target consumer and whether the request is standalone or part of an N370 composition path.
2. Preserve upstream IDs from N320/N330/N340/N350/N360 before creating new N370 IDs.
3. Assign `pipeline_scope` before writing route, snapshot, pipeline, or state artifacts.
4. Choose the narrowest selected mode that fits the evidence.
5. Build the canonical YAML artifact using the skill's schema and bundled references.
6. Add a sidecar metadata file with evidence, confidence, pending fields, cross-artifact refs, and handoff.
7. Run the bundled validator when producing a machine-readable artifact.
8. Run the quality checklist before returning the result.

## Strict boundaries
- Do not perform the downstream business skill's substantive analysis; coordinate routes, memory, pipelines, and states.
- Do not put prose inside DSL fields.
- Do not fabricate pipeline, route, state, transition, or snapshot IDs.
- Do not reference the current artifact in its own `cross_artifact_refs`.
- Do not rely on external node-level assets.

## Examples
Use `examples/platform-route-decision.yaml` as the canonical machine artifact and `examples/platform-route-decision.metadata.yaml` as its sidecar metadata and handoff example. Differences from the examples are allowed when the user's source material requires them, but field names, metadata order, ID style, cross-reference rules, and handoff shape should stay compatible.

## New validators (v1.1.1+)

- `scripts/validate_metadata.py` — checks sidecar contract_version, artifact_id prefix, and field completeness.
- `scripts/validate_skill_md.py` — prevents stale contract_version heading in SKILL.md.
- `scripts/validate_release_consistency.py` — single-skill and four-skill suite version alignment.
- `scripts/validate_cascade.py` — verifies coherent pipeline_id and schema across all four N370 artifacts.

## Quality check
Use `references/skill-routing-selection-quality-checklist.md`. If the output is machine-readable, run `scripts/validate_routes.py` against the artifact before finalizing.
