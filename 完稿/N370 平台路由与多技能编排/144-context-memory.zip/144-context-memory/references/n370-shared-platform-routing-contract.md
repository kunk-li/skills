# N370 Shared Platform Routing Contract Pointer

This release uses `references/n370-shared-platform-contract.md` as the canonical shared contract.

Contract version: `n370-platform-v1.1.1`

Use this file only as a compatibility pointer for older N370 v1.1.0 references.
