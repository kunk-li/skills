# Context Memory Quality Checklist

Use this checklist before finalizing `context-snapshot.yaml`.

1. Metadata uses `contract_version: n370-platform-v1.1.1` and includes `pipeline_scope`.
2. `selected_mode` matches the actual output shape.
3. `artifact_id` and row-level IDs follow `references/n370-id-space.md`.
4. `cross_artifact_refs` reference sibling or upstream artifacts and never the current artifact itself.
5. Evidence uses confirmed_fact, bounded_inference, or open_question layers.
6. DSL fields contain only DSL, not prose.
7. `engine_consumable` matches the actual artifact body.
8. Missing information is recorded in pending fields, not guessed.
9. `downstream_handoff` includes `pipeline_scope`, `engine_consumable`, required fields, readiness, and next checks.
10. The output aligns with both files under `examples/`; differences are allowed when intentional.
11. Run `scripts/validate_snapshot.py` on the canonical artifact when producing machine-readable output.

## Skill-specific checks
- all seven fixed snapshot fields are present.
- pm_overrides contains only explicit PM decisions.
- snapshot is compact enough for cold start.
- open_questions preserve unresolved context rather than hiding it.
