# N370 ID Space

This byte-identical reference is packaged into all N370 skills.

## Contract version
`n370-platform-v1.1.1`

## Five-tier ID model
1. `node_id`: always `N370`.
2. `pipeline_id`: `PL-<project_or_flow>-<yyyyww_or_nn>`.
3. `state_id`: `N370.<pipeline_id>.ST-<nn>`.
4. `route_id` / `transition_id`: `N370.<pipeline_id>.ST-<nn>.R<nn>` or `N370.<pipeline_id>.TR-<nn>`.
5. `step_id` / `snapshot_id`: `STEP-<nn>` or `SNAP-<project_or_flow>-<yyyymmdd_or_nn>`.

## Artifact IDs
- 143: `RT-RULESET-<project_or_flow>-<yyyyww_or_nn>`.
- 144: `SNAP-<project_or_flow>-<yyyymmdd_or_nn>`.
- 145: `PIPELINE-<project_or_flow>-<yyyyww_or_nn>`.
- 146: `STM-<project_or_flow>-<pipeline_or_yyyyww>-<nn>`.
- Fallback: `TEMP-N370-<date>-<source>`.

## Cross-reference rule
`cross_artifact_refs` must reference sibling or upstream artifacts only. It must not include the current artifact's own `artifact_id`.
