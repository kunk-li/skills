# N370 Shared Platform Contract

## 1. Contract version
`n370-platform-v1.1.1`

## 2. Node scope
N370 is the platform routing and orchestration node. It turns upstream decisions, task/risk signals, memory snapshots, and state signals into engine-consumable route rules, context snapshots, orchestration pipelines, and state maps.

## 3. Encapsulation governance
Each skill is self-contained. Required shared rules are packaged inside each skill under `references/`. No skill depends on external node-level assets.

## 4. Release consistency rule
A valid release keeps `n370-platform-v1.1.1` in every `SKILL.md`, `references/output-contract.yaml`, and this shared contract. Shared references packaged into multiple skills must remain byte-identical.

## 5. Schema governance
N370 uses dual-track versioning. `contract_version` governs node-level metadata, ID, handoff, and composition protocols. The per-skill `schema` field governs the machine artifact body, for example `n370.skill-routing-selection.v2` or `n370.state-transition-mapping.v2`.

## 6. Shared metadata schema
Every reusable N370 output should use a sidecar `.metadata.yaml` file or an equivalent metadata block.

```yaml
metadata:
  contract_version: n370-platform-v1.1.1
  workflow_node: N370
  skill_id: 143 | 144 | 145 | 146
  skill_name: string
  artifact_family_id: n370-platform-foundation-suite
  artifact_id: string
  schema: n370.<skill>.v2
  selected_mode: string
  readiness: draft | partial | ready | blocked
  pipeline_scope:
    pipeline_id: string | unknown
    state_id: string | unknown
    snapshot_id: string | unknown
  source_time_window:
    start: iso8601 | unknown
    end: iso8601 | unknown
    timezone: string
  project_scope: [string]
  source_artifacts: [string]
  upstream_id_aliases: [string]
  evidence_refs: [artifact_evidence_ref]
  cross_artifact_refs: [string]
  pending_clarifications: [string]
  pending_decisions: [string]
  open_blockers: [string]
  owner_placeholders: [role_or_team]
  confidentiality_level: public_internal | restricted_internal | confidential
  confidence: high | medium | low
  composition_role: string
  function_bias: routing | snapshot | orchestration | state_machine
  stage_position: platform_foundation.<substage>
  dsl_used: condition_dsl | guard_dsl | snapshot_7_fields | step_dag | none
  artifact_target: string
  engine_consumable: yaml | json | both | no
  freshness:
    as_of_date: iso8601 | unknown
    source_commit: string | null
    expected_review_window: string
```

## 7. Five-tier ID space
N370 IDs are hierarchical and engine-facing.

| tier | id | rule |
|---|---|---|
| node | `node_id` | always `N370` |
| pipeline | `pipeline_id` | `PL-<project_or_flow>-<yyyyww_or_nn>` |
| state | `state_id` | `N370.<pipeline_id>.ST-<nn>` |
| route / transition | `route_id` / `transition_id` | `N370.<pipeline_id>.ST-<nn>.R<nn>` or `N370.<pipeline_id>.TR-<nn>` |
| step / snapshot | `step_id` / `snapshot_id` | `STEP-<nn>` or `SNAP-<project_or_flow>-<yyyymmdd_or_nn>` |

## 8. Artifact ID rules
- 143 route rules: `RT-RULESET-<project_or_flow>-<yyyyww_or_nn>`.
- 144 context snapshots: `SNAP-<project_or_flow>-<yyyymmdd_or_nn>`.
- 145 pipelines: `PIPELINE-<project_or_flow>-<yyyyww_or_nn>`.
- 146 state maps: `STM-<project_or_flow>-<pipeline_or_yyyyww>-<nn>`.
- Temporary IDs use `TEMP-N370-<date>-<source>` and must appear in `pending_clarifications` or `upstream_id_aliases`.

## 9. DSL governance
N370 DSL fields must stay machine-readable and must not contain prose.
- `condition_dsl` belongs to routing rules.
- `guard_dsl` belongs to state transitions.
- `step_dag` is represented by `steps[].depends_on` in orchestration pipelines.
- `snapshot_7_fields` means the fixed snapshot fields: state, decisions, blockers, risks, deferred, open_questions, pm_overrides.
- Supported helper style: `has()`, `contains()`, `count()`, comparisons, boolean `and/or/not`.

## 10. Evidence reference schema
```yaml
artifact_evidence_ref:
  ref_id: string
  source_family: route | snapshot | pipeline | state_map | upstream_node | user_request | file | chat
  source_name: string
  source_artifact_id: string | null
  time_window_or_version: string | null
  scope: string | null
  upstream_id_aliases: [string]
  excerpt_or_pointer: string | null
  confidence: high | medium | low
  layer: confirmed_fact | bounded_inference | open_question
```

## 11. Cross-artifact join keys
Use stable IDs rather than file names: `artifact_id`, `pipeline_id`, `state_id`, `route_id`, `transition_id`, `snapshot_id`, `step_id`, `cross_artifact_refs`, `upstream_id_aliases`, and `handoff_id`.

## 12. Standard composition paths
1. **Route-then-orchestrate**: N100/N110/N360 signal -> 143 route decision -> 145 pipeline -> N380.
2. **Snapshot-then-resume**: N350/N360 context -> 144 snapshot -> sibling skill continuation.
3. **State-driven-pipeline**: 146 state map -> 143 route rules -> 145 pipeline.
4. **Cold-start-recovery**: prior 144 snapshot + new signals -> 143 + 145 + 146 restart.
5. **Standalone fallback**: any skill can run alone and mark `readiness: partial`.

## 13. Standalone guarantee
Each skill can produce a usable partial artifact with stable IDs, explicit pending gaps, and conservative confidence even when sibling artifacts are missing.

## 14. Composition guarantee
- 143 owns route decision and fallback chain.
- 144 owns continuity memory and cold-start recovery.
- 145 owns orchestration step order, dependencies, fallback, timeout, and compensation.
- 146 owns state and transition definitions.
- Skills strengthen each other by reusing IDs and metadata, not by rewriting sibling artifacts.

## 15. Downstream handoff schema
```yaml
downstream_handoff:
  contract_version: n370-platform-v1.1.1
  handoff_id: HO-N370-<artifact_id>-<seq>
  producer_skill: string
  consumer_skill_or_node: sibling_skill | N380 | N390 | governance_engine | human_operator
  artifact_family_id: n370-platform-foundation-suite
  artifact_id: string
  artifact_target: string
  pipeline_scope:
    pipeline_id: string | unknown
    state_id: string | unknown
    snapshot_id: string | unknown
  engine_consumable: yaml | json | both | no
  required_fields: [string]
  cross_artifact_refs: [string]
  pending_clarifications: [string]
  pending_decisions: [string]
  readiness: draft | partial | ready | blocked
  confidence: high | medium | low
  next_best_checks: [string]
```

## 16. Engine consumer guarantee
If `engine_consumable` is `yaml`, `json`, or `both`, the artifact body must validate with the bundled validator. Markdown may be used for review notes only, not for canonical engine input.

## 17. Compensation governance
Pipeline compensation must be operational: every fallback or compensation entry should state the trigger, action, expected outcome, and whether human signoff is required. Do not use vague phrases such as "handle manually" without a concrete owner role.

## 18. State machine governance
State maps should preserve `state_id`, `transition_id`, `state_from`, `state_to`, `trigger_type`, and `guard_dsl`. Compatibility aliases such as `from` or `guards` may appear in user input, but canonical outputs must use `state_from` and `guard_dsl`.

## 19. Common execution workflow
1. Identify whether the request is standalone or part of a composition path.
2. Preserve upstream IDs before creating new N370 IDs.
3. Assign pipeline/state/snapshot scope.
4. Choose the selected mode.
5. Emit a canonical YAML artifact and, when reusable, a `.metadata.yaml` sidecar.
6. Keep DSL fields machine-only.
7. Validate with the bundled script when possible.
8. Run the skill-specific quality checklist.

## 20. Common self-check
1. Contract version is `n370-platform-v1.1.1` everywhere.
2. Metadata sidecar exists for reusable outputs.
3. Five-tier ID space is stable.
4. `cross_artifact_refs` never includes the current artifact itself.
5. DSL fields contain only DSL.
6. Pipeline steps do not create cycles.
7. State transitions reference declared states.
8. Snapshot contains all seven fixed fields.
9. Handoff includes `engine_consumable` and `pipeline_scope`.
10. Missing information is explicit in pending fields.
11. Examples remain compatible; differences are allowed only when intentional.
