# Real Examples / 真实示例参考

These examples illustrate correctly formed context snapshot artifacts and common edge cases. Use them alongside the bundled `examples/` files and `examples/integration/`.

---

## Example 1: Delta mode — new snapshot must not overwrite prior

**Input**: A weekly delta refresh produces a new snapshot for `PL-invoice-202621`.

**Correct pattern**:
```yaml
snapshot_id: SNAP-invoice-20260521-02   # new id; incremented from -01
state:
  current_state_id: N370.PL-invoice-202621.ST-02
evidence_ref:
  - EV-invoice-delta-001
```

**Anti-pattern**: Writing the same `snapshot_id` as the prior week — this overwrites the historical snapshot and makes it impossible to replay the prior state during audit.

---

## Example 2: Cold start recovery mode — blockers and open questions required

**Input**: No prior snapshot exists; the system must recover from a cold start using only the N360 handoff as evidence.

**Correct pattern**:
```yaml
selected_mode: cold_start_recovery_mode
readiness: partial
confidence: low
blockers:
  - id: BLK-cold-001
    summary: no prior context snapshot; all decisions are unverified
open_questions:
  - Is the N360 handoff the most recent source of truth?
  - Does the routing-owner confirm the recovered context is accurate?
```

**Rule**: Cold start recovery artifacts must set `readiness: partial` and `confidence: low`. Do not route to N380 gate until a human confirms the snapshot accuracy.

---

## Example 3: Snapshot continuity — cross_artifact_refs must reference prior snapshot

**Input**: A delta snapshot builds on the prior week's snapshot.

**Correct pattern**:
```yaml
cross_artifact_refs:
  - SNAP-invoice-20260514-01   # prior snapshot
  - RT-RULESET-invoice-20260521
  - PIPELINE-invoice-PL-invoice-202621
```

**Anti-pattern**: Omitting the prior snapshot from `cross_artifact_refs` — the audit trail cannot reconstruct the incremental chain if the prior snapshot is not referenced.
