---
name: context-memory
display_name: 上下文记忆 / Context Memory
description: build cold-start context snapshots and continuity memory for platform routing workflows. use when Claude needs to preserve state, decisions, blockers, or PM overrides across sessions. trigger for cold-start recovery or snapshot management. not for route selection (use skill-routing-selection) or pipeline orchestration (use multi-skill-orchestration).
---

# Context Memory

## N370 v1.1.0 contract baseline
- contract_version: `n370-platform-v1.1.1`
- workflow node: `N370`
- skill_id: `144`
- schema: `n370.context-memory.v2`
- artifact target: `context-snapshot.yaml`
- composition_role: `continuity_memory_owner`
- function_bias: `snapshot`
- dsl_used: `snapshot_7_fields`

This skill is self-contained. It can run alone with partial evidence, and it becomes stronger when composed with the other N370 skills through `pipeline_scope`, stable IDs, `cross_artifact_refs`, and `downstream_handoff`.

## References
Read these files when their rules are relevant:
- `references/n370-shared-platform-contract.md`
- `references/n370-id-space.md`
- `references/output-contract.yaml`
- `references/context-memory-quality-checklist.md`
- `references/snapshot-contract.md`
- `references/cold-start-checklist.md`
- `references/audit-alignment.md`

## Inline field contract

Primary artifact: `context-snapshot.yaml`

| field | required | description |
| --- | --- | --- |
| `pipeline_scope` | required | scope identifier shared with sibling N370 artifacts |
| `snapshot_id` | required | stable snapshot identifier — never fabricate |
| `state_summary` | required | current workflow state in snapshot_7_fields DSL |
| `decisions` | required | decisions made since last snapshot |
| `blockers` | required | active blockers or `none` |
| `deferred_work` | required | work items deferred to a future session |
| `open_questions` | required | unresolved questions |
| `pm_overrides` | required | PM-level overrides applied |
| `cross_artifact_refs` | required | references to sibling N370 artifacts by artifact_id |
| `downstream_handoff` | required | handoff target for N380 or N390 |
| `readiness` | required | `ready\|partial\|needs_human_review` |

Full schema in `references/output-contract.yaml`. Self-check: run `scripts/validate_release_consistency.py` and the relevant per-artifact validator before finalizing.

## Standalone and composition role
Standalone use:
- Produce `context-snapshot.yaml` from the user's provided context, even if sibling N370 artifacts are missing.
- When evidence is incomplete, keep the output usable by setting `readiness: partial`, adding `pending_clarifications`, and preserving stable upstream IDs.

Composition use:
- 143 owns route selection and fallback chain.
- 144 owns cold-start memory and stable snapshot continuity.
- 145 owns multi-skill execution order, timeouts, fallback, and compensation.
- 146 owns state and transition definitions.
- Do not duplicate a sibling artifact; reference it with `cross_artifact_refs`.

## Selected modes
Use one of these modes and write it in metadata:
- `snapshot_mode`
- `quick_view_mode`
- `delta_mode`
- `cold_start_recovery_mode`

## Output contract
When the result will be reused by another skill, engine, or reviewer, emit:
1. the canonical YAML artifact matching `n370.context-memory.v2`;
2. a sidecar `.metadata.yaml` following `references/n370-shared-platform-contract.md`;
3. `downstream_handoff` when a sibling skill, N380, N390, or a governance engine should consume it.

## Workflow
1. Identify the target consumer and whether the request is standalone or part of an N370 composition path.
2. Preserve upstream IDs from N320/N330/N340/N350/N360 before creating new N370 IDs.
3. Assign `pipeline_scope` before writing route, snapshot, pipeline, or state artifacts.
4. Choose the narrowest selected mode that fits the evidence.
5. Build the canonical YAML artifact using the skill's schema and bundled references.
6. Add a sidecar metadata file with evidence, confidence, pending fields, cross-artifact refs, and handoff.
7. Run the bundled validator when producing a machine-readable artifact.
8. Run the quality checklist before returning the result.

## Strict boundaries
- Do not perform the downstream business skill's substantive analysis; coordinate routes, memory, pipelines, and states.
- Do not put prose inside DSL fields.
- Do not fabricate pipeline, route, state, transition, or snapshot IDs.
- Do not reference the current artifact in its own `cross_artifact_refs`.
- Do not rely on external node-level assets.

## Sibling skills quick reference

| skill | owns | use instead when |
| --- | --- | --- |
| `skill-routing-selection` (143) | route selection and fallback chain | routing rules or skill-selection logic is needed |
| `context-memory` (144) | cold-start memory and snapshot continuity | cross-session state or PM overrides need preserving |
| `multi-skill-orchestration` (145) | execution order, timeouts, fallback, compensation | multi-step pipeline sequencing is needed |
| `state-transition-mapping` (146) | state and transition definitions | workflow states or guard DSL need formalizing |

Compose through `cross_artifact_refs` and `downstream_handoff`; never duplicate a sibling artifact.

## Inline quality checklist

Quick self-check before delivery (full checklist in `references/context-memory-quality-checklist.md`):

Before finalizing any N370 artifact, confirm:
- [ ] `pipeline_scope` is assigned and shared across all N370 artifacts in this run
- [ ] All IDs (`route_id`, `snapshot_id`, `pipeline_id`, `state_id`) are stable and not fabricated
- [ ] No prose is placed inside DSL fields
- [ ] `cross_artifact_refs` does not reference the current artifact's own `artifact_id`
- [ ] `readiness` is set to `partial` when any required field is `待确认`
- [ ] `downstream_handoff` is populated when a sibling skill, N380, or N390 will consume this artifact
- [ ] Upstream IDs from N320–N360 are preserved in `upstream_id_aliases`

If the output is machine-readable, run `scripts/validate_snapshot.py` against the artifact before finalizing.

## Examples
Use `examples/platform-cold-start-snapshot.yaml` as the canonical machine artifact and `examples/platform-cold-start-snapshot.metadata.yaml` as its sidecar metadata and handoff example. Differences from the examples are allowed when the user's source material requires them, but field names, metadata order, ID style, cross-reference rules, and handoff shape should stay compatible.

## New validators (v1.1.1+)

- `scripts/validate_metadata.py` — checks sidecar contract_version, artifact_id prefix, and field completeness.
- `scripts/validate_skill_md.py` — prevents stale contract_version heading in SKILL.md.
- `scripts/validate_release_consistency.py` — single-skill and four-skill suite version alignment.
- `scripts/validate_cascade.py` — verifies coherent pipeline_id and schema across all four N370 artifacts.

## Quality check
Use `references/context-memory-quality-checklist.md`. If the output is machine-readable, run `scripts/validate_snapshot.py` against the artifact before finalizing.
