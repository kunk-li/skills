---
name: context-memory
description: build stable cold-start context snapshots and continuity memory for platform routing workflows. use when chatgpt needs to preserve state, decisions, blockers, risks, deferred work, open questions, and pm overrides across sessions while keeping route and pipeline ids reusable.
---

# Context Memory

## N370 v1.1.0 contract baseline
- contract_version: `n370-platform-v1.1.1`
- workflow node: `N370`
- skill_id: `144`
- schema: `n370.context-memory.v2`
- artifact target: `context-snapshot.yaml`
- composition_role: `continuity_memory_owner`
- function_bias: `snapshot`
- dsl_used: `snapshot_7_fields`

This skill is self-contained. It can run alone with partial evidence, and it becomes stronger when composed with the other N370 skills through `pipeline_scope`, stable IDs, `cross_artifact_refs`, and `downstream_handoff`.

## References
Read these files when their rules are relevant:
- `references/n370-shared-platform-contract.md`
- `references/n370-id-space.md`
- `references/output-contract.yaml`
- `references/context-memory-quality-checklist.md`
- `references/snapshot-contract.md`
- `references/cold-start-checklist.md`
- `references/audit-alignment.md`

## Standalone and composition role
Standalone use:
- Produce `context-snapshot.yaml` from the user's provided context, even if sibling N370 artifacts are missing.
- When evidence is incomplete, keep the output usable by setting `readiness: partial`, adding `pending_clarifications`, and preserving stable upstream IDs.

Composition use:
- 143 owns route selection and fallback chain.
- 144 owns cold-start memory and stable snapshot continuity.
- 145 owns multi-skill execution order, timeouts, fallback, and compensation.
- 146 owns state and transition definitions.
- Do not duplicate a sibling artifact; reference it with `cross_artifact_refs`.

## Selected modes
Use one of these modes and write it in metadata:
- `snapshot_mode`
- `quick_view_mode`
- `delta_mode`
- `cold_start_recovery_mode`

## Output contract
When the result will be reused by another skill, engine, or reviewer, emit:
1. the canonical YAML artifact matching `n370.context-memory.v2`;
2. a sidecar `.metadata.yaml` following `references/n370-shared-platform-contract.md`;
3. `downstream_handoff` when a sibling skill, N380, N390, or a governance engine should consume it.

## Workflow
1. Identify the target consumer and whether the request is standalone or part of an N370 composition path.
2. Preserve upstream IDs from N320/N330/N340/N350/N360 before creating new N370 IDs.
3. Assign `pipeline_scope` before writing route, snapshot, pipeline, or state artifacts.
4. Choose the narrowest selected mode that fits the evidence.
5. Build the canonical YAML artifact using the skill's schema and bundled references.
6. Add a sidecar metadata file with evidence, confidence, pending fields, cross-artifact refs, and handoff.
7. Run the bundled validator when producing a machine-readable artifact.
8. Run the quality checklist before returning the result.

## Strict boundaries
- Do not perform the downstream business skill's substantive analysis; coordinate routes, memory, pipelines, and states.
- Do not put prose inside DSL fields.
- Do not fabricate pipeline, route, state, transition, or snapshot IDs.
- Do not reference the current artifact in its own `cross_artifact_refs`.
- Do not rely on external node-level assets.

## Examples
Use `examples/platform-cold-start-snapshot.yaml` as the canonical machine artifact and `examples/platform-cold-start-snapshot.metadata.yaml` as its sidecar metadata and handoff example. Differences from the examples are allowed when the user's source material requires them, but field names, metadata order, ID style, cross-reference rules, and handoff shape should stay compatible.

## Quality check
Use `references/context-memory-quality-checklist.md`. If the output is machine-readable, run `scripts/validate_snapshot.py` against the artifact before finalizing.
