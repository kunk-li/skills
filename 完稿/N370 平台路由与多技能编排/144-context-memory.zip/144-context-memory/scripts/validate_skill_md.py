#!/usr/bin/env python3
"""Check that SKILL.md contract_version heading matches the expected N370 contract version."""
from __future__ import annotations
import re, sys
from pathlib import Path
from n370_validators_common import CONTRACT_VERSION, print_errors


def main(path: Path) -> int:
    errors = []
    text = path.read_text(encoding="utf-8")
    if CONTRACT_VERSION not in text:
        errors.append(
            f"SKILL.md does not contain expected contract_version {CONTRACT_VERSION!r}. "
            "Check for stale version heading."
        )
    if print_errors(errors):
        return 1
    print(f"OK: {path} contains correct contract_version")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python validate_skill_md.py SKILL.md")
        sys.exit(1)
    raise SystemExit(main(Path(sys.argv[1])))
