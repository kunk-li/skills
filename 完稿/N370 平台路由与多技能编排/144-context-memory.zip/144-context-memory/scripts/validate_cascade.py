#!/usr/bin/env python3
"""
N370 four-skill cascade validator.
Verifies that a route-rules artifact (143), context snapshot (144),
orchestration pipeline (145), and state-transition map (146)
form a coherent cascade: shared pipeline_scope IDs, no dangling references,
and downstream_handoff targets that exist within the suite.

Usage:
    python validate_cascade.py \
        <routes.yaml> <snapshot.yaml> <pipeline.yaml> <state-map.yaml>
"""
from __future__ import annotations
import sys
from pathlib import Path
import yaml


def load(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


SCHEMA_MAP = {
    0: "n370.skill-routing-selection.v2",
    1: "n370.context-memory.v2",
    2: "n370.multi-skill-orchestration.v2",
    3: "n370.state-transition-mapping.v2",
}

LABELS = ["143 routes", "144 snapshot", "145 pipeline", "146 state-map"]


def extract_pipeline_id(data: dict, label: str) -> str | None:
    """Best-effort extraction of a pipeline_id from any N370 artifact."""
    # routes.yaml: data.routes[n].pipeline_id
    if "routes" in data and isinstance(data["routes"], list):
        for r in data["routes"]:
            if "pipeline_id" in r:
                return str(r["pipeline_id"])
    # snapshot.yaml: data.state.pipeline_id or data.pipeline_scope.pipeline_id
    for key in ("pipeline_scope", "state"):
        sub = data.get(key)
        if isinstance(sub, dict) and "pipeline_id" in sub:
            return str(sub["pipeline_id"])
    # pipeline.yaml: data.pipeline_id
    if "pipeline_id" in data:
        return str(data["pipeline_id"])
    return None


def main() -> int:
    if len(sys.argv) != 5:
        print(
            "Usage: python validate_cascade.py "
            "<routes.yaml> <snapshot.yaml> <pipeline.yaml> <state-map.yaml>"
        )
        return 1

    paths = [Path(a) for a in sys.argv[1:]]
    artifacts = [load(p) for p in paths]
    errors = []

    # 1. Schema check
    for idx, (art, path) in enumerate(zip(artifacts, paths)):
        expected = SCHEMA_MAP[idx]
        actual = art.get("schema")
        if actual != expected:
            errors.append(
                f"{LABELS[idx]}: schema must be {expected!r}, got {actual!r} ({path.name})"
            )

    # 2. Pipeline ID coherence (best-effort; unknown values are skipped)
    pipeline_ids = []
    for idx, (art, lbl) in enumerate(zip(artifacts, LABELS)):
        pid = extract_pipeline_id(art, lbl)
        if pid and pid != "unknown":
            pipeline_ids.append(pid)

    unique_pids = set(pipeline_ids)
    if len(unique_pids) > 1:
        errors.append(
            f"pipeline_id mismatch across cascade: {sorted(unique_pids)}. "
            "All four artifacts should share the same pipeline_id."
        )

    # 3. Self-referencing artifact_id in cross_artifact_refs (metadata block)
    for idx, (art, path) in enumerate(zip(artifacts, paths)):
        meta = art.get("metadata") if isinstance(art.get("metadata"), dict) else {}
        aid = meta.get("artifact_id") or art.get("artifact_id")
        refs = list(meta.get("cross_artifact_refs") or art.get("cross_artifact_refs") or [])
        if aid and aid in refs:
            errors.append(f"{LABELS[idx]}: self-reference in cross_artifact_refs ({aid})")

    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        return 1

    print("OK: N370 four-skill cascade is coherent")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
