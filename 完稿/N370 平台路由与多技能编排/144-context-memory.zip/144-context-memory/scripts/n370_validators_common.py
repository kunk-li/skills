#!/usr/bin/env python3
"""Shared helpers for N370 platform validation scripts."""
from __future__ import annotations
import re
import sys
from pathlib import Path
import yaml

CONTRACT_VERSION = "n370-platform-v1.1.1"
WORKFLOW_NODE = "N370"
ARTIFACT_FAMILY_ID = "n370-platform-foundation-suite"

READINESS = {"draft", "partial", "ready", "blocked"}
CONFIDENCE = {"high", "medium", "low"}
CONFIDENTIALITY = {"public_internal", "restricted_internal", "confidential"}
ENGINE_CONSUMABLE = {"yaml", "json", "both", "no"}

SKILL_ID_TO_ARTIFACT_PREFIX = {
    "143": re.compile(r"^RT-RULESET-"),
    "144": re.compile(r"^SNAP-"),
    "145": re.compile(r"^PIPELINE-"),
    "146": re.compile(r"^STM-"),
}

REQUIRED_METADATA_FIELDS = [
    "contract_version", "workflow_node", "skill_id", "skill_name",
    "artifact_family_id", "artifact_id", "schema", "selected_mode",
    "readiness", "pipeline_scope", "source_artifacts", "evidence_refs",
    "cross_artifact_refs", "confidence",
]

REQUIRED_HANDOFF_FIELDS = ["contract_version", "consumer_skill_or_node"]


def load_yaml_like(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    data = yaml.safe_load(text)
    if not isinstance(data, dict):
        raise ValueError(f"{path}: root must be a YAML mapping, got {type(data)}")
    return data


def print_errors(errors: list[str]) -> int:
    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        return 1
    return 0
