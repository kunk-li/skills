#!/usr/bin/env python3
"""Validate a single N370 sidecar metadata file."""
from __future__ import annotations
import sys
from pathlib import Path
from n370_validators_common import (
    load_yaml_like, CONTRACT_VERSION, WORKFLOW_NODE, ARTIFACT_FAMILY_ID,
    READINESS, CONFIDENCE, CONFIDENTIALITY, ENGINE_CONSUMABLE,
    SKILL_ID_TO_ARTIFACT_PREFIX, REQUIRED_METADATA_FIELDS, REQUIRED_HANDOFF_FIELDS,
    print_errors,
)


def main(path: Path) -> int:
    errors = []
    data = load_yaml_like(path)
    md = data.get("metadata", {}) if isinstance(data, dict) else {}
    handoff = data.get("downstream_handoff", {}) if isinstance(data, dict) else {}

    missing = sorted(set(REQUIRED_METADATA_FIELDS) - set(md.keys()))
    if missing:
        errors.append(f"metadata missing required fields: {missing}")

    if md.get("contract_version") != CONTRACT_VERSION:
        errors.append(f"metadata.contract_version must be {CONTRACT_VERSION!r}, got {md.get('contract_version')!r}")
    if md.get("workflow_node") != WORKFLOW_NODE:
        errors.append(f"workflow_node must be {WORKFLOW_NODE!r}")
    if md.get("artifact_family_id") != ARTIFACT_FAMILY_ID:
        errors.append(f"artifact_family_id must be {ARTIFACT_FAMILY_ID!r}")

    skill_id = str(md.get("skill_id", ""))
    artifact_id = str(md.get("artifact_id", ""))
    if skill_id in SKILL_ID_TO_ARTIFACT_PREFIX:
        pat = SKILL_ID_TO_ARTIFACT_PREFIX[skill_id]
        if artifact_id and not pat.match(artifact_id):
            errors.append(f"artifact_id {artifact_id!r} does not match expected prefix for skill {skill_id}")

    cross_refs = md.get("cross_artifact_refs") or []
    if artifact_id and artifact_id in cross_refs:
        errors.append("cross_artifact_refs must not include own artifact_id")

    if "readiness" in md and md.get("readiness") not in READINESS:
        errors.append(f"readiness must be one of {sorted(READINESS)}")
    if "confidence" in md and md.get("confidence") not in CONFIDENCE:
        errors.append(f"confidence must be one of {sorted(CONFIDENCE)}")
    if "confidentiality_level" in md and md.get("confidentiality_level") not in CONFIDENTIALITY:
        errors.append(f"confidentiality_level must be one of {sorted(CONFIDENTIALITY)}")
    if "engine_consumable" in md and md.get("engine_consumable") not in ENGINE_CONSUMABLE:
        errors.append(f"engine_consumable must be one of {sorted(ENGINE_CONSUMABLE)}")

    if handoff:
        hmissing = sorted(set(REQUIRED_HANDOFF_FIELDS) - set(handoff.keys()))
        if hmissing:
            errors.append(f"downstream_handoff missing required fields: {hmissing}")
        if handoff.get("contract_version") != CONTRACT_VERSION:
            errors.append("downstream_handoff.contract_version mismatch")

    if print_errors(errors):
        return 1
    print(f"OK: {path} passes N370 metadata contract")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python validate_metadata.py <artifact.metadata.yaml>")
        sys.exit(1)
    raise SystemExit(main(Path(sys.argv[1])))
