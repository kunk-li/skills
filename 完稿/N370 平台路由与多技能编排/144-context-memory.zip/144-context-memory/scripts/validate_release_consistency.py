#!/usr/bin/env python3
"""
N370 release consistency validator.
Checks that all four N370 skill metadata files share the same contract_version,
SKILL.md files contain the right contract version heading, and no artifact has
a self-referencing cross_artifact_refs.

Usage:
    python validate_release_consistency.py \
        <143.metadata.yaml> <144.metadata.yaml> \
        <145.metadata.yaml> <146.metadata.yaml>

Or run from inside a single skill directory to check just that skill:
    python validate_release_consistency.py .
"""
from __future__ import annotations
import subprocess, sys
from pathlib import Path
from n370_validators_common import load_yaml_like, CONTRACT_VERSION, print_errors


def run(cmd: list) -> list[str]:
    p = subprocess.run(cmd, text=True, capture_output=True)
    if p.returncode != 0:
        return [p.stderr.strip() or p.stdout.strip() or f"failed: {' '.join(map(str, cmd))}"]
    return []


def skill_dir_from_meta(meta: Path) -> Path:
    return meta.parent.parent


def check_single_skill(skill_dir: Path) -> int:
    errors = []
    skill_md = skill_dir / "SKILL.md"
    metas = list((skill_dir / "examples").glob("*.metadata.yaml"))

    # Check SKILL.md version
    for e in run([sys.executable, str(skill_dir / "scripts" / "validate_skill_md.py"), str(skill_md)]):
        errors.append(f"SKILL.md: {e}")

    # Check each metadata sidecar
    for meta in metas:
        for e in run([sys.executable, str(skill_dir / "scripts" / "validate_metadata.py"), str(meta)]):
            errors.append(f"{meta.name}: {e}")

    if print_errors(errors):
        return 1
    print(f"OK: {skill_dir.name} passes single-skill release consistency")
    return 0


def check_four_skill_suite(meta_paths: list[Path]) -> int:
    errors = []
    labels = ["143", "144", "145", "146"]
    data = []

    for label, m in zip(labels, meta_paths):
        md = load_yaml_like(m).get("metadata", {})
        data.append(md)
        if md.get("contract_version") != CONTRACT_VERSION:
            errors.append(
                f"{label}: contract_version {md.get('contract_version')!r} "
                f"does not match expected {CONTRACT_VERSION!r}"
            )

    versions = {d.get("contract_version") for d in data}
    if versions != {CONTRACT_VERSION}:
        errors.append(f"contract_version mismatch across N370 family: {sorted(str(v) for v in versions)}")
        return print_errors(errors)

    for label, m in zip(labels, meta_paths):
        root = skill_dir_from_meta(m)
        cmds = [
            [sys.executable, str(root / "scripts" / "validate_skill_md.py"), str(root / "SKILL.md")],
            [sys.executable, str(root / "scripts" / "validate_metadata.py"), str(m)],
        ]
        for cmd in cmds:
            for e in run(cmd):
                errors.append(f"{label}: {e}")

    # Cross-artifact self-reference check
    ids = {d.get("artifact_id") for d in data}
    for d in data:
        aid = d.get("artifact_id")
        refs = set(d.get("cross_artifact_refs") or [])
        if aid in refs:
            errors.append(f"{aid}: self-reference in cross_artifact_refs")

    if print_errors(errors):
        return 1
    print("OK: N370 four-skill suite passes release consistency")
    return 0


def main() -> int:
    args = sys.argv[1:]
    if len(args) == 1 and Path(args[0]).is_dir():
        return check_single_skill(Path(args[0]))
    if len(args) == 4:
        return check_four_skill_suite([Path(a) for a in args])
    print(
        "Usage:\n"
        "  python validate_release_consistency.py .  (single skill dir)\n"
        "  python validate_release_consistency.py 143.meta.yaml 144.meta.yaml "
        "145.meta.yaml 146.meta.yaml  (four-skill suite)"
    )
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
