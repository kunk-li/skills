# Integration Examples / 集成示例

This directory contains a four-artifact integration example demonstrating how all four N370 skills work together in a single pipeline.

## Invoice Delta-Refresh Pipeline (PL-invoice-202621)

These four artifacts form a coherent cascade for the `PL-invoice-202621` pipeline:

| Skill | Artifact | File |
| --- | --- | --- |
| 143 skill-routing-selection | RT-RULESET-invoice-20260521 | `143-route-rules.yaml` + `.metadata.yaml` |
| 144 context-memory | SNAP-invoice-20260521-02 | `144-context-snapshot.yaml` + `.metadata.yaml` |
| 145 multi-skill-orchestration | PIPELINE-invoice-incremental-202621 | `145-pipeline.yaml` + `.metadata.yaml` |
| 146 state-transition-mapping | STM-invoice-PL-invoice-incremental-202621-01 | `146-state-map.yaml` + `.metadata.yaml` |

## Validate the cascade

```bash
python scripts/validate_cascade.py \
    examples/integration/143-route-rules.yaml \
    examples/integration/144-context-snapshot.yaml \
    examples/integration/145-pipeline.yaml \
    examples/integration/146-state-map.yaml
```

All four artifacts share `pipeline_id: PL-invoice-202621` and reference each other via `cross_artifact_refs`. Run from any N370 skill directory — the `validate_cascade.py` script is bundled in each.
