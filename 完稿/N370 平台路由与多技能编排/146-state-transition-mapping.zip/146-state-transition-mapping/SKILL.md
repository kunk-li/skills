---
name: state-transition-mapping
description: map workflow states and transitions into machine-consumable state maps. use when chatgpt needs state ids, transition ids, trigger types, guard dsl, mode selection, state-machine handoffs, or engine-ready state transition artifacts.
---

# State Transition Mapping

## N370 v1.1.0 contract baseline
- contract_version: `n370-platform-v1.1.1`
- workflow node: `N370`
- skill_id: `146`
- schema: `n370.state-transition-mapping.v2`
- artifact target: `state-transition-map.yaml`
- composition_role: `state_transition_source_of_truth`
- function_bias: `state_machine`
- dsl_used: `guard_dsl`

This skill is self-contained. It can run alone with partial evidence, and it becomes stronger when composed with the other N370 skills through `pipeline_scope`, stable IDs, `cross_artifact_refs`, and `downstream_handoff`.

## References
Read these files when their rules are relevant:
- `references/n370-shared-platform-contract.md`
- `references/n370-id-space.md`
- `references/output-contract.yaml`
- `references/state-transition-mapping-quality-checklist.md`
- `references/field-contract.md`
- `references/mode-selection.md`
- `references/transition-dsl.md`
- `references/output-template.md`
- `references/cross-skill-orchestration.md`

## Standalone and composition role
Standalone use:
- Produce `state-transition-map.yaml` from the user's provided context, even if sibling N370 artifacts are missing.
- When evidence is incomplete, keep the output usable by setting `readiness: partial`, adding `pending_clarifications`, and preserving stable upstream IDs.

Composition use:
- 143 owns route selection and fallback chain.
- 144 owns cold-start memory and stable snapshot continuity.
- 145 owns multi-skill execution order, timeouts, fallback, and compensation.
- 146 owns state and transition definitions.
- Do not duplicate a sibling artifact; reference it with `cross_artifact_refs`.

## Selected modes
Use one of these modes and write it in metadata:
- `review`
- `handoff`
- `system`
- `full`

## Output contract
When the result will be reused by another skill, engine, or reviewer, emit:
1. the canonical YAML artifact matching `n370.state-transition-mapping.v2`;
2. a sidecar `.metadata.yaml` following `references/n370-shared-platform-contract.md`;
3. `downstream_handoff` when a sibling skill, N380, N390, or a governance engine should consume it.

## Workflow
1. Identify the target consumer and whether the request is standalone or part of an N370 composition path.
2. Preserve upstream IDs from N320/N330/N340/N350/N360 before creating new N370 IDs.
3. Assign `pipeline_scope` before writing route, snapshot, pipeline, or state artifacts.
4. Choose the narrowest selected mode that fits the evidence.
5. Build the canonical YAML artifact using the skill's schema and bundled references.
6. Add a sidecar metadata file with evidence, confidence, pending fields, cross-artifact refs, and handoff.
7. Run the bundled validator when producing a machine-readable artifact.
8. Run the quality checklist before returning the result.

## Strict boundaries
- Do not perform the downstream business skill's substantive analysis; coordinate routes, memory, pipelines, and states.
- Do not put prose inside DSL fields.
- Do not fabricate pipeline, route, state, transition, or snapshot IDs.
- Do not reference the current artifact in its own `cross_artifact_refs`.
- Do not rely on external node-level assets.

## Examples
Use `examples/platform-state-machine.yaml` as the canonical machine artifact and `examples/platform-state-machine.metadata.yaml` as its sidecar metadata and handoff example. Differences from the examples are allowed when the user's source material requires them, but field names, metadata order, ID style, cross-reference rules, and handoff shape should stay compatible.

## Quality check
Use `references/state-transition-mapping-quality-checklist.md`. If the output is machine-readable, run `scripts/validate_state_map.py` against the artifact before finalizing.
