# Real Examples / 真实示例参考

These examples illustrate correctly formed state-transition map artifacts and common edge cases. Use them alongside the bundled `examples/` files and `examples/integration/`.

---

## Example 1: Guard DSL must use only allowed functions

**Input**: A state transition fires when a pipeline has no open blockers and has a complete route artifact.

**Correct guard_dsl**:
```yaml
guard_dsl: has("route-rules.yaml") and count(open_blockers) == 0
```

**Anti-pattern**: Writing `open_blockers == 0` — the `==` operator alone is not in the AST whitelist. Always wrap count-based checks with `count()`. Only `has()`, `contains()`, and `count()` are permitted.

---

## Example 2: Terminal state is required for handoff transitions

**Input**: The final transition routes to N380. The state machine needs a defined terminal state to avoid leaving the pipeline in a dangling state.

**Correct pattern**:
```yaml
states:
  - state_id: N370.PL-invoice-202621.ST-TERMINAL
    name: handed_off_to_n380
    definition: All pipeline artifacts complete; handed off to N380 gate.
    constraints: [no further N370 edits after handoff]
    evidence: [EV-invoice-delta-001]
    confidence: explicit

transitions:
  - transition_id: N370.PL-invoice-202621.TR-03
    state_from: N370.PL-invoice-202621.ST-03
    state_to: N370.PL-invoice-202621.ST-TERMINAL
    guard_dsl: has("state-transition-map.yaml") and count(open_blockers) == 0
```

**Anti-pattern**: Referencing an external state (like `N380.gate_review`) in `state_to` — the validator only accepts state_ids defined within the artifact's own `states` list. Use a local terminal state and document the handoff in `downstream_handoff`.

---

## Example 3: Full mode vs handoff mode — choose based on evidence

**Input**: A sprint has complete route artifacts and context; the team needs a full state review before gate submission.

**Correct mode selection**:
```yaml
mode: full
summary: Complete state map covering delta snapshot, route refresh, and N380 gate handoff.
```

**When to use handoff mode instead**: If the artifact is incomplete or the team only needs to document the handoff path without mapping internal states, use `mode: handoff` and set `readiness: partial`. Do not use `mode: full` when states or transitions are inferred without evidence — mark those with `confidence: inferred` and add `open_questions`.
