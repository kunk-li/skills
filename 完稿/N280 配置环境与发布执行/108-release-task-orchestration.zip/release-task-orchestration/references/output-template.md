# output-template — release-exec skill artifacts

This template defines common metadata patterns for all three release-exec skill artifacts.

## Shared metadata block
```yaml
artifact_contract:
  schema_version: release-exec.<skill-name>.v2.2.1
  artifact_type: <artifact_type>
  producer_skill: <skill-name>
  workflow_node: release-exec
  produced_event: produced.release-exec.<artifact_type>.v2
  event_delivery: declared_only
  subscribers_hint: [release-validation, deployment, infra, notifications, reporting]
```

## readiness values
- `green` — all required sections present, no P0/critical blockers, self-check passes
- `amber` — partial evidence; output stable but confidence reduced; some items constrained
- `red` — hard blocker present; deploy-phase tasks must not proceed
- `constrained` — evidence available but incomplete for a specific dimension

## downstream_handoff pattern
```yaml
downstream_handoff:
  target: <next-skill-or-node>
  readiness_inherited: <green | amber | red>
  blockers: []
  config_state:    # 106 → 107 → 108 handoff field
    reload_actions: []
    overall_ready_to_proceed: true | false
  environment_state:  # 107 → 108 handoff field
    parity_verdict: full | partial | not_assessed
    overall_ready_to_proceed: true | false
  missing_evidence: []
  next_best_checks: []
```

## self_check pattern
```yaml
self_check:
  passed: true | false
  failed_rules: []
  quality_check_failures: []
  schema_version_verified: true
  produced_event_declared: true
  no_plaintext_secrets: true
```


---

## Downstream handoff YAML templates

### 正常路径：108 → 109 移交，DAG completed
```yaml
downstream_handoff:
  produced_by: release-task-orchestration
  artifact: 发布任务编排表.csv
  produced_event: produced.release-exec.release_task_orchestration.v2
  handoffs:
    - target: post-release-validation-checklist
      handoff_type: evidence
      summary: "DAG completed: 8 tasks, all P3 tasks passed, T+34min. Now ready for post-deploy validation."
      required_fields:
        - dag_overview.execution_status
        - task_registry  # for PRV items to reference
        - circuit_breaker.triggered
      confidence: high
      next_best_checks:
        - "109: start PRV immediately — monitoring window is active"
        - "109: use task_registry to verify each service has deployed successfully"
  refresh_triggers:
    - skill: post-release-validation-checklist
      reason: "Task execution outcome changed — PRV must re-evaluate"
      condition: "any task status changed after initial 109 run"
```

### 阻断路径：circuit breaker triggered → 108 halted
```yaml
downstream_handoff:
  handoffs:
    - target: rollback-plan-generation
      handoff_type: action_hint
      summary: "URGENT: circuit_breaker triggered at T003. Initiate rollback immediately."
      required_fields: [pipeline_level_circuit_breaker, halted_at_task, task_registry]
      blocking: true
      urgency: immediate
    - target: on-call-response-recommendation
      handoff_type: routing
      summary: "Release execution halted — active incident response needed"
      urgency: immediate
```


---

## Standalone guarantee — run 108 without 106 or 107
108 is independently useful with only a release description. Do not refuse output because upstream release-exec artifacts are missing.

### Minimum viable standalone inputs
- release identity and service name
- target environment (prod, staging, or named env)
- at least one of: release notes, checklist, change description, or rollout scope

### Standalone simple_sequential example — no 106 or 107
```yaml
metadata:
  readiness: amber
  selected_mode: simple_sequential
evidence_profile:
  confirmed: [release_description]
  missing_evidence: [configuration-change-check, environment-difference-check]
  missing_evidence_impact: "Config reload mode and environment parity unknown. Conservative sequential mode applied. All tasks require manual confirmation gates."
dag_overview:
  total_tasks: 5
  parallelism: disabled
  mode: conservative_sequential
  note: "Safe sequential order used because 106 and 107 are absent."
task_registry:
  - task_id: T01
    task_name: pre-deploy approval
    phase: P1_prepare
    task_kind: manual_approval
    owner: release-manager
    dependencies: []
    precondition_status: ready
    timeout: 30m
    on_failure: abort
    resumability: idempotent
  - task_id: T02
    task_name: apply config changes
    phase: P2_pre_stage
    task_kind: apply_config
    owner: devops-team
    dependencies: [T01]
    precondition_status: unresolved
    precondition_note: "reload_mode unknown — 106 not provided. Treat as full_restart."
    timeout: 20m
    on_failure: rollback
    resumability: idempotent
  - task_id: T03
    task_name: deploy application
    phase: P3_execute
    task_kind: deploy_application
    owner: devops-team
    dependencies: [T02]
    precondition_status: unresolved
    precondition_note: "environment parity not confirmed — 107 not provided."
    timeout: 45m
    on_failure: rollback
    resumability: restart_from_task
  - task_id: T04
    task_name: run smoke tests
    phase: P4_verify
    task_kind: run_smoke_tests
    owner: qa-team
    dependencies: [T03]
    precondition_status: ready
    timeout: 15m
    on_failure: rollback
    resumability: idempotent
  - task_id: T05
    task_name: stabilization observation window
    phase: P5_stabilize
    task_kind: wait_and_observe
    owner: oncall
    dependencies: [T04]
    precondition_status: ready
    timeout: 30m
    on_failure: escalate
    resumability: continue
pipeline_level_circuit_breaker:
  enabled: true
  triggers: [critical_blocker_present, repeated_retry_failure, slo_verification_failed]
  threshold: 1
  action: halt_pipeline
  resume_authority: [release_manager, oncall]
blockers_and_pending:
  - item: "106 configuration-change-check not provided"
    severity: P1
    action: "Run configuration-change-check before next release to enable reload-mode-aware sequencing"
  - item: "107 environment-difference-check not provided"
    severity: P1
    action: "Run environment-difference-check to verify staging/prod parity"
downstream_handoff:
  target: release-validation
  checkpoint_and_resume_rules:
    resume_from: last_completed_task
    state_key: release-task-orchestration-state
  missing_evidence: [configuration-change-check, environment-difference-check]
self_check:
  passed: true
  failed_rules: []
  warnings: ["106 and 107 absent — conservative sequential mode, manual gates required"]
```

### Pipeline contract mode example — 106 + 107 both present
```yaml
metadata:
  readiness: green
  selected_mode: pipeline_contract_mode
evidence_profile:
  confirmed: [configuration-change-check, environment-difference-check, release_notes]
  missing_evidence: []
dag_overview:
  total_tasks: 8
  parallelism: enabled
  note: "106 reload_mode and 107 overall_ready_to_proceed consumed. Parallel deploy allowed for independent services."
task_registry:
  - task_id: T01
    task_name: validate config preconditions
    phase: P1_prepare
    task_kind: manual_approval
    owner: release-manager
    precondition_status: ready
    precondition_source: "106 config_state.overall_ready_to_proceed=true"
  - task_id: T02
    task_name: rolling restart payment-service
    phase: P3_execute
    task_kind: deploy_application
    owner: devops-team
    dependencies: [T01]
    precondition_status: ready
    precondition_source: "106 reload_mode=rolling_restart for db.pool.max-size"
    timeout: 30m
    on_failure: rollback
    resumability: restart_from_task
```

---

## Output completeness rule
Every release-task-orchestration artifact MUST include:
- `dag_overview.selected_mode` declared
- `task_registry` with ≥ 1 P3_execute task; each task has `on_failure` + `resumability` + `timeout`
- Every approval gate has `on_timeout` declared
- `pipeline_level_circuit_breaker` with ≥ 1 trigger + `cooldown` ISO 8601
- Rollback tasks present as P5_stabilize when rollback_plan was consumed
- `downstream_handoff` to post-release-validation-checklist
- `feedback_signal_candidates` ≥ 1 with `signal_type`
- `adversarial_detection` with `injection_attempt_detected` boolean

---

## Mode selection

### New: `hotfix_express` mode — 热修复极速编排
**Trigger:** Emergency hotfix needs to deploy in under 30 minutes, or user says "P0 hotfix — fastest possible deployment".

```yaml
hotfix_express:
  time_budget: 30min
  skipped_phases: [P2_pre_stage]  # skip pre-staging for speed
  minimal_gates:
    - gate_id: GATE-HOTFIX-001
      description: "Hotfix risk assessment approved (122 verdict: go/conditional_go)"
      required_evidence: "热修复风险评估.md"
      on_fail: abort
  compressed_dag:
    - task_id: T-HF-001
      action: "Deploy hotfix to production (rolling restart)"
      timeout: PT15M
      on_failure: rollback
    - task_id: T-HF-002
      action: "Smoke test: verify fix resolves incident"
      timeout: PT5M
      on_failure: rollback
  circuit_breaker:
    enabled: true
    trigger: "error_rate > 5% for 2 consecutive minutes"
    action: immediate_rollback
  total_estimated_duration: 25min
```
**SCR:** `selected_mode: hotfix_express` → `hotfix_express.minimal_gates` ≥ 1; `circuit_breaker.enabled: true` always.

### New: `rollback_execution` mode — 执行回滚（仅执行已有方案）
**Trigger:** Rollback decision made by 121/110 and 108 must execute the rollback plan from 105.

```yaml
rollback_execution:
  rollback_plan_source: "回滚预案.md from skill 105"
  active_phase: phase_1
  execution_status:
    phase_1:
      action: "Disable feature flag 'new_checkout_flow'"
      status: executing
      started_at: "2026-05-21T14:05:00Z"
      estimated_completion: "2026-05-21T14:07:00Z"
  remaining_phases: [phase_2]
  abort_if: "error_rate doesn't decrease within 10min of phase_1 completion"
```
**SCR:** `selected_mode: rollback_execution` → `rollback_execution.rollback_plan_source` declared; `active_phase` present.


## CSV 序列化规则(node_artifact_target 是 .csv)

本产物 node_artifact_target 是 `.csv`。必须序列化为**既是合法 CSV、又携带上面契约 metadata 信封**的文件:

1. 把上面完整的 metadata 信封及所有 YAML 块,作为文件开头的注释行输出,每行以 `# ` 前缀。CSV 读取器跳过 `#` 行;信封仍可被 `scripts/validate_artifact.py` 机读校验(该校验器按段名子串匹配,注释头满足全部 REQUIRED 段)。
2. 注释信封之后,再输出表头行 + 表格条目(检查项/测试点/任务行)为标准逗号分隔 CSV 行。
3. 不要输出无注释信封的纯数据 CSV——`validate_artifact.py` 会因缺 metadata/self_check/downstream_handoff/evidence_profile/emit_event(或 produced_event)/adversarial_detection/feedback_signal_candidates 等段判 FAIL。

合法示例骨架:

```
# metadata:
#   skill_id: <skill>
#   node_artifact_target: <本产物>.csv
#   readiness: green
# self_check: {passed: true, failed_rules: []}
# downstream_handoff: {primary_consumers: [...]}
# evidence_profile: {confirmed_evidence: [], assumptions: [], missing_evidence: []}
# emit_event: {event_name: produced.<node>.<artifact>.v2}
# adversarial_detection: none_detected
# feedback_signal_candidates: []
<列头1>,<列头2>,<列头3>
<行数据...>
```
