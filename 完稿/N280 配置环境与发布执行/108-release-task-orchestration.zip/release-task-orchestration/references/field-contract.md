# field-contract — release-task-orchestration

Canonical field definitions for the `release_task_orchestration` artifact produced by this skill.
This file complements `references/release-exec-shared-contract.md`, which defines the shared artifact header.

## Core artifact header fields
See `references/release-exec-shared-contract.md` for the full shared header specification.
| Field | Type | Required | Value |
|---|---|---|---|
| `schema_version` | string | yes | `release-exec.release-task-orchestration.v2.2.1` |
| `artifact_type` | string | yes | `release_task_orchestration` |
| `producer_skill` | string | yes | `release-task-orchestration` |
| `workflow_node` | string | yes | `release-exec` |
| `readiness` | enum | yes | `ready` \| `constrained` \| `blocked` |

## Task (DAG node) fields
| Field | Type | Required | Description |
|---|---|---|---|
| `task_id` | string | yes | Unique task identifier (e.g., `T-P3-001`) |
| `phase` | enum | yes | `P1_prepare` \| `P3_execute` \| `P4_verify` \| `P5_stabilize` |
| `task_name` | string | yes | Human-readable task description |
| `owner` | string | yes | Team or role responsible for this task |
| `depends_on` | string[] | yes | List of `task_id` values that must complete before this task starts (`[]` for root tasks) |
| `timeout_minutes` | integer | yes | Maximum duration before this task is considered failed |
| `on_failure` | enum | yes | `halt` \| `rollback` \| `escalate` \| `retry_once` |
| `approval_gate` | boolean | yes | Whether a human approval is required before this task executes |
| `approval_role` | string | if approval_gate=true | Role that must approve (e.g., `release_manager`, `sre_lead`, `dba`) |
| `resumable` | boolean | yes | Whether this task can be retried from the point of failure |
| `canary_phase_ref` | string | no | Reference to canary stage from canary-release-recommendation (104) if this task is a canary gate |
| `verification_hook` | string | no | Command or check to run after task completion to confirm success |

## DAG-level fields
| Field | Type | Required | Description |
|---|---|---|---|
| `dag_id` | string | yes | Stable identifier for this DAG run (e.g., `DAG-pay-v2.3-20260521`) |
| `execution_window_start` | string | yes | ISO8601 planned start time |
| `execution_window_end` | string | yes | ISO8601 planned end time (hard cutoff — triggers rollback if exceeded) |
| `total_tasks` | integer | yes | Total number of tasks in the DAG |
| `critical_path_tasks` | string[] | yes | `task_id` list forming the critical path (longest dependency chain) |
| `estimated_duration_minutes` | integer | yes | Sum of critical-path task durations |

## Circuit breaker fields
| Field | Type | Required | Description |
|---|---|---|---|
| `circuit_breaker.enabled` | boolean | yes | Always `true` |
| `circuit_breaker.halt_conditions` | string[] | yes | Metric or state conditions that trigger halt |
| `circuit_breaker.cooldown_minutes` | integer | yes | Minutes to wait before retrying after halt |
| `circuit_breaker.escalation_path` | string | yes | Who or what is notified on circuit breaker trigger |
| `circuit_breaker.rollback_on_halt` | boolean | yes | Whether halt automatically triggers rollback Phase 1 |

## Upstream evidence linkage fields (for provenance)
| Field | Type | Required | Description |
|---|---|---|---|
| `source_101` | string | no | `artifact_id` from release-checklist-generation (101) if consumed |
| `source_103` | string | no | `artifact_id` from rollback-plan-generation (103) if consumed |
| `source_104` | string | no | `artifact_id` from canary-release-recommendation (104) if consumed |
| `source_105` | string | no | `artifact_id` from release-risk-assessment (105) if consumed |
| `source_106` | string | no | `artifact_id` from configuration-change-check (106) if consumed |
| `source_107` | string | no | `artifact_id` from environment-difference-check (107) if consumed |

## Phase definitions
| Phase | Purpose | Typical task types |
|---|---|---|
| `P1_prepare` | Pre-deployment readiness | Feature flag staging, backup creation, DBA pre-checks, notification |
| `P3_execute` | Deployment execution | Image deploy, canary stage gates, config push, migration run |
| `P4_verify` | Post-deploy validation | Smoke tests, PRV P0 checks, synthetic monitoring |
| `P5_stabilize` | Observation window | SLO monitoring, rollback readiness confirmation, on-call handoff |

## Null / unknown handling
- `depends_on: []` is valid and indicates a root task with no dependencies.
- `timeout_minutes: null` is not valid; always provide an estimate, even if conservative (e.g., 60 for unknown tasks).
- `resumable: false` must be accompanied by an explicit `on_failure: rollback` or `on_failure: escalate` — never `on_failure: halt` alone for non-resumable tasks.


---

## Field contract — approval_gate entry

| Field | Required | Values / notes |
|---|---|---|
| `gate_id` | yes | `GATE-{NNN}` format |
| `gate_type` | yes | ∈ {human_approval, automated_check, timeout_wait} |
| `description` | yes | what approver must confirm |
| `owner` | yes | role string; never `unassigned` for P3 gates |
| `on_timeout` | yes | ∈ {block, escalate, skip_with_warning} |
| `timeout_duration` | yes | ISO 8601 or `{N}m` |
| `evidence_required` | yes | what constitutes approval |
| `auto_advance` | yes | boolean; `false` for P3 production gates |