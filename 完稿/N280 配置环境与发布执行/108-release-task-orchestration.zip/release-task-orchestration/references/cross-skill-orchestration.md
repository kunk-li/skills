# cross-skill-orchestration

Describes how the three release-exec skills collaborate in a full pipeline run.

## Canonical sequence

```
configuration-change-check (106)
        │
        │  config_state (config items, reload_mode, secret findings, blockers)
        ▼
environment-difference-check (107)
        │
        │  environment_state (difference_register, parity_verdict, overall_ready_to_proceed)
        ▼
release-task-orchestration (108)
        │
        │  downstream_handoff → release-validation verification hooks
        ▼
     release-validation post-release validation
```

## Join keys
All three skills share these join keys for artifact correlation:
- `schema_version` (must match across 106, 107, 108)
- `release_id` or `release_manifest.release_id`
- `produced_event` chain (106 → 107 → 108)

## Partial composition rules
- **106 only:** 107 and 108 run in standalone/conservative mode.
- **107 only:** 108 marks config preconditions as unresolved; applies conservative sequencing.
- **106 + 107:** 108 can use full `pipeline_contract_mode` with safe parallelism.
- **All three:** 108 emits the full release-exec node-level package `produced.release-exec.environment_release_execution_package.v2`.

## Refresh triggers
- If 106 is re-run and `config_state` changes, 107 must re-evaluate affected differences.
- If 107 `environment_state.overall_ready_to_proceed` changes, 108 must re-check preconditions.
- 108 emits `downstream_handoff.refresh_triggers: [release-validation]` when the DAG changes.


---

## Boundary comparison table — release-task vs release-checklist vs canary vs rollback

| Dimension | release-task-orchestration | release-checklist-generation | canary-release-recommendation | rollback-plan-generation |
|---|---|---|---|---|
| **Primary question** | "What is the execution sequence and dependencies?" | "Are we operationally ready?" | "What traffic strategy minimizes risk?" | "How do we reverse if needed?" |
| **Output type** | Execution DAG: tasks, timeouts, dependencies, approval gates | Readiness checklist: gate items with sign-off roles | Progressive rollout plan: stages, gates, auto-halt | Rollback procedure: phases, triggers, SLA |
| **Owns** | Task DAG, dependency ordering, approval gate execution, circuit breaker | Gate item design, sign-off tracking, timing markers | Stage traffic %, promotion criteria, abort criteria | Rollback phases, trigger conditions, dry-run evidence |
| **Does not own** | Gate item design (→103), canary strategy (→104), rollback design (→105) | Task execution (→108), canary traffic (→104) | Task execution (→108), gate tracking (→103) | Execution DAG (→108), path selection (→121) |

### Hard boundary rules
```
108 MUST NOT: design rollback procedures (procedures are in 105; 108 only wires 105 triggers into DAG)
108 MUST NOT: define canary stage traffic % (that is 104's job; 108 consumes 104 output)
108 MUST: receive 103/104/105/106/107 artifacts as input before DAG finalization
108 MUST: reference canary plan from 104 as a DAG phase, not rediscover canary strategy

Canonical input chain: 101→103→104→105→106→107 → 108 consumes all → 109/110 consume 108 outputs
```