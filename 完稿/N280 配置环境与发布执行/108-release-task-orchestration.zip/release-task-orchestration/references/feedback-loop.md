# release-task-orchestration — feedback loop protocol

## Retrospective integration
After each release, compare skill output predictions vs actual outcomes.

### Signal types and actions
| Signal | Trigger | Action |
|---|---|---|
| `false_positive` | Skill flagged issue that had no real impact | Add calibration note; review relevant SCR threshold |
| `false_negative` | Skill missed issue that caused a problem | Add to failure-modes.md; tighten SCR gate; file patch bump |
| `wrong_confidence` | Confidence label didn't match evidence quality | Update confidence_ceiling_rule; add calibration example |
| `correct` | Skill prediction matched actual outcome | Add as green-path calibration to real-examples.md |

## feedback_signal_candidates schema
Every output artifact MUST include at least one entry:
```yaml
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: correct | false_positive | false_negative | wrong_confidence
    description: "What to verify post-release"
    verification_method: "How to confirm the outcome"
    priority: P1 | P2
    status: pending  # updated to 'verified' or 'deferred' post-release
```

## Version bump triggers
- 3+ `false_negative` for same dimension within 90 days → patch bump; tighten SCR
- New integration type or platform → minor bump; add Mode
- Output schema breaking change → major bump; migration guide required

## Consumer impact protocol
```yaml
consumer_impact_assessment:
  changed_field: "{field name}"
  affected_consumers:
    - skill: "{downstream skill}"
      field_consumed: "{field}"
      action_required: true | false
  notification_timing: "Before packaging next release"
```


---

## Feedback loop — execution outcome integration

### Task execution outcome → DAG model calibration
After every deployment, compare planned DAG vs actual execution:

```yaml
execution_outcome_integration:
  release_id: payment-service-v2.1.3
  dag_planned_tasks: 8
  dag_executed_tasks: 8
  circuit_breaker_triggered: false
  actual_completion_time: "34min"
  planned_completion_time: "45min"
  
  deviations:
    - task_id: T03
      planned_duration: 20m
      actual_duration: 8m
      deviation_type: faster_than_planned
      calibration_note: "Rolling restart for 3-pod service completes in ~8min, not 20min"
      
  feedback_signal:
    signal_id: FSC-001
    signal_type: wrong_confidence
    description: "Timeout estimates were too conservative for this service size"
    calibration_action:
      update_target: "Task timeout defaults"
      add_rule: "For services with ≤5 pods, default rolling_restart timeout = 10m (not 20m)"
      version_bump: "patch"
      
  verification_date: "2026-05-20T15:30:00Z"
```

### DAG optimization feedback rule
```yaml
dag_optimization:
  trigger: "Same task type consistently completes in <50% planned timeout for 3+ releases"
  action: "Update default timeout for that task_kind in SKILL.md Mode selection section"
  trigger_2: "Circuit breaker triggers 2+ times for same task in 30-day window"
  action_2: "Add failure mode to references/failure-modes.md; consider reducing threshold"
```