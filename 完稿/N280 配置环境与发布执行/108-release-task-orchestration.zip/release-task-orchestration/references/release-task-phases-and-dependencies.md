# Release Task Phases and Dependencies v2.1

## Suggested release phases
- `P1_prepare`: artifacts, approvals, config validation, environment checks, evidence gathering.
- `P2_pre_stage`: staging deploy, smoke, dry run, migration rehearsal, or config reload rehearsal.
- `P3_execute`: production rollout, canary, phased promotion, traffic shifting, or GitOps sync.
- `P4_verify`: post-release smoke, dashboards, alerts, SLO checks, early validation, N290 handoff.
- `P5_stabilize`: observation window, rollback readiness, documentation handoff, closeout tasks.

## Task registry fields
Each task should include:
- `task_id`, `task_name`, `phase`, `task_kind`.
- `owner`, `dependencies`, `artifacts_consumed`, `artifacts_produced`.
- `timeout`, `retry_policy`, `success_criteria`, `verification_method`.
- `on_failure`, `resume_policy`, `automation_level`, `evidence`.

## Task kinds
Use these kinds where possible:
- `build_artifact`
- `run_tests`
- `apply_config`
- `deploy_infrastructure`
- `deploy_application`
- `run_migration`
- `run_smoke_tests`
- `progressive_rollout`
- `verify_slo`
- `manual_approval`
- `wait_and_observe`
- `send_notification`
- `update_documentation`

## Human approval gate fields
Every approval gate should include:
- `approval_gate_id`
- `at_stage` or `before_task`
- `required_approver_role`
- `alternate_approvers`
- `what_to_approve`
- `supporting_data`
- `timeout_duration`
- `on_timeout`: `auto_reject`, `escalate`, or `manual_decision`
- `escalation_target`
- `approval_audit`: recorded and immutable

## Circuit breaker fields
Use this structure for pipeline-level safety:

```yaml
pipeline_level_circuit_breaker:
  enabled: true
  triggers:
    - critical_blocker_present
    - failed_stage_count_exceeds_threshold
    - repeated_retry_failure
    - slo_verification_failed
  threshold: 1
  action: halt_pipeline
  cooldown: 30m
  resume_authority: [release_manager, oncall]
  event: exception.n280.release_circuit_breaker.opened
```

## Dependency guidance
- Build, sign, and scan tasks complete before rollout.
- 106 critical config blockers clear before production traffic changes.
- 107 critical environment blockers clear before production promotion.
- Cross-service provider updates usually precede consumer updates unless compatibility proof exists.
- Verification tasks block closeout even if deployment technically succeeded.
