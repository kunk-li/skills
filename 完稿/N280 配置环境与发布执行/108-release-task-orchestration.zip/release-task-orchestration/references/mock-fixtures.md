## Mock input fixture

```yaml
mock_input:
  source: "release_description_only"
  content: "Deploy payment-service v2.1.3 to production"
  expected_output_shape:
    dag_overview:
      selected_mode: simple_sequential
      parallelism: disabled
    task_registry:
      min_tasks: 3
      phases: [P1_prepare, P3_execute, P4_verify]
    pipeline_level_circuit_breaker:
      enabled: true
    self_check:
      passed: true
      warnings: ["106 and 107 absent — conservative sequential mode"]
```
