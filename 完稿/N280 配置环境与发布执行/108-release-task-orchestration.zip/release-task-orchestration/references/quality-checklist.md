# quality-checklist

Run this checklist before finalizing any release-exec skill artifact. Record any failures in the `self_check` section.

## Mandatory items

### Contract integrity
- [ ] `artifact_contract.schema_version` is present and matches the skill's declared version
- [ ] `artifact_contract.produced_event` is declared (even if `event_delivery: declared_only`)
- [ ] `artifact_contract.subscribers_hint` lists downstream consumers

### Config / environment safety
- [ ] No plaintext secrets, tokens, or credentials appear anywhere in the artifact
- [ ] Every config item has an `owner` (or `owner: unassigned` with a pending SLA item)
- [ ] Every secret-related finding is treated as blocked or constrained until lifecycle evidence is confirmed

### Output completeness
- [ ] All Required artifact sections from SKILL.md are present
- [ ] Any missing data uses `unknown`, `unresolved`, or `constrained` with a reason — never silently omitted
- [ ] `readiness` is consistent with the number and severity of open blockers

### Downstream handoff
- [ ] `downstream_handoff` is present and references correct targets (108 for config/env state, release-validation for verification)
- [ ] Any item consumed by `release-task-orchestration (108)` is explicitly formatted as a typed precondition
- [ ] `blockers_and_pending[]` items each have an owner placeholder, SLA, and required evidence

### Self-check
- [ ] All skill-specific self-check items pass
- [ ] `schema_version` and `produced_event` are present and correct

## Quality bar summary
A good release-exec artifact is machine-consumable by 108 as a typed precondition, never leaks secrets, has clear ownership for every item, and explicitly states readiness relative to open blockers.


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-RELEASET-051 | `circuit_breaker.cooldown` ISO 8601 format | regex `PT\d+[MHS]` | `self_check.warnings: ["SCR-RELEASET-051: cooldown not ISO 8601 format"]` |
| SCR-RELEASET-052 | Every approval gate has `on_timeout` declared | key exists | `self_check.failed_rules: ["SCR-RELEASET-052: approval gate missing on_timeout"]` |
| SCR-RELEASET-053 | No "chatgpt" in content | string search | `self_check.failed_rules: ["SCR-RELEASET-053: chatgpt brand word — BLOCKER"]` |
| SCR-RELEASET-054 | `feedback_signal_candidates` ≥ 1 | count ≥ 1 | `self_check.warnings: ["SCR-RELEASET-054: FSC missing"]` |