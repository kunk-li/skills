---
name: release-task-orchestration
description: generate n280 release-execution task orchestration from release notes, release checklists, environment configuration inventories, configuration-change-check output, environment-difference-check output, rollback plans, canary strategy, or gitops manifests. use for standalone release sequencing or full n280 pipeline composition. produces a versioned 发布任务编排表 artifact with dag tasks, dependencies, human approval gates, circuit breaker, resumability, observability, and event handoff.
---
# release-task-orchestration

## Role
Use this skill to turn N280 release intent and upstream checks into an executable, observable, restart-safe rollout plan. It is the authoritative N280 skill for task decomposition, dependency ordering, approval gates, failure policy, resumability, and execution-state handoff.

## Boundary
- Own release task decomposition, DAG ordering, dependencies, approval gates, failure policies, circuit breaker, state tracking, resumability, and observability hooks.
- Consume 106 config findings and 107 environment findings; do not reclassify config semantics or environment parity when those artifacts exist.
- Consume N270 rollback constraints; do not replace N270 rollback planning.
- Hand off checkpoints to N290; do not replace post-release validation or acceptance records.
- Produce an orchestration plan and platform config samples; do not execute external deployment systems unless the user provided a connector or tool.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `schema_version`, `produced_event`, and `event_delivery` at the top.

Allowed modes:
- `simple_sequential`: small release with a conservative sequential checklist and explicit evidence.
- `dag_enterprise`: multi-service or multi-stage release with dependency graph and control gates.
- `gitops_native`: repo-driven desired-state rollout with reconciliation checkpoints.
- `pipeline_contract_mode`: strictly consume 106 `config_state` and 107 `environment_state` as typed preconditions.
- `dry_run`: validate the orchestration shape without assuming execution will occur.

## Inputs
Preferred N280 workflow inputs:
- `发布说明.md`
- `发版检查清单.csv`
- `环境配置清单`

Strongly preferred pipeline inputs:
- `配置变更检查单.csv` or 106 `config_state`
- `环境差异检查单.csv` or 107 `environment_state`

Useful enhancement inputs:
- rollback plan, canary strategy, compatibility matrix, release manifest, workflow templates, owner list, maintenance window, observability dashboards.

Standalone rule:
- Work with one service release, one rollout slice, one recovery path, or one dry-run request.
- If upstream N280 checks are missing, keep the DAG stable and mark unresolved preconditions explicitly.

## Required artifact contract
Use `references/n280-shared-contract.md`. The metadata must include:

```yaml
artifact_contract:
  schema_version: n280.release-task-orchestration.v2.2.1
  artifact_type: release_task_orchestration
  producer_skill: release-task-orchestration
  workflow_node: N280
  produced_event: produced.n280.release_task_orchestration.v2
  event_delivery: declared_only
  subscribers_hint: [N290, N330, N350, N380, N390]
```

The result must include:
- `artifact_contract`
- `task_registry[]`
- `phase_map`
- `dag_overview`
- `human_approval_gates[]`
- `failure_policies`
- `pipeline_level_circuit_breaker`
- `state_management`
- `checkpoint_and_resume_rules`
- `cross_service_coordination`
- `observability_and_notifications`
- `release_execution_package`
- `downstream_handoff`
- `self_check`

## Design rules
- Prefer declarative DAG orchestration over purely procedural step lists.
- Every task must declare phase, dependencies, owner, timeout, verification method, evidence, and `on_failure` behavior.
- Supported `on_failure` strategies: `abort`, `retry_n_times`, `rollback`, `continue_with_warning`, `notify_and_wait`, `skip`, `manual_decision`.
- Track resumability explicitly: `idempotent`, `checkpointable`, `resumable`, `manual_safe_to_retry`, or `unsafe_to_retry`.
- Insert human approval gates before irreversible operations, production deployment, secret activation, migration, and canary progression to 100 percent.
- Production deployment must include approval role, alternate approvers, supporting data, timeout behavior, escalation, and immutable audit requirement.
- Add pipeline-level circuit breaker for repeated stage failures, critical secret blockers, unresolved environment drift, or failed verification loops.
- Emit `exception.n280.release_circuit_breaker.opened` when the plan requires halting or escalation.
- Model state persistence and observable states for task and pipeline: pending, running, succeeded, failed, skipped, waiting_approval, cancelled.
- Keep GitOps-native execution first-class when config and environment state are repo-driven.

## Execution workflow
1. Ingest release intent, checklist state, 106 config findings, 107 environment findings, rollback constraints, owners, and platform hints.
2. Convert release work into task registry entries with phases, dependencies, owners, timeouts, verification, artifacts, and failure handling.
3. Use 106 `reload_mode` and 107 readiness/blockers as preconditions; do not rejudge their domain findings.
4. Insert human approval gates, SLA queue items, circuit breaker rules, and state-management checkpoints.
5. Resolve cross-service ordering and identify safe parallelism.
6. Emit release execution package, observability hooks, downstream handoff, and produced event payload.

## Degradation rules
- Missing 106/107 artifacts: mark config or environment preconditions unresolved and select conservative sequencing.
- Partial rollback details: default to `notify_and_wait`, `manual_decision`, or `abort` rather than unsafe rollback automation.
- Unknown cross-service compatibility: avoid parallel rollout recommendations that assume compatibility.
- Missing owner or approver: create an SLA queue item and mark the relevant task or gate `blocked` or `constrained`.

## Self-check
Before finalizing, verify:
- Every task has dependencies, owner, timeout, verification, and `on_failure`.
- Production deployment has a human approval gate.
- The circuit breaker has threshold, trigger, action, cooldown or escalation, and resume authority.
- Rollback constraints are integrated but not reinvented.
- `schema_version` and `produced_event` are present.
- Downstream handoff includes N290 verification hooks and N330 documentation hints.

## Node-level package handoff
When the user asks for a complete N280 package or when at least two N280 artifacts are available, include or update the optional `node_level_package` described in `references/n280-shared-contract.md`. When all three artifacts exist, act as the default package producer and include `produced.n280.environment_release_execution_package.v2` in downstream handoff. Keep missing artifacts explicit instead of implying completeness.

## References
- `references/n280-shared-contract.md`
- `references/release-task-phases-and-dependencies.md`
- `references/real-examples.md`
