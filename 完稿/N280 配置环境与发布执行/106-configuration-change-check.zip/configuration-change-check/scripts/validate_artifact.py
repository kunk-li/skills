#!/usr/bin/env python3
"""validate_artifact.py v3 — full-coverage validator (D5/D6/D7/D8/D9/D10)."""
import sys, re, argparse

REQUIRED = ["metadata","self_check","downstream_handoff","readiness",
            "evidence_profile","emit_event","adversarial_detection",
            "feedback_signal_candidates"]
VALID_R  = {"draft","partial","ready","amber","red","green",
            "GO","NO_GO","CONDITIONAL_GO","DEFERRED_REVIEW","constrained","blocked"}
SCR_BLOCKERS = {
    "NO_CHATGPT": (r"chatgpt", "chatgpt brand word — BLOCKER"),
    "NO_SECRET":  (r"(?i)password:\s*[A-Za-z0-9!@#$]{8,}", "plaintext secret — BLOCKER"),
}
SCR_REQUIRED = {
    "SCR-META":    r"metadata:",
    "SCR-CHECK":   r"self_check:",
    "SCR-DOWN":    r"downstream_handoff:",
    "SCR-EMIT":    r"(emit_event:|produced_event:|produced\.release)",
    "SCR-READY":   r"readiness:\s*\S+",
    "SCR-CONF":    r"confidence:\s*(high|medium|low|speculative)",
    "SCR-ADV":     r"adversarial_detection:",
    "SCR-FSC":     r"feedback_signal_candidates:",
    "SCR-D10":     r"SCR-D10-\d+",
    "SCR-INJECT":  r"(SCR-INJECT|injection_attempt_detected)",
}
D9 = {
    "standalone":     r"(Tier 1:|minimum.*input|Standalone guarantee)",
    "red_state":      r"readiness:\s*(red|NO_GO|no_go)",
    "amber_state":    r"readiness:\s*(amber|CONDITIONAL|partial|constrained)",
    "field_contract": r"\| Field \|",
    "scr_d10":        r"SCR-D10-\d+",
    "real_examples":  r"real.examples",
    "failure_modes":  r"failure.modes",
    "four_tier":      r"confidence_ceiling_by_tier|tier_1.*ceiling|tier_4.*ceiling",
    "adv_full":       r"Forbidden pattern table",
    "feedback_loop":  r"feedback_signal_candidates",
    "output_comp":    r"Output completeness rule",
    "d2_boundary":    r"Boundary comparison table|Boundary clarification",
    "d3_modes":       r"### New:.*mode|quick_triage|Allowed modes:",
    "conf_quant":     r"confidence_quantification|confidence_ceiling_applied",
    "d6_amber":       r"readiness: amber|amber.*state|confidence_ceiling_applied",
    "d7_typed":       r"handoff_type:\s*(evidence|routing|gap|action_hint)",
    "d8_forbidden":   r"Forbidden pattern table|forbidden_pattern",
    "d8_trust":       r"trust_hierarchy:",
    "consumer_proto": r"consumer_impact|affected_consumers",
}
D7 = {
    "typed":     r"handoff_type:\s*(evidence|routing|gap|action_hint)",
    "refresh":   r"refresh_triggers:",
    "blocking":  r"blocking:\s*true",
    "next":      r"next_best_checks:",
    "urgency":   r"urgency:\s*(immediate|high)",
}
D8 = {
    "forbidden": r"Forbidden pattern table",
    "trust":     r"trust_hierarchy:",
    "inject":    r"SCR-INJECT|injection_attempt_detected",
    "plausi":    r"plausibility_check|plausibility_checks",
}
D10 = {
    "quant":    r"SCR-D10-\d+",
    "enum":     r"∈ \{",
    "numeric":  r"(≥ \d|≤ \d|count \w)",
    "failure":  r"self_check\.failed_rules",
    "warning":  r"self_check\.warnings",
    "conf_q":   r"confidence_quantification",
    "fsc":      r"feedback_signal_candidates",
}

def extract_artifact_yaml_blocks(content):
    """Extract only artifact YAML blocks; skip forbidden-pattern docs."""
    blocks = []
    pos = 0
    while True:
        start = content.find('```yaml', pos)
        if start == -1:
            break
        nl = content.find(chr(10), start)
        if nl == -1:
            break
        close_seq = chr(10) + '```'
        close = content.find(close_seq, nl)
        if close == -1:
            break
        block = content[nl + 1: close]
        preceding = content[max(0, start - 400): start].lower()
        skip = ['forbidden pattern', 'adversarial', 'reject this', 'do not allow',
                'block immediately', 'flag as suspicious', 'never accept',
                'bad example', 'incorrect', 'anti-pattern', 'must not appear',
                'prohibition', 'scr-no_', 'blocker']
        if not any(m in preceding for m in skip):
            blocks.append(block)
        pos = close + 1
    return "\n".join(blocks)


def validate(path, strict=False):
    try: content = open(path, encoding="utf-8").read()
    except FileNotFoundError: sys.exit(2)
    errs, warns, cov = [], [], {}

    # Blockers
    artifact_text = extract_artifact_yaml_blocks(content)
    for bid,(pat,msg) in SCR_BLOCKERS.items():
        if re.search(pat, artifact_text, re.IGNORECASE):
            errs.append(f"[BLOCKER-{bid}] {msg}")

    # Required sections
    for s in REQUIRED:
        if s not in content: errs.append(f"[SECTION] {s} missing")

    # Required SCR
    for rid, pat in SCR_REQUIRED.items():
        if not re.search(pat, content, re.IGNORECASE):
            (errs if strict else warns).append(f"[{rid}] not found")

    # Readiness
    rd = re.search(r"readiness:\s*(\S+)", content)
    if rd and rd.group(1).strip("'\"") not in VALID_R:
        warns.append(f"[READINESS] unknown value: {rd.group(1)}")

    # Dimension coverage
    for grp, checks in [("D9",D9),("D7",D7),("D8",D8),("D10",D10)]:
        for k, pat in checks.items():
            v = bool(re.search(pat, content, re.IGNORECASE|re.MULTILINE))
            cov[f"{grp}_{k}"] = v
            if not v: warns.append(f"[{grp}-{k}] missing")

    return errs, warns, cov

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("artifact"); p.add_argument("--strict", action="store_true")
    p.add_argument("--report-coverage", action="store_true")
    args = p.parse_args()
    errs, warns, cov = validate(args.artifact, args.strict)

    if args.report_coverage:
        for dim in ["D9","D7","D8","D10"]:
            dc = {k:v for k,v in cov.items() if k.startswith(dim)}
            s = round(sum(dc.values())/max(len(dc),1)*100)
            print(f"\n{dim} Coverage: {s}%")
            for k,v in dc.items(): print(f"  {'✓' if v else '✗'} {k}")

    if warns:
        print(f"\nWARNINGS ({len(warns)}):")
        for w in warns[:15]: print(f"  ! {w}")
        if len(warns) > 15: print(f"  ... +{len(warns)-15} more")

    if not errs:
        print(f"\nPASS: {args.artifact}"); sys.exit(0)
    print(f"\nFAIL ({len(errs)} blockers):")
    for e in errs: print(f"  ✗ {e}")
    sys.exit(1)
