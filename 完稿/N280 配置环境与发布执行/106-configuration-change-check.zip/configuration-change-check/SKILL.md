---
name: configuration-change-check
description: generate n280 release-execution configuration change checks from release notes, release checklists, environment configuration inventories, config diffs, manifests, or secret inventories. use for standalone config inspection or pipeline mode before environment-difference-check and release-task-orchestration. produces a versioned 配置变更检查单 artifact with schema metadata, secret lifecycle checks, reload impact, rollback and drift notes, blockers, and downstream event handoff.
---
# configuration-change-check

## Role
Use this skill to inspect configuration changes in N280. It is the authoritative skill for configuration classification, secret safety, versioning evidence, reload or restart impact, and config-specific blockers.

## Boundary
- Own config classification, `reload_mode`, secret lifecycle findings, versioning, rollback relevance, and config drift notes.
- Consume N270 release artifacts; do not recreate release notes, risk registers, or rollback plans.
- Do not replace `environment-difference-check` for multi-environment parity analysis.
- Do not replace `release-task-orchestration` for task ordering or execution sequencing.
- Provide execution signals for 108; do not generate an executable release DAG here.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `schema_version`, `produced_event`, and `event_delivery` at the top.

Allowed modes:
- `validate_only`: inspect config changes and blockers with minimal execution guidance.
- `impact_analysis_only`: focus on blast radius, reload impact, restart needs, and rollback relevance.
- `gitops_deploy`: inspect desired-state changes in repos, manifests, Helm values, or GitOps state.
- `pipeline_contract_mode`: produce a strict handoff for 107 and 108 with stable `config_state` fields.
- `secret_rotation_audit`: focus on secret lifecycle, rotation, revocation, and no-plaintext guarantees.

## Inputs
Preferred N280 workflow inputs:
- `发布说明.md`
- `发版检查清单.csv`
- `环境配置清单`

Useful enhancement inputs:
- config repo diffs, `values.yaml`, `application.yml`, Helm, K8s, Terraform, or remote-config changes.
- secret inventory, vault references, certificate metadata, or rotation evidence.
- release manifest, service ownership map, canary plan, or GitOps desired-state evidence.

Standalone rule:
- Work with one service config diff, one environment patch set, one release slice, or one secret rotation batch.
- If evidence is partial, keep the output schema stable and downgrade readiness rather than inventing facts.

## Required artifact contract
Use `references/n280-shared-contract.md`. The metadata must include:

```yaml
artifact_contract:
  schema_version: n280.configuration-change-check.v2.2.1
  artifact_type: configuration_change_check
  producer_skill: configuration-change-check
  workflow_node: N280
  produced_event: produced.n280.configuration_change_check.v2
  event_delivery: declared_only
  subscribers_hint: [N290, N330, N350, N380, N390]
```

The result must include:
- `artifact_contract`
- `config_change_inventory[]`
- `config_kind_summary`
- `secret_handling_findings`
- `secrets_management_lifecycle`
- `versioning_and_audit`
- `impact_analysis`
- `reload_action_matrix`
- `drift_detection_notes`
- `blockers_and_pending[]`
- `downstream_handoff`
- `self_check`

## Design rules
- Classify every changed item into exactly one `config_kind`: `CF01 application_config`, `CF02 infrastructure_config`, `CF03 secrets`, `CF04 feature_flag`, `CF05 policy_config`, `CF06 monitoring_config`, `CF07 network_config`, or `CF08 resource_limits`.
- Also map to v2 `change_kind` when useful: `CK1_application_config`, `CK2_feature_flag`, `CK3_secret_credential`, `CK4_infrastructure_config`, `CK5_database_config`, `CK6_external_service_endpoint`, `CK7_observability_config`.
- Never normalize plaintext secrets. Mark plaintext secret exposure as `blocked` and emit a P0 or P1 SLA queue item.
- For secrets, record lifecycle evidence: storage system, encryption, access control, rotation schedule, revocation-on-compromise path, audit access, and distribution method.
- Every row must state owner, old value summary, new value summary, environment scope, evidence, `reload_mode`, expected verification, and rollback relevance.
- Supported `reload_mode`: `hot_reload`, `rolling_restart`, `full_restart`, `migration_required`, `manual_trigger`, or `unknown`.
- Treat `reload_mode` as a finding for 108 to consume; do not sequence release tasks here.
- Prefer GitOps-compatible versioning notes when config repos, tags, manifests, or desired state are available.
- Separate confirmed facts from assumptions in `evidence_profile`.

## Execution workflow
1. Collect release inputs, configuration inventories, concrete diffs, and available ownership evidence.
2. Normalize each change into a row with config key, old value summary, new value summary, environment scope, service scope, owner, evidence, and config kind.
3. Run secret lifecycle checks, versioning checks, audit checks, reload-mode analysis, rollback relevance analysis, and drift-detection notes.
4. Emit blockers, SLA queue items, and `config_state` handoff for 107 and 108.
5. End with self-check and the produced event payload.

## Degradation rules
- Missing secret source of truth: classify conservatively and block only when unsafe evidence exists; otherwise mark `constrained` with required evidence.
- Missing deployment context: separate hot-reload assumptions from confirmed restart requirements.
- Missing ownership: keep `owner: unassigned` and emit a pending decision item.
- Redacted values: preserve semantics without revealing secrets.

## Self-check
Before finalizing, verify:
- Every item has one config kind.
- Secrets are masked and never logged in plain text.
- `schema_version` and `produced_event` are present.
- Versioning and audit evidence are captured or explicitly missing.
- Critical config has drift-detection notes.
- Downstream handoff includes `config_state` and 108-safe `reload_mode` values.

## Node-level package handoff
When the user asks for a complete N280 package or when at least two N280 artifacts are available, include or update the optional `node_level_package` described in `references/n280-shared-contract.md`. If 108 is available, hand the package responsibility to 108 as the default producer; otherwise create a partial package and mark missing artifacts explicitly.

## References
- `references/n280-shared-contract.md`
- `references/configuration-change-categories.md`
- `references/real-examples.md`
