# output-template — release-exec skill artifacts

This template defines common metadata patterns for all three release-exec skill artifacts.

## Shared metadata block
```yaml
artifact_contract:
  schema_version: release-exec.<skill-name>.v2.2.1
  artifact_type: <artifact_type>
  producer_skill: <skill-name>
  workflow_node: release-exec
  produced_event: produced.release-exec.<artifact_type>.v2
  event_delivery: declared_only
  subscribers_hint: [release-validation, deployment, infra, notifications, reporting]
```

## readiness values
- `green` — all required sections present, no P0/critical blockers, self-check passes
- `amber` — partial evidence; output stable but confidence reduced; some items constrained
- `red` — hard blocker present; deploy-phase tasks must not proceed
- `constrained` — evidence available but incomplete for a specific dimension

## downstream_handoff pattern
```yaml
downstream_handoff:
  target: <next-skill-or-node>
  readiness_inherited: <green | amber | red>
  blockers: []
  config_state:    # 106 → 107 → 108 handoff field
    reload_actions: []
    overall_ready_to_proceed: true | false
  environment_state:  # 107 → 108 handoff field
    parity_verdict: full | partial | not_assessed
    overall_ready_to_proceed: true | false
  missing_evidence: []
  next_best_checks: []
```

## self_check pattern
```yaml
self_check:
  passed: true | false
  failed_rules: []
  quality_check_failures: []
  schema_version_verified: true
  produced_event_declared: true
  no_plaintext_secrets: true
```


---

## Downstream handoff YAML templates

### 正常路径：106 → 108 移交，overall_ready_to_proceed:true
```yaml
downstream_handoff:
  produced_by: configuration-change-check
  artifact: 配置变更检查单.csv
  produced_event: produced.release-exec.configuration_change_check.v2
  handoffs:
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "3 config items: CF01×2(rolling_restart), CF03×1(secret rotation). overall_ready_to_proceed: true."
      required_fields:
        - config_change_inventory
        - config_state.overall_ready_to_proceed
        - config_state.reload_actions
        - secret_lifecycle_findings
      confidence: high
      missing_evidence: []
      next_best_checks:
        - "108: use config_state.reload_actions to sequence restart tasks"
        - "108: verify CF03 secret rotation completed before P3 execution"
    - target: release-risk-assessment
      handoff_type: evidence
      summary: "CF01 config change with resource limit reduction — flag availability_risk: medium"
      required_fields: [config_change_inventory, config_state.rollback_relevance_high_items]
      confidence: medium
  refresh_triggers:
    - skill: release-task-orchestration
      reason: "Config inventory updated — DAG preconditions must be re-evaluated"
      condition: "config_check.artifact_version > orchestration.source_106_version"
```

### 阻断路径：明文密钥检测
```yaml
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      handoff_type: gap
      summary: "BLOCKER: plaintext secret in config — overall_ready_to_proceed: false"
      blocking: true
      required_fields: [secret_lifecycle_findings, config_state.overall_ready_to_proceed]
      next_best_checks:
        - "Rotate secret and move to secret manager before re-running 106"
        - "Do not start release-task-orchestration until 106 reports overall_ready_to_proceed: true"
```


---

## Standalone guarantee — run 106 without any upstream artifacts
106 is independently useful with only a config diff or a verbal description of what changed. Do not refuse output because release notes or 107 are missing.

### Minimum viable standalone inputs
- at least one config diff, `values.yaml` change, environment variable delta, or explicit change description
- target environment (prod, staging, or environment name)

### What 106 produces standalone
- `config_change_inventory[]` with `config_kind`, `reload_mode`, `rollback_relevance`, and `owner` for every item
- `secret_lifecycle_findings[]` for any CF03 items
- `blockers_and_pending[]` for unresolved owners, unknown reload modes, or secret risks
- `config_state` handoff for 107 and 108

### Standalone red example — secret plaintext detected
```yaml
metadata:
  readiness: red
  selected_mode: secret_rotation_audit
evidence_profile:
  confirmed: [config_diff]
  missing_evidence: []
config_change_inventory:
  - config_key: PAYMENT_API_KEY
    config_kind: CF03_secrets
    reload_mode: rolling_restart
    owner: payments-team
    rollback_relevance: critical
    evidence: config-diff-provided
secret_lifecycle_findings:
  - config_key: PAYMENT_API_KEY
    finding: plaintext_secret_detected
    severity: P0
    storage: environment_variable_plaintext
    rotation_scheduled: unknown
    required_action: "Move to vault or sealed secret before release. Block deploy until resolved."
blockers_and_pending:
  - item: "Plaintext secret PAYMENT_API_KEY in config diff"
    severity: P0
    blocking_dimension: secret
    required_evidence: "Vault reference or sealed secret proof"
    sla: immediate
config_state:
  overall_ready_to_proceed: false
  reload_actions: []
downstream_handoff:
  target: environment-difference-check
  overall_ready_to_proceed: false
  missing_evidence: []
  next_best_checks:
    - "Resolve P0 secret blocker before running 107 or 108"
self_check:
  passed: false
  failed_rules: ["Plaintext secret detected — hard deploy blocker"]
```

### Standalone amber example — reload_mode unknown for one item
```yaml
metadata:
  readiness: amber
  selected_mode: validate_only
evidence_profile:
  confirmed: [helm_values_diff]
  missing_evidence: [service_owner_confirmation]
config_change_inventory:
  - config_key: db.pool.max-size
    config_kind: CF01_application_config
    old_value_summary: "100 connections"
    new_value_summary: "20 connections"
    environment_scope: production
    reload_mode: rolling_restart
    owner: backend-team
    rollback_relevance: high
    evidence: helm-values-diff
  - config_key: feature.new-checkout
    config_kind: CF04_feature_flag
    old_value_summary: "false"
    new_value_summary: "true"
    environment_scope: production
    reload_mode: hot_reload
    owner: unassigned
    rollback_relevance: medium
    evidence: helm-values-diff
blockers_and_pending:
  - item: "Owner unassigned for feature.new-checkout"
    severity: P1
    blocking_dimension: approval
    required_evidence: "Feature owner confirmation"
    sla: "4h before release"
config_state:
  overall_ready_to_proceed: true
  reload_actions:
    - config_key: db.pool.max-size
      reload_mode: rolling_restart
      owner: backend-team
      blocker_if_failed: amber
downstream_handoff:
  target: environment-difference-check
  overall_ready_to_proceed: true
  missing_evidence: [service_owner_for_feature_flag]
self_check:
  passed: true
  failed_rules: []
  warnings: ["feature.new-checkout owner unassigned — P1 pending"]
```

---

## Output completeness rule

**Additional hard rules:**
- `config_kind` MUST be classified from CF01–CF08 for every item — `unknown` is only allowed at Tier 1
- `reload_mode: full_restart` during peak traffic hours → `self_check.warnings: ["full_restart during peak"]`
- CF03 item detected → `secret_lifecycle_findings` MUST be present (may be `[]` only if no issues)
- `overall_ready_to_proceed: true` requires ALL items to have `reload_mode` ≠ `unknown`
- Any `severity: P0` finding → `overall_ready_to_proceed: false` always

---

## Mode selection

### New: `secret_rotation_audit` mode — 密钥轮换审计
**Trigger:** Security team needs to verify all secrets are properly rotated before a release, or user says "secret rotation check", "verify secrets rotated", "CF03 audit".

```yaml
secret_rotation_audit:
  audit_scope: [CF03_secrets, CF04_env_vars_with_secrets]
  secrets_found:
    - secret_id: SEC-001
      config_key: "database.password"
      kind: CF03
      rotation_status: rotated
      rotation_confirmed_at: "2026-05-20T09:00:00Z"
      vault_reference: "vault://prod/database/password"
      inline_value: false  # safe
    - secret_id: SEC-002
      config_key: "payment_gateway.api_key"
      kind: CF03
      rotation_status: pending
      rotation_required_by: "2026-05-21T18:00:00Z"
      blocker: "API key rotation not yet confirmed — block deployment"
  audit_verdict: blocked
  blocking_secrets: [SEC-002]
  config_state:
    overall_ready_to_proceed: false
    reason: "SEC-002 rotation not confirmed — cannot deploy with unrotated secrets"
```
**SCR:** `selected_mode: secret_rotation_audit` → `secret_rotation_audit.secrets_found` ≥ 1; `audit_verdict` ∈ {clear, blocked}; any unrotated secret → `config_state.overall_ready_to_proceed: false`.


## CSV 序列化规则(node_artifact_target 是 .csv)

本产物 node_artifact_target 是 `.csv`。必须序列化为**既是合法 CSV、又携带上面契约 metadata 信封**的文件:

1. 把上面完整的 metadata 信封及所有 YAML 块,作为文件开头的注释行输出,每行以 `# ` 前缀。CSV 读取器跳过 `#` 行;信封仍可被 `scripts/validate_artifact.py` 机读校验(该校验器按段名子串匹配,注释头满足全部 REQUIRED 段)。
2. 注释信封之后,再输出表头行 + 表格条目(检查项/测试点/任务行)为标准逗号分隔 CSV 行。
3. 不要输出无注释信封的纯数据 CSV——`validate_artifact.py` 会因缺 metadata/self_check/downstream_handoff/evidence_profile/emit_event(或 produced_event)/adversarial_detection/feedback_signal_candidates 等段判 FAIL。

合法示例骨架:

```
# metadata:
#   skill_id: <skill>
#   node_artifact_target: <本产物>.csv
#   readiness: green
# self_check: {passed: true, failed_rules: []}
# downstream_handoff: {primary_consumers: [...]}
# evidence_profile: {confirmed_evidence: [], assumptions: [], missing_evidence: []}
# emit_event: {event_name: produced.<node>.<artifact>.v2}
# adversarial_detection: none_detected
# feedback_signal_candidates: []
<列头1>,<列头2>,<列头3>
<行数据...>
```
