# release-exec Shared Artifact Contract v2.2.1

Canonical source: `release-exec-shared-contracts/release-exec-shared-contract-v2.2.1.md`.
This file is an embedded copy of the release-exec node-level contract for portable skill upload. Treat the canonical file as source of truth and regenerate embedded copies from it during packaging.

## Contract objective
Keep every release-exec skill usable alone while making multi-skill execution stronger through shared field names, versioned artifacts, explicit events, node-level package aggregation, and predictable version evolution.

## Artifact header
Every output must start with this metadata block, even when the user asks for CSV-friendly tables:

```yaml
artifact_contract:
  schema_version: release-exec.<skill_id>.v2.2
  artifact_id: <stable-id>
  artifact_type: configuration_change_check | environment_difference_check | release_task_orchestration
  producer_skill: configuration-change-check | environment-difference-check | release-task-orchestration
  workflow_node: release-exec
  selected_mode: <mode>
  readiness: ready | constrained | blocked
  produced_event: produced.release-exec.<artifact_type>.v2
  event_delivery: declared_only | emitted_by_platform
  emitted_at: <iso8601|null>        # optional; set only after real platform emission
  emitted_by: <platform-or-connector|null>
  subscribers_hint: [release-validation, deployment, infra, notifications, reporting]
  evidence_profile:
    confirmed_inputs: []
    missing_inputs: []
    assumptions: []
  blockers: []
  downstream_handoff: []
```

Use the literal skill id in `schema_version` and `producer_skill`. Keep event names on the v2 major event family unless a breaking event payload change is introduced.

## Versioning policy
Use semantic versioning for the artifact schema suffix:

- Patch updates (`v2.2.1`) are wording, examples, clarifications, or optional event/package metadata alignment only and must not change required fields.
- Minor updates (`v2.2`, `v2.3`) may add optional fields, new enum values, or extra examples while preserving backwards compatibility.
- Major updates (`v3.0`) may rename or remove fields and must declare migration guidance.
- Maintain a dual-read compatibility window for at least one downstream release cycle when moving from one minor version to the next.
- Downstream subscribers should accept `schema_version` with the same major version if required fields in this contract are present.
- Mark deprecated fields with `deprecated_since`, `replacement`, and `remove_after` before removal.

## Event delivery semantics
release-exec skills declare event metadata. They do not call an external event bus, CI/CD system, ticketing queue, or deployment system unless the user explicitly provides an enabled connector or tool for that action.

`event_delivery` values:

| Value | Meaning |
|---|---|
| `declared_only` | Event payload is included in the artifact for a platform or human to emit later. This is the default. |
| `emitted_by_platform` | A platform integration has actually emitted the event outside the skill output. Only use when there is evidence from the connector/tool. |

When unsure, set `event_delivery: declared_only` and include the exact event payload under `downstream_handoff`. If a platform integration actually emits the event, that integration should annotate the persisted artifact with `event_delivery: emitted_by_platform`, `emitted_at`, `emitted_by`, and connector/tool evidence before downstream subscribers consume it.

## Shared vocabulary
Use these fields across all release-exec artifacts whenever possible:

| Field | Meaning |
|---|---|
| `id` | Stable row id, not a display-only number. |
| `priority` | `critical`, `high`, `medium`, or `low`. |
| `owner` | Person, role, team, or explicit `unassigned`. |
| `status` | `pending`, `ready`, `blocked`, `waived`, `in_progress`, `done`, or `failed`. |
| `evidence` | Source artifact, observation, command result, diff, dashboard, or snapshot. |
| `upstream` | Producing node, skill, or input artifact. |
| `blocking_dimensions` | Dimensions blocking readiness, such as `secret`, `drift`, `approval`, `rollback`, `automation`, or `evidence`. |
| `automation_level` | `manual`, `semi_automated`, `automated`, or `gitops_managed`. |
| `verified_by` | Human, role, system, or `pending`. |
| `verified_at` | ISO-8601 timestamp or `pending`. |

## Readiness inheritance
release-exec inherits release readiness from release-prep but must downgrade it when:
- configuration drift is unresolved.
- secret handling is unsafe or unverifiable.
- environment isolation is broken.
- production deployment lacks required approval.
- release tasks lack retry, rollback, or resume handling.

Readiness values:
- `ready`: evidence is sufficient for execution or signoff.
- `constrained`: usable with explicit limitations or pending confirmations.
- `blocked`: critical evidence or safety requirements are missing.

## Event model
Emit event metadata in the output; do not actually call external systems unless the user provided a tool or connector for it.

| Producer | Event | Typical subscribers |
|---|---|---|
| configuration-change-check | `produced.release-exec.configuration_change_check.v2` | release-validation, deployment, infra, notifications, reporting |
| environment-difference-check | `produced.release-exec.environment_difference_check.v2` | release-validation, deployment, infra, notifications, reporting |
| release-task-orchestration | `produced.release-exec.release_task_orchestration.v2` | release-validation, deployment, infra, notifications, reporting |
| release-task-orchestration (default node-level aggregator) | `produced.release-exec.environment_release_execution_package.v2` | release-validation, notifications, reporting |
| release-task-orchestration | `exception.release-exec.release_circuit_breaker.opened` | feedback, release-prep, incident-response, infra, notifications |
| any release-exec skill | `sla.release-exec.manual_queue.requested` | infra, notifications, reporting |

## Node-level package schema
When all three release-exec artifacts are available, produce or hand off an optional node-level aggregate package instead of forcing downstream nodes to stitch files manually. `release-task-orchestration` is the default producer because it normally consumes both 106 and 107 before execution planning. If 108 is not available, another active release-exec skill may create a partial package, but it must mark missing artifacts explicitly and set readiness to `constrained` or `blocked`:

```yaml
node_level_package:
  package_id: release-exec-PKG-<release-or-date>
  schema_version: release-exec.node_level_package.v2.2.1
  workflow_node: release-exec
  package_type: environment_release_execution_package
  readiness: ready | constrained | blocked
  included_artifacts:
    configuration_change_check:
      artifact_id: string
      schema_version: string
      readiness: ready | constrained | blocked
    environment_difference_check:
      artifact_id: string
      schema_version: string
      readiness: ready | constrained | blocked
    release_task_orchestration:
      artifact_id: string
      schema_version: string
      readiness: ready | constrained | blocked
  aggregate_blockers: []
  aggregate_sla_queue: []
  downstream_handoff:
    to_N290: []
    to_N330: []
    to_N350: []
    to_N380: []
    to_N390: []
  produced_event: produced.release-exec.environment_release_execution_package.v2
  event_delivery: declared_only | emitted_by_platform
```

Use this package only when at least two release-exec artifacts are present or when the user asks for a node-level summary. Do not make a package look complete if a required artifact is missing; mark missing artifacts explicitly. When all three artifacts exist, prefer 108 as the package owner and include the aggregate event payload in 108's `downstream_handoff`.

## Output frame
Use this frame unless the user requests a different format:

1. `artifact_contract`
2. primary registry table or object
3. risk, blocker, and pending decision register
4. readiness and self-check
5. downstream handoff and produced event payload
6. optional `node_level_package` when aggregating multiple release-exec outputs

For CSV-friendly output, keep one row per actionable item and include `id`, `priority`, `owner`, `status`, and `evidence`.

## Cross-skill composition rules
- `configuration-change-check` owns config classification, `reload_mode`, secret handling, versioning evidence, and config drift notes.
- `environment-difference-check` owns environment comparison, allowed-difference rationale, `readiness_score`, isolation observations, and drift trend.
- `release-task-orchestration` owns executable task ordering, dependencies, approval gates, failure policy, resumability, and observability hooks.
- 108 is the default producer of `node_level_package` when all three release-exec artifacts exist; other release-exec skills may only create partial packages and must mark missing artifacts explicitly.
- 108 consumes 106 `reload_mode`; it must not reclassify config semantics unless the 106 artifact is missing.
- 108 consumes 107 `readiness_score`; it must not independently decide environment parity when a 107 artifact is present.
- 107 may emit readiness score, but notifications or the user decides final pass/block. 107 should state evidence and recommended action, not pretend to be the enterprise gate.
- None of the release-exec skills recreates release-prep release notes, rollback strategy, or release risk register.
- None of the release-exec skills replaces release-validation post-release validation or acceptance records.

## Shared state handoff
Prefer these state names in `downstream_handoff`:

```yaml
release_state: {}
config_state: {}
environment_state: {}
task_state: {}
rollback_state: {}
approval_state: {}
observability_state: {}
```

## SLA queue guidance
Create an SLA queue item when a blocker requires a human decision. Each item should include:

```yaml
sla_queue_item:
  queue_id: SLA-release-exec-001
  priority: P0 | P1 | P2
  reason: secret_blocker | prod_approval | drift_exception | rollback_gap | circuit_breaker
  recommended_action: string
  owner_role: release_manager | sre | security | compliance | tech_lead
  due_by: duration or timestamp
  escalation: string
```

## Common release-exec failure modes
Watch for these recurring issues:
- plaintext secrets committed into config repos.
- legitimate environment differences misclassified as drift.
- undocumented restart requirements causing surprise downtime.
- release tasks that cannot resume safely after partial failure.
- multi-service deployment order violating compatibility constraints.
- stale GitOps desired state differing from live cluster state.
- release steps marked done without evidence or verification.
