# real-examples

## Example 1: Configuration change check — minimal input (106)

**Scenario:** Single `application.yml` diff, no prior release artifacts.

**Input given:**
- Config diff: `db.pool.max-size` changed from `100` to `20`
- Environment: production
- Owner info: unknown

**Expected output shape:**
```yaml
readiness: partial
config_change_inventory:
  - config_key: db.pool.max-size
    config_kind: CF01_application_config
    old_value_summary: "100 connections"
    new_value_summary: "20 connections"
    environment_scope: production
    reload_mode: rolling_restart
    owner: unassigned
    evidence: config-diff-provided
    rollback_relevance: high
blockers_and_pending:
  - item: "Owner unassigned for db.pool.max-size change"
    severity: P1
    required_evidence: "service owner confirmation"
    sla: 4h before release
```

**Key calibration:** Even with minimal input, every config item must get a `config_kind`, `reload_mode`, and `rollback_relevance`. Missing owner → `unassigned` + blocker, not omitted.

---

## Example 2: Environment difference check — pipeline_contract_mode (107)

**Scenario:** 106 config_state available; comparing staging vs prod.

**Input given:**
- 106 output with `config_state` for 3 config items
- Staging snapshot vs prod snapshot

**Expected output shape:**
```yaml
selected_mode: pipeline_contract_mode
difference_register:
  - config_key: db.pool.max-size
    difference_nature: drift
    difference_kind: DK4_value_significant_divergence
    staging_value: "20"
    prod_value: "100"
    severity: high
    allowed: false
    rationale: null
    remediation: "Apply db.pool.max-size=20 to prod before release OR revert to 100"
env_readiness_scores:
  representativeness: 6/10
  config_alignment: 4/10
```

**Key calibration:** Every 106 config item must be accounted for (identical / expected-different / drifted / missing / unknown). A readiness score below 7 must include the specific gaps that caused the reduction.

---

## Example 3: Release task orchestration — degraded upstream (108)

**Scenario:** 106 output exists but 107 is missing.

**Expected output shape:**
```yaml
selected_mode: dag_enterprise
readiness: partial
evidence_profile:
  missing: [environment-difference-check]
  impact: "Environment parity cannot be confirmed; conservative sequencing applied"
dag_overview:
  parallelism: disabled  # conservative due to missing 107
task_registry:
  - task_id: T01
    phase: pre_deploy
    dependencies: []
    owner: release-manager
    on_failure: abort
    resumability: idempotent
    precondition_status: unresolved  # 107 not provided
blockers_and_pending:
  - item: "107 environment_state not provided"
    action: "Run environment-difference-check before proceeding to T05+"
```

**Key calibration:** Missing 107 → mark env preconditions `unresolved`, apply conservative sequencing. Never assume environment parity without 107 evidence.

---

## Example 4: secret_rotation_audit mode — certificate expiry risk

**Scenario:** Pre-release audit finds a TLS certificate expiring in 8 days.

**Input given:**
- Secret inventory includes: `payment-service TLS cert`, expiry `2026-05-28`, rotation status unknown

**Expected output shape:**
```yaml
selected_mode: secret_rotation_audit
readiness: amber
config_change_inventory:
  - config_key: payment-service.tls.cert
    config_kind: CF03_secrets
    environment_scope: production
    reload_mode: rolling_restart
    owner: security-team
    rollback_relevance: critical
    evidence: secret-inventory
secret_lifecycle_findings:
  - config_key: payment-service.tls.cert
    finding: expiry_imminent
    severity: P1
    expiry_date: "2026-05-28"
    days_remaining: 8
    rotation_scheduled: unknown
    required_action: "Confirm rotation schedule with security-team. Block release if cert cannot be rotated within maintenance window."
blockers_and_pending:
  - item: "TLS cert expiring in 8 days — rotation status unconfirmed"
    severity: P1
    blocking_dimension: secret
    required_evidence: "Security-team confirmation of rotation schedule"
    sla: "24h before release"
config_state:
  overall_ready_to_proceed: true
  reload_actions:
    - config_key: payment-service.tls.cert
      reload_mode: rolling_restart
      owner: security-team
      blocker_if_failed: red
self_check:
  passed: true
  warnings: ["TLS cert expiry within 8 days — P1 pending confirmation"]
```

**Key calibration:** `secret_rotation_audit` mode surfaces expiry, rotation schedule, and revocation readiness. Even a non-blocking finding must appear in `secret_lifecycle_findings`. `P1` because 8 days is risky; `P0` would apply if expiry is within 24h or if cert is already expired.

---

## Example 5: gitops_deploy mode — Helm values diff across three services

**Scenario:** Helm chart upgrade changes resource limits on three microservices.

**Input given:**
- Helm diff: `payment-service`: `resources.limits.memory: 256Mi → 512Mi`
- Helm diff: `auth-service`: `resources.limits.cpu: 250m → 500m`
- Helm diff: `notification-service`: `replicaCount: 2 → 3`

**Expected output shape:**
```yaml
selected_mode: gitops_deploy
readiness: green
config_change_inventory:
  - config_key: payment-service.resources.limits.memory
    config_kind: CF08_resource_limits
    old_value_summary: "256Mi"
    new_value_summary: "512Mi"
    environment_scope: production
    reload_mode: rolling_restart
    owner: platform-team
    rollback_relevance: medium
    evidence: helm-diff
  - config_key: auth-service.resources.limits.cpu
    config_kind: CF08_resource_limits
    old_value_summary: "250m"
    new_value_summary: "500m"
    environment_scope: production
    reload_mode: rolling_restart
    owner: platform-team
    rollback_relevance: medium
    evidence: helm-diff
  - config_key: notification-service.replicaCount
    config_kind: CF02_infrastructure_config
    old_value_summary: "2 replicas"
    new_value_summary: "3 replicas"
    environment_scope: production
    reload_mode: rolling_restart
    owner: platform-team
    rollback_relevance: low
    evidence: helm-diff
secret_lifecycle_findings: []
blockers_and_pending: []
config_state:
  overall_ready_to_proceed: true
  reload_actions:
    - config_key: payment-service.resources.limits.memory
      reload_mode: rolling_restart
      owner: platform-team
    - config_key: auth-service.resources.limits.cpu
      reload_mode: rolling_restart
      owner: platform-team
    - config_key: notification-service.replicaCount
      reload_mode: rolling_restart
      owner: platform-team
self_check:
  passed: true
  failed_rules: []
```

**Key calibration:** Resource limit changes are `CF08_resource_limits`, not `CF01_application_config`. All three require `rolling_restart`. When no secrets are involved and all owners are known, `readiness: green` is appropriate even for multi-service changes.

---

## Example 4: secret rotation audit — CF03 全量密钥审计

**Scenario:** Security team requests pre-release audit of all secrets before payment-service deploy.

```yaml
metadata:
  readiness: amber
  selected_mode: secret_rotation_audit
config_change_inventory:
  - config_key: "payment.gateway.api_key_ref"
    config_kind: CF03_secret_config
    proposed_value: "vault://payment/gateway/api_key@v4"
    reload_mode: rolling_restart
    rollback_relevance: high
    confidence: high
secret_lifecycle_findings:
  - finding_id: SLF-001
    severity: P1
    secret_ref: "vault://payment/gateway/api_key"
    current_version: v3
    target_version: v4
    rotation_type: planned
    dry_run_evidence: confirmed
    action: "Verify v4 key is valid in staging before deploying to prod"
  - finding_id: SLF-002
    severity: P2
    secret_ref: "vault://payment/db/password"
    current_version: v1
    last_rotated: "2025-11-01"
    rotation_overdue: true
    action: "Schedule rotation within 30 days (policy: 180d max)"
config_state:
  overall_ready_to_proceed: true
  advisory_items: ["SLF-002: DB password rotation overdue — non-blocking for this deploy"]
self_check:
  passed: true
  warnings: ["SLF-002: advisory rotation overdue item"]
```


---

## Real-world scenario calibration
See `references/real-examples.md` for three annotated scenarios covering minimal standalone (single diff), pipeline contract mode (full 106→107→108 chain), and degraded upstream handling.

For config kind definitions (CF01–CF08) and reload-mode guidance, see `references/configuration-change-categories.md`.
For secret lifecycle field requirements, see `references/configuration-change-categories.md` § Secret lifecycle fields.
For failure mode handling (FM01–FM06), see `references/failure-modes.md`.