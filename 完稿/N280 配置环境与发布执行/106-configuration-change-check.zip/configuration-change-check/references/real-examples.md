# configuration-change-check examples

## Example A: feature flag rollout
Input: release notes, a remote flag diff, and staging verification evidence.
Output focus: `CF04 feature_flag`, `reload_mode: hot_reload`, disable path, progressive rollout note, and 108 handoff.

## Example B: secret rotation
Input: vault path change, certificate metadata, and service ownership map.
Output focus: `CF03 secrets`, masked values, rotation schedule, revocation path, access audit, and P0/P1 blocker if plaintext is present.

## Example C: Helm resource change
Input: `values.yaml` diff changing replicas and memory limits.
Output focus: `CF08 resource_limits`, restart or rolling update impact, capacity risk, verification command, and drift-detection note.

## Anti-example D: raw secret pasted into release notes
Bad input pattern: a release note includes `payment_api_key=sk_live_...` and asks to normalize it into config.
Correct behavior: do not repeat or normalize the secret. Mark `readiness: blocked`, create a `secret_blocker` SLA item, require rotation/revocation evidence, and include only masked value summaries.

## Anti-example E: asking 106 to generate the release DAG
Bad request: "classify these config changes and produce the exact production deployment sequence."
Correct behavior: output config classification, `reload_mode`, blockers, and `config_state`; hand off executable sequencing to `release-task-orchestration`.
