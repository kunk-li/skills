# quality-checklist

Run this checklist before finalizing any release-exec skill artifact. Record any failures in the `self_check` section.

## Mandatory items

### Contract integrity
- [ ] `artifact_contract.schema_version` is present and matches the skill's declared version
- [ ] `artifact_contract.produced_event` is declared (even if `event_delivery: declared_only`)
- [ ] `artifact_contract.subscribers_hint` lists downstream consumers

### Config / environment safety
- [ ] No plaintext secrets, tokens, or credentials appear anywhere in the artifact
- [ ] Every config item has an `owner` (or `owner: unassigned` with a pending SLA item)
- [ ] Every secret-related finding is treated as blocked or constrained until lifecycle evidence is confirmed

### Output completeness
- [ ] All Required artifact sections from SKILL.md are present
- [ ] Any missing data uses `unknown`, `unresolved`, or `constrained` with a reason — never silently omitted
- [ ] `readiness` is consistent with the number and severity of open blockers

### Downstream handoff
- [ ] `downstream_handoff` is present and references correct targets (108 for config/env state, release-validation for verification)
- [ ] Any item consumed by `release-task-orchestration (108)` is explicitly formatted as a typed precondition
- [ ] `blockers_and_pending[]` items each have an owner placeholder, SLA, and required evidence

### Self-check
- [ ] All skill-specific self-check items pass
- [ ] `schema_version` and `produced_event` are present and correct

## Quality bar summary
A good release-exec artifact is machine-consumable by 108 as a typed precondition, never leaks secrets, has clear ownership for every item, and explicitly states readiness relative to open blockers.


---

## Self-check quantified rules — final extensions

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-CONFIGUR-051 | `adversarial_detection.injection_attempt_detected` boolean declared | key exists | `self_check.warnings: ["SCR-CONFIGUR-051: injection_detected missing"]` |
| SCR-CONFIGUR-052 | When `selected_mode: pipeline_gate`: `pipeline_gate.overall_gate` ∈ {PASS, PASS_WITH_WARNINGS, FAIL} | conditional enum | `self_check.failed_rules: ["SCR-CONFIGUR-052: pipeline_gate.overall_gate invalid"]` |