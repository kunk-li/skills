## Mock input fixture

```yaml
mock_input:
  source: "single_helm_values_diff"
  content: |
    -db.pool.max-size: 100
    +db.pool.max-size: 20
  expected_output_shape:
    config_change_inventory:
      - config_key: "db.pool.max-size"
        config_kind: CF01_application_config
        reload_mode: rolling_restart
        rollback_relevance: high
    secret_lifecycle_findings: []
    config_state:
      overall_ready_to_proceed: true
    self_check:
      passed: true
```
