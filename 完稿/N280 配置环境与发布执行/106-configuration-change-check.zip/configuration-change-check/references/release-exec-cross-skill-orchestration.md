# cross-skill-orchestration-release-exec

Detailed orchestration guidance for the three release-exec skills in both standalone and pipeline modes.

## Standalone mode summary

| Skill | Minimum viable run | Produces |
|---|---|---|
| configuration-change-check (106) | One config diff or secret change + target env | `配置变更检查单.csv` with config_kind, reload_mode, secret findings |
| environment-difference-check (107) | Two environment snapshots (baseline + target) | `环境差异检查单.csv` with parity verdict, readiness scores |
| release-task-orchestration (108) | Release description + service + target env | `发布任务编排表.csv` with sequential task DAG, manual gates |

## Pipeline mode (pipeline_contract_mode)

```
106 config-change-check
    ↓ config_state (reload_mode per config item, blockers)
107 environment-difference-check
    ↓ environment_state (overall_ready_to_proceed, blocker_differences)
108 release-task-orchestration
    ↓ node_artifact_package → release-validation
```

### Precondition gate
108 must not start deploy-phase tasks if `environment_state.overall_ready_to_proceed: false`.

### Handoff schema

```yaml
# 106 → 107
config_state:
  reload_actions: [{task_id, reload_mode, config_key, owner, blocker_if_failed}]
  overall_ready_to_proceed: true | false

# 107 → 108
environment_state:
  parity_verdict: full | partial | not_assessed
  overall_ready_to_proceed: true | false
  blocker_differences: [{difference_id, severity, description}]
  advisory_differences: [{difference_id, severity}]
```

## Error and degradation paths

| Condition | Handling |
|---|---|
| 106 missing — only env snapshots | 107 runs in standalone mode; 108 uses conservative sequential mode |
| 107 missing — only config diff | 108 uses config reload_mode but cannot verify parity |
| Both 106 and 107 missing | 108 must use simple_sequential mode with full manual gates |
| 106 readiness: red | 107 must note upstream_gap; 108 must block deploy-phase tasks |
| 107 overall_ready_to_proceed: false | 108 must gate all deploy tasks behind manual approval |

## Join keys

```yaml
composition_join_keys:
  - release_id
  - schema_version
  - produced_event
  - workflow_node: release-exec
```

## Downstream to release-validation

108 emits `produced.release-exec.release_task_orchestration.v2`. release-validation skills consume:
- `release_execution_package.release_id`
- `checkpoint_and_resume_rules`
- `observability_and_notifications.alert_routing`
