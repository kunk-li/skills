# failure-modes

Common failure modes in release-exec release-execution skills and how to handle them.

## FM01: Upstream artifact absent (106/107 missing)
- **Symptom:** `configuration-change-check` or `environment-difference-check` output not provided.
- **Impact:** 108 cannot use typed preconditions; parallelism unsafe.
- **Handling:** Apply conservative sequential DAG. Mark `readiness: amber`. Do not refuse output.

## FM02: Reload mode unknown
- **Symptom:** `reload_mode: unknown` on one or more config items.
- **Impact:** 108 cannot safely determine phase ordering for that service.
- **Handling:** Default to `full_restart` assumption. Mark the config item as `constrained`. Emit SLA queue item for owner to confirm.

## FM03: DK6 secret inconsistency detected
- **Symptom:** Staging uses plaintext secret; production uses vault reference (or vice versa).
- **Impact:** Hard security blocker.
- **Handling:** Emit `readiness: red`. Add P0 blocker. Block all deploy-phase tasks in 108 until resolved.

## FM04: Missing owner or approver
- **Symptom:** `owner: unassigned` on a required approval gate.
- **Impact:** Human approval cannot proceed.
- **Handling:** Keep `owner: unassigned`. Emit SLA queue item. Mark gate as `blocked`. Do not invent owner names.

## FM05: Migration required but confirmation signal absent
- **Symptom:** `reload_mode: migration_required` but no `confirmation_signal` or `confirmation_owner` defined.
- **Impact:** 108 cannot safely advance past migration phase.
- **Handling:** Keep deploy phase in `pre_deploy_hold`. Require explicit confirmation before proceeding.

## FM06: Double-partial (106 and 107 both readiness: partial)
- **Symptom:** Both upstream release-exec skills return partial readiness.
- **Impact:** 108 has no reliable preconditions.
- **Handling:** Apply the double-partial resolution rule defined in 107. Emit SLA queue item to release-manager.
