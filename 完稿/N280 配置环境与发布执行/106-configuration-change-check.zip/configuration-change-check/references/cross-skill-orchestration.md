# cross-skill-orchestration

Describes how the three release-exec skills collaborate in a full pipeline run.

## Canonical sequence

```
configuration-change-check (106)
        │
        │  config_state (config items, reload_mode, secret findings, blockers)
        ▼
environment-difference-check (107)
        │
        │  environment_state (difference_register, parity_verdict, overall_ready_to_proceed)
        ▼
release-task-orchestration (108)
        │
        │  downstream_handoff → release-validation verification hooks
        ▼
     release-validation post-release validation
```

## Join keys
All three skills share these join keys for artifact correlation:
- `schema_version` (must match across 106, 107, 108)
- `release_id` or `release_manifest.release_id`
- `produced_event` chain (106 → 107 → 108)

## Partial composition rules
- **106 only:** 107 and 108 run in standalone/conservative mode.
- **107 only:** 108 marks config preconditions as unresolved; applies conservative sequencing.
- **106 + 107:** 108 can use full `pipeline_contract_mode` with safe parallelism.
- **All three:** 108 emits the full release-exec node-level package `produced.release-exec.environment_release_execution_package.v2`.

## Refresh triggers
- If 106 is re-run and `config_state` changes, 107 must re-evaluate affected differences.
- If 107 `environment_state.overall_ready_to_proceed` changes, 108 must re-check preconditions.
- 108 emits `downstream_handoff.refresh_triggers: [release-validation]` when the DAG changes.


---

## Boundary comparison table — config-check vs env-diff vs release-risk vs release-task

| Dimension | configuration-change-check | environment-difference-check | release-risk-assessment | release-task-orchestration |
|---|---|---|---|---|
| **Primary question** | "What configs are changing and how do they reload?" | "Are staging and prod environments in parity?" | "Is the release safe overall?" | "How do we sequence the deployment?" |
| **Output type** | Config change inventory: config_kind, reload_mode, rollback_relevance | Environment diff register: difference_kind, severity, parity_verdict | Risk register: 12 risk categories, composite score | Execution DAG with dependencies |
| **Scope** | Changed configuration items only (not environment state) | Environment state comparison (staging vs prod) | Holistic release risk across all dimensions | Execution sequencing and gate management |
| **Owns** | Config classification (CF01–CF08), reload mode analysis, secret lifecycle | Env parity scoring, isolation findings, critical diff detection | Risk scoring, circuit breaker recommendation | Task DAG, approval gates, circuit breaker execution |
| **Does not own** | Env parity (→107), holistic risk (→101), execution (→108) | Config change details (→106), risk scoring (→101) | Config-level classification (→106), env state (→107) | Config analysis (→106), env analysis (→107) |

### Canonical 106/107 sequence
```
106 (config changes) + 107 (env parity) → both consumed by 108 as precondition evidence
106 focuses on WHAT is changing; 107 focuses on WHERE it's deployed (env consistency)
106 and 107 run INDEPENDENTLY and in PARALLEL when possible
Both 106 and 107 must have overall_ready_to_proceed: true before 108 starts P3 execution
```