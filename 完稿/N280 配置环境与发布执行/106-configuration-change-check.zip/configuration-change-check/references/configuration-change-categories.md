# Configuration Change Categories v2.1

## Canonical config kinds
- `CF01 application_config`: business toggles, service-level functional parameters, timeouts, pool sizes.
- `CF02 infrastructure_config`: deployment specs, ingress, service mesh, Helm values, Terraform, K8s objects.
- `CF03 secrets`: credentials, tokens, certificates, private keys, API keys.
- `CF04 feature_flag`: gated release toggles, cohort switches, experiment flags.
- `CF05 policy_config`: compliance, authorization, security, governance, retention policy switches.
- `CF06 monitoring_config`: alerts, dashboards, scraping, SLO thresholds, trace sampling, log levels.
- `CF07 network_config`: DNS, routing, TLS, firewall, allow-lists, external endpoints.
- `CF08 resource_limits`: CPU, memory, replicas, quota, autoscaling thresholds.

## v2 change-kind mapping
| config_kind | v2 change_kind |
|---|---|
| CF01 | CK1_application_config or CK5_database_config |
| CF02 | CK4_infrastructure_config |
| CF03 | CK3_secret_credential |
| CF04 | CK2_feature_flag |
| CF05 | CK1_application_config or CK4_infrastructure_config |
| CF06 | CK7_observability_config |
| CF07 | CK6_external_service_endpoint |
| CF08 | CK4_infrastructure_config |

## Required review fields
Every config row should evaluate:
- affected services and environments.
- owner and reviewer role.
- evidence source.
- sensitivity and masking status.
- reload mode.
- rollout impact.
- verification method.
- rollback relevance.
- drift-detection requirement.

## Secret lifecycle fields
For `CF03`, include:
- `storage`: vault, cloud secret manager, sealed secret, Kubernetes secret, or unknown.
- `access_control`: role-based, least privilege, audit enabled, or unknown.
- `encryption`: at rest and in transit evidence.
- `rotation_scheduled`: yes, no, unknown.
- `revocation_on_compromise`: yes, no, unknown.
- `distribution_method`: injected at startup, fetched at runtime, mounted filesystem, or unknown.

## Reload-mode guidance
- `hot_reload`: runtime reload supported and evidence exists.
- `rolling_restart`: restart required but can be done gradually.
- `full_restart`: all instances or critical dependency requires coordinated restart.
- `migration_required`: config interacts with schema, data, or irreversible state changes.
- `manual_trigger`: human or external system must apply the change.
- `unknown`: evidence is insufficient; mark readiness `constrained` or `blocked` depending on risk.
