# field-contract — configuration-change-check

Canonical field definitions for the `configuration_change_check` artifact produced by this skill.
This file complements `references/release-exec-shared-contract.md`, which defines the shared artifact header.
Fields defined here are specific to this skill's output sections.

## Core artifact header fields
See `references/release-exec-shared-contract.md` for the full shared header specification.
Key required fields from the shared contract:
| Field | Type | Required | Value |
|---|---|---|---|
| `schema_version` | string | yes | `release-exec.configuration-change-check.v2.2.1` |
| `artifact_type` | string | yes | `configuration_change_check` |
| `producer_skill` | string | yes | `configuration-change-check` |
| `workflow_node` | string | yes | `release-exec` |
| `readiness` | enum | yes | `ready` \| `constrained` \| `blocked` |
| `selected_mode` | enum | yes | See mode list in SKILL.md |

## Config change inventory fields
| Field | Type | Required | Description |
|---|---|---|---|
| `config_key` | string | yes | The config key, env var name, or file path being changed |
| `config_kind` | enum | yes | One of CF01–CF08 (see configuration-change-categories.md) |
| `reload_mode` | enum | yes | `no_restart` \| `rolling_restart` \| `full_restart` \| `unknown` |
| `rollback_relevance` | enum | yes | `reversible` \| `irreversible` \| `conditional` |
| `owner` | string | yes | Team or individual responsible for this config change |
| `config_value_before` | string | no | Previous value (redact secrets — use `[REDACTED]`) |
| `config_value_after` | string | no | New value (redact secrets — use `[REDACTED]`) |
| `drift_note` | string | no | Any known drift from expected state |

## Secret lifecycle fields (required for CF03 items)
| Field | Type | Required | Description |
|---|---|---|---|
| `secret_id` | string | yes | Identifier for the secret (not the value itself) |
| `rotation_required` | boolean | yes | Whether rotation must occur before deployment |
| `plaintext_detected` | boolean | yes | Whether a plaintext secret value was found in the diff |
| `stale_reference` | boolean | yes | Whether the secret reference points to an outdated version |
| `remediation` | string | yes | Required action before deployment (e.g., "rotate and update vault reference") |

## Blockers and pending fields
| Field | Type | Required | Description |
|---|---|---|---|
| `blocker_id` | string | yes | Unique identifier for the blocker |
| `blocker_type` | enum | yes | `unknown_reload_mode` \| `secret_risk` \| `missing_owner` \| `irreversible_change` |
| `blocking` | boolean | yes | Whether this blocker prevents deployment |
| `resolution_path` | string | yes | What must be done to clear this blocker |

## Config state handoff fields (consumed by 107 and 108)
| Field | Type | Required | Description |
|---|---|---|---|
| `config_state.overall_config_safe` | boolean | yes | True only when all CF03 items are resolved and all reload_modes are known |
| `config_state.restart_required` | boolean | yes | True if any item has `rolling_restart` or `full_restart` |
| `config_state.estimated_downtime_seconds` | integer | no | Estimated downtime if full_restart is required |
| `config_state.handoff_to_107` | object | no | Evidence slice for environment-difference-check (107) |
| `config_state.handoff_to_108` | object | no | reload_mode per item for release-task-orchestration (108) |

## Confidence-to-evidence mapping
| Evidence available | Max config_safe confidence |
|---|---|
| Full diff + owner confirmed + reload tested | `high` |
| Full diff + owner confirmed | `medium` |
| Diff only, no owner | `low` |
| Verbal description only | `speculative` |

## Null / unknown handling
- `reload_mode: unknown` is valid when the config owner has not confirmed restart behaviour. Do not infer `no_restart` without evidence.
- `config_value_before` and `config_value_after` must use `[REDACTED]` for any CF03 (secrets) items. Never include plaintext secret values in the artifact.
- `owner: unknown` triggers a `blocker_type: missing_owner` entry automatically.


---

## Field contract — secret_lifecycle_findings entry

| Field | Required | Values |
|---|---|---|
| `finding_id` | yes | `SLF-{NNN}` |
| `severity` | yes | ∈ {P0, P1, P2} |
| `description` | yes | clear finding text |
| `action` | yes | ∈ {block_release, rotate_before_deploy, monitor, none} |
| `evidence_ref` | yes | config_key or file reference |