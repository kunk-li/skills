# readiness-inheritance

Defines how readiness values propagate across release-exec skills.

## Inheritance rules

| Upstream readiness | Effect on downstream |
|---|---|
| 106 readiness: green | 107 can run in `pipeline_contract_mode`; 108 can use parallelism |
| 106 readiness: amber | 107 marks config preconditions as constrained; 108 uses conservative sequential |
| 106 readiness: red | 107 must not proceed to environment parity analysis until 106 is resolved; 108 is blocked |
| 107 readiness: green | 108 can proceed with full `pipeline_contract_mode` |
| 107 readiness: amber | 108 applies conservative sequencing; no parallelism |
| 107 readiness: red | 108 is blocked on deploy phase; applies `pre_deploy_hold` |
| Both 106 + 107 partial | Apply double-partial resolution rule (see cross-skill-orchestration.md) |

## Circuit breaker inheritance
- If 108 pipeline_level_circuit_breaker opens, the `readiness: red` is emitted to release-validation.
- release-validation must not issue a GO recommendation when receiving a red from 108.

## Green conditions
A skill may return `readiness: green` only when:
1. All required sections are present and complete.
2. No P0 or critical blockers exist.
3. All mandatory contract fields are populated.
4. Self-check passes all rules.
