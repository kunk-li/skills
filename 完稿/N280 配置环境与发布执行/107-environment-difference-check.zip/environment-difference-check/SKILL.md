---
name: environment-difference-check
description: generate n280 release-execution environment difference checks from environment snapshots, configuration inventories, release artifacts, allowed-difference policies, or prior configuration-change-check output. use for standalone parity review or pipeline contract mode after 106 and before release-task-orchestration. produces a versioned 环境差异检查单 artifact with schema metadata, difference kind, allowed registry, readiness score, drift trend, isolation findings, and event handoff.
---
# environment-difference-check

## Role
Use this skill to inspect differences across dev, test, staging, prod, and dr environments in N280. It is the authoritative skill for parity analysis, allowed-difference documentation, drift visibility, readiness scoring, and isolation observations.

## Boundary
- Own environment difference discovery, allowed-difference rationale, `difference_kind`, `difference_nature`, topology visibility, readiness score, drift trend, and isolation observations.
- Consume 106 config-state when available; do not reinterpret config semantics already classified by `configuration-change-check`.
- Do not replace security review skills; isolation findings describe observed environment reachability and evidence gaps.
- Do not replace `release-task-orchestration`; provide readiness and remediation inputs for 108.
- Do not make final enterprise gate decisions; N380 or the user decides final pass/block.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `schema_version`, `produced_event`, and `event_delivery` at the top.

Allowed modes:
- `snapshot_mode`: compare available environment snapshots.
- `drift_detection`: focus on desired-vs-actual and cross-environment drift.
- `isolation_audit`: inspect lower-environment access to production data, credentials, or network paths.
- `pipeline_contract_mode`: require and consume 106 `config_state` / `配置变更检查单.csv` before producing the 107 artifact.
- `allowed_list_review`: audit allowed differences and review cadence.

## Inputs
Preferred N280 workflow inputs:
- `发布说明.md`
- `发版检查清单.csv`
- `环境配置清单`

Pipeline contract mode inputs:
- `configuration-change-check` artifact or `配置变更检查单.csv`
- `config_state` handoff with config keys, owners, environment scope, and `reload_mode`

Useful enhancement inputs:
- environment snapshots, live facts, topology diagrams, cluster manifests, GitOps desired state.
- allowed-difference policy, baseline environment, drift history, network policy exports, staging readiness notes.

Standalone rule:
- Work with one environment pair, one staging-vs-prod comparison, one release-slice snapshot, or one isolation audit.
- If only one snapshot exists, produce observations and unknowns rather than fake comparisons.

## Required artifact contract
Use `references/n280-shared-contract.md`. The metadata must include:

```yaml
artifact_contract:
  schema_version: n280.environment-difference-check.v2.2.1
  artifact_type: environment_difference_check
  producer_skill: environment-difference-check
  workflow_node: N280
  produced_event: produced.n280.environment_difference_check.v2
  event_delivery: declared_only
  subscribers_hint: [N290, N330, N350, N380, N390]
```

The result must include:
- `artifact_contract`
- `environment_inventory`
- `difference_register[]`
- `difference_kind_summary`
- `allowed_differences_registry`
- `environment_topology`
- `env_readiness_scores`
- `drift_trend`
- `isolation_findings`
- `remediation_queue[]`
- `downstream_handoff`
- `self_check`

## Design rules
- Tag every observed difference with one `difference_nature`: `legitimate`, `drift`, `pending_consolidation`, or `unknown`.
- Also tag each difference with one v2 `difference_kind`: `DK1_expected_difference`, `DK2_configuration_drift`, `DK3_missing_in_environment`, `DK4_value_significant_divergence`, `DK5_deprecated_still_present`, `DK6_secret_handling_inconsistent`, `DK7_version_mismatch`, or `DK8_resource_allocation_difference`.
- Keep `difference_nature` as the simple decision layer and `difference_kind` as the detailed diagnostic layer.
- In `pipeline_contract_mode`, every 106 config item in scope must be accounted for as identical, expected-different, drifted, missing, unknown, or not observable.
- Allowed differences must include rationale, owner or approver, approval timestamp if known, review frequency, and expiry or next-review date when available.
- Score readiness across representativeness, config alignment, monitoring parity, isolation fitness, and evidence completeness.
- Readiness scores are inputs to N380; do not declare final enterprise pass/block unless the user explicitly asks for a local recommendation.
- Treat inconsistent secret handling as critical and emit an SLA queue item.

## Execution workflow
1. Collect release inputs, environment inventories, allowed-difference policy, and any 106 `config_state` handoff.
2. Compare environment facts across baseline and target environments.
3. Classify each difference with `difference_nature`, `difference_kind`, severity, allowed status, owner, evidence, and required follow-up.
4. Build topology, readiness scores, drift trend, and isolation findings.
5. Emit remediation queue, SLA queue items, and structured handoff for 108, N290, N330, and N380.

## Degradation rules
- Missing baseline: mark readiness `constrained`, propose a baseline, and do not overstate drift.
- Missing allowed-difference policy: classify differences as `unknown` or `drift` with review-needed status.
- Missing live facts: keep policy-only entries separate from observed runtime differences.
- Partial topology: score conservatively and list required evidence.

## Self-check
Before finalizing, verify:
- Every difference has both `difference_nature` and `difference_kind`.
- Allowed differences have rationale and review metadata or a pending item.
- 106 inputs are strongly consumed in `pipeline_contract_mode`.
- `schema_version` and `produced_event` are present.
- `env_readiness_scores` are evidence-backed and not used as final N380 approval.
- Downstream handoff includes `environment_state` and 108-safe readiness/blocker fields.

## Node-level package handoff
When the user asks for a complete N280 package or when at least two N280 artifacts are available, include or update the optional `node_level_package` described in `references/n280-shared-contract.md`. If 108 is available, hand the package responsibility to 108 as the default producer; otherwise create a partial package and mark missing artifacts explicitly.

## References
- `references/n280-shared-contract.md`
- `references/environment-diff-dimensions.md`
- `references/real-examples.md`
