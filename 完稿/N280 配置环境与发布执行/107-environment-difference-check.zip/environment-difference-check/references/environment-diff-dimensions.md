# Environment Difference Dimensions v2.1

## Recommended comparison dimensions
- version and artifact parity.
- config and secret source parity.
- scale, replicas, CPU, memory, and capacity parity.
- monitoring, alert, dashboard, log, and trace parity.
- network reachability, DNS, TLS, firewall, and isolation.
- dependency mode parity: real, sandbox, mock, stub, or disabled.
- data representativeness, freshness, masking, and sample size.
- compliance, policy, auth, and governance switches.

## Difference nature guidance
- `legitimate`: intentional, documented, approved, and reviewable.
- `drift`: should match the baseline but does not.
- `pending_consolidation`: known mismatch with accepted remediation plan.
- `unknown`: new or unexplained mismatch requiring evidence.

## Detailed difference kinds
- `DK1_expected_difference`: allowed and documented environment-specific value.
- `DK2_configuration_drift`: unexpected mismatch against baseline or desired state.
- `DK3_missing_in_environment`: required key, resource, dependency, or version missing in an environment.
- `DK4_value_significant_divergence`: values differ enough to affect test validity, performance, or risk.
- `DK5_deprecated_still_present`: retired key or resource still exists.
- `DK6_secret_handling_inconsistent`: secret storage, masking, or access control differs unsafely.
- `DK7_version_mismatch`: artifact, dependency, schema, or config version mismatch.
- `DK8_resource_allocation_difference`: CPU, memory, replicas, quota, autoscaling, or storage divergence.

## Readiness scoring anchors
- 90 or above: ready for release validation or realistic rehearsal.
- 75 to 89: usable with clear follow-up actions.
- below 75: insufficient for confident release execution rehearsal.

## Allowed-difference registry fields
Each allowed difference should include:
- `config_key` or resource identifier.
- environments where the difference is allowed.
- rationale.
- owner or approver.
- approval timestamp if known.
- review frequency.
- expiry or next-review date if available.
- suspicious marker for auth, secret, security, or feature-flag differences.
