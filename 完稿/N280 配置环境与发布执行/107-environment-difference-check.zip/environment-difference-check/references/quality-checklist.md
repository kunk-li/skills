# quality-checklist

Run this checklist before finalizing any release-exec skill artifact. Record any failures in the `self_check` section.

## Mandatory items

### Contract integrity
- [ ] `artifact_contract.schema_version` is present and matches the skill's declared version
- [ ] `artifact_contract.produced_event` is declared (even if `event_delivery: declared_only`)
- [ ] `artifact_contract.subscribers_hint` lists downstream consumers

### Config / environment safety
- [ ] No plaintext secrets, tokens, or credentials appear anywhere in the artifact
- [ ] Every config item has an `owner` (or `owner: unassigned` with a pending SLA item)
- [ ] Every secret-related finding is treated as blocked or constrained until lifecycle evidence is confirmed

### Output completeness
- [ ] All Required artifact sections from SKILL.md are present
- [ ] Any missing data uses `unknown`, `unresolved`, or `constrained` with a reason — never silently omitted
- [ ] `readiness` is consistent with the number and severity of open blockers

### Downstream handoff
- [ ] `downstream_handoff` is present and references correct targets (108 for config/env state, release-validation for verification)
- [ ] Any item consumed by `release-task-orchestration (108)` is explicitly formatted as a typed precondition
- [ ] `blockers_and_pending[]` items each have an owner placeholder, SLA, and required evidence

### Self-check
- [ ] All skill-specific self-check items pass
- [ ] `schema_version` and `produced_event` are present and correct

## Quality bar summary
A good release-exec artifact is machine-consumable by 108 as a typed precondition, never leaks secrets, has clear ownership for every item, and explicitly states readiness relative to open blockers.


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-ENVIRONM-051 | Every diff has `difference_kind` ∈ {DK1..DK8} | enum check | `self_check.failed_rules: ["SCR-ENVIRONM-051: difference_kind out of range"]` |
| SCR-ENVIRONM-052 | `env_readiness_scores.overall` numeric 0–10 | range check | `self_check.failed_rules: ["SCR-ENVIRONM-052: env_readiness_scores missing or invalid"]` |
| SCR-ENVIRONM-053 | Score < 7 → `gap_reasons[]` declared | conditional | `self_check.failed_rules: ["SCR-ENVIRONM-053: score <7 without gap_reasons"]` |
| SCR-ENVIRONM-054 | `parity_verdict` ∈ {full, partial, not_assessed} | enum check | `self_check.failed_rules: ["SCR-ENVIRONM-054: parity_verdict missing"]` |
| SCR-ENVIRONM-055 | `severity: critical` diff → `overall_ready_to_proceed: false` | conditional | `self_check.failed_rules: ["SCR-ENVIRONM-055: critical diff without blocking flag"]` |
| SCR-ENVIRONM-056 | `isolation_findings` present (may be `[]`) | key exists | `self_check.failed_rules: ["SCR-ENVIRONM-056: isolation_findings omitted entirely"]` |
| SCR-ENVIRONM-057 | No plaintext secrets in diff values | regex on secret fields | `self_check.warnings: ["SCR-ENVIRONM-057: possible plaintext secret in diff values"]` |
| SCR-ENVIRONM-058 | `downstream_handoff` to 108 present | key check | `self_check.failed_rules: ["SCR-ENVIRONM-058: handoff to 108 missing"]` |
| SCR-ENVIRONM-059 | `adversarial_detection` present | key exists | `self_check.warnings: ["SCR-ENVIRONM-059: adversarial_detection missing"]` |
| SCR-ENVIRONM-060 | `feedback_signal_candidates` ≥ 1 | count ≥ 1 | `self_check.warnings: ["SCR-ENVIRONM-060: FSC missing"]` |
| SCR-ENVIRONM-061 | No "chatgpt" in content | string search | `self_check.failed_rules: ["SCR-ENVIRONM-061: chatgpt brand word — BLOCKER"]` |