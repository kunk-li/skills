## Mock input fixture

```yaml
mock_input:
  source: "two_environment_snapshots"
  content: |
    staging: {db.pool.max-size: 20, feature.checkout: true}
    production: {db.pool.max-size: 100, feature.checkout: false}
  expected_output_shape:
    difference_register:
      min_entries: 2
    parity_verdict: partial
    env_readiness_scores:
      overall: present
    self_check:
      passed: true
```
