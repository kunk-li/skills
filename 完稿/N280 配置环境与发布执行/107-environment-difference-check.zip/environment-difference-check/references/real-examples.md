# environment-difference-check examples

## Example A: staging vs prod config parity
Input: staging and prod config snapshots plus allowed differences.
Output focus: `DK2_configuration_drift` for unexpected mismatches, `DK1_expected_difference` for approved endpoints, and readiness score.

## Example B: 106 pipeline mode
Input: `配置变更检查单.csv` from 106 plus environment snapshots.
Output focus: each changed config key is verified across environments as aligned, expected-different, drifted, missing, or unknown.

## Example C: isolation audit
Input: network policy exports and database connection summaries.
Output focus: lower-environment access to prod credentials or data is reported as evidence-backed isolation finding and SLA queue item.

## Anti-example D: missing baseline but asked to declare drift
Bad input pattern: only a staging snapshot is provided and the request asks to say whether prod drift exists.
Correct behavior: mark baseline as missing, set readiness to `constrained`, produce observations and required evidence, and do not invent prod comparisons.

## Anti-example E: asking 107 to make final enterprise gate decision
Bad request: "staging differs from prod; approve or block the whole release."
Correct behavior: classify differences, compute evidence-backed readiness score, emit blockers or SLA items, and state that N380 or the user makes the final pass/block decision.
