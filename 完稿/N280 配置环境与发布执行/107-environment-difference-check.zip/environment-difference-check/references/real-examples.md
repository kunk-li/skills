# real-examples

## Example 1: Configuration change check — minimal input (106)

**Scenario:** Single `application.yml` diff, no prior release artifacts.

**Input given:**
- Config diff: `db.pool.max-size` changed from `100` to `20`
- Environment: production
- Owner info: unknown

**Expected output shape:**
```yaml
readiness: partial
config_change_inventory:
  - config_key: db.pool.max-size
    config_kind: CF01_application_config
    old_value_summary: "100 connections"
    new_value_summary: "20 connections"
    environment_scope: production
    reload_mode: rolling_restart
    owner: unassigned
    evidence: config-diff-provided
    rollback_relevance: high
blockers_and_pending:
  - item: "Owner unassigned for db.pool.max-size change"
    severity: P1
    required_evidence: "service owner confirmation"
    sla: 4h before release
```

**Key calibration:** Even with minimal input, every config item must get a `config_kind`, `reload_mode`, and `rollback_relevance`. Missing owner → `unassigned` + blocker, not omitted.

---

## Example 2: Environment difference check — pipeline_contract_mode (107)

**Scenario:** 106 config_state available; comparing staging vs prod.

**Input given:**
- 106 output with `config_state` for 3 config items
- Staging snapshot vs prod snapshot

**Expected output shape:**
```yaml
selected_mode: pipeline_contract_mode
difference_register:
  - config_key: db.pool.max-size
    difference_nature: drift
    difference_kind: DK4_value_significant_divergence
    staging_value: "20"
    prod_value: "100"
    severity: high
    allowed: false
    rationale: null
    remediation: "Apply db.pool.max-size=20 to prod before release OR revert to 100"
env_readiness_scores:
  representativeness: 6/10
  config_alignment: 4/10
```

**Key calibration:** Every 106 config item must be accounted for (identical / expected-different / drifted / missing / unknown). A readiness score below 7 must include the specific gaps that caused the reduction.

---

## Example 3: Release task orchestration — degraded upstream (108)

**Scenario:** 106 output exists but 107 is missing.

**Expected output shape:**
```yaml
selected_mode: dag_enterprise
readiness: partial
evidence_profile:
  missing: [environment-difference-check]
  impact: "Environment parity cannot be confirmed; conservative sequencing applied"
dag_overview:
  parallelism: disabled  # conservative due to missing 107
task_registry:
  - task_id: T01
    phase: pre_deploy
    dependencies: []
    owner: release-manager
    on_failure: abort
    resumability: idempotent
    precondition_status: unresolved  # 107 not provided
blockers_and_pending:
  - item: "107 environment_state not provided"
    action: "Run environment-difference-check before proceeding to T05+"
```

**Key calibration:** Missing 107 → mark env preconditions `unresolved`, apply conservative sequencing. Never assume environment parity without 107 evidence.

---

## Example 4: Standalone — staging vs prod, no 106, isolation concern detected

**Scenario:** User provides two environment snapshots. No 106 output. Staging has access to a production database credential.

**Input given:**
- Staging env snapshot: `DATABASE_URL=postgres://prod-db.internal:5432/appdb` (production DB referenced from staging)
- Prod env snapshot: `DATABASE_URL=postgres://prod-db.internal:5432/appdb`

**Expected output shape:**
```yaml
selected_mode: snapshot_mode
readiness: red
difference_register:
  - diff_id: D-001
    config_key: DATABASE_URL
    difference_kind: DK6_secret_handling_inconsistent
    difference_nature: drift
    staging_value: "postgres://prod-db.internal:***" # masked
    prod_value: "postgres://prod-db.internal:***"   # masked
    severity: critical
    allowed: false
    rationale: null
    owner: unassigned
    remediation: "Staging must use a dedicated staging database. Remove production DB reference from staging immediately."
isolation_findings:
  - finding_id: ISO-001
    description: "Staging environment has direct access to production database"
    severity: critical
    evidence: "DATABASE_URL identical in both environments"
    recommended_action: "Provision staging-specific database before any test or rehearsal run"
env_readiness_scores:
  config_alignment: 2
  representativeness: 3
  overall: 2.5
parity_verdict: partial
downstream_handoff:
  overall_ready_to_proceed: false
  blocker_differences: [D-001]
  next_best_checks:
    - "Resolve ISO-001 before running any tests in staging"
    - "Run configuration-change-check (106) to classify all secret items"
self_check:
  passed: false
  failed_rules: ["Critical isolation finding — staging accessing production data"]
```

**Key calibration:** Isolation findings are a first-class output section, not a footnote. `DK6_secret_handling_inconsistent` is the correct difference_kind even when both environments show the same value — the issue is that they *shouldn't* be the same.

---

## Example 5: drift_detection mode — desired vs actual GitOps state

**Scenario:** ArgoCD desired state differs from live cluster state. Three services have drifted.

**Input given:**
- GitOps desired state: payment-service image tag `v2.1.3`
- Live cluster: payment-service image tag `v2.1.1`
- GitOps desired: auth-service replicas `3`
- Live cluster: auth-service replicas `1` (scaled down manually)

**Expected output shape:**
```yaml
selected_mode: drift_detection
readiness: amber
difference_register:
  - diff_id: D-001
    config_key: payment-service.image.tag
    difference_kind: DK7_version_mismatch
    difference_nature: drift
    desired_value: "v2.1.3"
    actual_value: "v2.1.1"
    severity: high
    allowed: false
    remediation: "Trigger ArgoCD sync for payment-service to apply v2.1.3"
    owner: devops-team
  - diff_id: D-002
    config_key: auth-service.replicaCount
    difference_kind: DK8_resource_allocation_difference
    difference_nature: drift
    desired_value: "3"
    actual_value: "1"
    severity: medium
    allowed: false
    remediation: "Re-apply HPA or manually scale auth-service to 3 replicas"
    owner: devops-team
env_readiness_scores:
  config_alignment: 5
  representativeness: 7
  overall: 6
parity_verdict: partial
downstream_handoff:
  overall_ready_to_proceed: true
  advisory_differences: [D-001, D-002]
  next_best_checks:
    - "Trigger ArgoCD sync before production promote"
    - "Verify auth-service HPA policy is not conflicting with desired replicas"
self_check:
  passed: true
  warnings: ["2 drift items require sync before safe deploy"]
```

**Key calibration:** `drift_detection` mode compares desired-state (GitOps) vs actual-state (live cluster). Use `DK7` for version mismatches and `DK8` for resource allocation divergence. Advisory differences do not block `overall_ready_to_proceed` but must be listed.

---

## Example 4: infrastructure_parity mode — cloud provider configuration drift

**Scenario:** After a Kubernetes cluster upgrade in prod, check if staging and prod configurations are still aligned.

```yaml
metadata:
  readiness: amber
  selected_mode: full_comparison
difference_register:
  - diff_id: DIFF-001
    config_key: "kubernetes.version"
    difference_kind: DK2_infrastructure_config
    difference_nature: version_drift
    severity: advisory
    staging_value: "1.28.4"
    prod_value: "1.29.1"
    rollback_safe: true
    action: "Schedule staging upgrade to 1.29.1 within 2 weeks"
  - diff_id: DIFF-002
    config_key: "node.instance_type"
    difference_kind: DK2_infrastructure_config
    difference_nature: capacity_difference
    severity: advisory
    staging_value: "t3.medium"
    prod_value: "m5.large"
    rollback_safe: true
    action: "Performance tests in staging may not represent prod behavior"
parity_verdict: partial
env_readiness_scores:
  overall: 8
  parity_gap_count: 2
  critical_diffs: 0
isolation_findings:
  - "Kubernetes version drift may affect API compatibility — test against 1.29.1 features"
config_state:
  overall_ready_to_proceed: true
  reason: "No critical blockers. Advisory diffs noted."
self_check:
  passed: true
  warnings: ["Advisory diffs present — review before next release cycle"]
```


---

## Real-world scenario calibration
See `references/real-examples.md` for three annotated scenarios:
1. **Minimal standalone** — two snapshots, no 106 input → amber output with inferred difference kinds.
2. **Pipeline contract mode** — 106 config_state consumed → full parity report with typed preconditions.
3. **Degraded upstream (108 missing 107)** — 108 receives no 107 output → conservative sequencing applied.

For difference kind definitions and readiness score anchors, see `references/environment-diff-dimensions.md`.
For readiness inheritance rules (106 → 107 → 108), see `references/readiness-inheritance.md`.
For failure mode handling (FM01–FM06), see `references/failure-modes.md`.