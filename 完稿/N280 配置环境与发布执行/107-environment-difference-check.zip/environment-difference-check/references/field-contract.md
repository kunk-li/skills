# field-contract — environment-difference-check

Canonical field definitions for the `environment_difference_check` artifact produced by this skill.
This file complements `references/release-exec-shared-contract.md`, which defines the shared artifact header.

## Core artifact header fields
See `references/release-exec-shared-contract.md` for the full shared header specification.
| Field | Type | Required | Value |
|---|---|---|---|
| `schema_version` | string | yes | `release-exec.environment-difference-check.v2.2.1` |
| `artifact_type` | string | yes | `environment_difference_check` |
| `producer_skill` | string | yes | `environment-difference-check` |
| `workflow_node` | string | yes | `release-exec` |
| `readiness` | enum | yes | `ready` \| `constrained` \| `blocked` |

## Environment identification fields
| Field | Type | Required | Description |
|---|---|---|---|
| `source_environment` | string | yes | The reference environment (typically `staging`) |
| `target_environment` | string | yes | The deployment target (typically `prod` or `prod-eu`, etc.) |
| `snapshot_timestamp_source` | string | yes | ISO8601 timestamp of source environment snapshot |
| `snapshot_timestamp_target` | string | yes | ISO8601 timestamp of target environment snapshot |
| `comparison_scope` | enum | yes | `full` \| `config_only` \| `version_only` \| `secret_only` |

## Difference register entry fields
| Field | Type | Required | Description |
|---|---|---|---|
| `diff_id` | string | yes | Unique identifier for this difference entry (e.g., `DIFF-001`) |
| `diff_kind` | enum | yes | One of DK1–DK8 (see environment-diff-dimensions.md) |
| `dimension` | string | yes | The specific attribute being compared (e.g., `image_tag`, `env_var.DATABASE_URL`) |
| `source_value` | string | yes | Value in source environment (`[REDACTED]` for secrets) |
| `target_value` | string | yes | Value in target environment (`[REDACTED]` for secrets) |
| `severity` | enum | yes | `critical` \| `high` \| `advisory` |
| `allowed` | boolean | yes | Whether this difference is in the allowed-difference registry |
| `allowed_reason` | string | if allowed=true | Documented reason why this difference is permitted |
| `blocking` | boolean | yes | Whether this difference blocks deployment |
| `resolution` | string | if blocking=true | What must be resolved before deployment |

## Parity verdict fields
| Field | Type | Required | Description |
|---|---|---|---|
| `env_readiness_score` | number (0–10) | yes | Overall parity score; 10 = fully aligned |
| `parity_verdict` | enum | yes | `aligned` \| `acceptable_drift` \| `unacceptable_drift` \| `blocked` |
| `critical_diff_count` | integer | yes | Number of `severity: critical` differences |
| `blocking_diff_count` | integer | yes | Number of `blocking: true` differences |

## Environment state handoff fields (consumed by 108)
| Field | Type | Required | Description |
|---|---|---|---|
| `environment_state.overall_ready_to_proceed` | boolean | yes | True only when `parity_verdict` is `aligned` or `acceptable_drift` AND `blocking_diff_count == 0` |
| `environment_state.diff_register_ref` | string | yes | Reference to the full diff register in the artifact |
| `environment_state.handoff_to_108` | object | no | Parity summary for release-task-orchestration (108) |

## Severity classification rules
| Severity | Criteria |
|---|---|
| `critical` | Version mismatch on core services, missing required env var, secret reference pointing to wrong vault path |
| `high` | Feature flag state mismatch, non-secret config value divergence affecting correctness |
| `advisory` | Minor config difference that does not affect correctness (e.g., logging verbosity, cache TTL difference within tolerance) |

## Allowed-difference registry rules
- Differences in the allowed registry are documented in `environment-diff-dimensions.md`.
- An allowed difference must have `allowed_reason` and must not be `severity: critical`.
- Allowed differences still appear in the diff register with `allowed: true`; they do not count toward `blocking_diff_count`.

## Null / unknown handling
- `source_value: unknown` and `target_value: unknown` are valid when snapshot access is partial. Treat as `severity: high` until confirmed.
- `env_readiness_score` must not exceed 7.0 when any `severity: critical` difference is present, regardless of blocking status.


---

## Field contract — difference_register entry

| Field | Required | Values / notes |
|---|---|---|
| `diff_id` | yes | `DIFF-{NNN}` format |
| `config_key` | yes | fully qualified key path |
| `difference_kind` | yes | ∈ {DK1..DK8} |
| `severity` | yes | ∈ {critical, high, advisory} |
| `staging_value` | yes | string or `unknown` |
| `prod_value` | yes | string or `unknown` |
| `rollback_safe` | yes | boolean |
| `action` | yes | imperative action string |
| `blocks_release` | yes | boolean; critical → must be true |