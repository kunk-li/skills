# cross-skill-orchestration

Describes how the three release-exec skills collaborate in a full pipeline run.

## Canonical sequence

```
configuration-change-check (106)
        │
        │  config_state (config items, reload_mode, secret findings, blockers)
        ▼
environment-difference-check (107)
        │
        │  environment_state (difference_register, parity_verdict, overall_ready_to_proceed)
        ▼
release-task-orchestration (108)
        │
        │  downstream_handoff → release-validation verification hooks
        ▼
     release-validation post-release validation
```

## Join keys
All three skills share these join keys for artifact correlation:
- `schema_version` (must match across 106, 107, 108)
- `release_id` or `release_manifest.release_id`
- `produced_event` chain (106 → 107 → 108)

## Partial composition rules
- **106 only:** 107 and 108 run in standalone/conservative mode.
- **107 only:** 108 marks config preconditions as unresolved; applies conservative sequencing.
- **106 + 107:** 108 can use full `pipeline_contract_mode` with safe parallelism.
- **All three:** 108 emits the full release-exec node-level package `produced.release-exec.environment_release_execution_package.v2`.

## Refresh triggers
- If 106 is re-run and `config_state` changes, 107 must re-evaluate affected differences.
- If 107 `environment_state.overall_ready_to_proceed` changes, 108 must re-check preconditions.
- 108 emits `downstream_handoff.refresh_triggers: [release-validation]` when the DAG changes.


---

## Boundary comparison table — env-diff vs config-check vs release-task vs release-risk

| Dimension | environment-difference-check | configuration-change-check | release-task-orchestration | release-risk-assessment |
|---|---|---|---|---|
| **Primary question** | "Are staging and prod in parity?" | "What configs are changing and how?" | "How do we sequence the deploy?" | "Is the overall release safe?" |
| **Output type** | Env diff register: difference_kind, severity, parity_verdict | Config change inventory: config_kind, reload_mode | Execution DAG | Risk register with composite score |
| **Scope** | Environment-level state comparison (all dimensions of staging vs prod) | Item-level config change analysis | Task execution | Holistic risk assessment |
| **Owns** | Env readiness score (0–10), parity_verdict, isolation_findings | Config change classification, reload impact, secret lifecycle | Task ordering, approval gates | Risk scoring across 12 categories |
| **Does not own** | Config change details (→106), risk scoring (→101), execution (→108) | Env parity (→107), task execution (→108) | Env analysis (→107), config analysis (→106) | Env parity (→107), config details (→106) |

### Key distinction: 106 vs 107
```
106 answers: "config X is changing from value A to B — impact: rolling restart needed"
107 answers: "staging has config X = A, but prod has config X = C — they are out of parity"

106 input:  the diff (what is about to change)
107 input:  two environment snapshots (current state of staging AND prod)

Both can detect the SAME config key, but from different angles:
  106 sees it as a CHANGE to be deployed
  107 sees it as an EXISTING DIFFERENCE between environments
```