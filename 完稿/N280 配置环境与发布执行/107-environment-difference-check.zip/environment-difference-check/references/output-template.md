# output-template — release-exec skill artifacts

This template defines common metadata patterns for all three release-exec skill artifacts.

## Shared metadata block
```yaml
artifact_contract:
  schema_version: release-exec.<skill-name>.v2.2.1
  artifact_type: <artifact_type>
  producer_skill: <skill-name>
  workflow_node: release-exec
  produced_event: produced.release-exec.<artifact_type>.v2
  event_delivery: declared_only
  subscribers_hint: [release-validation, deployment, infra, notifications, reporting]
```

## readiness values
- `green` — all required sections present, no P0/critical blockers, self-check passes
- `amber` — partial evidence; output stable but confidence reduced; some items constrained
- `red` — hard blocker present; deploy-phase tasks must not proceed
- `constrained` — evidence available but incomplete for a specific dimension

## downstream_handoff pattern
```yaml
downstream_handoff:
  target: <next-skill-or-node>
  readiness_inherited: <green | amber | red>
  blockers: []
  config_state:    # 106 → 107 → 108 handoff field
    reload_actions: []
    overall_ready_to_proceed: true | false
  environment_state:  # 107 → 108 handoff field
    parity_verdict: full | partial | not_assessed
    overall_ready_to_proceed: true | false
  missing_evidence: []
  next_best_checks: []
```

## self_check pattern
```yaml
self_check:
  passed: true | false
  failed_rules: []
  quality_check_failures: []
  schema_version_verified: true
  produced_event_declared: true
  no_plaintext_secrets: true
```


---

## Downstream handoff YAML templates

### 正常路径：107 → 108 移交，parity_verdict: partial (advisory diffs only)
```yaml
downstream_handoff:
  produced_by: environment-difference-check
  artifact: 环境差异检查单.csv
  produced_event: produced.release-exec.environment_difference_check.v2
  handoffs:
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "parity_verdict: partial. 2 advisory diffs (DK2 infra versions). overall_ready_to_proceed: true."
      required_fields:
        - environment_state.overall_ready_to_proceed
        - environment_state.parity_verdict
        - environment_state.blocker_differences
        - environment_state.advisory_differences
        - env_readiness_scores.overall
      confidence: high
      missing_evidence: []
      next_best_checks:
        - "108: schedule staging k8s upgrade to 1.29.1 within 2 weeks (advisory)"
  refresh_triggers:
    - skill: release-task-orchestration
      reason: "overall_ready_to_proceed changed — DAG preconditions must be re-evaluated"
      condition: "env_check.overall_ready_to_proceed != previous_value"

### 阻断路径：critical diff (secret mismatch)
    - target: release-task-orchestration
      handoff_type: gap
      summary: "BLOCKER: critical secret mismatch staging→prod. overall_ready_to_proceed: false."
      blocking: true
      required_fields: [difference_register, env_readiness_scores.overall]
      next_best_checks:
        - "Synchronize secret versions before re-running 107"
        - "Do NOT start P3 tasks until 107 reports overall_ready_to_proceed: true"
```


---

## Standalone guarantee — run 107 without 106 or 108
107 is independently useful when only two environment snapshots are available. Do not refuse output because 106 is missing.

### Minimum viable standalone inputs
- baseline environment snapshot (staging, pre-prod, or reference environment)
- target environment snapshot (prod or deploy target)
- release identity or change description (even a one-line description is sufficient)

### What 107 produces standalone
- `difference_register` with at least `difference_kind`, `difference_nature`, and `severity` per item
- `env_readiness_scores` covering at least config_alignment and representativeness
- `parity_verdict`: `full | partial | not_assessed`
- `downstream_handoff` with explicit `missing_evidence` when 106 is absent
- `self_check` with `passed: false` and explicit failed rules when preconditions are unmet

### Standalone red example — no snapshots provided, only release description
```yaml
metadata:
  readiness: red
  selected_mode: snapshot_mode
evidence_profile:
  confirmed: [release_description]
  missing_evidence:
    - baseline environment snapshot (staging or pre-prod)
    - target environment snapshot (prod)
  missing_evidence_impact: "No environment snapshots provided. Parity analysis cannot proceed. Provide at least two environment snapshots or config inventories."
difference_register: []
env_readiness_scores:
  overall: 0
  note: "Cannot score without snapshots."
parity_verdict: not_assessed
downstream_handoff:
  target: release-task-orchestration
  overall_ready_to_proceed: false
  missing_evidence: [baseline_snapshot, target_snapshot]
  next_best_checks:
    - "Provide staging vs prod config inventory or kubectl get configmap -o yaml output"
    - "Or provide Helm values.yaml diff between environments"
self_check:
  passed: false
  failed_rules: ["No environment snapshots — parity analysis not possible"]
```

### Standalone amber example — snapshots provided, 106 missing
```yaml
metadata:
  readiness: amber
  selected_mode: snapshot_mode
evidence_profile:
  confirmed: [staging_snapshot, prod_snapshot]
  missing_evidence:
    - configuration-change-check output
  missing_evidence_impact: "Config semantics not pre-classified. Difference kinds inferred from snapshot comparison only. Reload impact unknown."
difference_register:
  - diff_id: D-001
    config_key: app.feature.new-checkout
    difference_kind: DK1_expected_difference
    difference_nature: legitimate
    staging_value: "true"
    prod_value: "false"
    severity: medium
    allowed: true
    rationale: "Feature flag staged before prod rollout"
    owner: unassigned
    remediation: "Enable in prod after canary validation"
env_readiness_scores:
  config_alignment: 7
  representativeness: 8
  overall: 7.5
parity_verdict: partial
downstream_handoff:
  target: release-task-orchestration
  overall_ready_to_proceed: true
  missing_evidence: [configuration-change-check]
  next_best_checks:
    - "Run configuration-change-check to confirm reload_mode and secret safety before deploy"
self_check:
  passed: true
  failed_rules: []
  warnings: ["106 absent — config semantics inferred, not classified"]
```

---

## Output completeness rule
Every env-diff artifact MUST include all of:
- `difference_register[]` (may be `[]` if no diffs)
- `parity_verdict` ∈ {full, partial, not_assessed}
- `env_readiness_scores.overall` numeric 0–10
- `isolation_findings` (may be `[]`)
- `config_state.overall_ready_to_proceed` boolean
- `downstream_handoff` to release-task-orchestration
- `feedback_signal_candidates` ≥ 1
- `adversarial_detection` present

**Hard rules:**
- Any `severity: critical` diff → `blocks_release: true` AND `config_state.overall_ready_to_proceed: false`
- `parity_verdict: full` requires `difference_register: []` OR all diffs `severity: advisory`
- `env_readiness_scores.overall` < 7 → `gap_reasons[]` must be declared

---

## Mode selection

### New: `drift_detection` mode — 持续漂移检测
**Trigger:** Ops team wants to detect configuration drift that has accumulated since last release, or user says "config drift report", "what changed since last deploy?", "drift detection".

```yaml
drift_detection:
  drift_since: "2026-05-14T09:00:00Z"  # last known-good state
  drift_findings:
    - config_key: "app.feature_flags.new_checkout"
      expected: "false"
      actual: "true"
      changed_at: "2026-05-19T14:22:00Z"
      changed_by: "ops-runbook-001"
      drift_kind: unauthorized_change
      severity: advisory
    - config_key: "db.pool.max-size"
      expected: "100"
      actual: "150"
      changed_at: "2026-05-20T09:00:00Z"
      changed_by: "incident-remediation-20260520"
      drift_kind: incident_remediation_not_reverted
      severity: high
      action: "Revert or formally approve this change before next release"
  drift_summary:
    total_drifted: 2
    unauthorized: 1
    unreverted_incident_changes: 1
    severity_distribution: {advisory: 1, high: 1}
  parity_verdict: partial
```
**SCR:** `selected_mode: drift_detection` → `drift_detection.drift_since` declared; `drift_findings[*].drift_kind` ∈ {unauthorized_change, incident_remediation_not_reverted, manual_override, unknown}.

---

## Downstream handoff YAML

### 正常路径: 无 critical diff → 108
```yaml
downstream_handoff:
  produced_by: environment-difference-check
  artifact: 环境差异检查单.csv
  emit_event:
    event_name: produced.release-exec.environment_diff.v2
  handoffs:
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "Env parity: score=9/10, 0 critical diffs, 2 advisory. Proceed."
      required_fields: [parity_verdict, env_readiness_scores, difference_register]
      confidence: medium
      next_best_checks:
        - "108: use env_readiness_scores.overall as precondition gate threshold"
        - "108: advisory diffs noted — add monitoring for those config keys"
  refresh_triggers:
    - skill: release-task-orchestration
      reason: "Env snapshot updated — 108 preconditions must be re-evaluated"
      condition: "new snapshot provided after 108 started"
```

### 阻断路径: critical diff → block 108
```yaml
downstream_handoff:
  handoffs:
    - target: release-task-orchestration
      handoff_type: gap
      blocking: true
      summary: "BLOCKER: DIFF-001 critical secret mismatch — DO NOT start 108"
    - target: configuration-change-check
      handoff_type: routing
      summary: "Secret mismatch found — re-run 106 with secret rotation evidence"
      next_best_checks:
        - "106: provide vault reference for staging secret to match prod"
```


## CSV 序列化规则(node_artifact_target 是 .csv)

本产物 node_artifact_target 是 `.csv`。必须序列化为**既是合法 CSV、又携带上面契约 metadata 信封**的文件:

1. 把上面完整的 metadata 信封及所有 YAML 块,作为文件开头的注释行输出,每行以 `# ` 前缀。CSV 读取器跳过 `#` 行;信封仍可被 `scripts/validate_artifact.py` 机读校验(该校验器按段名子串匹配,注释头满足全部 REQUIRED 段)。
2. 注释信封之后,再输出表头行 + 表格条目(检查项/测试点/任务行)为标准逗号分隔 CSV 行。
3. 不要输出无注释信封的纯数据 CSV——`validate_artifact.py` 会因缺 metadata/self_check/downstream_handoff/evidence_profile/emit_event(或 produced_event)/adversarial_detection/feedback_signal_candidates 等段判 FAIL。

合法示例骨架:

```
# metadata:
#   skill_id: <skill>
#   node_artifact_target: <本产物>.csv
#   readiness: green
# self_check: {passed: true, failed_rules: []}
# downstream_handoff: {primary_consumers: [...]}
# evidence_profile: {confirmed_evidence: [], assumptions: [], missing_evidence: []}
# emit_event: {event_name: produced.<node>.<artifact>.v2}
# adversarial_detection: none_detected
# feedback_signal_candidates: []
<列头1>,<列头2>,<列头3>
<行数据...>
```
