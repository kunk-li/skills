# Output Template

## 0. Artifact Contract Header

在正文前优先给出 contract header。推荐使用 YAML front matter：

```yaml
---
artifact_type: prd_document
contract_version: n090.prd.v2
source_mode: from-source | from-structured | from-existing-prd | composed
traceability_summary: |
  Summarize which upstream structured outputs, raw notes, prototype anchors, and assumptions were consumed.
feedback_signals:
  - signal_type: needs_review_decision
    related_section: PRD-09
    description: Permission boundary is still undecided.
    target: human review
    severity: blocker
---
```

如果宿主环境不支持 YAML front matter，则在文档首节用等价结构显式呈现 `artifact_type`、`contract_version`、`source_mode`、`traceability_summary`，并在有需要时补 `feedback_signals[]`。

除非用户明确要求另一种输出格式，否则 **必须按以下 16 节顺序输出**。所有主节都必须保留；若信息不足，写明 `待确认`，不得删节。

## 1. 文档信息与版本说明 [PRD-01]
- 写明草稿状态、来源依据、适用评审对象。

## 2. 背景与目标 [PRD-02]
- 用新人也能看懂的语言解释业务背景与本期目标。

## 3. 范围与非范围 [PRD-03]
- 明确本期纳入范围与明确不做的内容。

## 4. 角色与核心场景 [PRD-04]
- 优先用表格呈现角色、目标、触发动作、关键约束。

## 5. 业务流程 / 页面或能力概览 [PRD-05]
- 先给总览，再说明关键分支、页面或能力块。

## 6. 功能需求清单 [PRD-06]
- 推荐使用功能条目表。必要时为功能点补充 requirement id。

## 7. 业务规则 [PRD-07]
- 用规则表：触发条件、判断逻辑、执行结果、例外说明。

## 8. 状态流转 [PRD-08]
- 用状态表：状态、进入条件、退出条件、允许动作、异常流。

## 9. 权限要求 [PRD-09]
- 用角色-资源-动作矩阵，明确禁止动作与例外情况。

## 10. 数据对象与关键字段 [PRD-10]
- 用表格列出对象、字段、含义、约束、source of truth。

## 11. 异常与边界处理 [PRD-11]
- 覆盖非法操作、失败结果、并发/重复触发、超时、回退等。

## 12. 非功能与约束 [PRD-12]
- 覆盖安全、合规、审计、性能、时效、系统边界等。

## 13. 验收标准 [PRD-13]
- 提供可检查、可评审的验收点，不写实现方案。

## 14. 依赖与风险 [PRD-14]
- 列出外部依赖、阻塞项、关键假设、风险暴露点。

## 15. 待确认项 [PRD-15]
- 用 P0 / P1 / P2 或 blocker / major / minor 标记优先级。

## 16. 附录 / 参考输入 [PRD-16]
- 列出用于生成本稿的输入材料与引用说明。
