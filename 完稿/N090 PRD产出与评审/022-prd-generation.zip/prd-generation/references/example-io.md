# Example IO

## Example input
- 一份结构化需求拆解，包含角色、关键流程、业务规则、状态、权限、对象字段。
- 一份质量审查结果，指出“异常处理”和“验收标准”不足。

## Good output characteristics
- 用 16 节固定骨架输出，而不是 6-8 节自由发挥。
- `PRD-11` 明确写出失败结果与边界处理。
- `PRD-13` 提供可评审的验收标准。
- `PRD-15` 用优先级列出待确认项。
- 下游 023/024 可以直接引用 `PRD-11`、`PRD-13`、`PRD-15`。

## Bad output characteristics

- Uses a free-form 6-8 section structure and drops the stable `PRD-01` to `PRD-16` anchors.
- Buries unresolved assumptions in prose instead of collecting them in `PRD-15 待确认项`.
- Converts weak production signals, meeting guesses, or reviewer opinions into confirmed requirements without evidence.
- Drifts into technical solution design, API implementation, release planning, or test-plan writing.
