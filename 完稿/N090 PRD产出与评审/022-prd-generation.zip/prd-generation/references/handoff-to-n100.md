# N090 → N100 节点交接协议

> 本文件定义 N090（PRD 产出与评审）向 N100（需求质量门禁）的正式交接规范。

---

## 1. N090 输出捆绑包 / Upstream Output Bundle

N100 消费以下 N090 产物：

| 产物 | 来源 Skill | 主要字段 | N100 用途 |
|---|---|---|---|
| PRD 主文档 | 022 | PRD-01..PRD-16 章节 + upstream_refs | 所有 N100 skill 的主要分析对象 |
| GAP 清单 | 023 | GAP-XXX + gap_type + priority_score | N100 已知缺口的关联参考 |
| 评审问题清单 | 024 | Q-XXX + question_urgency_score | 025-029 分析重点的提示 |

### N100 正式接收 N090 产物的 Intake 字段

每个 N100 skill（025-029）的输出中必须包含：

```yaml
n090_intake:
  prd_version: "n090.prd.v2"           # 从 PRD artifact header 读取
  prd_sections_available: [PRD-01, PRD-03, PRD-06, PRD-07, ...]
  gap_list_available: true | false
  gap_count: 12                         # 023 输出的 GAP 总数
  q_list_available: true | false
  high_urgency_questions:               # question_urgency_score ≥ 12 的 Q-XXX
    - q_id: Q-023
      related_prd: PRD-07
      urgency_score: 20
```

---

## 2. N100 各 Skill 的 N090 消费映射

| N100 Skill | 主要消费的 N090 产物 | 关键字段 |
|---|---|---|
| 025 completeness-check | PRD 所有章节 | D1-D8 维度检查，每维度对应 1-3 个 PRD-XX |
| 026 executability-check | PRD-06/07/11 | 功能需求与业务规则的可执行性 |
| 027 conflict-detection | PRD 全文 + GAP 清单 | 跨章节矛盾、GAP 与 PRD 描述的冲突 |
| 028 vulnerability-scan | PRD-07/09/12 + GAP 合规类 | 权限、合规、异常处理的漏洞 |
| 029 pending-items | PRD-15 + GAP 清单 + Q 清单 | 待确认项与未决 GAP 的合并 |
| 030 quality-review | 025-029 的全部输出 + N090 捆绑包 | 汇总 gate 决策 |

### PRD 章节 ↔ N100 维度对照表

| PRD 章节 | 主要关联 N100 维度 |
|---|---|
| PRD-03 范围与非范围 | 025 D1（functional_scope） |
| PRD-06 功能需求清单 | 025 D1/D2、026（executability）、027（conflict） |
| PRD-07 业务规则 | 025 D2、026（executability）、027（conflict/precedence）、028（business_logic vuln） |
| PRD-08 状态流转 | 025 D2、027（temporal/logical conflict）、028（failure_path_holes） |
| PRD-09 权限要求 | 025 D6（security_compliance）、028（authorization_drift）、027（permission conflict） |
| PRD-10 数据对象与关键字段 | 025 D2、025 D8（traceability）、028（data_exposure vuln） |
| PRD-11 异常与边界处理 | 025 D5（exception_handling）、028（failure_path_holes）、026（NE-01 ambiguous） |
| PRD-12 非功能与约束 | 025 D4（non_functional）、025 D6（security_compliance） |
| PRD-13 验收标准 | 025 D3（acceptance_criteria） |
| PRD-14 依赖与风险 | 026（NE-04 dependency_missing）、029（blocking pending） |
| PRD-15 待确认项 | 029（pending-items 主输入） |

---

## 3. GAP 清单到 N100 issue 的映射规则

当 N100 的某个 issue 与 023 的 GAP-XXX 对应时，必须使用 `source_gap_id` 建立链接：

### 3.1 GAP 类型到 N100 Skill 的路由

```
GAP 类型 → 主归属 N100 skill：

missing_scope            → 025（D1 functional_scope）
missing_business_rule    → 025（D2）+ 026（NE-02 underspecified）
missing_state_definition → 025（D2）+ 027（temporal/logical conflict 检查）
missing_permission       → 025（D6）+ 028（authorization_drift）
missing_data_definition  → 025（D2）+ 026（NE-01 ambiguous）
missing_error_handling   → 025（D5）+ 028（failure_path_holes）
missing_nfr              → 025（D4）
missing_acceptance_criteria → 025（D3）
missing_dependency       → 026（NE-04 dependency_missing）
missing_compliance       → 025（D6）+ 028（compliance vulnerability）
missing_sequence         → 027（temporal conflict）
missing_boundary_case    → 025（D5）+ 028（business_logic）
```

### 3.2 N100 issue 中的 GAP 引用格式

```yaml
- issue_id: N100-025-003
  issue_category: completeness
  dimension: D5_exception_handling
  finding: "PRD-11 未定义支付超时的补偿逻辑"
  source_gap_id: GAP-006            # 与 023 GAP 清单中的 GAP-006 对应
  source_gap_skill: "023"
  new_gap: false                     # 已在 023 中记录
  gap_type_match: missing_error_handling   # 与 GAP-006 的 gap_type 一致
```

### 3.3 N100 新发现 issue 的 GAP 回写（new_gap: true）

```
触发条件：
  issue.new_gap = true
  AND issue.severity ∈ {blocker, major}

030 在 cross_node_trace.remediation_plan 中记录：
  - action: "Create GAP-{next_id} in 023 for N100-028-002"
    gap_type: missing_compliance       # 按 gap-taxonomy.md 分类
    source_issue: N100-028-002
    priority: blocker
    suggested_prd_section: PRD-12
    owner: PM_or_tech_lead
```

---

## 4. N100 运行前的 N090 完成度校验

N100 各 skill 启动前，检查 N090 就绪状态：

```yaml
n090_readiness_gate:
  prd_artifact_present: true          # PRD 主文档存在
  prd_contract_version: "n090.prd.v2" # 版本匹配
  prd_sections_minimum:               # 必须存在的最低章节集合
    required: [PRD-03, PRD-06, PRD-07, PRD-13, PRD-15]
    present: [PRD-03, PRD-06, PRD-07, PRD-15]
    missing: [PRD-13]                 # 缺失章节进入 Partial Mode

  gap_list_present: true | false      # 影响 029 分析深度
  mode_selected: Full | Partial       # Partial Mode 时在 confidence 中标注
```

`prd_sections_minimum` 中的 `required` 有缺失时 → N100 自动降为 `Partial Mode`，并在输出中标注哪些维度因 PRD 缺失而分析受限。

---

## 5. 交接完成信号 / Handoff Completion Signal

030 完成后，在 output 中输出 N090→N100 汇总：

```yaml
n090_to_n100_handoff:
  prd_sections_analyzed: 14         # N100 实际分析的 PRD 章节数
  prd_sections_available: 16
  gaps_from_n090: 12                # 023 的 GAP 总数
  gaps_linked_to_n100_issues: 9     # 与 N100 issue 建立 source_gap_id 链接的 GAP 数
  gaps_unaddressed: 3               # N100 未直接处理的 GAP（需人工检查）
  new_gaps_discovered: 2            # N100 新发现的 issue（需回写到 023）
  gate: go | conditional-go | no-go
  ready_for_n110: true              # gate ≠ no-go OR PM 已批准继续
```
