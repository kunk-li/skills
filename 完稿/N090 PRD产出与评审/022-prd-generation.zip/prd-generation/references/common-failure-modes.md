# Common Failure Modes

1. Producing a long summary instead of a PRD draft.
2. Hiding unresolved items in prose instead of using a dedicated section.
3. Omitting acceptance criteria or review-ready acceptance notes.
4. Mixing confirmed facts with inferred content.
5. Repeating upstream analysis without consolidating it into document form.
6. Skipping exceptions, edge cases, or non-functional constraints.
7. Writing a draft that only experts can understand.

## Mode-routing specific failures

- **standalone / from-source**: Rebuilds a PRD draft from raw notes but forgets to materialize stable `PRD-XX` section IDs.
- **from-structured**: Ignores richer upstream structured outputs and rewrites them into a lossy narrative.
- **from-existing-prd**: Treats an existing draft as ground truth and silently carries forward stale or contradictory assumptions.
- **repair-loop**: Rewrites the whole PRD after a gate return instead of patching only the affected sections and preserving IDs.

## Contract-layer failures

- Missing `artifact_type`, `contract_version`, or `source_mode` in the output header.
- `traceability_summary` is absent or too vague to explain which upstream inputs were consumed.
- Emits a decision blocker in prose but forgets to surface it through `feedback_signals[]`.
- Changes section numbering or emits mixed contract versions across the same PRD artifact set.
