# Section Guidance

## Background and goal
Start simple. A newcomer should understand what business problem this PRD addresses.

## Scope and non-scope
Be explicit. Avoid implied boundaries.

## Feature requirements
Use requirement IDs when the draft is large enough to benefit from them.
If N080 `FT-...` IDs exist, preserve them as cross-reference IDs instead of renaming them.

## Rules / states / permissions
These are high-risk sections. Prefer tables over long prose.
If N080 `ACT-...` IDs exist, keep them visible in permissions and edge-case sections.

## Data objects
Do not invent fields. If fields are incomplete, mark them as pending.
If N080 `FLD-...` IDs exist, keep them in field mapping or appendix columns.

## Exceptions and edge cases
Mention invalid flows, blocked operations, timeout handling, and risky parallel actions when source support exists.

## Acceptance criteria
Focus on reviewable behavior, not implementation details.

## Pending items
Phrase each item as a decision or confirmation point, not as a vague note.

## N005 production signal handling

When N005 production signals are provided, treat them as upstream evidence, not as final product decisions. Use them as follows:

- Map high-frequency errors, defect clusters, and incident postmortem findings into `PRD-11 异常与边界处理` when they reveal missing failure paths, compensation logic, or user-visible error states.
- Map NPS, user-feedback clusters, and affected segment evidence into `PRD-02 背景与目标` when they clarify the product problem or success target, and into `PRD-04 角色与核心场景` when they clarify the affected user role, scenario, or journey break.
- Use `PRD-03 范围与非范围` only when the N005 signal changes what is explicitly in scope or out of scope; do not place generic pain-point evidence there.
- Map release/incident risk signals into `PRD-14 依赖与风险`.
- Preserve the original signal source in `PRD-16 附录/参考输入`; do not rewrite production observations as confirmed scope unless the product owner has decided them.
