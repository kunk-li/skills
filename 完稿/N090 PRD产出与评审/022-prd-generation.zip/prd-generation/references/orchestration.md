# Composition Guide

## Positioning
- 本 skill 是 N090 节点内的**通用文档生成 skill**，不是只能在固定 DAG 顺序里使用的 Stage A。
- 选择条件应是“当前是否需要一个可评审 PRD 主稿或 PRD 骨架”，而不是“是否已经完整跑过 022→023→024”。

## Operating modes
1. **standalone**：从碎片需求、已有 PRD 片段、会议笔记直接起稿。
2. **paired**：消费结构化需求、原型分析、质量检查结果，生成更稳的 PRD 主稿。
3. **chain**：作为 N090 中的主稿底座，为 gap 与 review question 提供 `PRD-XX` 锚点。
4. **repair-loop**：当 review 或 gate 退回时，局部重写受影响章节，而不是整稿重写。

## Handoff requirements
- 下游必须能按 `PRD-XX` 精确引用本输出。
- 若输入质量不足，必须把缺口沉淀到 `PRD-15` 或显式待确认项，而不是静默跳过。
- 若上游已有 `P- / FT- / ACT- / FLD-`，优先保留为 cross-reference。

## Cross-node collaboration

Use this section when N090 is not running as an isolated document task.

- **N005 production signal intake**: When inputs include `线上痛点信号包.json`, `数据驱动需求建议.csv`, incident postmortems, defect clusters, or NPS/user-feedback clusters, treat them as evidence. Convert them into PRD sections, gaps, or review questions, and preserve source references. Do not silently redefine scope based only on production signals.
- **N100 gate repair loop**: When inputs include requirement completeness, executability, conflict, vulnerability, or quality-review findings, map each blocker to the smallest affected `PRD-XX`, `GAP-XXX`, or `Q-XXX`. Prefer targeted repair over regenerating the whole N090 package.
- **N110 handoff readiness**: Before handing off to engineering or QA, highlight unresolved scope, rule, state, permission, data, acceptance, owner, or dependency issues as `handoff_risk` feedback signals.
- **N370/N380 routing and human confirmation**: When a decision cannot be closed by the skill, emit `needs_review_decision` or `gate_repair_required` so the platform router or human-confirmation queue can pick it up.
