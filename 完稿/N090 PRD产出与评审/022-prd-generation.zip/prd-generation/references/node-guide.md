# N090 PRD 产出与评审 — 节点导航

> **节点定位**：将 N070/N080 的结构化需求输出整合成正式 PRD 文档，识别缺口，生成评审问题。N090 的三个 skill 形成完整的 PRD 生产→补全→评审闭环。

---

## Skills 一览

| ID | Skill | 主要输出 | 适用场景 |
|---|---|---|---|
| 022 | prd-generation | PRD 主文档（PRD-01..PRD-12 章节） | 首次生成 PRD，或从结构化需求重建 |
| 023 | prd-completion | GAP-XXX 缺口清单 + draft_insert | 对现有 PRD 做缺口分析和补全建议 |
| 024 | prd-review-question-generation | Q-XXX 评审问题清单 | 为评审会准备可决策的问题结构 |

---

## 推荐执行顺序

```
022（PRD 主文档）→ 023（缺口分析）→ 024（评审问题）

或在有质量检查结果时：
022 → 023 → N100 质量检查 → 024（gate-driven-review 模式）
```

---

## 023 特别说明：gap_type 分类

**必须阅读 `references/gap-taxonomy.md`**（定义了全部 12 类标准缺口）

| gap_type | 中文名 | 核心判别信号 |
|---|---|---|
| `missing_scope` | 范围缺失 | "是否支持 X"无明确答案 |
| `missing_business_rule` | 业务规则缺失 | 分支/例外路径未定义 |
| `missing_state_definition` | 状态定义缺失 | 状态图有死端或孤立状态 |
| `missing_permission` | 权限定义缺失 | "谁可以做"或"条件下允许"缺失 |
| `missing_data_definition` | 数据定义缺失 | 字段名存在但无规格 |
| `missing_error_handling` | 异常处理缺失 | 正常流程有描述但失败路径无 |
| `missing_nfr` | 非功能需求缺失 | 只有定性描述，无可测量指标 |
| `missing_acceptance_criteria` | 验收标准缺失 | 无法写出测试用例 |
| `missing_dependency` | 依赖关系缺失 | 隐含外部依赖但未说明 |
| `missing_compliance` | 合规要求缺失 | 监管/法律要求未体现 |
| `missing_sequence` | 时序定义缺失 | 先后关系/并发约束未定义 |
| `missing_boundary_case` | 边界条件缺失 | 零值/最大值/并发场景未覆盖 |

**扩展规则**：只有以上 12 类均不适用时，才可用 `custom:<n>` 扩展（见 gap-taxonomy-extension.md）。

---

## 023 GAP 优先级评分

**必须阅读 `references/gap-scoring-model.md`**（三维量化公式）

```
priority_score = urgency_score × impact_score × resolution_difficulty_score
```
- 每维度 1-5 分
- 同分时按 blocking 级别（blocker > major > minor）排序
- N005 生产信号可提升 impact/urgency 最多 1 分（需说明来源）

---

## 共同契约

**N090_COMMON_CONTRACTS.md** + **N090_SHARED_CHECKLIST.md** 是所有 N090 skill 的必读文件：
- 章节 ID 命名：`PRD-01`..`PRD-12`
- Gap ID：`GAP-XXX`（三位数字，非 GAP-1）
- Question ID：`Q-XXX`
- artifact contract：`prd_main.v2` / `prd_gap_list.v2` / `prd_review_question_list.v2`

---

## 与 N100 的交接规则

N090 输出流入 N100 时：
- N100 的六个 gate skill 以 PRD 主文档和 gap 清单为主要输入
- N100 发现的问题使用 issue_id（非 GAP-XXX），回写路径：N100 issue → N090 GAP（需手动协调）
- N100 的 gate_status（go/conditional-go/no-go）→ N110 的 execution_mode（见 031/readiness-scoring.md）

---

## 跨节点交接协议

- 上游：参见 `transitions/N080-N090-transition.md`（如何消费 N080 的 P-/FT-/ACT-/FLD-）
- 下游：参见 `transitions/N090-N100-transition.md`（PRD + GAP 清单如何流入 N100）

GAP 清单（023 输出）中每条 GAP-XXX 与 N100 issue 的映射关系见 `cross-node-bridge-contract.md`。

## 常见误用

| 误用 | 正确做法 |
|---|---|
| 023 的 gap_type 用自由文本 | 从 gap-taxonomy.md 的 12 类中选；实在不适用再用 custom: |
| 024 的问题只罗列 blocker，没有优先排序 | 用 review-urgency-scoring.md 评分后排序；每次评审应明确"本轮必决项" |
| 不写 priority_score 的推导依据 | 省略三维分解时，必须在 evidence_note 中说明 priority_score 来源 |
