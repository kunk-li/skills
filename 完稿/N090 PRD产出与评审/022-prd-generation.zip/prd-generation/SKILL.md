---
name: prd-generation
description: generate a review-ready prd draft or structured prd skeleton from requirement notes, structured requirement outputs, prototype findings, business rules, states, permissions, data objects, production signals, and related review findings. use when the user needs a prd document that can stand alone for review, circulation, or handoff, whether starting from fragmented notes or from upstream structured analyses. works well on its own, and composes cleanly with prd-completion and prd-review-question-generation through shared prd section ids and artifact contracts. do not use for technical solution documents, test plans, meeting minutes, release notes, code design, or implementation plans.
---

# PRD Generation

生成**可评审、可流转、可交接**的 PRD 主稿或 PRD 骨架。这个 skill 在 N090 节点内承担“主稿生成”原子能力：**单独可交付，组合时为后续 gap 与 review 提供稳定底座**。

## Role / 角色定位
- 把碎片需求、结构化需求结果、原型分析与规则材料沉淀成统一 PRD 主稿。
- 输出的是**正式文档骨架与正文**，不是摘要，不是点评，不是会议纪要。
- 为相邻 skill 提供稳定的 `PRD-XX` 章节锚点和 traceability。

## Mode routing / 模式路由
### 1) `from-source`
适用于只有原始需求片段、会议笔记、现有 PRD 片段时。
- 先搭 16 节骨架。
- 能确认的写入正文。
- 不能确认的显式写入对应章节或 `PRD-15 待确认项`。

### 2) `from-structured`
适用于已有 N070 / N080 或其他结构化需求结果时。
- 优先复用业务规则、状态、权限、数据对象、功能点和原型锚点。
- 重点提升章节完整度与术语一致性。

### 3) `from-existing-prd`
适用于已有旧 PRD，但结构混乱、版本陈旧、缺失交叉引用时。
- 将既有内容重组到 `PRD-01` 到 `PRD-16`。
- 保留可追溯章节 ID。
- 对模糊历史内容标注 `待确认`，不要静默洗平。

### 4) `composed`
适用于已有 `prd-completion`、`prd-review-question-generation`、N100 gate return 或其他结构化结论，需要局部重写或合并为新 PRD 主稿时。
- 保留原有 `PRD-XX` 章节 ID，除非用户明确要求重构章节。
- 把外部 gap、review question、quality finding 映射回受影响章节。
- 不要把尚未决策的问题写成已确认事实。

## Single-skill value / 单独使用价值
- 没有其他 skill 结果，也必须交付**可评审主稿**。
- 即使输入很弱，也要交付完整 PRD 骨架，而不是“建议补充以下信息”的点评式回答。

## Composition value / 组合价值
- 与 `prd-completion` 组合：把主稿中的未决内容转成 `GAP-XXX` 补稿动作。
- 与 `prd-review-question-generation` 组合：让评审问题能按 `PRD-XX` 精确引用来源章节。
- 与 N070 / N080 输出组合：把对象、规则、状态、权限、字段、页面和动作统一落章。

## Accepted inputs / 可接受输入
### Primary
- requirement notes / requirement fragments
- structured requirement outputs
- existing prd text or prd fragments

### Recommended
- business rules
- state transitions
- permissions
- data objects
- prototype findings or screenshots

### Optional
- quality review findings
- pending-item lists
- meeting notes
- production signal package from N005, such as `线上痛点信号包.json`, `数据驱动需求建议.csv`, high-frequency error summaries, incident postmortems, defect clusters, or NPS/user-feedback clusters

## Mandatory output / 默认输出契约
除非用户明确要求其他格式，否则必须使用 `references/output-template.md` 的 16 节固定结构，并满足：
- 保留 `PRD-01` 到 `PRD-16`
- 默认主输出为 markdown
- 每节显式区分：**已确认事实 / 合理归纳 / 待确认项**
- 能引用上游锚点时，优先复用 `P- / FT- / ACT- / FLD-`
- 输出应符合 `references/N090_COMMON_CONTRACTS.md` 中 `prd_document` contract，契约版本为 `n090.prd.v2`

## Workflow / 执行流程
1. 识别当前 `source_mode`：`from-source` / `from-structured` / `from-existing-prd` / `composed`。
2. 先搭 16 节骨架，再回填内容。
3. 把 scope、roles、flows、rules、states、permissions、data、exceptions、constraints、acceptance 显式落章。
4. 执行全局约束扫描：红线/合规、幽灵实体、跨模块联动缺口。
5. 对不充分证据只写 `待确认`，不得伪造 owner、排期、接口实现细节或上线承诺。
6. 如存在上游结构化实体 ID，保留为 cross-reference，而不是重命名。
7. 判断是否需要外发 `feedback_signals[]`：若发现关键上游缺失、需要上游重跑、需要评审决策、或 N005 线上信号暴露 PRD 规则/异常/风险缺口，必须在契约头或输出元数据中记录信号，不要只写在正文里。
8. 交付前按 `references/checklist.md` 自检，并参照 `references/scoring-rubric.md` 做质量自评。

## Self-check gate / 节点内自检
交付前至少确认：
- 16 节结构完整。
- 每节都可定位到 `PRD-XX`。
- 事实 / 归纳 / 待确认未混写。
- 已显式扫描全局约束与关键缺口。
- 下游可以直接基于本稿继续做 gap 或 review question。

## Boundary rules / 边界规则
- 止于需求理解、结构化与文档化，不进入技术方案设计和研发实现。
- 不得把未决项写成既定答案。
- 不得因为是增强 / 迁移项目就删掉主章节。
- 若用户要求 JSON / CSV / 清单格式，可以调整呈现形式，但必须保留同等信息密度与 `PRD-XX` 追溯能力。

## Reference files / 参考文件
- `references/output-template.md`：16 节强制模板
- `references/section-guidance.md`：分节写作指导
- `references/prd-type-variants.md`：**PRD 类型路由规则（standalone/paired/chain/repair-loop 判别条件）（必读）**
- `references/checklist.md`：交付前检查清单
- `references/N090_SHARED_CHECKLIST.md`：N090 三个 skills 共享契约自检
- `references/scoring-rubric.md`：质量评分标准
- `references/orchestration.md`：单 skill / 多 skill 的组合方式
- `references/example-io.md`：输入输出示例
- `references/common-failure-modes.md`：常见失败模式
- `references/N090_COMMON_CONTRACTS.md`：共享契约与 artifact contract


## Workflow v2 artifact contract
```yaml
artifact_type: n090.prd-document
schema_version: "2.0.0"
producer_skill: prd-generation
consumer_nodes: [N100, N110, N370]
workflow_alias: PRD主文档.md
produced_event_name: produced.n090.prd
canonical_fields:
  - artifact_type
  - contract_version   # n090.prd.v2
  - source_mode        # from-source / from-structured / from-existing-prd / composed
  - traceability_summary
  - sections[]         # 每节含 section_id / section_title / status / upstream_refs[]
  - feedback_signals[]
n100_gate_trigger: true          # 发布此事件触发 N100 门禁启动
n005_consumption: direct         # 直接接受 feedback.n005.signal.production-pain
consumed_artifacts:
  - artifact_type: n070.requirement-breakdown
    min_schema_version: "1.0.0"
  - artifact_type: n080.feature-points
    min_schema_version: "1.1.0"
    fallback_on_mismatch: proceed_with_warning
```

## Key references
- `references/node-guide.md`：N090 节点导航（3 个 skill 的执行顺序、12 类 GAP taxonomy 速查、与 N100 交接规则）
- `references/handoff-to-n100.md`：**N090→N100 节点交接协议（PRD 章节到 N100 维度映射 + GAP 路由规则 + source_gap_id 格式）（必读）**

- `references/N090_COMMON_CONTRACTS.md`：**N090 节点 PRD-XX 章节契约 + prd_main artifact contract（必读）**
- `references/cross-node-bridge-contract.md`：**N080 P-/FT-/ACT-/FLD- ID 在 PRD 章节 upstream_refs[] 中的嵌入规则（必读）**
- `references/prd-type-variants.md`：**PRD 类型路由规则（必读）**
- `references/section-guidance.md`：每章写作指引
- `references/scoring-rubric.md`：质量评分标准
- `references/output-template.md`：输出结构
- `references/N090_SHARED_CHECKLIST.md`：N090 三 skills 共享自检清单
- `references/checklist.md`：022 专项自检清单
- `references/common-failure-modes.md`：常见错误模式
