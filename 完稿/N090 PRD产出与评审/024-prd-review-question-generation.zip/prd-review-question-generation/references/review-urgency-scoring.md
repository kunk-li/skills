# Review Urgency Scoring

用于 `prd-review-question-generation` 的会议问题排序。

## 输入因子
- `blocking_level`：`blocker / major / minor`
- `deadline_proximity`：
  - `immediate`：本次评审会必须定
  - `near_term`：设计前必须定
  - `next_handoff`：交接前必须定
  - `open_end`：可以后续澄清

## 建议权重
- `blocking_weight`：`blocker=5, major=3, minor=1`
- `deadline_weight`：`immediate=4, near_term=3, next_handoff=2, open_end=1`

## 推荐计算
- `question_urgency_score = blocking_weight * deadline_weight`
- 在同一优先级内，按 `question_urgency_score` 从高到低排序。

## 解释要求
每个高优先级问题都应说明：
- 为什么现在必须问
- 谁必须回答
- 不决策会卡在哪个阶段

## N005 production signal modifier

When a review question is supported by N005 production signals, use the signal to prioritize the discussion, not to answer the question automatically.

- Add a `production_signal_modifier` of `+2` when the question is tied to high-frequency errors, active incidents, recurring defect clusters, or measurable user-feedback/NPS pain that affects core flows.
- Add `+1` when the signal is credible but indirect, historical, or affects a secondary flow.
- Add `0` when the signal is anecdotal, unverified, or unrelated to the decision under review. In this case, consider emitting `production_signal_requires_triage` instead of raising urgency.
- Recommended calculation: `question_urgency_score = blocking_weight * deadline_weight + production_signal_modifier`.
- Each raised score must explain the N005 source, related `PRD-XX` or `GAP-XXX`, and who must decide.

---

## 问题分类决策树 / Question Classification Decision Tree

```
Q1: 问题的核心是"这个功能 / 对象 / 业务能力是否在本期"？
    YES → 分类：范围与边界
    NO  → Q2

Q2: 问题的核心是"数据由谁负责、以哪个系统为准"？
    YES → 分类：owner / source of truth
    NO  → Q3

Q3: 问题的核心是"多个动作/状态之间的触发关系和顺序"？
    YES → 分类：状态编排与联动
    NO  → Q4

Q4: 问题的核心是"谁能做、在什么条件下能做"？
    YES → 分类：权限边界与安全
    NO  → Q5

Q5: 问题的核心是"失败/超时/异常时如何处理"？
    YES → 分类：失败补偿与异常
    NO  → Q6

Q6: 问题的核心是"字段/对象的类型、枚举、约束"？
    YES → 分类：数据定义与字段口径
    NO  → Q7

Q7: 问题的核心是"如何判断功能完成/通过"？
    YES → 分类：验收与测试
    NO  → 分类：依赖与交接
```

### 边界 Case：多分类问题处理

| 场景 | 主分类 | 次分类 | 处理方式 |
|---|---|---|---|
| "审批通过后，数据由谁维护" | owner/source of truth | 状态编排 | 主分类决定讨论重点，次分类在 why_this_matters 中补充 |
| "删除操作后谁有权恢复" | 权限边界与安全 | 失败补偿 | 权限是主问题；恢复能力是次问题 |
| "超时后状态变更是否需要人工确认" | 状态编排与联动 | 验收与测试 | 状态变更规则是主问题 |

### urgency_score 计算示例

| 问题 | blocking | deadline | N005 | urgency_score | 优先级 |
|---|---:|---:|---:|---:|---|
| "结算接口依赖方确认" | blocker(5) | next_handoff(2) | +2 | 12 | 最高 |
| "审批流程状态定义" | major(3) | near_term(3) | 0 | 9 | 高 |
| "字段格式规范" | minor(1) | open_end(1) | 0 | 1 | 低 |
| "支付超时有线上告警" | major(3) | immediate(4) | +2 | 14 | 最高 |
