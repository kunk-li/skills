# Review Urgency Scoring

用于 `prd-review-question-generation` 的会议问题排序。

## 输入因子
- `blocking_level`：`blocker / major / minor`
- `deadline_proximity`：
  - `immediate`：本次评审会必须定
  - `near_term`：设计前必须定
  - `next_handoff`：交接前必须定
  - `open_end`：可以后续澄清

## 建议权重
- `blocking_weight`：`blocker=5, major=3, minor=1`
- `deadline_weight`：`immediate=4, near_term=3, next_handoff=2, open_end=1`

## 推荐计算
- `question_urgency_score = blocking_weight * deadline_weight`
- 在同一优先级内，按 `question_urgency_score` 从高到低排序。

## 解释要求
每个高优先级问题都应说明：
- 为什么现在必须问
- 谁必须回答
- 不决策会卡在哪个阶段

## N005 production signal modifier

When a review question is supported by N005 production signals, use the signal to prioritize the discussion, not to answer the question automatically.

- Add a `production_signal_modifier` of `+2` when the question is tied to high-frequency errors, active incidents, recurring defect clusters, or measurable user-feedback/NPS pain that affects core flows.
- Add `+1` when the signal is credible but indirect, historical, or affects a secondary flow.
- Add `0` when the signal is anecdotal, unverified, or unrelated to the decision under review. In this case, consider emitting `production_signal_requires_triage` instead of raising urgency.
- Recommended calculation: `question_urgency_score = blocking_weight * deadline_weight + production_signal_modifier`.
- Each raised score must explain the N005 source, related `PRD-XX` or `GAP-XXX`, and who must decide.
