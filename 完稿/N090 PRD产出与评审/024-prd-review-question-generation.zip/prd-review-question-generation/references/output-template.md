# Output Template

## 0. Artifact Contract Header

在正文前优先给出 contract header。推荐使用 YAML front matter：

```yaml
---
artifact_type: prd_review_question_list
contract_version: n090.prd-review.v2
source_mode: prd-only-review | gap-driven-review | gate-driven-review
traceability_summary: |
  Summarize which PRD sections, gap records, gate outputs, and evidence were consumed to build the review agenda.
feedback_signals:
  - signal_type: needs_review_decision
    related_section: Q-002
    description: The question exists because a blocker decision is still pending.
    target: human review
    severity: blocker
---
```

如果宿主环境不支持 YAML front matter，则在文档首节用等价结构显式呈现 `artifact_type`、`contract_version`、`source_mode`、`traceability_summary`，并在有需要时补 `feedback_signals[]`。

除非用户明确要求另一种格式，否则 **必须按以下 5 节顺序输出**。

## 1. 开场风险摘要
- 简洁说明本次评审为什么重要，最大的 blocker 在哪里。

## 2. 最高优先级问题
- 先列 P0 问题，建议每条给 `Q-XXX`、`related_prd_sections`、必要时 `related_gap_ids`、`question_urgency_score`。

## 3. 分主题问题清单
- 优先用表格，建议列：
  - `q_id`
  - `priority`
  - `blocking_level`
  - `deadline_proximity`
  - `question_urgency_score`
  - `category`
  - `question`
  - `why_it_matters`
  - `consequence_if_unresolved`
  - `suggested_responder`
  - `decision_phase`
  - `related_prd_sections`
  - `related_gap_ids`

## 4. 建议参会角色
- 只列真正能回答问题的人/角色，不做泛泛罗列。

## 5. 会后必须形成的决策项
- 把最高优先级未决项改写成“会议结束前必须形成的决策”。
