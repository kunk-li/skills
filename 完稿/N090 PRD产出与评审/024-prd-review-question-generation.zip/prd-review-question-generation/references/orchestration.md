# Composition Guide

## Positioning
- 本 skill 是 N090 节点内的**通用评审问题生成 skill**，不是只能在固定 DAG 顺序里使用的 Stage C。
- 选择条件应是“当前是否要把 PRD / gap / 质量结论转成会议可决策的问题”，而不是“链路是否已经完整串行执行”。

## Operating modes
1. **prd-only review**：仅基于 PRD 生成问题、挑战点和决策议程。
2. **gap-driven review**：把 `GAP-XXX` 转成会议可决策问题。
3. **gate-driven review**：吸收质量检查或 review blocker，聚焦必须在本轮决策的问题。
4. **repair-loop**：当会后仍有未决项时，只更新相关问题清单，不必重建整份 PRD。

## Handoff requirements
- 输出必须支持 `Q-XXX -> GAP-XXX -> PRD-XX` 回溯；若没有 gap，则至少支持 `Q-XXX -> PRD-XX`。
- 同类问题要合并，优先保留最能推动决策的表述。
- 若缺少 gap 级输入，必须说明限制，但不能因此放弃输出会议问题清单。

## Cross-node collaboration

Use this section when N090 is not running as an isolated document task.

- **N005 production signal intake**: When inputs include `线上痛点信号包.json`, `数据驱动需求建议.csv`, incident postmortems, defect clusters, or NPS/user-feedback clusters, treat them as evidence. Convert them into PRD sections, gaps, or review questions, and preserve source references. Do not silently redefine scope based only on production signals.
- **N100 gate repair loop**: When inputs include requirement completeness, executability, conflict, vulnerability, or quality-review findings, map each blocker to the smallest affected `PRD-XX`, `GAP-XXX`, or `Q-XXX`. Prefer targeted repair over regenerating the whole N090 package.
- **N110 handoff readiness**: Before handing off to engineering or QA, highlight unresolved scope, rule, state, permission, data, acceptance, owner, or dependency issues as `handoff_risk` feedback signals.
- **N370/N380 routing and human confirmation**: When a decision cannot be closed by the skill, emit `needs_review_decision` or `gate_repair_required` so the platform router or human-confirmation queue can pick it up.
