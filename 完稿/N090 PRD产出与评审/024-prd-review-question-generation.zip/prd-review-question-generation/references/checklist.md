# Delivery Checklist

## Shared contract self-check

先执行 `references/N090_SHARED_CHECKLIST.md`，再执行本文件中的 skill-specific 自检项。特别注意：`source_mode` 必须使用契约允许枚举，跨节点风险必须写入 `feedback_signals[]`。

- 是否保留了 5 节会议叙事结构，而不是只输出一个 csv？
- 每个关键问题是否带有 `Q-XXX`？
- 是否给出了 `related_prd_sections`，并在可能时给出 `related_gap_ids`？
- 是否优先暴露 blocker，而不是把高低优先级混在一起？
- 是否给出了 `blocking_level / deadline_proximity / question_urgency_score`？
- 是否解释了“为什么要问”和“不决策会怎样”？
- 是否明确了建议回答人/决策方？
- 是否完成了全局约束扫描并暴露红线、幽灵实体、跨模块联动缺口？
- 结果能否直接用于会议主持与会后决策追踪？
