# Example IO

## Example input
- 一份 022 生成的 PRD 主稿。
- 一份 023 补全建议，其中 `GAP-003` 指向 `PRD-09` 权限边界不清，`GAP-004` 指向 `PRD-11` 失败补偿缺失。

## Good output characteristics
- `Q-001` 追问 `GAP-003` 对应的权限边界与最终裁决方。
- `Q-002` 追问 `GAP-004` 对应的失败补偿与回退机制。
- 先输出会议风险摘要，再输出 P0 问题，再给分主题表，而不是只有 csv。
- 会后决策项能直接回写到 `PRD-09`、`PRD-11`。

## Bad output characteristics

- Produces many generic questions such as “是否考虑异常情况” without `Q-XXX`, source section, owner, or decision consequence.
- Copies `GAP-XXX` text verbatim instead of converting it into a meeting-decision question.
- Mixes blocker questions with nice-to-have questions without priority, urgency, or decision timing.
- Turns unresolved questions into answers, conclusions, or final approval decisions.
