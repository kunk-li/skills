# Common Failure Modes

1. Asking generic filler questions that do not change design or delivery.
2. Listing too many low-value questions and hiding the blockers.
3. Failing to say why a question matters.
4. Omitting who should answer the question.
5. Turning unresolved questions into assumed answers.
6. Producing a brainstorming list instead of a meeting-ready agenda.
7. Asking duplicate questions that differ only in wording.

## Mode-routing specific failures

- **prd-only-review**: Asks broad brainstorming questions instead of decision-shaping questions anchored to `PRD-XX`.
- **gap-driven-review**: Ignores `related_gap_ids` and loses the bridge from review agenda back to completion work.
- **gate-driven-review**: Copies gate failures verbatim without rewriting them into meeting-ready decision questions.
- **repair-loop**: Replaces the full agenda after a gate return instead of preserving existing `Q-XXX` IDs and patching the unresolved set.

## Contract-layer failures

- Missing `artifact_type`, `contract_version`, or `source_mode` in the output header.
- Fails to explain provenance in `traceability_summary`, leaving the meeting owner unable to verify why a question exists.
- Leaves blocker decisions in prose and forgets to emit `feedback_signals[]` when escalation or rerun is required.
- Emits mixed question versions or drops `related_prd_sections` / `related_gap_ids`, breaking chain traceability.
