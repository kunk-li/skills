---
name: prd-review-question-generation
description: Generate decision-oriented PRD review questions, challenge points, and meeting agendas exposing ambiguity, risk, ownership gaps, or gate blockers.
---

# PRD Review Question Generation

把 PRD、gap 和质量结论转成**会议可用、可决策、可回溯**的问题清单。这个 skill 在 N090 节点内承担“评审提问与议程生成”原子能力：**单独可做高质量 review agenda，组合时可形成完整追溯链**。

## Role / 角色定位
- 生成高价值 review questions、challenge points、discussion items 和决策提示。
- 输出必须优化“会议决策价值”，而不是只追求问题数量。
- 为主持人和参会人提供可排序、可回溯、可落会后动作的问题资产。

## Mode routing / 模式路由
### 1) `prd-only-review`
适用于只有 PRD 主稿时。
- 直接从 PRD 中识别歧义、缺口、风险和未决项。
- 即使没有 gap 输入，也必须交付会议可用的问题结构。

### 2) `gap-driven-review`
适用于已有 `GAP-XXX` 时。
- 把 gap 转成更适合会议决策的问题表述。
- 优先突出 blocker 和本轮必决项。

### 3) `gate-driven-review`
适用于已有质量检查、评审 blocker 或 handoff 风险时。
- 吸收审查结论，但避免只是复制 blocker 原文。
- 问题必须指向“谁来答、何时答、不答会怎样”。

## Single-skill value / 单独使用价值
- 仅基于 PRD 也必须产出高价值 review questions。
- 单独使用时，不能退化成“请补充更多信息”的空泛提问。

## Composition value / 组合价值
- 与 `prd-generation` 组合：问题可按 `PRD-XX` 精确定位来源章节。
- 与 `prd-completion` 组合：形成 `Q-XXX -> GAP-XXX -> PRD-XX` 的完整追溯链。
- 与 `requirement-quality-review` 组合：聚焦本轮评审、交接或 gate 必须决策的问题。

## Accepted inputs / 可接受输入
### Primary
- prd draft
- completion findings
- quality review findings

### Optional
- requirement notes
- screenshots or upstream analyses
- meeting context
- production signal package from N005, such as user-feedback clusters, defect clusters, incident postmortems, or NPS signals that should become review questions instead of silently changing the PRD

## Mandatory output / 默认输出契约
除非用户明确要求其他格式，否则必须按 `references/output-template.md` 输出，并满足：
1. 开场风险摘要
2. 最高优先级问题
3. 分主题问题清单
4. 建议参会角色
5. 会后必须形成的决策项

同时满足：
- 每个问题使用 `Q-XXX`
- 每个问题必须给出 `related_prd_sections`
- 若已有 gap，尽量补 `related_gap_ids`
- 关键问题补 `blocking_level / deadline_proximity / question_urgency_score`
- 输出应符合 `references/N090_COMMON_CONTRACTS.md` 中 `prd_review_question_list` contract，契约版本为 `n090.prd-review.v2`

## Question taxonomy / 提问主题
优先从以下主题提问：
- 范围与边界
- owner / source of truth
- 状态编排与联动
- 权限边界与安全
- 失败补偿与异常
- 数据定义与字段口径
- 验收与测试
- 依赖与交接

## Workflow / 执行流程
1. 识别当前 `source_mode`，并判断输入更偏 PRD、gap 还是 gate finding。
2. 先识别 blocker、major、minor 三档问题。
3. 若有 `GAP-XXX`，优先转成更适合会议决策的问题；若无，则直接从 PRD 抽题。
4. 对关键问题补 `why_this_matters`、建议回答角色、最晚决策时点和不决策后果。
5. 执行全局约束扫描，优先暴露红线/合规、幽灵实体、跨模块联动缺口。
6. 合并重复问题，保留最能推动决策的表述。
7. 判断是否需要外发 `feedback_signals[]`：若发现问题需要上游补稿、N100 gate 再判定、N110 交接前确认、或 N005 线上信号需要产品 owner 决策，必须在契约头或输出元数据中记录信号，不要只写在正文里。
8. 交付前按 `references/checklist.md` 自检，并参照 `references/scoring-rubric.md` 做质量自评。

## Self-check gate / 节点内自检
交付前至少确认：
- 每个关键问题都具体、可回答、可决定。
- 已排序且明确本轮必决项。
- 可回溯到 `PRD-XX`，有 gap 时也可回溯到 `GAP-XXX`。
- 没有大量 filler questions。
- 会议主持人能直接拿去开会，而不是再人工重写一版议程。

## Boundary rules / 边界规则
- 止于会议问题、挑战点、讨论提示和决策项，不代替技术方案或最终评审结论。
- 不得把未决问题写成既定答案。
- 若用户要求 CSV，可附表格；但默认仍保留会议叙事结构与优先级说明。

## Reference files / 参考文件
- `references/output-template.md`：固定会议输出结构
- `references/checklist.md`：交付前检查清单
- `references/N090_SHARED_CHECKLIST.md`：N090 三个 skills 共享契约自检
- `references/scoring-rubric.md`：质量评分标准
- `references/review-urgency-scoring.md`：**question_urgency_score = blocking_weight × deadline_weight + N005_modifier + Q1-Q7 分类决策树 + urgency 示例表（必读）**
- `references/meeting-facilitation-guide.md`：会议主持与升级建议
- `references/orchestration.md`：单 skill / 多 skill 的组合方式
- `references/example-io.md`：输入输出示例
- `references/common-failure-modes.md`：低价值问题模式
- `references/N090_COMMON_CONTRACTS.md`：共享契约与 artifact contract


## Workflow v2 artifact contract
```yaml
artifact_type: n090.prd-review-questions
schema_version: "2.0.0"
producer_skill: prd-review-question-generation
consumer_nodes: [N380]       # 送入人工 SLA 队列等待评审会处理
workflow_alias: PRD评审问题清单.md
produced_event_name: produced.n090.review-questions
sla_level: P1
auto_escalate_after: "48h"
canonical_fields:
  - question_id        # Q-{nnn}
  - question_urgency_score   # blocking_weight × deadline_weight + n005_modifier
  - blocking_level     # blocker / major / minor
  - deadline_proximity # immediate / near_term / next_handoff / open_end
  - related_prd_sections[]
  - related_gap_ids[]
  - why_this_matters
  - answer_owner
  - decision_deadline
n005_consumption: direct   # +2/+1/0 modifier on question_urgency_score
```

## Key references
- `../022-prd-generation/prd-generation/references/node-guide.md`：**N090 节点导航——3 个 skill 执行顺序、12 类 GAP taxonomy 速查（必读，见 022）**
- `../022-prd-generation/prd-generation/references/handoff-to-n100.md`：**N090→N100 节点交接协议——PRD 章节到 N100 维度映射（必读，见 022）**

- `references/N090_COMMON_CONTRACTS.md`：**N090 节点 prd_review_question_list artifact contract（必读）**
- `references/review-urgency-scoring.md`：**question_urgency_score = blocking_weight(blocker=5/major=3/minor=1) × deadline_weight(immediate=4/near_term=3/next_handoff=2/open_end=1) + N005_modifier(+2/+1/0)（必读）**
- `references/meeting-facilitation-guide.md`：会议主持与升级建议
- `references/scoring-rubric.md`：质量评分标准
- `references/output-template.md`：输出结构
- `references/N090_SHARED_CHECKLIST.md`：N090 三 skills 共享自检清单
- `references/checklist.md`：024 专项自检清单
- `references/common-failure-modes.md`：常见错误模式
