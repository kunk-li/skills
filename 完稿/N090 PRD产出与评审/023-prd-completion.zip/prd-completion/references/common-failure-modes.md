# Common Failure Modes

1. Writing only a summary instead of a working completion document.
2. Mixing fact, inference, and pending items in one paragraph.
3. Naming gaps without showing where they should be fixed in the PRD.
4. Giving generic suggestions like "补充信息" without a minimal-fill action.
5. Producing abstract design talk without modules, tables, or concrete examples.
6. Turning ambiguous PRD language into fake certainty.
7. Duplicating upstream analysis without adding completion value.
8. Failing to convert blocker gaps into reviewable questions or chapter-level edits.

## Mode-routing specific failures

- **standalone-gap-audit**: Produces a generic memo instead of a gap list with stable `GAP-XXX` records.
- **patch-drafting**: Suggests large rewrites when only a minimal fill or chapter-level insert is needed.
- **paired-or-chain**: Renumbers incoming `GAP-XXX` or `PRD-XX` references instead of preserving upstream traceability.
- **repair-loop**: Re-audits the whole PRD from scratch after a gate return, losing the focus on the returned blocker set.

## Contract-layer failures

- Missing `artifact_type`, `contract_version`, or `source_mode` in the output header.
- Emits `priority_score` with no supporting explanation and no `evidence_note` when the three component scores are omitted.
- Surfaces upstream blocking state in narrative only, without using `feedback_signals[]`.
- Mixes multiple contract versions or produces gaps that cannot be traced back to `PRD-XX` sections.
