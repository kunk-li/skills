# Composition Guide

## Positioning
- 本 skill 是 N090 节点内的**通用缺口补齐 skill**，不是只能在固定 DAG 顺序里使用的 Stage B。
- 选择条件应是“当前是否要识别、排序、补齐 PRD 缺口”，而不是“是否一定已有上一个 skill 的结果”。

## Operating modes
1. **standalone gap-audit**：仅基于现有 PRD 做缺口盘点与补稿建议。
2. **patch-drafting**：在发现 gap 后直接给章节级补写动作或草案插入段。
3. **paired / chain**：复用 `PRD-XX`、质量检查结果、上游主稿，把 gap 转成下游可消费的 `GAP-XXX`。
4. **repair-loop**：当门禁指出某类缺口未修复时，只重跑相关 gap 分析与补稿建议。

## Handoff requirements
- 输出必须能被 review question skill 直接消费：`GAP-XXX + related_prd_sections + review_followup`。
- 若缺少统一主稿结构，可以重建映射，但要明确标注 `from-source` 或 `derived_mapping`。
- 发现 blocker 时，必须给最小补齐动作；不能只给泛泛点评。

## Cross-node collaboration

Use this section when N090 is not running as an isolated document task.

- **N005 production signal intake**: When inputs include `线上痛点信号包.json`, `数据驱动需求建议.csv`, incident postmortems, defect clusters, or NPS/user-feedback clusters, treat them as evidence. Convert them into PRD sections, gaps, or review questions, and preserve source references. Do not silently redefine scope based only on production signals.
- **N100 gate repair loop**: When inputs include requirement completeness, executability, conflict, vulnerability, or quality-review findings, map each blocker to the smallest affected `PRD-XX`, `GAP-XXX`, or `Q-XXX`. Prefer targeted repair over regenerating the whole N090 package.
- **N110 handoff readiness**: Before handing off to engineering or QA, highlight unresolved scope, rule, state, permission, data, acceptance, owner, or dependency issues as `handoff_risk` feedback signals.
- **N370/N380 routing and human confirmation**: When a decision cannot be closed by the skill, emit `needs_review_decision` or `gate_repair_required` so the platform router or human-confirmation queue can pick it up.
