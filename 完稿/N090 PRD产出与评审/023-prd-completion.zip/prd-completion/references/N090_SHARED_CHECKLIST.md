# N090 Shared Contract Checklist

Use this checklist before applying the skill-specific delivery checklist. It is shared by `prd-generation`, `prd-completion`, and `prd-review-question-generation`.

## Contract header

- Declare `artifact_type` using the artifact produced by the current skill: `prd_document`, `prd_gap_list`, or `prd_review_question_list`.
- Declare `contract_version` using the current N090 contract version referenced in `N090_COMMON_CONTRACTS.md`.
- Declare `source_mode` using only allowed enum values from the relevant artifact contract.
- Include `traceability_summary` that explains which upstream inputs, evidence, PRD sections, gaps, questions, N005 signals, or gate findings were consumed.
- Preserve stable IDs instead of renaming them: `PRD-XX`, `GAP-XXX`, `Q-XXX`, `P-`, `FT-`, `ACT-`, and `FLD-`.

## Evidence and uncertainty

- Separate confirmed facts, reasonable inferences, and items needing confirmation.
- Do not turn weak evidence, production observations, or reviewer guesses into confirmed requirements.
- When evidence is insufficient, create a pending item, gap, or review question instead of silently filling the blank.

## Feedback signals

Populate `feedback_signals[]` when any of the following occur:

- `upstream_missing`: required upstream material is missing or unusable.
- `needs_review_decision`: a blocker cannot be closed without product, design, engineering, QA, security, legal, or operations decision.
- `needs_upstream_rerun`: upstream structure, prototype parsing, quality review, or signal aggregation should be rerun because the current output found material inconsistency.
- `gate_repair_required`: N100/N380 gate findings require a targeted repair loop.
- `handoff_risk`: N110 handoff would be risky without explicit confirmation.
- `production_signal_requires_triage`: N005 production signal reveals a PRD gap, review decision, or risk that should not be silently absorbed.

Each signal should include `signal_type`, `severity`, `target`, `evidence`, and a concise recommended next action.
