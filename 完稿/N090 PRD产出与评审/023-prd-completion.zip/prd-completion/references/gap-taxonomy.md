# N090 Standard Gap Taxonomy / 12 类标准缺口分类法

这是 `gap-taxonomy-extension.md` 所引用的"N090 的 12 类标准缺口"的正式定义文件。
所有 N090 skill 中 `gap_type` 字段的取值必须优先从本表选取。

---

## 12 类标准缺口

| gap_type | 中文名 | 核心定义 | 判别信号 | 排除规则 |
|---|---|---|---|---|
| `missing_scope` | 范围缺失 | 需求边界未明确，无法判断某功能或对象是否在本期 | "是否支持 X"没有明确答案；功能存在于原型但 PRD 未提及 | 已明确说明不做的，不计入 |
| `missing_business_rule` | 业务规则缺失 | 某个 L3 功能的执行条件/分支逻辑未定义 | "什么情况下触发"或"例外路径"未描述；现有描述无法覆盖所有输入 | 纯技术实现规则不属于本类 |
| `missing_state_definition` | 状态定义缺失 | 对象的状态集合或状态转移路径未完整描述 | 状态图中存在死端、孤立状态或未描述的触发条件 | 与 015 的状态机完整性检查配合使用 |
| `missing_permission` | 权限定义缺失 | 某个动作的主体/资源/效果未明确 | "谁可以做"或"在什么条件下允许"缺失；权限随状态变化的规则未定义 | 与 016 的权限矩阵配合 |
| `missing_data_definition` | 数据定义缺失 | 字段、对象或数据模型的属性、类型、约束未定义 | 字段名存在于功能描述但无数据规格；枚举值未列出 | 与 017 的数据对象识别配合 |
| `missing_error_handling` | 异常处理缺失 | 正常流程已描述，但失败路径/补偿逻辑/超时处理未定义 | "如果失败怎么办"或"超时后"无描述；幂等性未定义 | 仅适用于系统行为，UI 错误提示措辞不算 |
| `missing_nfr` | 非功能需求缺失 | 性能、可用性、安全、可扩展性等质量属性未量化 | 只有定性描述（"快速响应"）没有可测量指标；SLA 未定义 | 已有具体指标的视为已定义 |
| `missing_acceptance_criteria` | 验收标准缺失 | 某个功能/规则没有可验证的完成条件 | 无法写出对应的测试用例；描述为"应该""可能"而无明确断言 | 与 032 的验收标准生成配合 |
| `missing_dependency` | 依赖关系缺失 | 某功能依赖其他模块/外部系统/上游数据，但依赖关系未说明 | 功能隐含使用外部 API/数据但未列出；跨模块协作未定义接口 | 纯内部实现依赖不属于本类 |
| `missing_compliance` | 合规要求缺失 | 监管、法律、行业标准要求未在需求中体现 | 数据主权、隐私保护、留存期限等监管要求缺失；安全合规未提及 | 已有"待确认"的合规项视为 pending，不算 gap |
| `missing_sequence` | 时序定义缺失 | 多个动作/事件之间的先后关系、并发约束或等待条件未定义 | "何时触发""是否可以并行""等待谁完成"未描述；SLA 时序链缺失 | 仅适用于跨动作/跨角色时序，单动作内部顺序不算 |
| `missing_boundary_case` | 边界条件缺失 | 正常流程有描述，但极端值/零值/最大值/并发场景未覆盖 | 数量为 0 时的行为未定义；最大容量/并发限制未说明；临界状态的行为未描述 | 属于业务规则范畴的边界（if/else 可表达）优先归 `missing_business_rule` |

---

## 判别边界说明

### `missing_business_rule` vs `missing_boundary_case`
- 可以用 if/else 表达的执行逻辑 → `missing_business_rule`
- 无法用 if/else 在文档中找到入口、属于极端输入或容量边界 → `missing_boundary_case`

### `missing_state_definition` vs `missing_business_rule`
- 描述的是对象"是什么状态" → `missing_state_definition`
- 描述的是"什么条件触发状态变化的逻辑" → `missing_business_rule`（也可以两者同时标注）

### `missing_permission` vs `missing_business_rule`
- "谁可以做"（主体限制）→ `missing_permission`
- "什么条件下可以做"（非主体条件）→ `missing_business_rule`

### `missing_compliance` vs `missing_nfr`
- 有明确监管法规/条款可引用 → `missing_compliance`
- 是通用质量属性要求（性能/安全/可用性），无具体法规指向 → `missing_nfr`

---

## 扩展规则（引用自 gap-taxonomy-extension.md）

只有当上述 12 类无法准确描述缺口时，才允许使用 `custom:<name>` 扩展类型，且必须补充：
- `custom_taxonomy_name`
- `why_default_taxonomy_insufficient`
- `classification_rule`

---

## gap_type 选择决策树 / Gap Type Selection Decision Tree

```
Q1: 是否完全无法判断某功能是否在本期范围内？
    YES → missing_scope
    NO  → Q2

Q2: 问题的核心是"谁可以做"（主体限制）？
    YES → missing_permission
    NO  → Q3

Q3: 问题的核心是"某个对象有哪些状态"或"状态如何转移"？
    YES → missing_state_definition
    NO  → Q4

Q4: 问题的核心是"字段/对象/枚举值的定义或约束"？
    YES → missing_data_definition
    NO  → Q5

Q5: 问题的核心是"触发条件、分支逻辑、例外路径"（可用 if/else 表达）？
    YES → missing_business_rule
    NO  → Q6

Q6: 问题的核心是"失败时怎么办、超时怎么处理、幂等如何保证"？
    YES → missing_error_handling
    NO  → Q7

Q7: 问题的核心是"多个动作/事件的先后顺序或并发约束"？
    YES → missing_sequence
    NO  → Q8

Q8: 问题的核心是"测试用例无法写、无法判断什么算完成"？
    YES → missing_acceptance_criteria
    NO  → Q9

Q9: 问题的核心是"外部系统/模块依赖关系未说明"？
    YES → missing_dependency
    NO  → Q10

Q10: 问题的核心是"监管/法律/行业合规要求未体现"？
    YES → missing_compliance
    NO  → Q11

Q11: 问题的核心是"性能/可用性/安全等质量指标未量化"？
    YES → missing_nfr
    NO  → Q12

Q12: 问题的核心是"零值/最大值/并发等极端场景未覆盖"？
    YES → missing_boundary_case
    NO  → 尝试 custom:<n>（见 gap-taxonomy-extension.md）
```

### 高频混淆 Case 对照表

| 场景 | 正确 gap_type | 易混淆类型 | 判别信号 |
|---|---|---|---|
| "不知道 A 功能是否在本期做" | missing_scope | missing_business_rule | 无法判断范围本身 |
| "不知道 A 功能怎么触发/条件是什么" | missing_business_rule | missing_scope | 范围确定，逻辑不清 |
| "不知道谁能删除订单" | missing_permission | missing_business_rule | 核心问题是主体而非条件 |
| "不知道删除订单后数据如何处理" | missing_error_handling | missing_business_rule | 核心是失败/删除后的补偿 |
| "不知道支付接口是哪个" | missing_dependency | missing_data_definition | 核心是外部系统 |
| "支付字段没有定义格式" | missing_data_definition | missing_dependency | 核心是字段约束 |
| "先付款还是先扣库存" | missing_sequence | missing_business_rule | 核心是时序 |
| "并发扣减库存会超卖" | missing_boundary_case | missing_error_handling | 并发极端场景 |
| "数据主权法规未体现" | missing_compliance | missing_nfr | 有具体法规条款可引用 |
| "响应时间没有指标" | missing_nfr | missing_acceptance_criteria | 质量属性未量化 |
