# N090 Artifact Contracts v2.1

这份共同契约适用于 `prd-generation`、`prd-completion`、`prd-review-question-generation` 三个 skill，目标是让它们在 **节点内保持通用、单个可用、多个组合更强**。

## 0. 设计原则

1. **按产物语义协作，不按文件名硬耦合**。
   - workflow 中出现的 `PRD.md`、`PRD补全建议.md`、`PRD评审问题清单.csv` 是推荐产物名，不是唯一触发条件。
   - 只要输入在语义上等价于“PRD 主稿 / gap 清单 / 评审问题清单”，都应被视为可消费输入。
2. **先保证单 skill 可交付，再追求链路协同**。
3. **跨 skill 增强依赖共享 ID、共享字段、共享证据层级，而不是依赖固定顺序**。
4. **涉及结构性变更时必须升契约版本**，避免下游误读。

## 1. 契约版本

- 当前共同契约版本：`n090.contract.v2.1`
- `v2.1` 是对 `v2` 的非 breaking patch：仅新增可选字段、兼容性说明与评分澄清，不改变最小可读结构。
- 若发生以下任一变化，应视为 breaking change，并升主版本：
  - 必填字段变化
  - ID 体系变化
  - 输出结构无法被相邻 skill 直接复用
  - 事实 / 归纳 / 待确认三层表达被改写

### 1.1 Version Compatibility Matrix

| Contract ID | Current version | Compatible reads | Upgrade notes |
|---|---|---|---|
| `n090.contract` | v2.1 | v2 / v1 | Adds optional fields only; non-breaking. |
| `n090.prd` | v2 | v1 | The 16-section shape remains stable. |
| `n090.prd-gap` | v2 | v1 | Three-factor scoring remains valid; `priority_score` is now clarified as mandatory at contract layer. |
| `n090.prd-review` | v2 | v1 | The 5-part meeting-ready structure remains stable. |

Rules:
1. New consumers should read older artifacts without data loss whenever possible.
2. Breaking changes must bump the major contract version.
3. A single produced artifact set must not mix contract versions for the same semantic artifact type.

## 2. 输入证据分层契约

所有 skill 都必须按以下顺序判断证据权重：

1. **Primary inputs**：当前任务直接消费的核心输入。
2. **Upstream structured outputs**：相邻 skill 或上游节点提供的结构化结果。
3. **Secondary context**：原始笔记、截图、会议记录、补充说明。

规则：
- 不得让 Secondary context 覆盖 Primary inputs。
- 上游结构化结论若与 Primary inputs 冲突，必须显式标记为 `待确认`。
- 无法定位到证据层级的内容，不得写成既定事实。

## 3. 三层表达契约

每个输出都必须显式区分：
- **已确认事实**
- **合理归纳**
- **待确认项**

不得把三层内容混写成一个结论或同一条记录。

## 4. ID 命名空间契约

### 4.1 PRD section IDs
- `PRD-01` 文档信息与版本说明
- `PRD-02` 背景与目标
- `PRD-03` 范围与非范围
- `PRD-04` 角色与核心场景
- `PRD-05` 业务流程/页面或能力概览
- `PRD-06` 功能需求清单
- `PRD-07` 业务规则
- `PRD-08` 状态流转
- `PRD-09` 权限要求
- `PRD-10` 数据对象与关键字段
- `PRD-11` 异常与边界处理
- `PRD-12` 非功能与约束
- `PRD-13` 验收标准
- `PRD-14` 依赖与风险
- `PRD-15` 待确认项
- `PRD-16` 附录/参考输入

### 4.2 Gap IDs
- 使用 `GAP-001`、`GAP-002` ...
- 每个 gap 至少包含：`gap_id`、`gap_type`、`related_prd_sections`

### 4.3 Question IDs
- 使用 `Q-001`、`Q-002` ...
- 每个问题至少包含：`q_id`、`related_prd_sections`
- 若来自 gap，还应尽量补 `related_gap_ids`

### 4.4 跨节点锚点 IDs（与 N080 对齐）
当原型解析结果存在时，必须保留其 ID，不得重命名：
- `P-{module}-{nn}`：页面/容器锚点
- `FT-{module}-{page_seq}-{nn}`：功能点锚点
- `ACT-{module}-P{page_seq}-{nn}`：动作锚点
- `FLD-{module}-P{page_seq}-{nn}` 与 `F{seq}`：字段锚点

规则：
- `PRD-XX` 是 N090 内部章节 ID，不替代上游实体 ID。
- 上游实体 ID 作为 cross-reference 使用，而不是被抹掉。
- 若与 PRD 表述冲突，必须保留冲突并标记为 `待确认`。

#### upstream_refs[] 字段格式（PRD 章节级）

每个 PRD 章节的 section metadata 中应包含 `upstream_refs[]`，记录该章节的 N080 来源：

```yaml
- section_id: PRD-05
  section_title: 业务流程 / 页面或能力概览
  status: confirmed
  upstream_refs:
    - ref_type: page         # page / feature / action / field / rule / object
      ref_id: P-ORDER-01
      ref_skill: "018"
      relationship: primary_source   # primary_source / supporting / contradicted
```

当 N080 结果不可用时：`upstream_refs: []`（空列表，不得省略字段）。

详细规则见全链路 `references/cross-node-bridge-contract.md`。

## 5. 产物契约层（Artifact Contracts）

### 5.1 `prd_document` contract
适用于 `prd-generation` 的主输出，也适用于其他 skill 在引用 PRD 时的最小识别结构。

最少要让下游可恢复以下要素：
- `artifact_type = prd_document`
- `contract_version = n090.prd.v2`
- `source_mode`：`from-source` / `from-structured` / `from-existing-prd` / `composed`
- `traceability_summary`
- `sections[]`：每节至少可定位 `section_id`, `section_title`, `status(confirmed|inferred|open)`

规则：
- 默认保持 `PRD-01` 到 `PRD-16` 完整存在。
- 缺内容时保留章节，不得静默删除。
- 若输出为 markdown，自然语言结构也必须能稳定映射到以上字段。

### 5.2 `prd_gap_list` contract
适用于 `prd-completion` 的主输出。

每个 gap 最少包含：
- `gap_id`
- `gap_type`
- `related_prd_sections`
- `finding`
- `impact`
- `minimal_fill`
- `blocking`
- `priority_score`

能补时再补：
- `draft_insert`
- `review_followup`
- `suggested_owner`
- `evidence_note`

契约头至少可恢复：
- `artifact_type = prd_gap_list`
- `contract_version = n090.prd-gap.v2`
- `source_mode`

评分字段澄清：
- `priority_score` 是契约层必填字段，下游排序与聚合应优先依赖它。
- `urgency_score`、`impact_score`、`resolution_difficulty_score` 是 `gap-scoring-model.md` 定义的推理过程字段：在完整 gap scoring 视角下应填写；在共同契约层为推荐字段。
- 如果产物中省略三维分解，必须在 `evidence_note` 中说明 `priority_score` 的推导依据，保证审计与追溯可恢复。

### 5.3 `prd_review_question_list` contract
适用于 `prd-review-question-generation` 的主输出。

每个问题最少包含：
- `q_id`
- `question`
- `related_prd_sections`
- `why_this_matters`
- `decision_owner_or_role`
- `deadline_proximity`
- `question_urgency_score`

若来自 gap，尽量补：
- `related_gap_ids`
- `blocking_level`
- `if_unresolved_consequence`

契约头至少可恢复：
- `artifact_type = prd_review_question_list`
- `contract_version = n090.prd-review.v2`
- `source_mode`

### 5.4 `feedback_signals[]` optional field

三个 artifact contract 都可以在需要时输出 `feedback_signals[]`，用于表达“输入来源之外的反馈事件”：例如上游缺失、需要补稿、需要评审裁决、需要定向重跑等。

Recommended shape:

```yaml
feedback_signals:
  - signal_type: upstream_missing | needs_prd_backfill | needs_review_decision | needs_upstream_rerun | gate_repair_required | handoff_risk | production_signal_requires_triage | custom:<name>
    related_section: PRD-XX | GAP-XXX | Q-XXX
    description: Why this signal exists
    target: N005 feedback loop | N100 gate | N380 human coordination | human review | 022 prd-generation
    severity: blocker | major | minor
```

Notes:
- 标准 `signal_type` 必须优先使用上方枚举；只有无法归类时才使用 `custom:<name>`。
- `gate_repair_required` 用于 N100/N380 门禁返工；`handoff_risk` 用于 N110 交接风险；`production_signal_requires_triage` 用于 N005 线上信号需要产品 Owner 分诊。
- `source_mode` 描述输入来源；它不替代 `feedback_signals[]`。
- 需要向事件总线、门禁、人工评审或上游 skill 显式外发状态时，使用 `feedback_signals[]`。
- 如果没有反馈事件，不输出该字段也完全合法。

## 6. 兼容性与降级契约

### 6.1 Standalone mode
- 单独运行时，skill 可以从原始材料中**重建** `PRD-XX` / `GAP-XXX` / `Q-XXX` 映射。
- 只要是重建出来的映射，都应显式说明是 `derived_mapping` 或 `from-source`。

### 6.2 Paired / chain mode
- 多 skill 协同时，必须优先复用上游已有 ID，不得二次编号。
- 若上游缺失，可以继续执行，但不要把反馈状态塞进 `source_mode`。
- 需要显式外发的状态，应写入 `feedback_signals[]`，例如：`upstream_missing`、`needs_prd_backfill`、`needs_review_decision`、`needs_upstream_rerun`、`gate_repair_required`、`handoff_risk`、`production_signal_requires_triage`。

### 6.3 Repair loop mode
- 当质量门禁或人工评审退回时，应只修复相关产物，不要求整条链路重跑。
- rerun 时必须保留已有 ID，避免追溯断裂。
- repair-loop 的默认动作是 patch 相关 section / gap / question，而不是整稿重写；除非用户明确要求 full regeneration。

## 7. 全局约束扫描契约

三个 skill 都必须显式扫描以下风险，并在输出中单独呈现：
1. **红线/政策/合规约束**
2. **幽灵实体/幽灵流程**
3. **跨模块联动缺口**

若扫描到风险，必须进入显式输出，而不是埋在正文中。

## 8. 节点自检 / 渐进门禁契约

每个 skill 在交付前至少自检：
1. 结构是否完整。
2. 事实 / 归纳 / 待确认是否分层。
3. ID 与追溯关系是否完整。
4. 是否完成全局约束扫描。
5. 是否能被相邻 skill 或人工直接消费。
6. 是否明确说明当前 `source_mode` 与局限。

## 9. 与 workflow v2 的对齐方式

- **产物契约层**：通过 `artifact_type + contract_version + 共享 ID` 降低耦合。
- **渐进门禁**：每个 skill 内都先自检，再交给 N100 / N380 汇总判定。
- **三层路由**：平台先选阶段、再选节点、再选 skill；skill 本身只负责自己的原子能力，不要求强绑定串行 stage。
- **反馈修复**：若后续 review / gate 发现问题，优先回到最小必要 skill 修复，不整链回滚。
