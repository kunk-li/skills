# Gap Scoring Model

用于 `prd-completion` 的缺口优先级排序。

## 三维评分
每个 gap 都应给出 1-5 分：
- `urgency_score`：离评审 / 设计 / 交接越近，分越高。
- `impact_score`：若不解决，对评审、设计、实现、交接影响越大，分越高。
- `resolution_difficulty_score`：越难补、越需要提前拉齐，分越高。

## 推荐计算
- `priority_score = urgency_score * impact_score * resolution_difficulty_score`
- 同分时按 `blocking` 级别排序：`blocker > major > minor`

## 解释要求
- 不得只给分数，不解释来源。
- 每个高分 gap 至少要解释：为什么紧急、为什么影响大、为什么不容易补。

## N005 production signal weighting

When a gap is supported by N005 production signals, do not treat the signal as a confirmed requirement by itself. Use it as evidence that can raise urgency or impact when the signal is specific and traceable.

- Raise `impact_score` by 1 point, capped at 5, when the gap is linked to high-frequency errors, repeated defect clusters, incident postmortems, or measurable user feedback that affects core flows.
- Raise `urgency_score` by 1 point, capped at 5, when the N005 signal indicates an active production issue, repeated release regression, compliance/security exposure, or upcoming handoff risk.
- Do not raise scores for vague anecdotes, one-off feedback, or signals without a source reference; instead record `production_signal_requires_triage` in `feedback_signals[]`.
- For any N005-based adjustment, explain the source signal, affected PRD section, and why the score changed.
