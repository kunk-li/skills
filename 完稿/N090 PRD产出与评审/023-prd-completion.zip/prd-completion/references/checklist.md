# Delivery Checklist

## Shared contract self-check

先执行 `references/N090_SHARED_CHECKLIST.md`，再执行本文件中的 skill-specific 自检项。特别注意：`source_mode` 必须使用契约允许枚举，跨节点风险必须写入 `feedback_signals[]`。

## Scoring Field Self-check

- 是否为每个 gap 提供了 `priority_score`？
- 若提供完整评分，是否同时给出 `urgency_score`、`impact_score`、`resolution_difficulty_score`？
- 若未提供三维分解，是否在 `evidence_note` 中解释了 `priority_score` 的推导依据？

- 是否使用了固定结构，而不是自由发挥成 4-5 节 memo？
- 是否把 已确认事实 / 推断建议 / 待确认项 分层？
- 是否完成了全局约束 / 红线扫描？
- 每个 gap 是否都有 `GAP-XXX` 和 `related_prd_sections`？
- 是否明确指出应补到哪个 `PRD-XX`，而不是只说“需要补充”？
- blocker gap 是否给出了最小补齐动作、建议 owner、以及 review_followup？
- 是否给出了 `urgency_score / impact_score / resolution_difficulty_score / priority_score`？
- 若使用自定义 taxonomy，是否解释了为什么默认 taxonomy 不足？
- 新人是否能看懂为什么这是个 gap？
- 024 是否可以直接消费这份输出？
