# Scoring Rubric

## 1 - Weak
只是泛泛点评 PRD 不完整，没有 gap id、没有章节回填建议、没有评分。

## 2 - Basic
能看出主要缺口，但追溯性和可执行性不足，taxonomy 和排序仍很弱。

## 3 - Usable
有明确 `GAP-XXX`、章节回填点、优先级和基础三维评分，可作为补稿清单使用。

## 4 - Strong
兼顾新人可读性、章节级回填、gap traceability、taxonomy 解释与下游复用价值。

## 5 - Excellent
不仅识别缺口，还完成全局约束扫描、taxonomy 治理、三维评分排序和 024-ready 的问题转化线索。

---

## GAP 优先级量化评分（补充）

```
gap_list_quality_score = 100 - (
  gaps_without_priority_score × 10 +    # gap 无 priority_score 字段
  gaps_without_related_prd × 8 +        # gap 无 related_prd_sections
  gaps_without_minimal_fill × 12 +      # blocker 级别 gap 无 minimal_fill
  high_priority_without_owner × 8 +     # priority_score ≥ 15 且无 suggested_owner
  custom_gap_without_justification × 5  # custom: 类型无 why_default_insufficient
)
clip to [0, 100]
```
