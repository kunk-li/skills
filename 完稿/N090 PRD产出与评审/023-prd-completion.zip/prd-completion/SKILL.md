---
name: prd-completion
description: Identify, prioritize, and patch missing required PRD information into chapter-level backfill actions or draft inserts; completes an existing incomplete PRD, not authoring from scratch.
---

# PRD Completion

识别 PRD 缺口，并把缺口转成**可回填、可追溯、可交接**的补齐动作。这个 skill 在 N090 节点内承担“缺口补齐”原子能力：**既能独立盘点缺口，也能在组合链路里提供稳定的 `GAP-XXX` 资产**。

## Role / 角色定位
- 识别 PRD 中对 review、handoff、design、audit 有影响的缺失信息。
- 输出的不只是“哪里没写”，而是**缺什么、影响什么、最小怎么补、可选怎么补写**。
- 为 review question 和人工评审提供可追溯的 `GAP-XXX` 底稿。

## Mode routing / 模式路由
### 1) `standalone-gap-audit`
适用于只有现有 PRD 时。
- 重建 `PRD-XX` 映射。
- 输出缺口清单、优先级和最小补稿动作。
- 无法稳定补写时，也要明确说明为什么不能补。

### 2) `patch-drafting`
适用于用户明确要求“补全”而不是只做审查时。
- 在 gap 识别基础上，进一步给章节级 `draft_insert` 或补写建议。
- 高优先级 gap 尽量提供最小可落文段落。

### 3) `paired-or-chain`
适用于已有主稿、质量检查结果或其他结构化结论时。
- 优先复用 `PRD-XX`。
- 吸收 `requirement-completeness-check` 或质量审查中的 blocker。
- 输出必须可被下游直接转为 review questions。

## Single-skill value / 单独使用价值
- 即使没有 `prd-generation` 或质量检查结果，也必须交付**可执行的补齐方案**。
- 单独运行时，不能退化成只有 3-5 条泛泛点评。

## Composition value / 组合价值
- 与 `prd-generation` 组合：将主稿中的缺口转成章节级回填动作。
- 与 `requirement-completeness-check` 或质量审查结果组合：把完整性 blocker 显式落为 `GAP-XXX`。
- 与 `prd-review-question-generation` 组合：把 gap 直接转成会议决策问题底稿。

## Accepted inputs / 可接受输入
### Primary
- prd draft
- existing prd text
- prd fragments with recoverable section structure

### Recommended
- `prd-generation` output
- completeness / quality findings
- pending-item lists

### Optional
- structured requirement outputs
- prototype findings
- meeting notes
- production signal package from N005, such as incident postmortems, defect classifications, high-frequency error summaries, or user-feedback clusters that reveal missing rules, failure paths, acceptance criteria, or risk statements

## Mandatory output / 默认输出契约
除非用户明确要求另一种格式，否则必须按 `references/output-template.md` 输出，并满足：
- 每个 gap 使用 `GAP-XXX`
- 每个 gap 必须给出 `related_prd_sections`
- 每个 gap 至少给出 `finding / impact / minimal_fill / blocking / priority_score`
- 高优先级 gap 尽量补 `draft_insert`
- 必须包含“全局约束/红线扫描”章节
- 输出应符合 `references/N090_COMMON_CONTRACTS.md` 中 `prd_gap_list` contract，契约版本为 `n090.prd-gap.v2`

## Gap taxonomy / 缺口分类
默认使用以下类型，并按最接近的一类归档：
- `missing_scope`
- `missing_rule`
- `missing_state`
- `missing_permission`
- `missing_data_definition`
- `missing_source_of_truth`
- `missing_owner`
- `missing_failure_result`
- `missing_audit_requirement`
- `missing_acceptance_criteria`
- `missing_orchestration`
- `missing_policy_definition`

若明显超出默认 taxonomy，可按 `references/gap-taxonomy-extension.md` 扩展。

## Workflow / 执行流程
1. 识别当前 `source_mode`，并重建 `PRD-XX` 骨架。
2. 先做全局约束扫描：红线/合规、幽灵实体、跨模块联动缺口。
3. 逐条识别 gap，归类到标准 taxonomy。
4. 给每个 gap 打分，并按 `priority_score` 排序。
5. 为 blocker 和高优先级 gap 输出最小补稿动作；用户要求补写时，进一步补 `draft_insert`。
6. 对不能稳定补写的 gap，明确写出限制与待确认项，不能伪造 owner、规则、排期或决策。
7. 判断是否需要外发 `feedback_signals[]`：若发现上游 PRD 结构缺失、N100 gate return 未被修复、N005 线上信号指向新增 gap、或某个 blocker 必须人工决策，必须在契约头或输出元数据中记录信号，不要只写在正文里。
8. 交付前按 `references/checklist.md` 自检，并参照 `references/scoring-rubric.md` 做质量自评。

## Self-check gate / 节点内自检
交付前至少确认：
- 每个 gap 都能回溯到 `PRD-XX`。
- 关键 gap 已给 `minimal_fill`。
- 高优先级 gap 若未给 `draft_insert`，已说明原因。
- 事实 / 推断 / 待确认分层清晰。
- 下游能直接把 gap 转为问题、会议议程或补稿任务。

## Boundary rules / 边界规则
- 不得凭空创造未经证实的新规则、新范围或新承诺。
- 不得把模糊历史信息写成已确认事实。
- 不得只输出问题列表冒充补齐结果。
- 若用户只要 audit memo，可以减少补写正文；若用户要“直接补文档”，应尽量补章节级插入建议。

## Reference files / 参考文件
- `references/output-template.md`：固定输出结构
- `references/checklist.md`：交付前检查清单
- `references/N090_SHARED_CHECKLIST.md`：N090 三个 skills 共享契约自检
- `references/scoring-rubric.md`：质量评分标准
- `references/gap-scoring-model.md`：gap 三维评分模型
- `references/gap-taxonomy.md`：**N090 标准 12 类缺口分类法（gap_type 枚举 + Q1-Q12 选择决策树 + 高频混淆 case 表）（必读）**
- `references/gap-taxonomy-extension.md`：taxonomy 扩展规则（仅在 12 类不足时使用）
- `references/common-failure-modes.md`：常见失败模式
- `references/orchestration.md`：单 skill / 多 skill 的组合方式
- `references/example-io.md`：输入输出示例
- `references/N090_COMMON_CONTRACTS.md`：共享契约与 artifact contract


## Workflow v2 artifact contract
```yaml
artifact_type: n090.prd-gap-list
schema_version: "2.0.0"
producer_skill: prd-completion
consumer_nodes: [N100, N111]
workflow_alias: PRD缺口清单.md
produced_event_name: produced.n090.gap-list
canonical_fields:
  - gap_id             # GAP-{nnn}
  - gap_type           # 12 类标准缺口（见 gap-taxonomy.md）
  - related_prd_sections[]
  - upstream_refs[]    # N080 来源 ID（若 gap 源自原型发现）
  - finding
  - impact
  - minimal_fill
  - blocking
  - priority_score     # urgency × impact × difficulty
  - source_gap_id      # 若关联已有 GAP（自引用或 N100 回写用）
  - n005_influenced    # 是否受 N005 信号影响（bool）
n005_consumption: direct   # 接受 production_signal_modifier 调整 priority_score
```

## Key references
- `../../022-prd-generation/prd-generation/references/handoff-to-n100.md（见 022）`：**N090→N100 节点交接协议（必读）**
- `../../022-prd-generation/prd-generation/references/node-guide.md（见 022）`：**N090 节点导航——12 类 GAP taxonomy 速查、与 N100 交接规则（必读）**

- `references/N090_COMMON_CONTRACTS.md`：**N090 节点 prd_gap_list artifact contract（必读）**
- `references/cross-node-bridge-contract.md`：**GAP 条目中 upstream_refs[] 溯源 N080 ID + N100 新发现 issue 的 GAP 回写规则（必读）**
- `references/gap-taxonomy.md`：**N090 标准 12 类缺口分类法（gap_type 枚举及判别规则）（必读）**
- `references/gap-scoring-model.md`：**gap 三维优先级评分公式（urgency × impact × difficulty）+ N005 信号加权（必读）**
- `references/gap-taxonomy-extension.md`：自定义 gap 类型扩展规则
- `references/scoring-rubric.md`：质量评分标准
- `references/output-template.md`：输出结构
- `references/N090_SHARED_CHECKLIST.md`：N090 三 skills 共享自检清单
- `references/checklist.md`：023 专项自检清单
- `references/common-failure-modes.md`：常见错误模式
