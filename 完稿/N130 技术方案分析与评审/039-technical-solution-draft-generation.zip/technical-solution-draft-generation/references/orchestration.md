# orchestration

Use these skills independently or as a chain.

## default n130 chain
1. `technical-solution-analysis`
2. `technical-solution-draft-generation`
3. `solution-review-question-generation`

This is the preferred in-node order for workflow v2.

## standalone use
- `technical-solution-analysis`: use for decision framing, option comparison, assumption surfacing, and failure-mode discovery
- `technical-solution-draft-generation`: use for turning a chosen or provisional direction into a canonical design draft
- `solution-review-question-generation`: use for stress-testing any design or analysis pack and preparing a decision-oriented review

## shared carry-forward rules
Carry these items forward when present:
- upstream `decision_refs`
- `requirement_coverage_matrix` status
- `defect_items_to_carry_forward`
- open assumptions and high-risk failure modes
- unresolved items that may trigger `route_back_to`

## combination quality bar
A strong N130 chain usually shows:
- canonical contract header is present in every artifact
- every skill can run in `standalone` or `provisional` mode when inputs are partial
- exact section ids and enum values remain stable across the chain
- defects are not buried; they are mapped into risks, assumptions, gaps, or questions
- review findings can route back to analysis or draft without losing traceability

## merger rule
If the user asks for a single package document, keep the three skill outputs logically separate inside the merged package:
- analysis block
- draft block
- review block
Do not destroy canonical section ids just to make the prose read more smoothly.
