# example io

## example input packet
- output from `technical-solution-analysis`
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`
- optional permissions, objects, or acceptance material

## canonical output shape
1. artifact contract header
2. `solution_id`, `version`, `status`
3. `sections.S1_summary`
4. `sections.S2_alternatives_considered`
5. `sections.S3_proposed_architecture`
6. `sections.S4_interface_contracts`
7. `sections.S5_requirement_coverage_matrix`
8. `sections.S6_non_functional_design`
9. `sections.S7_deployment_topology`
10. `sections.S8_migration_and_rollout`
11. `derived_from`
12. `decision_refs`
13. unresolved items, node self-check summary, and downstream handoff

## strongest downstream carry-forward items
- `selected_candidate`
- `rejected_candidates`
- `requirement_coverage_matrix`
- `interface_contracts_summary`
- `deployment_decisions`
- `decision_refs`

## downgrade example · direction agreed, interface details missing

Scenario: the user already picked a direction (for example "extract order service + saga"), but the interface intent file is thin and N150 owner has not finalized endpoints.

Expected behaviour:

- set `readiness: provisional` and `artifact_nature: draft_only`
- `sections.S2_alternatives_considered` still lists at least three options; the rejected ones re-use the reasoning surfaced in the analysis artifact rather than being re-invented
- `sections.S3_proposed_architecture.components[]` is complete enough to name each component and its responsibility, even when `technology` is `TBD`
- `sections.S4_interface_contracts`:
  - `api_contracts[]` may list the APIs with `method`, `path`, and a placeholder `request: { fields: TBD }` / `response_200: { fields: TBD }` body
  - unresolved request / response shapes show up as `contract_ref` pointers to unresolved items, never as silent gaps
  - `event_contracts[]` and `db_schema_contracts[]` still exist; if they truly have no content, emit the empty arrays explicitly
- `sections.S6_non_functional_design` keeps all eight subsections; any subsection without data writes `status: to_confirm` rather than vanishing
- `sections.S7_deployment_topology` uses placeholders (`replicas: TBD`) plus a `decision_variable` note so downstream work knows what to fill in
- `sections.S8_migration_and_rollout.migration_phases[]` names every phase with a rollback point even when durations are still estimates
- every rule in `contract-consistency-check.md` still runs; any failure becomes a blocker listed in unresolved items

## ex-001 · S5 requirement coverage matrix — concrete example

```yaml
sections:
  S5_requirement_coverage_matrix:
    rows:
      - requirement_ref: ER-001
        name: dual-approval-capability
        priority: P0
        covered_by_components: [COMP-001-ApprovalOrchestrator, COMP-002-OrderCore]
        covered_by_apis: [API-approval-submit, API-approval-status]
        covered_by_events: [approval.decision.recorded]
        coverage_status: fully_covered
        gap_if_not_fully: ""

      - requirement_ref: ER-002
        name: audit-retention-7y
        priority: P0
        covered_by_components: [COMP-003-AuditService]
        covered_by_apis: []
        covered_by_events: [audit.event.written]
        coverage_status: fully_covered
        gap_if_not_fully: ""

      - requirement_ref: ER-003
        name: timeout-reminder-notification
        priority: P1
        covered_by_components: [COMP-004-NotificationScheduler]
        covered_by_apis: [API-reminder-trigger]
        covered_by_events: [reminder.sent]
        coverage_status: partially_covered
        gap_if_not_fully: "DLQ for failed reminders not yet designed; tracked in open question OQ-001"

      - requirement_ref: ER-004
        name: hr-system-integration
        priority: P1
        covered_by_components: [COMP-005-HRConnector]
        covered_by_apis: [API-hr-callback]
        covered_by_events: [hr.provisioning.triggered]
        coverage_status: partially_covered
        gap_if_not_fully: "HR API contract unconfirmed (ASSUMP-001); synchronous fallback not drafted"

    completeness_check:
      total_requirements: 4
      fully_covered: 2
      partially_covered: 2
      not_covered: 0
      p0_all_covered: true
      p0_gate: pass
      open_gaps:
        - gap_id: GAP-001
          requirement_ref: ER-003
          description: DLQ handling for reminder failure not designed
          owner: backend-team
          resolution_by: sprint-3
        - gap_id: GAP-002
          requirement_ref: ER-004
          description: HR callback fallback path pending ASSUMP-001 confirmation
          owner: integration-team
          resolution_by: sprint-2
```

## ex-002 · S2 alternatives with weighted scores — minimal example

```yaml
sections:
  S2_alternatives_considered:
    - alternative_id: ALT-001
      name: "Modular monolith — keep approval in same service"
      pros: ["zero distributed system risk", "simple rollback", "fast to deliver"]
      cons: ["cannot scale approval independently", "tight coupling grows over time"]
      scores:
        performance: 7
        cost: 9
        complexity: 9
        maintainability: 5
        time_to_market: 9
        risk: 9
      total_weighted_score: 8.0
      recommendation: acceptable
      rejection_reason: ""

    - alternative_id: ALT-002
      name: "Extract approval as separate service now"
      pros: ["independent scaling", "clean domain boundary"]
      cons: ["distributed transaction risk", "on-call complexity doubles", "saga needed"]
      scores:
        performance: 8
        cost: 5
        complexity: 4
        maintainability: 8
        time_to_market: 5
        risk: 5
      total_weighted_score: 5.8
      recommendation: rejected
      rejection_reason: "Team size (6) cannot sustain two on-call rotations; boundary defect BRISK-001 not resolved"

    - alternative_id: ALT-003
      name: "Strangler fig — gradual extraction with feature flag"
      pros: ["reversible", "incremental risk", "satisfies 8-week constraint"]
      cons: ["dual-write complexity during transition", "temporary tech debt"]
      scores:
        performance: 8
        cost: 7
        complexity: 6
        maintainability: 7
        time_to_market: 8
        risk: 7
      total_weighted_score: 7.2
      recommendation: recommended
```

## ex-003 · blocked — P0 requirement not covered after 3 iterations

```yaml
solution_id: SOL-BLOCKED-001
readiness: blocked
blocker_mapping: B-N130-02
route_back_to: technical-solution-analysis

blockers:
  - blocker_id: BLK-SOL-001
    type: p0_gap
    description: "ER-001 (dual-approval capability) has coverage_status: not_covered after 3 draft iterations — no architecture candidate satisfies the SoD constraint with the current team structure"
    coverage_status: not_covered
    requirement_ref: ER-001
    priority: P0
    gap_reason: "All three alternatives (ALT-001, ALT-002, ALT-003) require a dedicated approval service which violates C6_human_resource constraint (team of 4 cannot maintain additional service)"
    resolution_required: "Either relax C6 constraint (hire/grow team) or relax ER-001 (accept single-level approval for MVP)"
    unblock_evidence: "Product owner decision on constraint priority: team constraint vs capability requirement"

sections:
  S2_alternatives_considered:
    - alternative_id: ALT-001
      name: "Dedicated approval microservice"
      recommendation: rejected
      rejection_reason: "Violates C6_human_resource — team of 4 cannot sustain dedicated on-call rotation"
    - alternative_id: ALT-002
      name: "Approval embedded in order service"
      recommendation: rejected
      rejection_reason: "SoD violation — same service creates AND approves; ER-001 explicitly requires separation"
    - alternative_id: ALT-003
      name: "Approval via async event + policy engine"
      recommendation: rejected
      rejection_reason: "Complexity exceeds team capability; introduces OPA dependency"

feedback_signal_to_n005:
  signal_type: constraint_conflict
  summary: "C6 team constraint and ER-001 dual-approval requirement are mutually exclusive at current team size. Product owner must prioritize."
```
