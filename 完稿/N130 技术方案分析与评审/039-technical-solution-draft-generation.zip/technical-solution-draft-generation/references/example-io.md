# example io

## example input packet
- output from `technical-solution-analysis`
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`
- optional permissions, objects, or acceptance material

## canonical output shape
1. artifact contract header
2. `solution_id`, `version`, `status`
3. `sections.S1_summary`
4. `sections.S2_alternatives_considered`
5. `sections.S3_proposed_architecture`
6. `sections.S4_interface_contracts`
7. `sections.S5_requirement_coverage_matrix`
8. `sections.S6_non_functional_design`
9. `sections.S7_deployment_topology`
10. `sections.S8_migration_and_rollout`
11. `derived_from`
12. `decision_refs`
13. unresolved items, node self-check summary, and downstream handoff

## strongest downstream carry-forward items
- `selected_candidate`
- `rejected_candidates`
- `requirement_coverage_matrix`
- `interface_contracts_summary`
- `deployment_decisions`
- `decision_refs`

## downgrade example · direction agreed, interface details missing

Scenario: the user already picked a direction (for example "extract order service + saga"), but the interface intent file is thin and N150 owner has not finalized endpoints.

Expected behaviour:

- set `readiness: provisional` and `artifact_nature: draft_only`
- `sections.S2_alternatives_considered` still lists at least three options; the rejected ones re-use the reasoning surfaced in the analysis artifact rather than being re-invented
- `sections.S3_proposed_architecture.components[]` is complete enough to name each component and its responsibility, even when `technology` is `TBD`
- `sections.S4_interface_contracts`:
  - `api_contracts[]` may list the APIs with `method`, `path`, and a placeholder `request: { fields: TBD }` / `response_200: { fields: TBD }` body
  - unresolved request / response shapes show up as `contract_ref` pointers to unresolved items, never as silent gaps
  - `event_contracts[]` and `db_schema_contracts[]` still exist; if they truly have no content, emit the empty arrays explicitly
- `sections.S6_non_functional_design` keeps all eight subsections; any subsection without data writes `status: to_confirm` rather than vanishing
- `sections.S7_deployment_topology` uses placeholders (`replicas: TBD`) plus a `decision_variable` note so downstream work knows what to fill in
- `sections.S8_migration_and_rollout.migration_phases[]` names every phase with a rollback point even when durations are still estimates
- every rule in `contract-consistency-check.md` still runs; any failure becomes a blocker listed in unresolved items
