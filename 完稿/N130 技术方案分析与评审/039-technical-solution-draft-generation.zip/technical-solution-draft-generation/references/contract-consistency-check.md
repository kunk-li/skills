# contract consistency check

Use this reference when producing a `technical-solution-draft-generation` artifact that must be consumed by downstream nodes without rework.

The goal is to make cross-reference consistency **machine-checkable** rather than relying on reviewer memory.

## why this file exists

`SKILL.md` `§5 inline contract discipline` and `§6 coverage discipline` both require references to stay consistent.
This file collects every consistency rule in one place so the self-check and downstream consumption can be deterministic.

## rule set

### R1 · component to contract reference
Every `sections.S3_proposed_architecture.components[].interactions[].contract_ref` must point to a contract that exists in `sections.S4_interface_contracts`.

- valid targets include an `api_contracts[].api_id`, `event_contracts[].event_name`, or `db_schema_contracts[].table`
- unresolved `contract_ref` values must be listed under unresolved items, not silently dropped

### R2 · API contract to API intent
When `接口意图清单.csv` or equivalent API intent material is available, each `sections.S4_interface_contracts.api_contracts[]` must:

- be traceable to at least one `api_intent_ref` in `derived_from.api_intent_refs`
- keep method and path aligned with the upstream intent when the intent is specific
- call out any divergence in the `rationale` of the owning decision

### R3 · event publisher to component
Every `sections.S4_interface_contracts.event_contracts[].publisher` must appear as a `components[].name` in `sections.S3_proposed_architecture`.

Every listed subscriber must either:
- appear as another component in `S3`, or
- be clearly labelled as an external system in the event contract

### R4 · coverage matrix to contracts and components
For every row in `sections.S5_requirement_coverage_matrix`:

- `covered_by_components` must list only components defined in `S3`
- `covered_by_apis` must list only APIs defined in `S4.api_contracts`
- `covered_by_events` must list only events defined in `S4.event_contracts`
- a row with `coverage_status = fully_covered` must provide non-empty coverage arrays

### R5 · P0 coverage gate
`sections.S5_requirement_coverage_matrix.completeness_check.gate.p0_coverage_must_be_100_percent` is `true` by default.

- if any `P0` requirement has `coverage_status != fully_covered`, the artifact must be marked `readiness: constrained` or `blocked`
- downstream consumption continues in provisional mode only when every P0 gap is explicitly listed in unresolved items

### R6 · NFR to FMEA carry-forward
`sections.S6_non_functional_design.availability.failure_modes_addressed` should reference upstream FMEA ids (`FMEA-\\d+`) whenever the analysis artifact is available.

Unreferenced critical FMEA items should surface as unresolved items or blockers, not disappear from the draft.

### R7 · migration phase to rollback
Every `sections.S8_migration_and_rollout.migration_phases[]` must either:
- include `rollback_point: true` with a concrete mechanism, or
- include `rollback_point: false` with a written rationale in the phase notes

### R8 · decision_refs stability
`decision_refs` at the artifact root and any `decision_refs` embedded in alternatives or flows must share the same id space.
Do not introduce ad hoc decision ids that are not listed in the top-level `decision_refs` list.

### R9 · defect item survival
Every item in the upstream `defect_items_to_carry_forward` must appear in exactly one of:
- a rejected alternative reason
- a constraint added to the draft
- an NFR subsection (`security`, `compliance`, `operability`, etc.)
- an unresolved item

Do not bury defect-driven risks in prose.

### R10 · cross-skill field stability
When the draft is used as input to `solution-review-question-generation` or any N140/N150/N160/N170/N180 consumer, preserve the canonical field names.
Supplemental analyst-friendly headings may be appended; they must never replace canonical ids such as `S4_interface_contracts` or `coverage_status`.

## how to use this file
1. during drafting, surface any broken reference early rather than at the end
2. in `self-check before finishing`, run every rule above and mark failures as blockers, not warnings
3. when routing back via `route_back_to = draft`, start the next iteration by re-running this file against the updated draft
4. when merging the three N130 artifacts into a single package document, keep this file as the consistency reference; do not embed contract checks inside prose
