# Delivery checklist — technical-solution-draft-generation

## A. structure completeness
- [ ] All eight section IDs present and exact: `S1_summary`, `S2_alternatives_considered`, `S3_proposed_architecture`, `S4_interface_contracts`, `S5_requirement_coverage_matrix`, `S6_non_functional_design`, `S7_deployment_topology`, `S8_migration_and_rollout`
- [ ] No section renamed or merged with another

## B. alternatives (S2)
- [ ] At least three alternatives when problem space is non-trivial
- [ ] Each alternative has `pros[]`, `cons[]`, scores across 6 dimensions, `recommendation`, and `rejection_reason` when rejected
- [ ] Hard-constraint eliminations are stated explicitly

## C. interface contracts (S4)
- [ ] `api_contracts[]`, `event_contracts[]`, and `db_schema_contracts[]` all present (may be empty arrays, not omitted)
- [ ] Draft contracts are specific enough to feed N150 and N160 without starting from zero
- [ ] All draft contracts marked as `artifact_nature: draft_only`; never presented as final

## D. requirement coverage (S5)
- [ ] Every in-scope requirement has a row with `priority`, `covered_by_*`, `coverage_status`, `gap_if_not_fully`
- [ ] P0 requirements are all `fully_covered` or flagged as explicit blockers
- [ ] `completeness_check.p0_gate` is present

## E. non-functional design (S6)
- [ ] All eight subsections present together: `performance`, `scalability`, `availability`, `security`, `compliance`, `concurrency`, `observability`, `operability`
- [ ] No NFR content scattered across other sections
- [ ] Any subsection without data writes `status: to_confirm` rather than vanishing

## F. topology and rollout (S7/S8)
- [ ] `S7_deployment_topology` exists with node counts or decision variables
- [ ] `S8_migration_and_rollout` has phases each with a rollback point

## G. defect handling
- [ ] Every item from `需求漏洞清单.csv` (if present) mapped to coverage gap, alternative rejection, or open question

## H. v2 contract
- [ ] `artifact_schema_version`, `produced_event: produced.n130.technical_solution_draft.v2`, `blocker_mapping: B-N130-02`
- [ ] `rule_results[]` covers R1-R10
- [ ] `feedback_signal_to_n005` populated
- [ ] `decision_refs[]` visible when decisions were made

## One-vote rejection items
- [ ] Any S1-S8 section missing
- [ ] Fewer than three alternatives without justified shortfall
- [ ] P0 requirement not covered and not flagged as blocker
- [ ] Provisional contracts presented as final
