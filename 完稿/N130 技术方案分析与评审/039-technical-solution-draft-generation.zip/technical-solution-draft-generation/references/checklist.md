# checklist

Run this check before finishing.

## universal
- use only traceable facts from user-provided material
- separate confirmed, inferred, and pending content
- include the shared v2 artifact contract header
- include the node self-check summary
- keep the output reusable as a standalone artifact
- keep the output inside technical solution design boundaries

## draft-specific
- `S1` to `S8` all exist
- `S2` has at least three alternatives or a justified shortfall
- `S4` inlines API, event, and DB contracts
- `S5` includes requirement refs, coverage status, and visible P0 gate handling
- `S6` keeps all eight non-functional subsections together
- `S7` and `S8` both exist and expose rollback thinking
- `decision_refs` are visible when known
- requirement defects were absorbed into sections or unresolved items
- downstream handoff exists
- downgrade state, if any, follows `references/downgrade-templates.md`
