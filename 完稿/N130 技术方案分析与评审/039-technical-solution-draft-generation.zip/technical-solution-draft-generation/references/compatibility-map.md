# Compatibility map — technical-solution-draft-generation v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 038 technical-solution-analysis | `recommended_candidate, constraint_taxonomy_summary, fmea_analysis[]` | `S1-S8 content` | analysis feeds all eight draft sections |
| 036 engineering-requirement-parsing | `er_id, requirement_statement` | `S5_requirement_coverage_matrix` | ER IDs traced in coverage matrix rows |
| 037 api-intent-extraction | `intent_id, intent_key, api_style` | `S4_interface_contracts.api_contracts[]` | intent inventory seeds draft API contracts |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 040 solution-review-question-generation | `S4 contracts, S5 coverage gaps, S6 NFR` | `question sources` | review questions derived from each section |
| 041 module-boundary-identification | `S3_proposed_architecture.components[]` | `module candidate extraction` | architecture components → module boundary candidates |
| 043 api-design-recommendation | `S4_interface_contracts (draft)` | `design baseline` | draft contracts feed N150 detailed design |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
