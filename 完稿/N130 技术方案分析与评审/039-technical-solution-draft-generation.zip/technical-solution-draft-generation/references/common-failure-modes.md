# Common failure modes

## F1: S1-S8 sections missing or renamed
Symptom: sections use free-form headings like "Architecture Overview" instead of `S3_proposed_architecture`.
Fix: canonical IDs must be exact; display titles may be bilingual but IDs cannot vary.

## F2: fewer than three alternatives in S2
Symptom: only one or two options are listed, often the chosen one plus a brief "we considered X".
Fix: include at least three alternatives; if hard constraints eliminate options before three are found, document the elimination with rationale.

## F3: S4 placeholders instead of contracts
Symptom: S4 says "API contract TBD" or "DB schema to be designed in N160".
Fix: S4 must include draft-level inline API, event, and DB contracts — specific enough to feed N150 and N160 without starting from zero. Use `status: draft` markers, not silence.

## F4: P0 requirements invisible in S5
Symptom: the coverage matrix exists but P0 requirements are buried or missing.
Fix: P0 requirements must appear in S5 with explicit coverage status. Uncovered P0 → blocker.

## F5: S6 NFR scattered
Symptom: performance appears in S3, security appears in S4, observability is missing entirely.
Fix: all eight NFR subsections (performance, scalability, availability, security, compliance, concurrency, observability, operability) must be together in S6.

## F6: S8 has no rollback points
Symptom: migration phases are named but none state "if this fails, roll back by doing X".
Fix: every migration phase needs a rollback point, even if it's "feature flag back to old code path".

## F7: provisional APIs presented as final
Symptom: S4 draft contracts look the same as confirmed contracts; no `artifact_nature: draft_only` marker.
Fix: always set `artifact_nature: draft_only` when N150/N160 will refine the contracts further.

## F8: decision_refs missing
Symptom: the recommendation references "the team agreed" or "per earlier discussion" with no stable ID.
Fix: every decision should have a `decision_ref` that downstream work can cite and trace.
