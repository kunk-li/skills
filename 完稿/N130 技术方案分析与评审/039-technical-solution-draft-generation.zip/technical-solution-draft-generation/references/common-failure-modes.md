# common failure modes

Consider these patterns when analyzing, drafting, or reviewing designs:
- dependency unavailable
- latency spike or timeout chain
- stale cache or cache stampede
- duplicate event or replay
- out-of-order event delivery
- partial write or partial commit
- queue growth without bound
- cron drift or clock skew
- configuration rollout mismatch
- observability blind spot during incident
