# exact contract

Use this file whenever you need the exact `N130_Skills_v2.md` draft contract instead of a generalized design outline.

## canonical output root
Emit a solution artifact that contains:
- `solution_id`
- `version`
- `status`
- `sections`
- `derived_from`
- `decision_refs`

You may add short explanatory prose, but do not rename or omit the canonical blocks.

## `sections.S1_summary`
Include:
- `problem_statement`
- `proposed_solution`
- `key_design_decisions[]` with `decision` and `rationale`
- `expected_outcomes`

## `sections.S2_alternatives_considered`
At least three items when the decision space is non-trivial.
Each item should include:
- `alternative_id` matching `ALT-\d+`
- `name`
- `description`
- `pros[]`
- `cons[]`
- `scores.performance`
- `scores.cost`
- `scores.complexity`
- `scores.maintainability`
- `scores.time_to_market`
- `scores.risk`
- `total_weighted_score`
- `recommendation`: `recommended`, `acceptable`, or `rejected`
- `rejection_reason` when rejected

## `sections.S3_proposed_architecture`
Include:
- `components[]`
- `deployment_topology`

Each component should include:
- `component_id` matching `COMP-\d+`
- `name`
- `responsibility`
- `technology`
- `interactions[]`

Each interaction should include:
- `with`
- `via`: `sync_api`, `async_event`, `shared_db`, or `shared_cache`
- `contract_ref`

## `sections.S4_interface_contracts`
Include all three canonical lists:
- `api_contracts[]`
- `event_contracts[]`
- `db_schema_contracts[]`

API contracts should carry method, path, request, response_200, and response_errors.
Event contracts should carry event name, schema draft, publisher, and subscribers.
DB schema contracts should carry table, key columns, and key indexes.

## `sections.S5_requirement_coverage_matrix`
Each row should include:
- `requirement_ref`
- `priority`: `P0`, `P1`, `P2`, or `P3`
- `covered_by_components`
- `covered_by_apis`
- `covered_by_events`
- `coverage_status`: `fully_covered`, `partially_covered`, or `not_covered`
- `gap_if_not_fully`

Also include `completeness_check` with:
- `total_requirements`
- `fully_covered`
- `partially_covered`
- `not_covered`
- `coverage_rate`
- `gate.p0_coverage_must_be_100_percent`

## `sections.S6_non_functional_design`
Keep the exact eight subsections:
- `performance`
- `scalability`
- `availability`
- `security`
- `compliance`
- `concurrency`
- `observability`
- `operability`

Each subsection should include the exact fields described in `N130_Skills_v2.md` whenever they are relevant.

## `sections.S7_deployment_topology`
Include:
- `environments[]`
- `ci_cd`
- `monitoring_setup`

## `sections.S8_migration_and_rollout`
Include:
- `migration_phases[]`
- `data_migration`
- `rollout_plan`

Each migration phase should include:
- `phase`
- `duration`
- `activities`
- `rollback_point`

## `derived_from`
Include:
- `analysis_ref`
- `er_refs`
- `api_intent_refs`

## `decision_refs`
Each row should include:
- `decision_id`
- `category`: `BLK`, `MAJ`, `MIN`, or `PM_override`
- `rationale`

## exactness rules
- `S1` to `S8` must all exist, even if some sections are brief
- keep exact ids such as `S4_interface_contracts` and `coverage_status`
- do not replace canonical sections with generalized headings
- you may append explanatory notes after the canonical structure, never instead of it
