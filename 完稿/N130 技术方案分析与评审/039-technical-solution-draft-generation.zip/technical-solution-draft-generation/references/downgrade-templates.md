# downgrade templates

Use this reference when inputs are incomplete or contract checks cannot fully pass. The skill should remain usable instead of silently inventing missing facts.

## readiness states

### blocked
Use when a hard requirement is missing and continuing would create misleading output.

Required output pattern:
- `readiness: blocked`
- `blocking_reason`: what cannot be verified or generated
- `minimum_input_needed`: smallest concrete input set needed to continue
- `safe_partial_output`: only facts, risks, or questions that remain valid
- `route_back_to`: upstream step or `user_input`

### constrained
Use when the artifact can be produced, but one or more sections are materially limited.

Required output pattern:
- `readiness: constrained`
- `constraints_on_output`: which sections are limited
- `confirmed`: facts directly supported by input
- `inferred`: clearly labeled assumptions
- `pending`: questions or inputs still needed
- `downstream_warning`: what downstream consumers must not treat as final

### provisional
Use when the skill can produce a useful first pass with sparse input.

Required output pattern:
- `readiness: provisional`
- `confidence`: high / medium / low
- `assumption_register`: assumptions made to keep progress
- `verification_needed`: checks before promotion to constrained or ready
- `next_best_action`: one concrete follow-up action

## promotion rule
A provisional artifact can become constrained or ready only after pending items are answered or explicitly accepted by the user. A constrained artifact can become ready only after each downstream warning is resolved or intentionally waived.
