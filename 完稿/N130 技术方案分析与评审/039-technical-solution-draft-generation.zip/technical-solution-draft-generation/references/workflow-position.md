# Workflow position

## Node: N130
## Step order: 2_of_3

## Upstream inputs (feeds this skill)
- 038

## Downstream consumers (this skill feeds)
- 040
- N140/041
- N150/043
- N160/046

## When to use standalone vs in-workflow
- **Standalone**: when no structured upstream artifacts exist; start from raw requirements or PRD; output will be `readiness: provisional`.
- **In-workflow**: when upstream artifacts are available; inherit IDs and fields; output can reach `readiness: ready`.

## Minimum required inputs for `readiness: ready`
See `references/v2-contract.md` (N170 group) or `references/exact-contract.md` (N130/N140 group) for the typed input schema.
