# scoring rubric

Score from 1 to 5.

## 1 unusable
The output is mostly summary, misses canonical fields, or hides uncertainty.

## 2 weak
The output has some useful content but still misses major required sections or exact enum discipline.

## 3 usable
The output supports a real team discussion or planning step, though some gaps remain.

## 4 strong
The output is decision-ready, traceable, contract-stable, and reusable by downstream work.

## 5 exemplary
The output is highly reusable, preserves canonical contract fields, works both standalone and in-chain, and supports route-back with minimal rework.
