# v2 alignment

This trio must work both as standalone skills and as the canonical `N130` in-node chain.

## node role
- node: `N130`
- node name: `technical solution analysis and review`
- default chain: `technical-solution-analysis` -> `technical-solution-draft-generation` -> `solution-review-question-generation`
- node outputs: `技术方案分析.md`, `技术方案初稿.md`, `方案评审问题清单.csv`
- re-review supported: `true`
- adjacent downstream nodes: `N140`, `N150`, `N160`, `N170`, `N180`, `N330`

## source packet discipline
Prefer these inputs when present:
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`
- upstream outputs from the other two N130 skills
- user-provided requirement, constraint, acceptance, or review material

Treat only traceable user-provided material as confirmed facts.
Do not convert private memory, unstated team history, or assumed platform reality into confirmed content.

## shared artifact contract header
Start every output with a compact contract header containing:
- `artifact_id`
- `artifact_type`
- `schema_version: n130.v2`
- `node_id: N130`
- `step_order`
- `skill_name`
- `readiness`: `pass`, `constrained`, `blocked`, or `provisional`
- `contract_status`: `draft`, `review_ready`, or `blocked`
- `confidence_summary` for `confirmed`, `inferred`, and `pending`
- `source_artifacts`
- `upstream_dependencies`
- `downstream_targets`
- `route_back_to`: `none`, `analysis`, or `draft`

## shared registry discipline
Keep these concepts stable across the trio:
- `decision_refs`
- `requirement_coverage_matrix`
- `defect_items_to_carry_forward`
- `assumptions_to_verify`
- `route_back_to`
- `adjacent_nodes_to_notify`

If a downstream skill needs to reinterpret an upstream field, preserve the canonical field first and add a supplemental explanation rather than renaming the field.

## route-back rules
- use `route_back_to = analysis` when assumptions, constraints, option set, or defect interpretation are wrong
- use `route_back_to = draft` when the chosen direction stands but design detail is weak, incomplete, or inconsistent
- use `route_back_to = none` when downstream work can continue without returning

## progressive gate behavior
- `pass`: strong enough to feed downstream work directly
- `constrained`: usable, but one or more sections need attention
- `provisional`: continue with explicit uncertainty and placeholders
- `blocked`: emit only confirmed content, blockers, minimum next steps, and the node self-check summary

## combination principle
Each skill must be useful alone.
The trio must be stronger together because:
- analysis defines constraints, trade-offs, assumptions, and failure modes
- draft turns the direction into canonical sections and inline contracts
- review stress-tests the pack and decides whether to continue or route back

Do not collapse the three roles into one blended artifact unless the user explicitly asks for a merged N130 package.
