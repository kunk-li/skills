---
name: technical-solution-draft-generation
description: generate structured solution drafts with s1-s8 sections, inline contracts, coverage matrix, and nfr subsections. triggers on 技术方案分析.md.
---
# technical-solution-draft-generation

Produce a structured technical solution draft, not final code, final API specs, or final schema design.

Use the shared contract rules in `references/v2-alignment.md`, the chain rules in `references/orchestration.md`, the exact field obligations in `references/exact-contract.md`, and the cross-reference rules in `references/contract-consistency-check.md`, and the degradation patterns in `references/downgrade-templates.md`.



## S6 NFR subsection quick-reference
All eight must appear together in `S6_non_functional_design`. Never scatter across other sections.

| Subsection | Minimum content | Common gap |
|---|---|---|
| `performance` | SLO target (latency_p99, throughput), hotspot identification | missing floor / degradation trigger |
| `scalability` | horizontal/vertical strategy, sharding decision point | no trigger threshold stated |
| `availability` | SLA target, multi-AZ or redundancy, chaos test reference | no RTO/RPO defined |
| `security` | auth mechanism, encryption (at-rest, in-transit), threat model ref | delegated to 054 but not referenced |
| `compliance` | applicable regulations, data residency, audit requirements | regulation applicability not stated |
| `concurrency` | conflict strategy, lock scope, isolation level ref | delegated to 049 but not referenced |
| `observability` | key metrics, alert thresholds, tracing coverage | no alertable SLO defined |
| `operability` | runbook reference, deployment rollback procedure, on-call scope | no runbook or escalation path |

## Section cheat sheet
| Section ID | Must contain | Common gap |
|---|---|---|
| `S1_summary` | recommendation + rationale | missing "why not alternatives" |
| `S2_alternatives_considered` | ≥3 options or justified shortfall | only 1 option listed |
| `S3_proposed_architecture` | module map, flow, component diagram | vague prose only |
| `S4_interface_contracts` | inline API + event + DB drafts | placeholders without structure |
| `S5_requirement_coverage_matrix` | req → component/API/event mapping | P0 requirements not traced |
| `S6_non_functional_design` | all 8 subsections together | NFR scattered across sections |
| `S7_deployment_topology` | node count or variable, network, infra | skipped entirely |
| `S8_migration_and_rollout` | phases + rollback points | no rollback defined |

## Standalone downgrade quick-reference
| Available evidence | Max readiness | artifact_nature |
|---|---|---|
| Full N130 analysis output | ready | draft_only → final after review |
| Partial analysis / PRD only | provisional | draft_only (mandatory) |
| No upstream structure | provisional | draft_only with explicit gaps |
| Missing P0 requirement coverage | blocked | blocked |


## Trigger conditions
Use when a direction has been chosen (or provisionally selected) and a structured solution draft is needed. Strong triggers:
- output from `technical-solution-analysis` (038)
- `技术方案分析.md`
- explicit "write/draft the solution" or "generate technical design" requests
- user provides a chosen architecture direction and needs it documented

## Standalone rule
Works without 038 output. When upstream analysis is absent:
- Set `readiness: provisional` and `artifact_nature: draft_only`
- Still emit all S1-S8 sections; use `status: to_confirm` for missing data
- Mark inline contracts as `draft` with TBD placeholders rather than omitting them
- P0 coverage must be visible; partial coverage is flagged as a blocker

## role and boundary
This skill is the preferred **step 2 of 3** inside `N130 technical solution analysis and review`.

Stay inside the design-draft boundary:
- turn a chosen or provisional direction into a reusable solution draft
- expose module boundaries, flows, inline contracts, topology, migration, and rollout shape
- support downstream `N140`, `N150`, `N160`, `N170`, `N180`, and `N330`
- do not replace final `N150` API design, final `N160` schema design, code generation, testing, or release execution

## choose one operating mode
Choose exactly one mode and state it near the top.
Use the canonical mode names first.
- `fast_draft`: fastest useful draft; still keep canonical section ids
- `adr_formal`: formal decision-oriented draft that reads cleanly as an ADR-ready package
- `comparison_focused`: emphasize alternative comparison and recommendation strength while still emitting the canonical skeleton

Note: the mode `fast_draft` controls drafting speed and depth.
It is separate from the field `artifact_nature` in §2, which marks whether the whole artifact is `draft_only` or `final` for downstream consumption.
An `adr_formal` artifact can still carry `artifact_nature: draft_only`, and a `fast_draft` artifact can still be escalated to `artifact_nature: final`.

If inputs are partial, continue in `provisional` readiness and mark inferred sections clearly.
When draft inputs are incomplete, apply `references/downgrade-templates.md`; never let provisional interface, schema, or topology details look final.

## preferred inputs
Treat only user-provided material and traceable upstream outputs as facts.

Strong inputs when present:
- output from `technical-solution-analysis`
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`
- permissions, objects, acceptance, or design notes supplied by the user

Also accept requirement docs, PRDs, prior architecture notes, and review feedback.

Do not invent current implementation details or platform facts that were never provided.

## primary job
Turn the chosen or provisional direction into a reusable design draft that covers:
1. why one option is recommended
2. how requirements map into modules and contracts
3. how architecture, data, and interfaces fit together
4. how non-functional design is aggregated instead of scattered
5. how deployment, migration, and rollout should proceed
6. what remains unresolved for review or downstream specialization

## mandatory output structure
Use Markdown. Prefer tables and compact lists.
You may add a short executive summary, but do not replace or rename the canonical section ids below.

### 1. artifact contract header
Start with the shared contract header from `references/v2-alignment.md`.
Set:
- `artifact_type: technical_solution_draft`
- `step_order: 2_of_3` or `standalone`
- `skill_name: technical-solution-draft-generation`

### 2. solution identity
Emit:
- `solution_id` using `SOL-xxx` or a similarly stable id
- `version`
- `status`: `draft`, `under_review`, `approved`, or `obsolete`
- `artifact_nature: draft_only` by default, to make clear that S3 topology and S4 interface contracts are drafts for downstream N140 / N150 / N160 / N170 consumption, not final deliverables
- optional `draft_mode`

Only flip `artifact_nature` to `final` when the user explicitly treats this skill as the final deliverable and downstream N150 / N160 will not refine it further.

### 3. canonical `sections`
Always emit the eight fixed section ids exactly as named below.
Display titles may be bilingual, but the ids must stay exact.

- `S1_summary`
- `S2_alternatives_considered`
- `S3_proposed_architecture`
- `S4_interface_contracts`
- `S5_requirement_coverage_matrix`
- `S6_non_functional_design`
- `S7_deployment_topology`
- `S8_migration_and_rollout`

For exact required fields, follow `references/exact-contract.md`, and the degradation patterns in `references/downgrade-templates.md`.
Do not replace these ids with generalized headings such as “architecture”, “interfaces”, or “nfr”.

### 4. alternatives discipline
`S2_alternatives_considered` must include at least three alternatives when the problem is non-trivial.
Use a minimal, ideal, and balanced option when no better framing exists.
If fewer than three are viable because of hard constraints, say so explicitly and still list rejected near-options.

### 5. inline contract discipline
`S4_interface_contracts` must inline draft:
- API contracts
- event contracts
- DB schema contracts

Do not replace inline contract content with only links or vague placeholders.
Draft detail should be specific enough to feed `N150` and `N160`, while still marked as draft-level.

### 6. coverage discipline
`S5_requirement_coverage_matrix` must visibly map requirement refs to components, APIs, and events.
Keep `requirement_coverage_matrix` stable enough that downstream work can reuse it.
All `P0` requirements must be shown as fully covered or explicitly flagged as a blocker.

### 7. non-functional aggregation discipline
`S6_non_functional_design` must keep these exact subsections together:
- `performance`
- `scalability`
- `availability`
- `security`
- `compliance`
- `concurrency`
- `observability`
- `operability`

Do not scatter them across other sections.

### 8. topology and rollout discipline
`S7_deployment_topology` and `S8_migration_and_rollout` must both exist.
If exact infrastructure counts are unknown, use clear placeholders and decision variables rather than omitting the fields.
Every migration phase should have a rollback point.

### 9. derived_from and decision_refs
Emit:
- `derived_from.analysis_ref`
- `derived_from.er_refs`
- `derived_from.api_intent_refs`
- `decision_refs[]`

Keep `decision_refs` stable for downstream consumers.

### 10. unresolved items and node self-check
After the canonical solution sections, include:
- unresolved functional, contract, topology, or migration questions
- the shared node self-check summary
- a compact downstream handoff block that highlights selected candidate, rejected candidates, key trade-offs, `requirement_coverage_matrix`, `decision_refs`, and `adjacent_nodes_to_notify`

## defect and gap handling
If `需求漏洞清单.csv` or equivalent defect material is present, map each relevant issue into one or more of:
- alternative rejection logic
- requirement coverage gaps
- non-functional design risks
- migration or rollout cautions
- unresolved items for review

Do not leave defect inputs unconsumed.

## output rules
- keep confirmed, inferred, and pending content visibly distinct
- keep candidate options visible even when the preferred option seems obvious
- preserve the upstream analysis recommendation unless a concrete draft-level conflict appears
- make module boundaries and inline contracts explicit enough that downstream work does not start from zero
- keep canonical ids and enums stable for downstream parsing

## gate-aware downgrade
Use `references/downgrade-templates.md` as the source of truth for downgrade behavior.
- `blocked`: emit the artifact contract header, confirmed scope, blockers, minimum next steps, `route_back_to`, and node self-check summary only.
- `constrained`: emit all canonical `S1` to `S8` sections, but mark weak alternatives, coverage rows, contracts, topology, and rollout details as constrained.
- `provisional`: emit the canonical structure with draft placeholders clearly labeled; do not present provisional APIs, schema, or topology as final.

Never hide missing downstream-critical evidence inside polished prose.

## self-check before finishing
Verify all of the following:
- all `S1` to `S8` sections exist
- at least three alternatives exist or the shortfall is justified
- `S4` includes inline API, event, and DB contracts
- `S5` visibly maps requirements and preserves P0 visibility
- `S6` keeps all eight non-functional subsections together
- `S7` and `S8` both exist
- `decision_refs` are visible when known
- defect items were consumed
- node self-check exists
- every rule in `references/contract-consistency-check.md` (R1 to R10) passes or its failure is explicitly listed as a blocker
- `rule_results[]` populated with pass | warn | reject | not_applicable for R1-R10
- `blocker_id: B-N130-02` declared when readiness is blocked or constrained
- `feedback_signal_to_n005` field populated

## v2 artifact contract additions

```yaml
artifact_schema_version: n130.v2.1.0
skill_name: technical-solution-draft-generation
produced_event: produced.n130.technical_solution_draft.v2
blocker_mapping: B-N130-02
blocker_id: B-N130-02
rule_results:
  - rule_id: R1_s1_to_s8_sections_exist
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R2_three_alternatives_or_justified
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R3_s4_inline_contracts
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R4_coverage_matrix_present
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R5_nfr_subsections_complete
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R6_s7_s8_both_exist
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R7_defect_items_consumed
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R8_node_self_check_present
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R9_no_provisional_as_final
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R10_decision_refs_visible
    severity: warn
    result: pass | warn | reject | not_applicable
feedback_signal_to_n005:
  signal_type: none | gap_detected | design_pattern_signal
  summary: ""
  target_n070_skills:
  - 014-business-rule-extraction
  - 017-data-object-identification
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop

## Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| `业务规则清单.md` (014) | condition_expr, hardness | S4 inline rule contracts, S6 compliance section |
| `状态转移图.md` (015) | transitions, invariants | S4 state topology, S7 migration steps |
| `权限矩阵.md` (016) | subject, grain, evaluation_algo | S4 auth contracts, S6 security subsection |
| `数据对象目录.md` (017) | ddd_role, storage, constraint_tags | S4 DB contracts, S6 data retention |
| `需求交接包.zip` (031) | open_questions, risks | S8 open items |

## route_back_to and eventbus (v2 additions)

```yaml
route_back_to: none | analysis | draft
route_back_to: none | analysis | draft
# none    — downstream may proceed
# analysis — return to 038 when solution direction needs full re-analysis
# draft   — return to 039 itself when sections S1-S8 are structurally incomplete
eventbus_subscribers: [N330]
# N330 subscribes to auto-generate 技术方案初稿文档
```
