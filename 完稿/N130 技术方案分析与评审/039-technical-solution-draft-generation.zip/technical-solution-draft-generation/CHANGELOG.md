<!-- skill_version: 2.0.4 -->
# Changelog · technical-solution-draft-generation

All notable changes to this skill will be recorded here.
Follow `MAJOR.MINOR.PATCH` — break canonical schema only on MAJOR bumps.

## how to read this file

- **schema-breaking**: canonical section id, enum, or required field changed in a way downstream consumers must adapt to
- **schema-additive**: new optional field or new enum value; existing consumers keep working
- **non-schema**: wording, docs, examples, internal rules

## [2.0.4] - 2026-04-24

### added · non-schema
- machine-readable CHANGELOG marker `<!-- skill_version: 2.0.4 -->` for tools that need the skill version without adding non-standard SKILL.md frontmatter fields.

### changed · non-schema
- corrected the v2.0.3 changelog wording to say `total_weighted_score` was confirmed as the canonical term, not newly normalized in that patch.
- rewrote gate-aware downgrade guidance to delegate to `references/downgrade-templates.md` as the source of truth for `blocked`, `constrained`, and `provisional` outputs.

## [2.0.3] - 2026-04-24

### changed · non-schema
- removed `version` from `SKILL.md` frontmatter so the entrypoint uses only deployment-safe `name` and `description`; semantic version history now lives in this CHANGELOG
- confirmed existing alternatives terminology `total_weighted_score` as the canonical term in the exact contract (no schema change)

### added · non-schema
- `references/downgrade-templates.md` with separate `blocked`, `constrained`, and `provisional` output patterns for sparse-input handling

## [2.0.2] - 2026-04-24

### changed · non-schema
- operating mode `draft_only` renamed to `fast_draft` to avoid naming collision with the `artifact_nature: draft_only` field in §2 solution identity
- existing `artifact_nature: draft_only` field is unchanged; only the mode name moved
- downstream consumers that key on `artifact_nature` are unaffected; consumers that key on mode name should switch to `fast_draft`

### added · non-schema
- this CHANGELOG file

## [2.0.1] - 2026-04-23

### added · schema-additive
- `version: 2.0.0` in frontmatter (superseded in 2.0.3; version history now lives in CHANGELOG)
- `sections.artifact_nature` field with default value `draft_only`, flip to `final` only when the user explicitly treats this output as the final deliverable
- `references/contract-consistency-check.md` with machine-checkable rules R1 to R10:
  - R1 component `interactions.contract_ref` must resolve inside `S4_interface_contracts`
  - R2 API contracts should trace to upstream `api_intent_refs` when available
  - R3 every event publisher must exist as an `S3.components[].name`
  - R4 coverage matrix can only reference components, APIs, and events defined in this draft
  - R5 P0 coverage gate stays at 100% — otherwise set `readiness: constrained` or `blocked`
  - R6 `S6.availability.failure_modes_addressed` should link to upstream FMEA ids
  - R7 every migration phase must declare a rollback point (`true` + mechanism, or `false` + written rationale)
  - R8 `decision_refs` share the same id space across the artifact
  - R9 every defect-carry-forward item must survive in a rejected alternative, a constraint, an NFR subsection, or an unresolved item
  - R10 canonical field names are stable; supplemental headings may be appended but never replace canonical ids
- `self-check before finishing` gained a bullet requiring every R1 to R10 rule to pass or be listed as a blocker

### added · non-schema
- `example-io.md` gained a `## downgrade example · direction agreed, interface details missing` section

## [2.0.0] - 2026-04-23 · canonical contract lock

### added · schema-breaking (first canonical lock)
- `references/exact-contract.md` as the machine-readable contract
- canonical section ids `S1_summary` · `S2_alternatives_considered` · `S3_proposed_architecture` · `S4_interface_contracts` · `S5_requirement_coverage_matrix` · `S6_non_functional_design` · `S7_deployment_topology` · `S8_migration_and_rollout`
- canonical NFR subsections `performance` · `scalability` · `availability` · `security` · `compliance` · `concurrency` · `observability` · `operability`
- canonical alternatives scoring with required `total_weighted_score`
- P0 coverage gate (`p0_coverage_must_be_100_percent: true`)

### changed · schema-breaking
- NFR subsection names migrated from earlier `business arch / technical arch / data arch / concurrency / idempotency / security / audit / observability` to the v2 canonical names listed above
- `S4_interface_contracts` is now required to inline API, event, and DB contracts; external links alone are not enough

### added · non-schema
- operating modes: `draft_only` · `adr_formal` · `comparison_focused` (renamed to `fast_draft` in 2.0.2)
- `references/v2-alignment.md` with shared registry discipline

## [1.x] - superseded

pre-contract drafts; not tracked here.
