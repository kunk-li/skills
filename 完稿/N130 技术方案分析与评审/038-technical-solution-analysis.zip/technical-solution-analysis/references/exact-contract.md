# exact contract

Use this file whenever you need the exact `N130_Skills_v2.md` contract instead of a generalized interpretation.

## canonical output root
Emit an analysis artifact that contains:
- `analysis_id` matching `TSA-\d{3,}`
- `scope`
- `constraints_taxonomy`
- `tradeoff_analysis`
- `architecture_three_states`
- `assumptions`
- `fmea_analysis`

You may add short explanatory prose, but do not rename or omit the canonical blocks.

## constraints_taxonomy
### `C1_business`
Each item should carry:
- `constraint_id`
- `description`
- `source`
- `hardness`: `hard` or `soft`
- `rationale`
- `consequence_if_violated`

### `C2_regulatory`
Each item should carry:
- `regulation`: `GDPR`, `PCI-DSS`, `SOX`, `HIPAA`, `SOC2`, or `local`
- `specific_clause`
- `impact_on_design`
- `verification_method`

### `C3_technical`
Each item should carry:
- `constraint`
- `kind`: `language`, `framework`, `db`, `infra`, or `version_compatibility`
- `rationale`
- `workaround_cost`

### `C4_operational`
Each item should carry:
- `constraint`
- `kind`: `sla`, `maintenance_window`, `deployment_frequency`, or `capacity`
- `value`

### `C5_temporal`
Each item should carry:
- `milestone`
- `deadline`
- `flexibility`: `fixed`, `flexible`, or `soft`
- `stakeholder_commitment`

### `C6_human_resource`
Each item should carry:
- `constraint`
- `kind`: `skill_gap`, `team_availability`, or `learning_curve`
- `mitigation`

## tradeoff_analysis
Use `dimensions` plus `per_dimension`.
Each `per_dimension` row should include:
- `dimension`
- `current_stance`
- `rationale`
- `quantifiable_impact.metric`
- `quantifiable_impact.value`
- `reversibility`: `easy`, `medium`, `hard`, or `one_way_door`
- `revisit_trigger`
- `stakeholder_agreement`: `agreed`, `disputed`, or `pending`

## architecture_three_states
### `as_is`
- `description`
- `diagram_ref`
- `key_components`
- `known_pain_points`
- `technical_debt_score`

### `to_be`
- `description`
- `diagram_ref`
- `key_components`
- `improvements_over_as_is`
- `estimated_implementation_effort`

### `transitional`
- `description`
- `phases[]`
- `migration_risks[]`

Each phase should include:
- `phase_name`
- `duration`
- `components_changed`
- `coexistence_strategy`
- `rollback_point`
- `validation_gates`

## assumptions
Each item should include:
- `assumption_id` matching `ASSUMP-\d+`
- `statement`
- `category`: `business_assumption`, `technical_assumption`, `volume_assumption`, `environmental_assumption`, or `external_dependency_assumption`
- `confidence`: `high`, `medium`, or `low`
- `verification_plan.method`: `measurement`, `poc`, `expert_review`, or `historical_data`
- `verification_plan.when`
- `impact_if_wrong.severity`: `low`, `medium`, `high`, or `critical`
- `impact_if_wrong.description`
- `fallback_plan`

## fmea_analysis
Each item should include:
- `fmea_id` matching `FMEA-\d+`
- `component`
- `failure_mode`
- `failure_cause`
- `failure_effect`
- `severity`
- `occurrence`
- `detection`
- `rpn`
- `priority_tier`
- `mitigation_actions[]`
- `residual_risk.rpn`
- `residual_risk.acceptable`

Mitigation actions should include:
- `action`
- `reduces`: `severity`, `occurrence`, or `detection`
- `estimated_effort`

## exactness rules
- every canonical group must be present even when empty
- keep exact ids such as `C1_business`, `C2_regulatory`, and `ASSUMP-001`
- do not swap in generalized replacement enums
- you may append a supplemental analyst view after the canonical structure, never instead of it
