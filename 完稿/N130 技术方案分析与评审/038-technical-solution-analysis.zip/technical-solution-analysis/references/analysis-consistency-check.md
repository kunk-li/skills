# analysis-consistency-check

Use these rules as machine-checkable guards before finishing a `technical-solution-analysis` artifact. If a rule cannot pass because inputs are missing, list the failure in the blocker/open-items section and apply `downgrade-templates.md` rather than fabricating content.

| ID | Rule | Check |
|---|---|---|
| R1 | constraint taxonomy completeness | `C1_business`, `C2_regulatory`, `C3_technical`, `C4_operational`, `C5_temporal`, and `C6_human_resource` all appear, even when an item list is empty. |
| R2 | hard-constraint rationale | Every `hard` constraint includes both `rationale` and `consequence_if_violated`; missing evidence downgrades the row to pending or blocks the artifact. |
| R3 | one-way-door agreement | Any trade-off with `reversibility: one_way_door` must have `stakeholder_agreement: agreed`; otherwise mark it as disputed/pending and route back. |
| R4 | architecture three-state completeness | `as_is`, `to_be`, and `transitional` all exist; greenfield systems must still state the current baseline explicitly. |
| R5 | assumption verification | Every assumption has `verification_plan.method`, `verification_plan.when`, `impact_if_wrong.severity`, `impact_if_wrong.description`, and `fallback_plan`. |
| R6 | FMEA RPN arithmetic | Every FMEA row satisfies `rpn = severity * occurrence * detection`; invalid math is a blocker for that row. |
| R7 | FMEA priority tier | `priority_tier` follows the canonical threshold: `>=200 critical`, `100-199 high`, `50-99 medium`, `<50 low`. |
| R8 | critical mitigation | Every `critical` FMEA item has at least one mitigation action and a residual-risk statement. |
| R9 | defect carry-forward | Every relevant item from `需求漏洞清单.csv` or equivalent defect input is mapped to a constraint, assumption, FMEA row, blocker, or follow-up question. |
| R10 | downstream handoff grouping | Handoff items are grouped by consuming node or consumer type: draft generation, review generation, `N140`, `N150`, `N160`, `N170`, `N180`, and release/risk when applicable. |

## output discipline

- Do not silently omit a failed rule.
- Prefer `constrained` or `provisional` readiness for partial evidence.
- Use `blocked` only when core artifact identity, scope, or a critical input is missing.
