# example io

## example input packet
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`
- optional baseline constraints, incident learnings, or prior review notes

## canonical output shape
1. artifact contract header
2. `analysis_id` and scope
3. `constraints_taxonomy`
4. `tradeoff_analysis`
5. `architecture_three_states`
6. `assumptions`
7. `fmea_analysis`
8. recommendation and open items
9. node self-check summary
10. downstream handoff

## strongest downstream carry-forward items
- `recommended_candidate`
- `constraint_taxonomy_summary`
- `assumptions_to_verify`
- `failure_modes_to_carry_forward`
- `defect_items_to_carry_forward`
- `decision_refs`

## downgrade example · sparse constraints

Scenario: the team has a requirement one-pager and an incident log, but no handover package, no PRD, and no `接口意图清单.csv`.

Expected behaviour:

- set `readiness: provisional`
- emit every canonical group in `constraints_taxonomy`, even when empty:
  - `C1_business`, `C3_technical` may hold one or two items each
  - `C2_regulatory`, `C4_operational`, `C5_temporal`, `C6_human_resource` stay present with `items: []` and a short note such as `evidence_not_supplied`
- keep `tradeoff_analysis.per_dimension` focused on the two or three trade-offs that the one-pager actually touches; mark `stakeholder_agreement: pending` for the rest
- `architecture_three_states.as_is` may read `unknown; greenfield assumption` when evidence is missing, but `to_be` and `transitional` must still be emitted
- every assumption from the one-pager becomes an explicit item under `assumptions`, with `confidence: low` and a `verification_plan.when: before draft review`
- `fmea_analysis` may hold fewer than ten rows; explain the shortfall in the recommendation section rather than fabricating failure modes
- downstream handoff lists every missing input under `pending_confirmations` so the draft skill knows what to challenge

This pattern keeps the analysis usable while making the uncertainty explicit, which is the whole point of `provisional` readiness.
