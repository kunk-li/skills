# example io

## example input packet
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`
- optional baseline constraints, incident learnings, or prior review notes

## canonical output shape
1. artifact contract header
2. `analysis_id` and scope
3. `constraints_taxonomy`
4. `tradeoff_analysis`
5. `architecture_three_states`
6. `assumptions`
7. `fmea_analysis`
8. recommendation and open items
9. node self-check summary
10. downstream handoff

## strongest downstream carry-forward items
- `recommended_candidate`
- `constraint_taxonomy_summary`
- `assumptions_to_verify`
- `failure_modes_to_carry_forward`
- `defect_items_to_carry_forward`
- `decision_refs`

## downgrade example · sparse constraints

Scenario: the team has a requirement one-pager and an incident log, but no handover package, no PRD, and no `接口意图清单.csv`.

Expected behaviour:

- set `readiness: provisional`
- emit every canonical group in `constraints_taxonomy`, even when empty:
  - `C1_business`, `C3_technical` may hold one or two items each
  - `C2_regulatory`, `C4_operational`, `C5_temporal`, `C6_human_resource` stay present with `items: []` and a short note such as `evidence_not_supplied`
- keep `tradeoff_analysis.per_dimension` focused on the two or three trade-offs that the one-pager actually touches; mark `stakeholder_agreement: pending` for the rest
- `architecture_three_states.as_is` may read `unknown; greenfield assumption` when evidence is missing, but `to_be` and `transitional` must still be emitted
- every assumption from the one-pager becomes an explicit item under `assumptions`, with `confidence: low` and a `verification_plan.when: before draft review`
- `fmea_analysis` may hold fewer than ten rows; explain the shortfall in the recommendation section rather than fabricating failure modes
- downstream handoff lists every missing input under `pending_confirmations` so the draft skill knows what to challenge

This pattern keeps the analysis usable while making the uncertainty explicit, which is the whole point of `provisional` readiness.

## ex-001 · order service extraction — full analysis example

```yaml
analysis_id: TSA-001
scope: "Extract order management from monolith; introduce async payment + audit flow"
readiness: provisional
artifact_nature: analysis_only

constraints_taxonomy:
  C1_business:
    items:
      - id: C1-001
        constraint: Revenue SLO — order creation p99 must stay < 300ms post-migration
        hardness: hard
        rationale: customer churn data shows >500ms causes 8% drop-off
        consequence_if_violated: block release
  C2_regulatory:
    items:
      - id: C2-001
        constraint: PCI-DSS scope — card data must not transit order service
        hardness: hard
        rationale: compliance requirement
        consequence_if_violated: audit failure
  C3_technical:
    items:
      - id: C3-001
        constraint: No shared DB writes across service boundary
        hardness: hard
        rationale: distributed transaction risk
  C4_operational:
    items:
      - id: C4-001
        constraint: Single on-call rotation covers both services during transition
        hardness: soft
        note: team is 6 engineers, cannot split rotation yet
  C5_temporal:
    items:
      - id: C5-001
        constraint: MVP extraction in 8 weeks
        hardness: soft
  C6_human_resource:
    items: []
    evidence_note: no explicit team constraint supplied; treated as no constraint

tradeoff_analysis:
  per_dimension:
    - dimension: consistency_vs_availability
      current_stance: strong consistency (local DB transaction)
      proposed_stance: eventual consistency via outbox + saga
      rationale: saga eliminates distributed transaction; compensates for failures
      quantifiable_impact: "window of inconsistency ~200ms under normal load"
      reversibility: reversible with feature flag
      revisit_trigger: if compensation failure rate > 0.1%
      stakeholder_agreement: pending
    - dimension: complexity_vs_flexibility
      current_stance: monolith simple to debug
      proposed_stance: +2 services, +outbox table, +saga orchestrator
      rationale: bounded context separation needed for independent scaling
      quantifiable_impact: "debug path adds 1-2 service hops; local dev setup complexity doubles"
      reversibility: difficult after data migration
      stakeholder_agreement: pending

architecture_three_states:
  as_is:
    description: monolith with orders + payments + audit in same DB and process
    key_risks: [single point of failure, cannot scale payment independently]
  to_be:
    description: order-service owns order lifecycle; payment-service owns card auth; async audit via event
    target_properties: [independent scaling, PCI scope reduction, async audit]
  transitional:
    description: strangler fig — route new order traffic to order-service; legacy traffic to monolith; dual-write with feature flag
    coexistence_period: "6–8 weeks"
    rollback_point: feature flag kills new routing; monolith resumes full ownership

assumptions:
  - assumption_id: ASSUMP-001
    statement: "HR system can accept idempotent callbacks with retry-safe webhook"
    category: technical
    confidence: low
    verification_plan: {method: "review HR API contract", when: "sprint 1"}
    impact_if_wrong: "need synchronous call instead of async, blocking extraction"
    fallback_plan: "keep HR call synchronous inside monolith until HR API is confirmed"

fmea_analysis:
  - fmea_id: FMEA-001
    component: outbox relay
    failure_mode: relay crashes after DB write, before event publish
    failure_cause: process restart or OOM
    failure_effect: payment not triggered; order stuck in SUBMITTED
    severity: 9
    occurrence: 3
    detection: 4
    rpn: 108
    priority_tier: high
    mitigation_actions: ["idempotency key on event publish", "alerting on relay lag > 30s"]
    residual_risk: low
  - fmea_id: FMEA-002
    component: payment saga compensator
    failure_mode: compensation step fails to rollback order status
    failure_cause: order-service unavailable during compensation
    failure_effect: order status stuck; customer sees inconsistent state
    severity: 8
    occurrence: 2
    detection: 5
    rpn: 80
    priority_tier: medium
    mitigation_actions: ["retry compensation with exponential backoff", "dead-letter queue + ops alert"]
    residual_risk: medium

downstream_handoff:
  to_039_solution_draft:
    recommended_candidate: "strangler fig + saga + outbox"
    constraint_taxonomy_summary: [C1-001 latency hard, C2-001 PCI hard, C3-001 no shared DB hard]
    assumptions_to_verify: [ASSUMP-001 HR API]
    failure_modes_to_carry_forward: [FMEA-001 outbox relay, FMEA-002 saga compensation]
  to_040_review_questions:
    fmea_high_priority_rows: [FMEA-001]
    disputed_tradeoffs: [consistency_vs_availability stakeholder_agreement pending]
  to_N170_nfr: [saga retry policy, outbox relay SLO, payment timeout]
```

## ex-002 · blocked — boundary defect prevents analysis

```yaml
analysis_id: TSA-BLOCKED-001
readiness: blocked
blocker_mapping: B-N130-01
route_back_to: n120

blockers:
  - blocker_id: BLK-TSA-001
    type: missing_upstream
    description: "Interface intent list (接口意图清单.csv) absent — cannot scope technical analysis without confirmed API surface"
    impact: "Cannot evaluate C3_technical constraints; cannot produce meaningful FMEA without knowing what is being built"
    resolution_required: "Complete 037 api-intent-extraction before re-running this skill"
    unblock_evidence: "接口意图清单.csv with ≥1 confirmed intent"

  - blocker_id: BLK-TSA-002
    type: contradictory_requirements
    description: "Engineering requirements specify 'real-time processing' (ER-003) AND 'batch overnight processing' (ER-007) for the same data pipeline"
    impact: "Cannot select architecture candidate — both streaming and batch have opposite tradeoffs for this use case"
    resolution_required: "ER-003 and ER-007 must be reconciled by product owner; route back to 036"
    unblock_evidence: "Revised ER with single processing model, or explicit decision to run parallel architectures"

partial_output:
  constraint_taxonomy: partial
  completed_groups: [C1_business, C5_temporal]
  blocked_groups: [C3_technical, C4_operational]
  note: "Business and timeline constraints extracted; technical analysis blocked pending interface intent"

route_back_actions:
  - route_to: api-intent-extraction
    reason: "Complete intent inventory before re-running analysis"
  - route_to: engineering-requirement-parsing
    reason: "Resolve ER-003 vs ER-007 contradiction"
```

## ex-003 · degraded — sparse inputs, one-page PRD only

```yaml
analysis_id: TSA-002-DEGRADED
readiness: provisional
selected_mode: from_prd_only
evidence_profile:
  confirmed: []
  inferred: [all constraints derived from 1-page PRD]
  pending: [接口意图清单.csv, 需求漏洞清单.csv, stakeholder interviews]

degraded_reason: "No structured ER output from 036/037; analysis based solely on one-page PRD"
degraded_impact: "C2_regulatory and C4_operational constraints absent — unknown compliance and team constraints"

constraints_taxonomy:
  C1_business:
    items:
      - id: C1-001
        constraint: "Must support ≥100 concurrent users at launch"
        confidence: inferred
        inferred_from: "PRD section 3: 'designed for medium-sized enterprises'"
  C2_regulatory: {items: [], evidence_note: "No regulatory context in PRD — assume none until confirmed"}
  C3_technical: {items: [], evidence_note: "No architecture constraints stated — greenfield assumed"}
  C4_operational: {items: [], evidence_note: "No team/infra constraints stated — pending stakeholder interview"}
  C5_temporal:
    items:
      - id: C5-001
        constraint: "MVP in 3 months"
        confidence: explicit
  C6_human_resource: {items: [], evidence_note: "Team size unknown"}

pending_confirmations:
  - "Run 036 and 037 to get structured ER and intent inventory"
  - "Stakeholder interview for C2/C4 constraints"
```
