# Common failure modes

## F1: missing constraint groups
Symptom: only C1_business and C3_technical appear; C2_regulatory, C4_operational, C5_temporal, C6_human_resource are empty or absent.
Fix: all six groups must exist even if `items: []`; empty means no evidence, not no constraints.

## F2: untriaged FMEA
Symptom: failure modes are listed but RPN is missing or undifferentiated.
Fix: calculate `severity × occurrence × detection` per row; assign `priority_tier` using the canonical thresholds (≥200 = critical, 100–199 = high, 50–99 = medium, <50 = low).

## F3: assumptions without verification plans
Symptom: assumptions list "we assume X" but never state how or when X will be confirmed.
Fix: every assumption must have `verification_plan.method` and `verification_plan.when`, plus `impact_if_wrong` and `fallback_plan`.

## F4: transitional state omitted
Symptom: `as_is` and `to_be` are present but `transitional` is skipped ("we'll figure it out").
Fix: `transitional` is mandatory; even a one-line description of coexistence strategy qualifies.

## F5: trade-offs as bullet prose
Symptom: trade-off section reads as narrative without dimensions, current stance, or quantifiable impact.
Fix: use canonical dimension enums; each `per_dimension` row must have current stance, rationale, reversibility, and revisit trigger.

## F6: defect inputs ignored
Symptom: `需求漏洞清单.csv` is listed as input but none of its items appear in constraints, assumptions, or FMEA.
Fix: every defect item must map to at least one constraint, assumption risk, failure mode, or open question.

## F7: inventing facts
Symptom: "industry standard says X" or "teams typically do Y" appears as a confirmed constraint.
Fix: only facts traceable to user-provided material or explicitly labeled upstream outputs count as confirmed.

## F8: missing downstream handoff fields
Symptom: the analysis ends at the recommendation without grouping outputs per downstream consumer.
Fix: emit `to_039`, `to_040`, `to_N140`, `to_N150`, `to_N160`, `to_N170`, `to_N180` blocks even when mostly empty.

## Recurring system-level failure patterns to include in FMEA
- dependency unavailable (external API, DB, message broker)
- latency spike / timeout chain
- stale cache or cache stampede
- duplicate event or message replay
- out-of-order event delivery
- partial write or partial commit
- queue growth without bound
- cron drift or clock skew
- configuration rollout mismatch (old and new code running simultaneously)
- observability blind spot during incident (metrics lagging, logs not shipped)
