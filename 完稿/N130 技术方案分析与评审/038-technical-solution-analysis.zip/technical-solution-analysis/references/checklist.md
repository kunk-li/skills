# checklist

Run this check before finishing.

## universal
- use only traceable facts from user-provided material
- separate confirmed, inferred, and pending content
- include the shared v2 artifact contract header
- include the node self-check summary
- keep the output reusable as a standalone artifact
- keep the output inside technical solution design boundaries

## analysis-specific
- all six canonical constraint groups exist
- hard constraints include rationale and consequence
- trade-off rows use visible decision logic
- `as_is`, `to_be`, and `transitional` all exist
- assumptions include verification and fallback
- fmea rows use canonical fields and priority tiers
- requirement defects were absorbed into constraints, assumptions, risks, or blockers
- downstream handoff exists
- downgrade state, if any, follows `references/downgrade-templates.md`
- every rule in `references/analysis-consistency-check.md` R1 to R10 passes or its failure is listed as a blocker
