# Delivery checklist — technical-solution-analysis

Run before finalizing. Every unchecked item is either a blocker or an explicit provisional note.

## A. inputs and scope
- [ ] Sources used are only user-provided or explicitly traceable upstream outputs
- [ ] `confirmed`, `inferred`, and `pending` content are visibly separated throughout
- [ ] `readiness` level is set and justified

## B. constraints taxonomy
- [ ] All six groups exist: `C1_business`, `C2_regulatory`, `C3_technical`, `C4_operational`, `C5_temporal`, `C6_human_resource`
- [ ] Every hard constraint has `rationale` and `consequence_if_violated`
- [ ] Empty groups are present with `items: []` and `evidence_note`, not silently omitted

## C. trade-off analysis
- [ ] At least two canonical dimension enums are used
- [ ] Each `per_dimension` row has: current stance, rationale, quantifiable impact, reversibility, revisit trigger
- [ ] `stakeholder_agreement` is explicit (confirmed / pending / disputed)

## D. architecture three states
- [ ] `as_is`, `to_be`, and `transitional` all exist
- [ ] Greenfield projects write `as_is: none/greenfield` and still emit `to_be` and `transitional`
- [ ] `transitional` includes coexistence strategy and rollback point

## E. assumptions
- [ ] Every material assumption has: `assumption_id`, `statement`, `confidence`, `verification_plan`, `impact_if_wrong`, `fallback_plan`
- [ ] Low-confidence + high-impact assumptions are visually prominent

## F. FMEA
- [ ] Canonical fields used: `fmea_id`, `component`, `failure_mode`, `failure_cause`, `failure_effect`, `severity`, `occurrence`, `detection`, `rpn`, `priority_tier`, `mitigation_actions`, `residual_risk`
- [ ] RPN ≥ 200 → `priority_tier: critical`; 100-199 → `high`; 50-99 → `medium`; <50 → `low`
- [ ] Target ≥ 10 failure modes or justify shortfall in recommendation

## G. defect handling
- [ ] Every item from `需求漏洞清单.csv` (if present) mapped to constraint, assumption, FMEA row, or open question
- [ ] No defect input left unconsumed silently

## H. v2 contract
- [ ] Artifact header includes `artifact_schema_version`, `produced_event`, `blocker_mapping`, `rule_results[]`
- [ ] `rule_results[]` covers R1-R10 with `pass | warn | reject | not_applicable`
- [ ] `feedback_signal_to_n005` populated
- [ ] `downstream_handoff` includes blocks for: 039, 040, N140, N150, N160, N170, N180

## One-vote rejection items
Any of the following makes the output non-compliant regardless of other scores:
- [ ] Missing any of the six constraint groups
- [ ] FMEA rows missing canonical fields or RPN
- [ ] Three architecture states not all present
- [ ] Assumptions without verification plans
- [ ] Defect inputs unconsumed
