# Compatibility map — technical-solution-analysis v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 036 engineering-requirement-parsing | `er_id, technical_aspects[]` | `constraints_taxonomy source` | inherit TA aspects into C-group classification |
| 037 api-intent-extraction | `intent_id, nfr_hints` | `tradeoff_analysis.dimensions` | NFR hints seed performance/security trade-off dimensions |
| N070 014 business-rule-extraction | `RULE-* hardness=constraint` | `C1_business, C2_regulatory` | hard business rules become hard constraints |
| N070 015 state-transition-mapping | `SM-* invariants, blocked_by[]` | `fmea_analysis failure modes` | invariant violations → FMEA failure modes |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 039 technical-solution-draft-generation | `recommended_candidate, constraint_taxonomy_summary` | `S1_summary, S2_alternatives_considered` | draft inherits recommendation and constraints |
| 040 solution-review-question-generation | `fmea_analysis[], assumptions[]` | `question candidates` | FMEA critical rows → Q4_RISK questions |
| N170 all skills | `regulatory, operational, performance drivers` | `nfr design inputs` | C2/C4 constraints feed N170 design requirements |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
