<!-- skill_version: 2.0.4 -->
# Changelog · technical-solution-analysis

All notable changes to this skill will be recorded here.
Follow `MAJOR.MINOR.PATCH` — break canonical schema only on MAJOR bumps.

## how to read this file

- **schema-breaking**: canonical enum, field name, or required field changed in a way downstream consumers must adapt to
- **schema-additive**: new optional field or new enum value; existing consumers keep working
- **non-schema**: wording, docs, examples, internal rules

## [2.0.4] - 2026-04-24

### added · non-schema
- `references/analysis-consistency-check.md` with machine-checkable analysis rules R1 to R10 covering constraint presence, hard-constraint rationale, trade-off one-way-door agreement, architecture three-state completeness, assumption verification, FMEA RPN math, priority tiers, critical mitigations, defect carry-forward, and grouped downstream handoff.
- machine-readable CHANGELOG marker `<!-- skill_version: 2.0.4 -->` for tools that need the skill version without adding non-standard SKILL.md frontmatter fields.

### changed · non-schema
- rewrote gate-aware downgrade guidance to delegate to `references/downgrade-templates.md` as the source of truth for `blocked`, `constrained`, and `provisional` outputs.
- grouped downstream handoff by adjacent N130 consumer nodes (`N140`, `N150`, `N160`, `N170`, `N180`, `N270`, review) to improve orchestration readability.

## [2.0.3] - 2026-04-24

### changed · non-schema
- removed `version` from `SKILL.md` frontmatter so the entrypoint uses only deployment-safe `name` and `description`; semantic version history now lives in this CHANGELOG

### added · non-schema
- `references/downgrade-templates.md` with separate `blocked`, `constrained`, and `provisional` output patterns for sparse-input handling

## [2.0.2] - 2026-04-24

### added · non-schema
- this CHANGELOG file
- skill-internal version history for downstream consumers to track compatibility

### clarified · non-schema
- `mode` selection guidance distinguishes `deep_analysis` and `industry_template`: use `industry_template` only when the user names a regulated industry, otherwise prefer `deep_analysis` with optional industry references

## [2.0.1] - 2026-04-23

### added · schema-additive
- `version: 2.0.0` in frontmatter (superseded in 2.0.3; version history now lives in CHANGELOG; semantic skill version, distinct from `schema_version: n130.v2`)

### added · non-schema
- `example-io.md` gained a `## downgrade example · sparse constraints` section for provisional-readiness output shape
- `industry_template` operating mode listed alongside `deep_analysis`

## [2.0.0] - 2026-04-23 · canonical contract lock

### added · schema-breaking (first canonical lock)
- `references/exact-contract.md` as the machine-readable contract
- canonical constraint taxonomy `C1_business` · `C2_regulatory` · `C3_technical` · `C4_operational` · `C5_temporal` · `C6_human_resource`
- canonical FMEA priority-tier rule (`rpn >= 200 = critical`, `100-199 = high`, `50-99 = medium`, `< 50 = low`)
- canonical trade-off dimensions whitelist
- `references/v2-alignment.md` with shared registry discipline

### changed · schema-breaking
- constraint taxonomy ids migrated from `C1 technical_stack` / `C2 performance_slo` / `C3 business_rules` / `C4 compliance_regulatory` / `C5 operational` / `C6 organizational` to the v2 canonical names listed above
- FMEA row shape locked to canonical 12 fields

### added · non-schema
- four operating modes: `quick_check` · `deep_analysis` · `industry_template` · `retrospective`
- node self-check block as a mandatory closing section

## [1.x] - superseded

pre-contract drafts; not tracked here.
