---
name: technical-solution-analysis
description: analyze technical solutions against six constraint groups, produce fmea, trade-off rationale, and three architecture states. core n130 skill; precedes 039 and 040.
---
# technical-solution-analysis

Produce a reusable analysis artifact, not a full implementation draft.

Use the shared contract rules in `references/v2-alignment.md`, the chain rules in `references/orchestration.md`, the exact field obligations in `references/exact-contract.md`, the analysis consistency rules in `references/analysis-consistency-check.md`, and the degradation patterns in `references/downgrade-templates.md`.


## Constraint taxonomy quick-reference
| Group | Examples |
|---|---|
| `C1_business` | budget, revenue model, product strategy |
| `C2_regulatory` | GDPR, PCI-DSS, SOC2, local laws |
| `C3_technical` | existing tech stack, API contracts, data volume |
| `C4_operational` | on-call load, monitoring, SRE capacity |
| `C5_temporal` | launch deadline, sprint window, dependency freeze |
| `C6_human_resource` | team size, skills, hiring plan |

All six groups must exist in output even when empty.

## FMEA RPN quick-reference
| RPN | Priority tier | Action |
|---|---|---|
| ≥ 200 | critical | must mitigate before go-live |
| 100–199 | high | mitigate or accept with explicit rationale |
| 50–99 | medium | monitor and plan mitigation |
| < 50 | low | log and review at next cycle |


## Trigger conditions
Use when the task is to analyze trade-offs, constraints, assumptions, or architecture options before drafting a solution. Strong triggers:
- `开发需求解析.md` from N120
- `接口意图清单.csv` from N120  
- `需求漏洞清单.csv`
- explicit "analyze/compare/evaluate solution options" requests
- N110 handover packages requiring technical analysis

## Standalone rule
Works without structured upstream. When inputs are sparse:
- Set `readiness: provisional`
- Mark all assumptions as `confidence: low` with `verification_plan`
- Emit all six C-groups even if empty (`items: []`)
- Keep FMEA even if fewer than 10 rows — explain shortfall in recommendation

## role and boundary
This skill is the preferred **step 1 of 3** inside `N130 technical solution analysis and review`.

Stay inside the solution-analysis boundary:
- analyze constraints, trade-offs, architecture states, assumptions, and failure modes
- prepare downstream handoff for draft generation, review generation, and adjacent `N140` / `N150` / `N160` / `N170` / `N180` work
- do not generate runnable code, release plans, test execution plans, or final implementation details

## choose one operating mode
Choose exactly one mode and state it near the top.
Use the canonical mode names first.
- `quick_check`: focused directional analysis for one problem or sparse inputs
- `deep_analysis`: full N130 analysis with all canonical sections
- `industry_template`: full analysis plus industry-default constraints when the user explicitly gives an industry such as fintech, healthcare, ecommerce, saas, or gov
- `retrospective`: post-hoc analysis that checks whether the original assumptions and decision logic held

Optional: append an ADR-style block when the user specifically wants architecture decision framing.

If the input is incomplete, keep working in `provisional` readiness rather than stopping. Separate `confirmed`, `inferred`, and `pending` content.
When inputs are incomplete, apply `references/downgrade-templates.md` and keep `confirmed`, `inferred`, and `pending` analysis separate.

## preferred inputs
Treat only user-provided material and explicitly traceable upstream outputs as facts.

Strong inputs when present:
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`
- baseline constraints or handover invariants
- existing system context
- organizational context

Also accept requirement docs, PRDs, problem statements, incident learnings, and prior review notes supplied by the user.

Do not present unstated codebase reality, team history, vendor commitments, or “industry common practice” as confirmed facts.

## primary job
Turn raw requirements into a reusable analysis artifact that answers:
1. what problem must be solved
2. what constraints truly bind the solution
3. what trade-offs matter
4. what architecture transition is realistic
5. what assumptions and failure modes could break the decision
6. what downstream work should happen next

## mandatory output structure
Use Markdown. Prefer compact tables for comparative content.
You may add a short executive summary, but do not replace or rename the canonical fields below.

### 1. artifact contract header
Start with the shared contract header from `references/v2-alignment.md`.
Set:
- `artifact_type: technical_solution_analysis`
- `step_order: 1_of_3` or `standalone`
- `skill_name: technical-solution-analysis`

### 2. analysis identity
Emit:
- `analysis_id` using `TSA-xxx`
- `scope`
- optional `analysis_mode`

### 3. problem framing
Capture:
- problem statement
- business or system goal
- primary actors and key flows
- success criteria
- explicit out-of-scope items

### 4. constraints_taxonomy
Emit the canonical six groups exactly as named below.
Every group must exist even if the item list is empty.

- `C1_business`
- `C2_regulatory`
- `C3_technical`
- `C4_operational`
- `C5_temporal`
- `C6_human_resource`

For exact required fields and enums, follow `references/exact-contract.md`, and the degradation patterns in `references/downgrade-templates.md`.
Do not replace these canonical ids with generalized aliases.
If you want to add a supplemental analyst-friendly view such as “performance” or “organizational”, add it after the canonical block.

### 5. tradeoff_analysis
Emit:
- `dimensions`
- `per_dimension`

Use the canonical dimension enums first when applicable:
- `performance_vs_cost`
- `consistency_vs_availability`
- `complexity_vs_flexibility`
- `time_to_market_vs_quality`
- `security_vs_usability`
- `auto_vs_manual`
- `strong_typing_vs_dynamic`
- `build_vs_buy`
- `coupling_vs_cohesion`
- `lock_in_vs_portability`

Each `per_dimension` row must include current stance, rationale, quantifiable impact when possible, reversibility, revisit trigger, and stakeholder agreement.

### 6. architecture_three_states
Always emit:
- `as_is`
- `to_be`
- `transitional`

If the project is greenfield, write `as_is = none / greenfield` and still provide `to_be` and `transitional`.
Do not skip the transitional state.

### 7. assumptions
Emit the canonical `assumptions.items` list.
Every material assumption must include:
- `assumption_id`
- `statement`
- `category`
- `confidence`
- `verification_plan`
- `impact_if_wrong`
- `fallback_plan`

Low-confidence assumptions with high impact must be easy to spot.
If a requirement defect item caused the assumption, say so.

### 8. fmea_analysis
Perform explicit FMEA for the critical components, dependencies, or migration steps.
Use the canonical fields:
- `fmea_id`
- `component`
- `failure_mode`
- `failure_cause`
- `failure_effect`
- `severity`
- `occurrence`
- `detection`
- `rpn`
- `priority_tier`
- `mitigation_actions`
- `residual_risk`

Apply the canonical tier rule:
- `rpn >= 200 -> critical`
- `100-199 -> high`
- `50-99 -> medium`
- `< 50 -> low`

For non-trivial systems, aim for at least 10 failure modes total. If fewer exist, say why.

### 9. recommendation and open items
State:
- recommended direction
- why alternatives were not selected
- accepted risks
- decision preconditions
- pending confirmations
- blocked dependencies
- follow-up questions

### 10. node self-check summary
End with the shared node self-check block.

### 11. downstream handoff
Append a compact handoff block grouped by downstream consumer:
- `to_039_solution_draft`: recommended candidate, constraint taxonomy summary, trade-offs, assumptions to verify, decision refs
- `to_040_review_questions`: assumptions, FMEA rows, disputed trade-offs, defect items, decisions needing review
- `to_N140_architecture`: architecture states, module-boundary risks, migration/coexistence concerns
- `to_N150_api_design`: API-impacting constraints, integration assumptions, interface risks
- `to_N160_data_model`: data constraints, consistency assumptions, persistence failure modes
- `to_N170_nfr`: regulatory, operational, availability, security, performance, and observability drivers
- `to_N180_planning`: transitional phases, rollback points, blocked dependencies, effort drivers
- `to_N270_release_risk`: high/critical FMEA rows, residual risks, release blockers
- `adjacent_nodes_to_notify` and `decision_refs` when known

## defect and gap handling
If `需求漏洞清单.csv` or equivalent defect material is present, map every relevant item into one or more of:
- hard or soft constraint
- assumption risk
- failure mode
- blocker or follow-up question

Do not leave defect inputs unconsumed.

## output rules
- keep facts, inference, and pending items separate
- prefer tables over long prose
- make the recommendation logic visible, not implied
- keep the canonical field names stable for downstream consumption
- do not hide uncertainty; turn it into assumptions, open items, or risks

## gate-aware downgrade
Use `references/downgrade-templates.md` as the source of truth for downgrade behavior.
- `blocked`: emit the artifact contract header, confirmed facts, blockers, minimum next steps, `route_back_to`, and node self-check summary only.
- `constrained`: emit the canonical analysis skeleton, but mark weak constraints, assumptions, and FMEA rows as constrained and attach route-back actions.
- `provisional`: emit the canonical analysis skeleton with inferred content visibly labeled and verification plans attached.

Never invent missing constraints, stakeholder agreement, or FMEA evidence to make readiness look stronger than the inputs support.

## self-check before finishing
Verify all of the following:
- all six constraint groups exist
- hard constraints include rationale and consequence
- trade-off rationale is visible
- three architecture states exist
- assumptions include verification and fallback
- fmea uses canonical fields and visible priority tiers
- defect items were consumed
- node self-check exists
- downstream handoff exists
- every rule in `references/analysis-consistency-check.md` (R1 to R10) passes or its failure is explicitly listed as a blocker
- `rule_results[]` populated with pass | warn | reject | not_applicable for R1-R10
- `blocker_id: B-N130-01` declared when readiness is blocked or constrained
- `feedback_signal_to_n005` field populated (signal_type: none | gap_detected | fmea_critical_pattern

## v2 artifact contract additions

Append these fields to the existing v2-alignment.md header on every output:

```yaml
artifact_schema_version: n130.v2.1.0   # bump MINOR when output shape changes
skill_name: technical-solution-analysis
produced_event: produced.n130.technical_solution_analysis.v2
blocker_mapping: B-N130-01             # N380 SLA queue key
blocker_id: B-N130-01                  # legacy alias; prefer blocker_mapping
rule_results:
  - rule_id: R1_six_constraint_groups
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R2_hard_constraints_have_rationale
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R3_tradeoff_rationale_visible
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R4_three_architecture_states
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R5_assumptions_verified
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R6_fmea_canonical_fields
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R7_defect_items_consumed
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R8_downstream_handoff_complete
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R9_node_self_check_present
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R10_no_invented_evidence
    severity: reject
    result: pass | warn | reject | not_applicable
feedback_signal_to_n005:
  signal_type: none | gap_detected | fmea_critical_pattern
  fmea_critical_count: 0     # count of rpn >= 200 rows
  summary: ""
  target_n070_skills:
  - 014-business-rule-extraction
  - 015-state-transition-mapping
  - 017-data-object-identification
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop                # fill when recurring assumption failures map to upstream requirement gaps
```

## Upstream linkage from N070

When N070 artifacts are available as upstream context:

| upstream artifact | consume fields | maps to |
|---|---|---|
| `业务规则清单.md` (014) | RULE-* hardness=constraint | `C1_business`, `C2_regulatory` constraints |
| `状态转移图.md` (015) | SM-* invariants, blocked_by[] | `fmea_analysis` failure modes, `assumptions` |
| `权限矩阵.md` (016) | PERM-* compliance_flag | `C2_regulatory` constraints |
| `数据对象目录.md` (017) | OBJ-* constraint_tags: regulated, pii | `C2_regulatory`, `C3_technical` constraints |
| `验收标准.md` (032) | acceptance criteria | `success_criteria`, `defect_items_to_carry_forward` |
| `需求变更影响分析.md` (033) | impact dimensions | `C5_temporal`, `C6_human_resource` constraints |

## route_back_to and eventbus (v2 additions)

```yaml
route_back_to: none | analysis | draft
route_back_to: none | analysis | draft
# none    — downstream N140/N150/N160/N170/N180 may proceed
# analysis — assumptions, constraints, or defect interpretation wrong; return to 038
# draft   — chosen direction stands but design detail is weak; return to 039
eventbus_subscribers: [N330]
# N330 subscribes produced event to auto-generate 技术方案分析文档
```
