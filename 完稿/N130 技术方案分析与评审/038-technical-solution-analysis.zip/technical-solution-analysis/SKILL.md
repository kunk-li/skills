---
name: technical-solution-analysis
description: analyze technical solution constraints, trade-offs, architecture states, assumptions, and fmea before drafting a design. use for standalone technical direction analysis, adr-style decision support, or step 1 of the n130 chain when inputs such as 开发需求解析.md, 接口意图清单.csv, 需求漏洞清单.csv, or handover constraints must become a reusable analysis artifact that downstream draft and review skills can consume.
---
# technical-solution-analysis

Produce a reusable analysis artifact, not a full implementation draft.

Use the shared contract rules in `references/v2-alignment.md`, the chain rules in `references/orchestration.md`, the exact field obligations in `references/exact-contract.md`, the analysis consistency rules in `references/analysis-consistency-check.md`, and the degradation patterns in `references/downgrade-templates.md`.

## role and boundary
This skill is the preferred **step 1 of 3** inside `N130 technical solution analysis and review`.

Stay inside the solution-analysis boundary:
- analyze constraints, trade-offs, architecture states, assumptions, and failure modes
- prepare downstream handoff for draft generation, review generation, and adjacent `N140` / `N150` / `N160` / `N170` / `N180` work
- do not generate runnable code, release plans, test execution plans, or final implementation details

## choose one operating mode
Choose exactly one mode and state it near the top.
Use the canonical mode names first.
- `quick_check`: focused directional analysis for one problem or sparse inputs
- `deep_analysis`: full N130 analysis with all canonical sections
- `industry_template`: full analysis plus industry-default constraints when the user explicitly gives an industry such as fintech, healthcare, ecommerce, saas, or gov
- `retrospective`: post-hoc analysis that checks whether the original assumptions and decision logic held

Optional: append an ADR-style block when the user specifically wants architecture decision framing.

If the input is incomplete, keep working in `provisional` readiness rather than stopping. Separate `confirmed`, `inferred`, and `pending` content.
When inputs are incomplete, apply `references/downgrade-templates.md` and keep `confirmed`, `inferred`, and `pending` analysis separate.

## preferred inputs
Treat only user-provided material and explicitly traceable upstream outputs as facts.

Strong inputs when present:
- `开发需求解析.md`
- `接口意图清单.csv`
- `需求漏洞清单.csv`
- baseline constraints or handover invariants
- existing system context
- organizational context

Also accept requirement docs, PRDs, problem statements, incident learnings, and prior review notes supplied by the user.

Do not present unstated codebase reality, team history, vendor commitments, or “industry common practice” as confirmed facts.

## primary job
Turn raw requirements into a reusable analysis artifact that answers:
1. what problem must be solved
2. what constraints truly bind the solution
3. what trade-offs matter
4. what architecture transition is realistic
5. what assumptions and failure modes could break the decision
6. what downstream work should happen next

## mandatory output structure
Use Markdown. Prefer compact tables for comparative content.
You may add a short executive summary, but do not replace or rename the canonical fields below.

### 1. artifact contract header
Start with the shared contract header from `references/v2-alignment.md`.
Set:
- `artifact_type: technical_solution_analysis`
- `step_order: 1_of_3` or `standalone`
- `skill_name: technical-solution-analysis`

### 2. analysis identity
Emit:
- `analysis_id` using `TSA-xxx`
- `scope`
- optional `analysis_mode`

### 3. problem framing
Capture:
- problem statement
- business or system goal
- primary actors and key flows
- success criteria
- explicit out-of-scope items

### 4. constraints_taxonomy
Emit the canonical six groups exactly as named below.
Every group must exist even if the item list is empty.

- `C1_business`
- `C2_regulatory`
- `C3_technical`
- `C4_operational`
- `C5_temporal`
- `C6_human_resource`

For exact required fields and enums, follow `references/exact-contract.md`, and the degradation patterns in `references/downgrade-templates.md`.
Do not replace these canonical ids with generalized aliases.
If you want to add a supplemental analyst-friendly view such as “performance” or “organizational”, add it after the canonical block.

### 5. tradeoff_analysis
Emit:
- `dimensions`
- `per_dimension`

Use the canonical dimension enums first when applicable:
- `performance_vs_cost`
- `consistency_vs_availability`
- `complexity_vs_flexibility`
- `time_to_market_vs_quality`
- `security_vs_usability`
- `auto_vs_manual`
- `strong_typing_vs_dynamic`
- `build_vs_buy`
- `coupling_vs_cohesion`
- `lock_in_vs_portability`

Each `per_dimension` row must include current stance, rationale, quantifiable impact when possible, reversibility, revisit trigger, and stakeholder agreement.

### 6. architecture_three_states
Always emit:
- `as_is`
- `to_be`
- `transitional`

If the project is greenfield, write `as_is = none / greenfield` and still provide `to_be` and `transitional`.
Do not skip the transitional state.

### 7. assumptions
Emit the canonical `assumptions.items` list.
Every material assumption must include:
- `assumption_id`
- `statement`
- `category`
- `confidence`
- `verification_plan`
- `impact_if_wrong`
- `fallback_plan`

Low-confidence assumptions with high impact must be easy to spot.
If a requirement defect item caused the assumption, say so.

### 8. fmea_analysis
Perform explicit FMEA for the critical components, dependencies, or migration steps.
Use the canonical fields:
- `fmea_id`
- `component`
- `failure_mode`
- `failure_cause`
- `failure_effect`
- `severity`
- `occurrence`
- `detection`
- `rpn`
- `priority_tier`
- `mitigation_actions`
- `residual_risk`

Apply the canonical tier rule:
- `rpn >= 200 -> critical`
- `100-199 -> high`
- `50-99 -> medium`
- `< 50 -> low`

For non-trivial systems, aim for at least 10 failure modes total. If fewer exist, say why.

### 9. recommendation and open items
State:
- recommended direction
- why alternatives were not selected
- accepted risks
- decision preconditions
- pending confirmations
- blocked dependencies
- follow-up questions

### 10. node self-check summary
End with the shared node self-check block.

### 11. downstream handoff
Append a compact handoff block grouped by downstream consumer:
- `to_039_solution_draft`: recommended candidate, constraint taxonomy summary, trade-offs, assumptions to verify, decision refs
- `to_040_review_questions`: assumptions, FMEA rows, disputed trade-offs, defect items, decisions needing review
- `to_N140_architecture`: architecture states, module-boundary risks, migration/coexistence concerns
- `to_N150_api_design`: API-impacting constraints, integration assumptions, interface risks
- `to_N160_data_model`: data constraints, consistency assumptions, persistence failure modes
- `to_N170_nfr`: regulatory, operational, availability, security, performance, and observability drivers
- `to_N180_planning`: transitional phases, rollback points, blocked dependencies, effort drivers
- `to_N270_release_risk`: high/critical FMEA rows, residual risks, release blockers
- `adjacent_nodes_to_notify` and `decision_refs` when known

## defect and gap handling
If `需求漏洞清单.csv` or equivalent defect material is present, map every relevant item into one or more of:
- hard or soft constraint
- assumption risk
- failure mode
- blocker or follow-up question

Do not leave defect inputs unconsumed.

## output rules
- keep facts, inference, and pending items separate
- prefer tables over long prose
- make the recommendation logic visible, not implied
- keep the canonical field names stable for downstream consumption
- do not hide uncertainty; turn it into assumptions, open items, or risks

## gate-aware downgrade
Use `references/downgrade-templates.md` as the source of truth for downgrade behavior.
- `blocked`: emit the artifact contract header, confirmed facts, blockers, minimum next steps, `route_back_to`, and node self-check summary only.
- `constrained`: emit the canonical analysis skeleton, but mark weak constraints, assumptions, and FMEA rows as constrained and attach route-back actions.
- `provisional`: emit the canonical analysis skeleton with inferred content visibly labeled and verification plans attached.

Never invent missing constraints, stakeholder agreement, or FMEA evidence to make readiness look stronger than the inputs support.

## self-check before finishing
Verify all of the following:
- all six constraint groups exist
- hard constraints include rationale and consequence
- trade-off rationale is visible
- three architecture states exist
- assumptions include verification and fallback
- fmea uses canonical fields and visible priority tiers
- defect items were consumed
- node self-check exists
- downstream handoff exists
- every rule in `references/analysis-consistency-check.md` (R1 to R10) passes or its failure is explicitly listed as a blocker
