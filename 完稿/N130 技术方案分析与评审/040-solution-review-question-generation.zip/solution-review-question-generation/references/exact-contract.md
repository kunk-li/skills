# exact contract

Use this file whenever you need the exact `N130_Skills_v2.md` review contract instead of a generalized review template.

## canonical output root
Emit review questions plus probe information.
Each question row should include the exact fields below.

## canonical question fields
- `question_id` matching `RQ-\d{3,}`
- `question_kind`
- `target_section`
- `specific_location`
- `question_text`
- `context_quote`
- `criticality`
- `expected_answer_kind`
- `target_reviewer_role`
- `for_review_round`
- `generated_by_probe`
- `answer`

## `question_kind`
Use exactly one of:
- `Q1_CLARIFY`
- `Q2_CHALLENGE`
- `Q3_ALTERNATIVE`
- `Q4_RISK`
- `Q5_DETAIL`
- `Q6_CONSISTENCY`
- `Q7_CRITERIA`
- `Q8_FUTURE`

## `target_section`
Use one of:
- `S1`
- `S2`
- `S3`
- `S4`
- `S5`
- `S6`
- `S7`
- `S8`
- `external_doc` only when reviewing a non-canonical external design document

## `criticality`
Use one of:
- `critical`
- `high`
- `medium`
- `low`

## `expected_answer_kind`
Use one of:
- `fact`
- `judgment`
- `document_ref`
- `benchmark_data`

## `target_reviewer_role`
Prefer the exact output enum values:
- `architect`
- `security`
- `compliance`
- `dba`
- `sre`
- `pm`

If the practical helper is a `senior_dev` or `qa`, mention that in a supplemental note or `follow_up_action` without changing the canonical enum.

## `for_review_round`
Use the rounds that fit the request.
Canonical values are integers `1`, `2`, `3`, `4`, or the literal `final`, as defined by the N130 node contract. If a human-friendly label is helpful, add an optional supplemental `round_label` such as `round_1`; do not replace `for_review_round` with labels.

## `answer`
Include the canonical tracking object:
- `answered`
- `answer_text`
- `answered_by`
- `answered_at`
- `satisfactory`
- `follow_up_required`
- `follow_up_question_id`

## canonical probes
Use these exact ids when probe-generated:
- `P01_data_consistency_across_services`
- `P02_performance_under_peak_load`
- `P03_failure_of_critical_component`
- `P04_data_migration_safety`
- `P05_security_boundary_definition`
- `P06_compliance_verification`
- `P07_backward_compatibility`
- `P08_operational_readiness`
- `P09_cost_projections`
- `P10_team_readiness`
- `P11_chain_hangs_on_single_input_key`

Every probe-generated question should carry `advisory_only: true` by default. Override to `false` only when evidence elevates the probe question into a blocker, and record the reason in `follow_up_action`.

## exactness rules
- keep canonical field names stable
- do not replace canonical enums with generalized labels
- keep `target_section` and `specific_location` concrete enough for follow-up; when `target_section: external_doc`, `specific_location` must cite a document section, page, or paragraph
- include the `answer` object even when it is mostly unfilled
- you may add a blocker summary or meeting agenda after the canonical rows, never instead of them
