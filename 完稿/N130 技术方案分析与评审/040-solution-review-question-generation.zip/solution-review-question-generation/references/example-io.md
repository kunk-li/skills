# example io

## example input packet
- output from `technical-solution-analysis`
- output from `technical-solution-draft-generation`
- `需求漏洞清单.csv`
- optional review notes or unresolved item lists

## canonical output shape
1. artifact contract header
2. review header
3. blocker summary
4. question table with canonical fields
5. route-back summary
6. node self-check summary

## strongest downstream carry-forward items
- `analysis_return_items`
- `draft_return_items`
- `meeting_agenda_top_items`
- question rows with canonical `answer` tracking

## downgrade example · external design doc only

Scenario: the user hands in a single external solution document produced by another team. No upstream analysis, no upstream draft, no `需求漏洞清单.csv`. The document also does not follow the `S1` to `S8` structure.

Expected behaviour:

- set `readiness: provisional`, `scope: external_document_review`
- every question still uses a canonical `question_kind` from `Q1_CLARIFY` to `Q8_FUTURE`
- when the external document lacks a canonical section map:
  - `target_section` may read `external_doc`
  - `specific_location` points to a document section or paragraph reference such as `§3.2` or `page 5, paragraph 2`
  - write a short note under `context_quote` that identifies the passage; never invent an `S3.COMP-001` style address that the document does not contain
- probes still use canonical ids (`P01` to `P10`) and remain `advisory_only: true` unless the evidence clearly elevates one to a blocker
- `target_reviewer_role` stays on the canonical enum (`architect` / `security` / `compliance` / `dba` / `sre` / `pm`), even when the real team member is a `senior_dev` or `qa`; mention the real helper in `follow_up_action`
- `answer` object is present for every question, with `answered: false` and empty tracking fields
- `route_back_to` may be `none` since there is no in-house analysis or draft to return to; instead, list `meeting_agenda_top_items` and `parked_items` so the reviewing team decides the next step outside the N130 chain

## ex-001 · systematic mode — full YAML question pack (leave request system)

```yaml
artifact_contract:
  artifact_schema_version: n130.v2.1.0
  skill_name: solution-review-question-generation
  produced_event: produced.n130.solution_review_questions.v2
  blocker_mapping: B-N130-03
  readiness: provisional
  step_order: 3_of_3

review_header:
  review_pack_id: RQP-001
  mode: systematic
  scope: leave-request-approval-system
  sources_used: [038-TSA-001, 039-SOL-001]
  recommended_review_round: 1

blocker_summary:
  critical_count: 1
  high_count: 2
  medium_count: 3
  low_count: 1
  top_must_answer:
    - RQ-001: HR callback sync vs async — blocks saga design
    - RQ-002: approval SLO not defined — blocks FMEA floor

questions:
  - question_id: RQ-001
    question_kind: Q1_CLARIFY
    target_section: S4
    specific_location: S4.api_contracts.hr_provisioning_callback
    question_text: "Is the HR provisioning callback synchronous (blocking order creation) or asynchronous (outbox + webhook retry)? The current draft shows an outbox pattern but the acceptance criteria mention 'immediate HR confirmation'."
    context_quote: "upon final approval, trigger HR provisioning"
    criticality: critical
    expected_answer_kind: judgment
    target_reviewer_role: architect
    for_review_round: 1
    generated_by_probe: P01_data_consistency_across_services
    advisory_only: false
    category_tag: integration
    answer:
      answered: false
      answer_text: null
      answered_by: null
      answered_at: null
      satisfactory: null
      follow_up_required: true
      follow_up_question_id: RQ-006

  - question_id: RQ-002
    question_kind: Q7_CRITERIA
    target_section: S6
    specific_location: S6.performance.targets
    question_text: "What is the measurable acceptance criterion for approval submission latency? The S6 section states 'should be responsive' without a p99 target or floor threshold for alert/degrade."
    context_quote: "performance: should be responsive"
    criticality: high
    expected_answer_kind: benchmark_data
    target_reviewer_role: pm
    for_review_round: 1
    generated_by_probe: P02_performance_under_peak_load
    advisory_only: false
    category_tag: performance
    answer:
      answered: false
      answer_text: null
      answered_by: null
      answered_at: null
      satisfactory: null
      follow_up_required: false
      follow_up_question_id: null

  - question_id: RQ-003
    question_kind: Q4_RISK
    target_section: S4
    specific_location: S4.event_contracts.approval.decision.recorded
    question_text: "If the audit event write succeeds but the outbox relay fails after the approval DB commit, the approval is persisted but HR is never notified. What is the recovery procedure and how long is the inconsistency window?"
    context_quote: "FMEA-001: outbox relay crashes after DB write"
    criticality: high
    expected_answer_kind: document_ref
    target_reviewer_role: architect
    for_review_round: 1
    generated_by_probe: P03_failure_of_critical_component
    advisory_only: false
    category_tag: reliability
    answer:
      answered: false
      answer_text: null
      answered_by: null
      answered_at: null
      satisfactory: null
      follow_up_required: true
      follow_up_question_id: RQ-007

route_back_summary:
  analysis_return_items:
    - "RQ-001 answer may change saga vs sync constraint in C3_technical (return to 038)"
  draft_return_items:
    - "RQ-002 answer adds p99 target to S6.performance (return to 039)"
    - "RQ-003 answer adds recovery procedure to S8 rollout phases (return to 039)"
  meeting_agenda_top_items:
    - "RQ-001: HR callback architecture decision (architect + PM, 15min)"
    - "RQ-002: performance SLO definition (PM, 10min)"
    - "RQ-003: outbox failure recovery procedure (architect + SRE, 20min)"
  parked_items:
    - "RQ-008: future multi-tenant isolation (deferred to phase 2)"

rule_results:
  - {rule_id: R1_q1_to_q8_sections_covered, severity: reject, result: pass}
  - {rule_id: R2_blocker_questions_identified, severity: reject, result: pass}
  - {rule_id: R5_route_back_actions_present, severity: reject, result: pass}
  - {rule_id: R8_node_self_check_present, severity: warn, result: pass}
```

## ex-002 · blocked — solution draft not ready for review

```yaml
review_pack_id: RQP-BLOCKED-001
readiness: blocked
blocker_mapping: B-N130-03
route_back_to: technical-solution-draft-generation

blockers:
  - blocker_id: BLK-RQP-001
    type: draft_not_ready
    description: "S5_requirement_coverage_matrix shows 3 P0 requirements as not_covered — review cannot proceed on an incomplete draft"
    uncovered_p0s: [ER-001, ER-003, ER-007]
    impact: "Review of an incomplete draft wastes reviewer time; gaps will simply be flagged as missing rather than reviewed"
    resolution_required: "039 must produce fully_covered P0 requirements before review questions are meaningful"
    unblock_evidence: "Updated draft with S5.completeness_check.p0_gate: pass"

  - blocker_id: BLK-RQP-002
    type: missing_section
    description: "S7_deployment_topology and S8_migration_and_rollout are absent from the draft"
    impact: "Cannot generate Q8_FUTURE (scaling questions) or Q4_RISK (rollout risk questions) without these sections"
    resolution_required: "039 must complete S7 and S8 even with placeholder content"

partial_output:
  questions_generated: 2
  questions_blocked: 8
  generated_for: [S1_summary, S3_architecture]
  blocked_for: [S4_interface_contracts, S5_coverage_matrix, S6_nfr, S7_topology, S8_rollout]

route_back_actions:
  - route_to: technical-solution-draft-generation
    specific_request: "Complete S5, S7, S8 before requesting review questions"
```

## ex-003 · degraded — reviewing external design doc (non-canonical structure)

```yaml
review_pack_id: RQP-002-EXTERNAL
readiness: provisional
mode: external_doc_review
scope: "External architecture proposal from vendor team"
sources_used: ["vendor-proposal-v2.pdf — non-canonical structure"]

degraded_reason: "Source document does not follow S1-S8 canonical structure — all questions use target_section: external_doc"
degraded_impact: "Probe triggering limited; cannot map to specific draft sections; advisory questions only"

questions:
  - question_id: RQ-EXT-001
    question_kind: Q1_CLARIFY
    target_section: external_doc
    specific_location: "Page 3, Data Layer section"
    question_text: "The proposal mentions 'database clustering' — is this active-active or active-passive? What is the failover time?"
    criticality: high
    advisory_only: true
    evidence_strength: inferred

  - question_id: RQ-EXT-002
    question_kind: Q4_RISK
    target_section: external_doc
    specific_location: "Page 7, Integration section"
    question_text: "The integration relies on a third-party webhook. What is the retry policy if our endpoint is unavailable? Is there a dead-letter mechanism?"
    criticality: critical
    advisory_only: false
    generated_by_probe: P03_failure_of_critical_component

degraded_guidance: "For external docs: all questions tagged advisory_only=true unless direct evidence of critical risk exists"
```
