# example io

## example input packet
- output from `technical-solution-analysis`
- output from `technical-solution-draft-generation`
- `需求漏洞清单.csv`
- optional review notes or unresolved item lists

## canonical output shape
1. artifact contract header
2. review header
3. blocker summary
4. question table with canonical fields
5. route-back summary
6. node self-check summary

## strongest downstream carry-forward items
- `analysis_return_items`
- `draft_return_items`
- `meeting_agenda_top_items`
- question rows with canonical `answer` tracking

## downgrade example · external design doc only

Scenario: the user hands in a single external solution document produced by another team. No upstream analysis, no upstream draft, no `需求漏洞清单.csv`. The document also does not follow the `S1` to `S8` structure.

Expected behaviour:

- set `readiness: provisional`, `scope: external_document_review`
- every question still uses a canonical `question_kind` from `Q1_CLARIFY` to `Q8_FUTURE`
- when the external document lacks a canonical section map:
  - `target_section` may read `external_doc`
  - `specific_location` points to a document section or paragraph reference such as `§3.2` or `page 5, paragraph 2`
  - write a short note under `context_quote` that identifies the passage; never invent an `S3.COMP-001` style address that the document does not contain
- probes still use canonical ids (`P01` to `P10`) and remain `advisory_only: true` unless the evidence clearly elevates one to a blocker
- `target_reviewer_role` stays on the canonical enum (`architect` / `security` / `compliance` / `dba` / `sre` / `pm`), even when the real team member is a `senior_dev` or `qa`; mention the real helper in `follow_up_action`
- `answer` object is present for every question, with `answered: false` and empty tracking fields
- `route_back_to` may be `none` since there is no in-house analysis or draft to return to; instead, list `meeting_agenda_top_items` and `parked_items` so the reviewing team decides the next step outside the N130 chain
