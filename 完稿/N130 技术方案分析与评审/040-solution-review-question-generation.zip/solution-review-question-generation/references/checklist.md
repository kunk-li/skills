# Delivery checklist — solution-review-question-generation

## A. question quality
- [ ] Every question uses exactly one canonical `question_kind`: Q1_CLARIFY through Q8_FUTURE
- [ ] Every question has `target_section` (S1-S8 or `external_doc`) with `specific_location`
- [ ] Every question has `context_quote`, `expected_answer_kind`, `target_reviewer_role`, `for_review_round`
- [ ] `expected_answer_kind` uses canonical enum: `fact | judgment | document_ref | benchmark_data`

## B. blocker handling
- [ ] Critical questions are sorted to top and appear in blocker summary
- [ ] `criticality` uses canonical enum: `critical | high | medium | low`
- [ ] Every critical question has an owner and a due round

## C. probes
- [ ] Relevant probes triggered (P01-P10 with canonical IDs)
- [ ] No probe claimed without supporting evidence
- [ ] All probe-generated questions carry `advisory_only: true` unless explicitly elevated

## D. answer tracking
- [ ] Every question has canonical `answer` object with: `answered`, `answer_text`, `answered_by`, `answered_at`, `satisfactory`, `follow_up_required`, `follow_up_question_id`

## E. machine-readable output
- [ ] All questions emitted as YAML block after the Markdown table
- [ ] `question_id` values are stable (RQ-NNN format)
- [ ] `category_tag` present as supplemental grouping field

## F. route-back
- [ ] `analysis_return_items` grouped (questions pointing back to 038)
- [ ] `draft_return_items` grouped (questions pointing back to 039)
- [ ] `meeting_agenda_top_items` extracted (top 3-5 must-answer items)
- [ ] `parked_items` listed for deferred questions

## G. defect handling
- [ ] Every item from `需求漏洞清单.csv` (if present) converted to visible question or explicit blocker

## H. v2 contract
- [ ] `artifact_schema_version`, `produced_event: produced.n130.solution_review_questions.v2`, `blocker_mapping: B-N130-03`
- [ ] `rule_results[]` covers R1-R8
- [ ] `feedback_signal_to_n005` populated

## One-vote rejection items
- [ ] Any question using non-canonical kind or criticality enum
- [ ] FMEA critical rows not converted to questions
- [ ] Missing YAML block for downstream consumption
- [ ] Route-back summary absent
