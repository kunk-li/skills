# checklist

Run this check before finishing.

## universal
- use only traceable facts from user-provided material
- separate confirmed, inferred, and pending content
- include the shared v2 artifact contract header
- include the node self-check summary
- keep the output reusable as a standalone artifact
- keep the output inside technical solution design boundaries

## review-specific
- every question uses a canonical `Q1` to `Q8` kind
- every question points to `S1` to `S8` with `specific_location`; use `external_doc` only for non-canonical external documents and cite the concrete section/page/paragraph
- every question includes evidence, answer kind, owner, and review round
- canonical answer tracking fields exist
- relevant canonical probes are visible
- blocker-like items are easy to spot through ordering and summary
- requirement defects were converted into visible questions or blockers
- route-back summary exists
- every rule in `references/review-consistency-check.md` R1 to R5 passes or its failure is listed as a blocker
- downgrade state, if any, follows `references/downgrade-templates.md`
