# Compatibility map — solution-review-question-generation v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 038 technical-solution-analysis | `fmea_analysis[], assumptions[]` | `question candidates (Q4_RISK)` | FMEA critical rows become Q4_RISK questions |
| 039 technical-solution-draft-generation | `S1-S8 sections` | `target_section (S1-S8)` | each section generates targeted questions |
| N070 013 requirement-breakdown | `open_question_refs[], certainty=待确认` | `Q1_CLARIFY questions` | unresolved requirement items become clarification questions |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 038 technical-solution-analysis | `analysis_return_items` | `re-analysis input` | questions requiring constraint or FMEA revision route back |
| 039 technical-solution-draft-generation | `draft_return_items` | `section revision input` | questions requiring S1-S8 section changes route back |
| N330 documentation | `stable question rows (YAML block)` | `review question document` | machine-readable YAML consumed by N330 |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
