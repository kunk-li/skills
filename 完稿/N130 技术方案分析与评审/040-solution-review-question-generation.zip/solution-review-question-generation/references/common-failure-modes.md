# Common failure modes

## F1: questions without canonical kind
Symptom: question_kind uses labels like "blocker", "major", "concern" instead of Q1-Q8 enums.
Fix: every question must use exactly one of Q1_CLARIFY through Q8_FUTURE.

## F2: vague target_section
Symptom: target_section says "architecture" or "general" instead of S3 or S6.performance.targets.
Fix: use S1-S8 with the most specific sub-address available, e.g. `S4.API-ORDER-CREATE` or `S6.security.auth`.

## F3: probes claimed without evidence
Symptom: all 10 probes are listed as triggered even when the source has no relevant evidence.
Fix: trigger only probes supported by evidence in the input; `advisory_only: true` by default, `false` only when evidence elevates to blocker.

## F4: missing answer objects
Symptom: questions are listed but the `answer` tracking object is absent or has no `follow_up_required` field.
Fix: every question must have the canonical `answer` object with `answered: false` and all tracking fields initialized.

## F5: FMEA rows not converted to questions
Symptom: FMEA critical rows from 038 exist but no corresponding Q4_RISK or Q2_CHALLENGE question appears.
Fix: every critical or high FMEA row should generate at least one review question.

## F6: no YAML block for downstream
Symptom: questions are only in Markdown table; N330/N340 cannot consume without re-parsing.
Fix: emit all question rows in a fenced YAML block at the end, after the Markdown table. Stable `question_id` values are mandatory.

## F7: missing route-back summary
Symptom: the question pack ends at the question list; no `analysis_return_items` or `draft_return_items` are present.
Fix: route-back summary must appear after the question table with clear grouping: what goes back to 038 (analysis) vs 039 (draft).

## F8: meeting-agenda top items not extracted
Symptom: critical questions are buried in a flat list with no prioritization.
Fix: surface top 3–5 `meeting_agenda_top_items` explicitly; these are the ones that block proceeding.
