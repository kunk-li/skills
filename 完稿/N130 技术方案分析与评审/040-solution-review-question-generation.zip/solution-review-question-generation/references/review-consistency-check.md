# review consistency check

Use this reference when producing a `solution-review-question-generation` artifact that must be consumed downstream without rework.

The goal is to make cross-field consistency **machine-checkable** rather than relying on reviewer memory.

## why this file exists

`SKILL.md` `§8 answer tracking discipline`, `§9 probe discipline`, and `§10 route-back and self-check` each mention consistency requirements.
This file collects every cross-field rule in one place so the self-check and downstream consumption can be deterministic.

## rule set

### R1 · probe reference integrity
Every probe-generated question must carry a `generated_by_probe` value drawn from the canonical probe set:

- `P01_data_consistency_across_services`
- `P02_performance_under_peak_load`
- `P03_failure_of_critical_component`
- `P04_data_migration_safety`
- `P05_security_boundary_definition`
- `P06_compliance_verification`
- `P07_backward_compatibility`
- `P08_operational_readiness`
- `P09_cost_projections`
- `P10_team_readiness`

- do not invent probe ids outside this list
- do not claim a probe fired when no supporting evidence exists in `sources_used`
- if a question was not probe-triggered, omit `generated_by_probe` rather than leave it empty

### R2 · follow-up chain integrity
Every `answer.follow_up_question_id` must reference a `question_id` that exists in the same review pack.

- broken follow-up references become blockers, not silent gaps
- when a follow-up has not yet been drafted, set `answer.follow_up_required: true` and `answer.follow_up_question_id: pending` with a note in `follow_up_action`

### R3 · review round value
`for_review_round` must use the canonical N130 node-contract values:

- `1` — initial design review
- `2` — follow-up after rework
- `3` — deep technical review
- `4` — pre-release readiness review
- `final` — approval gate

- do not use free-form values such as `first review` or `design review 2`
- do not replace this field with labels such as `round_1`; when labels help humans, add optional `round_label` or put the label in `follow_up_action`

### R4 · target section resolution
Every question must specify `target_section` as one of:

- a canonical section id `S1` to `S8` when the draft is structured by `technical-solution-draft-generation`
- the literal `external_doc` when reviewing a non-canonical design document (see `example-io.md` downgrade example)

- no other values are allowed
- `specific_location` must be present in both cases; for `external_doc`, use concrete references such as `§3.2` or `page 5, paragraph 2`

### R5 · advisory elevation discipline
Probe-generated questions carry `advisory_only: true` by default.

- when a probe question is elevated to `advisory_only: false`, the question must include a non-empty `follow_up_action` explaining what evidence justifies the elevation
- elevated probe questions must also receive a non-`low` `criticality`
- if either the evidence or the `criticality` is weak, keep the question advisory and phrase it as a clarification instead

## how to use this file

1. during question generation, run each rule as questions accumulate rather than at the end
2. in `self-check before finishing`, every rule above must either pass or appear as an explicit blocker
3. when routing back via `route_back_to = analysis` or `route_back_to = draft`, re-run this file against the updated review pack
4. when the review pack is bundled with the analysis and draft artifacts, treat this file as the consistency reference — do not embed review checks inside prose
