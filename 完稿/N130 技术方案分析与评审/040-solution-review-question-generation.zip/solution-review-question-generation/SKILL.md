---
name: solution-review-question-generation
description: generate decision-ready review question packs covering architecture, data, api, security, performance, and risk. triggers on 技术方案初稿.md.
---
# solution-review-question-generation

Produce a decision-ready review question pack, not another solution draft.

Use the shared contract rules in `references/v2-alignment.md`, the chain rules in `references/orchestration.md`, the exact field obligations in `references/exact-contract.md`, and the cross-reference rules in `references/review-consistency-check.md`, and the degradation patterns in `references/downgrade-templates.md`.

When the user provides an external design document that does not follow the `S1` to `S8` canonical structure, fallback rules apply — see the external-doc downgrade example in `references/example-io.md`.


## Trigger conditions
Use when a solution draft or analysis exists and needs structured review questions. Strong triggers:
- `技术方案初稿.md` from 039
- `技术方案分析.md` from 038
- external design documents from other teams
- explicit "prepare review questions" or "what should we review?" requests
- FMEA outputs requiring risk-focused questions

## Standalone rule
Works without upstream 038/039 output. When inputs are sparse:
- Set `readiness: provisional`, `scope: sparse_inputs`
- Use `target_section: external_doc` with `specific_location` for non-canonical documents
- Narrow questions to Q1_CLARIFY and Q4_RISK when evidence is weak
- Probes remain `advisory_only: true` throughout

## role and boundary
This skill is the preferred **step 3 of 3** inside `N130 technical solution analysis and review`.

Stay inside the review-pack boundary:
- convert weak, risky, missing, or under-defended design areas into structured review questions
- help a team decide blockers, owners, due points, and route-back actions
- do not rewrite the full design, generate code, or replace later execution-stage testing and release work

## choose one operating mode
Choose exactly one mode and state it near the top.
Use the canonical mode names first.
- `systematic`: full review pack with broad canonical coverage and probe triggering
- `focused`: concentrate on one area such as risk, security, data migration, or consistency, while still using canonical question fields
- `round_specific`: optimize the pack for a named review round such as first review, second review, or final review
- `retrospective`: use after a review or incident to identify which questions should have been asked earlier

If the input is sparse, continue in `provisional` readiness and ask narrower questions rather than fabricating answers.
When review inputs are incomplete or external-only, apply `references/downgrade-templates.md` together with the external-doc rules in `references/example-io.md`.

## preferred inputs
Treat only user-provided material and traceable upstream outputs as facts.

Strong inputs when present:
- output from `technical-solution-analysis`
- output from `technical-solution-draft-generation`
- `需求漏洞清单.csv`
- prior review notes or unresolved item lists supplied by the user

Also accept requirement docs, problem statements, decision logs, and architecture notes supplied by the user.

Do not rely on private memory, oral context, or assumed implementation history.

## primary job
Turn unresolved, risky, or weakly-supported design areas into structured review questions that help a team decide:
1. what must be answered before proceeding
2. what is a blocker versus a detail
3. who should answer
4. when the answer is needed
5. what evidence supports asking the question
6. whether the issue should route back to analysis or draft

## mandatory output structure
Default to Markdown tables unless the user explicitly wants CSV.
You may add a short blocker summary, but do not replace or rename the canonical question fields below.

### 1. artifact contract header
Start with the shared contract header from `references/v2-alignment.md`.
Set:
- `artifact_type: solution_review_question_pack`
- `step_order: 3_of_3` or `standalone`
- `skill_name: solution-review-question-generation`

### 2. review header
Include:
- `review_pack_id`
- `mode`
- `scope`
- `sources_used`
- `recommended_review_round`

### 3. blocker summary
Before the question table, summarize:
- blocker-like `critical` question count
- `high` question count
- `medium` question count
- `low` question count
- top must-answer items

This summary is supplemental. The canonical question rows must still use the exact v2 criticality enum.


### 4a. machine-readable question schema
Every question row must also be representable as the following YAML structure so N330/N340 can consume without re-parsing prose. Emit all rows in a fenced `yaml` block at the end of the artifact, after the Markdown table.

```yaml
question_id: RQ-001
question_kind: Q4_RISK           # Q1–Q8 canonical enum
target_section: S4               # S1–S8 or external_doc
specific_location: S4.API-ORDER-CREATE
question_text: "..."
context_quote: "..."             # verbatim excerpt or empty string
criticality: critical            # critical | high | medium | low
expected_answer_kind: judgment   # fact | judgment | document_ref | benchmark_data
target_reviewer_role: architect  # architect | security | compliance | dba | sre | pm
for_review_round: 1              # 1 | 2 | 3 | 4 | final
generated_by_probe: P03_failure_of_critical_component  # probe id or null
advisory_only: true
category_tag: reliability        # supplemental grouping hint; does NOT replace criticality
answer:
  answered: false
  answer_text: null
  answered_by: null
  answered_at: null
  satisfactory: null
  follow_up_required: false
  follow_up_question_id: null
```

`category_tag` is supplemental — use for meeting facilitation grouping (e.g. `reliability`, `security`, `data_migration`, `operability`) without replacing canonical enums.



## Probe trigger quick-reference
Only trigger a probe when supporting evidence exists. Default: `advisory_only: true`.

| Probe ID | Trigger when | Elevate to non-advisory when |
|---|---|---|
| `P01_data_consistency_across_services` | multiple services write related data | FMEA rpn ≥ 100 on data consistency failure mode |
| `P02_performance_under_peak_load` | SLO targets missing or floor undefined | performance section has no p99 target |
| `P03_failure_of_critical_component` | single point of failure in architecture | FMEA rpn ≥ 200 on that component |
| `P04_data_migration_safety` | any schema change or data move in S8 | migration has no rollback point |
| `P05_security_boundary_definition` | external-facing APIs or PII in system | auth field missing on any API |
| `P06_compliance_verification` | regulated data (PII/PCI/PHI/financial) | compliance section has no regulation mapping |
| `P07_backward_compatibility` | existing clients or API versioning mentioned | breaking change in S4 with no version bump |
| `P08_operational_readiness` | S7 topology or S8 rollout exists | no runbook or escalation path defined |
| `P09_cost_projections` | infrastructure choices with cost implications | cost estimate section is empty |
| `P10_team_readiness` | new technology stack or skill gap implied | no training or hiring plan mentioned |

## Q1-Q8 application quick-reference
Use exactly one kind per question. Choose based on the intent of the question, not its phrasing.

| Kind | Intent | Example question |
|---|---|---|
| `Q1_CLARIFY` | Resolve ambiguity or missing spec | "What is the maximum order quantity per request — is there a business cap?" |
| `Q2_CHALLENGE` | Push back on a design decision | "Why was eventual consistency chosen over saga + compensation, given the P0 SLO?" |
| `Q3_ALTERNATIVE` | Surface an unexplored option | "Was CQRS considered as an alternative to read replicas for the status query?" |
| `Q4_RISK` | Expose a failure mode or gap | "What happens if the outbox relay is down for >30s — does the order appear stuck?" |
| `Q5_DETAIL` | Request missing design specifics | "What is the exact retry policy for the HR callback — max attempts and backoff?" |
| `Q6_CONSISTENCY` | Flag contradictions between sections | "S4 shows idempotency key on order create, but S6 says idempotency is 'TBD'" |
| `Q7_CRITERIA` | Verify acceptance/exit conditions | "What is the measurable success criterion for the saga compensation test?" |
| `Q8_FUTURE` | Flag known future work or tech debt | "When the team grows to 10+, will the modular monolith need to be extracted?" |

**Probe → kind mapping** (default):
- `P01_data_consistency` → Q4_RISK or Q6_CONSISTENCY
- `P02_performance_under_peak` → Q4_RISK or Q7_CRITERIA
- `P03_failure_of_critical_component` → Q4_RISK
- `P04_data_migration_safety` → Q4_RISK or Q5_DETAIL
- `P05_security_boundary` → Q2_CHALLENGE or Q4_RISK
- `P06_compliance_verification` → Q7_CRITERIA
- `P07_backward_compatibility` → Q1_CLARIFY or Q4_RISK
- `P08_operational_readiness` → Q5_DETAIL or Q7_CRITERIA
- `P09_cost_projections` → Q3_ALTERNATIVE or Q5_DETAIL
- `P10_team_readiness` → Q8_FUTURE

### 4. canonical question rows
Each question must use the exact field names from `references/exact-contract.md`, and the degradation patterns in `references/downgrade-templates.md`.
Do not replace the canonical enums with generalized labels such as blocker, major, minor, or cost-only categories.

### 5. question kind discipline
Use exactly one of these canonical enums for `question_kind`:
- `Q1_CLARIFY`
- `Q2_CHALLENGE`
- `Q3_ALTERNATIVE`
- `Q4_RISK`
- `Q5_DETAIL`
- `Q6_CONSISTENCY`
- `Q7_CRITERIA`
- `Q8_FUTURE`

If you want an internal analyst shorthand such as “validation” or “cost”, mention it in `question_text` or `follow_up_action`, not in place of the canonical enum.

### 6. section targeting discipline
Every question must include:
- `target_section` using `S1` to `S8`, or `external_doc` only when reviewing a non-canonical external design document
- `specific_location`

Questions should point to the most concrete address available, such as `S4.API-ORDER-CREATE` or `S6.performance.targets.throughput`. For `external_doc`, use the document section, page, or paragraph reference such as `§3.2` or `page 5, paragraph 2`.

### 7. evidence and owner discipline
Every question must include:
- `context_quote`
- `expected_answer_kind`
- `target_reviewer_role`
- `for_review_round`
- `generated_by_probe` when probe-triggered

Use the exact answer and role enums from `references/exact-contract.md`, and the degradation patterns in `references/downgrade-templates.md`.
If the user names additional reviewers such as `senior_dev` or `qa`, keep the canonical output enum stable and mention the practical helper in `follow_up_action` if needed.

### 8. answer tracking discipline
Every question must include the canonical `answer` object, even if mostly null at first.
Make `follow_up_required` visible.
If a follow-up is required, include `follow_up_question_id`.

### 9. probe discipline
Use the canonical probe ids:
- `P01_data_consistency_across_services`
- `P02_performance_under_peak_load`
- `P03_failure_of_critical_component`
- `P04_data_migration_safety`
- `P05_security_boundary_definition`
- `P06_compliance_verification`
- `P07_backward_compatibility`
- `P08_operational_readiness`
- `P09_cost_projections`
- `P10_team_readiness`

Trigger the probes that fit the evidence. Do not claim a probe triggered if no supporting evidence exists.

Probe-generated questions carry `advisory_only: true` by default. Probes raise attention, but do not automatically become blockers; `criticality` is still assigned on the evidence, not on the fact that a probe fired. To override, set `advisory_only: false` and explain why in `follow_up_action`.

### 10. route-back and self-check
After the question table, summarize:
- `analysis_return_items`
- `draft_return_items`
- `meeting_agenda_top_items`
- `parked_items`
- the shared node self-check summary


## downstream automation contract
N330 (document generation) and N340 (best-practice capture) consume this skill's output automatically. To support machine consumption:
- emit all canonical question rows as a YAML block after the Markdown table
- keep `question_id` values stable across revisions of the same pack
- do not change `question_kind` or `criticality` after issuance; add a new follow-up row with `follow_up_question_id` on the original instead

## defect and gap handling
If `需求漏洞清单.csv` or equivalent defect material is present, convert relevant items into visible review questions or explicit blockers.
Do not bury defect-driven risk in prose.

## output rules
- every question must be specific and answerable
- keep blocker-like items obvious via sorting and summary, but preserve canonical `criticality` enums
- if evidence is weak, phrase the item as clarification or criteria rather than a confident challenge
- keep canonical field names stable for downstream consumption
- help the meeting reach decisions, not just produce discussion topics

## gate-aware downgrade
Use `references/downgrade-templates.md` as the source of truth for downgrade behavior.
- `blocked`: emit the artifact contract header, blocker summary, minimum next steps, `route_back_to`, and node self-check summary only.
- `constrained`: keep critical and high questions, but mark weak evidence, ownership, or answer state as constrained and attach follow-up actions.
- `provisional`: emit useful review questions, but avoid fake detail in answers, owners, proof, or section targeting.

For non-canonical external design documents, use `target_section: external_doc` and cite the exact page, heading, paragraph, or excerpt in `specific_location`.

## self-check before finishing
Verify all of the following:
- every question uses a canonical `Q1` to `Q8` enum
- every question points to `S1` to `S8` with a concrete `specific_location`, or uses `target_section: external_doc` for non-canonical external documents
- every question has evidence, answer kind, owner, and review round
- canonical answer tracking fields exist
- relevant canonical probes were triggered
- defect items were converted into visible questions or blockers
- node self-check exists
- every rule in `references/review-consistency-check.md` (R1 to R5) passes or its failure is explicitly listed as a blocker
- `rule_results[]` populated with pass | warn | reject | not_applicable
- `blocker_id: B-N130-03` declared when readiness is blocked
- `feedback_signal_to_n005` field populated

## Downstream handoff summary
When the review pack is issued:
- `to_038_analysis` (analysis_return_items): questions requiring constraint or FMEA re-analysis
- `to_039_draft` (draft_return_items): questions requiring S1-S8 section revision
- `to_N330_document_generation`: stable question rows as YAML block for auto-documentation
- `to_N340_best_practice`: closed questions with satisfactory=true captured as reusable patterns



## Industry-standard review patterns
Apply these patterns to deepen review question quality beyond generic checklists.

### Google Design Doc Review patterns
Google's internal design review focuses on: clarity of constraints, falsifiability of decisions, and explicit tradeoffs.

| Google pattern | Key question to ask |
|---|---|
| **Scalability assumptions** | "What happens when load × 10? Which component fails first?" |
| **Consistency model** | "Is the consistency model explicit? Where is eventual consistency acceptable?" |
| **Failure taxonomy** | "What are the top 3 failure modes? What is the recovery procedure for each?" |
| **Rollback strategy** | "If this change needs to be reverted in production, how long does rollback take?" |
| **Dependency graph** | "Which external dependencies are not owned by this team? What is the fallback if each fails?" |
| **Monitoring gap** | "How will we know this is broken in production within 5 minutes?" |
| **Cost of change** | "How expensive is it to change this decision in 6 months?" |

### Amazon Bar Raiser patterns
Amazon's bar raiser focuses on: leadership principles applied to technical decisions, long-term thinking, and customer obsession.

| Amazon pattern | Key question to ask |
|---|---|
| **Customer backward** | "What is the customer experience if this system is down for 1 hour? For 24 hours?" |
| **Working backwards** | "If we wrote the press release for this design, what would it say? What's missing?" |
| **Think big** | "This design works at current scale. At 100× scale, what breaks first?" |
| **Ownership** | "Who owns this in production? Who is on-call? Is that person in this review?" |
| **Frugality** | "What is the estimated monthly cost? Is there a simpler solution at 20% of the cost?" |
| **Dive deep** | "Walk me through what happens when a user submits this form. Step by step. Every hop." |
| **Have backbone** | "Which decision here will be hardest to reverse? Have we stress-tested that decision?" |
| **Earn trust** | "What assumptions are we asking operations to trust? Are they justified?" |

### When to apply industry patterns
- `Q2_CHALLENGE` questions: pull from Google "cost of change" and Amazon "think big" patterns
- `Q4_RISK` questions: pull from Google "failure taxonomy" and Amazon "customer backward" patterns
- `Q7_CRITERIA` questions: pull from Google "falsifiability" and Amazon "dive deep" patterns
- `Q8_FUTURE` questions: pull from Google "scalability assumptions" and Amazon "100× scale" patterns

## Confidence discipline
Questions are evidence-based, not speculative:
- `evidence_strength: confirmed` — backed by direct evidence from the solution artifact
- `evidence_strength: inferred` — raised by probe without direct evidence; always `advisory_only: true`

Separate confirmed blocker questions from inferred advisory questions in the meeting agenda.
## v2 artifact contract additions

```yaml
artifact_schema_version: n130.v2.1.0
skill_name: solution-review-question-generation
produced_event: produced.n130.solution_review_questions.v2
blocker_mapping: B-N130-03
blocker_id: B-N130-03
rule_results:
  - rule_id: R1_q1_to_q8_sections_covered
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R2_blocker_questions_identified
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R3_owners_assigned
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R4_due_points_set
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R5_route_back_actions_present
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R6_fmea_rows_mapped_to_questions
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R7_defect_items_consumed
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R8_node_self_check_present
    severity: warn
    result: pass | warn | reject | not_applicable
feedback_signal_to_n005:
  signal_type: none | recurring_review_failures | design_gap_pattern
  summary: ""
  target_n070_skills:
  - 013-requirement-breakdown
  - 014-business-rule-extraction
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop

## Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| 需求结构拆解.md (013) | L4/L5 rules, open_question_refs[], certainty=待确认 | review question candidates, unresolved business logic |
| 业务规则清单.md (014) | RULE-* open_question_refs[], condition_expr complexity | design clarity questions, rule completeness checks |
| 状态转移图.md (015) | SM-* open_question_refs[], partial machines | state design completeness questions |
| 验收标准.md (032) | open acceptance items, testability=vague | feasibility and testability review questions |
| 需求变更影响分析.md (033) | unresolved impact dimensions | scope and risk review questions |

## route_back_to and eventbus (v2 additions)

```yaml
route_back_to: none | analysis | draft
route_back_to: none | analysis | draft
# none    — review questions issued; downstream may proceed
# analysis — blockers found requiring 038 re-analysis
# draft   — design detail gaps requiring 039 revision
eventbus_subscribers: [N330, N340]
# N330 subscribes to auto-generate 方案评审问题清单文档
# N340 subscribes to capture review findings as reusable best-practice
```
