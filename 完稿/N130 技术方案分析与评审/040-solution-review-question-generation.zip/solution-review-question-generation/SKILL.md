---
name: solution-review-question-generation
description: generate structured technical review questions from requirements, analysis, and design drafts. use for standalone design review, review meeting prep, pre-release gate review, or step 3 of the n130 chain when technical-solution-analysis, technical-solution-draft-generation, or 需求漏洞清单.csv must become canonical q1-q8 review questions, evidence-backed probes, answer tracking, and route-back actions rather than another design draft.
---
# solution-review-question-generation

Produce a decision-ready review question pack, not another solution draft.

Use the shared contract rules in `references/v2-alignment.md`, the chain rules in `references/orchestration.md`, the exact field obligations in `references/exact-contract.md`, and the cross-reference rules in `references/review-consistency-check.md`, and the degradation patterns in `references/downgrade-templates.md`.

When the user provides an external design document that does not follow the `S1` to `S8` canonical structure, fallback rules apply — see the external-doc downgrade example in `references/example-io.md`.

## role and boundary
This skill is the preferred **step 3 of 3** inside `N130 technical solution analysis and review`.

Stay inside the review-pack boundary:
- convert weak, risky, missing, or under-defended design areas into structured review questions
- help a team decide blockers, owners, due points, and route-back actions
- do not rewrite the full design, generate code, or replace later execution-stage testing and release work

## choose one operating mode
Choose exactly one mode and state it near the top.
Use the canonical mode names first.
- `systematic`: full review pack with broad canonical coverage and probe triggering
- `focused`: concentrate on one area such as risk, security, data migration, or consistency, while still using canonical question fields
- `round_specific`: optimize the pack for a named review round such as first review, second review, or final review
- `retrospective`: use after a review or incident to identify which questions should have been asked earlier

If the input is sparse, continue in `provisional` readiness and ask narrower questions rather than fabricating answers.
When review inputs are incomplete or external-only, apply `references/downgrade-templates.md` together with the external-doc rules in `references/example-io.md`.

## preferred inputs
Treat only user-provided material and traceable upstream outputs as facts.

Strong inputs when present:
- output from `technical-solution-analysis`
- output from `technical-solution-draft-generation`
- `需求漏洞清单.csv`
- prior review notes or unresolved item lists supplied by the user

Also accept requirement docs, problem statements, decision logs, and architecture notes supplied by the user.

Do not rely on private memory, oral context, or assumed implementation history.

## primary job
Turn unresolved, risky, or weakly-supported design areas into structured review questions that help a team decide:
1. what must be answered before proceeding
2. what is a blocker versus a detail
3. who should answer
4. when the answer is needed
5. what evidence supports asking the question
6. whether the issue should route back to analysis or draft

## mandatory output structure
Default to Markdown tables unless the user explicitly wants CSV.
You may add a short blocker summary, but do not replace or rename the canonical question fields below.

### 1. artifact contract header
Start with the shared contract header from `references/v2-alignment.md`.
Set:
- `artifact_type: solution_review_question_pack`
- `step_order: 3_of_3` or `standalone`
- `skill_name: solution-review-question-generation`

### 2. review header
Include:
- `review_pack_id`
- `mode`
- `scope`
- `sources_used`
- `recommended_review_round`

### 3. blocker summary
Before the question table, summarize:
- blocker-like `critical` question count
- `high` question count
- `medium` question count
- `low` question count
- top must-answer items

This summary is supplemental. The canonical question rows must still use the exact v2 criticality enum.

### 4. canonical question rows
Each question must use the exact field names from `references/exact-contract.md`, and the degradation patterns in `references/downgrade-templates.md`.
Do not replace the canonical enums with generalized labels such as blocker, major, minor, or cost-only categories.

### 5. question kind discipline
Use exactly one of these canonical enums for `question_kind`:
- `Q1_CLARIFY`
- `Q2_CHALLENGE`
- `Q3_ALTERNATIVE`
- `Q4_RISK`
- `Q5_DETAIL`
- `Q6_CONSISTENCY`
- `Q7_CRITERIA`
- `Q8_FUTURE`

If you want an internal analyst shorthand such as “validation” or “cost”, mention it in `question_text` or `follow_up_action`, not in place of the canonical enum.

### 6. section targeting discipline
Every question must include:
- `target_section` using `S1` to `S8`, or `external_doc` only when reviewing a non-canonical external design document
- `specific_location`

Questions should point to the most concrete address available, such as `S4.API-ORDER-CREATE` or `S6.performance.targets.throughput`. For `external_doc`, use the document section, page, or paragraph reference such as `§3.2` or `page 5, paragraph 2`.

### 7. evidence and owner discipline
Every question must include:
- `context_quote`
- `expected_answer_kind`
- `target_reviewer_role`
- `for_review_round`
- `generated_by_probe` when probe-triggered

Use the exact answer and role enums from `references/exact-contract.md`, and the degradation patterns in `references/downgrade-templates.md`.
If the user names additional reviewers such as `senior_dev` or `qa`, keep the canonical output enum stable and mention the practical helper in `follow_up_action` if needed.

### 8. answer tracking discipline
Every question must include the canonical `answer` object, even if mostly null at first.
Make `follow_up_required` visible.
If a follow-up is required, include `follow_up_question_id`.

### 9. probe discipline
Use the canonical probe ids:
- `P01_data_consistency_across_services`
- `P02_performance_under_peak_load`
- `P03_failure_of_critical_component`
- `P04_data_migration_safety`
- `P05_security_boundary_definition`
- `P06_compliance_verification`
- `P07_backward_compatibility`
- `P08_operational_readiness`
- `P09_cost_projections`
- `P10_team_readiness`

Trigger the probes that fit the evidence. Do not claim a probe triggered if no supporting evidence exists.

Probe-generated questions carry `advisory_only: true` by default. Probes raise attention, but do not automatically become blockers; `criticality` is still assigned on the evidence, not on the fact that a probe fired. To override, set `advisory_only: false` and explain why in `follow_up_action`.

### 10. route-back and self-check
After the question table, summarize:
- `analysis_return_items`
- `draft_return_items`
- `meeting_agenda_top_items`
- `parked_items`
- the shared node self-check summary

## defect and gap handling
If `需求漏洞清单.csv` or equivalent defect material is present, convert relevant items into visible review questions or explicit blockers.
Do not bury defect-driven risk in prose.

## output rules
- every question must be specific and answerable
- keep blocker-like items obvious via sorting and summary, but preserve canonical `criticality` enums
- if evidence is weak, phrase the item as clarification or criteria rather than a confident challenge
- keep canonical field names stable for downstream consumption
- help the meeting reach decisions, not just produce discussion topics

## gate-aware downgrade
Use `references/downgrade-templates.md` as the source of truth for downgrade behavior.
- `blocked`: emit the artifact contract header, blocker summary, minimum next steps, `route_back_to`, and node self-check summary only.
- `constrained`: keep critical and high questions, but mark weak evidence, ownership, or answer state as constrained and attach follow-up actions.
- `provisional`: emit useful review questions, but avoid fake detail in answers, owners, proof, or section targeting.

For non-canonical external design documents, use `target_section: external_doc` and cite the exact page, heading, paragraph, or excerpt in `specific_location`.

## self-check before finishing
Verify all of the following:
- every question uses a canonical `Q1` to `Q8` enum
- every question points to `S1` to `S8` with a concrete `specific_location`, or uses `target_section: external_doc` for non-canonical external documents
- every question has evidence, answer kind, owner, and review round
- canonical answer tracking fields exist
- relevant canonical probes were triggered
- defect items were converted into visible questions or blockers
- node self-check exists
- every rule in `references/review-consistency-check.md` (R1 to R5) passes or its failure is explicitly listed as a blocker
