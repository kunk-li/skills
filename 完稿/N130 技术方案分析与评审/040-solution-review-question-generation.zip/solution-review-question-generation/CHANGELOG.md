<!-- skill_version: 2.0.4 -->
# Changelog · solution-review-question-generation

All notable changes to this skill will be recorded here.
Follow `MAJOR.MINOR.PATCH` — break canonical schema only on MAJOR bumps.

## how to read this file

- **schema-breaking**: canonical enum, field name, or required field changed in a way downstream consumers must adapt to
- **schema-additive**: new optional field or new enum value; existing consumers keep working
- **non-schema**: wording, docs, examples, internal rules

## [2.0.4] - 2026-04-24

### added · non-schema
- machine-readable CHANGELOG marker `<!-- skill_version: 2.0.4 -->` for tools that need the skill version without adding non-standard SKILL.md frontmatter fields.

### changed · non-schema
- removed duplicate checklist bullets in `references/checklist.md` introduced by overlapping patch insertion.
- strengthened SKILL.md trigger description with review-meeting-prep and pre-release-gate contexts.
- rewrote gate-aware downgrade guidance to delegate to `references/downgrade-templates.md` as the source of truth for `blocked`, `constrained`, and `provisional` outputs.
- updated the self-check language so `target_section: external_doc` is accepted for non-canonical external design documents.

## [2.0.3] - 2026-04-24

### changed · non-schema
- removed `version` from `SKILL.md` frontmatter so the entrypoint uses only deployment-safe `name` and `description`; semantic version history now lives in this CHANGELOG
- corrected `for_review_round` guidance back to the canonical N130 values `1`, `2`, `3`, `4`, or `final`; optional human labels may be added in supplemental fields, not as replacements
- synchronized `target_section: external_doc` across `SKILL.md`, `exact-contract.md`, `checklist.md`, and `review-consistency-check.md` for non-canonical external design docs

### added · non-schema
- `references/downgrade-templates.md` with separate `blocked`, `constrained`, and `provisional` output patterns for sparse-input handling

## [2.0.2] - 2026-04-24

### added · schema-additive
- `references/review-consistency-check.md` with machine-checkable rules R1 to R5:
  - R1 every probe-generated question must carry a matching `generated_by_probe` id from the canonical `P01` to `P10` set
  - R2 every `follow_up_question_id` must reference an existing `question_id` in the same pack
  - R3 initially used named round labels (`round_1` to `round_4` or `final`); superseded in 2.0.3 by canonical N130 values `1`, `2`, `3`, `4`, or `final`
  - R4 every `target_section` that is not `external_doc` must resolve to a canonical `S1` to `S8` id
  - R5 every `advisory_only: false` probe question must include a `follow_up_action` explaining the elevation
- `self-check before finishing` gained a bullet requiring every R1 to R5 rule to pass or be listed as a blocker

### clarified · non-schema
- main `SKILL.md` points out that non-canonical design docs follow fallback rules in `example-io.md` (external-doc path) rather than forcing `S1` to `S8` targeting
- this CHANGELOG file

## [2.0.1] - 2026-04-23

### added · schema-additive
- `version: 2.0.0` in frontmatter (superseded in 2.0.3; version history now lives in CHANGELOG)
- `advisory_only: true` as the default flag on every probe-generated question; override to `false` only with `follow_up_action` rationale
- `references/exact-contract.md` gained an `advisory_only` note in the canonical probes section

### added · non-schema
- `example-io.md` gained a `## downgrade example · external design doc only` section with guidance on using `target_section: external_doc` and paragraph-level `specific_location`

## [2.0.0] - 2026-04-23 · canonical contract lock

### added · schema-breaking (first canonical lock)
- `references/exact-contract.md` as the machine-readable contract
- canonical `question_kind` enum `Q1_CLARIFY` · `Q2_CHALLENGE` · `Q3_ALTERNATIVE` · `Q4_RISK` · `Q5_DETAIL` · `Q6_CONSISTENCY` · `Q7_CRITERIA` · `Q8_FUTURE`
- canonical probe ids `P01_data_consistency_across_services` · `P02_performance_under_peak_load` · `P03_failure_of_critical_component` · `P04_data_migration_safety` · `P05_security_boundary_definition` · `P06_compliance_verification` · `P07_backward_compatibility` · `P08_operational_readiness` · `P09_cost_projections` · `P10_team_readiness`
- canonical reviewer role enum `architect` · `security` · `compliance` · `dba` · `sre` · `pm`
- canonical answer tracking object `answered` · `answered_by` · `answered_at` · `satisfactory` · `follow_up_required` · `follow_up_question_id`
- required `target_section` and `specific_location` for every question

### changed · schema-breaking
- `question_kind` migrated from earlier shorthand (`CLARIFY` / `CHALLENGE` / `COMPLETE` / `RISK` / `VALIDATION` / `ALTERNATIVE` / `PRIOR_ART` / `COST`) to the v2 canonical `Q1` to `Q8` ids; note `Q6_CONSISTENCY` is new and has no direct predecessor
- probe family reworked from SRE-centric ids (SPOF, thundering herd, race condition, clock skew, cold start, observability blind spot) to the review-centric `P01` to `P10` set shown above

### added · non-schema
- operating modes: `systematic` · `focused` · `round_specific` · `retrospective`
- `references/v2-alignment.md` with shared registry discipline
- `analysis_return_items` · `draft_return_items` · `meeting_agenda_top_items` · `parked_items` route-back handoff block

## [1.x] - superseded

pre-contract drafts; not tracked here.
