# CHANGELOG

## v4.1.0 (2026-07-08) — R6 flag-and-resolve exclusion (bar7 false-positive guard)

_skill: solution-review-question-generation_

### Added
- `references/review-consistency-check.md` R6 · flag-and-resolve exclusion: a version/cross-module/deprecated/ADR conflict question must first check whether the source doc already reconciles the item (clean deprecation + replacement / in-doc ADR reconciliation / resolved 勘误); resolved items are excluded (optionally `excluded_as_resolved`), only genuinely unreconciled residue is raised. A conflict question naming a resolved item is a false positive → reject.
- SKILL.md self-check bullet mirroring R6 + updated the consistency-rule range to R1–R6.

### Why
- Shakedown finding (2026-07-08): the same critique behavior had a variable false-positive rate across runs — a run that applied the flag-and-resolve exclusion (B2/N1) was clean; a run that did not (G_payroll) raised ~40% resolved-items as conflicts. R6 makes the exclusion a mandated self-check instead of run-random.

## v4.0.0 (2026-04-30) — v10 final optimization

_skill: solution-review-question-generation_

### Added
- Trigger conditions + Standalone rule sections
- Confidence discipline (confirmed/inferred/pending separation)
- Downstream handoff summary
- Compatibility-map.md with field-level input/output mapping
- blocked + degraded example-io scenarios

### Changed
- Description trimmed to ≤25 words
- Quick-reference tables expanded to ≥4 per skill
- rule_results expanded to R01-R08

### Fixed
- CHANGELOG format standardized to `# CHANGELOG` header
- Chinese/English section headers unified to English

---

## v3.0.0 (2026-04-30) — v5 optimization batch

### Added
- common-failure-modes.md with Symptom/Fix format (F1–F8)
- workflow-position.md
- compatibility-map.md
- CHANGELOG.md

### Changed
- Checklist rewritten with inline `- [ ]` items
- example-io.md expanded with concrete YAML examples
- Description word count reduced

---

## v2.0.0 (2026-01-15) — v2 contract migration

### Added
- artifact_schema_version header
- produced_event field
- blocker_mapping field
- rule_results[] with pass|warn|reject|not_applicable
- feedback_signal_to_n005 reverse governance channel

---

## v1.0.0 (2025-10-01) — initial release
