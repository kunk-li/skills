---
name: business-rule-extraction
description: extract reusable rule catalogs from requirement and process material with stable rule ids, semantic rule types, constraint strength, machine-readable condition expressions, dependency refs, lifecycle metadata, and negative examples. use when the source describes validation, approval, timing, compliance, concurrency, idempotency, escalation, or blocker logic and the result must work both as a standalone rule baseline and as a joinable artifact with requirement, state, permission, and object outputs.
---
# business-rule-extraction

Extract reviewable and machine-friendly rule units from the source. Do not leave rule logic trapped inside prose.

## N070 stage metadata / 阶段元数据
- `n070_stage`: `2`
- `depends_on`: `['013']`
- `blocks`: `['016']`
- `may_consume`: `['017']`
- Note: actual SKILL.md frontmatter must stay validator-compatible (`name` and `description` only), so the stage metadata is placed in the body top section instead of YAML frontmatter.

## Role / 角色定位
Produce a rule baseline that answers:
- what rule units exist
- what semantic kind each rule belongs to
- which rules are hard constraints versus ordinary business rules
- what machine-readable condition can be derived
- what negative examples, dependencies, and lifecycle signals exist

## Single-skill value / 单独使用价值
- 仅基于 PRD 或流程文档即可独立产出规则目录。
- 即使没有 requirement-breakdown，也要给出稳定 rule rows、执行方、负例与待确认项。
- 单独使用时也必须产出 `negative_examples`，防止规则只有正向 happy path。

## Multi-skill value / 组合使用价值
- 与 requirement-breakdown 对齐对象、角色、领域。
- 与 state-transition-mapping 对齐阻断条件、时间触发、补偿路径。
- 与 permission-matrix-extraction 对齐授权约束、deny 优先与合规规则。
- 与 data-object-identification 对齐规则作用对象、配置依赖与数据约束。
- 当规则作用对象带 `audit_required` tag 时，相关规则的 `hardness` 不应低于 `constraint`；若证据不足，明确标记待确认而不是静默降级。

## Allowed inputs / 允许输入
- 主输入：PRD、流程说明、策略说明、制度规则说明。
- 可选输入：需求结构树、状态流转表、权限矩阵、对象清单。
- 可选输入：全局上下文文档，仅用于全局禁用、合规要求、统一术语和 SLA 约束。

## Required row contract
每条 rule 尽量包含：
- `rule_id`
- `domain`
- `title`
- `rule_semantic`
- `hardness`
- `object_or_scope`
- `applicable_subject`
- `condition_text`
- `condition_expr`
- `action`
- `failure_result`
- `exception_or_escalation`
- `depends_on[]`
- `negative_examples[]`
- `lifecycle`
- `decision_refs[]`
- `blocker_refs[]`
- `open_question_refs[]`
- `certainty`
- `evidence`

枚举要求：
- `rule_semantic`: `business / temporal / concurrency / idempotency / compensation / rate_limit / compliance`
- `hardness`: `constraint / rule / guideline / preference`

## Condition expression rules
- 优先保留 `condition_text` 作为自然语言原文。
- 在可机器化时补 `condition_expr`。
- Canonical form is **yaml mapping**; optional human-writing form is **text function**.
- YAML mapping examples: `{'AND': [{'eq': ['ticket.state', 'SUBMITTED']}, {'in': ['ticket.tags', ['URGENT', 'COMPLIANCE']]}]}`
- Text function examples: `AND { eq(ticket.state, SUBMITTED), in(ticket.tags, [URGENT, COMPLIANCE]) }`
- `references/dsl-parser.py` is the reference implementation for YAML-form validation and optional textual parsing.
- 若无法安全结构化，不要硬凑 DSL；保留 `condition_text` 并将 `condition_expr` 记为 `未明确`。

## Negative example rules
- `business` 类至少 1 个 negative
- `compliance` 类至少 3 个 negative 或说明为何证据不足
- `temporal` 类至少覆盖“边界时刻 + 边界之外”
- `idempotency` 类至少覆盖“同 key 同 payload”和“同 key 不同 payload”

## Global validation rule ids / 全局校验规则编号
- Canonical references for this skill's validation rules:
- `014.R00_evidence_required`
- `014.R01_semantic_required`
- `014.R02_negative_required`
- `014.R03_constraint_level_compliance`
- `014.R04_dsl_parse`
- `014.R05_temporal_requires_window`
- When old notes or logs mention a short name like `R03`, interpret it through the list above; the global id is the canonical reference from v2.1.2 onward.

## Workflow / 执行流程
1. 通读文档，定位所有条件、门控、时间、审批、阻断、例外、恢复、升级语句。
2. 一条规则语义对应一条 row，避免把多条规则压成一句话。
3. 给每条规则分配稳定 `rule_id`，没有显式 id 时按 `{RULE-domain-nnn}` 生成。
4. 判定 `rule_semantic` 与 `hardness`。
5. 提取 `condition_text`，可机器化时再补 `condition_expr`。
6. 识别 `depends_on[]`，包括配置、阈值、外部规则和外部常量。
7. 为每条规则补 `negative_examples[]`。
8. 抽取 `lifecycle` 与 cross-skill refs。
9. 用 `references/output-template.md` 输出，并参照 `references/interoperability-contract.md` 做 join 友好检查。

## Output / 默认输出契约
- 默认 `full_mode`
- 面向产品或评审时可给 `csv` / `table_mode`
- 面向规则引擎时可追加 `drools-like` 或 `machine_mode`
- 需要版本回放时启用 `diff_mode`

## Boundary rules / 边界规则
- 跟随输入主语言输出。
- 不翻译错误码、状态值、API 名、字段名。
- 证据格式：`[doc_id]§[section].L[start]-L[end]`
- 确定性只允许：`明确写明 / 基于上下文推断 / 待确认`

## Evidence anchor contract / 证据锚点契约
- Canonical anchor format: `[doc_id]§[section].L[start]-L[end]`
- Canonical YAML-safe regex pattern: `'\[[^\]]+\]§[^.]+\.L\d+(-L\d+)?'`
- Prefer a single-quoted YAML scalar when documenting or exporting the regex to avoid escape ambiguity across parsers.
- Evidence must point to the source that actually supports the row; do not use a nearby paragraph as a placeholder.


## Workflow v2 artifact contract
```yaml
artifact_type: n070.business-rule-extraction
schema_version: "1.0.0"
producer_skill: business-rule-extraction
consumer_nodes: [N090, N100, N150, N230]
workflow_alias: 业务规则清单.md
produced_event_name: produced.n070.business-rule-extraction
canonical_fields:
  - rule_id        # RULE-{domain}-{nnn}
  - hardness       # constraint / rule / guideline / preference
  - condition_expr # DSL 条件表达式（经 dsl-parser.py 验证）
  - outcome
  - negative_examples
  - certainty
  - evidence
n005_consumption: indirect
```


## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认，并参照 `references/scoring-rubric.md` 做质量自评。确认已完成：
- 所有必填字段已填写，无静默缺失
- 使用了 N070 标准 ID 命名空间（REQ-/RULE-/SM-/PERM-/OBJ-）
- 证据锚点格式符合 `[doc_id]§[section].L[start]-L[end]`
- certainty 只使用：明确写明 / 基于上下文推断 / 待确认

## Key references
- `../013-requirement-breakdown/requirement-breakdown/references/node-guide.md`：**N070 节点导航——5 个 skill 执行顺序、跨 skill 契约、与 N080 交接规则（必读，见 013）**
- `../013-requirement-breakdown/requirement-breakdown/references/handoff-to-n080.md`：N070→N080 节点交接协议（词汇对齐规则 + ready_for_n090 信号，见 013）

- `references/scoring-rubric.md`：**규칙 质量量化评分公式 + L1-L5 判别决策树 + 规则类型分类决策树（constraint/rule/guideline/preference）+ 边界 case 表（必读）**
- `references/dsl-parser.py`：**condition_expr DSL 验证器（必读，含语法约束和错误类型）**
- `references/dsl-parser-tests.py`：DSL 测试用例（边界场景参考）
- `references/interoperability-contract.md`：N070 跨 skill 命名空间契约
- `references/output-template.md`：输出结构
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
