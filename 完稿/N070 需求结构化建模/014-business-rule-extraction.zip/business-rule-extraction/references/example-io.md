# Example I/O Pattern

## Input pattern
A PRD states that only approved orders may enter settlement, settlement must finish within 24 hours, and failed settlement should trigger manual review.

## Good output pattern
- one eligibility rule stating only approved orders may enter settlement
- one SLA rule stating settlement must finish within 24 hours
- one exception rule stating failed settlement triggers manual review
- evidence attached to each rule

## Bad output pattern
"The system supports settlement after approval and includes manual review for failures."

The bad output is descriptive but not structured enough for review or implementation.
