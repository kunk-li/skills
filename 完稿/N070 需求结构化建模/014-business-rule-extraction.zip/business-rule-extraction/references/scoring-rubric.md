# Scoring Rubric

## 1 - weak
Mostly narrative summary. Rules are incomplete, mixed together, or missing negative outcomes.

## 2 - usable with rework
Core rules are visible, but timing rules, exception paths, or evidence binding are inconsistent.

## 3 - review-ready
Rules are structured, classified, source-grounded, and detailed enough for product review or design discussion.

## 4 - implementation-ready
Rules are precise enough to support design, QA case derivation, and policy review with minimal clarification.

Aim for at least 3.
