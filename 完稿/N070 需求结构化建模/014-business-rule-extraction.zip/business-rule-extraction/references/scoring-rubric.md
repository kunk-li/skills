# Scoring Rubric

## 1 - weak
Mostly narrative summary. Rules are incomplete, mixed together, or missing negative outcomes.

## 2 - usable with rework
Core rules are visible, but timing rules, exception paths, or evidence binding are inconsistent.

## 3 - review-ready
Rules are structured, classified, source-grounded, and detailed enough for product review or design discussion.

## 4 - implementation-ready
Rules are precise enough to support design, QA case derivation, and policy review with minimal clarification.

Aim for at least 3.

---

## 边界 Case 对照表 / Boundary Case Reference

| Case | 描述 | 正确处理 | 常见误判 | 判别理由 |
|---|---|---|---|---|
| 条件为"始终" | 规则无任何条件（如"所有订单必须记录日志"） | L5 Constraint，hardness=constraint | L4 Rule | 无例外分支，条件为 always/all |
| 多步 if/else | 规则有嵌套条件（如"若金额>1000 且角色=审计员则..."） | L4 Rule，condition_expr=(amount>1000 AND role=auditor) | L5 | 有明确可表达的条件分支 |
| 互斥的两条规则 | 规则 A 和 B 在相同条件下结果相反 | 不发出其中任一，转为 027 冲突条目 | 选一保留 | 矛盾证据应升级处理 |
| 业务规则 vs 技术约束 | "密码须加密存储"是技术实现而非业务规则 | 排除，不纳入 RULE-* | 纳入作为 L5 | 技术实现细节不属于业务规则 |
| 软约束 | "建议使用实名注册"（非强制） | hardness=guideline | hardness=constraint | 有"建议/推荐"等弱化词 |
| 规则提及但无定义 | 文档说"按公司审批流程"但未展开 | 纳入，certainty=待确认，放 open_questions | 推断展开 | 不得基于常识补全业务规则 |
| 相同效果不同触发 | 两条规则触发不同但结果相同 | 分别记录，各自的 condition_expr 不同 | 合并为一条 | 触发路径不同的规则不得合并 |

### DSL 边界场景

| 场景 | DSL 表达 | 注意事项 |
|---|---|---|
| 时间窗口 | `(now - created_at) > 7d` | 需指定时区基准 |
| 角色组合 | `role IN [admin, finance]` | 枚举值需来自 016 权限矩阵 |
| 历史状态 | `previous_status == approved` | 历史行为难以在 DSL 中稳定表达，标注 certainty=待确认 |
| 并发条件 | `concurrent_requests >= 3` | 标注 implementation_note: "需事务锁/幂等设计" |

---

## 业务规则质量量化评分 / Rule Quality Scoring

```
rule_quality_score = 100 - (
  missing_condition_expr × 15 +     # 无 condition_expr 字段
  vague_trigger × 10 +              # 触发条件为"通常""一般"等模糊词
  missing_negative_example × 8 +   # 无 negative_example
  missing_hardness × 5 +            # 未指定 hardness（constraint/rule/guideline/preference）
  unverifiable_outcome × 12 +       # 执行结果无法用 if/else 验证
  missing_evidence × 8             # 无证据锚点（evidence 为空）
)
clip to [0, 100]
```

| rule_quality_score | 等级 |
|---:|---|
| ≥ 85 | implementation-ready（可直接指导开发） |
| 70–84 | review-ready（可评审，需补充细节） |
| 50–69 | usable with rework（基本可用，需补充） |
| < 50 | weak（需重写） |

## 规则类型分类决策树 / Rule Classification Decision Tree

```
Q1: 这条规则是否**无条件成立**（不存在任何例外路径）？
    YES → hardness = constraint（L5 级）
    NO  → Q2

Q2: 这条规则是否可以用 if/else 精确表达？
    YES → Q3
    NO  → 可能是 guideline 或描述性说明，不作为 RULE-* 发出

Q3: 违反这条规则是否会导致**系统错误或业务中断**？
    YES → hardness = rule（强制，L4 级）
    NO  → Q4

Q4: 这条规则是否被明确要求但允许特定角色豁免？
    YES → hardness = rule，注明豁免条件
    NO  → hardness = guideline 或 preference

Q5（规则类型）: 这条规则的核心是什么？
    时间/顺序约束（先做A再做B，超时X分钟）→ temporal_rule
    资源/容量约束（最多N个，配额X）        → capacity_rule
    角色/权限约束（只有A角色才能做）       → permission_rule（优先归 016）
    计算/推导逻辑（结果=输入A×参数B）      → computation_rule
    状态转移逻辑（当状态为X且条件Y时转为Z）→ state_rule（与 015 协同）
    其他条件分支                           → conditional_rule
```

## 边界 Case 对照表

| Case | hardness | 常见误判 | 判别信号 |
|---|---|---|---|
| "密码至少 8 位" | constraint | rule | 无条件，无例外 |
| "VIP 用户免运费" | rule | constraint | 有条件（身份判断），有例外（非 VIP） |
| "建议填写手机号" | guideline | rule | 有"建议"等弱化词 |
| "首次登录显示引导" | preference | rule | 可选，不影响核心流程 |
| "试错 5 次锁定 15 分钟" | rule | constraint | 有明确的 if（次数条件） |
| "GDPR 数据须在 EU 存储" | constraint | rule | 法规强制，无例外 |
