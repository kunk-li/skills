## Stage metadata
- n070_stage: 2
- depends_on: ['013']
- blocks: ['016']
- may_consume: ['017']

# Orchestration

## Upstream inputs
- PRD text
- optionally, `需求结构树.md` from requirement-breakdown output when it helps identify business objects and actors

## Downstream consumers
- state-transition-mapping
- permission-matrix-extraction
- N090 / N100 / N110 / N150 / N170 / N230 / N260 as `业务规则清单.csv` consumers
- review or design documents
- QA case design

## Handoff guidance
- keep object names and actor names stable across outputs
- preserve evidence so downstream skills can cross-check rules against source text
- when a rule depends on a state change, reference the relevant state or lifecycle section explicitly

---

## N070 共同契约

### Object name alignment contract (C1)
- Canonical source: **requirement-breakdown §4 "核心业务对象"** table.
- This skill MUST use object names from the canonical source in the "对象或领域" field of the rule catalog.
- If this skill discovers new objects not in the canonical source, tag them as "new object (not in breakdown)".
- If a name conflict is detected, append an "Object name alignment" table at end of output.

### N070 execution stage (C3)
- This skill executes in **stage 2** of N070 internal pipeline (parallel with data-object-identification and state-transition-mapping).
- Must wait for stage 1 (requirement-breakdown) to complete.
- Output is consumed by stage 3 (permission-matrix-extraction).

### CSV handoff contract (C4)
- Output filename: `业务规则清单.csv`
- Required downstream meaning: each row should be stable enough to be joined by object / actor / rule category with `状态流转表.csv` and `权限矩阵.csv`.
- Recommended direct consumers: N090 / N100 / N110 / N150 / N170 / N230 / N260.
