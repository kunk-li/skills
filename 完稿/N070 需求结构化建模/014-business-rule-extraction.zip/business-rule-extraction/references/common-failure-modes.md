# Common Failure Modes

- summarizing the workflow instead of extracting rule units
- omitting blocked outcomes, rejection reasons, or rollback behavior
- mixing actions, statuses, permissions, and approvals into one vague sentence
- keeping time limits in prose instead of a dedicated timing table
- treating recommendations or product preferences as mandatory rules
- inventing thresholds, owners, or fallback logic not written in the source
- failing to separate happy path from exception, arbitration, or escalation path

## Failure mode 8: global prohibitions treated as regular rules
Symptom: permanent bans, ghost entities, or system-wide red lines are buried inside ordinary validation rules or omitted.
Fix: extract them into the dedicated permanent prohibition section and classify the prohibition type.

## Failure mode 9: channel-blind rules
Symptom: a rule that only applies to one channel or client type is written as if it applies everywhere.
Fix: use the “适用渠道” field explicitly whenever the source shows channel-specific behavior.

## Failure mode 10: cross-module conflict hidden
Symptom: two rules from different modules or a module rule and a global rule can conflict, but the conflict table only lists same-module conflicts.
Fix: in the conflict section, classify the pair as same-module, cross-module, or module-vs-global and record both owners.
