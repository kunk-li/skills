"""Reference implementation for N070 SKILL-014 condition_expr DSL.
Supports canonical YAML mapping validation and optional textual parsing.
Textual parsing uses lark when available; YAML validation works without external deps.
"""
from __future__ import annotations

from typing import Any, List, Tuple
import re

LOGICAL_OPS = {"AND", "OR", "NOT"}
COMPARISON_OPS = {"eq", "ne", "lt", "lte", "gt", "gte", "in", "matches"}
TEMPORAL_OPS = {"before", "after", "within"}
ALL_OPS = LOGICAL_OPS | COMPARISON_OPS | TEMPORAL_OPS

ERROR_CODES = {
    "DSL_001": "unknown operator",
    "DSL_002": "invalid field path",
    "DSL_003": "temporal anchor or window missing",
    "DSL_004": "logical expression contains an empty clause list",
    "DSL_005": "type mismatch or malformed operand",
}

class DSLError(Exception):
    def __init__(self, code: str, path: str, detail: str = "") -> None:
        self.code = code
        self.path = path
        self.detail = detail
        super().__init__(self.__str__())

    def __str__(self) -> str:
        return f"[{self.code}] at {self.path}: {ERROR_CODES[self.code]} {self.detail}".strip()


def _is_ident(token: str) -> bool:
    return bool(re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", token))


def _valid_field(field: Any) -> bool:
    if not isinstance(field, str) or not field:
        return False
    return all(_is_ident(part) for part in field.split('.'))


def validate_yaml_form(expr: Any, path: str = '$') -> List[DSLError]:
    errors: List[DSLError] = []
    if not isinstance(expr, dict):
        return [DSLError('DSL_005', path, f'expected dict, got {type(expr).__name__}')]
    if len(expr) != 1:
        return [DSLError('DSL_005', path, 'expression must have exactly one key')]
    op, operand = next(iter(expr.items()))
    if op not in ALL_OPS:
        return [DSLError('DSL_001', path, f'unknown op: {op}')]
    if op in LOGICAL_OPS:
        return _validate_logical(op, operand, f'{path}.{op}')
    if op in COMPARISON_OPS:
        return _validate_comparison(op, operand, f'{path}.{op}')
    return _validate_temporal(op, operand, f'{path}.{op}')


def _validate_logical(op: str, operand: Any, path: str) -> List[DSLError]:
    if op == 'NOT':
        sub = operand.get('expr', operand) if isinstance(operand, dict) else operand
        if not isinstance(sub, dict):
            return [DSLError('DSL_005', path, 'NOT expects one sub-expression')]
        return validate_yaml_form(sub, path + '.expr')
    if not isinstance(operand, list):
        return [DSLError('DSL_005', path, f'{op} expects a list')]
    if not operand:
        return [DSLError('DSL_004', path)]
    errors: List[DSLError] = []
    for i, sub in enumerate(operand):
        errors.extend(validate_yaml_form(sub, f'{path}[{i}]'))
    return errors


def _validate_comparison(op: str, operand: Any, path: str) -> List[DSLError]:
    if not isinstance(operand, list) or len(operand) != 2:
        return [DSLError('DSL_005', path, f'{op} expects [field, value]')]
    field, value = operand
    errors: List[DSLError] = []
    if not _valid_field(field):
        errors.append(DSLError('DSL_002', path, f'invalid field: {field!r}'))
    if op == 'in' and not isinstance(value, list):
        errors.append(DSLError('DSL_005', path, 'in expects a value list'))
    return errors


def _validate_temporal(op: str, operand: Any, path: str) -> List[DSLError]:
    if op in {'before', 'after'}:
        if not isinstance(operand, list) or len(operand) != 2:
            return [DSLError('DSL_003', path, f'{op} expects [event_a, event_b]')]
        return []
    if not isinstance(operand, list) or len(operand) != 2:
        return [DSLError('DSL_003', path, 'within expects [event_or_clock, [from, to]]')]
    _, window = operand
    if not isinstance(window, list) or len(window) != 2:
        return [DSLError('DSL_003', path, 'within window must be [from, to]')]
    return []


def yaml_to_textual(expr: Any) -> str:
    if not isinstance(expr, dict) or len(expr) != 1:
        raise ValueError('expression must be a single-key dict')
    op, operand = next(iter(expr.items()))
    if op == 'NOT':
        sub = operand.get('expr', operand) if isinstance(operand, dict) else operand
        return f"NOT {yaml_to_textual(sub)}"
    if op in {'AND', 'OR'}:
        if not isinstance(operand, list):
            raise ValueError(f'{op} expects list operand')
        inner = ', '.join(yaml_to_textual(sub) for sub in operand)
        return f"{op} {{ {inner} }}"
    if op in COMPARISON_OPS:
        field, value = operand
        return f"{op}({field}, {value})"
    if op in {'before', 'after'}:
        left, right = operand
        return f"{op}({left}, {right})"
    if op == 'within':
        clock, window = operand
        return f"within({clock}, [{window[0]}, {window[1]}])"
    raise ValueError(f'unknown op {op}')


def parse_textual(text: str) -> Tuple[Any, List[DSLError]]:
    try:
        from lark import Lark  # type: ignore
    except Exception:
        return None, [DSLError('DSL_001', '$', 'lark is not installed; textual parsing is unavailable in this environment')]

    grammar = r'''
        start: expr
        ?expr: logical_expr | comparison_expr | temporal_expr
        logical_expr: "AND" "{" expr ("," expr)* "}"
                    | "OR" "{" expr ("," expr)* "}"
                    | "NOT" expr
        comparison_expr: COMP_OP "(" field "," value ")"
        temporal_expr: TEMP_OP "(" field "," field ")"
                     | "within" "(" field "," "[" value "," value "]" ")"
        field: CNAME ("." CNAME)*
        value: CNAME | SIGNED_NUMBER | ESCAPED_STRING | list_value
        list_value: "[" value ("," value)* "]"
        COMP_OP: "eq"|"ne"|"lt"|"lte"|"gt"|"gte"|"in"|"matches"
        TEMP_OP: "before"|"after"
        %import common.CNAME
        %import common.SIGNED_NUMBER
        %import common.ESCAPED_STRING
        %import common.WS
        %ignore WS
    '''
    parser = Lark(grammar, start='start')
    try:
        tree = parser.parse(text)
        return tree, []
    except Exception as exc:
        return None, [DSLError('DSL_001', '$', str(exc))]
