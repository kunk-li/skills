# Checklist

Before finalizing, verify:
- every strong rule statement is represented as a structured rule unit, not buried in prose
- conditions, thresholds, limits, and failure outcomes are not omitted
- timing rules are separated from general business rules
- exception and escalation paths are extracted separately from happy-path rules
- any error code, error message, or explicit rejection reason is preserved
- permission restrictions are kept as rules only when the PRD actually specifies them
- missing thresholds, missing owners, and missing recovery conditions are called out as gaps
- no rule is invented from common sense or undocumented product assumptions
- 当全局上下文包含永久禁用概念时，是否提取为独立的"永久禁用规则"？
- 当全局上下文包含幽灵实体时，是否提取为独立的"幽灵实体规则"？
- 多端架构下，是否在规则表标注了适用渠道？
- 是否检查了跨模块规则冲突（当 PRD 引用其他模块规则时）？
- 是否区分了业务 SLA / 合规 SLA / 系统 SLA？
- 对象名称是否与 requirement-breakdown 的 §4 "核心业务对象" 保持一致？
- 证据字段是否使用了 `[doc_id]§[section].L[start]-L[end]` 统一锚点格式？
