import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location('dsl_parser', Path(__file__).with_name('dsl-parser.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

VALID = {
    'AND': [
        {'eq': ['ticket.state', 'SUBMITTED']},
        {'in': ['ticket.tags', ['URGENT', 'COMPLIANCE']]},
    ]
}

INVALID_EMPTY = {'AND': []}
INVALID_OP = {'unknown_op': ['x', 'y']}

assert mod.validate_yaml_form(VALID) == []
assert mod.validate_yaml_form(INVALID_EMPTY)[0].code == 'DSL_004'
assert mod.validate_yaml_form(INVALID_OP)[0].code == 'DSL_001'
assert mod.yaml_to_textual({'NOT': {'expr': {'eq': ['state', 'DONE']}}}) == 'NOT eq(state, DONE)'

INVALID_FIELD = {'eq': ['ticket-state', 'SUBMITTED']}
INVALID_IN = {'in': ['ticket.tags', 'URGENT']}
INVALID_WITHIN = {'within': ['now', 'tomorrow']}
INVALID_NOT = {'NOT': ['bad']}
INVALID_NON_DICT = ['eq', 'x', 'y']

assert mod.validate_yaml_form(INVALID_FIELD)[0].code == 'DSL_002'
assert mod.validate_yaml_form(INVALID_IN)[0].code == 'DSL_005'
assert mod.validate_yaml_form(INVALID_WITHIN)[0].code == 'DSL_003'
assert mod.validate_yaml_form(INVALID_NOT)[0].code == 'DSL_005'
assert mod.validate_yaml_form(INVALID_NON_DICT)[0].code == 'DSL_005'

textual, errs = mod.parse_textual('AND { eq(ticket.state, SUBMITTED), in(ticket.tags, [URGENT, COMPLIANCE]) }')
assert (textual is not None and errs == []) or (textual is None and errs and errs[0].code == 'DSL_001')

print('dsl-parser-tests: ok')
