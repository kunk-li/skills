# 输出模板 / output template

## 1. 摘要 / Summary
- 覆盖规则域
- 规则语义分布
- 硬约束数量
- 最大规则缺口

## 2. 输出模式 / Output mode
| mode | 是否输出 | 说明 |
|---|---|---|
| table_mode |  | 核心规则目录 |
| full_mode |  | 完整规则视图 |
| machine_mode |  | 机器可消费结构 |
| diff_mode |  | 版本差异视图 |
| csv / drools-like |  | 可选增强 |

## 3. rule catalog
| rule_id | domain | title | rule_semantic | hardness | object_or_scope | applicable_subject | condition_text | condition_expr | action | failure_result | exception_or_escalation | depends_on | introduced_in | status | deprecated_in | decision_refs | blocker_refs | open_question_refs | certainty | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## 4. negative examples / 反例与边界
| rule_id | negative_type | input_or_scenario | expected_result | expected_error_or_state | boundary_note | evidence |
|---|---|---|---|---|---|---|

说明：
- `negative_type` 可用 `boundary / invalid_order / invalid_payload / forbidden_access / duplicate / timeout / conflict / other`

## 5. timing, concurrency, and idempotency focus
| rule_id | rule_semantic | trigger_or_window | concurrency or replay behavior | blocking outcome | recovery or compensation | evidence |
|---|---|---|---|---|---|---|

## 6. dependencies and external constants / 依赖引用链
| rule_id | dependency_type | dependency_ref | owner_or_source | hot_reload | impact if changed | evidence |
|---|---|---|---|---|---|---|

说明：
- `dependency_type` 可用 `config_key / rule_ref / external_policy / threshold / schedule / other`

## 7. conflict pairs and precedence / 冲突与优先级
| rule_a | rule_b | conflict_type | precedence or missing policy | risk | next action | evidence |
|---|---|---|---|---|---|---|

## 8. gaps and unresolved items / 缺口与待确认
| type | rule_ref | issue | downstream impact | next action |
|---|---|---|---|---|

## 9. optional cross-skill links / 可选跨 skill 回指
| rule_id | req_refs | sm_refs | perm_refs | obj_refs | alignment_note |
|---|---|---|---|---|---|

## 10. condition_expr canonical form
- Canonical storage form: YAML mapping
- Optional human-writing form: textual function call
- Use `references/dsl-parser.py` to validate YAML form and to parse textual form when needed
