---
name: state-transition-mapping
description: map reviewable state machines from requirement and process material with stable machine ids, explicit multi-machine separation, trigger kinds, transition kinds, invariants, orthogonal relationships, lifecycle metadata, and downstream-ready refs. use when the source describes statuses, lifecycles, approvals, checkpoints, timers, compensations, or recoveries and the result must stand alone as a state baseline while also joining cleanly with requirement, rule, permission, and object outputs.
---
# state-transition-mapping

Model stateful behavior from the source. Do not collapse several machines into one flat table.

## N070 stage metadata / 阶段元数据
- `n070_stage`: `2`
- `depends_on`: `['013']`
- `blocks`: `['016']`
- `may_consume`: `['017', '014']`
- Note: actual SKILL.md frontmatter must stay validator-compatible (`name` and `description` only), so the stage metadata is placed in the body top section instead of YAML frontmatter.

## Role / 角色定位
Produce a state baseline that answers:
- which state machines exist
- which ones are orthogonal or parallel
- what transitions are normal, compensating, recovering, or time-driven
- what invariants must always hold
- what is still missing for a safe state model

## Single-skill value / 单独使用价值
- 仅基于 PRD 或流程文档即可独立建立状态模型。
- 即使证据不完整，也要输出 partial machine、阻断迁移和待确认项。
- 单独使用时也必须给出 `trigger_kind`、`transition_kind` 与 `invariants`，不要只输出 from/to 表。

## Multi-skill value / 组合使用价值
- 与 business-rule-extraction 对齐触发条件、阻断规则、时间窗口、补偿逻辑。
- 与 requirement-breakdown 对齐对象名和 capability 边界。
- 与 permission-matrix-extraction 对齐状态相关权限变化。
- 与 data-object-identification 对齐状态主体对象和 append-only / snapshot 等对象属性。

## Allowed inputs / 允许输入
- 主输入：PRD、流程图文本、状态说明、审批流说明。
- 可选输入：需求结构树、业务规则清单、权限矩阵、对象清单。
- 可选输入：全局上下文，仅用于禁用主体、系统级红线、共用角色约束。

## Required machine contract
每个 machine 尽量包含：
- `machine_id`
- `domain`
- `entity`
- `orthogonal_with[]`
- `initial`
- `terminal[]`
- `states[]`
- `invariants[]`
- `lifecycle`
- `decision_refs[]`
- `blocker_refs[]`
- `open_question_refs[]`

每条 transition 尽量包含：
- `from`
- `to`
- `trigger`
- `trigger_kind`
- `transition_kind`
- `actor`
- `preconditions`
- `side_effects[]`
- `blocked_by[]`
- `recovery_note`
- `certainty`
- `evidence`

固定枚举：
- `trigger_kind`: `user / scheduled / system / external / composite`
- `transition_kind`: `forward / rollback / recovery / timeout`

## Invariant rules
- `invariants[]` 表示跨迁移始终成立的约束，不是普通迁移。
- 若文档只说明“任何情况下不得修改/删除/逆转”，优先建模为 invariant，而不是生造伪状态。

## Global validation rule ids / 全局校验规则编号
- Canonical references for this skill's validation rules:
- `015.R00_evidence_required`
- `015.R01_single_initial`
- `015.R02_terminal_no_outgoing`
- `015.R03_trigger_kind_required`
- `015.R04_invariant_enforcement`
- `015.R05_rollback_has_origin`
- When old notes or logs mention a short name like `R03`, interpret it through the list above; the global id is the canonical reference from v2.1.2 onward.

## Workflow / 执行流程
1. 先识别所有 stateful objects。
2. 一个对象一台 machine，不得混表。
3. 给每台 machine 分配稳定 `machine_id`；没有显式 id 时按 `{SM-domain-nnn}` 生成。
4. 抽取 explicit states，再判断 inferred states 和 control checkpoints。
5. 为每条 transition 标注 `trigger_kind` 与 `transition_kind`。
6. 抽取 machine 级 `invariants[]`。
7. 若存在并行状态维度，填写 `orthogonal_with[]`。
8. 若兄弟 skill 可用，补 cross refs 与 coverage hooks。
9. 使用 `references/output-template.md` 输出。

## Output / 默认输出契约
- 默认 `full_mode`
- 单机或人审场景建议补 `mermaid stateDiagram-v2`
- 需要自动化消费时输出 `machine_mode`
- 需要版本回放时启用 `diff_mode`

## Boundary rules / 边界规则
- 跟随输入主语言输出。
- 不翻译状态值、事件键、错误码、字段名。
- 证据格式：`[doc_id]§[section].L[start]-L[end]`
- 确定性只允许：`明确写明 / 基于上下文推断 / 待确认`

## Evidence anchor contract / 证据锚点契约
- Canonical anchor format: `[doc_id]§[section].L[start]-L[end]`
- Canonical YAML-safe regex pattern: `'\[[^\]]+\]§[^.]+\.L\d+(-L\d+)?'`
- Prefer a single-quoted YAML scalar when documenting or exporting the regex to avoid escape ambiguity across parsers.
- Evidence must point to the source that actually supports the row; do not use a nearby paragraph as a placeholder.


## Workflow v2 artifact contract
```yaml
artifact_type: n070.state-transition-mapping
schema_version: "1.0.0"
producer_skill: state-transition-mapping
consumer_nodes: [N090, N100, N160]
workflow_alias: 状态转移图.md
produced_event_name: produced.n070.state-transition-mapping
canonical_fields:
  - sm_id          # SM-{domain}-{nnn}
  - object
  - states[]
  - transitions[]
  - orthogonal_with[]
  - sync_constraints[]
  - invariants[]
  - gaps[]
n005_consumption: indirect
```


## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认，并参照 `references/scoring-rubric.md` 做质量自评。确认已完成：
- 所有必填字段已填写，无静默缺失
- 使用了 N070 标准 ID 命名空间（REQ-/RULE-/SM-/PERM-/OBJ-）
- 证据锚点格式符合 `[doc_id]§[section].L[start]-L[end]`
- certainty 只使用：明确写明 / 基于上下文推断 / 待确认

## Key references
- `../013-requirement-breakdown/requirement-breakdown/references/node-guide.md`：**N070 节点导航——5 个 skill 执行顺序、正交状态机识别规则参见 orthogonal-detection.md（必读，见 013）**
- `../013-requirement-breakdown/requirement-breakdown/references/handoff-to-n080.md`：N070→N080 节点交接协议（见 013）

- `references/orthogonal-detection.md`：**正交状态机识别决策树 + 同步约束格式（必读）**
- `references/scoring-rubric.md`：**状态机完整性量化评分公式 + L1-L5 判别决策树（见 013 scoring-rubric.md）+ 正交状态机识别决策树（见 orthogonal-detection.md）（必读）**
- `references/interoperability-contract.md`：N070 跨 skill 命名空间契约
- `references/output-template.md`：输出结构
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
