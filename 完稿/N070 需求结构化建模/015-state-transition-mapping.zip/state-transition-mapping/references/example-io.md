# Example I/O Pattern

## Input pattern
A PRD states that a request starts as draft, becomes submitted after confirmation, can be rejected during review, and becomes active after approval. If data validation fails, submission is blocked.

## Good output pattern
- one state machine object for the request
- state definitions for draft, submitted, rejected, active
- a transition from draft to submitted triggered by confirmation
- a blocked transition note for failed validation
- evidence attached to each item

## Bad output pattern
"The request goes through draft, review, and approval, with validation checks."

The bad output is too loose for state modeling.
