# Scoring Rubric

## 1 - weak
Only a narrative lifecycle summary. States and transitions are mixed, incomplete, or object ownership is unclear.

## 2 - usable with rework
Main states are present, but blocked paths, side effects, or completeness checks are inconsistent.

## 3 - review-ready
Objects, states, transitions, blockers, and gaps are structured clearly enough for product or design review.

## 4 - implementation-ready
The model is precise enough to inform API design, schema design, workflow validation, or QA flow derivation.

Aim for at least 3.

---

## 边界 Case 对照表 / Boundary Case Reference

| Case | 描述 | 正确处理 | 常见误判 | 判别理由 |
|---|---|---|---|---|
| 一个对象多个状态机 | 订单有"审批状态"和"支付状态"两套独立状态机 | orthogonal_with[]，两个 SM-* 相互引用 | 合并为一个状态机 | 不同维度的状态机应分开 |
| 状态机层次嵌套 | "进行中"状态下有子状态"处理中/等待确认" | sub_machine_of，子状态机 SM-B 的 parent=SM-A | orthogonal_with | 子状态机仅存在于父状态内 |
| 触发器是另一对象的状态变化 | 支付完成 → 触发订单进入"待发货" | transition.trigger_event 引用 SM-PAY 的 terminal state | 直接写"支付完成" | 跨对象触发需保持可追溯 |
| 单向依赖 vs 正交 | 审批通过才允许支付启动 | prerequisite_machines[]=SM-APPROVAL，不是正交 | orthogonal_with | 有顺序依赖的不是正交关系 |
| 状态死端 | 某状态无任何出路 | 列为 gap，放 open_questions，blocking=major | 忽略 | 死端状态意味着对象永远卡住 |
| 隐含终态 | 文档未明确说明终态（如"订单取消后如何"） | 推断为终态并标注 certainty=待确认 | 直接省略 | 终态缺失是结构性风险 |
| 并行区域 | 两个子流程同时执行（如签名 AND 付款） | parallel_regions[]，两个区域可独立完成 | 顺序执行 | 并行不等于正交 |

### invariant vs precondition 判别

| 特征 | invariant | precondition |
|---|---|---|
| 时机 | 在整个状态期间始终成立 | 仅在进入状态之前成立 |
| 违反后果 | 系统错误或告警 | 阻止进入该状态 |
| 示例 | "locked 状态下 balance 不变" | "余额 > 0 才可进入 active" |

---

## 状态机完整性量化评分 / State Machine Quality Scoring

```
state_machine_score = 100 - (
  missing_terminal_state × 20 +   # 无终态（对象永远无法退出）
  dead_end_state × 15 +           # 存在无出路的非终态
  missing_trigger × 10 +          # 状态转移无触发条件
  missing_invariant × 8 +         # 高风险状态无 invariant 约束
  unlinked_sm × 12 +              # SM-* 未被任何 REQ-* 引用
  orthogonal_not_declared × 10   # 并行状态机未声明 orthogonal_with[]
)
clip to [0, 100]
```

| state_machine_score | 等级 |
|---:|---|
| ≥ 85 | implementation-ready（可直接指导 API/schema 设计）|
| 70–84 | review-ready |
| 50–69 | usable with gaps |
| < 50 | weak（需重写）|

### 完整性核查清单（定量标准）

| 检查项 | 合格条件 |
|---|---|
| 终态覆盖 | 每个 SM-* 至少有 1 个 terminal=true 状态 |
| 转移可达性 | 从初态出发可达所有非孤立状态 |
| 触发器完整 | 每条 transition 有 trigger_event 或 trigger_condition |
| 需求溯源 | 每个 SM-* 被至少 1 条 REQ-* 引用 |
| 正交声明 | 共享同一实体的并行 SM 互相声明 orthogonal_with[] |
