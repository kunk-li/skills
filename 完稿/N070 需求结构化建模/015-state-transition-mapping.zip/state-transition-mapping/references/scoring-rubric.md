# Scoring Rubric

## 1 - weak
Only a narrative lifecycle summary. States and transitions are mixed, incomplete, or object ownership is unclear.

## 2 - usable with rework
Main states are present, but blocked paths, side effects, or completeness checks are inconsistent.

## 3 - review-ready
Objects, states, transitions, blockers, and gaps are structured clearly enough for product or design review.

## 4 - implementation-ready
The model is precise enough to inform API design, schema design, workflow validation, or QA flow derivation.

Aim for at least 3.
