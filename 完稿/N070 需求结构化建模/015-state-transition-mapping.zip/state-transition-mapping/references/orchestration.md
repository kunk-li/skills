## Stage metadata
- n070_stage: 2
- depends_on: ['013']
- blocks: ['016']
- may_consume: ['017', '014']

# Orchestration

## Upstream inputs
- PRD text
- optionally, `需求结构树.md` from requirement-breakdown output
- optionally, `业务规则清单.csv` from business-rule-extraction output when rules clarify blockers or exception paths

## Downstream consumers
- permission-matrix-extraction
- N090 / N100 / N110 / N150 / N170 / N230 / N260 as `状态流转表.csv` consumers
- review or design documents
- schema or API discussions
- QA flow design

## Handoff guidance
- keep object names stable across sections
- keep evidence attached so downstream consumers can trace each transition to source text
- when a transition depends on rules, point to the relevant rule statement rather than rephrasing loosely

---

## N070 共同契约

### Object name alignment contract (C1)
- Canonical source: **requirement-breakdown §4 "核心业务对象"** table.
- This skill's "对象" field in §2 state machine objects MUST use object names from the canonical source.
- New objects not in the canonical source must be tagged "new object (not in breakdown)".

### N070 execution stage (C3)
- This skill executes in **stage 2** of N070 internal pipeline (parallel with data-object-identification and business-rule-extraction).
- Must wait for stage 1 (requirement-breakdown) to complete.
- May optionally consume business-rule-extraction output (from same stage) when available.
- Output is consumed by stage 3 (permission-matrix-extraction).

### CSV handoff contract (C4)
- Output filename: `状态流转表.csv`
- Required downstream meaning: transitions must preserve object / from-state / event / to-state / exception evidence so permission, API, and QA stages can consume it directly.
- Recommended direct consumers: N090 / N100 / N110 / N150 / N170 / N230 / N260.
