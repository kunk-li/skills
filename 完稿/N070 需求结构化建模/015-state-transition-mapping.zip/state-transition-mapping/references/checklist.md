# Checklist

Before finalizing, verify:
- each state belongs to a specific object
- different objects are not merged into one state machine by convenience
- states are not confused with actions or events
- blocked, forbidden, timeout, rollback, and recovery paths are extracted where present
- side effects are attached to states or transitions when the source specifies them
- terminal or archive states have aftermath notes if the PRD mentions them
- unsupported assumptions are labeled as inferences or unresolved items
- states or transitions that are missing from the source are not invented
- 是否检查了跨模块状态依赖（当前迁移是否依赖另一模块的状态）？
- 多端架构下，是否区分了渠道特有的状态或迁移？
- 是否在完整性检查中排除了幽灵触发主体（全局上下文中已注销的角色）？
- 对象名称是否与 requirement-breakdown 的 §4 "核心业务对象" 保持一致？
- 证据字段是否使用了 `[doc_id]§[section].L[start]-L[end]` 统一锚点格式？
