# Common Failure Modes

- assuming the document contains only one state machine
- mixing business states, workflow states, and governance states without labeling them
- treating actions such as submit, approve, notify, or retry as states
- omitting blocked or forbidden transitions because the happy path looks complete
- missing side effects caused by a transition
- inventing rollback or recovery paths that the source does not define
- failing to flag unresolved entry, exit, or terminal conditions

## Failure mode 8: cross-module state coupling flattened
Symptom: an object transition actually depends on another module’s state, but the transition table only records local preconditions.
Fix: fill the dedicated cross-module prerequisite fields and validate that the prerequisite state is defined somewhere authoritative.

## Failure mode 9: channel-merged state machine
Symptom: the web and mobile clients have different state flows, but they are merged into one undifferentiated state machine.
Fix: either split into multiple state machines or tag states and transitions with the applicable channel.

## Failure mode 10: ghost actor triggers
Symptom: a trigger actor references a role or entity that has already been retired by the global context, so the transition can never happen in practice.
Fix: include a ghost-trigger check when global context is available and compare every trigger actor against the authoritative actor list.
