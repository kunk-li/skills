# Orthogonal state-machine detection

Use this reference when stateful behavior may contain more than one machine for
the same domain area, such as lifecycle state plus approval state, retention
state, retry/replay state, or timer/checkpoint state.

## Detection rules

1. Split machines when two state axes can change independently.
2. Split machines when each axis has a different trigger source, clock, owner,
   or rollback/compensation rule.
3. Keep machines separate when one axis is append-only/audit-oriented and the
   other is mutable workflow state.
4. Do not merge a timer, retention, replay, or reconciliation checkpoint into a
   business approval lifecycle unless the source explicitly says they share the
   same state enum.
5. If the source is ambiguous, emit separate provisional machines and mark the
   relationship as `pending_source_confirmation`; do not silently flatten.

## Required output signals

- `orthogonal_relationships[]`
- `machine_pair`
- `relationship_type`: `independent_parallel` | `gated_by` | `synchronized_checkpoint` | `pending_source_confirmation`
- `shared_entity_or_aggregate`
- `independent_triggers[]`
- `cross_machine_invariants[]`
- `handoff_to_n080`

## Quality checks

- Every machine still has stable states and transitions.
- Cross-machine invariants are explicit instead of hidden in prose.
- Pending ambiguity is surfaced as a blocker or handoff, not guessed away.
