# 输出模板 / output template

## 1. 摘要 / Summary
- 状态机数量
- 是否存在正交/并行状态机
- 不变式数量
- 最大建模缺口

## 2. 输出模式 / Output mode
| mode | 是否输出 | 说明 |
|---|---|---|
| table_mode |  | 核心机器与迁移 |
| full_mode |  | 完整机器视图 |
| machine_mode |  | `machines[]` 结构 |
| diff_mode |  | 版本差异 |
| mermaid |  | 可视化增强 |

## 3. machine catalog
| machine_id | domain | entity | initial | terminal | orthogonal_with | introduced_in | status | decision_refs | blocker_refs | certainty | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|

## 4. state definitions / 状态定义
### 4.1 [machine_id]
| state | node_type | business_meaning | entry_condition | exit_condition | terminal_flag | certainty | evidence |
|---|---|---|---|---|---|---|---|

## 5. invariants / 状态不变式
| machine_id | invariant_id | invariant_expr | violation_impact | likely implementation hook | evidence |
|---|---|---|---|---|---|

## 6. transitions / 状态迁移
### 6.1 [machine_id]
| from | to | trigger | trigger_kind | transition_kind | actor | preconditions | side_effects | blocked_by | recovery_note | certainty | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|

## 7. blocked and forbidden transitions / 阻断迁移
| machine_id | from | blocked_action_or_transition | blocking_rule_or_condition | result | recovery_path | evidence |
|---|---|---|---|---|---|---|

## 8. completeness and modeling gaps / 完整性检查
| machine_id | gap_type | description | risk | next action |
|---|---|---|---|---|

## 9. optional cross-skill links / 可选跨 skill 回指
| machine_id | related_req_refs | related_rule_refs | related_perm_refs | related_obj_refs | alignment_note |
|---|---|---|---|---|---|
