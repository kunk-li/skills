# 组合互操作契约 / interoperability contract

所有 N070 结构化分析 skill 共享以下最小互操作契约。该契约的目标是：
- 保证单个 skill 在没有兄弟产物时也能独立运行
- 保证多个 skill 组合时可以机器 join，而不是只能人工对照
- 保证输出在任何业务系统中都可复用，不依赖 Phase 1 私有术语

## 1. shared id namespace
默认前缀：
- `REQ-` requirement-breakdown
- `RULE-` business-rule-extraction
- `SM-` state-transition-mapping
- `PERM-` permission-matrix-extraction
- `OBJ-` data-object-identification

推荐格式：`{prefix}-{domain}-{nnn}`，如 `REQ-AUTH-001`、`OBJ-ORDER-003`。

如果源文档没有显式编号，可按首次出现顺序生成稳定 id；不要为了追求完美而省略 id。

## 2. shared linkage fields
所有五个 skill 的核心行项目都应尽量包含以下字段：
- `domain`
- `decision_refs[]`
- `blocker_refs[]`
- `open_question_refs[]`
- `certainty`
- `evidence`
- `lifecycle.introduced_in`
- `lifecycle.status`
- `lifecycle.deprecated_in`
- `lifecycle.change_history[]`

规则：
- 若源文档没有版本演化信息，`introduced_in`、`deprecated_in` 可写 `未明确`。
- 若没有显式决议编号，不要伪造；写空列表 `[]`。
- `certainty` 只允许：`明确写明` / `基于上下文推断` / `待确认`。

## 2.1 evidence anchor regex
Canonical YAML-safe regex pattern for `evidence`:
- `'\[[^\]]+\]§[^.]+\.L\d+(-L\d+)?'`

Guidance:
- Prefer a single-quoted YAML scalar when documenting or exporting the pattern.
- Keep the regex stable across all five skills so coverage tooling can validate anchors consistently.

## 2.2 global validation rule ids
From v2.1.2 onward, validation rules should be referenced by a global id such as `013.R01_grain_hierarchy` rather than an ambiguous short name like `R01`.

## 3. shared constraint strength
当某条记录带有规则/限制色彩时，优先增加强度字段：
- 若当前 skill 已定义专属字段名，则使用专属字段名（例如 `business-rule-extraction` 使用 `hardness`）
- 否则可沿用通用字段名 `constraint_strength`
- 枚举保持一致：`constraint / rule / guideline / preference`

不要把系统级硬约束与普通业务路由规则混写为同一强度。

## 4. shared output modes
所有 skill 默认支持以下输出模式：
- `table_mode`: 核心字段，便于人审
- `full_mode`: 全字段，便于追溯
- `machine_mode`: JSON/YAML 友好结构，便于下游自动化
- `diff_mode`: 带 change_history 的版本差异视图

skill 可额外扩展自己的专属模式，但不得删除以上四类基础模式。

## 5. single-skill fallback
当没有兄弟 skill 输出时：
- 仍必须交付一个自洽的主产物
- 对象、角色、规则、状态、资源命名可标记为 `source-derived`
- 允许缺少 cross-skill refs，但不得因为缺少上游而拒绝输出

## 6. combo-mode join rules
当兄弟 skill 结果存在时：
- requirement-breakdown 提供优先对象名、角色名、领域名
- business-rule-extraction 提供规则语义、负例、时间/幂等等可执行约束
- state-transition-mapping 提供状态机、触发器、不变式
- permission-matrix-extraction 提供主体-资源-动作-效果裁决
- data-object-identification 提供对象边界、storage、ddd_role、constraint_tags

若兄弟 skill 之间口径冲突：
1. 先保留冲突，不要静默覆盖
2. 在输出中增加 `alignment_note` / `conflict_note`
3. 在 coverage 报告中列出冲突项

## 7. coverage report
当同一轮分析中可获得多个兄弟产物时，补充 `coverage_report`，至少检查：
- `orphan_objects`: 每个 `OBJ-*` 是否至少被一条 `REQ-*` 引用
- `requirements_without_rules`: 每条可执行 `REQ-*` 是否至少对应一条 `RULE-*`
- `unlinked_state_machines`: 每个 `SM-*` 是否在需求结构中出现
- `unlinked_roles`: 每个 `PERM-*` 主体是否可回指到需求或规则

若无法完成覆盖检查，明确写 `coverage not executed` 并说明缺失输入。
