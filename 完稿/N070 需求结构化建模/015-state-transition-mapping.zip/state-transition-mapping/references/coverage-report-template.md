# coverage report template

| check | description | pass/fail | orphan or gap items | action |
|---|---|---|---|---|
| orphan_objects | every `OBJ-*` is referenced by at least one `REQ-*` |  |  |  |
| requirements_without_rules | every executable `REQ-*` is backed by at least one `RULE-*` |  |  |  |
| unlinked_state_machines | every `SM-*` appears in requirement structure |  |  |  |
| unlinked_roles | every permission subject can be traced to requirement or rule context |  |  |  |
| unresolved_conflicts | cross-skill naming or ownership conflicts remain |  |  |  |
