# 输出模板 / output template

## 1. 摘要 / Summary
- 权限域范围
- 主体类型分布
- 字段级/实例级控制覆盖情况
- 最大授权缺口

## 2. 输出模式 / Output mode
| mode | 是否输出 | 说明 |
|---|---|---|
| table_mode |  | 核心权限矩阵 |
| full_mode |  | 完整权限基线 |
| machine_mode |  | 机器可消费结构 |
| diff_mode |  | 版本差异 |
| rbac_csv / abac_json / xacml |  | 可选增强 |

## 3. resource taxonomy / 资源分类
| resource | domain | resource_type | grain_supported | likely owner | source_of_truth | certainty | evidence |
|---|---|---|---|---|---|---|---|

## 4. subjects / 权限主体
| subject | subject_kind | description | delegation_or_derivation | certainty | evidence |
|---|---|---|---|---|---|

## 5. permission matrix / 权限矩阵
| perm_id | domain | subject | subject_kind | resource | grain | channel | action | permission_layer | scope | condition | effect_summary | evaluation_algo | introduced_in | status | decision_refs | blocker_refs | certainty | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## 6. field policies / 字段级策略
| perm_id | resource | action | field_allow | field_deny | field_mask | mask_rule | evidence |
|---|---|---|---|---|---|---|---|

## 7. delegation and derived access / 委托与派生身份
| perm_id | subject_kind | source_identity | token_or_basis | ttl_or_validity | acting_as | audit_level | evidence |
|---|---|---|---|---|---|---|---|

## 8. relational constraints / 关系权限约束
| perm_id | constraint_type | relational_constraint | violation_result | evidence |
|---|---|---|---|---|

## 9. access control precedence / allow deny 裁决
| perm_id | effect | priority | reason | condition | evidence |
|---|---|---|---|---|---|

## 10. state-dependent permission changes / 状态相关权限变化
| perm_id | state_or_stage | permission_change | reason | evidence |
|---|---|---|---|---|

## 11. approval and high-risk controls / 审批与高风险动作
| action | initiator | approver | extra_control | blocking_condition | audit_requirement | evidence |
|---|---|---|---|---|---|---|

## 12. gaps and conflicts / 缺口与冲突
| type | ref | issue | downstream impact | next action |
|---|---|---|---|---|

## 13. optional cross-skill links / 可选跨 skill 回指
| perm_id | req_refs | rule_refs | sm_refs | obj_refs | alignment_note |
|---|---|---|---|---|---|
