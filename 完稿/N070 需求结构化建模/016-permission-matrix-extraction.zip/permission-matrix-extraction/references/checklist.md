# Checklist

Before finalizing, confirm all items below:

- [ ] Subjects were identified separately from resources and actions
- [ ] Permissions were normalized into subject-resource-action rows where possible
- [ ] Permission layers were separated instead of merged into generic prose
- [ ] Scope qualifiers were captured explicitly
- [ ] State-based permission changes were extracted when present
- [ ] Approval authority was separated from ordinary action rights
- [ ] High-risk controls were identified when present
- [ ] Notification recipients were not mistaken for authorized actors
- [ ] UI visibility was not treated as a full permission model without evidence
- [ ] Gaps, ambiguities, and conflicts were listed explicitly
- [ ] 当前模块权限是否依赖其他模块的 RBAC 执行？如是，是否填写了"权限执行方"和"执行方模块"字段？
- [ ] 多端架构下，是否填写了 §5.5 "渠道差异化权限"章节？
- [ ] 全局上下文中的系统级绝对禁止动作是否录入了高风险控制表并标注"系统级绝对禁止"等级？
- [ ] 资源名与业务对象名是否与 requirement-breakdown 的 §4 "核心业务对象" 保持一致？
- [ ] 证据字段是否使用了 `[doc_id]§[section].L[start]-L[end]` 统一锚点格式？
