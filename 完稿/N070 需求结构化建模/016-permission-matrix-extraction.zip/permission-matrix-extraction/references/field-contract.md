# field contract

Use the following meanings consistently.

- `subject`: the actor, role, delegated identity, derived identity, or context identity that may hold a permission
- `subject_kind`: one of `role` / `delegated` / `derived` / `context`
- `resource`: the thing being accessed or controlled
- `grain`: one of `resource` / `field` / `instance`
- `channel`: one of `public_api` / `internal_api` / `admin_ui` / `ops_cli` / `scheduled` / `callback` / `未明确`
- `action`: the operation performed on the resource
- `permission_layer`: one of `入口权限` / `数据可见性` / `编辑/审批权限` / `控制/管理权限` / `系统执行` / `流程职责`
- `scope`: the boundary limiting where the permission applies
- `condition`: prerequisites such as state, ownership, workflow stage, approval result, region, or risk level
- `effect`: one of `allow` / `deny` / `restricted` / `escalate` / `未明确`
- `priority`: numeric or ordinal precedence used when allow and deny coexist
- `evaluation_algo`: one of `deny-overrides` / `allow-overrides` / `first-applicable` / `未明确`
- `field_policy`: field-level allow/deny/mask policy for `grain = field`
- `delegation`: delegated identity contract for `subject_kind = delegated`
- `relational_constraint`: object-to-object or actor-to-object separation rules such as maker-checker or self-approval forbidden
- `evidence`: the source wording or precise paraphrase supporting the row
