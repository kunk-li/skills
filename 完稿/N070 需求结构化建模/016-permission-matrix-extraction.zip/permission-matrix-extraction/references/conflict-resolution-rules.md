# Permission Conflict Resolution Rules / 权限冲突解析规则

本文件是 `field-contract.md` 的补充，定义当同一访问请求匹配多条权限规则时，如何在 **channel × subject × grain** 三维组合下确定最终 effect。

---

## 1. 单维度评估顺序 / Single-Dimension Evaluation Order

每条权限规则由三个定位维度构成：`channel`、`subject_kind`（主体类型）、`grain`（粒度）。

评估时按以下**特异性降序**排列——越具体的规则优先级越高：

```
specificity（从高到低）：

  channel=<具体值>  >  channel=未明确
  subject_kind=<具体种类>  >  subject_kind 宽泛（如 role 包含所有角色）
  grain=field  >  grain=instance  >  grain=resource

组合特异性 = channel_specificity + subject_specificity + grain_specificity
```

---

## 2. 三维冲突解析算法 / Conflict Resolution Algorithm

当同一请求 `(subject, resource, action, channel, grain)` 命中 N 条规则时：

```
Step 1: 按 evaluation_algo 字段分组
  - 若所有命中规则共享相同 evaluation_algo → 直接按该算法处理（见 §3）
  - 若存在多个不同 evaluation_algo → 按 Step 2 的维度优先级选算法

Step 2: 算法选择优先级（当 evaluation_algo 不一致时）
  优先级：channel 特异性 > grain 特异性 > subject_kind 特异性
  即：channel 层定义的 evaluation_algo 覆盖其他层

Step 3: 仍有冲突（相同特异性）→ 保守原则
  effect 中有 deny → 最终 effect = deny
  effect 全为 allow → 最终 effect = allow
  effect 含 restricted → 最终 effect = restricted（优于 allow，次于 deny）
```

---

## 3. 四种 evaluation_algo 行为 / Algorithm Behavior

| evaluation_algo | 行为 | 适用场景 |
|---|---|---|
| `deny-overrides` | 任一规则为 deny → 整体 deny | 高安全性场景（金融/医疗/合规操作） |
| `allow-overrides` | 任一规则为 allow → 整体 allow | 内容分发/读取类宽松场景 |
| `first-applicable` | 按规则注册顺序，第一个命中的 effect 生效 | 有明确优先级排序的业务规则 |
| `未明确` | 使用保守原则（见 Step 3） + 在输出中标记 `evaluation_algo_undetermined` | 兜底，需升级至 PM/Arch 确认 |

---

## 4. channel × grain 交叉矩阵 / Cross-Dimension Matrix

当规则在 channel 和 grain 两个维度同时存在冲突时，使用以下矩阵确定有效规则：

| channel \ grain | `resource` | `instance` | `field` |
|---|---|---|---|
| `public_api` | 取 public_api 层规则 | 取 public_api + instance 层交集 | 取 public_api + field 层，field 层优先 |
| `internal_api` | 取 internal_api 层规则 | 取 internal_api + instance 层交集 | 取 internal_api + field 层，field 层优先 |
| `admin_ui` | 取 admin_ui 层规则（通常更宽松） | 取 admin_ui + instance 层 | 取 admin_ui + field 层，field 层优先 |
| `ops_cli` | 取 ops_cli 层规则 | 取 ops_cli + instance 层 | 取 ops_cli + field 层，field 层优先 |
| `scheduled` | 取 scheduled 层规则 | 不适用（scheduled 通常 resource 级） | 不适用 |
| `callback` | 取 callback 层规则 | 取 callback + instance 层 | 不适用 |

**field 层永远是最终 mask 层**：即使 resource 层 allow，field_policy 的 deny/mask 仍生效。

---

## 5. 记录要求 / Output Requirements

当发生三维冲突时，输出中必须记录：

```yaml
permission_conflict:
  conflict_id: "PERM-CONF-001"
  matched_rules: [<rule_id_1>, <rule_id_2>, ...]
  conflict_dimension: channel | grain | subject_kind | multi
  resolution_algo_used: deny-overrides | allow-overrides | first-applicable | conservative
  final_effect: allow | deny | restricted
  rationale: "<哪条维度冲突 + 按什么规则解析>"
  undetermined: false | true   # true → 需要 PM/Arch 决策
```

`undetermined: true` 的条目必须出现在 open_questions[] 中，blocking = true。

---

## 6. 常见冲突场景示例

| 场景 | channel | grain | 冲突 | 解析 |
|---|---|---|---|---|
| API 用户读字段，但字段级 mask | public_api | field | resource allow vs field deny | field 层优先 → deny/mask |
| admin 删除实例，但实例有 maker-checker | admin_ui | instance | allow vs relational_constraint | relational_constraint 生效 → deny |
| 内部 API 与定时任务都访问同一资源，algo 不同 | internal_api / scheduled | resource | deny-overrides vs first-applicable | channel 特异性决定：internal_api 优先 |
| SRE 通过 ops_cli 有 allow，但角色级 deny-overrides | ops_cli | resource | ops_cli allow vs role deny | deny-overrides 生效 → deny |

---

## 权限冲突优先级决策树

```
Q1: 所有命中规则的 evaluation_algo 是否相同？
    YES → 直接按该算法处理（见 §3）
    NO  → Q2

Q2: 不同 evaluation_algo 的规则中，哪个维度更特异？
    channel 更特异（如 public_api vs 未明确）→ 使用 channel 层的 evaluation_algo
    grain 更特异（如 field vs resource）→ 使用 grain 层的 evaluation_algo
    subject_kind 更特异 → 使用 subject_kind 层的 evaluation_algo

Q3（平局时）: 所有冲突规则中是否有任一 effect=deny？
    YES → 保守原则：最终 effect=deny
    NO  → 所有 effect=allow → 最终 effect=allow
         含 restricted → 最终 effect=restricted
```

### 边界 Case 对照表

| 场景 | channel | grain | 冲突性质 | 解析结果 |
|---|---|---|---|---|
| public_api + field 的 deny 覆盖 resource 层的 allow | public_api | field | field 层更特异 | deny 生效（field 优先） |
| admin_ui 比 public_api 更宽松 | admin_ui vs public_api | resource | channel 层不同 | admin_ui 规则适用于 admin_ui 请求 |
| 两个 role 各有 allow 和 deny，algo 一致为 deny-overrides | — | resource | algo 一致 | deny 生效（deny-overrides 定义） |
| delegated subject 与 role subject 冲突 | — | instance | subject_kind 不同 | delegated 规则更特异，优先 |
| compliance export 两个 allow，但来自不同 channel | ops_cli vs admin_ui | resource | 两个 allow 无冲突 | 各 channel 下都 allow，无需解析 |
