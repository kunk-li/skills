# Common Failure Modes

## Confusing participation with authorization
Being a requester, watcher, assignee, or notification recipient does not necessarily grant action permission.

## Confusing UI visibility with backend authorization
A visible or hidden button is not enough to conclude the real permission rule unless the document states it.

## Ignoring scope
A statement like "managers can view records" is incomplete if team, region, ownership, or stage boundaries are undefined.

## Missing dynamic changes
Permissions often change after submit, approve, archive, freeze, recover, or escalate. Do not report only the steady-state view.

## Missing high-risk controls
Do not bury export, delete, restore, privilege grant, or financial approval in the normal matrix only.

## Treating organization structure as permission structure
Reporting lines and departments may inform scope, but they are not themselves permission rules.

## Cross-module permission execution flattened
Symptom: A3 的编辑权限实际由 A1 的 RBAC 执行，但矩阵只写"L4 可编辑"，未标注"权限执行方 = A1"。
Fix: 使用 §4 的 "权限执行方" 和 "执行方模块" 字段显式记录。

## Channel-merged permission matrix
Symptom: Bot 端仅可查询、Web 端可 CRUD 的差异被压缩为"可编辑"单条。
Fix: 填写 §5.5 "渠道差异化权限"章节，按 Bot/Web 分开标注。

## System-level prohibitions hidden in ordinary matrix
Symptom: "禁直连生产库"这类全局红线被当成普通数据可见性处理。
Fix: §8 高风险动作控制表中标注为"系统级绝对禁止"等级，来源写"全局上下文"。
