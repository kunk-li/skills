# Example IO

## Example input
A workflow PRD says:
- employees may submit requests for themselves
- line managers may approve requests for their direct reports
- finance may view approved requests but may not edit them
- export of approved requests requires admin role and audit logging
- once a request is archived, managers lose edit rights and keep view-only access

## Example output snippet

### Role-resource-action matrix
| Subject | Resource | Action | Permission layer | Scope | Condition | Effect | Evidence |
|---|---|---|---|---|---|---|---|
| employee | request | submit | edit/approval | self only | when request is draft-capable | allowed | "employees may submit requests for themselves" |
| line manager | request | approve | edit/approval | direct reports | when request is pending approval | allowed | "line managers may approve requests for their direct reports" |
| finance | request | view | data visibility | approved requests | none stated | allowed | "finance may view approved requests" |
| finance | request | edit | edit/approval | approved requests | none stated | denied | "finance may view approved requests but may not edit them" |

### State-dependent permission changes
| Subject | Resource | Triggering state/stage | Permission change | Scope | Condition | Effect | Evidence |
|---|---|---|---|---|---|---|---|
| line manager | request | archived | edit removed, view retained | direct reports | after archive | restricted | "once a request is archived, managers lose edit rights and keep view-only access" |
