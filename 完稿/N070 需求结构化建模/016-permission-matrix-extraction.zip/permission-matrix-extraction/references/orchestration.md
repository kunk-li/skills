## Stage metadata
- n070_stage: 3
- depends_on: ['013', '017']
- blocks: []
- may_consume: ['014', '015']

# Orchestration Notes

This skill works well after requirement decomposition or alongside business rule extraction.

Recommended upstream inputs:
- `需求结构树.md` from requirement breakdown
- `业务规则清单.csv` from business rule extraction
- `状态流转表.csv` from state transition mapping
- `数据对象清单.csv` from data-object-identification

Recommended downstream uses:
- access control design
- approval workflow validation
- N090 / N100 / N110 / N170 / N230 / N260 as `权限矩阵.csv` consumers
- rule gap review
- implementation handoff

When a document is highly dynamic, use state transition mapping first to understand where permission changes occur, then build the dynamic permission matrix.

---

## N070 共同契约

### Object name alignment contract (C1)
- Canonical source: **requirement-breakdown §4 "核心业务对象"** table.
- When the resource in §3.2 / §4 refers to a business object, the resource name MUST match the canonical source.
- New resources not in the canonical source must be tagged "new resource (not in breakdown)".

### N070 execution stage (C3)
- This skill executes in **stage 3** (final stage) of N070 internal pipeline.
- Must wait for stage 1 (requirement-breakdown) AND stage 2 (data-object-identification, business-rule-extraction, state-transition-mapping) to complete.
- Consumes all upstream outputs:
  - requirement-breakdown: actor map, resource hints, canonical object names
  - data-object-identification: resource-level object granularity
  - business-rule-extraction: approval rules, permission restriction rules
  - state-transition-mapping: state-dependent permission change triggers

### CSV handoff contract (C4)
- Output filename: `权限矩阵.csv`
- Required downstream meaning: rows must be joinable with `业务规则清单.csv`, `状态流转表.csv`, and `数据对象清单.csv` by resource / actor / state-dependent trigger.
- Recommended direct consumers: N090 / N100 / N110 / N170 / N230 / N260.
