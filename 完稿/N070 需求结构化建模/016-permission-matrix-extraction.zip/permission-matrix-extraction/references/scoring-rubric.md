# Scoring Rubric

## 1 - Too vague
The output mostly paraphrases the document and does not form a usable permission model.

## 2 - Partial
The output identifies some roles and actions but misses scope, conditions, or approval boundaries.

## 3 - Reviewable
The output provides a usable matrix for review, with explicit gaps and limited inference.

## 4 - Design-ready
The output separates permission layers, dynamic changes, and high-risk controls clearly enough for downstream design or validation.
