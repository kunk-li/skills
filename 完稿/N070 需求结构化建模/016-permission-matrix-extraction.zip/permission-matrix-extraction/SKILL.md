---
name: permission-matrix-extraction
description: extract a reusable permission baseline from requirement and process material with stable permission ids, subject kinds, resource grains, channel-aware controls, relational constraints, delegation contracts, priority-based allow and deny effects, and downstream-ready refs. use when the source describes who may view, edit, approve, delegate, administer, or block access to data, fields, instances, channels, or workflows and the result must work standalone while also joining with requirement, rule, state, and data-object outputs.
---
# permission-matrix-extraction

Build a permission model from the source. Do not stop at prose summary.

## N070 stage metadata / 阶段元数据
- `n070_stage`: `3`
- `depends_on`: `['013', '017']`
- `blocks`: `[]`
- `may_consume`: `['014', '015']`
- Note: actual SKILL.md frontmatter must stay validator-compatible (`name` and `description` only), so the stage metadata is placed in the body top section instead of YAML frontmatter.

## Role / 角色定位
Produce a permission baseline that answers:
- who the permission subjects really are
- what resource grain is controlled
- whether channel context changes the decision
- whether access is static, delegated, derived, or contextual
- how allow/deny precedence works
- which object relationships impose separation-of-duty style constraints

## Single-skill value / 单独使用价值
- 仅基于 PRD 或流程文档即可独立构建权限矩阵。
- 即使没有兄弟 skill，也要输出主体、资源、动作、条件、效果、审批、高风险动作与缺口。
- 单独使用时也必须支持 `relational_constraint`，避免遗漏关键业务边界。

## Multi-skill value / 组合使用价值
- 与 requirement-breakdown 对齐角色、领域、对象范围。
- 与 business-rule-extraction 对齐 deny 规则、合规约束、时间/审批规则。
- 与 state-transition-mapping 对齐状态相关权限变化。
- 与 data-object-identification 对齐 resource/object 边界、字段级策略与对象关系。

## Allowed inputs / 允许输入
- 主输入：PRD、流程说明、权限需求、审批规范。
- 可选输入：需求结构树、规则清单、状态机、对象清单。
- 可选输入：全局上下文，仅用于全局角色体系、绝对禁止动作、网络或通道级约束。

## Required row contract
每条 permission row 尽量包含：
- `perm_id`
- `domain`
- `subject`
- `subject_kind`
- `resource`
- `grain`
- `channel`
- `action`
- `permission_layer`
- `scope`
- `condition`
- `field_policy`
- `delegation`
- `relational_constraint[]`
- `access_control[]`
- `evaluation_algo`
- `lifecycle`
- `decision_refs[]`
- `blocker_refs[]`
- `open_question_refs[]`
- `certainty`
- `evidence`

固定枚举：
- `subject_kind`: `role / delegated / derived / context`
- `grain`: `resource / field / instance`
- `channel`: `public_api / internal_api / admin_ui / ops_cli / scheduled / callback / 未明确`
- `evaluation_algo`: `deny-overrides / allow-overrides / first-applicable / 未明确`

## Access control rules
- 当允许与拒绝并存时，不要只写一个 `allow_deny` 字段。
- 改用 `access_control[]`，每条记录包含：`effect / priority / reason / condition`。
- 优先显式声明 `evaluation_algo`。
- 若文档没有给出裁决算法，不要猜；写 `未明确` 并加入缺口。

## Resource and subject modeling rules
- 先分清 `subject`、`resource`、`action`，再建矩阵。
- 对字段级场景使用 `grain = field` + `field_policy`。
- 对委托或代理使用 `subject_kind = delegated` + `delegation`。
- 对“创建者本人”“记录 owner”等派生身份使用 `subject_kind = derived`。
- 对“工作时间内”“内网来源”等上下文身份使用 `subject_kind = context`。
- 对对象间约束使用 `relational_constraint[]`，不要全部塞进 condition 文本。

## Lightweight / delegated-enforcement mode / 轻量·委托强制模式
不是每个模块都自带权限逻辑。当**访问控制集中在边界层**（网关 / 中间件 / 上游服务）或模块是**单 owner、无模块内权限判定**时：
- **不要硬产一张满是空行 / "未明确"的完整矩阵**——那是噪声，不是发现。
- 改为输出一条紧凑记录：
  - `enforcement_location`：鉴权实际发生处（如 `gateway` / `middleware` / `upstream:<module>` / `owner_check_in:<module>`）。
  - `ownership_scope`：owner-based 访问用 `subject_kind=derived` 表达（记录 owner 即可访问），不展开成全角色矩阵。
  - 把"本模块无独立权限模型"作为一条**显式 finding**（若边界层也找不到强制点则标 `absent_but_expected`），而不是留空。
- 仅当模块**确有**模块内、按角色 / 资源分叉的判定时，才产完整 `access_control[]` 矩阵。
- 目的：对集中鉴权 / owner-based 模块给"指针 + 缺口"，而非伪造的满矩阵。

## Permission-input provenance / 权限输入溯源（authz 决策依据的数据从哪来、写得守不守）
权限不只是"谁能做什么"，还包括**判定所依据的数据本身可不可信**。对每条 authz 谓词（`is_admin` / `owner_id` / `role` / `tier` 等），回答两问：
- **它的值在哪写入？** 追到写入点（字段 / 表 / 配置）。尤其警惕**开放/自由字段**（`metadata` / `attributes` / `extra` / 通用 JSON 包）被当权限输入——这类字段常无 schema、无专用 writer。
- **那个写路径守不守？** 若一个能改该字段的写入口（如通用 update / PATCH metadata）**无 owner/admin 守卫**，则任何调用者可自抬权限 = 提权漏洞，发 `authz_input_unguarded` finding（高信号红线）。
- 纪律：authz 谓词若读自开放包、且其写入口无守卫，**不要默认"有鉴权"**——这是最易漏的提权面（实测某真实系统：`is_admin` 读自开放 `metadata`，而通用 `PUT /users/{id}` 整体替换 metadata 且无守卫 → 任意用户自封 admin）。与 017 的 `authz_input` 标签配对（标了该 tag 的对象/字段，其写路径必须 owner/admin-write-only）。

## Global validation rule ids / 全局校验规则编号
- Canonical references for this skill's validation rules:
- `016.R00_evidence_required`
- `016.R01_grain_required`
- `016.R02_delegation_has_ttl`
- `016.R03_compliance_audit_full`
- `016.R04_evaluation_algo_declared`
- `016.R05_deny_priority_highest`
- `016.R06_fallback_discipline_016`
- When old notes or logs mention a short name like `R03`, interpret it through the list above; the global id is the canonical reference from v2.1.2 onward.

## Workflow / 执行流程
1. 识别所有主体、资源、动作、作用范围与审批关系。
2. 先构建资源分类，再写权限矩阵。
3. 给每条权限生成稳定 `perm_id`；没有显式 id 时按 `{PERM-domain-nnn}` 生成。
4. 标注 `subject_kind`、`grain`、`channel`、`permission_layer`。
5. 对字段级场景补 `field_policy`，对委托场景补 `delegation`。
6. 对 maker-checker、自我授权禁止、组织边界等补 `relational_constraint[]`。
7. 处理 allow/deny precedence，输出 `access_control[]` 与 `evaluation_algo`。
8. 若兄弟 skill 可用，补 cross refs 与 coverage hooks。
9. 使用 `references/output-template.md` 和 `references/field-contract.md` 输出。

## audit propagation note / 审计传播说明
- If an upstream object is tagged `audit_required`, treat the matching permission rows as requiring `audit_level >= full`.
- Preserve the original evidence on both the object row and the permission row; do not silently upgrade audit strength without leaving a note.

## Output / 默认输出契约
- 默认 `full_mode`
- 面向表格交付可补 `rbac_csv`
- 面向属性访问控制可补 `abac_json`
- 面向策略引擎可补 `xacml`
- 需要自动化 join 时输出 `machine_mode`
- 需要版本回放时启用 `diff_mode`

## Boundary rules / 边界规则
- 跟随输入主语言输出。
- 不翻译角色码、权限键、状态值、字段名。
- 证据格式：`[doc_id]§[section].L[start]-L[end]`
- 确定性只允许：`明确写明 / 基于上下文推断 / 待确认`

## Evidence anchor contract / 证据锚点契约
- Canonical anchor format: `[doc_id]§[section].L[start]-L[end]`
- Canonical YAML-safe regex pattern: `'\[[^\]]+\]§[^.]+\.L\d+(-L\d+)?'`
- Prefer a single-quoted YAML scalar when documenting or exporting the regex to avoid escape ambiguity across parsers.
- Evidence must point to the source that actually supports the row; do not use a nearby paragraph as a placeholder.


## Workflow v2 artifact contract
```yaml
artifact_type: n070.permission-matrix-extraction
schema_version: "1.0.0"
producer_skill: permission-matrix-extraction
consumer_nodes: [N090, N100, N170]
workflow_alias: 权限矩阵.md
produced_event_name: produced.n070.permission-matrix-extraction
canonical_fields:
  - perm_id        # PERM-{domain}-{nnn}
  - subject
  - subject_kind
  - resource
  - grain
  - channel
  - action
  - effect
  - evaluation_algo
  - permission_layer
  - condition
  - compliance_flag
  - evidence
n005_consumption: indirect
```


## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认，并参照 `references/scoring-rubric.md` 做质量自评。确认已完成：
- 所有必填字段已填写，无静默缺失
- 使用了 N070 标准 ID 命名空间（REQ-/RULE-/SM-/PERM-/OBJ-）
- 证据锚点格式符合 `[doc_id]§[section].L[start]-L[end]`
- certainty 只使用：明确写明 / 基于上下文推断 / 待确认

## Key references
- `references/handoff-to-n080.md（见 013）`：N070→N080 节点交接协议
- `../013-requirement-breakdown/requirement-breakdown/references/node-guide.md`：**N070 节点导航——5 个 skill 执行顺序、与 N080 交接规则（必读，见 013）**

- `references/field-contract.md`：**subject_kind / evaluation_algo / permission_layer / grain 等字段完整枚举定义（必读）**
- `references/conflict-resolution-rules.md`：**channel × subject × grain 三维冲突解析算法 + 四种 evaluation_algo 行为 + 交叉矩阵（必读）**
- `references/scoring-rubric.md`：质量评分 1-4 级标准
- `references/interoperability-contract.md`：N070 跨 skill 命名空间契约
- `references/output-template.md`：输出结构
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
