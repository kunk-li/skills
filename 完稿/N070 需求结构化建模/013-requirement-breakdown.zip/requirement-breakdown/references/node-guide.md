# N070 需求结构化建模 — 节点导航

> **节点定位**：将原始需求材料（PRD 草稿、政策文件、解决方案笔记等）拆解为结构化、可机器 join 的需求基线。N070 是整个分析链的起点，输出的命名空间（REQ-/OBJ-/RULE-/SM-/PERM-）被 N080 及下游节点引用。

---

## Skills 一览

| ID | Skill | 主要输出 | 适用场景 |
|---|---|---|---|
| 013 | requirement-breakdown | 五级分解结构（L1–L5）+ open_questions | 任何需求材料的首步分析 |
| 014 | business-rule-extraction | RULE-* 条目 + DSL condition_expr | 需要精确捕获业务逻辑条件分支 |
| 015 | state-transition-mapping | SM-* 状态机 + orthogonal_with[] | 对象有明确生命周期或状态转移 |
| 016 | permission-matrix-extraction | PERM-* 权限矩阵 | 需要建立主体-资源-动作-效果模型 |
| 017 | data-object-identification | OBJ-* 数据对象目录 | 需要建立数据模型或对象边界 |

---

## 推荐执行顺序

```
013（必选）→ 014 → 015 → 016 → 017
              ↑ 这四个可根据需求材料复杂度选择性执行
```

**013 是强制必选**：其他 skill 依赖 013 建立的对象名、角色名、领域名作为共享词汇表。

---

## 关键共享契约

每个 skill 的 `references/interoperability-contract.md` 定义了 N070 内部的跨 skill 命名空间规范：

- **ID 命名空间**：`REQ-`（013）/ `RULE-`（014）/ `SM-`（015）/ `PERM-`（016）/ `OBJ-`（017）
- **推荐格式**：`{prefix}-{domain}-{nnn}`（如 `REQ-AUTH-001`、`OBJ-ORDER-003`）
- **共享 linkage 字段**：`domain / decision_refs[] / blocker_refs[] / certainty / evidence / lifecycle.*`
- **输出模式**：`table_mode / full_mode / machine_mode / diff_mode`（四种均必须支持）

---

## 与 N080 的交接规则

N070 输出流入 N080 时：
- N080 的 018 SKILL.md 第 25 行：`use their authoritative object and role vocabulary to reduce naming drift`
- N080 建立独立命名空间（P-/FT-/BE-/API-/ACT-/FLD-），通过 **upstream_alignment** 软链接到 N070 词汇
- N070 覆盖报告中的 `orphan_objects`、`requirements_without_rules` 检查结果应在 N080 中持续追踪

---

## 与 N080 的正式交接

参见 `transitions/N070-N080-transition.md`，该文件定义：

- N070 输出捆绑包（对象目录/规则清单/状态表/权限矩阵/数据对象清单）的正式格式
- N080 入场校验需要检查的 `n070_intake_check` 块
- 词汇对齐规则（N080 使用 N070 OBJ-*/RULE-* 的要求）
- `ready_for_n090` 完成信号格式

**自动验证命令**：
```bash
python3 transitions/cross_node_validator.py --transition N070-N080 \
  --n070 ./n070_output.md --n080 ./n080_output.md
```

## 常见误用

| 误用 | 正确做法 |
|---|---|
| 直接从需求文档的章节结构提取层级 | 按 L1-L5 判别矩阵（013 scoring-rubric.md）重新分类 |
| 跳过 013，直接运行 014/015 | 013 必须先运行以建立共享词汇表 |
| 把所有 if/else 条件写成 L5 | L4 是有 if/else 逻辑的规则；L5 是无例外的硬约束 |
| 015 的正交关系凭感觉判断 | 使用 015 references/orthogonal-detection.md 的 Q1-Q4 决策树 |
| 016 的 evaluation_algo 留空 | 在 field-contract.md 中选 `deny-overrides / allow-overrides / first-applicable / 未明确` |
