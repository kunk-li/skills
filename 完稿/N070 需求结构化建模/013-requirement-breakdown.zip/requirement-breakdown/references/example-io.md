# Example input / output pattern

## Example input pattern
A PRD describes a request workflow with multiple roles, object records, approval gates, scheduled reminders, exception handling, and external sync.

## Example output pattern
The breakdown should:
- identify the request record, approval record, and reminder task as separate objects
- separate mainline request handling from approval controls and reminder automation
- show where external sync or notification depends on another system
- list unanswered questions such as missing ownership, missing failure handling, or unclear lifecycle boundaries
