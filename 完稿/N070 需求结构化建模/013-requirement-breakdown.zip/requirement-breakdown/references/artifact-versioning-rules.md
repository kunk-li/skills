# Artifact Schema 版本化规则
# Artifact Versioning & Breaking Change Detection

> 所有 N070–N110 的产物契约头（artifact contract header）都必须声明 `schema_version`（语义化版本号）。
> 本文件定义何时必须升版本、下游如何感知破坏性变更，以及双轨并存的迁移规则。

---

## 1. 版本号格式

```
schema_version: "MAJOR.MINOR.PATCH"

MAJOR：破坏性变更（下游必须更新消费逻辑）
MINOR：向后兼容的新增字段（下游可选消费）
PATCH：文档修订、注释、错误修正（不影响消费）
```

---

## 2. 破坏性变更定义（MAJOR 必须升）

以下任意一项成立 → `MAJOR` +1，重置 MINOR 和 PATCH 为 0：

| 变更类型 | 示例 |
|---|---|
| 删除 `canonical_fields` 中已声明的字段 | 删除 `issue_id` 字段 |
| 重命名 `canonical_fields` 中的字段 | `severity` → `severity_level` |
| 改变字段类型 | `score: float` → `score: string` |
| 改变枚举值（删除或重命名） | `"go"` → `"approved"` |
| 改变必填/可选性质（可选→必填） | `evidence` 从可选变必填 |
| 改变 `artifact_type` 标识符 | `n090.prd-document` → `n090.prd` |
| 拆分或合并输出文件（canonical output name 变化） | 一个 CSV → 两个 CSV |
| 变更 `produced_event_name` | 已注册的事件名重命名 |

---

## 3. 向后兼容变更（MINOR 升，不需要下游立即更新）

| 变更类型 | 示例 |
|---|---|
| 新增可选字段 | 新增 `upstream_refs[]` |
| 新增枚举值（不删除旧值） | gap_type 新增 `missing_compliance` |
| 新增输出文件（不删除旧文件） | 新增 Markdown summary |
| 放宽字段约束（必填→可选） | `evidence` 从必填变可选 |
| 新增 `consumer_nodes` | 加 N390 为新消费者 |

---

## 4. 下游感知破坏性变更的协议

### 4.1 版本锁定声明

消费方 skill 在其 SKILL.md 的 artifact contract 区域声明所期望的上游版本：

```yaml
consumed_artifacts:
  - artifact_type: n090.prd-document
    min_schema_version: "2.0.0"      # 接受 2.x.x 及以上
    max_schema_version: "2.99.99"    # 不接受 3.x.x（breaking）
    fallback_on_mismatch: degrade_to_partial_mode
```

### 4.2 版本不匹配时的行为

| 情况 | 行为 |
|---|---|
| 上游版本 < min_schema_version | 报错：`artifact_version_too_old`，emit `exception.{node}.artifact_version_mismatch` |
| 上游版本 > max_schema_version (MAJOR 不同) | 报错：`breaking_change_detected`，进入 `partial_mode` |
| 上游版本在范围内但有新 MINOR 字段 | 忽略新字段，正常消费 |
| 上游未声明 schema_version | 视为 `"0.0.0"`，进入 `partial_mode`，记录 `schema_version_missing` |

### 4.3 双轨并存期（Breaking Change 后的过渡）

当 MAJOR 升级时，产出方必须在 **2 个 sprint** 内同时维护新旧版本：

```yaml
# 新旧同时存在于 artifact contract header
schema_version: "2.0.0"
legacy_schema_version: "1.2.3"      # 旧版，2 sprint 后废弃
legacy_deprecation_date: "2026-06-01"
```

消费方在过渡期内可声明 `accept_legacy: true` 以继续使用旧字段，但必须在 deprecation_date 前完成迁移。

---

## 5. 各节点当前版本与 canonical_fields

| 节点 | artifact_type | schema_version | MAJOR 变更历史 |
|---|---|---|---|
| N070/013 | n070.requirement-breakdown | 1.0.0 | 初始 |
| N070/014 | n070.business-rule-extraction | 1.0.0 | 初始 |
| N070/015 | n070.state-transition-mapping | 1.0.0 | 初始 |
| N070/016 | n070.permission-matrix-extraction | 1.0.0 | 初始 |
| N070/017 | n070.data-object-identification | 1.0.0 | 初始 |
| N080/018 | n080.feature-points | 1.1.0 | 1.1.0: 引入 N080_COMMON_CONTRACTS |
| N080/019 | n080.backend-requirements | 1.1.0 | 同上 |
| N080/020 | n080.page-actions | 1.1.0 | 同上 |
| N080/021 | n080.form-fields | 1.1.0 | 同上 |
| N090/022 | n090.prd-document | 2.0.0 | 2.0.0: 新增 upstream_refs[] |
| N090/023 | n090.prd-gap-list | 2.0.0 | 2.0.0: 新增 source_gap_id + N005 |
| N090/024 | n090.prd-review-questions | 2.0.0 | 2.0.0: 量化 urgency_score |
| N100/025-030 | n100.* | 2.1.1 | 见各 skill 契约头 |
| N110/031-035 | n110.* | 2.1.0 | 见各 skill 契约头 |

---

## 6. 升版本操作清单

当产出方需要 MAJOR 升版时：

```
□ 在本文件的"各节点当前版本"表中更新版本号
□ 在 workflow-v2-event-schemas.md 的 Schema 版本历史中记录变更原因
□ 在 SKILL.md 的 artifact contract 区域更新 schema_version
□ 在 SKILL.md 添加 legacy_schema_version 和 legacy_deprecation_date
□ 在 CHANGELOG.md（若存在）记录 breaking change 详情
□ 通知所有 consumer_nodes 的 owner 完成版本迁移
□ 在 N380（平台门禁）的 schema_registry 中注册新版本
```

---

## 7. N380 Schema Registry 集成

N380 维护一个 `schema_registry` 字典，在 gate 检查时验证产物版本合规性：

```yaml
gate_check: schema_version_compliance
  for each consumed_artifact in [N090.prd, N100.quality-review]:
    assert artifact.schema_version satisfies consumer.min/max_schema_version
    if assertion fails:
      → emit exception.n380.schema_mismatch
      → gate = blocked
      → sla_level = P0, auto_escalate_after = 2h
```
