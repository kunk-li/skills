#!/usr/bin/env python3
"""
cross_node_validator.py
跨节点对齐验证工具

用法:
  python3 cross_node_validator.py --transition N070-N080 --n070-dir ./n070_outputs --n080-dir ./n080_outputs
  python3 cross_node_validator.py --transition all --input-dir ./session_outputs

验证范围:
  N070→N080: 词汇对齐、ready_for_n090 信号
  N080→N090: upstream_refs 覆盖率、未引用的 FT-* 条目
  N090→N100: PRD 章节完整性、GAP 链接率
  N100→N110: Gate 信号、blocker 继承完整性
"""

import re
import sys
import json
import argparse
from typing import List, Dict, Optional, Tuple

# ─────────────────────────────────────────────────────────────
# Pattern matchers
# ─────────────────────────────────────────────────────────────

def extract_ids(text: str, prefix: str) -> List[str]:
    """提取符合 PREFIX-* 格式的所有 ID"""
    pattern = rf'\b{re.escape(prefix)}-[A-Z0-9\-]+\b'
    return list(set(re.findall(pattern, text, re.IGNORECASE)))

def check_yaml_field(text: str, field: str) -> Optional[str]:
    """提取 YAML 风格的字段值"""
    pattern = rf'^{re.escape(field)}:\s*(.+)$'
    m = re.search(pattern, text, re.MULTILINE)
    return m.group(1).strip() if m else None

# ─────────────────────────────────────────────────────────────
# N070 → N080 Validation
# ─────────────────────────────────────────────────────────────

def validate_n070_n080(n070_text: str, n080_text: str) -> Dict:
    """
    验证 N080 正确使用了 N070 的词汇
    """
    results = {"transition": "N070→N080", "checks": [], "passed": 0, "failed": 0, "warnings": 0}

    def check(name: str, condition: bool, detail: str, level: str = "check"):
        entry = {"name": name, "status": "PASS" if condition else "FAIL", "detail": detail}
        results["checks"].append(entry)
        if condition:
            results["passed"] += 1
        else:
            results["failed"] += 1

    def warn(name: str, detail: str):
        results["checks"].append({"name": name, "status": "WARN", "detail": detail})
        results["warnings"] += 1

    # 1. N070 对象目录是否存在
    n070_objs = extract_ids(n070_text, "OBJ")
    check("N070 对象目录存在", len(n070_objs) > 0, f"发现 {len(n070_objs)} 个 OBJ-* 条目")

    # 2. N080 中引用了多少 N070 对象名
    n080_obj_refs = [obj for obj in n070_objs if obj in n080_text]
    if n070_objs:
        coverage = len(n080_obj_refs) / len(n070_objs)
        check("N080 引用 N070 对象", coverage >= 0.5,
              f"N080 引用了 {len(n080_obj_refs)}/{len(n070_objs)} 个 N070 对象 ({coverage:.0%})")

    # 3. N080 的 source-derived 标注
    source_derived_count = n080_text.count("source-derived")
    if source_derived_count > 0:
        warn("存在 source-derived 词汇", f"发现 {source_derived_count} 处 source-derived 标注，请确认是否已有 N070 词汇可替代")

    # 4. upstream_alignment 块存在
    has_alignment = "upstream_alignment" in n080_text or "n070_intake" in n080_text
    check("N080 包含 upstream_alignment", has_alignment, "需要在 output summary 中包含 n070_intake_check 块")

    # 5. ready_for_n090 信号
    ready = check_yaml_field(n080_text, "ready_for_n090")
    check("ready_for_n090 信号存在", ready is not None, f"值: {ready}")
    if ready:
        check("ready_for_n090 = true", ready.lower() == "true", f"当前值: {ready}")

    # 6. 页面命名空间稳定
    page_ids = extract_ids(n080_text, "P")
    check("P-* 页面命名空间已建立", len(page_ids) > 0, f"发现 {len(page_ids)} 个页面 ID")

    # 7. upstream_feedback 存在
    has_feedback = "upstream_feedback" in n080_text
    if not has_feedback:
        warn("upstream_feedback 未出现", "如果原型有 N070 未覆盖的对象，应在 upstream_feedback[] 中记录")

    results["summary"] = f"通过 {results['passed']}，失败 {results['failed']}，警告 {results['warnings']}"
    return results

# ─────────────────────────────────────────────────────────────
# N080 → N090 Validation
# ─────────────────────────────────────────────────────────────

def validate_n080_n090(n080_text: str, n090_text: str) -> Dict:
    """
    验证 N090 的 PRD 正确引用了 N080 的 P-*/FT-* 条目
    """
    results = {"transition": "N080→N090", "checks": [], "passed": 0, "failed": 0, "warnings": 0}

    def check(name, condition, detail):
        results["checks"].append({"name": name, "status": "PASS" if condition else "FAIL", "detail": detail})
        if condition: results["passed"] += 1
        else: results["failed"] += 1

    def warn(name, detail):
        results["checks"].append({"name": name, "status": "WARN", "detail": detail})
        results["warnings"] += 1

    # 1. N080 feature IDs 在 N090 中的引用率
    ft_ids = extract_ids(n080_text, "FT")
    ft_in_n090 = [fid for fid in ft_ids if fid in n090_text]
    if ft_ids:
        coverage = len(ft_in_n090) / len(ft_ids)
        check("N090 引用 FT-* 覆盖率 ≥ 70%", coverage >= 0.7,
              f"N090 引用了 {len(ft_in_n090)}/{len(ft_ids)} 个 FT-* ({coverage:.0%})")
    else:
        warn("N080 无 FT-* 条目", "N080 输出中未发现功能点 ID，请确认 N080 是否已运行")

    # 2. upstream_refs 字段在 PRD 中是否出现
    has_upstream_refs = "upstream_refs" in n090_text
    check("PRD 包含 upstream_refs", has_upstream_refs, "至少一个 PRD 章节应有 upstream_refs[] 字段")

    # 3. 关键 PRD 章节存在
    required_sections = ["PRD-03", "PRD-06", "PRD-07", "PRD-13", "PRD-15"]
    missing_sections = [s for s in required_sections if s not in n090_text]
    check("必须 PRD 章节存在", len(missing_sections) == 0,
          f"缺失: {missing_sections}" if missing_sections else "全部存在")

    # 4. traceability_summary 存在
    check("traceability_summary 存在", "traceability_summary" in n090_text,
          "PRD artifact header 需要 traceability_summary 字段")

    # 5. GAP-XXX 条目的 related_prd_sections 引用
    gap_count = len(extract_ids(n090_text, "GAP"))
    check("GAP-XXX 条目存在", gap_count > 0 or "gap_list_available: false" in n090_text,
          f"发现 {gap_count} 个 GAP 条目")

    # 6. ready_for_n100 信号
    ready = check_yaml_field(n090_text, "ready_for_n100")
    if ready:
        check("ready_for_n100 = true", ready.lower() == "true", f"当前值: {ready}")
    else:
        warn("ready_for_n100 信号缺失", "建议在 PRD artifact header 中添加 ready_for_n100 字段")

    # 7. 未引用的 FT-*
    unref_fts = [fid for fid in ft_ids if fid not in n090_text]
    if unref_fts:
        warn("存在未引用的 FT-* 条目",
             f"{len(unref_fts)} 个 N080 功能点未在 PRD 中引用: {unref_fts[:5]}{'...' if len(unref_fts) > 5 else ''}")

    results["summary"] = f"通过 {results['passed']}，失败 {results['failed']}，警告 {results['warnings']}"
    return results

# ─────────────────────────────────────────────────────────────
# N090 → N100 Validation
# ─────────────────────────────────────────────────────────────

def validate_n090_n100(n090_text: str, n100_text: str) -> Dict:
    """
    验证 N100 正确接收了 N090 的 PRD 和 GAP 清单
    """
    results = {"transition": "N090→N100", "checks": [], "passed": 0, "failed": 0, "warnings": 0}

    def check(name, condition, detail):
        results["checks"].append({"name": name, "status": "PASS" if condition else "FAIL", "detail": detail})
        if condition: results["passed"] += 1
        else: results["failed"] += 1

    def warn(name, detail):
        results["checks"].append({"name": name, "status": "WARN", "detail": detail})
        results["warnings"] += 1

    # 1. N100 包含 n090_intake 块
    has_intake = "n090_intake" in n100_text
    check("N100 包含 n090_intake 块", has_intake, "030 输出需要 n090_intake 段记录 N090 输入状态")

    # 2. GAP 链接率
    n090_gaps = extract_ids(n090_text, "GAP")
    n100_gap_refs = [g for g in n090_gaps if g in n100_text]
    if n090_gaps:
        gap_coverage = len(n100_gap_refs) / len(n090_gaps)
        check("GAP-XXX 链接率 ≥ 50%", gap_coverage >= 0.5,
              f"N100 引用了 {len(n100_gap_refs)}/{len(n090_gaps)} 个 GAP ({gap_coverage:.0%})")
    else:
        warn("N090 无 GAP 条目", "如果 023 未运行，N100 无 GAP 参考，应在 partial mode 下运行")

    # 3. gate 字段存在
    gate = check_yaml_field(n100_text, "gate")
    check("gate 决策字段存在", gate is not None, f"当前值: {gate}")
    if gate:
        check("gate 值合法", gate in ["go", "conditional-go", "no-go"],
              f"当前值: {gate}，合法值: go | conditional-go | no-go")

    # 4. cross_node_trace 段
    has_trace = "cross_node_trace" in n100_text
    check("030 包含 cross_node_trace", has_trace,
          "030 rollup 需要 cross_node_trace 段记录 N090 GAP 覆盖率")

    # 5. overall_score 字段
    score = check_yaml_field(n100_text, "overall_score")
    if score:
        try:
            score_val = float(score)
            check("overall_score 在合理范围", 0 <= score_val <= 100,
                  f"当前值: {score_val}")
        except ValueError:
            check("overall_score 是数值", False, f"无法解析: {score}")

    # 6. source_gap_id 使用情况
    source_gap_refs = re.findall(r'source_gap_id:\s*GAP-\w+', n100_text)
    if n090_gaps and not source_gap_refs:
        warn("source_gap_id 未使用", f"N090 有 {len(n090_gaps)} 个 GAP，但 N100 issue 未使用 source_gap_id 字段")

    # 7. new_gap 标注
    new_gaps = re.findall(r'new_gap:\s*true', n100_text, re.IGNORECASE)
    if new_gaps:
        warn("存在 new_gap=true 的 issue", f"发现 {len(new_gaps)} 个新发现的缺口，需要回写到 023")

    results["summary"] = f"通过 {results['passed']}，失败 {results['failed']}，警告 {results['warnings']}"
    return results

# ─────────────────────────────────────────────────────────────
# N100 → N110 Validation
# ─────────────────────────────────────────────────────────────

def validate_n100_n110(n100_text: str, n110_text: str) -> Dict:
    """
    验证 N110 正确接收了 N100 的 gate 决策和 blocker 清单
    """
    results = {"transition": "N100→N110", "checks": [], "passed": 0, "failed": 0, "warnings": 0}

    def check(name, condition, detail):
        results["checks"].append({"name": name, "status": "PASS" if condition else "FAIL", "detail": detail})
        if condition: results["passed"] += 1
        else: results["failed"] += 1

    def warn(name, detail):
        results["checks"].append({"name": name, "status": "WARN", "detail": detail})
        results["warnings"] += 1

    # 1. execution_mode 存在且与 gate 一致
    gate = check_yaml_field(n100_text, "gate")
    mode = check_yaml_field(n110_text, "execution_mode")
    check("execution_mode 字段存在", mode is not None, f"当前值: {mode}")

    if gate and mode:
        gate_mode_map = {
            "go": ["formal_mode"],
            "conditional-go": ["formal_mode"],
            "no-go": ["blocked_mode"],
        }
        expected_modes = gate_mode_map.get(gate, ["minimal_mode"])
        check("execution_mode 与 gate 一致", mode in expected_modes,
              f"gate={gate} 期望 {expected_modes}，实际 mode={mode}")

    # 2. conditional_go_conditions 在 conditional-go 时必须存在
    if gate == "conditional-go":
        has_conds = "conditional_go_conditions" in n110_text
        check("conditional_go_conditions 存在", has_conds,
              "gate=conditional-go 时 031 必须输出 conditional_go_conditions[]")

    # 3. open_questions 继承 N100 blockers
    n100_blockers = re.findall(r'severity:\s*blocker', n100_text, re.IGNORECASE)
    open_q_count = len(re.findall(r'question_id:\s*Q-031-', n110_text))
    if n100_blockers:
        check("open_questions 继承了 N100 blockers",
              open_q_count >= len(n100_blockers),
              f"N100 有 {len(n100_blockers)} 个 blocker，031 open_questions 有 {open_q_count} 条")

    # 4. handover_readiness_score 存在
    score = check_yaml_field(n110_text, "handover_readiness_score")
    check("handover_readiness_score 计算存在", score is not None, f"当前值: {score}")

    # 5. handover_readiness_breakdown 存在
    has_breakdown = "handover_readiness_breakdown" in n110_text
    check("handover_readiness_breakdown 存在", has_breakdown,
          "四个子维度分数必须输出以供审计")

    # 6. pass_readiness 字段
    readiness = check_yaml_field(n110_text, "pass_readiness")
    check("pass_readiness 字段存在", readiness is not None, f"当前值: {readiness}")
    if readiness:
        valid_values = ["ready", "conditional_ready", "needs_action", "not_ready"]
        check("pass_readiness 值合法", readiness in valid_values,
              f"合法值: {valid_values}")

    # 7. blocker=no-go 时 not_ready
    if gate == "no-go" and readiness:
        check("no-go 时 pass_readiness ≠ ready", readiness != "ready",
              f"gate=no-go 时不应为 ready，当前: {readiness}")

    # 8. GAP 回写追踪
    writebacks = re.findall(r'source_type:\s*n100_remediation', n110_text)
    remediation_plan = re.findall(r'remediation_plan', n100_text)
    if remediation_plan and not writebacks:
        warn("GAP 回写动作未在 031 中追踪",
             "030 的 remediation_plan 中有 GAP 回写动作，031 应在 open_questions 中跟踪")

    results["summary"] = f"通过 {results['passed']}，失败 {results['failed']}，警告 {results['warnings']}"
    return results

# ─────────────────────────────────────────────────────────────
# Report Formatter
# ─────────────────────────────────────────────────────────────

def format_report(results: Dict) -> str:
    lines = [f"\n{'='*60}", f"  {results['transition']} 跨节点验证报告",
             f"  {results['summary']}", f"{'='*60}"]

    for check in results["checks"]:
        icon = {"PASS": "✓", "FAIL": "✗", "WARN": "⚠"}.get(check["status"], "?")
        lines.append(f"  {icon} [{check['status']}] {check['name']}")
        lines.append(f"      {check['detail']}")

    return "\n".join(lines)

# ─────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────

def read_file(path: str) -> str:
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return ""
    except Exception as e:
        print(f"Warning: Cannot read {path}: {e}", file=sys.stderr)
        return ""

def main():
    parser = argparse.ArgumentParser(description="跨节点对齐验证工具")
    parser.add_argument("--transition", choices=["N070-N080", "N080-N090", "N090-N100", "N100-N110", "all"],
                        default="all", help="要验证的节点过渡")
    parser.add_argument("--n070", help="N070 输出文件路径")
    parser.add_argument("--n080", help="N080 输出文件路径")
    parser.add_argument("--n090", help="N090 PRD 文件路径")
    parser.add_argument("--n100", help="N100 质量评审报告路径")
    parser.add_argument("--n110", help="N110 交接包路径")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式")

    args = parser.parse_args()

    n070 = read_file(args.n070) if args.n070 else ""
    n080 = read_file(args.n080) if args.n080 else ""
    n090 = read_file(args.n090) if args.n090 else ""
    n100 = read_file(args.n100) if args.n100 else ""
    n110 = read_file(args.n110) if args.n110 else ""

    all_results = []

    if args.transition in ("N070-N080", "all") and (n070 or n080):
        r = validate_n070_n080(n070, n080)
        all_results.append(r)
        if not args.json:
            print(format_report(r))

    if args.transition in ("N080-N090", "all") and (n080 or n090):
        r = validate_n080_n090(n080, n090)
        all_results.append(r)
        if not args.json:
            print(format_report(r))

    if args.transition in ("N090-N100", "all") and (n090 or n100):
        r = validate_n090_n100(n090, n100)
        all_results.append(r)
        if not args.json:
            print(format_report(r))

    if args.transition in ("N100-N110", "all") and (n100 or n110):
        r = validate_n100_n110(n100, n110)
        all_results.append(r)
        if not args.json:
            print(format_report(r))

    if args.json:
        print(json.dumps(all_results, ensure_ascii=False, indent=2))

    total_failed = sum(r["failed"] for r in all_results)
    sys.exit(0 if total_failed == 0 else 1)

if __name__ == "__main__":
    main()
