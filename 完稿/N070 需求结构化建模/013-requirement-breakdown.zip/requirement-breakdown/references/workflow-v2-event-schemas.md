# Workflow v2 事件总线 Schema 目录
# Event Bus Schema Registry · N070–N110

> 本文件定义所有节点向事件总线发布的事件名称、payload 结构和订阅规则。
> 下游节点在 artifact contract header 中声明 `produced_event_name`，
> 横切订阅者（N330/N340/N350/N390）按 event_type 过滤订阅。

---

## 事件命名规范

```
produced.{node_id}.{artifact_slug}        # 产物发布事件
state.{node_id}.gate.{result}            # 门禁状态事件
exception.{node_id}.{error_kind}         # 异常事件
sla.{node_id}.{priority}.{action}       # SLA 队列事件
feedback.n005.signal.{signal_type}      # N005 反馈信号
```

---

## N070 事件

### `produced.n070.requirement-breakdown`
```yaml
event_type: produced.n070.requirement-breakdown
schema_version: "1.0.0"
payload:
  artifact_type: n070.requirement-breakdown
  producer_skill: requirement-breakdown
  consumer_nodes: [N080, N090, N100, N230, N260]
  req_count: <int>               # REQ-* 条目总数
  domain_count: <int>            # L1 域数量
  open_question_count: <int>     # open_questions[] 数量
  blocker_count: <int>           # blocking=true 的条目数
  cross_cut_count: <int>         # cross_cuts[] 非空的条目数
  completeness_signal:           # 供 025 completeness-check 消费
    has_l1_to_l5_coverage: <bool>
    has_evidence_anchors: <bool>
    has_interoperability_links: <bool>
  trace_id: <string>
  produced_at: <iso8601>
```

### `produced.n070.business-rule-extraction`
```yaml
event_type: produced.n070.business-rule-extraction
schema_version: "1.0.0"
payload:
  artifact_type: n070.business-rule-extraction
  producer_skill: business-rule-extraction
  consumer_nodes: [N090, N100, N150, N230]
  rule_count: <int>
  dsl_validated_count: <int>     # condition_expr 通过 DSL parser 的规则数
  hardness_distribution:
    constraint: <int>
    rule: <int>
    guideline: <int>
    preference: <int>
  blocker_count: <int>
  trace_id: <string>
  produced_at: <iso8601>
```

### `produced.n070.state-transition-mapping`
```yaml
event_type: produced.n070.state-transition-mapping
schema_version: "1.0.0"
payload:
  artifact_type: n070.state-transition-mapping
  producer_skill: state-transition-mapping
  consumer_nodes: [N090, N100, N160]
  object_count: <int>
  state_count: <int>
  orthogonal_pair_count: <int>   # orthogonal_with[] 关系数
  unreachable_state_count: <int> # gap: 孤立状态数
  trace_id: <string>
  produced_at: <iso8601>
```

### `produced.n070.permission-matrix-extraction`
```yaml
event_type: produced.n070.permission-matrix-extraction
schema_version: "1.0.0"
payload:
  artifact_type: n070.permission-matrix-extraction
  producer_skill: permission-matrix-extraction
  consumer_nodes: [N090, N100, N170]
  row_count: <int>
  undetermined_algo_count: <int>  # evaluation_algo=未明确 的行数
  conflict_count: <int>           # permission_conflict 条目数
  compliance_flag_count: <int>    # compliance_flag=true 的行数
  trace_id: <string>
  produced_at: <iso8601>
```

### `produced.n070.data-object-identification`
```yaml
event_type: produced.n070.data-object-identification
schema_version: "1.0.0"
payload:
  artifact_type: n070.data-object-identification
  producer_skill: data-object-identification
  consumer_nodes: [N090, N100, N160]
  object_count: <int>
  ddd_role_distribution:
    aggregate_root: <int>
    entity: <int>
    value_object: <int>
    service_data: <int>
    snapshot: <int>
    undetermined: <int>          # embedded_in 缺失的 entity 数
  trace_id: <string>
  produced_at: <iso8601>
```

---

## N080 事件

### `produced.n080.feature-points`
```yaml
event_type: produced.n080.feature-points
schema_version: "1.1.0"
payload:
  artifact_type: n080.feature-points
  producer_skill: prototype-to-feature-points
  consumer_nodes: [N090, N100]
  fallback_mode: has-prototype | partial-prototype | no-prototype
  page_count: <int>
  feature_count: <int>
  upstream_feedback_count: <int>  # 反哺 N070 的条目数
  missing_page_count: <int>       # N070 提及但原型未覆盖
  confidence_distribution:
    confirmed: <int>
    stable_inference: <int>
    needs_confirmation: <int>
  trace_id: <string>
  produced_at: <iso8601>
```

### `produced.n080.backend-requirements`
```yaml
event_type: produced.n080.backend-requirements
schema_version: "1.1.0"
payload:
  artifact_type: n080.backend-requirements
  producer_skill: prototype-to-backend-requirements
  consumer_nodes: [N090, N100, N150]
  endpoint_count: <int>
  be_gap_count: <int>
  be_gap_by_type:
    missing_object: <int>
    missing_endpoint: <int>
    missing_validation: <int>
    missing_event: <int>
  trace_id: <string>
  produced_at: <iso8601>
```

### `produced.n080.page-actions`
```yaml
event_type: produced.n080.page-actions
schema_version: "1.1.0"
payload:
  artifact_type: n080.page-actions
  producer_skill: page-action-extraction
  consumer_nodes: [N090, N100]
  action_count: <int>
  confirmation_distribution:
    weak: <int>
    medium: <int>
    strong: <int>
    very_strong: <int>
  design_risk_count: <int>   # 无确认但应有确认的 action 数
  trace_id: <string>
  produced_at: <iso8601>
```

### `produced.n080.form-fields`
```yaml
event_type: produced.n080.form-fields
schema_version: "1.1.0"
payload:
  artifact_type: n080.form-fields
  producer_skill: form-field-extraction
  consumer_nodes: [N090, N100, N150]
  form_count: <int>
  field_count: <int>
  conditional_required_count: <int>
  dsl_validated: <bool>
  trace_id: <string>
  produced_at: <iso8601>
```

---

## N090 事件

### `produced.n090.prd` ⭐ 触发 N100 门禁
```yaml
event_type: produced.n090.prd
schema_version: "2.0.0"
payload:
  artifact_type: n090.prd-document
  producer_skill: prd-generation
  consumer_nodes: [N100, N110, N370]
  contract_version: "n090.prd.v2"
  section_count: <int>           # PRD-XX 章节总数（标准 16）
  confirmed_section_count: <int>
  open_section_count: <int>
  upstream_refs_count: <int>     # upstream_refs[] 总条目数
  feedback_signal_count: <int>   # feedback_signals[] 数量
  n100_gate_trigger: true        # 明确触发 N100 门禁
  gate_trigger_reason: "prd_produced"
  trace_id: <string>
  produced_at: <iso8601>
```

### `produced.n090.gap-list`
```yaml
event_type: produced.n090.gap-list
schema_version: "2.0.0"
payload:
  artifact_type: n090.prd-gap-list
  producer_skill: prd-completion
  consumer_nodes: [N100, N110]
  contract_version: "n090.prd-gap.v2"
  gap_count: <int>
  blocker_gap_count: <int>
  gap_type_distribution: {}      # {missing_scope: N, missing_business_rule: N, ...}
  n005_influenced_count: <int>   # production_signal_modifier 影响的 GAP 数
  trace_id: <string>
  produced_at: <iso8601>
```

### `produced.n090.review-questions`
```yaml
event_type: produced.n090.review-questions
schema_version: "2.0.0"
payload:
  artifact_type: n090.prd-review-questions
  producer_skill: prd-review-question-generation
  consumer_nodes: [N380]         # 送入人工 SLA 队列
  contract_version: "n090.prd-review.v2"
  question_count: <int>
  p0_question_count: <int>
  blocker_question_count: <int>
  sla_level: P1                  # 评审会问题级别
  auto_escalate_after: "48h"
  trace_id: <string>
  produced_at: <iso8601>
```

---

## N005 → N070/N090 信号事件

### `feedback.n005.signal.production-pain`
```yaml
event_type: feedback.n005.signal.production-pain
payload:
  signal_type: production_pain | defect_cluster | nps_drop | incident_postmortem
  confidence_score: <float 0-1>   # N005 ML 降噪后的置信度
  affected_domains: [<L1 domain>] # 影响的 N070 L1 域（可为空）
  affected_prd_sections: []       # 影响的 PRD-XX 章节（可为空）
  urgency_modifier: +2 | +1 | 0  # 直接对应 024/023 的 production_signal_modifier
  source_node: N300 | N320 | N250
  recommended_action:
    - inject_to_n010              # 作为原始需求注入
    - raise_gap_priority          # 提升已有 GAP 优先级
    - trigger_n090_rerun          # 触发 N090 重跑
  trace_id: <string>
  produced_at: <iso8601>
```

**N070/N090 消费规则：**
- `confidence_score < 0.6` → 忽略，记录 `production_signal_requires_triage`
- `confidence_score ≥ 0.6 AND recommended_action contains raise_gap_priority` → 在 023 中将对应 GAP 的 `urgency_score +1`，上限 5
- `confidence_score ≥ 0.8 AND recommended_action contains inject_to_n010` → 通过 N010 → N030 → N070 正常流入，不直接修改 N070 输出

---

## 门禁状态事件

### `state.n100.gate.result`
```yaml
event_type: state.n100.gate.result
payload:
  gate_decision: go | conditional-go | no-go
  overall_score: <float>
  sub_scores:
    completeness: <float>
    executability: <float>
    conflict: <float>
    vulnerability: <float>
    pending: <float>
  hard_rule_triggered: <bool>
  consumer_nodes: [N110, N370, N380]
  sla_level: P0 | P1             # no-go → P0；conditional-go → P1
  auto_escalate_after: "24h"     # no-go 时 24h 内需人工处置
  trace_id: <string>
```

### `state.n110.handover.result`
```yaml
event_type: state.n110.handover.result
payload:
  pass_readiness: ready | conditional_ready | needs_action | not_ready
  handover_readiness_score: <float>
  execution_mode: formal_mode | minimal_mode | refresh_mode | blocked_mode
  circuit_breaker_state: open | closed | half-open
  current_refresh_count: <int>
  consumer_nodes: [N120, N230, N360, N370]
  sla_level: P0 | P1 | P2
  trace_id: <string>
```

---

## Schema 版本历史

| 节点组 | 当前版本 | 上次 Breaking Change | 原因 |
|---|---|---|---|
| N070 | 1.0.0 | — | 初始版本 |
| N080 | 1.1.0 | — | 引入 N080_COMMON_CONTRACTS |
| N090 | 2.0.0 | 2026-04-24 | 新增 upstream_refs[]、N005 signal、cross-node-bridge |
| N100 | 2.1.1 | 2025-Q4 | 新增 re_gate_session_id |
| N110 | 2.1.0 | 2025-Q4 | 引入 circuit-breaker |
