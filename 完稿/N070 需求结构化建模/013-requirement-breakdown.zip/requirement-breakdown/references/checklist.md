# Checklist

Before finalizing, verify all items below.

## Structure
- Is the output organized around business objects or stable domains rather than just PRD headings?
- Are capabilities grouped into meaningful layers instead of a flat bullet list?
- Are core objects, actors, dependencies, and open questions all present?

## Completeness
- Did you identify the main business goal and boundaries?
- Did you list the key actors and what they do?
- Did you identify the main objects and their important data or lifecycle hints?
- Did you separate core capabilities from control mechanisms?
- Did you list upstream and downstream dependencies?
- Did you capture exception handling or special paths if present?

## Quality
- Are confirmed facts separated from inference?
- Are missing details marked as gaps instead of guessed?
- Is evidence attached to major objects, capabilities, dependencies, and questions?
- Is the result reviewable without rereading the whole PRD?

## Downstream usefulness
- Can a state-modeling skill find state-bearing objects from this output?
- Can a rule-extraction skill find control points and decision logic from this output?
- Can a permission skill identify actors, actions, resources, and boundaries from this output?

## Cross-module and multi-channel (N070 增强)
- [ ] 当 PRD 引用同系统其他模块时，是否在依赖表中标注了"同系统兄弟模块"及依赖强度？
- [ ] 当系统是多端架构时，能力树是否标注了适用渠道？
- [ ] 当 PRD 引用全局上下文文档时，是否填写了 §6.5 全局约束传递章节？
- [ ] 实施分桶是否标注了前置分桶依赖？
- [ ] 证据字段是否使用了 `[doc_id]§[section].L[start]-L[end]` 统一锚点格式？
