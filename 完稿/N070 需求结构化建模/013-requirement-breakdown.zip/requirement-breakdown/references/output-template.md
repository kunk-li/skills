# 输出模板 / output template

默认按输入主语言输出。技术标识、状态值、错误码、字段名保持原样。

## 1. 摘要 / Summary
- 识别出的领域数量
- requirement 基线完整度
- 最大结构风险
- 是否具备单独交付条件

## 2. 输出模式 / Output mode
| mode | 是否输出 | 说明 |
|---|---|---|
| table_mode |  | 核心字段快照 |
| full_mode |  | 默认完整视图 |
| machine_mode |  | JSON/YAML 友好结构 |
| diff_mode |  | 版本差异视图 |
| tree / mermaid / json_schema |  | 可选增强 |

## 3. 领域字典 / Domain dictionary
| domain | 名称 | owner | 说明 | 来源 | 明确性 | 证据 |
|---|---|---|---|---|---|---|

## 4. requirement catalog
| requirement_id | domain | parent_id | level | title | summary | category | constraint_strength | testability | follow_up_question | lifecycle.status | introduced_in | deprecated_in | priority | phase | wave | decision_refs | blocker_refs | open_question_refs | certainty | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

说明：
- `level` 只允许 `L1/L2/L3/L4/L5`
- `testability` 只允许 `testable/quantifiable/vague/subjective`
- `decision_refs` 等引用字段没有时写 `[]`

## 5. capability tree / 能力树
按 `L1 → L2 → L3 → L4 → L5` 展开。可用缩进表、树视图或 mermaid。

## 6. cross-cut dependencies / 跨切面依赖
| requirement_id | cross_cut_ref | ref_type | reason | likely downstream impact | certainty | evidence |
|---|---|---|---|---|---|---|

说明：
- `ref_type` 可用 `requirement / rule / state_machine / permission / object / external_dependency / 待确认`

## 7. acceptance readiness / 可测性与验收准备
| requirement_id | level | testability | missing metric or ambiguity | follow_up_question | blocked downstream | evidence |
|---|---|---|---|---|---|---|

## 8. lifecycle and change history / 生命周期与变更
| requirement_id | introduced_in | status | deprecated_in | priority | phase | wave | change_history | evidence |
|---|---|---|---|---|---|---|---|---|

## 9. boundaries and dependencies / 边界与依赖
| requirement_id | dependency | dependency_type | ownership | source_of_truth | impact if missing | certainty | evidence |
|---|---|---|---|---|---|---|---|

## 10. open questions / 待确认问题
| type | item_ref | question | impact | next action | evidence |
|---|---|---|---|---|---|

## 11. optional coverage hooks / 可选覆盖检查
若兄弟 skill 可用，补充：
- `requirements_without_rules`
- `requirements_without_objects`
- `requirements_without_state_links`
- `requirements_without_permission_links`
