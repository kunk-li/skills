# Common failure modes

## Failure mode 1: chapter mirroring
Symptom: the output simply paraphrases each PRD section in order.
Fix: rebuild around objects, actors, and capabilities.

## Failure mode 2: vague capability labels
Symptom: uses labels like “manage workflow” or “support lifecycle” without breaking them down.
Fix: split into concrete capability items with trigger, object, and result.

## Failure mode 3: control logic hidden in prose
Symptom: approvals, validations, anti-bypass logic, or restrictions are buried inside summaries.
Fix: move them into the control mechanisms section.

## Failure mode 4: boundaries are implicit
Symptom: the output makes the current module appear to own work actually done by other systems or teams.
Fix: add an explicit dependency and boundary table.

## Failure mode 5: inferred facts presented as confirmed
Symptom: missing ownership, lifecycle stages, or source-of-truth details are silently guessed.
Fix: mark them as inference or open questions.

## Failure mode 6: no downstream utility
Symptom: a reviewer still cannot tell what objects exist, what acts on them, or where the unclear parts are.
Fix: strengthen the core objects, capability tree, and open questions sections.

## Failure mode 7: cross-module dependency flattened
Symptom: module A depends on module B for state, authorization, or shared data, but the output labels it only as “internal system” or ignores it entirely.
Fix: use the “same-system sibling module” dependency type and record dependency direction plus dependency strength.

## Failure mode 8: channel-blind capability tree
Symptom: capabilities that differ by channel, platform, or client type are merged together, so the reviewer cannot tell whether the behavior applies to web, mobile, desktop, api, or all channels.
Fix: use the “适用渠道” column explicitly whenever the system has channel-specific behavior.

## Failure mode 9: global constraints invisible
Symptom: prohibitions, ghost entities, and system-wide red lines from global context are missing from the output.
Fix: when global context is provided, always fill the global constraints inherited section.
