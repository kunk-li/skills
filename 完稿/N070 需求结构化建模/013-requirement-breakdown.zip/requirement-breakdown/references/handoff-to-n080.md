# N070 → N080 节点交接协议

> 本文件定义 N070（需求结构化建模）向 N080（原型解析）的正式交接规范。

---

## 1. N070 输出捆绑包 / Upstream Output Bundle

N070 向下游提供以下产物，N080 按优先级消费：

### 必须产物（N080 存在时必须检查是否可用）

| 产物 | 来源 Skill | 字段格式 | 用途 |
|---|---|---|---|
| 对象目录（Object Catalog） | 013 | `OBJ-{domain}-{nnn}` 行 | N080 功能点/字段的对象词汇来源 |
| 角色图（Role Graph） | 013 | `subject` + `role` 行 | N080 动作的主体权限映射 |
| 需求结构树（Requirement Tree） | 013 | `REQ-{domain}-{nnn}` + L1-L5 层级 | N080 功能点的需求溯源 |
| 业务规则清单（Rule Inventory） | 014 | `RULE-{domain}-{nnn}` 行 | N080 后端需求的逻辑约束来源 |
| 状态流转表（State Table） | 015 | `SM-{domain}-{nnn}` 行 | N080 动作的前置/后置状态约束 |
| 权限矩阵（Permission Matrix） | 016 | `PERM-{domain}-{nnn}` 行 | N080 动作的 confirmation_strength 参考 |
| 数据对象清单（Object Catalog v2） | 017 | `OBJ-*` + `ddd_role` + `constraint_tags` | N080 字段类型与约束的语义基础 |

### 降级规则（部分 N070 输出不可用时）

```
if 013 输出不可用:
  N080 fallback → no-prototype or partial-prototype 模式
  所有 object/role 词汇标记为 source-derived
  在 upstream_alignment.missing_n070 中列出缺失项

if 只有 013 可用（014-017 不可用）:
  N080 使用 013 的对象名作为唯一词汇来源
  但 N080 不得基于 013 推断业务规则（不得代替 014）

if N070 全部不可用:
  N080 只能从原型自推断，全部词汇标记 source-derived
  在 output summary 中声明 upstream_n070_available: false
```

---

## 2. N080 入场校验 / Downstream Intake Protocol

N080（018）启动前，必须执行以下入场检查：

```yaml
n070_intake_check:
  # Step 1: 确认可用的 N070 输出
  available_artifacts:
    - artifact: requirement_breakdown    # 013 输出
      available: true | false
      location: "<文件路径或对话上下文>"
    - artifact: business_rule_inventory  # 014 输出
      available: true | false
    - artifact: state_transition_table   # 015 输出
      available: true | false
    - artifact: permission_matrix        # 016 输出
      available: true | false
    - artifact: object_catalog           # 017 输出
      available: true | false

  # Step 2: 词汇对齐检查
  vocabulary_alignment:
    n070_object_names: [<从 013/017 提取的 OBJ-* 列表>]
    n070_role_names:   [<从 013/016 提取的 subject 列表>]
    n070_domain_list:  [<从 013 提取的 L1 domain 列表>]
    alignment_status: full | partial | none

  # Step 3: 声明当前运行模式
  fallback_mode: has-prototype | partial-prototype | no-prototype
  upstream_n070_available: true | false
```

---

## 3. N070 → N080 词汇对齐规则 / Vocabulary Alignment Rules

### 3.1 对象名对齐

N080 在创建 feature/action/field 时，若涉及业务对象，**必须**：

1. 优先使用 N070 的 `OBJ-{domain}-{nnn}` 对应对象名（`name` 字段）
2. 若原型中出现 N070 未定义的对象 → 标注为 `source-derived: true`，并在 `upstream_feedback[]` 中记录候补对象
3. 若原型中对象名与 N070 不一致 → 在 `alignment_note` 中记录冲突，不得静默覆盖

### 3.2 角色名对齐

N080 的 `subject` / `actor` 字段值 **必须**来自以下来源之一：
- N070 权限矩阵中已定义的 subject
- 原型中明确标注的角色（可能是 N070 未识别的新角色）
- `source-derived: true` 标注的推断角色

### 3.3 冲突处理

```
当 N080 在原型中发现 N070 未收录的对象或角色时：
  action: 记录到 upstream_feedback[]
  format:
    - type: new_object | new_role | naming_conflict
      n080_term: <原型中的词汇>
      n070_closest: <最接近的 N070 词汇，若有>
      page_evidence: <P-XX 页面证据>
      suggested_action: "补充到 013 §4 对象表 / 016 权限矩阵"

当原型命名与 N070 明确冲突时：
  action: 在 alignment_note 中标记，保持两者并呈现
  不得: 静默选择其中一个作为唯一真相
```

---

## 4. N080 的 N070 覆盖检查 / Coverage Verification

N080（018）产出后，在 `coverage_report` 中补充 N070 覆盖检查：

```yaml
n070_coverage_check:
  # 每条 N070 需求是否被至少一个 N080 feature 覆盖
  uncovered_requirements:
    - req_id: REQ-ORDER-005
      reason: "原型未呈现该需求的 UI 入口，可能是纯后端逻辑"

  # 每条 N070 对象是否在 N080 feature/field 中被引用
  orphan_objects:
    - obj_id: OBJ-ORDER-003
      reason: "原型中未出现对应的 UI 元素"

  # 每条 N080 feature 是否可追溯到至少一条 N070 需求
  untraced_features:
    - ft_id: FT-ORDER-02-005
      reason: "原型中有该功能，但 N070 需求树中未识别"
      suggested_action: "反哺 013 补充 REQ-ORDER-XXX"
```

---

## 5. 交接完成信号 / Handoff Completion Signal

N080 完成后，在 output summary 中输出：

```yaml
n070_to_n080_handoff:
  status: complete | partial | no_upstream
  n070_artifacts_used: [013, 015, 016]    # 实际使用了哪些 N070 skill 的输出
  vocabulary_alignment: full | partial | none
  upstream_feedback_count: 3              # 反哺给 N070 的候补项数量
  coverage_gaps: 2                        # 未被 N080 覆盖的 N070 需求数
  ready_for_n090: true                    # 018 完成且 P- 命名空间稳定
```

`ready_for_n090: false` 时，N090 不得以 N080 输出作为主要输入启动。
