# N070–N110 需求工程 Skills 全链路导航

> 本文件是 23 个 skills 的总入口。快速定位你需要的节点，然后进入对应节点的 README 获取详细信息。

---

## 节点全景

```
原始材料（PRD草稿/政策/原型/笔记）
       │
       ▼
  N070 需求结构化建模  (013–017)
  将文字需求拆解为结构化基线（REQ-/OBJ-/RULE-/SM-/PERM-）
       │
       ├──► N080 原型解析  (018–021)  [可与 N070 并行]
       │    从视觉材料提取功能点/动作/字段（P-/FT-/BE-/ACT-/FLD-）
       │
       ▼
  N090 PRD 产出与评审  (022–024)
  整合成正式 PRD（PRD-XX）→ 缺口分析（GAP-XXX）→ 评审问题（Q-XXX）
       │
       ▼
  N100 需求质量门禁  (025–030)
  六项量化检查 → gate 决策（go / conditional-go / no-go）
       │
       ▼
  N110 需求交接与验收  (031–035)
  交接包 → 验收标准 → 变更影响 → 同步 → 工程反馈
```

---

## 节点 README 导航

| 节点 | README | Skills | 核心产出 |
|---|---|---|---|
| N070 | [N070_README.md](N070_README.md) | 013–017 | L1-L5 结构 + RULE/SM/PERM/OBJ 目录 |
| N080 | [N080_README.md](N080_README.md) | 018–021 | 功能点/后端需求/动作/表单字段 |
| N090 | [N090_README.md](N090_README.md) | 022–024 | PRD + GAP 清单 + 评审问题 |
| N100 | [N100_README.md](N100_README.md) | 025–030 | 质量评分 + gate 决策 |
| N110 | [N110_README.md](N110_README.md) | 031–035 | 交接包 + AC + 变更影响 |

---

## 快速定位

**我有什么 → 我应该运行哪个 skill**

| 输入材料 | 推荐入口 |
|---|---|
| PRD 草稿 / 政策文件 / 解决方案笔记 | N070 → 013 |
| 原型截图 / HTML 原型 / 标注稿 | N080 → 018 |
| 已有 N070/N080 结构化输出 | N090 → 022 |
| 已有 PRD，需要找缺口 | N090 → 023 |
| 需要为评审会准备问题 | N090 → 024 |
| 需要验证 PRD 质量 | N100 → 025-030 |
| PRD 已通过质量检查，准备交给工程 | N110 → 031 |
| 需求发生变更 | N110 → 033 |
| 收到工程反馈 | N110 → 035 |

---

## 跨节点 ID 命名空间一览

| 节点 | ID 前缀 | 含义 |
|---|---|---|
| N070 | REQ- / RULE- / SM- / PERM- / OBJ- | 需求/规则/状态机/权限/数据对象 |
| N080 | P- / FT- / BE- / API- / ACT- / FLD- / F | 页面/功能/后端/接口/动作/字段/表单 |
| N090 | PRD-XX / GAP-XXX / Q-XXX | PRD 章节/缺口/评审问题 |
| N100 | issue_id / blocker_id / OVR- | 问题/阻断项/override |
| N110 | artifact_id / change_id / FB- | artifact/变更/工程反馈 |

---

## 最常见的跨节点规则

1. **N070 → N080**：N080 复用 N070 的对象/角色词汇（软链接，非强制），使用 `upstream_alignment` 记录
2. **N080 → N090**：N090 PRD 章节应在 `upstream_refs[]` 中引用 N080 的 P-/FT- ID
3. **N100 → N110**：030 的 gate_status 决定 031 的 execution_mode（见 031/references/readiness-scoring.md）
4. **N110 → N090**：035 工程反馈裁决为 ACCEPTED_WITH_CHANGE 时，应触发 022/023 的 PRD 局部更新

---

## 常见问题

**Q: 我可以只运行 N100 的某一个 skill 吗？**
A: 可以，但 030（quality-review）依赖前五项的分数。单独运行 025-029 中的某一个可以独立产出结论，但 030 需要全部。

**Q: 没有原型，可以跳过 N080 直接进 N090 吗？**
A: 可以。018 有 `no-prototype` fallback 模式，或直接从 N070 输出进入 N090。

**Q: N110 的 5 个 skill 必须全部运行吗？**
A: 不需要。031 和 032 是基础组合（交接+验收标准）；033/034 仅在有变更时触发；035 仅在有工程反馈时触发。
---

## 跨节点基础设施文件

| 文件 | 用途 |
|---|---|
| [workflow-v2-event-schemas.md](workflow-v2-event-schemas.md) | 所有节点的事件类型、payload schema、N005 信号消费规则 |
| [artifact-versioning-rules.md](artifact-versioning-rules.md) | schema_version 升版规则、破坏性变更检测、双轨并存协议 |
| [cross-node-bridge-contract.md](cross-node-bridge-contract.md) | N080→N090 upstream_refs、N090→N100 GAP 回写、N100→N110 继承 |

> 每个 SKILL.md 的 "Workflow v2 artifact contract" 区块声明本 skill 的 `artifact_type`、
> `schema_version`、`produced_event_name`、`consumer_nodes` 和 `n005_consumption` 级别。

---

## 跨节点交接协议 / Cross-Node Transition Protocols

`transitions/` 目录包含四个节点间的正式交接协议和验证工具：

| 文件 | 内容 |
|---|---|
| `N070-N080-transition.md` | 输出捆绑包定义 + 词汇对齐规则 + 覆盖检查 + 完成信号 |
| `N080-N090-transition.md` | N080 到 PRD 的 ID 映射 + upstream_refs 覆盖验证 + 完成信号 |
| `N090-N100-transition.md` | GAP 到 issue 的路由规则 + N100 入场校验 + GAP 回写协议 |
| `N100-N110-transition.md` | Gate→mode 映射 + open_questions 继承 + N110 兄弟 skill 触发 |
| `cross_node_validator.py` | 跨节点对齐自动验证脚本（可检查所有四个过渡） |

### 使用验证脚本

```bash
# 验证单个过渡
python3 transitions/cross_node_validator.py \
  --transition N090-N100 \
  --n090 ./session/prd_main.md \
  --n100 ./session/gate_report.md

# 验证所有过渡（输出 JSON）
python3 transitions/cross_node_validator.py \
  --transition all \
  --n070 ./n070.md --n080 ./n080.md \
  --n090 ./n090.md --n100 ./n100.md --n110 ./n110.md \
  --json
```

### 每个交接协议的核心要求

| 过渡 | 关键检查项 | 阻断条件 |
|---|---|---|
| N070→N080 | N080 使用 N070 OBJ-* 词汇 ≥50%；ready_for_n090 = true | ready_for_n089 = false |
| N080→N090 | PRD upstream_refs 覆盖 FT-* ≥70%；关键章节存在 | PRD-06/07 为空且 N080 有数据 |
| N090→N100 | GAP-XXX 链接率 ≥50%；gate 字段合法 | gate 字段缺失 |
| N100→N110 | execution_mode 与 gate 一致；open_questions 继承 blockers | execution_mode 与 gate 不一致 |
