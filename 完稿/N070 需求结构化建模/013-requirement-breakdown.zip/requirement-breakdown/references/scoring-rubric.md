# Scoring rubric

## 1 - weak
- Mostly summary prose
- Mirrors chapter structure without decomposition
- Missing objects, dependencies, or open questions
- Guesses details not stated in the source

## 2 - usable draft
- Extracts some objects and capabilities
- Still mixes business flow, control logic, and dependencies together
- Contains gaps but not all are clearly marked

## 3 - reviewable
- Object-first structure is clear
- Core capabilities, controls, dependencies, and gaps are separated
- Evidence exists for major conclusions
- Downstream analysts can use it without major rework

## 4 - design-ready
- Structure is stable and complete enough for design planning
- Open questions are concrete and prioritized
- Boundaries and ownership are explicit
- Implementation buckets are actionable
