# Scoring rubric

## 1 - weak
- Mostly summary prose
- Mirrors chapter structure without decomposition
- Missing objects, dependencies, or open questions
- Guesses details not stated in the source

## 2 - usable draft
- Extracts some objects and capabilities
- Still mixes business flow, control logic, and dependencies together
- Contains gaps but not all are clearly marked

## 3 - reviewable
- Object-first structure is clear
- Core capabilities, controls, dependencies, and gaps are separated
- Evidence exists for major conclusions
- Downstream analysts can use it without major rework

## 4 - design-ready
- Structure is stable and complete enough for design planning
- Open questions are concrete and prioritized
- Boundaries and ownership are explicit
- Implementation buckets are actionable

---

## L1–L5 判别矩阵 / Judgment Case Matrix

使用以下决策树与边界 case 确定层级，避免主观判断。

### 判别决策树

```
Q1: 去掉这条条目，某类核心业务边界会消失（即整个业务域不再存在）？
    YES → L1 Domain
    NO  → Q2

Q2: 去掉这条条目，某个完整业务场景会无法完成（即特定用户目标无法达到）？
    YES → L2 Capability
    NO  → Q3

Q3: 用户或外部系统能直接感知到这个动作/功能（即它在产品 UI 或 API 上可见）？
    YES → L3 Feature
    NO  → Q4

Q4: 可以用 if/else/when 精确表达，且去掉后某个 L3 功能会产生错误行为？
    YES → L4 Rule
    NO  → Q5

Q5: 这是一个"不写 if"都不应成立的硬约束（如合规、数据完整性、安全红线）？
    YES → L5 Constraint
    NO  → 重新检查是否为 omission 而非 requirement
```

### 边界 case 对照表

| Case | 描述 | 正确层级 | 常见误判 | 判别理由 |
|---|---|---|---|---|
| 用户登录 | 系统支持账号密码登录 | L3 | L2 | 用户可感知的具体动作，不是整个业务场景 |
| 认证域 | 系统对用户身份进行认证与授权管理 | L2 | L3 | 去掉它，登录/SSO/权限等所有功能全部失效 |
| 身份与访问管理 | 管控"谁能以什么身份访问什么资源" | L1 | L2 | 去掉它，整个 IAM 业务边界消失 |
| 密码最短 8 位 | 密码必须包含至少 8 个字符 | L5 | L4 | 无条件硬约束，不存在 if/else 分支 |
| 试错锁定规则 | 连续错误 5 次则锁定 15 分钟 | L4 | L5 | 有明确的 if/else 逻辑（次数→动作），可被覆盖 |
| 审批流转 | 订单审批后进入履约环节 | L4 | L3 | 不可见于 UI，是内部状态转移规则 |
| 多步报销 | 员工提交报销单→部门审核→财务审批 | L2 | L3 | 整个业务场景，包含多个 L3 动作 |
| 数据保留 7 年 | 财务数据必须保留不少于 7 年 | L5 | L4 | 合规硬约束，无例外分支 |
| 限时折扣 | 活动期间价格按系数折扣 | L4 | L3 | 有条件（活动期间），可用 if/else 表达 |
| 金融交易 | 系统支持资金划拨与结算 | L1 | L2 | 去掉它，整个交易业务域消失 |

### 常见误判模式

- **L2 误写成 L3**：描述了一个过程（"用户完成…"）但缺少多步组合。判断标准：是否包含多个用户或系统动作的串联？
- **L4 误写成 L5**：看起来是硬约束，但有例外路径（如 VIP 用户绕过）→ 应为 L4。
- **L5 误写成 L4**：写了 if/else，但 else 分支从来不应触发（如"若违反数据主权法则拒绝"）→ 应为 L5。
- **L3 误写成 L2**：一个功能被过度描述成场景。测试方法：它有多个子功能吗？每个子功能能独立被 L2 收敛吗？

### Cross-cut 识别规则

Cross-cut 表示该条目在多个 Domain/Capability 上均有表现，需要显式标注 `cross_cuts[]`：

| 信号 | 识别方法 | 示例 |
|---|---|---|
| 跨 Domain 复用 | 同一规则出现在 ≥2 个 L1 下 | 数据保留规则同时影响财务和用户中心 |
| 系统级约束 | 文档明确说"全局""所有模块""统一" | 统一认证、全局限流 |
| NFR 类 | 性能/安全/可用性要求不附属于某个 L2 | 99.9% SLA、加密传输 |
| 角色级权限 | 同一角色在多个功能域都有特权 | 超级管理员跨域操作 |

