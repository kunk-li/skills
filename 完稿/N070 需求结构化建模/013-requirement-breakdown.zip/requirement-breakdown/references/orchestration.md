## Stage metadata
- n070_stage: 1
- depends_on: []
- blocks: ['014', '015', '016', '017']
- may_consume: []

# Orchestration with adjacent skills

## Typical upstream
- raw PRD
- solution notes
- workflow description
- fragmented requirements collected from multiple sections

## Typical downstream
- business-rule-extraction
- state-transition-mapping
- permission-matrix-extraction
- completeness review or quality gate skills
- solution design and implementation planning

## Hand-off guidance
A good hand-off should make it easy for downstream skills to find:
- state-bearing objects
- rule-bearing control points
- role/action/resource hints
- boundary and dependency contracts
- unresolved ambiguities that should not be auto-completed

---

## N070 共同契约

### Object name alignment contract (C1)
- **Canonical source**: this skill's §4 "核心业务对象" table IS the canonical object name source for all other N070 skills.
- Downstream N070 skills (data-object-identification / business-rule-extraction / state-transition-mapping / permission-matrix-extraction) MUST use object names from this table when referencing business objects.
- If a downstream skill discovers new objects not in this table, they must tag them as "new object (not in breakdown)".

### N070 execution stage (C3)
- This skill executes in **stage 1** of N070 internal pipeline.
- Stage 1 (must complete first): **requirement-breakdown**
- Stage 2 (parallel, depends on stage 1): data-object-identification, business-rule-extraction, state-transition-mapping
- Stage 3 (depends on stages 1-2): permission-matrix-extraction

Stage 1 output (specifically the object table and dependency graph) is the foundation for all downstream stages.

### Downstream CSV dependency handoff (C4)
- `需求结构树.md` is the stage-1 canonical structural input for all later consumers.
- Stage-2 skills produce these CSV artifacts for downstream nodes:
  - `业务规则清单.csv`
  - `状态流转表.csv`
  - `权限矩阵.csv`
  - `数据对象清单.csv`
- Recommended downstream CSV consumers in workflow v2:
  - `业务规则清单.csv` → N090 / N100 / N110 / N150 / N170 / N230 / N260
  - `状态流转表.csv` → N090 / N100 / N110 / N150 / N170 / N230 / N260
  - `权限矩阵.csv` → N090 / N100 / N110 / N170 / N230 / N260
  - `数据对象清单.csv` → N090 / N100 / N110 / N160 / N170 / N230 / N260
