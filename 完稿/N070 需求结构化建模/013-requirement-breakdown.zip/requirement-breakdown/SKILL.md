---
name: requirement-breakdown
description: break complex requirement material into a reusable, business-agnostic structure with stable requirement ids, five-level decomposition, cross-cut dependencies, testability, lifecycle metadata, and downstream-ready references. use when the input is a prd, workflow draft, policy package, or solution note and the main need is to produce a self-contained requirement baseline that can also combine cleanly with rule, state, permission, and data-object skills.
---
# requirement-breakdown

Build a reusable structural decomposition of the input. Focus on extracting a stable requirement baseline, not rewriting the source document.

## N070 stage metadata / 阶段元数据
- `n070_stage`: `1`
- `depends_on`: `[]`
- `blocks`: `['014', '015', '016', '017']`
- `may_consume`: `[]`
- Note: actual SKILL.md frontmatter must stay validator-compatible (`name` and `description` only), so the stage metadata is placed in the body top section instead of YAML frontmatter.

## Role / 角色定位
Produce a self-contained requirement baseline that answers:
- what domains, capabilities, features, rules, and constraints exist
- what depends on what across functional slices
- which items are already testable and which are still vague
- which lifecycle/version signals exist
- which unresolved questions should not be guessed

## Single-skill value / 单独使用价值
- 仅基于 PRD 或等价需求文本即可独立运行。
- 即使没有兄弟 skill，也必须产出完整、可读、可继续向下游传递的需求基线。
- 单独使用时，仍强制要求可执行叶节点带 `testability`，避免产出“无法验收的需求树”。

## Multi-skill value / 组合使用价值
- 作为五个 N070 skill 的命名与范围底座。
- 为 `business-rule-extraction`、`state-transition-mapping`、`permission-matrix-extraction`、`data-object-identification` 提供统一的领域名、对象名、角色名、依赖边界与 requirement id。
- 当兄弟产物存在时，追加 cross-skill refs 和 coverage hooks，而不是重复抄写兄弟产物。

## Allowed inputs / 允许输入
- 主输入：PRD、需求说明、流程草案、方案草案。
- 可选输入：系统级全局上下文文档（仅用于提取全局约束、禁用概念、领域字典、公共角色或公共依赖）。
- 可选输入：兄弟 skill 产物，用于对齐命名和覆盖检查。

## Prohibited inputs / 禁止输入
- 不得用代码实现、数据库现状、原型截图替代需求证据。
- 不得把经验性架构习惯补写成需求事实。

## Required decomposition model
必须使用固定五层，不允许自由增删层级名称：
- `L1 Domain`
- `L2 Capability`
- `L3 Feature`
- `L4 Rule`
- `L5 Constraint`

判定法则：
- 去掉它整个系统就失去某类核心业务边界 → `L1`
- 去掉它某个业务场景无法完成 → `L2`
- 用户或外部系统可感知的动作/功能 → `L3`
- 可用 if/else 明确表达的规则 → `L4`
- 不写 if 都不该成立的硬约束 → `L5`

规则：
- 所有叶节点必须是 `L3`、`L4` 或 `L5`
- `L1/L2` 只作组织与聚合，不可充当最终验收项

## Required row contract
每个 requirement row 尽量包含：
- `requirement_id`
- `domain`
- `parent_id`
- `level`
- `title`
- `summary`
- `category`
- `constraint_strength`
- `cross_cuts[]`
- `realized_in`
- `contract_owner`
- `consumes_from[]`
- `testability`
- `follow_up_question`
- `lifecycle`
- `decision_refs[]`
- `blocker_refs[]`
- `open_question_refs[]`
- `certainty`
- `evidence`

字段规则：
- `constraint_strength` 使用 `constraint / rule / guideline / preference`
- `testability` 使用 `testable / quantifiable / vague / subjective`
- `vague` 与 `subjective` 必须伴随 `follow_up_question`
- `lifecycle.status` 使用 `active / deprecated / suspended / planned / 未明确`

## Cross-module provenance / 跨模块归属（模块化 / brownfield 适用）
- 模块化系统里，一个需求的**声明位置 ≠ 实现位置**。二者不同时显式记录：
  - `contract_owner`：谁拥有这条能力 / 契约（概念归属）。
  - `realized_in`：它实际在哪个模块 / 组件落地（实现归属）——"编排层声明、执行器层实现"是常见形态。
  - `consumes_from[]`：它向哪些上游模块取数据 / 能力。
- 目的：让下游（对象 017 / 验收 032 AH- / built-vs-spec 093）把每条需求路由到真正实现它的模块，而不是停在声明它的文档处。
- **brownfield 反推**：当证据表明某能力应存在、但在实现源中找不到落地时，标 `absent_but_expected: true`（区别于 `certainty=待确认`——后者是"信息不足"，前者是"明确该有却缺"）。

## Global validation rule ids / 全局校验规则编号
- Canonical references for this skill's validation rules:
- `013.R00_evidence_required`
- `013.R01_grain_hierarchy`
- `013.R02_vague_requires_question`
- `013.R03_id_convention`
- `013.R04_cross_cut_resolvable`
- `013.R05_p0_must_be_testable`
- `013.R06_fallback_discipline_013`
- When old notes or logs mention a short name like `R03`, interpret it through the list above; the global id is the canonical reference from v2.1.2 onward.

## Workflow / 执行流程
1. 先识别领域、对象、角色、能力边界。
2. 按固定五层生成 requirement catalog，而不是照抄原文目录。
3. 为每个 requirement 生成稳定 id；优先复用已有 id，没有就按 `{REQ-domain-nnn}` 生成。
4. 单独提取 `cross_cuts[]`，不要把跨切面依赖埋在 description 里。
5. 对所有叶节点评估 `testability`。
6. 抽取版本演化与优先级线索，写入 `lifecycle`。
7. 若有兄弟 skill，追加 cross refs 和 coverage hooks。
8. 使用 `references/output-template.md` 输出。
9. 在最终输出前检查 `references/checklist.md`、`references/common-failure-modes.md` 与 `references/interoperability-contract.md`。

## Output / 默认输出契约
默认支持以下模式：
- `tree`: markdown 树视图
- `table`: 平铺表，便于 CSV 化
- `mermaid`: 结构图或依赖图
- `json_schema`: 机器可消费结构
- `table_mode` / `full_mode` / `machine_mode` / `diff_mode`

如果用户未指定：
- 默认人审输出用 `full_mode`
- 需要给下游自动化时同时补 `machine_mode`
- 提到版本差异、增量变更、回放时启用 `diff_mode`

## Boundary rules / 边界规则
- 若 `business-rule-extraction` 已存在，要求 `REQ-L4/L5` 尽量回指 `RULE-*`
- 若 `state-transition-mapping` 已存在，要求涉及状态变化的 `L3/L4` 尽量回指 `SM-*`
- 若 `permission-matrix-extraction` 已存在，要求访问控制类 requirement 尽量回指 `PERM-*`
- 若 `data-object-identification` 已存在，要求对象类 requirement 尽量回指 `OBJ-*`
- 没有兄弟输入时，仍然必须输出完整 requirement baseline，不得中止

## Output language and evidence rules
- 跟随输入主语言输出自然语言说明。
- 不翻译状态值、字段名、错误码、API 名、常量名。
- 证据字段使用：`[doc_id]§[section].L[start]-L[end]`
- 确定性只允许：`明确写明 / 基于上下文推断 / 待确认`

## Evidence anchor contract / 证据锚点契约
- Canonical anchor format: `[doc_id]§[section].L[start]-L[end]`
- Canonical YAML-safe regex pattern: `'\[[^\]]+\]§[^.]+\.L\d+(-L\d+)?'`
- Prefer a single-quoted YAML scalar when documenting or exporting the regex to avoid escape ambiguity across parsers.
- Evidence must point to the source that actually supports the row; do not use a nearby paragraph as a placeholder.


## Workflow v2 artifact contract
```yaml
artifact_type: n070.requirement-breakdown
schema_version: "1.0.0"
producer_skill: requirement-breakdown
consumer_nodes: [N080, N090, N100, N230, N260]
workflow_alias: 需求结构拆解.md
produced_event_name: produced.n070.requirement-breakdown
canonical_fields:
  - req_id         # REQ-{domain}-{nnn}
  - level          # L1-L5
  - title
  - domain
  - certainty      # 明确写明 / 基于上下文推断 / 待确认
  - evidence
  - blocking
  - cross_cuts
  - decision_refs
  - lifecycle.status
n005_consumption: indirect   # N005 → N010 → N030 → N070，不直接消费
```


## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认，并参照 `references/scoring-rubric.md` 做质量自评。确认已完成：
- 所有必填字段已填写，无静默缺失
- 使用了 N070 标准 ID 命名空间（REQ-/RULE-/SM-/PERM-/OBJ-）
- 证据锚点格式符合 `[doc_id]§[section].L[start]-L[end]`
- certainty 只使用：明确写明 / 基于上下文推断 / 待确认

## Key references
- `references/node-guide.md`：N070 节点导航（5 个 skill 的执行顺序、跨 skill 契约、与 N080 交接规则）
- `references/system-guide.md`：全系统导航（23 个 skill 索引、跨节点 ID 命名空间、常见问题）
- `references/handoff-to-n080.md`：**N070→N080 节点交接协议（输出捆绑包 + 词汇对齐规则 + ready_for_n090 信号）（必读）**
- `references/artifact-versioning-rules.md`：产物 schema 版本化规则（MAJOR/MINOR/PATCH + 破坏性变更检测）
- `references/workflow-v2-event-schemas.md`：事件总线 schema 目录（所有节点 produced_event_name）
- `references/cross_node_validator.py`：跨节点对齐验证脚本（验证四个节点过渡的完整性）

- `references/scoring-rubric.md`：**L1-L5 判别矩阵 + 边界 case 对照表 + cross-cut 识别规则（必读）**
- `references/interoperability-contract.md`：N070 跨 skill 命名空间契约及 combo-mode join rules
- `references/output-template.md`：输出结构
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
