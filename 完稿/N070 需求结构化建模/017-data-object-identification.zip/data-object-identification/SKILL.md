---
name: data-object-identification
description: identify reusable business data objects from requirement material with stable object ids, ddd roles, subtype hierarchies, storage metadata, constraint tags, boundary-aware relationships, lifecycle signals, and downstream-ready refs. use when requirement, schema, permission, rule, or implementation work needs a standalone object baseline that can also join cleanly with requirement, rule, state, and permission artifacts.
---
# data-object-identification

Build a reviewable object baseline from the source. Focus on object identity, boundaries, ownership, relationships, and storage intent before implementation detail.

## N070 stage metadata / 阶段元数据
- `n070_stage`: `2`
- `depends_on`: `['013']`
- `blocks`: `['014', '015', '016']`
- `may_consume`: `[]`
- Note: actual SKILL.md frontmatter must stay validator-compatible (`name` and `description` only), so the stage metadata is placed in the body top section instead of YAML frontmatter.

## Goal
Produce an object baseline that answers:
- what objects actually exist
- which are aggregate roots, entities, value objects, service data, or snapshots
- whether an object has subtype hierarchy
- where the object likely lives and how long it is retained
- what cross-boundary relationship risks or invariants exist

## Single-skill value / 单独使用价值
- 仅基于 PRD 或等价需求文本即可独立生成对象目录。
- 即使没有兄弟 skill，也必须输出对象边界、归属、关系、生命周期与 storage 初判。
- 单独使用时也必须支持 `ddd_role`、`storage`、`constraint_tags`。

## Multi-skill value / 组合使用价值
- 与 requirement-breakdown 对齐对象命名、领域边界与上游 requirement refs。
- 与 business-rule-extraction 对齐对象级约束、配置依赖、append-only 等规则。
- 与 state-transition-mapping 对齐状态主体对象与 snapshot / append-only 模型。
- 与 permission-matrix-extraction 对齐 resource/object 粒度、字段级可见性与关系权限。

## Allowed inputs / 允许输入
- 主输入：PRD、领域说明、流程说明。
- 可选输入：需求结构树、规则清单、状态流转表、权限矩阵。
- 可选输入：全局上下文，仅用于统一术语、禁用概念、跨模块 ownership 边界。

## Required object contract
每个 object 尽量包含：
- `object_id`
- `domain`
- `name`
- `business_definition`
- `ddd_role`
- `type_hierarchy`
- `key_attributes`
- `lifecycle`
- `storage`
- `constraint_tags[]`
- `relationships[]`
- `owner_module`
- `source_of_truth`
- `decision_refs[]`
- `blocker_refs[]`
- `open_question_refs[]`
- `certainty`
- `evidence`

固定枚举：
- `ddd_role`: `aggregate_root / entity / value_object / service_data / snapshot`
- `storage.medium`: `relational_db / nosql / cache / queue / file_system / 未明确`

## Relationship rules
每条 relationship 尽量包含：
- `type`
- `target`
- `cardinality`
- `boundary.same_transaction`
- `boundary.same_database`
- `boundary.same_service`
- `boundary.consistency_mode`
- `boundary.compensation_needed`

不要只写抽象的 belongs_to / has_many，而不说明边界代价。

## Type hierarchy rules
- 当一个对象有共享身份但 subtype 行为差异明显时，优先建模为 `type_hierarchy`，不要强行拆成完全独立对象，也不要把 subtype 差异全埋在备注里。
- 若存在判别字段，记录 `discriminator`。

## Constraint tag rules
至少支持：
- `append_only`
- `single_source_of_truth`
- `pii`
- `financial`
- `regulated`
- `audit_required`
- `cache_friendly`
- `read_heavy`
- `write_heavy`

`audit_required` 语义：
- 表示对象的读/写访问都必须留下审计痕迹，但其监管强度低于 `regulated`。
- 不由其他 tag 自动派生；只有源文档明确要求保留操作痕迹时才增加。
- 当对象带 `audit_required` 时，下游 `permission-matrix-extraction` 的相关 `audit_level` 至少应为 `full`。
- 与 `pii` 的区别：`pii` 同时暗示脱敏/加密约束；`audit_required` 只强调审计留痕。

不要删除核心标签；可按项目扩展。

## Global validation rule ids / 全局校验规则编号
- Canonical references for this skill's validation rules:
- `017.R00_evidence_required`
- `017.R01_ddd_role_required`
- `017.R02_embedded_in_for_value_object`
- `017.R03_storage_required`
- `017.R04_pii_requires_audit`
- `017.R05_append_only_enforcement`
- `017.R06_fallback_discipline_017`
- `017.R07_audit_required_propagation`
- When old notes or logs mention a short name like `R03`, interpret it through the list above; the global id is the canonical reference from v2.1.2 onward.

## Execution workflow
1. 从业务描述识别对象，不要从数据库直觉反推对象。
2. 给每个对象分配稳定 `object_id`；没有显式 id 时按 `{OBJ-domain-nnn}` 生成。
3. 判定 `ddd_role`。
4. 当对象存在 subtype 差异时补 `type_hierarchy`。
5. 抽取 `storage` 和 retention/ttl 线索。
6. 给高价值对象打 `constraint_tags[]`。
7. 为 relationships 补边界属性。
8. 若兄弟 skill 可用，补 cross refs 与 coverage hooks。
9. 使用 `references/output-template.md` 输出。

## Output modes
- 默认 `full_mode`
- 需要可视化时补 `erd` 或 `class_diagram`
- 需要限界上下文视角时补 `ddd_context_map`
- 需要存储设计前置时补 `storage_plan`
- 需要自动化 join 时输出 `machine_mode`
- 需要版本回放时启用 `diff_mode`

## Output language and evidence rules
- 跟随输入主语言输出。
- 不翻译字段名、状态值、表名、常量名。
- 证据格式：`[doc_id]§[section].L[start]-L[end]`
- 确定性只允许：`明确写明 / 基于上下文推断 / 待确认`

## Evidence anchor contract / 证据锚点契约
- Canonical anchor format: `[doc_id]§[section].L[start]-L[end]`
- Canonical YAML-safe regex pattern: `'\[[^\]]+\]§[^.]+\.L\d+(-L\d+)?'`
- Prefer a single-quoted YAML scalar when documenting or exporting the regex to avoid escape ambiguity across parsers.
- Evidence must point to the source that actually supports the row; do not use a nearby paragraph as a placeholder.

## References
- `references/output-template.md`
- `references/interoperability-contract.md`
- `references/domain-dictionary-template.yaml`
- `references/coverage-report-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
