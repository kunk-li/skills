# Scoring Rubric

Score each output on a 1-4 scale.

## 1 - Too shallow
- Mostly summary
- Missing evidence or detailed structure
- Missing unclear items

## 2 - Usable but unstable
- Has sections and some detail
- Still missing tables, examples, or edge conditions

## 3 - Review/design ready
- Enough detail for the current stage
- Unclear items are explicit
- Major tables and rules are present

## 4 - Production-grade reusable output
- Strong structure
- Rich tables/examples
- Minimal ambiguity
- Can be reused consistently across PRDs

Minimum acceptable score for this skill: 3
