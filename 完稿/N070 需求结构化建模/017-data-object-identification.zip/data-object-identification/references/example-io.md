# Example Input / Output

## Example input
A PRD says: "Managers can approve leave requests. Employees submit leave, HR can view but cannot approve. Leave can be draft, submitted, approved, or rejected."

## Example output sketch
- Concepts: leave request, employee, manager, HR
- Data objects: leave_request, approval_action
- States: draft -> submitted -> approved/rejected
- Permissions: employee=create/view own, manager=approve, HR=view
- Unclear item: whether rejected requests can be resubmitted
