# Checklist

Before finalizing, confirm all items below:

## Input & scope
- [ ] Input really came from PRD (and optionally upstream skill outputs or global context)
- [ ] Output depth matches stage PRD理解, not just a summary

## Structure (对齐新模板)
- [ ] 对象目录是否使用了标准对象类别枚举（主数据 / 过程数据 / 结果数据 / 日志审计 / 配置 / 外部引用）？
- [ ] 每个对象是否标注了 owner module 和 source of truth？
- [ ] 对象关系图是否使用了标准关系类型和基数？
- [ ] 跨模块对象引用是否独立成章（§6）？
- [ ] 权威来源推断（§5）是否给出了置信度和冲突分析？

## Cross-skill alignment (N070 共同契约)
- [ ] 对象名称是否与 requirement-breakdown §4 "核心业务对象" 保持一致？
- [ ] 如发现命名冲突，是否填写了 §10 "对象名对齐说明"表？
- [ ] 证据字段是否使用了 `[doc_id]§[section].L[start]-L[end]` 统一锚点格式？

## Global constraint check
- [ ] 当全局上下文可用时，是否检查了对象名/字段名与永久禁用概念的碰撞？
- [ ] 是否检查了对象是否引用了幽灵实体？
- [ ] 触碰项是否记入 §7 "全局约束碰撞"表？

## Quality
- [ ] Confirmed facts vs inferred suggestions were separated
- [ ] Unclear items were listed explicitly in §8
- [ ] Output followed the standard template (10 个章节)

- [ ] Is the output detailed enough to support downstream review, schema discussion, or design work without rereading the PRD?
