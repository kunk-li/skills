# DDD Role Decision Rules / DDD 角色判别规则

本文件定义如何将识别到的业务数据对象判定为 `aggregate_root / entity / value_object / service_data / snapshot` 中的一种。

---

## 1. 五种角色定义

| ddd_role | 定义 | 核心特征 |
|---|---|---|
| `aggregate_root` | 一致性边界的入口对象，外部只能通过它访问其内部对象 | 有独立 ID；拥有其他对象的完整生命周期；直接对应业务操作的目标 |
| `entity` | 有独立标识且生命周期内状态可变的对象 | 有独立 ID；从属于某个 aggregate_root；不能独立于 root 存在 |
| `value_object` | 无独立标识、通过属性值定义的不可变对象 | 无独立 ID；不可变（替换而非修改）；两个具有相同属性的实例视为相等 |
| `service_data` | 用于跨服务/跨域传递数据的 DTO 或投影对象 | 无业务行为；仅用于传输或查询；不作为持久化的第一公民 |
| `snapshot` | 记录对象在某时刻状态的历史快照 | 有时间戳；不可修改；用于审计、历史回溯、幂等校验 |

---

## 2. 判别决策树 / Decision Tree

```
Q1: 业务操作（创建、修改、删除）直接以该对象为目标？
    YES → 继续 Q2
    NO  → 可能是 entity / value_object / service_data / snapshot，继续 Q3

Q2: 它拥有并控制其他相关对象的完整生命周期？
    YES → ddd_role = aggregate_root
    NO  → ddd_role = entity（有 ID 但从属于某个 root）

Q3: 它有独立的业务标识（ID）且状态随时间变化？
    YES → ddd_role = entity（从属型，需指定 embedded_in）
    NO  → 继续 Q4

Q4: 它是否不可变？（属性确定后不再修改，改变就换一个新实例）
    YES → ddd_role = value_object
    NO  → 继续 Q5

Q5: 它的主要目的是跨服务传递数据或作为查询结果返回？
    YES → ddd_role = service_data
    NO  → 继续 Q6

Q6: 它记录的是某个对象在特定时刻的历史状态？
    YES → ddd_role = snapshot
    NO  → 重新核查 Q1（可能分类错误或是新类型）
```

---

## 3. 边界 Case 对照表 / Boundary Cases

| 对象 | 正确 ddd_role | 常见误判 | 判别理由 |
|---|---|---|---|
| `Order`（订单） | aggregate_root | entity | 业务直接操作订单；订单控制 OrderItem 的生命周期 |
| `OrderItem`（订单行） | entity | aggregate_root | 有 ID 但无法脱离 Order 单独存在；生命周期随 Order |
| `Money`（金额+货币） | value_object | entity | 无独立 ID；¥100 和另一个 ¥100 是等价的 |
| `Address`（收货地址） | value_object | entity | 同一地址字符串视为相同；更换地址是替换不是修改 |
| `UserProfile`（用户资料） | aggregate_root | entity | 业务直接操作用户资料；控制 Address、Preferences 等 |
| `OrderDTO`（订单传输对象） | service_data | entity | 用于 API 响应；无业务行为；不持久化为第一公民 |
| `OrderSnapshot`（订单快照） | snapshot | entity | 有时间戳；不可修改；用于审计/历史回溯 |
| `Permission`（单条权限记录） | value_object | entity | subject+resource+action 三元组相同就是同一权限；无独立 ID |
| `AuditLog`（操作日志） | snapshot | service_data | 记录历史状态；不可修改；有明确时间戳 |
| `Cart`（购物车） | aggregate_root | entity | 业务直接操作购物车；控制 CartItem 生命周期 |
| `CartItem`（购物车行） | entity | aggregate_root | 从属于 Cart；脱离 Cart 无意义 |
| `ProductSummary`（产品摘要） | service_data | entity | 跨服务查询用；不代表 Product 本身的完整状态 |

---

## 4. 混合场景规则 / Hybrid Cases

### 4.1 同一对象在不同上下文中角色不同

同一个现实实体在不同 Bounded Context 中可能有不同角色：

| 对象 | Context A | Context B | 处理方式 |
|---|---|---|---|
| `User` | 用户中心 = aggregate_root | 订单服务 = service_data（只引用 user_id） | 分别记录两个条目，`ddd_context_map` 中注明 |
| `Product` | 商品中心 = aggregate_root | 购物车 = entity（embedded_in Cart，只含 product_id + snapshot 字段） | 同上 |

### 4.2 aggregate_root vs entity 的特殊判定

当无法通过 Q1/Q2 明确判断时，使用以下辅助指标：

```
若以下任意一项成立 → aggregate_root：
  - 需求中存在"创建/归档/删除 X"的直接操作
  - X 有独立的状态机（有自己的 status 字段和状态转移）
  - X 在权限矩阵中作为 resource 出现（不只是关联对象）
  - X 是其他对象的 owner_module

若以下任意一项成立 → entity（embedded_in 某个 root）：
  - X 只通过其所属的 root 被操作（"添加到 Order"而非"创建 X"）
  - X 的删除必然伴随 root 的某个操作
  - X 没有独立的 status 字段（共享 root 的状态）
```

---

## 5. 输出格式要求 / Output Requirements

在对象目录的 `ddd_role` 列填写后，必须同时补充：

```yaml
ddd_role: aggregate_root | entity | value_object | service_data | snapshot
ddd_decision_path: "Q1:YES → Q2:YES → aggregate_root"   # 记录决策树路径
ddd_context: <所属 Bounded Context 名称>
embedded_in: <父 aggregate_root 的 object_id>           # entity 必填
ddd_notes: <edge case 或特殊情况说明>                    # 可选
```

`embedded_in` 为空但 `ddd_role = entity` → 标记为 `ddd_role_undetermined`，放入 open_questions[]。

---

## 6. 常见误判来源 / Anti-patterns

- **把所有有 ID 的对象都归为 entity**：需先问 Q1/Q2，ID 存在不等于 entity。
- **把 DTO 归为 entity**：DTO 无业务行为，无生命周期管理 → service_data。
- **把 Value Object 归为 entity 只因为它出现在数据库表里**：数据库实现细节不影响 DDD 角色。
- **把含有时间戳的对象都归为 snapshot**：时间戳可以是 entity 的字段；snapshot 特指"整体状态在某时刻的冻结记录"。
