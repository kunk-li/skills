# 输出模板 / output template

## 1. 摘要 / Summary
- 对象数量与角色分布
- subtype hierarchy 覆盖情况
- storage 介质分布
- 最大对象边界风险

## 2. 输出模式 / Output mode
| mode | 是否输出 | 说明 |
|---|---|---|
| table_mode |  | 核心对象目录 |
| full_mode |  | 完整对象视图 |
| machine_mode |  | 机器可消费结构 |
| diff_mode |  | 版本差异 |
| erd / class_diagram / ddd_context_map / storage_plan |  | 可选增强 |

## 3. object catalog / 对象目录
| object_id | domain | name | business_definition | ddd_role | owner_module | source_of_truth | introduced_in | status | constraint_tags | decision_refs | certainty | evidence |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## 4. type hierarchy / 类型层次
| object_id | is_abstract | discriminator | subtypes | common_attributes | subtype_specific | evidence |
|---|---|---|---|---|---|---|

## 5. lifecycle and storage / 生命周期与存储
| object_id | lifecycle | storage.medium | storage.location | ttl | retention_policy | partition_strategy | archival | evidence |
|---|---|---|---|---|---|---|---|---|

## 6. ownership and responsibilities / 归属与职责
| object_id | creator | maintainer | consumer | archive_or_delete_owner | shared_across_modules | evidence |
|---|---|---|---|---|---|---|

## 7. relationships / 关系与边界
| object_id | relation_type | target | cardinality | same_transaction | same_database | same_service | consistency_mode | compensation_needed | evidence |
|---|---|---|---|---|---|---|---|---|---|

## 8. canonical source analysis / 权威来源分析
| object_id | canonical_source_candidate | rationale | confidence | conflict_note | next action |
|---|---|---|---|---|---|

## 9. global constraints and object risks / 全局约束与风险
| object_id_or_field | risk_type | detail | likely downstream impact | evidence |
|---|---|---|---|---|

## 10. gaps and unresolved items / 缺口与待确认
| type | ref | issue | impact | next action |
|---|---|---|---|---|

## 11. optional cross-skill links / 可选跨 skill 回指
| object_id | req_refs | rule_refs | sm_refs | perm_refs | alignment_note |
|---|---|---|---|---|---|

## 10. audit_required semantic
- `audit_required` means the object must leave access or mutation traces in downstream permission and audit outputs.
- It is weaker than `regulated`, but stronger than an ordinary operational preference.
