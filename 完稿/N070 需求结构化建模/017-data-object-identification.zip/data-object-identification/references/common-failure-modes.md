# Common Failure Modes

## Failure mode 1: UI labels treated as stable object names
Symptom: temporary page labels, button labels, or display aliases are copied into the object catalog as if they were authoritative names.
Fix: prefer the most stable business name and record aliases separately when needed.

## Failure mode 2: object and field mixed together
Symptom: a field, status, or attribute is listed as if it were a standalone business object.
Fix: keep objects at entity level; move attributes into key fields or notes.

## Failure mode 3: lifecycle omitted
Symptom: the object clearly changes across stages, but the lifecycle column is empty.
Fix: add observable states, stages, or lifecycle checkpoints whenever the source supports them.

## Failure mode 4: control artifact mistaken for primary object
Symptom: approval tickets, validation records, or audit events are listed as the primary business object while the real business entity is under-described.
Fix: classify each object as main object, workflow object, control object, automation object, audit object, or configuration object.

## Failure mode 5: ownership guessed
Symptom: owner module or source of truth is inferred without evidence.
Fix: write “未明确” unless the document clearly establishes ownership.

## Failure mode 6: cross-module reuse hidden
Symptom: one module consumes or references an object owned by another module, but the object is not marked as a cross-module reference.
Fix: explicitly record owner module, source of truth, and cross-module usage.

## Failure mode 7: duplicate objects created from wording drift
Symptom: the same object appears under multiple names such as a display label, english alias, and api field label.
Fix: merge them into one authoritative object entry and record aliases in notes.

## Failure mode 8: prohibited or retired entities revived
Symptom: an object or actor that has been globally retired is still listed as active.
Fix: compare the candidate object list against the global context before finalizing the catalog.
