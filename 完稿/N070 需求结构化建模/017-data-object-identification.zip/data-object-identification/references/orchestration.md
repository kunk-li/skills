## Stage metadata
- n070_stage: 2
- depends_on: ['013']
- blocks: ['014', '015', '016']
- may_consume: []

# Orchestration

## Upstream expectation
- PRD text as primary input
- requirement-breakdown §4 "核心业务对象" as canonical object name source
- Optionally: project_context.md for global constraint check

## What this skill adds
- 识别业务对象、对象关系、主从对象与生命周期
- 对每个对象深化 owner module / source of truth / 生命周期 / 跨模块引用四个维度
- 在 requirement-breakdown 基础上做深层分析，而非平行重复

## Relationship with requirement-breakdown
- requirement-breakdown §4 的"核心业务对象"是高层概览（5-8 列），重点在"为何是核心"
- data-object-identification 的"对象目录"是深层分析（10 列），重点在"归属、来源、生命周期"
- 对象名称必须与 requirement-breakdown 保持一致
- 如果发现新对象，标注为"new object (not in breakdown)"

## Downstream handoff
- Output should be Markdown with stable section names (10 个标准章节)
- Downstream consumers: table-schema-design-recommendation / data-flow-mapping / review-doc-generator / N090 / N100 / N110 / N160 / N170 / N230 / N260 as `数据对象清单.csv` consumers
- 始终保留显式"待确认项"而非隐藏

## Recommended companions
- Nearby skills in stage PRD理解
- review-doc-generator for final review output
- rd-design-generator for final design output

---

## N070 共同契约

### Object name alignment contract (C1)
- Canonical source: **requirement-breakdown §4 "核心业务对象"** table.
- This skill's §2 "对象目录" MUST use canonical object names.
- New objects discovered by this skill must be tagged "new object (not in breakdown)".
- Name conflicts must be logged in §10 "对象名对齐说明" table.

### N070 execution stage (C3)
- This skill executes in **stage 2** of N070 internal pipeline (parallel with business-rule-extraction and state-transition-mapping).
- Must wait for stage 1 (requirement-breakdown) to complete.
- Output is consumed by stage 3 (permission-matrix-extraction) as resource-level granularity input.

### CSV handoff contract (C4)
- Output filename: `数据对象清单.csv`
- Required downstream meaning: rows should preserve object name / owner module / source of truth / lifecycle so data-model, permission, QA, and review stages can consume them directly.
- Recommended direct consumers: N090 / N100 / N110 / N160 / N170 / N230 / N260.
