---
name: defect-severity-assessment
description: assess defect severity from classified defects, incidents, user impact, data integrity, business impact, urgency, sla policy, and escalation signals. use for standalone severity triage or n250 workflows where final severity, response sla, war-room need, business impact, gate signals, or reproduction priority must be determined after classification.
---
# defect-severity-assessment

## Role
Determine authoritative severity and escalation for a defect. This skill is standalone-capable and is baton 3 in the N250 chain.

## Boundary
- This is the authority for final severity in N250.
- Consume 090 `technical_severity_hint` as a prior, not as final truth.
- Produce SLA, escalation, business impact, risk, and reproduction priority.
- Do not reclassify ODC taxonomy except to explain severity conflicts.
- Do not create reproduction steps; trigger 092 behavior instead.

## Routing triggers
Use this skill for P0/P1 triage, release blockers, defect prioritization, SLA routing, business impact quantification, escalation decisions, or severity reassessment.

## Modes
- `quick_sev`: urgent first-pass severity for one defect or incident.
- `comprehensive_sev`: full scoring, business impact, SLA, and escalation path.
- `batch_reassess`: reassess backlog, release slice, or defect portfolio.

## Inputs
Minimum standalone input: one defect, incident, bug observation, or failure cluster with impact clues.

Preferred upstream input in N250: 090 `defect_rows[]` and 089 evidence.

Optional enhancements:
- user counts and tiers
- revenue, SLA, legal, contract, or reputation exposure
- production duration and release deadline
- support ticket volume
- recovery or workaround details

## Output contract
Default to CSV-friendly rows or Markdown tables. Follow `references/output-template.md`.

Required sections for full output (`output_compactness: full`):
- `metadata`
- `severity_rows[]`
- `assessment_matrix`
- `overall_severity`
- `sla_commitments`
- `escalation`
- `business_impact_quantification`
- `risk_factors`
- `circuit_breaker_evaluation`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `schema_version: n250.severity.v2.2.0`
- `contract_version: n250.defect-management.v2`
- `selected_mode`, `readiness`, `evidence_profile`
- `function_bias: decision_support`
- `workflow_node: N250` or `standalone`
- `node_artifact_target: defect-severity-assessment.csv`
- `produced_events[]`
- `output_compactness`: quick or full

## Assessment authority
Use four dimensions scored 1-5:
- D1 `user_impact`: users affected, severity per user, duration, workaround.
- D2 `business_impact`: revenue, reputation, legal/regulatory, strategic impact.
- D3 `data_integrity`: loss, corruption, recoverability, audit trail, compliance data.
- D4 `urgency`: production impact, release/development blocking, deadlines, customer commitments.

Weighted formula: `composite_score = D1*0.30 + D2*0.30 + D3*0.20 + D4*0.20`.

Mapping:
- > 4.0 -> `P0_blocker`
- 3.0-4.0 -> `P1_critical`
- 2.0-3.0 -> `P2_major`
- 1.0-2.0 -> `P3_minor`
- below 1.0 -> `P4_trivial`

Hard overrides:
- unrecoverable data loss -> force P0.
- security breach -> force P0.
- compliance violation -> force P1 or higher.
- P0 requires war room when customer-facing and blast radius is some_users or all_users.


## Compact output guidance for quick_sev
When `selected_mode: quick_sev` and no P0/P1 hard override is present, use the compact template in `references/output-template.md` to control token cost:
- Include `metadata`, one `severity_rows[]` row, `overall_severity`, `sla_commitments`, `downstream_handoff`, and `self_check`.
- Keep D1-D4 scores and short factor summaries, but omit expanded cost narratives unless final severity is P0/P1 or data is already available.
- Set unknown business numbers as `pending_business_metric` rather than estimating.
- Still include `hard_overrides_applied[]` even when empty, so audit readers know overrides were checked.
- Escalate from quick to full output when `final_severity` is P0/P1, `compliance_related: true`, `data_loss_risk: true`, or `human_review.required: true`.

## Rules
- R01_4_dimensions_scored: D1-D4 must be scored or explicitly pending; on_violation: reject.
- R02_data_loss_min_P1: data loss or corruption with customer/audit impact must be P1 or higher; on_violation: auto_upgrade.
- R03_compliance_min_P1: compliance violation must be P1 or higher; on_violation: auto_upgrade.
- R04_P0_has_war_room: P0 customer-facing defects require war_room decision; on_violation: reject.
- R05_override_has_signer: manual severity override requires signer, reason, and original severity; on_violation: reject.
- R06_sla_mapped: every final severity must map response SLA, resolution SLA, communication cadence, and owner; on_violation: reject.
- R07_cost_quantified_for_high: P0/P1 requires business impact quantification or explicit pending factor; on_violation: human_review.
- R08_reproduction_priority_triggered: P0/P1 must trigger 092 debugging aids and prioritized reproduction; on_violation: auto_enforce.

## Algorithm
1. Read 090 defect rows first when available; preserve 090 ids and tags.
2. Score D1-D4 using evidence and mark pending factors without invention.
3. Calculate weighted composite score.
4. Apply hard overrides.
5. Map final severity and SLA.
6. Build escalation chain and business impact quantification.
7. Set reproduction triggers for 092.
8. Emit N005 and N260 signals for high-risk, recurrent, customer-facing, or process-gap defects.

## Downstream handoff requirements
`downstream_handoff.to_092_reproduction` must include:
- `defect_id`, `final_severity`, `composite_score`
- `prioritize_reproduction: true` for P0/P1
- `generate_debugging_aids: true` for P0/P1
- `required_attempts_minimum`: 10 for P0/P1 reliability measurement unless unsafe or impossible
- `logs_to_capture_priority[]`, `monitoring_to_enable[]`, `owner_and_sla`

`downstream_handoff.to_N260_gate` must include `block_release`, `hotfix_required`, `war_room_required`, `executive_notification`, and `sla_queue_priority`.

`downstream_handoff.to_N005_feedback` must include high-severity patterns, recurrence, phase_delta, customer impact, and suspected process gaps.

## Reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/severity-matrix.md`
- `references/severity-assessment-rubric.md`
- `references/sla-and-escalation-policy.md`
- `references/circuit-breaker-policy.md`
- `references/cross-skill-orchestration.md`
- `references/n250-integration-map.md`
- `references/readiness-inheritance.md`
- `references/quality-checklist.md`
- `references/real-examples.md`
## v2.2 operational refinements
- Use full YAML examples in `references/real-examples.md` for few-shot guidance.
- Follow schema ratchet and compatibility rules in `references/field-contract.md`.
- Feed self-check and readiness into N250 rollup for N260 using `references/n250-integration-map.md`.
