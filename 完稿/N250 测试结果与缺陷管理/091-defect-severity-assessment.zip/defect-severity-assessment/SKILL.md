---
name: defect-severity-assessment
description: Assess defect severity and response SLA from classified defects, user and data impact, urgency, and escalation signals; decide war-room need and reproduction priority.
---
# defect-severity-assessment


## Routing decision table

| Situation | Action |
|---|---|
| Data loss or corruption | Apply hard override → always P0; skip weighted score |
| Security vulnerability (authentication/auth) | Apply hard override → P0 with security escalation |
| Business impact data unavailable | Default to conservative tier; set `business_impact: pending_stakeholder_input` |
| quick_sev mode requested | Return compact severity tier only; omit dimensional breakdown |
| War room threshold reached | Set `war_room_needed: true`; page on-call immediately |
| Latent defect (missing guardrail, dead code, unexercised path — no user currently broken) | Score `latent_risk`; live-impact dims under-score it, so a `priority_override_reason` may raise scheduling priority above the weighted tier |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n250.defect-severity-assessment.v2.2"
contract_version: "n250.defect-management.v2.2"
workflow_node: "N250"
```


## Role
Determine authoritative severity and escalation for a defect. This skill is standalone-capable and is baton 3 in the N250 chain.

## Boundary
- This is the authority for final severity in N250.
- Consume 090 `technical_severity_hint` as a prior, not as final truth.
- Produce SLA, escalation, business impact, risk, and reproduction priority.
- Do not reclassify ODC taxonomy except to explain severity conflicts.
- Do not create reproduction steps; trigger 092 behavior instead.

## Routing triggers
Use this skill for P0/P1 triage, release blockers, defect prioritization, SLA routing, business impact quantification, escalation decisions, or severity reassessment.

## Modes
- `quick_sev`: urgent first-pass severity for one defect or incident.
- `comprehensive_sev`: full scoring, business impact, SLA, and escalation path.
- `batch_reassess`: reassess backlog, release slice, or defect portfolio.

## Inputs
Minimum standalone input: one defect, incident, bug observation, or failure cluster with impact clues.

Preferred upstream input in N250: 090 `defect_rows[]` and 089 evidence.

Optional enhancements:
- user counts and tiers
- revenue, SLA, legal, contract, or reputation exposure
- production duration and release deadline
- support ticket volume
- recovery or workaround details


### Degradation rules

- If business impact data is unavailable, default to the most conservative severity tier and mark `business_impact: pending_stakeholder_input`.
- If SLA policy is unspecified, apply the default severity matrix from `references/severity-matrix.md` and mark `sla_policy: pending_confirmation`.
- Keep the severity assessment shape stable even under partial evidence.

## Output contract
Default to CSV-friendly rows or Markdown tables. Follow `references/output-template.md`.

Required sections for full output (`output_compactness: full`):
- `metadata`
- `severity_rows[]`
- `assessment_matrix`
- `overall_severity`
- `sla_commitments`
- `escalation`
- `business_impact_quantification`
- `risk_factors`
- `circuit_breaker_evaluation`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `schema_version: n250.severity.v2.2.0`
- `contract_version: n250.defect-management.v2`
- `selected_mode`, `readiness`, `evidence_profile`
- `function_bias: decision_support`
- `workflow_node: N250` or `standalone`
- `node_artifact_target: defect-severity-assessment.csv`
- `produced_events[]`
- `output_compactness`: quick or full

## Assessment authority
Use four dimensions scored 1-5:
- D1 `user_impact`: users affected, severity per user, duration, workaround.
- D2 `business_impact`: revenue, reputation, legal/regulatory, strategic impact.
- D3 `data_integrity`: loss, corruption, recoverability, audit trail, compliance data.
- D4 `urgency`: production impact, release/development blocking, deadlines, customer commitments.

Weighted formula: `composite_score = D1*0.30 + D2*0.30 + D3*0.20 + D4*0.20`.

Mapping:
- > 4.0 -> `P0_blocker`
- 3.0-4.0 -> `P1_critical`
- 2.0-3.0 -> `P2_major`
- 1.0-2.0 -> `P3_minor`
- below 1.0 -> `P4_trivial`

Hard overrides:
- unrecoverable data loss -> force P0.
- security breach -> force P0.
- compliance violation -> force P1 or higher.
- P0 requires war room when customer-facing and blast radius is some_users or all_users.

### Latent risk（潜伏缺陷：别被 live-impact 维度低估）
四维（D1-D4）度量的是**当前已发生**的影响。对**潜伏类**缺陷——缺失守卫（如未建的预算 / 配额闸）、死码 / 假安全（built-but-never-called）、未触发的设计缺陷——「当前无用户被破坏」会让 D1/D4 系统性偏低、加权 tier 偏轻，但它可能是 readiness blocker。
- 标 `latent_risk: {trigger_condition, blast_if_triggered}`（什么条件引爆、爆了多惨）。
- severity（impact 加权）与 scheduling priority **背离**时，写 first-class `priority_override_reason`（非埋 footnote），**不静默**：weighted tier 是「现在多惨」、priority 是「多急该修」，二者可不同（同发现器→人裁定：把背离亮给人，不替人决定）。
- 这**不是**改 D1-D4 评分或 ODC 分类（那走 `R05`）；是在诚实 severity 之上，显式记「为何调度优先级更高」。


## Compact output guidance for quick_sev
When `selected_mode: quick_sev` and no P0/P1 hard override is present, use the compact template in `references/output-template.md` to control token cost:
- Include `metadata`, one `severity_rows[]` row, `overall_severity`, `sla_commitments`, `downstream_handoff`, and `self_check`.
- Keep D1-D4 scores and short factor summaries, but omit expanded cost narratives unless final severity is P0/P1 or data is already available.
- Set unknown business numbers as `pending_business_metric` rather than estimating.
- Still include `hard_overrides_applied[]` even when empty, so audit readers know overrides were checked.
- Escalate from quick to full output when `final_severity` is P0/P1, `compliance_related: true`, `data_loss_risk: true`, or `human_review.required: true`.

## Auditable rules
- R01_4_dimensions_scored: D1-D4 must be scored or explicitly pending; on_violation: reject.
- R02_data_loss_min_P1: data loss or corruption with customer/audit impact must be P1 or higher; on_violation: auto_upgrade.
- R03_compliance_min_P1: compliance violation must be P1 or higher; on_violation: auto_upgrade.
- R04_P0_has_war_room: P0 customer-facing defects require war_room decision; on_violation: reject.
- R05_override_has_signer: manual severity override requires signer, reason, and original severity; on_violation: reject.
- R06_sla_mapped: every final severity must map response SLA, resolution SLA, communication cadence, and owner; on_violation: reject.
- R07_cost_quantified_for_high: P0/P1 requires business impact quantification or explicit pending factor; on_violation: human_review.
- R08_reproduction_priority_triggered: P0/P1 must trigger 092 debugging aids and prioritized reproduction; on_violation: auto_enforce.

## Algorithm
1. Read 090 defect rows first when available; preserve 090 ids and tags.
2. Score D1-D4 using evidence and mark pending factors without invention.
3. Calculate weighted composite score.
4. Apply hard overrides.
5. Map final severity and SLA.
6. Build escalation chain and business impact quantification.
7. Set reproduction triggers for 092.
8. Emit N005 and N260 signals for high-risk, recurrent, customer-facing, or process-gap defects.



## Usage scenarios

- `standard_sev`: full severity assessment with SLA, business impact, and escalation guidance.
- `quick_sev`: rapid severity assignment for high-volume triage (compact output mode).
- `war_room_trigger`: assess whether a defect requires war-room escalation and immediate on-call paging.
- `sla_conflict_resolution`: resolve competing SLA pressures when multiple P0 defects are open.
- `n250_chain_severity`: third baton in the N250 chain, consuming 090 and triggering 092 reproduction.


## Quality bar

- Every severity assessment must include all four weighted dimensions (frequency, business_impact, blast_radius, detectability).
- The weighted severity score must map to a canonical severity tier (P0/P1/P2/P3).
- `hard_override_applied: true` must be set when any P0 override rule fires.
- Results with `assessment_confidence < 0.7` must set `human_review_required: true`.


## Cross-skill integration map

| 上游 skill | 提供给 091 | 用途 |
|---|---|---|
| 090 defect-classification | `odc_type`, `defect_record` | ODC 分类输入严重度评估公式 |
| 089 test-failure-attribution | `attribution_confidence` | 归因置信度影响评估结果 |

| 下游 skill | 091 输出 | 如何使用 |
|---|---|---|
| 092 defect-reproduction-steps-generation | `severity_tier` | P0 缺陷优先生成复现步骤 |
| 093 quality-gate-check | `severity_distribution` | 门禁的严重度分布维度（P0 否决） |

**工作流位置**: 090 分类 → **091 严重度评估** → 092 复现/093 门禁。

## Standalone usage guide

**Minimum input:** defect description + affected component — no ODC classification required.

**Standalone severity path:**
1. Score four dimensions from available evidence; use conservative defaults for unknowns.
2. Apply hard override rules first (data loss, security breach → always P0).
3. Set `business_impact: pending_stakeholder_input` if business context is unavailable.

**Minimum viable output:**
```yaml
severity_assessment:
  readiness: constrained
  business_impact: pending_stakeholder_input
  dimensions:
    frequency: 6
    business_impact: 5
    blast_radius: 4
    detectability: 7
  weighted_score: 5.5
  severity_tier: P2
  sla: 24h
  human_review_required: false
  downstream_handoff:
    to: 092-defect-reproduction-steps-generation
```

## Resilience and governance addendum

**Readiness blocking**: Set `readiness: blocked` when a P0 severity is assigned but war_room_needed is not acknowledged within the declared SLA window.

**Confidence scoring**: Every severity assessment must include a `confidence` score (0–1). Assessments derived from incomplete impact data default to confidence: 0.65 and require human_review_required: true.

**Traceability**: Each severity assessment must reference defect_id from 090 classification and include escalation_target for downstream N260 gate and N300 incident reporting.
## Downstream handoff requirements
`downstream_handoff.to_092_reproduction` must include:
- `defect_id`, `final_severity`, `composite_score`
- `prioritize_reproduction: true` for P0/P1
- `generate_debugging_aids: true` for P0/P1
- `required_attempts_minimum`: 10 for P0/P1 reliability measurement unless unsafe or impossible
- `logs_to_capture_priority[]`, `monitoring_to_enable[]`, `owner_and_sla`

`downstream_handoff.to_N260_gate` must include `block_release`, `hotfix_required`, `war_room_required`, `executive_notification`, and `sla_queue_priority`.

`downstream_handoff.to_N005_feedback` must include high-severity patterns, recurrence, phase_delta, customer impact, and suspected process gaps.


## Example usage

**Input**: DEF-5021 — checkout total returning $0.00; affects all users applying discount codes; reported in production.

**Output** (`standard_sev` mode):
```yaml
defect_id: DEF-5021
final_severity: P0
sla:
  response: immediate
  fix_target: 4h
  workaround_target: 1h
business_impact:
  revenue_risk: high
  affected_users: all_users_with_discounts
  data_integrity: false
escalation:
  war_room_needed: true
  escalation_target: engineering_lead
  on_call_paged: true
prioritize_reproduction: true
generate_debugging_aids: true
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/severity-matrix.md`
- `references/severity-assessment-rubric.md`
- `references/sla-and-escalation-policy.md`
- `references/circuit-breaker-policy.md`
- `references/cross-skill-orchestration.md`
- `references/n250-integration-map.md`
- `references/readiness-inheritance.md`
- `references/quality-checklist.md`
- `references/real-examples.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## v2.2 operational refinements
- Use full YAML examples in `references/real-examples.md` for few-shot guidance.
- Follow schema ratchet and compatibility rules in `references/field-contract.md`.
- Feed self-check and readiness into N250 rollup for N260 using `references/n250-integration-map.md`.
