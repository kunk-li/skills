#!/usr/bin/env python3
"""Universal SKILL.md structural validator for N220–N260 skills.
Handles heading name variants across all groups.
Usage: python3 validate_skill.py SKILL.md [SKILL.md ...] [--strict] [--json]
"""
import sys, re, os, json as _json

VERSION = "1.0.0"

REQUIRED_FIELDS   = ['skill_version', 'schema_version', 'contract_version', 'workflow_node']
GOVERNANCE_SIGNALS = ['downstream_handoff', 'self_check', 'readiness', 'on_violation']

# Each entry: list of alternative heading patterns (any one match = satisfied)
REQUIRED_SECTIONS = [
    [r'## (auditable rules|auditable rules summary|design rules)',         'auditable_rules'],
    [r'## (algorithm|execution workflow)',                                  'algorithm_or_workflow'],
    [r'## (quality bar)',                                                   'quality_bar'],
    [r'## (reference files|references)',                                   'reference_files'],
    [r'## (example usage|example)',                                        'example_usage'],
    [r'## (role|role and boundary|role / role positioning)',               'role'],
]

def get_real_headings(text):
    in_code, headings = False, []
    for line in text.splitlines():
        if line.startswith("```"):
            in_code = not in_code
        if not in_code and line.startswith("## "):
            headings.append(line.lower().strip())
    return headings, in_code   # in_code True = unclosed block

def validate(path, strict=False):
    if not os.path.exists(path):
        return {"path": path, "ok": False, "errors": [f"File not found: {path}"], "warnings": []}
    
    c = open(path, encoding="utf-8").read()
    lo = c.lower()
    errors, warnings = [], []
    
    # Required fields
    for field in REQUIRED_FIELDS:
        if field not in lo:
            errors.append(f"Missing required field: {field}")
    
    # Real headings (code-block aware)
    headings, unclosed = get_real_headings(c)
    if unclosed:
        errors.append("Unclosed code block — headings below may be mis-detected")
    
    # Required sections
    for patterns_str, label in REQUIRED_SECTIONS:
        found = any(re.match(patterns_str, h) for h in headings)
        if not found:
            errors.append(f"Missing section [{label}]: no heading matching {patterns_str!r}")
    
    # Duplicate real headings
    seen = set()
    for h in headings:
        if h in seen:
            warnings.append(f"Duplicate heading: {h}")
        seen.add(h)
    
    # Governance signals
    for signal in GOVERNANCE_SIGNALS:
        if signal not in lo:
            warnings.append(f"Missing governance signal: {signal}")
    
    # Broken reference links
    ref_dir = os.path.join(os.path.dirname(path), "references")
    for line in c.splitlines():
        m = re.search(r"`references/([^`]+)`", line)
        if m and not os.path.exists(os.path.join(ref_dir, m.group(1))):
            errors.append(f"Broken reference: references/{m.group(1)}")
    
    # Version consistency
    sv = re.search(r'skill_version:\s*"([^"]+)"', c)
    if sv and sv.group(1) != "2.2":
        warnings.append(f"skill_version={sv.group(1)!r}, expected \'2.2\'")
    
    # Token efficiency: warn if > 350 lines
    n_lines = len(c.splitlines())
    if n_lines > 350:
        warnings.append(f"SKILL.md has {n_lines} lines (threshold: 350) — consider sinking examples to references/example-io-v2.md")
    
    ok = len(errors) == 0 and (not strict or len(warnings) == 0)
    return {"path": path, "ok": ok, "errors": errors, "warnings": warnings,
            "lines": n_lines, "sections": len(headings)}

def main():
    args = sys.argv[1:]
    strict  = "--strict" in args
    as_json = "--json"   in args
    paths   = [a for a in args if not a.startswith("--")]
    
    if not paths:
        print(f"validate_skill.py v{VERSION}")
        print("Usage: python3 validate_skill.py SKILL.md [SKILL.md ...] [--strict] [--json]")
        sys.exit(0)
    
    results = [validate(p, strict) for p in paths]
    
    if as_json:
        print(_json.dumps(results, indent=2))
    else:
        for r in results:
            skill = os.path.basename(os.path.dirname(r["path"]))
            tag   = "OK  " if r["ok"] else "FAIL"
            print(f"{tag} [{skill}] {r.get('lines',0)}L {r.get('sections',0)}sec — "
                  f"{len(r['errors'])} errors, {len(r['warnings'])} warnings")
            for e in r["errors"]:   print(f"     ERROR: {e}")
            if strict:
                for w in r["warnings"]: print(f"     WARN:  {w}")
        passed = sum(1 for r in results if r["ok"])
        print(f"\nResult: {passed}/{len(results)} passed")
    
    sys.exit(0 if all(r["ok"] for r in results) else 1)

if __name__ == "__main__":
    main()
