# Real examples v2.2

## Example A: full P1 severity from classified payment regression

```yaml
metadata:
  schema_version: n250.severity.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: comprehensive_sev
  output_compactness: full
  readiness: ready
  evidence_profile: strong
  workflow_node: N250
  node_artifact_target: defect-severity-assessment.csv
  produced_events:
    - produced.n250.severity.v2
    - sla.n250.human_review

severity_rows:
  - assessment_id: SEV-001
    defect_id: DEF-PAY-001
    technical_severity_hint_from_090: critical
    assessment_matrix:
      D1_user_impact:
        score: 4
        factors:
          users_affected: 500
          severity_per_user: blocking
          duration_of_impact: 2h
          workaround_available: true
      D2_business_impact:
        score: 4
        factors:
          revenue_at_risk: "$50000"
          reputation_damage: moderate
          legal_regulatory_risk: none
      D3_data_integrity:
        score: 2
        factors:
          data_loss_present: false
          audit_trail_affected: false
      D4_urgency:
        score: 4
        factors:
          affecting_production: false
          blocking_deployment: true
          customer_contract_commitment: affected
    composite_score: 3.8
    final_severity: P1_critical
    hard_overrides_applied: []
    sla_commitments:
      response_sla: 4h
      resolution_sla: 24h
      hotfix_required: yes
      communication_cadence: every_2h
    escalation:
      initial_owner: payment-oncall
      escalation_chain:
        - level: 1
          role: oncall_engineer
          trigger_after: 0m
          trigger_condition: immediate_triage
        - level: 2
          role: team_lead
          trigger_after: 4h
          trigger_condition: response_sla_missed
      war_room_required: false
      executive_notification:
        required: false
        notify_within: null
    business_impact_quantification:
      direct_cost:
        revenue_loss_per_hour: "$25000"
        estimated_resolution_time: 2h
        total_revenue_at_risk: "$50000"
      indirect_cost:
        customer_support_cost: pending_business_metric
      recovery_cost:
        fix_effort_pd: 1
        testing_effort_pd: 1
      total_cost_estimate: "$50000 + pending support cost"
    risk_factors:
      spread_potential: medium
      aggravation_over_time: stable
      downstream_dependencies: [checkout, invoicing]
    evidence_refs: [E1, E2]

downstream_handoff:
  to_092_reproduction:
    defect_id: DEF-PAY-001
    final_severity: P1_critical
    composite_score: 3.8
    prioritize_reproduction: true
    generate_debugging_aids: true
    required_attempts_minimum: 10
    logs_to_capture_priority: [payment-service DEBUG, checkout trace]
    monitoring_to_enable: [distributed_trace]
    owner_and_sla: payment-oncall within 4h
  to_N260_gate:
    block_release: true
    hotfix_required: true
    war_room_required: false
    executive_notification: false
    sla_queue_priority: P1
  to_N005_feedback:
    high_severity_pattern: payment_regression
    recurrence: false
    phase_delta: 2
    customer_impact: some_users

self_check:
  R01_4_dimensions_scored: pass
  R02_data_loss_min_P1: pass
  R03_compliance_min_P1: pass
  R04_P0_has_war_room: pass
  R05_override_has_signer: pass
  R06_sla_mapped: pass
  R07_cost_quantified_for_high: pass
  R08_reproduction_priority_triggered: pass
```

## Example B: compact quick_sev P3 with pending business metrics

```yaml
metadata:
  schema_version: n250.severity.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: quick_sev
  output_compactness: quick
  readiness: partial
  evidence_profile: sparse
  workflow_node: standalone
  produced_events:
    - produced.n250.severity.v2

severity_rows:
  - assessment_id: SEV-002
    defect_id: DEF-UI-014
    technical_severity_hint_from_090: minor
    scores:
      D1_user_impact: 2
      D2_business_impact: pending
      D3_data_integrity: 1
      D4_urgency: 2
    short_factors:
      user_impact: small user group sees confusing copy
      business_impact: pending_business_metric
      data_integrity: no data impact reported
      urgency: not production-blocking
    composite_score: 1.8
    hard_overrides_applied: []
    final_severity: P3_minor
    pending_factors: [business_impact]
    sla_commitments:
      response_sla: 3d
      resolution_sla: 1_month
      owner: frontend-team
    downstream_handoff:
      to_092_reproduction:
        prioritize_reproduction: false
        generate_debugging_aids: false
      to_N260_gate:
        block_release: false
      to_N005_feedback: {}
    self_check:
      R01_4_dimensions_scored: pass
      R06_sla_mapped: pass
```
