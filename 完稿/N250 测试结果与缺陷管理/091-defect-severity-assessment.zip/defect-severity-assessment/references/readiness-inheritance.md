# Readiness inheritance v2.2

Readiness is a contract, not a tone marker. It must be derived from self-check results and evidence sufficiency.

## Values
- `ready`: enough evidence exists for downstream consumption and all reject rules pass.
- `partial`: artifact shape is stable, but at least one important factor is unknown or requires human review.
- `blocked`: critical evidence is missing, contradictory, unsafe, or a reject rule failed.

## Degradation rules
- Preserve output shape even when readiness is partial or blocked.
- Use `pending_*` fields for missing inputs instead of inventing facts.
- When upstream artifacts exist, consume them as the source of truth and cite their ids.
- When upstream artifacts are absent, operate standalone from raw evidence and mark inferred fields.
- Do not downgrade a hard stop condition merely because evidence is incomplete; escalate the uncertainty.

## Gate mapping
- self_check all pass -> `readiness: ready`.
- only review/warn checks fail -> `readiness: partial` and route to human queue.
- reject/unsafe/no-evidence checks fail -> `readiness: blocked`.
