# N250 integration map v2.2

N250 canonical lifecycle:
1. `test-failure-attribution` -> attribution and failure-to-defect evidence.
2. `defect-classification` -> defect registry rows and ODC-aligned tags.
3. `defect-severity-assessment` -> authoritative severity, SLA, escalation, and business impact.
4. `defect-reproduction-steps-generation` -> minimal executable reproduction package.

## Node-level principles
- Each skill must work standalone on one valid input.
- Multiple skills must become stronger by sharing ids, evidence, and handoff triggers.
- The node should support a single-source defect package assembled from the four artifacts.
- The node emits defect signals to N005 and gate signals to N260.

## Event names
- `produced.n250.attribution.v2`
- `produced.n250.classification.v2`
- `produced.n250.severity.v2`
- `produced.n250.reproduction.v2`
- `signal.n250.defect_to_n005`
- `gate.n250.to_n260`
- `sla.n250.human_review`
- `exception.n250.circuit_open`

## Downstream consumers
- `N005`: defect signals for production-signal loop and data-driven requirement mining.
- `N260`: quality gate, special tests, and stop-the-line aggregation.
- `N300`: monitoring, log localization, and incident triage.
- `N360`: cross-team quality and version-scope alignment.
- `engineering_metrics`: distributions by category, severity, source, phase, and recurrence.

## N250 readiness rollup for N260
N260 should aggregate skill-level `self_check` and `readiness` into one node-level gate object instead of reinterpreting every artifact from scratch.

Recommended rollup object:
```yaml
n250_readiness_rollup:
  contract_version: n250.defect-management.v2
  schema_version: n250.rollup.v2.2.0
  defect_id:
  involved_artifacts:
    attribution: ready|partial|blocked|not_applicable
    classification: ready|partial|blocked|not_applicable
    severity: ready|partial|blocked|not_applicable
    reproduction: ready|partial|blocked|not_applicable
  node_readiness: ready|partial|blocked
  blocking_reasons: []
  human_reviews_required: []
  circuit_states: []
  release_blockers: []
  n005_feedback_signals: []
```

Rollup rules:
- `blocked`: any required artifact has `readiness: blocked`, production data appears in reproduction, a release-blocking circuit is open, or a P0/P1 defect lacks severity or reproduction handoff.
- `partial`: at least one required dimension is pending, human review is required, or reproduction is environment-limited but not release-blocking.
- `ready`: required artifacts pass self-check, no release-blocking circuit is open, and every P0/P1 defect has severity, SLA, and reproduction/debugging-aid handoff.
- `not_applicable`: valid only when an upstream skill proves the item is not a product defect, for example C2 flaky test routed to quarantine rather than defect severity.

## Fast-lane mode alignment
For urgent but evidence-limited cases, the recommended fast-lane chain is:
`quick_triage` -> `single_defect` -> `quick_sev` -> `from_failed_tc`.

Fast-lane expectations:
- Preserve all ids and evidence refs.
- Mark missing facts as `pending_*` instead of inventing them.
- Emit compact outputs where allowed.
- Escalate to deep/comprehensive modes only when a reject rule, P0/P1 signal, safety issue, or open circuit requires it.
