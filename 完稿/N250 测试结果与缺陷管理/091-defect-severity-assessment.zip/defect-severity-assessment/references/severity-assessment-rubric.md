# Severity assessment rubric v2.2

## Formula
`composite_score = D1_user_impact*0.30 + D2_business_impact*0.30 + D3_data_integrity*0.20 + D4_urgency*0.20`

## Severity mapping
- `P0_blocker`: composite > 4.0 or hard override.
- `P1_critical`: composite 3.0-4.0 or compliance/security/data rule.
- `P2_major`: composite 2.0-3.0.
- `P3_minor`: composite 1.0-2.0.
- `P4_trivial`: composite below 1.0.

## Business impact formulas
- Direct cost: `revenue_loss_per_hour * downtime_hours`.
- Indirect cost: `support_ticket_count * avg_handle_time_hours * hourly_rate`.
- Recovery cost: `engineering_pd * daily_rate + qa_pd * daily_rate + deploy_pd * daily_rate + comms_pd * daily_rate`.

Use `pending_business_metric` when an input is unknown. Never invent revenue or customer counts.


## Quick severity compactness
Use full matrix detail for `comprehensive_sev` and P0/P1 cases. For `quick_sev` P2-P4 cases, keep only the score, one-line factor rationale, pending factors, SLA, and downstream gate signals. This preserves decision quality while reducing token cost.
