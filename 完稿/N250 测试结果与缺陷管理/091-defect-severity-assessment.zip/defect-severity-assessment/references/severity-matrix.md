# Severity matrix v2.2

Score each dimension from 1 to 5.

## D1 user_impact
5: many users or critical users cannot use core function, no workaround.
4: many users affected or workflow badly degraded.
3: some users affected with painful workaround.
2: few users affected and workaround exists.
1: negligible user impact.

## D2 business_impact
5: major revenue loss, legal/regulatory event, severe reputation damage, or strategic commitment failure.
4: significant revenue, reputation, contract, or customer-success impact.
3: moderate support or business disruption.
2: small business impact.
1: no material business impact.

## D3 data_integrity
5: unrecoverable or widespread data loss/corruption.
4: limited unrecoverable or large recoverable corruption.
3: recoverable data issue or audit gap.
2: small easy-to-repair data issue.
1: no data issue.

## D4 urgency
5: production currently affected, release blocked, or deadline already breached.
4: production or contractual deadline likely affected soon.
3: should be fixed soon to avoid downstream risk.
2: can be planned into normal work.
1: backlog-level urgency.
