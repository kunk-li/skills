# SKILL.md 标准章节骨架

> 本文件为 N220–N260 技能包统一骨架参考。各组因历史原因使用略微不同的章节名；
> 新增或重构 skill 时，应尽量对齐下方顺序与命名。

## 推荐章节顺序

```
1.  ## <决策表 / 路由表>       (Routing decision table / Review boundary decision table)
2.  ## Version and artifact contract
3.  ## <角色定位>              (Role / Role and boundary / Role / role positioning)
4.  ## <模式选择>              (Mode selection / Selected mode / Modes)
5.  ## <输入>                  (Inputs / Primary inputs / Primary inputs / primary inputs)
6.  ## <输出契约>              (Core output contract / Output contract)
7.  ## <规则>                  (Auditable rules / Auditable rules summary / Design rules / Hard gates and v2 rules)
8.  ## <算法/工作流>           (Algorithm / Execution workflow)
9.  ## Example usage           (保留 Scenario A；B/C/D 下沉到 references/example-io-v2.md)
10. ## Usage scenarios
11. ## <跨技能集成>            (Cross-skill integration map) [如有]
12. ## Standalone usage guide
13. ## <韧性与治理>            (Resilience and governance / Resilience and governance addendum)
14. ## Quality bar
15. ## Reference files
```

## 命名约定对照

| 语义 | N220/N230 用法 | N240 用法 | N250 用法 | N260 用法 |
|---|---|---|---|---|
| 角色定位 | Role / role positioning | Role and boundary | Role | Role / role positioning |
| 模式选择 | Selected mode / mode selection | Mode selection | Modes | Selected mode / mode selection |
| 输入 | Primary inputs / primary inputs | Inputs | Inputs | Primary inputs / primary inputs |
| 规则 | Design rules / design rules | Auditable rules summary | Auditable rules | Design rules / design rules |
| 算法 | Execution workflow / execution workflow | Algorithm | Algorithm | Execution workflow / execution workflow |
| 边界 | Standalone rule / standalone usage | Role and boundary | Boundary | Standalone rule / standalone usage |

## 必须存在的字段（frontmatter / Version block）

- `skill_version: "2.2"`
- `schema_version`
- `contract_version`
- `workflow_node`
- `node_artifact_target`
- `function_bias`

## 必须存在的治理信号（正文任意位置）

- `downstream_handoff`
- `self_check`
- `readiness`
- `on_violation`
