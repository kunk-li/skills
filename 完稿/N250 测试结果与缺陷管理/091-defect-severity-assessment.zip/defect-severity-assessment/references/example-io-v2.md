# N250 示例输入输出 v2（扩展场景）

## 示例 3：缺陷严重度评估（defect-severity-assessment）

### 输入
- ODC类型：function，影响：reliability，blast_radius：中

### 输出
```yaml
severity_assessment:
  severity_tier: P1
  weighted_score: 6.8
  dimensions:
    frequency: 7
    business_impact: 6
    blast_radius: 5
    detectability: 9
  sla: 4小时内修复
  downstream_handoff:
    to: 092-defect-reproduction-steps-generation
```

## 示例 4：缺陷复现步骤生成（defect-reproduction-steps-generation）

### 输入
- 缺陷：OrderService NPE，严重度P1，归因C2

### 输出
```yaml
reproduction_package:
  mode: from_failed_tc
  reproduction_confidence: high
  steps:
    - step: 1
      action: POST /api/orders with null customer_id
      expected: 400 Bad Request
      actual: 500 NullPointerException
  downstream_handoff:
    to: engineering
    artifact: reproduction_package
```

## 091 扩展示例输入输出

### Scenario B — Hard override: data loss (always P0)

**Input**: User saved payment methods silently deleted after profile update.

**Output** (hard_override triggered):
```yaml
severity_assessment:
  hard_override_applied: true
  override_rule: R_DATA_LOSS_ALWAYS_P0
  severity_tier: P0
  weighted_score: 6.2
  sla: immediate
  war_room_needed: true
  escalation_target: engineering_lead + data_protection_officer
  downstream_handoff:
    to: 092-defect-reproduction-steps-generation
    priority: P0_immediate
```



### Scenario C — quick_sev mode (high volume triage)

**Input**: 12 defects from regression run; need rapid P-tier assignment.

**Output** (`quick_sev` mode, batch):
```yaml
severity_assessments:
  mode: quick_sev
  assessments:
    - defect_id: DEF-4831
      severity_tier: P2
      rationale: UI display glitch; no data impact; low blast radius
    - defect_id: DEF-4832
      severity_tier: P1
      rationale: API error for 10% of users on checkout; business impact confirmed
    - defect_id: DEF-4833
      severity_tier: P0
      override_rule: R_AUTH_BYPASS_ALWAYS_P0
      rationale: Authentication bypass — hard override applied
      war_room_needed: true
  processing_time: batch
  human_review_required: [DEF-4831]
```

### Scenario D — quick_sev batch mode (12 defects from regression run)

**Input**: 12 defects from regression; need rapid P-tier assignment for triage.

**Output** (`quick_sev` mode, batch):
```yaml
severity_assessments:
  mode: quick_sev
  assessments:
    - defect_id: DEF-4831
      severity_tier: P2
      rationale: UI display glitch; no data impact; low blast radius
    - defect_id: DEF-4832
      severity_tier: P1
      rationale: API error for 10% of users at checkout; business impact confirmed
    - defect_id: DEF-4833
      severity_tier: P0
      override_rule: R_AUTH_BYPASS_ALWAYS_P0
      rationale: Authentication bypass — hard override applied
      war_room_needed: true
  processing_mode: batch
  human_review_required: [DEF-4831]
  total_processed: 12
```

### Scenario D — Severity override by security team

**Input**: Defect initially auto-scored P2 (UX bug); security team flags potential data exposure.

**Output** (`security_override` mode):
```yaml
severity_assessment:
  initial_auto_tier: P2
  override_applied: true
  override_source: security_team_review
  override_rule: R_SECURITY_EXPOSURE_ALWAYS_P1_MIN
  final_severity_tier: P0
  override_rationale: >
    User profile photo URL contains signed token with 7-day expiry shared in
    email notifications. Token could expose private content to unauthorized parties.
  confidence: 0.95
  human_review_required: true
  war_room_needed: false
  required_actions:
    - Invalidate existing signed URLs immediately
    - Rotate URL signing key
    - Audit email logs for last 7 days
  sla: Fix within 4h (P0 SLA)
  downstream_handoff:
    to: 092-defect-reproduction-steps-generation
    signal: security_p0_priority
```
