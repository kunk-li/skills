# Output template v2.2: defect severity assessment

```yaml
metadata:
  schema_version: n250.severity.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: quick_sev|comprehensive_sev|batch_reassess
  readiness: ready|partial|blocked
  evidence_profile: strong|mixed|sparse|contradictory
  workflow_node: N250|standalone
  node_artifact_target: defect-severity-assessment.csv
  produced_events:
    - produced.n250.severity.v2
    - sla.n250.human_review

severity_rows:
  - assessment_id: SEV-001
    defect_id:
    technical_severity_hint_from_090:
    assessment_matrix:
      D1_user_impact:
        score:
        factors: {}
      D2_business_impact:
        score:
        factors: {}
      D3_data_integrity:
        score:
        factors: {}
      D4_urgency:
        score:
        factors: {}
    composite_score:
    final_severity: P0_blocker|P1_critical|P2_major|P3_minor|P4_trivial
    hard_overrides_applied: []
    sla_commitments:
      response_sla:
      resolution_sla:
      hotfix_required:
      communication_cadence:
    escalation:
      initial_owner:
      escalation_chain: []
      war_room_required: false
      executive_notification:
        required: false
        notify_within:
    business_impact_quantification:
      direct_cost: {}
      indirect_cost: {}
      recovery_cost: {}
      total_cost_estimate:
    risk_factors:
      spread_potential:
      aggravation_over_time:
      downstream_dependencies: []
    evidence_refs: []

downstream_handoff:
  to_092_reproduction: {}
  to_N260_gate: {}
  to_N005_feedback: {}

self_check: {}
```


## Compact template for quick_sev
Use this template when `selected_mode: quick_sev`, no P0/P1 hard override is present, and the user needs fast triage rather than a full business-impact report.

```yaml
metadata:
  schema_version: n250.severity.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: quick_sev
  output_compactness: quick
  readiness: ready|partial|blocked
  evidence_profile: strong|mixed|sparse|contradictory
  produced_events:
    - produced.n250.severity.v2

severity_rows:
  - assessment_id: SEV-001
    defect_id:
    technical_severity_hint_from_090:
    scores:
      D1_user_impact: 1-5|pending
      D2_business_impact: 1-5|pending
      D3_data_integrity: 1-5|pending
      D4_urgency: 1-5|pending
    short_factors:
      user_impact:
      business_impact:
      data_integrity:
      urgency:
    composite_score:
    hard_overrides_applied: []
    final_severity: P0_blocker|P1_critical|P2_major|P3_minor|P4_trivial
    pending_factors: []
    sla_commitments:
      response_sla:
      resolution_sla:
      owner:
    downstream_handoff:
      to_092_reproduction: {}
      to_N260_gate: {}
      to_N005_feedback: {}
    self_check: {}
```
