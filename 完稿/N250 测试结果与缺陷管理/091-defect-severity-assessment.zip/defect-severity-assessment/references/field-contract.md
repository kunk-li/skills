# N250 field contract v2.2

Use these names consistently across all N250 defect-management skills. Preserve ids from upstream artifacts and never mint a replacement id when one already exists.

## Common ids
- `failure_id`: stable id for a single observed failure.
- `failure_signature`: normalized hash or pattern built from stack trace, error message, testcase, and observable symptom.
- `defect_id`: stable id for the defect candidate or confirmed defect. If the issue is not a product defect, keep `defect_id: null` and explain why.
- `tc_id`, `suite_id`, `ci_run_id`, `pipeline_url`, `environment`, `module`, `owner_hint`, `fix_pr_id`, `regression_tc_id`.

## Evidence refs
Each `evidence_refs[]` entry should include:
- `ref_id`: short stable reference id.
- `source`: log, trace, metric, test output, screenshot, ticket, incident, user report, code change, config change, dependency status, or replay.
- `locator`: line number, timestamp, url, run id, file path, metric name, or screenshot id.
- `claim_supported`: what this evidence proves.
- `strength`: high, medium, or low.

## Contract metadata
Every output must include:
- `schema_version`: semantic artifact schema version, for example `n250.attribution.v2.2.0`.
- `contract_version`: `n250.defect-management.v2`.
- `selected_mode`: declared execution mode.
- `readiness`: ready, partial, or blocked.
- `evidence_profile`: strong, mixed, sparse, or contradictory.
- `workflow_node`: `N250` when used in the workflow; `standalone` when used independently.
- `node_artifact_target`: the artifact this skill produces.
- `produced_events[]`: event-bus signals emitted by this artifact.
- `self_check`: gate result and failed checks.

## Readiness and self-check binding
- `ready`: all required checks pass and no critical field is missing.
- `partial`: output is useful but at least one important dimension is pending.
- `blocked`: facts are insufficient for a trustworthy output or a hard rule is violated.
If any rule with `on_violation: reject` fails, set `readiness: blocked`. If any rule with `on_violation: human_review` fails, set `readiness: partial` unless there is also a reject failure.

## Schema version ratchet policy
Use semantic artifact schema versions with the shape `n250.<artifact>.vMAJOR.MINOR.PATCH`.

- Patch changes: typo fixes, clearer wording, examples, non-normative guidance, or bug fixes that do not change fields or meanings.
- Minor changes: additive optional fields, new examples, new reference guidance, new non-breaking enum aliases, or stricter documentation that preserves downstream compatibility.
- Major changes: renamed fields, removed fields, required-field changes, changed enum meanings, changed severity authority, changed category taxonomy, changed event names, or changed downstream handoff semantics.

Compatibility rules:
- Producers must emit their exact `schema_version` and `contract_version`.
- Consumers should declare `consumes_schema_version`, for example `^2`, in handoff-aware contexts.
- Same major and greater-or-equal minor is normally compatible when changes are additive.
- Major mismatch must set `readiness: blocked` or require human review before consumption.
- When unsure whether a change is breaking, treat it as major.

Every schema-changing revision should add:
- `contract_change_type`: patch, minor, major, or none.
- `compatible_with[]`: prior versions that are safe to consume.
- `migration_notes`: required only for major or risky minor changes.

## Rule observability for production tuning
During the first 30 days after deployment, outputs should preserve enough self-check telemetry for N260/N390 to measure false positives and excessive blocking.

Recommended telemetry fields:
- `rule_id`
- `rule_result`: pass, fail, auto_enforced, auto_upgraded, human_review, or waived_by_human
- `on_violation`
- `readiness_effect`: none, partial, blocked, or escalated
- `false_positive_suspected`: true or false
- `operator_override_reason`

Do not relax reject rules preemptively. Prefer observing trigger rates first; if a rule blocks more than 15% of medium-evidence cases with later human approval, change that rule in a future minor or major version with migration notes.
