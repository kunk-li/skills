# Severity circuit breaker v2.2

## Business-level triggers
- Any P0 -> open severity circuit for the affected release or production slice.
- More than 5 P0 candidates per day -> open portfolio circuit and notify leadership.
- P1/P0 with compliance, security, or data loss -> open governance circuit.
- SLA response missed -> escalate to manager; resolution missed -> escalate to director.

## Actions
- Set `block_release: true` for P0 and for P1 when compliance/security/data-loss risk is present.
- Route to SLA human queue with priority P0/P1/P2.
- Trigger 092 prioritized reproduction and debugging aids for P0/P1.
- Emit `exception.n250.circuit_open` when the circuit is open.

## Recovery
Circuit closes only after severity owner confirms mitigation, customer/data risk is addressed, and gate owner acknowledges.
