# N250 示例输入输出

## 示例 1：测试失败归因（test-failure-attribution）

### 输入
- 失败测试：payment_gateway_test::test_retry_on_timeout
- 日志：ConnectionTimeout after 5000ms，提交 a3f92c 将超时从8000ms改为5000ms

### 输出
```yaml
attribution_result:
  confidence: 0.78
  primary_category: C2_product_code_bug
  attribution_summary: 超时缩短提交直接导致重试次数超限
  downstream_handoff:
    to: 090-defect-classification
    category: C2_product_code_bug
```

## 示例 2：缺陷分类（defect-classification）

### 输入
- 归因结果：C2_product_code_bug，NPE at OrderService.java:142

### 输出
```yaml
classification_record:
  odc_type: function
  odc_trigger: code_review
  odc_impact: reliability
  classification_confidence: 0.85
  downstream_handoff:
    to: 091-defect-severity-assessment
```
