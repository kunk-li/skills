# Quality checklist v2.2

Before finalizing any N250 artifact, verify:
- The output declares `schema_version`, `contract_version`, `selected_mode`, `readiness`, and `evidence_profile`.
- Every major conclusion links to `evidence_refs[]`.
- Facts, hypotheses, decisions, and actions are separated.
- Shared ids are preserved across the N250 chain.
- `downstream_handoff` is field-level and not just prose.
- `produced_events[]` contains at least one artifact event and one downstream signal when applicable.
- `self_check` contains pass/fail status for every rule used by the skill.
- Missing information is represented as `pending_*`, not invented.
- N250 workflow use stays compatible with standalone use.
