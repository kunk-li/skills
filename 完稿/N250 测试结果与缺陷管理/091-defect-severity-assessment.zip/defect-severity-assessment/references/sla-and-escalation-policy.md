# SLA and escalation policy v2.2

## SLA defaults
- P0_blocker: response 1h, resolution 4h, hotfix yes, communication every 30 minutes.
- P1_critical: response 4h, resolution 24h, hotfix yes, communication every 2 hours.
- P2_major: response 24h, resolution 1 week, hotfix assess, communication daily.
- P3_minor: response 3 days, resolution 1 month, hotfix no, communication weekly.
- P4_trivial: response 2 weeks, resolution backlog, hotfix no, communication on planning cadence.

## Escalation chain
Emit explicit entries:
- level 1: owner or on-call, trigger_after 0 minutes for P0/P1.
- level 2: team lead, trigger_after 30 minutes for P0 or 4 hours for P1.
- level 3: director or release owner, trigger_after 2 hours for P0 or SLA breach for P1.
- level 4: executive notification when P0 is customer-facing, data/security/compliance related, or contractual.

## War room
Required when final severity is P0 and customer-facing blast radius is some_users or all_users. Consider for P1 with compliance/security/data risk.
