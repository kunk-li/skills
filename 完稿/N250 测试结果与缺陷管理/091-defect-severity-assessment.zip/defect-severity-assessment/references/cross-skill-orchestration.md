# Cross-skill orchestration for 091 v2.2

This skill is baton 3 of 4 in N250 and is the severity authority.

## Consume from 090
- `defect_id`
- `related_failures[]`
- `D1_odc_defect_type`
- `technical_severity_hint`
- `additional_tags`
- `phase_delta`
- `classification_confidence_by_dimension`
- `severity_authority`

## Consume from 089 when needed
- stable failure evidence
- real regression signal
- block merge signal
- environment and replay confidence

## Produce for 092
- `defect_id`
- `final_severity`
- `composite_score`
- `prioritize_reproduction`
- `generate_debugging_aids`
- `required_attempts_minimum`
- `logs_to_capture_priority[]`
- `monitoring_to_enable[]`

## Behavior change when combined
When 090 exists, treat D2 only as prior context. When 092 exists, set field-level triggers instead of writing reproduction steps yourself. When N260 is active, emit block/release and SLA queue fields.
