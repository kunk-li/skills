# Cross-skill orchestration for 092 v2.2

This skill is baton 4 of 4 in N250.

## Consume from 089
- `failure_signature`
- `stable_failure`
- `replay_required`
- `replay_results`
- `environment_constraints[]`
- `logs_to_capture[]`

## Consume from 090
- `defect_id`
- `D1_odc_defect_type`
- `functional_area`
- `related_failures[]`
- `reproduction_strategy_hint`
- `evidence_refs[]`

## Consume from 091
- `final_severity`
- `prioritize_reproduction`
- `generate_debugging_aids`
- `required_attempts_minimum`
- `logs_to_capture_priority[]`
- `monitoring_to_enable[]`
- `owner_and_sla`

## Behavior change when combined
If 091 final severity is P0/P1 or `generate_debugging_aids` is true, debugging aids are mandatory and reliability measurement must be explicit. If 090 provides ODC timing, prioritize timing/concurrency templates. If 089 marks replay_required, include replay plan and do not claim verified until replay evidence exists.
