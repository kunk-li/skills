# Common reproduction mistakes

Avoid:
- Leaving out environment, data, or feature-flag prerequisites.
- Using raw production data instead of synthetic or sanitized data.
- Providing only narrative steps when a test case or API request is possible.
- Claiming verification when reproduction was not actually confirmed.
- Ignoring false-positive checks.
- Omitting cleanup for created records.
- Failing to add debugging aids for P0/P1 defects.
