# Reproduction circuit breaker v2.2

## Reproduction-specific triggers
- Three failed reproduction attempts with unchanged evidence -> open `non_repro` circuit and escalate strategy.
- P0/P1 lacks debugging aids -> open `handoff_quality` circuit.
- Missing cleanup for generated test data -> open `data_safety` circuit.
- Raw production data requested or used -> block output until sanitized alternative is defined.

## Actions
- Switch format strategy: manual -> script -> api_test -> test_case, or add instrumentation.
- Request or identify missing logs, traces, fixtures, flags, or environment snapshots.
- Route to defect owner, QA lead, or on-call depending on severity.
- Mark `verification_status: blocked_non_repro` when reproduction is not currently trustworthy.

## Recovery
Close only after a verified reproduction, accepted mitigation, or explicit owner decision that reproduction is impossible and alternate evidence is sufficient.
