# Real examples v2.2

## Example A: executable reproduction for concurrent idempotency defect

```yaml
metadata:
  schema_version: n250.reproduction.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: executable_package
  readiness: ready
  evidence_profile: strong
  workflow_node: N250
  node_artifact_target: defect-reproduction-steps.md
  produced_events:
    - produced.n250.reproduction.v2

reproduction_packages:
  - reproduction_id: REPRO-001
    defect_id: DEF-ORDER-001
    source_failure_id: failure-order-idempotency-002
    format_kind: test_case
    minimal_reproduction:
      original_scenario:
        steps_count: 15
        data_complexity: high
      reduced_scenario:
        steps_count: 4
        data_complexity: minimal
        reduction_percentage: 73%
      isolated_conditions:
        required:
          - condition: two concurrent POST /orders calls
            reason: triggers race in idempotency check
          - condition: same X-Idempotency-Key
            reason: verifies duplicate prevention
        excluded:
          - factor: specific user profile
            verified_not_needed: true
    executable_format:
      framework_or_language: junit5
      full_script_or_test_code: |
        @Test
        void reproduceDuplicateOrderWithSameIdempotencyKey() throws Exception {
          String key = "bug-repro-" + UUID.randomUUID();
          CountDownLatch start = new CountDownLatch(1);
          ExecutorService pool = Executors.newFixedThreadPool(2);
          AtomicInteger created = new AtomicInteger(0);
          for (int i = 0; i < 2; i++) {
            pool.submit(() -> {
              start.await();
              ResponseEntity<OrderResponse> r = postOrderWithKey(key);
              if (r.getStatusCode() == HttpStatus.CREATED) created.incrementAndGet();
              return null;
            });
          }
          start.countDown();
          pool.shutdown();
          pool.awaitTermination(10, TimeUnit.SECONDS);
          assertThat(created.get()).isEqualTo(1);
        }
      commands:
        - ./gradlew test --tests OrderIdempotencyReproTest
      dependencies:
        - testcontainers-postgres
    test_data:
      seed_data:
        - data_source: sql_script
          data_location: testdata/users_minimal.sql
      generated_data:
        - factory: OrderRequestFactory.validOrder
          parameters:
            sku: TEST-SKU-1
      data_cleanup:
        automatic: true
        cleanup_script: DELETE FROM orders WHERE idempotency_key LIKE 'bug-repro-%';
      prod_data_used: false
    step_by_step:
      preparation_steps:
        - step_number: 1
          description: start clean database container
          command_or_action: docker compose up -d postgres
          expected_outcome: postgres ready
      reproduction_steps:
        - step_number: 1
          description: send two concurrent requests with same idempotency key
          command_or_action: run JUnit test method above
          expected_outcome: only one order should be created
          failure_manifestation:
            observable:
              - kind: db_state
                specific_content: two rows share the same idempotency key
      verification_steps:
        - step_number: 1
          description: verify duplicate count
          how_to_verify: SELECT COUNT(*) FROM orders WHERE idempotency_key = :key
    environment_requirements:
      mandatory:
        database: postgres 15
        runtime_version: java 21
      optional: [local trace collector]
      constraints: [clean state, no concurrent unrelated tests]
    verification_checklist:
      success_criteria:
        - indicator: duplicate order created
          match_pattern: count == 2
      false_positive_check:
        differentiating_factors:
          - must use same idempotency key
          - must not be generic 500 response
    reproduction_reliability:
      success_rate: 90%
      flakiness_factors:
        - factor: scheduler timing
          likelihood: sometimes
          mitigation: repeat up to 10 attempts for P1
      required_attempts:
        typical: 1
        worst_case: 10
    debugging_aids:
      logs_to_capture:
        - log_source: order-service
          log_level: DEBUG
          keywords_to_watch: [idempotency, duplicate, race]
      monitoring_to_enable: [distributed_trace]
      breakpoint_suggestions:
        - file: OrderService.java
          line: 62
          reason: check-before-insert race window
    verification_status: verified
    evidence_refs: [E1, E2]

downstream_handoff:
  to_dev_team:
    reproduction_id: REPRO-001
    priority: P1
    owner_hint: order-service-team
  to_N230_test:
    regression_tc_candidate: OrderIdempotencyReproTest
    convert_to_permanent_test: true
  to_N260_gate:
    reproduction_ready: true
    no_prod_data: true
  to_N300_incident:
    trace_keywords: [idempotency, duplicate]
  to_knowledge_base:
    known_issue_pattern: concurrent_idempotency_duplicate_order

self_check:
  R01_minimal_reproduction: pass
  R02_executable_format_preferred: pass
  R03_verification_steps_included: pass
  R04_environment_requirements_explicit: pass
  R05_data_cleanup_provided: pass
  R06_reliability_documented: pass
  R07_no_prod_data: pass
  R08_debugging_aids_for_high: pass
  R09_non_repro_escalation: pass
```

## Example B: partial user-report reproduction

```yaml
metadata:
  schema_version: n250.reproduction.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: from_user_report
  readiness: partial
  evidence_profile: sparse
  workflow_node: standalone
  produced_events:
    - produced.n250.reproduction.v2

reproduction_packages:
  - reproduction_id: REPRO-002
    defect_id: DEF-UI-014
    source_failure_id: null
    format_kind: manual_steps
    minimal_reproduction:
      original_scenario:
        steps_count: unknown
        data_complexity: unknown
      reduced_scenario:
        steps_count: 3
        data_complexity: pending_user_state
        reduction_percentage: pending
      isolated_conditions:
        required:
          - condition: same browser and account state as reporter
            reason: report lacks exact environment
        excluded: []
    test_data:
      seed_data: []
      generated_data: []
      data_cleanup:
        automatic: false
        cleanup_script: not_applicable_no_data_mutation
      prod_data_used: false
    step_by_step:
      preparation_steps:
        - step_number: 1
          description: open account settings page
          command_or_action: navigate to /settings/account
          expected_outcome: page loads
      reproduction_steps:
        - step_number: 1
          description: change display name to a long value
          command_or_action: type 80-character name and save
          expected_outcome: validation message should appear
      verification_steps:
        - step_number: 1
          description: verify reported UI overlap
          how_to_verify: screenshot comparison against reporter attachment
    verification_checklist:
      success_criteria:
        - indicator: label overlaps save button
          match_pattern: visual overlap
      false_positive_check:
        differentiating_factors:
          - distinguish from browser zoom above 125 percent
    reproduction_reliability:
      success_rate: pending
      flakiness_factors:
        - factor: unknown browser version
          likelihood: sometimes
          mitigation: ask reporter for browser and zoom
      required_attempts:
        typical: pending
        worst_case: pending
    debugging_aids:
      logs_to_capture: []
      monitoring_to_enable: []
      breakpoint_suggestions: []
    verification_status: pending
    evidence_refs:
      - ref_id: E1
        source: user report
        locator: support-ticket-77
        claim_supported: symptom exists for reporter
        strength: low

self_check:
  R01_minimal_reproduction: pass
  R02_executable_format_preferred: warn
  R03_verification_steps_included: pass
  R04_environment_requirements_explicit: pass
  R05_data_cleanup_provided: pass
  R06_reliability_documented: pass
  R07_no_prod_data: pass
  R08_debugging_aids_for_high: pass
  R09_non_repro_escalation: pass
```
