# Reproduction patterns guide v2.2

## Executable format priority
1. `test_case`: JUnit, pytest, Jest, Cypress, Playwright, or project-native test.
2. `api_test`: curl, Postman collection, HTTPie, or contract test.
3. `script`: bash, Python, JavaScript, or seed/replay script.
4. `gherkin`: BDD scenario for human-readable review.
5. `manual_steps`: last resort when automation evidence is unavailable.

## Pattern hints
- API defect: include method, URL, headers, body, auth context, idempotency key, expected status, actual status, and response diff.
- UI defect: include role, browser/device, state, navigation path, action, screenshot evidence, and accessibility or locale conditions.
- Concurrency/timing defect: include actors, start barrier, ordering, latency windows, retry count, and observed race signature.
- Config/environment defect: include versions, flags, env vars, schema version, region, dependencies, and clean-state requirements.
- Performance defect: include load profile, data volume, baseline, threshold, metric, and observation window.

## Minimal reduction technique
1. Capture the full original scenario.
2. Remove one factor at a time: user profile, data volume, optional services, UI steps, retries, flags.
3. Rerun or reason against the failure signature after each removal.
4. Stop when further removal changes the signature or hides the failure.
5. Report original step count, reduced step count, and reduction percentage.
