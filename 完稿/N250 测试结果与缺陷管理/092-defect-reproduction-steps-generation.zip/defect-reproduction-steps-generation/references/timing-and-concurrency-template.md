# Timing and concurrency template v2.2

Use this notation for timing-sensitive reproductions:

```yaml
actors:
  - name: actor_a
    role:
  - name: actor_b
    role:
barriers:
  - name: start_latch
    release_condition: both actors ready
sequence:
  - t: 0ms
    actor: actor_a
    action:
  - t: 0ms
    actor: actor_b
    action:
  - t: +50ms
    observe:
expected:
actual:
failure_signature:
retries:
  typical:
  worst_case:
```

Always identify what timing condition is mandatory and what timing condition was tested and found unnecessary.
