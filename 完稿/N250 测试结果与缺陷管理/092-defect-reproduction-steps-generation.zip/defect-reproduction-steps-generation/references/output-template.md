# Output template v2.2: defect reproduction steps

```yaml
metadata:
  schema_version: n250.reproduction.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: from_failed_tc|from_user_report|from_production_incident|executable_package
  readiness: ready|partial|blocked
  evidence_profile: strong|mixed|sparse|contradictory
  workflow_node: N250|standalone
  node_artifact_target: defect-reproduction-steps.md
  produced_events:
    - produced.n250.reproduction.v2

reproduction_packages:
  - reproduction_id: REPRO-001
    defect_id:
    source_failure_id:
    format_kind: test_case|api_test|script|gherkin|manual_steps
    minimal_reproduction:
      original_scenario:
        steps_count:
        data_complexity:
      reduced_scenario:
        steps_count:
        data_complexity:
        reduction_percentage:
      isolated_conditions:
        required: []
        excluded: []
    executable_format:
      framework_or_language:
      full_script_or_test_code:
      commands: []
      dependencies: []
    test_data:
      seed_data: []
      generated_data: []
      data_cleanup:
        automatic: true
        cleanup_script:
      prod_data_used: false
    step_by_step:
      preparation_steps: []
      reproduction_steps: []
      verification_steps: []
    environment_requirements:
      mandatory: {}
      optional: []
      constraints: []
    verification_checklist:
      success_criteria: []
      false_positive_check:
        differentiating_factors: []
    reproduction_reliability:
      success_rate:
      flakiness_factors: []
      required_attempts:
        typical:
        worst_case:
    debugging_aids:
      logs_to_capture: []
      monitoring_to_enable: []
      breakpoint_suggestions: []
    verification_status: verified|pending|blocked_non_repro|environment_limited
    evidence_refs: []

downstream_handoff:
  to_dev_team: {}
  to_N230_test: {}
  to_N260_gate: {}
  to_N300_incident: {}
  to_knowledge_base: {}

self_check: {}
```
