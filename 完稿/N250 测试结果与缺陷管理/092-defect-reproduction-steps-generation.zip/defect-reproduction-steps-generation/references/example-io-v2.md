# N250 示例输入输出 v2（扩展场景）

## 示例 3：缺陷严重度评估（defect-severity-assessment）

### 输入
- ODC类型：function，影响：reliability，blast_radius：中

### 输出
```yaml
severity_assessment:
  severity_tier: P1
  weighted_score: 6.8
  dimensions:
    frequency: 7
    business_impact: 6
    blast_radius: 5
    detectability: 9
  sla: 4小时内修复
  downstream_handoff:
    to: 092-defect-reproduction-steps-generation
```

## 示例 4：缺陷复现步骤生成（defect-reproduction-steps-generation）

### 输入
- 缺陷：OrderService NPE，严重度P1，归因C2

### 输出
```yaml
reproduction_package:
  mode: from_failed_tc
  reproduction_confidence: high
  steps:
    - step: 1
      action: POST /api/orders with null customer_id
      expected: 400 Bad Request
      actual: 500 NullPointerException
  downstream_handoff:
    to: engineering
    artifact: reproduction_package
```

## 092 扩展示例输入输出

### Scenario B — Production incident reproduction

**Input**: P0 — payment refunds returning 500 for orders > $10,000; sanitized production logs.

**Output** (`from_production_incident` mode):
```yaml
reproduction_package:
  mode: from_production_incident
  reproduction_confidence: high
  data_source: sanitized
  steps:
    - step: 1
      action: Create order with total $10,001 via POST /api/v1/orders
      expected: HTTP 201 with order_id
    - step: 2
      action: POST /api/v1/refunds with that order_id
      expected: HTTP 200
      actual: HTTP 500 — "Amount exceeds refund limit 10000.00"
    - step: 3
      action: Check RefundService.java:89 — hardcoded limit
  false_positive_check: Confirm HTTP 200 for order total $9,999
  root_cause_hint: Hardcoded ceiling at RefundService.java:89
```



### Scenario C — Executable package (docker-compose setup)

**Input**: Defect requires specific DB state to reproduce; engineering needs runnable environment.

**Output** (`executable_package` mode):
```yaml
reproduction_package:
  mode: executable_package
  format: docker_compose
  reproduction_confidence: high
  setup: |
    # Run: docker-compose -f reproduce-DEF-4821.yml up
    version: '3.8'
    services:
      db:
        image: postgres:15
        environment:
          POSTGRES_DB: test_orders
          POSTGRES_PASSWORD: test
        volumes:
          - ./seed-data/orders-with-discount.sql:/docker-entrypoint-initdb.d/seed.sql
      app:
        image: payment-service:v2.4.0
        depends_on: [db]
        environment:
          DB_URL: jdbc:postgresql://db:5432/test_orders
  reproduction_steps: |
    1. docker-compose up
    2. POST http://localhost:8080/api/v1/refunds with order_id from seed data
    3. Observe HTTP 500 with "Amount exceeds refund limit"
  teardown: docker-compose down -v
```

### Scenario D — Executable docker-compose package

**Input**: Defect requires specific DB state; engineering needs a runnable environment.

**Output** (`executable_package` mode):
```yaml
reproduction_package:
  mode: executable_package
  format: docker_compose
  reproduction_confidence: high
  setup: |
    # Run: docker-compose -f reproduce-DEF-4821.yml up
    version: '3.8'
    services:
      db:
        image: postgres:15
        environment:
          POSTGRES_DB: test_orders
          POSTGRES_PASSWORD: test
        volumes:
          - ./seed-data/orders-seed.sql:/docker-entrypoint-initdb.d/seed.sql
      app:
        image: payment-service:v2.4.0
        depends_on: [db]
        ports: ["8080:8080"]
  reproduction_steps: |
    1. docker-compose up
    2. POST http://localhost:8080/api/v1/refunds with order_id from seed data
    3. Observe HTTP 500 "Amount exceeds refund limit"
  false_positive_check: Confirm HTTP 200 for order total $9,999
  teardown: docker-compose down -v
```

### Scenario D — Cannot reproduce in local env (environment-dependent)

**Input**: Defect only occurs in staging with specific DB snapshot; not reproducible locally.

**Output** (`environment_dependent` mode):
```yaml
reproduction_package:
  mode: environment_dependent
  readiness: constrained
  pending_environment_access: true
  environment_requirements:
    required_env: staging
    required_db_snapshot: staging-snapshot-2026-05-14T18:00:00Z
    required_data: Order IDs in state PAYMENT_PENDING with age >4h
  reproduction_steps: |
    1. Restore staging-snapshot-2026-05-14T18:00:00Z to staging DB
    2. SSH to staging app server
    3. POST /api/v1/orders/retry with body: {"order_id": "<PAYMENT_PENDING order >4h old>"}
    4. Observe: HTTP 500 "NullPointerException at OrderRetryService.java:88"
  cannot_reproduce_locally_reason: >
    Requires orders aged >4h in PAYMENT_PENDING state — local DB does not have
    sufficient aged data. Snapshot restore required.
  alternative_local_approach: >
    Manually set order.created_at = NOW() - INTERVAL 5 HOUR in local DB
    for any order in PAYMENT_PENDING state, then retry.
  false_positive_check: Confirm fresh orders (age <1h) do NOT trigger the error
```
