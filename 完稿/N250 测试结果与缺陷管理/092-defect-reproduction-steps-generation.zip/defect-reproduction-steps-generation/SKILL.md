---
name: defect-reproduction-steps-generation
description: generate minimal, executable defect reproduction packages from failed tests, user reports, production incidents, logs, environment snapshots, classification, and severity triggers. use for standalone bug reproduction, regression backfill, engineering handoff, or n250 workflows where prioritized p0 or p1 defects require reliable steps, fixtures, cleanup, verification, and debugging aids.
---
# defect-reproduction-steps-generation

## Role
Create handoff-ready reproduction packages. This skill is standalone-capable and is baton 4 in the N250 chain.

## Boundary
- Produce minimal steps, executable format, data setup, cleanup, verification, reliability, and debugging aids.
- Prefer existing failed testcases, fixtures, and logs over invented steps.
- Do not claim reproduction is verified unless it was actually run or proven by evidence.
- Do not use production data; use synthetic, fixture, factory, or sanitized data.

## Routing triggers
Use this skill for failed testcase reproduction, user-report reproduction drafts, API or UI reproduction, timing/concurrency reproduction, environment-specific setup, regression testcase backfill, or P0/P1 handoff.

## Modes
- `from_failed_tc`: derive reproduction from failed testcase, logs, and fixtures.
- `from_user_report`: build structured reproduction from user or support observations.
- `from_production_incident`: reconstruct safe reproduction from incident, logs, trace, and sanitized scenario.
- `executable_package`: generate script, API test, test case, or compose-style setup.

## Inputs
Minimum standalone input: one symptom, failed testcase, user report, incident summary, log excerpt, or bug observation.

Preferred upstream inputs:
- 089 attribution: failure signature, replay need, environment constraints, logs to capture.
- 090 classification: defect id, ODC type, functional area, root cause category, evidence refs.
- 091 severity: final severity, prioritize_reproduction, generate_debugging_aids, SLA, risk factors.

## Output contract
Default to Markdown with embedded code blocks or table sections. Follow `references/output-template.md`.

Required sections:
- `metadata`
- `reproduction_packages[]`
- `minimal_reproduction`
- `executable_format`
- `test_data`
- `step_by_step`
- `environment_requirements`
- `verification_checklist`
- `reproduction_reliability`
- `debugging_aids`
- `circuit_breaker_evaluation`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `schema_version: n250.reproduction.v2.2.0`
- `contract_version: n250.defect-management.v2`
- `selected_mode`, `readiness`, `evidence_profile`
- `function_bias: handoff_ready_result`
- `workflow_node: N250` or `standalone`
- `node_artifact_target: defect-reproduction-steps.md`
- `produced_events[]`

## Rules
- R01_minimal_reproduction: remove nonessential steps and record reduction attempts; on_violation: human_review.
- R02_executable_format_preferred: prefer test_case, api_test, script, then gherkin, with manual_steps last; on_violation: warn.
- R03_verification_steps_included: include success criteria and false-positive checks; on_violation: reject.
- R04_environment_requirements_explicit: list mandatory versions, dependencies, config, and constraints; on_violation: reject.
- R05_data_cleanup_provided: test data must include cleanup or reset plan; on_violation: reject.
- R06_reliability_documented: include success rate, attempts, or pending measurement plan; on_violation: reject.
- R07_no_prod_data: do not use raw production data; on_violation: reject.
- R08_debugging_aids_for_high: P0/P1 or `generate_debugging_aids: true` requires logs, monitoring, and breakpoint or trace suggestions; on_violation: reject.
- R09_non_repro_escalation: three failed reproduction attempts require strategy change or escalation; on_violation: auto_enforce.

## Algorithm
1. Choose input mode: failed test, user report, production incident, or executable package.
2. Start with the full scenario and iteratively remove nonessential steps while checking whether the signature still appears.
3. Choose executable format by priority: test_case, api_test, script, gherkin, manual_steps.
4. Define fixture, seed, factory, container, or sanitized data setup and cleanup.
5. Write preparation, reproduction, and verification steps with expected and actual results.
6. Add false-positive checks to prove the observed failure is this defect, not a generic error.
7. Measure or plan reliability; for high severity, default to 10 attempts unless unsafe/impossible.
8. Add debugging aids when triggered by 091 or when severity/evidence demands it.
9. Emit handoff to engineering, N230 regression tests, N260 gate, N300 incident, and knowledge base.

## Downstream handoff requirements
`downstream_handoff.to_dev_team` must include `reproduction_id`, `defect_id`, `format_kind`, `commands_or_steps`, `data_setup`, `cleanup`, `success_criteria`, and `debugging_aids`.

`downstream_handoff.to_N230_test` must include `regression_tc_candidate`, `test_case_code_or_outline`, `fixture_needs`, and `reliability_target`.

`downstream_handoff.to_N260_gate` must include `reproduction_verified`, `verification_status`, `reliability_success_rate`, and `non_repro_escalation`.

Emit `signal.n250.defect_to_n005` when repeated non-repro, high-severity, recurring, or process-gap patterns appear.

## Reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/reproduction-patterns-guide.md`
- `references/timing-and-concurrency-template.md`
- `references/circuit-breaker-policy.md`
- `references/cross-skill-orchestration.md`
- `references/n250-integration-map.md`
- `references/readiness-inheritance.md`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
## v2.2 operational refinements
- Use full YAML examples in `references/real-examples.md` for few-shot guidance.
- Follow schema ratchet and compatibility rules in `references/field-contract.md`.
- Feed self-check and readiness into N250 rollup for N260 using `references/n250-integration-map.md`.
