---
name: defect-reproduction-steps-generation
description: generate minimal, executable defect reproduction packages from failed tests, user reports, production incidents, logs, environment snapshots, classification, and severity triggers. use for standalone bug reproduction, regression backfill, engineering handoff, or n250 workflows where prioritized p0 or p1 defects require reliable steps, fixtures, cleanup, verification, and debugging aids. trigger on any request to generate reproduction steps, create a minimal repro package, write steps-to-reproduce for a bug, or build a regression test from a defect. [N250]
---
# defect-reproduction-steps-generation


## Routing decision table

| Situation | Action |
|---|---|
| Failed test case available | Use `from_failed_tc` mode; reference tc_id in output |
| User report only | Use `from_user_report` mode; extract steps from description |
| Production incident | Use `from_production_incident`; sanitize all data before output |
| 3 consecutive reproduction failures | Trigger `R09_non_repro_escalation`; change strategy or escalate |
| Production data required | Reject raw production data; create sanitized fixture instead |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n250.defect-reproduction-steps.v2.2"
contract_version: "n250.defect-management.v2.2"
workflow_node: "N250"
```


## Role
Create handoff-ready reproduction packages. This skill is standalone-capable and is baton 4 in the N250 chain.

## Boundary
- Produce minimal steps, executable format, data setup, cleanup, verification, reliability, and debugging aids.
- Prefer existing failed testcases, fixtures, and logs over invented steps.
- Do not claim reproduction is verified unless it was actually run or proven by evidence.
- Do not use production data; use synthetic, fixture, factory, or sanitized data.

## Routing triggers
Use this skill for failed testcase reproduction, user-report reproduction drafts, API or UI reproduction, timing/concurrency reproduction, environment-specific setup, regression testcase backfill, or P0/P1 handoff.

## Modes
- `from_failed_tc`: derive reproduction from failed testcase, logs, and fixtures.
- `from_user_report`: build structured reproduction from user or support observations.
- `from_production_incident`: reconstruct safe reproduction from incident, logs, trace, and sanitized scenario.
- `executable_package`: generate script, API test, test case, or compose-style setup.

## Inputs
Minimum standalone input: one symptom, failed testcase, user report, incident summary, log excerpt, or bug observation.

Preferred upstream inputs:
- 089 attribution: failure signature, replay need, environment constraints, logs to capture.
- 090 classification: defect id, ODC type, functional area, root cause category, evidence refs.
- 091 severity: final severity, prioritize_reproduction, generate_debugging_aids, SLA, risk factors.


### Input tiers

**Required (minimum standalone input):**
- One symptom, failed testcase, user report, incident summary, log excerpt, or bug observation.

**Optional enhancement inputs:**
- Attribution result from 089, classification from 090, severity from 091, environment snapshots, production traces.

### Degradation rules

- If a failed testcase is unavailable, derive reproduction from user report or incident log and mark `mode: from_user_report` with `pending_testcase_confirmation`.
- If production data is involved, use synthetic or sanitized fixtures and mark `data_source: sanitized` with `pending_data_review`.
- Keep the reproduction package shape stable even under minimal evidence; use `pending_*` fields rather than fabricating steps.

## Output contract
Default to Markdown with embedded code blocks or table sections. Follow `references/output-template.md`.

Required sections:
- `metadata`
- `reproduction_packages[]`
- `minimal_reproduction`
- `executable_format`
- `test_data`
- `step_by_step`
- `environment_requirements`
- `verification_checklist`
- `reproduction_reliability`
- `debugging_aids`
- `circuit_breaker_evaluation`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `schema_version: n250.reproduction.v2.2.0`
- `contract_version: n250.defect-management.v2`
- `selected_mode`, `readiness`, `evidence_profile`
- `function_bias: handoff_ready_result`
- `workflow_node: N250` or `standalone`
- `node_artifact_target: defect-reproduction-steps.md`
- `produced_events[]`

## Auditable rules
- R01_minimal_reproduction: remove nonessential steps and record reduction attempts; on_violation: human_review.
- R02_executable_format_preferred: prefer test_case, api_test, script, then gherkin, with manual_steps last; on_violation: warn.
- R03_verification_steps_included: include success criteria and false-positive checks; on_violation: reject.
- R04_environment_requirements_explicit: list mandatory versions, dependencies, config, and constraints; on_violation: reject.
- R05_data_cleanup_provided: test data must include cleanup or reset plan; on_violation: reject.
- R06_reliability_documented: include success rate, attempts, or pending measurement plan; on_violation: reject.
- R07_no_prod_data: do not use raw production data; on_violation: reject.
- R08_debugging_aids_for_high: P0/P1 or `generate_debugging_aids: true` requires logs, monitoring, and breakpoint or trace suggestions; on_violation: reject.
- R09_non_repro_escalation: three failed reproduction attempts require strategy change or escalation; on_violation: auto_enforce.

## Algorithm
1. Choose input mode: failed test, user report, production incident, or executable package.
2. Start with the full scenario and iteratively remove nonessential steps while checking whether the signature still appears.
3. Choose executable format by priority: test_case, api_test, script, gherkin, manual_steps.
4. Define fixture, seed, factory, container, or sanitized data setup and cleanup.
5. Write preparation, reproduction, and verification steps with expected and actual results.
6. Add false-positive checks to prove the observed failure is this defect, not a generic error.
7. Measure or plan reliability; for high severity, default to 10 attempts unless unsafe/impossible.
8. Add debugging aids when triggered by 091 or when severity/evidence demands it.
9. Emit handoff to engineering, N230 regression tests, N260 gate, N300 incident, and knowledge base.



## Usage scenarios

- `from_failed_tc`: derive reproduction from a failed test case, logs, and fixtures.
- `from_user_report`: build structured reproduction from user or support observations.
- `from_production_incident`: reconstruct safe reproduction from incident logs and sanitized scenario.
- `executable_package`: generate script, API test, or compose-style setup for engineering handoff.
- `n250_chain_end`: final baton in the N250 chain, producing handoff-ready packages for engineering and N230 regression backfill.


## Cross-skill integration map

| 上游 skill | 提供给 092 | 用途 |
|---|---|---|
| 090 defect-classification | `defect_record` | 缺陷记录提供环境/步骤基础 |
| 091 defect-severity-assessment | `severity_tier` | P0 缺陷优先且要求完整复现包 |

| 下游 skill | 092 输出 | 如何使用 |
|---|---|---|
| 093 quality-gate-check | `reproduction_package` | 门禁验证高危缺陷已有可复现证据 |
| 开发修复 | `reproduction_steps` | 精确复现步骤加速修复定位 |

**工作流位置**: 091 严重度 → **092 复现步骤** → 093 门禁/开发修复。

## Standalone usage guide

**Minimum input:** any symptom — error message, user complaint, or test failure name.

**Standalone reproduction path:**
1. Choose `from_user_report` or `from_failed_tc` mode based on available input.
2. If no environment details → use generic setup steps; set `environment_source: assumed`.
3. Include false-positive check to distinguish this defect from similar-looking issues.

**Minimum viable output:**
```yaml
reproduction_package:
  mode: from_user_report
  readiness: constrained
  environment_source: assumed
  reproduction_confidence: low
  steps:
    - step: 1
      action: Navigate to checkout with item in cart
      expected: Order form displayed
    - step: 2
      action: Submit order with null promo_code field
      expected: HTTP 400 Bad Request
      actual: HTTP 500 NullPointerException
  false_positive_check: Verify NPE appears at OrderService:142 in stack trace
  pending_environment_confirmation: true
```

## Resilience and governance addendum

**Readiness blocking**: Set `readiness: blocked` when R09_non_repro_escalation fires (3 failed attempts) and no alternative strategy is available.

**Confidence scoring**: Include `reproduction_confidence: high/medium/low` in metadata. Low confidence (< 3 successful reproductions or environment-specific only) requires human_review_required: true before handoff to engineering.

**Traceability**: Each reproduction package must reference defect_id, failure_signature from 089, and ODC classification from 090 to enable traceability in the full N250 chain.
## Downstream handoff requirements
`downstream_handoff.to_dev_team` must include `reproduction_id`, `defect_id`, `format_kind`, `commands_or_steps`, `data_setup`, `cleanup`, `success_criteria`, and `debugging_aids`.

`downstream_handoff.to_N230_test` must include `regression_tc_candidate`, `test_case_code_or_outline`, `fixture_needs`, and `reliability_target`.

`downstream_handoff.to_N260_gate` must include `reproduction_verified`, `verification_status`, `reliability_success_rate`, and `non_repro_escalation`.

Emit `signal.n250.defect_to_n005` when repeated non-repro, high-severity, recurring, or process-gap patterns appear.


## Quality bar

A good result produces a reproduction package that another engineer can run without back-and-forth clarification. It must include a minimal step sequence, explicit environment requirements, data setup and cleanup, verification criteria, and a reliability estimate. For P0/P1 defects, debugging aids (logs, trace, breakpoints) are mandatory. The package must be directly handoff-ready to the engineering team and usable as a regression test candidate by N230.


## Example usage

**Input**: P1 defect — "order total shows $0 after applying discount code SAVE20 on mobile Safari 16".

**Output** (`from_user_report` mode, minimal):
```yaml
reproduction_package:
  defect_id: DEF-4821
  mode: from_user_report
  environment_requirements:
    browser: Safari 16+
    platform: iOS 15+
    account: test user with at least one item in cart
  step_by_step:
    - Add any in-stock item to cart
    - Proceed to checkout
    - Enter discount code: SAVE20
    - Observe order total display
  expected: order total reflects 20% discount
  actual: order total shows $0.00
  verification_checklist:
    - Confirm discount applies correctly on Chrome (isolate browser-specific bug)
    - Confirm backend order total is correct despite UI display
  false_positive_check: do NOT mark reproduced if total is simply $0 due to full discount item
  reliability: pending (target 8/10 attempts)
  debugging_aids:
    - Capture Safari console for JS errors during discount application
    - Check network tab for /api/cart/apply-discount response payload
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/reproduction-patterns-guide.md`
- `references/timing-and-concurrency-template.md`
- `references/circuit-breaker-policy.md`
- `references/cross-skill-orchestration.md`
- `references/n250-integration-map.md`
- `references/readiness-inheritance.md`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## v2.2 operational refinements
- Use full YAML examples in `references/real-examples.md` for few-shot guidance.
- Follow schema ratchet and compatibility rules in `references/field-contract.md`.
- Feed self-check and readiness into N250 rollup for N260 using `references/n250-integration-map.md`.
