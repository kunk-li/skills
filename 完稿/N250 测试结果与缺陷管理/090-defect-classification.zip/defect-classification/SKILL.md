---
name: defect-classification
description: classify defects from failure evidence, tickets, production incidents, user reports, or internal discoveries into odc-aligned six-dimensional records with confidence, traceability, consistency checks, human-review routing, and downstream handoff. use for standalone defect registry work or n250 defect-management workflows after attribution and before severity assessment, reproduction, quality gates, metrics, or feedback-loop aggregation.
---
# defect-classification

## Role
Convert failures, incidents, and bug observations into structured defect records. This skill is standalone-capable and is baton 2 in the N250 chain.

## Boundary
- Decide whether one or more failures map to a formal defect, no defect, or review-needed candidate.
- Classify every formal defect using the six-dimensional N250/ODC model.
- Provide only a `technical_severity_hint`; final severity authority belongs to `defect-severity-assessment`.
- Do not perform reproduction packaging or release go/no-go.

## Routing triggers
Use this skill for defect triage tables, ODC classification, defect registry cleanup, failure-to-defect mapping, trend analysis, or preparing defects for severity/reproduction.

## Modes
- `single_defect`: classify one ticket, incident, failure cluster, or user-reported bug.
- `bulk_classify`: classify many failures or tickets into a consistent registry.
- `trend_analysis`: emphasize distributions, recurrence, process gaps, and feedback signals.
- `rca_driven`: classify from root-cause or postmortem material.

## Inputs
Minimum standalone input: one defect description, failure cluster, incident summary, user report, or internal discovery.

Preferred upstream input in N250: `test-failure-attribution` handoff fields from 089.

Preferred raw inputs when 089 is absent:
- test execution results
- logs and symptoms
- bug records
- product taxonomy, module map, ownership map
- compliance, security, data, customer, or recurrence signals

## Output contract
Default to CSV-friendly rows or Markdown tables. Follow `references/output-template.md`.

Required sections:
- `metadata`
- `defect_rows[]`
- `classification_summary`
- `root_cause_distribution[]`
- `additional_tags_summary`
- `auto_classification_confidence`
- `human_review_queue[]`
- `consistency_check`
- `circuit_breaker_evaluation`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `schema_version: n250.classification.v2.2.0`
- `contract_version: n250.defect-management.v2`
- `selected_mode`, `readiness`, `evidence_profile`
- `function_bias: structured_registry`
- `workflow_node: N250` or `standalone`
- `node_artifact_target: defect-classification.csv`
- `produced_events[]`

## Six-dimensional classification authority
Each formal defect row must include:
- D1 `odc_defect_type`: function, interface, checking, assignment, timing, algorithm, documentation, build_package.
- D2 `technical_severity_hint`: blocker, critical, major, minor, trivial, or pending. This is not final severity.
- D3 `functional_area`: product taxonomy value and optional sub_area.
- D4 `phase_detected`: requirements, design, coding, unit_test, integration_test, system_test, acceptance_test, uat, staging, production.
- D5 `phase_introduced`: requirements, design, coding, configuration, data_migration, deployment, third_party_change, unknown.
- D6 `root_cause_category`: from `references/root-cause-taxonomy.md`.

## Rules
- R01_all_6_dimensions: formal defects must include D1-D6; on_violation: reject.
- R02_odc_strict: D1 must use ODC 8-class values; on_violation: reject.
- R03_severity_authority_split: D2 is a hint only and must not override 091; on_violation: reject.
- R04_phase_introduced_plausible: D5 must be supported by evidence or marked pending; on_violation: human_review.
- R05_low_confidence_review: any dimension confidence below 0.7 requires human review; on_violation: human_review.
- R06_compliance_security_always_flagged: compliance, security, data loss, or privacy signals must be explicit additional tags; on_violation: reject.
- R07_regression_traced: regression rows need source version, PR, release, or `pending_regression_source`; on_violation: human_review.
- R08_consistency_checked: cross-dimensional consistency must be evaluated; on_violation: reject.

## Algorithm
1. Consume 089 handoff first when present; otherwise infer from raw observations.
2. Map failures to defects: no defect, one-to-one, many-to-one, one-to-many, or needs review.
3. Classify D1 with ODC symptom mapping from `references/defect-taxonomy-guide.md`.
4. Infer D5 with heuristics from `references/defect-classification-matrix.md`.
5. Assign D6 root cause and additional tags.
6. Calculate per-dimension confidence and route low-confidence dimensions to human review.
7. Run consistency validation and circuit-breaker checks.
8. Emit field-level handoff to 091, 092, N005, N260, and metrics.

## Downstream handoff requirements
`downstream_handoff.to_091_severity` must include:
- `defect_id`, `related_failures[]`, `D1_odc_defect_type`, `technical_severity_hint`
- `customer_facing`, `blast_radius`, `compliance_related`, `security_related`, `data_loss_risk`
- `regression`, `recurrence`, `phase_delta`, `classification_confidence_by_dimension`
- `severity_authority: defect-severity-assessment`

`downstream_handoff.to_092_reproduction` must include `defect_id`, `D1_odc_defect_type`, `functional_area`, `related_failures[]`, `reproduction_strategy_hint`, and `evidence_refs[]`.

Emit `signal.n250.defect_to_n005` for recurring root causes, phase-delta gaps, customer-facing defects, compliance/security/data tags, or high-volume defect clusters.

## Reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/defect-classification-matrix.md`
- `references/defect-taxonomy-guide.md`
- `references/root-cause-taxonomy.md`
- `references/circuit-breaker-policy.md`
- `references/cross-skill-orchestration.md`
- `references/n250-integration-map.md`
- `references/readiness-inheritance.md`
- `references/quality-checklist.md`
- `references/real-examples.md`
## v2.2 operational refinements
- Use full YAML examples in `references/real-examples.md` for few-shot guidance.
- Follow schema ratchet and compatibility rules in `references/field-contract.md`.
- Feed self-check and readiness into N250 rollup for N260 using `references/n250-integration-map.md`.
