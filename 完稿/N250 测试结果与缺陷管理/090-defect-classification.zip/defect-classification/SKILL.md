---
name: defect-classification
description: classify defects from failure evidence, tickets, production incidents, user reports, or internal discoveries into odc-aligned six-dimensional records with confidence, traceability, consistency checks, human-review routing, and downstream handoff. use for standalone defect registry work or n250 defect-management workflows after attribution and before severity assessment, reproduction, quality gates, metrics, or feedback-loop aggregation. trigger on any request to classify a defect, convert a failure into a bug record, apply ODC taxonomy, or structure a defect before severity assessment. [N250]
---
# defect-classification


## Routing decision table

| Situation | Action |
|---|---|
| Attribution result from 089 available | Use as primary evidence; set `attribution_source: 089` |
| No attribution — defect report only | Classify from description; set `attribution_source: direct_observation` |
| ODC type cannot be determined | Set `odc_type: pending_review`; route to human reviewer |
| Test infrastructure issue detected | Use `no_defect_decision` path; do not create product defect record |
| Recurring pattern matches historical ODC | Set `recurrence: true`; link to prior defect cluster |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n250.defect-classification.v2.2"
contract_version: "n250.defect-management.v2.2"
workflow_node: "N250"
```


## Role
Convert failures, incidents, and bug observations into structured defect records. This skill is standalone-capable and is baton 2 in the N250 chain.

## Boundary
- Decide whether one or more failures map to a formal defect, no defect, or review-needed candidate.
- Classify every formal defect using the six-dimensional N250/ODC model.
- Provide only a `technical_severity_hint`; final severity authority belongs to `defect-severity-assessment`.
- Do not perform reproduction packaging or release go/no-go.

## Routing triggers
Use this skill for defect triage tables, ODC classification, defect registry cleanup, failure-to-defect mapping, trend analysis, or preparing defects for severity/reproduction.

## Modes
- `single_defect`: classify one ticket, incident, failure cluster, or user-reported bug.
- `bulk_classify`: classify many failures or tickets into a consistent registry.
- `trend_analysis`: emphasize distributions, recurrence, process gaps, and feedback signals.
- `rca_driven`: classify from root-cause or postmortem material.

## Inputs
Minimum standalone input: one defect description, failure cluster, incident summary, user report, or internal discovery.

Preferred upstream input in N250: `test-failure-attribution` handoff fields from 089.

Preferred raw inputs when 089 is absent:
- test execution results
- logs and symptoms
- bug records
- product taxonomy, module map, ownership map
- compliance, security, data, customer, or recurrence signals


### Degradation rules

- If attribution evidence from 089 is absent, derive classification from direct failure symptom or user report and mark `readiness: constrained` with `pending_attribution_input`.
- If ODC type cannot be determined from available evidence after two classification attempts, mark `odc_type: pending_review` and route to human reviewer.
- Keep the six-dimensional record shape stable even under minimal evidence.

## Output contract
Default to CSV-friendly rows or Markdown tables. Follow `references/output-template.md`.

Required sections:
- `metadata`
- `defect_rows[]`
- `classification_summary`
- `root_cause_distribution[]`
- `additional_tags_summary`
- `auto_classification_confidence`
- `human_review_queue[]`
- `consistency_check`
- `circuit_breaker_evaluation`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `schema_version: n250.classification.v2.2.0`
- `contract_version: n250.defect-management.v2`
- `selected_mode`, `readiness`, `evidence_profile`
- `function_bias: structured_registry`
- `workflow_node: N250` or `standalone`
- `node_artifact_target: defect-classification.csv`
- `produced_events[]`

## Six-dimensional classification authority
Each formal defect row must include:
- D1 `odc_defect_type`: function, interface, checking, assignment, timing, algorithm, documentation, build_package.
- D2 `technical_severity_hint`: blocker, critical, major, minor, trivial, or pending. This is not final severity.
- D3 `functional_area`: product taxonomy value and optional sub_area.
- D4 `phase_detected`: requirements, design, coding, unit_test, integration_test, system_test, acceptance_test, uat, staging, production.
- D5 `phase_introduced`: requirements, design, coding, configuration, data_migration, deployment, third_party_change, unknown.
- D6 `root_cause_category`: from `references/root-cause-taxonomy.md`.

## Auditable rules
- R01_all_6_dimensions: formal defects must include D1-D6; on_violation: reject.
- R02_odc_strict: D1 must use ODC 8-class values; on_violation: reject.
- R03_severity_authority_split: D2 is a hint only and must not override 091; on_violation: reject.
- R04_phase_introduced_plausible: D5 must be supported by evidence or marked pending; on_violation: human_review.
- R05_low_confidence_review: any dimension confidence below 0.7 requires human review; on_violation: human_review.
- R06_compliance_security_always_flagged: compliance, security, data loss, or privacy signals must be explicit additional tags; on_violation: reject.
- R07_regression_traced: regression rows need source version, PR, release, or `pending_regression_source`; on_violation: human_review.
- R08_consistency_checked: cross-dimensional consistency must be evaluated; on_violation: reject.

## Algorithm
1. Consume 089 handoff first when present; otherwise infer from raw observations.
2. Map failures to defects: no defect, one-to-one, many-to-one, one-to-many, or needs review.
3. Classify D1 with ODC symptom mapping from `references/defect-taxonomy-guide.md`.
4. Infer D5 with heuristics from `references/defect-classification-matrix.md`.
5. Assign D6 root cause and additional tags.
6. Calculate per-dimension confidence and route low-confidence dimensions to human review.
7. Run consistency validation and circuit-breaker checks.
8. Emit field-level handoff to 091, 092, N005, N260, and metrics.



## Usage scenarios

- `standard`: classify a formal defect from attribution evidence with full ODC taxonomy.
- `triage_only`: rapid ODC type assignment for high-volume defect intake.
- `no_defect_decision`: determine that a failure is not a product defect (e.g., test code bug or environment issue).
- `recurrence_detection`: identify whether a new defect matches a known defect pattern.
- `n250_chain_middle`: second baton in the N250 chain, consuming 089 and feeding 091 severity assessment.


## Quality bar

- Every classification record must complete all six ODC dimensions (D1-D6).
- `odc_type` must be one of the eight canonical ODC defect types.
- Records with `classification_confidence < 0.7` must set `human_review_required: true`.
- `downstream_handoff.to` must always point to `091-defect-severity-assessment`.


## Cross-skill integration map

| 上游 skill | 提供给 090 | 用途 |
|---|---|---|
| 089 test-failure-attribution | `attribution_result` | 已归因失败转为缺陷分类 |

| 下游 skill | 090 输出 | 如何使用 |
|---|---|---|
| 091 defect-severity-assessment | `odc_type`, `defect_record` | ODC 类型输入严重度评估 |
| 092 defect-reproduction-steps-generation | `defect_record` | 缺陷记录触发复现步骤生成 |
| 093 quality-gate-check | `defect_classification` | 门禁的缺陷类型分布维度 |

**工作流位置**: 089 归因 → **090 缺陷分类** → 091 严重度/092 复现 → 093 门禁。

## Standalone usage guide

**Minimum input:** any defect description, error log, or user report — 089 attribution not required.

**Standalone classification path:**
1. Derive ODC type from defect description; set `attribution_source: direct_observation`.
2. If attribution confidence < 0.7 → set `classification_confidence: low` and `human_review_required: true`.
3. Complete all six ODC dimensions; use `unknown` for unavailable dimensions with a `pending_*` note.

**Minimum viable output:**
```yaml
classification_record:
  readiness: constrained
  attribution_source: direct_observation
  classification_confidence: 0.65
  human_review_required: true
  odc_type: function
  odc_trigger: code_review
  odc_impact: reliability
  odc_age: current_release
  odc_defect_type: missing_logic
  odc_qualifier: missing
  downstream_handoff:
    to: 091-defect-severity-assessment
```

## Resilience and governance addendum

**Readiness blocking**: Set `readiness: blocked` when a formal defect cannot be mapped to any ODC type after three classification attempts; escalate to QA lead.

**SLA guidance**: P0 defects (severity_hint: critical) must be routed to severity assessment within 30 minutes of classification completion. P1 within 4 hours.

**Escalation path**: When classification confidence < 0.6 on a customer-facing or data-integrity defect, escalate to the senior QA engineer for manual review.
## Downstream handoff requirements
`downstream_handoff.to_091_severity` must include:
- `defect_id`, `related_failures[]`, `D1_odc_defect_type`, `technical_severity_hint`
- `customer_facing`, `blast_radius`, `compliance_related`, `security_related`, `data_loss_risk`
- `regression`, `recurrence`, `phase_delta`, `classification_confidence_by_dimension`
- `severity_authority: defect-severity-assessment`

`downstream_handoff.to_092_reproduction` must include `defect_id`, `D1_odc_defect_type`, `functional_area`, `related_failures[]`, `reproduction_strategy_hint`, and `evidence_refs[]`.

Emit `signal.n250.defect_to_n005` for recurring root causes, phase-delta gaps, customer-facing defects, compliance/security/data tags, or high-volume defect clusters.


## Example usage

**Input**: attribution result F-001 — C1 real regression, checkout total returning 0.0.

**Output** (`standard` mode):
```yaml
defect_id: DEF-5021
odc_classification:
  defect_type: Function
  qualifier: Incorrect
  activity_found: System_Test
  target: Code
  age: Base
  source: Developed_Internally
  impact: Reliability
technical_severity_hint: high
functional_area: checkout.pricing
evidence_refs: ["F-001", "ci_log_run_47"]
confidence: 0.88
downstream_handoff:
  to_severity_assessment: true
  to_reproduction: true
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/defect-classification-matrix.md`
- `references/defect-taxonomy-guide.md`
- `references/root-cause-taxonomy.md`
- `references/circuit-breaker-policy.md`
- `references/cross-skill-orchestration.md`
- `references/n250-integration-map.md`
- `references/readiness-inheritance.md`
- `references/quality-checklist.md`
- `references/real-examples.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## v2.2 operational refinements
- Use full YAML examples in `references/real-examples.md` for few-shot guidance.
- Follow schema ratchet and compatibility rules in `references/field-contract.md`.
- Feed self-check and readiness into N250 rollup for N260 using `references/n250-integration-map.md`.
