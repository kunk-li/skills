# N250 示例输入输出 v2（扩展场景）

## 示例 3：缺陷严重度评估（defect-severity-assessment）

### 输入
- ODC类型：function，影响：reliability，blast_radius：中

### 输出
```yaml
severity_assessment:
  severity_tier: P1
  weighted_score: 6.8
  dimensions:
    frequency: 7
    business_impact: 6
    blast_radius: 5
    detectability: 9
  sla: 4小时内修复
  downstream_handoff:
    to: 092-defect-reproduction-steps-generation
```

## 示例 4：缺陷复现步骤生成（defect-reproduction-steps-generation）

### 输入
- 缺陷：OrderService NPE，严重度P1，归因C2

### 输出
```yaml
reproduction_package:
  mode: from_failed_tc
  reproduction_confidence: high
  steps:
    - step: 1
      action: POST /api/orders with null customer_id
      expected: 400 Bad Request
      actual: 500 NullPointerException
  downstream_handoff:
    to: engineering
    artifact: reproduction_package
```

## 090 扩展示例输入输出

### Scenario B — Environmental defect (no product bug)

**Input**: Test fails intermittently due to shared test DB state between parallel runners.

**Output** (`no_defect_decision`):
```yaml
classification_record:
  odc_type: environment
  no_product_defect: true
  resolution: test_isolation_required
  classification_confidence: 0.88
  finding: Failure caused by shared test DB — not a product defect
  recommended_action: Add @Transactional rollback to test setup; isolate DB per runner
  downstream_handoff:
    to: engineering
    type: test_infrastructure_fix
    note: No defect record created
```



### Scenario C — Recurrence detection

**Input**: New defect: `NullPointerException at PaymentService.java:142` — same location as DEF-3210.

**Output** (`recurrence_detection` mode):
```yaml
classification_record:
  mode: recurrence_detection
  odc_type: function
  recurrence: true
  prior_defect_cluster: DEF-3210
  recurrence_pattern: null_guard_missing_at_payment_service
  classification_confidence: 0.91
  finding: >
    Same NPE at PaymentService.java, line within 20 lines of DEF-3210.
    Likely incomplete fix in prior resolution.
  recommended_action: Review DEF-3210 fix scope; add comprehensive null guard for all transaction paths
  downstream_handoff:
    to: 091-defect-severity-assessment
    recurrence_flag: true
```

### Scenario D — Recurrence detection

**Input**: New defect — `NullPointerException at PaymentService.java:142`; same location as DEF-3210.

**Output** (`recurrence_detection` mode):
```yaml
classification_record:
  mode: recurrence_detection
  odc_type: function
  recurrence: true
  prior_defect_cluster: DEF-3210
  recurrence_pattern: null_guard_missing_at_payment_service
  classification_confidence: 0.91
  finding: >
    Same NPE at PaymentService.java, within 20 lines of DEF-3210.
    Likely incomplete fix in prior resolution.
  recommended_action: >
    Review DEF-3210 fix scope; add comprehensive null guard for all
    transaction paths in PaymentService.
  downstream_handoff:
    to: 091-defect-severity-assessment
    recurrence_flag: true
    priority_hint: escalate_severity_by_one_tier
```

### Scenario D — Customer-reported defect (incomplete reproduction info)

**Input**: Customer report: "Payment fails sometimes after 11 PM" — no logs, no repro steps.

**Output** (`triage_mode`, degraded):
```yaml
classification_record:
  mode: triage_degraded
  readiness: constrained
  pending_environment_details: true
  pending_reproduction_steps: true
  preliminary_classification:
    odc_type: function
    suspected_area: payment_gateway
    time_pattern: after_23:00_UTC
    hypothesis: Scheduled job or token expiry at midnight boundary
  required_for_full_classification:
    - Server logs from 22:50–23:10 UTC on failure date
    - User ID + session ID for failed transaction
    - Payment gateway response code
  triage_action: assign_to_payment_team_for_log_collection
  sla_queue_hint: P2_until_repro_confirmed
  downstream_handoff:
    to: 092-defect-reproduction-steps-generation
    signal: pending_log_collection
```
