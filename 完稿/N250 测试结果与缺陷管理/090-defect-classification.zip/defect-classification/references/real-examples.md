# Real examples v2.2

## Example A: timing defect classified from 089 attribution

```yaml
metadata:
  schema_version: n250.classification.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: single_defect
  readiness: ready
  evidence_profile: strong
  workflow_node: N250
  node_artifact_target: defect-classification.csv
  produced_events:
    - produced.n250.classification.v2
    - signal.n250.defect_to_n005

defect_rows:
  - defect_id: DEF-PAY-001
    related_failures: [failure-payment-charge-001]
    mapping_decision: new_defect
    D1_odc_defect_type: assignment
    D2_technical_severity_hint: critical
    D3_functional_area:
      value: payment
      sub_area: charge_authorization
    D4_phase_detected: integration_test
    D5_phase_introduced: coding
    phase_delta: 2
    D6_root_cause_category: coding_error
    additional_tags:
      customer_facing: true
      blast_radius: some_users
      compliance_related: false
      security_related: false
      data_loss_risk: false
      regression:
        is_regression: true
        regression_from_version: v2.7.4
        regression_pr: PR-1234
      recurrence:
        similar_to_past: false
        past_defect_id: null
    auto_classification_confidence:
      D1: 0.86
      D2_hint: 0.80
      D3: 0.95
      D4: 0.92
      D5: 0.88
      D6: 0.84
    human_review:
      required: false
      low_confidence_dimensions: []
      suggested_alternatives: []
    evidence_refs: [E1, E2]

classification_summary:
  formal_defects: 1
  no_defect_items: 0
  needs_review_items: 0

root_cause_distribution:
  - root_cause_category: coding_error
    count: 1

additional_tags_summary:
  customer_facing: 1
  compliance_related: 0
  security_related: 0
  data_loss_risk: 0

consistency_check:
  conflicts_detected: []
  resolutions: []

downstream_handoff:
  to_091_severity:
    defect_id: DEF-PAY-001
    related_failures: [failure-payment-charge-001]
    D1_odc_defect_type: assignment
    technical_severity_hint: critical
    customer_facing: true
    blast_radius: some_users
    compliance_related: false
    security_related: false
    data_loss_risk: false
    regression:
      is_regression: true
      regression_pr: PR-1234
    recurrence:
      similar_to_past: false
    phase_delta: 2
    severity_authority: defect-severity-assessment
  to_092_reproduction:
    defect_id: DEF-PAY-001
    D1_odc_defect_type: assignment
    functional_area: payment.charge_authorization
    related_failures: [failure-payment-charge-001]
    reproduction_strategy_hint: test_case
    evidence_refs: [E1, E2]
  to_N005_feedback:
    signal_kind: regression_process_gap
    phase_delta: 2
  to_N260_gate:
    candidate_gate_signal: release_risk_review

self_check:
  R01_all_6_dimensions: pass
  R02_odc_strict: pass
  R03_severity_authority_split: pass
  R04_phase_introduced_plausible: pass
  R05_low_confidence_review: pass
  R06_compliance_security_always_flagged: pass
  R07_regression_traced: pass
  R08_consistency_checked: pass
```

## Example B: flaky test mapped to no formal defect

```yaml
metadata:
  schema_version: n250.classification.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: single_defect
  readiness: ready
  evidence_profile: mixed
  workflow_node: N250
  produced_events:
    - produced.n250.classification.v2

defect_rows:
  - defect_id: null
    related_failures: [failure-order-concurrency-007]
    mapping_decision: no_defect
    D1_odc_defect_type: null
    D2_technical_severity_hint: pending
    D3_functional_area:
      value: test_automation
      sub_area: concurrency_fixture
    D4_phase_detected: integration_test
    D5_phase_introduced: unknown
    phase_delta: null
    D6_root_cause_category: insufficient_testing
    additional_tags:
      customer_facing: false
      blast_radius: unknown
      compliance_related: false
      security_related: false
      data_loss_risk: false
      regression:
        is_regression: false
      recurrence:
        similar_to_past: true
        past_defect_id: FLAKY-ORDER-042
    auto_classification_confidence:
      D1: 1.0
      D2_hint: 0.0
      D3: 0.8
      D4: 0.8
      D5: 0.4
      D6: 0.7
    human_review:
      required: false
    evidence_refs: [E3]

downstream_handoff:
  to_091_severity:
    severity_authority: defect-severity-assessment
    skip_reason: no_formal_product_defect
  to_N260_gate:
    quarantine_candidate: true
    release_blocker: false

self_check:
  R01_all_6_dimensions: pass
  R02_odc_strict: pass
  R03_severity_authority_split: pass
  R04_phase_introduced_plausible: pass
  R05_low_confidence_review: pass
  R06_compliance_security_always_flagged: pass
  R07_regression_traced: pass
  R08_consistency_checked: pass
```
