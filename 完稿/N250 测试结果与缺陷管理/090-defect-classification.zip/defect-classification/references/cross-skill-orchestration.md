# Cross-skill orchestration for 090 v2.2

This skill is baton 2 of 4 in N250.

## Consume from 089
- `failure_id`
- `failure_signature`
- `primary_category`
- `category_confidence`
- `candidate_defect_group_id`
- `shared_defect_candidate_signal`
- `classification_hint`
- `evidence_refs[]`

## Produce for 091
- `defect_id`
- `related_failures[]`
- `D1_odc_defect_type`
- `technical_severity_hint`
- `D3_functional_area`
- `D4_phase_detected`
- `D5_phase_introduced`
- `D6_root_cause_category`
- `additional_tags`
- `classification_confidence_by_dimension`
- `severity_authority: defect-severity-assessment`

## Produce for 092
- `defect_id`
- `D1_odc_defect_type`
- `functional_area`
- `related_failures[]`
- `reproduction_strategy_hint`
- `evidence_refs[]`

## Behavior change when combined
When 089 exists, do not re-attribute failures except to resolve field conflicts. When 091 exists, do not finalize severity. When 092 exists, set reproduction strategy based on D1 and tags.
