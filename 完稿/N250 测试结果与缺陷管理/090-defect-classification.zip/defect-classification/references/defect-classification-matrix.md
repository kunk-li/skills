# Six-dimensional classification matrix v2.2

Required dimensions:
- D1 `odc_defect_type`: ODC 8-class type.
- D2 `technical_severity_hint`: blocker, critical, major, minor, trivial, or pending. This is only an input to 091.
- D3 `functional_area`: taxonomy domain/module/user journey and optional sub_area.
- D4 `phase_detected`: where the defect was found.
- D5 `phase_introduced`: where the defect likely entered.
- D6 `root_cause_category`: process or technical root category.

## Phase introduced heuristics
- Recent code change in failing module -> coding.
- Recent config, flag, credential, or env change -> configuration.
- Recent migration or data backfill -> data_migration.
- Recent third-party/vendor/API upgrade -> third_party_change.
- No recent change plus design mismatch -> design or requirements.
- Release packaging, image, or dependency mismatch -> deployment or build_package evidence.

## Phase delta
`phase_delta = detected_index - introduced_index` using the lifecycle order. Interpret:
- 0: found immediately.
- 1-2: acceptable detection lag.
- 3 or more: process gap and feedback candidate for N005/N260.

## Consistency checks
- customer_facing all_users plus blocker-like symptom should not have trivial hint.
- compliance_related or security_related should be at least major hint unless evidence proves no exposure.
- data_loss_risk should be at least critical hint when data is unrecoverable or audit trail is affected.
- production detected with coding introduced and regression true should emit a process-improvement signal.
