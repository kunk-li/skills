# Defect classification circuit breaker v2.2

## Classification-specific triggers
- More than 30% of batch rows have low-confidence D1 or D6 -> open `classification_quality` circuit and require human review.
- Any compliance/security/data-loss tag with missing owner -> open `governance` circuit.
- More than 5 critical/blocker hints in one release slice -> open `release_risk` circuit and notify N260.
- Phase delta of 3 or more across repeated defects in same area -> open `process_gap` circuit and emit N005 signal.

## Actions
- Pause automatic severity propagation for rows with low-confidence mandatory dimensions.
- Route to human queue with field-level missing dimensions.
- Notify QA lead and product/engineering owner for governance or release-risk circuits.

## State machine
Use closed, open, half_open. Recovery requires corrected classifications plus one clean validation pass for affected rows.
