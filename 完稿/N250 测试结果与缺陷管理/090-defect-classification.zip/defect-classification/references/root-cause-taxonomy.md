# Root cause taxonomy v2.2

Use one primary D6 value and optional secondary values:
- `missing_requirement`
- `ambiguous_requirement`
- `design_flaw`
- `coding_error`
- `insufficient_testing`
- `environment_issue`
- `data_issue`
- `third_party`
- `integration_issue`
- `performance_limitation`
- `security_oversight`
- `concurrency_issue`
- `configuration_error`
- `human_error`
- `unknown_pending_review`

Prefer `unknown_pending_review` over unsupported certainty. Preserve evidence and suggested alternatives for human review.
