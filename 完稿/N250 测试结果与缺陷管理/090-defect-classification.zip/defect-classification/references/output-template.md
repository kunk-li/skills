# Output template v2.2: defect classification

```yaml
metadata:
  schema_version: n250.classification.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: single_defect|bulk_classify|trend_analysis|rca_driven
  readiness: ready|partial|blocked
  evidence_profile: strong|mixed|sparse|contradictory
  workflow_node: N250|standalone
  node_artifact_target: defect-classification.csv
  produced_events:
    - produced.n250.classification.v2
    - signal.n250.defect_to_n005

defect_rows:
  - defect_id:
    related_failures: []
    mapping_decision: no_defect|new_defect|existing_defect|needs_review
    D1_odc_defect_type: function|interface|checking|assignment|timing|algorithm|documentation|build_package
    D2_technical_severity_hint: blocker|critical|major|minor|trivial|pending
    D3_functional_area:
      value:
      sub_area:
    D4_phase_detected:
    D5_phase_introduced:
    phase_delta:
    D6_root_cause_category:
    additional_tags:
      customer_facing: false
      blast_radius: single_user|some_users|all_users|unknown
      compliance_related: false
      security_related: false
      data_loss_risk: false
      regression:
        is_regression: false
        regression_from_version:
        regression_pr:
      recurrence:
        similar_to_past: false
        past_defect_id:
    auto_classification_confidence:
      D1: 0.0
      D2_hint: 0.0
      D3: 0.0
      D4: 0.0
      D5: 0.0
      D6: 0.0
    human_review:
      required: false
      low_confidence_dimensions: []
      suggested_alternatives: []
    evidence_refs: []

consistency_check:
  conflicts_detected: []
  resolutions: []

downstream_handoff:
  to_091_severity: {}
  to_092_reproduction: {}
  to_N005_feedback: {}
  to_N260_gate: {}

self_check: {}
```
