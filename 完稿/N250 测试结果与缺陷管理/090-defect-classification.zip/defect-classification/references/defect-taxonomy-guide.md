# ODC defect taxonomy guide v2.2

Use these D1 `odc_defect_type` values only:
- `function`: missing or wrong function, missing capability, incorrect behavior.
- `interface`: API, contract, parameter, integration, or interaction mismatch.
- `checking`: validation, guard, boundary, permission, or error handling gap.
- `assignment`: initialization, null, off-by-one, wrong value, state mutation, or mapping error.
- `timing`: order, concurrency, race, timeout, async, idempotency, or transaction timing issue.
- `algorithm`: wrong logic, calculation, ranking, matching, transformation, or decision rule.
- `documentation`: requirement, help text, runbook, or user-facing documentation mismatch.
- `build_package`: build, dependency, packaging, deployment artifact, or release bundle issue.

## Symptom mapping hints
- timeout, race, duplicate write, non-idempotent concurrent request -> timing.
- null pointer, wrong default, wrong field value -> assignment.
- wrong price, wrong route, wrong matching result -> algorithm.
- invalid input accepted or valid input rejected -> checking.
- API schema mismatch or incompatible contract -> interface.
- missing feature or wrong functional outcome -> function.
- package missing file, wrong image, dependency mismatch -> build_package.
- docs or spec contradiction -> documentation.
