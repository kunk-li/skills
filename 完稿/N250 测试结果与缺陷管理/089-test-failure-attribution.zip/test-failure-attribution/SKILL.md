---
name: test-failure-attribution
description: attribute test, ci, automation, and defect failures to likely cause categories with evidence, confidence scoring, replay guidance, circuit-breaker signals, and downstream handoff. use for any failed test run, flaky suspicion, ci pipeline failure, environment or dependency failure, production-like defect signal, or n250 defect-management workflow before classification, severity assessment, reproduction, gate, or feedback-loop decisions. trigger on any request to attribute a test failure, triage a CI failure, investigate flaky tests, or categorize a failed run before classification. [N250]
---
# test-failure-attribution


## Attribution routing decision table

| Situation | Action |
|---|---|
| Clean single failure with stack trace | Use quick_triage; classify C1–C6 from trace |
| Flaky test (inconsistent failures) | Use flaky_investigation; check for race conditions, shared state |
| Failure cluster across multiple tests | Use deep_analysis; run pattern registry against historical data |
| Infrastructure health degraded | Classify as C3; set circuit_breaker check for environment |
| Confidence < 0.7 on any C1 attribution | Set human_review_required: true; do not auto-block merge |
| Audit / static / code-review finding (no failing test, no stack trace) | Use `audit_intake`; skip `failure_signature`, mark `intake_source: direct_observation`, hand to 090 |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n250.test-failure-attribution.v2.2"
contract_version: "n250.defect-management.v2.2"
workflow_node: "N250"
```


## Role
Attribute observed failures without assuming every failure is a product defect. The skill must be useful standalone and also act as the first baton in the N250 chain.

## Boundary
- Diagnose likely cause, confidence, evidence, replay need, and next owner.
- Model one failure to one defect, many failures to one defect, no-defect, and unknown mappings.
- Do not assign final severity or release go/no-go.
- Do not invent root causes; use `pending_*` fields when evidence is missing.
- The attribution model (`failure_signature` + replay + signature-based confidence) is built for **test / CI failures**. An audit / static / code-review finding has no signature → use `audit_intake` (mark `intake_source: direct_observation`, do not fabricate a signature); 090 is its correct classification entry.

## Routing triggers
Use this skill when the user provides failed tests, CI logs, test execution output, flaky suspicion, regression failure, dependency or infrastructure symptoms, or a defect signal that needs attribution before classification.

## Modes
Declare one mode in `metadata.selected_mode`:
- `quick_triage`: one failed run, one failure cluster, or urgent first-pass triage.
- `deep_analysis`: full evidence collection, clustering, replay strategy, confidence scoring, and escalation.
- `pattern_registry`: update or apply historical failure signatures and recurring patterns.
- `audit_intake`: spec↔code audit / static-analysis / code-review finding with **no failing test and no stack trace**. Skip `failure_signature` (undefined here); set `intake_source: direct_observation`; give a cause hint from spec-drift / missing-logic / dead-code classes; hand straight to 090 (which supports a direct-observation entry). Do **not** fabricate a signature, replay, or signature-based confidence.

## Inputs
Minimum standalone input: one failure symptom, failed testcase, CI run, log excerpt, defect observation, or user-reported failure.

Preferred N250 raw inputs:
- test execution results
- automation trigger recommendation
- log excerpt
- bug symptom record

Preferred enhancement inputs:
- historical failure clusters
- infrastructure health and dependency status
- recent code, config, deployment, feature-flag, or data changes
- trace, metric, screenshot, or pipeline links


### Input tiers

**Required (minimum standalone input):**
- One failure symptom, failed testcase, CI run, log excerpt, or defect observation.

**Optional enhancement inputs:**
- Historical failure clusters, infrastructure health, recent code/config changes, trace or metric links.

### Degradation rules

- If only a raw log excerpt is available without testcase context, produce a hypothesis-level attribution marked `readiness: constrained` and flag `pending_testcase_context`.
- If environment health data is absent, treat infrastructure failure (C3) as a hypothesis and mark `pending_environment_confirmation`.
- Keep the output schema stable even under minimal evidence; use `pending_*` fields rather than fabricating root causes.
- For an audit / static finding (no failing test, no stack trace): use `audit_intake`; replace signature-based `confidence` with **evidence directness** (operator-verified `file:line` = high), skip replay, set `intake_source: direct_observation`. The defect identity is the `defect_locus` (`file:line` + defect type), not a normalized stack trace.

## Output contract
Default to Markdown with stable table sections. Follow `references/output-template.md`.

Required top-level sections:
- `metadata`
- `failure_scope_summary`
- `attribution_rows[]`
- `failure_clusters[]`
- `evidence_bundle[]`
- `confidence_scoring`
- `replay_sampling`
- `circuit_breaker`
- `root_cause_hypotheses[]`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `schema_version: n250.attribution.v2.2.0`
- `contract_version: n250.defect-management.v2`
- `selected_mode`, `readiness`, `evidence_profile`
- `function_bias: diagnostic_attribution`
- `workflow_node: N250` or `standalone`
- `node_artifact_target: test-failure-attribution.md`
- `produced_events[]`

## Auditable rules
Use these rules as auditable checks:
- R01_category_required: every failure row must have exactly one C1-C6 category; on_violation: reject.
- R02_evidence_required: every attribution must cite evidence_refs; on_violation: reject.
- R03_confidence_scored: every category decision must include confidence 0-1 and factors; on_violation: reject.
- R04_low_confidence_escalated: confidence below 0.5 requires human review; on_violation: human_review.
- R05_replay_for_ambiguous: confidence 0.3-0.7 or flaky/infra/dependency ambiguity requires replay_sampling; on_violation: reject.
- R06_real_regression_blocks_merge: C1 with confidence above 0.8 sets `block_merge: true`; on_violation: auto_enforce.
- R07_flaky_quarantine_after_3: C2 with 3 consecutive flaky outcomes sets `quarantine_candidate: true`; on_violation: auto_enforce.
- R08_circuit_state_required: circuit status must be closed, open, or half_open; on_violation: reject.

## Category authority
Use the v2 canonical six categories from `references/failure-category-taxonomy.md`: C1 real regression, C2 flaky test, C3 infrastructure failure, C4 external dependency failure, C5 environment configuration, C6 test code bug. Legacy F01-F10 labels may appear only in `legacy_mapping`.

## Algorithm
1. Generate `failure_signature` from normalized stack trace, error message, testcase, and symptom.
2. Compare signature with historical failures and similar clusters.
3. Apply category decision tree from `references/auto-attribution-pipeline.md`.
4. Calculate confidence as `0.30 * signature_match + 0.30 * historical_match + 0.20 * environment_indicators + 0.20 * code_change_proximity`.
5. Trigger replay sampling when confidence is ambiguous, category is C2/C3/C4, or no prior conclusive replay exists.
6. Evaluate circuit breaker status from `references/circuit-breaker-policy.md`.
7. Emit handoff fields for classification, severity, reproduction, N005, and N260.



## Usage scenarios

- `quick_triage`: one failed run or one failure cluster — fast first-pass attribution.
- `deep_analysis`: full evidence collection, clustering, replay strategy, and confidence scoring.
- `pattern_registry`: apply historical failure signatures to identify recurring patterns.
- `flaky_investigation`: focused mode for tests with inconsistent pass/fail history.
- `n250_chain_start`: first baton in the N250 defect management chain, feeding 090 classification.



## Cross-skill integration map

| 上游 skill | 提供给 089 | 用途 |
|---|---|---|
| 088 test-automation-orchestration | `failed_test_ids[]`, `execution_log` | 失败用例列表触发归因 |

| 下游 skill | 089 输出 | 如何使用 |
|---|---|---|
| 090 defect-classification | `attribution_result` | 已归因失败转为缺陷分类 |
| 091 defect-severity-assessment | `attribution_confidence` | 归因置信度影响严重度评估 |
| 093 quality-gate-check | `attribution_summary` | 门禁的失败归因维度 |

**工作流位置**: 088 编排失败 → **089 失败归因** → 090 分类/091 严重度 → 093 门禁。

## Standalone usage guide

**Minimum input:** any failure signal — a test name, error message, log line, or incident description.

**Standalone triage path:**
1. Classify into C1–C6 from available evidence; mark `evidence_source` for each item.
2. If confidence < 0.7 → set `hypothesis_level: true` and `human_review_required: true`.
3. Always produce a `downstream_handoff` to 090 even under low confidence.

**Minimum viable output:**
```yaml
attribution_result:
  readiness: constrained
  confidence: 0.55
  pending_testcase_context: true
  human_review_required: true
  primary_category: C1_real_regression
  evidence:
    - type: log_excerpt
      content: "NullPointerException at OrderService.java:142"
  attribution_summary: NPE at OrderService line 142 — null guard missing
  downstream_handoff:
    to: 090-defect-classification
    category: C1_real_regression
```

## Quality bar

- Every attribution result must include `confidence` (0–1) and `primary_category`.
- Results with `confidence < 0.7` must set `human_review_required: true`.
- Standalone-input results must include `pending_testcase_context: true` when no testcase is available.
- `downstream_handoff.to` must always point to `090-defect-classification`.

## Resilience and governance addendum

**Readiness blocking**: Set `readiness: blocked` when any C1 real-regression attribution reaches confidence ≥ 0.8 and block_merge is not yet acknowledged by a reviewer.

**Traceability**: Every attribution row must carry `failure_signature` and `evidence_refs[]` enabling downstream traceability in 090 classification, 091 severity, and N260 gate.
## Downstream handoff requirements
`downstream_handoff.to_090_defect_classification` must include:
- `failure_id`, `failure_signature`, `primary_category`, `category_confidence`
- `shared_defect_candidate_signal`: none, possible, likely, confirmed
- `candidate_defect_group_id`
- `evidence_refs[]`
- `classification_hint`: no_defect, formal_defect, needs_review
- `pending_attribution_confirmation`

`downstream_handoff.to_091_severity` should include `real_regression_signal`, `customer_or_data_risk_signal`, `block_merge`, and `sla_queue_priority` when severity is needed before classification.

`downstream_handoff.to_092_reproduction` should include `failure_signature`, `stable_failure`, `replay_required`, `environment_constraints[]`, and `logs_to_capture[]`.

Emit `signal.n250.defect_to_n005` when repeated, high-severity, customer-facing, recurrent, or process-gap signals are found.


## Example usage

### Scenario A — Single CI failure triage (quick triage)

**Input**: `payment_gateway_test.py::test_retry_on_timeout` failed in CI run #4821; no prior context.

**Output** (`quick_triage` mode):
```yaml
attribution_result:
  failure_id: FAIL-4821-001
  mode: quick_triage
  readiness: ready
  confidence: 0.78
  primary_category: C1_real_regression
  evidence:
    - type: log_excerpt
      content: "ConnectionTimeout after 5000ms; retry count 3 exceeded"
    - type: recent_commit
      content: "feat: reduce timeout from 8000ms to 5000ms (commit a3f92c)"
  attribution_summary: >
    Timeout reduction commit (a3f92c) directly caused the retry count to
    exceed threshold. Attributed to product code change, not environment.
  next_step: route_to_090_defect_classification
  downstream_handoff:
    to: 090-defect-classification
    signal: attribution_result
    category: C1_real_regression
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/failure-category-taxonomy.md`
- `references/auto-attribution-pipeline.md`
- `references/circuit-breaker-policy.md`
- `references/cross-skill-orchestration.md`
- `references/n250-integration-map.md`
- `references/readiness-inheritance.md`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## v2.2 operational refinements
- Use full YAML examples in `references/real-examples.md` for few-shot guidance.
- Follow schema ratchet and compatibility rules in `references/field-contract.md`.
- Feed self-check and readiness into N250 rollup for N260 using `references/n250-integration-map.md`.
