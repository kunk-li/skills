---
name: test-failure-attribution
description: attribute test, ci, automation, and defect failures to likely cause categories with evidence, confidence scoring, replay guidance, circuit-breaker signals, and downstream handoff. use for any failed test run, flaky suspicion, ci pipeline failure, environment or dependency failure, production-like defect signal, or n250 defect-management workflow before classification, severity assessment, reproduction, gate, or feedback-loop decisions.
---
# test-failure-attribution

## Role
Attribute observed failures without assuming every failure is a product defect. The skill must be useful standalone and also act as the first baton in the N250 chain.

## Boundary
- Diagnose likely cause, confidence, evidence, replay need, and next owner.
- Model one failure to one defect, many failures to one defect, no-defect, and unknown mappings.
- Do not assign final severity or release go/no-go.
- Do not invent root causes; use `pending_*` fields when evidence is missing.

## Routing triggers
Use this skill when the user provides failed tests, CI logs, test execution output, flaky suspicion, regression failure, dependency or infrastructure symptoms, or a defect signal that needs attribution before classification.

## Modes
Declare one mode in `metadata.selected_mode`:
- `quick_triage`: one failed run, one failure cluster, or urgent first-pass triage.
- `deep_analysis`: full evidence collection, clustering, replay strategy, confidence scoring, and escalation.
- `pattern_registry`: update or apply historical failure signatures and recurring patterns.

## Inputs
Minimum standalone input: one failure symptom, failed testcase, CI run, log excerpt, defect observation, or user-reported failure.

Preferred N250 raw inputs:
- test execution results
- automation trigger recommendation
- log excerpt
- bug symptom record

Preferred enhancement inputs:
- historical failure clusters
- infrastructure health and dependency status
- recent code, config, deployment, feature-flag, or data changes
- trace, metric, screenshot, or pipeline links

## Output contract
Default to Markdown with stable table sections. Follow `references/output-template.md`.

Required top-level sections:
- `metadata`
- `failure_scope_summary`
- `attribution_rows[]`
- `failure_clusters[]`
- `evidence_bundle[]`
- `confidence_scoring`
- `replay_sampling`
- `circuit_breaker`
- `root_cause_hypotheses[]`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `schema_version: n250.attribution.v2.2.0`
- `contract_version: n250.defect-management.v2`
- `selected_mode`, `readiness`, `evidence_profile`
- `function_bias: diagnostic_attribution`
- `workflow_node: N250` or `standalone`
- `node_artifact_target: test-failure-attribution.md`
- `produced_events[]`

## Rules
Use these rules as auditable checks:
- R01_category_required: every failure row must have exactly one C1-C6 category; on_violation: reject.
- R02_evidence_required: every attribution must cite evidence_refs; on_violation: reject.
- R03_confidence_scored: every category decision must include confidence 0-1 and factors; on_violation: reject.
- R04_low_confidence_escalated: confidence below 0.5 requires human review; on_violation: human_review.
- R05_replay_for_ambiguous: confidence 0.3-0.7 or flaky/infra/dependency ambiguity requires replay_sampling; on_violation: reject.
- R06_real_regression_blocks_merge: C1 with confidence above 0.8 sets `block_merge: true`; on_violation: auto_enforce.
- R07_flaky_quarantine_after_3: C2 with 3 consecutive flaky outcomes sets `quarantine_candidate: true`; on_violation: auto_enforce.
- R08_circuit_state_required: circuit status must be closed, open, or half_open; on_violation: reject.

## Category authority
Use the v2 canonical six categories from `references/failure-category-taxonomy.md`: C1 real regression, C2 flaky test, C3 infrastructure failure, C4 external dependency failure, C5 environment configuration, C6 test code bug. Legacy F01-F10 labels may appear only in `legacy_mapping`.

## Algorithm
1. Generate `failure_signature` from normalized stack trace, error message, testcase, and symptom.
2. Compare signature with historical failures and similar clusters.
3. Apply category decision tree from `references/auto-attribution-pipeline.md`.
4. Calculate confidence as `0.30 * signature_match + 0.30 * historical_match + 0.20 * environment_indicators + 0.20 * code_change_proximity`.
5. Trigger replay sampling when confidence is ambiguous, category is C2/C3/C4, or no prior conclusive replay exists.
6. Evaluate circuit breaker status from `references/circuit-breaker-policy.md`.
7. Emit handoff fields for classification, severity, reproduction, N005, and N260.

## Downstream handoff requirements
`downstream_handoff.to_090_defect_classification` must include:
- `failure_id`, `failure_signature`, `primary_category`, `category_confidence`
- `shared_defect_candidate_signal`: none, possible, likely, confirmed
- `candidate_defect_group_id`
- `evidence_refs[]`
- `classification_hint`: no_defect, formal_defect, needs_review
- `pending_attribution_confirmation`

`downstream_handoff.to_091_severity` should include `real_regression_signal`, `customer_or_data_risk_signal`, `block_merge`, and `sla_queue_priority` when severity is needed before classification.

`downstream_handoff.to_092_reproduction` should include `failure_signature`, `stable_failure`, `replay_required`, `environment_constraints[]`, and `logs_to_capture[]`.

Emit `signal.n250.defect_to_n005` when repeated, high-severity, customer-facing, recurrent, or process-gap signals are found.

## Reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/failure-category-taxonomy.md`
- `references/auto-attribution-pipeline.md`
- `references/circuit-breaker-policy.md`
- `references/cross-skill-orchestration.md`
- `references/n250-integration-map.md`
- `references/readiness-inheritance.md`
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
## v2.2 operational refinements
- Use full YAML examples in `references/real-examples.md` for few-shot guidance.
- Follow schema ratchet and compatibility rules in `references/field-contract.md`.
- Feed self-check and readiness into N250 rollup for N260 using `references/n250-integration-map.md`.
