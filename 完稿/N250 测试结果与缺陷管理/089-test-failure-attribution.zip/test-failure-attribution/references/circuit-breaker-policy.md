# Test attribution circuit breaker v2.2

## Levels
- `test_level`: 3 consecutive C2 flaky outcomes for the same `tc_id` -> open circuit, quarantine candidate, create ticket, notify test owner.
- `suite_level`: suite pass rate below 50% or more than 30% of failures share no stable signature -> open circuit, pause suite, notify QA lead.
- `pipeline_level`: 5 consecutive pipeline failures or C1 high-confidence regression blocks main -> open circuit, pause deploy, notify on-call and release owner.
- `infrastructure_level`: multiple suites fail while infra metrics are abnormal -> open circuit, pause affected CI lane, notify devops.

## State machine
`closed -> open` when threshold is reached.
`open -> half_open` after cooldown plus one successful validation run.
`half_open -> closed` after next successful validation run.
`half_open -> open` after next failure.

## Defaults
- cooldown: 30 minutes for test/suite, 60 minutes for pipeline/infrastructure.
- max_iter: 3 repeated rerun or repair loops before escalation.
- escalation: test owner, QA lead, on-call engineer, devops, release owner depending on circuit level.

## Output fields
Always emit `circuit_breaker.state`, `level`, `trigger`, `threshold`, `cooldown`, `auto_actions[]`, `manual_owner`, and `recovery_condition`.
