# Cross-skill orchestration for 089 v2.2

This skill is baton 1 of 4 in N250.

## Consume
- Raw N250 inputs: test results, automation triggers, logs, bug observations.
- Optional context: history, infra/dependency health, recent changes, traces, metrics.

## Produce for 090
`to_090_defect_classification`:
- `failure_id`
- `failure_signature`
- `primary_category`
- `category_confidence`
- `candidate_defect_group_id`
- `shared_defect_candidate_signal`
- `classification_hint`
- `evidence_refs[]`
- `pending_attribution_confirmation`

## Produce for 091
Use only when urgent severity triage is needed before 090 completes:
- `real_regression_signal`
- `block_merge`
- `customer_or_data_risk_signal`
- `sla_queue_priority`

## Produce for 092
- `failure_signature`
- `stable_failure`
- `replay_required`
- `replay_results`
- `environment_constraints[]`
- `logs_to_capture[]`

## Behavior change when combined
When 090 is available, do not create defect taxonomy yourself. When 091 is available, do not finalize severity. When 092 is available, provide replay and environment cues rather than prose-only next steps.
