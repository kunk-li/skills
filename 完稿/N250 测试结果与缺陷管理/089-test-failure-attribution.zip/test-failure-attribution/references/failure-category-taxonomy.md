# Failure category taxonomy v2.2

Use one primary `failure_category` per failed observation.

## Canonical categories
- `C1_real_regression`: product behavior regressed because recent code, data, config, or integration change touched the failing area. Action: block merge or release when confidence is high.
- `C2_flaky_test`: test is nondeterministic or timing/order/resource sensitive. Action: replay, quarantine after threshold, and fix test or isolation.
- `C3_infrastructure_failure`: CI runner, container, network, storage, resource, or platform instability caused the failure. Action: retry, notify devops, and pause affected suite when widespread.
- `C4_external_dependency_failure`: vendor, third-party API, sandbox, rate limit, or dependent service outage caused the failure. Action: wait, mock, or degrade.
- `C5_environment_configuration`: wrong env var, stale schema, feature flag, credentials, seed data, region, or config drift. Action: fix environment/config and rerun.
- `C6_test_code_bug`: assertion, fixture, test data, deprecated API, or test harness bug. Action: fix test, not product, unless evidence proves product regression.

## Legacy mapping
Legacy labels may be preserved in `legacy_failure_category` but not used as the primary category:
- F01 code_bug -> C1_real_regression
- F02 test_bug -> C6_test_code_bug
- F03 data_dependency -> C5_environment_configuration or C4_external_dependency_failure
- F04 env_issue -> C3_infrastructure_failure or C5_environment_configuration
- F05 external_dependency_down -> C4_external_dependency_failure
- F06 timing_issue -> C2_flaky_test or C1_real_regression depending on stability
- F07 resource_exhaustion -> C3_infrastructure_failure
- F08 flaky_race_condition -> C2_flaky_test
- F09 config_drift -> C5_environment_configuration
- F10 known_limitation -> C6_test_code_bug or no formal defect
