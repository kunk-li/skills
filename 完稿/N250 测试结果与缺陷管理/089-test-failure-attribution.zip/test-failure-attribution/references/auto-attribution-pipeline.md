# Auto attribution pipeline v2.2

## Failure signature generation
Inputs: stack trace, error message, testcase name, suite, failing assertion, environment, and symptom. Normalize volatile tokens such as timestamps, ids, ports, temp paths, and randomized data before hashing.

## Decision tree
1. If infrastructure alerts or runner failures are present, suggest `C3_infrastructure_failure`.
2. Else if dependency health is down, rate-limited, or timed out across unrelated tests, suggest `C4_external_dependency_failure`.
3. Else if missing env vars, stale schema, wrong feature flag, credentials, or seed-data mismatch are present, suggest `C5_environment_configuration`.
4. Else if history shows intermittent pass/fail with similar signature or replay is mixed, suggest `C2_flaky_test`.
5. Else if recent code/config/data changes touch the failing module and replay consistently fails, suggest `C1_real_regression`.
6. Else if assertion logic, fixture, deprecated API, or invalid test data is the strongest signal, suggest `C6_test_code_bug`.
7. Otherwise mark `needs_investigation` with low confidence and human review.

## Confidence formula
`confidence = 0.30 * signature_match + 0.30 * historical_match + 0.20 * environment_indicators + 0.20 * code_change_proximity`

Factor scoring guidance:
- 0.9-1.0: direct conclusive evidence.
- 0.7-0.8: strong but not exclusive evidence.
- 0.4-0.6: plausible partial evidence.
- 0.0-0.3: weak, absent, or contradictory evidence.

## Replay sampling
Replay when:
- confidence is between 0.3 and 0.7;
- category is C2, C3, or C4 and evidence is not conclusive;
- recent failures lack prior conclusive replay;
- release or merge would otherwise be blocked.

Default replay: 3 runs in a clean isolated environment, capped at 2x original suite duration unless explicitly overridden.

Replay interpretation:
- all pass -> C2 flaky confirmed or environment recovered.
- all fail with same signature -> C1 real regression or C6 test code bug, choose by code/test evidence.
- mixed -> C2 flaky, investigate isolation and timing.
- different failures -> cluster separately and avoid forced single-root conclusion.
