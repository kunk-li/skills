# N250 示例输入输出 v2（扩展场景）

## 示例 3：缺陷严重度评估（defect-severity-assessment）

### 输入
- ODC类型：function，影响：reliability，blast_radius：中

### 输出
```yaml
severity_assessment:
  severity_tier: P1
  weighted_score: 6.8
  dimensions:
    frequency: 7
    business_impact: 6
    blast_radius: 5
    detectability: 9
  sla: 4小时内修复
  downstream_handoff:
    to: 092-defect-reproduction-steps-generation
```

## 示例 4：缺陷复现步骤生成（defect-reproduction-steps-generation）

### 输入
- 缺陷：OrderService NPE，严重度P1，归因C2

### 输出
```yaml
reproduction_package:
  mode: from_failed_tc
  reproduction_confidence: high
  steps:
    - step: 1
      action: POST /api/orders with null customer_id
      expected: 400 Bad Request
      actual: 500 NullPointerException
  downstream_handoff:
    to: engineering
    artifact: reproduction_package
```

## 089 扩展示例输入输出

### Scenario B — Flaky test deep analysis (pattern registry)

**Input**: `user_session_test.py::test_concurrent_login` flaked 4/10 runs over past week; no deterministic failure.

**Output** (`deep_analysis` mode):
```yaml
attribution_result:
  failure_id: FAIL-FLAKY-0178
  mode: deep_analysis
  readiness: constrained
  confidence: 0.61
  primary_category: C3_environment_infrastructure
  hypothesis_level: true
  evidence:
    - type: failure_cluster
      pattern: "fails under concurrent load > 50 req/s"
    - type: infrastructure
      content: "DB connection pool exhausted in 2/4 failures"
  attribution_summary: >
    Pattern suggests race condition in DB pool under concurrent load.
    Cannot confirm without targeted isolation test.
    Confidence below 0.7 — human_review_required.
  human_review_required: true
  pending_isolation_test: true
  downstream_handoff:
    to: 090-defect-classification
    category: C3_environment_infrastructure
    note: pending_confirmation_before_formal_defect
```

### Scenario C — Standalone from log excerpt (no testcase)

**Input**: Production error log excerpt only; no testcase or CI context.

**Output** (`quick_triage` mode, degraded):
```yaml
attribution_result:
  failure_id: FAIL-PROD-LOG-001
  mode: quick_triage
  readiness: constrained
  confidence: 0.55
  pending_testcase_context: true
  primary_category: C2_product_code_bug
  evidence:
    - type: log_excerpt
      content: "NullPointerException at OrderService.java:142"
  attribution_summary: >
    NPE at OrderService line 142. Attributed to product code — likely
    null guard missing. Low confidence (no testcase); human review required.
  human_review_required: true
  downstream_handoff:
    to: 090-defect-classification
    category: C2_product_code_bug
```


### Scenario D — Flaky test investigation (pattern registry mode)

**Input**: `user_session_test.py::test_concurrent_login` failed 4/10 CI runs over 7 days; no error is consistent.

**Output** (`flaky_investigation` mode):
```yaml
attribution_result:
  failure_id: FAIL-FLAKY-0178
  mode: flaky_investigation
  readiness: constrained
  confidence: 0.58
  primary_category: C3_environment_infrastructure
  hypothesis_level: true
  flaky_pattern:
    historical_runs: 10
    failure_count: 4
    failure_rate: 40%
    pattern: failures cluster at >50 concurrent requests
  evidence:
    - type: failure_cluster
      content: "DB connection pool exhausted in 3/4 failure runs"
    - type: infrastructure
      content: "test runner shared DB pool (max 10 connections)"
  attribution_summary: >
    Pattern strongly suggests DB connection pool exhaustion under concurrent
    load. Cannot deterministically reproduce — isolation test recommended.
    Confidence 0.58 (below threshold) — human review required.
  human_review_required: true
  pending_isolation_test: true
  quarantine_recommendation:
    action: isolate_and_rerun
    reason: flaky_rate 40% exceeds 10% quarantine threshold
  downstream_handoff:
    to: 090-defect-classification
    category: C3_environment_infrastructure
    note: pending isolation confirmation — do not block merge yet
```
