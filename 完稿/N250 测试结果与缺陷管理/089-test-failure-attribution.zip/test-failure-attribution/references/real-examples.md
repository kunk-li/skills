# Real examples v2.2

## Example A: real regression from payment test

```yaml
metadata:
  schema_version: n250.attribution.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: deep_analysis
  readiness: ready
  evidence_profile: strong
  workflow_node: N250
  node_artifact_target: test-failure-attribution.md
  produced_events:
    - produced.n250.attribution.v2
    - signal.n250.defect_to_n005

failure_scope_summary:
  ci_run_id: CI-2026-04-28-1187
  failed_count: 1
  affected_suites: [payment-regression]
  environments: [ci-clean]
  release_or_pr_context: PR-1234 touches payment charge path

attribution_rows:
  - attribution_id: FAIL-001
    failure_id: failure-payment-charge-001
    tc_id: TC-PAYMENT-CHARGE-001
    suite_id: payment-regression
    failure_signature: sig_payment_null_charge_9ab3
    failure_timestamp: 2026-04-28T02:12:44Z
    category: C1_real_regression
    legacy_failure_category: F01_product_regression
    top_hypothesis: recent payment charge refactor returns null authorization token
    confidence: 0.91
    owner_hint: payment-service-team
    shared_defect_candidate_signal: confirmed
    candidate_defect_group_id: DEF-GRP-PAY-001
    block_merge: true
    evidence_refs:
      - ref_id: E1
        source: test output
        locator: CI-2026-04-28-1187#payment-regression
        claim_supported: clean replay fails with same stack trace
        strength: high
      - ref_id: E2
        source: code change
        locator: PR-1234 files payment/ChargeService.java
        claim_supported: changed code is in failed execution path
        strength: high

confidence_scoring:
  formula: signature*0.30 + history*0.30 + environment*0.20 + code_change*0.20
  factors_by_failure_id:
    - failure_id: failure-payment-charge-001
      signature_match: 0.95
      historical_match: 0.70
      environment_indicators: 0.90
      code_change_proximity: 1.00
      value: 0.91

replay_sampling:
  replay_required: true
  replay_count: 3
  replay_environment: clean_isolated
  replay_results:
    all_pass: false
    some_fail: false
    all_fail: true
    final_category_after_replay: C1_real_regression

circuit_breaker:
  state: closed
  level: none
  auto_actions:
    - block_merge
    - notify_author

downstream_handoff:
  to_090_defect_classification:
    failure_id: failure-payment-charge-001
    failure_signature: sig_payment_null_charge_9ab3
    primary_category: C1_real_regression
    category_confidence: 0.91
    shared_defect_candidate_signal: confirmed
    candidate_defect_group_id: DEF-GRP-PAY-001
    classification_hint: formal_defect
    evidence_refs: [E1, E2]
    pending_attribution_confirmation: false
  to_091_severity:
    real_regression_signal: true
    block_merge: true
    sla_queue_priority: P1_candidate
  to_092_reproduction:
    failure_signature: sig_payment_null_charge_9ab3
    stable_failure: true
    replay_required: false
    environment_constraints: [ci-clean]
    logs_to_capture: [payment-service DEBUG, charge-service trace]
  to_N005_feedback:
    signal_kind: recurring_payment_regression
    customer_facing_risk: true
  to_N260_gate:
    block_merge: true
    required_gate_action: stop_pr_merge

self_check:
  R01_category_required: pass
  R02_evidence_required: pass
  R03_confidence_scored: pass
  R04_low_confidence_escalated: pass
  R05_replay_for_ambiguous: pass
  R06_real_regression_blocks_merge: pass
  R07_flaky_quarantine_after_3: pass
  R08_circuit_state_required: pass
```

## Example B: flaky test without formal defect

```yaml
metadata:
  schema_version: n250.attribution.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: quick_triage
  readiness: partial
  evidence_profile: mixed
  workflow_node: N250
  produced_events:
    - produced.n250.attribution.v2

attribution_rows:
  - attribution_id: FAIL-002
    failure_id: failure-order-concurrency-007
    tc_id: TC-ORDER-CONCURRENT-001
    failure_signature: sig_order_timeout_flaky_b7c1
    category: C2_flaky_test
    legacy_failure_category: F08_flaky_race
    confidence: 0.74
    owner_hint: qa-automation
    shared_defect_candidate_signal: none
    candidate_defect_group_id: null
    block_merge: false
    evidence_refs:
      - ref_id: E3
        source: replay
        locator: replay-run-3-of-3
        claim_supported: mixed pass/fail under high load
        strength: medium

replay_sampling:
  replay_required: true
  replay_count: 3
  replay_environment: clean_isolated
  replay_results:
    all_pass: false
    some_fail: true
    all_fail: false
    final_category_after_replay: C2_flaky_test

circuit_breaker:
  state: open
  level: test_level
  auto_actions: [auto_quarantine, create_flaky_ticket]

downstream_handoff:
  to_090_defect_classification:
    classification_hint: no_defect
    pending_attribution_confirmation: false
  to_N260_gate:
    quarantine_candidate: true
    release_blocker: false

self_check:
  R01_category_required: pass
  R02_evidence_required: pass
  R03_confidence_scored: pass
  R04_low_confidence_escalated: pass
  R05_replay_for_ambiguous: pass
  R06_real_regression_blocks_merge: pass
  R07_flaky_quarantine_after_3: pass
  R08_circuit_state_required: pass
```
