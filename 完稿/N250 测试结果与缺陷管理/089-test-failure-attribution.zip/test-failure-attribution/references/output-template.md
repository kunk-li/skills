# Output template v2.2: test failure attribution

```yaml
metadata:
  schema_version: n250.attribution.v2.2.0
  contract_version: n250.defect-management.v2
  selected_mode: quick_triage|deep_analysis|pattern_registry
  readiness: ready|partial|blocked
  evidence_profile: strong|mixed|sparse|contradictory
  workflow_node: N250|standalone
  node_artifact_target: test-failure-attribution.md
  produced_events:
    - produced.n250.attribution.v2
    - signal.n250.defect_to_n005

failure_scope_summary:
  ci_run_id:
  failed_count:
  affected_suites: []
  environments: []
  release_or_pr_context:

attribution_rows:
  - attribution_id: FAIL-001
    failure_id:
    tc_id:
    suite_id:
    failure_signature:
    failure_timestamp:
    category: C1_real_regression|C2_flaky_test|C3_infrastructure_failure|C4_external_dependency_failure|C5_environment_configuration|C6_test_code_bug
    legacy_failure_category:
    top_hypothesis:
    confidence: 0.0
    owner_hint:
    shared_defect_candidate_signal: none|possible|likely|confirmed
    candidate_defect_group_id:
    block_merge: false
    evidence_refs: []

confidence_scoring:
  formula: signature*0.30 + history*0.30 + environment*0.20 + code_change*0.20
  factors_by_failure_id: []

replay_sampling:
  replay_required: true|false
  replay_count: 3
  replay_environment: clean_isolated
  replay_results:
    all_pass: false
    some_fail: false
    all_fail: false
    final_category_after_replay:

circuit_breaker:
  state: closed|open|half_open
  level: none|test_level|suite_level|pipeline_level|infrastructure_level
  auto_actions: []

downstream_handoff:
  to_090_defect_classification: {}
  to_091_severity: {}
  to_092_reproduction: {}
  to_N005_feedback: {}
  to_N260_gate: {}

self_check:
  R01_category_required: pass|fail
  R02_evidence_required: pass|fail
  R03_confidence_scored: pass|fail
  R04_low_confidence_escalated: pass|fail
  R05_replay_for_ambiguous: pass|fail
  R06_real_regression_blocks_merge: pass|fail
  R07_flaky_quarantine_after_3: pass|fail
  R08_circuit_state_required: pass|fail
```
