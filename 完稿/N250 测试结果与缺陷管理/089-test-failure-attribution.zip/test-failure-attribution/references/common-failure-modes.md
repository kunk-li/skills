# Common failure attribution mistakes

Avoid:
- Treating every failed testcase as a unique product defect.
- Calling a real regression flaky without replay or history.
- Calling a flaky failure a product regression without stable repeat failure.
- Ignoring infrastructure, dependency, and environment clues.
- Mixing observed facts, hypotheses, and recommended actions.
- Omitting confidence factors or evidence references.
- Forgetting to hand off `shared_defect_candidate_signal` to classification.
