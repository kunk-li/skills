# Real Examples / 真实示例参考

These examples illustrate correctly formed cost estimation rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Low-evidence cost — unknown costs must use needs_human_review

**Input**: A team needs to estimate the cost of adding full-text search but has no engineering input yet.

**Correct pattern**:
```
cost_id: COST-search-low-001
requirement_id: REQ-search-001
implementation_cost: needs_human_review
data_cost: high
integration_cost: medium
overall_cost: needs_human_review
uncertainty_level: high
confidence: low
technical_spike_needed: yes
open_questions: Is a dedicated search index required? Can we reuse Elasticsearch infrastructure already in production?
```

**Anti-pattern to avoid**: Setting `implementation_cost: unknown` or `overall_cost: unknown` — `unknown` is not a valid enum value. Use `needs_human_review` to signal that the estimate requires a technical spike or engineering input.

---

## Example 2: Early sizing — technical spike triggers a cost revision

**Input**: An early estimate of `medium` for a payment gateway integration is revised to `high` after a technical spike.

**Correct pattern (revision row)**:
```
cost_id: COST-payment-002
requirement_id: REQ-payment-001
prior_cost_id: COST-payment-001
revision_reason: technical spike revealed PCI-DSS compliance requirement adds 3–4 weeks of security review and code audit
implementation_cost: high
overall_cost: high
confidence: high
technical_spike_needed: no
assumption: PCI-DSS SAQ-D compliance required for direct card storage; tokenization approach would reduce to medium
```

**Rule**: Always create a new cost row with a reference to the prior estimate. Overwriting the original hides the estimation history from the audit trail.

---

## Example 3: Cost estimation boundary — do not include roadmap commitment

**Input**: A PM asks the cost estimator to also decide whether to build the feature.

**Correct pattern**:
```
cost_id: COST-ai-category-001
overall_cost: high
recommended_route: priority_assessment
notes: Cost estimate complete. Decision to build is not within scope of this skill — route to priority assessment to weigh cost against value and risk. (AP-08)
```

**Anti-pattern to avoid (AP-08)**: Writing `recommended_action: Do not build` in the cost estimation artifact — this crosses the skill boundary into roadmap decision-making.
