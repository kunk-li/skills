# Output template for Requirement Cost Estimation

Primary artifact: `requirement-cost-estimate.csv`

Required CSV header:

```csv
cost_id,requirement_id,requirement_summary,implementation_cost,data_cost,integration_cost,testing_cost,release_coordination_cost,change_management_cost,uncertainty_level,confidence,overall_cost,rationale,recommended_route,open_questions,cost_driver_ids,dependency_refs,sizing_band,assumption,technical_spike_needed
```

Recommended human-readable explanation:

## 1. Cost summary

- ...

## 2. Cost breakdown

- ...

## 3. Volatility drivers

- ...

## 4. Next-step recommendation

- ...

