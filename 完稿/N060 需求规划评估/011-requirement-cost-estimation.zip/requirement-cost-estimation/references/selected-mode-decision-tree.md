# Selected-mode decision tree

## `early_sizing`
- Use when the input most closely matches `early sizing`.
- Output schema: `planning.requirement-cost-estimation.v4`.
- Primary artifact: `requirement-cost-estimate.csv`.

## `t_shirt_estimation`
- Use when the input most closely matches `t shirt estimation`.
- Output schema: `planning.requirement-cost-estimation.v4`.
- Primary artifact: `requirement-cost-estimate.csv`.

## `implementation_driver_scan`
- Use when the input most closely matches `implementation driver scan`.
- Output schema: `planning.requirement-cost-estimation.v4`.
- Primary artifact: `requirement-cost-estimate.csv`.

## `dependency_cost_scan`
- Use when the input most closely matches `dependency cost scan`.
- Output schema: `planning.requirement-cost-estimation.v4`.
- Primary artifact: `requirement-cost-estimate.csv`.

## `low_evidence_cost`
- Use when the input most closely matches `low evidence cost`.
- Output schema: `planning.requirement-cost-estimation.v4`.
- Primary artifact: `requirement-cost-estimate.csv`.
