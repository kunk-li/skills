# Quality checklist for Requirement Cost Estimation

Start with the shared checklist in `shared-planning-assessment-contract.md#common-quality-checklist`, then apply these skill-specific checks:

- Giving exact days without design evidence
- Ignoring testing and release coordination
- Averaging unrelated sub-requirements
- Using business importance as cost evidence
- Hiding uncertainty drivers

Before handoff, run `python scripts/validate_release_consistency.py .`.
