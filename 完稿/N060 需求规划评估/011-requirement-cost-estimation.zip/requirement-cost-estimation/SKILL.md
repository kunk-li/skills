---
name: requirement-cost-estimation
description: Produce a rough requirement cost estimate by outlining likely implementation, data, integration, testing, release, coordination, and change-management effort drivers from requirement context. Use when early sizing is needed before detailed technical design, estimation workshops, or scheduling. Not for final engineering commitment, delivery dates, staffing approval, or precise person-day promises.
---

# 需求成本预估 / Requirement Cost Estimation

## Contract baseline

- `skill_id`: `requirement-cost-estimation`
- `skill_family`: `planning-assessment-suite`
- `contract_version`: `planning-assessment-suite-v1.2.1`
- `schema`: `planning.requirement-cost-estimation.v4`
- `family_role`: `cost_estimation`
- `primary_artifact`: `requirement-cost-estimate.csv`
- `composable_with`:
- `requirement-priority-assessment`
- `requirement-risk-assessment`
- `requirement-value-assessment`

This skill is standalone. It may consume outputs from sibling planning, market-research, or requirement-definition skills when available, but it must not require a fixed upstream order.

## What this skill does

在缺少完整技术方案的前提下，对需求投入做早期粗估。输出关注的是成本来源、投入等级、波动因素和不确定性，不是正式工时承诺或排期承诺。

Use this skill to create evidence-backed planning assessment artifacts with stable row contracts, metadata sidecars, route tokens, and handoff-ready identifiers.

## What this skill is not for

- final engineering commitment
- delivery scheduling
- precise person-day estimate

## Operating rules

1. Define scope before assessment: target module, candidate requirement, competitor set, user segment, time window, and source boundary.
2. Mark each important conclusion as `confirmed`, `inferred`, or `unverified` when evidence status is required.
3. Keep route values semantic: use tokens such as `priority_assessment` or `human_review`; do not write private workflow-node codes.
4. Do not encode prerequisites, stage gates, positional IDs, or hidden execution-order assumptions.
5. Preserve uncertainty as `open_questions` instead of silently filling gaps.
6. Never present an assessment recommendation as final roadmap, approval, staffing, or delivery commitment.

## Selected modes

- `early_sizing`
- `t_shirt_estimation`
- `implementation_driver_scan`
- `dependency_cost_scan`
- `low_evidence_cost`

When unsure, select the closest low-evidence mode and explicitly list missing information.

## Required row contract

| Field | Level | Meaning |
| --- | --- | --- |
| `cost_id` | required | stable cost row id |
| `requirement_id` | required | source requirement id |
| `requirement_summary` | required | short requirement summary |
| `implementation_cost` | required | implementation cost level |
| `data_cost` | required | data/model/migration cost level |
| `integration_cost` | required | integration cost level |
| `testing_cost` | required | testing and regression cost level |
| `release_coordination_cost` | required | release/training/rollout cost level |
| `change_management_cost` | required | coordination/change cost level |
| `uncertainty_level` | required | estimate uncertainty |
| `confidence` | required | confidence level |
| `overall_cost` | required | overall cost level |
| `rationale` | required | reasoning summary |
| `recommended_route` | required | semantic next route token |
| `open_questions` | required | unresolved questions |
| `cost_driver_ids` | recommended | cost driver ids |
| `dependency_refs` | recommended | dependency refs |
| `sizing_band` | recommended | sizing band |
| `assumption` | recommended | assumption |
| `technical_spike_needed` | recommended | technical spike needed |

## Route tokens

- `priority_assessment`
- `risk_assessment`
- `planning_intake`
- `human_review`
- `monitor_only`

## Output shape

Produce `requirement-cost-estimate.csv` by default. The user-facing explanation should cover:

- Cost summary
- Cost breakdown
- Volatility drivers
- Next-step recommendation

## Validation workflow

Before treating an artifact as reusable:

```bash
python scripts/validate_artifact.py examples/<example>.csv
python scripts/validate_metadata.py examples/<example>.metadata.yaml
python scripts/validate_release_consistency.py .
```

For cross-skill handoff checks, use:

```bash
python scripts/validate_handoff.py --auto examples --allow-unresolved-cross-refs
```

## References

Load these only when needed:

- `references/shared-planning-assessment-contract.md` for suite-wide route, metadata, evidence, and quality rules.
- `references/planning-assessment-id-space.md` for artifact and row ID namespaces.
- `references/field-contract.yaml` for row-level fields.
- `references/metadata-schema.json` for metadata sidecar rules.
- `references/output-template.md` for output shape.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and corrections.
- `references/quality-checklist.md` for pre-handoff checks.
- `references/common-failure-modes.md` for review risks.
