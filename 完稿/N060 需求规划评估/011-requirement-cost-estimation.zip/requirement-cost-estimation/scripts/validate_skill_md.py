#!/usr/bin/env python3
import re, sys
from pathlib import Path
NAME='requirement-cost-estimation'
REQUIRED_REFS=['shared-planning-assessment-contract.md',
 'planning-assessment-id-space.md',
 'field-contract.yaml',
 'metadata-schema.json',
 'output-template.md',
 'quality-checklist.md',
 'selected-mode-decision-tree.md',
 'anti-patterns.md',
 'common-failure-modes.md']
PRIVATE_NODE_RE = re.compile(r'(?<![A-Za-z0-9])N\d{3}(?![A-Za-z0-9])', re.IGNORECASE)
DEPENDS_TOKEN='depends' + '_on'
BLOCKS_TOKEN='blo' + 'cks'
ORDER_RE=re.compile("(^|[\\s`'\"])(?:"+DEPENDS_TOKEN+"|"+BLOCKS_TOKEN+")(\\s*:|[`'\"])", re.IGNORECASE)
POS_RE = re.compile(r'(?<![A-Za-z0-9_-])(?:[A-Za-z][A-Za-z0-9_-]*-[sS]\d{2,}|[sS]\d{2,})(?![A-Za-z0-9_-])', re.IGNORECASE)
RETIRED = (
    'planning-assessment-suite-v' + '1.0.0',
    'planning-assessment-suite-v' + '1.1.0',
    'planning-assessment-suite-v' + '1.1.1',
    'planning-assessment-suite-v' + '1.2.0',
    'planning.requirement-cost-estimation.v' + '1',
    'planning.requirement-cost-estimation.v' + '2',
    'planning.requirement-cost-estimation.v' + '3',
)

def parse_frontmatter(text):
    if not text.startswith('---'):
        return {}, text
    end = text.find('\n---', 3)
    if end < 0:
        return {}, text
    fm = {}
    for line in text[3:end].splitlines():
        if ':' in line:
            k, v = line.split(':', 1)
            fm[k.strip()] = v.strip().strip("\"'")
    return fm, text[end + 4:]

def collect_errors(skill_dir):
    d=Path(skill_dir); errors=[]
    p=d/'SKILL.md'
    if not p.exists(): return ['missing SKILL.md']
    text=p.read_text(encoding='utf-8')
    fm,body=parse_frontmatter(text)
    if fm.get('name') != NAME: errors.append(f'frontmatter name must be {NAME}')
    desc=fm.get('description','')
    if len(desc) < 160: errors.append('description is too short')
    low=desc.lower()
    if 'use when' not in low: errors.append('description must include use when')
    if 'not for' not in low and 'do not use' not in low: errors.append('description must include not for or do not use')
    if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in SKILL.md')
    if ORDER_RE.search(text): errors.append('order/prerequisite field found in SKILL.md')
    if POS_RE.search(text): errors.append('positional skill id found in SKILL.md')
    for token in RETIRED:
        if token in text: errors.append(f'retired contract or schema token remains in SKILL.md: {token}')
    for ref in REQUIRED_REFS:
        if not (d/'references'/ref).exists(): errors.append(f'missing reference {ref}')
    if 'TODO' in text or 'TBD' in text: errors.append('TODO/TBD marker remains in SKILL.md')
    return errors

def main():
    target=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
    errors=collect_errors(target)
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f'OK: SKILL.md baseline for {NAME}')
    return 0
if __name__=='__main__': sys.exit(main())
