#!/usr/bin/env python3
import re, sys
from pathlib import Path
TOKEN_RE = re.compile('\\bN\\d{3}\\b', re.IGNORECASE)
TEXT_EXTS={'.md','.yaml','.yml','.json','.csv','.py','.txt','.log'}
SKIP={'__pycache__','.git'}
SELF=Path(__file__).name

def collect_errors(skill_dir):
    errors=[]
    for p in Path(skill_dir).rglob('*'):
        if not p.is_file() or p.suffix not in TEXT_EXTS: continue
        if SELF == p.name: continue
        if any(part in SKIP for part in p.parts): continue
        text=p.read_text(encoding='utf-8', errors='ignore')
        for i,line in enumerate(text.splitlines(),1):
            if TOKEN_RE.search(line): errors.append(f'{p.relative_to(skill_dir)}:{i}: private workflow-node code')
    return errors

def main():
    d=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
    errors=collect_errors(d)
    if errors:
        print(f'FAIL: {len(errors)} private workflow-node references remain', file=sys.stderr)
        for e in errors[:30]: print('  '+e, file=sys.stderr)
        return 1
    print(f'OK: node-neutral skill package for {d}')
    return 0
if __name__=='__main__': sys.exit(main())
