---
name: requirement-value-assessment
description: Evaluate requirement value by examining user benefit, business impact, strategic fit, leverage, and timing signals from requirement context and supporting materials. Use when a feature, requirement group, or initiative needs a structured value view before prioritization, scope trade-offs, or roadmap discussion. Not for ROI promises, final investment approval, cost estimation, or delivery sequencing.
---

# 需求价值评估 / Requirement Value Assessment

## Contract baseline

- `skill_id`: `requirement-value-assessment`
- `skill_family`: `planning-assessment-suite`
- `contract_version`: `planning-assessment-suite-v1.2.1`
- `schema`: `planning.requirement-value-assessment.v4`
- `family_role`: `value_assessment`
- `primary_artifact`: `requirement-value-assessment.csv`
- `composable_with`:
- `requirement-priority-assessment`
- `requirement-cost-estimation`
- `requirement-risk-assessment`
- `competitor-analysis`

This skill is standalone. It may consume outputs from sibling planning, market-research, or requirement-definition skills when available, but it must not require a fixed upstream order.

## What this skill does

判断一个需求、功能组或能力方向“值不值得做”，并说明为什么。重点输出价值依据、受益对象、成立前提和不确定性，不做正式 ROI 承诺，也不替代最终立项决策。

Use this skill to create evidence-backed planning assessment artifacts with stable row contracts, metadata sidecars, route tokens, and handoff-ready identifiers.

## What this skill is not for

- ROI guarantee
- final investment approval
- cost estimation

## Operating rules

1. Define scope before assessment: target module, candidate requirement, competitor set, user segment, time window, and source boundary.
2. Mark each important conclusion as `confirmed`, `inferred`, or `unverified` when evidence status is required.
3. Keep route values semantic: use tokens such as `priority_assessment` or `human_review`; do not write private workflow-node codes.
4. Do not encode prerequisites, stage gates, positional IDs, or hidden execution-order assumptions.
5. Preserve uncertainty as `open_questions` instead of silently filling gaps.
6. Never present an assessment recommendation as final roadmap, approval, staffing, or delivery commitment.

## Selected modes

- `single_requirement_value`
- `initiative_value`
- `customer_value`
- `business_value`
- `low_evidence_value`

When unsure, select the closest low-evidence mode and explicitly list missing information.

## Required row contract

| Field | Level | Meaning |
| --- | --- | --- |
| `value_id` | required | stable value row id |
| `requirement_id` | required | source requirement id |
| `requirement_summary` | required | short requirement summary |
| `beneficiary` | required | primary beneficiary |
| `user_value` | required | user value level |
| `business_value` | required | business value level |
| `strategic_value` | required | strategic fit level |
| `leverage_value` | required | reuse/platform leverage level |
| `timing_signal` | required | time sensitivity |
| `confidence` | required | confidence level |
| `overall_value` | required | overall value level |
| `rationale` | required | reasoning summary |
| `recommended_route` | required | semantic next route token |
| `open_questions` | required | unresolved questions |
| `source_refs` | required | source anchors, URLs, doc ids, screenshots, or notes |
| `value_assumption` | recommended | value assumption |
| `evidence_status` | required | confirmed, inferred, or unverified |
| `time_window` | recommended | time window |
| `affected_segments` | recommended | affected segments |


## Value dimension boundary

Use `strategic_value` for fit with declared company, product, segment, or platform direction. Use `leverage_value` for reuse, compounding, or enablement effects such as shared primitives, reusable workflows, or unlocking multiple downstream requirements. Do not score the same evidence twice: if one fact supports both dimensions, explain the split in `rationale` and mark uncertainty in `open_questions`.

## Route tokens

- `priority_assessment`
- `cost_estimation`
- `risk_assessment`
- `planning_intake`
- `human_review`
- `monitor_only`

## Output shape

Produce `requirement-value-assessment.csv` by default. The user-facing explanation should cover:

- Value summary
- Dimension table
- Assumptions
- Evidence gaps

## Validation workflow

Before treating an artifact as reusable:

```bash
python scripts/validate_artifact.py examples/<example>.csv
python scripts/validate_metadata.py examples/<example>.metadata.yaml
python scripts/validate_release_consistency.py .
```

For cross-skill handoff checks, use:

```bash
python scripts/validate_handoff.py --auto examples --allow-unresolved-cross-refs
```

## References

Load these only when needed:

- `references/shared-planning-assessment-contract.md` for suite-wide route, metadata, evidence, and quality rules.
- `references/planning-assessment-id-space.md` for artifact and row ID namespaces.
- `references/field-contract.yaml` for row-level fields.
- `references/metadata-schema.json` for metadata sidecar rules.
- `references/output-template.md` for output shape.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and corrections.
- `references/quality-checklist.md` for pre-handoff checks.
- `references/common-failure-modes.md` for review risks.
