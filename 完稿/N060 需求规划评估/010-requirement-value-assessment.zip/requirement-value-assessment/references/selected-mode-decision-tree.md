# Selected-mode decision tree

## `single_requirement_value`
- Use when the input most closely matches `single requirement value`.
- Output schema: `planning.requirement-value-assessment.v4`.
- Primary artifact: `requirement-value-assessment.csv`.

## `initiative_value`
- Use when the input most closely matches `initiative value`.
- Output schema: `planning.requirement-value-assessment.v4`.
- Primary artifact: `requirement-value-assessment.csv`.

## `customer_value`
- Use when the input most closely matches `customer value`.
- Output schema: `planning.requirement-value-assessment.v4`.
- Primary artifact: `requirement-value-assessment.csv`.

## `business_value`
- Use when the input most closely matches `business value`.
- Output schema: `planning.requirement-value-assessment.v4`.
- Primary artifact: `requirement-value-assessment.csv`.

## `low_evidence_value`
- Use when the input most closely matches `low evidence value`.
- Output schema: `planning.requirement-value-assessment.v4`.
- Primary artifact: `requirement-value-assessment.csv`.
