# Output template for Requirement Value Assessment

Primary artifact: `requirement-value-assessment.csv`

Required CSV header:

```csv
value_id,requirement_id,requirement_summary,beneficiary,user_value,business_value,strategic_value,leverage_value,timing_signal,confidence,overall_value,rationale,recommended_route,open_questions,source_refs,value_assumption,evidence_status,time_window,affected_segments
```

Recommended human-readable explanation:

## 1. Value summary

- ...

## 2. Dimension table

- ...

## 3. Assumptions

- ...

## 4. Evidence gaps

- ...

