# Quality checklist for Requirement Value Assessment

Start with the shared checklist in `shared-planning-assessment-contract.md#common-quality-checklist`, then apply these skill-specific checks:

- Equating demand volume with high value
- Inventing ROI numbers
- Mixing implementation difficulty into value score
- Ignoring beneficiary scope
- Treating one customer request as global value without caveat

Before handoff, run `python scripts/validate_release_consistency.py .`.
