# Real Examples / 真实示例参考

These examples illustrate correctly formed value assessment rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Single requirement value — separating value from implementation cost

**Input**: Product team wants to assess the value of adding bulk invoice export for finance admins.

**Correct pattern**:
```
value_id: VAL-invoice-export-001
requirement_id: REQ-invoice-001
value_statement: Finance admins can complete monthly reconciliation batches in minutes instead of hours by exporting all invoices at once.
beneficiary_scope: finance_admin segment; estimated 40% of paid accounts
demand_signal_strength: high
strategic_alignment: high
user_pain_severity: high
revenue_or_retention_signal: medium
evidence_status: confirmed
confidence: high
value_score: high
notes: Value score is separate from implementation cost and risk — do not conflate. Route to cost-estimation for full picture. (AP-VAL-03)
```

**Anti-pattern to avoid (AP-VAL-03)**: Writing `value_score: medium` because the feature "looks complex to build" — implementation difficulty is not a value dimension.

---

## Example 2: Value assessment — one customer request with caveat

**Input**: A single enterprise customer requests a custom approval workflow with 10 stages.

**Correct pattern**:
```
value_id: VAL-approval-custom-001
requirement_id: REQ-approval-001
value_statement: A single enterprise account requests a 10-stage custom approval workflow for their procurement process.
beneficiary_scope: 1 confirmed enterprise customer; unclear whether this generalizes
demand_signal_strength: low
strategic_alignment: medium
user_pain_severity: high (for this customer)
evidence_status: confirmed
confidence: low
value_score: low-to-medium
notes: Single-customer request. Value score may rise if signal repeats across accounts. (AP-VAL-05) Do not present this as a high-value opportunity without wider validation.
open_questions: Is this requirement latent for other enterprise accounts? Would a simpler n-stage workflow satisfy most cases?
```

---

## Example 3: Tradeoff assessment — volume does not equal value

**Input**: 1,200 NPS comments mention "make the dashboard faster" but no analytics data supports which dashboard feature causes the slowness.

**Correct pattern**:
```
value_id: VAL-dashboard-perf-001
demand_signal_strength: high
evidence_status: reasonable_assumption
confidence: medium
notes: High volume of demand signal does not confirm high impact value without isolating which feature causes the performance issue. Route to user-journey-analysis before scoring value. (AP-VAL-01)
value_score: unscored_pending_evidence
open_questions: Which dashboard feature or data volume triggers the performance issue? What is the p95 load time?
```
