---
name: requirement-priority-assessment
display_name: 需求优先级评估 / Requirement Priority Assessment
description: assess requirement priority by combining value, urgency, dependency unlock, cost, risk, and confidence into a transparent ranking rationale. use when backlog items or scope trade-offs need structured prioritization after value, cost, and risk signals are available. not for final roadmap approval, delivery scheduling, or black-box scoring.
---

# 需求优先级评估 / Requirement Priority Assessment

## Contract baseline

- `skill_id`: `requirement-priority-assessment`
- `skill_family`: `planning-assessment-suite`
- `contract_version`: `planning-assessment-suite-v1.2.1`
- `schema`: `planning.requirement-priority-assessment.v4`
- `family_role`: `priority_assessment`
- `primary_artifact`: `requirement-priority-recommendations.csv`
- `composable_with`:
- `requirement-value-assessment`
- `requirement-cost-estimation`
- `requirement-risk-assessment`

This skill is standalone. It may consume outputs from sibling planning, market-research, or requirement-definition skills when available, but it must not require a fixed upstream order.

## What this skill does

把一组候选需求按优先级做透明排序，并解释排序依据。核心目标是给出可讨论的排序逻辑、分层结果和争议点，而不是把建议排序伪装成最终版本决策。

Use this skill to create evidence-backed planning assessment artifacts with stable row contracts, metadata sidecars, route tokens, and handoff-ready identifiers.

## What this skill is not for

- final roadmap approval
- delivery scheduling
- single-dimension ranking

## Operating rules

1. Define scope before assessment: target module, candidate requirement, competitor set, user segment, time window, and source boundary.
2. Mark each important conclusion as `confirmed`, `inferred`, or `unverified` when evidence status is required.
3. Keep route values semantic: use tokens such as `planning_intake` or `human_review`; do not write private workflow-node codes.
4. Do not encode prerequisites, stage gates, positional IDs, or hidden execution-order assumptions.
5. Preserve uncertainty as `open_questions` instead of silently filling gaps.
6. Never present an assessment recommendation as final roadmap, approval, staffing, or delivery commitment.

## Selected modes

- `backlog_ranking`
- `version_scope_prioritization`
- `tradeoff_review`
- `dependency_driven_ranking`
- `low_evidence_prioritization`

When unsure, select the closest low-evidence mode and explicitly list missing information.

## Required row contract

| Field | Level | Meaning |
| --- | --- | --- |
| `priority_id` | required | stable priority row id |
| `requirement_id` | required | source requirement id |
| `requirement_summary` | required | short requirement summary |
| `value_level` | required | value judgement |
| `urgency_level` | required | urgency judgement |
| `dependency_unlock` | required | unlock strength |
| `cost_level` | required | cost judgement |
| `risk_level` | required | risk judgement |
| `confidence` | required | confidence level |
| `recommended_priority` | required | p0/p1/p2/p3/monitor/human_review |
| `rationale` | required | reasoning summary |
| `recommended_route` | required | semantic next route token |
| `open_questions` | required | unresolved questions |
| `source_assessment_ids` | recommended | source assessment ids |
| `priority_band` | recommended | priority band |
| `tie_breaker` | recommended | tie breaker |
| `unstable_reason` | recommended | unstable reason |
| `reorder_trigger` | recommended | reorder trigger |

## Composition note

When this skill is run in the same batch as `requirement-value-assessment`, `requirement-cost-estimation`, and `requirement-risk-assessment`, strongly prefer filling `source_assessment_ids` with the matching VAL-*, COST-*, and RISK-* row IDs. Missing `source_assessment_ids` remains allowed for standalone or low-evidence prioritization, but `validate_handoff.py` emits a WARN so the row can be manually reviewed before downstream planning.

## Route tokens

- `planning_intake`
- `scope_tradeoff`
- `human_review`
- `monitor_only`

## Skill-specific anti-patterns (AP-PRI-*)

| id | anti-pattern | why harmful | correct pattern |
| --- | --- | --- | --- |
| AP-PRI-01 | outputting a single-number score without rationale | reviewers cannot challenge or adjust the ranking | always populate `rationale` with the key factors driving `recommended_priority` |
| AP-PRI-02 | setting `recommended_priority: p0` for every high-value requirement | priority inflation makes p0 meaningless | reserve p0 for items that block other p0 items or have a fixed external deadline |
| AP-PRI-03 | omitting `reorder_trigger` for unstable rankings | rankings silently become stale after context changes | always state what would cause this ranking to change |

## Output shape

Produce `requirement-priority-recommendations.csv` by default. The user-facing explanation should cover:

- Priority summary
- Ranking table
- Rationale
- Reorder triggers

## Validation workflow

Before treating an artifact as reusable:

```bash
python scripts/validate_artifact.py examples/<example>.csv
python scripts/validate_metadata.py examples/<example>.metadata.yaml
python scripts/validate_release_consistency.py .
```

For cross-skill handoff checks and node-neutrality guards, use:

```bash
python scripts/validate_handoff.py --auto examples --allow-unresolved-cross-refs
python scripts/check_node_neutrality.py examples/<example>.csv
python scripts/check_order_neutrality.py examples/<example>.csv
python scripts/self_test_ci_guards.py
```

## References

See also `scripts/cross_family_cascade.py` for cross-family pipeline validation.

## Cross-family cascade validation

To validate the full pipeline from feedback-loop through requirement-definition to planning-assessment:
```bash
python scripts/cross_family_cascade.py \
    --feedback <feedback-loop-artifact.metadata.yaml> \
    --requirement <requirement-definition-artifact.metadata.yaml> \
    --planning examples/checkout-priority.metadata.yaml
```


Load these only when needed:

- `references/shared-planning-assessment-contract.md` for suite-wide route, metadata, evidence, and quality rules.
- `references/planning-assessment-id-space.md` for artifact and row ID namespaces.
- `references/field-contract.yaml` for row-level fields.
- `references/metadata-schema.json` for metadata sidecar rules.
- `references/output-template.md` for output shape.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and corrections.
- `references/quality-checklist.md` for pre-handoff checks.
- `references/common-failure-modes.md` for review risks.

## B-family planning-assessment chain validation

To validate the full 6-skill planning-assessment chain:

```bash
python scripts/validate_planning_assessment_chain.py \
    --competitor    ../007-competitor-analysis/examples/integration/search-competitor-analysis.metadata.yaml \
    --benchmarking  ../008-competitor-feature-benchmarking/examples/integration/search-feature-benchmarking.metadata.yaml \
    --value         ../010-requirement-value-assessment/examples/integration/search-value-assessment.metadata.yaml \
    --cost          ../011-requirement-cost-estimation/examples/integration/search-cost-assessment.metadata.yaml \
    --risk          ../012-requirement-risk-assessment/examples/integration/search-risk-assessment.metadata.yaml \
    --priority      ../009-requirement-priority-assessment/examples/integration/search-priority-assessment.metadata.yaml
```

See `examples/integration/README.md` for the coherent search-feature bundle.

