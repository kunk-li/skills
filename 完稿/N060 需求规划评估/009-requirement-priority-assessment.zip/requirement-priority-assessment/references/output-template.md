# Output template for Requirement Priority Assessment

Primary artifact: `requirement-priority-recommendations.csv`

Required CSV header:

```csv
priority_id,requirement_id,requirement_summary,value_level,urgency_level,dependency_unlock,cost_level,risk_level,confidence,recommended_priority,rationale,recommended_route,open_questions,source_assessment_ids,priority_band,tie_breaker,unstable_reason,reorder_trigger
```

Recommended human-readable explanation:

## 1. Priority summary

- ...

## 2. Ranking table

- ...

## 3. Rationale

- ...

## 4. Reorder triggers

- ...

