# Selected-mode decision tree

## `backlog_ranking`
- Use when the input most closely matches `backlog ranking`.
- Output schema: `planning.requirement-priority-assessment.v4`.
- Primary artifact: `requirement-priority-recommendations.csv`.

## `version_scope_prioritization`
- Use when the input most closely matches `version scope prioritization`.
- Output schema: `planning.requirement-priority-assessment.v4`.
- Primary artifact: `requirement-priority-recommendations.csv`.

## `tradeoff_review`
- Use when the input most closely matches `tradeoff review`.
- Output schema: `planning.requirement-priority-assessment.v4`.
- Primary artifact: `requirement-priority-recommendations.csv`.

## `dependency_driven_ranking`
- Use when the input most closely matches `dependency driven ranking`.
- Output schema: `planning.requirement-priority-assessment.v4`.
- Primary artifact: `requirement-priority-recommendations.csv`.

## `low_evidence_prioritization`
- Use when the input most closely matches `low evidence prioritization`.
- Output schema: `planning.requirement-priority-assessment.v4`.
- Primary artifact: `requirement-priority-recommendations.csv`.
