# Quality checklist for Requirement Priority Assessment

Start with the shared checklist in `shared-planning-assessment-contract.md#common-quality-checklist`, then apply these skill-specific checks:

- Sorting mixed-granularity requirements together
- Using a score without rationale
- Ignoring dependency unlock value
- Treating suggested priority as roadmap commitment
- Letting low confidence items dominate without human review

Before handoff, run `python scripts/validate_release_consistency.py .`.
