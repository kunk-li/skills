# Real Examples / 真实示例参考

These examples illustrate correctly formed priority assessment rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Low-evidence prioritization — cost must not be unknown

**Input**: A product team wants to prioritize a full-text search requirement with no engineering estimate available.

**Correct pattern**:
```
priority_id: PRIO-search-low-001
requirement_id: REQ-search-001
cost_level: needs_human_review
confidence: low
recommended_priority: p3
rationale: cost is unconfirmed; no technical spike completed; deprioritized until cost estimate is available
recommended_route: human_review
open_questions: Is a dedicated search service required or can we reuse existing infrastructure? What is the index size?
```

**Anti-pattern to avoid**: Setting `cost_level: unknown` — `unknown` is not a valid enum value. Use `needs_human_review` to signal that the cost estimate requires human input before the row can be promoted.

---

## Example 2: Tradeoff review — competing high-value requirements

**Input**: Two requirements both score high on value but the team can only ship one in the current sprint.

**Correct pattern**:
```
priority_id: PRIO-tradeoff-001
requirement_id: REQ-export-001
value_level: high
urgency_level: high
dependency_unlock: REQ-audit-001
cost_level: medium
risk_level: low
recommended_priority: p1
rationale: unlocks downstream audit requirement and has lower risk than REQ-bulk-upload-001; recommended over the alternative for this sprint
tie_breaker: dependency_unlock
unstable_reason: none
reorder_trigger: if REQ-audit-001 is de-scoped, re-evaluate against REQ-bulk-upload-001
```

**Rule**: `tie_breaker` documents the deciding factor when two requirements have equivalent scores. This makes re-evaluation explicit when the deciding factor changes.

---

## Example 3: Backlog ranking — open questions must be preserved

**Input**: A batch of 8 requirements needs a priority ranking. Two of them have unclear user segments.

**Correct pattern for the unclear rows**:
```
priority_id: PRIO-unclear-001
confidence: low
recommended_priority: p3
open_questions: User segment is unclear — is this for enterprise accounts only or all users? Priority may change significantly depending on segment size.
recommended_route: human_review
```

**Anti-pattern to avoid (AP-08)**: Assigning a confident `p1` to a requirement with an unknown user segment — this presents an assessment as final when the evidence is insufficient.
