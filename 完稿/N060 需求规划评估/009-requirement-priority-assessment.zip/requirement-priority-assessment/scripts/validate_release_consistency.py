#!/usr/bin/env python3
import importlib.util, sys, tempfile, re
from pathlib import Path
from types import SimpleNamespace
NAME = 'requirement-priority-assessment'
KIND = 'priority'
PLACEHOLDERS = {'host-workflow','tbd','todo','待确认','<host-workflow>','<由 host workflow 注入>','example'}
PRIVATE_NODE_RE = re.compile('\\bN\\d{3}\\b', re.IGNORECASE)

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def parse_yaml_like(path: Path) -> dict:
    data = {}
    cur = None
    for raw in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw.rstrip()
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        if line.startswith('  - ') and cur:
            data.setdefault(cur, []).append(line[4:].strip().strip("\"'"))
        elif ':' in line and not line.startswith(' '):
            k, v = line.split(':', 1)
            k = k.strip(); v = v.strip().strip("\"'")
            if v == '':
                data[k] = []; cur = k
            else:
                data[k] = v; cur = None
    return data

def guard_self_test_errors(node, order, skill_md):
    errors = []
    with tempfile.TemporaryDirectory() as tmp:
        t = Path(tmp)
        (t / 'leak.md').write_text('leak ' + 'N' + '010 here\n', encoding='utf-8')
        if not node.collect_errors(t):
            errors.append('guard-self-test: node guard did not catch private workflow-node code')
    with tempfile.TemporaryDirectory() as tmp:
        t = Path(tmp)
        (t / 'leak.yaml').write_text('skill_id: comp-' + 'S' + '01' + '\n' + ('depends' + '_on') + ': [x]\n' + ('blo' + 'cks') + ': [x]\n', encoding='utf-8')
        found = order.collect_errors(t)
        if not any('positional' in x for x in found):
            errors.append('guard-self-test: order guard did not catch positional skill id')
        if not any('prerequisite' in x for x in found):
            errors.append('guard-self-test: order guard did not catch prerequisite field')
    retired = tuple(getattr(skill_md, 'RETIRED', ()))
    if any('" + "' in token or "' + '" in token for token in retired):
        errors.append('guard-self-test: retired token list contains literal string-concat syntax')
    required = 'planning-assessment-suite-v' + '1.2.0'
    if required not in retired:
        errors.append('guard-self-test: retired token list does not include prior suite version')
    return errors

def validate_upstream_sidecars(skill_dir: Path):
    errors = []
    upstream = skill_dir / 'examples' / 'upstream'
    required = {'artifact_id','skill_id','contract_version','schema','workflow_node','selected_mode','readiness','confidence','source_artifacts','evidence_refs','downstream_routes'}
    if not upstream.exists():
        return ['examples/upstream is missing']
    artifacts = [p for p in upstream.iterdir() if p.is_file() and p.suffix in {'.csv','.md'} and p.name != 'README.md']
    if not artifacts:
        errors.append('examples/upstream has no sample artifacts')
    for art in artifacts:
        text = art.read_text(encoding='utf-8', errors='ignore')
        if PRIVATE_NODE_RE.search(text):
            errors.append(f'{art.name}: private workflow-node code in upstream artifact')
        meta = art.with_suffix('.metadata.yaml')
        if not meta.exists():
            errors.append(f'missing upstream metadata sidecar for {art.name}')
            continue
        mtext = meta.read_text(encoding='utf-8', errors='ignore')
        if PRIVATE_NODE_RE.search(mtext):
            errors.append(f'{meta.name}: private workflow-node code in upstream metadata sidecar')
        data = parse_yaml_like(meta)
        missing = [k for k in sorted(required) if k not in data or data[k] in ('', [])]
        if missing:
            errors.append(f'{meta.name}: missing upstream metadata fields {missing}')
        wf = str(data.get('workflow_node','')).strip().lower()
        if wf in PLACEHOLDERS:
            errors.append(f'{meta.name}: placeholder value in upstream metadata sidecar')
    return errors

def collect_errors(skill_dir):
    d = Path(skill_dir)
    scripts = d / 'scripts'
    examples = d / 'examples'
    errors = []
    skill_md = load(scripts / 'validate_skill_md.py', 'validate_skill_md')
    node = load(scripts / 'check_node_neutrality.py', 'check_node_neutrality')
    order = load(scripts / 'check_order_neutrality.py', 'check_order_neutrality')
    self_test = load(scripts / 'self_test_ci_guards.py', 'self_test_ci_guards')
    decision = load(scripts / 'validate_decision_tree.py', 'validate_decision_tree')
    artifact = load(scripts / 'validate_artifact.py', 'validate_artifact')
    metadata = load(scripts / 'validate_metadata.py', 'validate_metadata')
    handoff = load(scripts / 'validate_handoff.py', 'validate_handoff')
    errors += [f'guard-self-test: {x}' for x in guard_self_test_errors(node, order, skill_md)]
    errors += [f'self-test: {x}' for x in self_test.collect_errors(d)]
    for label, func in [
        ('skill-md', skill_md.collect_errors),
        ('node-neutrality', node.collect_errors),
        ('order-neutrality', order.collect_errors),
        ('decision-tree', decision.collect_errors),
    ]:
        for e in func(d):
            errors.append(f'{label}: {e}')
    for art in sorted(examples.glob('*.csv')):
        e, w = artifact.validate(art, strict=False)
        errors += [f'artifact {art.name}: {x}' for x in e]
        meta = art.with_suffix('.metadata.yaml')
        if not meta.exists():
            errors.append(f'missing metadata sidecar for {art.name}')
        else:
            errors += [f'metadata {meta.name}: {x}' for x in metadata.validate(meta)]
    errors += [f'upstream-sidecar: {x}' for x in validate_upstream_sidecars(d)]
    args = SimpleNamespace(competitor=[], benchmark=[], value=[], cost=[], risk=[], priority=[], auto=str(examples), allow_unresolved_cross_refs=True)
    e, w = handoff.validate(args)
    errors += [f'handoff: {x}' for x in e]
    return errors

def main():
    d = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
    errors = collect_errors(d)
    if errors:
        for e in errors:
            print('ERROR:', e, file=sys.stderr)
        return 1
    print(f'OK: release consistency passed for {NAME} (7-in-1 + self-test)')
    return 0
if __name__ == '__main__':
    sys.exit(main())
