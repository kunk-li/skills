# Integration Examples / 集成示例

This directory contains a six-artifact integration example demonstrating how all six B-family planning-assessment skills chain together for a search feature assessment.

## Search Feature Planning Chain

| Skill | Artifact | File |
| --- | --- | --- |
| 007 competitor-analysis | CA-search-202605 | `search-competitor-analysis.csv` + `.metadata.yaml` |
| 008 competitor-feature-benchmarking | FBK-search-202605 | `search-feature-benchmarking.csv` + `.metadata.yaml` |
| 010 requirement-value-assessment | VAL-search-202605 | `search-value-assessment.csv` + `.metadata.yaml` |
| 011 requirement-cost-estimation | COST-search-202605 | `search-cost-assessment.csv` + `.metadata.yaml` |
| 012 requirement-risk-assessment | RISK-search-202605 | `search-risk-assessment.csv` + `.metadata.yaml` |
| 009 requirement-priority-assessment | PRIO-search-202605 | `search-priority-assessment.csv` + `.metadata.yaml` |

## Downstream handoff chain

```
competitor-analysis → feature-benchmarking → value/cost/risk (parallel) → priority-assessment → planning_intake
```

## Validate the chain

Run from any B-family skill directory. Each skill's `examples/integration/` contains only its own artifact and metadata.

```bash
python scripts/validate_planning_assessment_chain.py \
    --competitor    examples/integration/search-competitor-analysis.metadata.yaml \
    --benchmarking  <008-dir>/examples/integration/search-feature-benchmarking.metadata.yaml \
    --value         <010-dir>/examples/integration/search-value-assessment.metadata.yaml \
    --cost          <011-dir>/examples/integration/search-cost-assessment.metadata.yaml \
    --risk          <012-dir>/examples/integration/search-risk-assessment.metadata.yaml \
    --priority      <009-dir>/examples/integration/search-priority-assessment.metadata.yaml
```
