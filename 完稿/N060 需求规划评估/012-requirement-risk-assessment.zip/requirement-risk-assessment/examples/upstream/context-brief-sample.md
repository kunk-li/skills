# Context brief sample

context_id: CTX-checkout-001
requirement_id: REQ-checkout-001
summary: Checkout recovery context compiled from interviews, support notes, and product analytics.
evidence_status: confirmed
recommended_route: value_assessment
