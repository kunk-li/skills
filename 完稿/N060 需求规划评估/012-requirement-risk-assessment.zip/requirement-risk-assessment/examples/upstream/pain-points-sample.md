# Pain point sample

pain_id: PAIN-checkout-001
requirement_id: REQ-checkout-001
pain_statement: Buyers lose trust when payment retry guidance is unclear after issuer failure.
severity: high
evidence_status: confirmed
recommended_route: risk_assessment
