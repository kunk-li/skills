# Journey sample

journey_id: JNY-checkout-001
requirement_id: REQ-checkout-001
stage: payment retry
actor: buyer
breakpoint: Retry feedback is unclear after payment failure.
recommended_route: priority_assessment
