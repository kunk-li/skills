# Upstream cascade samples

These fixtures emulate upstream requirement-definition artifacts used by planning assessment skills. They are bundled regression samples only; they do not define additional skills and do not define host workflow nodes.

Each upstream artifact has a metadata sidecar so release checks can verify traceability and placeholder hygiene without external files.
