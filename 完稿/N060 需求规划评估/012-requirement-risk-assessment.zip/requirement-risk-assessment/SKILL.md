---
name: requirement-risk-assessment
display_name: 需求风险预判 / Requirement Risk Assessment
description: Identify early requirement risks across implementation, release, policy, data, and dependency dimensions before solution design; not launch approval or compliance sign-off.
---

# 需求风险预判 / Requirement Risk Assessment

## Contract baseline

- `skill_id`: `requirement-risk-assessment`
- `skill_family`: `planning-assessment-suite`
- `contract_version`: `planning-assessment-suite-v1.2.1`
- `schema`: `planning.requirement-risk-assessment.v4`
- `family_role`: `risk_assessment`
- `primary_artifact`: `requirement-risk-register.csv`
- `composable_with`:
- `requirement-priority-assessment`
- `requirement-cost-estimation`
- `requirement-value-assessment`
- `competitor-analysis`
- `competitor-feature-benchmarking`

This skill is standalone. It may consume outputs from sibling planning, market-research, or requirement-definition skills when available, but it must not require a fixed upstream order.

## What this skill does

提前识别需求在实现、上线、协同、规则、数据和组织推进上的主要风险。输出的是前置风险判断和缓解方向，不替代正式技术评审、风控评审或上线审批。

Use this skill to create evidence-backed planning assessment artifacts with stable row contracts, metadata sidecars, route tokens, and handoff-ready identifiers.

## What this skill is not for

- formal launch approval
- compliance sign-off
- solution design

## Operating rules

1. Define scope before assessment: target module, candidate requirement, competitor set, user segment, time window, and source boundary.
2. Mark each important conclusion as `confirmed`, `inferred`, or `unverified` when evidence status is required.
3. Keep route values semantic: use tokens such as `priority_assessment` or `human_review`; do not write private workflow-node codes.
4. Do not encode prerequisites, stage gates, positional IDs, or hidden execution-order assumptions.
5. Preserve uncertainty as `open_questions` instead of silently filling gaps.
6. Never present an assessment recommendation as final roadmap, approval, staffing, or delivery commitment.

## Selected modes

- `early_risk_scan`
- `release_risk_scan`
- `integration_risk_scan`
- `policy_risk_scan`
- `low_evidence_risk`

When unsure, select the closest low-evidence mode and explicitly list missing information.

## Mode selection at a glance

| mode | signal in input | when to use |
| --- | --- | --- |
| `early_risk_scan` | general requirement context | broad forward-looking risk identification |
| `release_risk_scan` | launch or rollout timing is a concern | release-focused risk with go/no-go signals |
| `integration_risk_scan` | cross-team or API dependencies present | integration and dependency risk mapping |
| `policy_risk_scan` | regulatory, compliance, or rule concerns | policy and legal risk identification |
| `low_evidence_risk` | sparse context or unverified assumptions | skeleton risk register with explicit unknowns |

For detailed selection logic, consult `references/selected-mode-decision-tree.md`.

## Required row contract

| Field | Level | Meaning |
| --- | --- | --- |
| `risk_id` | required | stable risk row id |
| `requirement_id` | required | source requirement id |
| `requirement_summary` | required | short requirement summary |
| `risk_category` | required | risk category |
| `risk_statement` | required | risk statement |
| `trigger_condition` | required | condition that triggers the risk |
| `consequence` | required | likely consequence |
| `likelihood` | required | likelihood level |
| `impact` | required | impact level |
| `overall_risk` | required | overall risk level |
| `evidence_status` | required | confirmed, inferred, or unverified |
| `mitigation_direction` | required | mitigation direction |
| `recommended_route` | required | semantic next route token |
| `open_questions` | required | unresolved questions |
| `exposure_stage` | recommended | exposure stage |
| `owner_hint` | recommended | owner hint |
| `monitoring_signal` | recommended | monitoring signal |
| `fallback_option` | recommended | fallback option |
| `related_cost_ids` | recommended | related cost ids |

## Composition note

When run alongside `requirement-value-assessment` and `requirement-cost-estimation`, populate `related_cost_ids` with matching COST-* IDs so risk and cost signals are traceable together in downstream priority assessment. `validate_handoff.py` emits WARN on missing cross-refs.

## Route tokens

- `priority_assessment`
- `cost_estimation`
- `planning_intake`
- `human_review`
- `monitor_only`

## Skill-specific anti-patterns (AP-RISK-*)

| id | anti-pattern | why harmful | correct pattern |
| --- | --- | --- | --- |
| AP-RISK-01 | marking `likelihood: low` without evidence to support it | risks are silently dismissed before solution design | always state the basis for likelihood in `trigger_condition` |
| AP-RISK-02 | omitting `mitigation_direction` for high-impact risks | downstream teams have no starting point for risk response | every risk row with `impact: high` must have a concrete `mitigation_direction` |
| AP-RISK-03 | routing a high-overall-risk item directly to `planning_intake` | unmitigated risks enter roadmap without review | route to `human_review` first when `overall_risk: high` |

## Output shape

Produce `requirement-risk-register.csv` by default. The user-facing explanation should cover:

- Risk summary
- Risk register
- High-priority risks
- Confirmation gaps

## Validation workflow

Before treating an artifact as reusable:

```bash
python scripts/validate_artifact.py examples/<example>.csv
python scripts/validate_metadata.py examples/<example>.metadata.yaml
python scripts/validate_release_consistency.py .
```

For cross-skill handoff checks and node-neutrality guards, use:

```bash
python scripts/validate_handoff.py --auto examples --allow-unresolved-cross-refs
python scripts/check_node_neutrality.py examples/<example>.csv
python scripts/check_order_neutrality.py examples/<example>.csv
python scripts/self_test_ci_guards.py
```

## References

Load these only when needed:

- `references/shared-planning-assessment-contract.md` for suite-wide route, metadata, evidence, and quality rules.
- `references/planning-assessment-id-space.md` for artifact and row ID namespaces.
- `references/field-contract.yaml` for row-level fields.
- `references/metadata-schema.json` for metadata sidecar rules.
- `references/output-template.md` for output shape.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and corrections.
- `references/quality-checklist.md` for pre-handoff checks.
- `references/common-failure-modes.md` for review risks.

## B-family planning-assessment chain validation

To validate the full 6-skill planning-assessment chain:

```bash
python scripts/validate_planning_assessment_chain.py \
    --competitor    ../007-competitor-analysis/examples/integration/search-competitor-analysis.metadata.yaml \
    --benchmarking  ../008-competitor-feature-benchmarking/examples/integration/search-feature-benchmarking.metadata.yaml \
    --value         ../010-requirement-value-assessment/examples/integration/search-value-assessment.metadata.yaml \
    --cost          ../011-requirement-cost-estimation/examples/integration/search-cost-assessment.metadata.yaml \
    --risk          ../012-requirement-risk-assessment/examples/integration/search-risk-assessment.metadata.yaml \
    --priority      ../009-requirement-priority-assessment/examples/integration/search-priority-assessment.metadata.yaml
```

See `examples/integration/README.md` for the coherent search-feature bundle.

