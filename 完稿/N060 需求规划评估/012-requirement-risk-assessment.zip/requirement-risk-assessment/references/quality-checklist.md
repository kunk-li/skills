# Quality checklist for Requirement Risk Assessment

Start with the shared checklist in `shared-planning-assessment-contract.md#common-quality-checklist`, then apply these skill-specific checks:

- Listing risk nouns without trigger and consequence
- Treating potential risk as already happened
- Ignoring release or collaboration risks
- Writing approval decisions instead of risk signals
- Missing mitigation direction for high risks

Before handoff, run `python scripts/validate_release_consistency.py .`.
