# Planning assessment ID space

| Prefix | Row field | Row pattern | Artifact pattern | Primary artifact |
| --- | --- | --- | --- | --- |
| `CA` | `competitor_insight_id` | `^CA-[a-z0-9_]+-\d{3,}$` | `^CA-[a-z0-9_]+-\d{6}$` | competitor-capability-scan.csv |
| `FBK` | `benchmark_id` | `^FBK-[a-z0-9_]+-\d{3,}$` | `^FBK-[a-z0-9_]+-\d{6}$` | competitor-feature-benchmark.csv |
| `PRIO` | `priority_id` | `^PRIO-[a-z0-9_]+-\d{3,}$` | `^PRIO-[a-z0-9_]+-\d{6}$` | requirement-priority-recommendations.csv |
| `VAL` | `value_id` | `^VAL-[a-z0-9_]+-\d{3,}$` | `^VAL-[a-z0-9_]+-\d{6}$` | requirement-value-assessment.csv |
| `COST` | `cost_id` | `^COST-[a-z0-9_]+-\d{3,}$` | `^COST-[a-z0-9_]+-\d{6}$` | requirement-cost-estimate.csv |
| `RISK` | `risk_id` | `^RISK-[a-z0-9_]+-\d{3,}$` | `^RISK-[a-z0-9_]+-\d{6}$` | requirement-risk-register.csv |

Use lowercase scope tokens inside IDs, for example `VAL-checkout-001` or `RISK-approval-001`. Row IDs identify rows; artifact IDs identify a whole file or release batch and should end in `yyyymm`.
