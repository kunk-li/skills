# Anti-patterns

| id | anti-pattern | why harmful | validator coverage | correct pattern |
| --- | --- | --- | --- | --- |
| AP-01 | Embedding private workflow-node codes | Breaks reuse across host workflows | check_node_neutrality.py fails the package | Use semantic route tokens. |
| AP-02 | Encoding prerequisite or blocking-order fields | Makes standalone use brittle | check_order_neutrality.py fails the package | Use composable prose only. |
| AP-03 | Missing metadata sidecar | Breaks audit and handoff traceability | validate_release_consistency.py fails examples | Create <artifact>.metadata.yaml. |
| AP-04 | Placeholder workflow identifier | Lets draft metadata leak to production | validate_metadata.py fails placeholders | Use a real host workflow id. |
| AP-05 | Unsupported confidence value | Makes downstream scoring ambiguous | validate_artifact.py fails enum | Use high/medium/low/needs_human_review. |
| AP-06 | Malformed row id | Breaks cross-artifact references | validate_artifact.py fails id pattern | Use the skill-specific ID pattern. |
| AP-07 | Empty source_refs or evidence_refs | Hides evidence gaps | artifact/metadata validators fail required fields | Provide source anchors or mark open questions. |
| AP-08 | Recommendation as final decision | Oversteps skill boundary | quality checklist catches it | Write assessment recommendation with caveats. |
| AP-09 | Mixing facts and assumptions | Creates false certainty | review checklist catches it | Separate confirmed, inferred, and unverified. |
| AP-10 | PII or secret in assessment text | Creates privacy/security risk | validate_artifact.py warns or fails in strict mode | Redact personal data and tokens. |
| AP-RISK-01 | Listing risk nouns without trigger and consequence | Produces misleading assessment output | review checklist + artifact validator where applicable | Preserve scope, evidence, caveats, and route tokens. |
| AP-RISK-02 | Treating potential risk as already happened | Produces misleading assessment output | review checklist + artifact validator where applicable | Preserve scope, evidence, caveats, and route tokens. |
| AP-RISK-03 | Ignoring release or collaboration risks | Produces misleading assessment output | review checklist + artifact validator where applicable | Preserve scope, evidence, caveats, and route tokens. |
| AP-RISK-04 | Writing approval decisions instead of risk signals | Produces misleading assessment output | review checklist + artifact validator where applicable | Preserve scope, evidence, caveats, and route tokens. |
| AP-RISK-05 | Ignoring competitor gaps as market or competitive risk | Can hide urgency when competitors already support the capability | review checklist + handoff review | Bring competitor-analysis or feature-benchmarking signals into risk_statement; use policy, adoption, dependency, or other category and explain rationale. |
| AP-RISK-06 | Missing mitigation direction for high risks | Produces misleading assessment output | review checklist + artifact validator where applicable | Preserve scope, evidence, caveats, and route tokens. |
