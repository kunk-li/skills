# Real Examples / 真实示例参考

These examples illustrate correctly formed risk assessment rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Early risk scan — trigger and consequence required

**Input**: Requirement to add SSO login for enterprise accounts.

**Correct pattern**:
```
risk_id: RISK-sso-001
requirement_id: REQ-sso-001
risk_category: dependency
risk_statement: SSO integration depends on each enterprise customer's IdP configuration, which varies by vendor (Okta, Azure AD, SAML 2.0).
trigger: customer initiates SSO setup with a non-standard IdP configuration
consequence: integration fails silently or requires custom engineering for each customer, delaying onboarding
likelihood: medium
severity: high
mitigation_direction: build an IdP-agnostic SAML 2.0 adapter; test against Okta and Azure AD configurations in staging before GA
evidence_status: inferred
confidence: medium
open_questions: How many enterprise customers use non-standard IdP configurations? Is SAML 2.0 sufficient or do we need OAuth/OIDC support?
```

**Anti-pattern to avoid (AP-RISK-01)**: Writing `risk: IdP dependency` with no trigger or consequence — vague risk nouns cannot be mitigated or tracked.

---

## Example 2: Risk assessment — potential risk vs. confirmed incident

**Input**: A product manager says "if we add AI categorization, we might get GDPR complaints."

**Correct pattern**:
```
risk_id: RISK-ai-gdpr-001
risk_category: compliance
risk_statement: AI categorization that processes invoice content may require explicit GDPR consent disclosure if the training data includes EU customer PII.
trigger: AI model processes invoice line items containing EU-resident billing addresses or VAT IDs
consequence: potential GDPR Article 22 violation if automated processing is not disclosed and consented to
likelihood: medium
severity: high
mitigation_direction: engage legal and DPO team before enabling AI categorization for EU accounts; consider opt-in consent gate
evidence_status: reasonable_assumption
confidence: medium
notes: Risk is potential, not confirmed. Do not assert that a GDPR violation has occurred. (AP-RISK-02)
```

---

## Example 3: Competitor risk — missing competitor signal

**Input**: Competitor Y launched bulk AI invoice categorization last quarter; our product does not have this.

**Correct pattern**:
```
risk_id: RISK-competitor-ai-001
risk_category: competitive
risk_statement: Competitor Y's AI invoice categorization creates a competitive gap that may influence enterprise RFP decisions against our product.
trigger: enterprise prospect compares our manual categorization against Competitor Y during evaluation
consequence: loss of enterprise deals where AI automation is a key decision criterion
likelihood: medium
severity: medium
mitigation_direction: route to competitor-feature-benchmarking for a full gap analysis before scheduling the feature
evidence_status: confirmed
confidence: medium
source_refs: SRC-competitorY-launch-202602
notes: Competitor gap is a market risk signal, not an automatic roadmap commitment. (AP-RISK-05)
```
