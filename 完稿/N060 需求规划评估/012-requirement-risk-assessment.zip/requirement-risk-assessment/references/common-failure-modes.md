# Common failure modes

| Failure mode | Symptom | Prevention |
| --- | --- | --- |
| Scope drift | Output answers a broader or narrower question than requested | Restate scope at the top and keep row fields scoped |
| False certainty | Inferred items appear as confirmed | Use evidence_status and confidence fields |
| Hidden gaps | Unknowns disappear from final output | Fill open_questions and evidence_refs |
| Decision overreach | Assessment is phrased as final approval | Use recommended_route and caveats |
| Handoff break | IDs cannot be joined downstream | Run validate_handoff.py and release consistency |
| Private-node leakage | Host-specific node identifiers appear in reusable artifacts | Run check_node_neutrality.py |
