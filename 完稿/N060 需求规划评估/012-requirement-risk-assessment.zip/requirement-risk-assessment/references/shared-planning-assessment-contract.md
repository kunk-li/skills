# Shared planning-assessment contract

## Skill family identity

```yaml
skill_family: planning-assessment-suite
contract_version: planning-assessment-suite-v1.2.1
private_workflow_node_policy: do_not_embed_numeric_workflow_node_ids_in_skill_artifacts
order_policy: skills_are_standalone_and_composable
route_policy: use_semantic_route_tokens
```

This suite covers market reference and planning assessment work: competitor analysis, feature benchmarking, value assessment, cost estimation, risk assessment, and priority assessment.

## Route tokens

- `context_enrichment`
- `cost_estimation`
- `feature_benchmarking`
- `human_review`
- `monitor_only`
- `planning_intake`
- `priority_assessment`
- `risk_assessment`
- `scope_tradeoff`
- `value_assessment`

Host workflows may map these tokens to local workflow nodes outside the skill package. Skill artifacts must keep the token values, not host-specific node identifiers.

## Evidence states

- `confirmed`: directly supported by provided material.
- `inferred`: reasonable inference from provided material.
- `unverified`: plausible but requires confirmation.

## Confidence values

Use `high`, `medium`, `low`, or `needs_human_review`.

## Handoff rules

- Artifact rows must have stable row IDs.
- Metadata sidecars must include `artifact_id`, `skill_id`, `contract_version`, `schema`, `workflow_node`, `selected_mode`, `readiness`, `confidence`, `source_artifacts`, `evidence_refs`, and `downstream_routes`.
- Use `cross_artifact_refs` for optional links to sibling artifacts.
- If a cross reference is not available in the current package, warn in single-skill validation and fail in strict cross-skill validation.

## Common quality checklist

1. Use host-neutral route tokens instead of private workflow-node codes.
2. Keep skill outputs standalone and composable; do not encode execution order.
3. Preserve source references and evidence status for each material conclusion.
4. Separate confirmed facts, reasonable inference, and open questions.
5. Do not convert assessment recommendations into final roadmap commitments.
6. Do not hide low confidence behind precise-looking scores.
7. Flag scope, version, market, package, or segment differences explicitly.
8. Keep artifact IDs stable and namespace-scoped.
9. Attach metadata sidecars to every reusable artifact.
10. Route uncertain or conflicting cases to human_review.
11. Run release consistency before handing off outputs.


## Upstream cascade fixtures

Each skill includes `examples/upstream/` fixtures with requirement-definition context, pain, journey, and intake-style samples. They are regression fixtures only; they do not define additional skills or host workflow nodes. Every upstream fixture must carry a metadata sidecar and must pass release consistency.

## CI guard self-test policy

Release consistency runs guard self-tests before accepting node-neutral, order-neutral, or retired-version checks. This prevents silent no-op CI guards.
