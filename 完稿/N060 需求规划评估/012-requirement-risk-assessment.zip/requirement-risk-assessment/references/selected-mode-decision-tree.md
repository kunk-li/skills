# Selected-mode decision tree

## `early_risk_scan`
- Use when the input most closely matches `early risk scan`.
- Output schema: `planning.requirement-risk-assessment.v4`.
- Primary artifact: `requirement-risk-register.csv`.

## `release_risk_scan`
- Use when the input most closely matches `release risk scan`.
- Output schema: `planning.requirement-risk-assessment.v4`.
- Primary artifact: `requirement-risk-register.csv`.

## `integration_risk_scan`
- Use when the input most closely matches `integration risk scan`.
- Output schema: `planning.requirement-risk-assessment.v4`.
- Primary artifact: `requirement-risk-register.csv`.

## `policy_risk_scan`
- Use when the input most closely matches `policy risk scan`.
- Output schema: `planning.requirement-risk-assessment.v4`.
- Primary artifact: `requirement-risk-register.csv`.

## `low_evidence_risk`
- Use when the input most closely matches `low evidence risk`.
- Output schema: `planning.requirement-risk-assessment.v4`.
- Primary artifact: `requirement-risk-register.csv`.
