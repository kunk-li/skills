# Output template for Requirement Risk Assessment

Primary artifact: `requirement-risk-register.csv`

Required CSV header:

```csv
risk_id,requirement_id,requirement_summary,risk_category,risk_statement,trigger_condition,consequence,likelihood,impact,overall_risk,evidence_status,mitigation_direction,recommended_route,open_questions,exposure_stage,owner_hint,monitoring_signal,fallback_option,related_cost_ids
```

Recommended human-readable explanation:

## 1. Risk summary

- ...

## 2. Risk register

- ...

## 3. High-priority risks

- ...

## 4. Confirmation gaps

- ...

