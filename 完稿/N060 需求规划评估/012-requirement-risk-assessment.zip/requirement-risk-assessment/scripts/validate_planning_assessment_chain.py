#!/usr/bin/env python3
"""
Validate the intra-B-family planning-assessment chain.

Checks that artifacts from the planning-assessment + competitor-research pipeline
form a coherent chain:

  007 competitor → 008 benchmarking → 010 value → 011 cost → 012 risk → 009 priority

Checks:
  1. Each artifact carries the correct contract_version.
  2. artifact_id follows the expected namespace prefix.
  3. downstream_routes contain tokens matching the next skill's expected intake.
  4. No artifact_id appears in its own cross_artifact_refs.
  5. evidence_refs are non-empty at each stage.

Usage:
    python validate_planning_assessment_chain.py \\
        --competitor    <007.metadata.yaml> \\
        --benchmarking  <008.metadata.yaml> \\
        --value         <010.metadata.yaml> \\
        --cost          <011.metadata.yaml> \\
        --risk          <012.metadata.yaml> \\
        --priority      <009.metadata.yaml>

All six arguments are optional; omit a stage to skip its checks.
"""
from __future__ import annotations
import argparse, sys, re
from pathlib import Path

try:
    import yaml
    def _load(p: Path) -> dict:
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
except ImportError:
    def _load(p: Path) -> dict:
        data: dict = {}
        cur = None
        for raw in p.read_text(encoding="utf-8").splitlines():
            line = raw.rstrip()
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            if line.startswith("  - ") and cur:
                data.setdefault(cur, []).append(line[4:].strip().strip("\"'"))
            elif ":" in line and not line.startswith(" "):
                k, v = line.split(":", 1)
                k = k.strip(); v = v.strip().strip("\"'")
                data[k] = [] if v == "" else v
                cur = k if v == "" else None
        return data


CONTRACT = "planning-assessment-suite-v1.2.1"

STAGE_CONFIG = {
    "competitor":   {"id_prefix": re.compile(r"^CA-")},
    "benchmarking": {"id_prefix": re.compile(r"^FBK-")},
    "value":        {"id_prefix": re.compile(r"^VAL-")},
    "cost":         {"id_prefix": re.compile(r"^COST-")},
    "risk":         {"id_prefix": re.compile(r"^RISK-")},
    "priority":     {"id_prefix": re.compile(r"^PRIO-")},
}

# Ordered pipeline: competitor -> benchmarking -> value/cost/risk -> priority
PIPELINE_ORDER = ["competitor", "benchmarking", "value", "cost", "risk", "priority"]

HANDOFF_TOKENS = {
    # competitor feeds feature benchmarking
    ("competitor",   "benchmarking"): {"feature_benchmarking"},
    # benchmarking feeds value assessment (cost and risk may run in parallel, not required)
    ("benchmarking", "value"):        {"value_assessment"},
    # value/cost/risk each feed priority assessment
    ("value",        "priority"):     {"priority_assessment"},
    ("cost",         "priority"):     {"priority_assessment"},
    ("risk",         "priority"):     {"priority_assessment"},
}


def _routes(data: dict) -> list[str]:
    raw = data.get("downstream_routes") or []
    if isinstance(raw, list):
        return [str(r) for r in raw]
    return [str(raw)] if raw else []


def check_stage(path: Path, stage: str, errors: list[str]) -> dict:
    data = _load(path)
    cfg = STAGE_CONFIG[stage]

    cv = data.get("contract_version")
    if cv != CONTRACT:
        errors.append(
            f"{path.name} [{stage}]: contract_version {cv!r} != expected {CONTRACT!r}"
        )

    aid = str(data.get("artifact_id") or "")
    if aid and not cfg["id_prefix"].match(aid):
        errors.append(
            f"{path.name} [{stage}]: artifact_id {aid!r} does not match expected "
            f"prefix {cfg['id_prefix'].pattern}"
        )

    refs = list(data.get("cross_artifact_refs") or [])
    if aid and aid in refs:
        errors.append(f"{path.name} [{stage}]: self-reference in cross_artifact_refs ({aid})")

    evs = list(data.get("evidence_refs") or [])
    if not evs:
        errors.append(f"{path.name} [{stage}]: evidence_refs is empty")

    return data


def check_handoff(src_path: Path, src: str, dst: str, src_data: dict,
                  errors: list[str]) -> None:
    routes = _routes(src_data)
    expected = HANDOFF_TOKENS.get((src, dst), set())
    if expected and not any(r in expected for r in routes):
        errors.append(
            f"{src_path.name} [{src}→{dst}]: "
            f"no matching handoff token in downstream_routes {routes}. "
            f"Expected one of: {sorted(expected)}"
        )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--competitor",   metavar="YAML", help="007 competitor-analysis metadata")
    ap.add_argument("--benchmarking", metavar="YAML", help="008 competitor-feature-benchmarking metadata")
    ap.add_argument("--value",        metavar="YAML", help="010 requirement-value-assessment metadata")
    ap.add_argument("--cost",         metavar="YAML", help="011 requirement-cost-estimation metadata")
    ap.add_argument("--risk",         metavar="YAML", help="012 requirement-risk-assessment metadata")
    ap.add_argument("--priority",     metavar="YAML", help="009 requirement-priority-assessment metadata")
    args = ap.parse_args()

    stage_args = {
        "competitor":   args.competitor,
        "benchmarking": args.benchmarking,
        "value":        args.value,
        "cost":         args.cost,
        "risk":         args.risk,
        "priority":     args.priority,
    }

    if not any(stage_args.values()):
        ap.print_help()
        return 1

    errors: list[str] = []
    data: dict[str, dict] = {}

    for stage, arg in stage_args.items():
        if arg:
            p = Path(arg)
            if not p.exists():
                errors.append(f"file not found: {p}")
            else:
                data[stage] = check_stage(p, stage, errors)

    # Check handoffs in pipeline order
    present = [s for s in PIPELINE_ORDER if s in data]
    checked_pairs: set[tuple] = set()
    for i, stage in enumerate(present):
        for j in range(i+1, len(present)):
            nxt = present[j]
            pair = (stage, nxt)
            if pair in HANDOFF_TOKENS and pair not in checked_pairs:
                src_path = Path(stage_args[stage])
                check_handoff(src_path, stage, nxt, data[stage], errors)
                checked_pairs.add(pair)

    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        return 1

    stage_labels = " → ".join(present)
    print(f"OK: planning-assessment chain passes ({stage_labels})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
