#!/usr/bin/env python3
import importlib.util, sys, tempfile
from pathlib import Path

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def collect_errors(skill_dir):
    d = Path(skill_dir)
    scripts = d / 'scripts'
    node = load(scripts / 'check_node_neutrality.py', 'node_guard')
    order = load(scripts / 'check_order_neutrality.py', 'order_guard')
    skill_md = load(scripts / 'validate_skill_md.py', 'skill_md_guard')
    errors = []
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        (t / 'references').mkdir()
        (t / 'references' / 'leak.md').write_text('leak ' + 'N' + '010' + ' here\n', encoding='utf-8')
        if not node.collect_errors(t):
            errors.append('node guard self-test failed to catch private workflow-node code')
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        (t / 'references').mkdir()
        (t / 'references' / 'order.yaml').write_text('skill_id: sample-' + 'S' + '01' + '\n', encoding='utf-8')
        if not any('positional' in e for e in order.collect_errors(t)):
            errors.append('order guard self-test failed to catch positional skill id')
    for field in ['depends' + '_on', 'blo' + 'cks']:
        with tempfile.TemporaryDirectory() as td:
            t = Path(td)
            (t / 'references').mkdir()
            (t / 'references' / 'order.yaml').write_text(field + ': [foo]\n', encoding='utf-8')
            if not any('prerequisite' in e for e in order.collect_errors(t)):
                errors.append('order guard self-test failed to catch prerequisite/order field ' + field)
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        (t / 'references').mkdir()
        (t / 'references' / 'shared-planning-assessment-contract.md').write_text('x', encoding='utf-8')
        for ref in ['planning-assessment-id-space.md','field-contract.yaml','metadata-schema.json','output-template.md','quality-checklist.md','selected-mode-decision-tree.md','anti-patterns.md','common-failure-modes.md']:
            (t / 'references' / ref).write_text('x', encoding='utf-8')
        skill_name = d.name
        desc = 'use when planning assessment needs structured scoring and evidence. not for final approval; do not use for roadmap commitments without human review. this description is intentionally long enough for routing.'
        retired = 'planning-assessment-suite-v' + '1.2.0'
        (t / 'SKILL.md').write_text('---\nname: ' + skill_name + '\ndescription: ' + desc + '\n---\n' + retired + '\n', encoding='utf-8')
        if not any('retired contract or schema token' in e for e in skill_md.collect_errors(t)):
            errors.append('skill-md self-test failed to catch retired prior contract token')
    return errors

def main():
    d = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
    errors = collect_errors(d)
    if errors:
        for e in errors:
            print('ERROR:', e, file=sys.stderr)
        return 1
    print(f'OK: CI guard self-tests passed for {d}')
    return 0
if __name__ == '__main__':
    sys.exit(main())
