#!/usr/bin/env python3
import argparse, csv, re, sys
from pathlib import Path
_B = chr(92)
PRIVATE_NODE_RE = re.compile(_B + 'b' + 'N' + _B + 'd{3}' + _B + 'b', re.IGNORECASE)
ID_PATTERNS={
 'competitor': re.compile(r'^CA-[a-z0-9_]+-\d{3,}$', re.I),
 'benchmark': re.compile(r'^FBK-[a-z0-9_]+-\d{3,}$', re.I),
 'value': re.compile(r'^VAL-[a-z0-9_]+-\d{3,}$', re.I),
 'cost': re.compile(r'^COST-[a-z0-9_]+-\d{3,}$', re.I),
 'risk': re.compile(r'^RISK-[a-z0-9_]+-\d{3,}$', re.I),
 'priority': re.compile(r'^PRIO-[a-z0-9_]+-\d{3,}$', re.I),
 'requirement': re.compile(r'^REQ-[a-z0-9_]+-\d{3,}$', re.I),
}
FIELD_KIND={
 'competitor_insight_id':'competitor','benchmark_id':'benchmark','value_id':'value','cost_id':'cost','risk_id':'risk','priority_id':'priority','requirement_id':'requirement'
}
AUTO_HEADERS={
 'competitor_insight_id':'competitor','benchmark_id':'benchmark','value_id':'value','cost_id':'cost','risk_id':'risk','priority_id':'priority'
}

def read_csv(path):
    with open(path, encoding='utf-8-sig', newline='') as f: return list(csv.DictReader(f))

def add_file(kind,path,ids,errors):
    rows=read_csv(path)
    for i,row in enumerate(rows,1):
        for field,val in row.items():
            text=str(val or '')
            if PRIVATE_NODE_RE.search(text): errors.append(f'{path}: row {i}: private workflow-node code in {field}')
        for field,k in FIELD_KIND.items():
            val=str(row.get(field,'')).strip()
            if val:
                if not ID_PATTERNS[k].match(val): errors.append(f'{path}: row {i}: {field} has invalid id {val!r}')
                ids.setdefault(k,set()).add(val)

def auto_paths(d):
    result=[]
    for p in sorted(Path(d).glob('*.csv')):
        try:
            with open(p,encoding='utf-8-sig',newline='') as f:
                headers=next(csv.reader(f))
        except Exception:
            continue
        for h,k in AUTO_HEADERS.items():
            if h in headers:
                result.append((k,p)); break
    return result

def validate(args):
    errors=[]; warnings=[]; ids={}
    groups={'competitor':args.competitor,'benchmark':args.benchmark,'value':args.value,'cost':args.cost,'risk':args.risk,'priority':args.priority}
    if args.auto:
        for k,p in auto_paths(args.auto): groups.setdefault(k,[]).append(str(p))
    for kind,paths in groups.items():
        for p in paths or []: add_file(kind,Path(p),ids,errors)
    # cross checks
    for p in (args.benchmark or []):
        for i,row in enumerate(read_csv(p),1):
            refs=[x.strip() for x in str(row.get('competitor_insight_ids','')).replace(';',',').split(',') if x.strip()]
            for ref in refs:
                if ref not in ids.get('competitor',set()):
                    msg=f'{p}: row {i}: competitor_insight_id {ref!r} not found in competitor artifacts'
                    (warnings if args.allow_unresolved_cross_refs else errors).append(msg)
    for p in (args.priority or []):
        for i,row in enumerate(read_csv(p),1):
            refs=[x.strip() for x in str(row.get('source_assessment_ids','')).replace(';',',').split(',') if x.strip()]
            if not refs:
                warnings.append(f'{p}: row {i}: source_assessment_ids is empty; standalone use is allowed, but combined planning assessment should reference VAL-*/COST-*/RISK-* rows or route to human_review')
            for ref in refs:
                expected=None
                for kind,pat in ID_PATTERNS.items():
                    if kind!='requirement' and pat.match(ref): expected=kind
                if expected and ref not in ids.get(expected,set()):
                    msg=f'{p}: row {i}: source assessment id {ref!r} not found in provided {expected} artifacts'
                    (warnings if args.allow_unresolved_cross_refs else errors).append(msg)
    return errors,warnings

def main():
    ap=argparse.ArgumentParser()
    for opt in ['competitor','benchmark','value','cost','risk','priority']:
        ap.add_argument('--'+opt, action='append', default=[])
    ap.add_argument('--auto')
    ap.add_argument('--allow-unresolved-cross-refs', action='store_true')
    args=ap.parse_args()
    errors,warnings=validate(args)
    for w in warnings: print('WARN:',w)
    if errors:
        for e in errors: print('ERROR:',e,file=sys.stderr)
        return 1
    print('OK: planning-assessment handoff references are consistent for provided artifacts')
    return 0
if __name__=='__main__': sys.exit(main())
