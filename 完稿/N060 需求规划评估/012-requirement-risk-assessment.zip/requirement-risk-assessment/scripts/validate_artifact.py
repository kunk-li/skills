#!/usr/bin/env python3

import argparse, csv, json, re, sys
from pathlib import Path

CONFIG = {'cn': '需求风险预判',
 'composable': ['requirement-priority-assessment', 'requirement-cost-estimation', 'requirement-value-assessment', 'competitor-analysis', 'competitor-feature-benchmarking'],
 'display': 'Requirement Risk Assessment',
 'enums': {'evidence_status': ['confirmed', 'inferred', 'unverified'],
           'impact': ['high', 'medium', 'low', 'needs_human_review'],
           'likelihood': ['high', 'medium', 'low', 'needs_human_review'],
           'overall_risk': ['high', 'medium', 'low', 'needs_human_review'],
           'recommended_route': ['priority_assessment',
                                 'cost_estimation',
                                 'planning_intake',
                                 'human_review',
                                 'monitor_only'],
           'risk_category': ['implementation',
                             'data',
                             'integration',
                             'release',
                             'collaboration',
                             'rule_policy',
                             'other']},
 'family_role': 'risk_assessment',
 'id_field': 'risk_id',
 'id_re': '^RISK-[a-z0-9_]+-\\d{3,}$',
 'modes': ['early_risk_scan', 'release_risk_scan', 'integration_risk_scan', 'policy_risk_scan', 'low_evidence_risk'],
 'not_for': ['formal launch approval', 'compliance sign-off', 'solution design'],
 'primary': 'requirement-risk-register.csv',
 'recommended': ['exposure_stage', 'owner_hint', 'monitoring_signal', 'fallback_option', 'related_cost_ids'],
 'required': ['risk_id',
              'requirement_id',
              'requirement_summary',
              'risk_category',
              'risk_statement',
              'trigger_condition',
              'consequence',
              'likelihood',
              'impact',
              'overall_risk',
              'evidence_status',
              'mitigation_direction',
              'recommended_route',
              'open_questions'],
 'routes': ['priority_assessment', 'cost_estimation', 'planning_intake', 'human_review', 'monitor_only'],
 'schema': 'planning.requirement-risk-assessment.v4'}
CONTRACT_VERSION = 'planning-assessment-suite-v1.2.1'
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
SECRET_RE = re.compile(r"\b(?:sk|pk|api|secret)[-_][A-Za-z0-9]{12,}\b", re.IGNORECASE)

def read_rows(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def nonempty(v):
    return v is not None and str(v).strip() != ''

def validate(path, strict=False):
    rows = read_rows(path)
    errors=[]; warnings=[]; seen=set()
    if not rows:
        errors.append('artifact has no rows')
        return errors,warnings
    headers = set(rows[0].keys())
    missing_headers = [f for f in CONFIG['required'] if f not in headers]
    if missing_headers:
        errors.append(f'header missing required fields {missing_headers}')
    for idx,row in enumerate(rows,1):
        missing=[f for f in CONFIG['required'] if not nonempty(row.get(f))]
        if missing:
            errors.append(f'row {idx}: missing required fields {missing}')
        rid=str(row.get(CONFIG['id_field'],'')).strip()
        if rid:
            if not re.match(CONFIG['id_re'], rid, re.IGNORECASE):
                errors.append(f"row {idx}: {CONFIG['id_field']} {rid!r} does not match expected pattern {CONFIG['id_re']}")
            if rid in seen:
                errors.append(f"row {idx}: duplicate {CONFIG['id_field']} {rid!r}")
            seen.add(rid)
        for field, allowed in CONFIG['enums'].items():
            value=str(row.get(field,'')).strip()
            if value and value not in allowed:
                errors.append(f"row {idx}: {field} must be one of {allowed}, got {value!r}")
        for field,value in row.items():
            text=str(value or '')
            if PRIVATE_NODE_RE.search(text):
                errors.append(f'row {idx}: private workflow-node code found in {field}')
            if EMAIL_RE.search(text):
                warnings.append(f'row {idx}: possible email in {field}')
            if SECRET_RE.search(text):
                warnings.append(f'row {idx}: possible secret token in {field}')
        conf=str(row.get('confidence','')).strip()
        route=str(row.get('recommended_route','')).strip()
        if conf == 'low' and route not in ('human_review','monitor_only'):
            warnings.append(f'row {idx}: low confidence row should normally route to human_review or monitor_only')
    if strict and warnings:
        errors += [f'strict warning: {w}' for w in warnings]
    return errors,warnings

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('artifact', nargs='?')
    ap.add_argument('--strict', action='store_true')
    ap.add_argument('--summary', action='store_true')
    args=ap.parse_args()
    if args.summary:
        print(json.dumps(CONFIG | {'contract_version': CONTRACT_VERSION}, ensure_ascii=False, indent=2))
        return 0
    if not args.artifact:
        print('ERROR: artifact path required unless --summary is used', file=sys.stderr); return 2
    errors,warnings=validate(Path(args.artifact), args.strict)
    for w in warnings: print('WARN:', w)
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: {CONFIG['display']} artifact valid ({args.artifact})")
    return 0
if __name__=='__main__': sys.exit(main())
