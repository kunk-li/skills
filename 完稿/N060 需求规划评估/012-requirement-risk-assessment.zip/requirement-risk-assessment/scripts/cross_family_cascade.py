#!/usr/bin/env python3
"""
Cross-family end-to-end cascade validator.

Validates that artifacts from the main product-requirement pipeline form a
coherent cascade:

  N005 feedback-loop  →  N010-N040 requirement-definition  →  N050-N060 planning-assessment

Checks:
  1. Each artifact carries the correct contract_version for its family.
  2. downstream_routes / consumer_routes in each artifact contain a token that
     matches the next family's expected intake token.
  3. No artifact's artifact_id appears in its own cross_artifact_refs.
  4. Evidence refs are non-empty at each stage.

Usage:
    python cross_family_cascade.py \\
        --feedback  <N005-artifact.metadata.yaml> \\
        --requirement <N010-N040-artifact.metadata.yaml> \\
        --planning  <N050-N060-artifact.metadata.yaml>

All three arguments are optional; omit a stage to skip its checks.
"""
from __future__ import annotations
import argparse, sys
from pathlib import Path

try:
    import yaml
    def _load(p: Path) -> dict:
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
except ImportError:
    def _load(p: Path) -> dict:  # stdlib fallback
        data: dict = {}
        cur: str | None = None
        for raw in p.read_text(encoding="utf-8").splitlines():
            line = raw.rstrip()
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            if line.startswith("  - ") and cur:
                data.setdefault(cur, []).append(line[4:].strip().strip("\"'"))
            elif ":" in line and not line.startswith(" "):
                k, v = line.split(":", 1)
                k = k.strip(); v = v.strip().strip("\"'")
                data[k] = [] if v == "" else v
                cur = k if v == "" else None
        return data


FAMILY_CONTRACTS = {
    "feedback":    "feedback-loop-suite-v1.4.1",
    "requirement": "requirement-definition-suite-v1.3.0",
    "planning":    "planning-assessment-suite-v1.2.1",
}

HANDOFF_TOKENS = {
    # feedback-loop (N005 DDRM/PSA/UFC) -> requirement-definition (N010-N040)
    # Also accept intra-N005 tokens: UFC may route to PSA/DDRM first
    ("feedback", "requirement"): {
        "intake", "reprioritization", "deduplication", "context_enrichment",
        "planning_intake", "evidence_handoff", "pain_analysis", "journey_analysis",
        # intra-N005 pass-through tokens (UFC -> PSA or UFC -> DDRM)
        "production-signal-aggregation", "data-driven-requirement-mining",
    },
    # requirement-definition (N010-N040) -> planning-assessment (N050-N060)
    # Also accept intra-A tokens: collection may route to dedup/context first
    ("requirement", "planning"): {
        "planning_intake", "value_assessment", "priority_assessment",
        "cost_estimation", "risk_assessment", "pain_analysis",
        "journey_analysis", "feature_benchmarking",
        # intra-A pass-through tokens
        "deduplication", "context_enrichment", "human_review",
    },
}


def _get_md(data: dict) -> dict:
    """Return the metadata sub-dict, unwrapping a 'metadata:' wrapper if present."""
    if "metadata" in data and isinstance(data["metadata"], dict):
        return data["metadata"]
    return data


def _routes(data: dict) -> list[str]:
    md = _get_md(data)
    raw = md.get("downstream_routes") or data.get("downstream_handoff", {}) or {}
    if isinstance(raw, list):
        return [str(r) for r in raw]
    if isinstance(raw, dict):
        cr = raw.get("consumer_routes") or raw.get("consumer_skill_or_node") or []
        if isinstance(cr, list):
            return [str(r) for r in cr]
        if isinstance(cr, str):
            return [cr]
    return []


def check_artifact(path: Path, family: str, errors: list[str]) -> dict:
    data = _load(path)
    md = _get_md(data)
    expected_cv = FAMILY_CONTRACTS[family]

    cv = md.get("contract_version") or data.get("contract_version")
    if cv != expected_cv:
        errors.append(
            f"{path.name} [{family}]: contract_version {cv!r} != expected {expected_cv!r}"
        )

    aid = md.get("artifact_id") or data.get("artifact_id")
    refs = list(md.get("cross_artifact_refs") or data.get("cross_artifact_refs") or [])
    if aid and aid in refs:
        errors.append(f"{path.name} [{family}]: self-reference in cross_artifact_refs ({aid})")

    evs = list(md.get("evidence_refs") or data.get("evidence_refs") or [])
    if not evs:
        errors.append(f"{path.name} [{family}]: evidence_refs is empty")

    return data


def check_handoff(src_path: Path, src_family: str, dst_family: str,
                  src_data: dict, errors: list[str]) -> None:
    routes = _routes(src_data)
    expected_tokens = HANDOFF_TOKENS.get((src_family, dst_family), set())
    if expected_tokens and not any(r in expected_tokens for r in routes):
        errors.append(
            f"{src_path.name} [{src_family}→{dst_family}]: "
            f"no matching handoff token found in downstream_routes {routes}. "
            f"Expected one of: {sorted(expected_tokens)}"
        )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--feedback",    metavar="YAML", help="N005 feedback-loop artifact metadata")
    ap.add_argument("--requirement", metavar="YAML", help="N010-N040 requirement-definition artifact metadata")
    ap.add_argument("--planning",    metavar="YAML", help="N050-N060 planning-assessment artifact metadata")
    args = ap.parse_args()

    if not any([args.feedback, args.requirement, args.planning]):
        ap.print_help()
        return 1

    errors: list[str] = []
    data: dict[str, dict] = {}

    for family, arg in [("feedback", args.feedback),
                         ("requirement", args.requirement),
                         ("planning", args.planning)]:
        if arg:
            p = Path(arg)
            if not p.exists():
                errors.append(f"file not found: {p}")
            else:
                data[family] = check_artifact(p, family, errors)

    if "feedback" in data and "requirement" in data:
        check_handoff(
            Path(args.feedback), "feedback", "requirement",
            data["feedback"], errors
        )
    if "requirement" in data and "planning" in data:
        check_handoff(
            Path(args.requirement), "requirement", "planning",
            data["requirement"], errors
        )

    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        return 1

    stages = [f for f in ["feedback", "requirement", "planning"] if f in data]
    print(f"OK: cross-family cascade passes ({' → '.join(stages)})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
