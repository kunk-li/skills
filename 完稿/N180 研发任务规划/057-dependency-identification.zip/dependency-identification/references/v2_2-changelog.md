# v2.2 changelog: dependency-identification

## Optimized from v2.1复评 residual items

- Updated metadata and integration contract to `artifact_schema_version: n180.v2.2`.
- Added explicit handoff rules to `n180-planning-package-aggregator` for critical path, resource constraints, external dependencies, and risk propagation.
- Kept the v2.1 two-axis dependency model unchanged because the复评 judged it as the best fix.
