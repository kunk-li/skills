# 057 编排说明 v2.2

## 上游优先级

优先复用以下输入：

1. 055 开发任务拆分结果
2. 056 工时估算结果
3. 技术方案分析
4. 数据流图
5. 模块边界图
6. API 清单与契约草稿
7. 表结构与数据迁移方案
8. 非功能与环境准备说明
9. 待决问题清单

## 与 055 的字段映射

| 055 字段 | 057 字段 | 说明 |
|---|---|---|
| task_id | from_task / to_task_or_object | 依赖边锚点 |
| depends_on_hint | dependency edges | 可拆成一对多边 |
| task_kind | dependency_kind/domain hint | T7_spike 常映射 D6_knowledge_dependency + knowledge/decision |
| task_type | dependency_domain hint | db/data/env/test 等提示来源域 |
| priority | blocking_risk | blocker / must_have 往往对应 high |
| evidence | evidence | 保持来源可追踪 |

## 与 056 的协同

- 057 识别到的高风险依赖应进入 056 的 `cost_drivers`、`duration_formula_factors` 或 `notes`。
- 若某依赖固定占用外部窗口，056 需要把它反映到 `duration_calendar_days`。
- 056 若将任务标为 low confidence，通常能在 057 中找到未决依赖或高风险边。
- 057 的 CPM 输出可作为 056 Monte Carlo 的聚合约束。

## 反向约束

- `from_task` 和 `to_task_or_object` 优先引用 055 中存在的 `task_id`，除非对象是外部系统、资源或决策实体。
- 055 中 `depends_on_hint` 至少应是 057 依赖图的子集。
- 055 中 priority=blocker/must_have 的任务，至少应在 057 的依赖表中出现一次，除非无依赖。
- 如果 057 检测到循环依赖，必须回推给 055 调整任务边界或给出人工决策项。

## v2.2 与节点级聚合器的衔接

- `critical_path_analysis`、`resource_constraints`、`external_dependencies[]` 和 `dependency_risk_report` 是 `n180-planning-package-aggregator` 的直接输入。
- 如果 057 输出 `provisional_critical_path: true`，聚合器必须将 N180_planning_package 的 readiness 降为 `constrained`。
- 如果 057 输出 cycle detected 或 unresolved high-risk dependency，聚合器必须将风险清单置顶展示。
