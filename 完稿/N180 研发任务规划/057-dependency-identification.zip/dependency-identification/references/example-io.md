# 057 示例输入输出 v2.2

## 示例输入

基于 CRM 线索去重配置能力的方案、055 任务清单与 056 估算，用户希望识别 wave 1 / wave 2 的依赖关系与关键阻塞。

## 示例输出（节选）

### Metadata

```yaml
metadata:
  selected_mode: full
  readiness: constrained
  function_bias: structured_understanding_result
  workflow_node: N180
  producer_skill: dependency-identification
  node_artifact_target: 研发依赖清单.csv
  artifact_schema_version: n180.v2.2
```

### 主依赖表

| dep_id | dependency_kind | dependency_domain | from_task | to_task_or_object | dep_strength | scope | description | precondition | lag_time | lead_time | blocking_risk | avoidability | effort_to_remove | mitigation | status | owner | expected_ready_date | tracking_status | contact_person | evidence | confidence | mode |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| DEP-001 | D1_finish_to_start | task_sequence | TASK-S1-002 | TASK-S1-003 | strong | backend/frontend | 配置页依赖 API 契约与保存接口完成 | API 字段和错误码冻结 | 0d | 0.5d | high | technical_refactorable | 0.5d | 先冻结契约并提供 mock | confirmed | backend + frontend | n/a | ready | n/a | API 草稿 | high | confirmed |
| DEP-002 | D7_resource_dependency | env_dependency | TASK-S1-004 | 测试环境账号与回归数据 | environment | external | 联调回归依赖测试环境账号和基础数据 | 测试环境账号开通且样例数据导入完成 | 1d | 0d | high | organizational_refactorable | 0.5d | 提前申请账号并准备最小数据集 | 待解决 | qa / infra | 2026-05-10 | in_progress | qa-owner | 联调清单 | medium | constrained |
| DEP-003 | D6_knowledge_dependency | data_decision | TASK-S2-005 | 历史数据回刷策略 | medium | data | 回刷任务占位依赖产品确认全量或增量方案 | 产品确认回刷口径 | unknown | unknown | high | unavoidable | n/a | 本周在方案评审会上定稿 | 待解决 | 产品 + backend | unknown | not_started | product-owner | Q-12 | low | constrained |
| DEP-004 | D2_start_to_start | parallel_enable | TASK-S1-001 | TASK-S1-002;TASK-S1-003 | weak | db/backend/frontend | 规则表与索引完成后，后端和前端可并行推进 | 建表 SQL 通过评审并在测试库验证 | 0d | 1d | low | unavoidable | n/a | 优先完成表结构评审 | 并行 | backend | n/a | ready | n/a | 表结构草稿 | high | confirmed |

### 关键阻塞总览

- DEP-001：API 契约未冻结会阻断前端开发与联调。
- DEP-002：测试环境账号和数据未准备会推迟联调窗口。
- DEP-003：回刷策略未定会阻断 wave 2 数据任务。

### 本周必决清单

1. 冻结规则配置 API 契约与错误码。
2. 确认测试环境账号申请人和最小样例数据准备人。
3. 决定历史数据回刷采用全量还是增量策略。

### 关键路径分析

若 056 已提供 duration，可输出：

| task_id | earliest_start | earliest_finish | latest_start | latest_finish | slack | float_interpretation |
|---|---|---|---|---|---|---|
| TASK-S1-001 | D0 | D2 | D0 | D2 | 0d | zero |
| TASK-S1-002 | D2 | D5 | D2 | D5 | 0d | zero |
| TASK-S1-003 | D5 | D8 | D5 | D8 | 0d | zero |
| TASK-S1-004 | D8 | D12 | D8 | D12 | 0d | zero |
