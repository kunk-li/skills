# Output Template: 研发依赖清单 v2.2

## 默认交付结构

### 1. Metadata

```yaml
metadata:
  selected_mode: full
  readiness: pass | constrained | blocked | provisional
  function_bias: structured_understanding_result
  workflow_node: N180
  producer_skill: dependency-identification
  node_artifact_target: 研发依赖清单.csv
  artifact_schema_version: n180.v2.2
  contract_status:
    schema_valid: true | false
    self_check_passed: true | false
    blocking_issues: []
  n190_handoff:
    060_selected_mode: implement | guarded_reference_only | not_applicable
    implementable_core_flow_count: 0
    scoped_deferred_features: []
```

### 2. 识别范围与 readiness

先说明当前覆盖的材料、主要盲区，以及 readiness：pass / constrained / blocked / provisional。

### 3. 主依赖表

默认输出以下列：

| 列名 | 含义 | 允许值 / 备注 |
|---|---|---|
| dep_id | 依赖 ID | `DEP-001` |
| dependency_kind | v2 关系类型 | D1_finish_to_start / D2_start_to_start / D3_finish_to_finish / D4_start_to_finish / D5_data_dependency / D6_knowledge_dependency / D7_resource_dependency |
| dependency_domain | 依赖来源域 | 16 类 taxonomy |
| from_task | 来源任务 | task_id、问题 ID 或模块名 |
| to_task_or_object | 目标任务 / 对象 | task_id、外部系统、团队或决策对象 |
| dep_strength | 强度 | strong / medium / weak / environment |
| scope | 范围 | infra / db / backend / frontend / external / architecture / compliance 等 |
| description | 描述 | 一句话说明关系 |
| precondition | 前置条件 | 依赖解除或可推进的条件 |
| lag_time | 延迟 | from 完成到 to 可开始的延迟；未知填 unknown |
| lead_time | 提前量 | to 可提前启动的时间；未知填 unknown |
| blocking_risk | 阻塞风险 | high / medium / low |
| avoidability | 可避免性 | unavoidable / technical_refactorable / organizational_refactorable / artificial |
| effort_to_remove | 去依赖成本 | 对可移除依赖必填；否则可填 n/a |
| mitigation | 缓解方案 | 具体动作，不写套话 |
| status | 状态 | confirmed / 待解决 / 等待 / 并行 |
| owner | 责任角色 | 角色或团队 |
| expected_ready_date | 预计就绪日期 | 外部依赖建议必填；未知填 unknown |
| tracking_status | 跟踪状态 | not_started / in_progress / ready / delayed / unknown |
| contact_person | 联系人 | 外部依赖建议必填；未知填 unknown |
| evidence | 证据锚点 | 上游方案段落、task_id、API、表 |
| confidence | 置信度 | high / medium / low |
| mode | 模式 | confirmed / inferred / constrained / blocked |
| resolution_class | N190 释放分类 | pre_code_decidable / brownfield_code_extractable / implementation_layer_owned / true_owner_product_blocker |
| blocks_scope | 阻塞范围 | function / api_surface / adapter / data_migration / whole_d_code |
| handoff_to_060 | 给 060 的输入类型 | required_rule / current_state_decision / compatibility_decision / implementation_decision / made_by_implement_layer / deferred_blocked |
| made_by | 决策方 | implement_layer / product_owner / external_owner / existing_code |

### 4. 关键路径分析

在 full / risk_mode 下输出：

| task_id | earliest_start | earliest_finish | latest_start | latest_finish | slack | float_interpretation |
|---|---|---|---|---|---|---|

并给出：

- `total_project_duration`
- `critical_path_tasks`
- `near_critical_paths`
- `multi_critical_paths.exists`
- `provisional_critical_path: true/false`

### 5. Float analysis

| task_id | total_float | free_float | float_interpretation |
|---|---|---|---|

解释：

- `zero`: 关键路径，任何延期会影响项目。
- `small`: 浮动有限，需要监控。
- `large`: 可调度，适合吸收资源冲突。

### 6. Resource constraints

| resource_name | resource_type | capacity | tasks_needing_resource | conflict_description | resolution |
|---|---|---|---|---|---|

resolution 允许值：`serialize / add_resource / reduce_scope / reschedule / unknown`。

### 7. External dependencies

| dep_id | external_party | dependency_type | expected_ready_date | current_status | last_updated | contact_person | blocker_severity | mitigation_plan | fallback_plan |
|---|---|---|---|---|---|---|---|---|---|

### 8. 关键阻塞总览

单独列出：

- `status=待解决` 或 `tracking_status=delayed`
- 且 `blocking_risk=high`

### 9. 本周必决清单

将需要产品、架构、安全、外部团队在本周决策的问题单列出来，供 PM 或周会使用。

### 10. 并行使能点

单独列出 `dependency_domain=parallel_enable` 或能显著释放并行度的依赖，例如：

- 测试环境准备完成
- API 契约冻结
- 共享组件发布完成

### 11. Codegen dependency resolution

单独列出所有影响 N190/D-code 的依赖：

| dep_id | resolution_class | affected_feature_or_api | blocks_scope | handoff_to_060 | owner | made_by | mitigation | evidence |
|---|---|---|---|---|---|---|---|---|

规则：

- A/B/C 类依赖不得 `deferred_blocked`，不得 `blocks_scope=whole_d_code`。
- `implementation_layer_owned` 必须 `made_by=implement_layer`。
- `true_owner_product_blocker` 必须有 owner，只能 scoped block。

### 12. N190 handoff

```yaml
downstream_handoff:
  N190:
    060_selected_mode: implement
    implementation_decision_ledger_refs: []
    scoped_deferred_features: []
    forbidden_whole_phase_block_reason: "N150/API gate fail alone cannot block whole D-code when implementable flows remain."
```

## 最低覆盖要求

- 如果结果只覆盖 1-2 类来源域，通常不算完整，除非场景很简单并已解释。
- 默认扫描全部 16 类来源域；实际输出不要求硬凑 8 类。
- 不能只识别技术串行关系，忽略 PRD、合规、环境、资源和决策型依赖。
- 不能把 decision/prd_gap/architecture_decision 一律当 hard blocker；必须先做 `resolution_class`，A/B/C 类释放给 060 implement。
