# v2.1 changelog: dependency-identification

## Optimized from v2 analysis

- Changed `function_bias` from `direct_result` to `structured_understanding_result` to align with the skill table's understanding-support role.
- Resolved taxonomy conflict by introducing two required fields: `dependency_kind` (D1-D7 canonical relationship) and `dependency_domain` (16 source domains).
- Replaced legacy avoidability labels with v2 canonical `unavoidable / technical_refactorable / organizational_refactorable / artificial` and documented aliases.
- Added lag_time and lead_time requirements.
- Added CPM, float, Tarjan cycle detection, resource leveling, and artificial dependency detection instructions.
- Added external dependency tracking fields: expected_ready_date, current_status, last_updated, contact_person, mitigation_plan, fallback_plan.
- Changed minimum coverage rule from hard "8 classes" to full 16-domain scan with explanation if few domains appear.
- Added machine-readable rules with `on_violation` actions.
