# 057 常见失败模式 v2.2

## F1. 只识别技术依赖

症状：只列接口先后顺序，漏掉 PRD、合规、环境、资源和跨团队窗口。

修正：强制按 16 类 dependency_domain 全面扫描。

## F2. dependency_kind 与 dependency_domain 混用

症状：把 `cross_team` 填到 dependency_kind，或把 `D1_finish_to_start` 填到 dependency_domain。

修正：dependency_kind 写 D1-D7 排期/逻辑关系；dependency_domain 写依赖来源域。

## F3. 所有依赖都标成 strong

症状：依赖很多，但无法分辨真正的阻塞链。

修正：把环境、弱依赖、并行前提与强阻塞区分开，并单列 blocking_risk。

## F4. 待解决依赖没有 owner 或 tracking

症状：知道有风险，但不知道谁来推动，也没有状态。

修正：至少给责任角色或建议 owner；外部依赖补 expected_ready_date、current_status、last_updated、contact_person。

## F5. 缓解方案空泛

症状：只写“尽快推进”“加强沟通”。

修正：写成具体动作，例如“本周冻结 API 契约”“先用 mock 降低联调等待”。

## F6. 忽视正向并行使能点

症状：只写阻塞，不写哪些准备项完成后可并行推进。

修正：把环境就绪、契约冻结、公共组件发布等对象单列为 `parallel_enable`。

## F7. 未检测依赖环

症状：A 依赖 B，B 又依赖 A，却继续输出关键路径。

修正：使用 Tarjan SCC 或拓扑排序检测环；发现环后标 blocked 并要求人工修复。
