# 依赖分类体系 v2.2

057 同时使用两层分类，避免把“排期关系”和“依赖来源”混成一个字段。

## A. dependency_kind: v2 canonical 依赖关系类型

`dependency_kind` 描述 from 与 to 的调度/逻辑关系，必须使用 D1-D7：

1. `D1_finish_to_start`：from 完成后，to 才能开始。示例：API 设计完成 -> Controller 实现开始。
2. `D2_start_to_start`：from 开始后，to 才能开始。示例：测试计划开始 -> 测试实施开始。
3. `D3_finish_to_finish`：from 完成前，to 必须完成。示例：集成测试完成前，用户文档必须完成。
4. `D4_start_to_finish`：from 开始前，to 必须完成。少见，仅在切换/下线场景使用。
5. `D5_data_dependency`：to 需要 from 产出的数据、schema、样本或迁移结果。
6. `D6_knowledge_dependency`：to 需要 from 产出的知识、调研、POC 或决策记录。
7. `D7_resource_dependency`：to 受共享人、技能、环境、license、设备等资源约束。

## B. dependency_domain: 16 类依赖来源域

`dependency_domain` 描述依赖来自哪里。默认优先从以下目录中选用最贴切的类型；必要时可补充子类，但不要随意发明含糊标签。

1. `task_sequence`：任务间严格串行
2. `data_dependency`：依赖数据准备、回刷、迁移或同步
3. `platform_enablement`：平台、中间件、基础设施前置
4. `cross_team`：跨团队配合、接口排期、评审窗口
5. `architecture_decision`：架构方案待决
6. `security_decision`：安全评审、鉴权策略、脱敏方案待决
7. `data_decision`：口径、主数据、数据保留策略待决
8. `prd_gap`：需求缺口、规则缺失、业务口径不明
9. `env_dependency`：测试、预发、网络、密钥、账号等环境准备
10. `test_dependency`：测试数据、测试工具、回归资源
11. `monitoring`：日志、指标、告警、可观测性准备
12. `documentation`：设计文档、接口文档、操作手册缺失
13. `compliance`：法务、隐私、审计、合规签字
14. `ux_dependency`：设计稿、交互稿、文案确认
15. `knowledge`：信息待确认、历史实现未知、领域知识空白
16. `parallel_enable`：能够释放并行度的正向使能点

## C. 使用规则

- 每条依赖都必须同时填写 `dependency_kind` 与 `dependency_domain`。
- `parallel_enable` 是正向依赖，不是阻塞项；但它应单独列出，帮助团队找并行机会。
- 若最终覆盖来源域少于 4 类，需要解释是材料过少还是场景确实简单。
- 不再使用旧的单字段 `dep_type` 作为权威分类；如果用户输入中有 `dep_type`，将其映射为 `dependency_domain`。

## D. 常见映射

| 输入旧标签 | dependency_kind | dependency_domain |
|---|---|---|
| task_output | D1_finish_to_start | task_sequence |
| resource_constraint | D7_resource_dependency | platform_enablement / env_dependency |
| knowledge_transfer | D6_knowledge_dependency | knowledge |
| external_team | D1_finish_to_start 或 D2_start_to_start | cross_team |
| environmental | D7_resource_dependency | env_dependency |
| decision | D6_knowledge_dependency | architecture_decision / data_decision / security_decision |
| approval | D1_finish_to_start | compliance |
