# 057 交付检查清单 v2.2

## A. 覆盖范围

- [ ] 已覆盖技术依赖之外的跨团队、环境、资源、决策或合规依赖。
- [ ] 已说明识别范围与材料盲区。
- [ ] 已扫描 16 类 dependency_domain，输出少时已解释原因。

## B. 依赖质量

- [ ] 每条依赖都有明确的 `from_task` 和 `to_task_or_object`。
- [ ] 每条依赖同时包含 `dependency_kind` 与 `dependency_domain`。
- [ ] `dep_strength` 与 `blocking_risk` 已区分。
- [ ] 每条依赖都有 `avoidability`。
- [ ] lag_time 与 lead_time 已填写或标 unknown。
- [ ] 高风险依赖有前置条件与缓解方案。
- [ ] 待解决依赖有 owner 或建议 owner。

## C. CPM 与 float

- [ ] full/risk_mode 下已计算或说明 provisional critical path。
- [ ] 已检测循环依赖。
- [ ] 已输出 total_float / free_float 或说明缺少 duration。
- [ ] near critical path 已识别或说明不存在。

## D. 资源与外部依赖

- [ ] 资源冲突有 resolution。
- [ ] 外部依赖有 expected_ready_date 或 unknown。
- [ ] 外部依赖有 current_status、last_updated、contact_person 或 unknown。
- [ ] 高风险外部依赖有 mitigation_plan 与 fallback_plan。

## E. 结果可执行性

- [ ] 已单列关键阻塞总览。
- [ ] 已单列本周必决清单。
- [ ] 已标出并行使能点。
- [ ] 没有把所有依赖都打成 strong。

## F. 跨 skill 对齐

- [ ] 来自 055 的 task_id 可直接回指。
- [ ] 与 056 的风险表达保持一致。
- [ ] blocker 任务在依赖图中能找到对应边。
