---
name: dependency-identification
description: identify scheduling, data, knowledge, resource, external-team, environment, decision, and approval dependencies from technical solution notes, architecture outputs, task breakdowns, estimates, or mixed planning materials. use when chatgpt works in technical solution design / task management and must produce the n180 研发依赖清单.csv for implementation scheduling, review coordination, test planning, release preparation, staffing decisions, or project risk tracking.
---
# dependency-identification

## Role / 角色定位
本 skill 对齐 `skills_workflow_v2` 中的「技术方案设计 -> 任务管理 -> 研发依赖清单」。

它是 **structured_understanding_result** 型技能：目标是把任务、资源、外部团队与环境约束组织成可消费的 **`研发依赖清单.csv`**，帮助团队理解依赖结构、关键路径、浮动时间与高风险阻塞。

### Boundary / 边界
- 负责识别任务依赖、数据依赖、知识依赖、资源依赖、外部依赖、环境依赖、决策依赖与审批依赖。
- 负责判断依赖是否必要、是否可避免，并识别关键路径、浮动时间、资源冲突和外部依赖跟踪项。
- 不负责重新拆任务；任务对象本身优先来自 `development-task-breakdown`。
- 不负责正式工时估算；工期计算需要尽量复用 `effort-estimation-assistant` 的 duration 输入。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `lightweight`：仅输出任务到任务的主依赖关系，可省略 CPM，但必须保留 dependency_kind/domain 与 avoidability。
- `full`：默认模式，覆盖任务、资源、外部团队、环境，并计算关键路径与浮动时间。
- `risk_mode`：聚焦高风险依赖、关键路径上的外部瓶颈、资源冲突和本周必决项。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `模块边界图.md`
- `服务拆分建议.md`
- `数据流图.md`

### 节点内最强输入
- `开发任务拆分表.csv`
- `工时估算表.csv`

### 可选增强输入
- 资源池信息、团队 availability、环境就绪计划
- 外部团队 SLA、审批流、合规窗口
- 发布节奏、联调窗口、关键里程碑
- 测试环境、监控、数据迁移或安全评审计划

## Standalone rule / 独立使用规则
即使只有技术方案与高层任务，也可以单独使用。

降级规则：
- 若没有标准任务表，可先输出模块级或里程碑级依赖图。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的依赖边。
- 若缺少 duration 或资源信息，不得伪造精确关键路径总时长，只能输出 provisional path。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: structured_understanding_result`
  - `stage_position: technical_solution_design.task_management.dependency_identification`
  - `workflow_node: N180`
  - `producer_skill: dependency-identification`
  - `node_artifact_target: 研发依赖清单.csv`
  - `artifact_schema_version: n180.v2.2`
  - `evidence_profile`
  - `contract_status`
  - `event_emission`
- `dependency_registry[]`
- `critical_path_analysis`
- `float_analysis[]`
- `resource_constraints`
- `external_dependencies[]`
- `avoidable_dependencies[]`
- `blocker_dependencies[]`
- `dependency_risk_report`
- `downstream_handoff`
- `self_check`

### Required dependency fields / 必填字段
每条依赖至少包含：
- `dep_id`
- `from_task`
- `to_task_or_object`
- `dependency_kind`，使用 v2 canonical D1-D7 调度/关系枚举
- `dependency_domain`，使用 16 类来源域 taxonomy
- `dep_strength`
- `blocking_risk`
- `avoidability`
- `lag_time`
- `lead_time`
- `owner`
- `prerequisite`
- `mitigation`
- `confidence`
- `mode`

## Design rules / 设计规则
### Dependency kind / v2 canonical 依赖关系类型
`dependency_kind` 描述排期或逻辑关系，必须使用以下之一：
- `D1_finish_to_start`：from 完成后 to 才能开始。
- `D2_start_to_start`：from 开始后 to 才能开始。
- `D3_finish_to_finish`：from 完成前 to 必须完成。
- `D4_start_to_finish`：from 开始前 to 必须完成，少见。
- `D5_data_dependency`：to 需要 from 产出的数据。
- `D6_knowledge_dependency`：to 需要 from 产出的知识、调研或决策。
- `D7_resource_dependency`：to 受共享人、技能、环境、license 等资源约束。

### Dependency domain / 依赖来源域
`dependency_domain` 描述依赖来自哪里，必须优先使用 `references/dependency-taxonomy.md` 的 16 类：`task_sequence / data_dependency / platform_enablement / cross_team / architecture_decision / security_decision / data_decision / prd_gap / env_dependency / test_dependency / monitoring / documentation / compliance / ux_dependency / knowledge / parallel_enable`。

### Avoidability discipline / 可避免性纪律
每条依赖必须标为以下之一：
- `unavoidable`
- `technical_refactorable`
- `organizational_refactorable`
- `artificial`

旧标签映射：`necessary -> unavoidable`，`designed -> technical_refactorable`，`scheduling -> organizational_refactorable`，`artificial -> artificial`。

对 `technical_refactorable / organizational_refactorable / artificial` 必须给出去耦或并行化建议；对可移除依赖给出 `effort_to_remove`。

### Lag / lead discipline
每条边都要填写：
- `lag_time`：from 完成到 to 可开始的延迟。
- `lead_time`：from 未完成时 to 可提前开始的时间。

未知时填 `unknown`，不要留空。

### Critical path discipline / 关键路径纪律
在 `full` 或 `risk_mode` 下，必须输出：
- `critical_path_tasks`
- `earliest_start / earliest_finish`
- `latest_start / latest_finish`
- `slack`
- `total_project_duration`
- `near_critical_paths`
- `multi_critical_paths.exists`

若缺少 duration 数据，必须明确标记 `provisional_critical_path`。

### Float discipline / 浮动时间纪律
在可计算时，为每个主要任务提供：
- `total_float`
- `free_float`
- `float_interpretation`: zero / small / large

### Resource and external dependency discipline
当资源池或外部依赖已知时，必须额外识别：
- 单资源过载
- 专家瓶颈
- 环境排他冲突
- 外部团队时窗冲突
- expected_ready_date
- actual_readiness_tracking.current_status / last_updated / contact_person
- mitigation_plan
- fallback_plan

## Algorithms / 算法纪律
- `critical_path_method`: 构建 DAG -> forward pass -> backward pass -> slack 计算 -> slack=0 的路径为关键路径。
- `cycle_detection`: 使用 Tarjan SCC 或等效拓扑检测；发现环必须报告并要求人工修复。
- `float_calculation`: `total_float = latest_finish - earliest_finish`，`free_float = earliest_start(successor) - earliest_finish(self)`。
- `resource_leveling`: 优先保护关键路径，非关键路径可推迟以缓解资源冲突。
- `artificial_dependency_detection`: 无实际数据、代码、知识、审批或资源约束的依赖应标 artificial 并建议移除。

## Machine-readable rules / 机读门禁规则
- `R01_dependency_kind_required`: 必须有 D1-D7 `dependency_kind`; `on_violation: reject`。
- `R02_dependency_domain_required`: 必须有 16 类 `dependency_domain`; `on_violation: reject`。
- `R03_avoidability_assessed`: 必须评估 avoidability; `on_violation: reject`。
- `R04_artificial_should_be_removed`: artificial 必须 remove 或 justify; `on_violation: reject`。
- `R05_no_cycles`: 依赖图无环; `on_violation: reject`。
- `R06_critical_path_identified`: full/risk_mode 必须识别关键路径或标 provisional; `on_violation: reject`。
- `R07_external_has_tracking`: 外部依赖必须有 tracking + contact 或说明未知; `on_violation: reject`。
- `R08_resource_conflicts_resolved`: 资源冲突必须有 resolution; `on_violation: reject`。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 优先消费 `开发任务拆分表.csv` 与 `工时估算表.csv`；若缺失，则从方案推导粗粒度交付对象。
3. 先确定 `dependency_kind`，再确定 `dependency_domain`。
4. 判断 `dep_strength`、`blocking_risk`、`avoidability`、lag/lead 与 owner。
5. 对可移除或可并行依赖给出去耦建议与 `effort_to_remove`。
6. 检测循环依赖；发现环时标 blocked，不继续伪算关键路径。
7. 若 duration 已知，计算 `critical_path_analysis` 与 `float_analysis[]`。
8. 若资源信息已知，生成 `resource_constraints` 与冲突 resolution。
9. 若存在外部依赖，生成可跟踪 `external_dependencies[]`。
10. 汇总 `blocker_dependencies[]`、`avoidable_dependencies[]` 与 `dependency_risk_report`。
11. 形成面向 N180 标准产物的 **`研发依赖清单.csv`**。
12. 输出 `downstream_handoff`，供 056 反向修正 duration，也供 N190 / N220 / N240 / N270 / N330 / N350 消费。
13. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小型项目：覆盖所有显性前置依赖。
- 中型项目：覆盖全部关键路径候选、外部依赖与资源瓶颈。
- 大型项目：优先覆盖关键链、近关键链、审批与环境时窗冲突。

## Quality bar / 质量门槛
合格结果应能直接支撑排期、资源调度与风险沟通，而不需要再做一次“哪些依赖最危险”的人工重算。

## Reference files / 参考文件
- `references/output-template.md`
- `references/dependency-taxonomy.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/n180-integration-map.md`
- `references/v2_1-changelog.md`
- `references/v2_2-changelog.md`
