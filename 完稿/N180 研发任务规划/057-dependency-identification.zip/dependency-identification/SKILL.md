---
name: dependency-identification
description: Identify scheduling, data, knowledge, resource, external-team, environment, decision, and approval dependencies from solution notes, task breakdowns, and estimates; produces 研发依赖清单.csv.
---
# dependency-identification

## Role / 角色定位
本 skill 对齐 `skills_workflow_v2` 中的「技术方案设计 -> 任务管理 -> 研发依赖清单」。

它是 **structured_understanding_result** 型技能：目标是把任务、资源、外部团队与环境约束组织成可消费的 **`研发依赖清单.csv`**，帮助团队理解依赖结构、关键路径、浮动时间与高风险阻塞。

### Boundary / 边界
- 负责识别任务依赖、数据依赖、知识依赖、资源依赖、外部依赖、环境依赖、决策依赖与审批依赖。
- 负责判断依赖是否必要、是否可避免，并识别关键路径、浮动时间、资源冲突和外部依赖跟踪项。
- 不负责重新拆任务；任务对象本身优先来自 `development-task-breakdown`。
- 不负责正式工时估算；工期计算需要尽量复用 `effort-estimation-assistant` 的 duration 输入。
- 负责对影响 N190/D-code 的依赖做释放分类：可前置判定、可代码提取、实现层可自裁的依赖必须释放给 060 implement，不能变成 whole D-code blocker。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `lightweight`：仅输出任务到任务的主依赖关系，可省略 CPM，但必须保留 dependency_kind/domain 与 avoidability。
- `full`：默认模式，覆盖任务、资源、外部团队、环境，并计算关键路径与浮动时间。
- `risk_mode`：聚焦高风险依赖、关键路径上的外部瓶颈、资源冲突和本周必决项。


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 完整任务清单 + 模块边界 + 团队结构 + 外部依赖来源 全部齐备 | 完整 D1-D7 dependency_kind + 16 类 domain + 关键路径 |
| `provisional` | 任务齐备但缺外部依赖跟踪信息 | 输出依赖图，external 依赖进 pending_tracking[] |
| `constrained` | 仅有部分任务，模块边界不清 | 仅输出可识别依赖，标 partial_coverage |
| `blocked` | 仅有项目描述，无任务清单 | 输出 `request_for_inputs[]` |

## Primary inputs / 主要输入
### workflow 对齐的推荐输入（节点内最强）
- `开发任务拆分表.csv` — 任务主数据，关键路径和依赖的主键来源
- `工时估算表.csv` — duration 数据，CPM 计算的前提
- `技术方案分析.md` — 技术边界和模块交互
- `模块边界图.md` — 模块依赖的拓扑依据
- `服务拆分建议.md` — 跨服务依赖识别
- `数据流图.md` — **数据依赖（D5）的一级来源**；当提供此文件时，必须将数据流中的生产者→消费者关系转化为 `D5_data_dependency` 类型的依赖边

### 可选增强输入
- 资源池信息、团队 availability、环境就绪计划
- 外部团队 SLA、审批流、合规窗口
- 发布节奏、联调窗口、关键里程碑
- 测试环境、监控、数据迁移或安全评审计划
- 消息队列/事件 topic 配置（用于 D8_event_dependency 建模）

## Standalone rule / 独立使用规则
即使只有纯文字描述（无 CSV、无 YAML），也可以单独使用本 skill。最小输入为以下之一：
- `开发任务拆分表.csv`（首选）
- 包含任务或交付物的纯文字描述
- `技术方案分析.md` 或 `模块边界图.md`

降级规则（详见 `references/dependency-input-contract.yaml`）：
- **纯文字输入**：从文字中提取里程碑/交付物，输出模块级 D1 依赖图；所有边标 `inferred`，`confidence: low`；设置 `text_only_degradation_applied: true`，`readiness: provisional`，`mode: lightweight`；在 `request_for_inputs[]` 中引导用户先运行 `development-task-breakdown`。
- **无结构化任务表**：输出模块级或里程碑级依赖图；`readiness: provisional`。
- **有任务表但无 duration**：构建完整依赖图，CPM 仅输出拓扑顺序，不输出数字总时长；标 `provisional_critical_path`。
- **有任务表 + duration，无外部信息**：完整 CPM；外部依赖进 `pending_tracking[]`；`readiness: provisional`。
- **所有推荐输入齐备**：完整输出；`readiness: pass`。
- 顶部必须标明 `readiness`；必须区分 `confirmed / inferred / pending` 的依赖边；不得伪造精确关键路径总时长。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: structured_understanding_result`
  - `stage_position: technical_solution_design.task_management.dependency_identification`
  - `workflow_node: N180`
  - `producer_skill: dependency-identification`
  - `node_artifact_target: 研发依赖清单.csv`
  - `artifact_schema_version: n180.v2.2`
  - `evidence_profile`
  - `contract_status`
  - `event_emission`
- `dependency_registry[]`
- `critical_path_analysis`
- `float_analysis[]`
- `resource_constraints`
- `external_dependencies[]`
- `avoidable_dependencies[]`
- `blocker_dependencies[]`
- `codegen_dependency_resolution[]`
- `dependency_risk_report`
- `downstream_handoff`
- `self_check`

### Required dependency fields / 必填字段
每条依赖至少包含：
- `dep_id`
- `from_task`
- `to_task_or_object`
- `dependency_kind`，使用 v2 canonical D1-D7 调度/关系枚举
- `dependency_domain`，使用 16 类来源域 taxonomy
- `dep_strength`
- `blocking_risk`
- `avoidability`
- `lag_time`
- `lead_time`
- `owner`
- `prerequisite`
- `mitigation`
- `confidence`
- `mode`

## Design rules / 设计规则
### Dependency kind / v2 canonical 依赖关系类型
`dependency_kind` 描述排期或逻辑关系，必须使用以下之一：
- `D1_finish_to_start`：from 完成后 to 才能开始。
- `D2_start_to_start`：from 开始后 to 才能开始。
- `D3_finish_to_finish`：from 完成前 to 必须完成。
- `D4_start_to_finish`：from 开始前 to 必须完成，少见。
- `D5_data_dependency`：to 需要 from 产出的数据。
- `D6_knowledge_dependency`：to 需要 from 产出的知识、调研或决策。
- `D7_resource_dependency`：to 受共享人、技能、环境、license 等资源约束。
- `D8_event_dependency`：to 依赖 from 通过消息队列/事件总线发布的异步事件（如 Kafka topic、RabbitMQ queue、SNS/SQS），必须额外记录 `event_topic`、`expected_latency`、`schema_version` 和 `fallback_if_topic_unavailable`。

### Dependency domain / 依赖来源域
`dependency_domain` 描述依赖来自哪里，必须优先使用 `references/dependency-taxonomy.md` 的 16 类：`task_sequence / data_dependency / platform_enablement / cross_team / architecture_decision / security_decision / data_decision / prd_gap / env_dependency / test_dependency / monitoring / documentation / compliance / ux_dependency / knowledge / parallel_enable`。

### Codegen dependency resolution / N190 依赖释放分类

每条影响 N190/D-code 的依赖必须写 `resolution_class`：

- `pre_code_decidable`：前置 artifact 已能判定，转成 060 required rule。
- `brownfield_code_extractable`：授权目标项目代码可提取，转成 current-state / compatibility decision。
- `implementation_layer_owned`：实现层能用工程判断决定，标 `made_by=implement_layer`。
- `true_owner_product_blocker`：产品/合规/外部 owner 才能拍，只阻塞受影响功能。

`decision / architecture_decision / data_decision / security_decision / prd_gap` 不是天然 hard blocker。若依赖属于前三类，必须写 `handoff_to_060`，不得 `deferred_blocked`，不得 `blocks_scope=whole_d_code`。只要 `implementable_core_flow_count > 0`，`downstream_handoff.N190.060_selected_mode` 必须是 `implement`。

### Avoidability discipline / 可避免性纪律
每条依赖必须标为以下之一：
- `unavoidable`
- `technical_refactorable`
- `organizational_refactorable`
- `artificial`

旧标签映射：`necessary -> unavoidable`，`designed -> technical_refactorable`，`scheduling -> organizational_refactorable`，`artificial -> artificial`。

对 `technical_refactorable / organizational_refactorable / artificial` 必须给出去耦或并行化建议；对可移除依赖给出 `effort_to_remove`。

### Lag / lead discipline
每条边都要填写：
- `lag_time`：from 完成到 to 可开始的延迟。
- `lead_time`：from 未完成时 to 可提前开始的时间。

未知时填 `unknown`，不要留空。

### Critical path discipline / 关键路径纪律
在 `full` 或 `risk_mode` 下，必须输出：
- `critical_path_tasks`
- `earliest_start / earliest_finish`
- `latest_start / latest_finish`
- `slack`
- `total_project_duration`
- `near_critical_paths`
- `multi_critical_paths.exists`

若缺少 duration 数据，必须明确标记 `provisional_critical_path`。

### Float discipline / 浮动时间纪律
在可计算时，为每个主要任务提供：
- `total_float`
- `free_float`
- `float_interpretation`: zero / small / large

### Resource and external dependency discipline
当资源池或外部依赖已知时，必须额外识别：
- 单资源过载
- 专家瓶颈
- 环境排他冲突
- 外部团队时窗冲突
- expected_ready_date
- actual_readiness_tracking.current_status / last_updated / contact_person
- mitigation_plan
- fallback_plan

## Algorithms / 算法纪律
- `critical_path_method`: 构建 DAG -> forward pass -> backward pass -> slack 计算 -> slack=0 的路径为关键路径。
- `cycle_detection`: 使用 Tarjan SCC 或等效拓扑检测；发现环必须报告并要求人工修复。
- `float_calculation`: `total_float = latest_finish - earliest_finish`，`free_float = earliest_start(successor) - earliest_finish(self)`。
- `resource_leveling`: 优先保护关键路径，非关键路径可推迟以缓解资源冲突。
- `artificial_dependency_detection`: 无实际数据、代码、知识、审批或资源约束的依赖应标 artificial 并建议移除。

## Machine-readable rules / 机读门禁规则
- `R01_dependency_kind_required`: 必须有 D1-D7 `dependency_kind`; `on_violation: reject`。
- `R02_dependency_domain_required`: 必须有 16 类 `dependency_domain`; `on_violation: reject`。
- `R03_avoidability_assessed`: 必须评估 avoidability; `on_violation: reject`。
- `R04_artificial_should_be_removed`: artificial 必须 remove 或 justify; `on_violation: reject`。
- `R05_no_cycles`: 依赖图无环; `on_violation: reject`。
- `R06_critical_path_identified`: full/risk_mode 必须识别关键路径或标 provisional; `on_violation: reject`。
- `R07_external_has_tracking`: 外部依赖必须有 tracking + contact 或说明未知; `on_violation: reject`。
- `R08_resource_conflicts_resolved`: 资源冲突必须有 resolution; `on_violation: reject`。
- `R13_codegen_resolution_class_required`: every dependency affecting N190/D-code has `resolution_class` in `pre_code_decidable / brownfield_code_extractable / implementation_layer_owned / true_owner_product_blocker`; `on_violation: reject`。
- `R14_non_owner_dependency_not_whole_blocker`: dependencies with resolution_class A/B/C must hand off to 060 and must not set `blocks_scope=whole_d_code` or `deferred_blocked`; `on_violation: reject`。
- `R15_implementable_flows_force_060_implement`: if implementable core flows remain, `downstream_handoff.N190.060_selected_mode` must be `implement`; `on_violation: reject`。

## Tech stack adapter / 技术栈适配

本 skill 不依赖特定编程语言，产物为结构化 CSV/Markdown。以下适配说明适用于不同技术生态的输入解读：

| 输入来源 | 输入格式特点 | 适配说明 |
|---|---|---|
| Java/Spring | Maven/Gradle 模块、@Service/@Repository 分层 | 按 controller/service/repository/entity 拆层任务 |
| TypeScript/Node | npm workspace / nx monorepo | 按 routes/service/repository/model 拆层 |
| Python/Django-FastAPI | pyproject.toml / poetry；views/serializers/models | 按 view/serializer/service/model 拆层 |
| Go | cmd/ + internal/ + pkg/ 布局 | 按 handler/usecase/repository/domain 拆层 |
| Kotlin/Spring | 同 Java；data class 替代 POJO | 同 Java 分层策略 |
| 多语言混合 | 微服务各有独立技术栈 | 每服务独立拆层；跨服务依赖记入 D5/D6 |

当技术栈未声明时：`tech_stack_declaration: pending`；不假设为 Java。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 优先消费 `开发任务拆分表.csv` 与 `工时估算表.csv`；若缺失，则从方案推导粗粒度交付对象。
3. 先确定 `dependency_kind`，再确定 `dependency_domain`。
4. 判断 `dep_strength`、`blocking_risk`、`avoidability`、lag/lead 与 owner。
5. 对可移除或可并行依赖给出去耦建议与 `effort_to_remove`。
6. 检测循环依赖；发现环时标 blocked，不继续伪算关键路径。
7. 若 duration 已知，计算 `critical_path_analysis` 与 `float_analysis[]`。
8. 若资源信息已知，生成 `resource_constraints` 与冲突 resolution。
9. 若存在外部依赖，生成可跟踪 `external_dependencies[]`。
10. 汇总 `blocker_dependencies[]`、`avoidable_dependencies[]` 与 `dependency_risk_report`。
11. 构建 `codegen_dependency_resolution[]`，释放 A/B/C 类依赖给 060 implement，只保留 true owner/product scoped blocker。
12. 形成面向 N180 标准产物的 **`研发依赖清单.csv`**。
13. 输出 `downstream_handoff`，供 056 反向修正 duration，也供 N190 / N220 / N240 / N270 / N330 / N350 消费。
    - `external_dependencies[]` 中每条记录必须包含 `n350_tracking_ref: {dep_id, owner, contact_person, expected_ready_date, fallback_plan}`，以便 N350 直接建立外部依赖跟踪项。
    - `D8_event_dependency` 类型的依赖必须包含 `event_topic`、`expected_latency`、`schema_version`、`fallback_if_topic_unavailable`。
    - `downstream_handoff.N190` 必须包含 `060_selected_mode`、`implementation_decision_ledger_refs[]`、`scoped_deferred_features[]` 与 `forbidden_whole_phase_block_reason`。
14. 使用 checklist、common-failure review 与 `scripts/validate_codegen_handoff.py` 自检。

## Dynamic completeness / 动态完整度
- 小型项目：覆盖所有显性前置依赖。
- 中型项目：覆盖全部关键路径候选、外部依赖与资源瓶颈。
- 大型项目：优先覆盖关键链、近关键链、审批与环境时窗冲突。

## Common failure modes

1. **artificial 依赖未去除** — 把无实际约束的排期顺序依赖标为 `unavoidable`，关键路径被人为拉长。修复：对所有 `D1_finish_to_start` 依赖运行 `artificial_dependency_detection`；无实际数据/代码/知识约束的标为 `artificial` 并给出 `effort_to_remove`。
2. **循环依赖静默继续** — 发现循环依赖但仍继续输出关键路径，导致 CPM 结果无意义。修复：`R05_no_cycles` 门禁触发时立即停止 CPM 计算，将 `readiness` 设为 `blocked` 并要求人工修复。
3. **外部依赖无跟踪** — `external_dependencies[]` 只有依赖描述，缺少 `owner`/`contact_person`/`expected_ready_date`，项目经理无法跟踪。修复：`R07_external_has_tracking` 门禁必须验证每条外部依赖的 tracking 字段；缺失时报 `pending` 并分配默认跟踪 owner。

## Quality self-score / 质量自评

每次输出完成后，在 `artifact_contract` 中填写以下自评块：

```yaml
quality_self_score:
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null   # 最小输入即可产出可用结果=2; 依赖推荐输入=1; blocked=0
    contract_completeness: null  # 所有必填字段填写，无 null=2; 大部分填写=1; >30% null=0
    uncertainty_handling: null   # 推断进 inferred[]; 未知进 pending[]; 不发明=2; 部分=1; 静默发明=0
    downstream_handoff: null     # 下游消费字段精确命名=2; 有但模糊=1; 无=0
  overall_level: S | A | B | C  # 8分=S, 6-7分=A, 4-5分=B, <4分=C
```

`overall_level` 映射：8 分 = S，6–7 分 = A，4–5 分 = B，< 4 分 = C。`quality_self_score` 必须在 `self_gate` 之后、人类可读说明之前输出。

## Inline scoring rubric

每次输出完成后，验证以下门禁再提交：

| 检查项 | 通过条件 | 失败处置 |
|---|---|---|
| 输入分类完整 | minimum/recommended/optional 均已评估 | 重新分类，更新 readiness |
| 机读规则全通过 | `R01`–`R{max}` 无 reject 违规 | 修复违规字段后再输出 |
| 不确定性可见 | confirmed/inferred/pending 三类均有明确归属 | 补充 pending 项，不静默 |
| 下游 handoff 精确 | 每个下游节点的消费字段均已命名 | 补全 downstream_handoff |
| 产物事件已声明 | produced_event 字段完整（在 N180 聚合器中触发） | 由聚合器而非本 skill 发布 |

## Quality bar / 质量门槛
合格结果应能直接支撑排期、资源调度与风险沟通，而不需要再做一次“哪些依赖最危险”的人工重算。

## Reference files / 参考文件
- `references/output-template.md`
- `references/dependency-taxonomy.md`
- `references/dependency-algorithms.yaml`: D1-D8 决策表、可避免性规则、CPM 算法、纯文字降级处理
- `references/dependency-input-contract.yaml`: 三级输入分类与降级矩阵
- `references/dependency-self-check.yaml`: R01-R12 机读门禁规则
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/n180-integration-map.md`
- `references/v2_1-changelog.md`
- `references/v2_2-changelog.md`
