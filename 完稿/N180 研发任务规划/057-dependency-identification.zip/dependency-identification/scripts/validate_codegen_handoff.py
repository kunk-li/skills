#!/usr/bin/env python3
"""Validate N180 -> N190 implement handoff dependency classification."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


ALLOWED_BUCKETS = {
    "pre_code_decidable",
    "brownfield_code_extractable",
    "implementation_layer_owned",
    "true_owner_product_blocker",
}

IMPLEMENT_HANDOFFS = {
    "required_rule",
    "current_state_decision",
    "compatibility_decision",
    "implementation_decision",
    "made_by_implement_layer",
}

BAD_WHOLE_PHASE_EFFECTS = {
    "guarded_reference_only",
    "production_codegen_blocked",
    "blocked_for_production_codegen",
    "whole_d_code_blocked",
}


def as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"true", "yes", "1", "y"}
    return bool(value)


def validate(doc: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    deps = doc.get("dependency_registry") or doc.get("dependencies") or []
    handoff = doc.get("n190_handoff") or {}
    n190_effect = (handoff.get("n190_effect") or doc.get("n190_effect") or "").strip()
    selected_060 = (handoff.get("060_selected_mode") or doc.get("060_selected_mode") or "").strip()
    implementable_count = int(doc.get("implementable_core_flow_count") or 0)

    classified = []
    for dep in deps:
        if not isinstance(dep, dict):
            continue
        bucket = str(dep.get("resolution_class") or dep.get("boundary_bucket") or "")
        if bucket:
            classified.append(dep)

    if (deps or n190_effect in BAD_WHOLE_PHASE_EFFECTS) and not classified:
        errors.append("dependencies missing resolution_class/boundary_bucket for N190 handoff")

    all_core_flows_blocked = as_bool(doc.get("all_core_flows_blocked"))
    for idx, dep in enumerate(classified, 1):
        did = str(dep.get("dep_id") or dep.get("id") or f"#{idx}")
        bucket = str(dep.get("resolution_class") or dep.get("boundary_bucket") or "")
        if bucket not in ALLOWED_BUCKETS:
            errors.append(f"{did}: invalid resolution_class={bucket!r}")
            continue

        blocks_scope = str(dep.get("blocks_scope") or "")
        handoff_to_060 = str(dep.get("handoff_to_060") or "")
        blocking_risk = str(dep.get("blocking_risk") or "")
        deferred = as_bool(dep.get("deferred_blocked")) or str(dep.get("status") or "") == "deferred_blocked"

        if bucket != "true_owner_product_blocker":
            if deferred:
                errors.append(f"{did}: {bucket} must not be deferred_blocked")
            if handoff_to_060 not in IMPLEMENT_HANDOFFS:
                errors.append(f"{did}: {bucket} must hand off to 060")
            if blocks_scope == "whole_d_code" or (blocking_risk == "high" and n190_effect in BAD_WHOLE_PHASE_EFFECTS):
                errors.append(f"{did}: {bucket} must not block whole N190/D-code")
        else:
            if not dep.get("owner"):
                errors.append(f"{did}: true_owner_product_blocker requires owner")
            if blocks_scope == "whole_d_code" and not all_core_flows_blocked:
                errors.append(f"{did}: true owner blocker may block only affected function unless all_core_flows_blocked=true")

        if bucket == "implementation_layer_owned":
            made_by = str(dep.get("made_by") or "")
            if made_by != "implement_layer" and handoff_to_060 != "made_by_implement_layer":
                errors.append(f"{did}: implementation_layer_owned requires made_by=implement_layer")

    if implementable_count > 0:
        if selected_060 != "implement":
            errors.append("implementable core flows require 060_selected_mode=implement")
        if n190_effect in BAD_WHOLE_PHASE_EFFECTS:
            errors.append(f"n190_effect={n190_effect} is invalid while implementable core flows exist")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("--summary-line", action="store_true")
    args = parser.parse_args()

    doc = json.loads(args.input_json.read_text(encoding="utf-8"))
    errors = validate(doc)
    status = "pass" if not errors else "fail"
    if args.summary_line:
        print(f"N180-DEPENDENCY-CODEGEN-HANDOFF status={status} errors={len(errors)} failed={'-' if not errors else '|'.join(errors)}")
    else:
        print(json.dumps({"status": status, "errors": errors}, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
