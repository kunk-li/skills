---
name: development-task-breakdown
description: break technical solution notes, architecture boundaries, api and data outputs, nonfunctional constraints, or mixed implementation plans into workflow-aligned execution tasks. use when an LLM works in technical solution design / task management and must produce the 开发任务拆分表.csv before effort estimation, dependency analysis, code generation, review coordination, test planning, release preparation, or documentation handoff.
---
# development-task-breakdown

## Role / 角色定位
本 skill 对齐 `skills_workflow_v2` 中的「技术方案设计 -> 任务管理 -> 开发任务拆分表」。

它是 **direct_result** 型技能：把上游技术方案、边界、接口、数据与非功能设计落成可被下游直接消费的 **`开发任务拆分表.csv`**。

### Boundary / 边界
- 负责把需求与技术方案拆成可执行任务单元。
- 负责定义任务粒度、任务性质、技术域、DoD、追溯关系与 spike 管理。
- 可给出 `estimate_hint_pd` 或 `size_in_pd` 作为粒度辅助，但不替代正式三点估算；正式 PERT、buffer 与 Monte Carlo 由 `effort-estimation-assistant` 负责。
- 可显式写 `depends_on_hint`，但不替代关键路径、浮动时间、lag/lead 与资源冲突分析；这些由 `dependency-identification` 深化。
- 既能拆 greenfield 技术方案，也能把缺陷记录（已分类 / 定级 / 可复现，或审计、静态、事故发现）拆成 remediation task；区别在于后者修复位置已知（`target_site`），验收是回归测试而非从零设计的验收标准（见 `defect_remediation_mode`）。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 4 种模式：
- `brainstorm_mode`：早期规划，只输出候选 WBS、明显 blocker、待确认项和粗粒度任务，允许字段裁剪，但必须标注 `inferred` / `pending`。
- `refined_mode`：默认模式，输出完整任务清单，包含 `task_kind`、`task_type`、`task_size_tier`、`size_in_pd`、`definition_of_done`、`traces_to`。
- `jira_export`：在 refined 基础上增加 epic / story / task / subtask 层级，方便导入 Jira、Linear 或项目计划工具。
- `defect_remediation_mode`：输入是已分类 / 定级 / 可复现的缺陷记录（来自 N250 的 090/091/092，或等价的审计、事故、静态扫描发现），而非 greenfield 技术方案；为每个缺陷输出 remediation task（修复位置已知），`definition_of_done` 是钉死修复后行为的回归测试。用于把「缺陷 / 审计发现 → 可执行修复任务」拆出来——这一步落在 N250（止于 triage / 复现）与本节点（原为 greenfield 拆解）之间，原本无节点拥有。


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 完整需求 + 验收标准 + 团队技术栈 全部齐备 | 完整任务树 + 估时 + 验收标准 + 技术依赖 |
| `provisional` | 需求齐备但验收标准模糊 | 输出任务树，验收标准进 pending_acceptance[] |
| `constrained` | 仅有部分需求，缺业务规则细节 | 仅输出主干任务，子任务进 inferred[] |
| `blocked` | 仅有功能描述，无需求文档 | 输出 `request_for_inputs[]` |

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `模块边界图.md`
- `服务拆分建议.md`
- `数据流图.md`

### 可选增强输入
- `验收标准.md`
- `需求结构树.md`
- `可执行性检查单.csv`
- `接口设计草案.yaml`
- `表结构设计草案.sql`
- `并发控制建议.md`
- `幂等设计建议.md`
- `性能风险分析.md`
- `安全风险分析.md`
- 现有 Epic、里程碑、团队容量信息

### Defect-remediation 输入变体（`defect_remediation_mode`）
当输入是缺陷而非技术方案时，主要输入为 **缺陷记录**：
- 分类（ODC 缺陷类型 / 功能域 / 根因类别，来自 090 或等价分类）。
- 严重度与优先级（来自 091 或等价定级）。
- 复现包（最小复现 + 假阳性检查 + 回归测试候选，来自 092 或等价复现）。
- 已知缺陷位置（`file:line` / symbol）与修复方向线索（来自审计、code review、静态扫描或事故定位）。

降级规则：缺陷若由审计 / 静态发现而**无失败测试**（无 stack trace、无 failure signature），以 `intake_source: direct_observation` 标注，**不伪造** failure signature，仍可拆出 remediation task。

## Standalone rule / 独立使用规则
即使只拿到技术方案分析或粗粒度设计，也可以单独使用。

降级规则：
- 若缺少模块边界、数据流或接口契约，先输出候选 WBS。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的任务与追溯关系。
- 无法确认的大任务不可硬拆成看似精确的 Sprint 任务；应转成 spike、占位任务或待确认项。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.task_management.development_task_breakdown`
  - `workflow_node: N180`
  - `producer_skill: development-task-breakdown`
  - `node_artifact_target: 开发任务拆分表.csv`
  - `artifact_schema_version: n180.v2.2`
  - `evidence_profile`
  - `contract_status`
  - `event_emission`
- `task_registry[]`
- `granularity_audit`
- `coverage_backtrace`
- `spike_register[]`
- `orphan_items[]`
- `project_breakdown_health`
- `downstream_handoff`
- `self_check`

### Required task fields / 必填任务字段
每个任务至少包含：
- `task_id`，优先使用 `TASK-<SPRINT>-<NNN>`，例如 `TASK-S1-001`。
- `task_name`
- `task_kind`，使用 v2 canonical 任务性质枚举。
- `task_type`，表示技术域或交付面。
- `granularity`，v2 canonical 粒度字段。
- `task_size_tier`，v2.2 迁移期保留的 legacy alias，必须与 `granularity` 一致。
- `size_in_pd` 或 `estimate_hint_pd`
- `owner_role`
- `definition_of_done`
- `traces_to`
- `depends_on_hint`
- `sprint.target_sprint`，不确定时填 `TBD`。
- `sprint.priority_in_sprint`: must_have / should_have / could_have / won_t_have。
- `sprint.carry_over_policy`: can_carry / must_finish。
- `confidence`
- `mode`

## Design rules / 设计规则
### Granularity / 粒度分档
`granularity` 是 v2 canonical 字段；`task_size_tier` 是 legacy alias。输出表格中可以同时保留两列，但值必须一致。

必须强制使用以下分档：
- `XS`: `< 0.5 pd`
- `S`: `0.5-2 pd`
- `M`: `2-5 pd`
- `L`: `5-10 pd`
- `XL`: `> 10 pd`

执行规则：
- `XS / S / M`：可作为可执行任务保留；M 任务需确认验收边界清晰。
- `L`：建议拆分；若保留，必须说明为什么不能继续拆分。
- `XL`：必须拆分；若作为 placeholder 保留，必须标 `mode=blocked` 或给出人工接受理由。

### Sprint placement / Sprint 归属纪律
当任务进入 sprint 计划时，必须写清：
- `target_sprint`: `S1 / S2 / S3 / TBD`。
- `priority_in_sprint`: `must_have / should_have / could_have / won_t_have`。
- `carry_over_policy`: `can_carry / must_finish`。

`must_finish` 只用于 release gate、关键路径零浮动、强监管或必须在本 sprint 完结的任务；普通可延期任务应使用 `can_carry`，并在风险清单中说明影响。

### Task kind taxonomy / 任务性质矩阵
`task_kind` 是工作性质，必须使用 v2 canonical 枚举之一：
- `T1_design`：架构 / API / schema / 方案设计
- `T2_implementation`：编码实现
- `T3_testing`：单测 / 集成 / E2E / 回归
- `T4_documentation`：API 文档 / runbook / 用户或运维文档
- `T5_refactoring`：无 feature 改动的重构或清理
- `T6_infrastructure`：CI / deploy / monitoring / env / config
- `T7_spike`：技术探索 / POC / benchmark，必须 timeboxed
- `T8_review_or_coordination`：评审 / 协调 / signoff / 跨团队对齐

旧标签映射：`design -> T1_design`，`development -> T2_implementation`，`test -> T3_testing`，`documentation -> T4_documentation`，`refactor -> T5_refactoring`，`infrastructure -> T6_infrastructure`，`investigation -> T7_spike`，`integration/review/coordination -> T8_review_or_coordination`。

### Task type taxonomy / 技术域矩阵
`task_type` 是技术域或交付面，和 `task_kind` 正交。建议值：`backend / frontend / db / infra / test / config / integration / docs / security / data / observability / coordination`。

### Definition of Done discipline / 完成定义纪律
每个任务都必须包含 DoD，并按 `task_kind` 使用合适分桶：
- `T1_design`：设计文档已 review；关键备选方案已对比；stakeholder 或 owner 已签收。
- `T2_implementation` / `T5_refactoring`：代码合入主干；单测或关键验证通过；代码 review 通过；静态扫描无新增 critical；无未说明 TODO/FIXME。
- `T3_testing`：测试用例通过；边界/异常用例覆盖；CI 或测试记录可追溯。
- `T4_documentation`：文档发布；从相关页面引用；准确性已人工复核。
- `T6_infrastructure`：多环境验证；回滚验证；监控/告警或配置审计就绪。
- `T7_spike`：POC/benchmark 完成；结论文档化；下游任务可启动或明确 fallback。
- `T8_review_or_coordination`：会议结论、signoff 或行动项归档；owner 与截止时间明确。

### Trace discipline / 追溯纪律
`traces_to` 至少覆盖这些来源中的相关项：
- `requirements`
- `acs`
- `solution_components`
- `modules`
- `apis`
- `business_rules`
- `decision_refs`
- `nfr_designs.concurrency / idempotency / performance / security / observability`
- `defects`（`defect_remediation_mode`：回指缺陷 id / 审计或静态发现）

若某条需求、API、AC、NFR 或缺陷没有任何任务覆盖，必须进入 `orphan_items[]`。

### Spike discipline / Spike 纪律
探索型工作必须显式写：
- `task_kind: T7_spike`
- `is_spike: true`
- `timebox`
- `questions_to_answer[]`
- `success_criteria`
- `fallback_if_no_answer`
- `expected_output`: 必须是 `decision_record / benchmark_data / prototype` 之一。
- `exit_criteria`

Spike 不得伪装成普通开发任务。

### Defect-remediation tasks / 缺陷修复任务纪律
**readiness 判据（防误判 blocked）**：缺陷已分类 / 定级 / 位置已知、且**产品决策已定、仅实现机制待定** → `readiness: provisional` + 相关项标 `to_confirm`，**不得 `blocked`**（`blocked` 仅限源信息不足：无缺陷、无位置、无可判断的产品意图）。
`defect_remediation_mode` 下，每个任务在通用必填字段之外补以下字段（其余复用 `task_kind` T2/T5/T3、`granularity`、`estimate_hint_pd`、`depends_on_hint`，不另起一套；估时与依赖仍分别深化于 056 / 057）：
- `maps_to_defect`：回指缺陷 id（可多对一——同一签名的多个站点由一个参数化任务覆盖）。同时进 `traces_to.defects`。
- `remediation_kind`（与 `task_kind` 正交，描述修复**形状**）：
  - `fix`：改错误逻辑（有可复现失败）。
  - `add_missing_control`：补缺失的守卫 / 能力 / 约束（无 pre-existing 失败可复现，验收是行为场景而非红→绿）。
  - `delete_dead_code`：删死码 / 假能力（验收 = 删除后不可达 + 全套件仍绿；防「假安全」再生）。
  - `contract_align`：对齐状态码 / 契约 / 文档漂移（码与文档二选一改到一致）。
- `fix_approach`：修复**方向**而非从零设计；确切机制留作实现选择时，显式标 `to_confirm`（结构：`{id, question, why, blocks_code, decide_by}`，供机读 / 056 消费），不假装已定。
- `target_site`：已知 `file:line` 或 symbol；多站点同签名列全。位置若由人工核对得到，标 provenance（防转写阶段 file:line 漂移）。
- `priority`：继承缺陷严重度（来自 091 或等价定级）；若调度优先级与严重度背离（如死码严重度低却要尽快清），写 `priority_override_reason`，**不静默改级**。**若缺陷无源头严重度**（审计 / 静态发现未定级、新功能、agent-reported 未核）→ 按缺陷簇 / 影响**推断**并标 `inferred`（区别于 `priority_override_reason`：那是「已知严重度但调度背离」，此处是「源头缺级、推断补」）；二者皆不静默。
- `definition_of_done`：**钉死修复后不变量的回归测试** + 假阳性 / 负向 guard（断言只修目标、未过修，如清理类不得误删仍被引用的资源）。`add_missing_control` 用行为验收场景；`delete_dead_code` 用「不可达 + 套件绿」。

## Machine-readable rules / 机读门禁规则
- `R01_granularity_required`: 每任务必有 `granularity`；若输出 `task_size_tier`，必须与 `granularity` 一致; `on_violation: reject`。
- `R02_xl_must_split`: XL 必须拆分或显式保留为 blocked placeholder; `on_violation: auto_suggest_split`。
- `R03_task_kind_and_type_required`: 必须同时给出 `task_kind` 与 `task_type`; `on_violation: reject`。
- `R04_dod_required`: 每任务必有 DoD; `on_violation: reject`。
- `R05_traces_to_required`: 必至少追溯到 REQ / AC / COMP / MOD 之一; `on_violation: reject`。
- `R06_spike_timeboxed`: T7_spike 必须 timeboxed 且有 fallback; `on_violation: reject`。
- `R07_dependency_hint_no_obvious_cycle`: `depends_on_hint` 不应出现明显环; `on_violation: warn_and_flag_for_057`。
- `R08_size_is_range_or_hint`: 优先输出三点范围或 `estimate_hint_pd`; `on_violation: warn`。
- `R09_sprint_policy_required`: 已排入 sprint 的任务必须有 `carry_over_policy`; `on_violation: warn`。
- `R10_spike_expected_output_enum`: T7_spike 的 `expected_output` 必须为 decision_record / benchmark_data / prototype; `on_violation: reject`。
- `R11_remediation_task_grounded`: `defect_remediation_mode` 下每个任务必有 `maps_to_defect`、`remediation_kind`、`target_site` 与回归测试型 `definition_of_done`（`delete_dead_code` 用「不可达 + 套件绿」型 DoD）; `on_violation: reject`。**例外**：修复形状本身待判定（如某契约该补抛还是该删 = `task_kind: T7_spike`）的任务，DoD 走 spike 范式（`R06`/`R10`：decision_record + 后继任务可启动），不受本规则回归测试型 DoD 约束；回归测试落在 spike 产出的后继 fix / delete 任务上。

## Tech stack adapter / 技术栈适配

本 skill 不依赖特定编程语言，产物为结构化 CSV/Markdown。以下适配说明适用于不同技术生态的输入解读：

| 输入来源 | 输入格式特点 | 适配说明 |
|---|---|---|
| Java/Spring | Maven/Gradle 模块、@Service/@Repository 分层 | 按 controller/service/repository/entity 拆层任务 |
| TypeScript/Node | npm workspace / nx monorepo | 按 routes/service/repository/model 拆层 |
| Python/Django-FastAPI | pyproject.toml / poetry；views/serializers/models | 按 view/serializer/service/model 拆层 |
| Go | cmd/ + internal/ + pkg/ 布局 | 按 handler/usecase/repository/domain 拆层 |
| Kotlin/Spring | 同 Java；data class 替代 POJO | 同 Java 分层策略 |
| 多语言混合 | 微服务各有独立技术栈 | 每服务独立拆层；跨服务依赖记入 D5/D6 |

当技术栈未声明时：`tech_stack_declaration: pending`；不假设为 Java。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 从技术方案、边界、接口、数据流与 N170 约束中抽取交付对象。
3. 先形成粗粒度 WBS，再拆到可独立验收的任务。
4. 为每个任务赋予 `task_kind`、`task_type`、`task_size_tier`、`owner_role` 与 `definition_of_done`。
5. 建立 `traces_to`，把任务回指到需求、AC、模块、接口、决定项和 NFR。
6. 把未知较高的项转为 spike 或 pending 任务，不伪装成稳定开发项。
7. 运行 `granularity_audit`，检查是否存在 L/XL 或不可验收任务。
8. 产出 `coverage_backtrace` 与 `orphan_items[]`，确认上游关键对象都被覆盖。
9. 形成面向 N180 标准产物的 **`开发任务拆分表.csv`**。
10. 输出 `downstream_handoff`，供 056 / 057 以及 N190 / N220 / N240 / N270 / N330 / N350 消费。
11. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小型项目：覆盖全部任务、DoD 与追溯关系。
- 中型项目：覆盖全部关键链路，并明确低优先级或延后项。
- 大型项目：优先覆盖核心业务链、关键路径候选、跨团队联调与高风险交付面。


## Produced event schema

When this skill is used within the N180 workflow, the node orchestrator (or `planning-package-aggregator`) publishes:

```yaml
produced_event:
  event_type: produced.n180.task_breakdown
  contract_version: n180.v2.2
  artifact_ref: 开发任务拆分表.csv
  emitted_for: [planning-package-aggregator, N190, N220, N240, N270, N330, N350]
  readiness: pass | constrained | provisional
  task_count: <int>
  xl_blocked_count: <int>   # XL tasks not yet split
  spike_count: <int>
```

This schema allows downstream nodes to filter on `readiness` and `xl_blocked_count` before consuming the artifact.

## Common failure modes

1. **XL 任务未拆** — 保留 XL 占位任务但未提供不能拆分的说明，导致 Sprint 计划无法执行。修复：XL 必须触发 `R02_xl_must_split`；若确实无法拆分（技术探索阶段），必须转为 `T7_spike` 并给出 `timebox` 和 `fallback`。
2. **DoD 模糊** — 用"开发完成"作为 DoD，无法判断是否可验收。修复：DoD 必须按 `task_kind` 分桶；`T2_implementation` 至少需要"代码合入主干 + 单测通过 + review 通过"三条具体标准。
3. **追溯关系断链** — `traces_to` 只填了模块名而未对应需求 ID 或 AC-ID，导致需求覆盖率无法统计。修复：`orphan_items[]` 必须涵盖所有未被任何任务引用的 REQ/AC；`traces_to` 中的引用必须是可验证的稳定 ID。

## Quality self-score / 质量自评

每次输出完成后，在 `artifact_contract` 中填写以下自评块：

```yaml
quality_self_score:
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null   # 最小输入即可产出可用结果=2; 依赖推荐输入=1; blocked=0
    contract_completeness: null  # 所有必填字段填写，无 null=2; 大部分填写=1; >30% null=0
    uncertainty_handling: null   # 推断进 inferred[]; 未知进 pending[]; 不发明=2; 部分=1; 静默发明=0
    downstream_handoff: null     # 下游消费字段精确命名=2; 有但模糊=1; 无=0
  overall_level: S | A | B | C  # 8分=S, 6-7分=A, 4-5分=B, <4分=C
```

`overall_level` 映射：8 分 = S，6–7 分 = A，4–5 分 = B，< 4 分 = C。`quality_self_score` 必须在 `self_gate` 之后、人类可读说明之前输出。

## Inline scoring rubric

每次输出完成后，验证以下门禁再提交：

| 检查项 | 通过条件 | 失败处置 |
|---|---|---|
| 输入分类完整 | minimum/recommended/optional 均已评估 | 重新分类，更新 readiness |
| 机读规则全通过 | `R01`–`R{max}` 无 reject 违规 | 修复违规字段后再输出 |
| 不确定性可见 | confirmed/inferred/pending 三类均有明确归属 | 补充 pending 项，不静默 |
| 下游 handoff 精确 | 每个下游节点的消费字段均已命名 | 补全 downstream_handoff |
| 产物事件已声明 | produced_event 字段完整（在 N180 聚合器中触发） | 由聚合器而非本 skill 发布 |

## Quality bar / 质量门槛
合格结果应能直接进入估算、依赖分析与项目排期，而不需要再次解释“这个任务到底在做什么、做到什么算完”。

## Reference files / 参考文件
- `references/task-breakdown-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/task-breakdown-self-check.yaml`: R01-R10 机读门禁规则
- `references/task-breakdown-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/output-template.md`
- `references/task-granularity-guide.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/n180-integration-map.md`
- `references/v2_1-changelog.md`
- `references/v2_2-changelog.md`
