---
name: development-task-breakdown
description: break technical solution notes, architecture boundaries, api and data outputs, nonfunctional constraints, or mixed implementation plans into workflow-aligned execution tasks. use when chatgpt works in technical solution design / task management and must produce the n180 开发任务拆分表.csv before effort estimation, dependency analysis, code generation, review coordination, test planning, release preparation, or documentation handoff.
---
# development-task-breakdown

## Role / 角色定位
本 skill 对齐 `skills_workflow_v2` 中的「技术方案设计 -> 任务管理 -> 开发任务拆分表」。

它是 **direct_result** 型技能：把上游技术方案、边界、接口、数据与非功能设计落成可被下游直接消费的 **`开发任务拆分表.csv`**。

### Boundary / 边界
- 负责把需求与技术方案拆成可执行任务单元。
- 负责定义任务粒度、任务性质、技术域、DoD、追溯关系与 spike 管理。
- 可给出 `estimate_hint_pd` 或 `size_in_pd` 作为粒度辅助，但不替代正式三点估算；正式 PERT、buffer 与 Monte Carlo 由 `effort-estimation-assistant` 负责。
- 可显式写 `depends_on_hint`，但不替代关键路径、浮动时间、lag/lead 与资源冲突分析；这些由 `dependency-identification` 深化。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `brainstorm_mode`：早期规划，只输出候选 WBS、明显 blocker、待确认项和粗粒度任务，允许字段裁剪，但必须标注 `inferred` / `pending`。
- `refined_mode`：默认模式，输出完整任务清单，包含 `task_kind`、`task_type`、`task_size_tier`、`size_in_pd`、`definition_of_done`、`traces_to`。
- `jira_export`：在 refined 基础上增加 epic / story / task / subtask 层级，方便导入 Jira、Linear 或项目计划工具。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `模块边界图.md`
- `服务拆分建议.md`
- `数据流图.md`

### 可选增强输入
- `验收标准.md`
- `需求结构树.md`
- `可执行性检查单.csv`
- `接口设计草案.yaml`
- `表结构设计草案.sql`
- `并发控制建议.md`
- `幂等设计建议.md`
- `性能风险分析.md`
- `安全风险分析.md`
- 现有 Epic、里程碑、团队容量信息

## Standalone rule / 独立使用规则
即使只拿到技术方案分析或粗粒度设计，也可以单独使用。

降级规则：
- 若缺少模块边界、数据流或接口契约，先输出候选 WBS。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / inferred / pending` 的任务与追溯关系。
- 无法确认的大任务不可硬拆成看似精确的 Sprint 任务；应转成 spike、占位任务或待确认项。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.task_management.development_task_breakdown`
  - `workflow_node: N180`
  - `producer_skill: development-task-breakdown`
  - `node_artifact_target: 开发任务拆分表.csv`
  - `artifact_schema_version: n180.v2.2`
  - `evidence_profile`
  - `contract_status`
  - `event_emission`
- `task_registry[]`
- `granularity_audit`
- `coverage_backtrace`
- `spike_register[]`
- `orphan_items[]`
- `project_breakdown_health`
- `downstream_handoff`
- `self_check`

### Required task fields / 必填任务字段
每个任务至少包含：
- `task_id`，优先使用 `TASK-<SPRINT>-<NNN>`，例如 `TASK-S1-001`。
- `task_name`
- `task_kind`，使用 v2 canonical 任务性质枚举。
- `task_type`，表示技术域或交付面。
- `granularity`，v2 canonical 粒度字段。
- `task_size_tier`，v2.2 迁移期保留的 legacy alias，必须与 `granularity` 一致。
- `size_in_pd` 或 `estimate_hint_pd`
- `owner_role`
- `definition_of_done`
- `traces_to`
- `depends_on_hint`
- `sprint.target_sprint`，不确定时填 `TBD`。
- `sprint.priority_in_sprint`: must_have / should_have / could_have / won_t_have。
- `sprint.carry_over_policy`: can_carry / must_finish。
- `confidence`
- `mode`

## Design rules / 设计规则
### Granularity / 粒度分档
`granularity` 是 v2 canonical 字段；`task_size_tier` 是 legacy alias。输出表格中可以同时保留两列，但值必须一致。

必须强制使用以下分档：
- `XS`: `< 0.5 pd`
- `S`: `0.5-2 pd`
- `M`: `2-5 pd`
- `L`: `5-10 pd`
- `XL`: `> 10 pd`

执行规则：
- `XS / S / M`：可作为可执行任务保留；M 任务需确认验收边界清晰。
- `L`：建议拆分；若保留，必须说明为什么不能继续拆分。
- `XL`：必须拆分；若作为 placeholder 保留，必须标 `mode=blocked` 或给出人工接受理由。

### Sprint placement / Sprint 归属纪律
当任务进入 sprint 计划时，必须写清：
- `target_sprint`: `S1 / S2 / S3 / TBD`。
- `priority_in_sprint`: `must_have / should_have / could_have / won_t_have`。
- `carry_over_policy`: `can_carry / must_finish`。

`must_finish` 只用于 release gate、关键路径零浮动、强监管或必须在本 sprint 完结的任务；普通可延期任务应使用 `can_carry`，并在风险清单中说明影响。

### Task kind taxonomy / 任务性质矩阵
`task_kind` 是工作性质，必须使用 v2 canonical 枚举之一：
- `T1_design`：架构 / API / schema / 方案设计
- `T2_implementation`：编码实现
- `T3_testing`：单测 / 集成 / E2E / 回归
- `T4_documentation`：API 文档 / runbook / 用户或运维文档
- `T5_refactoring`：无 feature 改动的重构或清理
- `T6_infrastructure`：CI / deploy / monitoring / env / config
- `T7_spike`：技术探索 / POC / benchmark，必须 timeboxed
- `T8_review_or_coordination`：评审 / 协调 / signoff / 跨团队对齐

旧标签映射：`design -> T1_design`，`development -> T2_implementation`，`test -> T3_testing`，`documentation -> T4_documentation`，`refactor -> T5_refactoring`，`infrastructure -> T6_infrastructure`，`investigation -> T7_spike`，`integration/review/coordination -> T8_review_or_coordination`。

### Task type taxonomy / 技术域矩阵
`task_type` 是技术域或交付面，和 `task_kind` 正交。建议值：`backend / frontend / db / infra / test / config / integration / docs / security / data / observability / coordination`。

### Definition of Done discipline / 完成定义纪律
每个任务都必须包含 DoD，并按 `task_kind` 使用合适分桶：
- `T1_design`：设计文档已 review；关键备选方案已对比；stakeholder 或 owner 已签收。
- `T2_implementation` / `T5_refactoring`：代码合入主干；单测或关键验证通过；代码 review 通过；静态扫描无新增 critical；无未说明 TODO/FIXME。
- `T3_testing`：测试用例通过；边界/异常用例覆盖；CI 或测试记录可追溯。
- `T4_documentation`：文档发布；从相关页面引用；准确性已人工复核。
- `T6_infrastructure`：多环境验证；回滚验证；监控/告警或配置审计就绪。
- `T7_spike`：POC/benchmark 完成；结论文档化；下游任务可启动或明确 fallback。
- `T8_review_or_coordination`：会议结论、signoff 或行动项归档；owner 与截止时间明确。

### Trace discipline / 追溯纪律
`traces_to` 至少覆盖这些来源中的相关项：
- `requirements`
- `acs`
- `solution_components`
- `modules`
- `apis`
- `business_rules`
- `decision_refs`
- `nfr_designs.concurrency / idempotency / performance / security / observability`

若某条需求、API、AC 或 NFR 没有任何任务覆盖，必须进入 `orphan_items[]`。

### Spike discipline / Spike 纪律
探索型工作必须显式写：
- `task_kind: T7_spike`
- `is_spike: true`
- `timebox`
- `questions_to_answer[]`
- `success_criteria`
- `fallback_if_no_answer`
- `expected_output`: 必须是 `decision_record / benchmark_data / prototype` 之一。
- `exit_criteria`

Spike 不得伪装成普通开发任务。

## Machine-readable rules / 机读门禁规则
- `R01_granularity_required`: 每任务必有 `granularity`；若输出 `task_size_tier`，必须与 `granularity` 一致; `on_violation: reject`。
- `R02_xl_must_split`: XL 必须拆分或显式保留为 blocked placeholder; `on_violation: auto_suggest_split`。
- `R03_task_kind_and_type_required`: 必须同时给出 `task_kind` 与 `task_type`; `on_violation: reject`。
- `R04_dod_required`: 每任务必有 DoD; `on_violation: reject`。
- `R05_traces_to_required`: 必至少追溯到 REQ / AC / COMP / MOD 之一; `on_violation: reject`。
- `R06_spike_timeboxed`: T7_spike 必须 timeboxed 且有 fallback; `on_violation: reject`。
- `R07_dependency_hint_no_obvious_cycle`: `depends_on_hint` 不应出现明显环; `on_violation: warn_and_flag_for_057`。
- `R08_size_is_range_or_hint`: 优先输出三点范围或 `estimate_hint_pd`; `on_violation: warn`。
- `R09_sprint_policy_required`: 已排入 sprint 的任务必须有 `carry_over_policy`; `on_violation: warn`。
- `R10_spike_expected_output_enum`: T7_spike 的 `expected_output` 必须为 decision_record / benchmark_data / prototype; `on_violation: reject`。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 从技术方案、边界、接口、数据流与 N170 约束中抽取交付对象。
3. 先形成粗粒度 WBS，再拆到可独立验收的任务。
4. 为每个任务赋予 `task_kind`、`task_type`、`task_size_tier`、`owner_role` 与 `definition_of_done`。
5. 建立 `traces_to`，把任务回指到需求、AC、模块、接口、决定项和 NFR。
6. 把未知较高的项转为 spike 或 pending 任务，不伪装成稳定开发项。
7. 运行 `granularity_audit`，检查是否存在 L/XL 或不可验收任务。
8. 产出 `coverage_backtrace` 与 `orphan_items[]`，确认上游关键对象都被覆盖。
9. 形成面向 N180 标准产物的 **`开发任务拆分表.csv`**。
10. 输出 `downstream_handoff`，供 056 / 057 以及 N190 / N220 / N240 / N270 / N330 / N350 消费。
11. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小型项目：覆盖全部任务、DoD 与追溯关系。
- 中型项目：覆盖全部关键链路，并明确低优先级或延后项。
- 大型项目：优先覆盖核心业务链、关键路径候选、跨团队联调与高风险交付面。

## Quality bar / 质量门槛
合格结果应能直接进入估算、依赖分析与项目排期，而不需要再次解释“这个任务到底在做什么、做到什么算完”。

## Reference files / 参考文件
- `references/output-template.md`
- `references/task-granularity-guide.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/n180-integration-map.md`
- `references/v2_1-changelog.md`
- `references/v2_2-changelog.md`
