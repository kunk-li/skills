# 055 交付检查清单 v2.2

## A. 任务粒度

- [ ] 每个任务都有 `task_size_tier`。
- [ ] XS/S/M 任务边界清楚且可验收。
- [ ] L 任务已拆分或说明保留理由。
- [ ] XL 任务已拆分，或仅作为 blocked placeholder 保留。
- [ ] 低于 0.5 人天且不可独立验收的小任务已合并。

## B. 分类与 DoD

- [ ] 每个任务同时包含 `task_kind` 与 `task_type`。
- [ ] `task_kind` 使用 T1-T8 canonical 枚举。
- [ ] `task_type` 表示 backend/frontend/db/infra 等技术域。
- [ ] DoD 按 task_kind 分桶，不使用一套泛化 DoD 套所有任务。
- [ ] Spike 任务有 timebox、问题清单、success criteria、fallback。

## C. 依赖关系

- [ ] 前置依赖已写入 `depends_on_hint`。
- [ ] 跨系统、跨团队、数据准备与环境准备依赖已显式提示。
- [ ] 055 不伪装成完整关键路径工具；正式 CPM 交给 057。
- [ ] 明显依赖环已标记并提示 057 深化。

## D. 追溯与覆盖

- [ ] `traces_to` 至少回指 REQ / AC / COMP / MOD 之一。
- [ ] API、表结构、业务规则、NFR 和决策项尽量可追溯。
- [ ] 未覆盖的上游对象进入 `orphan_items[]`。
- [ ] `coverage_backtrace` 能解释哪些输入被哪些任务覆盖。

## E. 跨 skill 对齐

- [ ] `task_id` 稳定可复用。
- [ ] `estimate_hint_pd` 或 `size_in_pd` 足以作为 056 的输入基线。
- [ ] `depends_on_hint` 足以喂给 057。
- [ ] `evidence` 指回上游模块、接口、表结构或方案段落。

## F. 红线问题

- [ ] 没有把 blocked 任务包装成确定排期。
- [ ] 没有把多个独立流程混成一个任务。
- [ ] 没有缺失测试、联调、监控、文档或部署准备类任务。
- [ ] 没有无验收标准的模糊任务。

## G. v2.2 补充检查

- [ ] 已排入 sprint 的任务都有 `carry_over_policy`。
- [ ] `acceptance_criteria` 与 `traces_to.acs` 没有混淆：前者可读，后者稳定引用。
- [ ] T7_spike 的 `expected_output` 只使用 decision_record / benchmark_data / prototype。
