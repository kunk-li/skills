# v2.1 changelog: development-task-breakdown

## Optimized from v2 analysis

- Unified `task_kind` and `task_type` by making them two required orthogonal fields.
- Replaced legacy task kind labels with v2 canonical `T1_design` through `T8_review_or_coordination` and documented aliases.
- Aligned granularity with N180 v2: M can remain if bounded, L should split, XL must split or remain blocked.
- Added DoD buckets per task kind.
- Added `fallback_if_no_answer` for spikes.
- Renamed downstream mapping to prefer `estimate_hint_pd` and `depends_on_hint`.
- Added N180 v2.1 metadata, contract status, and event emission expectations.
- Added machine-readable rules with `on_violation` actions.
