# 055 编排说明 v2.2

## 上游优先级

优先复用以下输入，缺失时才降级：

1. 技术方案分析
2. 模块边界图
3. 服务拆分建议
4. 数据流图
5. 验收标准 / AC
6. API 清单
7. 表结构与索引设计
8. 非功能设计（并发、幂等、性能、安全、监控）
9. 需求漏洞清单 / 待决问题清单

若只有 PRD 或粗略方案，可直接拆分，但必须标记 `inferred`。

## 下游衔接

- **056 工时估算**：每个稳定 `task_id` 对应一条主估算记录；055 的 `estimate_hint_pd` / `size_in_pd` 只是输入基线，不替代 PERT。
- **057 依赖识别**：055 的 `depends_on_hint` 需要能展开为依赖边；高优先级 blocker 或 spike 任务应在 057 中出现。
- **项目管理 / 甘特图**：055 的 wave、sprint、priority 可以作为排期输入，但关键路径以 057 为准。

## 字段级映射

### 055 -> 056

| 055 字段 | 056 字段 | 说明 |
|---|---|---|
| task_id | task_id | 一一对应 |
| task_name | task_name | 名称保持一致 |
| task_kind | estimation_method_hint / cost_drivers | T7_spike 通常需要更高不确定性 |
| task_type | cost_drivers | db / infra / integration 等影响估算 |
| estimate_hint_pd | pd_most_likely 的输入基线 | 056 再扩成 optimistic / most_likely / pessimistic |
| size_in_pd | three_point_estimate | 若 055 已给三点范围，056 可复用并校准 |
| owner_role | assumptions | 仅作上下文，不强制保留 |
| priority | confidence / buffer 的参考 | blocker 往往意味着更低 confidence |
| mode | readiness / confidence | blocked 不应被硬估 |

### 055 -> 057

| 055 字段 | 057 字段 | 说明 |
|---|---|---|
| task_id | from_task / to_task_or_object | 依赖边锚点 |
| depends_on_hint | dependency edges | 一对多展开 |
| task_kind | dependency_domain hint | T7_spike 常映射 knowledge / decision 域 |
| task_type | dependency_domain hint | db/data/env 等可提示依赖域 |
| priority | blocking_risk | blocker 往往对应 high |
| evidence | evidence | 保持来源可追踪 |

## 反向约束

### 056 基于 055 的约束

- 估算记录数应接近 055 的任务数，加上少量全局假设行。
- 每个明确的 `task_id` 最好只有一条主估算记录。
- 如果 055 已标记 blocked，056 不应给出确定三点估算。

### 057 基于 055 的约束

- `from_task` 和 `to_task_or_object` 优先引用 055 中已存在的 `task_id`。
- 055 的 `depends_on_hint` 至少应是 057 依赖图的子集。
- 055 中 priority=must_have/blocker 的任务应至少在 057 中出现一次，除非无依赖。
