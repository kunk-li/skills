# Output Template: 开发任务拆分表 v2.2

## 默认交付结构

### 1. Metadata

```yaml
metadata:
  selected_mode: refined_mode
  readiness: pass | constrained | blocked | provisional
  function_bias: direct_result
  workflow_node: N180
  producer_skill: development-task-breakdown
  node_artifact_target: 开发任务拆分表.csv
  artifact_schema_version: n180.v2.2
  contract_status:
    schema_valid: true | false
    self_check_passed: true | false
    blocking_issues: []
```

### 2. 前置阻塞项（若存在关键缺口）

必需列：`blocking_issue`、`impact_scope`、`needed_input`、`suggested_owner`、`fallback_if_unresolved`。

### 3. 任务清单（主产出）

默认输出 csv 或 markdown 表，使用以下列：

| 列名 | 含义 | 允许值 / 备注 |
|---|---|---|
| task_id | 任务 ID | 优先 `TASK-S1-001`，可保留输入中的稳定 ID |
| task_name | 任务名 | 动宾结构，建议 20 字以内 |
| task_kind | 工作性质 | T1_design / T2_implementation / T3_testing / T4_documentation / T5_refactoring / T6_infrastructure / T7_spike / T8_review_or_coordination |
| task_type | 技术域 | backend / frontend / db / infra / test / config / integration / docs / security / data / observability / coordination |
| granularity | v2 canonical 粒度 | XS / S / M / L / XL |
| module | 所属模块 | 直接复用上游模块名或模块 ID |
| wave | 所属 wave | 1 / 2 / 3 |
| sprint | 所属 sprint | `S1` / `S2` / `S3`，不确定时填 `TBD` |
| carry_over_policy | Sprint 结转策略 | can_carry / must_finish |
| description | 任务描述 | 1-2 句说明范围 |
| definition_of_done | 完成定义 | 必须按 task_kind 可验证 |
| acceptance_criteria | 验收标准 | 人可读 AC 摘要或 AC-ID；稳定 ID 仍应写入 `traces_to.acs` |
| task_size_tier | legacy 粒度别名 | v2.2 迁移期保留，必须与 `granularity` 一致 |
| estimate_hint_pd | 粗估人天 | 用于粒度判断，不替代 056 的 PERT |
| size_in_pd_optimistic | 乐观值 | 可空；若已知则给出 |
| size_in_pd_most_likely | 最可能值 | 可空；若已知则给出 |
| size_in_pd_pessimistic | 悲观值 | 可空；若已知则给出 |
| depends_on_hint | 依赖提示 | 逗号或分号分隔；057 会深化 |
| owner_role | 负责人角色 | 角色而非姓名 |
| priority | 优先级 | must_have / should_have / could_have / won_t_have，或保留 blocker / major / minor alias |
| traces_to | 追溯 | REQ / AC / COMP / MOD / API / RULE / NFR / DECISION |
| evidence | 证据锚点 | 模块 / API / 表 / 方案段落 |
| confidence | 置信度 | high / medium / low |
| mode | 证据模式 | confirmed / constrained / blocked / inferred / pending |

### 4. Spike register

当 `task_kind=T7_spike` 时，必须额外列出：

| task_id | timebox | questions_to_answer | success_criteria | fallback_if_no_answer | expected_output | exit_criteria |
|---|---|---|---|---|---|---|

`expected_output` 只允许：`decision_record / benchmark_data / prototype`。

### 5. 依赖链路提示

055 只输出 `depends_on_hint` 与候选关键链，不计算正式 CPM。正式关键路径由 057 负责。

```text
TASK-S1-001 -> TASK-S1-002 -> TASK-S1-004
```

### 6. 可并行任务组

按 sprint 或模块分组，列出：

- 并行任务集合
- 并行前提
- 并行上限

### 7. Coverage backtrace

列出上游对象覆盖情况：

| upstream_object | covered_by_tasks | coverage_status | notes |
|---|---|---|---|

### 8. 风险提示

单列以下对象：

- L/XL 或边界不清任务
- 高不确定 spike
- 跨团队依赖提示
- 数据准备依赖
- 外部接口依赖

## 额外规则

- Blocked 任务不要给出看似精确的 `estimate_hint_pd`。
- Wave 3 未决任务可以保留占位行，但必须标 `mode=constrained` 或 `blocked`。
- 若用户只给高层方案，可输出候选任务，但必须在 `mode` 或备注中写明 `inferred`。
- `task_kind` 与 `task_type` 必须同时出现；一个描述工作性质，一个描述技术域，不可互相替代。
- `granularity` 是 canonical 字段；若保留 `task_size_tier`，两列必须一致。
- 已排入 sprint 的任务必须写 `carry_over_policy`。
