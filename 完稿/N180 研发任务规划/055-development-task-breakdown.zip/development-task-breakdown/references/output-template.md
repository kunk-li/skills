# Output Template: 开发任务拆分表 v2.2

## 默认交付结构

### 1. Metadata

```yaml
metadata:
  selected_mode: refined_mode
  readiness: pass | constrained | blocked | provisional
  function_bias: direct_result
  workflow_node: N180
  producer_skill: development-task-breakdown
  node_artifact_target: 开发任务拆分表.csv
  artifact_schema_version: n180.v2.2
  contract_status:
    schema_valid: true | false
    self_check_passed: true | false
    blocking_issues: []
  n190_handoff:
    060_selected_mode: implement | quick_service | full_service | guarded_reference_only
    n190_effect: production_implementation_required_for_implementable_flows | scoped_blocked | no_implementable_flow
    implementable_core_flow_count: 0
    all_core_flows_blocked: false
```

### 2. 前置阻塞项（若存在关键缺口）

必需列：`blocking_issue`、`impact_scope`、`needed_input`、`suggested_owner`、`fallback_if_unresolved`。

### 3. 任务清单（主产出）

默认输出 csv 或 markdown 表，使用以下列：

| 列名 | 含义 | 允许值 / 备注 |
|---|---|---|
| task_id | 任务 ID | 优先 `TASK-S1-001`，可保留输入中的稳定 ID |
| task_name | 任务名 | 动宾结构，建议 20 字以内 |
| task_kind | 工作性质 | T1_design / T2_implementation / T3_testing / T4_documentation / T5_refactoring / T6_infrastructure / T7_spike / T8_review_or_coordination |
| task_type | 技术域 | backend / frontend / db / infra / test / config / integration / docs / security / data / observability / coordination |
| granularity | v2 canonical 粒度 | XS / S / M / L / XL |
| module | 所属模块 | 直接复用上游模块名或模块 ID |
| wave | 所属 wave | 1 / 2 / 3 |
| sprint | 所属 sprint | `S1` / `S2` / `S3`，不确定时填 `TBD` |
| carry_over_policy | Sprint 结转策略 | can_carry / must_finish |
| description | 任务描述 | 1-2 句说明范围 |
| definition_of_done | 完成定义 | 必须按 task_kind 可验证 |
| acceptance_criteria | 验收标准 | 人可读 AC 摘要或 AC-ID；稳定 ID 仍应写入 `traces_to.acs` |
| task_size_tier | legacy 粒度别名 | v2.2 迁移期保留，必须与 `granularity` 一致 |
| estimate_hint_pd | 粗估人天 | 用于粒度判断，不替代 056 的 PERT |
| size_in_pd_optimistic | 乐观值 | 可空；若已知则给出 |
| size_in_pd_most_likely | 最可能值 | 可空；若已知则给出 |
| size_in_pd_pessimistic | 悲观值 | 可空；若已知则给出 |
| depends_on_hint | 依赖提示 | 逗号或分号分隔；057 会深化 |
| owner_role | 负责人角色 | 角色而非姓名 |
| priority | 优先级 | must_have / should_have / could_have / won_t_have，或保留 blocker / major / minor alias |
| traces_to | 追溯 | REQ / AC / COMP / MOD / API / RULE / NFR / DECISION |
| evidence | 证据锚点 | 模块 / API / 表 / 方案段落 |
| confidence | 置信度 | high / medium / low |
| mode | 证据模式 | confirmed / constrained / blocked / inferred / pending |

### 4. Spike register

当 `task_kind=T7_spike` 时，必须额外列出：

| task_id | timebox | questions_to_answer | success_criteria | fallback_if_no_answer | expected_output | exit_criteria |
|---|---|---|---|---|---|---|

`expected_output` 只允许：`decision_record / benchmark_data / prototype`。

### 5. 依赖链路提示

055 只输出 `depends_on_hint` 与候选关键链，不计算正式 CPM。正式关键路径由 057 负责。

```text
TASK-S1-001 -> TASK-S1-002 -> TASK-S1-004
```

### 6. 可并行任务组

按 sprint 或模块分组，列出：

- 并行任务集合
- 并行前提
- 并行上限

### 7. Coverage backtrace

列出上游对象覆盖情况：

| upstream_object | covered_by_tasks | coverage_status | notes |
|---|---|---|---|

### 8. 风险提示

单列以下对象：

- L/XL 或边界不清任务
- 高不确定 spike
- 跨团队依赖提示
- 数据准备依赖
- 外部接口依赖

### 9. Codegen blocker classification

所有影响 N190/D-code 的 blocker 必须逐条分桶，不允许用一句 “API gate fail / contract provisional” 阻塞整段代码生成。

| blocker_id | source | boundary_bucket | affected_feature_or_api | blocks_scope | handoff_to_060 | owner | made_by | decision_ledger_entry | deferred_reason |
|---|---|---|---|---|---|---|---|---|---|

允许值：

- `boundary_bucket`: `pre_code_decidable / brownfield_code_extractable / implementation_layer_owned / true_owner_product_blocker`
- `blocks_scope`: `function / api_surface / adapter / data_migration / whole_d_code`
- `handoff_to_060`: `required_rule / current_state_decision / compatibility_decision / implementation_decision / made_by_implement_layer / deferred_blocked`

规则：

- `pre_code_decidable`、`brownfield_code_extractable`、`implementation_layer_owned` 不得 `deferred_blocked`，不得 `blocks_scope=whole_d_code`。
- `implementation_layer_owned` 必须 `made_by=implement_layer`。
- `true_owner_product_blocker` 必须有 owner；除非 `all_core_flows_blocked=true`，不得 `blocks_scope=whole_d_code`。

### 10. Implementation decision ledger for 060

将 A/B/C 类 blocker 转成 060 implement 可消费的输入：

| decision_id | source_blocker_id | decision_type | resolution | source | risk | consumed_by_060_as |
|---|---|---|---|---|---|---|

`decision_type` 允许：`required_rule / current_state / compatibility / implementation_layer`。

### 11. N190 handoff

```yaml
n190_handoff:
  060_selected_mode: implement
  n190_effect: production_implementation_required_for_implementable_flows
  implementable_core_flow_count: 0
  scoped_deferred_features: []
  implementation_decision_ledger: []
  forbidden_reasoning:
    - "044/API gate fail alone cannot force guarded_reference_only"
    - "PRD silence on engineering decisions cannot block implement mode"
```

## 额外规则

- Blocked 任务不要给出看似精确的 `estimate_hint_pd`。
- Wave 3 未决任务可以保留占位行，但必须标 `mode=constrained` 或 `blocked`。
- 若用户只给高层方案，可输出候选任务，但必须在 `mode` 或备注中写明 `inferred`。
- `task_kind` 与 `task_type` 必须同时出现；一个描述工作性质，一个描述技术域，不可互相替代。
- `granularity` 是 canonical 字段；若保留 `task_size_tier`，两列必须一致。
- 已排入 sprint 的任务必须写 `carry_over_policy`。
- 存在 implementable core flow 时，N190 handoff 必须选择 060 `implement`；只能对 true owner blocker 影响的具体功能做 scoped deferred。
