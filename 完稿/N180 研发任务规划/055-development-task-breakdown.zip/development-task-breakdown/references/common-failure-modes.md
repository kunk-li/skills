# 055 常见失败模式 v2.2

## F1. 任务粒度过大

症状：出现“开发登录模块”“完成审批功能”这类 L/XL 大任务。

修正：继续拆成设计、接口实现、状态流转、数据变更、联调、测试与配置任务。XL 必须拆分或作为 blocked placeholder。

## F2. 完成标准模糊

症状：完成标准只写“开发完成”“测试通过”。

修正：改成可验证条件，例如“新增接口通过 5 个关键用例”“索引上线并通过回归 SQL 检查”。DoD 必须按 task_kind 分桶。

## F3. task_kind 与 task_type 混用

症状：把 backend/frontend/db 填到 `task_kind`，或把 design/test/spike 填到 `task_type`。

修正：`task_kind` 写 T1-T8 工作性质；`task_type` 写技术域。两者必须同时保留。

## F4. 依赖漏写

症状：只写内部前置任务，遗漏跨团队接口、数据准备或环境申请。

修正：把所有候选依赖写入 `depends_on_hint` 或阻塞项区域，正式依赖交给 057 深化。

## F5. 忽视阻塞任务

症状：关键方案未决，但仍输出完整排期和精确估时。

修正：降级为 constrained 或 blocked，只输出占位任务、spike 与待补充信息。

## F6. 并行度过高

症状：Sprint 安排过多并行任务，但团队人数不足或 reviewer 不足。

修正：按容量、联调窗口和 review 开销收敛并行度，并提示 056/057 进一步校验。

## F7. 缺失测试与基础设施任务

症状：只有业务开发任务，没有测试、监控、配置、数据迁移或环境准备。

修正：补齐 T3_testing、T6_infrastructure、T4_documentation 或 T8_review_or_coordination 类型任务。
