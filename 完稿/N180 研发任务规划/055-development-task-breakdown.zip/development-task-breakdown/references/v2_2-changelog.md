# v2.2 changelog: development-task-breakdown

## Optimized from v2.1复评 residual items

- Added `granularity` as the canonical v2 field while retaining `task_size_tier` as a legacy alias.
- Added sprint placement fields: `target_sprint`, `priority_in_sprint`, and `carry_over_policy`.
- Constrained T7_spike `expected_output` to `decision_record / benchmark_data / prototype`.
- Clarified `acceptance_criteria` vs `traces_to.acs`: human-readable AC summary versus stable AC-ID references.
- Updated output template, example, checklist, integration map, and machine-readable rules to v2.2.
