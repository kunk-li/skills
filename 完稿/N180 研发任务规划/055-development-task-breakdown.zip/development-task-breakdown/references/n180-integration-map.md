# N180 integration map v2.2

## Workflow alignment
This skill belongs to N180 in `skills_workflow_v2`.

### N180 node contract
- Inputs: `技术方案分析.md`, `模块边界图.md`, `服务拆分建议.md`, `数据流图.md`
- Node outputs:
  - `开发任务拆分表.csv`
  - `工时估算表.csv`
  - `研发依赖清单.csv`
  - `N180_planning_package.md`
- Downstream nodes:
  - `N190`
  - `N220`
  - `N240`
  - `N270`
  - `N330`
  - `N350`

## Shared metadata contract
Every N180 artifact should expose this metadata block when the answer format allows it:

```yaml
metadata:
  workflow_node: N180
  node_name: 研发任务规划
  artifact_schema_version: n180.v2.2
  producer_skill: <skill-name>
  node_artifact_target: <artifact-name>
  readiness: pass | constrained | blocked | provisional
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
  contract_status:
    schema_valid: true | false
    self_check_passed: true | false
    blocking_issues: []
  event_emission:
    produced_event: produced.n180.<artifact>
    state_event: state.n180.ready | state.n180.constrained | state.n180.blocked
```

## Internal handoff inside N180
- `development-task-breakdown` owns stable `task_id`, task granularity, DoD, sprint placement, carry-over policy, and upstream traceability.
- `effort-estimation-assistant` reuses `task_id` and produces PERT effort, duration, buffer, load, and optional Monte Carlo commitment percentiles.
- `dependency-identification` anchors dependency edges on `task_id`, then adds dependency kind/domain, avoidability, CPM, float, resource, and external dependency tracking.
- `n180-planning-package-aggregator` owns `N180_planning_package.md` by merging the three sibling artifacts and emitting the node-level package event.

## Canonical aliases
- `granularity` is the canonical v2 field for task size tier. `task_size_tier` is retained as a legacy alias during v2.2 migration and should mirror `granularity` when both are present.
- `acceptance_criteria` is the human-readable AC text or summary. `traces_to.acs` is the stable AC-ID reference list. They complement each other and should not be collapsed.
- `duration_calendar_days` is canonical for schedule duration. Legacy `duration_days` may be accepted as input and normalized by downstream tools.

## Node-level planning package
`N180_planning_package.md` is produced by `n180-planning-package-aggregator` or by N370 invoking the same merge rules. It should contain six sections:

1. 任务清单（按 sprint / wave）
2. 估算汇总（含 PERT、buffer、P50/P80/P95，如已启用 Monte Carlo）
3. 依赖图 + 关键路径
4. 资源 load balance
5. 外部依赖追踪
6. 风险清单

The aggregation remains a node-level orchestration concern. Individual skills prepare clean handoff data but should not absorb all responsibilities of their sibling skills.

## Package readiness gating
- If any source artifact is `blocked`, the planning package is `blocked` unless that blocked scope is explicitly excluded from the release candidate.
- If any source artifact is `provisional`, the planning package is at most `constrained`.
- If 057 detects a dependency cycle, the planning package is `blocked` until the cycle is resolved or formally accepted as an exception.
- If 056 reports over-allocation above 100%, the planning package must include a load-balance risk and mitigation.

## Node-level quality expectations
- Task granularity is explicit and follows XS/S/M/L/XL consistently.
- Estimates separate effort, duration, buffer, confidence, and commitment percentile.
- Dependencies distinguish scheduling relation (`dependency_kind`) from dependency source domain (`dependency_domain`).
- Sprint placement includes `carry_over_policy` when tasks are planned for a sprint.
- All artifacts are reusable by downstream implementation, review, testing, release, documentation, and coordination nodes.
