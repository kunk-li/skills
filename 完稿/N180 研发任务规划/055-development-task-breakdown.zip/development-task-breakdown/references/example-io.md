# 055 示例输入输出 v2.2

## 示例输入

用户给出：

- 目标：为 CRM 系统新增“线索去重规则配置”能力
- 已知模块：配置页、去重规则 API、规则表、定时回刷任务
- 约束：本周先完成配置页和后端主链路；数据回刷方案待确认

## 示例输出（节选）

### Metadata

```yaml
metadata:
  selected_mode: refined_mode
  readiness: constrained
  function_bias: direct_result
  workflow_node: N180
  producer_skill: development-task-breakdown
  node_artifact_target: 开发任务拆分表.csv
  artifact_schema_version: n180.v2.2
```

### 前置阻塞项

| blocking_issue | impact_scope | needed_input | suggested_owner | fallback_if_unresolved |
|---|---|---|---|---|
| 历史数据回刷策略未定 | wave 2 / 数据任务 | 确认全量回刷还是增量回刷 | 产品 + 后端 | 先保留 T7_spike，wave 1 不承诺回刷上线 |

### 任务清单

| task_id | task_name | task_kind | task_type | granularity | task_size_tier | module | wave | sprint | carry_over_policy | description | definition_of_done | acceptance_criteria | estimate_hint_pd | depends_on_hint | owner_role | priority | traces_to | evidence | confidence | mode |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---:|---|---|---|---|---|---|---|
| TASK-S1-001 | 新增规则配置表与索引 | T1_design | db | S | S | dedupe-core | 1 | S1 | must_finish | 创建规则主表与唯一索引设计 | 建表 SQL 通过评审并在测试库验证 | AC-001 | 1.0 |  | backend | must_have | MOD-DEDUP;DATA-rule;AC-001 | 表结构草稿 | high | confirmed |
| TASK-S1-002 | 实现规则配置查询与保存 API | T2_implementation | backend | S | S | dedupe-api | 1 | S1 | must_finish | 支持规则列表、保存与校验 | 代码合入主干；关键接口通过 5 个用例；review 通过 | AC-001 | 1.5 | TASK-S1-001 | backend | must_have | API-rule;AC-001 | API 草稿 | high | confirmed |
| TASK-S1-003 | 实现规则配置页表单与校验 | T2_implementation | frontend | S | S | dedupe-ui | 1 | S1 | can_carry | 新增配置页与前端表单校验 | 页面可新增、编辑并提示校验错误；前端用例通过 | AC-002 | 1.5 | TASK-S1-002 | frontend | should_have | AC-002;UI-rule | 页面原型 | medium | confirmed |
| TASK-S1-004 | 接入规则发布后的联调回归 | T3_testing | integration | S | S | dedupe-e2e | 1 | S2 | must_finish | 前后端联调并验证主流程 | 主流程回归通过且无阻断缺陷；结果记录归档 | AC-001;AC-002 | 1.0 | TASK-S1-002;TASK-S1-003 | qa | must_have | AC-001;AC-002 | 联调清单 | medium | confirmed |
| TASK-S2-005 | 调研历史数据回刷策略 | T7_spike | data | M | M | dedupe-replay | 2 | S2 | can_carry | 明确回刷方案与风险 | POC/数据量评估完成；形成决策记录；下游任务可启动 | 待定 | 3.0 |  | backend | should_have | Q-12;DATA-replay | 待决问题 Q-12 | low | constrained |

### Spike register

| task_id | timebox | questions_to_answer | success_criteria | fallback_if_no_answer | expected_output | exit_criteria |
|---|---|---|---|---|---|---|
| TASK-S2-005 | 3d | 全量或增量？数据量多少？是否需要回滚？ | 形成推荐方案与成本估算 | wave 1 不上线回刷，仅保留手工处理预案 | decision_record | 产品与后端签收方案 |

### 候选关键链提示

`TASK-S1-001 -> TASK-S1-002 -> TASK-S1-003 -> TASK-S1-004`

说明：正式关键路径、float 与资源冲突应由 057 基于 056 duration 继续计算。
