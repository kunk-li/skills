#!/usr/bin/env python3
"""Validate N180 -> N190 implement handoff.

Input is a small JSON export of the planning package fields that matter for
code generation. The gate is intentionally generic: it does not know OA, B2 or
Z1. It checks that constrained/blocker findings are classified before they can
downgrade code generation.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


ALLOWED_BUCKETS = {
    "pre_code_decidable",
    "brownfield_code_extractable",
    "implementation_layer_owned",
    "true_owner_product_blocker",
}

IMPLEMENT_HANDOFFS = {
    "required_rule",
    "current_state_decision",
    "compatibility_decision",
    "implementation_decision",
    "made_by_implement_layer",
}

BAD_WHOLE_PHASE_EFFECTS = {
    "guarded_reference_only",
    "production_codegen_blocked",
    "blocked_for_production_codegen",
    "whole_d_code_blocked",
}


def as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"true", "yes", "1", "y"}
    return bool(value)


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def validate(doc: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    blockers = doc.get("codegen_blocker_classification") or []
    raw_blockers = doc.get("raw_blockers") or doc.get("blocking_issues") or []
    handoff = doc.get("n190_handoff") or {}
    n190_effect = (handoff.get("n190_effect") or doc.get("n190_effect") or "").strip()
    selected_060 = (handoff.get("060_selected_mode") or doc.get("060_selected_mode") or "").strip()

    implementable_count = int(doc.get("implementable_core_flow_count") or 0)
    for flow in doc.get("core_business_flows") or []:
        if as_bool(flow.get("implementable")):
            implementable_count += 1

    if (raw_blockers or n190_effect in BAD_WHOLE_PHASE_EFFECTS) and not blockers:
        errors.append("missing codegen_blocker_classification[] for constrained/blocker handoff")

    blocker_ids = set()
    all_core_flows_blocked = as_bool(doc.get("all_core_flows_blocked"))
    for idx, item in enumerate(blockers, 1):
        bid = str(item.get("blocker_id") or item.get("id") or f"#{idx}")
        blocker_ids.add(bid)
        bucket = str(item.get("boundary_bucket") or "")
        if bucket not in ALLOWED_BUCKETS:
            errors.append(f"{bid}: invalid boundary_bucket={bucket!r}")
            continue

        blocks_scope = str(item.get("blocks_scope") or "")
        handoff_to_060 = str(item.get("handoff_to_060") or "")
        resolution = str(item.get("resolution_status") or "")
        deferred = as_bool(item.get("deferred_blocked")) or resolution == "deferred_blocked"

        if bucket != "true_owner_product_blocker":
            if deferred:
                errors.append(f"{bid}: {bucket} must not be deferred_blocked")
            if handoff_to_060 not in IMPLEMENT_HANDOFFS:
                errors.append(f"{bid}: {bucket} must hand off to 060 as implement input")
            if blocks_scope == "whole_d_code":
                errors.append(f"{bid}: {bucket} must not block whole D-code")
        else:
            if not item.get("owner"):
                errors.append(f"{bid}: true_owner_product_blocker requires owner")
            if blocks_scope == "whole_d_code" and not all_core_flows_blocked:
                errors.append(f"{bid}: true owner blocker may block only affected function unless all_core_flows_blocked=true")

        if bucket == "implementation_layer_owned":
            made_by = str(item.get("made_by") or "")
            if made_by != "implement_layer" and handoff_to_060 != "made_by_implement_layer":
                errors.append(f"{bid}: implementation_layer_owned requires made_by=implement_layer")

    if raw_blockers:
        raw_ids = {str(x.get("blocker_id") or x.get("id")) for x in raw_blockers if isinstance(x, dict)}
        missing = sorted(x for x in raw_ids if x and x not in blocker_ids)
        if missing:
            errors.append("raw blockers missing classification: " + ",".join(missing))

    if implementable_count > 0:
        if selected_060 != "implement":
            errors.append("implementable core flows require n190_handoff.060_selected_mode=implement")
        if n190_effect in BAD_WHOLE_PHASE_EFFECTS:
            errors.append(f"n190_effect={n190_effect} is invalid while implementable core flows exist")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("--summary-line", action="store_true")
    args = parser.parse_args()

    errors = validate(load(args.input_json))
    status = "pass" if not errors else "fail"
    if args.summary_line:
        print(f"N180-CODEGEN-HANDOFF status={status} errors={len(errors)} failed={'-' if not errors else '|'.join(errors)}")
    else:
        print(json.dumps({"status": status, "errors": errors}, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
