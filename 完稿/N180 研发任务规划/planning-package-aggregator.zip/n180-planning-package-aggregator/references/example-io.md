# N180 planning package example v2.2

## Input
- 055 输出：5 个 CRM 线索去重任务，其中 1 个 T7_spike。
- 056 输出：总 effort 8.5pd，P80 12d，1 个任务 confidence=low。
- 057 输出：3 个 high-risk dependency，其中测试环境账号 delayed。

## Output excerpt

```yaml
metadata:
  selected_mode: release_planning_package
  readiness: constrained
  function_bias: orchestration_result
  workflow_node: N180
  producer_skill: n180-planning-package-aggregator
  node_artifact_target: N180_planning_package.md
  artifact_schema_version: n180.v2.2
  event_emission:
    produced_event: produced.n180.planning_package
    state_event: state.n180.constrained
```

## Executive summary
本次 wave 1 可进入实现，但测试环境账号与历史数据回刷策略仍未关闭，因此 package readiness 为 constrained。P80 完成窗口为 12 个日历日，前提是 DEP-002 在 2026-05-10 前 ready。

## Top risks
| risk_id | source | severity | affected_tasks | mitigation | owner |
|---|---|---|---|---|---|
| RISK-001 | DEP-002 | high | TASK-S1-004 | 提前申请测试账号并准备最小数据集 | qa / infra |
