# Merge rules v2.2

## Primary keys
- `task_id` is the join key across 055, 056, and 057.
- 055 is authoritative for task names, granularity, DoD, sprint placement, and traces.
- 056 is authoritative for effort, duration, buffer, confidence, load, and commitment percentiles.
- 057 is authoritative for dependencies, critical path, float, resources, external dependencies, and dependency risks.

## Conflict resolution
- Missing 056 estimate for a must_have task -> add `join_anomaly` and risk.
- Missing 057 dependency edge for a blocker/must_have task -> add a warning unless task is truly independent.
- Unknown external dependency contact -> package readiness at most `constrained`.
- Cycle detected -> package readiness `blocked`.

## Readiness rollup
- blocked source -> blocked package unless excluded.
- provisional source -> constrained package.
- high load or high risk external dependency -> constrained package.
- all pass and no high unresolved risks -> pass package.
