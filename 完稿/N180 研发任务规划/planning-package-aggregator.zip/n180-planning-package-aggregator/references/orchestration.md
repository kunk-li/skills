# N180 planning package orchestration v2.2

## Recommended invocation order
1. 055 `development-task-breakdown`
2. 056 `effort-estimation-assistant` initial estimate
3. 057 `dependency-identification`
4. 056 optional recalibration with dependency waits
5. `n180-planning-package-aggregator`

## Event output
The final package should emit:

```yaml
event_emission:
  produced_event: produced.n180.planning_package
  state_event: state.n180.ready | state.n180.constrained | state.n180.blocked
```

## N370 handoff
N370 can invoke this skill after sibling skills finish, or implement the same merge rules directly in the orchestration engine.
