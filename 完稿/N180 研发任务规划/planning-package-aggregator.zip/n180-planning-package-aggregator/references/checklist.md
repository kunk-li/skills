# N180 planning package checklist v2.2

## A. Source coverage
- [ ] 已识别 055 / 056 / 057 输入及其 readiness。
- [ ] 以 055 的 task_id 作为主键。
- [ ] 缺失输入已降级并说明。

## B. Join quality
- [ ] 056 估算记录能回指 055 task_id。
- [ ] 057 依赖边能回指 055 task_id 或明确外部对象。
- [ ] join_anomalies 已列出。

## C. Readiness gating
- [ ] blocked/provisional/constrained 已按最保守口径汇总。
- [ ] cycle、over-allocation、高风险外部依赖已影响 readiness。

## D. Package completeness
- [ ] 六段式结构完整。
- [ ] 风险清单有 owner 与 mitigation。
- [ ] event_emission 已写 produced.n180.planning_package。
