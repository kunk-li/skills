# Common failure modes v2.2

- F1: 只把三份表拼接，没有做 readiness gating。
- F2: 重新改写 task_id，导致 056/057 无法回指。
- F3: 用 PERT expected 冒充 P80 承诺日期。
- F4: 忽略 057 的 dependency cycle 或 high-risk external dependency。
- F5: 风险清单没有 owner、due date 或 fallback。
- F6: 把 planning package 责任回塞给 055/056/057 任一单 skill。
