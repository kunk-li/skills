# N180 planning package scoring rubric v2.2

总分 10 分，每项 0-2 分。

## 1. Source integration
- 2 分：055/056/057 三源完整 join，异常清晰。
- 1 分：能 join 主要字段，但有未解释缺口。
- 0 分：只是复制粘贴三份产物。

## 2. Readiness and gate logic
- 2 分：blocked/constrained/provisional 传导正确。
- 1 分：有 readiness，但规则不完整。
- 0 分：不做门禁汇总。

## 3. Planning usefulness
- 2 分：任务、估算、依赖、资源、外部依赖能支持排期。
- 1 分：内容可读但仍需大量整理。
- 0 分：不能用于计划。

## 4. Risk rollup
- 2 分：风险有 severity、owner、mitigation、fallback。
- 1 分：风险有描述但不可执行。
- 0 分：风险缺失。

## 5. Downstream handoff
- 2 分：N190/N220/N240/N270/N330/N350 消费关系清楚。
- 1 分：部分节点可用。
- 0 分：没有下游契约。
