---
name: n180-planning-package-aggregator
description: aggregate n180 task breakdown, effort estimation, and dependency identification artifacts into a single workflow-aligned planning package. use when chatgpt has or is asked to combine 开发任务拆分表.csv, 工时估算表.csv, 研发依赖清单.csv, or their markdown equivalents into N180_planning_package.md with readiness gating, risk rollup, downstream handoff, and produced.n180.planning_package event metadata.
---
# n180-planning-package-aggregator

## Role / 角色定位
本 skill 对齐 `skills_workflow_v2` 中的 N180「研发任务规划」节点级聚合职责。

它是 **orchestration_result** 型技能：目标是把 `development-task-breakdown`、`effort-estimation-assistant`、`dependency-identification` 的产物合并成一份可交付的 **`N180_planning_package.md`**，而不是重新拆任务、重新估算或重新画依赖图。

### Boundary / 边界
- 负责校验、合并、去冲突、排序、摘要和节点级 readiness 判定。
- 负责将任务、估算、依赖、资源、外部依赖和风险合成一包式交付。
- 不负责替代 055 生成任务；任务粒度问题回推 055。
- 不负责替代 056 做 PERT / Monte Carlo；估算不一致回推 056。
- 不负责替代 057 做 CPM / cycle detection；依赖不一致回推 057。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `package_summary`：轻量汇总，适合周会、评审和上层同步。
- `release_planning_package`：默认模式，生成完整六段式 `N180_planning_package.md`。
- `gate_review_package`：聚焦 blocked / constrained 项、承诺日期、资源冲突和外部依赖，用于门禁或人工确认。

## Primary inputs / 主要输入
优先消费以下 N180 sibling artifacts：
- `开发任务拆分表.csv` 或 055 markdown 输出
- `工时估算表.csv` 或 056 markdown 输出
- `研发依赖清单.csv` 或 057 markdown 输出

可选增强输入：
- `技术方案分析.md`
- `模块边界图.md`
- 团队容量、版本目标日期、发布窗口、N370 多 skill 执行计划

## Standalone rule / 独立使用规则
即使缺少某一份 sibling artifact，也可以单独使用，但必须降级：
- 只有 055：只能输出任务包和待估算/待依赖分析清单，`readiness: provisional`。
- 有 055 + 056，缺 057：不能给正式关键路径，`readiness` 至多为 `constrained`。
- 有 055 + 057，缺 056：不能给 P80/P95 承诺日期，`readiness` 至多为 `constrained`。
- 任一输入 `blocked`：package 默认 `blocked`，除非明确排除 blocked scope。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: orchestration_result`
  - `workflow_node: N180`
  - `producer_skill: n180-planning-package-aggregator`
  - `node_artifact_target: N180_planning_package.md`
  - `artifact_schema_version: n180.v2.2`
  - `source_artifacts[]`
  - `contract_status`
  - `event_emission`
- `executive_summary`
- `section_1_task_plan`
- `section_2_estimation_summary`
- `section_3_dependency_and_critical_path`
- `section_4_resource_load_balance`
- `section_5_external_dependency_tracking`
- `section_6_risk_register`
- `downstream_handoff`
- `self_check`

## Merge rules / 合并规则
- `task_id` 是主键。055 为任务主数据源，056/057 只能引用或补充，不得静默改名。
- 若 056 或 057 引用了 055 不存在的 `task_id`，列入 `join_anomalies[]`。
- `granularity` 优先于 legacy `task_size_tier`；两者不一致时标 `schema_warning`。
- 任务的 `acceptance_criteria` 是可读描述；`traces_to.acs` 是稳定 AC-ID 引用。
- 估算承诺优先使用 056 的 P80；若 Monte Carlo 未启用，则只输出 PERT 汇总，不给伪承诺日期。
- 关键路径、float、资源冲突和外部依赖跟踪以 057 为准。
- readiness 取最保守口径：blocked > constrained/provisional > pass。

## Package readiness gating / readiness 判定
- 任一 source artifact 为 `blocked`，package 为 `blocked`，除非 blocked scope 明确不在本 release 范围。
- 任一 source artifact 为 `provisional`，package 至多为 `constrained`。
- 057 检测到循环依赖，package 为 `blocked`。
- 056 发现团队 load > 100%，package 至少为 `constrained`，并进入风险清单。
- 高风险外部依赖没有 owner/contact/fallback 时，package 至少为 `constrained`。

## Execution workflow / 执行流程
1. 识别输入产物、版本、readiness 与 source artifact metadata。
2. 以 055 的 `task_id` 构建主任务索引。
3. Join 056 估算记录，补 effort、duration、buffer、confidence、P50/P80/P95。
4. Join 057 依赖记录，补 dependency、critical path、float、resource、external tracking。
5. 执行 join anomalies 与 schema warnings 检查。
6. 运行 readiness gating，给出 package 级 `readiness`。
7. 生成六段式 `N180_planning_package.md`。
8. 生成 `produced.n180.planning_package` 事件 metadata。
9. 输出下游 handoff 给 N190 / N220 / N240 / N270 / N330 / N350 / N370。
10. 使用 checklist 与 common-failure review 自检。

## Reference files / 参考文件
- `references/output-template.md`
- `references/merge-rules.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/scoring-rubric.md`
- `references/orchestration.md`
- `references/example-io.md`
