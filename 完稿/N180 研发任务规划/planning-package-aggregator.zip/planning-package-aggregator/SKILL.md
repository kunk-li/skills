---
name: planning-package-aggregator
description: aggregate task breakdown, effort estimation, and dependency identification artifacts into a single workflow-aligned planning package. use when an llm has or is asked to combine 开发任务拆分表.csv, 工时估算表.csv, 研发依赖清单.csv, or their markdown equivalents into a planning package with readiness gating, risk rollup, downstream handoff, and produced-event metadata.
---
# planning-package-aggregator

## Role / 角色定位
本 skill 对齐 `skills_workflow_v2` 中的 N180「研发任务规划」节点级聚合职责。

它是 **orchestration_result** 型技能：目标是把 `development-task-breakdown`、`effort-estimation-assistant`、`dependency-identification` 的产物合并成一份可交付的 **`N180_planning_package.md`**，而不是重新拆任务、重新估算或重新画依赖图。

### Boundary / 边界
- 负责校验、合并、去冲突、排序、摘要和节点级 readiness 判定。
- 负责将任务、估算、依赖、资源、外部依赖和风险合成一包式交付。
- 不负责替代 055 生成任务；任务粒度问题回推 055。
- 不负责替代 056 做 PERT / Monte Carlo；估算不一致回推 056。
- 不负责替代 057 做 CPM / cycle detection；依赖不一致回推 057。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `package_summary`：轻量汇总，适合周会、评审和上层同步。
- `release_planning_package`：默认模式，生成完整六段式 `N180_planning_package.md`。
- `gate_review_package`：聚焦 blocked / constrained 项、承诺日期、资源冲突和外部依赖，用于门禁或人工确认。


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 全部 3 个上游 contributor (task-breakdown / effort / dependency) 齐备 | 完整 N180 包 + 跨 skill 一致性校验 |
| `provisional` | 2 个 contributor 齐备 + 1 个 partial | 输出聚合结果但标 aggregation_status: partial + missing_contributors[] |
| `constrained` | 仅 1 个 contributor 齐备 | 仅输出本部分，不聚合 |
| `blocked` | 0 个 contributor 输出 | 输出 `request_for_inputs[]` 引导用户先跑 N180 sibling |

## Primary inputs / 主要输入
优先消费以下 N180 sibling artifacts：
- `开发任务拆分表.csv` 或 055 markdown 输出
- `工时估算表.csv` 或 056 markdown 输出
- `研发依赖清单.csv` 或 057 markdown 输出

可选增强输入：
- `技术方案分析.md`
- `模块边界图.md`
- 团队容量、版本目标日期、发布窗口、N370 多 skill 执行计划

## Standalone rule / 独立使用规则
即使缺少某一份 sibling artifact，也可以单独使用，但必须降级：
- 只有 055：只能输出任务包和待估算/待依赖分析清单，`readiness: provisional`。
- 有 055 + 056，缺 057：不能给正式关键路径，`readiness` 至多为 `constrained`。
- 有 055 + 057，缺 056：不能给 P80/P95 承诺日期，`readiness` 至多为 `constrained`。
- 任一输入 `blocked`：package 默认 `blocked`，除非明确排除 blocked scope。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: orchestration_result`
  - `workflow_node: N180`
  - `producer_skill: planning-package-aggregator`
  - `node_artifact_target: N180_planning_package.md`
  - `artifact_schema_version: n180.v2.2`
  - `source_artifacts[]`
  - `contract_status`
  - `event_emission`
- `executive_summary`
- `section_1_task_plan`
- `section_2_estimation_summary`
- `section_3_dependency_and_critical_path`
- `section_4_resource_load_balance`
- `section_5_external_dependency_tracking`
- `section_6_risk_register`
- `downstream_handoff`
- `self_check`

## Merge rules / 合并规则
- `task_id` 是主键。055 为任务主数据源，056/057 只能引用或补充，不得静默改名。
- 若 056 或 057 引用了 055 不存在的 `task_id`，列入 `join_anomalies[]`。
- `granularity` 优先于 legacy `task_size_tier`；两者不一致时标 `schema_warning`。
- 任务的 `acceptance_criteria` 是可读描述；`traces_to.acs` 是稳定 AC-ID 引用。
- 估算承诺优先使用 056 的 P80；若 Monte Carlo 未启用，则只输出 PERT 汇总，不给伪承诺日期。
- 关键路径、float、资源冲突和外部依赖跟踪以 057 为准。
- readiness 取最保守口径：blocked > constrained/provisional > pass。

## Package readiness gating / readiness 判定
- 任一 source artifact 为 `blocked`，package 为 `blocked`，除非 blocked scope 明确不在本 release 范围。
- 任一 source artifact 为 `provisional`，package 至多为 `constrained`。
- 057 检测到循环依赖，package 为 `blocked`。
- 056 发现团队 load > 100%，package 至少为 `constrained`，并进入风险清单。
- 高风险外部依赖没有 owner/contact/fallback 时，package 至少为 `constrained`。
- 只有 056+057 缺 055 时：不能生成任务级 package；输出估算+依赖摘要，`readiness: constrained`，并在 executive_summary 中说明任务数据缺失。

## Risk register priority classification / 风险清单优先级分级

`section_6_risk_register` 中的每条风险必须标注优先级，以便 N380 SLA 队列分级处理：

| 级别 | 定义 | SLA 处置要求 |
|---|---|---|
| **P0** | 当前 Sprint 必须解决；阻塞关键路径或 release gate | 24h 内人工介入，写入 N380 SLA 队列 |
| **P1** | 本版本必须跟踪；影响工期或质量但有 workaround | 3 工作日内有 owner 和 action plan |
| **P2** | 低风险或远期；记录在册但不需立即处置 | 下一 Sprint 评审时复查 |

```yaml
# 风险条目示例
risk_id: RISK-003
description: "第三方支付接口 SLA 不明确，可能影响联调窗口"
priority: P1
owner: "张工"
impact_tasks: [TASK-S2-012, TASK-S2-013]
sla_deadline: "2026-05-20"
n380_escalation: true   # P0/P1 自动标记，由聚合器填写
```

## Execution workflow / 执行流程
1. 识别输入产物、版本、readiness 与 source artifact metadata。
2. 以 055 的 `task_id` 构建主任务索引（若 055 缺失，以 056 或 057 的任务引用为临时主键，标注 `readiness: constrained`）。
3. Join 056 估算记录，补 effort、duration、buffer、confidence、P50/P80/P95。
4. Join 057 依赖记录，补 dependency、critical path、float、resource、external tracking（含 `n355_tracking_ref`）。
5. 执行 join anomalies 与 schema warnings 检查。
6. 运行 readiness gating，给出 package 级 `readiness`。
7. 生成六段式 `N180_planning_package.md`，其中 `section_6_risk_register` 的每条风险标注 P0/P1/P2 优先级。
8. 生成 `produced.n180.planning_package` 事件 metadata，**显式声明订阅者**：

```yaml
produced_event:
  event_type: produced.n180.planning_package
  contract_version: n180.v2.2
  artifact_ref: N180_planning_package.md
  emitted_for: [N190, N220, N240, N270, N330, N340, N350, N370]
  p0_risks_count: 0    # 若 > 0，同时触发 N380 SLA 队列入队
  n380_escalation: false
```

9. 若 `p0_risks_count > 0`，在 downstream_handoff 中添加 `n380_sla_items[]`，格式与 N380 门禁输入契约对齐。
10. 输出下游 handoff 给 N190 / N220 / N240 / N270 / N330 / N350 / N370。
11. 使用 checklist 与 common-failure review 自检。

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Machine-readable self_check rules

- `R01_readiness_conservative`: package readiness 取所有 source artifacts 中最保守值（blocked > constrained/provisional > pass）; `on_violation: reject`
- `R02_no_commitment_without_055`: 缺少 `开发任务拆分表.csv` 时不得输出 P80 承诺日期; `on_violation: reject`
- `R03_blocked_scope_checked`: 标为 blocked 的任务必须检查是否在当前 release scope 内；不在则可排除并注明; `on_violation: warn`
- `R04_join_anomalies_recorded`: 056/057 引用了 055 中不存在的 task_id 时必须进入 `join_anomalies[]`; `on_violation: reject`
- `R05_cycle_blocks_package`: 057 检测到循环依赖时 package 必须设为 `blocked`; `on_violation: reject`
- `R06_load_over_100_constrained`: 056 发现 team load > 100% 时 package 至少为 `constrained`; `on_violation: warn`
- `R07_external_dep_has_owner`: 高风险外部依赖必须有 owner/contact/fallback; `on_violation: warn`
- `R08_p0_escalated_to_n380`: `p0_risks_count > 0` 时必须在 `downstream_handoff` 中声明 `n380_sla_items[]`; `on_violation: reject`
- `R09_six_sections_present`: `release_planning_package` 模式必须输出完整六段（section_1 ~ section_6）; `on_violation: reject`
- `R10_risk_priority_classified`: `section_6_risk_register` 每条风险必须有 P0/P1/P2 优先级; `on_violation: reject`

## Stack-agnostic orchestration rule

本 skill 是纯编排层，不产生代码产物，因此不设 `tech_stack_adapter`。但在以下情况必须显式声明栈偏好：
- `section_1_task_plan` 中的任务引用了特定语言框架（如 Spring Boot、NestJS）时，必须在 `executive_summary` 中注明技术栈；
- 若 055 产出的任务包含多语言混合栈，必须在 `section_4_resource_load_balance` 中按语言域区分资源池，避免把 Java 开发资源分配到 TypeScript 任务。

## Common failure modes

1. **055 缺失时仍给 P80 承诺日期** — 仅有估算和依赖数据时生成形式完整的 P80 日期，但任务主键缺失导致承诺无法追溯。修复：缺少 055 时 `readiness` 至多 `constrained`，不输出伪承诺日期，仅输出估算汇总。
2. **Blocked scope 未排除** — 节点内有一个 blocked 任务就将整包标为 blocked，实际上该任务可能不在当前 release 范围。修复：检查 blocked 任务是否带 `sprint.priority_in_sprint: won_t_have`；若确认不在 release scope，可将包 readiness 提升并在 executive_summary 注明排除原因。
3. **Join anomalies 静默忽略** — 056/057 引用了 055 中不存在的 task_id，未进入 `join_anomalies[]`，导致估算和依赖数据悬空。修复：join 阶段必须校验所有 task_id 是否有 055 主记录；不匹配时强制写入 `join_anomalies[]` 并降低受影响记录的 confidence。

## Reference files / 参考文件
- `references/planning-aggregator-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/planning-aggregator-self-check.yaml`: R01-R10 机读门禁规则
- `references/planning-aggregator-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/output-template.md`
- `references/merge-rules.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/scoring-rubric.md`
- `references/orchestration.md`
- `references/example-io.md`
