# N180 planning package 交付检查清单 v2.4

## A. 输入完整性 (must-pass)

- [ ] 已识别 task-breakdown / effort-estimation / dependency-identification 三个 contributor 的输出
- [ ] 每个 contributor 的 readiness 已记录到 `readiness_inheritance` 字段
- [ ] 缺失的 contributor 已列入 `missing_contributors[]` 并标记 `aggregation_status: partial`
- [ ] task-breakdown 的 task_id 作为聚合主键（不重新编号）
- [ ] 每个 contributor 的 schema_version 已校验且兼容

## B. Readiness 聚合规则 (must-pass)

- [ ] 聚合 readiness = min(各 contributor readiness)（min 法则）
- [ ] 任一 contributor 缺失 → 整包至少 `constrained`
- [ ] 检测到 dependency cycle → 整包 `blocked`
- [ ] 检测到 high-risk external dependency 无 fallback → 整包 `provisional`

## C. 引用完整性 (must-pass)

- [ ] effort_estimation 中的 task_id 全部存在于 task_breakdown
- [ ] dependency_identification 中的 task_id 全部存在于 task_breakdown
- [ ] 引用不存在的 task_id 进 `referential_integrity_violations[]`，**不静默丢弃**
- [ ] 跨产物字段单位一致（effort 全部 hours 或全部 days，不混用）
- [ ] 检测到单位不一致进 `cross_contributor_field_drift[]`

## D. Milestone 与 Commitment (must-pass)

- [ ] 每个 milestone 输出 3 档日期：p50_date / p80_date / p95_date
- [ ] 默认承诺线使用 p80（不是 PERT expected = p50）
- [ ] confidence_level 字段显式声明（0.80 默认）
- [ ] milestone 排序与 dependency 拓扑一致
- [ ] 拓扑冲突进 `milestone_dependency_conflicts[]`

## E. 风险清单完整性 (must-pass)

- [ ] 每条 risk 含 description + severity + owner + target_resolution_date + fallback_strategy 五件套
- [ ] owner 是具体人或角色（不是"团队"）
- [ ] fallback_strategy 至少给一个具体动作
- [ ] 缺字段的 risk 进 `pending_risk_details[]`，**不写入** `risks[]`

## F. 责任路由 (must-pass)

- [ ] 缺失字段每条都明确归属到具体 sibling skill
- [ ] `routing_table[]` 含 (missing_field, route_to_skill, suggested_query)
- [ ] 无字段缺失时 routing_table 为空数组（不省略）

## G. 阻塞项处理 (must-pass)

- [ ] 顶层 `top_level_blockers[]` 列出所有 critical 阻塞项
- [ ] 每个 blocker 含 type + description + affected_tasks + suggested_resolution
- [ ] cycle 类 blocker 含 cycle_resolution_required: true

## H. 包结构与事件 (must-pass)

- [ ] 包内含 6 段：metadata / executive_summary / milestone_table / risks / dependencies_summary / handoff
- [ ] event_emission 含 produced.n180.planning_package.completed
- [ ] event 含 contributors_received / contributors_expected / total_tasks 字段

## I. 不变量 (must-not)

- [ ] 不重新编号 task_id
- [ ] 不用 PERT expected 当承诺线
- [ ] 不忽略 cycle 或 high-risk 标记
- [ ] 不把责任回塞给 sibling

## J. 跨 skill 协作 (recommended)

- [ ] downstream_handoff 标识 N190 / N200 / N210 应消费的字段
- [ ] task_id_lineage 字段保留每个 task_id 的源头追溯
- [ ] 输出格式与 `n180-integration-map.md` 中的 N180 → N190 字段映射一致
