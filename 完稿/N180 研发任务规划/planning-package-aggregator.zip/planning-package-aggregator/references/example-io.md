# planning-package-aggregator 示例 v2.4

## Scenario A: 完整聚合（pass）

### Input

3 个 contributor 的产物：
- `task_breakdown.csv`（55 个 task，全部 readiness: pass）
- `effort_estimation.csv`（PERT 三点估时，全部含 confidence interval）
- `dependency_identification.csv`（含 12 条依赖、0 个 cycle、3 条 high-risk external）

### Output excerpt

```yaml
artifact_contract:
  schema_version: n180.planning-package-aggregator.v2.4
  produced_by: planning-package-aggregator
  selected_mode: release_planning_package
  readiness: pass
  evidence_profile: full_workflow_context
  workflow_node: N180
  node_artifact_target: N180_planning_package.zip

readiness_inheritance:
  task_breakdown:        {readiness: pass, contributor: development-task-breakdown}
  effort_estimation:     {readiness: pass, contributor: effort-estimation-assistant}
  dependency_identification: {readiness: pass, contributor: dependency-identification}
  rule: min_of_contributors
  result: pass

aggregation_status: complete
contributors_received: 3
contributors_expected: 3

milestone_table:
  - milestone_id: M1
    name: "Schema and infra ready"
    p50_date: 2026-05-15
    p80_date: 2026-05-17
    p95_date: 2026-05-22
    confidence_level: 0.80
    task_ids: [T-001, T-002, T-003]
    blocking_dependencies: []

  - milestone_id: M2
    name: "Core service implemented"
    p50_date: 2026-05-25
    p80_date: 2026-05-29
    p95_date: 2026-06-05
    confidence_level: 0.80
    task_ids: [T-004, T-005, T-006, T-007, T-008]
    blocking_dependencies: [DEP-002]   # waiting test env

risks:
  - risk_id: RISK-001
    description: "测试环境账号申请通常需 5 工作日，可能阻塞 M2"
    severity: medium
    owner: qa-lead
    target_resolution_date: 2026-05-12
    fallback_strategy: "提前向 infra 团队申请；若延期则准备 mock 数据集"
    related_dependencies: [DEP-002]

routing_table: []   # 无遗漏字段
referential_integrity_violations: []

produced_event:
  name: produced.n180.planning_package.completed
  contributors: 3
  total_tasks: 55
  total_effort_hours_p80: 384
```

### Self-score

```yaml
self_score:
  readiness_gating: 3        # min 法则正确应用
  task_id_lineage: 3         # 所有 task_id 保留 contributor 原值
  pert_p80_used: 3           # commitment date 用 p80, 不是 expected
  topology_consistency: 3    # milestone 与 dependency 拓扑一致
  total: 12
  band: S+
```

---

## Scenario B: Partial aggregation（dependency 缺失）

### Input

- task_breakdown.csv: 30 个 task，readiness pass
- effort_estimation.csv: 30 个估时，readiness provisional（缺历史数据）
- dependency_identification.csv: **缺失**

### Output excerpt

```yaml
artifact_contract:
  selected_mode: release_planning_package
  readiness: constrained          # min(pass, provisional, missing) = constrained
  aggregation_status: partial

readiness_inheritance:
  task_breakdown:    {readiness: pass}
  effort_estimation: {readiness: provisional, reason: lack_historical_data}
  dependency_identification: missing
  rule: min_of_contributors
  result: constrained

contributors_received: 2
contributors_expected: 3
missing_contributors: [dependency-identification]

routing_table:
  - missing_field: dependencies
    route_to_skill: dependency-identification
    suggested_query: "请运行 dependency-identification 处理 task_breakdown.csv"
  - missing_field: confidence_interval
    route_to_skill: effort-estimation-assistant
    suggested_query: "请补充团队历史 velocity 数据以提升 effort 置信度"

milestone_table:
  - milestone_id: M1
    p50_date: 2026-05-15
    p80_date: 2026-05-22         # wider interval due to provisional effort
    p95_date: 2026-06-01
    confidence_level: 0.80
    notes: "依赖关系未识别, p80 已加 30% buffer"
```

### Self-score

```yaml
self_score:
  readiness_gating: 3        # 正确降级到 constrained
  task_id_lineage: 3
  pert_p80_used: 3
  topology_consistency: 1    # 无 dependency 时 milestone 无法基于拓扑校验
  total: 10
  band: A
```

---

## Scenario C: Cycle detected（blocked）

### Input

- 三个 contributor 都齐备
- dependency 图含 1 个 cycle: T-005 → T-008 → T-005

### Output excerpt

```yaml
artifact_contract:
  readiness: blocked
  aggregation_status: complete

top_level_blockers:
  - blocker_id: BLK-001
    type: dependency_cycle
    description: "T-005 ↔ T-008 形成循环依赖"
    affected_tasks: [T-005, T-008]
    cycle_resolution_required: true
    suggested_resolution:
      - 1. 评估能否延后 T-008 的 T-005 依赖
      - 2. 评估能否拆分 T-005 为前置/后置两部分
      - 3. 与 dependency-identification 复核依赖语义

milestone_table: []   # 拓扑排序失败, 不输出 milestone

routing_table:
  - missing_field: cycle_resolution
    route_to_skill: dependency-identification
    suggested_query: "T-005 和 T-008 之间的循环依赖需要澄清, 哪个方向是真依赖？"
```

---

## Common readiness states

| readiness | 触发条件 |
|---|---|
| `pass` | 3 个 contributor 全部 pass + 无 blocker |
| `provisional` | 任一 contributor 是 provisional + 无 blocker |
| `constrained` | 缺 1-2 个 contributor + 无 cycle |
| `blocked` | dependency cycle 或 critical 外部依赖无 fallback |
