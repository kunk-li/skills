# planning-package-aggregator 评分标准 v2.4

## 总览

输出按 4 个维度评分，每维 0-3 分，总分 0-12。

| 总分 | 等级 | 含义 |
|---|---|---|
| 11-12 | **S** | 可直接消费 |
| 9-10 | **A** | 生产可用 |
| 6-8 | **B** | 需人工修订 |
| ≤5 | **C** | 不建议消费 |

---

## 维度 1: Readiness 聚合纪律 (readiness_aggregation_discipline)

衡量: 整包 readiness 是否正确反映 3 个 contributor 的最低水位.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% 正确应用 min 法则; readiness_inheritance 字段完整列出每个 contributor 的 readiness; 检测到 cycle 自动降级到 blocked; 高风险无 fallback 自动降级到 provisional |
| **A (2)** | min 法则正确, 但 readiness_inheritance 字段缺少部分明细 |
| **B (1)** | 仅简单取最差状态, 未输出明细 |
| **C (0)** | 用 max 法则或忽略 contributor readiness |

---

## 维度 2: 引用完整性 (referential_integrity)

衡量: task_id 跨 contributor 一致性 + 单位一致性.

| 等级 | 标准 |
|---|---|
| **S (3)** | task_id 100% 保留 contributor 原值; 跨产物引用做完整性校验; 不一致进 referential_integrity_violations[]; 单位字段做归一化 + cross_contributor_field_drift[] |
| **A (2)** | task_id 保留原值, 跨产物校验完整, 但单位不一致检测不全 |
| **B (1)** | task_id 保留, 但跨产物有 silent drop |
| **C (0)** | 重新编号 task_id, 破坏引用 |

---

## 维度 3: Milestone 承诺纪律 (milestone_commitment)

衡量: 是否使用 P80 而非 expected; 拓扑一致性.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% milestone 输出 p50/p80/p95 三档; 默认承诺线 p80; confidence_level 显式 0.80; milestone 排序与 dependency 拓扑一致; 不一致进 milestone_dependency_conflicts[] |
| **A (2)** | p80 用于承诺, 但只输出 p80 单档; 拓扑校验完整 |
| **B (1)** | 用 expected 当承诺线, 或拓扑校验缺失 |
| **C (0)** | 用 expected 且无任何 confidence 标识 |

---

## 维度 4: 责任路由与风险完整度 (responsibility_routing)

衡量: 缺失字段的路由 + risk 五件套完整度.

| 等级 | 标准 |
|---|---|
| **S (3)** | 100% 缺失字段都有明确 route_to_skill; routing_table 含 suggested_query; 100% risk 含五件套 (description + severity + owner + due_date + fallback); 缺字段的 risk 进 pending_risk_details[] |
| **A (2)** | 路由完整, 但 risk 五件套有 80%+ 完整 |
| **B (1)** | 仅给路由, 未生成 suggested_query; 或 risk 仅含 3 件套 |
| **C (0)** | 把责任回塞给人工或 sibling |

---

## 红线 (违反则直接归 C 或 0)

- 检测到 cycle 但 readiness 仍 pass -> 严重错误
- 重新编号 task_id 破坏跨产物引用 -> 严重错误
- 用 PERT expected 当承诺线 -> 等于让一半项目超期
- risk 没有 owner 或 fallback -> 风险清单失去价值
- 跨 contributor 字段单位不一致未检出 -> silent corruption

---

## 等级映射示例

- **S+ (12)**: 全部 4 维满分
- **S (11)**: 3 维满分 + 1 维 A
- **A (9-10)**: readiness 聚合正确, milestone 用 p80, 但 routing 或 risk 有缺
- **B (6-8)**: 引用完整性或拓扑校验缺失
- **C (<6)**: 严重违反任一红线

---

## 自评示例

```yaml
self_score:
  readiness_aggregation_discipline: 3
  referential_integrity: 3
  milestone_commitment: 3
  responsibility_routing: 2  # routing 完整但 risk fallback 部分模糊
  total: 11
  band: S
  rationale: 2 条 risk 的 fallback 仅给方向, 未到具体动作
```
