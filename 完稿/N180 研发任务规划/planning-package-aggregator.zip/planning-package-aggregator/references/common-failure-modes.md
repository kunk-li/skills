# planning-package-aggregator 常见失败模式 v2.4

## 通用部分（F1-F4）

### F1. 只把三份表拼接，没有做 readiness gating

**症状**：直接把 `task_breakdown.csv`、`effort_estimation.csv`、`dependency_identification.csv` 三份产物 concat 成一个 zip 包就交付。三份产物各自的 readiness 字段被忽略，aggregation 输出统一标 `pass`。

**影响**：下游 N190/N200/N210 节点消费聚合包时，以为整个规划已经收敛，会基于错误前提启动后续工作。例如某个 task 仅是 provisional 估时，但聚合标 pass 后，下游做容量规划，导致排期失实。

**修正**：
- aggregation 的 readiness 由 3 个 contributor 的最低 readiness 决定（min 法则）。
- 输出 `readiness_inheritance` 字段显式列出每个 contributor 的 readiness 来源。
- 任一 contributor 缺失 → 整包 readiness = `constrained` + `aggregation_status: partial` + `missing_contributors[]`。

---

### F2. 重新改写 task_id 导致跨产物引用断链

**症状**：聚合时为了 task_id 在新包内"看起来连续"，重新生成 1, 2, 3...，破坏了 task-breakdown 已分配的稳定 ID（T-001, T-002）。effort 和 dependency 表通过 task_id 引用的关系全部失效。

**影响**：跨产物的引用链断裂；下游消费者拿到 ID 后无法在原始 contributor 产出中追溯依据。与历史包对照时（版本对比、回归分析）ID 不稳定，无法做 diff。

**修正**：
- task_id **完全保留** 来自 task-breakdown 的原始值；聚合层不重新编号。
- effort/dependency 中引用了不存在的 task_id 应进 `referential_integrity_violations[]` 而非静默丢弃。
- 输出 `task_id_lineage` 字段标注每个 task_id 的源头。

---

### F3. 用 PERT expected 冒充 P80 承诺日期

**症状**：effort_estimation 给出 PERT 三点估算，expected = (O+4M+P)/6。聚合层把 expected 直接当作 P80 commitment date 写进 milestone 表。

**影响**：PERT expected 是 50 分位（理论上 50% 概率按时完成），不是承诺线。承诺线应该是 P80 或 P95。把 expected 当作承诺等于让一半项目超期。

**修正**：
- 对每个 milestone 输出 3 档：`p50_date` / `p80_date` / `p95_date`。
- 默认承诺线用 p80 而非 expected。
- milestone 表中显式标 `confidence_level: 0.80`。

---

### F4. 忽略 dependency cycle 或 high-risk external dependency

**症状**：dependency_identification.csv 中标了 `cycle_detected: true` 或 `risk_level: high` 的依赖，聚合层没有把这些升级到顶层 status，整体 readiness 仍是 pass。

**影响**：存在 dependency cycle 的项目无法做合理排程（拓扑排序失败但聚合层声称 pass）；high-risk 外部依赖被淹没在依赖表深处，决策者看不见。

**修正**：
- 聚合层显式扫描 dependency 表中的 `cycle_detected` 和 `risk_level: high` 标记，输出 `top_level_blockers[]`。
- 存在 cycle → readiness 自动降级到 `blocked`。
- 存在 high-risk external dependency 但缺 fallback → readiness 降级到 `provisional`。

---

## 本 skill 重点（F5-F8）

### F5. 风险清单没有 owner / due date / fallback

**症状**：聚合产出含 `risks[]` 数组，每条 risk 仅有 description 和 severity，缺 `owner`、`due_date`、`fallback_strategy`。

**影响**：风险清单是聚合包对决策者最直接的价值产物。无 owner 等于无人负责；无 due_date 等于不知何时复盘；无 fallback 等于风险触发时没有应对预案。这种 risk 只是装饰，不会被采取行动。

**修正**：
- 每条 risk 必填四件套：description + owner + target_resolution_date + fallback_strategy。
- owner 必须是具体人或角色（不是"团队"这种空话）。
- fallback_strategy 至少给一个具体动作。
- 缺任一字段的 risk 进 `pending_risk_details[]`，**不写入** `risks[]`。

---

### F6. 把责任回塞给 055/056/057 任一单 skill

**症状**：聚合输出"待补充字段"或"未识别的依赖"等责任不清的 placeholder，让下游或人工去找 task-breakdown / effort / dependency 哪个 sibling 该补。聚合层不做主动 dispatch。

**影响**：聚合的核心价值就是责任路由——告诉每个 contributor 它该补什么。把这个责任丢给人工或下游等于聚合层不做事。

**修正**：
- 缺失字段必须明确归属到具体的 sibling skill：
  - 缺任务粒度 → 路由到 `development-task-breakdown`
  - 缺估时数据 → 路由到 `effort-estimation-assistant`
  - 缺依赖关系 → 路由到 `dependency-identification`
- 输出 `routing_table[]` 字段，每行 = (missing_field, route_to_skill, suggested_query)。

---

### F7. 跨 contributor 的字段单位/类型不一致未被检出

**症状**：task-breakdown 给某 task 的 effort 估算字段是 `effort_days`，但 effort_estimation 给同一 task 用的字段是 `effort_hours`。两者数值都"对"但单位错位，聚合时直接拼接。

**影响**：看起来 effort 数据齐备但实际跨表不一致，下游做汇总（sum/avg）会出严重偏差（1 倍或 8 倍）。这种 silent mismatch 难发现。

**修正**：
- 聚合层做 schema validation：每个共享字段（task_id、effort、dependency_id、risk_level）必须在所有 contributor 的产出中使用同一类型 + 同一单位。
- 检测到不一致输出 `cross_contributor_field_drift[]`。
- 单位字段必须在 contract 中显式声明，聚合时做归一化（统一到 hours）。

---

### F8. milestone 表与 dependency 表的拓扑不一致

**症状**：聚合输出 milestone 表（M1 → M2 → M3）和 dependency 表（task 之间依赖），但 milestone 排序与 task 依赖图不一致——M2 包含的 task 依赖于 M3 包含的 task。

**影响**：milestone 是面向决策者的高层视图，dependency 是面向工程的低层视图。两者不一致等于规划包内部矛盾，下游消费时不知该信哪个。

**修正**：
- 聚合层基于 dependency graph 做拓扑排序，验证 milestone assignments 与 dependency 一致。
- 不一致时输出 `milestone_dependency_conflicts[]`，每条标识冲突的 (milestone_id, task_id, conflicting_dependency)。
- 严重不一致 → readiness 降级到 `provisional` 直到人工裁决。
