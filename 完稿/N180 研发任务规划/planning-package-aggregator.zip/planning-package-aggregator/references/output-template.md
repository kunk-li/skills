# Output Template: N180_planning_package.md v2.2

## 1. Metadata

```yaml
metadata:
  selected_mode: release_planning_package
  readiness: pass | constrained | blocked | provisional
  function_bias: orchestration_result
  workflow_node: N180
  producer_skill: planning-package-aggregator
  node_artifact_target: N180_planning_package.md
  artifact_schema_version: n180.v2.2
  source_artifacts:
    - 开发任务拆分表.csv
    - 工时估算表.csv
    - 研发依赖清单.csv
  contract_status:
    schema_valid: true | false
    self_check_passed: true | false
    join_anomalies: []
    blocking_issues: []
  event_emission:
    produced_event: produced.n180.planning_package
    state_event: state.n180.ready | state.n180.constrained | state.n180.blocked
```

## 2. Executive summary

- 本次规划范围：
- 总任务数 / must_have 数 / blocked 数：
- 总 effort / buffered effort / critical path duration：
- P80 承诺日期或说明：
- Top 3 风险：

## 3. 任务清单（按 sprint / wave）

| sprint | wave | task_id | task_name | task_kind | task_type | granularity | owner_role | priority_in_sprint | carry_over_policy | readiness | key_trace |
|---|---|---|---|---|---|---|---|---|---|---|---|

## 4. 估算汇总

| task_id | effort_pd_expected | duration_calendar_days | buffer_pd | confidence | uncertainty_level | p50 | p80 | p95 | notes |
|---|---:|---:|---:|---|---|---:|---:|---:|---|

若未启用 Monte Carlo，必须写明：`monte_carlo_simulation: not_enabled` 和原因。

## 5. 依赖图 + 关键路径

```mermaid
flowchart LR
  TASK-S1-001 --> TASK-S1-002
```

| task_id | earliest_start | earliest_finish | latest_start | latest_finish | slack | float_interpretation |
|---|---|---|---|---|---|---|

## 6. 资源 load balance

| resource_or_member | capacity_pd | assigned_pd | load_percentage | over_allocated | resolution |
|---|---:|---:|---:|---|---|

## 7. 外部依赖追踪

| dep_id | external_party | expected_ready_date | current_status | contact_person | blocker_severity | mitigation_plan | fallback_plan |
|---|---|---|---|---|---|---|---|

## 8. 风险清单

| risk_id | source | severity | affected_tasks | trigger | mitigation | owner | due_date |
|---|---|---|---|---|---|---|---|

## 9. Downstream handoff

| downstream_node | consumes | notes |
|---|---|---|
| N190 | T2 implementation tasks + API/schema traces | 代码骨架输入 |
| N220 | task_id + DoD + diff scope | PR 与 review 对齐 |
| N240 | task_id + AC + dependency risks | 自动化与回归编排 |
| N270 | must_finish + release risk + external deps | 发布准备 |
| N330 | technical decisions + runbook tasks | 文档生成 |
| N350 | risk register + blockers | 协同任务管理 |
