---
name: effort-estimation-assistant
description: estimate engineering effort, uncertainty, buffer, calendar impact, historical calibration, and probabilistic commitment percentiles from task breakdowns, technical solution notes, architecture outputs, nonfunctional constraints, or mixed planning evidence. use when chatgpt works in technical solution design / task management and must produce the n180 工时估算表.csv before sprint planning, staffing, test planning, release preparation, or stakeholder commitment.
---
# effort-estimation-assistant

## Role / 角色定位
本 skill 对齐 `skills_workflow_v2` 中的「技术方案设计 -> 任务管理 -> 工时估算表」。

它是 **decision_support_result** 型技能：目标是把任务、模块或需求范围转换成可沟通、可校准、可汇总的 **`工时估算表.csv`**，支撑排期和承诺决策，但不替代负责人最终拍板。

### Boundary / 边界
- 负责 PERT 三点估算、方差/标准差、置信度、缓冲策略、effort 与 duration 区分、历史校准、负载检查和项目级汇总。
- 在适用场景下负责 Monte Carlo 仿真并输出 P50/P80/P95/P99。
- 负责把估算假设和主要成本驱动写清楚。
- 不负责重新拆任务；若任务粒度失衡，应回推给 `development-task-breakdown`。
- 不负责完整依赖图、关键路径与资源冲突；这些由 `dependency-identification` 深化。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `quick_estimate`：轻量估算，只给核心项的 PERT 三点、区间、主要假设和低/中/高置信度。
- `probabilistic_estimate`：默认模式，要求 PERT、方差、标准差、4 因子不确定性、effort/duration 公式和 buffer 透明化。
- `calibrated_estimate`：在 probabilistic 基础上加入历史校准、团队负载、Monte Carlo 与项目级可承诺日期推导。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `技术方案分析.md`
- `模块边界图.md`
- `服务拆分建议.md`
- `数据流图.md`

### 节点内最强输入
- `开发任务拆分表.csv`
- `研发依赖清单.csv`

### 可选增强输入
- `可执行性检查单.csv`
- 历史任务估算与实际耗时
- 团队容量、角色构成、availability、日历窗口、外部联调计划
- `并发控制建议.md`
- `性能风险分析.md`
- `安全风险分析.md`
- `需求漏洞清单.csv`

## Standalone rule / 独立使用规则
即使没有完整任务表，只要有方案和模块范围，也可以单独使用。

降级规则：
- 若没有稳定任务清单，只能输出模块级或需求级粗估。
- 顶部必须标明 `readiness: provisional`。
- 必须显式区分 `confirmed / inferred / pending` 的估算对象。
- 缺乏关键依赖、可执行性检查或历史对照时，不得伪装成高可信度估算。

## Core output contract / 核心输出契约
默认输出 Markdown，并优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: decision_support_result`
  - `stage_position: technical_solution_design.task_management.effort_estimation`
  - `workflow_node: N180`
  - `producer_skill: effort-estimation-assistant`
  - `node_artifact_target: 工时估算表.csv`
  - `artifact_schema_version: n180.v2.2`
  - `evidence_profile`
  - `contract_status`
  - `event_emission`
- `estimate_registry[]`
- `assumption_set[]`
- `historical_calibration`
- `buffer_strategy`
- `uncertainty_assessment`
- `monte_carlo_simulation`，在触发条件满足时必须输出
- `team_load`
- `project_rollup`
- `confidence_summary`
- `downstream_handoff`
- `self_check`

### Required estimate fields / 必填字段
每条估算至少包含：
- `estimate_id`
- `task_id`
- `task_name`
- `estimate_scope`
- `three_point_estimate.optimistic`
- `three_point_estimate.most_likely`
- `three_point_estimate.pessimistic`
- `three_point_estimate.expected`
- `three_point_estimate.variance`
- `three_point_estimate.std_dev`
- `historical_calibration`
- `uncertainty_assessment`
- `confidence`
- `cost_drivers[]`
- `key_assumptions[]`
- `effort_pd`
- `duration_calendar_days`
- `buffer_allocation`

## Design rules / 设计规则
### PERT discipline / 三点估算纪律
默认使用 PERT：
- `expected = (optimistic + 4 * most_likely + pessimistic) / 6`
- `variance = ((pessimistic - optimistic) / 6)^2`
- `std_dev = sqrt(variance)`

不要只给单点数字而不解释区间来源。

### T-shirt mapping / 粒度映射
必须与 055 保持一致：
- `XS`: `< 0.5 pd`
- `S`: `0.5-2 pd`
- `M`: `2-5 pd`
- `L`: `5-10 pd`
- `XL`: `> 10 pd`

### Executability gate / 可执行性门禁
若输入包含 `可执行性检查单.csv` 或 N100 输出：
- `not_executable` 项不得进入正常 PERT 承诺；应标为 `blocked`、排除出承诺范围，或回推 055/需求侧处理。
- `needs_clarification` 项可以估算为 provisional，但必须降低 confidence 并列入 assumption_set。
- 若缺少可执行性检查单，不阻断 standalone 使用，但必须在 metadata 或 assumption 中说明 `executability_check: unavailable`。

### Historical calibration / 历史校准
若有历史数据，必须显式写：
- 相似任务样本
- `calibration_factor`
- `calibration_hint`: `likely_underestimate / likely_accurate / likely_overestimate`
- 校准前 / 校准后差异

若没有历史数据，必须写 `historical_calibration: unavailable`，不要假装组织已有成熟标定库。

### Buffer transparency / 缓冲透明化
必须分开写：
- `raw_estimate`
- `task_level_buffer`
- `sprint_level_buffer`
- `project_contingency`
- `communication_strategy.internal_reporting`
- `communication_strategy.stakeholder_reporting`

不能把 buffer 偷偷揉进 expected 数字里。

### Effort vs duration discipline / 工作量与时长纪律
- `effort_pd` 表示纯投入人天。
- `duration_calendar_days` 表示日历上的完成时间。
- 默认公式：`duration = effort / (availability * parallelism) + dependency_wait + review_wait + calendar_window_wait + meetings_overhead`。
- 如果缺少 availability 或 parallelism，必须说明采用的默认假设。

### Uncertainty discipline / 不确定性纪律
每个任务或模块必须输出 4 因子分解：
- `technical_unknowns`: none / low / medium / high
- `requirement_volatility`: stable / minor_changes / volatile
- `team_experience`: expert / familiar / learning / novice
- `external_dependencies`: none / manageable / risky / blocker

再汇总为 `uncertainty_level: low / medium / high / extreme`。
若 `extreme`，必须建议先 spike，再估算。

### Monte Carlo discipline / 仿真纪律
以下任一条件满足时，必须启用或至少建议 Monte Carlo：
- 任务数 > 50
- 用户要求对 stakeholder 承诺日期
- 关键路径包含多个 high risk 外部依赖
- 总 effort > 50 pd
- selected_mode = `calibrated_estimate`

输出至少包含：`simulation_runs`、`p50`、`p80`、`p95`、`p99`，若有起始日期则输出 `p50_date / p80_date / p95_date`。P80 是默认对外承诺口径。

## Machine-readable rules / 机读门禁规则
- `R01_pert_three_points`: 必须有三点估算; `on_violation: reject`。
- `R02_buffer_transparent`: buffer 独立标出; `on_violation: reject`。
- `R03_effort_vs_duration_separated`: effort 与 duration 分开; `on_violation: reject`。
- `R04_calibration_if_history_available`: 有历史数据必校准; `on_violation: reject`。
- `R05_extreme_uncertainty_needs_spike`: extreme 必先 spike; `on_violation: reject`。
- `R06_monte_carlo_for_commitment`: 承诺日期或大项目必须启用/建议 Monte Carlo; `on_violation: warn_or_reject_by_context`。
- `R07_over_allocation_warning`: load > 100% 必警告; `on_violation: warn`。
- `R08_blocked_not_precise`: blocked 任务不得给伪精确值; `on_violation: reject`。
- `R09_not_executable_excluded`: not_executable 项不得进入对外承诺; `on_violation: reject`。

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`evidence_profile`。
2. 确定估算层级：任务级、模块级或需求级。
3. 优先消费 `开发任务拆分表.csv`；若缺失，则从方案中抽取估算对象。
4. 检查可执行性、blocked / not_executable 任务与粒度异常，必要时回推 055 或需求侧。
5. 为每个对象生成 PERT、variance、std_dev、4 因子不确定性与 confidence。
6. 写出 `cost_drivers[]` 与 `key_assumptions[]`，解释估算来源。
7. 若有历史数据，生成 `historical_calibration` 并调整 effort。
8. 分开计算 `effort_pd` 与 `duration_calendar_days`。
9. 透明化 buffer，形成项目级 `project_rollup`。
10. 根据触发条件运行或建议 Monte Carlo。
11. 形成面向 N180 标准产物的 **`工时估算表.csv`**。
12. 输出 `downstream_handoff`，供 057 以及 N190 / N220 / N240 / N270 / N330 / N350 消费。
13. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 任务级明确：覆盖全部关键任务的 PERT 估算。
- 模块级明确：覆盖核心模块与高风险联调项。
- 大型项目：优先覆盖关键路径候选、外部依赖密集项与高不确定项，并补 Monte Carlo。

## Quality bar / 质量门槛
合格结果应能支撑排期、资源沟通与版本承诺，而不是只提供“看起来像数字”的表面精度。

## Reference files / 参考文件
- `references/output-template.md`
- `references/estimation-techniques.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/n180-integration-map.md`
- `references/v2_1-changelog.md`
- `references/v2_2-changelog.md`
