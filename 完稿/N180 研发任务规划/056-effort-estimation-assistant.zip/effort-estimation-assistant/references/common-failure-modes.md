# 056 常见失败模式 v2.2

## F1. 过度乐观

症状：optimistic、most_likely、pessimistic 三列几乎一样，完全没有体现不确定性。

修正：把依赖、联调、数据改造和未知规则纳入 pessimistic 与缓冲。

## F2. 不说明假设

症状：给出数字，但没有解释团队规模、availability、并行度和外部前提。

修正：始终先写全局假设，再给估算表。

## F3. 混淆工作量与日历时间

症状：把 3 pd 直接说成 3 天可上线。

修正：将 `effort_pd` 与 `duration_calendar_days` 分开，考虑排队、评审、等待、联调窗口和 meetings overhead。

## F4. 风险缓冲全部为 0

症状：所有任务都没有缓冲，但输入里存在明显不确定性。

修正：对高风险任务增加 task buffer 或降低 confidence，并解释对内/对外沟通口径。

## F5. confidence 与依赖状态矛盾

症状：关键依赖未决，但 confidence 仍为 high。

修正：根据信息完备度、4 因子不确定性和 057 依赖状态下调为 medium 或 low。

## F6. 把 blocked 任务估成精确数字

症状：方案未定，但仍给出 2.3 / 2.8 / 3.0 这类数字。

修正：改成 `?`、区间或“待确认”，并说明会影响估算的前提。

## F7. 需要承诺日期但没有 Monte Carlo

症状：用户需要 P80 日期或对外承诺，但只给单个日期。

修正：启用 Monte Carlo 或明确说明缺少依赖/duration 数据，暂时只能给 provisional commitment。
