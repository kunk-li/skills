# 056 交付检查清单 v2.2

## A. 估算口径

- [ ] 已说明估算对象是需求级、模块级还是任务级。
- [ ] 已使用 PERT 三点估算，而不是单点数字。
- [ ] 已输出 expected、variance、std_dev。
- [ ] 已显式写出全局假设。

## B. 结果完整性

- [ ] `pd_optimistic / pd_most_likely / pd_pessimistic` 逻辑一致。
- [ ] `pd_pert_expected` 使用 `(O+4M+P)/6`。
- [ ] `risk_buffer_pd` 或 `task_level_buffer_pd` 独立表达。
- [ ] `confidence` 与不确定性匹配。
- [ ] `effort_pd` 与 `duration_calendar_days` 分离。
- [ ] duration 因子包含 availability、parallelism、dep_wait 或说明默认值。

## C. 不确定性与历史校准

- [ ] 每条估算包含 4 因子不确定性分解。
- [ ] 有历史数据时已给 `calibration_factor` 与 `calibration_hint`。
- [ ] 无历史数据时已标 `historical_calibration: unavailable`。
- [ ] extreme 不确定任务已建议 spike。

## D. Monte Carlo 与承诺

- [ ] 大项目、对外承诺或 selected_mode=calibrated 时已启用或建议 Monte Carlo。
- [ ] 已输出 P50/P80/P95/P99 或说明为什么不能计算。
- [ ] P80 被明确为默认 stakeholder 承诺口径。

## E. 风险与依赖

- [ ] 关键依赖已进入成本驱动说明。
- [ ] 跨团队 / 联调成本已纳入估算。
- [ ] 未决问题单独列出。
- [ ] Blocked 任务没有被硬估成确定数字。

## F. 跨 skill 对齐

- [ ] `task_id` 可回指 055。
- [ ] 依赖相关风险与 057 保持一致。
- [ ] 大任务合计行与拆分任务没有重复计算。

## G. v2.2 可执行性检查

- [ ] 若存在 `可执行性检查单.csv`，not_executable 项没有进入对外承诺范围。
- [ ] needs_clarification 项已降级 confidence 或标 provisional。
- [ ] 缺少可执行性检查单时，已写明 `executability_check: unavailable`，没有伪装成高可信。
