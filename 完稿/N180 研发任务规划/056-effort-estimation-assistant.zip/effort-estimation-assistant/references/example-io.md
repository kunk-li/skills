# 056 示例输入输出 v2.2

## 示例输入

基于 055 的任务清单，用户希望估算 CRM 线索去重配置能力的 wave 1 工作量，并已说明：

- 2 名后端 + 1 名前端
- 本周可并行 2 个开发任务
- 外部联调窗口固定在下周三
- 历史数据回刷方案未决

## 示例输出（节选）

### Metadata

```yaml
metadata:
  selected_mode: probabilistic_estimate
  readiness: constrained
  function_bias: decision_support_result
  workflow_node: N180
  producer_skill: effort-estimation-assistant
  node_artifact_target: 工时估算表.csv
  artifact_schema_version: n180.v2.2
```

### 全局假设

1. wave 1 只覆盖配置页、规则 API、规则表与联调回归。
2. 前后端最多并行 2 条主任务。
3. availability 默认 80%，review_wait 默认 0.5 天。
4. 联调窗口固定在下周三，若错过则日历时间顺延 3 天。
5. 历史数据回刷不纳入本轮精确估算，只列影响项。

### 主估算表

| estimate_id | task_id | task_name | pd_optimistic | pd_most_likely | pd_pessimistic | pd_pert_expected | variance | std_dev | size_tshirt | effort_pd | task_level_buffer_pd | duration_calendar_days | uncertainty_level | uncertainty_factors | confidence | cost_drivers | notes |
|---|---|---|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---|---|---|---|---|
| EST-001 | TASK-S1-001 | 新增规则配置表与索引 | 0.5 | 1.0 | 1.5 | 1.0 | 0.03 | 0.17 | S | 1.0 | 0.2 | 2 | low | tech=low;req=stable;team=familiar;external=none | high | DB review | 依赖数据库评审 |
| EST-002 | TASK-S1-002 | 实现规则配置查询与保存 API | 1.0 | 1.5 | 2.5 | 1.6 | 0.06 | 0.25 | S | 1.6 | 0.4 | 3 | medium | tech=medium;req=stable;team=familiar;external=manageable | medium | 规则校验、联调、异常处理 | 若新增复杂规则会放大 pessimistic |
| EST-003 | TASK-S1-003 | 实现规则配置页表单与校验 | 1.0 | 1.5 | 2.0 | 1.5 | 0.03 | 0.17 | S | 1.5 | 0.3 | 3 | medium | tech=low;req=minor_changes;team=familiar;external=manageable | medium | 前后端契约稳定性 | 等待 API 契约冻结 |
| EST-004 | TASK-S1-004 | 接入规则发布后的联调回归 | 0.5 | 1.0 | 2.0 | 1.1 | 0.06 | 0.25 | S | 1.1 | 0.8 | 4 | high | tech=low;req=stable;team=familiar;external=risky | low | 固定联调窗口、回归缺陷数 | 日历时间受窗口影响明显 |
| EST-005 | TASK-S2-005 | 调研历史数据回刷策略 | ? | ? | ? | ? | ? | ? | M | ? | ? | ? | extreme | tech=high;req=volatile;team=learning;external=blocker | low | 数据量与执行策略 | blocked，先 spike 后估 |

### Monte Carlo

当前任务数较少且未要求承诺日期，可不启用正式 Monte Carlo；若用户需要版本承诺，使用 057 关键路径与上述 PERT 分布计算 P50/P80/P95。
