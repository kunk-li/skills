# v2.2 changelog: effort-estimation-assistant

## Optimized from v2.1复评 residual items

- Added `executability_gate` so not_executable items are excluded from stakeholder commitment.
- Clarified that missing `可执行性检查单.csv` does not block standalone usage but must be declared as unavailable.
- Added rule R09 for not_executable exclusion.
- Updated metadata and integration contract to `artifact_schema_version: n180.v2.2`.
