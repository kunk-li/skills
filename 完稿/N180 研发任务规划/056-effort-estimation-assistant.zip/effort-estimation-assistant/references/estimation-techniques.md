# 估算技术说明 v2.2

默认推荐 **PERT three-point + analogous calibration**。在需要对外承诺日期或项目较大时，叠加 **Monte Carlo simulation**。

## 1. PERT Three-point

适用：存在中等不确定性，需要给出上下界。

做法：保留 `optimistic / most_likely / pessimistic`，并计算：

```text
expected = (O + 4M + P) / 6
variance = ((P - O) / 6)^2
std_dev = sqrt(variance)
```

## 2. Analogous Estimation

适用：团队有相似历史任务或可比模块。

做法：引用相似任务作为基线，再根据差异调整。若样本数不足，必须标 `historical_calibration: unavailable` 或 `low_sample_size`。

## 3. Parametric Estimation

适用：同类任务很多，例如“每个 API 约 1 pd”。

风险：过度简化时容易低估边界条件。高复杂度 API、数据迁移、跨系统联调不得只用简单参数法。

## 4. Planning Poker / Team Review

适用：多人协作，需要共享认知并对齐假设。

本 skill 不组织会议，但可以提醒用户在高争议任务上采用团队复核。

## 5. Monte Carlo Simulation

适用：

- 任务数 > 50
- 总 effort > 50 pd
- 需要 stakeholder 承诺日期
- 关键路径包含多个 high risk 外部依赖
- selected_mode = `calibrated_estimate`

基本做法：

1. 对每个任务用三角分布或 beta-PERT 分布从 O/M/P 抽样。
2. 按依赖关系和并行度聚合。
3. 运行默认 10000 次。
4. 输出 P50/P80/P95/P99。

沟通口径：P50 用于内部理解，P80 通常用于对外承诺，P95 用于高风险保守场景。
