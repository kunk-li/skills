# Output Template: 工时估算表 v2.2

## 默认交付结构

### 1. Metadata

```yaml
metadata:
  selected_mode: probabilistic_estimate
  readiness: pass | constrained | blocked | provisional
  function_bias: decision_support_result
  workflow_node: N180
  producer_skill: effort-estimation-assistant
  node_artifact_target: 工时估算表.csv
  artifact_schema_version: n180.v2.2
  contract_status:
    schema_valid: true | false
    self_check_passed: true | false
    blocking_issues: []
```

### 2. 估算范围与 readiness

先说明：

- 当前估算层级：需求 / 模块 / 任务
- readiness：pass / constrained / blocked / provisional
- 估算口径：PERT 人天、t-shirt size、区间、是否含 buffer
- 是否已使用历史校准
- 是否启用 Monte Carlo

### 3. 全局假设

至少覆盖以下 6 类：

1. 团队规模与角色分配
2. availability 与并行度上限
3. 外部依赖 SLA 或联调窗口
4. 待确认问题何时决策
5. 工作量到日历时间的换算口径
6. buffer 对内 / 对外沟通口径

### 4. 主估算表

默认使用以下列：

| 列名 | 含义 |
|---|---|
| estimate_id | 估算 ID，例如 `EST-001` |
| task_id | 对应的 055 任务 ID |
| task_name | 任务名 |
| estimate_scope | task / module / requirement / summary |
| pd_optimistic | 乐观估时 O |
| pd_most_likely | 最可能估时 M |
| pd_pessimistic | 悲观估时 P |
| pd_pert_expected | PERT 期望 `(O+4M+P)/6` |
| variance | `((P-O)/6)^2` |
| std_dev | `sqrt(variance)` |
| size_tshirt | XS / S / M / L / XL，映射与 055 一致 |
| calibration_factor | 历史校准系数，缺失填 unavailable |
| calibration_hint | likely_underestimate / likely_accurate / likely_overestimate / unavailable |
| effort_pd | 校准后纯工作量 |
| task_level_buffer_pd | 任务级 buffer |
| duration_calendar_days | 日历时长 |
| duration_formula_factors | availability / parallelism / dep_wait / review_wait / meetings_overhead |
| uncertainty_level | low / medium / high / extreme |
| uncertainty_factors | technical_unknowns / requirement_volatility / team_experience / external_dependencies |
| confidence | high / medium / low |
| cost_drivers | 成本驱动因子 |
| key_assumptions | 关键假设 |
| notes | 备注 |

### 5. Historical calibration

若有历史数据，列出：

| similar_task_id | similarity_score | estimated_pd | actual_pd | ratio | weight |
|---|---:|---:|---:|---:|---:|

若没有，必须写：`historical_calibration: unavailable`。

### 6. Buffer strategy

必须分开列出：

| buffer_level | amount_pd | percentage | rationale | communication |
|---|---:|---:|---|---|
| task_level |  |  |  | internal detail |
| sprint_level |  |  |  | planning reserve |
| project_contingency |  |  |  | stakeholder-facing when appropriate |

### 7. Monte Carlo simulation（触发时）

| metric | value | interpretation |
|---|---:|---|
| simulation_runs | 10000 | 默认仿真次数 |
| p50 |  | 中位数，一半概率完成 |
| p80 |  | 默认对外承诺口径 |
| p95 |  | 保守承诺或高风险评估 |
| p99 |  | 极端情况 |

若有起始日期，增加：`p50_date`、`p80_date`、`p95_date`。

### 8. Team load

| member_or_role | assigned_pd | capacity_pd | load_percentage | over_allocated | notes |
|---|---:|---:|---:|---|---|

### 9. 待确认问题

单独列出会显著改变估算的假设，例如：

- 外部接口是否复用
- 数据迁移是否要回刷历史数据
- 联调窗口是否固定
- 关键任务是否应先 spike

## 计算与映射规则

### Three-point 默认规则

必须使用 PERT：

```text
expected = (optimistic + 4 * most_likely + pessimistic) / 6
variance = ((pessimistic - optimistic) / 6)^2
std_dev = sqrt(variance)
```

### T-shirt 映射

- XS: < 0.5 pd
- S: 0.5-2 pd
- M: 2-5 pd
- L: 5-10 pd
- XL: > 10 pd

### Confidence 规则

- high：需求明确、技术熟悉、依赖就绪、历史样本支持。
- medium：存在部分未知，但范围仍可控。
- low：关键依赖未决、输入明显不完整或外部窗口高风险。

## 禁止项

- 不要只给 `pd_most_likely` 单点而没有上下界，除非用户明确只要极简版。
- 不要为 blocked 任务给出伪精确数字。
- 不要把所有任务的 confidence 都填成 high。
- 不要把风险缓冲隐藏到主估值里而不说明。
- 不要把工作量和日历时间混成一个字段。
- 不要在需要 stakeholder 承诺日期时跳过 Monte Carlo 或至少跳过 P80/P95 说明。
