# v2.1 changelog: effort-estimation-assistant

## Optimized from v2 analysis

- Changed `function_bias` from `direct_result` to `decision_support_result` to align with the skill table's auxiliary decision role.
- Standardized PERT formula to `(O + 4M + P) / 6` with variance and standard deviation.
- Unified XS/S/M/L/XL mapping with 055.
- Added 4-factor uncertainty assessment and `uncertainty_level` rollup.
- Added historical calibration hint enum.
- Added duration formula factors and communication strategy for buffer.
- Added Monte Carlo trigger rules and P50/P80/P95/P99 output contract.
- Added requirement executability as a recommended input.
- Added machine-readable rules with `on_violation` actions.
