# 056 编排说明 v2.2

## 上游优先级

优先复用以下输入：

1. 055 开发任务拆分结果
2. 057 研发依赖清单与关键路径
3. 可执行性检查单
4. 技术方案分析
5. 模块边界图
6. 数据流图
7. API 清单
8. 表结构与索引变更
9. 非功能需求
10. 待决问题清单

## 与 055 的字段映射

| 055 字段 | 056 字段 | 说明 |
|---|---|---|
| task_id | task_id | 一一对应 |
| task_name | task_name | 名称保持一致 |
| task_kind | cost_drivers / uncertainty | T7_spike 或 T8_coordination 通常不确定性更高 |
| task_type | cost_drivers | db / infra / integration 等影响估算 |
| estimate_hint_pd | pd_most_likely 的输入基线 | 056 可围绕它展开 PERT |
| size_in_pd_optimistic | pd_optimistic | 若 055 已给三点范围则复用 |
| size_in_pd_most_likely | pd_most_likely | 若 055 已给三点范围则复用 |
| size_in_pd_pessimistic | pd_pessimistic | 若 055 已给三点范围则复用 |
| priority | confidence / buffer 的参考 | blocker 往往意味着更低 confidence |
| depends_on_hint | cost_drivers / notes | 依赖越重，缓冲通常越大 |
| mode | readiness / confidence | blocked 不给伪精确估算 |

## 与 057 的协同

- 057 给出的关键依赖、外部对象和阻塞风险应进入 `cost_drivers` 或 `duration_formula_factors`。
- 如果 057 标记 `blocking_risk=high`，056 通常不应给 high confidence。
- 若 057 识别出固定联调窗口，056 需要单独说明 `calendar_window_wait` 对 `duration_calendar_days` 的影响。
- 057 输出 critical path 后，056 可基于关键路径运行 Monte Carlo，并输出 P50/P80/P95。

## 反向约束

- `estimate_id` 数量通常应小于等于 055 的任务数加上少量汇总或假设行。
- 每个明确的 `task_id` 最好对应恰好 1 条主估算记录。
- Blocked 任务的 PERT 字段应为 `?`、区间或空值。
- `size_tshirt` 应与 `pd_pert_expected` 大致一致，并使用 055 的 XS/S/M/L/XL 映射。
- 需要对外承诺日期时，必须输出 P80 或说明无法计算的原因。
