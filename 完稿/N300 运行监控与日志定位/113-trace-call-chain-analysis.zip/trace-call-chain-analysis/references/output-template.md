# output-template

Use this template as the structural scaffold for producing this skill's artifact. Fill each section with evidence-derived content; never leave required fields empty — use `unable_to_measure`, `unknown`, or `needs_evidence` with a reason instead.

## Top-level structure

```markdown
---
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  node_artifact_target: <artifact-target>
  function_bias: <this-skill-function-bias>
  stage_position: <this-skill-stage-position>
  incident_id: <string | TEMP-ops-runtime-<date>-<source>>
  selected_mode: <allowed-mode>
  readiness: draft | partial | ready
  evidence_profile: <profile-value>
  tool_collaboration_mode: <mode>
  source_time_window:
    start: <iso8601 | unknown>
    end: <iso8601 | unknown>
  service_scope: [<service-names>]
---

## incident_overview
> 2–4 sentence plain-language summary of what happened, when, and which services.
> Always write this section even when readiness is partial.

## [skill-specific sections]
> See SKILL.md Required output sections.
> Every primary row must include all required fields.
> Use `unable_to_measure` + reason when data is unavailable.

## downstream_handoff
> Machine-readable handoff entries per the shared contract schema.
> Include missing_evidence and next_best_checks for every handoff item.

## self_check
> Record pass/fail for each shared V2.5.0 self-check item.
> If any item fails, readiness must be partial or draft.
```

## Field fill guidance

| Situation | Required action |
|---|---|
| No `incident_id` exists | Create `TEMP-ops-runtime-<YYYYMMDD>-<source>` and mark `provisional: true` |
| Evidence is partial | Keep all sections; fill with best estimate + confidence label |
| Metric not measurable | Use `unable_to_measure: true` with `reason` field |
| Hypothesis uncertain | Use `confidence: low` and list what would raise it |
| Sensitive data present | Summarize or hash; never include plaintext PII or credentials |

## Readiness decision guide

| Condition | Readiness |
|---|---|
| All required sections complete, evidence multi-signal, self-check passes | `ready` |
| Some evidence missing, assumptions made, but output is actionable | `partial` |
| Critical required fields cannot be filled without more data | `draft` |


---

## Downstream handoff YAML templates

```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: trace-call-chain-analysis
  incident_id: "{incident_id}"
  artifact: Trace分析.md
  handoffs:
    - target: root-cause-analysis-recommendation
      handoff_type: hypothesis
      summary: "Bottleneck: db-query-checkout span 2800ms (87.5% of trace). Likely slow query."
      required_fields: [critical_path_span, critical_path_duration_ms, critical_path_pct]
      evidence_refs: [span-db-003]
      confidence: high
      missing_evidence: []
      next_best_checks:
        - "RCA: start from db-query-checkout span as primary evidence"
    - target: log-analysis
      handoff_type: gap
      summary: "Missing spans: payment-service, auth-service. Use safe_queries to recover via logs."
      required_fields: [propagation_gaps, safe_queries]
      confidence: low
      missing_evidence: [payment_service_spans, auth_service_spans]
      next_best_checks:
        - "Run SQ-001 to correlate payment-service logs as proxy for missing spans"
```


---

## Standalone guarantee
This skill runs independently with the minimum evidence listed in this file. Do not refuse output because sibling ops-runtime skills have not been run first. When evidence is absent, declare `readiness: partial` or `readiness: red`, populate all stable output sections with available evidence, and list missing evidence in `downstream_handoff.missing_evidence`.

---

## Output completeness rule
Every artifact from this skill MUST include all of:
- `metadata` with `readiness`, `selected_mode`, `evidence_profile`
- `evidence_profile.confirmed` list ≥ 1 item (or explicit `[]` with missing_evidence explanation)
- `confidence` ∈ {high, medium, low, speculative}
- `downstream_handoff` with ≥ 1 typed `handoff_type` entry
- `self_check.passed` boolean + `self_check.warnings[]` (may be `[]`)
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry
- `emit_event.event_name` matching `produced.ops-runtime.*.v2`

**Hard rule:** `confidence: high` requires `evidence_profile.confirmed` ≥ 3 distinct signal families.

---

## Mode selection

### New: `latency_regression` mode — 延迟回归分析
**Trigger:** P99 latency increased after a recent deploy, or user says "why is latency higher after the deploy?", "latency regression", "before/after comparison".

```yaml
latency_regression:
  baseline_window: "2026-05-20T14:00:00Z to 2026-05-21T13:50:00Z"
  regression_window: "2026-05-21T14:00:00Z to now"
  deploy_at: "2026-05-21T13:55:00Z"
  comparison:
    baseline_p99_ms: 145
    regression_p99_ms: 820
    delta_ms: 675
    delta_pct: 465
  slow_span_identified:
    span_name: "db.query.checkout_items"
    service: "cart-service"
    baseline_p99_ms: 12
    regression_p99_ms: 680
    delta_pct: 5567
    probable_cause: "Missing DB index on checkout_items.user_id after migration"
  regression_verdict: confirmed
  confidence: high
```
**SCR:** `selected_mode: latency_regression` → `latency_regression.deploy_at` declared; `regression_verdict` ∈ {confirmed, probable, inconclusive}; `slow_span_identified` present when verdict ≠ inconclusive.