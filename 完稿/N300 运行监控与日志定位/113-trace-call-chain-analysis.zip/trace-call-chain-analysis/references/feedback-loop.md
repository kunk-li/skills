# feedback loop protocol — trace-call-chain-analysis

## Retrospective integration
After each incident closes, compare trace analysis output against post-mortem findings to calibrate span attribution accuracy, latency bottleneck identification, and confidence labels.

### Signal types and actions
| Signal | Trigger | Action |
|---|---|---|
| `false_positive` | Flagged span as bottleneck but post-mortem found a different cause | Review span duration threshold; check if fan-out aggregation was incorrect |
| `false_negative` | Real bottleneck span was not identified (e.g., missed cold start, DB pool wait) | Add detection pattern; broaden critical-path criteria in trace-critical-path-playbook.md |
| `wrong_confidence` | Confidence label didn't match post-mortem certainty | Adjust confidence_ceiling when trace_id coverage < 50% |
| `propagation_missed` | Error propagation path was incomplete — upstream cause not traced to origin | Add cross-service boundary rule; check for missing trace context propagation |
| `correct` | Identified bottleneck or error origin matched post-mortem finding | Add to real-examples.md as calibration anchor |

## feedback_signal_candidates schema
```yaml
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: correct | false_positive | false_negative | wrong_confidence | propagation_missed
    description: "Specific span or path to verify against post-mortem"
    verification_method: "Compare flagged critical_path to post-mortem confirmed latency root"
    downstream_skill: "root-cause-analysis-recommendation | log-analysis | monitoring-metric-interpretation"
    priority: P0 | P1 | P2
    status: pending
```

### Common signal examples
```yaml
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: false_negative
    description: "DB connection pool exhaustion was not flagged as the bottleneck span"
    verification_method: "Check if pool_wait spans were present in trace; if so, update critical-path weighting for pool_wait > 200ms"
    downstream_skill: root-cause-analysis-recommendation
    priority: P0
    status: pending

  - signal_id: FSC-002
    signal_type: propagation_missed
    description: "Error origin was auth-service but trace stopped at payment-service boundary"
    verification_method: "Check if auth-service propagated trace context (W3C TraceContext header). If not, flag as instrumentation gap."
    downstream_skill: log-analysis
    priority: P1
    status: pending

  - signal_id: FSC-003
    signal_type: wrong_confidence
    description: "Confidence was 'high' but only 12% of requests had trace coverage"
    verification_method: "Apply confidence_ceiling: medium when trace_coverage < 30%"
    downstream_skill: null
    priority: P2
    status: pending

  - signal_id: FSC-004
    signal_type: false_positive
    description: "Cold start delay was flagged as a bottleneck but turned out to be expected JVM warm-up"
    verification_method: "Check if span has cold_start label or first-request marker. If first-request only, downgrade to advisory."
    downstream_skill: monitoring-metric-interpretation
    priority: P2
    status: pending
```

## Version bump triggers
- 3+ `false_negative` with the same undetected span type (e.g., cache miss, pool wait) → patch; add critical-path detection rule
- New trace protocol support (OTLP gRPC, eBPF-based tracing) → minor; add evidence_profile field
- Span schema breaking change (e.g., span attribute rename) → minor; migration note
- Output contract breaking change → major; migration guide required

## Calibration cadence
- Review after every P1+ incident where trace-call-chain-analysis was invoked.
- Monthly: audit `propagation_missed` rate; if > 15% → file instrumentation gap report to platform team.


---

## Feedback loop — advanced integration (v2)

### Signal-type differentiated handling

| Signal type | Immediate action | Update target | Owner |
|---|---|---|---|
| `false_positive` | Open P2 ticket; mark in `real-examples.md` as "flagged FP" | Add calibration note to relevant SCR rule | Skill maintainer |
| `false_negative` | Open P1 ticket; investigate evidence gap | Add new scenario to `real-examples.md`; tighten field contract | Skill maintainer + incident owner |
| `missed_evidence` | Document the missed source in `references/failure-modes.md` | Add new input tier to `## Large input handling` | Skill maintainer |
| `wrong_confidence` | Update `confidence_ceiling_rule` in field contract | Re-run SCR-TRACECAL-001 equivalents against historical artifacts | Skill maintainer |
| `slow_resolution` | Profile which output section delayed the decision | Simplify that section; add a `quick_triage` mode if not present | Skill maintainer |
| `correct` | Add to `real-examples.md` as a calibration green-path example | Consider as regression baseline for future changes | Skill maintainer |

### Postmortem auto-mapping rule
When a postmortem skill (or manual RCA document) references an artifact from this skill, apply this mapping automatically:

```yaml
postmortem_integration:
  trigger: "postmortem references artifact_id from this skill"
  auto_actions:
    - action: extract_feedback_signals
      source: "postmortem.findings[].related_artifact_id == this.artifact_id"
      output: "feedback_signal_candidates[] with signal_type auto-classified"
    - action: update_real_examples
      condition: "signal_type in [false_negative, correct]"
      target: "references/real-examples.md"
    - action: open_scr_review_ticket
      condition: "signal_type in [false_positive, wrong_confidence]"
      ticket_template: "SCR review: {skill_id} produced {signal_type} in incident {incident_id}"
```

### Full retrospective YAML flow
After every incident where this skill was invoked, execute this flow:

```yaml
retrospective_flow:
  step_1_collect:
    action: "Query artifact store for all outputs from this skill during incident_id"
    tool: "artifact registry or conversation history"
    output: "artifact_list[]"

  step_2_evaluate:
    action: "For each artifact, compare recommended hypothesis/action vs actual outcome"
    criteria:
      - "Was the top hypothesis confirmed by post-incident RCA?"
      - "Were immediate actions sufficient to contain the incident?"
      - "Were evidence gaps listed in downstream_handoff.missing_evidence actually missing?"
    output: "signal_type classification per artifact"

  step_3_update:
    condition: "signal_type confirmed"
    actions:
      false_negative:
        - "Add new scenario to references/real-examples.md"
        - "Add new SCR rule to detect this gap"
        - "File patch upgrade ticket (v2.5.x bump)"
      correct:
        - "Add to references/real-examples.md as green-path calibration"
        - "No version bump required"
      false_positive:
        - "Review confidence_ceiling_rule for affected field"
        - "Add 'calibration note' to the relevant example"

  step_4_close:
    action: "Mark feedback_signal_candidates[].status: verified | deferred"
    output: "Updated artifact with verification timestamps"
```

### feedback_signal_candidates SCR rule
```yaml
# SCR-FEEDBACK: Every artifact must include at least 1 feedback_signal_candidates entry
# If evidence is thin → default to wrong_confidence signal
# If output is confident → add correct signal for future calibration
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: wrong_confidence  # default for partial-evidence artifacts
    description: "Verify hypothesis against post-incident RCA"
    verification_method: "Compare top hypothesis to confirmed root cause in postmortem"
    downstream_skill: root-cause-analysis-recommendation  # or relevant postmortem skill
    priority: P1
    status: pending  # updated to 'verified' or 'deferred' post-incident
```
