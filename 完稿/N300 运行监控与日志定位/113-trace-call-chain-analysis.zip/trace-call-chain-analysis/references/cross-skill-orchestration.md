# cross-skill-orchestration

Describes how the nine ops-runtime skills collaborate in multi-signal incident diagnosis.

## Canonical combination paths

### Alert-first (most common)
```
alert-attribution
  → monitoring-metric-interpretation  (metric anomaly confirmation)
  → log-analysis                       (log evidence gathering)
  → trace-call-chain-analysis          (call path reconstruction)
  → bug-analysis                       (fast symptom triage)
  → root-cause-analysis-recommendation (evidence-chained RCA)
  → impact-scope-analysis              (blast radius quantification)
```

### Metric-first
```
monitoring-metric-interpretation
  → alert-attribution        (alert dedup and routing)
  → trace-call-chain-analysis (latency/error path drilldown)
  → impact-scope-analysis     (SLO burn → user impact)
  → root-cause-analysis-recommendation
```

### Log-first
```
log-analysis
  → anomaly-clustering        (pattern deduplication)
  → frequent-error-summary    (error ranking)
  → bug-analysis              (triage framing)
  → root-cause-analysis-recommendation
```

## Join keys for composition
All ops-runtime skills share these composition join keys:
- `incident_id` — primary correlation key
- `source_time_window` — time range anchor
- `service_scope` — affected service list
- `evidence_refs` — reference IDs passed between skills
- `contract_version: ops-runtime-runtime-v2.5.0` — version guard

## Composition rules
1. Later skills cite earlier artifacts by `artifact name + evidence_ref`, never by re-running the same analysis.
2. `incident_id` must remain stable across all skills in a single incident. Only `alert-attribution` may create or normalize a new incident_id.
3. Skills emit `downstream_handoff` records that declare `handoff_type`, `required_fields`, `evidence_refs`, `confidence`, and `next_best_checks`.
4. When two skills contradict each other (e.g., log-analysis says service A is healthy, metrics say it is degraded), both findings remain visible with `conflicting` confidence labels — do not suppress contradictions.
5. Circuit breakers are skill-local. A skill that triggers its circuit breaker must emit `exception.ops-runtime.skill_blocked.v2.5.0` and hand off to the incident commander, not to the next ops-runtime skill in the chain.

## Refresh triggers
- If `alert-attribution` re-classifies the root alert, emit `downstream_handoff.refresh_triggers: [monitoring-metric-interpretation, log-analysis]` so those skills can re-consume updated `incident_id` and `source_time_window`.
- If `anomaly-clustering` merges or splits clusters, emit `downstream_handoff.refresh_triggers: [frequent-error-summary, root-cause-analysis-recommendation]`.


---

## Boundary comparison table — trace precise

| Dimension | trace-call-chain-analysis | log-analysis | monitoring-metric-interpretation | root-cause-analysis-recommendation |
|---|---|---|---|---|
| **Primary question** | "WHICH span is slow/failing and why?" | "WHAT do the logs show?" | "HOW do the metrics behave?" | "WHY did the incident happen?" |
| **Input type** | Distributed trace spans (timing, error flags, parent-child relationships) | Log files, log streams, structured query results | Time-series metrics, SLO data, dashboards | All evidence types (logs+traces+metrics+topology) |
| **Output type** | Span-level latency breakdown, propagation path, critical path | Error patterns, frequency, first-occurrence | Metric anomaly, SLO burn rate, trend | Causal chain, hypothesis ranking, prevention |
| **Timing** | T+0 onward when trace data available | T+0 onward when logs available | T+0 onward when metrics available | Parallel with 120 (on-call response) |
| **Owns** | Span timing, propagation gaps, cold start detection, critical path | Error pattern ranking, log structure, timeline | Metric anomaly, SLO math, trend direction | Root cause chain, five-why, prevention recommendations |
| **Does not own** | Business impact (→116) · Root cause (→119) · Response steps (→120) | Business impact (→116) · Trace timing (→115) · Root cause (→119) | Trace timing (→115) · Log content (→113) · Root cause (→119) | Trace details (→115) · Log patterns (→113) · Impact scope (→116) |

### When to call 115 vs neighbors
```
"Why is P99 latency 800ms?"              → 115 (span-level breakdown)
"What errors are in the logs?"            → 113 (log-analysis)
"Is SLO burn rate elevated?"             → 114 (monitoring)
"What is the root cause?"               → 119 (after 113/114/115 feed it)
"Which users are affected?"             → 116 (impact-scope-analysis)
```