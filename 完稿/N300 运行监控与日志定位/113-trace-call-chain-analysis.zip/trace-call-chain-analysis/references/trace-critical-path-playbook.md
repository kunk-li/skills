# trace critical path playbook

## Required checks
- critical path duration share
- top span contributors
- error span highlighting
- missing span or propagation gaps
- dependency latency and fan-out
- baseline comparison against recent healthy traces when available

## Span naming preference
- `http.GET /path`
- `db.SELECT table`
- `cache.GET keyspace`
- `external.service.operation`

## Downstream evidence anchors
- `critical_path_pct` for RCA strength
- `dependency` and `operation` for impact propagation
- `trace_id` and `span_id` for log linkage
