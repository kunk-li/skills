# failure-modes — trace-call-chain-analysis

Common failure modes for `Trace分析.md` and how to handle them.

## FM01: No evidence provided — symptom description only
- **Symptom:** Only a text description; no logs, metrics, traces, or structured data.
- **Impact:** All findings are speculative. Confidence ceiling: low.
- **Handling:** Produce artifact with `readiness: partial`, all hypotheses at `confidence: speculative`. List required evidence in `downstream_handoff.missing_evidence`. Do not refuse output.

## FM02: Single signal family — cannot cross-validate
- **Symptom:** Only one evidence type available (e.g., logs only, no metrics or traces).
- **Impact:** Confidence ceiling: low. Cannot confirm or contradict findings.
- **Handling:** Set `evidence_profile.source_family_coverage: single`. Cap all findings at `confidence: low`. Recommend second signal family in `downstream_handoff.next_best_checks`.

## FM03: Timestamps missing or inconsistent timezone
- **Symptom:** Events have no timestamps or mixed timezones.
- **Impact:** Time correlation and time-window normalization unreliable.
- **Handling:** Normalize to UTC; set `timestamp_assumption: utc_assumed` if timezone unknown. Bucket at coarsest granularity. Document under normalization notes.

## FM04: Circuit breaker triggered — skill invoked ≥3 times without resolution
- **Symptom:** `metadata.iter_count >= max_iter` and readiness still `partial`.
- **Impact:** Further regeneration will not resolve the issue without new evidence.
- **Handling:** Stop regeneration. Set `readiness: red`. Emit `exception.ops-runtime.skill_blocked.v2.5.0`. Escalate to incident-commander. Reset only when new `evidence_refs` are provided.

## FM05: Sensitive data (PII / secrets) detected in evidence
- **Symptom:** Raw log lines contain email addresses, passwords, tokens, or PII.
- **Impact:** Cannot include raw data in artifact without violating data handling policy.
- **Handling:** Redact before analysis. Reference by `evidence_ref` id, not raw content. Set `pii_risk: detected` in the relevant finding. Note in `self_check.failed_rules` if redaction is incomplete.

## FM06: Downstream skill unavailable — cannot hand off
- **Symptom:** Target skill in `downstream_handoff` is not reachable or not invoked.
- **Impact:** Composed workflow stalls.
- **Handling:** Emit `downstream_handoff` with `urgency: deferred` and list the missing context. The current artifact remains valid as a standalone output. Do not retry indefinitely.


---

## Degradation examples — amber extended & confidence quantification

### readiness: amber — 有指标但无时序，无法判断趋势

```yaml
metadata:
  readiness: amber
  selected_mode: quick_triage
evidence_profile:
  confirmed: [single_metric_snapshot]
  missing_evidence: [time_series_data, baseline, deployment_history]
  missing_evidence_impact: "Single snapshot only. Cannot determine if value is stable, improving, or worsening."
  confidence_ceiling_applied: low
self_check:
  passed: true
  warnings:
    - "amber — single snapshot, no time series; trend unknown"
    - "Upgrade: provide 30min time series to determine trend direction"
```

### readiness: amber — 两个信号相互矛盾

```yaml
metadata:
  readiness: amber
  selected_mode: log_investigation
evidence_profile:
  confirmed: [error_rate_metric, log_bundle]
  conflicting_signals:
    signal_a: "error_rate: 0.28% — within normal range"
    signal_b: "log_bundle: 47 NullPointerException per minute — elevated"
    conflict_note: "Metric and logs disagree; likely metric aggregation lag"
  confidence_ceiling_applied: low
  confidence_rationale: "Contradicting signals cap confidence at low regardless of tier"
self_check:
  passed: true
  warnings:
    - "amber — contradicting signals: metric shows normal, logs show elevated"
    - "Prefer log evidence when metric has >5min aggregation lag"
```

### Confidence quantification
```yaml
confidence_quantification_v3:
  no_evidence:
    ceiling: speculative
    readiness: draft
  single_signal:
    ceiling: low
    readiness: amber
  two_signals_agreeing:
    ceiling: medium
    readiness: amber_to_ready
  two_signals_contradicting:
    ceiling: low   # contradiction caps ceiling regardless of tier
    readiness: amber
    action: flag_conflicting_signals
  three_plus_signals:
    ceiling: high
    readiness: ready
    condition: "no contradictions"
```