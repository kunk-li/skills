# real-examples

These examples illustrate how to produce this skill's artifact under different evidence conditions. Use them as output calibration references — not as templates to copy verbatim.

## Example 1: Minimum viable input (readiness: partial)

**Scenario:** Single metric spike, no logs or traces available.

**Input given:**
- Service: `payment-service`
- Signal: `http_error_rate` jumped from 0.3% to 12% at 14:32 UTC
- No trace data, no log access

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  evidence_profile: metrics_only
  incident_id: TEMP-ops-runtime-20240315-payment-metric
evidence_profile:
  missing_evidence:
    - structured logs for error classification
    - trace ids to correlate request path
  next_best_checks:
    - pull error log sample from payment-service for 14:30–14:40 UTC
    - check recent deployment or config change in this window
```

**Key calibration:** Output must not invent error causes. State "elevated error rate observed; cause undetermined pending log/trace evidence."

---

## Example 2: Rich multi-signal input (readiness: ready)

**Scenario:** Alert storm with logs and partial traces available.

**Input given:**
- Alert: `payment-service SLO burn rate 14× budget`
- Log sample: 3,200 lines of `NullPointerException` in `PaymentProcessor.java:142`
- Trace: 2 trace IDs showing 8s p99 at `db-connection-pool`
- Recent change: DB connection pool size reduced from 100→20 at 14:15 UTC

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  evidence_profile: multi_signal
recommended_finding:
  hypothesis_id: H1
  statement: "Connection pool exhaustion caused by config change at 14:15 UTC"
  confidence: high
  supporting_evidence_refs: [alert-001, log-finding-3, trace-T1, trace-T2]
  contradicting_evidence_refs: []
```

**Key calibration:** Confidence "high" requires at least 2 corroborating signal families AND a plausible causal mechanism.

---

## Example 3: Conflicting evidence (readiness: partial)

**Scenario:** Logs point to DB; metrics show CPU spike on app tier.

**Expected output shape:**
```yaml
hypothesis_testing:
  - hypothesis_id: H1
    statement: "DB connection exhaustion is root cause"
    confidence: medium
    supporting_evidence_refs: [log-finding-1]
    contradicting_evidence_refs: [metric-cpu-001]
    status: unresolved — conflicting signals
  - hypothesis_id: H2
    statement: "App-tier CPU spike caused downstream DB timeouts"
    confidence: low
    supporting_evidence_refs: [metric-cpu-001]
    contradicting_evidence_refs: [log-finding-1]
    status: unresolved
recommended_root_cause:
  statement: "Insufficient evidence to choose between H1 and H2"
  next_best_checks:
    - capture JVM thread dump from app tier during next occurrence
    - check DB slow query log for same window
```

**Key calibration:** Never collapse conflicting hypotheses into a single confident conclusion. Keep both visible.

---

## Example 4: critical path — bottleneck span identified

**Scenario:** Single trace with 7 spans. Checkout flow takes 3.2s total. DB span takes 2.8s.

**Expected behavior:**
- Identify `db-query-checkout` as the critical path bottleneck.
- Express as percentage of total trace duration.
- Provide actionable recommendation.

```yaml
call_chain_summary:
  total_trace_duration_ms: 3200
  span_count: 7
  critical_path_span: db-query-checkout
  critical_path_duration_ms: 2800
  critical_path_pct: 87.5
bottleneck_analysis:
  - span_id: span-db-003
    service: postgres-checkout
    operation: SELECT items WHERE cart_id=?
    duration_ms: 2800
    bottleneck_classification: slow_query
    confidence: high
    recommendation: "Add index on cart_id column. Current full table scan on 2.4M rows."
downstream_handoff:
  next_best_checks:
    - "log-analysis: check postgres slow query log for SELECT on checkout table"
    - "root-cause-analysis-recommendation: use this span as primary evidence"
```

**Key calibration:** `critical_path_pct` (87.5%) is more actionable than raw duration alone. Always include `recommendation` when the bottleneck classification is `slow_query` or `n+1_query`.

---

## Example 5: sampling gap — trace covers only 2 of 5 services

**Scenario:** Checkout trace has spans for frontend and API gateway only. Payment, auth, and DB spans are missing.

**Expected behavior:**
- Document which services are missing spans.
- Classify propagation gap cause (missing instrumentation).
- Provide safe query templates for recovering missing spans from logs.

```yaml
trace_scope:
  trace_completeness: partial
  spans_available: 2
  services_with_spans: [frontend, api-gateway]
  services_missing_spans: [payment-service, auth-service, postgres-checkout]
  propagation_headers_detected: true
  propagation_gap_cause: missing_instrumentation
propagation_gaps:
  - gap_id: GAP-001
    missing_service: payment-service
    recommended_fix: "Add OpenTelemetry SDK to payment-service and propagate W3C traceparent header"
  - gap_id: GAP-002
    missing_service: auth-service
    recommended_fix: "Enable tracing middleware in auth-service Express.js config"
safe_queries:
  - query_id: SQ-001
    description: "Find payment-service logs correlated with this trace via request-id header"
    query_template: "service=payment-service AND request_id={request_id} AND timestamp:[{start} TO {end}]"
downstream_handoff:
  missing_evidence: [payment_service_spans, auth_service_spans, db_spans]
  next_best_checks:
    - "Use SQ-001 to correlate payment-service logs as proxy for missing spans"
    - "Instrument missing services before next incident to enable full call chain reconstruction"
```

**Key calibration:** `safe_queries` are a first-class output when trace spans are missing. They let log-analysis pick up where trace instrumentation gaps leave off.

---

## Example 4: gRPC cross-service propagation break — trace context lost at service boundary

**Scenario:** 6-service call chain. trace_id propagates correctly through 4 services, then breaks at the gRPC boundary between checkout-service and inventory-service. Downstream spans are invisible.

**Input given:**
- trace_id: `abc-def-123`
- Spans available: gateway → auth-service → payment-service → checkout-service (spans 1-4 visible)
- Span 5 (inventory-service): no span found for trace_id
- Error in checkout logs: `inventory_client timeout after 800ms`

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  selected_mode: call_chain_analysis
  evidence_profile:
    confirmed: [trace_spans_1_4, checkout_error_log]
    missing_evidence:
      - inventory-service spans (trace context propagation broken at gRPC boundary)
    missing_evidence_impact: "Cannot observe inventory-service internal behaviour — propagation gap confirmed"
critical_path:
  - span_id: span-1
    service: api-gateway
    duration_ms: 12
    status: ok
  - span_id: span-2
    service: auth-service
    duration_ms: 45
    status: ok
  - span_id: span-3
    service: payment-service
    duration_ms: 23
    status: ok
  - span_id: span-4
    service: checkout-service
    duration_ms: 812    # 800ms of this is the inventory_client wait
    status: timeout
    bottleneck: true
    bottleneck_type: downstream_timeout
    downstream_call: inventory-service (gRPC)
    downstream_trace_found: false

propagation_gap:
  detected: true
  gap_location: "checkout-service → inventory-service (gRPC)"
  gap_cause: "W3C TraceContext header not propagated on outbound gRPC call"
  gap_impact: "inventory-service internal spans invisible — cannot determine if timeout is client-side or server-side"
  remediation: "Add gRPC interceptor to propagate traceparent header on outbound calls from checkout-service"

bottleneck_finding:
  service: inventory-service
  confidence: medium    # cannot reach high without inventory-service spans
  evidence: "checkout-service logs show 800ms wait on inventory_client; no inventory spans to confirm server-side behaviour"
  next_best_checks:
    - "Check inventory-service logs for same timestamp window (800ms timeout correlates with span-4)"
    - "Fix gRPC trace propagation; re-run trace after fix to get full call chain"

downstream_handoff:
  to_skill: root-cause-analysis-recommendation
  finding_summary: "Bottleneck likely in inventory-service (checkout timeout 800ms); propagation gap prevents confirmation"
  to_skill_log_analysis:
    urgency: immediate
    reason: "Pull inventory-service logs for T+span-4 window to compensate for missing trace spans"
self_check:
  passed: true
  warnings:
    - "Propagation gap detected — confidence capped at medium until inventory-service spans available"
```

**Key calibration:** When trace propagation breaks, document the exact gap location and cause. Confidence must not exceed `medium` when spans are missing. Always suggest log_analysis as a compensating investigation path.

---

## Example 5: Cold start / first-request latency spike

**Scenario:** First request to a freshly-deployed checkout-service pod spikes to 4,200ms. Subsequent requests are normal (85ms p99). Cold start suspected.

**Input given:**
- trace_id: `cold-start-trace-001` (first request after pod restart)
- Span breakdown: pod initialization 3,800ms + actual request processing 400ms
- All subsequent traces: 85ms p99 (no cold start)

**Expected output shape:**
```yaml
critical_path:
  - span_id: cold-init-001
    service: checkout-service
    span_name: "pod_initialization"
    duration_ms: 3800
    span_labels: [cold_start, jvm_warmup]
    bottleneck: true
    bottleneck_type: cold_start_initialization
    note: "JVM class loading + Spring context initialization. Expected behaviour on first request after deploy."
  - span_id: request-001
    service: checkout-service
    span_name: "POST /checkout"
    duration_ms: 400
    status: ok

bottleneck_finding:
  service: checkout-service
  bottleneck_type: cold_start
  confidence: high
  cold_start_evidence:
    first_request_latency_ms: 4200
    subsequent_p99_ms: 85
    cold_start_overhead_ms: 3800
    cold_start_label_present: true
  classification: expected_behaviour
  action_required: false
  recommendation: "Cold start is expected on pod restart. If SLO is affected, consider JVM warmup traffic (priming requests) as part of release-task-orchestration phase P3."

downstream_handoff:
  to_skill: monitoring-metric-interpretation
  finding_summary: "Cold start confirmed — 3,800ms init overhead on first request. Normal behaviour; no incident."
  alert_suppression_hint: "Suppress first-request p99 SLO alert within T+2min of pod restart"
self_check:
  passed: true
```

**Key calibration:** Cold start latency must be classified as `expected_behaviour` when JVM warmup labels or pod restart context is present. Do not escalate to incident response. Recommend SLO alert suppression window and priming traffic as mitigation.


---

## Scenario calibration
See `references/real-examples.md` for annotated scenarios covering green (full evidence), amber (partial evidence with degradation), and red (hard-blocker) paths.

For output field definitions, see `references/field-contract.md`.
For quality-gate rules, see `references/quality-checklist.md`.
For failure-mode handling, see `references/failure-modes.md`.
For shared ops-runtime execution contract, see `references/ops-runtime-shared-contract.md`.