---
name: trace-call-chain-analysis
description: analyze distributed trace call chains for n300 incidents. use for single trace drilldown, aggregated trace patterns, critical path bottlenecks, propagation gaps, slow or failed spans, dependency latency, and evidence consumed by rca, impact scope, and bug triage. produce Trace分析.md without designing tracing instrumentation.
---
# trace-call-chain-analysis

## Purpose
Use this skill in the N300 runtime monitoring and incident-diagnosis node to produce `Trace分析.md`. The skill is standalone: it can work with the minimum evidence listed below, and it becomes stronger when combined through the shared N300 contract.

## V2.5.0 optimization note
This version uses `references/n300-shared-runtime-contract.md` as the common source for execution workflow, input handling, self-check, incident id rules, evidence references, downstream handoff schema, and combination paths. Keep this SKILL.md focused on the skill-specific boundary, modes, minimum inputs, output sections, and consumers.

## V2.5.0 encapsulation baseline
This release keeps one contract version across SKILL.md metadata, output-contract.yaml, and references/n300-shared-runtime-contract.md. The skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside each skill plus the artifacts exchanged through downstream_handoff.

## Scope boundary
- Own: distributed trace causal path and bottleneck analysis.
- Artifact target: `Trace分析.md`.
- Boundary: explain request path, bottlenecks, and propagation gaps; do not own business impact or final root-cause decision.
- Do not perform N310 remediation execution or N320 postmortem authorship unless explicitly asked to create a handoff draft.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `incident_id`, and `contract_version` before the main findings.

Allowed modes:
- `single_trace`
- `aggregated_patterns`
- `perf_regression_scan`
- `dependency_map_focus`

## Standalone minimum viable input
This skill can run with only:
- one trace id or exported trace sample
- service boundary or entry span when available
- time window for comparison when available

When evidence is partial, keep the output structure stable, lower `readiness`, and list missing evidence in `downstream_handoff.missing_evidence`.


## Standalone and composition role
```yaml
standalone_guarantee: "Analyze one trace id, trace export, or call-chain sample into critical path, bottleneck spans, and propagation gaps without requiring logs or metrics."
composition_role: "trace_path_explainer"
composition_leverage: "Adds causal path evidence to metric/log symptoms; supplies critical-path percentages, downstream propagation, and span-level errors to bug analysis, RCA, impact scope, and postmortem timelines."
best_combines_with: ["bug-analysis", "root-cause-analysis-recommendation", "impact-scope-analysis", "N320"]
standalone_readiness_floor: partial
composition_join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - evidence_refs
```

When this skill is run alone, produce `Trace分析.md` without waiting for sibling artifacts. When it is run in a composed N300 path, consume earlier artifacts only through `downstream_handoff` and `evidence_refs`, then emit a stronger handoff for the next skill.

## Input handling
Follow `V2.5.0 common input handling` in `references/n300-shared-runtime-contract.md`. Use optional evidence only to strengthen this skill's own artifact, not to perform sibling-skill work.
## Execution workflow
Follow `V2.5.0 common execution workflow` in `references/n300-shared-runtime-contract.md`, then apply the skill-specific required sections and design rules below.
## Required output sections
Every output must include:
- `metadata`
- `incident_overview`
- `trace_scope`
- `call_chain_summary`
- `critical_path[]`
- `bottleneck_spans[]`
- `error_spans[]`
- `propagation_gaps[]`
- `baseline_comparison`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `contract_version: n300-runtime-v2.5.0`
- `workflow_node: N300`
- `node_artifact_target: Trace分析.md`
- `function_bias: distributed_trace_causal_path_and_bottleneck_analysis`
- `stage_position: operations_runtime.monitoring_and_diagnosis.trace_call_chain_analysis`
- `incident_id`
- `selected_mode`
- `readiness`
- `evidence_profile`
- `tool_collaboration_mode`

Primary rows or structured entries must preserve:
- `trace_id`
- `span_id`
- `parent_span_id`
- `service`
- `operation`
- `duration_ms`
- `critical_path_pct`
- `status`
- `error_type`
- `dependency`
- `evidence_ref`
- `confidence`

## Downstream handoff contract
Use the shared schema in `references/n300-shared-runtime-contract.md`. For this skill, preferred consumers are:

```yaml
downstream_consumers:
  - target: bug-analysis
    summary: failing operation and request path evidence for symptom triage
  - target: root-cause-analysis-recommendation
    summary: critical-path, error-span, and dependency evidence for hypothesis testing
  - target: impact-scope-analysis
    summary: affected services, dependencies, and propagation path for blast-radius estimation
  - target: N320
    summary: timeline checkpoints and dependency graph snippets for postmortem
```

## Design rules
- always distinguish entry span, critical path, and symptom spans.
- when no baseline exists, mark baseline_comparison as unavailable and avoid regression claims.
- call out missing spans, missing propagation, or broken parent-child links as evidence gaps.
- do not infer user impact from trace count alone; hand that to impact-scope-analysis.
- Always preserve source time windows, source systems, and evidence references.
- Distinguish observed facts from hypotheses.
- Keep sensitive raw data out of final artifacts.

## Self-check
Run `V2.5.0 common self-check` from `references/n300-shared-runtime-contract.md` and additionally confirm this skill's artifact target, boundary, modes, and `output-contract.yaml` fields are satisfied.
## Reference files
- `references/n300-shared-runtime-contract.md`
- `references/output-contract.yaml`
- `references/trace-critical-path-playbook.md`
