---
name: alert-attribution
description: attribute alert storms for n300 incidents. use for alert deduplication, root alert versus symptom alert selection, false positive checks, incident_id creation or normalization, owner routing, escalation sla, suppression notes, and handoff to on-call response. produce 告警归因.md.
---
# alert-attribution

## Purpose
Use this skill in the N300 runtime monitoring and incident-diagnosis node to produce `告警归因.md`. The skill is standalone: it can work with the minimum evidence listed below, and it becomes stronger when combined through the shared N300 contract.

## V2.5.0 optimization note
This version uses `references/n300-shared-runtime-contract.md` as the common source for execution workflow, input handling, self-check, incident id rules, evidence references, downstream handoff schema, and combination paths. Keep this SKILL.md focused on the skill-specific boundary, modes, minimum inputs, output sections, and consumers.

## V2.5.0 encapsulation baseline
This release keeps one contract version across SKILL.md metadata, output-contract.yaml, and references/n300-shared-runtime-contract.md. The skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside each skill plus the artifacts exchanged through downstream_handoff.

## Scope boundary
- Own: alert deduplication routing and initial incident hypothesis.
- Artifact target: `告警归因.md`.
- Boundary: normalize and attribute alert signals and routing; do not perform full RCA, final remediation, or long-term alert catalog governance unless in fatigue_reduction mode.
- Do not perform N310 remediation execution or N320 postmortem authorship unless explicitly asked to create a handoff draft.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `incident_id`, and `contract_version` before the main findings.

Allowed modes:
- `dedup_only`
- `root_cause_hint`
- `routing_only`
- `fatigue_reduction`

## Standalone minimum viable input
This skill can run with only:
- one alert payload, alert burst, or monitor firing record
- timestamp or alert window
- alert labels or service hints when available

When evidence is partial, keep the output structure stable, lower `readiness`, and list missing evidence in `downstream_handoff.missing_evidence`.


## Standalone and composition role
```yaml
standalone_guarantee: "Attribute a single alert or alert storm into root alert, symptom alerts, dedup groups, provisional or normalized incident_id, owner routing, and escalation notes."
composition_role: "alert_entry_and_routing"
composition_leverage: "Often starts alert-first orchestration; supplies incident entry, alert windows, ownership, suppression hints, and routing context to metrics, logs, traces, N310, and N320."
best_combines_with: ["monitoring-metric-interpretation", "log-analysis", "trace-call-chain-analysis", "N310", "N320"]
standalone_readiness_floor: partial
composition_join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - evidence_refs
```

When this skill is run alone, produce `告警归因.md` without waiting for sibling artifacts. When it is run in a composed N300 path, consume earlier artifacts only through `downstream_handoff` and `evidence_refs`, then emit a stronger handoff for the next skill.

## Input handling
Follow `V2.5.0 common input handling` in `references/n300-shared-runtime-contract.md`. Use optional evidence only to strengthen this skill's own artifact, not to perform sibling-skill work.
## Execution workflow
Follow `V2.5.0 common execution workflow` in `references/n300-shared-runtime-contract.md`, then apply the skill-specific required sections and design rules below.
## Required output sections
Every output must include:
- `metadata`
- `incident_overview`
- `incident_entry`
- `alert_clusters[]`
- `dedup_summary`
- `likely_root_alert`
- `routing_decision`
- `upstream_downstream_map`
- `suppression_or_fatigue_notes`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `contract_version: n300-runtime-v2.5.0`
- `workflow_node: N300`
- `node_artifact_target: 告警归因.md`
- `function_bias: alert_deduplication_routing_and_initial_incident_hypothesis`
- `stage_position: operations_runtime.monitoring_and_diagnosis.alert_attribution`
- `incident_id`
- `selected_mode`
- `readiness`
- `evidence_profile`
- `tool_collaboration_mode`

Primary rows or structured entries must preserve:
- `alert_group_id`
- `incident_id`
- `alert_type`
- `dedup_key`
- `correlated_alerts`
- `likely_root_component`
- `initial_hypothesis`
- `primary_responder`
- `secondary_responder`
- `escalation_sla`

## Downstream handoff contract
Use the shared schema in `references/n300-shared-runtime-contract.md`. For this skill, preferred consumers are:

```yaml
downstream_consumers:
  - target: monitoring-metric-interpretation
    summary: root alert metric names and time windows for signal interpretation
  - target: log-analysis
    summary: alert-correlated service/time windows for log evidence gathering
  - target: trace-call-chain-analysis
    summary: suspected services or request paths needing trace drilldown
  - target: N310
    summary: primary responder, secondary responder, escalation SLA, and alert severity context
  - target: N320
    summary: first alert time, alert fan-out, dedup reasoning, and routing timeline
```

## Design rules
- if no incident_id exists, create or normalize a stable incident entry and mark generation method.
- distinguish likely root alert from downstream symptom alerts.
- always include routing and escalation ownership when evidence allows.
- record false-positive, suppression, or fatigue evidence without hiding real user impact.
- Always preserve source time windows, source systems, and evidence references.
- Distinguish observed facts from hypotheses.
- Keep sensitive raw data out of final artifacts.

## Self-check
Run `V2.5.0 common self-check` from `references/n300-shared-runtime-contract.md` and additionally confirm this skill's artifact target, boundary, modes, and `output-contract.yaml` fields are satisfied.
## Reference files
- `references/n300-shared-runtime-contract.md`
- `references/output-contract.yaml`
- `references/alert-routing-and-dedup.md`
