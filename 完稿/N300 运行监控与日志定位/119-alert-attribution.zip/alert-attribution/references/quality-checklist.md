# quality-checklist

Run this checklist before finalizing any ops-runtime skill artifact. A good ops-runtime output passes all items or explicitly records why an item is not applicable.

## Mandatory items (must pass or explicitly N/A)

### Evidence integrity
- [ ] `incident_id` is present and either official or marked provisional with generation method
- [ ] `source_time_window` start and end are specified or marked `unknown` with reason
- [ ] Every primary finding cites at least one `evidence_ref` with `source_family` and `confidence`
- [ ] Observed facts are separated from inferences and hypotheses
- [ ] No plaintext PII, passwords, tokens, or secrets appear in the artifact

### Boundary compliance
- [ ] The artifact stays inside this skill's `Scope boundary` from SKILL.md
- [ ] No sibling-skill analysis was performed (e.g., log-analysis does not perform RCA)
- [ ] If sibling artifact content was used, it is cited by artifact name and `evidence_ref` only

### Output completeness
- [ ] All Required output sections from SKILL.md are present
- [ ] All primary row fields are present; missing values use `unable_to_measure` or `unknown` + reason
- [ ] `readiness` value is consistent with evidence quality and section completeness
- [ ] `evidence_profile` matches the actual signal families present

### Downstream handoff
- [ ] `downstream_handoff` is present and machine-readable
- [ ] Each handoff entry specifies `target`, `handoff_type`, `summary`, and `confidence`
- [ ] `missing_evidence` and `next_best_checks` are non-empty when readiness is partial or draft

### Self-check
- [ ] All V2.5.0 common self-check items from `references/ops-runtime-shared-runtime-contract.md` pass
- [ ] Any failed self-check item is recorded with reason and remediation action

## Quality bar summary

A high-quality ops-runtime artifact:
- Is incident-centric, not tool-centric
- Tells a coherent diagnostic story from signal → finding → handoff
- Preserves all uncertainty explicitly (confidence labels, conflicting signals, missing evidence)
- Is machine-consumable by the next skill in any combination path
- Can be audited post-incident without additional context from the analyst


---

## Self-check quantified rules

| Rule ID | Condition | Failure action |
|---|---|---|
| SCR-ALERTATT-001 | Every alert has exactly one cluster assignment | `self_check.passed: false` |
| SCR-ALERTATT-002 | No duplicate `root_alert_id` across clusters | `self_check.passed: false` |
| SCR-ALERTATT-003 | `provisional_incident_id` present on every cluster | `self_check.passed: false` |
| SCR-ALERTATT-004 | `downstream_handoff` present with at least one `handoff_type` | `self_check.passed: false` |
| SCR-ALERTATT-005 | `storm_detected: true` → `selected_mode: dedup_only`, `readiness: red` | `self_check.passed: false` if inconsistent |