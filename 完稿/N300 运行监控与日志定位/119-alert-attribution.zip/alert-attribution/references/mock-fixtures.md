## Mock input fixture

```yaml
mock_input:
  scenario: "alert_storm"
  content:
    alert_count: 312
    alert_rate_per_min: 312
    label_coverage_pct: 60
  expected_output_shape:
    metadata:
      selected_mode: dedup_only
      readiness: red
    dedup_summary:
      storm_detected: true
      routing_decision: default_oncall_queue
    self_check:
      passed: false
      failed_rules: ["Alert storm — structured deduplication not possible with <90% label coverage"]

mock_input_2:
  scenario: "single_alert_rich_evidence"
  content:
    alert: "payment-service SLO burn 14x"
    logs: "NullPointerException at PaymentProcessor.java:142"
    trace_count: 2
  expected_output_shape:
    alert_clusters:
      min_entries: 1
    dedup_summary:
      storm_detected: false
    self_check:
      passed: true
```
