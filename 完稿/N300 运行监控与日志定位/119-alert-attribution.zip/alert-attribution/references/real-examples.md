# real-examples

These examples illustrate how to produce this skill's artifact under different evidence conditions. Use them as output calibration references — not as templates to copy verbatim.

## Example 1: Minimum viable input (readiness: partial)

**Scenario:** Single metric spike, no logs or traces available.

**Input given:**
- Service: `payment-service`
- Signal: `http_error_rate` jumped from 0.3% to 12% at 14:32 UTC
- No trace data, no log access

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  evidence_profile: metrics_only
  incident_id: TEMP-ops-runtime-20240315-payment-metric
evidence_profile:
  missing_evidence:
    - structured logs for error classification
    - trace ids to correlate request path
  next_best_checks:
    - pull error log sample from payment-service for 14:30–14:40 UTC
    - check recent deployment or config change in this window
```

**Key calibration:** Output must not invent error causes. State "elevated error rate observed; cause undetermined pending log/trace evidence."

---

## Example 2: Rich multi-signal input (readiness: ready)

**Scenario:** Alert storm with logs and partial traces available.

**Input given:**
- Alert: `payment-service SLO burn rate 14× budget`
- Log sample: 3,200 lines of `NullPointerException` in `PaymentProcessor.java:142`
- Trace: 2 trace IDs showing 8s p99 at `db-connection-pool`
- Recent change: DB connection pool size reduced from 100→20 at 14:15 UTC

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  evidence_profile: multi_signal
recommended_finding:
  hypothesis_id: H1
  statement: "Connection pool exhaustion caused by config change at 14:15 UTC"
  confidence: high
  supporting_evidence_refs: [alert-001, log-finding-3, trace-T1, trace-T2]
  contradicting_evidence_refs: []
```

**Key calibration:** Confidence "high" requires at least 2 corroborating signal families AND a plausible causal mechanism.

---

## Example 3: Conflicting evidence (readiness: partial)

**Scenario:** Logs point to DB; metrics show CPU spike on app tier.

**Expected output shape:**
```yaml
hypothesis_testing:
  - hypothesis_id: H1
    statement: "DB connection exhaustion is root cause"
    confidence: medium
    supporting_evidence_refs: [log-finding-1]
    contradicting_evidence_refs: [metric-cpu-001]
    status: unresolved — conflicting signals
  - hypothesis_id: H2
    statement: "App-tier CPU spike caused downstream DB timeouts"
    confidence: low
    supporting_evidence_refs: [metric-cpu-001]
    contradicting_evidence_refs: [log-finding-1]
    status: unresolved
recommended_root_cause:
  statement: "Insufficient evidence to choose between H1 and H2"
  next_best_checks:
    - capture JVM thread dump from app tier during next occurrence
    - check DB slow query log for same window
```

**Key calibration:** Never collapse conflicting hypotheses into a single confident conclusion. Keep both visible.

---

## Example 4: Alert storm — dedup_only mode (readiness: red)

**Scenario:** 312 alerts/min firing across 15 services. Structured labels cover only 60% of alerts.

**Expected behavior:**
- Activate `dedup_only` mode immediately.
- Do NOT attempt cluster-based routing; label coverage is insufficient.
- Route entire burst to default on-call queue with urgency: immediate.
- Set `storm_detected: true` and document the label gap.

```yaml
metadata:
  readiness: red
  selected_mode: dedup_only
  incident_id: TEMP-storm-20260520-002
alert_clusters:
  cluster_count: 0
  note: "Storm mode — structured deduplication suppressed"
dedup_summary:
  storm_detected: true
  alert_rate_per_min: 312
  label_coverage_pct: 60
  routing_decision: default_oncall_queue
downstream_handoff:
  urgency: immediate
  next_best_checks:
    - "Enforce structured alert labels on all services (target: >90% coverage)"
    - "Run anomaly-clustering once storm subsides to identify root cluster"
self_check:
  passed: false
  failed_rules: ["Alert storm — structured deduplication not possible with <90% label coverage"]
```

**Key calibration:** Alert storm → `readiness: red` is correct. A red artifact that routes to default on-call is more valuable than refusing to produce output.

---

## Example 5: fatigue_reduction mode — suppressing known flapping alert

**Scenario:** `disk-usage-warning` on `batch-server-03` has fired 47 times in 30 days with no actionable outcome.

**Expected behavior:**
- Classify as `suppression_candidate`.
- Document suppression rationale with evidence (fire count, zero actionable outcomes).
- Require human approval before suppression takes effect.

```yaml
metadata:
  readiness: ready
  selected_mode: fatigue_reduction
suppression_candidates:
  - alert_name: disk-usage-warning
    service: batch-server-03
    fire_count_30d: 47
    actionable_outcomes: 0
    suppression_rationale: "Chronic low-priority noise; no incident escalated in 30 days"
    suppression_kind: time_window_suppress
    suppression_window: "02:00–06:00 UTC weekdays"
    approval_required: true
    approval_role: sre-lead
downstream_handoff:
  next_best_checks:
    - "SRE lead to approve suppression rule before next maintenance window"
self_check:
  passed: true
```

**Key calibration:** `fatigue_reduction` mode never auto-suppresses. Always require `approval_required: true` with a named `approval_role`.

---

## Example 6: Post-incident feedback integration

**Scenario:** After an incident where alert-attribution incorrectly identified DB-slow as root (it was actually network partition), a `false_negative` signal is confirmed.

**Expected SKILL.md retrospective action:**
1. The `false_negative` is confirmed: network partition was missed because network alerts lacked structured labels
2. Add to `real-examples.md` as a new calibration scenario
3. Add SCR rule: "When `DK7_version_mismatch` and `network_alert` both present, route to network team first"

**New calibration example added from retrospective:**
```yaml
# Scenario: network partition masked by DB slow alert
alert_clusters:
  - cluster_id: CL-CAUTION-001
    root_alert_id: "db-slow-query-001"
    symptom_alert_ids: ["db-connection-timeout-002"]
    routing_decision: db-team
    confidence: medium
    calibration_note: "RETROSPECTIVE: If network_partition_alert also present, demote db-team routing to secondary. Network team is primary."
    retrospective_ref: "INC-2026-0312: false negative — network partition missed"
```

**Key calibration:** Retrospective feedback must update `real-examples.md` and optionally tighten SCR rules. Never silently absorb false positives/negatives without updating the skill package.

---

## Example 4: Alert storm mode — 300+ alerts/min, deduplication suppressed

**Scenario:** Production alert storm: 312 alerts/min triggered by a cascading DB failure. Structured labels cover only 60% of alerts. Full dedup impossible; storm mode activates.

**Input given:**
- Alert burst: 312 alerts/min for 8 minutes
- Structured label coverage: 61% (below 90% threshold)
- Incident context: payment-service DB primary down

**Expected output shape:**
```yaml
metadata:
  readiness: red
  selected_mode: dedup_only
  evidence_profile:
    confirmed: [alert_burst_payload]
    missing_evidence:
      - structured alert labels for >90% of alerts
    missing_evidence_impact: "Alert storm: 312 alerts/min. Label coverage 61% — insufficient for reliable routing."
alert_clusters:
  cluster_count: 0
  note: "Alert storm mode. Deduplication suppressed — routing to on-call default queue."
dedup_summary:
  storm_detected: true
  alert_rate_per_min: 312
  storm_duration_min: 8
  label_coverage_pct: 61
  routing_decision: default_oncall_queue
  root_alert_candidates:
    - alert_id: "db-primary-down-001"
      service: payment-service
      label: "db_primary_health"
      confidence: medium
      note: "Only candidate with structured label — provisional root alert"
downstream_handoff:
  urgency: immediate
  missing_evidence: [structured_alert_labels]
  next_best_checks:
    - "on-call-response-recommendation: activate T1 playbook immediately"
    - "Once storm subsides, re-run alert-attribution with full structured labels"
self_check:
  passed: false
  failed_rules: ["Alert storm — structured deduplication not possible; label coverage 61% < 90% threshold"]
```

**Key calibration:** Storm mode is readiness: red. Even in storm mode, surface the best available root alert candidate with confidence: medium. Provide a clear resolution path for post-storm re-attribution.

---

## Example 5: False positive suppression — alert fired on canary cohort only

**Scenario:** Error rate alert fires during canary stage 1 (1% traffic). The alert threshold was not adjusted for canary traffic volume, making it a false positive at this stage.

**Input given:**
- Alert: `payment-service error_rate > 2%` fired at 14:35 UTC
- Canary context: stage_1 is 1% traffic — absolute error count is 3 errors in 5 minutes
- Baseline: at full traffic this would be 300 errors — threshold calibrated for full traffic

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  selected_mode: standard
alert_clusters:
  - cluster_id: CL-001
    root_alert: "payment-service error_rate > 2%"
    alert_type: false_positive
    confidence: high
    false_positive_reason: "Alert threshold calibrated for 100% traffic; at 1% canary volume, 3 errors triggers alert but does not represent a real error rate elevation"
    suppression_note: "Suppressed for canary stage_1 (1% traffic). Re-evaluate at stage_2 (10% traffic)."
    routing_decision: suppress_with_note
    escalation_sla: none
downstream_handoff:
  to_skill: monitoring-metric-interpretation
  summary: "Alert CL-001 suppressed: canary volume false positive. Monitor at stage_2."
self_check:
  passed: true
  warnings: ["false_positive suppressed — verify canary threshold adjustment for stage_2"]
```

**Key calibration:** False positive suppression must include an explicit `false_positive_reason` and a re-evaluation trigger (next canary stage). Never suppress without documenting the reason and the re-evaluation point.


---

## Scenario calibration
See `references/real-examples.md` for annotated scenarios covering green (full evidence), amber (partial evidence with degradation), and red (hard-blocker) paths.

For output field definitions, see `references/field-contract.md`.
For quality-gate rules, see `references/quality-checklist.md`.
For failure-mode handling, see `references/failure-modes.md`.
For shared ops-runtime execution contract, see `references/ops-runtime-shared-contract.md`.