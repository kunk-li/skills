# alert routing and dedup

## Dedup goals
- suppress same-alert repeats in a short window
- merge correlated downstream alerts under one likely root alert
- reduce alert storms into one incident storyline

## Routing goals
Map alert families to primary and secondary responders with escalation timers.

## Incident entry role
If the input has no `incident_id`, this skill may create or normalize one using:
- alert timestamp
- primary service or component
- dedup key
- source alert id

Mark generated ids as `generated_by_alert_attribution` and allow later systems to replace them with an official incident id.
