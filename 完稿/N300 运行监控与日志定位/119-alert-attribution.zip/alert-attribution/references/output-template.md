# output-template

Use this template as the structural scaffold for producing this skill's artifact. Fill each section with evidence-derived content; never leave required fields empty — use `unable_to_measure`, `unknown`, or `needs_evidence` with a reason instead.

## Top-level structure

```markdown
---
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  node_artifact_target: <artifact-target>
  function_bias: <this-skill-function-bias>
  stage_position: <this-skill-stage-position>
  incident_id: <string | TEMP-ops-runtime-<date>-<source>>
  selected_mode: <allowed-mode>
  readiness: draft | partial | ready
  evidence_profile: <profile-value>
  tool_collaboration_mode: <mode>
  source_time_window:
    start: <iso8601 | unknown>
    end: <iso8601 | unknown>
  service_scope: [<service-names>]
---

## incident_overview
> 2–4 sentence plain-language summary of what happened, when, and which services.
> Always write this section even when readiness is partial.

## [skill-specific sections]
> See SKILL.md Required output sections.
> Every primary row must include all required fields.
> Use `unable_to_measure` + reason when data is unavailable.

## downstream_handoff
> Machine-readable handoff entries per the shared contract schema.
> Include missing_evidence and next_best_checks for every handoff item.

## self_check
> Record pass/fail for each shared V2.5.0 self-check item.
> If any item fails, readiness must be partial or draft.
```

## Field fill guidance

| Situation | Required action |
|---|---|
| No `incident_id` exists | Create `TEMP-ops-runtime-<YYYYMMDD>-<source>` and mark `provisional: true` |
| Evidence is partial | Keep all sections; fill with best estimate + confidence label |
| Metric not measurable | Use `unable_to_measure: true` with `reason` field |
| Hypothesis uncertain | Use `confidence: low` and list what would raise it |
| Sensitive data present | Summarize or hash; never include plaintext PII or credentials |

## Readiness decision guide

| Condition | Readiness |
|---|---|
| All required sections complete, evidence multi-signal, self-check passes | `ready` |
| Some evidence missing, assumptions made, but output is actionable | `partial` |
| Critical required fields cannot be filled without more data | `draft` |


---

## Downstream handoff YAML templates

```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: alert-attribution
  incident_id: "{incident_id}"
  artifact: 告警归因.md
  handoffs:
    - target: monitoring-metric-interpretation
      handoff_type: routing
      summary: "Root alert: payment-service SLO burn 14×; symptom alerts suppressed"
      required_fields: [root_alert_id, incident_id, escalation_sla]
      evidence_refs: [alert-001]
      confidence: high
      missing_evidence: []
      next_best_checks:
        - "Focus metric interpretation on payment-service error_rate and latency"
    - target: log-analysis
      handoff_type: routing
      summary: "Incident window: 14:15–14:45 UTC; service scope: [payment-service]"
      required_fields: [incident_id, source_time_window, service_scope]
      confidence: high
```


---

## Standalone guarantee
This skill runs independently with the minimum evidence listed in this file. Do not refuse output because sibling ops-runtime skills have not been run first. When evidence is absent, declare `readiness: partial` or `readiness: red`, populate all stable output sections with available evidence, and list missing evidence in `downstream_handoff.missing_evidence`.

---

## Mode selection

### New: `multi_alert_correlation` mode — 多告警关联分析
**Trigger:** Multiple alerts firing simultaneously and team needs to determine if they share a common root service, or user says "multiple alerts at once", "alert storm", "correlate these alerts".

```yaml
multi_alert_correlation:
  alerts_received:
    - alert_id: ALT-001
      service: payment-service
      metric: error_rate
      value: 4.2
      severity: critical
    - alert_id: ALT-002
      service: checkout-api
      metric: p99_latency_ms
      value: 820
      severity: high
    - alert_id: ALT-003
      service: cart-service
      metric: timeout_rate
      value: 12.3
      severity: high
  correlation_analysis:
    common_cause_detected: true
    probable_origin: payment-service
    correlation_pattern: cascading_dependency_failure
    evidence: "ALT-001 onset (14:03:12) precedes ALT-002 (14:03:47) and ALT-003 (14:04:01)"
    non_correlated_alerts: []
  attribution:
    primary_service: payment-service
    confidence: high
    attribution_basis: temporal_cascade + dependency_topology
```
**SCR:** `selected_mode: multi_alert_correlation` → `multi_alert_correlation.correlation_analysis.common_cause_detected` boolean; `attribution.primary_service` declared.