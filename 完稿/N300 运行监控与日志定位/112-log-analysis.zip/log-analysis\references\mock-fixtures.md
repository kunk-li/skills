## Mock input fixture

```yaml
mock_input:
  scenario: "log_access_blocked"
  content: "alert: payment-service 500 errors; log access: unavailable"
  expected_output_shape:
    metadata:
      readiness: red
    log_signatures: []
    safe_queries:
      min_entries: 1
    self_check:
      passed: false
      failed_rules: ["Log access blocked — analysis deferred"]

mock_input_2:
  scenario: "rich_log_bundle"
  content: "500 log lines, structured JSON, trace_ids present"
  expected_output_shape:
    log_signatures:
      min_entries: 1
    metadata:
      readiness: ready
    self_check:
      passed: true
```
