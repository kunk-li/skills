# readiness-inheritance

Defines how `readiness` propagates across ops-runtime skills in composed workflows.

## Readiness levels
- `green` — all required sections present, primary evidence confirmed, self-check passes
- `amber` — partial evidence; required sections stable; some findings inferred or low-confidence
- `red` — hard blocker present; output is structural only; do not act on findings without new evidence
- `partial` — output structure intact but ≥1 required section has empty or placeholder content

## Inheritance rules

### In standalone mode
Each skill sets its own `readiness` based solely on available evidence. Sibling skill outputs are not required.

### In composition (multi-skill pipeline)
| Producer skill | Consumer skill | Inheritance behavior |
|---|---|---|
| `alert-attribution` | All other ops-runtime skills | `incident_id` and `source_time_window` must be preserved; `readiness` does not inherit |
| `anomaly-clustering` | `frequent-error-summary` | `source_cluster_id` references carry over; consumer readiness is independent |
| `bug-analysis` | `root-cause-analysis-recommendation` | `accepted_hypotheses` carry over; consumer re-evaluates confidence against new evidence |
| `log-analysis` | `bug-analysis`, `root-cause-analysis-recommendation` | `evidence_refs` carry over; consumer cites them, does not re-extract |
| `impact-scope-analysis` | `root-cause-analysis-recommendation` | `blast_radius` and `affected_services` inform scope of RCA |
| Any ops-runtime skill | incident-response | `downstream_handoff` consumed; `incident_id` must match; readiness thresholds apply |

### Readiness escalation
If any upstream ops-runtime skill is `red`:
- Downstream skills must note the upstream red status in `evidence_profile.upstream_gaps`
- Downstream skills may still produce `amber` output if their own evidence is sufficient
- Downstream skills must NOT copy upstream `red` findings as `confirmed` facts

## Circuit breaker interaction
If `iter_count >= max_iter` and readiness remains `partial`, the circuit breaker fires before downstream propagation. The blocked skill emits `exception.ops-runtime.skill_blocked.v2.5.0` and halts downstream invocation.
