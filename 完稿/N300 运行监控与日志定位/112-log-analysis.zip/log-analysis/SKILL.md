---
name: log-analysis
description: analyze runtime logs for n300 incidents. use for structured log investigation, error signatures, trace id correlation, pii or secret exposure risks, portable log queries, and evidence needed by bug triage, anomaly clustering, frequent error ranking, rca, and alert attribution. produce 日志分析.md.
---
# log-analysis

## Purpose
Use this skill in the N300 runtime monitoring and incident-diagnosis node to produce `日志分析.md`. The skill is standalone: it can work with the minimum evidence listed below, and it becomes stronger when combined through the shared N300 contract.

## V2.5.0 optimization note
This version uses `references/n300-shared-runtime-contract.md` as the common source for execution workflow, input handling, self-check, incident id rules, evidence references, downstream handoff schema, and combination paths. Keep this SKILL.md focused on the skill-specific boundary, modes, minimum inputs, output sections, and consumers.

## V2.5.0 encapsulation baseline
This release keeps one contract version across SKILL.md metadata, output-contract.yaml, and references/n300-shared-runtime-contract.md. The skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside each skill plus the artifacts exchanged through downstream_handoff.

## Scope boundary
- Own: structured log investigation and pattern extraction.
- Artifact target: `日志分析.md`.
- Boundary: interpret log evidence and local log patterns; do not replace cross-signal anomaly clustering or trace critical-path analysis.
- Do not perform N310 remediation execution or N320 postmortem authorship unless explicitly asked to create a handoff draft.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `incident_id`, and `contract_version` before the main findings.

Allowed modes:
- `trace_follow`
- `error_pattern`
- `anomaly_mode`
- `audit_or_pii_check`

## Standalone minimum viable input
This skill can run with only:
- one log bundle or query result
- time window or timestamp range
- service/log source if available

When evidence is partial, keep the output structure stable, lower `readiness`, and list missing evidence in `downstream_handoff.missing_evidence`.


## Standalone and composition role
```yaml
standalone_guarantee: "Analyze a log bundle or query result into structured findings, signatures, redaction risks, and trace/log correlation without requiring metric or trace artifacts."
composition_role: "log_evidence_hub"
composition_leverage: "Acts as the evidence hub for log-first diagnosis; supplies normalized signatures, trace ids, sample-safe evidence, and contradiction signals to bug triage, clustering, frequent errors, RCA, and alerts."
best_combines_with: ["trace-call-chain-analysis", "bug-analysis", "anomaly-clustering", "frequent-error-summary", "root-cause-analysis-recommendation", "alert-attribution"]
standalone_readiness_floor: partial
composition_join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - evidence_refs
```

When this skill is run alone, produce `日志分析.md` without waiting for sibling artifacts. When it is run in a composed N300 path, consume earlier artifacts only through `downstream_handoff` and `evidence_refs`, then emit a stronger handoff for the next skill.

## Input handling
Follow `V2.5.0 common input handling` in `references/n300-shared-runtime-contract.md`. Use optional evidence only to strengthen this skill's own artifact, not to perform sibling-skill work.
## Execution workflow
Follow `V2.5.0 common execution workflow` in `references/n300-shared-runtime-contract.md`, then apply the skill-specific required sections and design rules below.
## Required output sections
Every output must include:
- `metadata`
- `incident_overview`
- `query_scope`
- `log_findings[]`
- `pattern_clusters[]`
- `redaction_risks[]`
- `trace_linkage`
- `query_translations[]`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `contract_version: n300-runtime-v2.5.0`
- `workflow_node: N300`
- `node_artifact_target: 日志分析.md`
- `function_bias: structured_log_investigation_and_pattern_extraction`
- `stage_position: operations_runtime.monitoring_and_diagnosis.log_analysis`
- `incident_id`
- `selected_mode`
- `readiness`
- `evidence_profile`
- `tool_collaboration_mode`

Primary rows or structured entries must preserve:
- `finding_id`
- `log_query_abstract`
- `backend_query_examples`
- `time_window`
- `service_scope`
- `trace_id_refs`
- `event_or_pattern`
- `level_profile`
- `pii_risk`
- `confidence`
- `next_check`

## Downstream handoff contract
Use the shared schema in `references/n300-shared-runtime-contract.md`. For this skill, preferred consumers are:

```yaml
downstream_consumers:
  - target: trace-call-chain-analysis
    summary: trace_id_refs, span hints, and request identifiers for call-chain reconstruction
  - target: bug-analysis
    summary: symptom evidence, error signatures, and recent-change correlations for fast triage
  - target: anomaly-clustering
    summary: raw event signatures and counts for cross-signal grouping
  - target: frequent-error-summary
    summary: normalized error signatures and time windows for ranking
  - target: root-cause-analysis-recommendation
    summary: supporting and contradicting log evidence for hypotheses
  - target: alert-attribution
    summary: alert-correlated log events for dedup and routing
```

## Design rules
- prefer structured json/logfmt interpretation and call out free-text logs as an observability gap.
- preserve trace_id, request_id, correlation_id, or equivalent linkage for every important finding when available.
- separate recurrent patterns from one-off noisy lines.
- keep abstract log queries canonical; backend syntax is a convenience translation.
- Always preserve source time windows, source systems, and evidence references.
- Distinguish observed facts from hypotheses.
- Keep sensitive raw data out of final artifacts.

## Self-check
Run `V2.5.0 common self-check` from `references/n300-shared-runtime-contract.md` and additionally confirm this skill's artifact target, boundary, modes, and `output-contract.yaml` fields are satisfied.
## Reference files
- `references/n300-shared-runtime-contract.md`
- `references/output-contract.yaml`
- `references/log-structure-spec.md`
