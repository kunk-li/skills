# log structure spec

## Required fields for strong readiness
- `timestamp`
- `level`
- `service`
- `event` or `message`
- `trace_id` or `correlation_id`

## Query portability
Keep `log_query_abstract` as the canonical form before translating to Loki, Splunk, Datadog, CloudWatch, Elasticsearch, or other backends.

## Policy highlights
- redact PII, tokens, api keys, credentials, and full payment data
- treat missing `trace_id` as an observability gap
- keep raw samples short and representative

## Boundary with anomaly-clustering
This skill may group similar lines inside one log investigation. `anomaly-clustering` owns cross-source, cross-incident cluster construction.
