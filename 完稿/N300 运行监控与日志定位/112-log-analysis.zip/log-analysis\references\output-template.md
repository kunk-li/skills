# output-template

Use this template as the structural scaffold for producing this skill's artifact. Fill each section with evidence-derived content; never leave required fields empty — use `unable_to_measure`, `unknown`, or `needs_evidence` with a reason instead.

## Top-level structure

```markdown
---
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  node_artifact_target: <artifact-target>
  function_bias: <this-skill-function-bias>
  stage_position: <this-skill-stage-position>
  incident_id: <string | TEMP-ops-runtime-<date>-<source>>
  selected_mode: <allowed-mode>
  readiness: draft | partial | ready
  evidence_profile: <profile-value>
  tool_collaboration_mode: <mode>
  source_time_window:
    start: <iso8601 | unknown>
    end: <iso8601 | unknown>
  service_scope: [<service-names>]
---

## incident_overview
> 2–4 sentence plain-language summary of what happened, when, and which services.
> Always write this section even when readiness is partial.

## [skill-specific sections]
> See SKILL.md Required output sections.
> Every primary row must include all required fields.
> Use `unable_to_measure` + reason when data is unavailable.

## downstream_handoff
> Machine-readable handoff entries per the shared contract schema.
> Include missing_evidence and next_best_checks for every handoff item.

## self_check
> Record pass/fail for each shared V2.5.0 self-check item.
> If any item fails, readiness must be partial or draft.
```

## Field fill guidance

| Situation | Required action |
|---|---|
| No `incident_id` exists | Create `TEMP-ops-runtime-<YYYYMMDD>-<source>` and mark `provisional: true` |
| Evidence is partial | Keep all sections; fill with best estimate + confidence label |
| Metric not measurable | Use `unable_to_measure: true` with `reason` field |
| Hypothesis uncertain | Use `confidence: low` and list what would raise it |
| Sensitive data present | Summarize or hash; never include plaintext PII or credentials |

## Readiness decision guide

| Condition | Readiness |
|---|---|
| All required sections complete, evidence multi-signal, self-check passes | `ready` |
| Some evidence missing, assumptions made, but output is actionable | `partial` |
| Critical required fields cannot be filled without more data | `draft` |


---

## Downstream handoff YAML templates

```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: log-analysis
  incident_id: "{incident_id}"
  artifact: 日志分析.md
  handoffs:
    - target: bug-analysis
      handoff_type: evidence
      summary: "Top error: NullPointerException at PaymentProcessor.java:142 (count: 3847, confidence: high)"
      required_fields: [signature_id, pattern, count, confidence, trace_ids_linked]
      evidence_refs: [LS-001]
      confidence: high
      missing_evidence: []
    - target: anomaly-clustering
      handoff_type: pattern
      summary: "3 distinct error patterns ready for cluster deduplication"
      required_fields: [signature_id, pattern, pii_risk, safe_query]
      evidence_refs: [LS-001, LS-002, LS-003]
      confidence: high
```


---

## Standalone guarantee
This skill runs independently with the minimum evidence listed in this file. Do not refuse output because sibling ops-runtime skills have not been run first. When evidence is absent, declare `readiness: partial` or `readiness: red`, populate all stable output sections with available evidence, and list missing evidence in `downstream_handoff.missing_evidence`.

---

## Output completeness rule
Every artifact from this skill MUST include:
- `metadata` with `readiness`, `selected_mode`, `evidence_profile`, `schema_version`
- `evidence_profile.confirmed` ≥ 1 item; if empty → `readiness: partial` always
- `confidence` ∈ {high, medium, low, speculative} — never absent
- `downstream_handoff` with ≥ 1 typed `handoff_type` entry
- `self_check.passed` boolean + `self_check.warnings[]`
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry with `signal_type`
- `emit_event.event_name` matching `produced.ops-runtime.*.v2`

**Hard rules:**
- `confidence: high` requires ≥ 3 distinct signal families in `evidence_profile.confirmed`
- `readiness: ready` requires `self_check.passed: true`
- Any `readiness: red` requires `self_check.failed_rules` non-empty

---

## Mode selection

### New: `structured_query` mode — 结构化日志查询分析
**Trigger:** User provides a specific log query (e.g., Elasticsearch DSL, Splunk SPL, Loki LogQL) and wants analysis of the results, or says "analyze these query results", "parse this Elasticsearch output".

```yaml
structured_query:
  query_language: elasticsearch_dsl
  query: '{"query":{"bool":{"must":[{"term":{"level":"ERROR"}},{"range":{"@timestamp":{"gte":"now-30m"}}}]}}}'
  result_summary:
    total_hits: 847
    top_patterns:
      - pattern: "NullPointerException at PaymentProcessor:142"
        count: 423
        first_occurrence: "2026-05-21T14:03:12Z"
        trend: accelerating
      - pattern: "ConnectionTimeoutException at DBPool:89"
        count: 312
        first_occurrence: "2026-05-21T13:58:00Z"
        trend: stable
    novel_patterns: []
  confidence: high
```
**SCR:** `selected_mode: structured_query` → `structured_query.query_language` declared; `result_summary.total_hits` numeric.