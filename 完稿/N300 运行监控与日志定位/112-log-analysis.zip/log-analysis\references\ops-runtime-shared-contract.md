# ops-runtime shared runtime contract

contract_version: `ops-runtime-runtime-v2.5.0`

Use this self-contained contract across all ops-runtime runtime skills. It keeps each skill independent while making multi-skill combinations stronger. This contract is packaged inside each skill under `references/ops-runtime-shared-runtime-contract.md`; no external node-level assets or scripts are required to understand or apply it.

## Shared incident keys
Every output must keep these fields in `metadata`:

```yaml
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  incident_id: string
  selected_mode: string
  readiness: draft | partial | ready
  evidence_profile: metrics_only | logs_only | traces_only | alerts_only | multi_signal | historical_enriched
  tool_collaboration_mode: unified_observability_plane | single_incident_traceback | batch_pattern_review
  source_time_window:
    start: iso8601 | unknown
    end: iso8601 | unknown
  service_scope: [string]
```

## Incident id rule
- Preserve an existing official `incident_id`.
- `alert-attribution` may create or normalize a provisional id when none exists.
- Other skills may create a temporary id only when standalone, using `TEMP-ops-runtime-<date>-<source>` style and marking it as provisional.

## Evidence reference schema
Use compact evidence references instead of copying long raw logs or traces.

```yaml
evidence_ref:
  ref_id: string
  source_family: metric | log | trace | alert | deployment | test | user_report | manual_note
  source_name: string
  query_or_source: string
  time_window: string
  service_scope: [string]
  trace_id_refs: [string]
  confidence: high | medium | low
```

## Downstream handoff schema
Every skill must include `downstream_handoff` with machine-readable entries.

```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: string
  incident_id: string
  artifact: string
  handoffs:
    - target: string
      handoff_type: evidence | hypothesis | scope | routing | pattern | gap | action_hint
      summary: string
      required_fields: [string]
      evidence_refs: [string]
      confidence: high | medium | low
      missing_evidence: [string]
      next_best_checks: [string]
```

## Shared quality rules
- Stay inside the producing skill boundary.
- Separate observed facts, inferred hypotheses, and recommended checks.
- Quantify when data exists; otherwise mark `unable_to_measure` or `needs_evidence`.
- Keep raw sensitive data out of final artifacts.
- Prefer references and row ids over copied source dumps.
- Lower readiness instead of dropping required sections when evidence is incomplete.

## ops-runtime combination paths

### Alert-first
`alert-attribution -> monitoring-metric-interpretation -> log-analysis -> trace-call-chain-analysis -> bug-analysis -> root-cause-analysis-recommendation -> impact-scope-analysis`

### Metric-first
`monitoring-metric-interpretation -> alert-attribution -> trace-call-chain-analysis -> impact-scope-analysis -> root-cause-analysis-recommendation`

### Log-first
`log-analysis -> bug-analysis -> anomaly-clustering -> frequent-error-summary -> root-cause-analysis-recommendation`

### Trace-first
`trace-call-chain-analysis -> log-analysis -> bug-analysis -> impact-scope-analysis -> root-cause-analysis-recommendation`

### Post-incident review
`frequent-error-summary + root-cause-analysis-recommendation + impact-scope-analysis -> feedback/postmortem/deployment`

## Boundary summary
- `monitoring-metric-interpretation`: signal explanation, SLO/KPI movement, metric quality.
- `log-analysis`: log evidence, signatures, trace linkage, safe queries.
- `trace-call-chain-analysis`: call path, critical path, bottleneck spans, propagation gaps.
- `bug-analysis`: fast symptom triage and decision framing.
- `anomaly-clustering`: deduplicate raw anomalies into clusters.
- `frequent-error-summary`: rank recurring known signatures over reporting windows.
- `root-cause-analysis-recommendation`: evidence-chained cause hypotheses.
- `impact-scope-analysis`: blast radius, affected users/services/data/time.
- `alert-attribution`: alert entry, dedup, root alert, routing, escalation.

## V2.5.0 common execution workflow
All ops-runtime skills follow this common runtime workflow unless the user explicitly requests a narrower extraction:

1. Normalize `incident_id`, source time window, service scope, evidence references, and provisional-id status.
2. Select the narrowest mode that answers the request; do not run sibling-skill analysis just because related evidence exists.
3. Analyze only the evidence family owned by the current skill and reference sibling outputs by artifact name plus `evidence_ref`.
4. Produce stable required sections even when evidence is incomplete; lower `readiness` instead of dropping sections.
5. Emit `downstream_handoff` entries with `handoff_type`, `required_fields`, `evidence_refs`, `confidence`, `missing_evidence`, and `next_best_checks`.
6. Run the common V2.5.0 self-check before finalizing.

## V2.5.0 common input handling
Prefer ops-runtime workflow evidence when available: `发布后验证清单.csv`, `日志文件`, `监控面板截图`, `trace数据`, and `Diff风险点评.md`. Optional enhancement evidence may include alert payloads, dashboard queries, ownership maps, release manifests, known incident history, support tickets, user reports, and business baselines.

## V2.5.0 common self-check
Before returning any ops-runtime artifact, verify:

- the output is incident-centric rather than tool-centric
- `contract_version` is exactly `ops-runtime-runtime-v2.5.0`
- `incident_id` exists or is explicitly provisional
- required sections and primary row fields from `output-contract.yaml` are present
- confidence and readiness are consistent with available evidence
- sibling-skill boundaries are respected
- `downstream_handoff` follows the machine-readable contract
- sensitive raw data is summarized or referenced, not copied verbatim

## V2.5.0 release consistency rule
A valid ops-runtime V2.5.0 skill set keeps the same `contract_version` in every `SKILL.md`, `references/output-contract.yaml`, and `references/ops-runtime-shared-runtime-contract.md`. The nine skill-local shared contract files should remain byte-identical before packaging.

## V2.5.0 encapsulation governance
Each ops-runtime skill is self-contained. The skill-local `references/ops-runtime-shared-runtime-contract.md` is the packaged contract for that skill, and the 9 skill-local contract copies together form the node-level shared convention. Do not require files, scripts, directories, or services outside the skill package to interpret the contract or to run the skill standalone.

## V2.5.0 standalone and composition guarantee
Every ops-runtime skill must be useful alone and stronger in combination.

Standalone guarantee:
- A skill must run with its own minimum viable input and no sibling artifacts.
- A skill must produce its target artifact with stable required sections even when `readiness` is `partial`.
- A skill must list missing evidence and next best checks rather than blocking on unavailable sibling signals.

Composition guarantee:
- A skill must emit `downstream_handoff` records that can be consumed by later skills.
- A composed run must join artifacts by `incident_id`, `source_time_window`, `service_scope`, and `evidence_refs`.
- Later skills must cite earlier artifacts instead of redoing their analysis.
- Conflicting evidence must remain visible with confidence labels.
- Composition guidance lives in this contract and in each skill's `Standalone and composition role` block; no external composition matrix is required.
