# rca evidence chain

Every hypothesis must include:
- supporting evidence
- contradicting evidence
- confidence
- additional investigation needed

## Methodology enum
- `RM1_five_whys`: simple to moderate incidents
- `RM2_fishbone`: multi-factor people/process/technology/environment analysis
- `RM3_fault_tree`: complex systems and multiple failure modes
- `RM4_timeline_analysis`: distributed system incidents
- `RM5_barrier_analysis`: where safeguards failed
- `RM6_change_analysis`: recent change related incidents
- `RM7_causal_loop_diagram`: systemic dynamics

## Output discipline
Distinguish containment from prevention. If evidence is incomplete, keep the hypothesis as partial and list exact evidence gaps.
