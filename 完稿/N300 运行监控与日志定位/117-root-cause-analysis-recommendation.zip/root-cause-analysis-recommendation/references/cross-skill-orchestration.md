# cross-skill-orchestration

Describes how the nine ops-runtime skills collaborate in multi-signal incident diagnosis.

## Canonical combination paths

### Alert-first (most common)
```
alert-attribution
  → monitoring-metric-interpretation  (metric anomaly confirmation)
  → log-analysis                       (log evidence gathering)
  → trace-call-chain-analysis          (call path reconstruction)
  → bug-analysis                       (fast symptom triage)
  → root-cause-analysis-recommendation (evidence-chained RCA)
  → impact-scope-analysis              (blast radius quantification)
```

### Metric-first
```
monitoring-metric-interpretation
  → alert-attribution        (alert dedup and routing)
  → trace-call-chain-analysis (latency/error path drilldown)
  → impact-scope-analysis     (SLO burn → user impact)
  → root-cause-analysis-recommendation
```

### Log-first
```
log-analysis
  → anomaly-clustering        (pattern deduplication)
  → frequent-error-summary    (error ranking)
  → bug-analysis              (triage framing)
  → root-cause-analysis-recommendation
```

## Join keys for composition
All ops-runtime skills share these composition join keys:
- `incident_id` — primary correlation key
- `source_time_window` — time range anchor
- `service_scope` — affected service list
- `evidence_refs` — reference IDs passed between skills
- `contract_version: ops-runtime-runtime-v2.5.0` — version guard

## Composition rules
1. Later skills cite earlier artifacts by `artifact name + evidence_ref`, never by re-running the same analysis.
2. `incident_id` must remain stable across all skills in a single incident. Only `alert-attribution` may create or normalize a new incident_id.
3. Skills emit `downstream_handoff` records that declare `handoff_type`, `required_fields`, `evidence_refs`, `confidence`, and `next_best_checks`.
4. When two skills contradict each other (e.g., log-analysis says service A is healthy, metrics say it is degraded), both findings remain visible with `conflicting` confidence labels — do not suppress contradictions.
5. Circuit breakers are skill-local. A skill that triggers its circuit breaker must emit `exception.ops-runtime.skill_blocked.v2.5.0` and hand off to the incident commander, not to the next ops-runtime skill in the chain.

## Refresh triggers
- If `alert-attribution` re-classifies the root alert, emit `downstream_handoff.refresh_triggers: [monitoring-metric-interpretation, log-analysis]` so those skills can re-consume updated `incident_id` and `source_time_window`.
- If `anomaly-clustering` merges or splits clusters, emit `downstream_handoff.refresh_triggers: [frequent-error-summary, root-cause-analysis-recommendation]`.


---

## Boundary comparison table — root-cause-analysis-recommendation

| Dimension | root-cause-analysis-recommendation | alert-attribution | impact-scope-analysis | remediation-plan-recommendation |
|---|---|---|---|---|
| **Primary question** | "WHY did this incident happen?" | "WHICH component triggered the alert?" | "WHO and WHAT is affected?" | "WHICH fix path to take?" |
| **Output type** | Causal chain: evidence-backed five-why + hypothesis ranking | Attribution record: signal→service + confidence | Scope map: users/revenue/SLA impact | Option comparison: rollback vs hotfix vs contain |
| **Timing** | Starts parallel with response; may run for hours post-containment | At alert detection (T+0, fast) | T+5min (impact signal needed) | After containment (T+15min to T+60min) |
| **Evidence type** | Logs, traces, metrics, deployment history, topology | Alert payload, metric correlation, topology | User signals, error rates, SLO data, business metrics | RCA output + impact scope + rollback plan |
| **Owns** | Causal chain, five-why, hypothesis, prevention recommendations | Alert→service attribution | User count, revenue, tier recommendation | Fix path selection, TTR comparison |
| **Does not own** | Alert attribution (→111), impact quantification (→116), fix path (→121) | Root cause depth (→119), impact (→116) | Root cause (→119), attribution (→111) | Root cause analysis (→119), impact (→116) |

### Hard sequencing rule
```
Canonical flow:
  111 (attribution) → 116 (impact) → 119 (RCA) → 121 (remediation path)

119 MUST start in parallel with 120 (response) — not after
119 output SHOULD feed 121 before fix path decision
119 NEVER produces fix steps — that belongs to 121
119 CAN run without 111 output (evidence can include alert payload directly)
```