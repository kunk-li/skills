# output-template

Use this template as the structural scaffold for producing this skill's artifact. Fill each section with evidence-derived content; never leave required fields empty — use `unable_to_measure`, `unknown`, or `needs_evidence` with a reason instead.

## Top-level structure

```markdown
---
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  node_artifact_target: <artifact-target>
  function_bias: <this-skill-function-bias>
  stage_position: <this-skill-stage-position>
  incident_id: <string | TEMP-ops-runtime-<date>-<source>>
  selected_mode: <allowed-mode>
  readiness: draft | partial | ready
  evidence_profile: <profile-value>
  tool_collaboration_mode: <mode>
  source_time_window:
    start: <iso8601 | unknown>
    end: <iso8601 | unknown>
  service_scope: [<service-names>]
---

## incident_overview
> 2–4 sentence plain-language summary of what happened, when, and which services.
> Always write this section even when readiness is partial.

## [skill-specific sections]
> See SKILL.md Required output sections.
> Every primary row must include all required fields.
> Use `unable_to_measure` + reason when data is unavailable.

## downstream_handoff
> Machine-readable handoff entries per the shared contract schema.
> Include missing_evidence and next_best_checks for every handoff item.

## self_check
> Record pass/fail for each shared V2.5.0 self-check item.
> If any item fails, readiness must be partial or draft.
```

## Field fill guidance

| Situation | Required action |
|---|---|
| No `incident_id` exists | Create `TEMP-ops-runtime-<YYYYMMDD>-<source>` and mark `provisional: true` |
| Evidence is partial | Keep all sections; fill with best estimate + confidence label |
| Metric not measurable | Use `unable_to_measure: true` with `reason` field |
| Hypothesis uncertain | Use `confidence: low` and list what would raise it |
| Sensitive data present | Summarize or hash; never include plaintext PII or credentials |

## Readiness decision guide

| Condition | Readiness |
|---|---|
| All required sections complete, evidence multi-signal, self-check passes | `ready` |
| Some evidence missing, assumptions made, but output is actionable | `partial` |
| Critical required fields cannot be filled without more data | `draft` |


---

## Downstream handoff YAML templates

```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: root-cause-analysis-recommendation
  incident_id: "{incident_id}"
  artifact: 根因定位建议.md
  handoffs:
    - target: on-call-response-recommendation  # cross-node
      handoff_type: hypothesis
      summary: "Root cause confirmed (high): DB connection pool exhaustion from config change at T-30min"
      required_fields: [recommended_root_cause, confidence, evidence_refs]
      evidence_refs: [log-finding-1, trace-T1, config-diff-001]
      confidence: high
      missing_evidence: []
    - target: remediation-plan-recommendation  # cross-node: ops-runtime → incident-response
      handoff_type: hypothesis
      summary: "Root cause: config change → connection exhaustion. Rollback is fastest fix path."
      required_fields: [recommended_root_cause, systemic_vs_sporadic, prevention_hint]
      confidence: high
      next_best_checks:
        - "Evaluate rollback vs hotfix in remediation-plan-recommendation"
```


---

## Standalone guarantee
This skill runs independently with the minimum evidence listed in this file. Do not refuse output because sibling ops-runtime skills have not been run first. When evidence is absent, declare `readiness: partial` or `readiness: red`, populate all stable output sections with available evidence, and list missing evidence in `downstream_handoff.missing_evidence`.

---

## Output completeness rule
Every artifact from this skill MUST include:
- `metadata` with `readiness`, `selected_mode`, `evidence_profile`, `schema_version`
- `evidence_profile.confirmed` ≥ 1 item; if empty → `readiness: partial` always
- `confidence` ∈ {high, medium, low, speculative} — never absent
- `downstream_handoff` with ≥ 1 typed `handoff_type` entry
- `self_check.passed` boolean + `self_check.warnings[]`
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry with `signal_type`
- `emit_event.event_name` matching `produced.ops-runtime.*.v2`

**Hard rules:**
- `confidence: high` requires ≥ 3 distinct signal families in `evidence_profile.confirmed`
- `readiness: ready` requires `self_check.passed: true`
- Any `readiness: red` requires `self_check.failed_rules` non-empty

---

## Mode selection

### New: `infrastructure_rca` mode — 基础设施根因分析
**Trigger:** Incident is infrastructure-related (cloud, k8s, network) rather than application code, or user says "infra root cause", "k8s issue RCA", "cloud provider outage analysis".

```yaml
infrastructure_rca:
  infra_scope: kubernetes
  infra_signals:
    - signal: "Pod OOMKilled — memory limit 512Mi exceeded"
      signal_type: k8s_event
      timestamp: "2026-05-21T14:02:00Z"
    - signal: "Node memory pressure detected on node-04"
      signal_type: k8s_node_condition
      timestamp: "2026-05-21T14:00:00Z"
  hypothesis_ranking:
    - rank: 1
      category: resource_limit_misconfiguration
      hypothesis: "Memory limit 512Mi too low for new feature's heap allocation"
      evidence: "OOMKilled + node pressure correlating with v2.1 deploy at T-47min"
      confidence: high
      fix_hint: "Increase memory limit to 768Mi; add vertical pod autoscaling"
    - rank: 2
      category: memory_leak
      hypothesis: "Memory leak in new code path"
      confidence: medium
      fix_hint: "Profile heap with pprof — requires code investigation"
  causal_chain:
    - why_1: "Pods restarting frequently"
    - why_2: "OOMKilled events on payment-service pods"
    - why_3: "Memory usage exceeds 512Mi limit"
    - why_4: "v2.1 added image processing feature with 300MB baseline heap"
    - why_5: "Memory limit was not updated when feature was added"
  prevention: "Add memory limit validation to CI pipeline for PRs touching new features"
  confidence: high
```
**SCR:** `selected_mode: infrastructure_rca` → `infrastructure_rca.infra_scope` declared; `causal_chain` ≥ 3 why steps.