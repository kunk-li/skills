# quality-checklist

Run this checklist before finalizing any ops-runtime skill artifact. A good ops-runtime output passes all items or explicitly records why an item is not applicable.

## Mandatory items (must pass or explicitly N/A)

### Evidence integrity
- [ ] `incident_id` is present and either official or marked provisional with generation method
- [ ] `source_time_window` start and end are specified or marked `unknown` with reason
- [ ] Every primary finding cites at least one `evidence_ref` with `source_family` and `confidence`
- [ ] Observed facts are separated from inferences and hypotheses
- [ ] No plaintext PII, passwords, tokens, or secrets appear in the artifact

### Boundary compliance
- [ ] The artifact stays inside this skill's `Scope boundary` from SKILL.md
- [ ] No sibling-skill analysis was performed (e.g., log-analysis does not perform RCA)
- [ ] If sibling artifact content was used, it is cited by artifact name and `evidence_ref` only

### Output completeness
- [ ] All Required output sections from SKILL.md are present
- [ ] All primary row fields are present; missing values use `unable_to_measure` or `unknown` + reason
- [ ] `readiness` value is consistent with evidence quality and section completeness
- [ ] `evidence_profile` matches the actual signal families present

### Downstream handoff
- [ ] `downstream_handoff` is present and machine-readable
- [ ] Each handoff entry specifies `target`, `handoff_type`, `summary`, and `confidence`
- [ ] `missing_evidence` and `next_best_checks` are non-empty when readiness is partial or draft

### Self-check
- [ ] All V2.5.0 common self-check items from `references/ops-runtime-shared-runtime-contract.md` pass
- [ ] Any failed self-check item is recorded with reason and remediation action

## Quality bar summary

A high-quality ops-runtime artifact:
- Is incident-centric, not tool-centric
- Tells a coherent diagnostic story from signal → finding → handoff
- Preserves all uncertainty explicitly (confidence labels, conflicting signals, missing evidence)
- Is machine-consumable by the next skill in any combination path
- Can be audited post-incident without additional context from the analyst


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-ROOTCAUS-051 | `causal_chain` or `hypothesis_ranking` present | key exists | `self_check.warnings: ["SCR-ROOTCAUS-051: no causal chain or hypothesis present"]` |
| SCR-ROOTCAUS-052 | Top hypothesis has `confidence` ∈ {high, medium, low, speculative} | enum check | `self_check.warnings: ["SCR-ROOTCAUS-052: top hypothesis missing confidence"]` |
| SCR-ROOTCAUS-053 | `quick_triage` mode → `full_analysis_mode` declared | conditional | `self_check.failed_rules: ["SCR-ROOTCAUS-053: quick_triage without full_analysis_mode"]` |
| SCR-ROOTCAUS-054 | When `readiness: red`: `adversarial_detection.injection_attempt_detected` declared | conditional | `self_check.failed_rules: ["SCR-ROOTCAUS-054: red state without injection_detected field"]` |
| SCR-ROOTCAUS-055 | `prevention_recommendations` ≥ 1 when `confidence` ≥ medium | conditional count | `self_check.warnings: ["SCR-ROOTCAUS-055: medium+ confidence without prevention recommendations"]` |