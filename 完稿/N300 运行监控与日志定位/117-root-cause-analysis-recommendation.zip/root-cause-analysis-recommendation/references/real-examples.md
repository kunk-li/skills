# real-examples

These examples illustrate how to produce this skill's artifact under different evidence conditions. Use them as output calibration references — not as templates to copy verbatim.

## Example 1: Minimum viable input (readiness: partial)

**Scenario:** Single metric spike, no logs or traces available.

**Input given:**
- Service: `payment-service`
- Signal: `http_error_rate` jumped from 0.3% to 12% at 14:32 UTC
- No trace data, no log access

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  evidence_profile: metrics_only
  incident_id: TEMP-ops-runtime-20240315-payment-metric
evidence_profile:
  missing_evidence:
    - structured logs for error classification
    - trace ids to correlate request path
  next_best_checks:
    - pull error log sample from payment-service for 14:30–14:40 UTC
    - check recent deployment or config change in this window
```

**Key calibration:** Output must not invent error causes. State "elevated error rate observed; cause undetermined pending log/trace evidence."

---

## Example 2: Rich multi-signal input (readiness: ready)

**Scenario:** Alert storm with logs and partial traces available.

**Input given:**
- Alert: `payment-service SLO burn rate 14× budget`
- Log sample: 3,200 lines of `NullPointerException` in `PaymentProcessor.java:142`
- Trace: 2 trace IDs showing 8s p99 at `db-connection-pool`
- Recent change: DB connection pool size reduced from 100→20 at 14:15 UTC

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  evidence_profile: multi_signal
recommended_finding:
  hypothesis_id: H1
  statement: "Connection pool exhaustion caused by config change at 14:15 UTC"
  confidence: high
  supporting_evidence_refs: [alert-001, log-finding-3, trace-T1, trace-T2]
  contradicting_evidence_refs: []
```

**Key calibration:** Confidence "high" requires at least 2 corroborating signal families AND a plausible causal mechanism.

---

## Example 3: Conflicting evidence (readiness: partial)

**Scenario:** Logs point to DB; metrics show CPU spike on app tier.

**Expected output shape:**
```yaml
hypothesis_testing:
  - hypothesis_id: H1
    statement: "DB connection exhaustion is root cause"
    confidence: medium
    supporting_evidence_refs: [log-finding-1]
    contradicting_evidence_refs: [metric-cpu-001]
    status: unresolved — conflicting signals
  - hypothesis_id: H2
    statement: "App-tier CPU spike caused downstream DB timeouts"
    confidence: low
    supporting_evidence_refs: [metric-cpu-001]
    contradicting_evidence_refs: [log-finding-1]
    status: unresolved
recommended_root_cause:
  statement: "Insufficient evidence to choose between H1 and H2"
  next_best_checks:
    - capture JVM thread dump from app tier during next occurrence
    - check DB slow query log for same window
```

**Key calibration:** Never collapse conflicting hypotheses into a single confident conclusion. Keep both visible.

---

## Example 4: Change-correlated failure — five-why chain

**Scenario:** Checkout service started returning 503s exactly 2 minutes after a config deploy. Change analysis confirms correlation.

**Input given:**
- Alert: checkout-service 503 rate 18% starting 15:44 UTC
- Change log: `CHECKOUT_TIMEOUT_MS` env var changed from `5000` to `500` at 15:42 UTC (operator typo)
- Logs: `ReadTimeout: exceeded 500ms connecting to inventory-service` (inventory p99 is typically 800ms)
- No prior incident history for this error signature

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  selected_mode: change_correlation
  evidence_profile:
    confirmed: [alert, logs, change_log]
    missing_evidence: []
incident_id: INC-2026-0521-checkout-timeout
five_why_chain:
  - why_1: "checkout-service returns 503 to users"
    answer: "ReadTimeout thrown when inventory-service call exceeds 500ms"
  - why_2: "Timeout threshold is 500ms"
    answer: "CHECKOUT_TIMEOUT_MS was changed from 5000 to 500 at 15:42 UTC (operator typo)"
  - why_3: "Inventory-service p99 latency is 800ms"
    answer: "Normal operating range; baseline unchanged"
  - why_4: "Why was the typo not caught before deploy?"
    answer: "Config change went through without unit validation of numeric range"
  - why_5: "Why is there no validation for CHECKOUT_TIMEOUT_MS?"
    answer: "Config schema does not enforce minimum/maximum for timeout values"
hypothesis_ranking:
  - hypothesis_id: H1
    statement: "Operator typo in CHECKOUT_TIMEOUT_MS (5000→500) caused timeout threshold below inventory p99"
    confidence: high
    supporting_evidence_refs: [change_log, log-timeout-pattern]
    classification: change_regression
    systemic: false
    prevention_hint: "Add config value range validation for timeout parameters"
recommended_root_cause:
  hypothesis_id: H1
  confidence: high
  immediate_action: "Revert CHECKOUT_TIMEOUT_MS to 5000 via config rollback (no restart required)"
  downstream_handoff_to: remediation-plan-recommendation
self_check:
  passed: true
```

**Key calibration:** Change-correlated failures warrant a five-why chain even when the proximate cause is obvious. Surface the systemic gap (missing validation) at why_4 or why_5.

---

## Example 5: Sporadic vs systemic classification

**Scenario:** Memory leak in auth-service surfaces only during high-traffic windows (> 5000 req/min). Three incidents in 30 days, same pattern each time.

**Input given:**
- Incident history: 3 incidents (INC-001, INC-012, INC-021) — all Monday mornings 09:00–10:00 JST
- Pattern: auth-service heap usage climbs linearly, OOMKilled at ~1.8GB
- Traffic: all incidents coincide with batch job triggering 6000 req/min spikes
- Code: no recent changes in auth-service for 45 days

**Key calibration:**
```yaml
hypothesis_ranking:
  - hypothesis_id: H1
    statement: "Memory leak in auth-service session cache — unbounded growth under high concurrency"
    confidence: medium
    classification: systemic_latent
    systemic: true
    recurrence_evidence:
      incident_ids: [INC-001, INC-012, INC-021]
      pattern: "Linear heap growth during traffic > 5000 req/min; no growth at normal load"
    supporting_evidence_refs: [incident_history, heap_trend]
    prevention_hint: "Add max_size cap on session cache; add heap usage SLO alert before OOM threshold"
  - hypothesis_id: H2
    statement: "Batch job load pattern is the trigger — not a code defect"
    confidence: low
    supporting_evidence_refs: [traffic_correlation]
    contradicting_evidence_refs: [no_heap_growth_at_normal_load]
    status: unlikely — load is a trigger condition, not root cause
recommended_root_cause:
  hypothesis_id: H1
  confidence: medium
  note: "Systemic latent defect — requires heap profiler run during high-traffic window to confirm session cache as the source. Confidence cannot reach high without profiler evidence."
  next_best_checks:
    - "Attach heap profiler to auth-service replica during next Monday batch window"
    - "Check session cache implementation for missing eviction policy"
  downstream_handoff_to: root-cause-analysis-recommendation  # escalate to SRE for profiler access
```

**Key calibration:** Classify `systemic: true` when the same pattern recurs across 3+ incidents. Never promote `confidence: high` without the confirming profiler evidence — state the gap explicitly.


---

## Scenario calibration
See `references/real-examples.md` for annotated scenarios covering green (full evidence), amber (partial evidence with degradation), and red (hard-blocker) paths.

For output field definitions, see `references/field-contract.md`.
For quality-gate rules, see `references/quality-checklist.md`.
For failure-mode handling, see `references/failure-modes.md`.
For shared ops-runtime execution contract, see `references/ops-runtime-shared-contract.md`.