---
name: root-cause-analysis-recommendation
description: recommend likely root causes for n300 incidents. use when bug symptoms, logs, metrics, traces, changes, clusters, or frequent errors need evidence chained hypotheses, five whys, change analysis, systemic versus sporadic classification, and prevention oriented handoff. produce 根因定位建议.md without pretending uncertainty is certainty.
---
# root-cause-analysis-recommendation

## Purpose
Use this skill in the N300 runtime monitoring and incident-diagnosis node to produce `根因定位建议.md`. The skill is standalone: it can work with the minimum evidence listed below, and it becomes stronger when combined through the shared N300 contract.

## V2.5.0 optimization note
This version uses `references/n300-shared-runtime-contract.md` as the common source for execution workflow, input handling, self-check, incident id rules, evidence references, downstream handoff schema, and combination paths. Keep this SKILL.md focused on the skill-specific boundary, modes, minimum inputs, output sections, and consumers.

## V2.5.0 encapsulation baseline
This release keeps one contract version across SKILL.md metadata, output-contract.yaml, and references/n300-shared-runtime-contract.md. The skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside each skill plus the artifacts exchanged through downstream_handoff.

## Scope boundary
- Own: evidence chained root cause hypothesis and recommendation.
- Artifact target: `根因定位建议.md`.
- Boundary: recommend root-cause hypotheses and evidence strength; do not own hotfix execution, customer comms, or final incident closure.
- Do not perform N310 remediation execution or N320 postmortem authorship unless explicitly asked to create a handoff draft.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `incident_id`, and `contract_version` before the main findings.

Allowed modes:
- `automated_hypothesis`
- `five_why_guided`
- `historical_match`
- `methodology_selection`

## Standalone minimum viable input
This skill can run with only:
- one incident symptom or bug analysis
- one supporting or contradicting evidence source
- time window or recent change context when available

When evidence is partial, keep the output structure stable, lower `readiness`, and list missing evidence in `downstream_handoff.missing_evidence`.


## Standalone and composition role
```yaml
standalone_guarantee: "Recommend evidence-chained root-cause hypotheses from one symptom plus evidence while explicitly preserving uncertainty and evidence gaps."
composition_role: "evidence_chained_rca"
composition_leverage: "Synthesizes sibling outputs into accepted/rejected hypotheses, five-whys, systemic/sporadic classification, prevention actions, and N310/N320 handoff."
best_combines_with: ["N310", "N320", "impact-scope-analysis", "N330/N390"]
standalone_readiness_floor: partial
composition_join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - evidence_refs
```

When this skill is run alone, produce `根因定位建议.md` without waiting for sibling artifacts. When it is run in a composed N300 path, consume earlier artifacts only through `downstream_handoff` and `evidence_refs`, then emit a stronger handoff for the next skill.

## Input handling
Follow `V2.5.0 common input handling` in `references/n300-shared-runtime-contract.md`. Use optional evidence only to strengthen this skill's own artifact, not to perform sibling-skill work.
## Execution workflow
Follow `V2.5.0 common execution workflow` in `references/n300-shared-runtime-contract.md`, then apply the skill-specific required sections and design rules below.
## Required output sections
Every output must include:
- `metadata`
- `incident_overview`
- `methodology_used`
- `evidence_chain`
- `hypothesis_testing`
- `recommended_root_cause`
- `systemic_vs_sporadic`
- `containment_vs_prevention`
- `evidence_gaps[]`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `contract_version: n300-runtime-v2.5.0`
- `workflow_node: N300`
- `node_artifact_target: 根因定位建议.md`
- `function_bias: evidence_chained_root_cause_hypothesis_and_recommendation`
- `stage_position: operations_runtime.monitoring_and_diagnosis.root_cause_analysis`
- `incident_id`
- `selected_mode`
- `readiness`
- `evidence_profile`
- `tool_collaboration_mode`

Primary rows or structured entries must preserve:
- `hypothesis_id`
- `hypothesis_statement`
- `supporting_evidence_refs`
- `contradicting_evidence_refs`
- `confidence`
- `methodology`
- `status`
- `additional_investigation_needed`

## Downstream handoff contract
Use the shared schema in `references/n300-shared-runtime-contract.md`. For this skill, preferred consumers are:

```yaml
downstream_consumers:
  - target: N310
    summary: containment versus prevention recommendations and confidence/risk notes for remediation planning
  - target: N320
    summary: evidence chain, five-whys, counterfactuals, and systemic classification for postmortem
  - target: impact-scope-analysis
    summary: root cause and propagation mechanism if scope refinement is needed
  - target: N330/N390
    summary: knowledge capture, playbook updates, and governance gaps
```

## Design rules
- every accepted hypothesis must include supporting and contradicting evidence.
- state methodology used rather than silently applying one reasoning style.
- classify systemic versus sporadic when evidence allows.
- separate immediate cause, proximate cause, and root cause.
- Always preserve source time windows, source systems, and evidence references.
- Distinguish observed facts from hypotheses.
- Keep sensitive raw data out of final artifacts.

## Self-check
Run `V2.5.0 common self-check` from `references/n300-shared-runtime-contract.md` and additionally confirm this skill's artifact target, boundary, modes, and `output-contract.yaml` fields are satisfied.
## Reference files
- `references/n300-shared-runtime-contract.md`
- `references/output-contract.yaml`
- `references/rca-evidence-chain.md`
