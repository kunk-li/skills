---
name: frequent-error-summary
description: summarize frequent runtime errors for n300 incidents or review windows. use after logs or anomaly clusters exist to rank known error signatures by count, trend, severity, business weight, recurrence, and fix roi. produce 高频报错摘要.md as a runtime evidence package for rca and n005 feedback. do not discover new anomaly clusters.
---
# frequent-error-summary

## Purpose
Use this skill in the N300 runtime monitoring and incident-diagnosis node to produce `高频报错摘要.md`. The skill is standalone: it can work with the minimum evidence listed below, and it becomes stronger when combined through the shared N300 contract.

## V2.5.0 optimization note
This version uses `references/n300-shared-runtime-contract.md` as the common source for execution workflow, input handling, self-check, incident id rules, evidence references, downstream handoff schema, and combination paths. Keep this SKILL.md focused on the skill-specific boundary, modes, minimum inputs, output sections, and consumers.

## V2.5.0 encapsulation baseline
This release keeps one contract version across SKILL.md metadata, output-contract.yaml, and references/n300-shared-runtime-contract.md. The skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside each skill plus the artifacts exchanged through downstream_handoff.

## Scope boundary
- Own: recurring error ranking trend and cost summary.
- Artifact target: `高频报错摘要.md`.
- Boundary: rank recurring known signatures and trends; do not perform initial clustering, root-cause proof, or demand mining for N005.
- Do not perform N310 remediation execution or N320 postmortem authorship unless explicitly asked to create a handoff draft.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `incident_id`, and `contract_version` before the main findings.

Allowed modes:
- `raw_frequency`
- `weighted`
- `trend_detect`
- `n005_feedback_pack`

## Standalone minimum viable input
This skill can run with only:
- normalized error signature or log findings
- reporting window such as last hour, 24h, 7d, or 30d
- counts or queryable source for counts

When evidence is partial, keep the output structure stable, lower `readiness`, and list missing evidence in `downstream_handoff.missing_evidence`.


## Standalone and composition role
```yaml
standalone_guarantee: "Rank known or discovered error signatures over a window by count, trend, severity, business weight, recurrence, and fix ROI without discovering new clusters."
composition_role: "recurrence_ranker"
composition_leverage: "Turns event history into prioritization evidence; consumes 115 clusters when available and feeds RCA, N005 production signal aggregation, planning, N310, and N320."
best_combines_with: ["root-cause-analysis-recommendation", "N005", "N180/N350", "N310", "N320"]
standalone_readiness_floor: partial
composition_join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - evidence_refs
```

When this skill is run alone, produce `高频报错摘要.md` without waiting for sibling artifacts. When it is run in a composed N300 path, consume earlier artifacts only through `downstream_handoff` and `evidence_refs`, then emit a stronger handoff for the next skill.

## Input handling
Follow `V2.5.0 common input handling` in `references/n300-shared-runtime-contract.md`. Use optional evidence only to strengthen this skill's own artifact, not to perform sibling-skill work.
## Execution workflow
Follow `V2.5.0 common execution workflow` in `references/n300-shared-runtime-contract.md`, then apply the skill-specific required sections and design rules below.
## Required output sections
Every output must include:
- `metadata`
- `incident_overview`
- `reporting_window`
- `top_errors[]`
- `trend_analysis`
- `weighted_ranking`
- `fix_attention_candidates[]`
- `n005_feedback_handoff`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `contract_version: n300-runtime-v2.5.0`
- `workflow_node: N300`
- `node_artifact_target: 高频报错摘要.md`
- `function_bias: recurring_error_ranking_trend_and_cost_summary`
- `stage_position: operations_runtime.monitoring_and_diagnosis.frequent_error_summary`
- `incident_id`
- `selected_mode`
- `readiness`
- `evidence_profile`
- `tool_collaboration_mode`

Primary rows or structured entries must preserve:
- `rank`
- `error_signature`
- `source_cluster_id`
- `raw_count`
- `rate`
- `trend`
- `severity_weight`
- `business_weight`
- `weighted_score`
- `affected_services`
- `recommended_next_owner`

## Downstream handoff contract
Use the shared schema in `references/n300-shared-runtime-contract.md`. For this skill, preferred consumers are:

```yaml
downstream_consumers:
  - target: root-cause-analysis-recommendation
    summary: top recurring signatures and cost/severity context for deeper RCA
  - target: N005 production signal aggregation
    summary: high-frequency runtime evidence pack only, not final data-driven requirement decisions
  - target: N180/N350 planning
    summary: fix attention candidates and weighted cost signals for backlog discussions
  - target: N320
    summary: recurrence trend and unresolved top errors for postmortem learning
```

## Design rules
- require a reporting window before ranking.
- separate raw_count ranking from weighted_score ranking.
- reference source_cluster_id when input comes from 115, but do not invent clusters.
- keep N005 handoff as evidence and recommendation inputs; N005 owns feedback aggregation and requirement mining.
- Always preserve source time windows, source systems, and evidence references.
- Distinguish observed facts from hypotheses.
- Keep sensitive raw data out of final artifacts.

## Self-check
Run `V2.5.0 common self-check` from `references/n300-shared-runtime-contract.md` and additionally confirm this skill's artifact target, boundary, modes, and `output-contract.yaml` fields are satisfied.
## Reference files
- `references/n300-shared-runtime-contract.md`
- `references/output-contract.yaml`
- `references/frequency-weighting-model.md`
