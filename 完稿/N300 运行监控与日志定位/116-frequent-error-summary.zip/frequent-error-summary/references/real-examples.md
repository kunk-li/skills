# real-examples

These examples illustrate how to produce this skill's artifact under different evidence conditions. Use them as output calibration references — not as templates to copy verbatim.

## Example 1: Minimum viable input (readiness: partial)

**Scenario:** Single metric spike, no logs or traces available.

**Input given:**
- Service: `payment-service`
- Signal: `http_error_rate` jumped from 0.3% to 12% at 14:32 UTC
- No trace data, no log access

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  evidence_profile: metrics_only
  incident_id: TEMP-ops-runtime-20240315-payment-metric
evidence_profile:
  missing_evidence:
    - structured logs for error classification
    - trace ids to correlate request path
  next_best_checks:
    - pull error log sample from payment-service for 14:30–14:40 UTC
    - check recent deployment or config change in this window
```

**Key calibration:** Output must not invent error causes. State "elevated error rate observed; cause undetermined pending log/trace evidence."

---

## Example 2: Rich multi-signal input (readiness: ready)

**Scenario:** Alert storm with logs and partial traces available.

**Input given:**
- Alert: `payment-service SLO burn rate 14× budget`
- Log sample: 3,200 lines of `NullPointerException` in `PaymentProcessor.java:142`
- Trace: 2 trace IDs showing 8s p99 at `db-connection-pool`
- Recent change: DB connection pool size reduced from 100→20 at 14:15 UTC

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  evidence_profile: multi_signal
recommended_finding:
  hypothesis_id: H1
  statement: "Connection pool exhaustion caused by config change at 14:15 UTC"
  confidence: high
  supporting_evidence_refs: [alert-001, log-finding-3, trace-T1, trace-T2]
  contradicting_evidence_refs: []
```

**Key calibration:** Confidence "high" requires at least 2 corroborating signal families AND a plausible causal mechanism.

---

## Example 3: Conflicting evidence (readiness: partial)

**Scenario:** Logs point to DB; metrics show CPU spike on app tier.

**Expected output shape:**
```yaml
hypothesis_testing:
  - hypothesis_id: H1
    statement: "DB connection exhaustion is root cause"
    confidence: medium
    supporting_evidence_refs: [log-finding-1]
    contradicting_evidence_refs: [metric-cpu-001]
    status: unresolved — conflicting signals
  - hypothesis_id: H2
    statement: "App-tier CPU spike caused downstream DB timeouts"
    confidence: low
    supporting_evidence_refs: [metric-cpu-001]
    contradicting_evidence_refs: [log-finding-1]
    status: unresolved
recommended_root_cause:
  statement: "Insufficient evidence to choose between H1 and H2"
  next_best_checks:
    - capture JVM thread dump from app tier during next occurrence
    - check DB slow query log for same window
```

**Key calibration:** Never collapse conflicting hypotheses into a single confident conclusion. Keep both visible.

---

## Example 4: fix_roi quantification — three approaches

**Scenario:** Three recurring errors ranked by frequency. ROI must be quantified for each.

```yaml
top_errors:
  - rank: 1
    error_signature: "NullPointerException at PaymentProcessor.java:142"
    count: 3847
    trend_direction: increasing
    severity_weight: critical
    fix_roi_estimate:
      method: "error_count × avg_resolution_time × engineer_hourly_cost"
      calculation: "3847 × 0.5h × $150/h = $288,525/month"
      confidence: medium
      assumption: "avg resolution time per occurrence = 30min"
    confidence: high
    source_ref: "log-query-SQ-001"
  - rank: 2
    error_signature: "ConnectionTimeoutException at DatabasePool.java:89"
    count: 1203
    trend_direction: stable
    severity_weight: high
    fix_roi_estimate:
      method: "error_count × SLO_budget_consumed × budget_hourly_value"
      calculation: "1203 errors × 0.05% SLO × $5000/h SLO value = $3,007/month"
      confidence: low
      assumption: "SLO value estimated from revenue impact"
    confidence: high
  - rank: 3
    error_signature: "OutOfMemoryError in ReportGenerator"
    count: 47
    trend_direction: decreasing
    severity_weight: medium
    fix_roi_estimate:
      method: "incident_count × avg_MTTR × engineer_hourly_cost"
      calculation: "47 × 2h × $150/h = $14,100/month"
      confidence: medium
    confidence: medium
```

**Key calibration:** `fix_roi_estimate` is required for top-3 items. Use whichever of the three methods has available inputs. Always declare the `method` and `assumption`. Never omit or use vague language like "high ROI" without a number.

---

## Example 5: ops_sprint_retrospective mode — 30-day error backlog

**Scenario:** SRE team wants to prioritize error fixes for the next sprint. 30-day window, 8 services.

```yaml
metadata:
  readiness: ready
  selected_mode: raw_frequency
  reporting_window: 30d
  services: [payment-service, auth-service, notification-service, user-service,
             order-service, inventory-service, search-service, recommendation-engine]
top_errors:
  - rank: 1
    error_signature: "ConnectionTimeoutException at DatabasePool.java:89"
    service: payment-service
    count: 18420
    trend_direction: increasing
    severity_weight: critical
    fix_roi_estimate:
      calculation: "18420 × 2min avg_resolution_time × $2.50/min_oncall_cost = $92,100/month"
      confidence: medium
    confidence: high
    source_ref: "log-query-SQ-prod-30d"
  - rank: 2
    error_signature: "NullPointerException at UserRepository.java:142"
    service: user-service
    count: 4821
    trend_direction: stable
    severity_weight: high
    fix_roi_estimate:
      calculation: "4821 × 0.5h × $150/h_engineer = $361,575/year ($30,131/month)"
      confidence: low
      assumption: "0.5h engineer time per occurrence — likely overestimate; many auto-resolve"
    confidence: high
  - rank: 3
    error_signature: "OutOfMemoryError in RecommendationBatchJob"
    service: recommendation-engine
    count: 47
    trend_direction: decreasing
    severity_weight: medium
    fix_roi_estimate:
      calculation: "47 × 3h × $150/h = $21,150/month (incident MTTR)"
      confidence: medium
    confidence: medium
sprint_prioritization:
  p0_this_sprint: [rank-1]    # ConnectionTimeout — increasing trend, critical severity
  p1_next_sprint: [rank-2]    # NullPointerException — stable, defer to validate count
  p2_backlog: [rank-3]        # OOM — decreasing, monitor
  rationale: "Rank-1 is increasing trend + critical severity. Ranks 2-3 are stable/decreasing; defer."
downstream_handoff:
  to_skill: root-cause-analysis-recommendation
  primary_focus: "rank-1 ConnectionTimeoutException"
  secondary_focus: "rank-2 NullPointerException if rank-1 is resolved in sprint"
self_check:
  passed: true
```

**Key calibration:** Sprint retrospective mode adds `sprint_prioritization` section with explicit P0/P1/P2 assignments and rationale. ROI calculations should use 3 different methods for the top-3 items to show range of estimation approaches.


---

## Scenario calibration
See `references/real-examples.md` for annotated scenarios covering green (full evidence), amber (partial evidence with degradation), and red (hard-blocker) paths.

For output field definitions, see `references/field-contract.md`.
For quality-gate rules, see `references/quality-checklist.md`.
For failure-mode handling, see `references/failure-modes.md`.
For shared ops-runtime execution contract, see `references/ops-runtime-shared-contract.md`.