# cross-skill-orchestration

Describes how the nine ops-runtime skills collaborate in multi-signal incident diagnosis.

## Canonical combination paths

### Alert-first (most common)
```
alert-attribution
  → monitoring-metric-interpretation  (metric anomaly confirmation)
  → log-analysis                       (log evidence gathering)
  → trace-call-chain-analysis          (call path reconstruction)
  → bug-analysis                       (fast symptom triage)
  → root-cause-analysis-recommendation (evidence-chained RCA)
  → impact-scope-analysis              (blast radius quantification)
```

### Metric-first
```
monitoring-metric-interpretation
  → alert-attribution        (alert dedup and routing)
  → trace-call-chain-analysis (latency/error path drilldown)
  → impact-scope-analysis     (SLO burn → user impact)
  → root-cause-analysis-recommendation
```

### Log-first
```
log-analysis
  → anomaly-clustering        (pattern deduplication)
  → frequent-error-summary    (error ranking)
  → bug-analysis              (triage framing)
  → root-cause-analysis-recommendation
```

## Join keys for composition
All ops-runtime skills share these composition join keys:
- `incident_id` — primary correlation key
- `source_time_window` — time range anchor
- `service_scope` — affected service list
- `evidence_refs` — reference IDs passed between skills
- `contract_version: ops-runtime-runtime-v2.5.0` — version guard

## Composition rules
1. Later skills cite earlier artifacts by `artifact name + evidence_ref`, never by re-running the same analysis.
2. `incident_id` must remain stable across all skills in a single incident. Only `alert-attribution` may create or normalize a new incident_id.
3. Skills emit `downstream_handoff` records that declare `handoff_type`, `required_fields`, `evidence_refs`, `confidence`, and `next_best_checks`.
4. When two skills contradict each other (e.g., log-analysis says service A is healthy, metrics say it is degraded), both findings remain visible with `conflicting` confidence labels — do not suppress contradictions.
5. Circuit breakers are skill-local. A skill that triggers its circuit breaker must emit `exception.ops-runtime.skill_blocked.v2.5.0` and hand off to the incident commander, not to the next ops-runtime skill in the chain.

## Refresh triggers
- If `alert-attribution` re-classifies the root alert, emit `downstream_handoff.refresh_triggers: [monitoring-metric-interpretation, log-analysis]` so those skills can re-consume updated `incident_id` and `source_time_window`.
- If `anomaly-clustering` merges or splits clusters, emit `downstream_handoff.refresh_triggers: [frequent-error-summary, root-cause-analysis-recommendation]`.


---

## Boundary comparison table — frequent-error-summary precise

| Dimension | frequent-error-summary | log-analysis | bug-analysis | root-cause-analysis-recommendation |
|---|---|---|---|---|
| **Primary question** | "WHICH errors repeat most and cost most?" | "WHAT does this log show?" | "What is this specific bug?" | "WHY did the incident happen?" |
| **Input** | Error streams, error frequency tables, log bundles with pattern counts | Raw logs, log files, query results | Single bug report / incident symptom | All evidence types |
| **Output** | Ranked error patterns: count, frequency, error_budget_burn, recurrence | Error timeline, novel events, parsed patterns | Five-element triage + next-step decision | Causal chain + hypotheses + prevention |
| **Timing** | Review windows, sprint planning, post-incident analysis | T+0 (real-time during incident) | T+0 (immediate triage) | Parallel with response |
| **Owns** | Error frequency ranking, error budget burn per pattern, recurrence trend, prioritization advice | Log structure, timeline, novel event detection | Bug classification, fast hypothesis, decision | Root cause chain, five-why, prevention |
| **Does not own** | Root cause analysis (→119) · Impact quantification (→116) · Real-time triage (→118) | Error ranking by frequency (→117) · Bug triage (→118) | Frequency across patterns (→117) · Root cause depth (→119) | Error frequency (→117) · Impact numbers (→116) |

---

## Boundary: frequent-error-summary vs anomaly-clustering (116 vs 115)

Use **this skill** when:
- You have **normalized signatures** (named patterns, known error codes, cluster ids)
- The goal is **ranking by count, trend, severity weight, and fix ROI** over a defined window (24h–30d)
- The cluster discovery step is already done (by 115 or by existing monitoring queries)
- The consumer needs **prioritization evidence** for RCA, backlog planning, or feedback feedback

Use **anomaly-clustering** when:
- Events are raw and noisy with no pre-established signature vocabulary
- You are working within a **live incident window** and need deduplication first
- You need **novelty flags** (new vs known vs likely noise)

**Trigger rule:** If the user provides a raw log/metric dump with no named patterns → 115 first. If the user provides a named error list, query results, or cluster_ids → 116 directly.



---

## Composition: 116 re-ranking trigger after 115 update
When `source_cluster_id` values from `anomaly-clustering` are updated (a second clustering pass produces new or merged clusters), 116 must re-rank if:
- Any `source_cluster_id` in the current `top_errors[]` has been **merged, split, or retired** by the new 115 output
- Detect via: `115.downstream_handoff.refresh_triggers contains frequent-error-summary`

Re-ranking behavior:
```yaml
rerank_trigger:
  condition: "115 emits downstream_handoff.refresh_triggers: [frequent-error-summary]"
  action: re-run weighted_ranking with updated cluster_ids
  emit: downstream_handoff.refresh_triggers: [root-cause-analysis-recommendation, feedback]
  note: "Consumers of 116 rankings must also re-consume after re-rank"
```

