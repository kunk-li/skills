# frequency weighting model

## Windows
- `last_hour`: incident hot path
- `last_24h`: short operational trend
- `last_7d`: weekly recurrence
- `last_30d`: backlog and review planning

## Weighted score
Use:
`weighted_score = raw_count * business_weight * severity_weight`

When available, include trend multiplier separately instead of hiding it in the base score.

## Boundary with anomaly-clustering
Input may include `source_cluster_id` from 115. This skill ranks and explains frequency; it does not discover new clusters.

## feedback handoff
The output can feed feedback as `runtime_frequent_error_signal`, but feedback owns production signal aggregation and data-driven requirement mining.
