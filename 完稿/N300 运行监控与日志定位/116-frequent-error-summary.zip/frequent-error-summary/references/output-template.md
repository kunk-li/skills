# output-template

Use this template as the structural scaffold for producing this skill's artifact. Fill each section with evidence-derived content; never leave required fields empty — use `unable_to_measure`, `unknown`, or `needs_evidence` with a reason instead.

## Top-level structure

```markdown
---
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  node_artifact_target: <artifact-target>
  function_bias: <this-skill-function-bias>
  stage_position: <this-skill-stage-position>
  incident_id: <string | TEMP-ops-runtime-<date>-<source>>
  selected_mode: <allowed-mode>
  readiness: draft | partial | ready
  evidence_profile: <profile-value>
  tool_collaboration_mode: <mode>
  source_time_window:
    start: <iso8601 | unknown>
    end: <iso8601 | unknown>
  service_scope: [<service-names>]
---

## incident_overview
> 2–4 sentence plain-language summary of what happened, when, and which services.
> Always write this section even when readiness is partial.

## [skill-specific sections]
> See SKILL.md Required output sections.
> Every primary row must include all required fields.
> Use `unable_to_measure` + reason when data is unavailable.

## downstream_handoff
> Machine-readable handoff entries per the shared contract schema.
> Include missing_evidence and next_best_checks for every handoff item.

## self_check
> Record pass/fail for each shared V2.5.0 self-check item.
> If any item fails, readiness must be partial or draft.
```

## Field fill guidance

| Situation | Required action |
|---|---|
| No `incident_id` exists | Create `TEMP-ops-runtime-<YYYYMMDD>-<source>` and mark `provisional: true` |
| Evidence is partial | Keep all sections; fill with best estimate + confidence label |
| Metric not measurable | Use `unable_to_measure: true` with `reason` field |
| Hypothesis uncertain | Use `confidence: low` and list what would raise it |
| Sensitive data present | Summarize or hash; never include plaintext PII or credentials |

## Readiness decision guide

| Condition | Readiness |
|---|---|
| All required sections complete, evidence multi-signal, self-check passes | `ready` |
| Some evidence missing, assumptions made, but output is actionable | `partial` |
| Critical required fields cannot be filled without more data | `draft` |


---

## Downstream handoff YAML templates

```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: frequent-error-summary
  incident_id: "{incident_id}"
  artifact: 高频报错摘要.md
  handoffs:
    - target: root-cause-analysis-recommendation
      handoff_type: pattern
      summary: "Top-3 errors: NullPointerException (rank-1, fix_roi: high), ConnectionTimeout (rank-2), OutOfMemory (rank-3)"
      required_fields: [error_signature, rank, count, trend_direction, fix_roi_estimate]
      evidence_refs: [LS-001, LS-002, LS-003]
      confidence: high
      missing_evidence: []
      next_best_checks:
        - "Start RCA hypothesis chain from rank-1 error signature"
    - target: anomaly-clustering  # only when running in post-incident review mode
      handoff_type: evidence
      summary: "Normalized error signatures ready for cross-window cluster correlation"
      required_fields: [source_cluster_id, error_signature, reporting_window]
      confidence: medium
      missing_evidence: [raw_event_ids_for_cluster_correlation]
```


---

## Standalone guarantee
This skill runs independently with the minimum evidence listed in this file. Do not refuse output because sibling ops-runtime skills have not been run first. When evidence is absent, declare `readiness: partial` or `readiness: red`, populate all stable output sections with available evidence, and list missing evidence in `downstream_handoff.missing_evidence`.

---

## Output completeness rule
Every artifact from this skill MUST include all of:
- `metadata` with `readiness`, `selected_mode`, `evidence_profile`
- `evidence_profile.confirmed` list ≥ 1 item (or explicit `[]` with missing_evidence explanation)
- `confidence` ∈ {high, medium, low, speculative}
- `downstream_handoff` with ≥ 1 typed `handoff_type` entry
- `self_check.passed` boolean + `self_check.warnings[]` (may be `[]`)
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry
- `emit_event.event_name` matching `produced.ops-runtime.*.v2`

**Hard rule:** `confidence: high` requires `evidence_profile.confirmed` ≥ 3 distinct signal families.

---

## Mode selection

### New: `error_budget_analysis` mode — 错误预算消耗分析
**Trigger:** User asks "how much error budget have we consumed?", "error budget report", or SRE team needs to decide whether to proceed with a release given current error budget.

```yaml
error_budget_analysis:
  slo_target: 99.9  # %
  measurement_window: 30d
  error_budget_total_minutes: 43.2  # (100-99.9)% × 30d × 24h × 60min
  consumed_minutes: 31.7
  remaining_minutes: 11.5
  consumption_pct: 73.4
  burn_rate_last_7d: "2.8×"  # consuming at 2.8× the sustainable rate
  budget_verdict: at_risk
  release_recommendation:
    proceed: false
    reason: "73.4% consumed with 73% of window remaining — budget exhausted early"
    condition: "Reduce burn_rate to ≤1.0× for 7 days before releasing"
  top_budget_consumers:
    - error_pattern: "PaymentTimeoutException at checkout"
      minutes_consumed: 18.2
      pct_of_budget: 42.1
      remediation_priority: P1
  confidence: high
```
**SCR:** `selected_mode: error_budget_analysis` → `error_budget_analysis.error_budget_total_minutes` numeric; `budget_verdict` ∈ {healthy, at_risk, exhausted}.