## Large input handling — skill-specific strategies

### Token budget management
When input is large, allocate processing budget as follows:

```yaml
token_budget:
  p0_signals:     40%   # Always process first: high-severity/novel items
  p1_signals:     30%   # Process after P0 is clear
  p2_summary:     20%   # Group and summarize
  metadata:       10%   # Timestamps, service names, incident_id

budget_rule: "Never spend >10% of token budget on a single signal source before P0 extraction is complete."
```

### Skill-specific sampling strategies

#### For anomaly-clustering (raw event streams)
```yaml
sampling_strategy_anomaly_clustering:
  tier_500_lines: "Process all — build full cluster topology"
  tier_5000_lines:
    step_1: "Extract all events with ERROR/CRITICAL/FATAL severity → full processing"
    step_2: "Sample middle window: first 100 lines per 500-line block → frequency count"
    step_3: "Cluster by error signature; preserve novel patterns even if count=1"
  tier_over_5000:
    filter_template: |
      # Pre-filter command for user to run:
      grep -E "ERROR|CRITICAL|FATAL" /path/to/logs | \
        sort | uniq -c | sort -rn | head -200 > filtered_for_anomaly_clustering.txt
    expected_size_after_filter: "≈200 lines"
```

#### For log-analysis (structured log bundles)
```yaml
sampling_strategy_log_analysis:
  tier_500_lines: "Process all"
  tier_5000_lines:
    step_1: "Extract all ERROR+ lines → full analysis"
    step_2: "Sample INFO lines: 1 per 50 for context"
    step_3: "Preserve all lines with trace_id matching known error traces"
  tier_over_5000:
    filter_template: |
      # Pre-filter for user:
      jq 'select(.level == "ERROR" or .level == "CRITICAL")' \
        /path/to/logs.json > filtered_errors.json
    max_lines_after_filter: 500
```

#### For monitoring-metric-interpretation (metric time series)
```yaml
sampling_strategy_metrics:
  tier_100_metrics: "Analyze all"
  tier_1000_metrics:
    step_1: "Process all metrics with anomaly_direction != stable first"
    step_2: "Summarize stable metrics by service group"
    step_3: "SLO-linked metrics always processed fully regardless of count"
  tier_over_1000:
    filter_template: |
      # Ask user to pre-filter:
      # 1. Provide only metrics with values outside their 7-day p95 range
      # 2. Or group by service and provide the top-5 anomalous per service
```

#### For frequent-error-summary (error signature lists)
```yaml
sampling_strategy_error_summary:
  tier_100_signatures: "Rank all"
  tier_500_signatures:
    step_1: "Rank by count descending"
    step_2: "Fully analyze top-20 by count"
    step_3: "Group remainder by error class; emit class-level summary"
  tier_over_500:
    filter_template: |
      # Pre-aggregation for user:
      awk '{print $NF}' errors.log | sort | uniq -c | sort -rn | head -50
```

### Complete sampling output example
```yaml
# Full artifact snippet when sampling was applied
metadata:
  readiness: partial
evidence_profile:
  input_received:
    raw_lines: 12847
    services: [payment-service, auth-service, notification-service]
    time_window: "2026-05-20T14:00:00Z / 2026-05-20T16:00:00Z"
  sampling_applied: true
  sampling_strategy: "ERROR+ lines fully processed; INFO sampled 1:50; DEBUG excluded"
  p0_coverage:
    lines_fully_processed: 2341     # all ERROR/CRITICAL
    lines_sampled: 211              # INFO 1:50
    lines_excluded: 10295           # DEBUG excluded
  estimated_coverage_pct: 20
  p0_signal_coverage_pct: 100       # all ERROR lines reviewed
  sampling_caveat: "INFO context underrepresented. P0 signals (ERROR+) are fully covered."
  filter_template_for_full_analysis: |
    grep -E 'ERROR|CRITICAL' /path/to/app.log > filtered.log
    # Then re-invoke this skill with filtered.log (estimated: ~2300 lines)
```

### Never rules (hard enforcement)
- NEVER claim `confidence: high` when `estimated_coverage_pct < 60` AND P0 signals not fully covered
- NEVER silently reduce output sections due to large input — always emit all required sections with `unknown` placeholders
- NEVER ask user to "try again with less input" without providing a specific filter template
- ALWAYS emit `filter_template_for_full_analysis` when sampling was applied


---

## Input elasticity — Tier 4 and field-level unlock

### What Tier 4 unlocks

```yaml
tier_4_capabilities:
  requires: [log_bundle_multi_window, error_tracker_export, slo_data, deployment_history]
  unlocks:
    error_budget_per_pattern: confirmed_from_slo_data
    recurrence_correlation: "cross-deployment pattern matching available"
    statistical_significance: "≥ 100 events per pattern for significance testing"
    trend_direction: "week-over-week + rolling 7d confirmed"
    suppression_candidates: "patterns with declining trend can be suppressed"
  confidence: high
  readiness: ready

tier_3_vs_4_distinction:
  tier_3: "frequency ranking available; budget burn estimated from error_rate"
  tier_4: "frequency + budget burn confirmed from SLO data + statistical significance"
```

---

## Input format specification: reporting window
`reporting_window` accepts the following formats. Normalize to ISO 8601 interval internally:

| Input format | Example | Normalization |
|---|---|---|
| ISO 8601 duration | `PT24H`, `P7D`, `PT1H30M` | Use as-is |
| ISO 8601 interval | `2024-01-15T00:00Z/2024-01-16T00:00Z` | Compute duration from interval |
| Natural language (short) | `last 24h`, `last 7 days`, `past hour` | Map to ISO 8601 duration |
| Natural language (relative) | `since yesterday`, `this week`, `last sprint` | Anchor to current UTC timestamp; document anchor in `reporting_window.anchor_note` |
| Epoch ms pair | `{"start": 1716000000000, "end": 1716086400000}` | Convert to ISO 8601 interval |
| Absent | *(no window provided)* | Apply Case A default: `PT24H` with `window_assumption: 24h_default` |

Always emit `reporting_window.normalized_iso8601` in the output regardless of input format.

