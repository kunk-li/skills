---
name: anomaly-clustering
description: cluster raw anomalies for n300 incidents. use when noisy logs, metrics, traces, failed checks, or alerts may represent the same issue and need deduped pattern groups, novelty flags, cluster priority, and investigation hints. produce 异常聚类表.csv. do not rank recurring known errors over long windows; use frequent-error-summary for that.
---
# anomaly-clustering

## Purpose
Use this skill in the N300 runtime monitoring and incident-diagnosis node to produce `异常聚类表.csv`. The skill is standalone: it can work with the minimum evidence listed below, and it becomes stronger when combined through the shared N300 contract.

## V2.5.0 optimization note
This version uses `references/n300-shared-runtime-contract.md` as the common source for execution workflow, input handling, self-check, incident id rules, evidence references, downstream handoff schema, and combination paths. Keep this SKILL.md focused on the skill-specific boundary, modes, minimum inputs, output sections, and consumers.

## V2.5.0 encapsulation baseline
This release keeps one contract version across SKILL.md metadata, output-contract.yaml, and references/n300-shared-runtime-contract.md. The skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside each skill plus the artifacts exchanged through downstream_handoff.

## Scope boundary
- Own: cross-signal anomaly grouping and deduplication.
- Artifact target: `异常聚类表.csv`.
- Boundary: create deduplicated anomaly clusters and novelty context; do not produce long-window top error rankings or backlog ROI.
- Do not perform N310 remediation execution or N320 postmortem authorship unless explicitly asked to create a handoff draft.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `incident_id`, and `contract_version` before the main findings.

Allowed modes:
- `realtime`
- `batch`
- `pattern_learning`
- `novelty_monitoring`

## Standalone minimum viable input
This skill can run with only:
- two or more anomaly events, or one noisy event stream
- event timestamps
- source family such as log, metric, trace, alert, or test

When evidence is partial, keep the output structure stable, lower `readiness`, and list missing evidence in `downstream_handoff.missing_evidence`.


## Standalone and composition role
```yaml
standalone_guarantee: "Cluster a raw anomaly list from logs, metrics, traces, checks, or alerts into deduplicated groups and novelty flags without needing a historical error ranking."
composition_role: "noise_reduction_clusterer"
composition_leverage: "Reduces alert/log noise before ranking or RCA; supplies source_cluster_id, cluster signature, novelty, and priority to frequent-error summary, alert attribution, and RCA."
best_combines_with: ["frequent-error-summary", "root-cause-analysis-recommendation", "alert-attribution", "N320/N330"]
standalone_readiness_floor: partial
composition_join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - evidence_refs
```

When this skill is run alone, produce `异常聚类表.csv` without waiting for sibling artifacts. When it is run in a composed N300 path, consume earlier artifacts only through `downstream_handoff` and `evidence_refs`, then emit a stronger handoff for the next skill.

## Input handling
Follow `V2.5.0 common input handling` in `references/n300-shared-runtime-contract.md`. Use optional evidence only to strengthen this skill's own artifact, not to perform sibling-skill work.
## Execution workflow
Follow `V2.5.0 common execution workflow` in `references/n300-shared-runtime-contract.md`, then apply the skill-specific required sections and design rules below.
## Required output sections
Every output must include:
- `metadata`
- `incident_overview`
- `cluster_summary`
- `anomaly_clusters[]`
- `deduplication`
- `novelty_analysis`
- `priority_scoring`
- `recommended_investigation_steps[]`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `contract_version: n300-runtime-v2.5.0`
- `workflow_node: N300`
- `node_artifact_target: 异常聚类表.csv`
- `function_bias: cross_signal_anomaly_grouping_and_deduplication`
- `stage_position: operations_runtime.monitoring_and_diagnosis.anomaly_clustering`
- `incident_id`
- `selected_mode`
- `readiness`
- `evidence_profile`
- `tool_collaboration_mode`

Primary rows or structured entries must preserve:
- `cluster_id`
- `cluster_signature`
- `source_types`
- `member_count`
- `first_seen`
- `last_seen`
- `novelty`
- `priority_score`
- `priority`
- `representative_evidence_refs`
- `suggested_consumer`

## Downstream handoff contract
Use the shared schema in `references/n300-shared-runtime-contract.md`. For this skill, preferred consumers are:

```yaml
downstream_consumers:
  - target: frequent-error-summary
    summary: cluster_id, normalized signature, counts, and time buckets for recurring error ranking
  - target: root-cause-analysis-recommendation
    summary: cluster signature, novelty, and representative evidence for root-cause hypothesis generation
  - target: alert-attribution
    summary: dedup keys and correlated source events for alert storm reduction
  - target: N320/N330
    summary: novel patterns and observability gaps for learning and documentation
```

## Design rules
- cluster by evidence similarity, time correlation, spatial/service correlation, causal path, user segment, or root-cause hypothesis.
- keep raw anomaly count separate from deduplicated cluster count.
- mark whether a cluster is new, known, recurring, or likely noise.
- do not call a cluster high frequency unless a reporting window ranking has been computed by 116.
- Always preserve source time windows, source systems, and evidence references.
- Distinguish observed facts from hypotheses.
- Keep sensitive raw data out of final artifacts.

## Self-check
Run `V2.5.0 common self-check` from `references/n300-shared-runtime-contract.md` and additionally confirm this skill's artifact target, boundary, modes, and `output-contract.yaml` fields are satisfied.
## Reference files
- `references/n300-shared-runtime-contract.md`
- `references/output-contract.yaml`
- `references/clustering-priority-matrix.md`
