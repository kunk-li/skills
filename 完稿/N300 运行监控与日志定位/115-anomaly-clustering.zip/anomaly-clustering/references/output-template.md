# output-template

Use this template as the structural scaffold for producing this skill's artifact. Fill each section with evidence-derived content; never leave required fields empty — use `unable_to_measure`, `unknown`, or `needs_evidence` with a reason instead.

## Top-level structure

```markdown
---
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  node_artifact_target: <artifact-target>
  function_bias: <this-skill-function-bias>
  stage_position: <this-skill-stage-position>
  incident_id: <string | TEMP-ops-runtime-<date>-<source>>
  selected_mode: <allowed-mode>
  readiness: draft | partial | ready
  evidence_profile: <profile-value>
  tool_collaboration_mode: <mode>
  source_time_window:
    start: <iso8601 | unknown>
    end: <iso8601 | unknown>
  service_scope: [<service-names>]
---

## incident_overview
> 2–4 sentence plain-language summary of what happened, when, and which services.
> Always write this section even when readiness is partial.

## [skill-specific sections]
> See SKILL.md Required output sections.
> Every primary row must include all required fields.
> Use `unable_to_measure` + reason when data is unavailable.

## downstream_handoff
> Machine-readable handoff entries per the shared contract schema.
> Include missing_evidence and next_best_checks for every handoff item.

## self_check
> Record pass/fail for each shared V2.5.0 self-check item.
> If any item fails, readiness must be partial or draft.
```

## Field fill guidance

| Situation | Required action |
|---|---|
| No `incident_id` exists | Create `TEMP-ops-runtime-<YYYYMMDD>-<source>` and mark `provisional: true` |
| Evidence is partial | Keep all sections; fill with best estimate + confidence label |
| Metric not measurable | Use `unable_to_measure: true` with `reason` field |
| Hypothesis uncertain | Use `confidence: low` and list what would raise it |
| Sensitive data present | Summarize or hash; never include plaintext PII or credentials |

## Readiness decision guide

| Condition | Readiness |
|---|---|
| All required sections complete, evidence multi-signal, self-check passes | `ready` |
| Some evidence missing, assumptions made, but output is actionable | `partial` |
| Critical required fields cannot be filled without more data | `draft` |


---

## Downstream handoff YAML templates

### 正常路径：向 frequent-error-summary 和 root-cause-analysis-recommendation 移交
```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: anomaly-clustering
  incident_id: "{incident_id}"
  artifact: 异常聚类表.csv
  handoffs:
    - target: frequent-error-summary
      handoff_type: pattern
      summary: "Top cluster CL-001 has 847 events — candidate for frequency ranking"
      required_fields: [source_cluster_id, representative_event, event_count]
      evidence_refs: [CL-001, CL-002]
      confidence: high
      missing_evidence: []
      next_best_checks:
        - "Run frequent-error-summary with source_cluster_ids from this output"
    - target: root-cause-analysis-recommendation
      handoff_type: hypothesis
      summary: "Novel cluster CL-NOVEL-001 (P0) — no historical baseline, escalate"
      required_fields: [source_cluster_id, novelty, cluster_priority]
      evidence_refs: [CL-NOVEL-001]
      confidence: medium
      missing_evidence: [historical_baseline]
      next_best_checks:
        - "root-cause-analysis: start hypothesis chain from CL-NOVEL-001"
```

### 降级路径：时间窗口超限，仅可部分移交
```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  incident_id: "{incident_id}"
  handoffs:
    - target: root-cause-analysis-recommendation
      handoff_type: gap
      summary: "6h window split into 3 isolated sub-windows — cross-window causality suppressed"
      required_fields: [cluster_id, time_window_isolated]
      confidence: low
      missing_evidence: [cross_window_causal_linkage]
      next_best_checks:
        - "Analyze each 2h window independently with root-cause-analysis-recommendation"
        - "Check if CL-W1-001 and CL-W2-001 share the same root service before merging"
```

### Refresh trigger rule
When `anomaly-clustering` merges or splits clusters after re-analysis:
```yaml
refresh_triggers:
  - skill: frequent-error-summary
    reason: "Cluster topology changed — source_cluster_ids may have shifted"
    action: "Re-run frequent-error-summary with updated source_cluster_ids"
  - skill: root-cause-analysis-recommendation
    reason: "Novel cluster confirmed or retracted — hypothesis chain needs update"
```


---

## Standalone guarantee
This skill runs independently with the minimum evidence listed in this file. Do not refuse output because sibling ops-runtime skills have not been run first. When evidence is absent, declare `readiness: partial` or `readiness: red`, populate all stable output sections with available evidence, and list missing evidence in `downstream_handoff.missing_evidence`.

---

## Mode selection

### New: `temporal_pattern` mode — 时序异常模式分析
**Trigger:** Anomalies have a temporal pattern (e.g., recurring every hour, spike at peak time), or user says "periodic anomaly", "hourly spike", "when does this happen?".

```yaml
temporal_pattern:
  analysis_window: 7d
  pattern_detected:
    type: periodic
    period: 1h
    peak_time: "HH:00 to HH:05 (top of each hour)"
    amplitude: "error_rate spikes from 0.28% to 2.1% every hour"
    first_observed: "2026-05-19T14:00:00Z"
    recurrence_count: 42
  probable_cause: "Hourly batch job triggering DB lock contention"
  pattern_confidence: high
  correlated_signals:
    - signal: batch_job_start_time
      correlation: "batch_job fires at HH:00 — matches spike onset"
  recommended_action: "Stagger batch job start time or add retry logic"
```
**SCR:** `selected_mode: temporal_pattern` → `temporal_pattern.pattern_detected.type` ∈ {periodic, burst, diurnal, random}; `pattern_confidence` declared.