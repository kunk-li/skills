# clustering priority matrix

## Suggested grouping dimensions
- error signature: error type, code, message template, stack prefix
- time correlation: simultaneous or cascading occurrence
- spatial correlation: service, host, region, shard, tenant, feature flag
- causal chain: trace or dependency path
- user segment: tier, region, journey, cohort
- root-cause hypothesis: similar triggering signal

## Suggested algorithms
- logs: template clustering, NLP similarity, fuzzy signature grouping
- metrics: change-point or density-based grouping
- traces: hierarchical similarity by path, span, dependency, error type

## Boundary with frequent-error-summary
`anomaly-clustering` discovers and deduplicates signatures. `frequent-error-summary` ranks known or discovered signatures over a reporting window.
