## Mock input fixture

```yaml
mock_input:
  scenario: "noisy_raw_events"
  content:
    event_count: 47
    time_window: "2h"
    services: [payment-service, auth-service]
  expected_output_shape:
    anomaly_clusters:
      min_entries: 1
    deduplication:
      cross_window_merge_suppressed: false  # within 2h
    self_check:
      passed: true

mock_input_2:
  scenario: "wide_time_window"
  content:
    event_count: 120
    time_window: "6h"
  expected_output_shape:
    metadata:
      readiness: partial
      selected_mode: batch
    deduplication:
      cross_window_merge_suppressed: true
    self_check:
      passed: false
      failed_rules: ["Event window >2h — cross-window causal linkage suppressed"]
```
