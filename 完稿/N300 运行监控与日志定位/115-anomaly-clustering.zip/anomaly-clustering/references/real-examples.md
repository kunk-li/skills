# real-examples

These examples illustrate how to produce this skill's artifact under different evidence conditions. Use them as output calibration references — not as templates to copy verbatim.

## Example 1: Minimum viable input (readiness: partial)

**Scenario:** Single metric spike, no logs or traces available.

**Input given:**
- Service: `payment-service`
- Signal: `http_error_rate` jumped from 0.3% to 12% at 14:32 UTC
- No trace data, no log access

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  evidence_profile: metrics_only
  incident_id: TEMP-ops-runtime-20240315-payment-metric
evidence_profile:
  missing_evidence:
    - structured logs for error classification
    - trace ids to correlate request path
  next_best_checks:
    - pull error log sample from payment-service for 14:30–14:40 UTC
    - check recent deployment or config change in this window
```

**Key calibration:** Output must not invent error causes. State "elevated error rate observed; cause undetermined pending log/trace evidence."

---

## Example 2: Rich multi-signal input (readiness: ready)

**Scenario:** Alert storm with logs and partial traces available.

**Input given:**
- Alert: `payment-service SLO burn rate 14× budget`
- Log sample: 3,200 lines of `NullPointerException` in `PaymentProcessor.java:142`
- Trace: 2 trace IDs showing 8s p99 at `db-connection-pool`
- Recent change: DB connection pool size reduced from 100→20 at 14:15 UTC

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  evidence_profile: multi_signal
recommended_finding:
  hypothesis_id: H1
  statement: "Connection pool exhaustion caused by config change at 14:15 UTC"
  confidence: high
  supporting_evidence_refs: [alert-001, log-finding-3, trace-T1, trace-T2]
  contradicting_evidence_refs: []
```

**Key calibration:** Confidence "high" requires at least 2 corroborating signal families AND a plausible causal mechanism.

---

## Example 3: Conflicting evidence (readiness: partial)

**Scenario:** Logs point to DB; metrics show CPU spike on app tier.

**Expected output shape:**
```yaml
hypothesis_testing:
  - hypothesis_id: H1
    statement: "DB connection exhaustion is root cause"
    confidence: medium
    supporting_evidence_refs: [log-finding-1]
    contradicting_evidence_refs: [metric-cpu-001]
    status: unresolved — conflicting signals
  - hypothesis_id: H2
    statement: "App-tier CPU spike caused downstream DB timeouts"
    confidence: low
    supporting_evidence_refs: [metric-cpu-001]
    contradicting_evidence_refs: [log-finding-1]
    status: unresolved
recommended_root_cause:
  statement: "Insufficient evidence to choose between H1 and H2"
  next_best_checks:
    - capture JVM thread dump from app tier during next occurrence
    - check DB slow query log for same window
```

**Key calibration:** Never collapse conflicting hypotheses into a single confident conclusion. Keep both visible.

---

## Example 4: novelty detection — new error pattern never seen before

**Scenario:** Logs contain an error signature `CIRCUIT_OPEN: downstream-payments-v2` which has no historical record.

**Expected behavior:**
- Flag as `novelty: true` with `novelty_reason: no_historical_baseline`.
- Assign highest cluster priority.
- Do not merge with existing `CIRCUIT_OPEN` clusters unless service scope is identical.

```yaml
anomaly_clusters:
  - cluster_id: CL-NOVEL-001
    representative_event: "CIRCUIT_OPEN: downstream-payments-v2"
    event_count: 14
    novelty: true
    novelty_reason: no_historical_baseline
    cluster_priority: P0
    confidence: medium
    note: "New circuit breaker target not seen in prior 30-day window. Escalate immediately."
downstream_handoff:
  urgency: immediate
  next_best_checks:
    - "Check if downstream-payments-v2 was recently deployed"
    - "Run log-analysis to extract full stack trace for CL-NOVEL-001"
```

**Key calibration:** `novelty: true` + `no_historical_baseline` → always P0. Do not down-prioritize novel clusters even if event count is low.

---

## Example 5: batch mode — post-incident retrospective clustering

**Scenario:** 6-hour incident window needs post-hoc clustering for RCA evidence. Single 2h sub-windows used.

**Expected behavior:**
- Split into three 2h windows: W1 (00–02h), W2 (02–04h), W3 (04–06h).
- Cluster each window independently.
- Note cross-window causal linkage is suppressed; recommend running RCA on each window cluster set separately.

```yaml
metadata:
  readiness: partial
  selected_mode: batch
  note: "6h span exceeds 2h causal linkage threshold. Split into 3 independent windows."
anomaly_clusters:
  - cluster_id: CL-W1-001
    time_window: "00:00–02:00 UTC"
    time_window_isolated: true
  - cluster_id: CL-W2-001
    time_window: "02:00–04:00 UTC"
    time_window_isolated: true
deduplication:
  cross_window_merge_suppressed: true
downstream_handoff:
  next_best_checks:
    - "Run root-cause-analysis-recommendation on W1 cluster set first"
    - "Check if CL-W1-001 and CL-W2-001 share the same root service"
```

**Key calibration:** Post-incident batch mode is valid. Each sub-window cluster is useful for RCA even if causal linkage across windows cannot be established.

---

## Example 6: D2 Tier 1 input — verbal description only

**Scenario:** User says "payment service keeps timing out" — no logs, no traces, no metrics.

```yaml
metadata:
  readiness: partial
  selected_mode: batch
evidence_profile:
  confirmed: [verbal_description]
  missing_evidence: [raw_events, metrics, logs, traces]
  missing_evidence_impact: "Tier 1 input only. Cluster is a speculative placeholder."
anomaly_clusters:
  - cluster_id: CL-TEMP-001
    representative_event: "payment service timeout (verbal description)"
    event_count: unknown
    novelty: unknown
    cluster_priority: P1  # default when no evidence to rank
    confidence: speculative
    note: "Placeholder cluster. Provide raw logs or alert payloads to build real clusters."
downstream_handoff:
  missing_evidence: [raw_events, alert_payload, log_bundle, metric_snapshot]
  next_best_checks:
    - "Provide error logs from payment service for the affected time window"
    - "Or provide alert payload from monitoring system"
self_check:
  passed: false
  failed_rules: ["Tier 1 input only — cluster is speculative placeholder"]
```

**Key calibration:** Even with a single sentence of input, produce a partial artifact with a placeholder cluster. Never refuse. Speculative clusters are explicitly labeled and cannot propagate to downstream skills as confirmed evidence.

---

## Example 4: Cross-service fan-out clustering — one root event, multiple downstream anomalies

**Scenario:** DB connection pool exhaustion in auth-service caused fan-out of 47 anomalous events across 6 dependent services. All events within a 20-minute window.

**Input given:**
- 47 raw events across 6 services: auth-service, payment-service, checkout-service, notification-service, order-service, user-service
- Time window: 14:15–14:35 UTC (20 minutes — within 2h limit)
- Signal families: metrics (CPU, latency), logs (timeout errors), alerts (SLO burns)

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  selected_mode: batch
  evidence_profile:
    confirmed: [metric_events, log_events, alert_events]
    missing_evidence: []
anomaly_clusters:
  - cluster_id: CL-ROOT-001
    cluster_name: "auth-service DB connection pool exhaustion"
    source_cluster_id: CL-ROOT-001
    novelty_flag: true       # not seen in baseline 30d window
    cluster_priority: P0
    event_count: 8
    signal_families: [metric, log, alert]
    representative_event: "auth-service: db_connection_wait_ms > 5000 at 14:15 UTC"
    services_affected: [auth-service]
    causal_hypothesis: "Connection pool exhausted — all downstream auth failures are symptoms"
    confidence: high

  - cluster_id: CL-SYM-002
    cluster_name: "Downstream auth timeout cascade"
    source_cluster_id: CL-ROOT-001    # linked to root cluster
    novelty_flag: false
    cluster_priority: P1
    event_count: 39
    signal_families: [metric, log]
    services_affected: [payment-service, checkout-service, notification-service, order-service, user-service]
    causal_hypothesis: "All 39 events are symptom clusters caused by CL-ROOT-001 (auth timeout propagation)"
    confidence: high

deduplication:
  raw_events_in: 47
  clusters_out: 2
  dedup_ratio: "23.5:1"
  cross_window_merge_suppressed: false
  note: "20-minute window within 2h limit — cross-event causal linkage established"

downstream_handoff:
  to_skill: root-cause-analysis-recommendation
  priority_cluster: CL-ROOT-001
  summary: "1 root cluster (auth DB pool) + 1 symptom cascade cluster (39 events). Investigate CL-ROOT-001 first."
self_check:
  passed: true
```

**Key calibration:** Fan-out anomalies should produce ONE root cluster and ONE (or few) symptom cluster(s). Never create 47 separate clusters for 47 raw events. `dedup_ratio` documents the compression effectiveness.

---

## Example 5: Novelty detection — pattern not seen in 30-day baseline

**Scenario:** New error pattern appears in payment-service: `PaymentGatewayTimeoutException` — never seen in 30-day baseline. 12 occurrences in 10 minutes.

**Input given:**
- 12 error events, all `PaymentGatewayTimeoutException` in `PaymentProcessor.java:287`
- Baseline window: 30 days — zero occurrences of this error class
- Current incident: no other anomaly signals

**Key calibration:**
```yaml
anomaly_clusters:
  - cluster_id: CL-NOVEL-001
    cluster_name: "PaymentGatewayTimeoutException — novel pattern"
    novelty_flag: true
    novelty_basis: "Zero occurrences in 30-day baseline window"
    cluster_priority: P0   # novel + production = automatic P0 escalation
    event_count: 12
    event_rate_per_min: 1.2
    signal_families: [log]
    representative_event: "PaymentProcessor.java:287 — PaymentGatewayTimeoutException"
    investigation_hints:
      - "Check payment gateway API status — external dependency timeout possible"
      - "Check recent changes to PaymentProcessor.java (regression candidate)"
      - "Run trace-call-chain-analysis on a PaymentGatewayTimeoutException trace ID"
    confidence: high    # novelty is confirmed fact; cause is unknown
```

**Key calibration:** Novel patterns always get `cluster_priority: P0` regardless of event count. Distinguish `confidence` on the cluster existence (high — it's a real pattern) from the causal hypothesis (which may be lower confidence).


---

## Scenario calibration
See `references/real-examples.md` for annotated scenarios covering green (full evidence), amber (partial evidence with degradation), and red (hard-blocker) paths.

For output field definitions, see `references/field-contract.md`.
For quality-gate rules, see `references/quality-checklist.md`.
For failure-mode handling, see `references/failure-modes.md`.
For shared ops-runtime execution contract, see `references/ops-runtime-shared-contract.md`.