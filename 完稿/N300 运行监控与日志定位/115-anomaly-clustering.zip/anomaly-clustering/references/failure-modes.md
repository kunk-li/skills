# failure-modes — anomaly-clustering

Common failure modes for `异常聚类表.csv` and how to handle them.

## FM01: No evidence provided — symptom description only
- **Symptom:** Only a text description; no logs, metrics, traces, or structured data.
- **Impact:** All findings are speculative. Confidence ceiling: low.
- **Handling:** Produce artifact with `readiness: partial`, all hypotheses at `confidence: speculative`. List required evidence in `downstream_handoff.missing_evidence`. Do not refuse output.

## FM02: Single signal family — cannot cross-validate
- **Symptom:** Only one evidence type available (e.g., logs only, no metrics or traces).
- **Impact:** Confidence ceiling: low. Cannot confirm or contradict findings.
- **Handling:** Set `evidence_profile.source_family_coverage: single`. Cap all findings at `confidence: low`. Recommend second signal family in `downstream_handoff.next_best_checks`.

## FM03: Timestamps missing or inconsistent timezone
- **Symptom:** Events have no timestamps or mixed timezones.
- **Impact:** Time correlation and time-window normalization unreliable.
- **Handling:** Normalize to UTC; set `timestamp_assumption: utc_assumed` if timezone unknown. Bucket at coarsest granularity. Document under normalization notes.

## FM04: Circuit breaker triggered — skill invoked ≥3 times without resolution
- **Symptom:** `metadata.iter_count >= max_iter` and readiness still `partial`.
- **Impact:** Further regeneration will not resolve the issue without new evidence.
- **Handling:** Stop regeneration. Set `readiness: red`. Emit `exception.ops-runtime.skill_blocked.v2.5.0`. Escalate to incident-commander. Reset only when new `evidence_refs` are provided.

## FM05: Sensitive data (PII / secrets) detected in evidence
- **Symptom:** Raw log lines contain email addresses, passwords, tokens, or PII.
- **Impact:** Cannot include raw data in artifact without violating data handling policy.
- **Handling:** Redact before analysis. Reference by `evidence_ref` id, not raw content. Set `pii_risk: detected` in the relevant finding. Note in `self_check.failed_rules` if redaction is incomplete.

## FM06: Downstream skill unavailable — cannot hand off
- **Symptom:** Target skill in `downstream_handoff` is not reachable or not invoked.
- **Impact:** Composed workflow stalls.
- **Handling:** Emit `downstream_handoff` with `urgency: deferred` and list the missing context. The current artifact remains valid as a standalone output. Do not retry indefinitely.
