# cross-skill-orchestration

Describes how the nine ops-runtime skills collaborate in multi-signal incident diagnosis.

## Canonical combination paths

### Alert-first (most common)
```
alert-attribution
  → monitoring-metric-interpretation  (metric anomaly confirmation)
  → log-analysis                       (log evidence gathering)
  → trace-call-chain-analysis          (call path reconstruction)
  → bug-analysis                       (fast symptom triage)
  → root-cause-analysis-recommendation (evidence-chained RCA)
  → impact-scope-analysis              (blast radius quantification)
```

### Metric-first
```
monitoring-metric-interpretation
  → alert-attribution        (alert dedup and routing)
  → trace-call-chain-analysis (latency/error path drilldown)
  → impact-scope-analysis     (SLO burn → user impact)
  → root-cause-analysis-recommendation
```

### Log-first
```
log-analysis
  → anomaly-clustering        (pattern deduplication)
  → frequent-error-summary    (error ranking)
  → bug-analysis              (triage framing)
  → root-cause-analysis-recommendation
```

## Join keys for composition
All ops-runtime skills share these composition join keys:
- `incident_id` — primary correlation key
- `source_time_window` — time range anchor
- `service_scope` — affected service list
- `evidence_refs` — reference IDs passed between skills
- `contract_version: ops-runtime-runtime-v2.5.0` — version guard

## Composition rules
1. Later skills cite earlier artifacts by `artifact name + evidence_ref`, never by re-running the same analysis.
2. `incident_id` must remain stable across all skills in a single incident. Only `alert-attribution` may create or normalize a new incident_id.
3. Skills emit `downstream_handoff` records that declare `handoff_type`, `required_fields`, `evidence_refs`, `confidence`, and `next_best_checks`.
4. When two skills contradict each other (e.g., log-analysis says service A is healthy, metrics say it is degraded), both findings remain visible with `conflicting` confidence labels — do not suppress contradictions.
5. Circuit breakers are skill-local. A skill that triggers its circuit breaker must emit `exception.ops-runtime.skill_blocked.v2.5.0` and hand off to the incident commander, not to the next ops-runtime skill in the chain.

## Refresh triggers
- If `alert-attribution` re-classifies the root alert, emit `downstream_handoff.refresh_triggers: [monitoring-metric-interpretation, log-analysis]` so those skills can re-consume updated `incident_id` and `source_time_window`.
- If `anomaly-clustering` merges or splits clusters, emit `downstream_handoff.refresh_triggers: [frequent-error-summary, root-cause-analysis-recommendation]`.


---

## Boundary: anomaly-clustering vs frequent-error-summary (115 vs 116)

Use **this skill** when:
- You have **raw, noisy events** from any signal family (logs, metrics, traces, alerts, checks) within a **single incident window** (typically ≤ 2h)
- The goal is **deduplication and grouping** — reducing N events to M clusters (M << N)
- The event stream has not yet been normalized into known signatures
- You need **novelty detection** (is this cluster new or recurring?)

Use **frequent-error-summary** when:
- You have **normalized error signatures** (already named patterns, known error codes)
- The goal is **ranking over a longer reporting window** (typically ≥ 24h, up to 30d)
- You need **trend analysis and fix ROI** across sprints or ops reviews
- Clusters already exist (from 115 or log queries) and you need ranking

**When both apply:** Run 115 first to produce `source_cluster_id` values, then pass those to 116 for weighted ranking. 116 must reference `source_cluster_id` when consuming 115 output.

