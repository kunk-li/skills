#!/usr/bin/env python3
"""
validate_artifact.py — ops-runtime skill artifact validator v3.
Usage: python scripts/validate_artifact.py <artifact.md> [--strict] [--report-coverage]
Exit 0 = PASS, 1 = FAIL, 2 = file error
"""
import sys, re, argparse

REQUIRED_METADATA = [
    "contract_version", "workflow_node", "incident_id",
    "selected_mode", "readiness", "evidence_profile",
    "artifact_schema_name", "artifact_schema_version",
]
REQUIRED_SECTIONS = ["downstream_handoff", "self_check", "evidence_profile", "metadata"]
VALID_READINESS   = {"draft", "partial", "ready", "amber", "red", "green"}
VALID_CONTRACT    = "ops-runtime-runtime-v2.5.0"

SCR_RULES = {
    "SCR-DOWNSTREAM":   (r"downstream_handoff", "downstream_handoff section missing"),
    "SCR-SELFCHECK":    (r"self_check", "self_check section missing"),
    "SCR-CONFIDENCE":   (r"confidence:\s*(high|medium|low|speculative)", "no confidence label found"),
    "SCR-INCIDENT_ID":  (r"incident_id:", "incident_id field missing"),
    "SCR-NO_PLAINTEXT": (r"(?i)password:\s*[A-Za-z0-9!@#$%]{8,}", "possible plaintext secret"),
    "SCR-READINESS":    (r"readiness:\s*(green|amber|red|partial|draft|ready)", "readiness invalid"),
    "SCR-HANDOFF_TYPE": (r"(to_skill|handoff_type|next_best_checks|urgency)", "handoff missing routing"),
    "SCR-FIELD_CONTRACT":(r"(\| Field \|| field contract)", "no field contract found"),
    "SCR-MOCK_INPUT":   (r"mock_input:", "no mock input fixture found"),
    "SCR-FOUR_TIER":    (r"(Tier [1-4]|tier_1|tier_2|tier_3|tier_4)", "no four-tier input model"),
    "SCR-SAMPLING":     (r"(sampling_applied|filter_template|token_budget)", "no large-input strategy"),
}

# D9 Testability Coverage — 11 fixtures
D9_FIXTURES = {
    "standalone_example":     r"(Standalone guarantee|minimum.*input|minimum viable)",
    "red_state_example":      r"readiness:\s*red",
    "amber_state_example":    r"readiness:\s*(amber|partial)",
    "field_contract_table":   r"\| Field \|",
    "scr_rules":              r"SCR-\d+",
    "real_examples_ref":      r"real.examples",
    "failure_modes_ref":      r"failure.modes",
    "large_input_handling":   r"(large input|Large input|token_budget|sampling_applied)",
    "adversarial_defense":    r"(adversarial|injection_attempt|Injection|forbidden_patterns)",
    "feedback_loop":          r"(feedback_signal_candidates|FSC-\d+)",
    "mock_input_fixture":     r"mock_input:",
}

# D5 handoff type checks
D5_CHECKS = {
    "handoff_type_typed":  r"handoff_type:\s*(evidence|hypothesis|scope|routing|pattern|gap|action_hint)",
    "handoff_target":      r"target:\s*(root-cause|alert|log|monitoring|impact|bug|trace|anomaly|frequent)",
    "refresh_triggers":    r"refresh_triggers:",
}

# D6 maintenance checks
D6_CHECKS = {
    "consumer_protocol":   r"(consumer.*impact|affected_consumers|consumer_impact_assessment)",
    "deprecation_timeline":r"(deprecated_since|remove_after|dual_emit)",
    "upgrade_checklist":   r"(upgrade.*checklist|WHEN to trigger|patch.*minor.*major)",
}

def validate(path: str, strict: bool = False):
    try:
        content = open(path, encoding="utf-8").read()
    except FileNotFoundError:
        sys.exit(2)
    errs, warns, coverage = [], [], {}

    for f in REQUIRED_METADATA:
        if f not in content:
            errs.append(f"[FIELD] MISSING: {f}")
    for s in REQUIRED_SECTIONS:
        if s not in content:
            errs.append(f"[SECTION] MISSING: {s}")
    if VALID_CONTRACT not in content:
        errs.append(f"[CONTRACT] expected '{VALID_CONTRACT}'")
    rd = re.search(r"readiness:\s*(\S+)", content)
    if rd:
        v = rd.group(1).strip("'\"")
        if v not in VALID_READINESS:
            errs.append(f"[READINESS] invalid: {v}")

    for rule_id, (pattern, msg) in SCR_RULES.items():
        match = bool(re.search(pattern, content, re.IGNORECASE))
        if rule_id == "SCR-NO_PLAINTEXT":
            if match: errs.append(f"[{rule_id}] {msg}")
        else:
            if not match:
                (errs if strict else warns).append(f"[{rule_id}] {msg}")

    # D9 fixture coverage
    for check, pattern in D9_FIXTURES.items():
        covered = bool(re.search(pattern, content, re.IGNORECASE))
        coverage[f"D9_{check}"] = covered
        if not covered:
            warns.append(f"[D9-{check}] not found")

    # D5 handoff coverage
    for check, pattern in D5_CHECKS.items():
        covered = bool(re.search(pattern, content, re.IGNORECASE))
        coverage[f"D5_{check}"] = covered
        if not covered:
            warns.append(f"[D5-{check}] not found")

    # D6 maintenance coverage
    for check, pattern in D6_CHECKS.items():
        covered = bool(re.search(pattern, content, re.IGNORECASE))
        coverage[f"D6_{check}"] = covered
        if not covered:
            warns.append(f"[D6-{check}] not found")

    return errs, warns, coverage

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact")
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--report-coverage", action="store_true")
    args = parser.parse_args()

    errs, warns, cov = validate(args.artifact, args.strict)

    if args.report_coverage:
        groups = {"D9 Testability": {k:v for k,v in cov.items() if k.startswith("D9")},
                  "D5 Orchestration": {k:v for k,v in cov.items() if k.startswith("D5")},
                  "D6 Maintenance": {k:v for k,v in cov.items() if k.startswith("D6")}}
        for gname, gcov in groups.items():
            score = round(sum(gcov.values())/len(gcov)*100) if gcov else 0
            print(f"\n{gname} Coverage: {score}%")
            for k, v in gcov.items():
                print(f"  {'✓' if v else '✗'} {k}")

    if warns:
        print(f"\nWARNINGS ({len(warns)}):")
        for w in warns[:10]: print(f"  ! {w}")
        if len(warns) > 10: print(f"  ... and {len(warns)-10} more")

    if not errs:
        print(f"\nPASS: {args.artifact}")
        sys.exit(0)
    print(f"\nFAIL: {len(errs)} error(s):")
    for e in errs: print(f"  x {e}")
    sys.exit(1)
