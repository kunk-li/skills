---
name: bug-analysis
description: triage production bug symptoms for n300 incidents. use for fast five element bug analysis across symptoms, impact, evidence, hypotheses, and decision, especially when alert, user report, logs, traces, or diff risk need one actionable bug narrative. produce Bug分析.md and hand deep cause work to rca.
---
# bug-analysis

## Purpose
Use this skill in the N300 runtime monitoring and incident-diagnosis node to produce `Bug分析.md`. The skill is standalone: it can work with the minimum evidence listed below, and it becomes stronger when combined through the shared N300 contract.

## V2.5.0 optimization note
This version uses `references/n300-shared-runtime-contract.md` as the common source for execution workflow, input handling, self-check, incident id rules, evidence references, downstream handoff schema, and combination paths. Keep this SKILL.md focused on the skill-specific boundary, modes, minimum inputs, output sections, and consumers.

## V2.5.0 encapsulation baseline
This release keeps one contract version across SKILL.md metadata, output-contract.yaml, and references/n300-shared-runtime-contract.md. The skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside each skill plus the artifacts exchanged through downstream_handoff.

## Scope boundary
- Own: production bug triage and decision framing.
- Artifact target: `Bug分析.md`.
- Boundary: perform fast bug triage and action framing; do not perform deep five-why RCA or final prevention design.
- Do not perform N310 remediation execution or N320 postmortem authorship unless explicitly asked to create a handoff draft.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `incident_id`, and `contract_version` before the main findings.

Allowed modes:
- `from_alert`
- `from_user_report`
- `quick_triage`
- `comprehensive_report_bridge`

## Standalone minimum viable input
This skill can run with only:
- bug symptom or incident report
- one evidence source such as logs, traces, metrics, or diff risk
- observed time or affected flow when available

When evidence is partial, keep the output structure stable, lower `readiness`, and list missing evidence in `downstream_handoff.missing_evidence`.


## Standalone and composition role
```yaml
standalone_guarantee: "Triage a production symptom, alert, user report, or failed check into a five-element bug narrative with hypotheses and immediate decision framing."
composition_role: "runtime_bug_triage"
composition_leverage: "Turns raw signals into an actionable bug frame; consumes logs/traces/diff risk when present and hands bounded hypotheses to RCA, impact scope, N310, and N320."
best_combines_with: ["root-cause-analysis-recommendation", "impact-scope-analysis", "N310", "N320", "N370"]
standalone_readiness_floor: partial
composition_join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - evidence_refs
```

When this skill is run alone, produce `Bug分析.md` without waiting for sibling artifacts. When it is run in a composed N300 path, consume earlier artifacts only through `downstream_handoff` and `evidence_refs`, then emit a stronger handoff for the next skill.

## Input handling
Follow `V2.5.0 common input handling` in `references/n300-shared-runtime-contract.md`. Use optional evidence only to strengthen this skill's own artifact, not to perform sibling-skill work.
## Execution workflow
Follow `V2.5.0 common execution workflow` in `references/n300-shared-runtime-contract.md`, then apply the skill-specific required sections and design rules below.
## Required output sections
Every output must include:
- `metadata`
- `incident_overview`
- `bug_summary`
- `symptoms[]`
- `impact_snapshot`
- `evidence_summary[]`
- `attribution_hypotheses[]`
- `decision`
- `immediate_actions[]`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `contract_version: n300-runtime-v2.5.0`
- `workflow_node: N300`
- `node_artifact_target: Bug分析.md`
- `function_bias: production_bug_triage_and_decision_framing`
- `stage_position: operations_runtime.monitoring_and_diagnosis.bug_analysis`
- `incident_id`
- `selected_mode`
- `readiness`
- `evidence_profile`
- `tool_collaboration_mode`

Primary rows or structured entries must preserve:
- `symptom_id`
- `observed_behavior`
- `expected_behavior`
- `affected_flow`
- `evidence_refs`
- `hypothesis_id`
- `confidence`
- `decision`
- `next_action`

## Downstream handoff contract
Use the shared schema in `references/n300-shared-runtime-contract.md`. For this skill, preferred consumers are:

```yaml
downstream_consumers:
  - target: root-cause-analysis-recommendation
    summary: accepted and rejected hypotheses plus evidence gaps for deep RCA
  - target: impact-scope-analysis
    summary: affected flows and user-visible symptoms for scope quantification
  - target: N310
    summary: immediate action candidates and risk notes for response planning
  - target: N320
    summary: triage narrative and symptom timeline for postmortem
  - target: N370
    summary: skill routing cues when further N300 analysis is needed
```

## Design rules
- organize the output around symptoms, impact, evidence, hypotheses, and decision.
- state whether the bug is confirmed, probable, speculative, or not enough evidence.
- separate containment actions from full fixes.
- when using comprehensive_report_bridge, borrow report structure only; keep RCA ownership with 117.
- Always preserve source time windows, source systems, and evidence references.
- Distinguish observed facts from hypotheses.
- Keep sensitive raw data out of final artifacts.

## Self-check
Run `V2.5.0 common self-check` from `references/n300-shared-runtime-contract.md` and additionally confirm this skill's artifact target, boundary, modes, and `output-contract.yaml` fields are satisfied.
## Reference files
- `references/n300-shared-runtime-contract.md`
- `references/output-contract.yaml`
- `references/bug-5-elements.md`
