# real-examples

These examples illustrate how to produce this skill's artifact under different evidence conditions. Use them as output calibration references — not as templates to copy verbatim.

## Example 1: Minimum viable input (readiness: partial)

**Scenario:** Single metric spike, no logs or traces available.

**Input given:**
- Service: `payment-service`
- Signal: `http_error_rate` jumped from 0.3% to 12% at 14:32 UTC
- No trace data, no log access

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  evidence_profile: metrics_only
  incident_id: TEMP-ops-runtime-20240315-payment-metric
evidence_profile:
  missing_evidence:
    - structured logs for error classification
    - trace ids to correlate request path
  next_best_checks:
    - pull error log sample from payment-service for 14:30–14:40 UTC
    - check recent deployment or config change in this window
```

**Key calibration:** Output must not invent error causes. State "elevated error rate observed; cause undetermined pending log/trace evidence."

---

## Example 2: Rich multi-signal input (readiness: ready)

**Scenario:** Alert storm with logs and partial traces available.

**Input given:**
- Alert: `payment-service SLO burn rate 14× budget`
- Log sample: 3,200 lines of `NullPointerException` in `PaymentProcessor.java:142`
- Trace: 2 trace IDs showing 8s p99 at `db-connection-pool`
- Recent change: DB connection pool size reduced from 100→20 at 14:15 UTC

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  evidence_profile: multi_signal
recommended_finding:
  hypothesis_id: H1
  statement: "Connection pool exhaustion caused by config change at 14:15 UTC"
  confidence: high
  supporting_evidence_refs: [alert-001, log-finding-3, trace-T1, trace-T2]
  contradicting_evidence_refs: []
```

**Key calibration:** Confidence "high" requires at least 2 corroborating signal families AND a plausible causal mechanism.

---

## Example 3: Conflicting evidence (readiness: partial)

**Scenario:** Logs point to DB; metrics show CPU spike on app tier.

**Expected output shape:**
```yaml
hypothesis_testing:
  - hypothesis_id: H1
    statement: "DB connection exhaustion is root cause"
    confidence: medium
    supporting_evidence_refs: [log-finding-1]
    contradicting_evidence_refs: [metric-cpu-001]
    status: unresolved — conflicting signals
  - hypothesis_id: H2
    statement: "App-tier CPU spike caused downstream DB timeouts"
    confidence: low
    supporting_evidence_refs: [metric-cpu-001]
    contradicting_evidence_refs: [log-finding-1]
    status: unresolved
recommended_root_cause:
  statement: "Insufficient evidence to choose between H1 and H2"
  next_best_checks:
    - capture JVM thread dump from app tier during next occurrence
    - check DB slow query log for same window
```

**Key calibration:** Never collapse conflicting hypotheses into a single confident conclusion. Keep both visible.

---

## Example 4: multi-signal rich input — cascade failure confirmed

**Scenario:** Auth service 500 errors triggered by upstream DB connection pool exhaustion. Three signal families confirm the cascade.

**Input given:**
- Alert: `auth-service HTTP 500, error_rate 18%`
- Logs: `AuthService: ConnectionPoolExhaustedException — pool size 20/20 at 14:32 UTC`
- Metrics: `auth-service latency p99 spike from 80ms → 4200ms at 14:30 UTC`
- Trace: `auth-service span blocked on db-connection-pool for 3800ms`
- Recent change: `db.pool.max-size reduced from 100 → 20 at 14:15 UTC`

**Expected output:**
```yaml
metadata:
  readiness: ready
  selected_mode: deep_investigation
  evidence_profile: multi_signal
five_element_triage:
  symptom: "auth-service HTTP 500, error_rate 18%, latency p99 4200ms"
  impact: "All requests requiring auth are failing; downstream services cascade"
  evidence:
    - source: alert_payload
      finding: "auth-service error_rate 18% — 18× normal baseline"
      confidence: high
    - source: connection_pool_log
      finding: "Pool exhausted (20/20) at 14:32 UTC, 17 minutes after config change"
      confidence: high
    - source: trace_span
      finding: "db-connection-pool bottleneck: 3800ms of 4200ms total span"
      confidence: high
    - source: config_change_ref
      finding: "db.pool.max-size 100→20 at 14:15 UTC — plausible cause"
      confidence: high
  hypothesis:
    - hypothesis_id: H-001
      statement: "DB connection pool exhaustion caused by config change at 14:15 UTC"
      confidence: high
      hypothesis_status: accepted
      supporting_evidence_refs: [alert-001, log-pool-001, trace-span-001, config-change-001]
      five_why_chain:
        why_1: "auth-service returns HTTP 500"
        why_2: "auth-service cannot acquire DB connection"
        why_3: "DB connection pool is exhausted (20/20)"
        why_4: "Pool size was reduced from 100 to 20"
        why_5: "Config change not load-tested under peak traffic conditions"
  immediate_actions:
    - action: "Revert db.pool.max-size to 100 (config rollback)"
      priority: P0
      owner: devops-team
      expected_ttr: 5m
    - action: "Monitor auth-service error rate for 10 minutes after revert"
      priority: P1
      owner: sre-oncall
downstream_handoff:
  to_skill: root-cause-analysis-recommendation
  handoff_type: hypothesis
  summary: "H-001 confirmed with high confidence. Root cause: config change → pool exhaustion → cascade."
self_check:
  passed: true
  failed_rules: []
```

**Key calibration:** When `confidence: high` is warranted (3+ corroborating signal families), explicitly show the five-why chain. `hypothesis_status: accepted` requires both `high confidence` AND no contradicting evidence.

---

## Example 5: D2 Tier 1 minimum — one sentence only

```yaml
metadata:
  readiness: partial
  evidence_profile: minimal_verbal
five_element_triage:
  symptom: "checkout failing (verbal description only)"
  impact: unable_to_measure
  evidence:
    - source: verbal_description
      finding: "checkout failing — no structured evidence"
      confidence: speculative
  hypothesis:
    - hypothesis_id: H-001
      statement: "Unknown — verbal description only; root cause undetermined"
      confidence: speculative
      hypothesis_status: unresolved
  immediate_actions:
    - action: "Gather structured evidence: pull error logs, check monitoring alerts, review recent deployments"
      priority: P1
      owner: oncall-engineer
downstream_handoff:
  missing_evidence: [alert_payload, error_logs, metric_snapshot, recent_changes]
  next_best_checks:
    - "Pull payment service error logs for last 30 minutes"
    - "Check monitoring dashboard for error rate and latency spikes"
self_check:
  passed: false
  failed_rules: ["Tier 1 input — five_element_triage is speculative placeholder only"]
```


---

## Scenario calibration
See `references/real-examples.md` for annotated scenarios covering green (full evidence), amber (partial evidence with degradation), and red (hard-blocker) paths.

For output field definitions, see `references/field-contract.md`.
For quality-gate rules, see `references/quality-checklist.md`.
For failure-mode handling, see `references/failure-modes.md`.
For shared ops-runtime execution contract, see `references/ops-runtime-shared-contract.md`.