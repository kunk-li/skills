## Mock input fixture

```yaml
mock_input:
  scenario: "alert_only"
  content: "payment-service HTTP 500 spike since 14:32 UTC"
  expected_output_shape:
    five_element_triage:
      symptom: present
      impact: present
      evidence: present
      hypothesis: present
      immediate_actions: present
    self_check:
      passed: true

mock_input_2:
  scenario: "contradicting_evidence"
  content:
    initial_hypothesis: "payment-service connection timeout"
    new_trace: "auth-service returned 500 before payment timeout"
  expected_output_shape:
    five_element_triage:
      hypothesis_status: contradicted
      revised_hypothesis: present
    metadata:
      readiness: red
    self_check:
      passed: false
      failed_rules: ["Initial hypothesis contradicted — triage restart required"]
```
