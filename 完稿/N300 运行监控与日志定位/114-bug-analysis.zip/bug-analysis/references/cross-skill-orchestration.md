# cross-skill-orchestration

Describes how the nine ops-runtime skills collaborate in multi-signal incident diagnosis.

## Canonical combination paths

### Alert-first (most common)
```
alert-attribution
  → monitoring-metric-interpretation  (metric anomaly confirmation)
  → log-analysis                       (log evidence gathering)
  → trace-call-chain-analysis          (call path reconstruction)
  → bug-analysis                       (fast symptom triage)
  → root-cause-analysis-recommendation (evidence-chained RCA)
  → impact-scope-analysis              (blast radius quantification)
```

### Metric-first
```
monitoring-metric-interpretation
  → alert-attribution        (alert dedup and routing)
  → trace-call-chain-analysis (latency/error path drilldown)
  → impact-scope-analysis     (SLO burn → user impact)
  → root-cause-analysis-recommendation
```

### Log-first
```
log-analysis
  → anomaly-clustering        (pattern deduplication)
  → frequent-error-summary    (error ranking)
  → bug-analysis              (triage framing)
  → root-cause-analysis-recommendation
```

## Join keys for composition
All ops-runtime skills share these composition join keys:
- `incident_id` — primary correlation key
- `source_time_window` — time range anchor
- `service_scope` — affected service list
- `evidence_refs` — reference IDs passed between skills
- `contract_version: ops-runtime-runtime-v2.5.0` — version guard

## Composition rules
1. Later skills cite earlier artifacts by `artifact name + evidence_ref`, never by re-running the same analysis.
2. `incident_id` must remain stable across all skills in a single incident. Only `alert-attribution` may create or normalize a new incident_id.
3. Skills emit `downstream_handoff` records that declare `handoff_type`, `required_fields`, `evidence_refs`, `confidence`, and `next_best_checks`.
4. When two skills contradict each other (e.g., log-analysis says service A is healthy, metrics say it is degraded), both findings remain visible with `conflicting` confidence labels — do not suppress contradictions.
5. Circuit breakers are skill-local. A skill that triggers its circuit breaker must emit `exception.ops-runtime.skill_blocked.v2.5.0` and hand off to the incident commander, not to the next ops-runtime skill in the chain.

## Refresh triggers
- If `alert-attribution` re-classifies the root alert, emit `downstream_handoff.refresh_triggers: [monitoring-metric-interpretation, log-analysis]` so those skills can re-consume updated `incident_id` and `source_time_window`.
- If `anomaly-clustering` merges or splits clusters, emit `downstream_handoff.refresh_triggers: [frequent-error-summary, root-cause-analysis-recommendation]`.


---

## Boundary comparison table — bug-analysis precise

| Dimension | bug-analysis | root-cause-analysis-recommendation | impact-scope-analysis | on-call-response-recommendation |
|---|---|---|---|---|
| **Primary question** | "What is this bug and what should we do NOW?" | "WHY did the incident happen?" | "WHO is affected and how badly?" | "What do responders do in the next 15min?" |
| **Output type** | Five-element triage: symptoms/impact/evidence/hypotheses/decision | Causal chain + ranked hypotheses + prevention | Affected users, revenue, SLA, tier | Timed response sequence + incident command |
| **Timing** | T+0 (immediate triage, ≤10min) | Parallel with response; may take hours | T+5min (after impact signals available) | T+0 to T+15min (immediate) |
| **Owns** | Bug classification (regression/environment/systemic), fast hypothesis ranking, next-step decision | Root cause causal chain, five-why, prevention | User count, revenue at risk, tier recommendation | Response steps, incident command, escalation |
| **Does not own** | Root cause depth (→119) · Impact quantification (→116) · Response steps (→120) | Fast triage (→118) · Impact numbers (→116) · Response steps (→120) | Bug triage (→118) · Root cause (→119) · Response steps (→120) | Bug triage (→118) · Root cause (→119) · Impact (→116) |

### When to call 118 vs neighbors
```
"What's causing this bug? (fast)"      → 118 (≤10min triage)
"What's the deep root cause?"           → 119 (may take hours, runs parallel)
"How many users are affected?"          → 116 (impact-scope)
"What do we do right now?"             → 120 (on-call response steps)
118 triage feeds → 119 for deep investigation
118 classification feeds → 116 for impact quantification
```