# output-template

Use this template as the structural scaffold for producing this skill's artifact. Fill each section with evidence-derived content; never leave required fields empty — use `unable_to_measure`, `unknown`, or `needs_evidence` with a reason instead.

## Top-level structure

```markdown
---
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  node_artifact_target: <artifact-target>
  function_bias: <this-skill-function-bias>
  stage_position: <this-skill-stage-position>
  incident_id: <string | TEMP-ops-runtime-<date>-<source>>
  selected_mode: <allowed-mode>
  readiness: draft | partial | ready
  evidence_profile: <profile-value>
  tool_collaboration_mode: <mode>
  source_time_window:
    start: <iso8601 | unknown>
    end: <iso8601 | unknown>
  service_scope: [<service-names>]
---

## incident_overview
> 2–4 sentence plain-language summary of what happened, when, and which services.
> Always write this section even when readiness is partial.

## [skill-specific sections]
> See SKILL.md Required output sections.
> Every primary row must include all required fields.
> Use `unable_to_measure` + reason when data is unavailable.

## downstream_handoff
> Machine-readable handoff entries per the shared contract schema.
> Include missing_evidence and next_best_checks for every handoff item.

## self_check
> Record pass/fail for each shared V2.5.0 self-check item.
> If any item fails, readiness must be partial or draft.
```

## Field fill guidance

| Situation | Required action |
|---|---|
| No `incident_id` exists | Create `TEMP-ops-runtime-<YYYYMMDD>-<source>` and mark `provisional: true` |
| Evidence is partial | Keep all sections; fill with best estimate + confidence label |
| Metric not measurable | Use `unable_to_measure: true` with `reason` field |
| Hypothesis uncertain | Use `confidence: low` and list what would raise it |
| Sensitive data present | Summarize or hash; never include plaintext PII or credentials |

## Readiness decision guide

| Condition | Readiness |
|---|---|
| All required sections complete, evidence multi-signal, self-check passes | `ready` |
| Some evidence missing, assumptions made, but output is actionable | `partial` |
| Critical required fields cannot be filled without more data | `draft` |


---

## Downstream handoff YAML templates

### 正常路径：向 root-cause-analysis-recommendation 和 impact-scope-analysis 移交
```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: bug-analysis
  incident_id: "{incident_id}"
  artifact: Bug分析.md
  handoffs:
    - target: root-cause-analysis-recommendation
      handoff_type: hypothesis
      summary: "Top hypothesis H-001: DB connection pool exhaustion (confidence: medium)"
      required_fields: [hypothesis_id, hypothesis_statement, confidence, evidence_refs]
      evidence_refs: [log-finding-1, metric-M001]
      confidence: medium
      missing_evidence: [trace_data_for_db_service]
      next_best_checks:
        - "Confirm H-001 with trace-call-chain-analysis on db-service span"
    - target: impact-scope-analysis
      handoff_type: scope
      summary: "Affected service: payment-service; symptom: HTTP 500; duration: 45min"
      required_fields: [service_scope, symptom, impact_estimate]
      evidence_refs: [alert-001]
      confidence: high
      missing_evidence: []
      next_best_checks:
        - "Quantify affected user count from transaction logs"
```

### 假设被推翻路径：向上游技能发起 refresh
```yaml
downstream_handoff:
  handoffs:
    - target: log-analysis
      handoff_type: gap
      summary: "Initial hypothesis contradicted — re-run log-analysis on auth-service"
      required_fields: [service_scope, time_window]
      confidence: low
      missing_evidence: [auth_service_logs]
      next_best_checks:
        - "Filter auth-service logs at incident time window"
        - "Re-run trace-call-chain-analysis: re-examine span from auth-service"
  refresh_triggers:
    - skill: log-analysis
      reason: "Hypothesis restart requires new log evidence"
```


---

## Standalone guarantee
This skill runs independently with the minimum evidence listed in this file. Do not refuse output because sibling ops-runtime skills have not been run first. When evidence is absent, declare `readiness: partial` or `readiness: red`, populate all stable output sections with available evidence, and list missing evidence in `downstream_handoff.missing_evidence`.

---

## Output completeness rule
Every artifact from this skill MUST include all of:
- `metadata` with `readiness`, `selected_mode`, `evidence_profile`
- `evidence_profile.confirmed` list ≥ 1 item (or explicit `[]` with missing_evidence explanation)
- `confidence` ∈ {high, medium, low, speculative}
- `downstream_handoff` with ≥ 1 typed `handoff_type` entry
- `self_check.passed` boolean + `self_check.warnings[]` (may be `[]`)
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry
- `emit_event.event_name` matching `produced.ops-runtime.*.v2`

**Hard rule:** `confidence: high` requires `evidence_profile.confirmed` ≥ 3 distinct signal families.

---

## Mode selection

### New: `multi_service_bug` mode — 跨服务 Bug 分析
**Trigger:** Bug manifests across multiple services, or user says "bug affecting multiple services", "cross-service issue", "which service is the origin?"

```yaml
multi_service_bug:
  affected_services: [payment-service, cart-service, checkout-api]
  bug_propagation:
    origin_service: payment-service
    origin_evidence: "NullPointerException at PaymentProcessor:142 — only in payment-service logs"
    propagation_path:
      - service: payment-service
        symptom: "NPE at PaymentProcessor:142"
        role: origin
      - service: checkout-api
        symptom: "503 from payment-service — retry storm triggered"
        role: downstream_victim
        propagation_mechanism: synchronous_dependency
      - service: cart-service
        symptom: "Cart lock timeout waiting for checkout-api"
        role: indirect_victim
  origin_confirmed: true
  cross_service_impact_note: "cart-service impact is indirect — resolving origin fixes all"
  recommended_focus: payment-service
  confidence: high
```
**SCR:** `selected_mode: multi_service_bug` → `multi_service_bug.origin_service` declared; `propagation_path` ≥ 2 entries; `origin_confirmed` boolean.