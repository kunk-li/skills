# bug 5 elements

Every bug analysis should organize evidence into:
1. symptoms
2. impact snapshot
3. evidence
4. attribution hypotheses
5. decision and next action

This skill is for fast triage and action framing. It may prepare inputs for a full bug report, but deep five-why RCA and prevention recommendations belong to `root-cause-analysis-recommendation`.

## Optional comprehensive bridge
When the user explicitly needs a fuller incident report, add sections for detection, reproduction evidence, remediation options, and prevention placeholders, then hand off root-cause depth to 117.
