---
name: monitoring-metric-interpretation
description: interpret runtime metric anomalies for n300 incidents. use for cpu, latency, traffic, errors, saturation, slo burn, business kpi movement, baseline comparison, and deciding whether metric evidence is a symptom, impact signal, or monitoring gap. produce 监控指标解读.md without designing new monitoring systems.
---
# monitoring-metric-interpretation

## Purpose
Use this skill in the N300 runtime monitoring and incident-diagnosis node to produce `监控指标解读.md`. The skill is standalone: it can work with the minimum evidence listed below, and it becomes stronger when combined through the shared N300 contract.

## V2.5.0 optimization note
This version uses `references/n300-shared-runtime-contract.md` as the common source for execution workflow, input handling, self-check, incident id rules, evidence references, downstream handoff schema, and combination paths. Keep this SKILL.md focused on the skill-specific boundary, modes, minimum inputs, output sections, and consumers.

## V2.5.0 encapsulation baseline
This release keeps one contract version across SKILL.md metadata, output-contract.yaml, and references/n300-shared-runtime-contract.md. The skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside each skill plus the artifacts exchanged through downstream_handoff.

## Scope boundary
- Own: signal health interpretation and metric storytelling.
- Artifact target: `监控指标解读.md`.
- Boundary: explain metric movement and monitoring quality; do not deduplicate alert storms or generate monitoring-plan design deliverables.
- Do not perform N310 remediation execution or N320 postmortem authorship unless explicitly asked to create a handoff draft.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `incident_id`, and `contract_version` before the main findings.

Allowed modes:
- `slo_focused`
- `business_focused`
- `comprehensive`
- `cost_metric_audit`

## Standalone minimum viable input
This skill can run with only:
- one metric time series or dashboard slice
- observed time window
- service or component name when available

When evidence is partial, keep the output structure stable, lower `readiness`, and list missing evidence in `downstream_handoff.missing_evidence`.


## Standalone and composition role
```yaml
standalone_guarantee: "Interpret one metric slice or dashboard window into signal health, metric quality, and SLO/KPI meaning without requiring logs, traces, or alert data."
composition_role: "metric_signal_interpreter"
composition_leverage: "Starts or strengthens metric-first diagnosis; supplies anomaly windows, signal families, SLO burn, and business KPI movement to alert attribution, trace drilldown, impact scope, and RCA."
best_combines_with: ["alert-attribution", "trace-call-chain-analysis", "impact-scope-analysis", "root-cause-analysis-recommendation"]
standalone_readiness_floor: partial
composition_join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - evidence_refs
```

When this skill is run alone, produce `监控指标解读.md` without waiting for sibling artifacts. When it is run in a composed N300 path, consume earlier artifacts only through `downstream_handoff` and `evidence_refs`, then emit a stronger handoff for the next skill.

## Input handling
Follow `V2.5.0 common input handling` in `references/n300-shared-runtime-contract.md`. Use optional evidence only to strengthen this skill's own artifact, not to perform sibling-skill work.
## Execution workflow
Follow `V2.5.0 common execution workflow` in `references/n300-shared-runtime-contract.md`, then apply the skill-specific required sections and design rules below.
## Required output sections
Every output must include:
- `metadata`
- `incident_overview`
- `signal_inventory`
- `metric_interpretations[]`
- `sli_slo_map`
- `anomaly_judgements[]`
- `business_signal_view`
- `metric_lifecycle_actions[]`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `contract_version: n300-runtime-v2.5.0`
- `workflow_node: N300`
- `node_artifact_target: 监控指标解读.md`
- `function_bias: signal_health_interpretation_and_metric_storytelling`
- `stage_position: operations_runtime.monitoring_and_diagnosis.metric_interpretation`
- `incident_id`
- `selected_mode`
- `readiness`
- `evidence_profile`
- `tool_collaboration_mode`

Primary rows or structured entries must preserve:
- `metric_id`
- `metric_name`
- `metric_tier`
- `signal_family`
- `current_value`
- `baseline_source`
- `anomaly_rule`
- `current_state`
- `interpretation`
- `business_relevance`
- `alert_priority`
- `owner_placeholder`

## Downstream handoff contract
Use the shared schema in `references/n300-shared-runtime-contract.md`. For this skill, preferred consumers are:

```yaml
downstream_consumers:
  - target: alert-attribution
    summary: metric anomaly windows, severity hints, and signal family labels for root alert selection
  - target: trace-call-chain-analysis
    summary: time ranges and service scopes where latency/error movement needs trace drilldown
  - target: impact-scope-analysis
    summary: business-facing metrics and SLO burn signals for scope estimation
  - target: root-cause-analysis-recommendation
    summary: metric evidence and contradictory signals for hypothesis testing
  - target: N310/N320/N330
    summary: actionable signal gaps, monitoring gaps, and lifecycle actions
```

## Design rules
- always name the anomaly judgement method and baseline before calling a metric abnormal.
- separate technical signals from business-visible signals when both are present.
- treat stale, missing, or misleading metrics as monitoring gaps instead of silently trusting them.
- mark metric-derived hypotheses as hypotheses, not root causes.
- Always preserve source time windows, source systems, and evidence references.
- Distinguish observed facts from hypotheses.
- Keep sensitive raw data out of final artifacts.

## Self-check
Run `V2.5.0 common self-check` from `references/n300-shared-runtime-contract.md` and additionally confirm this skill's artifact target, boundary, modes, and `output-contract.yaml` fields are satisfied.
## Reference files
- `references/n300-shared-runtime-contract.md`
- `references/output-contract.yaml`
- `references/monitoring-framework.md`
