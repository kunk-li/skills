# cross-skill-orchestration

Describes how the nine ops-runtime skills collaborate in multi-signal incident diagnosis.

## Canonical combination paths

### Alert-first (most common)
```
alert-attribution
  → monitoring-metric-interpretation  (metric anomaly confirmation)
  → log-analysis                       (log evidence gathering)
  → trace-call-chain-analysis          (call path reconstruction)
  → bug-analysis                       (fast symptom triage)
  → root-cause-analysis-recommendation (evidence-chained RCA)
  → impact-scope-analysis              (blast radius quantification)
```

### Metric-first
```
monitoring-metric-interpretation
  → alert-attribution        (alert dedup and routing)
  → trace-call-chain-analysis (latency/error path drilldown)
  → impact-scope-analysis     (SLO burn → user impact)
  → root-cause-analysis-recommendation
```

### Log-first
```
log-analysis
  → anomaly-clustering        (pattern deduplication)
  → frequent-error-summary    (error ranking)
  → bug-analysis              (triage framing)
  → root-cause-analysis-recommendation
```

## Join keys for composition
All ops-runtime skills share these composition join keys:
- `incident_id` — primary correlation key
- `source_time_window` — time range anchor
- `service_scope` — affected service list
- `evidence_refs` — reference IDs passed between skills
- `contract_version: ops-runtime-runtime-v2.5.0` — version guard

## Composition rules
1. Later skills cite earlier artifacts by `artifact name + evidence_ref`, never by re-running the same analysis.
2. `incident_id` must remain stable across all skills in a single incident. Only `alert-attribution` may create or normalize a new incident_id.
3. Skills emit `downstream_handoff` records that declare `handoff_type`, `required_fields`, `evidence_refs`, `confidence`, and `next_best_checks`.
4. When two skills contradict each other (e.g., log-analysis says service A is healthy, metrics say it is degraded), both findings remain visible with `conflicting` confidence labels — do not suppress contradictions.
5. Circuit breakers are skill-local. A skill that triggers its circuit breaker must emit `exception.ops-runtime.skill_blocked.v2.5.0` and hand off to the incident commander, not to the next ops-runtime skill in the chain.

## Refresh triggers
- If `alert-attribution` re-classifies the root alert, emit `downstream_handoff.refresh_triggers: [monitoring-metric-interpretation, log-analysis]` so those skills can re-consume updated `incident_id` and `source_time_window`.
- If `anomaly-clustering` merges or splits clusters, emit `downstream_handoff.refresh_triggers: [frequent-error-summary, root-cause-analysis-recommendation]`.


---

## Boundary comparison table — monitoring precise

| Dimension | monitoring-metric-interpretation | trace-call-chain-analysis | log-analysis | impact-scope-analysis |
|---|---|---|---|---|
| **Primary question** | "HOW do the metrics behave?" | "WHICH span is causing the latency?" | "WHAT do the logs say?" | "WHO is affected and how badly?" |
| **Input** | Time-series metrics, SLO data, dashboards | Distributed trace spans | Log files and streams | User signals, error rates, business KPIs |
| **Output** | Metric anomaly report, SLO burn rate, trend analysis | Span timing and propagation path | Error patterns and timeline | Affected users, revenue at risk, tier recommendation |
| **Owns** | SLO math, burn rate calculation, metric trend, capacity planning | Span timing, cold start, propagation | Log structure, timeline, novel events | Business impact quantification, tier recommendation |
| **Does not own** | Span-level details (→115) · Log content (→113) · Business impact (→116) | Metric trends (→114) · Log content (→113) | Metric analysis (→114) · Span timing (→115) | Metric analysis (→114) · Log content (→113) |

### Key distinction: 114 vs 116
```
114: "error_rate is 0.89% — that's 2.1× above baseline"
     (metric behavior question)
116: "12,400 users are seeing checkout failures — $96K/h revenue at risk"
     (business impact question)

114 feeds → 116 as evidence for user impact calculation
```