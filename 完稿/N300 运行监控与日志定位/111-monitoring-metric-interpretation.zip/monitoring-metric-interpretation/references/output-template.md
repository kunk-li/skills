# output-template

Use this template as the structural scaffold for producing this skill's artifact. Fill each section with evidence-derived content; never leave required fields empty — use `unable_to_measure`, `unknown`, or `needs_evidence` with a reason instead.

## Top-level structure

```markdown
---
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  node_artifact_target: <artifact-target>
  function_bias: <this-skill-function-bias>
  stage_position: <this-skill-stage-position>
  incident_id: <string | TEMP-ops-runtime-<date>-<source>>
  selected_mode: <allowed-mode>
  readiness: draft | partial | ready
  evidence_profile: <profile-value>
  tool_collaboration_mode: <mode>
  source_time_window:
    start: <iso8601 | unknown>
    end: <iso8601 | unknown>
  service_scope: [<service-names>]
---

## incident_overview
> 2–4 sentence plain-language summary of what happened, when, and which services.
> Always write this section even when readiness is partial.

## [skill-specific sections]
> See SKILL.md Required output sections.
> Every primary row must include all required fields.
> Use `unable_to_measure` + reason when data is unavailable.

## downstream_handoff
> Machine-readable handoff entries per the shared contract schema.
> Include missing_evidence and next_best_checks for every handoff item.

## self_check
> Record pass/fail for each shared V2.5.0 self-check item.
> If any item fails, readiness must be partial or draft.
```

## Field fill guidance

| Situation | Required action |
|---|---|
| No `incident_id` exists | Create `TEMP-ops-runtime-<YYYYMMDD>-<source>` and mark `provisional: true` |
| Evidence is partial | Keep all sections; fill with best estimate + confidence label |
| Metric not measurable | Use `unable_to_measure: true` with `reason` field |
| Hypothesis uncertain | Use `confidence: low` and list what would raise it |
| Sensitive data present | Summarize or hash; never include plaintext PII or credentials |

## Readiness decision guide

| Condition | Readiness |
|---|---|
| All required sections complete, evidence multi-signal, self-check passes | `ready` |
| Some evidence missing, assumptions made, but output is actionable | `partial` |
| Critical required fields cannot be filled without more data | `draft` |


---

## Downstream handoff YAML templates

```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: monitoring-metric-interpretation
  incident_id: "{incident_id}"
  artifact: 监控指标解读.md
  handoffs:
    - target: alert-attribution
      handoff_type: evidence
      summary: "Fast burn (42×) on error_rate confirms root alert classification"
      required_fields: [slo_burn_rate, metric_id, confidence]
      evidence_refs: [metric-M001]
      confidence: high
    - target: bug-analysis
      handoff_type: evidence
      summary: "Metric story: error_rate spike at T+0, latency p99 spike at T+2min — cascade pattern"
      required_fields: [signal_interpretation, anomaly_direction, baseline_reference]
      confidence: medium
      next_best_checks:
        - "Check if latency spike preceded error rate — may indicate upstream dependency failure"
```


---

## Standalone guarantee
This skill runs independently with the minimum evidence listed in this file. Do not refuse output because sibling ops-runtime skills have not been run first. When evidence is absent, declare `readiness: partial` or `readiness: red`, populate all stable output sections with available evidence, and list missing evidence in `downstream_handoff.missing_evidence`.

---

## Output completeness rule
Every artifact from this skill MUST include all of:
- `metadata` with `readiness`, `selected_mode`, `evidence_profile`
- `evidence_profile.confirmed` list ≥ 1 item (or explicit `[]` with missing_evidence explanation)
- `confidence` ∈ {high, medium, low, speculative}
- `downstream_handoff` with ≥ 1 typed `handoff_type` entry
- `self_check.passed` boolean + `self_check.warnings[]` (may be `[]`)
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry
- `emit_event.event_name` matching `produced.ops-runtime.*.v2`

**Hard rule:** `confidence: high` requires `evidence_profile.confirmed` ≥ 3 distinct signal families.

---

## Mode selection

### New: `capacity_planning` mode — 容量规划指标分析
**Trigger:** User asks "will we run out of capacity?", "when do we hit limits?", "capacity forecast for next month", or needs resource utilization trend analysis.

```yaml
capacity_planning:
  planning_horizon: 30d
  metrics_analyzed:
    - metric: cpu_utilization_pct
      current_avg: 62.3
      trend_slope: "+0.8% per day"
      forecast_at_horizon: 86.3
      threshold: 85
      days_to_threshold: 29
      alert: "CPU will exceed 85% threshold in 29 days"
    - metric: db_connection_pool_utilization
      current_avg: 78.1
      trend_slope: "+1.2% per day"
      forecast_at_horizon: 96  # capped
      threshold: 90
      days_to_threshold: 10
      alert: "CONNECTION POOL critical in 10 days — urgent capacity action needed"
  capacity_verdict:
    immediate_action_required: true
    reason: "db_connection_pool will hit 90% in 10 days"
    recommended_action: "Increase connection pool max-size from 100 to 150 this sprint"
  confidence: medium
```
**SCR:** `selected_mode: capacity_planning` → `capacity_planning.planning_horizon` declared; `capacity_verdict.recommended_action` present when `immediate_action_required: true`.