# monitoring framework

## Mandatory signal families
- golden signals: latency, traffic, errors, saturation
- infrastructure use signals: utilization, saturation, errors
- service red signals: rate, errors, duration
- business signals: value, user experience, outcome, health

## Metric tiers
- `T1_SLI`: service level indicators and burn-rate signals
- `T2_KPI`: user or business outcome metrics
- `T3_operational`: infra and service health indicators
- `T4_debug_only`: diagnostic-only metrics that should not drive incident severity alone

## Anomaly judgement methods
- `threshold_based`: fixed safe limit or SLO threshold
- `baseline_based`: comparison to recent healthy period
- `change_point_detection`: abrupt deviation from previous trend
- `composite_alerting`: multiple signals agree

## Boundary with alert-attribution
This skill says whether metric movement is meaningful. `alert-attribution` decides whether alerts are root, symptom, duplicate, suppressed, or routed.
