# field-contract

Canonical field definitions shared across all ops-runtime runtime skill artifacts.

## Core metadata fields
| Field | Type | Required | Description |
|---|---|---|---|
| `contract_version` | string | yes | Must be `ops-runtime-runtime-v2.5.0` |
| `artifact_schema_name` | string | yes | Unique schema name for this skill's output |
| `artifact_schema_version` | string | yes | Semantic version matching the skill package |
| `workflow_node` | string | yes | Always `ops-runtime` |
| `artifact_type` | string | yes | Snake_case artifact type identifier |
| `incident_id` | string | yes | Stable incident identifier; only `alert-attribution` may create/normalize |
| `selected_mode` | string | yes | One of the declared allowed modes |
| `readiness` | enum | yes | `draft` \| `partial` \| `ready` \| `amber` \| `red` \| `green` |
| `evidence_profile` | object | yes | `confirmed`, `assumed`, `missing_evidence`, `missing_evidence_impact` |
| `source_time_window` | object | yes | `start` (iso8601 or `unknown`), `end` (iso8601 or `unknown`) |
| `service_scope` | string[] | yes | Affected service list |

## Evidence reference fields
| Field | Type | Required | Description |
|---|---|---|---|
| `ref_id` | string | yes | Unique reference identifier |
| `source_family` | enum | yes | `metric` \| `log` \| `trace` \| `alert` \| `deployment` \| `test` \| `user_report` \| `manual_note` |
| `source_name` | string | yes | Name of the source system or file |
| `time_window` | string | yes | ISO duration or timestamp range |
| `confidence` | enum | yes | `high` \| `medium` \| `low` \| `speculative` |

## Downstream handoff fields
| Field | Type | Required | Description |
|---|---|---|---|
| `handoff_type` | enum | yes | `evidence` \| `hypothesis` \| `scope` \| `routing` \| `pattern` \| `gap` \| `action_hint` |
| `required_fields` | string[] | yes | Fields the receiving skill must consume |
| `evidence_refs` | string[] | yes | `ref_id` values supporting this handoff |
| `confidence` | enum | yes | Confidence level of this handoff entry |
| `missing_evidence` | string[] | yes | Evidence that would improve this handoff |
| `next_best_checks` | string[] | yes | Recommended next investigation steps |

## Confidence-to-evidence mapping
| Evidence sources | Max confidence |
|---|---|
| 0 sources | `speculative` |
| 1 source (any family) | `low` |
| 2 consistent sources (same family) | `medium` |
| 2+ sources (different families, consistent) | `high` |
| 3+ sources (multi-family, consistent) | `high` |


---

## Field contract — signal_interpretation row

| Field | Required | Values / notes |
|---|---|---|
| `metric_id` | yes | stable ID e.g. `M-001` |
| `metric_name` | yes | canonical metric name |
| `anomaly_direction` | yes | `spike` / `drop` / `elevated` / `sustained_high` / `stable` |
| `magnitude` | yes | absolute or relative value vs baseline |
| `baseline_reference` | yes | baseline value or `no_baseline_available` |
| `slo_burn_contribution` | yes | `primary` / `contributing` / `none` / `unknown` |
| `confidence` | yes | `high` / `medium` / `low` / `speculative` |