# real-examples

These examples illustrate how to produce this skill's artifact under different evidence conditions. Use them as output calibration references — not as templates to copy verbatim.

## Example 1: Minimum viable input (readiness: partial)

**Scenario:** Single metric spike, no logs or traces available.

**Input given:**
- Service: `payment-service`
- Signal: `http_error_rate` jumped from 0.3% to 12% at 14:32 UTC
- No trace data, no log access

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  evidence_profile: metrics_only
  incident_id: TEMP-ops-runtime-20240315-payment-metric
evidence_profile:
  missing_evidence:
    - structured logs for error classification
    - trace ids to correlate request path
  next_best_checks:
    - pull error log sample from payment-service for 14:30–14:40 UTC
    - check recent deployment or config change in this window
```

**Key calibration:** Output must not invent error causes. State "elevated error rate observed; cause undetermined pending log/trace evidence."

---

## Example 2: Rich multi-signal input (readiness: ready)

**Scenario:** Alert storm with logs and partial traces available.

**Input given:**
- Alert: `payment-service SLO burn rate 14× budget`
- Log sample: 3,200 lines of `NullPointerException` in `PaymentProcessor.java:142`
- Trace: 2 trace IDs showing 8s p99 at `db-connection-pool`
- Recent change: DB connection pool size reduced from 100→20 at 14:15 UTC

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  evidence_profile: multi_signal
recommended_finding:
  hypothesis_id: H1
  statement: "Connection pool exhaustion caused by config change at 14:15 UTC"
  confidence: high
  supporting_evidence_refs: [alert-001, log-finding-3, trace-T1, trace-T2]
  contradicting_evidence_refs: []
```

**Key calibration:** Confidence "high" requires at least 2 corroborating signal families AND a plausible causal mechanism.

---

## Example 3: Conflicting evidence (readiness: partial)

**Scenario:** Logs point to DB; metrics show CPU spike on app tier.

**Expected output shape:**
```yaml
hypothesis_testing:
  - hypothesis_id: H1
    statement: "DB connection exhaustion is root cause"
    confidence: medium
    supporting_evidence_refs: [log-finding-1]
    contradicting_evidence_refs: [metric-cpu-001]
    status: unresolved — conflicting signals
  - hypothesis_id: H2
    statement: "App-tier CPU spike caused downstream DB timeouts"
    confidence: low
    supporting_evidence_refs: [metric-cpu-001]
    contradicting_evidence_refs: [log-finding-1]
    status: unresolved
recommended_root_cause:
  statement: "Insufficient evidence to choose between H1 and H2"
  next_best_checks:
    - capture JVM thread dump from app tier during next occurrence
    - check DB slow query log for same window
```

**Key calibration:** Never collapse conflicting hypotheses into a single confident conclusion. Keep both visible.

---

## Example 4: SLO burn rate — fast burn detected, page required

**Scenario:** error_rate SLO: target 99.9% (0.1% error budget). Current 1h window: 4.2% error rate.

**Expected behavior:**
- Compute burn rate: 4.2% / 0.1% = 42×.
- At 42× burn rate, 30-day budget exhausted in ~17 hours.
- Classify as fast-burn page-level event.

```yaml
slo_analysis:
  slo_name: payment-service-availability
  slo_target_pct: 99.9
  error_budget_pct: 0.1
  current_error_rate_pct: 4.2
  burn_rate: 42
  budget_exhaustion_at_current_rate: "17h"
  classification: fast_burn
  action: page_oncall_immediately
  confidence: high
signal_interpretation:
  - metric_id: M-001
    metric_name: error_rate
    anomaly_direction: spike
    magnitude: "42× budget consumption"
    baseline_reference: "0.3% (7-day p95)"
    slo_burn_contribution: primary
downstream_handoff:
  urgency: immediate
  next_best_checks:
    - "alert-attribution: identify root alert cluster for this error rate spike"
    - "log-analysis: extract error signatures from payment-service logs"
```

**Key calibration:** Fast burn (>14×) always means `page_oncall_immediately`. Never downgrade urgency because the absolute error rate looks small in percentage terms — the burn multiple is what matters.

---

## Example 5: monitoring gap — metric exists but baseline unavailable

**Scenario:** New service `recommendation-engine` deployed 3 days ago. No 7-day baseline available.

**Expected behavior:**
- Declare `monitoring_quality: insufficient_baseline`.
- Provide directional signal interpretation only.
- Recommend establishing baseline before next release.

```yaml
metadata:
  readiness: partial
slo_analysis:
  slo_burn_rate: unable_to_measure
  reason: "Service deployed 3 days ago. Minimum 7-day baseline not available."
signal_interpretation:
  - metric_id: M-001
    metric_name: latency_p99
    anomaly_direction: elevated
    magnitude: "280ms (no baseline to compare)"
    confidence: low
    note: "Directional only — no baseline anchor"
monitoring_quality:
  assessment: insufficient_baseline
  baseline_available_in: "4 days (7-day minimum)"
  recommendation: "Monitor manually for 4 more days before automated SLO evaluation"
downstream_handoff:
  missing_evidence: [metric_baseline, slo_definition]
  next_best_checks:
    - "Set SLO definition for recommendation-engine after 7-day baseline established"
```

**Key calibration:** `unable_to_measure` with a clear reason is correct — do not substitute a made-up baseline or extrapolate from 3 days of data.

---

## Example 6: Chinese-language output

**Scenario:** User writes in Chinese: "支付服务的错误率在过去10分钟从0.2%跳到了4.5%，请分析一下"

**Expected output (Chinese prose, English YAML field names):**
```yaml
metadata:
  readiness: amber
  selected_mode: raw_metric
  output_language: zh-CN
slo_analysis:
  slo_burn_rate: 22.5  # 4.5% / 0.2% = 22.5×
  classification: fast_burn
  action: page_oncall_immediately
signal_interpretation:
  - metric_id: M-001
    metric_name: error_rate
    anomaly_direction: spike
    magnitude: "22.5× SLO budget consumption"
    baseline_reference: "0.2% (10min前基线)"
    confidence: high
    # 中文说明段落:
    interpretation_zh: "错误率从0.2%骤升至4.5%，SLO燃烧率达22.5×。按此速率，30天错误预算将在约32小时内耗尽。需立即介入。"
downstream_handoff:
  urgency: immediate
  next_best_checks:
    - "alert-attribution: 识别告警风暴根因告警"
    - "log-analysis: 提取支付服务错误日志（过去10分钟）"
```

**Key calibration:** YAML field names stay in English. Prose sections (`interpretation_zh`, `next_best_checks`) follow user language. SLO calculation is language-agnostic.


---

## Scenario calibration
See `references/real-examples.md` for annotated scenarios covering green (full evidence), amber (partial evidence with degradation), and red (hard-blocker) paths.

For output field definitions, see `references/field-contract.md`.
For quality-gate rules, see `references/quality-checklist.md`.
For failure-mode handling, see `references/failure-modes.md`.
For shared ops-runtime execution contract, see `references/ops-runtime-shared-contract.md`.