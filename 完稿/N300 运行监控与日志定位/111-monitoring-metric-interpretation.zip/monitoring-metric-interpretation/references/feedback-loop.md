# feedback loop protocol — ops-runtime

## Retrospective integration
After each incident closes, compare skill output vs actual resolution findings.

### Signal types and actions
| Signal | Trigger | Action |
|---|---|---|
| `false_positive` | Flagged anomaly was normal variation | Tighten threshold; add calibration example |
| `false_negative` | Missed real anomaly | Add detection rule; file patch bump |
| `wrong_confidence` | Confidence label didn't match outcome | Update confidence_ceiling_rule |
| `correct` | Output matched actual incident finding | Add green-path example to real-examples.md |

## feedback_signal_candidates schema
```yaml
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: correct | false_positive | false_negative | wrong_confidence
    description: "What to verify post-incident"
    verification_method: "Compare output prediction to post-mortem finding"
    priority: P1 | P2
    status: pending
```

## Version bump triggers
- 3+ `false_negative` same detection pattern → patch; tighten SCR
- New signal type (eBPF, continuous profiling) → minor; add evidence_profile field
- Output schema breaking change → major; migration guide required


---

## Feedback loop — advanced integration (v2)

### Signal-type differentiated handling

| Signal type | Immediate action | Update target | Owner |
|---|---|---|---|
| `false_positive` | Open P2 ticket; mark in `real-examples.md` as "flagged FP" | Add calibration note to relevant SCR rule | Skill maintainer |
| `false_negative` | Open P1 ticket; investigate evidence gap | Add new scenario to `real-examples.md`; tighten field contract | Skill maintainer + incident owner |
| `missed_evidence` | Document the missed source in `references/failure-modes.md` | Add new input tier to `## Large input handling` | Skill maintainer |
| `wrong_confidence` | Update `confidence_ceiling_rule` in field contract | Re-run SCR-MONITORI-001 equivalents against historical artifacts | Skill maintainer |
| `slow_resolution` | Profile which output section delayed the decision | Simplify that section; add a `quick_triage` mode if not present | Skill maintainer |
| `correct` | Add to `real-examples.md` as a calibration green-path example | Consider as regression baseline for future changes | Skill maintainer |

### Postmortem auto-mapping rule
When a postmortem skill (or manual RCA document) references an artifact from this skill, apply this mapping automatically:

```yaml
postmortem_integration:
  trigger: "postmortem references artifact_id from this skill"
  auto_actions:
    - action: extract_feedback_signals
      source: "postmortem.findings[].related_artifact_id == this.artifact_id"
      output: "feedback_signal_candidates[] with signal_type auto-classified"
    - action: update_real_examples
      condition: "signal_type in [false_negative, correct]"
      target: "references/real-examples.md"
    - action: open_scr_review_ticket
      condition: "signal_type in [false_positive, wrong_confidence]"
      ticket_template: "SCR review: {skill_id} produced {signal_type} in incident {incident_id}"
```

### Full retrospective YAML flow
After every incident where this skill was invoked, execute this flow:

```yaml
retrospective_flow:
  step_1_collect:
    action: "Query artifact store for all outputs from this skill during incident_id"
    tool: "artifact registry or conversation history"
    output: "artifact_list[]"

  step_2_evaluate:
    action: "For each artifact, compare recommended hypothesis/action vs actual outcome"
    criteria:
      - "Was the top hypothesis confirmed by post-incident RCA?"
      - "Were immediate actions sufficient to contain the incident?"
      - "Were evidence gaps listed in downstream_handoff.missing_evidence actually missing?"
    output: "signal_type classification per artifact"

  step_3_update:
    condition: "signal_type confirmed"
    actions:
      false_negative:
        - "Add new scenario to references/real-examples.md"
        - "Add new SCR rule to detect this gap"
        - "File patch upgrade ticket (v2.5.x bump)"
      correct:
        - "Add to references/real-examples.md as green-path calibration"
        - "No version bump required"
      false_positive:
        - "Review confidence_ceiling_rule for affected field"
        - "Add 'calibration note' to the relevant example"

  step_4_close:
    action: "Mark feedback_signal_candidates[].status: verified | deferred"
    output: "Updated artifact with verification timestamps"
```

### feedback_signal_candidates SCR rule
```yaml
# SCR-FEEDBACK: Every artifact must include at least 1 feedback_signal_candidates entry
# If evidence is thin → default to wrong_confidence signal
# If output is confident → add correct signal for future calibration
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: wrong_confidence  # default for partial-evidence artifacts
    description: "Verify hypothesis against post-incident RCA"
    verification_method: "Compare top hypothesis to confirmed root cause in postmortem"
    downstream_skill: root-cause-analysis-recommendation  # or relevant postmortem skill
    priority: P1
    status: pending  # updated to 'verified' or 'deferred' post-incident
```
