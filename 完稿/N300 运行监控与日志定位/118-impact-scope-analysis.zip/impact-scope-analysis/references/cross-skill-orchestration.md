# cross-skill-orchestration

Describes how the nine ops-runtime skills collaborate in multi-signal incident diagnosis.

## Canonical combination paths

### Alert-first (most common)
```
alert-attribution
  → monitoring-metric-interpretation  (metric anomaly confirmation)
  → log-analysis                       (log evidence gathering)
  → trace-call-chain-analysis          (call path reconstruction)
  → bug-analysis                       (fast symptom triage)
  → root-cause-analysis-recommendation (evidence-chained RCA)
  → impact-scope-analysis              (blast radius quantification)
```

### Metric-first
```
monitoring-metric-interpretation
  → alert-attribution        (alert dedup and routing)
  → trace-call-chain-analysis (latency/error path drilldown)
  → impact-scope-analysis     (SLO burn → user impact)
  → root-cause-analysis-recommendation
```

### Log-first
```
log-analysis
  → anomaly-clustering        (pattern deduplication)
  → frequent-error-summary    (error ranking)
  → bug-analysis              (triage framing)
  → root-cause-analysis-recommendation
```

## Join keys for composition
All ops-runtime skills share these composition join keys:
- `incident_id` — primary correlation key
- `source_time_window` — time range anchor
- `service_scope` — affected service list
- `evidence_refs` — reference IDs passed between skills
- `contract_version: ops-runtime-runtime-v2.5.0` — version guard

## Composition rules
1. Later skills cite earlier artifacts by `artifact name + evidence_ref`, never by re-running the same analysis.
2. `incident_id` must remain stable across all skills in a single incident. Only `alert-attribution` may create or normalize a new incident_id.
3. Skills emit `downstream_handoff` records that declare `handoff_type`, `required_fields`, `evidence_refs`, `confidence`, and `next_best_checks`.
4. When two skills contradict each other (e.g., log-analysis says service A is healthy, metrics say it is degraded), both findings remain visible with `conflicting` confidence labels — do not suppress contradictions.
5. Circuit breakers are skill-local. A skill that triggers its circuit breaker must emit `exception.ops-runtime.skill_blocked.v2.5.0` and hand off to the incident commander, not to the next ops-runtime skill in the chain.

## Refresh triggers
- If `alert-attribution` re-classifies the root alert, emit `downstream_handoff.refresh_triggers: [monitoring-metric-interpretation, log-analysis]` so those skills can re-consume updated `incident_id` and `source_time_window`.
- If `anomaly-clustering` merges or splits clusters, emit `downstream_handoff.refresh_triggers: [frequent-error-summary, root-cause-analysis-recommendation]`.


---

## Boundary comparison table — impact-scope-analysis

| Dimension | impact-scope-analysis | alert-attribution | root-cause-analysis-recommendation | on-call-response-recommendation |
|---|---|---|---|---|
| **Primary question** | "WHO and WHAT is affected?" | "WHICH service triggered this alert?" | "WHY did this happen?" | "What do responders do NOW?" |
| **Output type** | Scope map: affected users/services/regions + revenue impact estimate | Attribution: signal→service causality chain | Causal chain: five-why + hypothesis ranking | Timed response sequence + tier classification |
| **Timing** | During incident (T+5min, as soon as impact signal available) | At alert detection (T+0) | Parallel with response (T+0 onward, may take hours) | T+0 to T+15min (immediate response) |
| **Owns** | User count, revenue impact, SLA blast radius, tier recommendation | Alert-to-service attribution, signal clustering | Root cause hypothesis, five-why analysis, prevention | Response steps, incident command, containment |
| **Does not own** | Root cause (→119), alert attribution (→111), response steps (→120) | Impact scope (→116), root cause (→119) | Impact scope (→116), attribution (→111), response (→120) | Impact scope (→116), root cause (→119) |

### When to call 116 vs its neighbors
```
"How many users are affected?"         → 116 ✓
"Which service is causing the alert?"  → 111 (alert-attribution)
"Why is this happening?"               → 119 (root-cause-analysis)
"What revenue are we losing?"          → 116 ✓ (business_kpi_impact mode)
"Should we escalate to T1?"            → 116 feeds → 120 tier recommendation
"What do we do right now?"             → 120 (on-call-response)
```