# failure-modes — impact-scope-analysis

Common failure modes for `影响范围分析.md` and how to handle them.

## FM01: No evidence provided — symptom description only
- **Symptom:** Only a text description; no logs, metrics, traces, or structured data.
- **Impact:** All findings are speculative. Confidence ceiling: low.
- **Handling:** Produce artifact with `readiness: partial`, all hypotheses at `confidence: speculative`. List required evidence in `downstream_handoff.missing_evidence`. Do not refuse output.

## FM02: Single signal family — cannot cross-validate
- **Symptom:** Only one evidence type available (e.g., logs only, no metrics or traces).
- **Impact:** Confidence ceiling: low. Cannot confirm or contradict findings.
- **Handling:** Set `evidence_profile.source_family_coverage: single`. Cap all findings at `confidence: low`. Recommend second signal family in `downstream_handoff.next_best_checks`.

## FM03: Timestamps missing or inconsistent timezone
- **Symptom:** Events have no timestamps or mixed timezones.
- **Impact:** Time correlation and time-window normalization unreliable.
- **Handling:** Normalize to UTC; set `timestamp_assumption: utc_assumed` if timezone unknown. Bucket at coarsest granularity. Document under normalization notes.

## FM04: Circuit breaker triggered — skill invoked ≥3 times without resolution
- **Symptom:** `metadata.iter_count >= max_iter` and readiness still `partial`.
- **Impact:** Further regeneration will not resolve the issue without new evidence.
- **Handling:** Stop regeneration. Set `readiness: red`. Emit `exception.ops-runtime.skill_blocked.v2.5.0`. Escalate to incident-commander. Reset only when new `evidence_refs` are provided.

## FM05: Sensitive data (PII / secrets) detected in evidence
- **Symptom:** Raw log lines contain email addresses, passwords, tokens, or PII.
- **Impact:** Cannot include raw data in artifact without violating data handling policy.
- **Handling:** Redact before analysis. Reference by `evidence_ref` id, not raw content. Set `pii_risk: detected` in the relevant finding. Note in `self_check.failed_rules` if redaction is incomplete.

## FM06: Downstream skill unavailable — cannot hand off
- **Symptom:** Target skill in `downstream_handoff` is not reachable or not invoked.
- **Impact:** Composed workflow stalls.
- **Handling:** Emit `downstream_handoff` with `urgency: deferred` and list the missing context. The current artifact remains valid as a standalone output. Do not retry indefinitely.


---

## Degradation examples

### readiness: amber — 有用户投诉但无指标，用户数量不可计算

```yaml
metadata:
  readiness: amber
  selected_mode: quick_triage
evidence_profile:
  confirmed: [user_complaint_count]
  missing_evidence: [error_rate_metric, session_data, payment_logs]
  missing_evidence_impact: "User count estimated from complaint rate only. True affected count unknown."
  confidence_ceiling_applied: low
impact_assessment:
  affected_users_estimate:
    method: complaint_extrapolation
    value: "~500-2000 (high uncertainty)"
    confidence: low
    note: "Provide error rate + session data for accurate count"
  revenue_impact_estimate:
    value: unknown
    missing_evidence: [transaction_data, conversion_metrics]
tier_recommendation:
  recommended_tier: T2
  basis: complaint_count_only
  confidence: low
  upgrade_condition: "Provide session data to confirm tier"
self_check:
  passed: true
  warnings:
    - "amber — user count estimated from complaints only; uncertainty high"
    - "Upgrade: provide error_rate + session data for accurate impact"
```

### readiness: red — 确认 T1，收入损失超阈值

```yaml
metadata:
  readiness: red
evidence_profile:
  confirmed: [checkout_conversion_rate, error_rate, session_data]
  confidence_ceiling_applied: high
impact_assessment:
  affected_users:
    value: 12400
    confidence: high
  revenue_at_risk_per_hour:
    value: "$96,480"
    confidence: medium
    calculation: "12400 × $47 avg_order × 0.166 conversion_gap = $96,480/h"
tier_recommendation:
  recommended_tier: T1
  escalation_required: true
  page_oncall: true
  basis: revenue_threshold_exceeded
downstream_handoff:
  handoffs:
    - target: on-call-response-recommendation
      handoff_type: routing
      urgency: immediate
      summary: "T1 confirmed: 12,400 users affected, $96K/h revenue at risk"
self_check:
  passed: false
  failed_rules: ["T1 threshold exceeded — immediate escalation mandatory"]
```