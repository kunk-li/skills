## Mock input fixture

```yaml
mock_input:
  scenario: "minimum_evidence"
  content: "service name and one symptom description"
  expected_output_shape:
    metadata:
      readiness: partial
    downstream_handoff:
      missing_evidence: present
    self_check:
      passed: false  # partial evidence = self_check fails on completeness rules
      warnings: present

mock_input_2:
  scenario: "rich_evidence"
  content: "multi-signal: alerts + logs + metrics + recent change"
  expected_output_shape:
    metadata:
      readiness: ready
    self_check:
      passed: true
```
