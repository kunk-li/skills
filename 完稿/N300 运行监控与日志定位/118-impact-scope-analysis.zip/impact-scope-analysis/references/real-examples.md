# real-examples

These examples illustrate how to produce this skill's artifact under different evidence conditions. Use them as output calibration references — not as templates to copy verbatim.

## Example 1: Minimum viable input (readiness: partial)

**Scenario:** Single metric spike, no logs or traces available.

**Input given:**
- Service: `payment-service`
- Signal: `http_error_rate` jumped from 0.3% to 12% at 14:32 UTC
- No trace data, no log access

**Expected output shape:**
```yaml
metadata:
  readiness: partial
  evidence_profile: metrics_only
  incident_id: TEMP-ops-runtime-20240315-payment-metric
evidence_profile:
  missing_evidence:
    - structured logs for error classification
    - trace ids to correlate request path
  next_best_checks:
    - pull error log sample from payment-service for 14:30–14:40 UTC
    - check recent deployment or config change in this window
```

**Key calibration:** Output must not invent error causes. State "elevated error rate observed; cause undetermined pending log/trace evidence."

---

## Example 2: Rich multi-signal input (readiness: ready)

**Scenario:** Alert storm with logs and partial traces available.

**Input given:**
- Alert: `payment-service SLO burn rate 14× budget`
- Log sample: 3,200 lines of `NullPointerException` in `PaymentProcessor.java:142`
- Trace: 2 trace IDs showing 8s p99 at `db-connection-pool`
- Recent change: DB connection pool size reduced from 100→20 at 14:15 UTC

**Expected output shape:**
```yaml
metadata:
  readiness: ready
  evidence_profile: multi_signal
recommended_finding:
  hypothesis_id: H1
  statement: "Connection pool exhaustion caused by config change at 14:15 UTC"
  confidence: high
  supporting_evidence_refs: [alert-001, log-finding-3, trace-T1, trace-T2]
  contradicting_evidence_refs: []
```

**Key calibration:** Confidence "high" requires at least 2 corroborating signal families AND a plausible causal mechanism.

---

## Example 3: Conflicting evidence (readiness: partial)

**Scenario:** Logs point to DB; metrics show CPU spike on app tier.

**Expected output shape:**
```yaml
hypothesis_testing:
  - hypothesis_id: H1
    statement: "DB connection exhaustion is root cause"
    confidence: medium
    supporting_evidence_refs: [log-finding-1]
    contradicting_evidence_refs: [metric-cpu-001]
    status: unresolved — conflicting signals
  - hypothesis_id: H2
    statement: "App-tier CPU spike caused downstream DB timeouts"
    confidence: low
    supporting_evidence_refs: [metric-cpu-001]
    contradicting_evidence_refs: [log-finding-1]
    status: unresolved
recommended_root_cause:
  statement: "Insufficient evidence to choose between H1 and H2"
  next_best_checks:
    - capture JVM thread dump from app tier during next occurrence
    - check DB slow query log for same window
```

**Key calibration:** Never collapse conflicting hypotheses into a single confident conclusion. Keep both visible.

---

## Example 4: Multi-dimensional quantification — revenue + compliance + SLO

**Scenario:** Payment service outage with confirmed user impact, revenue loss, and GDPR data exposure risk.

```yaml
metadata:
  readiness: ready
  selected_mode: full_scope
blast_radius:
  affected_users_estimate: 8420
  estimation_method: transaction_log_count
  confidence: high
  affected_services: [payment-service, checkout-service, notification-service]
  affected_journeys: [checkout_flow, subscription_renewal]
  slo_burn_rate: 38.5
  slo_burn_label: critical_fast_burn
revenue_impact:
  method: "affected_transactions × avg_transaction_value × failure_rate"
  calculation: "8420 × $47 × 0.34 = $134,500 (estimated revenue at risk)"
  confidence: medium
  currency: USD
  assumption: "34% of affected users attempted checkout; avg basket $47"
compliance_scope:
  pii_exposed: false
  pii_exposure_risk: low
  gdpr_article_applicable: "Article 33 — not triggered (no breach; availability issue only)"
  compliance_notification_required: false
  note: "Payment data isolated in payment-service vault; not exposed to checkout-service"
temporal_evolution:
  t_plus_0:   {affected_users: 0, slo_burn: 0}
  t_plus_15m: {affected_users: 1200, slo_burn: 8}
  t_plus_30m: {affected_users: 4800, slo_burn: 22}
  t_plus_45m: {affected_users: 8420, slo_burn: 38.5}
notification_scope:
  roles_to_notify: [sre-oncall, engineering-vp, finance-controller, customer-success]
  customer_comms_required: true
  comms_template_ref: "status-page-template-payment-outage"
downstream_handoff:
  to_skill: on-call-response-recommendation
  tier_recommendation: T1   # revenue > $100K threshold
self_check:
  passed: true
```

**Key calibration:** Revenue impact always needs `method`, `calculation`, `confidence`, and `assumption`. Never use vague language like "significant revenue loss" — use a number with confidence level and stated assumptions.


---

## Scenario calibration
See `references/real-examples.md` for annotated scenarios covering green (full evidence), amber (partial evidence with degradation), and red (hard-blocker) paths.

For output field definitions, see `references/field-contract.md`.
For quality-gate rules, see `references/quality-checklist.md`.
For failure-mode handling, see `references/failure-modes.md`.
For shared ops-runtime execution contract, see `references/ops-runtime-shared-contract.md`.