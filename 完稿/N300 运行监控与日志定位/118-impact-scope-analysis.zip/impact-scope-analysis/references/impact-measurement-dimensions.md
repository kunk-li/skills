# impact measurement dimensions

Use quantified scope where possible.

## Core dimensions
- users and user segments
- functions or journeys
- services, components, dependencies, and regions
- data records, integrity, loss, duplicates, or inconsistency
- revenue, refunds, support cost, customer satisfaction
- compliance exposure and notification triggers
- temporal scope, peak, recovery, and residual effects

Every numeric claim should cite its data source or say `unable_to_measure`.

## Confidence values
- `exact`
- `estimate`
- `bounded`
- `unable_to_measure`
