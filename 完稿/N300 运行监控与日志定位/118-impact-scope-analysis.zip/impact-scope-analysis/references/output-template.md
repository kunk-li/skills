# output-template

Use this template as the structural scaffold for producing this skill's artifact. Fill each section with evidence-derived content; never leave required fields empty — use `unable_to_measure`, `unknown`, or `needs_evidence` with a reason instead.

## Top-level structure

```markdown
---
metadata:
  contract_version: ops-runtime-runtime-v2.5.0
  workflow_node: ops-runtime
  node_artifact_target: <artifact-target>
  function_bias: <this-skill-function-bias>
  stage_position: <this-skill-stage-position>
  incident_id: <string | TEMP-ops-runtime-<date>-<source>>
  selected_mode: <allowed-mode>
  readiness: draft | partial | ready
  evidence_profile: <profile-value>
  tool_collaboration_mode: <mode>
  source_time_window:
    start: <iso8601 | unknown>
    end: <iso8601 | unknown>
  service_scope: [<service-names>]
---

## incident_overview
> 2–4 sentence plain-language summary of what happened, when, and which services.
> Always write this section even when readiness is partial.

## [skill-specific sections]
> See SKILL.md Required output sections.
> Every primary row must include all required fields.
> Use `unable_to_measure` + reason when data is unavailable.

## downstream_handoff
> Machine-readable handoff entries per the shared contract schema.
> Include missing_evidence and next_best_checks for every handoff item.

## self_check
> Record pass/fail for each shared V2.5.0 self-check item.
> If any item fails, readiness must be partial or draft.
```

## Field fill guidance

| Situation | Required action |
|---|---|
| No `incident_id` exists | Create `TEMP-ops-runtime-<YYYYMMDD>-<source>` and mark `provisional: true` |
| Evidence is partial | Keep all sections; fill with best estimate + confidence label |
| Metric not measurable | Use `unable_to_measure: true` with `reason` field |
| Hypothesis uncertain | Use `confidence: low` and list what would raise it |
| Sensitive data present | Summarize or hash; never include plaintext PII or credentials |

## Readiness decision guide

| Condition | Readiness |
|---|---|
| All required sections complete, evidence multi-signal, self-check passes | `ready` |
| Some evidence missing, assumptions made, but output is actionable | `partial` |
| Critical required fields cannot be filled without more data | `draft` |


---

## Downstream handoff YAML templates

```yaml
downstream_handoff:
  contract_version: ops-runtime-runtime-v2.5.0
  produced_by: impact-scope-analysis
  incident_id: "{incident_id}"
  artifact: 影响范围分析.md
  handoffs:
    - target: on-call-response-recommendation  # cross-node: ops-runtime → incident-response
      handoff_type: scope
      summary: "Blast radius: 3,200 affected users; revenue at risk: $12K; SLO burn: 42×"
      required_fields: [affected_users_estimate, revenue_impact_estimate, slo_burn_rate, notification_scope]
      evidence_refs: [metric-M001, transaction-log-sample]
      confidence: high
      missing_evidence: []
      next_best_checks:
        - "Use blast radius to classify incident tier (T1 if revenue >$50K)"
    - target: root-cause-analysis-recommendation
      handoff_type: scope
      summary: "Affected services: [payment-service, auth-service]; compliance scope: PII not exposed"
      required_fields: [affected_services, compliance_scope]
      confidence: medium
```


---

## Standalone guarantee
This skill runs independently with the minimum evidence listed in this file. Do not refuse output because sibling ops-runtime skills have not been run first. When evidence is absent, declare `readiness: partial` or `readiness: red`, populate all stable output sections with available evidence, and list missing evidence in `downstream_handoff.missing_evidence`.

---

## Output completeness rule
Every artifact from this skill MUST include:
- `metadata` with `readiness`, `selected_mode`, `evidence_profile`, `schema_version`
- `evidence_profile.confirmed` ≥ 1 item; if empty → `readiness: partial` always
- `confidence` ∈ {high, medium, low, speculative} — never absent
- `downstream_handoff` with ≥ 1 typed `handoff_type` entry
- `self_check.passed` boolean + `self_check.warnings[]`
- `adversarial_detection.injection_attempt_detected` boolean
- `feedback_signal_candidates` ≥ 1 entry with `signal_type`
- `emit_event.event_name` matching `produced.ops-runtime.*.v2`

**Hard rules:**
- `confidence: high` requires ≥ 3 distinct signal families in `evidence_profile.confirmed`
- `readiness: ready` requires `self_check.passed: true`
- Any `readiness: red` requires `self_check.failed_rules` non-empty

---

## Mode selection

### New: `slo_burn_analysis` mode — SLO 燃烧率影响分析
**Trigger:** User asks "how much SLO budget are we burning?", "will we breach SLO?", "SLO risk from this incident".

```yaml
slo_burn_analysis:
  slo_target: 99.9   # %
  measurement_window: 30d
  incident_start: "2026-05-21T14:00:00Z"
  incident_duration_min: 47
  error_rate_during_incident: 4.2
  slo_budget_total_min: 43.2
  budget_burned_this_incident:
    value: 0.7  # minutes of downtime attributed to this incident
    pct_of_monthly_budget: 1.6
    confidence: high
  budget_burned_this_month_so_far: 28.4  # minutes
  remaining_budget_min: 14.8
  slo_breach_risk:
    current: low
    projected_at_current_burn_rate: "2026-06-03"
    risk_level: medium
  recommended_action: "Resolve within 2 hours to avoid elevated SLO risk"
  confidence: high
```
**SCR:** `selected_mode: slo_burn_analysis` → `slo_burn_analysis.slo_target` numeric; `slo_breach_risk.risk_level` ∈ {low, medium, high, critical}.