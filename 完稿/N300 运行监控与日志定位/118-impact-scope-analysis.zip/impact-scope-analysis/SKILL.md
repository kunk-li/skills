---
name: impact-scope-analysis
description: quantify incident impact scope for n300 incidents. use for affected users, journeys, services, dependencies, data records, revenue, compliance exposure, temporal evolution, confidence labels, and notification evidence. produce 影响范围分析.md and hand response decisions to n310.
---
# impact-scope-analysis

## Purpose
Use this skill in the N300 runtime monitoring and incident-diagnosis node to produce `影响范围分析.md`. The skill is standalone: it can work with the minimum evidence listed below, and it becomes stronger when combined through the shared N300 contract.

## V2.5.0 optimization note
This version uses `references/n300-shared-runtime-contract.md` as the common source for execution workflow, input handling, self-check, incident id rules, evidence references, downstream handoff schema, and combination paths. Keep this SKILL.md focused on the skill-specific boundary, modes, minimum inputs, output sections, and consumers.

## V2.5.0 encapsulation baseline
This release keeps one contract version across SKILL.md metadata, output-contract.yaml, and references/n300-shared-runtime-contract.md. The skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside each skill plus the artifacts exchanged through downstream_handoff.

## Scope boundary
- Own: quantified scope estimation across users services data business and time.
- Artifact target: `影响范围分析.md`.
- Boundary: measure blast radius and confidence; do not decide remediation strategy, legal stance, or customer message approval.
- Do not perform N310 remediation execution or N320 postmortem authorship unless explicitly asked to create a handoff draft.

## Mode selection
Always declare `selected_mode`, `readiness`, `evidence_profile`, `incident_id`, and `contract_version` before the main findings.

Allowed modes:
- `quick_assess`
- `deep_analysis`
- `continuous_tracking`
- `compliance_reporting`

## Standalone minimum viable input
This skill can run with only:
- incident symptom or signal
- time window
- one source for affected entities such as logs, metrics, traces, user reports, or transaction data

When evidence is partial, keep the output structure stable, lower `readiness`, and list missing evidence in `downstream_handoff.missing_evidence`.


## Standalone and composition role
```yaml
standalone_guarantee: "Quantify incident scope from a signal and time window across users, journeys, services, data, revenue, compliance, and temporal evolution even with partial evidence."
composition_role: "blast_radius_quantifier"
composition_leverage: "Combines metric/log/trace/RCA evidence into defensible impact estimates, confidence labels, notification inputs, and N310/N320/customer-support handoff."
best_combines_with: ["N310", "N320", "customer-support", "compliance", "root-cause-analysis-recommendation"]
standalone_readiness_floor: partial
composition_join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - evidence_refs
```

When this skill is run alone, produce `影响范围分析.md` without waiting for sibling artifacts. When it is run in a composed N300 path, consume earlier artifacts only through `downstream_handoff` and `evidence_refs`, then emit a stronger handoff for the next skill.

## Input handling
Follow `V2.5.0 common input handling` in `references/n300-shared-runtime-contract.md`. Use optional evidence only to strengthen this skill's own artifact, not to perform sibling-skill work.
## Execution workflow
Follow `V2.5.0 common execution workflow` in `references/n300-shared-runtime-contract.md`, then apply the skill-specific required sections and design rules below.
## Required output sections
Every output must include:
- `metadata`
- `incident_overview`
- `scope_dimensions`
- `quantified_impacts[]`
- `temporal_scope`
- `data_integrity_notes`
- `confidence_notes`
- `decision_mapping`
- `notification_scope`
- `downstream_handoff`
- `self_check`

`metadata` must include:
- `contract_version: n300-runtime-v2.5.0`
- `workflow_node: N300`
- `node_artifact_target: 影响范围分析.md`
- `function_bias: quantified_scope_estimation_across_users_services_data_business_and_time`
- `stage_position: operations_runtime.monitoring_and_diagnosis.impact_scope_analysis`
- `incident_id`
- `selected_mode`
- `readiness`
- `evidence_profile`
- `tool_collaboration_mode`

Primary rows or structured entries must preserve:
- `dimension`
- `measurement_query`
- `value`
- `unit`
- `affected_entities`
- `confidence`
- `status`
- `source_refs`
- `unable_to_measure_reason`

## Downstream handoff contract
Use the shared schema in `references/n300-shared-runtime-contract.md`. For this skill, preferred consumers are:

```yaml
downstream_consumers:
  - target: N310
    summary: severity, blast radius, rollback/hotfix risk input, and response prioritization evidence
  - target: N320
    summary: final impact counts, peak impact time, recovery curve, and data integrity notes
  - target: customer support or compliance workflows
    summary: notification scope and evidence when explicitly requested
  - target: root-cause-analysis-recommendation
    summary: propagation path if it clarifies root cause
```

## Design rules
- quantify where possible and label confidence as exact, estimate, bounded, or unable_to_measure.
- show temporal evolution, not only total counts.
- include data integrity checks when data mutation or duplication is possible.
- assess compliance/customer notification scope without issuing final legal advice.
- Always preserve source time windows, source systems, and evidence references.
- Distinguish observed facts from hypotheses.
- Keep sensitive raw data out of final artifacts.

## Self-check
Run `V2.5.0 common self-check` from `references/n300-shared-runtime-contract.md` and additionally confirm this skill's artifact target, boundary, modes, and `output-contract.yaml` fields are satisfied.
## Reference files
- `references/n300-shared-runtime-contract.md`
- `references/output-contract.yaml`
- `references/impact-measurement-dimensions.md`
