---
name: api-design-recommendation
description: recommend api contracts, project-level api policy, resource and action patterns, pagination and filtering conventions, response envelopes, contract metadata, and openapi-ready structures from requirement analysis, api intent, architecture notes, boundary outputs, existing specs, or live api inventories. use for n150 api design before compliance checking, error-code design, code generation, test orchestration, or api documentation.
---
# api-design-recommendation

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> API设计 -> 接口契约设计」。

它是 **direct_result** 型技能：目标是把产品 / 技术意图落实成可消费的接口契约，而不是只讨论“接口大概怎么设计”。默认交付物对齐 N150 节点标准产物 **`接口设计草案.yaml`**。

## Boundary / 边界
- 负责定义项目级 `api_policy`、API surface、请求 / 响应 schema、路径 / operation、response envelope、error format baseline 和 error-case seeds。
- 负责产出 OpenAPI-ready 结构；`openapi_export` 是可选增强模式，不强制所有场景输出完整 OpenAPI 文件。
- 负责为 044 提供设计期规范基线、为 045 提供 error seeds。
- 不负责最终规范门禁判定；该职责交给 `api-spec-compliance-check`。
- 不负责错误码注册表本身；该职责交给 `api-error-code-design`。
- 不深做 security / performance / lifecycle / NFR 方案；仅记录 `security_refs`、`nfr_refs`、`lifecycle_refs` 或 pending questions，深度设计交给 N170 专职 skills。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness`、`artifact_contract` 和 `evidence_profile`。

允许 4 种模式：
- `from_intent`：从需求、流程、接口意图或上游结构化分析设计 API；默认模式。
- `from_existing`：从现有 OpenAPI、接口清单、注解或 legacy 文档逆向整理。
- `policy_only`：仅建立或修正项目级 `api_policy`，不强制展开完整 `api_catalog`。
- `openapi_export`：在正常分析基础上额外产出机器可消费的 YAML / OpenAPI 结构。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `开发需求解析.md` from `N120/engineering-requirement-parsing`
- `接口意图清单.csv` from `N120/api-intent-extraction`
- `技术方案分析.md` from `N130/technical-solution-analysis`

### 可选增强输入
- `数据对象清单.csv` from `N070/data-object-identification`
- `权限矩阵.csv` from `N070/permission-matrix-extraction`
- `服务拆分建议.md` from `N140/service-decomposition-recommendation`
- 现有 API inventory、OpenAPI 文件、控制器注解、对外集成说明

## Minimum viable input / 最小启动条件
- `confirmed` 输出：需要 API intent 或等价的接口清单 + 技术方案上下文。
- `provisional` 输出：只有 PRD、流程说明、技术方案草稿或 legacy 文档时也可运行，但必须显式列出 inferred APIs。
- `blocked` 输出：如果连业务动作、资源对象或调用方/被调用方都无法判断，不要发明接口；输出缺失证据清单。

## Standalone rule / 独立使用规则
即使没有完整上游节点输出，也可以单独使用。

降级规则：
- 若缺少结构化 API intent，可从 PRD / 流程 / 技术方案反推 provisional contract。
- 顶部必须标明 `readiness: provisional`。
- 必须把 `confirmed / inferred / pending` 分开写。
- 未决的 style、versioning、auth、pagination、error format 选择必须进入 `open_questions` 或 `policy_exceptions`。

## Core output contract / 核心输出契约
默认输出应以 YAML / OpenAPI-ready 契约为主，必要时附简短 Markdown 说明。优先复用 `references/output-template.md` 与 `references/yaml-structure.md`。

结果至少包含以下结构：
- `artifact_contract` per `references/SHARED_CONTRACT.md`
- `metadata`
  - `selected_mode`
  - `readiness`
  - `correlation_id`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.api_design.contract_design`
  - `node_artifact_target: 接口设计草案.yaml`
  - `workflow_node: N150`
  - `evidence_profile`
  - `contract_fingerprint`
  - `fingerprint_version`
- `api_policy`
- `api_catalog[]`
- `shared_schemas[]`
- `pagination_contract`
- `consistency_waivers[]`
- `security_refs[]`
- `nfr_refs[]`
- `lifecycle_refs[]`
- `open_questions[]`
- `emit_events[]`
- `downstream_contract`
  - `to_044`: `api_policy`, `api_catalog`, `shared_schemas`, `consistency_waivers`
  - `to_045`: `api_policy.error_format`, `error_case_seeds`, `api_catalog[].api_id`, `contract_metadata.auth`
  - `to_N190`: OpenAPI-ready paths, operations, request/response schemas, error response format
  - `to_N200`: DTO/VO schemas, validation constraints, error refs
  - `to_N240`: API list, negative scenarios, status/error mappings
  - `to_N330`: policy, catalog, examples, compatibility notes
- `self_check`

### Required `api_policy`
必须先定义：
- `style`
- `mixed_rules` when needed
- `versioning`
- `pagination`
- `filter`
- `response_envelope`
- `error_format`
- `idempotency`
- `request_id`
- `auth_baseline`

### Required per-API fields
每个 API 至少包含：
- `api_id`
- `name`
- `api_kind`
- `protocol`
- `method_or_operation`
- `path_or_topic`
- `purpose`
- `request`
- `response`
- `available_actions` when stateful
- `contract_metadata`
- `policy_exceptions`
- `error_case_seeds`
- `evidence`
- `confidence`

## Design rules / 设计规则
### Policy-first discipline / 策略先行
- 先定义 `api_policy`，再写单个 API。
- 任何偏离项目 policy 的 API 都必须记录 `policy_exception_reason`。
- 不得随意混用 REST、action-oriented 和 RPC-like 风格。
- 不硬编码 ID pattern；命名由 `api_policy.naming` 决定。

### Resource vs action discipline / 资源与动作纪律
- 稳定 CRUD 优先资源路径。
- 真正的状态迁移、跨资源命令才用 action path。
- 若团队故意选择动作风格，也要把它写成 policy decision，而不是默许的不一致。

### Pagination and filter discipline / 分页过滤纪律
- 每个项目定义一个主分页风格。
- offset 风格必须返回 `total / offset / limit`。
- cursor 风格必须返回 `next_cursor / has_more`。
- 未经说明，不要把 PII 放进 query parameter。

### Contract metadata discipline / 契约元数据纪律
每个 API 必须包含或继承：
- `stability`
- `owner`
- `auth`
- `rate_limit_ref` or `rate_limit_placeholder`
- `sla_ref` or `sla_placeholder`
- `idempotent`
- `safe`
- `deprecated_since / sunset_date` when explicitly known

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`artifact_contract`、`evidence_profile`。
2. 以 `开发需求解析.md`、`接口意图清单.csv`、`技术方案分析.md` 为主输入建模。
3. 先定义项目级 `api_policy`。
4. 构造 `api_catalog`，为每个 API 归类 `api_kind`。
5. 统一 pagination、filter、response envelope、auth baseline、metadata。
6. 抽取 `shared_schemas`。
7. 生成 `error_case_seeds`，供 045 继续设计。
8. 形成面向 N150 节点标准产物的 **`接口设计草案.yaml`**。
9. 输出 `downstream_contract` 与 `emit_events`，供 044、045 以及 N190 / N200 / N240 / N330 使用。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小 feature：覆盖全部接口。
- 中等系统：覆盖全部关键业务与对外暴露接口。
- 大型平台：至少覆盖核心 API catalog、项目 policy、高风险 path，并显式标 deferred area。

不要为了凑完整度制造并不存在的接口，也不要因为系统大就只给空泛 guideline。

## Quality bar / 质量门槛
合格结果应能直接被 044 与 045 继续消费，并能被 N190 / N200 / N240 / N330 复用，而不需要二次翻译。

使用以下参考文件自检：
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/api-policy-taxonomy.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/output-template.md`
- `references/yaml-structure.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/api-policy-taxonomy.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
