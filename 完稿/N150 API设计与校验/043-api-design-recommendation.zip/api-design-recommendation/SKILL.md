---
name: api-design-recommendation
description: recommend api contracts, project policy, pagination, and openapi-ready structures. triggers on 接口意图清单.csv. precedes 044 and 045 inside n150.
---
# api-design-recommendation


## Policy exception and mixed-style quick-reference
When any API deviates from the project-level `api_policy`, it must be logged in `policy_exceptions`.

| Exception type | Required fields | Example |
|---|---|---|
| Different pagination style | `policy_exception_reason`, `approved_by` | streaming endpoint uses cursor-only |
| Different auth | `policy_exception_reason`, `risk_note` | internal service uses mTLS not JWT |
| Action-path instead of resource | `policy_exception_reason`, `api_kind: state_transition` | `/orders/{id}/cancel` |
| Non-REST style in REST project | `mixed_rules` entry in `api_policy`, `api_style` on intent | webhook for payment callback |

**`api_policy.mixed_rules` template** (when `style: mixed`):
```yaml
api_policy:
  style: mixed
  mixed_rules:
    - applies_to: webhooks
      style: webhook
      rationale: third-party payment provider pushes events
    - applies_to: bulk-import
      style: batch_rpc
      rationale: file-based import does not fit REST resource model
```

## api_policy quick-reference
Define these before writing any single API. Every deviation must be logged in `policy_exceptions`.

| Field | Common values | Notes |
|---|---|---|
| `style` | `rest` / `mixed` / `action_oriented` | must be explicit |
| `versioning` | `uri` (`/v1/`) / `header` | choose one |
| `pagination` | `offset` / `cursor` / `none` | per project, one primary |
| `response_envelope` | `{data, meta, errors}` / flat | standardize across all APIs |
| `error_format` | `{code, message, details}` | seeds for 045 |
| `idempotency` | `idempotency-key` header / body field | document required/optional |
| `auth_baseline` | `Bearer JWT` / `API key` / `mTLS` | inherited by all APIs |
| `request_id` | `X-Request-ID` header | required for tracing |

## Common API kind patterns
| api_kind | trigger | example |
|---|---|---|
| `resource_crud` | stable CRUD on a noun | `POST /orders` |
| `state_transition` | explicit status change | `POST /orders/{id}/cancel` |
| `async_command` | fire-and-forget, returns job_id | `POST /exports` |
| `query_projection` | read-only, filter/sort/page | `GET /orders?status=paid` |
| `event_publication` | outbound event to event bus | `order.paid` topic |
| `webhook_delivery` | push to registered callback URL | `POST {callback_url}` |
| `batch_import_export` | bulk data movement | `POST /orders/bulk-import` |


## Trigger conditions
Design API contracts when any of the following are present:
- `接口意图清单.csv` from 037
- N120 engineering requirement output
- explicit API design or OpenAPI drafting requests
- existing API inventory or spec for reverse-engineering

## Standalone rule
Use `selected_mode: from_intent`. If intent list is absent, infer candidate APIs from PRD or solution analysis and set `readiness: provisional`. Mark all inferred APIs as `confidence: inferred`.

## Role and boundary
本 skill 对齐 skills_workflow 中in the technical-solution-design -> API设计 -> 接口契约设计」. It is a **direct_result** skill: the goal is to produce a concrete 产品 / 技术意图落实成可消费的接口契约，而不是只讨论“接口大概怎么设计”。默认交付物对齐 N150 节点标准产物 **`接口设计草案.yaml`**。

## Boundary
- 负责定义项目级 `api_policy`、API surface、请求 / 响应 schema、路径 / operation、response envelope、error format baseline 和 error-case seeds。
- 负责产出 OpenAPI-ready 结构；`openapi_export` 是可选增强模式，不强制所有场景输出完整 OpenAPI 文件。
- 负责为 044 提供设计期规范基线、为 045 提供 error seeds。
- 不负责最终规范门禁判定；该职责交给 `api-spec-compliance-check`。
- 不负责错误码注册表本身；该职责交给 `api-error-code-design`。
- 不深做 security / performance / lifecycle / NFR 方案；仅记录 `security_refs`、`nfr_refs`、`lifecycle_refs` 或 pending questions，深度设计交给 N170 专职 skills。

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness`、`artifact_contract` 和 `evidence_profile`。

允许 4 种模式：
- `from_intent`：从需求、流程、接口意图或上游结构化分析设计 API；默认模式。
- `from_existing`：从现有 OpenAPI、接口清单、注解或 legacy 文档逆向整理。
- `policy_only`：仅建立或修正项目级 `api_policy`，不强制展开完整 `api_catalog`。
- `openapi_export`：在正常分析基础上额外产出机器可消费的 YAML / OpenAPI 结构。

## Primary inputs
### workflow 对齐的推荐输入
- `开发需求解析.md` from `N120/engineering-requirement-parsing`
- `接口意图清单.csv` from `N120/api-intent-extraction`
- `技术方案分析.md` from `N130/technical-solution-analysis`

### 可选增强输入
- `数据对象清单.csv` from `N070/data-object-identification`
- `权限矩阵.csv` from `N070/permission-matrix-extraction`
- `服务拆分建议.md` from `N140/service-decomposition-recommendation`
- 现有 API inventory、OpenAPI 文件、控制器注解、对外集成说明

## Minimum viable input
- `confirmed` 输出：需要 API intent 或等价的接口清单 + 技术方案上下文。
- `provisional` 输出：只有 PRD、流程说明、技术方案草稿或 legacy 文档时也可运行，但必须显式列出 inferred APIs。
- `blocked` 输出：如果连业务动作、资源对象或调用方/被调用方都无法判断，不要发明接口；输出缺失证据清单。

## Standalone rule
即使没有完整上游节点输出，也可以单独使用。

降级规则：
- 若缺少结构化 API intent，可从 PRD / 流程 / 技术方案反推 provisional contract。
- 顶部必须标明 `readiness: provisional`。
- 必须把 `confirmed / inferred / pending` 分开写。
- 未决的 style、versioning、auth、pagination、error format 选择必须进入 `open_questions` 或 `policy_exceptions`。

## Core output contract
默认输出应以 YAML / OpenAPI-ready 契约为主，必要时附简短 Markdown 说明。优先复用 `references/output-template.md` 与 `references/yaml-structure.md`。

结果至少包含以下结构：
- `artifact_contract` per `references/SHARED_CONTRACT.md`
- `metadata`
  - `selected_mode`
  - `readiness`
  - `correlation_id`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.api_design.contract_design`
  - `node_artifact_target: 接口设计草案.yaml`
  - `workflow_node: N150`
  - `evidence_profile`
  - `contract_fingerprint`
  - `fingerprint_version`
- `api_policy`
- `api_catalog[]`
- `shared_schemas[]`
- `authoritative_enums[]`
- `enum_coverage_report[]`
- `pagination_contract`
- `consistency_waivers[]`
- `security_refs[]`
- `nfr_refs[]`
- `lifecycle_refs[]`
- `open_questions[]`
- `emit_events[]`
- `downstream_contract`
  - `to_044`: `api_policy`, `api_catalog`, `shared_schemas`, `authoritative_enums`, `enum_coverage_report`, `consistency_waivers`
  - `to_045`: `api_policy.error_format`, `error_case_seeds`, `api_catalog[].api_id`, `contract_metadata.auth`
  - `to_N190`: OpenAPI-ready paths, operations, request/response schemas, error response format
  - `to_N200`: DTO/VO schemas, validation constraints, error refs
  - `to_N240`: API list, negative scenarios, status/error mappings
  - `to_N330`: policy, catalog, examples, compatibility notes
- `self_check`

### Required `api_policy`
必须先定义：
- `style`
- `mixed_rules` when needed
- `versioning`
- `pagination`
- `filter`
- `response_envelope`
- `error_format`
- `idempotency`
- `request_id`
- `auth_baseline`

### Required per-API fields
每个 API 至少包含：
- `api_id`
- `name`
- `api_kind`
- `protocol`
- `method_or_operation`
- `path_or_topic`
- `purpose`
- `request`
- `response`
- `available_actions` when stateful
- `contract_metadata`
- `policy_exceptions`
- `error_case_seeds`
- `evidence`
- `confidence`

## Downstream handoff summary
Every 043 output feeds downstream nodes through these canonical fields:
- `to_044_compliance_check`: `api_policy`, `api_catalog[]`, `shared_schemas[]`, `authoritative_enums[]`, `enum_coverage_report[]`, `consistency_waivers[]`
- `to_045_error_code_design`: `api_policy.error_format`, `error_case_seeds[]`, `api_catalog[].api_id`
- `to_N190_code_generation`: OpenAPI-ready paths, operations, request/response schemas
- `to_N200_dto_design`: shared_schemas with validation constraints and error refs
- `to_N240_test_design`: API list, negative scenarios, status/error mappings
- `to_N330_documentation`: policy, catalog, examples, compatibility notes

## Design rules
### Policy-first discipline / 策略先行
- 先定义 `api_policy`，再写单个 API。
- 任何偏离项目 policy 的 API 都必须记录 `policy_exception_reason`。
- 不得随意混用 REST、action-oriented 和 RPC-like 风格。
- 不硬编码 ID pattern；命名由 `api_policy.naming` 决定。

### Resource vs action discipline / 资源与动作纪律
- 稳定 CRUD 优先资源路径。
- 真正的状态迁移、跨资源命令才用 action path。
- 若团队故意选择动作风格，也要把它写成 policy decision，而不是默许的不一致。

### Pagination and filter discipline / 分页过滤纪律
- 每个项目定义一个主分页风格。
- offset 风格必须返回 `total / offset / limit`。
- cursor 风格必须返回 `next_cursor / has_more`。
- 未经说明，不要把 PII 放进 query parameter。

### Contract metadata discipline / 契约元数据纪律
每个 API 必须包含或继承：
- `stability`
- `owner`
- `auth`
- `rate_limit_ref` or `rate_limit_placeholder`
- `sla_ref` or `sla_placeholder`
- `idempotent`
- `safe`
- `deprecated_since / sunset_date` when explicitly known

### Authoritative enum coverage / 权威枚举覆盖
- When PRD, state-machine, data-object, permission, or prior design inputs define authoritative enum/status vocabularies, extract them into `authoritative_enums[]` with `enum_name`, `source_ref`, `values[]`, and optional aliases.
- Project each authoritative enum into `shared_schemas[]` or every consuming request/response field. Partial operation-local enums are not enough when the domain enum is broader.
- If the enum cannot be fully projected because the product or brownfield mapping is undecided, emit `enum_coverage_report[]` with `coverage_status: blocked | partial`, `missing_values[]`, `blocker_id`, owner, and next action; keep `readiness` below `pass`.
- Before final handoff, run `scripts/validate_enum_coverage.py --authority <authority.json> --artifact <api-artifact.json|yaml>` when an authority enum list is available.

## Execution workflow
1. 识别 `selected_mode`、`readiness`、`artifact_contract`、`evidence_profile`。
2. 以 `开发需求解析.md`、`接口意图清单.csv`、`技术方案分析.md` 为主输入建模。
3. 先定义项目级 `api_policy`。
4. 构造 `api_catalog`，为每个 API 归类 `api_kind`。
5. 统一 pagination、filter、response envelope、auth baseline、metadata。
6. 抽取 `shared_schemas` 与 `authoritative_enums[]`，并生成 `enum_coverage_report[]`。
7. 生成 `error_case_seeds`，供 045 继续设计。
8. 形成面向 N150 节点标准产物的 **`接口设计草案.yaml`**。
9. 输出 `downstream_contract` 与 `emit_events`，供 044、045 以及 N190 / N200 / N240 / N330 使用。
10. 使用 checklist、common-failure review 与 enum coverage validator 自检。

## Dynamic completeness
- 小 feature：覆盖全部接口。
- 中等系统：覆盖全部关键业务与对外暴露接口。
- 大型平台：至少覆盖核心 API catalog、项目 policy、高风险 path，并显式标 deferred area。

不要为了凑完整度制造并不存在的接口，也不要因为系统大就只给空泛 guideline。

## Quality bar
合格结果应能直接被 044 与 045 继续消费，并能被 N190 / N200 / N240 / N330 复用，而不需要二次翻译。

使用以下参考文件自检：
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/api-policy-taxonomy.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/output-template.md`
- `references/yaml-structure.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/api-policy-taxonomy.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
## v2 artifact contract additions

The following fields are **mandatory** on every non-blocked output. Declare at the artifact header top, alongside `selected_mode` and `readiness`.

```yaml
artifact_schema_version: n150.v2.1.0
skill_name: api-design-recommendation
produced_event: produced.n150.api_design.v2
blocker_mapping: B-N150-01
correlation_id: ""    # REQUIRED: same value shared by 043, 044, 045 in one N150 run
contract_fingerprint: ""
fingerprint_version: "1"
rule_results:
  - rule_id: R01_api_policy_defined
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_api_catalog_covers_all_intents
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R03_error_case_seeds_present
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R04_shared_schemas_extracted
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R05_downstream_contract_emitted
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R06_error_case_seeds_per_write_api
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R07_no_pii_in_query_params
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R08_openapi_export_has_shared_schemas
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R09_authoritative_enum_coverage
    severity: reject
    result: pass | warn | reject | not_applicable
feedback_signal_to_n005:
  signal_type: none | api_gap_detected | design_pattern_signal
  summary: ""
  target_n070_skills:
  - 015-state-transition-mapping
  - 016-permission-matrix-extraction
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
eventbus_subscribers: [N330]   # N330 subscribes produced_event to trigger API doc generation
route_back_to: none | api-design | compliance-check
# none             — design ready; 044 and 045 may proceed
# api-design       — return to 043 when compliance gate fails (044 triggers)
# compliance-check — re-run 044 after 043 revision; do not skip gate
eventbus_subscribers: [N330]
# N330 → 接口文档自动生成 (triggered on produced.n150.api_contract_draft)
```

## Upstream linkage from N070 (mandatory when artifacts exist)

| upstream artifact | consume fields | maps to |
|---|---|---|
| `接口意图清单.csv` (037) | intent_id, api_style, nfr_hints, derived_from_er_ids[] | api_catalog seeds, nfr_refs |
| `权限矩阵.csv` (016) | PERM-* subject, grain, evaluation_algo | api_policy.auth_baseline, per-API auth constraints |
| `业务规则清单.md` (014) | RULE-* condition_expr, hardness=constraint | api error case seeds, validation rules |
| `状态转移图.md` (015) | SM-* transitions, trigger_kind=external | webhook / callback API candidates |
| `数据对象目录.md` (017) | OBJ-* ddd_role, constraint_tags: pii/regulated | shared_schemas, sensitive field handling |
