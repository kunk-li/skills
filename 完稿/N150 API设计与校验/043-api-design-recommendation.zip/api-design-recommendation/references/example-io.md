# Example Input / Output

## Example input
A workflow says: employees submit leave requests, managers approve or reject them, HR can view all requests but cannot approve, and the system may send callbacks to payroll after approval.

Available inputs:
- PRD excerpt with leave request workflow.
- Permission matrix: employee=create/read own, manager=approve/reject team, HR=read all.
- Data objects: LeaveRequest, Employee, ApprovalDecision.

## Example output sketch

```yaml
artifact_contract:
  artifact_schema_version: n150.api_contract.v2.2
  producer_skill_id: api-design-recommendation
  selected_mode: from_intent
  readiness: provisional
  correlation_id: n150-leave-001
  contract_fingerprint: null
  fingerprint_version: n150-fingerprint-v1

api_policy:
  style: mixed
  versioning: {strategy: url_path, current: v1}
  pagination: {default_style: cursor, limit_max: 100}
  response_envelope: {success: standard_envelope, error: rfc7807}
  error_format: {authority: api-design-recommendation, standard: rfc7807}
  idempotency: {header: X-Idempotency-Key, applies_to: [POST, PATCH]}
  request_id: {required_header: X-Request-ID}
  auth_baseline: {type: bearer_jwt, permission_refs_required: true}
  security_refs: [N170/security-risk-analysis]
  nfr_refs: []

api_catalog:
  - api_id: leave-request-create
    api_kind: crud_resource
    method_or_operation: POST
    path_or_topic: /api/v1/leave-requests
    request: {schema_ref: LeaveRequestCreateRequest}
    response: {status: 201, schema_ref: LeaveRequestResponse}
    contract_metadata: {owner: HRIS, auth: PERM_LEAVE_CREATE, idempotent: key_based}
    error_case_seeds: [LEAVE_BALANCE_INSUFFICIENT, LEAVE_DATE_OVERLAP]
    confidence: medium
  - api_id: leave-request-approve
    api_kind: state_transition
    method_or_operation: POST
    path_or_topic: /api/v1/leave-requests/{requestId}/approval
    request: {schema_ref: ApprovalDecisionRequest}
    response: {status: 200, schema_ref: LeaveRequestResponse}
    contract_metadata: {owner: HRIS, auth: PERM_LEAVE_APPROVE, idempotent: key_based}
    error_case_seeds: [LEAVE_INVALID_STATE, LEAVE_PERMISSION_DENIED]
    confidence: medium

shared_schemas:
  - schema_name: LeaveRequestResponse
    reused_by: [leave-request-create, leave-request-approve]

open_questions:
  - id: Q-001
    question: Should payroll callback be synchronous or webhook retryable?
    impact: affects webhook_callback API and idempotency policy
```

## Notes
- `style: mixed` is valid because this design uses resource CRUD plus state-transition action endpoints.
- Security and NFR details are referenced, not deeply designed in 043.
- 044 should validate HTTP semantics, pagination consistency, and auth consistency next.
- 045 should expand `error_case_seeds` into registry entries.
