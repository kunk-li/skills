# Mode Selection v2.2

- Use `from_intent` when API intents, requirement parsing, or technical solution notes are available.
- Use `from_existing` when normalizing OpenAPI, controller annotations, API inventory, or legacy docs.
- Use `policy_only` when the project only needs shared API conventions before detailed API expansion.
- Use `openapi_export` when an OpenAPI-ready artifact is explicitly needed for code generation or contract testing.

If inputs are partial, keep the selected mode but set `readiness: provisional` and fill `input_coverage.degraded_reason`.
