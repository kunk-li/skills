# Scoring Rubric v2.3: API Design Recommendation

Score 1-5 for each dimension.

| Dimension | 5 means | 1 means |
|---|---|---|
| Policy-first clarity | project policy is explicit and reusable | API rules are implicit or inconsistent |
| API surface completeness | core APIs and high-risk paths are covered with evidence | important operations are missing without explanation |
| Contract consumability | N190/N200/N240/N330 can consume output directly | output needs manual translation |
| Standalone honesty | provisional/inferred/pending evidence is clearly separated | guesses are presented as confirmed |
| Boundary control | security/NFR/lifecycle are referenced without taking over N170 | skill overreaches into non-API design |
| Composition readiness | 044/045 fields are complete and aligned with SHARED_CONTRACT | downstream skills cannot reliably consume output |
| Traceability hygiene | correlation_id is propagated consistently across artifact, events, and examples | artifacts cannot be grouped with sibling N150 outputs |
| Idempotency verifiability | contract_fingerprint and fingerprint_version are present or honestly degraded | repeated runs cannot be compared safely |
