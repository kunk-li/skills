# Compatibility map — api-design-recommendation v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 037 api-intent-extraction | `intent_id, api_style, nfr_hints` | `api_catalog seeds` | intent inventory is primary input for API design |
| 038 technical-solution-analysis | `constraint_taxonomy_summary, fmea_analysis[]` | `api_policy constraints, security_refs` | analysis constraints shape API policy decisions |
| N070 016 permission-matrix-extraction | `PERM-* subject, grain` | `api_policy.auth_baseline, per-API auth` | permission matrix defines auth requirements |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 044 api-spec-compliance-check | `api_policy, api_catalog[], shared_schemas[]` | `compliance baseline` | 044 checks output against 043 policy |
| 045 api-error-code-design | `error_case_seeds[], api_policy.error_format` | `registry seeds` | 043 seeds feed 045 error registry |
| N190 code-generation | `OpenAPI-ready paths, schemas` | `code scaffolding` | API contracts generate boilerplate code |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
