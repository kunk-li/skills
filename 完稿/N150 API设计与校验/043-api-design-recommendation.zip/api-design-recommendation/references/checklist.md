# 043 Delivery Checklist

## Policy baseline
- [ ] `api_policy` exists before per-API drafting
- [ ] style, versioning, pagination, envelope, auth baseline, and request ID policy are explicit
- [ ] any policy deviation is recorded as a waiver or exception

## Contract completeness
- [ ] every API has `api_id`, `api_kind`, protocol, operation, request, response, metadata, and evidence
- [ ] stateful resources include `available_actions` when that materially helps clients
- [ ] shared request/response shapes are extracted into `shared_schemas`
- [ ] write APIs include idempotency behavior

## Consistency and safety
- [ ] pagination and filtering follow one project rule unless an exception is justified
- [ ] GET or equivalent safe operations do not mutate state
- [ ] sensitive data is not silently placed in query parameters
- [ ] response envelopes and error-format assumptions are stable for downstream reuse

## Cross-skill alignment
- [ ] output is immediately usable by 044 as a compliance baseline
- [ ] output contains error-case seeds for 045
- [ ] `downstream_contract` includes OpenAPI/export hints when relevant

## v2.3 Contract Checks
- [ ] Output starts with `artifact_contract`.
- [ ] `artifact_contract.correlation_id` is present when the artifact belongs to an N150 run; if standalone and unavailable, it is explicitly `null` with a degraded reason.
- [ ] `artifact_contract.contract_fingerprint` is computed from the semantic fields defined in `SHARED_CONTRACT.md`, or explicitly set to `null` with a fingerprint unavailable reason.
- [ ] `artifact_contract.fingerprint_version` matches the shared algorithm version, currently `n150-fingerprint-v1`.
- [ ] `api_policy.error_format` is defined once as the source of truth for 045.
- [ ] security/NFR/lifecycle deep design is referenced, not absorbed.
- [ ] `downstream_contract` lists 044, 045, N190, N200, N240, and N330.
- [ ] `emit_events` includes `produced.n150.api_contract_draft` and carries the same `correlation_id` as the artifact.
- [ ] Partial inputs are marked as provisional with input coverage.
