# Common failure modes — api-design-recommendation

## F1: no policy, only endpoint list
Symptom: API endpoints are listed but there is no `api_policy` defining style, versioning, pagination, auth, or error format.
Fix: Define `api_policy` first. Every endpoint must either conform to the policy or have an explicit `policy_exception`.

## F2: mixed styles without a rule
Symptom: REST, action-path, and webhook endpoints coexist but `api_policy.style` is not `mixed` and `mixed_rules` is absent.
Fix: Set `api_policy.style: mixed` and add `mixed_rules[]` entries. Each non-default style must have a `rationale`.

## F3: workflow steps as bespoke endpoints
Symptom: Every state transition in a workflow becomes a unique endpoint path: `/start`, `/pause`, `/resume`, `/finish`.
Fix: Classify using `api_kind`. Use `state_transition` with a consistent pattern like `POST /resources/{id}/cancel` rather than inventing paths per action.

## F4: pagination drift
Symptom: Some list endpoints use offset pagination, others use cursor, others return all records with no pagination at all.
Fix: Define one primary `pagination` style in `api_policy`. Any exception requires `policy_exception_reason`. Audit all list endpoints for consistency.

## F5: stateful APIs without client guidance
Symptom: A resource has multiple states (DRAFT → SUBMITTED → APPROVED → REJECTED) but the API response does not include `available_actions` or `_links`.
Fix: Add `available_actions[]` to stateful resources so clients know which transitions are currently valid. This prevents invalid state transition calls.

## F6: metadata omitted
Symptom: APIs are defined with method, path, request, and response but missing `owner`, `stability`, `auth`, `rate_limit_ref`, `idempotent`, and `sla_ref`.
Fix: Include or inherit `contract_metadata` on every API. Operational metadata is as important as the interface contract itself.

## F7: error seeds not generated
Symptom: The API catalog is complete but `error_case_seeds[]` is empty on every entry, giving 045 nothing to work with.
Fix: For every API, enumerate business-rule violations, not-found cases, auth failures, and state conflicts as `error_case_seeds[]`. These feed 045 directly.

## F8: openapi export without shared schemas
Symptom: An openapi_export is requested but `shared_schemas[]` was never extracted — every response repeats the same object inline.
Fix: Extract reusable schemas into `shared_schemas[]` first. Then reference via `$ref`. Export without shared schemas produces unmaintainable OpenAPI.

## F9: partial authoritative enum projected as complete API schema
Symptom: A PRD/state-machine/data-object enum has many values, but 043 only lists the few values used by one operation and still marks the API draft ready.
Fix: Add the full enum to `authoritative_enums[]` and `shared_schemas[]`, or emit `enum_coverage_report[]` with missing values, `blocker_id`, owner, and next action; readiness stays below `pass`.
