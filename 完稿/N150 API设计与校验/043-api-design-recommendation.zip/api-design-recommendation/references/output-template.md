# Output Template: API Design Recommendation v2.3.1

## 1. Artifact Contract
Start with `artifact_contract` from `SHARED_CONTRACT.md`. Explicitly include the v2.3-readable fields below so callers do not need to infer them from prose:

```yaml
artifact_contract:
  schema_version: n150.api_contract.v2.2
  producer_skill_id: api-design-recommendation
  workflow_node: N150
  selected_mode: from_intent | from_existing | policy_only | openapi_export
  readiness: confirmed | provisional | partial | blocked
  correlation_id: string | null
  input_coverage:
    required_present: []
    required_missing: []
    optional_present: []
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
  contract_fingerprint: sha256-lowercase-hex | null
  fingerprint_version: n150-fingerprint-v1 | null
  downstream_consumers: [api-spec-compliance-check, api-error-code-design, N190, N200, N240, N330]
  emit_events: []
  degraded_reason: []
```

## 2. Objective
State scope, selected mode, excluded scope, and readiness.

## 3. Evidence Profile
| source | from | what it confirms | remaining uncertainty |

## 4. Project API Policy
Use YAML or tables covering style, versioning, pagination, filter/sort rules, response envelope, error format, idempotency, request ID, auth baseline, and refs to security/NFR/lifecycle design.

## 5. API Surface Summary
| api_id | api_kind | method_or_operation | path_or_topic | owner | confidence |

## 6. Detailed API Catalog
For each API include purpose, request, response, available actions when relevant, metadata, policy exceptions, evidence, open questions, and error-case seeds.

## 7. Shared Schemas and Conventions
| schema or convention | reused by | notes |

## 8. Consistency Waivers
| api_id | waived rule | reason | review trigger |

## 9. Downstream Contract
| consumer | fields to read | why |

## 10. Emit Events
List event types to emit, payload readiness, and rerun hints.

## 11. Open Questions
| id | question | impact | owner |

## 12. Self-Check
Summarize checklist and scoring results.
