# YAML Structure Contract v2.2

Use this structure when the output is YAML, `markdown_and_yaml`, or OpenAPI-adjacent.

## Top-level sections
- `artifact_contract`
- `metadata`
- `api_policy`
- `api_catalog`
- `shared_schemas`
- `authoritative_enums`
- `enum_coverage_report`
- `pagination_contract`
- `consistency_waivers`
- `security_refs`
- `nfr_refs`
- `lifecycle_refs`
- `open_questions`
- `emit_events`
- `downstream_contract`
- `self_check`

## artifact_contract
Follow `references/SHARED_CONTRACT.md`:
- `artifact_schema_version: n150.api_contract.v2.2`
- `producer_skill_id: api-design-recommendation`
- `workflow_node: N150`
- `selected_mode`
- `readiness`
- `correlation_id`
- `contract_fingerprint`
- `fingerprint_version`
- `evidence_profile`
- `input_coverage`
- `downstream_consumers`
- `emit_events`

## metadata
Required keys:
- `artifact_type: api_design_draft`
- `selected_mode`
- `readiness`
- `function_bias: direct_result`
- `stage_position: technical_solution_design.api_design.contract_design`
- `node_artifact_target: 接口设计草案.yaml`
- `workflow_node: N150`
- `coverage_scope`
- `excluded_scope`
- `generated_from`

## api_policy
Required keys:
- `style` using `rest | rpc | event | mixed | unspecified`
- `versioning`
- `pagination`
- `filtering`
- `response_envelope`
- `error_format`
- `idempotency`
- `request_id`
- `auth_baseline`
- `security_refs`
- `nfr_refs`
- `lifecycle_refs`

## api_catalog[]
Each entry should contain:
- `api_id`
- `name`
- `api_kind`
- `protocol`
- `method_or_operation`
- `path_or_topic`
- `purpose`
- `request`
- `response`
- `available_actions`
- `contract_metadata`
- `policy_exceptions`
- `error_case_seeds`
- `evidence`
- `confidence`

## shared_schemas[]
For each schema include:
- `schema_name`
- `fields`
- `reused_by`
- `notes`

## authoritative_enums[]
For each authoritative enum/status vocabulary include:
- `enum_name`
- `source_ref`
- `values`
- `aliases` when operation-local fields use names like `status` or `expectedStatus`

## enum_coverage_report[]
For each authoritative enum include:
- `enum_name`
- `coverage_status: complete | partial | blocked`
- `projected_in`
- `missing_values`
- `blocker_id` when coverage is partial or blocked
- `owner`
- `next_action`

## pagination_contract
Required keys:
- `default_style`
- `request_shape`
- `response_shape`
- `limit_max`
- `waivers`

## emit_events
List event declarations from `references/events.md`, especially:
- `produced.n150.api_contract_draft`
- `state.n150.needs_design_revision` when 044 feedback must be handled

## downstream_contract
Required consumers:
- `to_044`: `api_policy`, `api_catalog`, `shared_schemas`, `authoritative_enums`, `enum_coverage_report`, `consistency_waivers`
- `to_045`: `api_policy.error_format`, `error_case_seeds`, `api_catalog[].api_id`, `contract_metadata.auth`
- `to_N190`: OpenAPI-ready path, method, request, response, error response format
- `to_N200`: schemas, validation constraints, error seeds / registry references
- `to_N240`: API list, negative scenarios, status/error mappings
- `to_N330`: API policy, catalog, and documentation-ready examples
