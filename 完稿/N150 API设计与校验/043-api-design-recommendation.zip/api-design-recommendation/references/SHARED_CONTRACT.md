# N150 Shared Contract v2.2

Use this file as the shared node-level contract for the three N150 skills:

- `api-design-recommendation` (043) defines the API contract surface and project API policy.
- `api-spec-compliance-check` (044) checks the contract and emits gate findings.
- `api-error-code-design` (045) defines the error-code registry and client-consumable error semantics.

This contract keeps the skills independently usable while making the trio stronger when composed.

## Contract identity

```yaml
n150_shared_contract:
  schema_version: n150.api_contract.v2.2
  workflow_node: N150
  node_goal: api_design_and_validation
  package_artifacts:
    - 接口设计草案.yaml
    - API规范检查单.csv
    - 错误码清单.csv
  aggregate_artifact: N150_api_spec_package.md
```

## Required artifact header

Every N150 skill output must start with this metadata block, adapted to the producer.

```yaml
artifact_contract:
  artifact_schema_version: n150.api_contract.v2.2
  producer_skill_id: api-design-recommendation | api-spec-compliance-check | api-error-code-design
  workflow_node: N150
  selected_mode: string
  readiness: confirmed | provisional | partial | blocked
  correlation_id: string | null
  contract_fingerprint: stable-sha256-or-null
  fingerprint_version: n150-fingerprint-v1 | null
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
  input_coverage:
    required_present: []
    required_missing: []
    optional_present: []
    degraded_reason: []
  downstream_consumers:
    - api-design-recommendation
    - api-spec-compliance-check
    - api-error-code-design
    - N190
    - N200
    - N240
    - N330
  emit_events:
    - event_type: produced.n150.artifact
      event_version: v1
      should_emit: true
```

## Authoritative ownership

| Area | Authority | Other skills may do |
|---|---|---|
| `api_policy` | 043 | 044 may check, 045 may consume |
| API surface and `api_catalog` | 043 | 044 may flag gaps; 045 may link codes to APIs |
| authoritative enums and enum coverage | 043 | 044 may gate missing coverage; N200/N240 may consume |
| response envelope and `error_format` | 043 | 044 may check conformance; 045 fills code semantics inside the format |
| `error_case_seeds` | 043 | 045 expands, deduplicates, and normalizes |
| compliance findings and gate verdict | 044 | 043/045 consume as feedback |
| coverage ratio for compliance checks | 044 | others may display but not recalculate |
| error registry and HTTP status matrix | 045 | 044 may flag missing or inconsistent references |
| error coverage, orphan, and missing-code judgment | 045 | 044 emits signals only |
| produced event authority | producing skill | other skills and N150 orchestrator may consume or aggregate |
| security, performance, deep NFR design | N170 skills | 043 records references or placeholders only |

## Canonical shared object

```yaml
project_api_contract:
  schema_version: n150.api_contract.v2.2
  correlation_id: string | null
  contract_fingerprint: string | null
  fingerprint_version: n150-fingerprint-v1 | null
  api_policy:
    authority: api-design-recommendation
    style: rest | rpc | event | mixed | unspecified
    versioning: object
    pagination: object
    filtering: object
    response_envelope: object
    error_format: object
    idempotency: object
    request_id: object
    auth_baseline: object
    nfr_refs: []
    security_refs: []
  api_catalog:
    - api_id: string
      api_kind: crud_resource | state_transition | composite_query | batch_operation | webhook_callback | stream_event | rpc_command
      method_or_operation: string
      path_or_topic: string
      request: object
      response: object
      contract_metadata: object
      error_case_seeds: []
      policy_exceptions: []
      evidence: []
      confidence: high | medium | low
  authoritative_enums:
    - enum_name: string
      source_ref: string
      values: []
      aliases: []
  enum_coverage_report:
    - enum_name: string
      coverage_status: complete | partial | blocked
      projected_in: []
      missing_values: []
      blocker_id: string | null
  compliance_report:
    authority: api-spec-compliance-check
    policy_baseline_source: string
    coverage_ratio: number
    findings: []
    cross_api_consistency_findings: []
    gate_decision: pass | conditional | fail | blocked
  error_policy:
    authority: api-error-code-design
    naming_convention: string
    http_status_mapping_policy: object
    minimum_locales: []
    client_action_enum: []
  error_registry:
    authority: api-error-code-design
    codes: []
    coverage_summary: object
    orphan_or_missing_codes: []
  maturity_signals:
    blockers: []
    waivers: []
    open_questions: []
```

## Rerun and conflict rules

- If 043 changes `api_policy`, rerun 044 and 045.
- If 043 changes `api_catalog`, rerun 044; rerun 045 when changed APIs have new or removed error scenarios.
- If 043 changes `error_format`, rerun 045 and then run 044 final consistency gate.
- If 044 emits unresolved `MUST` or `MUST_NOT` findings, loop back to 043 before sending the contract to N190 or N200.
- If 045 changes `error_registry`, rerun 044 for error-format and status-mapping consistency only.
- Limit the 043 -> 044 repair loop to two automatic iterations inside a single N150 run. On the third blocker pass, emit an escalation event and return a `blocked` artifact rather than cycling indefinitely.

## Standalone readiness rules

- `confirmed`: all required workflow inputs or equivalent evidence are present.
- `provisional`: a skill is run from partial PRD, technical notes, legacy docs, or inferred evidence.
- `partial`: the skill completed only a subset of checks or registry coverage.
- `blocked`: missing evidence prevents responsible output or unresolved blockers must be handled by another skill.

Standalone mode is allowed, but the skill must make degraded coverage explicit and must not present inferred results as confirmed.

## Downstream field contract

| Consumer | Required fields |
|---|---|
| 044 | `api_policy`, `api_catalog`, `shared_schemas`, `authoritative_enums`, `enum_coverage_report`, `consistency_waivers` |
| 045 | `api_policy.error_format`, `error_case_seeds`, `api_catalog[].api_id`, `contract_metadata.auth` |
| N190 | OpenAPI-ready path, method, request, response, error response format |
| N200 | request/response schemas, validation constraints, error registry |
| N240 | API list, negative scenarios, status/error mappings |
| N330 | API policy, catalog, compliance report, error registry |

## Contract fingerprint

Use `contract_fingerprint` to support idempotency, event de-duplication, and rerun decisions.

### Fingerprint algorithm

Use `fingerprint_version: n150-fingerprint-v1` and compute:

1. Select only semantic fields, excluding timestamps, generated prose summaries, display-only ordering, transient evidence snippets, and runtime diagnostics.
2. Build a canonical JSON object with these producer-specific fields:
   - 043: `api_policy`, `api_catalog[].{api_id,api_kind,method_or_operation,path_or_topic,request,response,contract_metadata,error_case_seeds,policy_exceptions}`, `shared_schemas`, `authoritative_enums`, `enum_coverage_report`, `pagination_contract`.
   - 044: `policy_baseline_source`, `gate_coverage`, `findings[].{check_id,rule_category,severity,api_ref,status,owner_skill}`, `cross_api_consistency_findings`, `gate_decision`.
   - 045: `error_policy`, `error_registry[].{error_code,status,domain,category,scenario,client_guidance,related_apis,lifecycle_status}`, `http_status_matrix`, `coverage_summary`, `orphan_or_missing_codes`.
3. Normalize object keys lexicographically.
4. Normalize unordered arrays by stable keys when available (`api_id`, `schema_name`, `check_id`, `error_code`); preserve order only for priority-ranked lists.
5. Serialize as UTF-8 JSON with no insignificant whitespace.
6. Compute SHA-256 and encode as lowercase hexadecimal.

If the artifact is too incomplete to compute a meaningful fingerprint, set `contract_fingerprint: null` and add a degraded reason such as `fingerprint_unavailable_missing_api_catalog`.

## Idempotency

Given the same semantic inputs and the same selected mode, the output should be semantically equivalent across runs. Timestamps, ordering of non-priority lists, and generated IDs may vary, but `contract_fingerprint` should remain stable when the contract does not change.
