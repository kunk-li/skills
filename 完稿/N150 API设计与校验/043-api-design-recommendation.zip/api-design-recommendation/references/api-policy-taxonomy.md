# API Policy Taxonomy

Use this taxonomy to keep `api_policy` consistent with `SHARED_CONTRACT.md`.

## Style
Canonical enum values:
- `rest`: REST-oriented HTTP resources and collections.
- `rpc`: command/action-oriented operations where resource modeling is not the primary fit.
- `event`: event, stream, webhook, or callback oriented API surface.
- `mixed`: more than one style is intentionally used in one project.
- `unspecified`: not enough evidence; must be resolved before a confirmed contract.

Legacy aliases may be normalized as follows:
- `rest_oriented` -> `rest`
- `action_oriented` -> `rpc`
- `webhook_or_stream` -> `event`

## Versioning
- `url_path`
- `header`
- `accept_type`
- `query`
- `none`
- `unspecified`

## Pagination
- `offset_limit`
- `cursor`
- `keyset`
- `page_size`
- `none`
- `unspecified`

## Filtering and sorting
- `query_params`
- `filter_dsl`
- `jsonapi_style`
- `none`
- `unspecified`

## Response envelope
- `none` for bare HTTP body plus status semantics.
- `standard_envelope` such as `{ request_id, data, error }`.
- `custom_envelope` such as `{ code, message, data }`.
- `rfc7807` for problem details on errors.
- `unspecified` when the envelope needs a policy decision.

## Error format
- `rfc7807`
- `standard_envelope_error`
- `custom_error_object`
- `unspecified`

## Idempotency
Recommended header: `X-Idempotency-Key`.

Typical apply set:
- POST with create-or-trigger semantics.
- PUT/PATCH when retries matter.
- Long-running action endpoints that may be retried by clients.

## API kinds
- `crud_resource`
- `state_transition`
- `composite_query`
- `batch_operation`
- `webhook_callback`
- `stream_event`
- `rpc_command`

## Contract metadata
Recommended minimum:
- `stability`
- `owner`
- `auth`
- `rate_limit`
- `sla`
- `idempotent`
- `safe`
- `security_refs`
- `nfr_refs`
- `lifecycle_refs`
