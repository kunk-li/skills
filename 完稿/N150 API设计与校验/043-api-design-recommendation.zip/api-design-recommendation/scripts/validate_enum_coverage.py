#!/usr/bin/env python3
"""Validate that API artifacts fully project authoritative enums or emit blockers.

Usage:
    python scripts/validate_enum_coverage.py --authority authority.json --artifact api.json

The authority file should contain `authoritative_enums[]` entries with:
`enum_name`, `values[]`, optional `aliases[]`, and optional `source_ref`.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None


BLOCKING_STATUSES = {"blocked", "partial", "incomplete", "missing", "open", "constrained"}
PASS_READINESS = {"pass", "ready", "complete"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate authoritative enum coverage in a 043 API artifact")
    parser.add_argument("--authority", required=True, help="JSON/YAML file with authoritative_enums[]")
    parser.add_argument("--artifact", required=True, help="043 API artifact JSON/YAML")
    return parser.parse_args()


def load_doc(path: Path) -> Any:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        return json.loads(text)
    if path.suffix.lower() in {".yaml", ".yml"}:
        if yaml is None:
            raise RuntimeError("PyYAML is required for YAML artifacts; use JSON or install PyYAML")
        return yaml.safe_load(text)
    raise ValueError("supported files: .json, .yaml, .yml")


def norm(value: Any) -> str:
    return str(value).strip().lower().replace("-", "_").replace(" ", "_")


def walk(obj: Any, path: tuple[str, ...] = ()) -> list[tuple[tuple[str, ...], Any]]:
    rows = [(path, obj)]
    if isinstance(obj, dict):
        for key, value in obj.items():
            rows.extend(walk(value, path + (str(key),)))
    elif isinstance(obj, list):
        for idx, value in enumerate(obj):
            rows.extend(walk(value, path + (str(idx),)))
    return rows


def context_matches(path: tuple[str, ...], container: dict[str, Any], aliases: set[str]) -> bool:
    path_tokens = {norm(part) for part in path}
    if path_tokens & aliases:
        return True
    for key in ("enum_name", "schema_name", "name", "field", "field_name", "property", "property_name"):
        if norm(container.get(key, "")) in aliases:
            return True
    return False


def collect_projected_values(artifact: dict[str, Any], aliases: set[str]) -> set[str]:
    values: set[str] = set()
    for path, obj in walk(artifact):
        if not isinstance(obj, dict):
            continue
        if not context_matches(path, obj, aliases):
            continue
        for key in ("enum", "values", "allowed_values", "enum_values"):
            raw = obj.get(key)
            if isinstance(raw, list):
                values.update(str(value).strip() for value in raw if str(value).strip())
    return values


def has_explicit_blocker(artifact: dict[str, Any], enum_name: str, aliases: set[str], missing: set[str]) -> bool:
    for _path, obj in walk(artifact):
        if not isinstance(obj, dict):
            continue
        if not context_matches((), obj, aliases | {norm(enum_name)}):
            continue
        raw_missing = obj.get("missing_values")
        missing_values = {str(value).strip() for value in raw_missing} if isinstance(raw_missing, list) else set()
        status = norm(obj.get("coverage_status", obj.get("status", "")))
        has_blocker_id = bool(obj.get("blocker_id") or obj.get("question_id") or obj.get("decision_id"))
        blocking_flag = obj.get("blocking") is True or norm(obj.get("gate_decision", "")) in BLOCKING_STATUSES
        if missing and missing_values and not missing_values.intersection(missing):
            continue
        if status in BLOCKING_STATUSES or has_blocker_id or blocking_flag:
            return True
    return False


def artifact_readiness(artifact: dict[str, Any]) -> str:
    metadata = artifact.get("metadata") if isinstance(artifact, dict) else {}
    if isinstance(metadata, dict):
        return norm(metadata.get("readiness", ""))
    return ""


def main() -> int:
    args = parse_args()
    authority = load_doc(Path(args.authority))
    artifact = load_doc(Path(args.artifact))
    if not isinstance(authority, dict) or not isinstance(artifact, dict):
        print("INVALID")
        print("- authority and artifact roots must be objects")
        return 1

    enum_specs = authority.get("authoritative_enums", [])
    if not isinstance(enum_specs, list) or not enum_specs:
        print("INVALID")
        print("- authority.authoritative_enums[] is required")
        return 1

    errors: list[str] = []
    warnings: list[str] = []
    readiness = artifact_readiness(artifact)

    for spec in enum_specs:
        if not isinstance(spec, dict):
            errors.append("authoritative_enums[] entries must be objects")
            continue
        enum_name = str(spec.get("enum_name", "")).strip()
        expected = {str(value).strip() for value in spec.get("values", []) if str(value).strip()}
        aliases = {norm(enum_name)}
        aliases.update(norm(value) for value in spec.get("aliases", []) if str(value).strip())
        if not enum_name or not expected:
            errors.append("each authoritative enum needs enum_name and non-empty values[]")
            continue
        projected = collect_projected_values(artifact, aliases)
        missing = expected - projected
        extra = projected - expected
        if not missing:
            if extra:
                warnings.append(f"{enum_name}: projected enum has extra values {sorted(extra)}")
            continue
        if has_explicit_blocker(artifact, enum_name, aliases, missing):
            if readiness in PASS_READINESS:
                errors.append(f"{enum_name}: missing {len(missing)} authoritative values but metadata.readiness={readiness}; downgrade readiness")
            continue
        errors.append(
            f"{enum_name}: missing {len(missing)} authoritative values without explicit blocker: {sorted(missing)}"
        )

    if errors:
        print("INVALID")
        for err in errors:
            print(f"- {err}")
        for warn in warnings:
            print(f"WARNING: {warn}")
        return 1
    print("VALID")
    for warn in warnings:
        print(f"WARNING: {warn}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
