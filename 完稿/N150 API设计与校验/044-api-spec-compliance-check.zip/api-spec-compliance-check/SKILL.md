---
name: api-spec-compliance-check
description: review api definitions, inventories, annotations, or live implementations against project-level api policy, rfc-2119 severity rules, contract checks, implementation checks, and cross-api consistency requirements. use as the n150 design-time gate to produce api规范检查单.csv before code generation, test orchestration, or documentation, with explicit coverage ratio when evidence is partial.
---
# api-spec-compliance-check

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> API设计 -> 规范校验与设计期门禁」。

它是 **gate_result** 型技能：不负责发明接口本身，而是对接口设计做 **节点自检 / 设计期守门**，并形成 N150 节点标准校验产物 **`API规范检查单.csv`**。

## Boundary / 边界
- 负责检查 API 设计、规范、契约、实现对齐与跨 API 一致性。
- 负责给出 RFC 2119 严重级、gate decision、检查覆盖度、修复建议与 CI / lint 接口。
- 不直接替代 043 设计接口，也不替代 045 设计错误码。
- 不自动补齐 API，不 auto-fix 设计；发现缺失 CRUD、缺状态迁移 API 或 family completeness 问题时，只发 SHOULD / MUST finding 并回传 043。
- 错误码覆盖度最终判断归 045；本 skill 只发出缺失、未引用、不一致的检查信号。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness`、`artifact_contract` 和 `evidence_profile`。

允许 4 种模式：
- `design_gate`：N150 内部默认模式；消费 043 输出，执行设计期 gate。
- `audit_existing`：对现有 OpenAPI、接口文档、注解、实现进行全量审查。
- `lint_pr`：只审查变更接口与受影响共享规则。
- `emit_spectral_rules`：在正常审查基础上补规则导出与 CI 集成建议。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `接口设计草案.yaml` from `043/api-design-recommendation`
- `开发需求解析.md` from `N120/engineering-requirement-parsing`
- `接口意图清单.csv` from `N120/api-intent-extraction`
- `技术方案分析.md` from `N130/technical-solution-analysis`

### 可选增强输入
- `业务规则清单.csv` from `N070/business-rule-extraction`
- `权限矩阵.csv` from `N070/permission-matrix-extraction`
- `错误码清单.csv` from `045/api-error-code-design`
- 现有 OpenAPI、注解、控制器清单、历史规范、CI 配置、组织级 API 标准

## Minimum viable input / 最小启动条件
- `confirmed` 输出：需要 043 contract 或等价 OpenAPI / API inventory + policy baseline。
- `partial` 输出：只有接口清单或 PR diff 时，只检查 L1/L2 可验证规则，并输出 `coverage_ratio`。
- `blocked` 输出：没有 API surface 或无法判断 policy baseline 时，不给 pass；输出 blocked / unknown 项。

## Standalone rule / 独立使用规则
即使没有完整 043 输出，也可以单独使用。

降级规则：
- 若没有统一 policy baseline，必须先生成 provisional baseline，并显式降低 gate 置信度。
- 缺证据时要把未检查项列为 `blocked / unknown`，不能伪装成 pass。
- 不得把“暂时没看到问题”写成“已经合规”。
- 必须输出 `gate_coverage.coverage_ratio` 与 degraded reason。

## Core output contract / 核心输出契约
默认输出应以结构化检查表为主，可附 Markdown 摘要。优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `artifact_contract` per `references/SHARED_CONTRACT.md`
- `metadata`
  - `selected_mode`
  - `readiness`
  - `correlation_id`
  - `function_bias: gate_result`
  - `stage_position: technical_solution_design.api_design.compliance_gate`
  - `node_artifact_target: API规范检查单.csv`
  - `workflow_node: N150`
  - `gate_role: node_self_check`
  - `evidence_profile`
  - `contract_fingerprint`
  - `fingerprint_version`
- `policy_baseline_source`
- `gate_coverage`
  - `apis_checked`
  - `total_apis_detected`
  - `rules_checked`
  - `rules_applicable`
  - `coverage_ratio`
  - `degraded_reason[]`
  - `confidence`
- `rule_catalog_applied`
- `findings[]`
- `cross_api_consistency_findings[]`
- `automation_integration`
- `gate_decision`
- `emit_events[]`
- `feedback_handoff`
  - `loop_back_to`: `api-design-recommendation`, `api-error-code-design`
  - `workflow_downstream_effect`: `N190`, `N200`, `N240`, `N330`
  - `artifact_name: API规范检查单.csv`
- `self_check`

### Required fields for every finding
- `check_id`
- `rule_category`
- `severity`
- `check_level`
- `api_ref`
- `status`
- `rule`
- `violation_detail`
- `fix_suggestion`
- `evidence`
- `owner_skill`: `api-design-recommendation` | `api-error-code-design` | `upstream` | `human`

## Review rules / 评审规则
### Gate discipline / 门禁纪律
- 任一 unresolved `MUST` 或 `MUST_NOT` 违规都应 fail gate。
- `SHOULD / SHOULD_NOT` 默认不阻塞，但需要记录与追踪。
- `MAY` 只做信息提示，不得包装成 blocker。
- `family_completeness` 只产生 finding 和回传建议；不得替 043 自动生成接口。

### Coverage discipline / 覆盖度纪律
- `coverage_ratio = rules_checked / rules_applicable`，必要时也给出 API 覆盖率。
- 默认阈值：`coverage_ratio < 0.70` 时，gate 结果不得标为 fully confirmed pass。
- 默认阈值：`coverage_ratio < 0.40` 时，默认 `readiness: partial` 或 `blocked`。
- 阈值可由项目级 `api_policy.gate_thresholds` 调整；若调整，必须在 `policy_baseline_source` 与 `gate_coverage.degraded_reason` 中说明。
- 所有 `unknown` 都必须解释是缺 API contract、缺 policy、缺业务规则还是缺错误码 registry。

### Cross-API consistency discipline / 跨 API 一致性纪律
只要有足够接口面，就必须检查：
- shared ID type consistency
- field semantic consistency
- pagination parameter consistency
- error response shape consistency
- time format consistency
- monetary field consistency
- CRUD behavior consistency
- auth mechanism consistency
- request ID header consistency
- versioning consistency

### Design-time gate discipline / 设计期守门纪律
若 043 仍在草拟：
- 先跑 `MUST / MUST_NOT`
- 立即把 blocker 回馈给 043 / 045
- 不要等到 N150 末尾才暴露本可前置避免的问题
- 单次 N150 内自动回环最多两轮；仍失败则输出 blocked 并要求人工确认

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`artifact_contract`、`evidence_profile`。
2. 读取 043 的 policy baseline 或生成 provisional baseline。
3. 区分可检查范围、blocked 范围、未定义范围，并计算 `gate_coverage`。
4. 运行 L1 / L2 / L3 检查。
5. 按 `rule_category` 与 `severity` 分组 findings。
6. 运行 cross-API consistency 检查。
7. 形成 **`API规范检查单.csv`** 与 `gate_decision`。
8. 输出 `feedback_handoff` 与 `emit_events`，把 blocker 回传 043 / 045，并说明对 N190 / N200 / N240 / N330 的影响。
9. 在需要时给出 lint / CI / spectral 集成建议。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- PR diff：聚焦变更接口与受影响共识规则。
- 中型系统：覆盖全部规则类别与跨 API 一致性。
- 大型平台：优先暴露 blocker 风险、共享组件漂移与标准退化热点。

不要把 audit 写成流水账，也不要把例外当成通过。

## Quality bar / 质量门槛
合格结果应能被 N150 当作设计期 gate 使用，并能指导 043 / 045 返修与下游 CI 集成。

使用以下参考文件自检：
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/check-catalog.md`
- `references/severity-model.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/output-template.md`
- `references/check-catalog.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/severity-model.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
