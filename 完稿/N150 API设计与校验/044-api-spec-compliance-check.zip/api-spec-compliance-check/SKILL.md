---
name: api-spec-compliance-check
description: gate api definitions against project policy, rfc-2119 severity rules, and cross-api consistency. triggers on 接口设计草案.yaml. n150 design-time gate.
---
# api-spec-compliance-check


## Check catalog quick-reference
Full catalog in `references/check-catalog.md`. Top 10 most commonly violated rules:

| Check ID | Severity | Rule | Common violation |
|---|---|---|---|
| R-METHOD-001 | MUST_NOT | GET must not mutate state | approval/cancel via GET |
| R-PAGINATION-001 | MUST | list endpoints must declare pagination | `GET /items` without cursor/offset |
| R-ERROR-FORMAT-001 | MUST | error responses must conform to api_policy error_format | mixed `{code,message}` and RFC 7807 |
| R-IDEMPOTENCY-001 | SHOULD | POST/PUT/PATCH should declare idempotency mechanism | no `X-Idempotency-Key` on write APIs |
| R-AUTH-001 | MUST | every API must declare auth requirement | auth field missing or `auth: none` without justification |
| R-REQUEST-ID-001 | SHOULD | every API should support `X-Request-ID` tracing | header undocumented |
| R-ENVELOPE-001 | MUST | response envelope must match api_policy | ad-hoc response shapes |
| R-VERSION-001 | MUST | all APIs must carry version in URI or header | unversioned paths |
| R-NAMING-001 | SHOULD | resource names should be plural nouns | `/user` instead of `/users` |
| R-SENSITIVE-001 | MUST_NOT | PII must not appear in query parameters | `?email=user@example.com` in URL |

## Severity model quick-reference (RFC 2119)
| Severity | RFC keyword | Gate effect | Action |
|---|---|---|---|
| `MUST` / `MUST_NOT` | SHALL / SHALL_NOT | blocks gate | fix before proceeding |
| `SHOULD` / `SHOULD_NOT` | RECOMMENDED | warns | fix recommended; accept with rationale |
| `MAY` | OPTIONAL | informational | no gate effect |

**Gate decision rules**:
- Any unresolved `MUST`/`MUST_NOT` finding → `gate: fail`
- All `MUST` pass, ≥1 `SHOULD` open → `gate: warn`
- All findings resolved or explicitly accepted → `gate: pass`
- Evidence missing for ≥20% of APIs → cap at `gate: partial`

**Boundary rule**: this skill emits findings only — it does NOT auto-fix or invent APIs. When a missing API is found, emit a `SHOULD` finding and route back to 043.


## Trigger conditions
Gate API spec compliance when any of the following are present:
- `接口设计草案.yaml` from 043
- any OpenAPI spec, API inventory, or controller annotations
- explicit compliance check or audit requests
- PR diff of API changes for `lint_pr` mode

## Standalone rule
Use `selected_mode: design_gate` inside N150. Without 043 output, generate provisional `policy_baseline` from available evidence. Set `gate_coverage.coverage_ratio` and `degraded_reason[]` explicitly when inputs are partial.

## Role and boundary
本 skill 对齐 skills_workflow 中in the technical-solution-design -> API设计 -> 规范校验与设计期门禁」。

它是 **gate_result** 型技能：不负责发明接口本身，而是对接口设计做 **节点自检 / 设计期守门**，并形成 N150 节点标准校验产物 **`API规范检查单.csv`**。

## Boundary
- 负责检查 API 设计、规范、契约、实现对齐与跨 API 一致性。
- 负责给出 RFC 2119 严重级、gate decision、检查覆盖度、修复建议与 CI / lint 接口。
- 不直接替代 043 设计接口，也不替代 045 设计错误码。
- 不自动补齐 API，不 auto-fix 设计；发现缺失 CRUD、缺状态迁移 API 或 family completeness 问题时，只发 SHOULD / MUST finding 并回传 043。
- 错误码覆盖度最终判断归 045；本 skill 只发出缺失、未引用、不一致的检查信号。

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness`、`artifact_contract` 和 `evidence_profile`。

允许 4 种模式：
- `design_gate`：N150 内部默认模式；消费 043 输出，执行设计期 gate。
- `audit_existing`：对现有 OpenAPI、接口文档、注解、实现进行全量审查。
- `lint_pr`：只审查变更接口与受影响共享规则。
- `emit_spectral_rules`：在正常审查基础上补规则导出与 CI 集成建议。

## Primary inputs
### workflow 对齐的推荐输入
- `接口设计草案.yaml` from `043/api-design-recommendation`
- `开发需求解析.md` from `N120/engineering-requirement-parsing`
- `接口意图清单.csv` from `N120/api-intent-extraction`
- `技术方案分析.md` from `N130/technical-solution-analysis`

### 可选增强输入
- `业务规则清单.csv` from `N070/business-rule-extraction`
- `权限矩阵.csv` from `N070/permission-matrix-extraction`
- `错误码清单.csv` from `045/api-error-code-design`
- 现有 OpenAPI、注解、控制器清单、历史规范、CI 配置、组织级 API 标准

## Minimum viable input
- `confirmed` 输出：需要 043 contract 或等价 OpenAPI / API inventory + policy baseline。
- `partial` 输出：只有接口清单或 PR diff 时，只检查 L1/L2 可验证规则，并输出 `coverage_ratio`。
- `blocked` 输出：没有 API surface 或无法判断 policy baseline 时，不给 pass；输出 blocked / unknown 项。

## Downstream handoff summary
Gate results flow to:
- `loop_back_to_043`: MUST/MUST_NOT findings requiring API redesign
- `loop_back_to_045`: error-format inconsistencies requiring registry update
- `to_N190_code_generation`: gate pass required before code generation begins
- `to_N330_documentation`: coverage_ratio and gate decision included in API docs

## Standalone rule
即使没有完整 043 输出，也可以单独使用。

降级规则：
- 若没有统一 policy baseline，必须先生成 provisional baseline，并显式降低 gate 置信度。
- 缺证据时要把未检查项列为 `blocked / unknown`，不能伪装成 pass。
- 不得把“暂时没看到问题”写成“已经合规”。
- 必须输出 `gate_coverage.coverage_ratio` 与 degraded reason。

## Core output contract
默认输出应以结构化检查表为主，可附 Markdown 摘要。优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `artifact_contract` per `references/SHARED_CONTRACT.md`
- `metadata`
  - `selected_mode`
  - `readiness`
  - `correlation_id`
  - `function_bias: gate_result`
  - `stage_position: technical_solution_design.api_design.compliance_gate`
  - `node_artifact_target: API规范检查单.csv`
  - `workflow_node: N150`
  - `gate_role: node_self_check`
  - `evidence_profile`
  - `contract_fingerprint`
  - `fingerprint_version`
- `policy_baseline_source`
- `gate_coverage`
  - `apis_checked`
  - `total_apis_detected`
  - `rules_checked`
  - `rules_applicable`
  - `coverage_ratio`
  - `degraded_reason[]`
  - `confidence`
- `rule_catalog_applied`
- `expected_route_families[]`
- `route_inventory_comparison[]`
- `route_compatibility_waivers[]`
- `findings[]`
- `cross_api_consistency_findings[]`
- `automation_integration`
- `gate_decision`
- `emit_events[]`
- `feedback_handoff`
  - `loop_back_to`: `api-design-recommendation`, `api-error-code-design`
  - `workflow_downstream_effect`: `N190`, `N200`, `N240`, `N330`
  - `artifact_name: API规范检查单.csv`
- `self_check`

### Required fields for every finding
- `check_id`
- `rule_category`
- `severity`
- `check_level`
- `api_ref`
- `status`
- `rule`
- `violation_detail`
- `fix_suggestion`
- `evidence`
- `owner_skill`: `api-design-recommendation` | `api-error-code-design` | `upstream` | `human`

## Review rules
### Gate discipline / 门禁纪律
- 任一 unresolved `MUST` 或 `MUST_NOT` 违规都应 fail gate。
- `SHOULD / SHOULD_NOT` 默认不阻塞，但需要记录与追踪。
- `MAY` 只做信息提示，不得包装成 blocker。
- `family_completeness` 只产生 finding 和回传建议；不得替 043 自动生成接口。

### Coverage discipline / 覆盖度纪律
- `coverage_ratio = rules_checked / rules_applicable`，必要时也给出 API 覆盖率。
- 默认阈值：`coverage_ratio < 0.70` 时，gate 结果不得标为 fully confirmed pass。
- 默认阈值：`coverage_ratio < 0.40` 时，默认 `readiness: partial` 或 `blocked`。
- 阈值可由项目级 `api_policy.gate_thresholds` 调整；若调整，必须在 `policy_baseline_source` 与 `gate_coverage.degraded_reason` 中说明。
- 所有 `unknown` 都必须解释是缺 API contract、缺 policy、缺业务规则还是缺错误码 registry。

### Cross-API consistency discipline / 跨 API 一致性纪律
只要有足够接口面，就必须检查：
- shared ID type consistency
- field semantic consistency
- pagination parameter consistency
- error response shape consistency
- time format consistency
- monetary field consistency
- CRUD behavior consistency
- auth mechanism consistency
- request ID header consistency
- versioning consistency

### Route inventory drift discipline / 路由清单漂移纪律
- When 043, PRD, OpenAPI, or route intent inputs define route families and a controller/OpenAPI/API gateway inventory is available, compare expected route families against actual route inventory before gate decision.
- Missing expected prefixes, deprecated prefixes, or similar-but-different prefixes such as `/foo/bar` vs `/foo-bar` are `MUST` findings unless a documented `route_compatibility_waiver` exists.
- Emit `route_inventory_comparison[]` with expected prefix, matched routes, drift routes, source refs, severity, and gate effect.
- Do not auto-fix or invent routes. Route drift findings loop back to 043 or the API owner for an explicit compatibility decision.
- Run `scripts/validate_route_drift.py --expected <expected-routes.json> --actual <route-inventory.json>` when route family and inventory inputs are available.

### Design-time gate discipline / 设计期守门纪律
若 043 仍在草拟：
- 先跑 `MUST / MUST_NOT`
- 立即把 blocker 回馈给 043 / 045
- 不要等到 N150 末尾才暴露本可前置避免的问题
- 单次 N150 内自动回环最多两轮；仍失败则输出 blocked 并要求人工确认

## Execution workflow
1. 识别 `selected_mode`、`readiness`、`artifact_contract`、`evidence_profile`。
2. 读取 043 的 policy baseline 或生成 provisional baseline。
3. 区分可检查范围、blocked 范围、未定义范围，并计算 `gate_coverage`。
4. 运行 L1 / L2 / L3 检查。
5. 在有 controller/OpenAPI/API gateway inventory 时运行 route inventory drift check。
6. 按 `rule_category` 与 `severity` 分组 findings。
7. 运行 cross-API consistency 检查。
8. 形成 **`API规范检查单.csv`** 与 `gate_decision`。
9. 输出 `feedback_handoff` 与 `emit_events`，把 blocker 回传 043 / 045，并说明对 N190 / N200 / N240 / N330 的影响。
10. 在需要时给出 lint / CI / spectral 集成建议。
11. 使用 checklist、route drift validator 与 common-failure review 自检。

## Dynamic completeness
- PR diff：聚焦变更接口与受影响共识规则。
- 中型系统：覆盖全部规则类别与跨 API 一致性。
- 大型平台：优先暴露 blocker 风险、共享组件漂移与标准退化热点。

不要把 audit 写成流水账，也不要把例外当成通过。

## Quality bar
合格结果应能被 N150 当作设计期 gate 使用，并能指导 043 / 045 返修与下游 CI 集成。

使用以下参考文件自检：
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/check-catalog.md`
- `references/severity-model.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/output-template.md`
- `references/check-catalog.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/severity-model.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`


## Confidence discipline
Every finding must declare evidence quality. Separate confirmed blockers from inferred warnings.
- `evidence_quality: confirmed` — finding has direct evidence from spec or code
- `evidence_quality: inferred` — deduced from policy interpretation; may need clarification  
- `evidence_quality: pending` — evidence requires additional access

A `gate: pass` with inferred evidence carries `confidence: partial`.
## v2 artifact contract additions

```yaml
artifact_schema_version: n150.v2.1.0
skill_name: api-spec-compliance-check
produced_event: produced.n150.api_compliance_check.v2
blocker_mapping: B-N150-02
correlation_id: ""    # REQUIRED: must match 043 and 045 in same N150 run
contract_fingerprint: ""
fingerprint_version: "1"
rule_results:
  - rule_id: R01_gate_decision_declared
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_coverage_ratio_present
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R03_must_findings_have_fix_suggestions
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R04_cross_api_consistency_checked
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R05_error_coverage_signaled_to_045
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R06_coverage_ratio_explicit
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R07_waivers_recorded_not_hidden
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R08_route_inventory_drift_checked
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R08_cross_api_consistency_checked
    severity: warn
    result: pass | warn | reject | not_applicable
feedback_signal_to_n005:
  signal_type: none | recurring_compliance_failures | spec_debt_signal
  summary: ""
  target_n070_skills:
  - 014-business-rule-extraction
  - 016-permission-matrix-extraction
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
route_back_to: none | api-design
# none       — gate passed; 045 may proceed
# api-design — MUST/MUST_NOT violations found; 043 must revise before gate re-run
eventbus_subscribers: [N330]
# N330 → API规范检查报告归档 (triggered on produced.n150.api_compliance_report)
```

## Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| `业务规则清单.md` (014) | hardness=constraint rules | MUST compliance checks |
| `权限矩阵.csv` (016) | subject, grain, evaluation_algo | auth compliance checks |
| `验收标准.md` (032) | acceptance criteria | gate pass/fail evidence |
