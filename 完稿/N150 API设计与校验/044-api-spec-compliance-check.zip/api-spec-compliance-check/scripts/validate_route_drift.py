#!/usr/bin/env python3
"""Compare expected route families against actual controller/OpenAPI route inventory.

Usage:
    python scripts/validate_route_drift.py --expected expected_routes.json --actual route_inventory.json

Inputs are JSON/YAML objects. Expected input uses `expected_route_families[]`.
Actual input uses `route_inventory[]` and optional `route_compatibility_waivers[]`.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None


VALID_WAIVER_STATUSES = {"accepted", "temporary", "documented"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate route prefix drift for 044 API compliance checks")
    parser.add_argument("--expected", required=True, help="JSON/YAML with expected_route_families[]")
    parser.add_argument("--actual", required=True, help="JSON/YAML with route_inventory[]")
    return parser.parse_args()


def load_doc(path: Path) -> Any:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        return json.loads(text)
    if path.suffix.lower() in {".yaml", ".yml"}:
        if yaml is None:
            raise RuntimeError("PyYAML is required for YAML artifacts; use JSON or install PyYAML")
        return yaml.safe_load(text)
    raise ValueError("supported files: .json, .yaml, .yml")


def norm_path(value: Any) -> str:
    text = str(value).strip()
    if not text:
        return ""
    if not text.startswith("/"):
        text = "/" + text
    while len(text) > 1 and text.endswith("/"):
        text = text[:-1]
    return text


def compact_path(path: str) -> str:
    return norm_path(path).replace("/", "").replace("-", "").replace("_", "").lower()


def route_startswith(route: str, prefix: str) -> bool:
    route = norm_path(route)
    prefix = norm_path(prefix)
    return route == prefix or route.startswith(prefix + "/")


def extract_routes(actual: dict[str, Any]) -> list[dict[str, str]]:
    rows = actual.get("route_inventory", actual.get("controller_routes", actual.get("routes", [])))
    result: list[dict[str, str]] = []
    if not isinstance(rows, list):
        return result
    for row in rows:
        if isinstance(row, str):
            result.append({"route": norm_path(row), "source_ref": ""})
        elif isinstance(row, dict):
            route = row.get("route", row.get("path", row.get("path_or_topic", "")))
            result.append({"route": norm_path(route), "source_ref": str(row.get("source_ref", ""))})
    return [row for row in result if row["route"]]


def has_waiver(actual: dict[str, Any], expected_prefix: str, actual_prefix: str | None = None) -> bool:
    waivers = actual.get("route_compatibility_waivers", actual.get("compatibility_waivers", []))
    if not isinstance(waivers, list):
        return False
    for waiver in waivers:
        if not isinstance(waiver, dict):
            continue
        status = str(waiver.get("status", "")).strip().lower()
        if status not in VALID_WAIVER_STATUSES:
            continue
        expected_ok = norm_path(waiver.get("expected_prefix", "")) == norm_path(expected_prefix)
        actual_ok = actual_prefix is None or norm_path(waiver.get("actual_prefix", "")) == norm_path(actual_prefix)
        if expected_ok and actual_ok and waiver.get("waiver_id"):
            return True
    return False


def main() -> int:
    args = parse_args()
    expected = load_doc(Path(args.expected))
    actual = load_doc(Path(args.actual))
    if not isinstance(expected, dict) or not isinstance(actual, dict):
        print("INVALID")
        print("- expected and actual roots must be objects")
        return 1

    families = expected.get("expected_route_families", [])
    routes = extract_routes(actual)
    if not isinstance(families, list) or not families:
        print("INVALID")
        print("- expected.expected_route_families[] is required")
        return 1
    if not routes:
        print("INVALID")
        print("- actual route inventory is empty")
        return 1

    errors: list[str] = []
    warnings: list[str] = []
    actual_paths = [row["route"] for row in routes]

    deprecated = [norm_path(p) for p in expected.get("deprecated_prefixes", []) if norm_path(p)]
    for route in actual_paths:
        for prefix in deprecated:
            if route_startswith(route, prefix):
                errors.append(f"route {route} uses deprecated prefix {prefix}")

    for family in families:
        if not isinstance(family, dict):
            errors.append("expected_route_families[] entries must be objects")
            continue
        expected_prefix = norm_path(family.get("route_family", family.get("required_prefix", "")))
        family_id = str(family.get("family_id", expected_prefix))
        if not expected_prefix:
            errors.append(f"{family_id}: route_family is required")
            continue
        matches = [route for route in actual_paths if route_startswith(route, expected_prefix)]
        if matches:
            continue

        similar = [
            route for route in actual_paths
            if compact_path(route).startswith(compact_path(expected_prefix))
            or compact_path(expected_prefix).startswith(compact_path(route))
        ]
        if similar:
            unwaived = [route for route in similar if not has_waiver(actual, expected_prefix, route.rsplit("/", 1)[0])]
            if unwaived:
                errors.append(
                    f"{family_id}: expected prefix {expected_prefix} missing; similar drift routes found {unwaived} without compatibility waiver"
                )
            else:
                warnings.append(f"{family_id}: expected prefix {expected_prefix} covered by documented compatibility waiver")
            continue

        if not has_waiver(actual, expected_prefix):
            errors.append(f"{family_id}: expected prefix {expected_prefix} missing from route inventory")

    if errors:
        print("INVALID")
        for err in errors:
            print(f"- {err}")
        for warn in warnings:
            print(f"WARNING: {warn}")
        return 1
    print("VALID")
    for warn in warnings:
        print(f"WARNING: {warn}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
