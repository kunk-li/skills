# Common failure modes — api-spec-compliance-check

## F1: findings without a baseline
Symptom: A list of issues is presented but the `policy_baseline_source` is not stated — reviewers cannot verify which rules were applied.
Fix: State the policy source before listing findings. Every finding must cite the specific rule from the policy or from `references/check-catalog.md`.

## F2: equal severity for all findings
Symptom: All findings are labeled 'issue' or 'problem' regardless of whether they are MUST violations or MAY suggestions.
Fix: Use RFC 2119 severity exactly: `MUST`/`MUST_NOT` blockers → `gate: fail`; `SHOULD` warnings → `gate: warn`; `MAY` → informational. Never inflate a SHOULD to a blocker.

## F3: single-endpoint checking only
Symptom: The output lists findings per endpoint but never checks whether naming conventions, pagination styles, and error formats are consistent across the API surface.
Fix: Run cross-API consistency checks when ≥3 APIs exist. Drift across APIs is often more damaging than a single-endpoint violation.

## F4: auto-fixing instead of finding
Symptom: The compliance check invents a corrected API design and presents it as the result, replacing 043's work.
Fix: Gate role: emit findings only. When a missing API is detected, emit a SHOULD finding and route back to 043. Never insert new APIs or rewrite contracts.

## F5: coverage ratio hidden
Symptom: The output gives a gate decision (pass/fail) but never states how many APIs were actually checked versus the total detected.
Fix: Always emit `gate_coverage.coverage_ratio` and `degraded_reason[]`. An 80% check with 20% unknown areas cannot give a confident `gate: pass`.

## F6: exception waivers hidden
Symptom: An intentional policy deviation is marked as a pass because 'the team agreed to it' — but there is no waiver record.
Fix: Record all intentional exceptions as waivers with `owner`, `rationale`, and `review_trigger`. Hidden waivers appear as passes and mislead future audits.

## F7: route prefix drift hidden by partial API review
Symptom: The PRD or 043 contract expects one route family, but controller/OpenAPI/gateway inventory exposes a similar different prefix, and 044 only checks the written API draft.
Fix: Compare expected route families against actual route inventory. Emit a MUST finding unless `route_compatibility_waivers[]` documents the compatibility route with owner and review trigger.
