# Mode Selection v2.2

- Use `design_gate` inside N150 after 043 creates or revises `接口设计草案.yaml`.
- Use `audit_existing` for full review of existing APIs, OpenAPI, annotations, or live implementation inventory.
- Use `lint_pr` for a diff-scoped review of changed APIs and impacted shared rules.
- Use `emit_spectral_rules` only when the user asks for CI/lint export; it is an add-on, not the default.

Always compute `gate_coverage`. If coverage is low, do not label the gate as a fully confirmed pass.
