# Scoring Rubric v2.3: API Spec Compliance Check

Score 1-5 for each dimension.

| Dimension | 5 means | 1 means |
|---|---|---|
| Gate correctness | MUST/MUST_NOT handling is precise and actionable | blockers are missed or non-blockers are inflated |
| Coverage transparency | coverage_ratio and unknown areas are explicit | pass/fail hides missing evidence |
| Evidence quality | every finding has concrete evidence and location | findings are vague opinions |
| Boundary control | emits findings without auto-fixing or inventing APIs | gate rewrites design silently |
| Feedback quality | owners, fixes, and loop-back targets are clear | findings do not guide 043/045 |
| Cross-API consistency | repeated conventions and drift are detected | only isolated endpoint lint is done |
| Traceability hygiene | correlation_id links findings, emitted events, and N150 sibling artifacts | gate results cannot be traced to a run |
| Idempotency verifiability | contract_fingerprint and fingerprint_version make repeated gate runs comparable | gate output changes cannot be distinguished from formatting noise |
