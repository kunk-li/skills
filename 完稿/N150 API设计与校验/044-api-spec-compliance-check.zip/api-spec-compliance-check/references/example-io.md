# Example Input / Output

## Example input
A project has a draft API contract for leave requests:
- `POST /api/v1/leave-requests` creates a leave request.
- `GET /api/v1/leave-requests` lists requests but omits pagination.
- `GET /api/v1/leave-requests/{id}/approve` approves a request.
- Error format is RFC 7807, but two APIs return `{code,message}`.

## Example output sketch

```yaml
artifact_contract:
  artifact_schema_version: n150.api_contract.v2.2
  producer_skill_id: api-spec-compliance-check
  selected_mode: design_gate
  readiness: partial
  correlation_id: n150-leave-001
  contract_fingerprint: null
  fingerprint_version: n150-fingerprint-v1

gate_coverage:
  apis_checked: 3
  total_apis_detected: 3
  rules_checked: 18
  rules_applicable: 24
  coverage_ratio: 0.75
  degraded_reason: [missing_error_registry]
  confidence: medium

gate_decision: fail

findings:
  - check_id: R-METHOD-001
    rule_category: http_method_semantics
    severity: blocker
    check_level: MUST_NOT
    api_ref: leave-request-approve
    status: open
    rule: GET must not mutate state
    violation_detail: approval endpoint uses GET for a state transition
    fix_suggestion: change to POST /api/v1/leave-requests/{requestId}/approval
    owner_skill: api-design-recommendation
  - check_id: R-PAGINATION-001
    rule_category: collection_contract
    severity: major
    check_level: MUST
    api_ref: leave-request-list
    status: open
    rule: list APIs must declare pagination
    fix_suggestion: add cursor pagination params and response metadata
    owner_skill: api-design-recommendation
  - check_id: R-ERROR-001
    rule_category: error_format_consistency
    severity: major
    check_level: SHOULD
    api_ref: [leave-request-create, leave-request-approve]
    status: open
    rule: error response must conform to API policy
    fix_suggestion: align responses to RFC 7807; ask 045 to confirm code registry coverage
    owner_skill: api-error-code-design

emit_events:
  - event_type: exception.n150.api_contract_blocker
    rerun_hint: [api-design-recommendation]
```

## Notes
- The gate is `fail` because a `MUST_NOT` HTTP semantic violation is unresolved.
- The coverage ratio is high enough for a meaningful design gate, but not enough for final confirmed pass because the error registry is missing.
- 044 does not rewrite the API; it routes fixes to 043 and 045.
