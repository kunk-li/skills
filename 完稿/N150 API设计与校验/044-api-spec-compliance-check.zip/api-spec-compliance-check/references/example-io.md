# Example Input / Output

## Example input
A project has a draft API contract for leave requests:
- `POST /api/v1/leave-requests` creates a leave request.
- `GET /api/v1/leave-requests` lists requests but omits pagination.
- `GET /api/v1/leave-requests/{id}/approve` approves a request.
- Error format is RFC 7807, but two APIs return `{code,message}`.

## Example output sketch

```yaml
artifact_contract:
  artifact_schema_version: n150.api_contract.v2.2
  producer_skill_id: api-spec-compliance-check
  selected_mode: design_gate
  readiness: partial
  correlation_id: n150-leave-001
  contract_fingerprint: null
  fingerprint_version: n150-fingerprint-v1

gate_coverage:
  apis_checked: 3
  total_apis_detected: 3
  rules_checked: 18
  rules_applicable: 24
  coverage_ratio: 0.75
  degraded_reason: [missing_error_registry]
  confidence: medium

gate_decision: fail

findings:
  - check_id: R-METHOD-001
    rule_category: http_method_semantics
    severity: blocker
    check_level: MUST_NOT
    api_ref: leave-request-approve
    status: open
    rule: GET must not mutate state
    violation_detail: approval endpoint uses GET for a state transition
    fix_suggestion: change to POST /api/v1/leave-requests/{requestId}/approval
    owner_skill: api-design-recommendation
  - check_id: R-PAGINATION-001
    rule_category: collection_contract
    severity: major
    check_level: MUST
    api_ref: leave-request-list
    status: open
    rule: list APIs must declare pagination
    fix_suggestion: add cursor pagination params and response metadata
    owner_skill: api-design-recommendation
  - check_id: R-ERROR-001
    rule_category: error_format_consistency
    severity: major
    check_level: SHOULD
    api_ref: [leave-request-create, leave-request-approve]
    status: open
    rule: error response must conform to API policy
    fix_suggestion: align responses to RFC 7807; ask 045 to confirm code registry coverage
    owner_skill: api-error-code-design

emit_events:
  - event_type: exception.n150.api_contract_blocker
    rerun_hint: [api-design-recommendation]
```

## Notes
- The gate is `fail` because a `MUST_NOT` HTTP semantic violation is unresolved.
- The coverage ratio is high enough for a meaningful design gate, but not enough for final confirmed pass because the error registry is missing.
- 044 does not rewrite the API; it routes fixes to 043 and 045.

## CI/lint integration example — Spectral rule export

```yaml
automation_integration:
  spectral_ruleset_hint:
    format: spectral-v6
    file: .spectral.yaml
    rules:
      - name: must-have-request-id-header
        severity: error
        given: "$.paths.*.*.parameters"
        then:
          field: name
          function: enumeration
          functionOptions:
            values: [X-Request-ID]
      - name: pagination-on-list-endpoints
        severity: warn
        given: "$.paths[?(@match('[GET]') && @match('/s$'))]"
        then:
          field: "parameters[?(@.name == 'cursor' || @.name == 'offset')]"
          function: truthy
      - name: error-format-must-include-code
        severity: error
        given: "$.paths.*.*.responses.*.content.application/json.schema"
        then:
          field: properties.error_code
          function: truthy

  ci_pipeline_integration:
    tool: spectral
    command: "spectral lint ./api-spec/*.yaml --ruleset .spectral.yaml"
    fail_on: error
    warn_on: warn
    gate_position: "pre-code-generation (before N190)"
    note: "044 findings map to spectral severity: MUST → error, SHOULD → warn, MAY → info"
```

## ex-002 · constrained gate with coverage ratio and IDs

```yaml
metadata:
  artifact_schema_version: n150.api_contract.v2.2
  producer_skill_id: api-spec-compliance-check
  selected_mode: design_gate
  readiness: partial
  correlation_id: n150-order-run-001
  contract_fingerprint: null
  fingerprint_version: n150-fingerprint-v1

gate_coverage:
  apis_checked: 4
  total_apis_detected: 5
  rules_checked: 20
  rules_applicable: 28
  coverage_ratio: 0.71
  degraded_reason: [API-005 missing spec — not checked]
  confidence: low

gate_decision: fail

findings:
  - check_id: R-METHOD-001
    api_ref: API-002
    rule: "GET must not mutate state"
    severity: blocker
    evidence: "API-002 approval endpoint uses GET /orders/{id}/approve"
    fix_suggestion: "Change to POST /orders/{id}/approval"
    owner_skill: api-design-recommendation

  - check_id: R-PAGINATION-001
    api_ref: API-003
    rule: "List APIs must declare pagination"
    severity: major
    evidence: "API-003 GET /orders has no cursor or offset parameters"
    fix_suggestion: "Add cursor pagination per api_policy"
    owner_skill: api-design-recommendation

  - check_id: R-ERROR-001
    api_ref: [API-002, API-003]
    rule: "Error responses must conform to api_policy error_format"
    evidence: "API-002 returns {code, message}; policy requires RFC 7807"
    severity: major
    owner_skill: api-error-code-design

waivers: []

rule_results:
  - {rule_id: R06_coverage_ratio_explicit, severity: reject, result: pass}
  - {rule_id: R07_waivers_recorded_not_hidden, severity: reject, result: pass}
  - {rule_id: R08_cross_api_consistency_checked, severity: warn, result: pass}

negative_case:
  scenario: "Gate passes without checking all APIs (coverage_ratio=1.0 but 1 API not reviewed)"
  risk: "Unchecked API-005 may have MUST violations that block N190 code generation"
  correct_behavior: "coverage_ratio must reflect actual checked/detected ratio; never fake 1.0"

emit_events:
  - event_type: exception.n150.api_contract_blocker
    correlation_id: n150-order-run-001
    rerun_hint: [api-design-recommendation]
```

## ex-003 · blocked — no api_policy baseline to check against

```yaml
skill_name: api-spec-compliance-check
readiness: blocked
blocker_mapping: B-N150-02
route_back_to: api-design-recommendation

blockers:
  - blocker_id: BLK-CHECK-001
    type: missing_policy_baseline
    description: "043 api-design-recommendation has not produced api_policy — compliance check has no standard to verify against"
    impact: "Every compliance check requires a baseline. Without api_policy, all findings would be against generic industry defaults, not project-specific rules."
    resolution_required: "043 must produce api_policy before 044 can gate"
    unblock_evidence: "api_policy with style, versioning, pagination, response_envelope, and auth_baseline defined"

  - blocker_id: BLK-CHECK-002
    type: spec_not_ready
    description: "接口设计草案.yaml not yet provided — nothing to check"
    impact: "Cannot issue gate decision without a spec"
    resolution_required: "043 must produce initial api_catalog[] and yaml-structure.md export"
    unblock_evidence: "接口设计草案.yaml with at least 1 API documented"

gate_decision: blocked
gate_coverage:
  coverage_ratio: 0.0
  degraded_reason: ["No spec provided", "No policy baseline"]
```

## ex-004 · degraded — partial coverage, policy inferred not confirmed

```yaml
skill_name: api-spec-compliance-check
readiness: provisional
selected_mode: design_gate
gate_coverage:
  apis_checked: 3
  total_apis_detected: 5
  coverage_ratio: 0.60
  degraded_reason: ["API-004 and API-005 missing spec — not checked"]
  confidence: low

policy_source: inferred
policy_source_note: "api_policy not yet produced by 043 — checking against REST industry defaults"

gate_decision: fail
findings:
  - check_id: R-PAGINATION-001
    api_ref: API-003
    severity: major
    evidence: "GET /orders has no pagination — returns all records"
    fix_suggestion: "Add cursor pagination per industry default (offset is acceptable)"
    confidence: confirmed

rule_results:
  - {rule_id: R06_coverage_ratio_explicit, result: pass, evidence: "0.60 stated"}
  - {rule_id: R07_waivers_recorded_not_hidden, result: pass}
  - {rule_id: R08_cross_api_consistency_checked, result: warn, evidence: "Only 3/5 APIs available for cross-check"}

degraded_guidance: "Complete 043 and provide full spec before requesting final gate decision"
```
