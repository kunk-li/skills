# Compatibility map — api-spec-compliance-check v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 043 api-design-recommendation | `api_policy, api_catalog[], shared_schemas[]` | `compliance baseline` | 043 output is primary gate input |
| 037 api-intent-extraction | `intent_id, api_style` | `coverage verification` | intent list verifies all intents have API contracts |
| 045 api-error-code-design | `error_code registry` | `error format consistency check` | 044 signals 045 when error format drifts |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 043 api-design-recommendation | `MUST/MUST_NOT findings` | `revision input (loop_back)` | blockers route back to 043 for redesign |
| 045 api-error-code-design | `error-format findings` | `registry alignment signal` | error inconsistencies signal 045 to update |
| N190 code-generation | `gate: pass required` | `generation gate` | code generation blocked until 044 passes |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
