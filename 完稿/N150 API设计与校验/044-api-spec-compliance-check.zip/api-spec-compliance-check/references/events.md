# N150 Event Contract v2.2

Use these event schemas when the skill participates in the workflow v2 event bus.

- Declaration layer: every N150 artifact should declare the relevant events and payload fields so downstream orchestrators can subscribe consistently.
- Execution layer: do not simulate, publish, or integrate with an actual event bus unless the user or host workflow explicitly asks for executable integration.

## Common payload envelope

```yaml
event:
  event_id: string
  correlation_id: string
  event_type: produced.n150.* | state.n150.* | exception.n150.*
  event_version: v1
  occurred_at: iso8601 | null
  workflow_node: N150
  producer_skill_id: string
  artifact_name: string
  artifact_schema_version: n150.api_contract.v2.2
  readiness: confirmed | provisional | partial | blocked
  contract_fingerprint: string | null
  fingerprint_version: n150-fingerprint-v1 | null
  affected_apis: []
  severity_counts:
    blocker: 0
    major: 0
    warning: 0
    info: 0
  downstream_consumers: []
  rerun_hint: []
  human_review_required: false
```

## Correlation rules

- Use the same `correlation_id` for all events produced by one N150 node execution.
- Propagate the `correlation_id` into `artifact_contract.correlation_id` when the artifact is emitted from a skill.
- If a skill runs standalone outside a workflow, set `correlation_id` to a stable run ID when available; otherwise use `null` in the artifact and explain the limitation.

## Produced events

| Skill | Event type | Trigger |
|---|---|---|
| 043 | `produced.n150.api_contract_draft` | after `接口设计草案.yaml` is created or revised |
| 044 | `produced.n150.api_compliance_report` | after `API规范检查单.csv` and gate decision are produced |
| 044 | `exception.n150.api_contract_blocker` | when unresolved MUST or MUST_NOT findings fail the gate |
| 045 | `produced.n150.error_registry` | after `错误码清单.csv` or registry is produced |
| N150 orchestrator | `produced.n150.api_spec_package` | after the three artifacts are assembled |

## Event authority

The skill that produces the artifact is the authority for its produced event:

- 043 owns `produced.n150.api_contract_draft`.
- 044 owns `produced.n150.api_compliance_report` and `exception.n150.api_contract_blocker`.
- 045 owns `produced.n150.error_registry`.
- The N150 orchestrator owns `produced.n150.api_spec_package` after aggregation.

Other skills may reference, aggregate, or display these events, but should not recalculate another skill's event payload semantics.

## State events

| Event type | Meaning |
|---|---|
| `state.n150.needs_design_revision` | 044 found blockers that must return to 043 |
| `state.n150.needs_error_registry_revision` | 044 or 043 changed assumptions that affect 045 |
| `state.n150.ready_for_codegen` | final gate passed or was explicitly waived |
| `state.n150.blocked_for_human_review` | automatic loop limit or policy conflict requires human resolution |

## Subscriber hints

- N330 should subscribe to produced events for API docs.
- N340 may subscribe to state and blocker events for best-practice capture.
- N350 may subscribe to blocker events for task/risk creation.
- N390 may subscribe to all produced and exception events for governance and quality scoring.
