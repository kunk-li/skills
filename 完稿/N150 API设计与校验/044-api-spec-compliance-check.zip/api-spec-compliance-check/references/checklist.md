# 044 Delivery Checklist

## Baseline and coverage
- [ ] policy baseline source is explicit
- [ ] findings use `rule_category`, `severity`, and `check_level`
- [ ] blocked or undefined APIs are not treated as full passes
- [ ] cross-API consistency was checked when enough APIs exist
- [ ] expected route families are compared with controller/OpenAPI/gateway route inventory when inventory is available
- [ ] route drift findings include source refs and explicit waiver status

## Gate quality
- [ ] MUST and MUST_NOT findings are clearly separated
- [ ] SHOULD and MAY findings are not overstated as blockers
- [ ] fix suggestions are actionable and specific
- [ ] waivers and exceptions are recorded, not hidden

## Cross-skill alignment
- [ ] feedback can go directly back into 043
- [ ] error-related findings can go directly into 045
- [ ] automation advice is present when CI or lint output is requested

## v2.3 Contract Checks
- [ ] Output starts with `artifact_contract`.
- [ ] `artifact_contract.correlation_id` is present when the artifact belongs to an N150 run; if standalone and unavailable, it is explicitly `null` with a degraded reason.
- [ ] `artifact_contract.contract_fingerprint` is computed from the semantic fields defined in `SHARED_CONTRACT.md`, or explicitly set to `null` with a fingerprint unavailable reason.
- [ ] `artifact_contract.fingerprint_version` matches the shared algorithm version, currently `n150-fingerprint-v1`.
- [ ] `gate_coverage.coverage_ratio` is present.
- [ ] Unknown or unchecked areas are not counted as pass.
- [ ] Family completeness issues are findings only; no auto-generated APIs are inserted.
- [ ] Error-code coverage is signaled to 045, not adjudicated twice.
- [ ] `emit_events` includes pass/fail/blocker state as appropriate and carries the same `correlation_id` as the artifact.
- [ ] `scripts/validate_route_drift.py` passes when expected route families and route inventory are available.
