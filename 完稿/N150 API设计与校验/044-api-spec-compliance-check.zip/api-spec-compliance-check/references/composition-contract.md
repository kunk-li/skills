# Composition Contract for the N150 Trio v2.3.1

This file is the local navigation page for the shared N150 contract.

Use `references/SHARED_CONTRACT.md` as the authoritative schema, ownership, rerun, fingerprint, and conflict-resolution source. Use `references/events.md` for event declarations.

## Minimal rule

- 043 defines API policy and API surface.
- 044 checks the API contract and emits gate findings; it does not auto-fix or invent APIs.
- 045 defines the error registry and owns error-code coverage judgment.
- If a field is owned by another skill, consume it or raise a finding; do not silently redefine it.
- In one N150 run, all three skills should share the same `artifact_contract.correlation_id`.
- Every produced artifact should include `contract_fingerprint` and `fingerprint_version`, or explicitly explain why fingerprinting is unavailable.
- Treat `SKILL.md` `downstream_contract` / `feedback_handoff` as the authoritative downstream source. In `output-template.md`, `downstream_consumers` represents the artifact impact domain, including direct consumers and indirect workflow effects.

## Default composition loop

1. 043 drafts or normalizes the API contract.
2. 044 runs the fast design gate on MUST and MUST_NOT rules.
3. 043 revises the contract if the gate fails.
4. 045 derives or normalizes the error registry.
5. 044 runs final consistency checks for error format, status mapping, and cross-API drift.
6. The orchestrator assembles `N150_api_spec_package.md` and groups the sibling artifacts by `correlation_id`.

Do not run this as an unbounded loop. Follow the loop limit and escalation rules in `SHARED_CONTRACT.md`.
