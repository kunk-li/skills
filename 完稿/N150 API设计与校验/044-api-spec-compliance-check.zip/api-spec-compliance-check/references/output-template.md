# Output Template: API Spec Compliance Check v2.3.1

## 1. Artifact Contract
Start with `artifact_contract` from `SHARED_CONTRACT.md`. Explicitly include the v2.3-readable fields below so callers do not need to infer them from prose:

```yaml
artifact_contract:
  schema_version: n150.api_contract.v2.2
  producer_skill_id: api-spec-compliance-check
  workflow_node: N150
  selected_mode: design_gate | audit_existing | lint_pr | emit_spectral_rules
  readiness: confirmed | provisional | partial | blocked
  correlation_id: string | null
  input_coverage:
    required_present: []
    required_missing: []
    optional_present: []
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
  contract_fingerprint: sha256-lowercase-hex | null
  fingerprint_version: n150-fingerprint-v1 | null
  downstream_consumers: [api-design-recommendation, api-error-code-design, N190, N200, N240, N330]
  emit_events: []
  degraded_reason: []
```

## 2. Objective
State selected mode, reviewed scope, and policy baseline source.

## 3. Gate Coverage
| metric | value | notes |
|---|---|---|
| apis_checked |  |  |
| total_apis_detected |  |  |
| rules_checked |  |  |
| rules_applicable |  |  |
| coverage_ratio |  |  |
| confidence | high / medium / low |  |

## 4. Gate Decision
| decision | blocker count | major count | coverage ratio | notes |

## 5. Findings by Severity
Summarize blockers, majors, warnings, and optional items.

## 6. Findings by Category
| rule_category | count | dominant pattern | owner_skill |

## 7. Cross-API Consistency Findings
| rule_id | affected APIs | conflict | required fix | owner_skill |

## 8. Route Inventory Comparison
| family_id | expected_prefix | matched_routes | drift_routes | source_refs | severity | gate_effect | waiver_id | recommendation |
|---|---|---|---|---|---|---|---|---|

Rules:
- Compare expected route families with controller/OpenAPI/API gateway inventory when available.
- Missing expected prefixes, deprecated prefixes, and similar-but-different prefixes are `MUST` findings unless a documented compatibility waiver exists.
- Keep compatibility waivers explicit in `route_compatibility_waivers[]`; do not hide them in prose.

## 9. Automation Integration
Describe CI, lint, or Spectral export guidance when requested.

## 10. Feedback Handoff
| consumer | what to fix or consume | priority |

## 11. Emit Events
List produced, state, or exception events and rerun hints.

## 12. Self-Check
Summarize checklist and scoring results.
