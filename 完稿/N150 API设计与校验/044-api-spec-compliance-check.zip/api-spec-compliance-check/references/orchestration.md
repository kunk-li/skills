# N150 Orchestration v2.3

Use this sequence when the three N150 skills are composed. A skill may still be used standalone, but it must mark degraded readiness and input coverage explicitly.

## Run identity and fingerprint discipline

- All artifacts and emitted event declarations produced in the same N150 execution should share one `correlation_id`.
- If a skill is used standalone and no run identity is available, set `correlation_id: null` and explain the degraded reason.
- Each produced artifact should include `contract_fingerprint` and `fingerprint_version` according to `SHARED_CONTRACT.md`.
- Fingerprints are for semantic change detection and event de-duplication; do not include timestamps, prose summaries, or transient diagnostics.

## Default design loop

1. `api-design-recommendation` drafts or normalizes the API contract surface.
2. `api-spec-compliance-check` immediately runs the fast gate for MUST and MUST_NOT violations.
3. `api-design-recommendation` revises the contract when blockers are found.
4. `api-error-code-design` derives or normalizes the error registry from 043 seeds, business rules, and relevant 044 findings.
5. `api-spec-compliance-check` runs final consistency checks for cross-API drift, error format, and status mapping.
6. The N150 orchestrator assembles `N150_api_spec_package.md` and keeps sibling artifacts correlated by `correlation_id`.

## Loop limit

Run at most two automatic 043 -> 044 repair iterations in one N150 execution. If blockers remain after the second repair, emit `state.n150.blocked_for_human_review` and return a `blocked` artifact with the unresolved findings.

## Field mappings

| Producer field | Consumer | Usage |
|---|---|---|
| shared `artifact_contract.correlation_id` | all N150 skills and orchestrator | group sibling artifacts and emitted events from one run |
| shared `artifact_contract.contract_fingerprint` | N370/N390/orchestrator | detect semantic changes and suppress duplicate processing |
| 043 `api_policy` | 044 | rule baseline and consistency checks |
| 043 `api_policy.error_format` | 045 | error response envelope baseline |
| 043 `api_catalog[].api_kind` | 044 | method/style checks |
| 043 `error_case_seeds` | 045 | candidate error-code scenarios |
| 044 `findings[]` | 043 | design repair input |
| 044 `findings[]` with error implications | 045 | registry gaps or normalization input |
| 045 `error_registry[]` | 044 | final error consistency and status mapping check |

## Authority reminder

See `SHARED_CONTRACT.md` for the authoritative source for each field. A skill should not silently overwrite fields owned by a different skill.
