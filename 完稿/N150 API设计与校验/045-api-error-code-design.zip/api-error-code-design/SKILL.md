---
name: api-error-code-design
description: design structured error code registries with http mapping, i18n keys, lifecycle management, and orphan detection. triggers on 接口设计草案.yaml or explicit error registry requests.
---
# api-error-code-design

## Error code structure quick-reference
Format: `{DOMAIN}.{CATEGORY}.{SPECIFIC}`

| Part | Example | Rule |
|---|---|---|
| DOMAIN | `ORDER` / `AUTH` / `PAYMENT` | uppercase, matches bounded context |
| CATEGORY | `VALIDATION` / `NOT_FOUND` / `CONFLICT` | uppercase, stable enum |
| SPECIFIC | `QUANTITY_EXCEEDS_STOCK` | uppercase, describes the exact condition |

Full example: `ORDER.VALIDATION.QUANTITY_EXCEEDS_STOCK`

## HTTP status mapping quick-reference
| HTTP status | Use when |
|---|---|
| 400 | client input invalid |
| 401 | authentication missing or expired |
| 403 | authenticated but unauthorized |
| 404 | resource not found |
| 409 | state conflict (idempotency, concurrent update) |
| 422 | input structurally valid but semantically wrong |
| 429 | rate limit exceeded |
| 500 | unexpected server error |
| 503 | dependency unavailable, circuit open |

## i18n key template
```yaml
error_code: ORDER.VALIDATION.QUANTITY_EXCEEDS_STOCK
http_status: 400
i18n_key: error.order.validation.quantity_exceeds_stock
i18n_params: [requested_qty, available_qty]
client_action: reduce_quantity_and_retry
```

Every code must have `i18n_key`, `i18n_params[]`, and `client_action`. Never hardcode human-readable messages in the registry.


## Trigger conditions
Design error code registry when any of the following are present:
- `error_case_seeds[]` from 043
- business rule catalog (`业务规则清单.md`) from N070
- existing error inventories or legacy code
- explicit error registry design requests

## Standalone rule
Works without 043 seeds — infer error categories from domain language and common patterns. Mark inferred codes as `lifecycle_status: proposed`. All codes require 044 findings review before moving to `confirmed`.

## Role and boundary
本 skill 对齐 skills_workflow 中in the technical-solution-design -> API设计 -> 错误语义设计」。

它是 **direct_result** 型技能：目标不是简单罗列错误常量，而是形成可供实现、校验、测试与文档复用的 **`错误码清单.csv`** / registry 结构。

## Boundary
- 负责定义错误码体系、命名规范、HTTP 映射、多语言消息与客户端行为指导。
- 负责把 043 的 error seeds 与 044 的覆盖缺口统一收口成 registry。
- 负责错误码覆盖度、orphan codes、missing codes 的最终判断。
- 不替代 043 的接口设计，也不重新定义 043 的 `api_policy.error_format`；只在其 envelope 内填充错误语义。
- 不替代 044 的规范 gate；若发现规范问题，反馈给 044 或 043。
- 错误码自动派生必须保守：自动 proposal 可生成，但进入 active registry 前需要证据或人工确认。

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness`、`artifact_contract` 和 `evidence_profile`。

允许 5 种模式：
- `from_api_contract`：N150 默认模式；从 043 API contract 和 044 findings 生成 registry。
- `auto_from_rules`：从业务规则、negative examples、权限拒绝场景自动提出候选错误码。
- `audit_existing`：现有错误码、异常映射、响应样例已存在时做标准化。
- `hierarchy_refactor`：错误码过于扁平、命名混乱时做层级重构。
- `i18n_batch_translate`：语义体系已稳定，但多语言消息缺失时补齐本地化。

## Primary inputs
### workflow 对齐的推荐输入
- `接口设计草案.yaml` from `043/api-design-recommendation`
- `API规范检查单.csv` from `044/api-spec-compliance-check`
- `业务规则清单.csv` from `N070/business-rule-extraction`
- `权限矩阵.csv` from `N070/permission-matrix-extraction`

### 可选增强输入
- `开发需求解析.md` from `N120/engineering-requirement-parsing`
- `接口意图清单.csv` from `N120/api-intent-extraction`
- 现有 error constants、response samples、exception mappings、历史 registry、i18n 文件

## Minimum viable input
- `confirmed` 输出：需要 043 error seeds 或等价 API failure scenarios，并有 status/error-format baseline。
- `provisional` 输出：只有 PRD / 技术方案 / 业务规则时可先生成候选 registry，但必须标为 proposed。
- `partial` 输出：仅做 audit、refactor 或 i18n 时，可以只覆盖已有 codes。
- `blocked` 输出：缺少任何错误场景、API surface 或状态映射依据时，不要发明 active codes。

## Standalone rule
即使没有完整 043 / 044 输出，也可以单独使用。

降级规则：
- 若只有 PRD / 技术方案，可先生成 provisional registry。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / normalized / proposed` 错误码。
- 未决的命名、HTTP 映射、locale 或 client action 要求必须列入 `open_questions`。

## Core output contract
默认输出应以机器友好的 registry / CSV 结构为主，可附短摘要。优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `artifact_contract` per `references/SHARED_CONTRACT.md`
- `metadata`
  - `selected_mode`
  - `readiness`
  - `correlation_id`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.api_design.error_semantics_design`
  - `node_artifact_target: 错误码清单.csv`
  - `workflow_node: N150`
  - `evidence_profile`
  - `contract_fingerprint`
  - `fingerprint_version`
- `error_policy`
- `error_registry[]`
- `http_status_matrix`
- `coverage_summary`
- `orphan_or_missing_codes[]`
- `exports`
- `open_questions[]`
- `emit_events[]`
- `downstream_contract`
  - `to_043`: `error_code_refs`, API design feedback when scenarios are ambiguous
  - `to_044`: registry, status matrix, coverage summary for final consistency check
  - `to_N190`: unified error response format and exception mapping guidance
  - `to_N200`: error code to exception class mapping
  - `to_N230`: error registry and negative scenarios for test design
  - `to_N240`: negative scenario to expected error code mapping
  - `to_N330`: registry, localized messages, client guidance
- `self_check`

### Required `error_policy`
至少包含：
- `naming_convention`
- `http_status_mapping_policy`
- `minimum_locales`
- `client_action_enum`
- `compatibility_policy`

### Required per-code fields
每条错误码至少包含：
- `error_code`
- `http_status`
- `domain`
- `category`
- `specific`
- `scenario`
- `messages`
- `params`
- `client_guidance`
- `related_apis`
- `derived_from`
- `evidence`
- `status`: `proposed` | `active` | `deprecated`

## Downstream handoff summary
Error registry feeds:
- `to_N190_code_generation`: error code constants for generated exception classes
- `to_N200_dto_design`: error response DTOs matching registry structure
- `to_N240_test_design`: negative test scenarios derived from registry entries
- `to_N330_documentation`: client-facing error reference guide

## Design rules
### Seed ownership discipline / 种子所有权纪律
- 043 负责产出 `error_case_seeds`。
- 045 负责扩展、去重、命名、映射和 registry 化。
- 不要在 045 中重写 API surface；如果错误场景暗示接口设计问题，反馈给 043。

### Naming convention discipline / 命名纪律
使用项目级模板：
`{DOMAIN}_{CATEGORY}_{SPECIFIC}`
- upper snake case only
- 一个语义场景对应一个 code
- 不得混用 `ERR_*`、`*_ERROR` 与自然语言名，除非兼容旧系统并记录 alias

### HTTP mapping discipline / HTTP 映射纪律
- 每个 code 必须映射到且仅映射到一个 HTTP 或协议状态。
- 若项目故意偏离标准映射，必须记录 waiver 与理由。
- status: active 的 code，其 (语义, HTTP) 一经发布即冻结;变更必须走显式 deprecation 或 fingerprint_version bump，不得静默改(由 `R09_published_code_contract_stability` 强制，违反即 reject)。
- 跨同族一致性(区别于上条单码冻结):把 active 码按拒绝原因/语义聚类成族(如「前置未就绪、稍后重试」「权限不足」「资源冲突」);同族成员必须映射到同一协议级状态与命名风格,新增码须与既有同族码比对状态选择。同族状态分叉(同类「前置未就绪」一半 423Locked 一半 403Forbidden)即契约不一致,除非 registry 内显式声明 axis/waiver 说明分叉意图(显式声明判 not_applicable,非 pass)。控制基数/方案被改(N 方联签的 N 变、阈值档数变)时,所有以旧基数字面命名的码/枚举/文案标识须随语义迁移或显式声明兼容别名,不得残留旧基数字面(如方案改双签后码名仍含 TRIPLE)。每个码契约声明的触发场景须与实际抛出场景一致,不得契约列码而运行时该路径从不抛出(由 `R10_error_code_family_status_consistency` 强制:族状态分叉无 waiver 警告级、命名/场景漂移 reject)。扫描锚(R10):把 active 码按拒绝原因/语义聚类成族后,grep 同族每个码的协议级状态映射(HTTP status / `@ResponseStatus` / gRPC code / 状态码常量),同族出现 ≥2 个不同协议状态(如同类「理由太短/校验失败」一半 400 一半 422、或「资源不存在」一半 404 一半 409)且无 axis/waiver 声明即报;再 grep `@Deprecated` 邻近同族码定位基数/状态迁移残留。同一逻辑码在不同协议面(REST/gRPC/事件等)的不同传输状态,若已显式声明 protocol/transport waiver,不属本规则范围,判 not_applicable 而非 pass(它本就不是同一传输面上的快照变更)。跨 artifact 层(PRD/dev/api/test)同码一致性由 044 跨产物 gate 判，不在 045 立规则(045 仅产单份 registry，不拥有下游层产物)。

### Localization discipline / 本地化纪律
- 至少提供两个 locale：项目主语言 + English；若输入不足，可标 `pending_translation`。
- 消息参数必须显式声明。
- user-facing 与 developer-facing 消息默认不应完全相同。

### Client guidance discipline / 客户端指导纪律
每个 code 必须包含结构化 `client_guidance.action`。
允许的 action：
- `show_to_user`
- `retry_with_backoff`
- `retry_after`
- `refresh_token`
- `fail_fast`
- `fallback_to_cached`
- `alert_support`
- `silent_ignore`

## Execution workflow
1. 识别 `selected_mode`、`readiness`、`artifact_contract`、`evidence_profile`。
2. 读取 043 的 error seeds 与 044 的覆盖缺口。
3. 定义项目级 `error_policy`，但不重定义 043 的 response envelope。
4. 种出候选 code，并统一命名、层级与 HTTP 映射。
5. 补充多语言消息与参数声明。
6. 为每个 code 增加 `client_guidance`。
7. 检查 documented 4xx / 5xx 路径覆盖度，识别 orphan 或 missing code。
8. 形成面向 N150 节点标准产物的 **`错误码清单.csv`** / registry。
9. 输出 `downstream_contract` 与 `emit_events`，供 044 复核以及 N190 / N200 / N230 / N240 / N330 使用。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness
- 小 feature：覆盖全部显式业务错误与基础设施错误。
- 中等服务：覆盖全部用户可见与集成可见失败场景。
- 大型平台：重点放在层级质量、重复清理、本地化覆盖与 client guidance 一致性。

不要把 registry 做成一次性表格，也不要因为 scope 大就回避 coverage 检查。

## Quality bar
合格结果应能直接被实现层、测试层、文档层复用，而不需要二次解释错误语义。

使用以下参考文件自检：
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/error-taxonomy.md`
- `references/http-status-mapping.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/output-template.md`
- `references/error-taxonomy.md`
- `references/http-status-mapping.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`

## Confidence discipline
Every error code lifecycle status must be explicit:
- `lifecycle_status: proposed` — auto-derived or inferred; not yet validated
- `lifecycle_status: confirmed` — reviewed by API owner and consumer team
- `lifecycle_status: pending_review` — drafted, awaiting sign-off

Separate proposed from confirmed. Never treat `proposed` as `confirmed` in production.
## v2 artifact contract additions

045 now has its own `schema_version` for independent tracking. Declare at header top.

```yaml
artifact_schema_version: n150.error-registry.v2.1.0
skill_name: api-error-code-design
produced_event: produced.n150.error_code_registry.v2
blocker_mapping: B-N150-03
correlation_id: ""    # REQUIRED: must match 043 and 044 in same N150 run
contract_fingerprint: ""
fingerprint_version: "1"
rule_results:
  - rule_id: R01_every_active_code_has_evidence
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_http_status_mapping_complete
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R03_orphan_codes_identified
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R04_i18n_keys_present_or_deferred
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R05_044_coverage_gaps_addressed
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R06_orphan_detection_run
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R07_lifecycle_status_explicit
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R08_i18n_params_not_hardcoded
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R09_published_code_contract_stability
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R10_error_code_family_status_consistency
    severity: warn
    result: pass | warn | reject | not_applicable
    # family-level: cluster active codes by rejection reason / semantic family; codes in one family must map to one protocol-level status (HTTP/gRPC) and naming style; a family-status split is a contract inconsistency unless the registry carries an explicit axis/waiver (declared → not_applicable, not pass). Also: when a control's cardinality or scheme changes (N-of-M co-sign N changes, threshold tier count changes), every code/enum/message identifier named after the OLD cardinality must migrate with the semantics or declare a compat alias — a residual old-cardinality literal feeds consumers that read by code name the opposite meaning. Also: a code's declared trigger scenario must match the scenario it is actually thrown in; a code listed in the contract but never emitted on the declared path (or emitted only elsewhere) makes status/code-based consumer dispatch silently fail. Distinct from R02 (single-code mapping completeness) and R09 (single-code (meaning, HTTP) frozen across published versions) — R10's axis is cross-family consistency and naming-migrates-with-cardinality at a single point in time, not a per-code or version-drift property. Scan anchor: cluster active codes by rejection-reason/semantic family, grep each member's protocol status mapping (HTTP / @ResponseStatus / gRPC code), and report a family carrying >=2 distinct protocol statuses with no axis/waiver; also grep @Deprecated near family members for cardinality/status-migration residue.
feedback_signal_to_n005:
  signal_type: none | error_pattern_signal | missing_error_coverage
  summary: ""
  target_n070_skills:
  - 014-business-rule-extraction
  - 015-state-transition-mapping
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
route_back_to: none | api-design | compliance-check
# none             — error registry complete; downstream consumers (N190, N200) may proceed
# api-design       — missing API surface requires 043 to add interface first
# compliance-check — error coverage gaps must be re-validated by 044
eventbus_subscribers: [N330]
# N330 → 错误码清单归档 (triggered on produced.n150.error_registry)
```

## Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| `业务规则清单.md` (014) | condition_expr, failure_result, hardness=constraint | error code candidates, business error semantics |
| `状态转移图.md` (015) | blocked_by[], recovery_note | state-related error codes and compensation errors |
| `权限矩阵.csv` (016) | effect=deny, evaluation_algo | 403/401 error code semantics |
| `验收标准.md` (032) | negative cases | error scenario validation |
