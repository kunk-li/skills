---
name: api-error-code-design
description: design or normalize api error-code systems using project-level naming conventions, http status mapping policy, hierarchy, localization requirements, client guidance, and traceability to related apis and compliance findings. use for n150 错误码清单.csv after api contract drafting and compliance review, or standalone to audit existing codes, derive codes from rules, and prepare implementation, tests, and documentation.
---
# api-error-code-design

## Role / 角色定位
本 skill 对齐 skills_workflow 中的「技术方案设计 -> API设计 -> 错误语义设计」。

它是 **direct_result** 型技能：目标不是简单罗列错误常量，而是形成可供实现、校验、测试与文档复用的 **`错误码清单.csv`** / registry 结构。

## Boundary / 边界
- 负责定义错误码体系、命名规范、HTTP 映射、多语言消息与客户端行为指导。
- 负责把 043 的 error seeds 与 044 的覆盖缺口统一收口成 registry。
- 负责错误码覆盖度、orphan codes、missing codes 的最终判断。
- 不替代 043 的接口设计，也不重新定义 043 的 `api_policy.error_format`；只在其 envelope 内填充错误语义。
- 不替代 044 的规范 gate；若发现规范问题，反馈给 044 或 043。
- 错误码自动派生必须保守：自动 proposal 可生成，但进入 active registry 前需要证据或人工确认。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness`、`artifact_contract` 和 `evidence_profile`。

允许 5 种模式：
- `from_api_contract`：N150 默认模式；从 043 API contract 和 044 findings 生成 registry。
- `auto_from_rules`：从业务规则、negative examples、权限拒绝场景自动提出候选错误码。
- `audit_existing`：现有错误码、异常映射、响应样例已存在时做标准化。
- `hierarchy_refactor`：错误码过于扁平、命名混乱时做层级重构。
- `i18n_batch_translate`：语义体系已稳定，但多语言消息缺失时补齐本地化。

## Primary inputs / 主要输入
### workflow 对齐的推荐输入
- `接口设计草案.yaml` from `043/api-design-recommendation`
- `API规范检查单.csv` from `044/api-spec-compliance-check`
- `业务规则清单.csv` from `N070/business-rule-extraction`
- `权限矩阵.csv` from `N070/permission-matrix-extraction`

### 可选增强输入
- `开发需求解析.md` from `N120/engineering-requirement-parsing`
- `接口意图清单.csv` from `N120/api-intent-extraction`
- 现有 error constants、response samples、exception mappings、历史 registry、i18n 文件

## Minimum viable input / 最小启动条件
- `confirmed` 输出：需要 043 error seeds 或等价 API failure scenarios，并有 status/error-format baseline。
- `provisional` 输出：只有 PRD / 技术方案 / 业务规则时可先生成候选 registry，但必须标为 proposed。
- `partial` 输出：仅做 audit、refactor 或 i18n 时，可以只覆盖已有 codes。
- `blocked` 输出：缺少任何错误场景、API surface 或状态映射依据时，不要发明 active codes。

## Standalone rule / 独立使用规则
即使没有完整 043 / 044 输出，也可以单独使用。

降级规则：
- 若只有 PRD / 技术方案，可先生成 provisional registry。
- 顶部必须标明 `readiness: provisional`。
- 必须区分 `confirmed / normalized / proposed` 错误码。
- 未决的命名、HTTP 映射、locale 或 client action 要求必须列入 `open_questions`。

## Core output contract / 核心输出契约
默认输出应以机器友好的 registry / CSV 结构为主，可附短摘要。优先复用 `references/output-template.md`。

结果至少包含以下结构：
- `artifact_contract` per `references/SHARED_CONTRACT.md`
- `metadata`
  - `selected_mode`
  - `readiness`
  - `correlation_id`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.api_design.error_semantics_design`
  - `node_artifact_target: 错误码清单.csv`
  - `workflow_node: N150`
  - `evidence_profile`
  - `contract_fingerprint`
  - `fingerprint_version`
- `error_policy`
- `error_registry[]`
- `http_status_matrix`
- `coverage_summary`
- `orphan_or_missing_codes[]`
- `exports`
- `open_questions[]`
- `emit_events[]`
- `downstream_contract`
  - `to_043`: `error_code_refs`, API design feedback when scenarios are ambiguous
  - `to_044`: registry, status matrix, coverage summary for final consistency check
  - `to_N190`: unified error response format and exception mapping guidance
  - `to_N200`: error code to exception class mapping
  - `to_N230`: error registry and negative scenarios for test design
  - `to_N240`: negative scenario to expected error code mapping
  - `to_N330`: registry, localized messages, client guidance
- `self_check`

### Required `error_policy`
至少包含：
- `naming_convention`
- `http_status_mapping_policy`
- `minimum_locales`
- `client_action_enum`
- `compatibility_policy`

### Required per-code fields
每条错误码至少包含：
- `error_code`
- `http_status`
- `domain`
- `category`
- `specific`
- `scenario`
- `messages`
- `params`
- `client_guidance`
- `related_apis`
- `derived_from`
- `evidence`
- `status`: `proposed` | `active` | `deprecated`

## Design rules / 设计规则
### Seed ownership discipline / 种子所有权纪律
- 043 负责产出 `error_case_seeds`。
- 045 负责扩展、去重、命名、映射和 registry 化。
- 不要在 045 中重写 API surface；如果错误场景暗示接口设计问题，反馈给 043。

### Naming convention discipline / 命名纪律
使用项目级模板：
`{DOMAIN}_{CATEGORY}_{SPECIFIC}`
- upper snake case only
- 一个语义场景对应一个 code
- 不得混用 `ERR_*`、`*_ERROR` 与自然语言名，除非兼容旧系统并记录 alias

### HTTP mapping discipline / HTTP 映射纪律
- 每个 code 必须映射到且仅映射到一个 HTTP 或协议状态。
- 若项目故意偏离标准映射，必须记录 waiver 与理由。

### Localization discipline / 本地化纪律
- 至少提供两个 locale：项目主语言 + English；若输入不足，可标 `pending_translation`。
- 消息参数必须显式声明。
- user-facing 与 developer-facing 消息默认不应完全相同。

### Client guidance discipline / 客户端指导纪律
每个 code 必须包含结构化 `client_guidance.action`。
允许的 action：
- `show_to_user`
- `retry_with_backoff`
- `retry_after`
- `refresh_token`
- `fail_fast`
- `fallback_to_cached`
- `alert_support`
- `silent_ignore`

## Execution workflow / 执行流程
1. 识别 `selected_mode`、`readiness`、`artifact_contract`、`evidence_profile`。
2. 读取 043 的 error seeds 与 044 的覆盖缺口。
3. 定义项目级 `error_policy`，但不重定义 043 的 response envelope。
4. 种出候选 code，并统一命名、层级与 HTTP 映射。
5. 补充多语言消息与参数声明。
6. 为每个 code 增加 `client_guidance`。
7. 检查 documented 4xx / 5xx 路径覆盖度，识别 orphan 或 missing code。
8. 形成面向 N150 节点标准产物的 **`错误码清单.csv`** / registry。
9. 输出 `downstream_contract` 与 `emit_events`，供 044 复核以及 N190 / N200 / N230 / N240 / N330 使用。
10. 使用 checklist 与 common-failure review 自检。

## Dynamic completeness / 动态完整度
- 小 feature：覆盖全部显式业务错误与基础设施错误。
- 中等服务：覆盖全部用户可见与集成可见失败场景。
- 大型平台：重点放在层级质量、重复清理、本地化覆盖与 client guidance 一致性。

不要把 registry 做成一次性表格，也不要因为 scope 大就回避 coverage 检查。

## Quality bar / 质量门槛
合格结果应能直接被实现层、测试层、文档层复用，而不需要二次解释错误语义。

使用以下参考文件自检：
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/error-taxonomy.md`
- `references/http-status-mapping.md`
- `references/mode-selection.md`
- `references/composition-contract.md`

## Reference files / 参考文件
- `references/SHARED_CONTRACT.md`
- `references/events.md`
- `references/output-template.md`
- `references/error-taxonomy.md`
- `references/http-status-mapping.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`
