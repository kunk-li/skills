# Mode Selection v2.2

- Use `from_api_contract` inside N150 after 043 and preferably after an initial 044 gate.
- Use `auto_from_rules` when business rules, negative examples, or permission-denial scenarios are the best evidence.
- Use `audit_existing` when error constants, response samples, or exception mappings already exist.
- Use `hierarchy_refactor` when codes exist but are flat, duplicated, or inconsistently named.
- Use `i18n_batch_translate` when semantics are stable and localization is the main task.

Auto-derived codes should default to `status: proposed` unless backed by explicit requirements or accepted existing behavior.
