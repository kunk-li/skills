# Common failure modes — api-error-code-design

## F1: three naming systems in one registry
Symptom: Error codes mix styles: `ERR_001`, `ORDER_VALIDATION_FAILED`, and `order.validation.quantity` all coexist in the same registry.
Fix: Define one naming convention in `error_policy.naming_convention` at the start. Map legacy aliases explicitly. Every new code must follow the canonical `DOMAIN.CATEGORY.SPECIFIC` structure.

## F2: HTTP status chosen by habit
Symptom: All business rule violations return 400; all state conflicts return 500; no justification is provided for any status code.
Fix: Apply the HTTP status mapping policy first. Use 422 for semantic validation, 409 for state conflict, 403 for auth. Log any deviation as a waiver with `http_mapping_rationale`.

## F3: one code for unrelated scenarios
Symptom: `ORDER.VALIDATION.ERROR` is used for both quantity-exceeds-stock and invalid-date-range — clients cannot distinguish them programmatically.
Fix: Each code must represent exactly one semantic scenario. Split by the client's recovery action: if the client needs to do different things, it needs different codes.

## F4: messages hardcoded, not parameterized
Symptom: Error messages are written as fixed strings: 'Quantity 5 exceeds available stock of 2.' — the numbers are not parameters.
Fix: Use parameterized `i18n_key` with `i18n_params[]`: `error.order.validation.quantity_exceeds_stock` with params `[requested_qty, available_qty]`. Never hardcode values in the registry.

## F5: no client action guidance
Symptom: Codes are defined with HTTP status and message but no `client_action` — clients cannot decide whether to retry, show, or escalate.
Fix: Every code must have `client_action` from the canonical enum: `fix_input_and_retry | contact_admin | not_retryable | retry_after_delay`. This is the primary value of a structured error registry.

## F6: orphan codes not detected
Symptom: The registry has 40 codes but 8 of them are not referenced by any API in the current design — they exist from a previous version but were never cleaned up.
Fix: Run orphan detection on every 044 gate run. Codes with zero `related_apis` are orphans. Surface them as `coverage_summary.orphan_codes[]` and recommend retirement after 90 days of zero production usage.

