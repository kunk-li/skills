# Common failure modes — api-error-code-design

## F1: three naming systems in one registry
Symptom: Error codes mix styles: `ERR_001`, `ORDER_VALIDATION_FAILED`, and `order.validation.quantity` all coexist in the same registry.
Fix: Define one naming convention in `error_policy.naming_convention` at the start. Map legacy aliases explicitly. Every new code must follow the canonical `DOMAIN.CATEGORY.SPECIFIC` structure.

## F2: HTTP status chosen by habit
Symptom: All business rule violations return 400; all state conflicts return 500; no justification is provided for any status code.
Fix: Apply the HTTP status mapping policy first. Use 422 for semantic validation, 409 for state conflict, 403 for auth. Log any deviation as a waiver with `http_mapping_rationale`.

## F3: one code for unrelated scenarios
Symptom: `ORDER.VALIDATION.ERROR` is used for both quantity-exceeds-stock and invalid-date-range — clients cannot distinguish them programmatically.
Fix: Each code must represent exactly one semantic scenario. Split by the client's recovery action: if the client needs to do different things, it needs different codes.

## F4: messages hardcoded, not parameterized
Symptom: Error messages are written as fixed strings: 'Quantity 5 exceeds available stock of 2.' — the numbers are not parameters.
Fix: Use parameterized `i18n_key` with `i18n_params[]`: `error.order.validation.quantity_exceeds_stock` with params `[requested_qty, available_qty]`. Never hardcode values in the registry.

## F5: no client action guidance
Symptom: Codes are defined with HTTP status and message but no `client_action` — clients cannot decide whether to retry, show, or escalate.
Fix: Every code must have `client_action` from the canonical enum: `fix_input_and_retry | contact_admin | not_retryable | retry_after_delay`. This is the primary value of a structured error registry.

## F6: orphan codes not detected
Symptom: The registry has 40 codes but 8 of them are not referenced by any API in the current design — they exist from a previous version but were never cleaned up.
Fix: Run orphan detection on every 044 gate run. Codes with zero `related_apis` are orphans. Surface them as `coverage_summary.orphan_codes[]` and recommend retirement after 90 days of zero production usage.

## F7: published code silently changes meaning or status
Symptom: An `active` error code shipped one release with HTTP 409 / "idempotency conflict", and a later edit quietly repointed it to 422 / "validation failed" with no deprecation and no version bump. Consumers built against the old contract keep parsing the old meaning; the change is invisible because the registry is internally consistent at every point in time — only across versions does it drift.
Fix: Freeze the (meaning, HTTP status) pair of every `active` code against the published contract fingerprint. Any change to a live code's semantics or status must go through an explicit deprecation record or a fingerprint/version bump — never a silent edit. A new meaning needs a new code; the old code is deprecated, not repurposed. (Cross-protocol transport differences for one logical code are legitimate, not drift — declare them as a protocol/transport waiver; a declared waiver case is not_applicable to this rule, not a pass, because it is not a same-transport snapshot change at all.)

## F8: same-family codes drift to different protocol statuses; names and declared scenarios go stale
Symptom: Three distinct problems in one registry. (a) A batch of new gate codes `GATE_A_DATA_NOT_COLLECTED`, `GATE_B_VALIDATION_PENDING` all return 423 Locked, while a pre-existing code expressing the same "precondition not yet passed, retry later" semantics returns 403 — the same rejection family is split across two HTTP statuses with no family-level consistency check. (b) A control moved from triple sign-off to dual sign-off, but every failure path still throws a code named for the old cardinality (e.g. `*_NOT_TRIPLE_SIGNER`); a client or audit tool that reads the code name infers "triple" and contradicts the live dual-sign reality. (c) A code named for an unreached state (e.g. `*_PENDING_NSIG`, 423) is listed in the contract for "signatures not yet complete", but the code is never thrown on the sign path (throwing would roll back the partial write), so a client dispatching on HTTP 423 waits forever.
Fix: Cluster active codes by rejection reason / semantic family and map every member of a family to one protocol-level status and naming style; when adding a code, compare its status choice against existing same-family codes. A family-status split is a contract inconsistency unless the registry declares an explicit axis/waiver (a declared split is not_applicable, not a pass). When a control's cardinality or scheme changes, migrate every code/enum/message identifier named after the old cardinality (or declare a compat alias) — never leave an old-cardinality literal in a live code name. Keep each code's declared trigger scenario in sync with the scenario it is actually thrown in; if a declared path cannot throw the code, fix the contract or the throw site, do not leave a code consumers can never observe. (This is cross-family consistency at one point in time and naming-migrates-with-cardinality — distinct from F7, which is one live code's pair drifting across published versions.)

