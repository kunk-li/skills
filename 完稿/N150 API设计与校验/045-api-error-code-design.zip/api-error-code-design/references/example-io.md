# Example Input / Output

## Example input
A leave-request API contract has error seeds:
- `LEAVE_BALANCE_INSUFFICIENT`
- `LEAVE_DATE_OVERLAP`
- `LEAVE_INVALID_STATE`
- `LEAVE_PERMISSION_DENIED`

Business rules say leave balance cannot go below zero and approval is only valid for requests in `SUBMITTED` state. Permission matrix says HR can view all requests but cannot approve.

## Example output sketch

```yaml
artifact_contract:
  artifact_schema_version: n150.api_contract.v2.2
  producer_skill_id: api-error-code-design
  selected_mode: from_api_contract
  readiness: provisional
  correlation_id: n150-leave-001
  contract_fingerprint: null
  fingerprint_version: n150-fingerprint-v1

error_policy:
  naming_convention: DOMAIN_CATEGORY_SPECIFIC
  minimum_locales: [en-US, zh-CN]
  response_envelope_source: api_policy.error_format
  client_action_enum: [fix_input_and_retry, contact_admin, not_retryable, retry_after_delay]

error_registry:
  - error_code: LEAVE_BALANCE_INSUFFICIENT
    status: 422
    domain: LEAVE
    category: BUSINESS_RULE
    scenario: requested leave exceeds available balance
    client_guidance: {action: fix_input_and_retry, retryable: false}
    related_apis: [leave-request-create]
    lifecycle_status: proposed
  - error_code: LEAVE_INVALID_STATE
    status: 409
    domain: LEAVE
    category: STATE_CONFLICT
    scenario: approval attempted when request is not SUBMITTED
    client_guidance: {action: not_retryable, retryable: false}
    related_apis: [leave-request-approve]
    lifecycle_status: proposed
  - error_code: LEAVE_PERMISSION_DENIED
    status: 403
    domain: LEAVE
    category: AUTHORIZATION
    scenario: actor lacks permission for requested action
    client_guidance: {action: contact_admin, retryable: false}
    related_apis: [leave-request-approve]
    lifecycle_status: proposed

http_status_matrix:
  403: [LEAVE_PERMISSION_DENIED]
  409: [LEAVE_INVALID_STATE]
  422: [LEAVE_BALANCE_INSUFFICIENT, LEAVE_DATE_OVERLAP]

coverage_summary:
  api_error_seed_count: 4
  registry_code_count: 4
  missing_codes: []
  orphan_codes: []
```

## Notes
- Generated codes are `proposed` until confirmed by rules, examples, or human review.
- 045 owns missing/orphan judgment; 044 may only flag consistency signals.
- The response envelope is consumed from 043 and not redefined here.
