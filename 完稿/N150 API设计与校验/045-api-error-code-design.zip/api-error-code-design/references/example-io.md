# Example Input / Output

## Example input
A leave-request API contract has error seeds:
- `LEAVE_BALANCE_INSUFFICIENT`
- `LEAVE_DATE_OVERLAP`
- `LEAVE_INVALID_STATE`
- `LEAVE_PERMISSION_DENIED`

Business rules say leave balance cannot go below zero and approval is only valid for requests in `SUBMITTED` state. Permission matrix says HR can view all requests but cannot approve.

## Example output sketch

```yaml
artifact_contract:
  artifact_schema_version: n150.api_contract.v2.2
  producer_skill_id: api-error-code-design
  selected_mode: from_api_contract
  readiness: provisional
  correlation_id: n150-leave-001
  contract_fingerprint: null
  fingerprint_version: n150-fingerprint-v1

error_policy:
  naming_convention: DOMAIN_CATEGORY_SPECIFIC
  minimum_locales: [en-US, zh-CN]
  response_envelope_source: api_policy.error_format
  client_action_enum: [fix_input_and_retry, contact_admin, not_retryable, retry_after_delay]

error_registry:
  - error_code: LEAVE_BALANCE_INSUFFICIENT
    status: 422
    domain: LEAVE
    category: BUSINESS_RULE
    scenario: requested leave exceeds available balance
    client_guidance: {action: fix_input_and_retry, retryable: false}
    related_apis: [leave-request-create]
    lifecycle_status: proposed
  - error_code: LEAVE_INVALID_STATE
    status: 409
    domain: LEAVE
    category: STATE_CONFLICT
    scenario: approval attempted when request is not SUBMITTED
    client_guidance: {action: not_retryable, retryable: false}
    related_apis: [leave-request-approve]
    lifecycle_status: proposed
  - error_code: LEAVE_PERMISSION_DENIED
    status: 403
    domain: LEAVE
    category: AUTHORIZATION
    scenario: actor lacks permission for requested action
    client_guidance: {action: contact_admin, retryable: false}
    related_apis: [leave-request-approve]
    lifecycle_status: proposed

http_status_matrix:
  403: [LEAVE_PERMISSION_DENIED]
  409: [LEAVE_INVALID_STATE]
  422: [LEAVE_BALANCE_INSUFFICIENT, LEAVE_DATE_OVERLAP]

coverage_summary:
  api_error_seed_count: 4
  registry_code_count: 4
  missing_codes: []
  orphan_codes: []
```

## Notes
- Generated codes are `proposed` until confirmed by rules, examples, or human review.
- 045 owns missing/orphan judgment; 044 may only flag consistency signals.
- The response envelope is consumed from 043 and not redefined here.

## ex-002 · error lifecycle management

```yaml
error_registry_management:
  lifecycle_states:
    proposed:
      description: "Auto-derived from 043 seeds or inferred from business rules; not yet in production"
      transition_to_confirmed: "reviewed by API owner + at least 1 consumer team"
    confirmed:
      description: "In production; clients depend on this code; must not change semantics"
      transition_to_deprecated: "replacement code exists and is stable"
    deprecated:
      description: "Still returned but superseded; clients should migrate"
      sunset_after: "2 minor API versions or 6 months, whichever is later"
    retired:
      description: "No longer returned; can be removed from client SDK"

  change_rules:
    - rule: "Never change the semantic meaning of a confirmed error code"
      enforcement: "code review gate — semantic change requires new code + deprecate old"
    - rule: "Never remove a confirmed code without a deprecated → retired cycle"
      enforcement: "checklist item in release process"
    - rule: "i18n_key must be versioned if message parameters change"
      enforcement: "i18n team sign-off required"

  orphan_detection:
    definition: "error code exists in registry but is referenced by 0 confirmed APIs"
    detection_frequency: "on every 044 gate run"
    action: "warn + notify owner; auto-retire after 90 days if still unreferenced"
    example_orphan:
      error_code: ORDER.LEGACY.OLD_CHECKOUT_ERROR
      referenced_by_apis: []
      status: orphan
      last_seen_in_production: "2024-03-01"
      recommended_action: "retire — no client reference found"

  coverage_summary_example:
    api_error_seed_count: 6
    registry_code_count: 8
    missing_codes: [LEAVE.CONFLICT.CONCURRENT_APPROVAL]
    orphan_codes: [ORDER.LEGACY.OLD_CHECKOUT_ERROR]
    missing_action: "Add LEAVE.CONFLICT.CONCURRENT_APPROVAL derived from concurrent approval edge case"
    orphan_action: "Retire ORDER.LEGACY.OLD_CHECKOUT_ERROR after confirming no client usage"
```

## ex-003 · negative cases — common registry mistakes

```yaml
negative_cases:
  - case_id: NEG-001
    title: "One code for multiple unrelated scenarios"
    bad_example:
      error_code: ORDER.ERROR.INVALID
      scenario: "Used for: quantity invalid, date invalid, address invalid, payment failed"
      problem: "Clients cannot distinguish — all get the same code regardless of cause"
    correct_example:
      - error_code: ORDER.VALIDATION.QUANTITY_EXCEEDS_STOCK
        scenario: "Requested quantity exceeds available stock"
        client_action: fix_input_and_retry
      - error_code: ORDER.VALIDATION.DELIVERY_DATE_IN_PAST
        scenario: "Requested delivery date is before today"
        client_action: fix_input_and_retry
      - error_code: ORDER.PAYMENT.CARD_DECLINED
        scenario: "Payment gateway declined the card"
        client_action: contact_admin

  - case_id: NEG-002
    title: "Hardcoded values in error message instead of i18n params"
    bad_example:
      error_code: ORDER.VALIDATION.QUANTITY_EXCEEDS_STOCK
      message: "Quantity 5 exceeds available stock of 2"
      problem: "Numbers are hardcoded — cannot format for different locales, cannot be tested reliably"
    correct_example:
      error_code: ORDER.VALIDATION.QUANTITY_EXCEEDS_STOCK
      i18n_key: error.order.validation.quantity_exceeds_stock
      i18n_params: [requested_qty, available_qty]
      sample_rendered: "Quantity {requested_qty} exceeds available stock of {available_qty}"
      lifecycle_status: confirmed

  - case_id: NEG-003
    title: "HTTP 500 for a business rule violation"
    bad_example:
      error_code: ORDER.PAYMENT.CARD_DECLINED
      http_status: 500
      problem: "500 signals unexpected server error — card declined is expected business flow"
    correct_example:
      error_code: ORDER.PAYMENT.CARD_DECLINED
      http_status: 402
      client_action: contact_admin
      rationale: "402 Payment Required — client action is to retry with different payment method"

coverage_summary:
  api_error_seed_count: 6
  registry_code_count: 8
  missing_codes: [ORDER.VALIDATION.ADDRESS_NOT_SERVICEABLE]
  orphan_codes: [ORDER.LEGACY.V1_ERROR]
  missing_action: "Add ADDRESS_NOT_SERVICEABLE — detected from delivery address validation flow"
  orphan_action: "Retire V1_ERROR — no API references found; last seen in v1 API removed 2023-06"
```

## ex-004 · degraded — designing without error_case_seeds from 043

```yaml
skill_name: api-error-code-design
readiness: provisional
selected_mode: domain_inference
evidence_profile:
  confirmed: []
  inferred: [all error codes derived from domain knowledge and ER business rules]
  pending: [error_case_seeds from 043, HTTP status policy from api_policy]

degraded_reason: "043 has not yet produced error_case_seeds[] — codes inferred from business rules and domain knowledge"
degraded_impact: "Error codes may not align with actual API operations; orphan codes likely after 043 completes"

error_registry:
  - error_code: ORDER.VALIDATION.QUANTITY_EXCEEDS_STOCK
    lifecycle_status: proposed
    confidence: inferred
    inferred_from: "ER-005: system must prevent overselling"
    http_status: 422
    client_action: fix_input_and_retry
    i18n_key: error.order.validation.quantity_exceeds_stock
    note: "Provisional — validate against 043 api_catalog when available"

  - error_code: AUTH.PERMISSION.ACCESS_DENIED
    lifecycle_status: proposed
    confidence: inferred
    inferred_from: "General authorization requirement ER-009"
    http_status: 403
    client_action: contact_admin

pending_confirmations:
  - "Run 043 to get error_case_seeds[] — expect 3-5 additional codes"
  - "Confirm HTTP status policy from api_policy.error_format"
  - "Validate proposed codes against 043's api_catalog after completion"

coverage_summary:
  proposed_count: 2
  confirmed_count: 0
  warning: "Do not implement until 043 error_case_seeds reviewed and codes confirmed"
```

## ex-005 · blocked — error format policy conflict

```yaml
skill_name: api-error-code-design
readiness: blocked
blocker_mapping: B-N150-03
route_back_to: api-design-recommendation

blockers:
  - blocker_id: BLK-ERR-001
    type: policy_conflict
    description: "Existing legacy service uses {code, message, details} format. New api_policy mandates RFC 7807 {type, title, status, detail, instance}. Cannot design registry that satisfies both without waivers."
    impact: "All error code i18n_key structures differ between formats — cannot produce unified registry"
    resolution_required: "Product owner must decide: migrate legacy service to RFC 7807, or accept dual-format with explicit policy_exception"
    unblock_evidence: "api_policy with explicit legacy_exception_policy: accept_both|migrate|new_only"

  - blocker_id: BLK-ERR-002
    type: missing_domain_scope
    description: "No api_catalog[] from 043 — cannot determine which error domains (ORDER.*, AUTH.*, PAYMENT.*) are needed"
    impact: "Domain prefixes are the foundation of the three-segment naming structure — cannot design without them"
    resolution_required: "043 must produce api_catalog with domain mapping"

interim_assessment:
  domains_identified: 0
  confirmed_codes: 0
  note: "No registry can be produced until policy conflict resolved and domain scope defined"
```
