# Scoring Rubric v2.3: API Error Code Design

Score 1-5 for each dimension.

| Dimension | 5 means | 1 means |
|---|---|---|
| Taxonomy clarity | codes have stable domain/category/specific structure | codes are ad hoc strings |
| HTTP mapping quality | each code has a justified single primary status | status mapping is missing or inconsistent |
| Client guidance | each code has actionable client behavior | clients cannot programmatically react |
| Localization readiness | locales, parameters, and pending translations are explicit | messages are mixed, missing, or hard-coded |
| Coverage ownership | gaps and orphans are clearly judged by 045 | coverage is duplicated or conflicting with 044 |
| Traceability | codes link to APIs, rules, permissions, or findings | registry cannot explain why codes exist |
| Correlation hygiene | correlation_id links registry, events, 043 seeds, and 044 findings | registry cannot be grouped with the design run |
| Idempotency verifiability | contract_fingerprint and fingerprint_version make registry changes auditable | code registry drift cannot be reliably detected |
