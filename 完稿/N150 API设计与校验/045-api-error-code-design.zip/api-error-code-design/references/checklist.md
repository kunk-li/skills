# 045 Delivery Checklist

## Policy baseline
- [ ] `error_policy` exists and defines naming, mapping, locales, and client actions
- [ ] every code follows one naming convention
- [ ] every code maps to exactly one status

## Registry completeness
- [ ] every entry has domain, category, specific, scenario, messages, params, and client guidance
- [ ] at least two locales are present unless the caller explicitly narrowed the scope
- [ ] related APIs or source evidence are attached where possible

## Coverage and hygiene
- [ ] duplicate or overlapping codes are identified
- [ ] orphan codes and missing codes are surfaced
- [ ] 4xx and 5xx paths are not missing documented error coverage
- [ ] every `active` code's (meaning, HTTP status) is unchanged versus the last published contract fingerprint, or the change carries an explicit deprecation / version bump (no silent repurposing of a live code; cross-protocol transport waivers excepted)
- [ ] active codes are clustered by rejection reason / semantic family, and every member of one family maps to the same protocol-level status and naming style — any family-status split (e.g. one "precondition-not-met" code at 423 and a sibling at 403) carries an explicit registry axis/waiver, otherwise it is flagged
- [ ] no code retains an old-cardinality literal after the control's cardinality/scheme changed (e.g. a code named `*_TRIPLE_*` after the scheme moved to dual sign-off) — names migrate with semantics or declare a compat alias
- [ ] every code's declared trigger scenario matches the scenario it is actually thrown in — no code is listed in the contract yet never emitted on its declared path

## Cross-skill alignment
- [ ] registry aligns with 043 error-case seeds
- [ ] registry responds to 044 error-related findings
- [ ] envelope and client behavior assumptions remain consistent across the project

## v2.3 Contract Checks
- [ ] Output starts with `artifact_contract`.
- [ ] `artifact_contract.correlation_id` is present when the artifact belongs to an N150 run; if standalone and unavailable, it is explicitly `null` with a degraded reason.
- [ ] `artifact_contract.contract_fingerprint` is computed from the semantic fields defined in `SHARED_CONTRACT.md`, or explicitly set to `null` with a fingerprint unavailable reason.
- [ ] `artifact_contract.fingerprint_version` matches the shared algorithm version, currently `n150-fingerprint-v1`.
- [ ] 043 `error_case_seeds` are preserved in `derived_from` when present.
- [ ] 045 owns missing/orphan error-code coverage judgment.
- [ ] 043 `api_policy.error_format` is consumed, not redefined.
- [ ] Auto-derived codes are marked `proposed` unless confirmed.
- [ ] `emit_events` includes `produced.n150.error_registry` and carries the same `correlation_id` as the artifact.
