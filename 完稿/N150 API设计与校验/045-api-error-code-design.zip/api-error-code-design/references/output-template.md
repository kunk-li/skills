# Output Template: API Error Code Design v2.3.1

## 1. Artifact Contract
Start with `artifact_contract` from `SHARED_CONTRACT.md`. Explicitly include the v2.3-readable fields below so callers do not need to infer them from prose:

```yaml
artifact_contract:
  schema_version: n150.api_contract.v2.2
  producer_skill_id: api-error-code-design
  workflow_node: N150
  selected_mode: from_api_contract | auto_from_rules | audit_existing | hierarchy_refactor | i18n_batch_translate
  readiness: confirmed | provisional | partial | blocked
  correlation_id: string | null
  input_coverage:
    required_present: []
    required_missing: []
    optional_present: []
  evidence_profile:
    confirmed: []
    inferred: []
    pending: []
  contract_fingerprint: sha256-lowercase-hex | null
  fingerprint_version: n150-fingerprint-v1 | null
  downstream_consumers: [api-design-recommendation, api-spec-compliance-check, N190, N200, N230, N240, N330]
  emit_events: []
  degraded_reason: []
```

## 2. Error Policy
Show naming convention, status mapping policy, locale baseline, client action enum, and compatibility policy. Do not redefine 043's response envelope.

## 3. Registry Summary
| family or domain | count | active | proposed | notable notes |

## 4. HTTP Status Matrix
| status | default code | codes | notes |

## 5. Error Registry
For each entry include code, status, domain, category, scenario, locales, params, client guidance, related APIs, derived_from, evidence, and lifecycle status.

## 6. Coverage Gaps and Orphans
| type | item | impact | required action | owner |

## 7. Export Notes
Describe YAML, JSON, properties, compatibility aliases, or exception mapping when relevant.

## 8. Downstream Contract
| consumer | fields to read | why |

## 9. Emit Events
List event types to emit, payload readiness, and rerun hints.

## 10. Open Questions
| id | question | affected codes | impact |

## 11. Self-Check
Summarize checklist and scoring results.
