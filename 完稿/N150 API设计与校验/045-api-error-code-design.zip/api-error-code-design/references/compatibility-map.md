# Compatibility map — api-error-code-design v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 043 api-design-recommendation | `error_case_seeds[], api_policy.error_format` | `registry seeds, envelope authority` | 043 seeds become proposed codes; 043 owns error format |
| 044 api-spec-compliance-check | `error-format findings` | `orphan detection input` | 044 signals which codes are misaligned |
| N070 014 business-rule-extraction | `RULE-* condition_expr` | `additional code seeds` | business rule violations → additional error codes |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| N190 code-generation | `error_code constants` | `exception class generation` | codes generate typed exception classes |
| N200 dto-design | `error response schema` | `DTO structure` | error structure defines error response DTOs |
| N240 test-design | `error codes with client_action` | `negative test scenarios` | each code generates at least one negative test |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
