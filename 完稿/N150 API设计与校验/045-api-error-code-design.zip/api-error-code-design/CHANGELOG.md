# Changelog
## v2.3.2
- Fixed `references/output-template.md` so `artifact_contract.downstream_consumers` includes `N230`, matching the SKILL.md downstream contract and the v2.3.1 arbitration rule that the template represents the impact domain.
- Updated the execution workflow sentence to mention N230 alongside N190 / N200 / N240 / N330.

## v2.3.1 - Downstream consumer arbitration
- Restore N190 in output-template downstream_consumers to preserve controller/error-response consumption.
- Add to_N230 in SKILL.md downstream_contract for negative test design consumption.
- Add composition-contract arbitration clarifying direct-vs-indirect downstream semantics without introducing a v2.4 contract field.


## v2.3.0
- Align checklist, output-template, scoring-rubric, orchestration, and composition reference files with v2.2 runtime fields.
- Add explicit checks for `correlation_id`, `contract_fingerprint`, and `fingerprint_version`.
- Add scoring dimensions for traceability hygiene and idempotency verifiability.
- Clarify that all N150 sibling artifacts in one run share the same `correlation_id`.


## v2.2.0 - Contract polish and evaluation fixes

- Updated `SHARED_CONTRACT.md` to schema `n150.api_contract.v2.2`.
- Added `correlation_id` to artifact and event contracts for grouping events from one N150 run.
- Added a deterministic `contract_fingerprint` algorithm with canonical JSON + SHA-256 rules.
- Clarified produced event authority and declaration-vs-execution semantics.
- Expanded `example-io.md` into a runnable 40-60 line skeleton example.

## v2.1.0 - N150 contract optimization

- Added `references/SHARED_CONTRACT.md` with node-level schema, ownership, rerun, conflict, and idempotency rules.
- Added `references/events.md` for workflow v2 event-bus declarations.
- Updated `SKILL.md` to include artifact contract, input traceability, downstream contract, standalone readiness, and composition rules.
- Preserved standalone usability with explicit provisional/partial readiness instead of all-or-nothing v2 schema rejection.
- Kept examples and detailed schemas in references rather than expanding the main skill file.
