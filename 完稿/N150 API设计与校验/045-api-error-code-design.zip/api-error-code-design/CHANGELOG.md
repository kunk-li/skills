# CHANGELOG

## v4.2.0 (2026-06-25) — R10 recall: operational HTTP-status scan anchor

_skill: api-error-code-design_

### Changed
- R10_error_code_family_status_consistency: added an operational scan anchor — cluster active codes by rejection-reason/semantic family, grep each member's protocol status (HTTP / @ResponseStatus / gRPC), and flag a family carrying >=2 distinct statuses with no axis/waiver; grep @Deprecated near family members for migration residue. The rule already defined family-status divergence but gave no operational way to locate it; in practice the wording surfaced such splits only by inspiration, missing real 400-vs-422 family splits (a recall gap, not a precision gap).

## v4.1.0 (2026-06-24) — error-code family consistency

_skill: api-error-code-design_

### Added
- R10_error_code_family_status_consistency: cluster active codes by rejection-reason / semantic family and require one protocol-level status + naming style per family (split needs explicit registry axis/waiver); require code/enum/message names to migrate when a control's cardinality or scheme changes (no residual old-cardinality literal); require each code's declared trigger scenario to match the scenario it is actually thrown in.
- HTTP mapping discipline: added cross-family consistency clause (distinct from the single-code published-pair freeze of R09).
- checklist: family-status consistency, name-migrates-with-cardinality, declared-vs-actual-scenario checks.
- common-failure-modes F8: same-family status drift + stale cardinality names + declared-vs-actual scenario drift.

### Note
- R10 is orthogonal to R02 (single-code mapping completeness) and R09 (single-code pair frozen across versions); its axis is cross-same-family status/naming consistency at a single point in time plus naming-migrates-with-control-cardinality.

---

## v4.0.0 (2026-04-30) — v10 final optimization

_skill: api-error-code-design_

### Added
- Trigger conditions + Standalone rule sections
- Confidence discipline (confirmed/inferred/pending separation)
- Downstream handoff summary
- Compatibility-map.md with field-level input/output mapping
- blocked + degraded example-io scenarios

### Changed
- Description trimmed to ≤25 words
- Quick-reference tables expanded to ≥4 per skill
- rule_results expanded to R01-R08

### Fixed
- CHANGELOG format standardized to `# CHANGELOG` header
- Chinese/English section headers unified to English

---

## v3.0.0 (2026-04-30) — v5 optimization batch

### Added
- common-failure-modes.md with Symptom/Fix format (F1–F8)
- workflow-position.md
- compatibility-map.md
- CHANGELOG.md

### Changed
- Checklist rewritten with inline `- [ ]` items
- example-io.md expanded with concrete YAML examples
- Description word count reduced

---

## v2.0.0 (2026-01-15) — v2 contract migration

### Added
- artifact_schema_version header
- produced_event field
- blocker_mapping field
- rule_results[] with pass|warn|reject|not_applicable
- feedback_signal_to_n005 reverse governance channel

---

## v1.0.0 (2025-10-01) — initial release
