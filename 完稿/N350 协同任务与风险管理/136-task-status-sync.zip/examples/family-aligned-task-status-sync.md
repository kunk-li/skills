# Task Status Sync Example - TASK register to status snapshot

```yaml
metadata:
  contract_version: n350-coordination-v1.1.0
  workflow_node: N350
  skill_id: 136
  skill_name: task-status-sync
  artifact_family_id: n350-task-risk-coordination-suite
  artifact_id: STATUS-platform-202619
  csv_schema: n350.task-status-sync.v2
  selected_mode: blocker_aware_status_refresh
  readiness: ready
  source_time_window: {start: 2026-05-07, end: 2026-05-07, timezone: Asia/Tokyo}
  project_scope: platform
  team_scope: [platform, backend, qa]
  sprint_or_release: 2026-W19
  source_artifacts: [TASK-LIST-platform-202619, weekly status notes]
  upstream_id_aliases: [ACT-platform-202619-01]
  evidence_refs:
    - {ref_id: EV-N350-STATUS-001, source_family: status_update, source_name: weekly status notes, time_window_or_version: 2026-05-07, scope: [platform], upstream_id_aliases: [TASK-platform-01], excerpt_or_pointer: API doc patch started and QA waits for docs, confidence: high, layer: confirmed_fact}
  cross_artifact_refs: [TASK-LIST-platform-202619]
  pending_clarifications: []
  open_blockers: [BLK-platform-01]
  owner_placeholders: [backend lead, qa owner]
  confidentiality_level: public_internal
  confidence: high
  composition_role: task_state_refresher
  function_bias: turn_updates_into_conservative_status_snapshot
  stage_position: execution_governance.task_coordination.task-status-sync
  artifact_target: 任务状态快照.csv
  freshness: {as_of_date: 2026-05-07, source_commit: null, expected_review_window: weekly}
```

```csv
id,title,owner,status,progress_summary,blocker_refs,dependency_refs,next_step,deadline,last_update,evidence_ref
TASK-platform-01,补齐平台错误码文档入口,backend lead,IN_PROGRESS,已开始补 API 文档入口并确认 FAQ 链接位置,,ACT-platform-202619-01,补齐错误码表并提交审核,2026-05-10,2026-05-07,EV-N350-STATUS-001
TASK-platform-02,补一轮回归状态同步,qa owner,BLOCKED,等待 TASK-platform-01 完成后才能启动回归,BLK-platform-01,TASK-platform-01,等待文档入口补齐后启动回归,2026-05-11,2026-05-07,EV-N350-STATUS-001
```
