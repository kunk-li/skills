# N350 Escalation Path Rules

Use this reference when determining escalation paths for blockers, risks, and stale tasks.

## Escalation triggers

| Signal | Threshold | Escalation target | Skill |
|--------|-----------|------------------|-------|
| Blocker not resolved | >3 business days open | PM-role → EM | #137 |
| Risk score | ≥15 (high) | PM-role + ENG-lead | #138 |
| scope_trim_candidate=YES | Any single YES | N360 #141 | #138 |
| Stale task | IN_PROGRESS(stale) for ≥2 cycles | Owner's TL | #136 |
| Success criteria unclear | Ambiguous after 1 clarification | ENG-lead | #135 |

## Escalation path format

```yaml
escalation_path:
  level_1: "[role] via [channel] by [deadline]"
  level_2: "[role] via [channel] if level_1 fails by [date]"
  level_3: "[role/group] for unresolved critical issues"
```

## N350 → N360 escalation

When N350 signals reach N360 thresholds:
- **scope_trim_candidate=YES**: immediately trigger #141 fresh_assessment or emergency_trim
- **≥2 BLOCKED tasks with same blocker**: escalate to PM for external dependency resolution
- **≥50% tasks IN_PROGRESS(stale)**: escalate to ENG-lead for sprint health review

## Cross-skill escalation handoffs

#135 → #137: task marked BLOCKED → blocker-extraction creates BLK-* entry
#136 → #137: IN_PROGRESS(stale) tasks flagged → blocker-extraction confirms if blocked
#137 → #138: unresolved blocker with high business impact → risk item created
#138 → N360: scope_trim_candidate=YES → version-scope-trimming triggered

## Escalation anti-patterns

- **Do not escalate every blocker**: only escalate when owner cannot unblock independently within 3 business days
- **Do not skip levels**: level_1 escalation must be attempted before level_2
- **Do not use personal blame**: use role/team language, never individual names
