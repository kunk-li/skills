# Stale Task Detection Rules

Use this reference when applying `IN_PROGRESS(stale)` status or evaluating task activity.

## Definition of stale

A task is `IN_PROGRESS(stale)` when ALL of the following are true:
1. The task's status in the previous snapshot was `IN_PROGRESS`
2. The current input cycle (standup notes, weekly update, status email, etc.) contains NO mention of this task
3. No progress evidence of any kind is available (no PR, no commit, no meeting reference, no dependency update)

**One missing cycle is sufficient to mark stale.** Do not wait for two cycles.

## Stale detection procedure

```
For each task with prior status = IN_PROGRESS:
  1. Search current input for task_id (T-xxx) OR task title keywords
  2. If found with progress evidence → keep IN_PROGRESS, update progress_summary
  3. If found but only to say "still in progress" with no new evidence → IN_PROGRESS(stale)
  4. If NOT found anywhere in current input → IN_PROGRESS(stale)
  5. If found with a blocker newly mentioned → BLOCKED (update blocker_refs)
```

## progress_summary for stale tasks

When marking `IN_PROGRESS(stale)`, the `progress_summary` field must contain:
```
"上周状态: IN_PROGRESS; 本周无进展证据; 建议下次同步确认是否阻塞或可推进"
```
Never leave `progress_summary` empty for a stale task.

## What is NOT stale (do not over-apply)

- Task mentioned but owner said "no update this week" → still IN_PROGRESS (explicit confirmation is evidence)
- Task not mentioned but has a known external dependency (appears in blocker_refs) → BLOCKED, not stale
- Task in a planned pause (holiday, dependency wait with known resume date) → add note to progress_summary, keep IN_PROGRESS

## Stale task escalation

If a task has been `IN_PROGRESS(stale)` for 2 consecutive cycles:
1. Add to `downstream_handoff.stale_tasks` with `stale_cycles: 2`
2. Flag in delta summary as requiring explicit owner confirmation
3. Do NOT automatically change to BLOCKED without blocker evidence

## validate_csv.py stale checks

The validate_csv.py script enforces:
- `IN_PROGRESS(stale)` is a valid status value (not rejected)
- Any row with `IN_PROGRESS(stale)` must have `progress_summary` containing "无进展" or "stale"
- Rows with `IN_PROGRESS(stale)` generate an INFO line listing all stale task IDs
