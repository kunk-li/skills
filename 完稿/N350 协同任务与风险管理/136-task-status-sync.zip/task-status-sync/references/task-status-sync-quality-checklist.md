# 任务状态同步 Quality Checklist

Use this checklist before returning an N350 artifact.

1. Metadata contains all required shared fields when structured output is expected.
2. `contract_version` and `csv_schema` match the current skill and release.
3. `selected_mode` matches the actual update path.
4. Stable IDs follow artifact and row ID formats; old IDs are preserved in delta mode.
5. CSV output uses the exact column order from `references/csv-schema.md`.
6. Multi-value CSV fields use `|`, not bare commas.
7. Evidence references identify source family, source name, pointer, confidence, and layer.
8. Missing owner, deadline, evidence, score, or decision is marked `待确认` or `待核对`.
9. `cross_artifact_refs` use artifact or row IDs, not local file paths.
10. `downstream_handoff` includes handoff_id, consumer, required_fields, readiness, confidence, and next_best_checks.
11. Compare the output against the closest file under `examples/`; differences are allowed but should be intentional.

## Skill-specific checks
- Only use TODO, IN_PROGRESS, DONE, BLOCKED.
- DONE requires completion evidence; BLOCKED requires current blocker evidence.
- progress_summary starts with facts before uncertainty.
- Use blocker_refs/dependency_refs/evidence_ref with pipe-separated IDs.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- `delta_mode`: `## 变更摘要` block always present with all 5 subsections; empty subsections state "无".
- `IN_PROGRESS(stale)` correctly used when task had prior IN_PROGRESS but no progress evidence this cycle.
- No status field uses values outside {TODO, IN_PROGRESS, DONE, BLOCKED, IN_PROGRESS(stale)}.

## Output structure completeness checks
- All 4 mandatory sections present per mandatory section table
- validate_csv.py passes all schema checks (no invalid status values)
- `delta_mode`: `## 变更摘要` present with all 5 sub-sections, each explicitly writes "无" if empty
- downstream_handoff has `blocked_task_ids` and `stale_task_ids` fields
