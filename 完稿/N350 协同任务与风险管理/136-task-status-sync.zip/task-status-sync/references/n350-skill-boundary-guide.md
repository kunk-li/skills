# N350 Skill Boundary Guide

Use this reference when you need to decide which N350 skill to invoke or how to handle borderline cases.

## N350 skill selection decision tree

```
Input contains task/action items to be created or structured?
  YES → #135 task-initiation
  NO  ↓
Input contains status updates for existing tasks?
  YES → #136 task-status-sync
  NO  ↓
Input contains something currently blocking progress?
  YES → #137 blocker-extraction
  NO  ↓
Input contains something that might block future progress?
  YES → #138 risk-item-extraction
```

## Boundary cases

| Situation | Correct skill | Why |
|-----------|--------------|-----|
| "Task T-034 is blocked waiting for auth-team spec" | #137 | Blocker is actively preventing work NOW |
| "We might miss the deadline if auth-team is late" | #138 | Future risk, not current blocker |
| "We need to track the auth-team spec delivery as a task" | #135 | New task creation |
| "T-034 status changed from TODO to BLOCKED" | #136 | Status update of existing task |

## Dual-extraction rule

A single input may simultaneously produce:
- #135 output (new tasks discovered)
- #136 output (existing task status updates)
- #137 output (blockers identified)
- #138 output (risks identified)

All four can be produced in a single session with separate artifacts.

## Anti-patterns

**Do not force a risk into a blocker**: "might be late" is a risk, not a blocker. Blockers require evidence of current impact.
**Do not create tasks for blockers**: blockers have unblock_actions, not task IDs. If a blocker requires new work, create a separate task in #135.
**Do not track individual defects as risks**: defects belong in the defect tracking system. #138 tracks delivery/schedule/scope risks.
