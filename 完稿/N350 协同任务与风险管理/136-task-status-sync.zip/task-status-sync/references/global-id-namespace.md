# global-id-namespace.md — N320–N360 跨节点 ID 前缀注册表

**用途**：所有在 downstream_handoff 中传递的 artifact ID 必须使用此表登记的前缀，确保跨 skill 引用可追溯。

**维护规则**：
- 每次新增 ID 前缀时同步更新此表
- 前缀格式：`<PREFIX>-<YYYYMMDD 或序号或语义标识>`，如 `TL-INC-20250607-001`
- 前缀唯一性由发起方 skill 负责；接收方 skill 不应自行创建同前缀 ID

---

## N320 — 故障沉淀层

| ID 前缀 | 归属 Skill | Artifact 类型 | 示例 | 传递方向 |
|---------|------------|--------------|------|---------|
| `TL-INC-` | #123 incident-timeline-compilation | 故障时间线 | `TL-INC-20250507-001` | #123 → #124 |
| `AI-INC-` | #124 production-incident-postmortem | 复盘行动项 | `AI-INC-20250507-001` | #124 → N340 #131 |

**契约版本**：`n320-postmortem-v1.3.2`

---

## N330 — 技术与运维文档层

| ID 前缀 | 归属 Skill | Artifact 类型 | 示例 | 传递方向 |
|---------|------------|--------------|------|---------|
| `DOC-DEV-` | #125 development-documentation-generation | 开发者入口文档 | `DOC-DEV-20250607-001` | #125 → N340 #132/#133 |
| `API-` | #126 api-documentation-generation | API 索引条目 | `API-checkout-v2` | #126 → #125, #129 |
| `SVC-` | #127 module-design-document-generation | 服务卡片 ID | `SVC-payment-001` | #127 → #125/#126/#128/#129/#130 |
| `FLD-` | #128 data-dictionary-generation | 字段级条目 | `FLD-users-email-001` | #128 → #125/#126 |
| `DEPLOY-` | #129 deployment-documentation-generation | 部署文档 | `DEPLOY-v2.3.0-prod` | #129 → #130 |
| `OPS-` | #130 maintenance-manual-generation | 运维手册 | `OPS-checkout-triage-001` | #130 → N320 #123 (scenario_triggered) |

**契约版本**：`n330-doc-suite-v1.2.1`

---

## N340 — 协作文档层

| ID 前缀 | 归属 Skill | Artifact 类型 | 示例 | 传递方向 |
|---------|------------|--------------|------|---------|
| `AI-` | #131 meeting-minutes-to-action-items | 行动项 | `AI-20250607-001` | #131 → #132, N350 #135 |
| `WEEK-` | #132 weekly-report-generation | 周报 | `WEEK-2025W24-pm` | #132 → #133, N360 #142 |
| `FAQ-` | #133 faq-generation | FAQ 条目 | `FAQ-checkout-001` | #133 → #134 |
| `BP-` | #134 best-practice-summary | 最佳实践 pattern | `BP-001` | #134 → 知识库/工程标准 |
| `AP-` | #134 best-practice-summary | 反模式 anti-pattern | `AP-001` | #134 → 知识库/工程标准 |

**契约版本**：`n340-collaboration-v1.1.2`

---

## N350 — 任务协同层

| ID 前缀 | 归属 Skill | Artifact 类型 | 示例 | 传递方向 |
|---------|------------|--------------|------|---------|
| `T-` | #135 task-initiation | 任务台账条目 | `T-042` | #135 → #136 |
| `SNAP-` | #136 task-status-sync | 状态快照 | `SNAP-2025W24-001` | #136 → #137 |
| `BLK-` | #137 blocker-extraction | 阻塞项 | `BLK-042` | #137 → #138 |
| `RISK-` | #138 risk-item-extraction | 风险项 | `RISK-042` | #138 → N360 #141 |

**契约版本**：`n350-coordination-v1.1.1`

---

## N360 — 跨团队治理层

| ID 前缀 | 归属 Skill | Artifact 类型 | 示例 | 传递方向 |
|---------|------------|--------------|------|---------|
| `TOPIC-` | #139 product-engineering-alignment-summary | 产研对齐议题 | `TOPIC-003` | #139 → #141, N380 |
| `QA-TOPIC-` | #140 qa-engineering-alignment-summary | 测研对齐议题 | `QA-TOPIC-003` | #140 → #141, N380 |
| `TRIM-` | #141 version-scope-trimming-recommendation | 裁剪建议条目 | `TRIM-001` | #141 → release-owner |
| `RHYTHM-` | #142 project-rhythm-tracking | 节奏跟踪条目 | `RHYTHM-003` | #142 → #141 |

**契约版本**：`n360-cross-team-v1.1.2`

---

## 跨节点传递链路汇总

```
N320:
  #123 (TL-INC-*) → #124
  #124 (AI-INC-*) → N340 #131

N330:
  #127 (SVC-*) → #125/#126/#128/#129/#130
  #128 (FLD-*) → #125/#126
  #126 (API-*) → #125/#129
  #129 (DEPLOY-*) → #130
  #130 scenario_triggered → N320 #123

N340:
  #131 (AI-*) → #132, N350 #135
  #132 (WEEK-*) → #133, N360 #142
  #133 (FAQ-*) → #134

N350:
  #135 (T-*) → #136
  #136 (SNAP-*, blocked_task_ids) → #137
  #137 (BLK-*) → #138
  #138 (RISK-*, scope_trim_candidate=YES) → N360 #141

N360:
  #139 (TOPIC-*, pending_decisions) → #141, N380
  #140 (QA-TOPIC-*, pending_decisions) → #141, N380
  #141 (TRIM-*) → release-owner
  #142 (RHYTHM-*, scope_trim_recommended) → #141
```
