# N350 Contracts Quick Pointer

Use `references/n350-shared-coordination-contract.md` as the canonical node contract for `n350-coordination-v1.1.1`.

This file remains as a short compatibility pointer for original N350 skills.
