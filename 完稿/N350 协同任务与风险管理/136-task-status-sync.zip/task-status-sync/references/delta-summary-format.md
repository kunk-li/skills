# Delta Summary Format

Use this reference when producing output in `delta_mode` to construct the mandatory `## 变更摘要` block.

## When this block is required
The `## 变更摘要` block is required every time `delta_mode` is used — i.e., whenever an existing task snapshot is updated rather than created from scratch.

## Format specification

```markdown
## 变更摘要（相比上次快照，日期: YYYY-MM-DD）

### 状态变化
- T-012: TODO → IN_PROGRESS（开始 API 接口开发，owner: backend-team）
- T-019: IN_PROGRESS → DONE（代码 review 通过，PR #1892 合入）
- T-023: IN_PROGRESS → IN_PROGRESS(stale)（上周已启动，本周无进展证据）

### 新增阻塞
- T-015: 新增 BLOCKED（依赖 auth-team API spec 未交付，见 BLK-008）

### 新完成
- T-009: DONE（QA staging 回归通过，2025-06-10）
- T-011: DONE（合规文档更新，法务确认）

### 新增任务
- T-031: 新增 TODO（从 MTG-2025-0610#action:5 提取）

### ID 保留确认
所有原有任务 ID（T-001 ~ T-030）已保留，无漂移。
```

## Rules for each subsection
- **状态变化**: Only include tasks whose status actually changed. Format: `{id}: {old} → {new}（{reason}）`
- **新增阻塞**: Only new blockers added this cycle. Reference blocker IDs from blocker register if available.
- **新完成**: Only tasks completed this cycle, with evidence (PR number, approval record, meeting reference).
- **新增任务**: Only tasks added this cycle (not previously tracked). Include source reference.
- **ID 保留确认**: Always include this line to confirm ID stability.

## IN_PROGRESS(stale) rules
Use `IN_PROGRESS(stale)` when:
- A task was `IN_PROGRESS` in the previous snapshot
- This cycle's input contains NO mention of that task
- No progress evidence of any kind is available

Format in the delta summary: `T-023: IN_PROGRESS → IN_PROGRESS(stale)（上周已启动，本周无进展证据；需确认是否阻塞）`

The `progress_summary` field in the CSV row for stale tasks must include: `"上周状态: IN_PROGRESS; 本周无进展证据; 建议下次同步确认"`

## Omitting subsections
A subsection may be omitted if it has no entries — but the `## 变更摘要` header and `ID 保留确认` line are always required in delta mode.

## Linking to blocker register
If a new blocker is added, reference the blocker register artifact:
```
- T-015: 新增 BLOCKED（BLK-008, 详见阻塞项台账 artifact:BLOCKER-REG-2025-06）
```
