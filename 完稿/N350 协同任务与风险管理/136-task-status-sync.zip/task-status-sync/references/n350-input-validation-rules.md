# N350 Input Validation Rules

Use this reference when input quality is uncertain or when selecting the appropriate N350 skill or mode.

## Skill selection per input signal

| Input signal | Best skill | Mode |
|-------------|-----------|------|
| "Need to create task list from scratch" | #135 task-initiation | full_draft |
| "Have existing tasks, need to update" | #135 then #136 | incremental_merge → delta_update |
| "Something is blocking progress RIGHT NOW" | #137 blocker-extraction | fresh_register or delta_update |
| "Something MIGHT block future progress" | #138 risk-item-extraction | fresh_register or delta_update |
| "Need to track task status across the week" | #136 task-status-sync | delta_update or snapshot |
| "Risk score is ≥15, need trimming decision" | → N360 #141 | emergency_trim |

## Minimum viable input per skill

| Skill | Minimum | What is produced without full input |
|-------|---------|-------------------------------------|
| #135 | Any task list, action items, or requirements | full_draft with `待确认` for missing fields |
| #136 | Status mentions, standup notes, or prior snapshot | snapshot with IN_PROGRESS(stale) for silent tasks |
| #137 | Any mention of something "blocking" or "waiting" | blocker register; ambiguous items marked PENDING_CONFIRMATION |
| #138 | Any mention of risk, dependency, or uncertainty | risk register with estimated likelihood/impact |

## Input quality tiers for N350

**tier-1**: Structured artifacts with stable IDs (TASK-REG-*, STATUS-*, BLOCKER-*, RISK-*)  
**tier-2**: Meeting notes, standup summaries, weekly updates  
**tier-3**: Verbal descriptions, Slack message screenshots, rough notes  

Lower tiers → lower `confidence` in output → stated in downstream_handoff.

## When NOT to use any N350 skill

- **Single-sentence task**: "do X" without any context → ask for minimum input first
- **Already in N360 scope**: if the conversation is about release go/no-go, route to N360 directly
- **Governance decisions**: "should we cancel the project?" belongs to N380, not N350

## Partial input handling

When critical fields cannot be determined:
1. Use `待确认` for owner, deadline, priority — never invent values
2. Use `待核对` for evidence_ref when source cannot be traced
3. Set `readiness: partial` in metadata
4. List all gaps in `downstream_handoff.next_best_checks`
