---
name: task-status-sync
description: 生成任务状态快照（任务状态同步）用于 n350 任务协同。triggered when the assistant needs to produce or refresh a task status csv from standup notes, chat logs, sprint board exports, or direct status updates. use delta_status_sync mode (default) when a prior snapshot exists. do not use for task creation (→ #135), blocker analysis (→ #137), or risk assessment (→ #138).
---

# 任务状态同步

## N350 contract baseline (n350-coordination-v1.1.1)

- contract_version: `n350-coordination-v1.1.1`
- workflow_node: N350
- skill_id: 136
- artifact_target: `任务状态快照.csv / task_status_snapshot.csv`
- csv_schema: `n350.task-status-sync.v2`
- composition_role: `task_state_refresher`
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through stable row IDs, `csv_schema`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

## Role

作为 N350 任务协同层的**任务状态同步生成器**，把散落在各处的状态更新压缩成可追踪、可增量刷新的任务状态快照。

具体职责：
- `delta_status_sync` 模式（最常用）：保留所有 task ID，只更新变化字段，输出完整 `## 变更摘要` 5子区块
- 标记 `IN_PROGRESS(stale)` — 仅限当前周期**零证据**的任务（owner 确认"无更新"本身就是证据，不算 stale）
- 将 `blocked_task_ids` 和 `stale_task_ids` 传递给 #137
- 运行 validate_csv.py 验证状态值合法性

**不负责**：任务创建（→ #135）、阻塞详情分析（→ #137）、风险评估（→ #138）、规划决策（→ N360）。

## When NOT to use this skill

- **Not a task register**: task creation belongs in #135; #136 updates status of existing tasks.
- **Not a blocker register**: when a blocked task needs unblock analysis, route to #137 after snapshot; #136 only marks tasks as BLOCKED.
- **Not a risk register**: risk signals in status updates flow to #138; #136 records task-level status, not risk assessments.
- **Not a planning tool**: #136 reflects what IS happening, not what SHOULD happen; scope changes belong in N360 #141.
- **Stale boundary**: `IN_PROGRESS(stale)` is for tasks with ZERO evidence in the current cycle. Owner confirming "no update this week" IS evidence → keep `IN_PROGRESS`, not stale.

## Standalone and composition role

```yaml
standalone_goal: produce or refresh a task status snapshot from any available status update material
minimum_viable_input:
  any_of:
    - standup 记录或状态更新
    - 聊天记录或 sprint board 导出
    - 周期进展笔记或邮件摘要
    - 旧快照 + 新输入（delta 模式首选）
partial_readiness_allowed: true
degradation_behavior: >
  If input is sparse, keep the most conservative defensible status and write uncertainty
  into progress_summary. Use IN_PROGRESS(stale) only for truly zero-evidence tasks.
  When prior snapshot conflicts with new input on same task status: prefer new evidence
  (new input takes precedence), and note the discrepancy in progress_summary.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `delta_status_sync`: 有旧快照 + 新状态更新 → 保留所有 task ID，只更新变化字段，输出完整 `## 变更摘要` 区块（5子区块）。**最常用模式**。
- `snapshot_status_report`: 无旧快照或需要完整重建 → 从头生成当前完整任务状态快照。
- `weekly_sync_summary`: 面向周报消费的精简版快照，附 delta 摘要，适合传递给 N340 #132。
- `blocker_aware_status_refresh`: 含大量 BLOCKED 任务时，优先展示阻塞任务，blocked_task_ids 置顶。

**Default routing**: 有旧快照 + 新更新 → `delta_status_sync`; 无旧快照 → `snapshot_status_report`.

## Status values

Only use these enumerated values: `TODO` / `IN_PROGRESS` / `IN_PROGRESS(stale)` / `DONE` / `BLOCKED`

- `TODO`: 没有可靠证据显示已启动
- `IN_PROGRESS`: 有可靠证据显示已开始，但未完成，也未被 blocker 卡住
- `IN_PROGRESS(stale)`: 上周 IN_PROGRESS 但**本周完全无证据**（owner 确认"无更新"不算 stale）
- `DONE`: 有明确完成证据
- `BLOCKED`: 有明确证据显示当前进度被 blocker 卡住

**Input conflict rule**: when prior snapshot and new input disagree on the same task status → prefer new input, record discrepancy in `progress_summary`.

## Input conflict resolution

When the same task appears in multiple sources with conflicting status values (e.g., `DONE` in a standup note but `IN_PROGRESS` in the prior snapshot):
- Prefer the **most recent source** — new input takes precedence over prior snapshot.
- Record discrepancy in `progress_summary`: `"Status conflict on TASK-001: done per standup vs in_progress in prior snapshot — validated with owner"`.
- Never silently resolve by keeping the prior value.
- Status improvements (e.g., BLOCKED → IN_PROGRESS) require an `unblock_evidence` note; otherwise treat as a data entry error and flag for confirmation.

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | Metadata | Always | artifact_id, selected_mode, snapshot_date, prior_snapshot_id |
| 2 | 任务状态快照 CSV | Always | All status columns; run validate_csv.py before output |
| 3 | 变更摘要 | Always in delta_status_sync | 5 sub-blocks: new_done / newly_blocked / stale / status_changed / unchanged |
| 4 | Downstream handoff | Always | blocked_task_ids + stale_task_ids passed to #137 |

> Legend: Always = required in every mode.

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** 把"owner 确认本周无更新"标为 `IN_PROGRESS(stale)` → 确认本身是证据；保持 `IN_PROGRESS`，stale 仅用于真正零证据任务。量化检验：标为 IN_PROGRESS(stale) 的任务数必须 ≤ 本周期确实无任何证据（standup 记录、commit、PR）的任务数；owner 确认「无更新」本身即为证据，不算 stale。
- **AP-2** 旧快照与新输入冲突时静默采用旧值 → 必须以新证据为准，并在 progress_summary 中记录差异。量化检验：prior snapshot 和 new input 对同一 task status 不一致的冲突数 = progress_summary 中「Status conflict」记录数；漏记则 FAIL。
- **AP-3** delta 模式下 `## 变更摘要` 缺少 5 个子区块 → 必须完整输出；即使某子区块为空也要保留标题。量化检验：delta_status_sync 模式下，new_done/newly_blocked/stale/status_changed/unchanged 五个子标题必须全部出现；缺失任一则 FAIL。
- **AP-4** status 使用枚举以外的值（如"进行中"、"阻塞"）→ 只接受 TODO/IN_PROGRESS/IN_PROGRESS(stale)/DONE/BLOCKED。量化检验：validate_csv.py 校验 status 列枚举值，非法值行数 = FAIL 数。

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: blocker-extraction / N340/weekly-report-generation
  blocked_task_ids: [T-012, T-015]
  stale_task_ids: [T-008]
  snapshot_date: "YYYY-MM-DD"
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all tasks have confirmed status with evidence) / `partial` (some tasks have unconfirmed status — listed in open notes) / `degraded` (minimal evidence; snapshot reflects assumed states only — downstream consumers must validate all BLOCKED and stale entries before acting).

## Workflow position

```
Standup notes / sprint board exports / chat logs / prior snapshot
  ↓ #136 (status snapshot refresh → 任务状态快照.csv)
  → blocked_task_ids + stale_task_ids → #137 (blocker extraction)
  → weekly_sync_summary → N340 #132 (weekly report)
```

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n350-shared-coordination-contract.md` — shared contract and handoff rules
- `references/n350-skill-boundary-guide.md` — when skill selection is ambiguous
- `references/n350-escalation-path-rules.md` — when determining escalation paths
- `references/n350-input-validation-rules.md` — when input quality is uncertain
- `references/csv-schema.md` — column definitions for n350.task-status-sync.v2
- `references/delta-summary-format.md` — when building the delta summary 5-sub-block structure
- `references/stale-detection-rules.md` — when evaluating IN_PROGRESS(stale) eligibility
- `references/task-status-sync-quality-checklist.md` — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/delta-status-with-stale.md` — delta_status_sync with stale detection and 5-sub-block summary
- `examples/family-aligned-task-status-sync.md` — weekly_sync_summary feeding N340 #132
