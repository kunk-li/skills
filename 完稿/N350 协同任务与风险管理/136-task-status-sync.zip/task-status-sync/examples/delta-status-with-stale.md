# Example: Task Status Sync — Delta Mode with Stale Tasks

Demonstrates `delta_mode` with `IN_PROGRESS(stale)` detection and full `## 变更摘要` block.

**Input**: `TASK-REG-S23` (prior snapshot) + Sprint 23 week 2 standup notes.

```yaml
metadata:
  contract_version: n350-coordination-v1.1.1
  skill_id: "136"
  selected_mode: delta_mode
  artifact_id: STATUS-S23-W25
  prior_snapshot_id: STATUS-S23-W24
  readiness: complete
```

## Task Status Snapshot CSV

```csv
id,title,owner,status,progress_summary,blocker_refs,dependency_refs,next_step,deadline,last_update,evidence_ref
T-031,支付模块后端 API 实现,backend-team,DONE,PR #1892 合入 main，代码 review 通过，覆盖率 82%,,T-034,移交 QA 开始回归,2025-06-13,2025-06-13,pr:1892|standup:2025-06-13
T-032,支付模块 QA 回归,qa-team,IN_PROGRESS,已收到 T-031 移交，开始 staging 环境部署，预计明天完成基础回归,BLK-008,T-031,完成 staging 基础回归,2025-06-17,2025-06-13,standup:2025-06-13
T-033,Redis warm-up 集成,platform-team,IN_PROGRESS(stale),上上周已启动方案设计，本周及上周均无进展证据，需确认是否阻塞,,T-031,确认状态,2025-07-01,,
T-034,OAuth callback spec v1,backend-lead,BLOCKED,等待 auth-team spec，BLK-008 未解阻,BLK-008,,等待 BLK-008 解阻,2025-06-30,2025-06-10,meeting:sync-0610
```

## 变更摘要（相比上次快照 STATUS-S23-W24，2025-06-10）

### 状态变化
- T-031: IN_PROGRESS → DONE（PR #1892 合入，覆盖率 82%，2025-06-13）
- T-032: TODO → IN_PROGRESS（收到 T-031 移交，开始 staging 部署）
- T-033: IN_PROGRESS → IN_PROGRESS(stale)（连续两周无进展证据）

### 新增阻塞
- 无新增阻塞（BLK-008 持续，状态未变）

### 新完成
- T-031: DONE（2025-06-13，evidence: PR #1892）

### 新增任务
- 无

### ID 保留确认
T-031 ~ T-034 均保留，无漂移。

---

**IN_PROGRESS(stale) 说明**: T-033 连续两周在 standup 和周报中未被提及，无任何进展记录。按 `references/delta-summary-format.md` 规则，标记为 `IN_PROGRESS(stale)`，`progress_summary` 注明"建议下次同步确认是否阻塞"。

**Downstream Handoff**

```yaml
handoff_id: STATUS-HANDOFF-S23-W25
producer_skill: task-status-sync
consumer_skill_or_node: blocker-extraction|N360
cross_artifact_refs:
  - artifact_id: STATUS-S23-W24
    relationship: prior_snapshot
stale_tasks: [T-033]
blocked_tasks: [T-034]
readiness: complete
confidence: high
next_best_checks:
  - "blocker-extraction: confirm T-033 stale status is not a new blocker"
  - "BLK-008: check if auth-team spec arrived since last snapshot"
```
