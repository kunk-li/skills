# Example: Task Status Sync — Sparse Input / Degraded Mode

## Metadata

```yaml
artifact_id: TASK-STATUS-SPARSE-001
skill_id: 136
contract_version: n350-coordination-v1.1.1
selected_mode: snapshot_status_report
snapshot_date: "2025-06-20"
prior_snapshot_id: null
evidence_sources: ["one standup note with incomplete coverage"]
readiness: degraded
```

## Task Status Snapshot CSV

| id | title | owner | status | progress_summary | evidence_ref |
|----|-------|-------|--------|-----------------|--------------|
| T-001 | 支付接口开发 | 后端团队 | IN_PROGRESS | standup 提到「在做」，无具体进展 | standup-2025-06-20 |
| T-002 | 数据迁移脚本 | DBA 团队 | IN_PROGRESS(stale) | 本周 standup 完全未提及，无任何证据 | 待核对 |
| T-003 | 前端联调 | 前端团队 | TODO | standup 未提及；prior snapshot 中为 TODO | standup-2025-06-20 |
| T-004 | 压测执行 | QA 团队 | BLOCKED | standup: QA-lead 提到「等待测试环境，本周无法开始」 | standup-2025-06-20 |

**Degradation notes:**
- 仅有 1 个 standup 记录，覆盖 4/4 任务但信息密度低
- T-002 无任何证据 → 标为 IN_PROGRESS(stale)（上周为 IN_PROGRESS）
- T-003 无更新证据 → 保守维持 TODO（不推测已启动）
- 本快照 readiness=degraded，下游消费方（#137）在使用 blocked_task_ids 前应额外确认

## Change Summary (delta vs prior snapshot)

> 注：本次为首次 snapshot（无 prior），直接生成完整快照，变更摘要仅供参考。

- **new_done**: 无
- **newly_blocked**: T-004（新增 BLOCKED 证据）
- **stale**: T-002（零证据，升级为 stale）
- **status_changed**: T-004 TODO→BLOCKED
- **unchanged**: T-001、T-003

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: blocker-extraction / N340/weekly-report-generation
  blocked_task_ids: [T-004]
  stale_task_ids: [T-002]
  snapshot_date: "2025-06-20"
  readiness: degraded
  degradation_note: "single standup source only; all statuses should be confirmed before acting on blocked/stale signals"
```
