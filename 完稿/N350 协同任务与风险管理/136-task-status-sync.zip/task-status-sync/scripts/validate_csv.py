#!/usr/bin/env python3
"""validate_csv.py for n350.task-status-sync.v2 — updated to support IN_PROGRESS(stale)"""
import csv
import sys
import re
from pathlib import Path

SCHEMA_NAME = 'n350.task-status-sync.v2'
EXPECTED_HEADERS = ['id', 'title', 'owner', 'status', 'progress_summary', 'blocker_refs', 'dependency_refs', 'next_step', 'deadline', 'last_update', 'evidence_ref']
REQUIRED_FIELDS = set(['id', 'title', 'owner', 'status', 'progress_summary'])
LIST_FIELDS = set(['blocker_refs', 'dependency_refs', 'evidence_ref'])
ALLOWED_STATUS = {'TODO', 'IN_PROGRESS', 'DONE', 'BLOCKED', 'IN_PROGRESS(stale)'}

# success_criteria vague phrases to warn about (for task-initiation schema only)
VAGUE_CRITERIA_PATTERNS = [r'^完成$', r'^完成开发$', r'^测试通过$', r'^上线$', r'^验证完成$']

def fail(msg: str) -> int:
    print(f"[FAIL] {msg}")
    return 1

def warn(msg: str) -> None:
    print(f"[WARN] {msg}")

def ok(msg: str) -> int:
    print(f"[OK] {msg}")
    return 0

def main() -> int:
    if len(sys.argv) < 2:
        print('usage: python scripts/validate_csv.py <task-status-sync.csv> [--strict]')
        return 2
    path = Path(sys.argv[1])
    strict = '--strict' in sys.argv
    if not path.exists():
        return fail(f"file not found: {path}")
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        if headers != EXPECTED_HEADERS:
            return fail(f"header mismatch for {SCHEMA_NAME}. expected={EXPECTED_HEADERS} got={headers}")
        rows = list(reader)
    if not rows:
        return fail("csv has no data rows")

    seen_ids = set()
    errors = 0
    warnings = 0
    stale_count = 0

    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED_FIELDS:
            if not (row.get(field) or '').strip():
                print(f"[FAIL] row {idx} missing required field: {field}")
                errors += 1
        for field in LIST_FIELDS:
            value = (row.get(field) or '').strip()
            if ',' in value and '待' not in value:
                print(f"[FAIL] row {idx} field '{field}' must use '|' instead of commas for multi-value lists")
                errors += 1

        ident = (row.get('id') or '').strip()
        if ident in seen_ids:
            print(f"[FAIL] duplicate id at row {idx}: {ident}")
            errors += 1
        seen_ids.add(ident)

        status = (row.get('status') or '').strip()
        if status not in ALLOWED_STATUS:
            print(f"[FAIL] row {idx} invalid status: '{status}'. allowed: {sorted(ALLOWED_STATUS)}")
            errors += 1
        if status == 'IN_PROGRESS(stale)':
            stale_count += 1
            # Stale tasks must have progress_summary mentioning "无进展"
            summary = (row.get('progress_summary') or '').strip()
            if '无进展' not in summary and 'stale' not in summary.lower():
                warn(f"row {idx} IN_PROGRESS(stale) status but progress_summary does not mention lack of progress")
                warnings += 1

    if stale_count > 0:
        print(f"[INFO] {stale_count} task(s) marked IN_PROGRESS(stale) — confirm with team whether these are blocked or abandoned")

    if errors > 0:
        return fail(f"{SCHEMA_NAME} validation FAILED: {errors} error(s), {warnings} warning(s)")
    msg = f"{SCHEMA_NAME} validation passed: {len(rows)} rows, {warnings} warning(s)"
    if stale_count:
        msg += f", {stale_count} stale task(s)"
    return ok(msg)

if __name__ == '__main__':
    raise SystemExit(main())
