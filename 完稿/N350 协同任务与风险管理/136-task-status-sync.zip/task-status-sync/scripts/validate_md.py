#!/usr/bin/env python3
"""validate_md.py for skill #136 task-status-sync (n350-coordination-v1.1.1)

Validates Markdown artifacts (change summaries, status reports).
For CSV validation, use validate_csv.py.

Usage:
    python scripts/validate_md.py <output.md> [--strict]
"""
import re, sys
from pathlib import Path

SCHEMA = "n350-coordination-v1.1.1 / #136 task-status-sync"
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}
DELTA_SUBBLOCKS = ["new_done", "newly_blocked", "stale", "status_changed", "unchanged"]

REQUIRED_HEADINGS = [
    ("metadata",           re.compile(r"##\s*\d*\.?\s*Metadata|^```yaml[\s\S]*?\bmetadata:\b", re.I | re.MULTILINE)),
    ("change_summary",     re.compile(r"##\s*\d*\.?\s*(Change [Ss]ummary|变更摘要)", re.I)),
    ("downstream_handoff", re.compile(r"##\s*\d*\.?\s*(Downstream [Hh]andoff|下游交接)", re.I)),
]


def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0


def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_md.py <output.md> [--strict]"); return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists(): return fail(f"file not found: {path}")
    text = path.read_text(encoding="utf-8")
    errors = 0; warnings = 0

    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    if _is_example and _has_any_heading:
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness '{_rm.group(1)}' not in {VALID_READINESS}"); return 1
        return ok(f"{SCHEMA} example validation passed (light-check mode)")

    found = {}
    for key, pat in REQUIRED_HEADINGS:
        m = pat.search(text)
        if m: found[key] = m.start()
        else:
            # change_summary is only required in delta mode
            if key == "change_summary":
                if re.search(r"selected_mode[:\s]+delta", text):
                    print(f"[FAIL] delta mode missing change_summary section"); errors += 1
                else:
                    warn(f"no change_summary section — OK if not delta mode"); warnings += 1
            else:
                print(f"[FAIL] missing section: {key}"); errors += 1

    # AP-3: delta mode must have all 5 sub-blocks in change_summary
    if "change_summary" in found and re.search(r"selected_mode[:\s]+delta", text):
        cs_pos = found["change_summary"]
        next_h = re.search(r'\n## ', text[cs_pos+10:])
        snippet = text[cs_pos:cs_pos + (next_h.start() + 10 if next_h else 1000)]
        missing_blocks = [b for b in DELTA_SUBBLOCKS if b not in snippet]
        if missing_blocks:
            print(f"[FAIL] delta mode change_summary missing sub-blocks: {missing_blocks}")
            errors += 1

    # Downstream handoff fields
    if "downstream_handoff" in found:
        snippet = text[found["downstream_handoff"]:found["downstream_handoff"]+500]
        if "blocked_task_ids" not in snippet:
            warn("downstream_handoff missing blocked_task_ids → #137"); warnings += 1
        if "readiness" not in snippet:
            print("[FAIL] downstream_handoff missing readiness field"); errors += 1

    rm = re.search(r"readiness:\s*([\w]+)", text)
    if rm and rm.group(1) not in VALID_READINESS:
        print(f"[FAIL] readiness '{rm.group(1)}' not in {VALID_READINESS}"); errors += 1

    if errors > 0: return fail(f"{SCHEMA} FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} passed — {warnings} warning(s)")


if __name__ == "__main__":
    raise SystemExit(main())
