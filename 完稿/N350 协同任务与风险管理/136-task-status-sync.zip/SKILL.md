---
name: task-status-sync
description: consolidate scattered updates into a task status snapshot for n350 coordination. use when chatgpt needs to map work into todo, in_progress, done, or blocked, output rfc4180 csv or a concise sync note, preserve evidence, keep stable task ids, and keep list fields pipe-separated for downstream n360 or n370 consumption.
---

# 任务状态同步

## N350 v1.1.0 contract baseline
- contract_version: `n350-coordination-v1.1.0`
- workflow_node: `N350`
- skill_id: `136`
- artifact_target: `任务状态快照.csv / task_status_snapshot.csv`
- csv_schema: `n350.task-status-sync.v2`
- composition_role: `task_state_refresher`

This skill is self-contained. It can be used alone with minimum viable input, and it composes with sibling N350 skills through stable row IDs, `csv_schema`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Apply these bundled references when structured output or downstream consumption is needed:
- `references/n350-shared-coordination-contract.md`
- `references/output-contract.yaml`
- `references/csv-schema.md`
- `references/task-status-sync-quality-checklist.md`


把分散在会议纪要、任务列表、周报、聊天记录、状态更新里的信息，压缩成 **可追踪、可增量刷新** 的任务状态快照。

先阅读：
- `references/n350-contracts.md`
- `references/n350-shared-coordination-contract.md`
- `references/output-contract.yaml`
- `references/csv-schema.md`

## 优先模式
先判断是否存在“旧台账 + 新状态”：
- 有 → 走 **delta mode**，保留原 `id`，只更新变化字段，并补一段变更摘要。
- 没有 → 走 **snapshot mode**，生成当前完整快照。

## 状态判定规则
仅使用以下枚举：`TODO` / `IN_PROGRESS` / `DONE` / `BLOCKED`

- `TODO`：没有可靠证据显示已启动。
- `IN_PROGRESS`：有可靠证据显示已开始，但未完成，也未被当前 blocker 卡住。
- `DONE`：有明确完成证据。
- `BLOCKED`：有明确证据显示当前进度被 blocker 卡住。

不要因为主观判断就把任务升级为 `DONE` 或 `BLOCKED`。

## 工作流
1. 先抽取任务 id / 标题 / owner / 当前更新证据。
2. 把原始更新整理为“事实、推断、待核对”三层；状态只基于事实落位。
3. 若用户给了旧快照，优先在原快照上更新，不重新发明 `id`。
4. 对每条任务补上下一步、阻塞引用和最近更新时间。
5. 如果信息不足，保持最保守且有依据的状态，并把不确定性写入 `progress_summary`。

## 默认契约模式（推荐）
当结果需要被继续消费时，输出：

- schema: `n350.task-status-sync.v2`
- exact columns:
  `id,title,owner,status,progress_summary,blocker_refs,dependency_refs,next_step,deadline,last_update,evidence_ref`

规则：
- `blocker_refs`、`dependency_refs`、`evidence_ref` 多值统一用 `|`
- `last_update` 尽量保留原文中的日期或时间戳
- `progress_summary` 先写事实，再写不足，不做优先级排序
- 不要在这个 skill 里偷偷做 scope trim、技术方案、测试分析

## 何时输出 markdown
用户只要“周会简报 / 口头同步摘要 / 快速查看”时，可以输出 markdown；但仍然要保持上述状态枚举和字段语义。

## 严格边界
- 不重排优先级。
- 不替代 blocker/risk skill 做正式分类，只引用或标注现有 blocker / risk。
- 不输出专业需求、技术、测试、发布细节。

## 质量检查
在完成前确认：
- 每条状态更新都能找到证据。
- `DONE` 与 `BLOCKED` 没有被滥用。
- 若用户给了旧快照，`id` 没有无故漂移。
- 若输出 CSV，遵守 `references/csv-schema.md`，必要时可运行 `scripts/validate_csv.py`。
