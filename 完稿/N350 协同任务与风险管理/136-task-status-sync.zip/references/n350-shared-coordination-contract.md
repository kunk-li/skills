# N350 Shared Coordination Contract

## Contract version
`n350-coordination-v1.1.0`

## Node scope
N350 turns action items, task registers, status updates, blockers, and risk signals into a coordinated execution control plane. The node contains four standalone CSV-first skills that become stronger when joined through stable row IDs, CSV schemas, evidence references, cross-artifact references, and downstream handoffs.

## Encapsulation governance
Each N350 skill is self-contained. Shared rules, output contracts, CSV schemas, validators, examples, and quality checklists are packaged inside each skill. Do not rely on external node-level directories, external registries, or hidden matrices.

## Release consistency rule
A valid N350 release keeps the same `contract_version` in every `SKILL.md`, every `references/output-contract.yaml`, and every local copy of this shared contract. The four skill-local copies of this file must remain byte-identical before packaging.

## Shared metadata schema
N350 is CSV-first. Keep CSV bodies RFC-4180 compatible and put metadata in a companion block or companion file named `<artifact>.metadata.yaml` when downstream consumption is expected.

```yaml
metadata:
  contract_version: n350-coordination-v1.1.0
  workflow_node: N350
  skill_id: 135 | 136 | 137 | 138
  skill_name: task-initiation | task-status-sync | blocker-extraction | risk-item-extraction
  artifact_family_id: n350-task-risk-coordination-suite
  artifact_id: string
  csv_schema: n350.task-initiation.v2 | n350.task-status-sync.v2 | n350.blocker-extraction.v2 | n350.risk-item-extraction.v2
  selected_mode: string
  readiness: draft | partial | ready | blocked
  source_time_window:
    start: iso8601 | unknown
    end: iso8601 | unknown
    timezone: string
  project_scope: string | unknown
  team_scope: [string]
  sprint_or_release: string | unknown
  source_artifacts: [string]
  upstream_id_aliases: [string]
  evidence_refs: [artifact_evidence_ref]
  cross_artifact_refs: [string]
  pending_clarifications: [string]
  open_blockers: [string]
  owner_placeholders: [string]
  confidentiality_level: public_internal | restricted_internal | confidential
  confidence: high | medium | low
  composition_role: string
  function_bias: string
  stage_position: execution_governance.task_coordination.<sub-stage>
  artifact_target: string
  freshness:
    as_of_date: iso8601 | unknown
    source_commit: string | null
    expected_review_window: string
```

## Metadata enums
- `readiness`: `draft`, `partial`, `ready`, or `blocked`.
- `confidence`: `high`, `medium`, or `low`, based on evidence quality.
- `confidentiality_level`: use `public_internal` for ordinary internal coordination, `restricted_internal` for incident-, customer-, vendor-, security-, or personnel-sensitive signals, and `confidential` only when required by the user or source.
- `owner_placeholders`: use role/team names or `待确认`; never invent named people.

## Artifact id and row id rules
| skill_id | skill | artifact_id format | row id format | artifact_target | composition_role |
|---|---|---|---|---|---|
| 135 | task-initiation | `TASK-LIST-<project_id>-<yyyyww>` | `TASK-<project_id>-<nn>` | 任务清单.csv | task_register_creator |
| 136 | task-status-sync | `STATUS-<project_id>-<yyyyww>` | reuse `TASK-*` | 任务状态快照.csv | task_state_refresher |
| 137 | blocker-extraction | `BLK-REG-<project_id>-<yyyyww>` | `BLK-<project_id>-<nn>` | 阻塞项台账.csv | active_impediment_classifier |
| 138 | risk-item-extraction | `RISK-REG-<project_id>-<yyyyww>` | `RISK-<project_id>-<nn>` | 风险台账.csv | future_delivery_risk_scorer |

Fallback artifact IDs use `TEMP-N350-<date>-<source>` and must appear in `pending_clarifications`. Preserve upstream IDs instead of renaming them.

## CSV schema governance
N350 uses two version tracks:
- `contract_version` governs node-level protocol: metadata, handoff, composition, examples, and shared behavior.
- `csv_schema` governs skill-specific CSV columns and validator behavior, for example `n350.task-initiation.v2`.

Do not change CSV columns without bumping the relevant `csv_schema`. Do not change node-wide metadata or handoff rules without bumping `contract_version`.

## Upstream ID alias rules
Preserve upstream IDs exactly. Put N340 `ACT-*`, N320 `incident_id` or `timeline_anchor_ref`, N330 `DOC-*`, N310 response IDs, issue IDs, chat links, meeting IDs, and external tracker IDs into `upstream_id_aliases` and cite them in `evidence_refs` when they support a row.

## Evidence reference schema
```yaml
artifact_evidence_ref:
  ref_id: string
  source_family: action_item | meeting | status_update | task_log | doc | incident | chat | ticket | manual_note | external_system
  source_name: string
  time_window_or_version: string
  scope: [string]
  upstream_id_aliases: [string]
  excerpt_or_pointer: string
  confidence: high | medium | low
  layer: confirmed_fact | bounded_inference | open_question
```

## Cross-artifact join keys
- `artifact_id`: identifies a whole N350 artifact.
- `TASK-*`, `BLK-*`, and `RISK-*`: connect rows across N350 skills.
- `cross_artifact_refs`: sibling or upstream artifact IDs, never local file paths.
- `evidence_refs.ref_id`: reusable evidence pointers.
- skill-specific join fields: `parent_ref`, `blocker_refs`, `dependency_refs`, `affected_task_ids`, and `related_blocker_ids`.

## Standard composition paths
1. **Task-bootstrap**: N340 `ACT-*` -> 135 task-initiation -> 136 task-status-sync.
2. **Weekly-coordination**: 136 task-status-sync -> 137 blocker-extraction -> 138 risk-item-extraction -> N360.
3. **Incident-followup**: N320 postmortem or N340 best practice -> 135 task-initiation -> 136 task-status-sync.
4. **Scope-trim**: 138 risk-item-extraction with `scope_trim_candidate=YES` -> N360 scope alignment.
5. **Standalone fallback**: any skill can run with minimum viable input and emit `readiness: partial` when evidence is incomplete.

## Standalone guarantee
- Each skill can run without sibling artifacts.
- Preserve missing values as `待确认` or `待核对` instead of fabricating.
- Emit valid CSV columns when structured output is requested.
- If Markdown is requested, preserve the same field semantics and include metadata and handoff blocks when useful.
- Old registers trigger delta mode by default; preserve existing IDs.
- Always state evidence gaps and confidence.

## Composition guarantee
- 135 owns initial executable task rows and `TASK-*` creation.
- 136 owns conservative status transitions for existing `TASK-*` rows.
- 137 owns active blockers, `BLK-*` rows, and escalation paths.
- 138 owns risk scoring, `RISK-*` rows, mitigation, and scope-trim candidates.
- 136 references `BLK-*` and `RISK-*` rather than reclassifying them when sibling artifacts exist.
- 137 sends future concerns to 138 rather than labeling them as current blockers.
- 138 links related blockers through `related_blocker_ids` rather than duplicating blocker rows.

## Downstream handoff schema
```yaml
downstream_handoff:
  contract_version: n350-coordination-v1.1.0
  handoff_id: HO-N350-<artifact_id>-<seq>
  producer_skill: task-initiation | task-status-sync | blocker-extraction | risk-item-extraction
  consumer_skill_or_node: task-initiation | task-status-sync | blocker-extraction | risk-item-extraction | N340 | N360 | N370 | N380 | knowledge_base
  artifact_family_id: n350-task-risk-coordination-suite
  artifact_id: string
  artifact_target: string
  required_fields: [string]
  cross_artifact_refs: [string]
  pending_clarifications: [string]
  readiness: draft | partial | ready | blocked
  confidence: high | medium | low
  next_best_checks: [string]
```

## Common execution workflow
1. Identify the artifact type and selected mode.
2. Separate confirmed facts, bounded inferences, and open questions.
3. Preserve stable IDs from old registers and upstream artifacts.
4. Apply the skill-specific CSV schema or Markdown equivalent.
5. Populate metadata, `csv_schema`, and evidence references when downstream consumption is likely.
6. Use `待确认` or `待核对` for missing required information.
7. Emit downstream handoff with next best checks.
8. Run the skill-specific quality checklist and, when CSV is produced, the bundled `scripts/validate_csv.py`.

## Common input handling
- Old register plus new signal -> delta update.
- No old register -> fresh register or snapshot.
- Mixed meeting, chat, doc, ticket, and tracker input -> cite each source separately in `evidence_refs`.
- Conflicting updates -> keep the most recent explicit evidence and write the conflict in `pending_clarifications`.

## Common self-check
1. `contract_version` is consistent across SKILL.md, output contract, and shared contract.
2. `csv_schema` is declared and matches the skill-specific schema file.
3. `selected_mode` is declared and matches the artifact.
4. Existing IDs are preserved unless a merge explanation is given.
5. CSV columns match `references/csv-schema.md` exactly when CSV is requested.
6. Multi-value fields use `|`, not bare commas.
7. Evidence references exist for high-impact rows.
8. Owner placeholders use role/team or `待确认` only.
9. Blockers and risks are not mixed.
10. Handoff contains handoff_id, consumer, required fields, readiness, and next checks.
11. Output aligns with the closest example; differences are intentional.

## Tone and content rules
- Be concise, execution-oriented, and evidence-grounded.
- Do not operate external task systems; produce importable or reviewable artifacts only.
- Do not fabricate owners, deadlines, scores, completion evidence, or commitments.
- Keep blocker and risk language blame-free and action-oriented.
