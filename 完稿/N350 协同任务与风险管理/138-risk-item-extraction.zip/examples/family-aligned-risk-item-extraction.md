# Risk Item Extraction Example - blocker to delivery risk register

```yaml
metadata:
  contract_version: n350-coordination-v1.1.0
  workflow_node: N350
  skill_id: 138
  skill_name: risk-item-extraction
  artifact_family_id: n350-task-risk-coordination-suite
  artifact_id: RISK-REG-platform-202619
  csv_schema: n350.risk-item-extraction.v2
  selected_mode: blocker_to_risk_review
  readiness: ready
  source_time_window: {start: 2026-05-07, end: 2026-05-07, timezone: Asia/Tokyo}
  project_scope: platform
  team_scope: [platform, backend, qa]
  sprint_or_release: 2026-W19
  source_artifacts: [BLK-REG-platform-202619, STATUS-platform-202619]
  upstream_id_aliases: [ACT-platform-202619-01, TASK-platform-02, BLK-platform-01]
  evidence_refs:
    - {ref_id: EV-N350-RISK-001, source_family: status_update, source_name: BLK-REG-platform-202619, time_window_or_version: 2026-W19, scope: [platform], upstream_id_aliases: [BLK-platform-01], excerpt_or_pointer: blocker remains OPEN and affects QA regression, confidence: high, layer: confirmed_fact}
  cross_artifact_refs: [BLK-REG-platform-202619, STATUS-platform-202619, TASK-LIST-platform-202619]
  pending_clarifications: []
  open_blockers: [BLK-platform-01]
  owner_placeholders: [backend lead, qa owner]
  confidentiality_level: public_internal
  confidence: high
  composition_role: future_delivery_risk_scorer
  function_bias: score_future_risks_and_suggest_mitigation
  stage_position: execution_governance.task_coordination.risk-item-extraction
  artifact_target: 风险台账.csv
  freshness: {as_of_date: 2026-05-07, source_commit: null, expected_review_window: weekly}
```

```csv
risk_id,title,category,likelihood,impact,risk_score,affected_scope,trigger_signal,mitigation,mitigation_owner,mitigation_due,evidence_ref,scope_trim_candidate,related_blocker_ids
RISK-platform-01,API 文档入口延期可能压缩回归窗口,schedule,3,4,12,platform release|qa regression,BLK-platform-01 仍为 OPEN,若 2026-05-10 前未解阻则将低优先级 FAQ 更新移出本周版本,release owner,2026-05-10,EV-N350-RISK-001,YES,BLK-platform-01
```
