---
name: risk-item-extraction
description: extract project risks that may happen in the future and recommend mitigations in n350 coordination. use when chatgpt should score likelihood and impact on a 1-5 scale, calculate risk_score, distinguish risks from current blockers, highlight scope-trim candidates for downstream alignment, preserve stable risk ids, and output structured risk registers grounded in provided material.
---

# 风险项提取

## N350 v1.1.0 contract baseline
- contract_version: `n350-coordination-v1.1.0`
- workflow_node: `N350`
- skill_id: `138`
- artifact_target: `风险台账.csv / risk_register.csv`
- csv_schema: `n350.risk-item-extraction.v2`
- composition_role: `future_delivery_risk_scorer`

This skill is self-contained. It can be used alone with minimum viable input, and it composes with sibling N350 skills through stable row IDs, `csv_schema`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Apply these bundled references when structured output or downstream consumption is needed:
- `references/n350-shared-coordination-contract.md`
- `references/output-contract.yaml`
- `references/csv-schema.md`
- `references/risk-item-extraction-quality-checklist.md`


识别 **尚未发生但可能影响交付、范围、质量、依赖或版本节奏** 的风险，并输出可执行的缓解建议。

先阅读：
- `references/n350-contracts.md`
- `references/n350-shared-coordination-contract.md`
- `references/output-contract.yaml`
- `references/csv-schema.md`
- `references/risk-scoring.md`

## 先判断 risk 还是 blocker
- **risk**：未来可能发生，当前仍是预判或前兆。
- **blocker**：已经发生并正在阻塞进度。

如果材料明确显示问题已经在当前周期卡住执行，应转交 blocker-extraction，而不是留在风险台账里。

## 优先模式
- 有旧风险台账 + 新信号 → **delta mode**，保留 `risk_id`，更新分数、触发信号和 mitigation。
- 没有旧台账 → **fresh register**。

## 工作流
1. 先抽取风险陈述、前兆信号、受影响范围和已有证据。
2. 按 `references/risk-scoring.md` 给出 `likelihood`、`impact`、`risk_score`。
3. 只在输入支持时写具体缓解动作；缺责任人或时间时写 `待确认`，不要用空泛口号代替。
4. 判断是否需要给 N360 / 版本裁剪提供提示：高分风险应明确 `scope_trim_candidate`。
5. 若输入中已有关联 blocker，保留到 `related_blocker_ids`，便于上下游串联。

## 默认契约模式（推荐）
当结果需要结构化沉淀或下游消费时，输出：

- schema: `n350.risk-item-extraction.v2`
- exact columns:
  `risk_id,title,category,likelihood,impact,risk_score,affected_scope,trigger_signal,mitigation,mitigation_owner,mitigation_due,evidence_ref,scope_trim_candidate,related_blocker_ids`

规则：
- `likelihood`、`impact` 用 `1-5` 整数
- `risk_score = likelihood × impact`
- `affected_scope`、`evidence_ref`、`related_blocker_ids` 多值统一用 `|`
- `scope_trim_candidate` 仅用 `YES` / `NO`
- 输出前按 `risk_score` 从高到低排序；分数相同再按 `impact` 从高到低排

## 分类枚举
`category` 仅用：`schedule` / `resource` / `dependency` / `technical` / `quality` / `security` / `compliance` / `external` / `other`

## 何时输出 markdown
用户只要“风险盘点摘要”或“风险评审纪要”时，可以输出 markdown；但仍要保留评分、证据、mitigation 和 scope trim 提示。

## 严格边界
- 不把已发生的当前阻塞留在 risk 里冒充预测。
- 不输出脱离证据的风险故事。
- 不直接替用户做版本裁剪结论；这里只给 `scope_trim_candidate` 和理由。

## 质量检查
在完成前确认：
- `risk_score` 计算正确。
- mitigation 尽量包含动作、责任、时间或触发条件。
- 高风险项是否需要 scope trim 已被显式标记。
- 若输出 CSV，遵守 `references/csv-schema.md`，必要时可运行 `scripts/validate_csv.py`。
