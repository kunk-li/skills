# 风险项提取 Quality Checklist

Use this checklist before returning an N350 artifact.

1. Metadata contains all required shared fields when structured output is expected.
2. `contract_version` and `csv_schema` match the current skill and release.
3. `selected_mode` matches the actual update path.
4. Stable IDs follow artifact and row ID formats; old IDs are preserved in delta mode.
5. CSV output uses the exact column order from `references/csv-schema.md`.
6. Multi-value CSV fields use `|`, not bare commas.
7. Evidence references identify source family, source name, pointer, confidence, and layer.
8. Missing owner, deadline, evidence, score, or decision is marked `待确认` or `待核对`.
9. `cross_artifact_refs` use artifact or row IDs, not local file paths.
10. `downstream_handoff` includes handoff_id, consumer, required_fields, readiness, confidence, and next_best_checks.
11. Compare the output against the closest file under `examples/`; differences are allowed but should be intentional.

## Skill-specific checks
- risk_score equals likelihood times impact.
- Do not leave current blockers in risk register.
- scope_trim_candidate is YES or NO.
- Mitigation includes action, owner role, and due date or 待确认.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- Every risk has `mitigation` with all 3 elements (trigger condition + specific action + target outcome).
- `risk_score = likelihood × impact` is mathematically verified before output.
- `## 风险优先级解读` block always present at end of output; empty if no high-risk items.
- `scope_trim_candidate` is YES or NO for every row — never blank.

## Output structure completeness checks
- All 5 mandatory sections present per mandatory section table
- validate_csv.py passes; `risk_score = likelihood × impact` verified
- `## 风险优先级解读` present; "当前无高优先级风险" if none

## Mode-specific checks

### pre_release_risk_sweep mode
- Every item in release scope has ≥1 risk assessment
- `scope_trim_candidate` populated for all items; YES entries go to downstream_handoff

### scope_trim_trigger_review mode
- Only evaluates existing risks with scope_trim_candidate=YES
- Provides #141 trigger recommendation for each qualifying risk
