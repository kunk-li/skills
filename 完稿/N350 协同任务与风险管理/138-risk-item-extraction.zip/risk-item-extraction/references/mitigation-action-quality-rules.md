# Mitigation Action Quality Rules

Use this reference when writing `mitigation` for any risk entry.

## The three-element requirement
Every `mitigation` must contain all three elements:

| Element | What it answers | Example |
|---------|-----------------|---------|
| **Trigger condition** (触发条件) | What signal activates this mitigation? | "若 2025-06-20 前未收到第三方 API 文档", "若压测结果 TPS < 500" |
| **Specific action** (具体动作) | What exactly happens? Who does it? | "PM 启动备用方案评估（内部 mock + 适配层），由 backend-team 实施" |
| **Target** (目标) | What does this mitigation achieve? Quantify if possible. | "将 likelihood 从 4 降至 2", "确保发版日期不受影响", "将影响范围限制在单一模块" |

## Rejected phrases
| Rejected | Rewrite as |
|---------|-----------|
| "加强与第三方的沟通" | "若 2025-06-20 前无回复，PM 升级至合作方 BD 负责人，并启动内部 mock 方案，目标：联调不因外部依赖延期" |
| "持续监控" | "配置 P99 延迟告警（阈值 500ms），若触发，SRE 在 30 分钟内介入扩容，目标：将 likelihood 从 3 降至 1" |
| "提前准备" | "在 2025-06-10 前完成备用数据库环境搭建，若主库出现问题可在 15 分钟内切换" |
| "评估替代方案" | "在 2025-06-15 前完成方案 A vs 方案 B 的技术对比文档，由 TL 决策；若方案 A 风险过高，切换至方案 B，timeline 不变" |

## Risk priority output block format
The `## 风险优先级解读` block must appear after the CSV output and follow this structure:

```markdown
## 风险优先级解读

### 高危风险（risk_score ≥ 15）
| risk_id | title | score | 触发信号 | 建议行动 |
|---------|-------|-------|---------|---------|
| RISK-003 | 外部 API 文档延期 | 20 | 2025-06-20 前无回复 | 启动内部 mock；升级合作方 BD |
| RISK-007 | 性能压测未达标 | 16 | TPS < 500 | 提前扩容评估；考虑范围裁剪 |

### 版本裁剪候选（scope_trim_candidate = YES）
| risk_id | title | 裁剪理由 |
|---------|-------|--------|
| RISK-003 | 外部 API 文档延期 | 依赖方不可控，风险无法在版本内完全消除 |

### 综合建议
[若高危风险 ≥ 3 个，建议启动 N360 版本裁剪评估]
[若所有风险均已有具体 mitigation，说明当前风险可控]
```

## scope_trim_candidate decision rules
Mark `scope_trim_candidate: YES` when ANY of these is true:
1. `risk_score >= 15`
2. The risk's `mitigation_due` is beyond the version release date
3. The risk involves an external dependency with no internal workaround
4. Prior version had the same risk and it caused a delay

Mark `scope_trim_candidate: NO` when:
- Mitigation is concrete, owned, and within the version window
- Risk impact is limited to a non-critical feature
- Risk has already been accepted by PM with explicit sign-off
