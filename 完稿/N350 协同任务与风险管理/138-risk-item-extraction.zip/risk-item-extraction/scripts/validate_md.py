#!/usr/bin/env python3
"""validate_md.py for skill #138 risk-item-extraction (n350-coordination-v1.1.1)

Validates Markdown risk analysis reports. For CSV validation, use validate_csv.py.

Usage:
    python scripts/validate_md.py <output.md> [--strict]
"""
import re, sys
from pathlib import Path

SCHEMA = "n350-coordination-v1.1.1 / #138 risk-item-extraction"
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}

REQUIRED_HEADINGS = [
    ("metadata",           re.compile(r"##\s*\d*\.?\s*Metadata|^```yaml[\s\S]*?\bmetadata:\b", re.I | re.MULTILINE)),
    ("risk_summary",       re.compile(r"##\s*\d*\.?\s*[^\n]*?(Risk [Ss]ummary|风险.*解读|Risk.*Priority)", re.I)),
    ("downstream_handoff", re.compile(r"##\s*\d*\.?\s*[^\n]*?(Downstream [Hh]andoff|下游交接)", re.I)),
]


def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0


def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_md.py <output.md> [--strict]"); return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists(): return fail(f"file not found: {path}")
    text = path.read_text(encoding="utf-8")
    errors = 0; warnings = 0

    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    if _is_example and _has_any_heading:
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness '{_rm.group(1)}' not in {VALID_READINESS}"); return 1
        return ok(f"{SCHEMA} example validation passed (light-check mode)")

    found = {}
    for key, pat in REQUIRED_HEADINGS:
        m = pat.search(text)
        if m: found[key] = m.start()
        else:
            if key == "risk_summary" and not re.search(r"selected_mode[:\s]+pre_release", text):
                warn(f"no risk_summary section — only required in pre_release_risk_sweep mode"); warnings += 1
            else:
                print(f"[FAIL] missing section: {key}"); errors += 1

    # AP-2: mitigation three-element check
    mitigations = re.findall(r"mitigation[:\s]+([^\n|]{10,})", text)
    for m_text in mitigations:
        if len(m_text.strip()) < 20:
            warn(f"mitigation may be too brief (< 20 chars): {m_text.strip()[:40]}"); warnings += 1

    # Downstream: scope_trim_candidates for YES items
    if "scope_trim_candidate" in text and "YES" in text:
        if "downstream_handoff" in found:
            snippet = text[found["downstream_handoff"]:found["downstream_handoff"]+600]
            if "scope_trim_candidates" not in snippet:
                print("[FAIL] scope_trim_candidate=YES found but downstream_handoff missing scope_trim_candidates")
                errors += 1

    if "downstream_handoff" in found:
        snippet = text[found["downstream_handoff"]:found["downstream_handoff"]+500]
        if "readiness" not in snippet:
            print("[FAIL] downstream_handoff missing readiness field"); errors += 1

    rm = re.search(r"readiness:\s*([\w]+)", text)
    if rm and rm.group(1) not in VALID_READINESS:
        print(f"[FAIL] readiness '{rm.group(1)}' not in {VALID_READINESS}"); errors += 1

    if errors > 0: return fail(f"{SCHEMA} FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} passed — {warnings} warning(s)")


if __name__ == "__main__":
    raise SystemExit(main())
