# Example: Risk Item Extraction — Pre-Release Risk Sweep

## Metadata

```yaml
artifact_id: RISK-PRE-RELEASE-001
skill_id: 138
contract_version: n350-coordination-v1.1.1
selected_mode: pre_release_risk_sweep
source_snapshot_ids: [TASK-STATUS-SPARSE-001, BLK-PENDING-001]
release_target: "v2.3.0"
release_date: "2025-07-04"
readiness: complete
```

## Risk Register CSV

| risk_id | title | likelihood | impact | risk_score | status | scope_trim_candidate | mitigation | trigger_condition | specific_action | target_effect |
|---------|-------|:----------:|:------:|:----------:|--------|:--------------------:|-----------|------------------|----------------|---------------|
| RISK-001 | 测试环境 W24 仍不可用，压测无法完成 | 3 | 4 | 12 | OPEN | NO | 若 W24 仍不可用 | 申请备用云环境完成最低限度压测（30 并发） | 压测延迟从 3 天缩短至 1 天内 |
| RISK-002 | 数据迁移脚本质量不明，可能拖延发版 | 4 | 5 | 20 | OPEN | YES | DBA 确认阻塞后立即触发 | 启动 scope_trim 评估，将数据迁移推迟至 v2.3.1 | 保护 v2.3.0 发版日期不受影响 |
| RISK-003 | 前端联调未启动，集成测试窗口压缩 | 2 | 3 | 6 | OPEN | NO | 联调延迟超过 2 天 | 前端团队优先释放 1 名工程师提前介入联调 | 联调窗口从 3 天扩展至 5 天 |

**算术验证（validate_csv.py 输出）：**
- RISK-001: 3 × 4 = 12 ✅
- RISK-002: 4 × 5 = 20 ✅ → scope_trim_candidate=YES（阈值 ≥ 15）
- RISK-003: 2 × 3 = 6 ✅

## 风险优先级解读

| 优先级 | Risk ID | risk_score | 建议行动 |
|:------:|---------|:----------:|---------|
| 🔴 P0 | RISK-002 | 20 | 立即确认 DBA 状态，触发 scope_trim 评估 → N360 #141 |
| 🟡 P1 | RISK-001 | 12 | W24 末确认，备用方案已准备 |
| 🟢 P2 | RISK-003 | 6 | 持续观测，联调启动后复评 |

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: N360/version-scope-trimming-recommendation
  scope_trim_candidates:
    - risk_id: RISK-002
      risk_score: 20
      scope_trim_candidate: YES
      mitigation_status: proposed
      title: 数据迁移脚本质量不明
  related_blocker_ids: [BLK-001, BLK-002]
  readiness: complete
```
