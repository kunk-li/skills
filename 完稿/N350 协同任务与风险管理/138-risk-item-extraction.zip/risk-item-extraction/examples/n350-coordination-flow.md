# Example: N350 Cross-Skill Coordination Flow

Shows #135 → #136 → #137 → #138 pipeline for Platform v2.3 Sprint 23.

---

## Step 1 — #135 Task Initiation

**Input**: Sprint 23 planning + postmortem action items  
**Artifact**: `TASK-REG-S23`

```csv
id,title,owner,priority,status,deadline,dependencies,success_criteria,evidence_ref,parent_ref
T-031,支付模块后端 API 实现,backend-team,P1,IN_PROGRESS,2025-06-13,,代码 review 通过，单测覆盖率≥80%,meeting:S23-planning#action:1,
T-032,支付模块 QA 回归,qa-team,P1,TODO,2025-06-17,T-031,Staging 无 P0/P1 缺陷，TPS≥500,,T-031
T-033,Redis warm-up 集成到 CD pipeline,platform-team,P1,TODO,2025-07-01,,连续 3 次含缓存变更的 deploy 零 503,postmortem:PM-INC-2025-0612#AI-001-001,
T-034,OAuth callback spec v1 草稿交付,backend-lead,P0,TODO,2025-06-30,,ABC 集成团队书面确认收到并可用,meeting:arch-sync-0610#action:2,
```

**Splitting rule applied**: "完成支付模块开发和测试" split into T-031 + T-032 (different owners, blocking relationship).

---

## Step 2 — #136 Task Status Sync (delta mode, W24 update)

**Input**: `TASK-REG-S23` + week's progress  
**Artifact**: `STATUS-S23-W24`

```csv
id,title,owner,status,progress_summary,blocker_refs,dependency_refs,next_step,deadline,last_update,evidence_ref
T-031,支付模块后端 API 实现,backend-team,IN_PROGRESS,核心 CRUD 完成，支付回调逻辑开发中，预计明天完成,,T-034,完成回调逻辑，提交 PR,2025-06-13,2025-06-10,standup:2025-06-10
T-032,支付模块 QA 回归,qa-team,TODO,等待 T-031 完成，测试环境已准备,BLK-008,T-031,等待 T-031 PR 合入,2025-06-17,,
T-033,Redis warm-up 集成,platform-team,IN_PROGRESS(stale),上周已启动方案设计，本周无进展证据,,T-031,需确认是否阻塞,2025-07-01,,
T-034,OAuth callback spec v1,backend-lead,BLOCKED,等待 auth-team API spec 交付，当前无法开始,BLK-008,,等待 BLK-008 解阻,2025-06-30,2025-06-10,meeting:sync-0610
```

**变更摘要（相比上次快照，2025-06-03）**

- 状态变化: T-031 TODO → IN_PROGRESS（核心 CRUD 完成）
- 新增阻塞: T-034 BLOCKED（BLK-008：auth-team API spec 未交付）
- 新增: T-033 IN_PROGRESS(stale)（上周启动，本周无进展证据）
- ID 保留确认: T-031 ~ T-034 均保留，无漂移

---

## Step 3 — #137 Blocker Extraction

**Input**: `STATUS-S23-W24` blocked tasks  
**Artifact**: `BLOCKER-S23-W24`

```csv
blocker_id,title,affected_task_ids,blocker_type,severity,owner,evidence_ref,impact_summary,unblock_action,escalation_path,status
BLK-008,Auth-team OAuth callback spec 未交付,T-034|T-032,dependency,high,PM-role,meeting:sync-0610,T-034 无法开始；若 T-034 延期则 T-032 最晚开始日期为 2025-06-18，M3 联调有延期风险,"PM 在 2025-06-12 前通过 Slack #dev-sync 向 auth-team TL 发出书面请求，要求 spec v1 在 2025-06-14 17:00 前交付；若逾期，PM 升级至 EM 并抄送合作方 BD 负责人",N380|PM,OPEN
```

**Unblock action quality check**: ✅ Actor (PM-role) + Specific action (Slack + email) + Time target (2025-06-14 17:00) — all three elements present.

---

## Step 4 — #138 Risk Item Extraction

**Input**: `BLOCKER-S23-W24` + `STATUS-S23-W24` stale tasks  
**Artifact**: `RISK-S23-W24`

```csv
risk_id,title,category,likelihood,impact,risk_score,affected_scope,trigger_signal,mitigation,mitigation_owner,mitigation_due,evidence_ref,scope_trim_candidate,related_blocker_ids
RISK-007,Auth-team spec 延期导致联调推迟,dependency,4,4,16,M3联调|T-034|T-032,"若 2025-06-14 前未收到 spec","PM 在 2025-06-12 升级至 EM；若 2025-06-14 仍无 spec，ENG-lead 启动 mock-first 联调方案，目标：联调不因外部延期超过 3 天",PM-role|ENG-lead,2025-06-14,meeting:sync-0610,YES,BLK-008
RISK-008,Redis warm-up 集成停滞,technical,2,3,6,T-033 发版质量,"T-033 持续 stale 状态超过 2 周","platform-team TL 在 2025-06-12 站会确认 T-033 当前状态及阻塞原因，若已阻塞则转为 BLK-009",platform-team,2025-06-12,standup:2025-06-10,NO,
```

## 风险优先级解读

### 高危风险（risk_score ≥ 15）
| risk_id | title | score | 触发信号 | 建议行动 |
|---------|-------|-------|---------|--------|
| RISK-007 | Auth-team spec 延期 | 16 | 2025-06-14 前无 spec | 升级 EM；启动 mock-first 方案 |

### 版本裁剪候选（scope_trim_candidate = YES）
| risk_id | title | 裁剪理由 |
|---------|-------|--------|
| RISK-007 | Auth-team spec 延期 | 外部依赖不可控，mitigation 边界在 ENG-lead mock 方案，若不可行则 T-034 范围需裁剪 |

### 综合建议
当前版本 1 个高危风险（score=16），建议与 PM 确认是否触发 N360 skill #141 `emergency_trim` 评估（发版 T-14 天）。

---

## Coordination Summary

```
Sprint 23 planning
      ↓ #135 (task-initiation, full draft)
TASK-REG-S23  ──→  T-031~T-034, splitting applied, criteria validated
      ↓ week delta ↓ #136 (delta_mode)
STATUS-S23-W24  ──→  BLK-008 surfaced, T-033 stale identified
      ↓ #137 (blocker-extraction)
BLOCKER-S23-W24  ──→  BLK-008 unblock_action: 3 elements complete
      ↓ #138 (risk-item-extraction)
RISK-S23-W24  ──→  RISK-007 score=16, scope_trim=YES → N360 #141 triggered
```

## Downstream Handoff

```yaml
handoff_id: RISK-HANDOFF-S23-W24
producer_skill: risk-item-extraction
consumer_skill_or_node: N360|release-owner
cross_artifact_refs:
  - artifact_id: TASK-REG-S23
    producer_skill: task-initiation
    consumed_fields: [task_ids, dependencies]
  - artifact_id: STATUS-S23-W24
    producer_skill: task-status-sync
    consumed_fields: [blocked_task_ids, stale_task_ids]
  - artifact_id: BLOCKER-S23-W24
    producer_skill: blocker-extraction
    consumed_fields: [blocker_id, related_blocker_ids]
scope_trim_candidates: [RISK-007]
readiness: complete
confidence: high
next_best_checks:
  - "N360 #141: initiate emergency_trim assessment for RISK-007 (scope_trim_candidate=YES)"
  - "PM: confirm 2025-06-12 formal request to auth-team is sent"
  - "platform-team TL: clarify T-033 stale status in next standup"
```
