---
name: risk-item-extraction
description: Assess forward-looking delivery risks that may happen, compute risk scores (likelihood × impact), and flag scope-trim candidates for release review.
---

# 风险项提取

## N350 contract baseline (n350-coordination-v1.1.1)

- contract_version: `n350-coordination-v1.1.1`
- workflow_node: N350
- skill_id: 138
- artifact_target: `风险台账.csv / risk_register.csv`
- csv_schema: `n350.risk-item-extraction.v2`
- composition_role: `future_delivery_risk_scorer`
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through stable row IDs, `csv_schema`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

## Role

作为 N350 任务协同层的**风险项提取生成器**，识别可能影响交付的前瞻性风险并评估裁剪必要性。

具体职责：
- 明确区分 risk（未来可能）vs blocker（已经发生）— 前者进本 skill，后者进 #137
- `risk_score = likelihood × impact`，运行 validate_csv.py 数学验证
- 每条 `mitigation` 包含三要素：触发条件 + 具体动作 + 目标效果
- `scope_trim_candidate=YES` 的风险自动触发 N360 #141 评估

**不负责**：任务状态（→ #136）、阻塞识别（→ #137）、裁剪决策（→ #141）、合规审计（→ 专项合规流程）。

## When NOT to use this skill

- **Not a blocker register**: if the issue has already occurred and is actively blocking, route to #137 instead.
- **Not a task register**: #138 records risk items, not tasks; task extraction belongs in #135.
- **Not a release decision maker**: #138 identifies scope trim candidates; the trim decision belongs to N360 #141.
- **Not a compliance audit**: regulatory risk assessment belongs to dedicated compliance processes; #138 records operational and delivery risks.

## Risk vs blocker — classification matrix

> **This matrix is also present in #137 from the blocker perspective. Both skills are intentionally bidirectional so each can be used independently without consulting the other.**

| | 正在阻塞进度 | 尚未阻塞进度 |
|---|---|---|
| **已经发生** | ✅ Blocker → #137 | ⚠️ 有前兆 → #137 PENDING_CONFIRMATION 或 #138 |
| **尚未发生** | ❌ 不可能 | ✅ Risk → **#138 (本 skill)** |

**判断原则（从 risk 侧看）**:
- "这个问题还没发生，但如果发生会影响交付" → **#138 (Risk)**
- "这个问题今天才发生，但尚未实际卡住任何任务" → **#137 PENDING_CONFIRMATION**
- "问题已经卡住当前周期的执行" → **#137 (Blocker)**
- 如果你不确定，选 #137 PENDING_CONFIRMATION — blocker 可以降级为 risk，但不要把活跃 blocker 漏报为 risk

## Standalone and composition role

```yaml
standalone_goal: identify future delivery risks, score them, and flag scope_trim_candidates for N360 review
minimum_viable_input:
  any_of:
    - 阻塞项台账（来自 #137，含 open_blockers 信号）
    - 规划材料或依赖关系说明
    - 旧风险台账 + 新信号（delta 模式）
    - 发版计划或里程碑清单
    - 团队会议或周报中的风险前兆
partial_readiness_allowed: true
degradation_behavior: >
  If mitigation components are partially missing, write 待确认 for missing element.
  Do not invent likelihood/impact scores without evidence — use medium as conservative
  default and note uncertainty. scope_trim_candidate=YES only when risk_score ≥ threshold
  in references/risk-scoring.md.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `fresh_register`: 无旧台账 → 从输入材料识别并记录所有风险。
- `delta_update`: 有旧台账 + 新信号 → 保留 `risk_id`，更新 likelihood/impact/mitigation/trigger_signal。
- `scope_trim_trigger_review`: 专门针对 `scope_trim_candidate=YES` 的风险，评估是否触发 N360 #141。
- `pre_release_risk_sweep`: 发版前风险全扫描，输出 `## 风险优先级解读` 作为发版前 checklist。

**Default routing**: 无旧台账 → `fresh_register`; 有旧台账 → `delta_update`; 发版前 → `pre_release_risk_sweep`.

## Risk scoring

`risk_score = likelihood × impact`

- likelihood: 1–5 (1=极低, 5=极高)
- impact: 1–5 (1=极低影响, 5=业务停止)
- risk_score range: 1–25
- scope_trim_candidate=YES trigger: refer to `references/risk-scoring.md` for threshold

Run validate_csv.py to verify arithmetic consistency before output.

## Mitigation quality rules

Every `mitigation` must contain three elements:

| Element | Requirement | Anti-pattern |
|---------|-------------|--------------|
| Trigger condition | When to activate the mitigation | "有风险时" |
| Specific action | Concrete step | "制定计划" |
| Target effect | Expected risk reduction | "降低风险" |

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | Metadata | Always | artifact_id, selected_mode, source_snapshot_ids |
| 2 | 风险台账 CSV | Always | All columns; run validate_csv.py; verify risk_score arithmetic |
| 3 | 风险优先级解读 | Always in pre_release_risk_sweep; optional in other modes | High-risk items summary and recommended actions |
| 4 | Downstream handoff | Always | scope_trim_candidates passed to N360 #141; related_blocker_ids from #137 |

> Legend: Always = required in every mode.

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: N360/version-scope-trimming-recommendation
  scope_trim_candidates:
    - risk_id: RISK-*-001
      risk_score: 18
      scope_trim_candidate: YES
      mitigation_status: insufficient
  related_blocker_ids: [BLK-001]
  readiness: complete | partial | degraded
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** 把已经发生并正在卡住任务的问题记入风险台账 → 已发生阻塞归 #137；参考分类矩阵。量化检验：风险台账中，is_currently_blocking=true（或等价字段）的条目数必须 = 0；此类条目应路由到 #137。
- **AP-2** `mitigation` 缺少三要素之一 → 缺失元素写 `待确认`；不允许用"加强监控"等口号替代具体动作。量化检验：mitigation 字段中，trigger_condition/specific_action/target_effect 三要素任一缺失（或使用 `加强监控`/`持续关注` 等口号）的条目数 = open_blocker 数。
- **AP-3** `risk_score` 未经数学验证就输出 → 必须运行 validate_csv.py 验证 likelihood × impact = risk_score。量化检验：validate_csv.py 对每行执行 `abs(likelihood × impact - risk_score) > 0` 检测，不等于 0 的行数 = FAIL 数（允许浮点误差 ε < 0.01）。
- **AP-4** `scope_trim_candidate=YES` 未触发 N360 #141 → 高分风险必须在 downstream_handoff 中明确传递给 #141。量化检验：scope_trim_candidate=YES 的条目数必须 ≤ downstream_handoff.scope_trim_candidates 列表长度；漏传则 FAIL。

## Workflow position

```
Blocker open_blockers (from #137) / planning materials / prior risk register / milestone data
  ↓ #138 (risk register → 风险台账.csv)
  → scope_trim_candidates → N360 #141 (version scope trimming)
  → risk signals → N360 #142 (project rhythm tracking)
```

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n350-shared-coordination-contract.md` — shared contract and handoff rules
- `references/n350-skill-boundary-guide.md` — when skill selection is ambiguous (risk vs blocker)
- `references/n350-input-validation-rules.md` — when input quality is uncertain
- `references/csv-schema.md` — column definitions for n350.risk-item-extraction.v2
- `references/risk-scoring.md` — likelihood × impact matrix and scope_trim_candidate threshold
- `references/mitigation-action-quality-rules.md` — three-element validation for mitigation
- `references/risk-item-extraction-quality-checklist.md` — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/n350-coordination-flow.md` — full N350 pipeline: #135 → #136 → #137 → #138 → N360
- `examples/family-aligned-risk-item-extraction.md` — delta_update with scope_trim_candidate trigger
