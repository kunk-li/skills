#!/usr/bin/env python3
"""validate_csv.py for n350.task-initiation.v2 — updated with success_criteria quality check"""
import csv
import sys
import re
from pathlib import Path

SCHEMA_NAME = 'n350.task-initiation.v2'
EXPECTED_HEADERS = ['id', 'title', 'owner', 'priority', 'status', 'deadline', 'dependencies', 'success_criteria', 'evidence_ref', 'parent_ref']
REQUIRED_FIELDS = set(['id', 'title', 'owner', 'priority', 'status'])
LIST_FIELDS = set(['dependencies', 'evidence_ref'])
ALLOWED_STATUS = {'TODO', 'IN_PROGRESS', 'DONE', 'BLOCKED'}
ALLOWED_PRIORITY = {'P0', 'P1', 'P2', 'P3'}

# Vague success_criteria patterns that should trigger warnings
VAGUE_CRITERIA = [
    r'^完成$', r'^完成开发$', r'^测试通过$', r'^上线$', r'^验证完成$',
    r'^开发完毕$', r'^功能完成$', r'^完成测试$', r'^部署完成$'
]

def fail(msg: str) -> int:
    print(f"[FAIL] {msg}")
    return 1

def warn(msg: str) -> None:
    print(f"[WARN] {msg}")

def ok(msg: str) -> int:
    print(f"[OK] {msg}")
    return 0

def is_vague_criteria(criteria: str) -> bool:
    c = criteria.strip()
    if not c or c in ('待确认', '待核对', 'n/a', 'N/A'):
        return False  # explicitly deferred is ok
    for pattern in VAGUE_CRITERIA:
        if re.fullmatch(pattern, c):
            return True
    # Also warn if criteria is very short (< 10 chars) and doesn't contain measurable terms
    if len(c) < 10 and not any(char.isdigit() for char in c):
        return True
    return False

def main() -> int:
    if len(sys.argv) < 2:
        print('usage: python scripts/validate_csv.py <task_register.csv> [--strict]')
        return 2
    path = Path(sys.argv[1])
    strict = '--strict' in sys.argv
    if not path.exists():
        return fail(f"file not found: {path}")
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        if headers != EXPECTED_HEADERS:
            return fail(f"header mismatch. expected={EXPECTED_HEADERS} got={headers}")
        rows = list(reader)
    if not rows:
        return fail("csv has no data rows")

    seen_ids = set()
    errors = 0
    warnings = 0
    vague_criteria_count = 0

    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED_FIELDS:
            if not (row.get(field) or '').strip():
                print(f"[FAIL] row {idx} missing required field: {field}")
                errors += 1
        for field in LIST_FIELDS:
            value = (row.get(field) or '').strip()
            if ',' in value and not value.startswith('"'):
                print(f"[FAIL] row {idx} field '{field}' must use '|' not commas")
                errors += 1

        ident = (row.get('id') or '').strip()
        if ident in seen_ids:
            print(f"[FAIL] duplicate id at row {idx}: {ident}")
            errors += 1
        seen_ids.add(ident)

        status = (row.get('status') or '').strip()
        if status not in ALLOWED_STATUS:
            print(f"[FAIL] row {idx} invalid status: '{status}'")
            errors += 1

        priority = (row.get('priority') or '').strip()
        if priority and priority not in ALLOWED_PRIORITY:
            print(f"[FAIL] row {idx} invalid priority: '{priority}'")
            errors += 1

        # success_criteria quality check
        criteria = (row.get('success_criteria') or '').strip()
        if is_vague_criteria(criteria):
            msg = f"row {idx} success_criteria appears vague: '{criteria}'. Specify who verifies, in what environment, and what constitutes pass."
            if strict:
                print(f"[FAIL] {msg}")
                errors += 1
            else:
                warn(msg)
                warnings += 1
            vague_criteria_count += 1

    if vague_criteria_count > 0:
        print(f"[INFO] {vague_criteria_count} row(s) have potentially vague success_criteria. Use --strict to treat as errors.")

    if errors > 0:
        return fail(f"{SCHEMA_NAME} validation FAILED: {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA_NAME} validation passed: {len(rows)} rows, {warnings} warning(s)")

if __name__ == '__main__':
    raise SystemExit(main())
