#!/usr/bin/env python3
"""validate_md.py for skill #135 task-initiation (n350-coordination-v1.1.1)

Validates Markdown artifacts (analysis notes, split review reports, downstream
handoff documents). For CSV validation, use validate_csv.py.

Usage:
    python scripts/validate_md.py <output.md> [--strict]
"""
import re, sys
from pathlib import Path

SCHEMA = "n350-coordination-v1.1.1 / #135 task-initiation"
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}

REQUIRED_HEADINGS = [
    ("metadata",          re.compile(r"##\s*\d*\.?\s*Metadata|^```yaml[\s\S]*?\bmetadata:\b", re.I | re.MULTILINE)),
    ("downstream_handoff", re.compile(r"##\s*\d*\.?\s*(Downstream [Hh]andoff|下游交接)", re.I)),
]


def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0


def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_md.py <output.md> [--strict]"); return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists(): return fail(f"file not found: {path}")
    text = path.read_text(encoding="utf-8")
    errors = 0; warnings = 0

    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    _has_yaml_block = bool(re.search(r"^```yaml", text, re.MULTILINE))
    if _is_example and (_has_any_heading or _has_yaml_block):
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness '{_rm.group(1)}' not in {VALID_READINESS}"); return 1
        if "downstream_handoff" not in text.lower() and "downstream" not in text.lower():
            warn("example may be missing downstream_handoff section")
        return ok(f"{SCHEMA} example validation passed (light-check mode)")

    found = {}
    for key, pat in REQUIRED_HEADINGS:
        m = pat.search(text)
        if m: found[key] = m.start()
        else: print(f"[FAIL] missing section: {key}"); errors += 1

    # Downstream handoff fields
    if "downstream_handoff" in found:
        snippet = text[found["downstream_handoff"]:found["downstream_handoff"]+600]
        if "readiness" not in snippet:
            print("[FAIL] downstream_handoff missing readiness field"); errors += 1
        if "new_task_ids" not in snippet and "preserved_task_ids" not in snippet and "proposed" not in snippet:
            warn("downstream_handoff may be missing task ID lists"); warnings += 1

    # success_criteria vague word check (AP-1)
    VAGUE = ["完成", "测试通过", "上线", "推进", "验证", "确认", "搞定", "跟进", "对齐"]
    if "success_criteria" in text:
        sc_blocks = re.findall(r"success_criteria[:\s]+([^\n|]+)", text)
        for sc in sc_blocks:
            for vague in VAGUE:
                if vague in sc and len(sc.strip()) < 30:
                    msg = f"success_criteria may be vague (contains '{vague}'): {sc.strip()[:60]}"
                    if strict: print(f"[FAIL] {msg}"); errors += 1
                    else: warn(msg); warnings += 1
                    break

    rm = re.search(r"readiness:\s*([\w]+)", text)
    if rm and rm.group(1) not in VALID_READINESS:
        print(f"[FAIL] readiness '{rm.group(1)}' not in {VALID_READINESS}"); errors += 1

    if errors > 0: return fail(f"{SCHEMA} FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} passed — {warnings} warning(s)")


if __name__ == "__main__":
    raise SystemExit(main())
