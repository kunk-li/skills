---
name: task-initiation
description: Generate a structured task register (RFC4180 CSV) — reusable task rows with stable IDs, priorities, parent refs, and placeholders, without operating an external task system.
---

# 任务发起

## N350 contract baseline (n350-coordination-v1.1.1)

- contract_version: `n350-coordination-v1.1.1`
- workflow_node: N350
- skill_id: 135
- artifact_target: `任务清单.csv / task_register.csv`
- csv_schema: `n350.task-initiation.v2`
- composition_role: `task_register_creator`
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through stable row IDs, `csv_schema`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

## Role

作为 N350 任务协同层的**任务台账起草与合并生成器**，从规划输入创建或更新可追踪的任务台账。

具体职责：
- 识别并结构化任务（what/success_criteria/owner/deadline/dependencies/evidence_ref）
- `incremental_merge` 模式：保留所有旧 task ID，新任务从末尾编号；ID 冲突时以旧 ID 为准，差异字段以新输入为准并记录变更日志
- 运行 validate_csv.py 验证 CSV schema；`success_criteria` 拒绝 9 个模糊词
- 为 #136 提供稳定的 task ID 基础，为 N350 管道起点

**不负责**：状态更新（→ #136）、阻塞识别（→ #137）、风险评估（→ #138）、项目计划创建（→ PM 工具）。

## When NOT to use this skill

- **Not a status tracker**: task status updates belong in #136; #135 creates the initial task register.
- **Not a blocker register**: blocker details belong in #137; #135 marks tasks as BLOCKED and flags the dependency.
- **Not a risk register**: risk items belong in #138; #135 notes risk signals in task dependencies but does not analyze them.
- **Not a project plan**: #135 extracts actionable tasks from existing inputs; it does not create project milestones or timelines from scratch.

## Standalone and composition role

```yaml
standalone_goal: create or update a trackable task register from any planning input
minimum_viable_input:
  any_of:
    - 需求交接包或规划文档
    - 行动项清单（来自 N340 #131）
    - 需求变更影响分析
    - GAP、incident RCA、上线问题、或周报
    - 用户现有任务模板或字段约束
partial_readiness_allowed: true
degradation_behavior: >
  If key fields are missing, use 待确认 as value — never fabricate owner, deadline,
  or evidence_ref. Mark tasks with unknown owner as readiness=partial.
  Still run validate_csv.py and fix schema errors before output.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `full_draft`: 无旧台账 → 全量起草新任务台账。
- `incremental_merge`: 已有旧台账 + 新输入信号 → 增量合并，保留所有旧 `id`，新任务从末尾编号。ID 冲突处理：旧 ID 保留，差异字段以新证据为准并在合并变更说明中记录。
- `split_task_review`: 专门针对已有任务清单进行拆分审查，输出拆分建议而不修改原台账。

**Default routing**: 有旧台账 → `incremental_merge`; 无旧台账 → `full_draft`.

## Primary inputs

1. `需求交接包.zip`
2. `行动项清单.csv` / 会议纪要（来自 N340 #131）
3. `需求变更影响分析.md`
4. GAP、incident RCA、上线问题、周报
5. 用户现有任务模板或字段约束

## Task splitting rules

- 一条任务只对应一个可独立验收的交付物
- 如果"完成标准"需要用"并且"连接两个独立结果 → 必须拆分为两条任务
- 如果估算工作量超过 5 个工作日 → 建议拆分为子任务并通过 `parent_ref` 关联
- 若各步骤有独立的 owner 或 deadline → 必须拆分

## Default CSV contract

schema: `n350.task-initiation.v2`
columns: `id,title,owner,priority,status,deadline,dependencies,success_criteria,evidence_ref,parent_ref`

Rules:
- `status` 默认 `TODO`；只有输入明确显示已启动/已完成/已阻塞时才改值
- `dependencies`、`evidence_ref`、`parent_ref` 多值字段统一用 `|` 分隔（参考 csv-list-field-escape.md 处理 `|` 字符本身的转义）
- `evidence_ref` 为空极少；若无法追溯写 `待核对`，不要编造链接或 ticket
- **`success_criteria` 必须回答"由谁在什么条件下验证"**；不接受: 完成/测试通过/上线/推进/验证/确认/搞定/跟进/对齐（9 个模糊词）

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | Metadata (artifact_id, selected_mode, prior_register_id) | Always | prior_register_id required for incremental_merge |
| 2 | 合并决策 / 全量说明 | Always | State full_draft or incremental_merge with rationale |
| 3 | 任务台账 CSV | Always | All 10 columns; run validate_csv.py before output |
| 4 | 合并变更说明 | Always in incremental_merge | New tasks + preserved tasks + ID conflict resolutions |
| 5 | 任务拆分验证 | Always | Confirm split rule applied or N/A |
| 6 | Downstream handoff | Always | new_task_ids + preserved_task_ids + done_this_merge |

> Legend: Always = required in every mode.

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: task-status-sync
  new_task_ids: [T-035, T-036, T-037]
  preserved_task_ids: [T-031, T-032]
  done_this_merge: [T-031]
  readiness: complete | partial | degraded
```

## Workflow position

```
Planning input (N340 #131 action items / N090 PRD / requirements change analysis) + prior register
  ↓ #135 (task register creation → 任务清单.csv with stable task IDs)
  ↓ #136 (status snapshot refresh → 任务状态快照.csv)
  ↓ #137 (blocker extraction → 阻塞项台账.csv)
  ↓ #138 (risk extraction → 风险台账.csv) → N360 #141 (scope trimming)
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** `success_criteria` 使用模糊词（完成/测试通过/上线等）→ 必须写清楚谁验收、在什么环境、用什么标准；拒绝接受模糊表述。量化检验：validate_csv.py 的 VAGUE_CRITERIA 正则黑名单（9 个词）命中的 success_criteria 字段数 = --strict 模式下的 FAIL 数。
- **AP-2** 把多个独立可验收目标写成一条任务 → 若各步骤有独立 owner 或 deadline，必须拆分并用 `parent_ref` 关联。量化检验：单条任务的 success_criteria 中包含「并且」/「and」连接两个独立可验收目标时，parent_ref 字段必须非空；否则计入违例。
- **AP-3** `incremental_merge` 模式下新输入与旧台账出现同名 task 但 ID 不同 → 以旧 ID 为准；在合并变更说明中记录差异字段和解决方式。量化检验：incremental_merge 模式下，ID 冲突条目数必须 = 合并变更说明中「ID 冲突」记录数；不等时 FAIL。
- **AP-4** `evidence_ref` 留空或伪造 → 若无法追溯来源，写 `待核对`；不允许编造 ticket 链接。量化检验：evidence_ref 字段中出现 `http://example.com`/`placeholder` 等占位 URL 的行数 = open_blocker 数；允许 `待核对` 作为合法占位值。

## References

Read only when relevant to the request:
- `../../../_fixtures/n320-n360-end-to-end/README.md` — cross-skill end-to-end test fixture; read when verifying cross-node artifact handoffs
- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming IDs across skills
- `references/n350-shared-coordination-contract.md` — shared contract, ID format, handoff rules
- `references/n350-skill-boundary-guide.md` — when skill selection is ambiguous or dual-extraction scenarios
- `references/n350-escalation-path-rules.md` — when determining escalation paths or N350→N360 triggers
- `references/n350-input-validation-rules.md` — when input quality is uncertain
- `references/csv-schema.md` — column definitions and enum values for n350.task-initiation.v2
- `references/task-splitting-rules.md` — when assessing task granularity and success_criteria quality
- `references/task-priority-modes.md` — only when switching priority systems
- `references/task-initiation-quality-checklist.md` — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/family-aligned-task-initiation.md` — full_draft with parent-child task linking
- `examples/incremental-merge-mode.md` — incremental_merge with ID conflict resolution and preserved IDs
