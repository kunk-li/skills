# Example: Task Initiation — Incremental Merge Mode

Demonstrates **增量合并** mode: existing task register + new inputs → merged register with preserved IDs.

**Input**: `TASK-REG-S23`（已有台账）+ Sprint 24 planning output + postmortem action items

```yaml
metadata:
  contract_version: n350-coordination-v1.1.1
  skill_id: "135"
  selected_mode: incremental_merge
  artifact_id: TASK-REG-S24
  prior_register_id: TASK-REG-S23
  readiness: complete
```

## 合并决策

**判断结果**: 增量合并（已有旧台账 TASK-REG-S23 + 新输入信号）  
**操作规则**: 保留所有旧 `id`（T-031 ~ T-034），新任务从 T-035 起编

---

## 任务台账 CSV（合并后）

```csv
id,title,owner,priority,status,deadline,dependencies,success_criteria,evidence_ref,parent_ref
T-031,支付模块后端 API 实现,backend-team,P1,DONE,2025-06-13,,代码 review 通过，覆盖率82%,pr:1892,
T-032,支付模块 QA 回归,qa-team,P1,DONE,2025-06-17,T-031,Staging 无 P0/P1 缺陷 TPS≥500,qa-report:S23-QA,T-031
T-033,Redis warm-up 集成,platform-team,P1,IN_PROGRESS,2025-07-01,,连续3次含缓存变更的deploy零503;warm-up步骤出现在deploy日志,postmortem:PM-INC-2025-0612#AI-001-001,
T-034,OAuth callback spec v1,backend-lead,P0,BLOCKED,2025-06-30,,ABC集成团队书面确认收到并可用,meeting:arch-sync-0610#action:2,
T-035,POST /cart/add 513+条友好错误提示,backend-team,P1,TODO,2025-06-25,T-034决策,"QA在staging验证：第513条返回HTTP200+{limited:true,current_count:512}",meeting:S24-planning#item:3,
T-036,购物车数量上限策略决策,PM|ENG-lead,P1,TODO,2025-06-20,,书面决策记录发布Confluence并同步backend-team,meeting:S24-planning#item:5,
T-037,向auth-team确认OAuth延期影响,PM,P1,TODO,2025-06-17,,收到auth-team书面回复明确延期天数,meeting:S24-planning#item:8,
```

---

## 合并变更说明

### 保留的旧任务
- **T-031**: 状态已更新为 DONE（来自 qa-report:S23-QA）
- **T-032**: 状态已更新为 DONE（来自 qa-report:S23-QA）
- **T-033**: 保留 IN_PROGRESS，evidence_ref 更新（来自 postmortem）
- **T-034**: 保留 BLOCKED（BLK-008 未解阻）

### 新增任务（Sprint 24 Planning + Postmortem）
- **T-035**: 来自 S24 Planning（AI-S24-003 转为任务）
- **T-036**: 来自 S24 Planning（AI-S24-002 决策类转为任务）
- **T-037**: 来自 S24 Planning（AI-S24-004 跟进类转为任务）

### 任务拆分验证
- T-035 success_criteria：单一验收标准，无 "and" 连接独立结果 ✓（无需拆分）
- T-036 success_criteria：单一决策输出 ✓（无需拆分）

### 已删除/归档
- 无（增量合并不删除，仅在 DONE 后可标记为 archived）

---

## Downstream Handoff

```yaml
handoff_id: TASK-REG-S24-HANDOFF
producer_skill: task-initiation
consumer_skill_or_node: task-status-sync
cross_artifact_refs:
  - artifact_id: TASK-REG-S23
    relationship: prior_register
  - artifact_id: ACTION-N340-S24-PLANNING
    relationship: source_of_new_tasks
    consumed_items: [AI-S24-002, AI-S24-003, AI-S24-004]
new_task_ids: [T-035, T-036, T-037]
preserved_task_ids: [T-031, T-032, T-033, T-034]
done_this_merge: [T-031, T-032]
readiness: complete
confidence: high
next_best_checks:
  - "task-status-sync: use delta_mode with prior_snapshot_id=TASK-REG-S23"
  - "Confirm T-034 BLOCKED status still applies (BLK-008)"
  - "T-036 decision deadline 2025-06-20: PM to ensure decision is made"
```
