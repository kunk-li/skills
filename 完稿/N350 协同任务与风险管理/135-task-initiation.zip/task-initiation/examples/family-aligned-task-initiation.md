# Task Initiation Example - N340 ACT to TASK register

```yaml
metadata:
  contract_version: n350-coordination-v1.1.1
  workflow_node: N350
  skill_id: 135
  skill_name: task-initiation
  artifact_family_id: n350-task-risk-coordination-suite
  artifact_id: TASK-LIST-platform-202619
  csv_schema: n350.task-initiation.v2
  selected_mode: action_items_to_tasks
  readiness: ready
  source_time_window: {start: 2026-05-04, end: 2026-05-10, timezone: Asia/Tokyo}
  project_scope: platform
  team_scope: [platform, backend, qa]
  sprint_or_release: 2026-W19
  source_artifacts: [N340 action-items.md]
  upstream_id_aliases: [ACT-platform-202619-01]
  evidence_refs:
    - {ref_id: EV-N340-ACT-001, source_family: action_item, source_name: N340 action-items.md, time_window_or_version: 2026-W19, scope: [platform], upstream_id_aliases: [ACT-platform-202619-01], excerpt_or_pointer: section=follow_up_actions; row=1, confidence: high, layer: confirmed_fact}
  cross_artifact_refs: [ACT-platform-202619-01]
  pending_clarifications: []
  open_blockers: []
  owner_placeholders: [backend lead, qa owner]
  confidentiality_level: public_internal
  confidence: high
  composition_role: task_register_creator
  function_bias: convert_decisions_into_executable_tasks
  stage_position: execution_governance.task_coordination.task-initiation
  artifact_target: 任务清单.csv
  freshness: {as_of_date: 2026-05-07, source_commit: null, expected_review_window: weekly}
```

```csv
id,title,owner,priority,status,deadline,dependencies,success_criteria,evidence_ref,parent_ref
TASK-platform-01,补齐平台错误码文档入口,backend lead,P1,TODO,2026-05-10,,API 文档入口包含最新错误码和 FAQ 链接,EV-N340-ACT-001,ACT-platform-202619-01
TASK-platform-02,补一轮回归状态同步,qa owner,P2,TODO,2026-05-11,TASK-platform-01,回归结果同步到状态快照,EV-N340-ACT-001,ACT-platform-202619-01
```

```yaml
downstream_handoff:
  contract_version: n350-coordination-v1.1.1
  handoff_id: HO-N350-TASK-LIST-platform-202619-001
  producer_skill: task-initiation
  consumer_skill_or_node: task-status-sync
  artifact_family_id: n350-task-risk-coordination-suite
  artifact_id: TASK-LIST-platform-202619
  artifact_target: 任务清单.csv
  required_fields: [id, title, owner, priority, status, deadline, evidence_ref, parent_ref]
  cross_artifact_refs: [ACT-platform-202619-01]
  pending_clarifications: []
  readiness: ready
  confidence: high
  next_best_checks: [run task-status-sync after next weekly update]
```
