# Split Task Review Mode Example — Task Initiation #135

## Metadata

```yaml
artifact_id: TASK-SPLIT-REVIEW-001
skill_id: 135
contract_version: n350-coordination-v1.1.1
selected_mode: split_task_review
prior_register_id: TASK-REG-007
review_scope: [T-042, T-043, T-044]
readiness: partial
```

## Split Task Review — Selected Tasks

**Purpose**: Review tasks T-042 through T-044 for split eligibility without modifying the original register.

### Task T-042 — "完成支付模块开发和测试"

**Split verdict**: ⚠️ **Must split**

**Reason**: `success_criteria` contains "并且"连接两个独立验收目标：
- 目标 A: "支付接口通过联调测试"（独立 owner: 后端团队，deadline: W24）
- 目标 B: "支付流程通过 QA 回归"（独立 owner: QA 团队，deadline: W25）

**Proposed split**:

| id | title | owner | deadline | success_criteria |
|----|-------|-------|----------|-----------------|
| T-042a | 支付接口联调 | 后端团队 | 2025-06-13 | 后端负责人在 staging 环境确认 /pay 和 /refund 接口返回 200，联调记录归档 |
| T-042b | 支付流程 QA 回归 | QA 团队 | 2025-06-20 | QA-lead 在 staging 确认支付回归用例全部通过，报告链接附入 PR |

`parent_ref`: both → T-042 (original)

---

### Task T-043 — "数据库迁移脚本编写"

**Split verdict**: ✅ **No split needed**

**Reason**: Single deliverable (migration script), single owner (DBA 团队), single deadline (W23).
`success_criteria` is specific: "DBA-lead 在 pre-prod 执行迁移后确认数据行数与源库一致，回滚脚本已通过演练"。
Estimated effort: 3 working days — below 5-day split threshold.

---

### Task T-044 — "发布说明文档、培训材料、上线通知"

**Split verdict**: ⚠️ **Should split** (3 independent deliverables, 3 owners)

**Proposed split**:

| id | title | owner | deadline | success_criteria |
|----|-------|-------|----------|-----------------|
| T-044a | 发布说明文档 | Tech Writer | 2025-06-18 | PM-lead 审阅通过，文档链接发布至 wiki |
| T-044b | 培训材料 | 产品团队 | 2025-06-19 | 培训视频上传完成，CS 团队负责人确认收到 |
| T-044c | 上线通知邮件 | PM | 2025-06-20 | 发送至 stakeholders 列表，抄送 ENG-lead |

`parent_ref`: all → T-044

## Summary

| Task | Verdict | Action Required |
|------|---------|----------------|
| T-042 | Must split | Create T-042a, T-042b before next sprint planning |
| T-043 | No split | No changes needed |
| T-044 | Should split | Create T-044a/b/c; coordinate with 3 owners |

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: task-initiation (incremental_merge on prior register)
  split_candidates: [T-042, T-044]
  no_split_confirmed: [T-043]
  proposed_new_tasks: [T-042a, T-042b, T-044a, T-044b, T-044c]
  readiness: partial
  note: "This is a review-only output — run incremental_merge to apply splits to TASK-REG-007"
```
