# Task Splitting Rules

Use this reference when deciding whether to split a task or keep it as one unit.

## The core splitting test
A task must be split if any of the following is true:

1. **AND test**: The `success_criteria` field contains the word "and" connecting two independently verifiable outcomes
   - Split: "后端开发完成 **and** 单测覆盖率≥80%" → Two tasks
   - Keep: "后端开发完成，单测覆盖率≥80%作为完成标准" → One task with clear criterion

2. **Different owner test**: Different roles are responsible for different parts
   - Split: "后端开发（backend-team）and 集成测试（qa-team）" → Two tasks with different owners

3. **5-day rule**: Estimated effort exceeds 5 working days for one task
   - Split into sub-tasks linked via `parent_ref`
   - Each sub-task should be completable in ≤5 days

4. **Blocking relationship**: Part A must complete before Part B can start
   - Split: Part A and Part B as separate tasks with `dependency` link
   - This preserves the ability to track which sub-part is actually blocked

## When NOT to split
- Multiple steps within the same role's work that form a natural unit ("设计 → 实现 → 单测" all by backend-team is one task)
- Verification steps that are intrinsic to completion ("code review" is part of "feature development," not a separate task)
- Documentation that accompanies the main deliverable

## Parent-child task format
```csv
id,title,owner,priority,status,deadline,dependencies,success_criteria,evidence_ref,parent_ref
T-030,支付模块开发（父任务）,backend-team,P1,TODO,2025-06-20,,所有子任务完成,,
T-031,支付模块后端 API 实现,backend-team,P1,TODO,2025-06-17,,代码 review 通过，单测覆盖率≥80%,meeting:MTG-001#action:3,T-030
T-032,支付模块 QA 回归,qa-team,P1,TODO,2025-06-20,T-031,Staging 环境无 P0/P1 缺陷，TPS≥500,,T-030
```

## success_criteria quality rules
**Rejected phrases** (too vague, must be rewritten):
- "完成开发" → rewrite as "代码 review 通过，合入 main 分支"
- "测试通过" → rewrite as "QA 在 staging 无 P0/P1 缺陷"
- "上线" → rewrite as "灰度 10% 无异常，完整发布后监控正常 2h"
- "验证完成" → rewrite as "由 [role] 在 [environment] 完成以下验证：[specific steps]"

**Accepted format**:
- Who verifies + Environment + What constitutes pass + Measurable threshold (if applicable)
- Example: "QA 在 staging 环境回归通过，无 P0/P1 缺陷；backend-team P95 延迟 < 200ms"
