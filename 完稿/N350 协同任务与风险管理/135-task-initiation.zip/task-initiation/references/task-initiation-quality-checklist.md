# 任务发起 Quality Checklist

Use this checklist before returning an N350 artifact.

1. Metadata contains all required shared fields when structured output is expected.
2. `contract_version` and `csv_schema` match the current skill and release.
3. `selected_mode` matches the actual update path.
4. Stable IDs follow artifact and row ID formats; old IDs are preserved in delta mode.
5. CSV output uses the exact column order from `references/csv-schema.md`.
6. Multi-value CSV fields use `|`, not bare commas.
7. Evidence references identify source family, source name, pointer, confidence, and layer.
8. Missing owner, deadline, evidence, score, or decision is marked `待确认` or `待核对`.
9. `cross_artifact_refs` use artifact or row IDs, not local file paths.
10. `downstream_handoff` includes handoff_id, consumer, required_fields, readiness, confidence, and next_best_checks.
11. Compare the output against the closest file under `examples/`; differences are allowed but should be intentional.

## Skill-specific checks
- Each task has action, role owner or placeholder, deadline, success criteria, evidence_ref, and parent_ref.
- Preserve old TASK-* IDs in delta mode.
- Use one priority mode per artifact.
- Do not operate external task systems.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- Every task passes splitting rule check: `success_criteria` containing "and" between two independent outcomes triggers split suggestion.
- `success_criteria` quality check: phrases in the rejected list trigger open_blocker, not silent pass.
- `evidence_ref` is present or explicitly `待核对` — never empty string.

## Output structure completeness checks
- All 6 mandatory sections present per mandatory section table
- validate_csv.py passes all schema checks
- `incremental_merge` mode: `## 合并变更说明` section present

## Mode-specific checks

### incremental_merge mode
- prior_register_id in metadata
- preserved_task_ids and new_task_ids both listed in downstream_handoff
- No task ID drift (all prior IDs preserved)

### split_task_review mode
- Every split recommendation has clear split rationale
- Original task_id referenced for each split suggestion
