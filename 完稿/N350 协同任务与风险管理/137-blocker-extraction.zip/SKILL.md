---
name: blocker-extraction
description: extract current blockers that have already happened and are actively constraining progress in n350 coordination. use when chatgpt should distinguish blockers from future risks, require evidence refs, recommend escalation paths, preserve stable blocker ids, and output structured blocker registers or concise summaries grounded in provided material.
---

# 阻塞项提取

## N350 v1.1.0 contract baseline
- contract_version: `n350-coordination-v1.1.0`
- workflow_node: `N350`
- skill_id: `137`
- artifact_target: `阻塞项台账.csv / blocker_register.csv`
- csv_schema: `n350.blocker-extraction.v2`
- composition_role: `active_impediment_classifier`

This skill is self-contained. It can be used alone with minimum viable input, and it composes with sibling N350 skills through stable row IDs, `csv_schema`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

Apply these bundled references when structured output or downstream consumption is needed:
- `references/n350-shared-coordination-contract.md`
- `references/output-contract.yaml`
- `references/csv-schema.md`
- `references/blocker-extraction-quality-checklist.md`


识别 **已经发生且正在阻碍进度** 的 blocker，并给出适合的解阻动作与升级路径。

先阅读：
- `references/n350-contracts.md`
- `references/n350-shared-coordination-contract.md`
- `references/output-contract.yaml`
- `references/csv-schema.md`
- `references/blocker-evidence-template.md`

## 先判断 blocker 还是 risk
- **blocker**：已经发生，当前正在卡住任务、里程碑、发版、依赖或决策。
- **risk**：还没发生，但有可能造成未来损失或延误。

如果材料只支持“可能会出问题”，不要强行记成 blocker，应转交给 risk-item-extraction。

## 优先模式
- 有旧 blocker 台账 + 新更新 → **delta mode**，保留 `blocker_id`，补充新证据、状态或升级路径。
- 没有旧台账 → **fresh register**。

## 工作流
1. 从输入里先抽出“被什么卡住了、卡住谁、证据在哪”。
2. 只把 **当前有效** 的阻塞记为 blocker；历史已解决项仅在用户要求时保留并标为 `RESOLVED`。
3. 为每条 blocker 补齐受影响任务、类型、严重度、证据、解阻动作。
4. 判断是否需要升级：
   - 质量门禁 / 缺陷熔断相关 → 考虑 `N250`
   - 人工确认 / 跨团队拍板 / 平台放行相关 → 考虑 `N380`
   - 一般协同推进 → `PM`
5. 如果证据不足但 blocker 基本可信，`evidence_ref` 写 `待核对`，并明确说明缺口。

## 默认契约模式（推荐）
当结果需要沉淀台账或下游消费时，输出：

- schema: `n350.blocker-extraction.v2`
- exact columns:
  `blocker_id,title,affected_task_ids,blocker_type,severity,owner,evidence_ref,impact_summary,unblock_action,escalation_path,status`

规则：
- `affected_task_ids`、`evidence_ref`、`escalation_path` 多值统一用 `|`
- `blocker_type` 仅用：`dependency` / `decision` / `resource` / `technical` / `external` / `compliance` / `other`
- `severity` 仅用：`low` / `medium` / `high`
- `status` 仅用：`OPEN` / `MONITORING` / `RESOLVED`
- `evidence_ref` 是必填字段；拿不到时写 `待核对`

## 何时输出 markdown
用户只要“阻塞盘点摘要”或“周会 blocker 列表”时，可以输出 markdown；但仍要保留 blocker vs risk 的边界和 evidence 意识。

## 严格边界
- 不把尚未发生的问题写成 blocker。
- 不补充输入里不存在的业务承诺。
- 不在这里做完整风险台账或版本裁剪决策，只提供升级建议和 risk handoff 提示。

## 质量检查
在完成前确认：
- 每条 blocker 都能回答“卡住了谁、为什么、证据在哪、怎么解”。
- blocker 与 risk 没有混淆。
- 升级路径有依据，不是机械全部升级。
- 若输出 CSV，遵守 `references/csv-schema.md`，必要时可运行 `scripts/validate_csv.py`。
