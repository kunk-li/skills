# Blocker Extraction Example - status snapshot to blocker register

```yaml
metadata:
  contract_version: n350-coordination-v1.1.0
  workflow_node: N350
  skill_id: 137
  skill_name: blocker-extraction
  artifact_family_id: n350-task-risk-coordination-suite
  artifact_id: BLK-REG-platform-202619
  csv_schema: n350.blocker-extraction.v2
  selected_mode: status_sync_blocker_scan
  readiness: ready
  source_time_window: {start: 2026-05-07, end: 2026-05-07, timezone: Asia/Tokyo}
  project_scope: platform
  team_scope: [platform, backend, qa]
  sprint_or_release: 2026-W19
  source_artifacts: [STATUS-platform-202619]
  upstream_id_aliases: [ACT-platform-202619-01, TASK-platform-02]
  evidence_refs:
    - {ref_id: EV-N350-BLK-001, source_family: status_update, source_name: STATUS-platform-202619, time_window_or_version: 2026-W19, scope: [platform], upstream_id_aliases: [TASK-platform-02], excerpt_or_pointer: row TASK-platform-02 status=BLOCKED blocker_refs=BLK-platform-01, confidence: high, layer: confirmed_fact}
  cross_artifact_refs: [STATUS-platform-202619, TASK-LIST-platform-202619]
  pending_clarifications: []
  open_blockers: [BLK-platform-01]
  owner_placeholders: [backend lead]
  confidentiality_level: public_internal
  confidence: high
  composition_role: active_impediment_classifier
  function_bias: separate_current_blockers_from_future_risks
  stage_position: execution_governance.task_coordination.blocker-extraction
  artifact_target: 阻塞项台账.csv
  freshness: {as_of_date: 2026-05-07, source_commit: null, expected_review_window: weekly}
```

```csv
blocker_id,title,affected_task_ids,blocker_type,severity,owner,evidence_ref,impact_summary,unblock_action,escalation_path,status
BLK-platform-01,API 文档入口未补齐导致 QA 回归无法启动,TASK-platform-02,dependency,medium,backend lead,EV-N350-BLK-001,阻塞本周回归状态同步,在 2026-05-10 前补齐并通知 QA,N360,OPEN
```
