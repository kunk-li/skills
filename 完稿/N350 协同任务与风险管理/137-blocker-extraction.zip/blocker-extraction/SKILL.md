---
name: blocker-extraction
description: Identify and classify blockers already occurring and actively constraining progress, each with an explicit unblock action (actor + action + time target).
---

# 阻塞项提取

## N350 contract baseline (n350-coordination-v1.1.1)

- contract_version: `n350-coordination-v1.1.1`
- workflow_node: N350
- skill_id: 137
- artifact_target: `阻塞项台账.csv / blocker_register.csv`
- csv_schema: `n350.blocker-extraction.v2`
- composition_role: `active_impediment_classifier`
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through stable row IDs, `csv_schema`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

## Role

作为 N350 任务协同层的**阻塞项提取生成器**，从状态快照和输入材料中识别正在阻塞进度的事项。

具体职责：
- 明确区分 blocker（已发生、正在阻塞）vs risk（可能发生）— 前者进本 skill，后者进 #138
- 每条 blocker 的 `unblock_action` 必须包含三要素：Actor + Specific action + Time target
- `PENDING_CONFIRMATION` 状态用于尚需一轮确认的候选 blocker
- 将 `open_blockers` 和 `related_blocker_ids` 传递给 #138

**不负责**：任务创建（→ #135）、状态快照（→ #136）、风险台账（→ #138）、升级执行（→ PM/EM）。

## When NOT to use this skill

- **Not a task register**: #137 extracts blockers, not tasks; task creation belongs in #135.
- **Not a risk register**: if the issue has not yet occurred, route to #138 instead of #137.
- **Not an escalation decision maker**: #137 identifies escalation paths; the actual escalation decision and execution belongs to PM or EM.
- **Not a status tracker**: #137 focuses on active blockers; completed or historical blockers belong in #136 status snapshots.

## Blocker vs risk — classification matrix

Use this 2×2 matrix when classification is ambiguous:

| | 正在阻塞进度 | 尚未阻塞进度 |
|---|---|---|
| **已经发生** | ✅ Blocker → #137 | ⚠️ 有前兆，但尚未卡住 → 视情况 #137 或 #138 |
| **尚未发生** | ❌ 不可能 | ✅ Risk → #138 |

**判断原则**: 如果材料只支持"可能会出问题"→ 转交 #138。如果问题今天才发生但尚未实际卡住任何任务 → 标为 PENDING_CONFIRMATION。

## Standalone and composition role

```yaml
standalone_goal: identify, classify, and document active blockers with explicit unblock actions and escalation paths
minimum_viable_input:
  any_of:
    - 任务状态快照（来自 #136，含 blocked_task_ids）
    - standup 记录或阻塞反馈
    - 旧阻塞台账 + 新更新（delta 模式）
    - 直接的阻塞描述或障碍清单
partial_readiness_allowed: true
degradation_behavior: >
  If unblock_action components are partially missing, mark as PENDING_CONFIRMATION.
  Do not force a blocker classification when evidence only shows potential future risk.
  Pass unresolved PENDING_CONFIRMATION items to #138 as candidate risks.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `fresh_blocker_register`: 无旧台账 → 从状态快照和输入材料构建新 blocker 台账。
- `delta_blocker_update`: 有旧台账 + 新更新 → 保留所有 `blocker_id`，补充新证据、状态变化或升级路径。
- `status_sync_blocker_scan`: 专门从 #136 状态快照的 `blocked_task_ids` 扫描提取 blocker。
- `escalation_ready_blocker_list`: 专门输出升级路径已明确、可立即升级的 blocker 清单（escalation_status=ready）。

**Default routing**: 无旧台账 → `fresh_blocker_register`; 有旧台账 → `delta_blocker_update`; 来自 #136 → `status_sync_blocker_scan`.

## Unblock action quality rules

Every `unblock_action` must contain three elements:

| Element | Requirement | Anti-pattern |
|---------|-------------|--------------|
| Actor | Specific role or team who takes action | "相关人员" |
| Specific action | Concrete step, not general direction | "推进解决" |
| Time target | Specific date or sprint reference | "尽快" |

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | Metadata | Always | artifact_id, selected_mode, source_snapshot_id |
| 2 | 阻塞项台账 CSV | Always | All columns; run validate_csv.py before output |
| 3 | 升级路径汇总 | Always | Which blockers need escalation and to whom |
| 4 | Downstream handoff | Always | open_blockers + related_blocker_ids passed to #138 |

> Legend: Always = required in every mode.

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** 把"可能出问题"的风险标为 blocker → 必须用分类矩阵区分；风险归 #138，已发生阻塞归 #137。量化检验：blocker 台账中，status=ACTIVE 且 blocker_type 被标为「潜在风险」的条目数 = 需路由到 #138 的 open_blocker 数。
- **AP-2** `unblock_action` 缺少三要素之一（actor/action/time_target）→ 必须完整；缺失任一元素标为 PENDING_CONFIRMATION。量化检验：unblock_action 字段中，actor/action/time_target 三要素任一缺失的条目数 = PENDING_CONFIRMATION 状态条目数；不等时 FAIL。
- **AP-3** 历史已解决的阻塞保留在 active 台账中 → 已解决项标为 RESOLVED；只在用户要求时保留历史记录。量化检验：status=ACTIVE 的条目中，resolution_date 字段非空的条目数必须 = 0；否则计入违例（已解决应标为 RESOLVED）。
- **AP-4** 模式选择中 `escalation_ready_blocker_list` 与 `fresh_blocker_register` 混用 → 模式互斥；escalation_ready 仅用于审查升级状态，不添加新条目。量化检验：escalation_ready_blocker_list 模式输出的条目数必须 ≤ 输入台账中 escalation_status=ready 的条目数；新增条目数 = FAIL 数。

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: risk-item-extraction
  open_blockers: [BLK-003, BLK-007]
  related_blocker_ids: [BLK-001, BLK-002]
  escalation_ready_ids: [BLK-003]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all blockers have unblock_action three-element data and escalation paths confirmed) / `partial` (some blockers have PENDING_CONFIRMATION status — listed in open_blockers) / `degraded` (blocker list only; unblock_action and escalation paths not yet populated — downstream consumers must not treat as actionable without additional triage).

## Workflow position

```
Status snapshot blocked_task_ids (from #136) / standup impediments / direct blocker descriptions
  ↓ #137 (blocker register → 阻塞项台账.csv)
  → open_blockers + related_blocker_ids → #138 (risk extraction)
  → escalation_ready items → PM/EM for resolution
```

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n350-shared-coordination-contract.md` — shared contract and handoff rules
- `references/n350-skill-boundary-guide.md` — when skill selection is ambiguous (blocker vs risk)
- `references/n350-escalation-path-rules.md` — when determining escalation paths or N350→N360 triggers
- `references/n350-input-validation-rules.md` — when input quality is uncertain
- `references/csv-schema.md` — column definitions for n350.blocker-extraction.v2
- `references/blocker-evidence-template.md` — evidence field format for each blocker
- `references/unblock-action-quality-rules.md` — three-element validation for unblock_action
- `references/blocker-extraction-quality-checklist.md` — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/blocker-pipeline-example.md` — status_sync_blocker_scan from #136 blocked_task_ids
- `examples/family-aligned-blocker-extraction.md` — delta_blocker_update with escalation_ready items
