# Unblock Action Quality Rules

Use this reference when writing `unblock_action` for any blocker entry.

## The three-element requirement
Every `unblock_action` must contain all three elements:

| Element | What it answers | Example |
|---------|-----------------|---------|
| **Actor** (动作主语) | Who is responsible for taking this action? Use role, not individual name. | `PM-role`, `auth-team TL`, `on-call-sre` |
| **Specific action** (具体动作) | What exactly will they do? No vague verbs allowed. | Not "推进" or "跟进" — use "在 Slack #auth-dev 频道发出正式请求", "召开对齐会议", "提交 PR" |
| **Time target** (时间节点) | By when, or triggered by what condition? | Explicit date: `2025-06-14`; OR sprint label: `Sprint 12 结束前`; OR trigger: `若 2025-06-12 前无回复，升级至 EM` |

## Rejected phrases (must be rewritten)
| Rejected | Why | Rewrite as |
|---------|-----|-----------|
| "PM 推进 Auth 团队配合" | No specific action, no date | "PM 在 2025-06-12 前向 auth-team TL 发出正式请求，要求 OAuth callback spec v1 在 2025-06-14 前交付" |
| "持续跟进" | Not an action | "每日站会检查状态，若 2025-06-14 前无进展，升级至 EM 介入" |
| "尽快解决" | No specificity | "backend-team 在 2025-06-11 前完成本地复现，并输出根因假设" |
| "协调资源" | Too vague | "EM 在 2025-06-10 前确认额外 1 名 backend 工程师加入支付模块" |
| "等待对方回复" | No active action | "若 2025-06-13 18:00 前未收到回复，PM 升级至合作方 BD 负责人" |

## Format for unblock_action in CSV
```
unblock_action: "PM 在 2025-06-12 向 auth-team TL 发出正式书面请求（Slack #dev-sync + email），要求 OAuth callback spec v1 在 2025-06-14 17:00前交付；若逾期，PM 升级至 EM 并抄送合作方项目负责人"
```

## Escalation path completeness
When `escalation_path` references `N380` (人工确认 / 跨团队拍板), the `unblock_action` must additionally specify:
- **Who initiates the N380 escalation** (role)
- **What artifact or information is needed for N380 to decide**
- **What is the decision deadline**

## Self-referential blockers
If the blocker owner IS the blocking party (e.g., `owner: auth-team` and the blocker is that auth-team hasn't delivered), the unblock_action must involve a third party (PM, EM, or escalation path) — not just the owner themselves.
