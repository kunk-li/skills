# 阻塞项提取 Quality Checklist

Use this checklist before returning an N350 artifact.

1. Metadata contains all required shared fields when structured output is expected.
2. `contract_version` and `csv_schema` match the current skill and release.
3. `selected_mode` matches the actual update path.
4. Stable IDs follow artifact and row ID formats; old IDs are preserved in delta mode.
5. CSV output uses the exact column order from `references/csv-schema.md`.
6. Multi-value CSV fields use `|`, not bare commas.
7. Evidence references identify source family, source name, pointer, confidence, and layer.
8. Missing owner, deadline, evidence, score, or decision is marked `待确认` or `待核对`.
9. `cross_artifact_refs` use artifact or row IDs, not local file paths.
10. `downstream_handoff` includes handoff_id, consumer, required_fields, readiness, confidence, and next_best_checks.
11. Compare the output against the closest file under `examples/`; differences are allowed but should be intentional.

## Skill-specific checks
- Only record current active blockers, not future risks.
- Every blocker has evidence_ref or 待核对.
- affected_task_ids uses TASK-* IDs.
- Escalation path uses role/team/node, not named people.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- Every blocker has `unblock_action` with all 3 elements (actor + specific action + time target).
- `blocker` vs `risk` classification is always explicit; ambiguous items include classification rationale.
- `evidence_ref` is present or `待核对` — never empty; missing evidence triggers open_blocker.

## Output structure completeness checks
- All 5 mandatory sections present per mandatory section table
- validate_csv.py passes all schema checks
- `## Blocker vs risk 分类决策` section explicit

## Mode-specific checks

### delta_update mode
- prior_blocker_register_id in metadata
- Changed blockers show `previous_status` → `current_status`

### escalation_review mode
- Every OPEN blocker's escalation_path reviewed
- `escalation_recommended: true/false` for each blocker
