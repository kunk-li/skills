# Example: Blocker Extraction — PENDING_CONFIRMATION Mode

## Metadata

```yaml
artifact_id: BLK-PENDING-001
skill_id: 137
contract_version: n350-coordination-v1.1.1
selected_mode: fresh_blocker_register
source_snapshot_id: TASK-STATUS-SPARSE-001
readiness: partial
```

## Blocker Register CSV

| blocker_id | task_id | blocker_description | status | unblock_action | actor | time_target | evidence_ref |
|------------|---------|---------------------|--------|---------------|-------|-------------|--------------|
| BLK-001 | T-004 | 测试环境不可用，QA 无法开始压测 | ACTIVE | 申请 ops 团队在 W24 前恢复测试环境；若 W24 仍不可用则升级至 EM | ops 团队 | 2025-06-27 | standup-2025-06-20 |
| BLK-002 | T-002 | 数据迁移脚本进度不明，本周零证据 | PENDING_CONFIRMATION | 由 PM 在 standup 前向 DBA-lead 确认当前状态；若确认为阻塞则升级为 ACTIVE | PM | 2025-06-21 | 待核对 |

**PENDING_CONFIRMATION 说明：**
- BLK-002：T-002 为 IN_PROGRESS(stale)，可能已阻塞也可能仅未报告。unblock_action 缺少 specific_action（仅有确认动作），暂标 PENDING_CONFIRMATION
- BLK-002 将在下次 standup 确认后升级为 ACTIVE 或关闭

## Escalation Path Summary

| blocker_id | escalation_needed | escalate_to | deadline |
|------------|:-----------------:|-------------|----------|
| BLK-001 | ✅ | EM（若 W24 仍不可用） | 2025-06-27 |
| BLK-002 | ⏳ 待确认 | — | 2025-06-21 确认后决定 |

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: risk-item-extraction
  open_blockers: [BLK-001]
  pending_confirmation: [BLK-002]
  related_blocker_ids: []
  escalation_ready_ids: []
  readiness: partial
  note: "BLK-002 requires one confirmation round before being actionable"
```
