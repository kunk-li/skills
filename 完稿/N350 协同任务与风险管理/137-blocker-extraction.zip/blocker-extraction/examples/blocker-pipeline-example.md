# Example: Blocker Extraction — Fresh Register + Upstream/Downstream Pipeline

Demonstrates `fresh_register` mode: building blocker register from status snapshot, with full pipeline context.

**Input**: `STATUS-S24-W01` (from #136 task-status-sync)  
**Key signal**: T-034 BLOCKED, T-033 IN_PROGRESS(stale)

```yaml
metadata:
  contract_version: n350-coordination-v1.1.1
  skill_id: "137"
  selected_mode: fresh_register
  artifact_id: BLOCKER-S24-W01
  source_snapshot_id: STATUS-S24-W01
  readiness: complete
```

## Blocker vs Risk 分类决策

| Task | 信号 | 分类依据 | 路由 |
|------|------|---------|------|
| T-034 BLOCKED | auth-team spec 未到 2周以上 | **已发生，正在阻塞** T-034 无法开始 | → blocker |
| T-033 stale | 两周无进展证据 | **可能**是阻塞，但无明确阻塞信号；需确认 | → pending（确认后分类）|

---

## Blocker 台账 CSV

```csv
blocker_id,title,affected_task_ids,blocker_type,severity,owner,evidence_ref,impact_summary,unblock_action,escalation_path,status
BLK-S24-001,Auth-team OAuth callback spec 未交付,T-034,dependency,high,PM-role,meeting:sync-0610|status:STATUS-S24-W01#T-034,"T-034 无法开始；若 T-034 延期则 T-035 开始日期推迟，Sprint 24 M3 联调 AT_RISK","PM 在 2025-06-17 前通过 Slack #dev-sync 向 auth-team TL 发出正式书面请求，要求 OAuth callback spec v1 在 2025-06-19 17:00 前交付；若逾期，PM 升级至 EM 并抄送合作方 BD 负责人",N380|PM-escalation,OPEN
BLK-S24-002（待确认）,T-033 Redis warm-up 集成停滞原因不明,T-033,unknown,medium,platform-team,status:STATUS-S24-W01#T-033,"若为阻塞：T-033 延期可能导致 v2.4 发版质量风险","platform-team TL 在 2025-06-17 standup 前确认 T-033 是否阻塞及阻塞原因；若确认阻塞，提供具体阻塞信号后升级为正式 blocker",PM,PENDING_CONFIRMATION
```

---

## BLK-S24-001 详情

**Unblock action 三要素验证**:
- ✅ Actor（主语）: PM-role
- ✅ Specific action（具体动作）: 通过 Slack #dev-sync 发出正式书面请求 + 要求明确交付时间
- ✅ Time target（时间节点）: 2025-06-19 17:00；逾期升级至 EM

**Escalation path**:
- Level 1: PM-role 书面请求（2025-06-17）
- Level 2: EM 介入（若 2025-06-19 未收到）
- Level 3: N380 跨团队协调（若 EM 无法解阻）

---

## 上游消费关系

| 来源 artifact | 字段 | 用途 |
|-------------|------|------|
| STATUS-S24-W01 (#136 output) | blocked_task_ids=[T-034] | 识别 BLK-S24-001 |
| STATUS-S24-W01 (#136 output) | stale_task_ids=[T-033] | 识别 BLK-S24-002 待确认 |
| TASK-REG-S24 (#135 output) | T-034.dependencies=[T-034决策] | 确认阻塞影响范围 |

---

## Downstream Handoff

```yaml
handoff_id: BLOCKER-S24-W01-HANDOFF
producer_skill: blocker-extraction
consumer_skill_or_node: risk-item-extraction
cross_artifact_refs:
  - artifact_id: STATUS-S24-W01
    producer_skill: task-status-sync
    consumed_fields: [blocked_task_ids, stale_task_ids]
  - artifact_id: TASK-REG-S24
    producer_skill: task-initiation
    consumed_fields: [task dependencies]
open_blockers: [BLK-S24-001]
pending_confirmation: [BLK-S24-002]
readiness: complete
confidence: high
next_best_checks:
  - "risk-item-extraction: BLK-S24-001 is related_blocker_id for auth-team dependency risk"
  - "Confirm BLK-S24-002 status by 2025-06-17 standup"
  - "PM: send formal request for BLK-S24-001 by 2025-06-17"
```
