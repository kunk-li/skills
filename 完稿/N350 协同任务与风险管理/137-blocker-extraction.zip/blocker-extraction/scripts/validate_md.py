#!/usr/bin/env python3
"""validate_md.py for skill #137 blocker-extraction (n350-coordination-v1.1.1)

Validates Markdown analysis reports. For CSV validation, use validate_csv.py.

Usage:
    python scripts/validate_md.py <output.md> [--strict]
"""
import re, sys
from pathlib import Path

SCHEMA = "n350-coordination-v1.1.1 / #137 blocker-extraction"
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}

REQUIRED_HEADINGS = [
    ("metadata",           re.compile(r"##\s*\d*\.?\s*Metadata|^```yaml[\s\S]*?\bmetadata:\b", re.I | re.MULTILINE)),
    ("escalation_summary", re.compile(r"##\s*\d*\.?\s*[^\n]*?(Escalation|升级路径)", re.I)),
    ("downstream_handoff", re.compile(r"##\s*\d*\.?\s*[^\n]*?(Downstream [Hh]andoff|下游交接)", re.I)),
]


def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0


def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_md.py <output.md> [--strict]"); return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists(): return fail(f"file not found: {path}")
    text = path.read_text(encoding="utf-8")
    errors = 0; warnings = 0

    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    if _is_example and _has_any_heading:
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness '{_rm.group(1)}' not in {VALID_READINESS}"); return 1
        return ok(f"{SCHEMA} example validation passed (light-check mode)")

    found = {}
    for key, pat in REQUIRED_HEADINGS:
        m = pat.search(text)
        if m: found[key] = m.start()
        else: print(f"[FAIL] missing section: {key}"); errors += 1

    # AP-2: unblock_action completeness check
    unblock_actions = re.findall(r"unblock_action[:\s]+([^\n|]{10,})", text)
    for ua in unblock_actions:
        if len(ua.strip()) < 15:
            warn(f"unblock_action may be incomplete (< 15 chars): {ua.strip()[:40]}"); warnings += 1

    # Downstream handoff fields
    if "downstream_handoff" in found:
        snippet = text[found["downstream_handoff"]:found["downstream_handoff"]+500]
        if "open_blockers" not in snippet and "related_blocker" not in snippet:
            warn("downstream_handoff missing open_blockers/related_blocker_ids → #138"); warnings += 1
        if "readiness" not in snippet:
            print("[FAIL] downstream_handoff missing readiness field"); errors += 1

    rm = re.search(r"readiness:\s*([\w]+)", text)
    if rm and rm.group(1) not in VALID_READINESS:
        print(f"[FAIL] readiness '{rm.group(1)}' not in {VALID_READINESS}"); errors += 1

    if errors > 0: return fail(f"{SCHEMA} FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} passed — {warnings} warning(s)")


if __name__ == "__main__":
    raise SystemExit(main())
