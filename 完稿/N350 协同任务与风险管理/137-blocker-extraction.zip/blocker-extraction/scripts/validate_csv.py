#!/usr/bin/env python3
"""validate_csv.py for skill #137 blocker-extraction (n350-coordination-v1.1.1)

Validates the blocker register CSV for schema conformance, business rule
compliance, and mode-specific constraints.

Usage:
    python scripts/validate_csv.py <blockers.csv> [--mode <mode>] [--strict]
"""
import csv, sys, re
from pathlib import Path

SCHEMA_NAME = "n350-coordination-v1.1.1 / #137 blocker-extraction"
EXPECTED_HEADERS = [
    "blocker_id", "title", "affected_task_ids", "blocker_type",
    "severity", "owner", "evidence_ref", "impact_summary",
    "unblock_action", "escalation_path", "status"
]
REQUIRED_FIELDS = {
    "blocker_id", "title", "blocker_type", "severity",
    "owner", "evidence_ref", "impact_summary", "status"
}
LIST_FIELDS = {"affected_task_ids", "evidence_ref", "escalation_path"}
ALLOWED_BLOCKER_TYPE = {
    "dependency", "decision", "resource", "technical",
    "external", "compliance", "other"
}
ALLOWED_SEVERITY = {"low", "medium", "high"}
ALLOWED_STATUS = {"OPEN", "MONITORING", "RESOLVED", "PENDING_CONFIRMATION"}

# AP-2: unblock_action three-element check keywords
UNBLOCK_ACTOR_PATTERNS = [
    r"\b(owner|eng-lead|pm|qa-lead|team|squad|ops|DBA|[A-Z][a-z]+-team)\b",
]
UNBLOCK_TIME_PATTERNS = [
    r"\b(\d{4}-\d{2}-\d{2}|W\d{2}|sprint-\d+|by\s+\w+|EOD|EOW|ASAP|within \d+ day)\b",
]


def fail(msg):
    print(f"[FAIL] {msg}")
    return 1


def warn(msg):
    print(f"[WARN] {msg}")


def ok(msg):
    print(f"[OK]   {msg}")
    return 0


def check_unblock_action_three_elements(row_idx, unblock_action):
    """AP-2: unblock_action must have Actor + Specific action + Time target."""
    if not unblock_action.strip():
        return fail(f"row {row_idx}: unblock_action is empty — set status to PENDING_CONFIRMATION")
    
    # Heuristic: action must be > 10 chars (not just a placeholder)
    if len(unblock_action.strip()) < 12:
        return fail(f"row {row_idx}: unblock_action too short (< 12 chars) — "
                    f"must include Actor + Specific action + Time target")
    
    # Check for time target
    has_time = any(re.search(p, unblock_action, re.I) for p in UNBLOCK_TIME_PATTERNS)
    if not has_time and "待确认" not in unblock_action and "TBD" not in unblock_action.upper():
        warn(f"row {row_idx}: unblock_action may be missing Time target — "
             f"consider PENDING_CONFIRMATION if incomplete")
    return 0


def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_csv.py <blockers.csv> [--mode <mode>] [--strict]")
        return 2

    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv

    # Mode detection
    mode = None
    if "--mode" in sys.argv:
        idx = sys.argv.index("--mode")
        if idx + 1 < len(sys.argv):
            mode = sys.argv[idx + 1]

    if not path.exists():
        return fail(f"file not found: {path}")

    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        headers = list(reader.fieldnames or [])
        if headers != EXPECTED_HEADERS:
            return fail(
                f"header mismatch.\n"
                f"  expected: {EXPECTED_HEADERS}\n"
                f"  got:      {headers}"
            )
        rows = list(reader)

    if not rows:
        return fail("CSV has no data rows")

    errors = 0
    warnings = 0
    seen_ids = set()

    for idx, row in enumerate(rows, start=2):
        # Required fields
        for field in REQUIRED_FIELDS:
            if not (row.get(field) or "").strip():
                errors += fail(f"row {idx}: missing required field: {field}")

        # List field separator
        for field in LIST_FIELDS:
            val = (row.get(field) or "").strip()
            if "," in val:
                errors += fail(
                    f"row {idx}: field '{field}' must use '|' not ',' for multi-values"
                )

        # Duplicate ID check
        bid = (row.get("blocker_id") or "").strip()
        if bid in seen_ids:
            errors += fail(f"row {idx}: duplicate blocker_id: {bid}")
        seen_ids.add(bid)

        # Enum checks
        blocker_type = (row.get("blocker_type") or "").strip()
        if blocker_type not in ALLOWED_BLOCKER_TYPE:
            errors += fail(
                f"row {idx}: invalid blocker_type '{blocker_type}' "
                f"— allowed: {sorted(ALLOWED_BLOCKER_TYPE)}"
            )

        severity = (row.get("severity") or "").strip()
        if severity not in ALLOWED_SEVERITY:
            errors += fail(
                f"row {idx}: invalid severity '{severity}' "
                f"— allowed: {sorted(ALLOWED_SEVERITY)}"
            )

        status = (row.get("status") or "").strip()
        if status not in ALLOWED_STATUS:
            errors += fail(
                f"row {idx}: invalid status '{status}' "
                f"— allowed: {sorted(ALLOWED_STATUS)}"
            )

        # AP-2: unblock_action three-element check
        unblock_action = (row.get("unblock_action") or "").strip()
        if status == "OPEN" and not unblock_action:
            errors += fail(
                f"row {idx}: OPEN blocker missing unblock_action — "
                f"set to PENDING_CONFIRMATION if unblock path is unknown"
            )
        elif unblock_action:
            r = check_unblock_action_three_elements(idx, unblock_action)
            errors += r

        # AP-3: RESOLVED items should not have active escalation_path
        if status == "RESOLVED":
            escalation = (row.get("escalation_path") or "").strip()
            if escalation and escalation.lower() not in {"none", "n/a", "resolved", "—", "-"}:
                warn(
                    f"row {idx}: RESOLVED blocker still has escalation_path '{escalation[:40]}' "
                    f"— consider clearing it"
                )
                warnings += 1

        # AP-4: escalation_ready mode — no new rows should appear
        # (checked at aggregate level after loop)

        # Evidence ref should not be placeholder URLs
        evidence = (row.get("evidence_ref") or "").strip()
        if re.search(r"example\.com|placeholder|dummy", evidence, re.I):
            errors += fail(
                f"row {idx}: evidence_ref appears to be a placeholder URL "
                f"— use '待核对' instead of fake links"
            )

    # AP-4: escalation_ready mode check
    if mode == "escalation_ready_blocker_list":
        # In this mode, output rows must be a subset of OPEN rows with escalation_status=ready
        # Heuristic: no row should have status=OPEN without an escalation_path
        open_without_escalation = [
            r["blocker_id"] for r in rows
            if (r.get("status") or "").strip() == "OPEN"
            and not (r.get("escalation_path") or "").strip()
        ]
        if open_without_escalation:
            errors += fail(
                f"escalation_ready_blocker_list mode: {len(open_without_escalation)} OPEN rows "
                f"missing escalation_path: {open_without_escalation}"
            )

    if errors > 0:
        return fail(
            f"{SCHEMA_NAME} validation FAILED — "
            f"{errors} error(s), {warnings} warning(s) in {len(rows)} rows"
        )
    return ok(
        f"{SCHEMA_NAME} validation passed — "
        f"{len(rows)} rows, {warnings} warning(s)"
    )


if __name__ == "__main__":
    raise SystemExit(main())
