# failure-modes

Common failure modes in incident-response incident response skills and how to handle them.

## FM01: RCA not available (no root cause identified)
- **Symptom:** `root-cause-analysis-recommendation` output not provided to incident-response.
- **Impact:** incident-response skills must operate from symptom evidence alone.
- **Handling:** Mark `evidence_profile.rca_available: false`. Use `confidence: low` on all hypothesis-dependent decisions. Still produce artifact.

## FM02: Rollback evidence absent
- **Symptom:** No rollback plan or rollback procedure provided.
- **Impact:** Hotfix-risk-assessment cannot confirm rollback safety (hard blocker).
- **Handling:** Mark `rollback_evidence: absent`. Add as mandatory blocker in `hotfix-risk-assessment`. Do not issue `go` without rollback evidence.

## FM03: Compliance branch activation
- **Symptom:** `event_type_branch` is or includes `compliance` or `data_consistency`.
- **Impact:** Standard mandatory→signoff_required demotion rules are restricted (see hotfix-risk-assessment demotion table).
- **Handling:** `rollback_evidence` and `compliance_exposure` checklist items remain mandatory. No demotion allowed.

## FM04: All fix paths blocked
- **Symptom:** Every `remediation_options[]` item evaluates to `no_go`.
- **Impact:** No automated fix path available.
- **Handling:** `containment_only` is always at least `conditional`. Escalate to engineering-director. Apply bridge SLA.

## FM05: Incident active > 4h without resolution
- **Symptom:** MTTR exceeds 4h threshold.
- **Impact:** Original `response_sequence[]` is stale.
- **Handling:** Apply rolling response sequence update (see on-call-response-recommendation MTTR extended protocol).

## FM06: Circuit breaker triggered
- **Symptom:** Skill re-invoked ≥ 3 times without resolving readiness.
- **Impact:** Further re-generation will not resolve the issue.
- **Handling:** Stop regeneration. Emit `readiness: red`. Escalate to release-manager. Require new evidence before reset.


---

## Degradation examples — amber/red full set

### readiness: amber — 有 diff 但无 RCA，mandatory_unknown 仍高

```yaml
metadata:
  readiness: amber
  selected_mode: rapid_hotfix_gate
evidence_profile:
  confirmed: [fix_diff, service_context]
  missing_evidence: [rca_output, compliance_sign_off, rollback_plan]
  confidence_ceiling_applied: low
go_no_go_recommendation:
  verdict: conditional_go
  mandatory_passed: 1   # code_change_risk assessed from diff
  mandatory_failed: 0
  mandatory_unknown: 2  # compliance_exposure, rollback_evidence
  conditions:
    - item: "Confirm rollback plan exists before deploying"
      owner: sre-oncall
      due: "T-15min"
self_check:
  passed: true
  warnings:
    - "amber — 2 mandatory gates unknown; conditional_go only"
    - "Provide RCA and rollback plan to reach definitive verdict"
```

### readiness: red — compliance gate failed, no_go mandatory

```yaml
metadata:
  readiness: red
go_no_go_recommendation:
  verdict: no_go
  mandatory_failed: 1
  failed_gates:
    - gate: compliance_exposure
      reason: "Fix touches PII data path without DPO sign-off"
      demotable: false
      action: block_release
self_check:
  passed: false
  failed_rules: ["SCR-HOTFIXRI-051: compliance_exposure mandatory gate failed — verdict must be no_go"]
```