# incident-response Handoff Contract

## Shared fields
Every incident-response output should expose:
- `incident_id`
- `source_time_window`
- `service_scope`
- `event_type_branch`
- `readiness`
- `evidence_profile`
- `open_blockers[]`
- `owner_placeholders[]`
- `evidence_refs[]`
- `downstream_handoff[]`

## 120 -> 121
`on-call-response-recommendation` hands off:
- tier recommendation
- incident snapshot
- primary event type
- containment already attempted
- temporary restrictions, feature flags, kill switches, or traffic controls
- escalation and signoff context
- unresolved blockers and next checks

## 121 -> 122
`remediation-plan-recommendation` hands off:
- selected remediation path
- whether hotfix is recommended
- selected candidate scope
- expected diff surface
- rollback assumptions
- regression minimums
- approvals required
- rejected alternatives and rationale

## 122 -> 120 / 121
`hotfix-risk-assessment` can hand back:
- no_go blockers that require a safer remediation path
- conditional_go guardrails that affect on-call communication or containment
- rollout and rollback conditions that response teams must monitor

## incident-response downstream handoff
- to release or delivery work when emergency release, rollback, or patch execution is approved.
- to postmortem work when response decisions, blockers, and risk tradeoffs should be preserved.
