# readiness-inheritance-incident-response

How readiness propagates between incident-response skills and from ops-runtime → incident-response.

## ops-runtime → incident-response inheritance rules
| ops-runtime upstream | incident-response consumer | Inherited fields |
|---|---|---|
| `alert-attribution` | All incident-response | `incident_id`, `event_type_branch` (mapped), `source_time_window`, `service_scope` |
| `impact-scope-analysis` | `on-call-response-recommendation`, `hotfix-risk-assessment` | `blast_radius`, `affected_users_estimate`, `slo_status` |
| `root-cause-analysis-recommendation` | `remediation-plan-recommendation` | `recommended_root_cause`, `accepted_hypotheses`, `evidence_chain` |
| `bug-analysis` | `hotfix-risk-assessment` | `immediate_actions`, `accepted_risk_level` |

## incident-response internal sequencing
`on-call-response-recommendation` (121) → `remediation-plan-recommendation` (122) → `hotfix-risk-assessment` (120)

- 121 consumes ops-runtime evidence and issues initial containment + tier classification
- 122 consumes 121 `containment_state` + ops-runtime RCA and recommends fix path
- 120 consumes 122 `selected_path` and evaluates hotfix-specific risk gate

## Readiness escalation rules
- If upstream ops-runtime readiness is `red`, incident-response skill must record `upstream_gap: true` and cap own confidence at `low`
- If incident-response skill readiness is `red`, it must emit `exception.incident-response.response_blocked` before halting
- A `conditional_go` verdict from 120 or 122 must include explicit conditions with owner + SLA

## Circuit breaker
- Max iterations: 3 per incident_id per incident-response skill
- Cooldown: PT20M after circuit fires
- Reset: only when new ops-runtime evidence arrives with updated `incident_id` or extended `source_time_window`
