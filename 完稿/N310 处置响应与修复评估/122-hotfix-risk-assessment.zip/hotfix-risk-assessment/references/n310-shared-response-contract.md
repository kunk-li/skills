# N310 Shared Response Contract

contract_version: n310-response-v1.0.0
workflow_node: N310
node_goal: produce incident response, remediation planning, and hotfix-risk artifacts that are each useful alone and stronger together.

This contract is packaged inside each N310 skill. No files, scripts, directories, or services outside the skill package are required.

## Encapsulation governance
Each N310 skill is self-contained. Use only the current skill package, user-provided inputs, and artifacts explicitly supplied in the conversation. Do not require node-level folders, external tools, hidden registries, or sibling skill files.

## Shared artifact anchors
Every N310 output should expose these fields when possible:
- `contract_version: n310-response-v1.0.0`
- `workflow_node: N310`
- `incident_id`
- `source_time_window`
- `service_scope`
- `event_type_branch`
- `readiness`
- `evidence_profile`
- `confidence`
- `open_blockers[]`
- `owner_placeholders[]`
- `evidence_refs[]`
- `downstream_handoff[]`

## Standalone guarantee
- A skill must run with its own minimum viable input and no sibling artifacts.
- A skill must produce its target artifact with stable required sections even when readiness is partial.
- A skill must list missing evidence and next best checks rather than blocking on unavailable sibling signals.
- If an upstream artifact is absent, use the available incident evidence and mark assumptions explicitly.

## Composition guarantee
- A skill must emit `downstream_handoff[]` records that later N310 skills or downstream delivery/review work can consume.
- A composed run must join artifacts by `incident_id`, `source_time_window`, `service_scope`, `event_type_branch`, and `evidence_refs`.
- Later skills must cite earlier artifacts instead of redoing their analysis.
- Conflicting evidence must remain visible with confidence labels.
- Composition guidance lives in this contract and in each skill's `Standalone and composition role` block; no external composition matrix is required.

## Standard N310 composition paths
### Response-first
on-call-response-recommendation -> remediation-plan-recommendation -> hotfix-risk-assessment
Use when the incident is active and the team first needs safe command, containment, escalation, and audit actions.

### Remediation-first
remediation-plan-recommendation -> hotfix-risk-assessment -> on-call-response-recommendation
Use when a candidate fix or RCA already exists and the main question is how to correct safely, then update live response guidance.

### Hotfix-gate-first
hotfix-risk-assessment -> remediation-plan-recommendation -> on-call-response-recommendation
Use when someone proposes an emergency patch before the remediation tradeoff is mature; gate risk first, then refine the fix path and response communication.

### Containment-only
on-call-response-recommendation
Use when evidence is too weak or risk is too high for remediation decisions; stabilize first and emit blockers for later planning.

## Handoff record schema
Each downstream handoff item should include:
- `handoff_id`
- `producer_skill`
- `consumer_skill_or_node`
- `artifact_target`
- `incident_id`
- `event_type_branch`
- `source_time_window`
- `service_scope`
- `required_fields[]`
- `evidence_refs[]`
- `open_blockers[]`
- `confidence`
- `next_best_checks[]`

## Readiness values
Use one readiness value:
- `ready`: enough evidence to act.
- `partial`: usable output, but assumptions or blockers remain.
- `blocked`: not enough information to safely recommend action; still emit missing evidence and next checks.

## Evidence profile values
Use one or more values:
- `direct_observability`
- `operator_report`
- `root_cause_hypothesis`
- `impact_estimate`
- `change_evidence`
- `rollback_evidence`
- `regression_evidence`
- `assumption_only`

## Self-check
Before finalizing any N310 artifact, verify:
- the output stays inside the current skill boundary.
- the contract_version is exactly `n310-response-v1.0.0`.
- the artifact can stand alone without sibling skill outputs.
- downstream_handoff is present when another skill or downstream node can consume the result.
- missing evidence is explicit and not hidden as certainty.
- owner names are not invented; use owner_role or owner_placeholders.
