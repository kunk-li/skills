# N310 Quality Checklist

Before finalizing:
- Keep the result inside the current N310 skill boundary.
- Ensure the output can stand alone with the supplied evidence.
- Make the decision path auditable.
- Prefer quantitative thresholds over prose-only judgment.
- Surface blockers explicitly.
- Preserve owner placeholders instead of inventing names.
- Emit downstream_handoff when another skill or downstream workflow can consume the result.
- Do not require files, scripts, directories, or services outside the skill package.
