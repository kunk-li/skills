# incident-response Quality Checklist

Before finalizing:
- Keep the result inside the current incident-response skill boundary.
- Ensure the output can stand alone with the supplied evidence.
- Make the decision path auditable.
- Prefer quantitative thresholds over prose-only judgment.
- Surface blockers explicitly.
- Preserve owner placeholders instead of inventing names.
- Emit downstream_handoff when another skill or downstream workflow can consume the result.
- Do not require files, scripts, directories, or services outside the skill package.


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-HOTFIXRI-052 | `event_type_branch` ∈ {regression_hotfix, dependency_hotfix, config_hotfix, code_hotfix} | enum check | `self_check.warnings: ["SCR-HOTFIXRI-052: event_type_branch missing or invalid"]` |
| SCR-HOTFIXRI-053 | `mandatory_passed + mandatory_failed + mandatory_unknown = 6` | sum check | `self_check.failed_rules: ["SCR-HOTFIXRI-053: mandatory gate totals don't sum to 6"]` |
| SCR-HOTFIXRI-054 | `verdict: go` requires `mandatory_failed = 0` AND `mandatory_unknown = 0` | conditional | `self_check.failed_rules: ["SCR-HOTFIXRI-054: GO issued with unresolved mandatory gates"]` |
| SCR-HOTFIXRI-055 | `adversarial_detection.injection_attempt_detected` boolean declared | key exists | `self_check.warnings: ["SCR-HOTFIXRI-055: injection_detected field missing"]` |
| SCR-HOTFIXRI-056 | `feedback_signal_candidates` ≥ 1 with `signal_type` declared | key check | `self_check.warnings: ["SCR-HOTFIXRI-056: FSC missing signal_type"]` |