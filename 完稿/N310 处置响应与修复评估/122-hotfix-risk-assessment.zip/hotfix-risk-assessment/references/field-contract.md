# field-contract-incident-response

Canonical field definitions for all incident-response response skill artifacts.

## Core metadata fields
| Field | Type | Required | Description |
|---|---|---|---|
| `contract_version` | string | yes | Must be `incident-response-response-v1.0.0` |
| `artifact_schema_name` | string | yes | Unique schema name for this incident-response skill |
| `artifact_schema_version` | string | yes | Semver matching the skill package |
| `artifact_type` | string | yes | Snake_case type: `hotfix_risk_assessment`, `on_call_response_recommendation`, `remediation_plan_recommendation` |
| `workflow_node` | string | yes | Always `incident-response` |
| `skill_id` | string/int | yes | Canonical skill number: `120`, `121`, or `122` |
| `selected_mode` | string | yes | One of the declared allowed modes for this skill |
| `readiness` | enum | yes | `green` / `amber` / `red` / `partial` |
| `incident_id` | string | yes | Stable identifier; preserved from ops-runtime upstream |
| `event_type_branch` | enum | yes | `availability` / `performance` / `data_consistency` / `compliance` / `unknown` |
| `source_time_window` | object | yes | `start` (iso8601), `end` (iso8601) |
| `service_scope` | string[] | yes | Affected services |
| `evidence_profile` | object | yes | `confirmed`, `assumed`, `missing_evidence`, `missing_evidence_impact` |
| `confidence` | enum | yes | `high` / `medium` / `low` / `speculative` |

## go_no_go / verdict fields
| Field | Type | Required | Description |
|---|---|---|---|
| `verdict` | enum | yes | `go` / `conditional_go` / `no_go` |
| `condition` | string | conditional | Required when verdict is `conditional_go` |
| `reason` | string | yes | Explicit rationale citing evidence |
| `blocker_if_failed` | boolean | yes | Whether this is a hard blocker |

## Downstream handoff fields (incident-response → release-prep/release-exec/release-validation)
| Field | Type | Required | Description |
|---|---|---|---|
| `handoff_type` | enum | yes | `risk` / `recommendation` / `escalation` / `rollback_trigger` / `evidence` |
| `target` | string | yes | Target node or skill |
| `required_fields` | string[] | yes | Fields the receiver must consume |
| `confidence` | enum | yes | Confidence of this handoff entry |
| `urgency` | enum | yes | `immediate` / `deferred` / `monitor_only` |

## Confidence-to-evidence mapping (incident-response context)
| Available evidence | Max confidence |
|---|---|
| Symptom description only | `speculative` |
| One ops-runtime artifact (any) | `low` |
| Two ops-runtime artifacts (consistent) | `medium` |
| Three+ ops-runtime artifacts + operator confirmation | `high` |

## Event type branch field definitions
| Branch | Trigger condition | Key checklist items |
|---|---|---|
| `availability` | Service down, error rate > threshold, SLO burn critical | Rollback readiness, blast radius, P0 PRV active probes |
| `performance` | Latency spike, throughput drop, queue build-up | Saturation point, auto-scaling, cache coherence |
| `data_consistency` | Data corruption, sync lag, divergent state | Data migration safety, dual-write risk, reconciliation plan |
| `compliance` | PII exposure, audit log gap, regulatory boundary breach | Legal review, data deletion scope, notification SLA |
| `unknown` | Cannot classify from available evidence | Conservative defaults, all mandatory items enforced |


---

## Field contract — mandatory_gate entry

| Field | Required | Values / notes |
|---|---|---|
| `gate_id` | yes | `GATE-HF-{NNN}` format |
| `gate_name` | yes | descriptive string |
| `status` | yes | ∈ {pass, fail, unknown, conditional} |
| `evidence` | if pass/conditional | artifact reference or measurement |
| `missing_evidence` | if unknown | why gate can't be evaluated |
| `demotable` | yes | boolean; false = mandatory block |

---

## Low-evidence checklist: mandatory → signoff_required demotion rules
When evidence is insufficient to verify a `mandatory` checklist item, apply these demotion rules. Demotion is **not automatic** — it requires explicit justification per item:

| Checklist control_area | Can demote mandatory → signoff_required? | Demotion condition | Cannot demote if |
|---|---|---|---|
| regression_confidence | Yes | "No test environment available; SRE signs off on deploy safety" | Compliance or data_consistency event_type_branch is active |
| diff_surface_review | Yes | "Diff reviewed by senior engineer — formal tool scan unavailable" | diff_surface > 200 lines changed |
| rollback_evidence | **No** | Never demotion — rollback evidence is a hard mandatory | Any condition |
| compliance_exposure | **No** | Never demotion — compliance items cannot be signed off without legal review | Any condition |
| signoff_owner | Yes | "Primary owner unavailable; backup approver confirmed" | No backup approver identified |
| canary_plan | Yes | "Canary skipped — blast radius < 1 service, traffic < 5k RPM" | Multi-service or stateful change |

**Demotion YAML pattern:**
```yaml
per_type_checklist:
  - checklist_id: CHK-003
    control_area: regression_confidence
    requirement_level: signoff_required   # demoted from mandatory
    demotion_applied: true
    demotion_justification: "No staging environment available for this hotfix window. SRE lead will sign off based on code review and diff scope review."
    demotion_approver: sre-lead
    blocker_if_failed: false   # signoff_required — not a hard blocker
    can_be_deferred: false
```

**Hard rule:** `rollback_evidence` and `compliance_exposure` items must **never** be demoted. If they cannot be verified, the checklist item remains `mandatory` and its `blocker_if_failed: true` forces `no_go`.

