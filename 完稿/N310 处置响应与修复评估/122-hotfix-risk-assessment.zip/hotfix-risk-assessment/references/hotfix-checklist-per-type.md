# Hotfix Checklist Per Event Type

## compliance
Focus on signoff, audit evidence, blast radius, policy compatibility, data protection, and rollback safety.

## performance
Focus on traffic shaping, baseline comparisons, capacity guardrails, canary health, latency SLOs, and rollback speed.

## availability
Focus on restoration speed, health probes, dependency reachability, rollback, communications, and user-impact monitoring.

## data_consistency
Focus on write protection, reconciliation plan, irreversible data risk, replay behavior, idempotency, and rollback window.
