## Contract evolution and version upgrade path
This skill's contract is `incident-response-response-v1.0.0`. Change rules:

### Patch: new real-examples, SCR rules, field contract clarifications.
### Minor (v1.0 → v1.1): new optional fields. Coordinated across all 3 incident-response skills.
### Major (v1.0 → v2.0): breaking changes. All 3 skills updated together; migration guide required.

**Trigger for minor bump:** A new `event_type_branch` (e.g., `ai_model_degradation`) needs to be added.
**Trigger for major bump:** `downstream_handoff` schema changes break 121→122 handoff.

### Cross-skill coordination requirement
All 3 incident-response skills share `references/incident-response-shared-contract.md`. Any schema change must:
1. Update the shared contract first
2. Update all 3 SKILL.md files together
3. Update all 3 `validate_artifact.py` scripts together
4. Add a migration note to `references/incident-response-shared-contract.md`


---

## Maintenance playbook — concrete upgrade examples

### WHEN to trigger a patch upgrade (examples)
- Production incident reveals a new `false_negative` pattern not covered by existing SCRs → add SCR rule + patch bump
- A `real-examples.md` scenario added that reveals a documentation gap → patch bump, no coordination needed
- A field description is ambiguous and causes wrong output → clarify description + patch bump
- `validate_artifact.py` misses a common error → fix check + patch bump

### WHEN to trigger a minor upgrade (examples)
- A new observability platform (e.g., OpenTelemetry Metrics) requires a new `evidence_profile` enum value
- A new cloud region introduces a new `environment_scope` value (e.g., `sovereign_cloud`)
- A new deployment model (e.g., WASM edge) requires a new `automation_level` value
- A new compliance regime requires a new `compliance_scope` enum

### WHEN to trigger a major upgrade (examples)
- The `downstream_handoff` schema changes in a breaking way (e.g., `handoff_type` enum renamed)
- A required metadata field is renamed across all artifacts in the node
- The `confidence_ceiling_rule` semantics fundamentally change

### Upgrade verification checklist
Before releasing any version bump, verify:
- [ ] `schema_version` updated in SKILL.md metadata
- [ ] `output-contract.yaml` updated to match
- [ ] All `real-examples.md` examples pass `validate_artifact.py --strict`
- [ ] `feedback_signal_candidates` from the triggering incident are marked `status: resolved`
- [ ] Downstream consumers notified (via `downstream_handoff.refresh_triggers`)
- [ ] For minor+: all sibling skills in the same node are updated together
- [ ] For major: migration guide added to `references/` and dual-read window opened

### Rollback compatibility test
```bash
# Before releasing, verify backward compatibility:
python scripts/validate_artifact.py old_artifact_v{previous}.md
# Must pass without errors on the new validator
```


---

## Maintenance — consumer impact notification protocol

### When a change affects downstream consumers
Any patch, minor, or major version bump that changes fields consumed by other skills must follow this protocol:

```yaml
consumer_impact_assessment:
  changed_field: "downstream_handoff.handoff_type enum"
  impact_level: minor       # patch | minor | major
  affected_consumers:
    - skill: release-task-orchestration
      field_consumed: downstream_handoff.handoff_type
      impact: "New enum value 'action_hint' added — backward compatible"
      action_required: false
    - skill: monitoring-metric-interpretation
      field_consumed: evidence_refs
      impact: "No change"
      action_required: false
  notification_method: downstream_handoff.refresh_triggers
  notification_timing: "Before packaging; after testing"
```

### Deprecation timeline protocol
When deprecating a field or mode:

```yaml
deprecation_protocol:
  announcement_in: "Current release SKILL.md — add deprecation note"
  deprecated_since: "v2.5.0"
  replacement: "new_field_name"
  dual_emit_until: "v2.7.0"   # emit both old and new for 2 minor versions
  remove_after: "v3.0.0"
  consumer_migration_guide: |
    # Consumers of old_field_name should migrate to new_field_name:
    # old: downstream_handoff.old_field_name
    # new: downstream_handoff.new_field_name
    # Both fields available in v2.5.0–v2.6.x; old_field removed in v3.0.0
```

### Breaking change notification checklist
Before releasing any change that removes or renames a required field:
- [ ] List all downstream skills that consume this field
- [ ] Open migration tracking issue for each affected consumer
- [ ] Add `deprecated_since` + `remove_after` to the field's documentation
- [ ] Emit both old and new field names for the dual-read window duration
- [ ] Update `references/readiness-inheritance.md` with migration notes
- [ ] Coordinate release timing so consumers update before the field is removed


---

## Contract evolution and version upgrade path
See `references/maintenance.md` for full specification.

