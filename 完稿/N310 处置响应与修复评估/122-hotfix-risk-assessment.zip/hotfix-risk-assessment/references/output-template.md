# N310 Output Template

## Recommended metadata block
- `contract_version`
- `workflow_node`
- `skill_id`
- `selected_mode`
- `readiness`
- `incident_id`
- `source_time_window`
- `service_scope`
- `event_type_branch`
- `evidence_profile`
- `confidence`
- `node_artifact_target`
- `function_bias`
- `stage_position`
- `composition_role`

## Evidence discipline
Always separate:
- direct evidence
- inference
- assumption
- blocker or missing input

## Handoff discipline
When another N310 skill can use the result, include `downstream_handoff[]` with required fields, evidence_refs, open blockers, and next best checks.
