# incident-response Output Template

## Recommended metadata block
- `contract_version`
- `workflow_node`
- `skill_id`
- `selected_mode`
- `readiness`
- `incident_id`
- `source_time_window`
- `service_scope`
- `event_type_branch`
- `evidence_profile`
- `confidence`
- `node_artifact_target`
- `function_bias`
- `stage_position`
- `composition_role`

## Evidence discipline
Always separate:
- direct evidence
- inference
- assumption
- blocker or missing input

## Handoff discipline
When another incident-response skill can use the result, include `downstream_handoff[]` with required fields, evidence_refs, open blockers, and next best checks.


---

## Downstream handoff YAML templates

### 正常路径: verdict=conditional_go → release-task-orchestration
```yaml
downstream_handoff:
  produced_by: hotfix-risk-assessment
  artifact: 热修复风险评估.md
  emit_event:
    event_name: produced.incident-response.hotfix_risk_assessment.v2
  handoffs:
    - target: release-task-orchestration
      handoff_type: evidence
      summary: "verdict: conditional_go. 3 mandatory passed, 0 failed. Conditions: DBA sign-off due T-30min."
      required_fields:
        - go_no_go_recommendation.verdict
        - go_no_go_recommendation.conditions
        - hotfix_candidate_summary.services_affected
      confidence: medium
      next_best_checks:
        - "108: add DBA approval gate before P3 execution"
        - "108: wire rollback triggers from rollback-plan-generation"
    - target: on-call-response-recommendation
      handoff_type: routing
      summary: "Hotfix authorized — coordinate deployment with oncall lead"
      confidence: medium
```

### 阻断路径: verdict=no_go
```yaml
downstream_handoff:
  handoffs:
    - target: remediation-plan-recommendation
      handoff_type: gap
      summary: "BLOCKER: compliance gate failed. Reconsider fix path."
      blocking: true
      required_fields: [go_no_go_recommendation.failed_gates]
```


---

## Output completeness rule
Every hotfix-risk-assessment artifact MUST include ALL of:
- `hotfix_candidate_summary` with change scope and affected components
- `go_no_go_recommendation.verdict` ∈ {go, no_go, conditional_go}
- `go_no_go_recommendation.mandatory_passed` + `mandatory_failed` + `mandatory_unknown` integers summing to 6
- `mandatory_gates[]` with ALL 6 gates, each with ALL 6 fields above
- `event_type_branch` ∈ {regression_hotfix, dependency_hotfix, config_hotfix, code_hotfix}
- `adversarial_detection.injection_attempt_detected` boolean
- `downstream_handoff` typed to ≥ 1 target
- `feedback_signal_candidates` ≥ 1 entry
- `consumer_impact_assessment` present
**Hard rule:** `verdict: go` requires `mandatory_failed: 0` AND `mandatory_unknown: 0`

---

## Mode selection

### New: `regression_hotfix` mode — 回归问题热修复评估
**Trigger:** Hotfix is a revert of a recent change that caused regression, or user says "we need to revert commit X that broke prod."

```yaml
regression_hotfix:
  regression_source:
    commit_ref: "abc123"
    deployed_at: "2026-05-20T14:15:00Z"
    time_since_deploy: 47m
  revert_safety:
    schema_migration_involved: false
    data_written_since_deploy:
      estimate: 127_records
      impact_if_reverted: "127 new orders will lose payment_method field — must forward-fix"
    revert_mechanism: "git revert abc123 — clean revert possible"
  mandatory_gate_shortcut:
    compliance_exposure: pass  # revert restores compliant state
    rollback_evidence: confirmed  # revert IS the rollback
    code_change_risk: low  # reverting known-good code
  verdict_fast_path:
    eligible: true
    reason: "Clean revert of recent change with known-good baseline"
    recommended_verdict: conditional_go
    condition: "Confirm 127 records forward-fix plan before deploying"
```
**SCR:** `selected_mode: regression_hotfix` → `regression_hotfix.revert_safety.data_written_since_deploy` declared; `verdict_fast_path.eligible` boolean present.

### New: `dependency_hotfix` mode — 依赖项漏洞热修复
**Trigger:** CVE or security vulnerability in a dependency requires emergency patch, or user says "we need to update library X due to CVE-YYYY-NNNN."

```yaml
dependency_hotfix:
  cve_reference: "CVE-2026-12345"
  cvss_score: 9.1
  cvss_severity: critical
  affected_dependency: "payment-gateway-sdk v3.2.1"
  fix_version: "payment-gateway-sdk v3.2.2"
  patch_type: dependency_bump_only  # no code changes
  security_assessment:
    attack_vector: network
    exploitability: high
    fix_verification: "v3.2.2 changelog confirms CVE patched"
    regression_risk: low  # patch-level bump only
  mandatory_gate_override:
    compliance_exposure: auto_pass_if_cve_critical  # CVE fix IS compliance
    note: "CVSS ≥ 9.0 — compliance gate auto-cleared for security patch"
  recommended_verdict: conditional_go
  condition: "Run smoke tests to confirm v3.2.2 API compatibility"
```
**SCR:** `selected_mode: dependency_hotfix` → `dependency_hotfix.cve_reference` declared; `cvss_score` numeric.