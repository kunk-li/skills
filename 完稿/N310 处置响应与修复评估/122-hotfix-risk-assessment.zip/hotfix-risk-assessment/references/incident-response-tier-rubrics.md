# incident-response Tier And Criticality Rubrics

## On-call tier auto-classify
Use three factors:
- `compliance_impact`: `none`, `review`, `breach`
- `user_impact`: `isolated`, `partial`, `widespread`, `systemic`
- `reversibility`: `easy`, `controlled`, `hard`, `irreversible`

Suggested score:
- compliance: none=0, review=2, breach=4
- user impact: isolated=1, partial=2, widespread=3, systemic=4
- reversibility: easy=0, controlled=1, hard=2, irreversible=3

Recommended tier:
- `Tier 0`: any compliance breach or irreversible data harm
- `Tier 1`: total score >= 7 or widespread/systemic user impact
- `Tier 2`: total score 4-6
- `Tier 3`: total score <= 3

## Remediation criticality template
Use `criticality_class`:
- `Critical`: compliance impact is not `none`, irreversible data risk exists, user impact >= 10%, or no safe rollback exists for an active incident.
- `Major`: key workflow blocked, repeated partial outage, or user impact between 1% and 10%.
- `Minor`: limited impact, safe workaround exists, and rollback or containment is easy.

## Hotfix decision bands
Compute a weighted score from 0.00 to 1.00.
- `go`: < 0.25 and no hard blocker
- `conditional_go`: 0.25-0.50 or manageable blocker with explicit mitigation
- `no_go`: > 0.50 or any hard blocker without mitigation

Hard blockers include missing rollback evidence, missing signoff owner, unresolved compliance exposure, irreversible data risk without mitigation, or absent regression minimums.
