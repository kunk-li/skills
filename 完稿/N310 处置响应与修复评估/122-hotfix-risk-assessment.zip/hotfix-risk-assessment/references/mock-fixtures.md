## Mock input fixture

```yaml
mock_input:
  source: "minimal_fix_summary"
  content: "Proposed fix: revert db.pool.max-size to 100 (config change only)"
  expected_output_shape:
    go_no_go_recommendation:
      verdict: go  # or conditional_go
    event_type_branch: present
    self_check:
      passed: true
```
