# incident-response Event Type Branches

Use exactly one primary `event_type_branch` for each recommendation. If the event spans multiple domains, name one primary branch and list secondary branches in metadata.

## compliance
Use when the incident may violate audit, authorization, privacy, regulatory, or policy constraints. Prioritize containment, evidence preservation, signoff, legal/compliance notification, and auditability.

## performance
Use when the main symptom is latency regression, throughput collapse, queue buildup, resource saturation, or degradation without clear correctness breach. Prioritize capacity, throttling, rollbackability, graceful degradation, and baseline comparison.

## availability
Use when the service or critical capability is unavailable, unstable, repeatedly failing, or producing user-visible outage. Prioritize restoration speed, blast-radius reduction, rollback, communications, and health verification.

## data_consistency
Use when the main risk involves duplicate writes, stale reads, inconsistent state propagation, lost updates, replay, incorrect state transition, or irreversible business-state corruption. Prioritize write protection, reconciliation, data safety, and reversibility.
