# feedback loop protocol — incident-response

## Retrospective integration
After each incident, compare skill output vs actual resolution outcome.

### Signal types and actions
| Signal | Trigger | Action |
|---|---|---|
| `false_positive` | Over-escalated severity or unnecessary action | Review tier rubric; calibrate |
| `false_negative` | Missed critical action or severity | Tighten SCR gate; file patch bump |
| `slow_resolution` | Skill output didn't accelerate resolution | Simplify output; add fast-track mode |
| `correct` | Output matched actual outcome | Add green-path calibration to real-examples.md |

## feedback_signal_candidates schema
```yaml
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: correct | false_positive | false_negative | slow_resolution
    description: "What to verify post-incident"
    verification_method: "Compare recommendation to actual resolution path"
    priority: P1 | P2
    status: pending
```

## Version bump triggers
- 3+ `false_negative` for same incident pattern within 90 days → patch bump
- New incident type (e.g., AI model degradation, eBPF signal) → minor bump; add Mode
- Output schema breaking change → major bump; migration guide required


---

## Feedback loop — advanced integration (v2)

### Signal-type differentiated handling

| Signal type | Immediate action | Update target |
|---|---|---|
| `false_positive` | Mark in real-examples; review confidence rules | Add calibration note to relevant SCR rule |
| `false_negative` | Document missed signal source in failure-modes.md | Add new scenario to real-examples.md |
| `missed_evidence` | Add new input tier or degradation rule | Update large-input handling thresholds |
| `wrong_confidence` | Update relevant field contract confidence rule | Review confidence_ceiling_rule |
| `slow_resolution` | Simplify the section that caused delay | Consider adding a fast-track mode |
| `correct` | Add as green-path calibration example | No version bump required |

### Postmortem auto-mapping rule
When a postmortem references an artifact from this skill:

```yaml
postmortem_integration:
  trigger: "postmortem references artifact_id from this skill"
  auto_actions:
    - action: classify_feedback_signals
      source: "postmortem.outcome vs artifact.recommendation"
      output: "feedback_signal_candidates[] with verified signal_type"
    - action: update_real_examples
      condition: "signal_type in [false_negative, correct]"
    - action: open_scr_review
      condition: "signal_type in [false_positive, wrong_confidence]"
```

### Retrospective YAML flow
```yaml
retrospective_flow:
  step_1: "Retrieve artifact from this skill for the completed release/incident"
  step_2: "Compare recommendation vs actual outcome"
  step_3:
    if_false_negative: "Add new real-examples.md scenario; file patch bump ticket"
    if_correct: "Add calibration example to real-examples.md"
    if_false_positive: "Review SCR confidence rules"
  step_4: "Mark feedback_signal_candidates[].status: verified | deferred"
```
