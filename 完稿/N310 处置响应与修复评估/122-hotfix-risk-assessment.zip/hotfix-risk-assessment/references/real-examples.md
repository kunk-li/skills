# real-examples

## Example 1: on-call-response-recommendation — minimum viable input (120)

**Scenario:** Single alert, no RCA or impact scope available.

**Input given:**
- Alert: `checkout-service HTTP 5xx rate > 5% for 3 min`
- Time: 02:14 UTC
- No root cause, no impact data

**Expected output shape:**
```yaml
selected_mode: quick_triage
readiness: partial
tier_auto_classification:
  recommended_tier: 2
  rationale: "User-visible checkout impact; no confirmed data harm or compliance breach"
event_type_branch: availability
response_sequence:
  - step_id: R1
    goal: Confirm blast radius
    action: "Check checkout error rate dashboard for affected user cohort size"
    owner_role: on-call-engineer
    timebox: 5 min
    verification_signal: "Error rate trend direction (rising / stable / falling)"
    fallback_if_unsuccessful: "Escalate to checkout-team lead"
  - step_id: R2
    goal: Attempt safe containment
    action: "Enable feature flag CHECKOUT_FALLBACK_MODE if available"
    owner_role: on-call-engineer
    timebox: 10 min
    verification_signal: "5xx rate returns to < 1%"
    fallback_if_unsuccessful: "Proceed to rollback decision — see R3"
```

**Key calibration:** Minimum input → Tier 2 (not Tier 0) unless compliance breach or irreversible data harm is confirmed. Always emit at least 3 response steps even with partial evidence.

---

## Example 2: remediation-plan-recommendation — multiple path comparison (121)

**Scenario:** DB connection pool exhaustion identified as root cause.

**Input given:**
- RCA: `db.pool.max-size` reduced from 100→20 at 14:15 UTC caused checkout failures
- On-call response: feature flag containment partially effective (50% error reduction)
- Rollback evidence: config change is reversible

**Expected output shape:**
```yaml
selected_mode: stabilize_now
decision_weight_profile:
  regulatory_impact: 0.30
  user_impact: 0.25
  rollbackability: 0.20
  implementation_scope: 0.15
  verification_cost: 0.10
remediation_options:
  - fix_id: FIX-001
    remediation_path: rollback_first_then_fix
    objective: "Revert db.pool.max-size to 100; then investigate correct production value"
    immediate_effect: "Checkout error rate returns to baseline within 1 restart cycle"
    rollback_path: "Git revert config commit; rolling restart of checkout-service"
    criticality_class: Critical
    weighted_score: 0.87
    recommended_when: "Rollback dry-run evidence exists"
  - fix_id: FIX-002
    remediation_path: hotfix
    objective: "Deploy corrected pool size as emergency config patch"
    weighted_score: 0.61
    recommended_when: "Rollback is blocked (e.g., irreversible schema change)"
selected_path_recommendation:
  selected: FIX-001
  rationale: "Highest weighted score; reversible; rollback path confirmed"
hotfix_trigger_decision:
  trigger_hotfix: false
  reason: "Rollback path preferred; hotfix not needed for config-only change"
```

---

## Example 3: hotfix-risk-assessment — multi-event-type (122)

**Scenario:** Proposed hotfix touches both availability fix AND compliance-adjacent audit log.

**Input given:**
- Proposed diff: fixes connection pool config AND adds audit log for payment events
- Primary issue: availability (checkout outage)
- Secondary concern: compliance (audit log completeness)

**Expected output shape:**
```yaml
event_type_branch: availability  # primary
metadata:
  event_type_branch_secondary: [compliance]
  note: "Secondary compliance branch requires additional checklist items"
per_type_checklist:
  # availability items
  - checklist_id: CK-AV-001
    event_type_branch: availability
    control_area: rollback_safety
    requirement_level: mandatory
    blocker_if_failed: true
  # compliance items (added due to audit log change)
  - checklist_id: CK-CO-001
    event_type_branch: compliance
    control_area: audit_completeness
    requirement_level: mandatory
    question: "Does the new audit log meet retention and tamper-evidence requirements?"
    blocker_if_failed: true
go_no_go_recommendation:
  recommendation: conditional_go
  conditions:
    - "Compliance team confirms audit log schema meets retention policy"
    - "Rollback tested in staging with audit log rollback included"
```

**Key calibration for multi-event-type:** Always declare ONE primary `event_type_branch`; list secondaries explicitly. Add checklist items for each secondary branch. A secondary compliance branch can escalate go → conditional_go or no_go even if primary branch passes.
