---
name: hotfix-risk-assessment
description: produce self-contained n310 hotfix risk assessments for emergency change go/no-go decisions, rollback safety, regression minimums, release guardrails, and approval readiness. use when given 修复方案建议.md, proposed patch scope, incident evidence, rollback evidence, or release constraints and the needed artifact is 热修复风险评估.md. this skill can run alone from a proposed fix summary and composes with on-call-response-recommendation and remediation-plan-recommendation through incident_id, event_type_branch, selected_path, service_scope, evidence_refs, and downstream_handoff.
---
# hotfix-risk-assessment

## N310 encapsulation baseline
This skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside this skill plus artifacts supplied in the conversation. Do not require node-level folders, external tools, hidden registries, or sibling skill files.

## Role positioning
This skill aligns to N310 incident response and produces `热修复风险评估.md`. It is authoritative for `emergency_change_risk_assessment_and_release_gate`.

## Scope boundary
Own:
- hotfix risk matrix
- event-type checklisting
- go/conditional_go/no_go recommendation
- rollback, rollout, regression, and approval guardrails

Do not own:
- incident-command response ordering
- durable fix path selection among non-hotfix options
- deep RCA or postmortem authorship

## Selected mode
Every result must declare `selected_mode`, `readiness`, `evidence_profile`, and `contract_version` at the top.

Allowed modes:
- `rapid_hotfix_gate`
- `event_type_checklist`
- `comprehensive_go_no_go`
- `conditional_release_guardrails`

## Standalone and composition role
```yaml
contract_version: n310-response-v1.0.0
workflow_node: N310
skill_id: '122'
artifact_target: 热修复风险评估.md
composition_role: emergency_change_gatekeeper
standalone_guarantee:
  minimum_viable_input:
  - one proposed fix summary or remediation candidate
  - rough incident description or event_type_branch
  - optional diff scope, rollback, regression, canary, signoff, or release-owner evidence
  stable_output_sections:
  - metadata
  - hotfix_candidate_summary
  - event_type_branch
  - per_type_checklist[]
  - checklist_summary
  - risk_matrix
  - go_no_go_recommendation
  - blockers[]
  - required_approvals
  - regression_minimums
  - rollout_guardrails
  - downstream_handoff
  - self_check
  degradation_behavior:
  - emit partial readiness instead of blocking
  - list missing evidence and next best checks
  - preserve assumptions separately from direct evidence
composition_contract:
  join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - event_type_branch
  - evidence_refs
  best_combines_with:
    remediation-plan-recommendation: uses selected_path, candidate scope, rollback
      assumptions, approvals, and regression minimums to gate emergency release
    on-call-response-recommendation: uses live containment, tier, escalation, and
      signoff context to decide whether hotfix timing is safe
  strengthens:
  - emergency release safety
  - approval readiness
  - rollback and canary planning
```

## Primary inputs
Preferred workflow inputs:
- `根因定位建议.md`
- `影响范围分析.md`
- `告警归因.md`

Minimum viable standalone inputs:
- one proposed fix summary or remediation candidate
- rough incident description or event_type_branch
- optional diff scope, rollback, regression, canary, signoff, or release-owner evidence

Optional enhancement inputs:
- current containment state or operator notes
- recent deployment, config, rollback, or diff evidence
- log, trace, metric, alert, or dashboard excerpts
- owner role map, signoff roster, or release constraints

## Core output contract
Default to markdown sections or compact tables that can be copied into `热修复风险评估.md`.

The result must include at least:
- `metadata`
- `hotfix_candidate_summary`
- `event_type_branch`
- `per_type_checklist[]`
- `checklist_summary`
- `risk_matrix`
- `go_no_go_recommendation`
- `blockers[]`
- `required_approvals`
- `regression_minimums`
- `rollout_guardrails`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `contract_version: n310-response-v1.0.0`
- `workflow_node: N310`
- `skill_id: 122`
- `selected_mode`
- `readiness`
- `incident_id`
- `source_time_window`
- `service_scope`
- `event_type_branch`
- `evidence_profile`
- `confidence`
- `composition_role: emergency_change_gatekeeper`
- `function_bias: emergency_change_risk_assessment_and_release_gate`
- `stage_position: operations_governance.incident_response.hotfix_risk_assessment`
- `node_artifact_target: 热修复风险评估.md`

Each `per_type_checklist` item must include:
- `checklist_id`
- `event_type_branch`
- `requirement_level`
- `control_area`
- `question`
- `verification_method`
- `evidence_expected`
- `blocker_if_failed`
- `owner_role`
- `can_be_deferred`
- `notes`

## Downstream handoff
Emit `downstream_handoff[]` when another skill or downstream workflow can use the output.

Expected handoffs:
- to remediation-plan-recommendation when the candidate is not safe: blockers, rejected assumptions, safer alternate path requirements
- to on-call-response-recommendation when go/conditional_go changes live containment or communication strategy
- to downstream release work when go or conditional_go: required approvals, rollout guardrails, rollback conditions, and regression minimums

## Design rules
- Use one primary event_type_branch: compliance, performance, availability, or data_consistency.
- Use requirement_level: mandatory, signoff_required, or recommended.
- Expose risk weights: compliance_exposure 0.30, user_impact 0.25, diff_surface 0.15, stateful_change_risk 0.20, regression_confidence 0.10.
- Always compute a weighted score and map it to go, conditional_go, or no_go.
- Missing rollback evidence, missing signoff owner, unresolved compliance exposure, or absent regression minimums are automatic blockers.
- Keep the checklist short enough for an incident, but strict enough to stop unsafe emergency changes.

## Execution workflow
1. Normalize incident evidence into shared N310 anchors: `incident_id`, `source_time_window`, `service_scope`, `event_type_branch`, and `evidence_refs`.
2. Select the mode and determine readiness from the minimum viable inputs.
3. Produce the skill-specific artifact sections without redoing sibling skill analysis.
4. Separate direct evidence, inference, assumption, and blocker.
5. Emit downstream handoff records with confidence and next best checks.
6. Run the self-check in `references/n310-shared-response-contract.md`.

## Dynamic completeness
- If evidence is weak, produce a partial but usable artifact and mark blockers explicitly.
- If the event spans multiple domains, name one primary event_type_branch and list secondaries in metadata.
- If ownership, rollback, signoff, or verification evidence is missing, preserve the gap rather than inventing it.

## Quality bar
A good `热修复风险评估.md` is safe to act on, auditable, explicit about uncertainty, and usable both alone and as an input to the other N310 skills.

## Reference files
- `references/n310-shared-response-contract.md`
- `references/n310-event-type-branches.md`
- `references/n310-tier-and-criticality-rubrics.md`
- `references/n310-handoff-contract.md`
- `references/output-contract.yaml`
- `references/output-template.md`
- `references/quality-checklist.md`
