## Boundary comparison table — incident-response precise

| Dimension | on-call-response-recommendation | remediation-plan-recommendation | hotfix-risk-assessment | root-cause-analysis-recommendation |
|---|---|---|---|---|
| **Primary question** | "What do responders do RIGHT NOW?" | "Which fix path should we choose?" | "Is this hotfix safe to ship?" | "What caused the incident?" |
| **Timing** | First 5 minutes of incident | After containment, before fix execution | After fix is designed, before deploy | During or after investigation |
| **Output type** | Response sequence with timed steps and owners | Option comparison: 2-3 paths with TTR and recommendation | Go/no-go verdict with mandatory gate checklist | Root cause hypothesis chain with evidence |
| **Decision** | What immediate actions to take | Which fix path (rollback/hotfix/containment) | Whether this hotfix is safe to deploy | What caused the issue |
| **Owns** | Incident command setup, triage steps, escalation path, evidence collection | Path comparison, TTR estimates, feasibility, recommended path | Mandatory gate assessment, compliance check, go/no-go verdict | Hypothesis chain, five-why, prevention recommendations |
| **Does not own** | Fix path selection (→121), hotfix safety (→122), root cause (→119) | Incident command (→120), hotfix safety (→122) | Fix path selection (→121), procedure design (→105/108) | Response steps (→120), fix path (→121) |

### Canonical incident-response sequence
```
Alert fires → 120 (immediate response + containment)
              → 119 (root cause investigation, parallel)
              → 121 (fix path selection: rollback vs hotfix vs contain)
              → 122 (if hotfix chosen: safety gate assessment)
              → 105/108 (rollback/deploy procedure)
```

### When NOT to use this skill
```
"What caused the incident?"     → root-cause-analysis-recommendation, NOT 120
"Should we roll back?"          → remediation-plan-recommendation, NOT 120 or 122
"Is this hotfix safe?"          → hotfix-risk-assessment, NOT 120 or 121
"Design the rollback procedure" → rollback-plan-generation, NOT 121
```

---

## Cross-skill handoff rules
121 → 122 when `selected_path: hotfix`:
```yaml
downstream_handoff:
  to_skill: hotfix-risk-assessment    # MANDATORY when selected_path=hotfix
  selected_path: hotfix
  incident_id: "{incident_id}"
  event_type_branch: "{branch}"
  service_scope: [list]
  proposed_fix_summary: "{one_paragraph}"
  evidence_refs: [list]
  note: "121 selects the path; 122 gates the release"
```



---

## Boundary comparison table — incident-response 4-column precise

| Dimension | on-call-response | remediation-plan | hotfix-risk-assessment | root-cause-analysis |
|---|---|---|---|---|
| **Primary question** | "What do responders do RIGHT NOW (first 15min)?" | "Which fix path? Rollback vs hotfix vs contain?" | "Is THIS specific hotfix safe to deploy?" | "What CAUSED the incident?" |
| **Timing** | T+0 to T+15min (immediate response) | T+15min to T+60min (after containment) | T+60min+ (after fix designed) | Parallel with 120, continues through 121 |
| **Output type** | Timed response sequence with owners and escalation path | Option comparison table with TTR + recommended path | Go/no-go verdict with 6 mandatory gate results | Causal chain (five-why) with hypothesis and evidence |
| **Decision** | What immediate actions to take NOW | Which of 2-4 fix paths to pursue | Whether THIS hotfix is safe to ship | What the actual root cause is |
| **Owns** | Tier classification, incident command, containment steps, evidence collection | Path comparison, TTR estimation, feasibility, selected_path | Mandatory gate checklist (6 gates), compliance check, verdict | Causal chain, five-why, hypothesis, prevention recommendations |
| **Does not own** | Fix path decision (→121), hotfix safety (→122), root cause (→119) | Incident command (→120), hotfix procedure (→122), root cause (→119) | Fix path selection (→121), procedure design (→105), root cause (→119) | Response steps (→120), fix path (→121), hotfix gate (→122) |

### Canonical sequence
```
Alert → 120 (immediate response + containment)
      → 119 (root cause — starts parallel, may take hours)
      → 121 (fix path decision, after containment)
      → 122 (if hotfix path chosen — safety gate)
      → 105/108 (rollback/deploy procedure + execution)
```

### When NOT to use this skill — routing table
| User intent | Use | NOT |
|---|---|---|
| "Incident just declared — what now?" | 120 ✓ | 121, 122 |
| "Should we roll back or hotfix?" | 121 ✓ | 120, 122 |
| "Is this fix safe to ship?" | 122 ✓ | 121, 120 |
| "What caused the outage?" | 119 ✓ | 120, 121, 122 |
| "Set up war room / incident command" | 120 ✓ | — |
| "Compare TTR of rollback vs hotfix" | 121 ✓ | 122 |
| "CVE patch — go/no-go?" | 122 ✓ | 121 |

