## Mock input fixture

```yaml
mock_input:
  source: "incident_brief"
  content: "payment-service DB connection pool exhausted — 8% error rate, 45 min duration"
  expected_output_shape:
    remediation_options:
      min_entries: 2
      must_include: containment_only
      exactly_one_recommended: true
    decision_weight_profile:
      min_dimensions: 3
    self_check:
      passed: true
```
