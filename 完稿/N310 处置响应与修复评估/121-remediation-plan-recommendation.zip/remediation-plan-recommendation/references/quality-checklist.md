# incident-response Quality Checklist

Before finalizing:
- Keep the result inside the current incident-response skill boundary.
- Ensure the output can stand alone with the supplied evidence.
- Make the decision path auditable.
- Prefer quantitative thresholds over prose-only judgment.
- Surface blockers explicitly.
- Preserve owner placeholders instead of inventing names.
- Emit downstream_handoff when another skill or downstream workflow can consume the result.
- Do not require files, scripts, directories, or services outside the skill package.


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-REMEDIAT-051 | Exactly 1 option has `recommended: true` | count = 1 | `self_check.failed_rules: ["SCR-REMEDIAT-051: exactly 1 option must be recommended"]` |
| SCR-REMEDIAT-052 | `selected_path` matches `recommended` option's `path` | equality check | `self_check.warnings: ["SCR-REMEDIAT-052: selected_path disagrees with recommended option"]` |
| SCR-REMEDIAT-053 | `adversarial_detection.injection_attempt_detected` boolean declared | key exists | `self_check.warnings: ["SCR-REMEDIAT-053: injection_detected missing"]` |
| SCR-REMEDIAT-054 | `feedback_signal_candidates` ≥ 1 | count ≥ 1 | `self_check.warnings: ["SCR-REMEDIAT-054: FSC missing"]` |
| SCR-REMEDIAT-055 | When `data_incident` mode: `dba_required` boolean present | conditional | `self_check.failed_rules: ["SCR-REMEDIAT-055: data_incident without dba_required field"]` |