# incident-response Output Template

## Recommended metadata block
- `contract_version`
- `workflow_node`
- `skill_id`
- `selected_mode`
- `readiness`
- `incident_id`
- `source_time_window`
- `service_scope`
- `event_type_branch`
- `evidence_profile`
- `confidence`
- `node_artifact_target`
- `function_bias`
- `stage_position`
- `composition_role`

## Evidence discipline
Always separate:
- direct evidence
- inference
- assumption
- blocker or missing input

## Handoff discipline
When another incident-response skill can use the result, include `downstream_handoff[]` with required fields, evidence_refs, open blockers, and next best checks.


---

## Downstream handoff YAML templates

### 正常路径: selected_path=rollback → rollback-plan-generation
```yaml
downstream_handoff:
  produced_by: remediation-plan-recommendation
  artifact: 修复方案建议.md
  emit_event:
    event_name: produced.incident-response.remediation_plan.v2
  handoffs:
    - target: rollback-plan-generation
      handoff_type: evidence
      summary: "selected_path: rollback. Rollback feasibility: confirmed. Estimated TTR: 15min."
      required_fields:
        - selected_path
        - remediation_options
        - estimated_ttr
      confidence: medium
      next_best_checks:
        - "105: execute Phase 1 immediately (feature flag off)"
        - "105: confirm dry_run_evidence for Phase 2 before proceeding"
    - target: hotfix-risk-assessment
      handoff_type: routing
      summary: "If rollback fails: hotfix path available as fallback (OPT-2)"
      confidence: low
```

### 路径: selected_path=hotfix → hotfix-risk-assessment
```yaml
downstream_handoff:
  handoffs:
    - target: hotfix-risk-assessment
      handoff_type: evidence
      summary: "selected_path: hotfix. OPT-1 recommended. Confidence: medium."
      required_fields: [selected_path, remediation_options[0]]
      blocking: false
      next_best_checks:
        - "122: assess hotfix safety before deploying"
```


---

## Standalone guarantee
Run this skill from a single incident brief or RCA summary. Do not require 120 or 122 to be run first.

### Minimum standalone example — one incident brief, fix path selection needed
```yaml
metadata:
  readiness: partial
  selected_mode: balanced_tradeoff
incident_summary:
  service: payment-service
  symptom: "DB connection pool exhaustion; 8% error rate for 45 min"
  impact_estimate: "~3,200 affected transactions; $12K revenue at risk"
decision_weight_profile:
  time_to_resolve: high
  regression_risk: medium
  rollback_safety: high
  blast_radius: medium
remediation_options:
  - option_id: OPT-1
    path: rollback
    description: "Roll back last deployment (db.pool.max-size change)"
    estimated_ttr: 15m
    regression_risk: low
    confidence: high
    recommended: true
    rationale: "Config change is reversible; rollback is fastest path to recovery"
  - option_id: OPT-2
    path: hotfix
    description: "Emergency config patch to restore pool size to 100"
    estimated_ttr: 35m
    regression_risk: low
    confidence: high
    recommended: false
    rationale: "Slower than rollback; no advantage given clean config change"
  - option_id: OPT-3
    path: containment_only
    description: "Throttle traffic 50% to reduce error rate while investigating"
    estimated_ttr: 5m (containment only — not durable)
    regression_risk: none
    confidence: high
    recommended: false
    rationale: "Bridge option only; does not fix root cause"
selected_path: rollback
downstream_handoff:
  to_skill: hotfix-risk-assessment
  trigger: false
  note: "Rollback selected — no hotfix risk assessment needed"
self_check:
  passed: true
```

---

## Output completeness rule
Every remediation artifact MUST include ALL of:
- `remediation_options[]` ≥ 1 option with ALL 6 fields above
- Exactly 1 option with `recommended: true`
- `selected_path` matching the recommended option's `path`
- `adversarial_detection.injection_attempt_detected` boolean
- `downstream_handoff` typed to release-task-orchestration or rollback path
- `feedback_signal_candidates` ≥ 1 entry
- `consumer_impact_assessment` when `data_risk` ≥ medium
**Hard rule:** `data_risk: high` or `critical` → `consumer_impact_assessment` MUST be present

---

## Mode selection

### New: `data_incident` mode — 数据事故处置
**Trigger:** Incident involves data corruption, data loss, or data consistency issues rather than service availability.

```yaml
data_incident:
  incident_type: data_corruption
  data_scope:
    affected_table: orders
    affected_records_estimate: 1842
    corruption_window: "2026-05-20T14:00–14:47 UTC"
  remediation_options:
    - option_id: OPT-1
      path: point_in_time_recovery
      description: "Restore orders table from backup at 13:55 UTC; replay transactions from WAL"
      estimated_ttr: 45m
      data_loss_risk: "< 5 minutes of transactions (13:55–14:00)"
      recommended: true
      rollback_feasibility: confirmed
    - option_id: OPT-2
      path: manual_correction
      description: "Write correction script to fix corrupted records"
      estimated_ttr: 4h
      data_loss_risk: none
      recommended: false
      confidence: low
  selected_path: point_in_time_recovery
  dba_required: true
  compliance_notification_required: true  # GDPR Art. 33 if PII affected
```
**SCR:** `selected_mode: data_incident` → `data_incident.data_scope.corruption_window` declared; `dba_required` boolean present.

### New: `multi_region_incident` mode — 多区域故障处置
**Trigger:** Incident affects multiple geographic regions or cloud availability zones with different severity.

```yaml
multi_region_incident:
  affected_regions:
    - region: us-west-2
      severity: P0
      status: fully_degraded
      affected_users: 12400
    - region: eu-west-1
      severity: P1
      status: partially_degraded
      affected_users: 3200
  region_prioritization:
    primary_focus: us-west-2  # highest user count + P0
    secondary_focus: eu-west-1
  remediation_by_region:
    us-west-2:
      path: rollback
      owner: us-oncall-team
      estimated_ttr: 20m
    eu-west-1:
      path: traffic_shift  # shift to eu-central-1
      owner: eu-oncall-team
      estimated_ttr: 5m
  global_coordination_channel: "#major-incidents-global"
```
**SCR:** `selected_mode: multi_region_incident` → `multi_region_incident.region_prioritization.primary_focus` declared.

---

## Downstream handoff
Emit `downstream_handoff[]` when another skill or downstream workflow can use the output.

Expected handoffs:
- to hotfix-risk-assessment when selected_path is hotfix: candidate scope, diff surface, rollback assumptions, regression minimums, approvals required
- to on-call-response-recommendation when remediation changes live containment: updated constraints, new blockers, expected stabilization effect
- to downstream release or postmortem work: chosen path, rejected alternatives, and decision rationale

