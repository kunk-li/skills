# failure-modes

Common failure modes in incident-response incident response skills and how to handle them.

## FM01: RCA not available (no root cause identified)
- **Symptom:** `root-cause-analysis-recommendation` output not provided to incident-response.
- **Impact:** incident-response skills must operate from symptom evidence alone.
- **Handling:** Mark `evidence_profile.rca_available: false`. Use `confidence: low` on all hypothesis-dependent decisions. Still produce artifact.

## FM02: Rollback evidence absent
- **Symptom:** No rollback plan or rollback procedure provided.
- **Impact:** Hotfix-risk-assessment cannot confirm rollback safety (hard blocker).
- **Handling:** Mark `rollback_evidence: absent`. Add as mandatory blocker in `hotfix-risk-assessment`. Do not issue `go` without rollback evidence.

## FM03: Compliance branch activation
- **Symptom:** `event_type_branch` is or includes `compliance` or `data_consistency`.
- **Impact:** Standard mandatory→signoff_required demotion rules are restricted (see hotfix-risk-assessment demotion table).
- **Handling:** `rollback_evidence` and `compliance_exposure` checklist items remain mandatory. No demotion allowed.

## FM04: All fix paths blocked
- **Symptom:** Every `remediation_options[]` item evaluates to `no_go`.
- **Impact:** No automated fix path available.
- **Handling:** `containment_only` is always at least `conditional`. Escalate to engineering-director. Apply bridge SLA.

## FM05: Incident active > 4h without resolution
- **Symptom:** MTTR exceeds 4h threshold.
- **Impact:** Original `response_sequence[]` is stale.
- **Handling:** Apply rolling response sequence update (see on-call-response-recommendation MTTR extended protocol).

## FM06: Circuit breaker triggered
- **Symptom:** Skill re-invoked ≥ 3 times without resolving readiness.
- **Impact:** Further re-generation will not resolve the issue.
- **Handling:** Stop regeneration. Emit `readiness: red`. Escalate to release-manager. Require new evidence before reset.


---

## Degradation

### readiness: amber — 多路径置信度相似，无法区分最优解

```yaml
metadata:
  readiness: amber
  selected_mode: stabilize_now
evidence_profile:
  confirmed: [rca_output, impact_scope, deployment_history]
  missing_evidence: [rollback_plan_105, fix_diff]
  confidence_ceiling_applied: medium
remediation_options:
  - option_id: OPT-1
    path: rollback
    ttr_estimate: "8-15min"
    confidence: medium
    rollback_plan: absent  # amber: 105 not yet available
    note: "Rollback likely viable (deploy 47min ago) but plan not confirmed"
    recommended: true
  - option_id: OPT-2
    path: hotfix
    ttr_estimate: "unknown — fix_diff not provided"
    confidence: speculative
    recommended: false
selected_path: rollback
amber_reason: "Rollback recommended but plan not confirmed; TTR range broad"
self_check:
  passed: true
  warnings:
    - "amber — rollback_plan_105 absent; TTR estimate is range not confirmed"
    - "Upgrade: provide rollback-plan-generation output to confirm TTR"
```

### Confidence quantification
```yaml
confidence_quantification_v3:
  symptom_only:
    ceiling: speculative
    viable_paths: [containment_only]
    note: "Cannot evaluate rollback/hotfix without diff or history"
  rca_available:
    ceiling: low
    viable_paths: [containment_only, rollback_if_recent]
  rca_plus_impact:
    ceiling: medium
    viable_paths: [rollback, hotfix, containment]
    ttr: range_estimate
  rca_plus_rollback_plan_105:
    ceiling: high
    viable_paths: all_quantified
    ttr: confirmed_from_dry_run
  data_incident_no_dba:
    ceiling: none
    readiness: red
    note: "DBA required; cannot proceed with data recovery path"
```

