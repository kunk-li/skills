# real-examples

## Example 1: on-call-response-recommendation — minimum viable input (120)

**Scenario:** Single alert, no RCA or impact scope available.

**Input given:**
- Alert: `checkout-service HTTP 5xx rate > 5% for 3 min`
- Time: 02:14 UTC
- No root cause, no impact data

**Expected output shape:**
```yaml
selected_mode: quick_triage
readiness: partial
tier_auto_classification:
  recommended_tier: 2
  rationale: "User-visible checkout impact; no confirmed data harm or compliance breach"
event_type_branch: availability
response_sequence:
  - step_id: R1
    goal: Confirm blast radius
    action: "Check checkout error rate dashboard for affected user cohort size"
    owner_role: on-call-engineer
    timebox: 5 min
    verification_signal: "Error rate trend direction (rising / stable / falling)"
    fallback_if_unsuccessful: "Escalate to checkout-team lead"
  - step_id: R2
    goal: Attempt safe containment
    action: "Enable feature flag CHECKOUT_FALLBACK_MODE if available"
    owner_role: on-call-engineer
    timebox: 10 min
    verification_signal: "5xx rate returns to < 1%"
    fallback_if_unsuccessful: "Proceed to rollback decision — see R3"
```

**Key calibration:** Minimum input → Tier 2 (not Tier 0) unless compliance breach or irreversible data harm is confirmed. Always emit at least 3 response steps even with partial evidence.

---

## Example 2: remediation-plan-recommendation — multiple path comparison (121)

**Scenario:** DB connection pool exhaustion identified as root cause.

**Input given:**
- RCA: `db.pool.max-size` reduced from 100→20 at 14:15 UTC caused checkout failures
- On-call response: feature flag containment partially effective (50% error reduction)
- Rollback evidence: config change is reversible

**Expected output shape:**
```yaml
selected_mode: stabilize_now
decision_weight_profile:
  regulatory_impact: 0.30
  user_impact: 0.25
  rollbackability: 0.20
  implementation_scope: 0.15
  verification_cost: 0.10
remediation_options:
  - fix_id: FIX-001
    remediation_path: rollback_first_then_fix
    objective: "Revert db.pool.max-size to 100; then investigate correct production value"
    immediate_effect: "Checkout error rate returns to baseline within 1 restart cycle"
    rollback_path: "Git revert config commit; rolling restart of checkout-service"
    criticality_class: Critical
    weighted_score: 0.87
    recommended_when: "Rollback dry-run evidence exists"
  - fix_id: FIX-002
    remediation_path: hotfix
    objective: "Deploy corrected pool size as emergency config patch"
    weighted_score: 0.61
    recommended_when: "Rollback is blocked (e.g., irreversible schema change)"
selected_path_recommendation:
  selected: FIX-001
  rationale: "Highest weighted score; reversible; rollback path confirmed"
hotfix_trigger_decision:
  trigger_hotfix: false
  reason: "Rollback path preferred; hotfix not needed for config-only change"
```

---

## Example 3: hotfix-risk-assessment — multi-event-type (122)

**Scenario:** Proposed hotfix touches both availability fix AND compliance-adjacent audit log.

**Input given:**
- Proposed diff: fixes connection pool config AND adds audit log for payment events
- Primary issue: availability (checkout outage)
- Secondary concern: compliance (audit log completeness)

**Expected output shape:**
```yaml
event_type_branch: availability  # primary
metadata:
  event_type_branch_secondary: [compliance]
  note: "Secondary compliance branch requires additional checklist items"
per_type_checklist:
  # availability items
  - checklist_id: CK-AV-001
    event_type_branch: availability
    control_area: rollback_safety
    requirement_level: mandatory
    blocker_if_failed: true
  # compliance items (added due to audit log change)
  - checklist_id: CK-CO-001
    event_type_branch: compliance
    control_area: audit_completeness
    requirement_level: mandatory
    question: "Does the new audit log meet retention and tamper-evidence requirements?"
    blocker_if_failed: true
go_no_go_recommendation:
  recommendation: conditional_go
  conditions:
    - "Compliance team confirms audit log schema meets retention policy"
    - "Rollback tested in staging with audit log rollback included"
```

**Key calibration for multi-event-type:** Always declare ONE primary `event_type_branch`; list secondaries explicitly. Add checklist items for each secondary branch. A secondary compliance branch can escalate go → conditional_go or no_go even if primary branch passes.

---

## Example 4: patch_release path — when rollback is not feasible

**Scenario:** DB migration already applied. Rollback would cause data loss. Patch release is preferred.

```yaml
metadata:
  readiness: amber
  selected_mode: long_term_fix_alignment
incident_summary:
  service: user-profile-service
  symptom: "User tier calculation incorrect since v3.1.0 deploy"
  impact: "~12,000 users shown wrong subscription tier"
  root_cause_ref: "RCA-042: bug in tier calculation logic introduced in PR-1204"
severity_quantification:
  blast_radius: 12000_users
  revenue_impact: low   # display bug only; billing unaffected
  data_correctness_impact: high
decision_weight_profile:
  rollback_feasibility: not_feasible  # DB migration applied; would cause data loss
  time_to_resolve:      medium
  regression_risk:      low
  rollback_safety:      not_applicable
remediation_options:
  - option_id: OPT-1
    path: patch_release
    description: "Fix tier calculation logic in v3.1.1; re-compute affected user tiers via background job"
    estimated_ttr: 4h
    regression_risk: low
    confidence: high
    recommended: true
    rationale: "Rollback not feasible. Patch is targeted (1 function change). Background job corrects data state."
  - option_id: OPT-2
    path: containment_only
    description: "Manual override affected user tiers in admin panel while patch is prepared"
    estimated_ttr: 30m (containment) + 4h (patch)
    regression_risk: none
    confidence: high
    recommended: false
    rationale: "Containment only — not durable. Use as bridge if patch cannot deploy in this window."
  - option_id: OPT-3
    path: next_regular_release
    description: "Include fix in v3.2.0 next week"
    estimated_ttr: 7d
    regression_risk: none
    recommended: false
    rationale: "Too slow — data correctness issue affects user trust."
selected_path: patch_release
downstream_handoff:
  to_skill: hotfix-risk-assessment
  trigger: false     # patch_release is not an emergency hotfix
  note: "Proceed with standard release process for v3.1.1"
self_check:
  passed: true
  failed_rules: []
```

**Key calibration:** When `rollback_feasibility: not_feasible`, always include `patch_release` as a recommended option. `containment_only` is still present as a bridge option. `next_regular_release` is still listed even if clearly too slow — gives decision-makers a complete picture.

---

## Example 5: Tier 1 minimum input — verbal incident brief only

```yaml
metadata:
  readiness: partial
  selected_mode: stabilize_now
incident_summary:
  symptom: "checkout failing (verbal description)"
  service: unknown
  impact: unknown
decision_weight_profile:
  time_to_resolve: high   # default weight when impact unknown
  rollback_safety: unknown
  regression_risk: unknown
remediation_options:
  - option_id: OPT-1
    path: containment_only
    description: "Gather evidence (logs, metrics, alerts) to characterize the failure before committing to a fix path"
    estimated_ttr: 15m (evidence gathering)
    recommended: true
    rationale: "Insufficient evidence to recommend rollback or hotfix safely. Containment while evidence is gathered."
  - option_id: OPT-2
    path: rollback
    description: "Roll back last deployment if a deployment occurred in the past 2 hours"
    estimated_ttr: unknown (depends on rollback plan availability)
    recommended: false
    rationale: "No evidence of deployment as cause. Rollback may not help and could cause unrelated issues."
selected_path: containment_only
self_check:
  passed: false
  failed_rules: ["Tier 1 input — all options have low confidence; gather evidence before acting"]
```


---

## Scenario calibration
See `references/real-examples.md` for stabilize_now, balanced_tradeoff, and hotfix_candidate_selection scenarios.

For fix path decision matrix, see `references/remediation-decision-matrix.md`.
For incident tier rubrics, see `references/incident-response-tier-rubrics.md`.