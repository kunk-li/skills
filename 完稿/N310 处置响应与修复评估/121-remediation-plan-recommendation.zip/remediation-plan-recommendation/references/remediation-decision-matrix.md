# Remediation Decision Matrix

Candidate paths:
- `containment_only`
- `hotfix`
- `patch_release`
- `next_regular_release`
- `rollback_first_then_fix`

Score candidates against:
- regulatory impact
- user impact
- rollbackability
- implementation scope
- verification cost

Expose the chosen `decision_weight_profile` in every result so teams can tune the model by project. Keep the preferred path and rejected alternatives visible.
