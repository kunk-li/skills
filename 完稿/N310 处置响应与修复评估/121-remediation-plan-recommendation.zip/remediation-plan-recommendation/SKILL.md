---
name: remediation-plan-recommendation
description: produce self-contained n310 remediation plan recommendations that compare containment-only, hotfix, patch release, rollback-first, and next regular release options. use when an incident needs 修复方案建议.md, durable correction, tradeoff scoring, regression expectations, rollback assumptions, or a handoff to hotfix-risk-assessment. this skill can run alone from one incident brief or rca summary and composes with on-call-response-recommendation and hotfix-risk-assessment through incident_id, event_type_branch, service_scope, evidence_refs, selected_path, and downstream_handoff.
---
# remediation-plan-recommendation

## N310 encapsulation baseline
This skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside this skill plus artifacts supplied in the conversation. Do not require node-level folders, external tools, hidden registries, or sibling skill files.

## Role positioning
This skill aligns to N310 incident response and produces `修复方案建议.md`. It is authoritative for `remediation_option_design_and_fix_path_tradeoff`.

## Scope boundary
Own:
- durable fix options
- decision-weight profile and scoring
- selected remediation path
- hotfix trigger decision and handoff

Do not own:
- incident-command sequencing
- emergency release go/no-go gate
- long-form postmortem authorship

## Selected mode
Every result must declare `selected_mode`, `readiness`, `evidence_profile`, and `contract_version` at the top.

Allowed modes:
- `stabilize_now`
- `balanced_tradeoff`
- `long_term_fix_alignment`
- `hotfix_candidate_selection`

## Standalone and composition role
```yaml
contract_version: n310-response-v1.0.0
workflow_node: N310
skill_id: '121'
artifact_target: 修复方案建议.md
composition_role: durable_fix_path_selector
standalone_guarantee:
  minimum_viable_input:
  - one incident brief, bug cluster, or RCA summary
  - a symptom or root-cause hypothesis
  - optional on-call response, impact scope, rollback, diff, or owner evidence
  stable_output_sections:
  - metadata
  - incident_summary
  - severity_quantification
  - decision_weight_profile
  - remediation_options[]
  - selected_path_recommendation
  - hotfix_trigger_decision
  - regression_and_validation_expectations
  - dependencies_and_preconditions
  - downstream_handoff
  - self_check
  degradation_behavior:
  - emit partial readiness instead of blocking
  - list missing evidence and next best checks
  - preserve assumptions separately from direct evidence
composition_contract:
  join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - event_type_branch
  - evidence_refs
  best_combines_with:
    on-call-response-recommendation: consumes containment state, tier, and active
      blockers so durable options do not contradict live response
    hotfix-risk-assessment: hands selected hotfix candidates, diff surface, rollback
      assumptions, approvals, and regression minimums into the go/no-go gate
  strengthens:
  - hotfix gate quality
  - release strategy clarity
  - postmortem prevention actions
```

## Primary inputs
Preferred workflow inputs:
- `根因定位建议.md`
- `影响范围分析.md`
- `告警归因.md`

Minimum viable standalone inputs:
- one incident brief, bug cluster, or RCA summary
- a symptom or root-cause hypothesis
- optional on-call response, impact scope, rollback, diff, or owner evidence

Optional enhancement inputs:
- current containment state or operator notes
- recent deployment, config, rollback, or diff evidence
- log, trace, metric, alert, or dashboard excerpts
- owner role map, signoff roster, or release constraints

## Core output contract
Default to markdown sections or compact tables that can be copied into `修复方案建议.md`.

The result must include at least:
- `metadata`
- `incident_summary`
- `severity_quantification`
- `decision_weight_profile`
- `remediation_options[]`
- `selected_path_recommendation`
- `hotfix_trigger_decision`
- `regression_and_validation_expectations`
- `dependencies_and_preconditions`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `contract_version: n310-response-v1.0.0`
- `workflow_node: N310`
- `skill_id: 121`
- `selected_mode`
- `readiness`
- `incident_id`
- `source_time_window`
- `service_scope`
- `event_type_branch`
- `evidence_profile`
- `confidence`
- `composition_role: durable_fix_path_selector`
- `function_bias: remediation_option_design_and_fix_path_tradeoff`
- `stage_position: operations_governance.incident_response.remediation_planning`
- `node_artifact_target: 修复方案建议.md`

Each `remediation_options` item must include:
- `fix_id`
- `remediation_path`
- `event_type_branch`
- `objective`
- `immediate_effect`
- `long_term_effect`
- `implementation_scope`
- `blast_radius`
- `rollback_path`
- `criticality_class`
- `decision_inputs`
- `regression_expectation`
- `approvals_needed`
- `recommended_when`
- `not_recommended_when`

## Downstream handoff
Emit `downstream_handoff[]` when another skill or downstream workflow can use the output.

Expected handoffs:
- to hotfix-risk-assessment when selected_path is hotfix: candidate scope, diff surface, rollback assumptions, regression minimums, approvals required
- to on-call-response-recommendation when remediation changes live containment: updated constraints, new blockers, expected stabilization effect
- to downstream release or postmortem work: chosen path, rejected alternatives, and decision rationale

## Design rules
- Use one remediation_path: containment_only, hotfix, patch_release, next_regular_release, or rollback_first_then_fix.
- Expose a configurable decision_weight_profile; do not hide weights.
- Default weights: regulatory_impact 0.30, user_impact 0.25, rollbackability 0.20, implementation_scope 0.15, verification_cost 0.10.
- Use Critical, Major, or Minor criticality_class with visible rationale.
- Show both short-term stabilization and durable fix path.
- If preferred path is hotfix, downstream_handoff to hotfix-risk-assessment is mandatory.

## Execution workflow
1. Normalize incident evidence into shared N310 anchors: `incident_id`, `source_time_window`, `service_scope`, `event_type_branch`, and `evidence_refs`.
2. Select the mode and determine readiness from the minimum viable inputs.
3. Produce the skill-specific artifact sections without redoing sibling skill analysis.
4. Separate direct evidence, inference, assumption, and blocker.
5. Emit downstream handoff records with confidence and next best checks.
6. Run the self-check in `references/n310-shared-response-contract.md`.

## Dynamic completeness
- If evidence is weak, produce a partial but usable artifact and mark blockers explicitly.
- If the event spans multiple domains, name one primary event_type_branch and list secondaries in metadata.
- If ownership, rollback, signoff, or verification evidence is missing, preserve the gap rather than inventing it.

## Quality bar
A good `修复方案建议.md` is safe to act on, auditable, explicit about uncertainty, and usable both alone and as an input to the other N310 skills.

## Reference files
- `references/n310-shared-response-contract.md`
- `references/n310-event-type-branches.md`
- `references/n310-tier-and-criticality-rubrics.md`
- `references/n310-handoff-contract.md`
- `references/output-contract.yaml`
- `references/output-template.md`
- `references/quality-checklist.md`
