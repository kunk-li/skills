---
name: on-call-response-recommendation
description: produce self-contained n310 on-call response recommendations for incident command, containment, escalation, communications, signoff, and audit-ready responder actions. use when given root-cause hints, impact scope, alert attribution, incident summaries, or partial runtime evidence and the needed artifact is 值班处置建议.md. this skill can run alone from minimal alert evidence and composes with remediation-plan-recommendation and hotfix-risk-assessment through incident_id, event_type_branch, service_scope, evidence_refs, and downstream_handoff.
---
# on-call-response-recommendation

## N310 encapsulation baseline
This skill package is self-contained: standalone execution and multi-skill composition rely only on files packaged inside this skill plus artifacts supplied in the conversation. Do not require node-level folders, external tools, hidden registries, or sibling skill files.

## Role positioning
This skill aligns to N310 incident response and produces `值班处置建议.md`. It is authoritative for `immediate_response_ordering_and_incident_command_guidance`.

## Scope boundary
Own:
- incident tier recommendation
- responder sequence and timebox
- containment options and fallback order
- escalation, communication, signoff, and audit steps

Do not own:
- durable remediation path selection
- hotfix go/no-go decision
- deep RCA or postmortem authorship

## Selected mode
Every result must declare `selected_mode`, `readiness`, `evidence_profile`, and `contract_version` at the top.

Allowed modes:
- `quick_triage`
- `scenario_playbook`
- `major_incident_command`
- `containment_only`

## Standalone and composition role
```yaml
contract_version: n310-response-v1.0.0
workflow_node: N310
skill_id: '120'
artifact_target: 值班处置建议.md
composition_role: incident_command_and_containment
standalone_guarantee:
  minimum_viable_input:
  - one alert, incident summary, or operator note
  - at least one symptom, impacted service, or time window
  - optional root-cause, impact, or alert attribution artifacts
  stable_output_sections:
  - metadata
  - incident_snapshot
  - tier_auto_classification
  - event_type_branch
  - response_sequence[]
  - containment_options[]
  - escalation_chain
  - communication_points
  - signoff_and_audit_requirements
  - handoff_to_remediation
  - downstream_handoff
  - self_check
  degradation_behavior:
  - emit partial readiness instead of blocking
  - list missing evidence and next best checks
  - preserve assumptions separately from direct evidence
composition_contract:
  join_keys:
  - incident_id
  - source_time_window
  - service_scope
  - event_type_branch
  - evidence_refs
  best_combines_with:
    remediation-plan-recommendation: turns containment state, tier, blockers, and
      response decisions into durable remediation options
    hotfix-risk-assessment: uses emergency constraints, signoff needs, and containment
      context to assess hotfix safety
  strengthens:
  - remediation prioritization
  - hotfix readiness
  - retrospective decision timeline
```

## Primary inputs
Preferred workflow inputs:
- `根因定位建议.md`
- `影响范围分析.md`
- `告警归因.md`

Minimum viable standalone inputs:
- one alert, incident summary, or operator note
- at least one symptom, impacted service, or time window
- optional root-cause, impact, or alert attribution artifacts

Optional enhancement inputs:
- current containment state or operator notes
- recent deployment, config, rollback, or diff evidence
- log, trace, metric, alert, or dashboard excerpts
- owner role map, signoff roster, or release constraints

## Core output contract
Default to markdown sections or compact tables that can be copied into `值班处置建议.md`.

The result must include at least:
- `metadata`
- `incident_snapshot`
- `tier_auto_classification`
- `event_type_branch`
- `response_sequence[]`
- `containment_options[]`
- `escalation_chain`
- `communication_points`
- `signoff_and_audit_requirements`
- `handoff_to_remediation`
- `downstream_handoff`
- `self_check`

`metadata` must contain:
- `contract_version: n310-response-v1.0.0`
- `workflow_node: N310`
- `skill_id: 120`
- `selected_mode`
- `readiness`
- `incident_id`
- `source_time_window`
- `service_scope`
- `event_type_branch`
- `evidence_profile`
- `confidence`
- `composition_role: incident_command_and_containment`
- `function_bias: immediate_response_ordering_and_incident_command_guidance`
- `stage_position: operations_governance.incident_response.on_call_response`
- `node_artifact_target: 值班处置建议.md`

Each `response_sequence` item must include:
- `step_id`
- `goal`
- `action`
- `owner_role`
- `timebox`
- `verification_signal`
- `fallback_if_unsuccessful`

## Downstream handoff
Emit `downstream_handoff[]` when another skill or downstream workflow can use the output.

Expected handoffs:
- to remediation-plan-recommendation: incident tier, containment attempted, open blockers, temporary restrictions, escalation context
- to hotfix-risk-assessment when emergency change is considered: response timebox, rollback uncertainty, signoff and audit constraints
- to downstream release or postmortem work: auditable response timeline and decision points

## Design rules
- Use exactly one primary event_type_branch: compliance, performance, availability, or data_consistency.
- Always auto-classify a recommended tier using compliance_impact, user_impact, and reversibility.
- Use Tier 0 for compliance breach or irreversible data harm even when traffic is low.
- Separate detection, containment, communication, signoff, and audit actions.
- When root cause is uncertain, lead with safe containment and explicitly mark provisional assumptions.
- Do not invent owner names; use owner_role placeholders and blockers.

## Execution workflow
1. Normalize incident evidence into shared N310 anchors: `incident_id`, `source_time_window`, `service_scope`, `event_type_branch`, and `evidence_refs`.
2. Select the mode and determine readiness from the minimum viable inputs.
3. Produce the skill-specific artifact sections without redoing sibling skill analysis.
4. Separate direct evidence, inference, assumption, and blocker.
5. Emit downstream handoff records with confidence and next best checks.
6. Run the self-check in `references/n310-shared-response-contract.md`.

## Dynamic completeness
- If evidence is weak, produce a partial but usable artifact and mark blockers explicitly.
- If the event spans multiple domains, name one primary event_type_branch and list secondaries in metadata.
- If ownership, rollback, signoff, or verification evidence is missing, preserve the gap rather than inventing it.

## Quality bar
A good `值班处置建议.md` is safe to act on, auditable, explicit about uncertainty, and usable both alone and as an input to the other N310 skills.

## Reference files
- `references/n310-shared-response-contract.md`
- `references/n310-event-type-branches.md`
- `references/n310-tier-and-criticality-rubrics.md`
- `references/n310-handoff-contract.md`
- `references/output-contract.yaml`
- `references/output-template.md`
- `references/quality-checklist.md`
