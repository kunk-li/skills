# incident-response Quality Checklist

Before finalizing:
- Keep the result inside the current incident-response skill boundary.
- Ensure the output can stand alone with the supplied evidence.
- Make the decision path auditable.
- Prefer quantitative thresholds over prose-only judgment.
- Surface blockers explicitly.
- Preserve owner placeholders instead of inventing names.
- Emit downstream_handoff when another skill or downstream workflow can consume the result.
- Do not require files, scripts, directories, or services outside the skill package.


---

## Self-check quantified rules

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-ONCALLRE-051 | `tier_auto_classification.tier` ∈ {T1, T2, T3} | enum check | `self_check.failed_rules: ["SCR-ONCALLRE-051: tier not classified"]` |
| SCR-ONCALLRE-052 | Every `response_sequence` step has numeric `timebox` | regex `\d+m` | `self_check.warnings: ["SCR-ONCALLRE-052: step missing timebox"]` |
| SCR-ONCALLRE-053 | `response_sequence` P0 extraction total ≤ 15min for T1, ≤ 30min for T2 | sum check | `self_check.warnings: ["SCR-ONCALLRE-053: P0 extraction exceeds timebox"]` |
| SCR-ONCALLRE-054 | Every step has `on_failure` declared | key exists | `self_check.warnings: ["SCR-ONCALLRE-054: step missing on_failure handler"]` |
| SCR-ONCALLRE-055 | T1 incident → `incident_command` section present | conditional | `self_check.failed_rules: ["SCR-ONCALLRE-055: T1 without incident_command section"]` |
| SCR-ONCALLRE-056 | `downstream_handoff` to `remediation-plan-recommendation` present | key check | `self_check.warnings: ["SCR-ONCALLRE-056: no handoff to 121"]` |
| SCR-ONCALLRE-057 | `event_type_branch` declared | key exists | `self_check.failed_rules: ["SCR-ONCALLRE-057: event_type_branch missing"]` |
| SCR-ONCALLRE-058 | `adversarial_detection` present | key exists | `self_check.warnings: ["SCR-ONCALLRE-058: adversarial_detection missing"]` |
| SCR-ONCALLRE-059 | `feedback_signal_candidates` ≥ 1 | count ≥ 1 | `self_check.warnings: ["SCR-ONCALLRE-059: FSC missing"]` |
| SCR-ONCALLRE-060 | `confidence` ≤ tier ceiling (see D4 four-tier) | tier check | `self_check.warnings: ["SCR-ONCALLRE-060: confidence exceeds tier ceiling"]` |