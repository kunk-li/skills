## Mock input fixture

```yaml
mock_input:
  source: "single_alert_payload"
  content: "payment-service HTTP 500 error rate 12% since 14:32 UTC"
  expected_output_shape:
    tier_auto_classification:
      tier: T2
    response_sequence:
      min_steps: 3
    event_type_branch: present
    downstream_handoff:
      to_skill: remediation-plan-recommendation
    self_check:
      passed: true
      warnings: ["RCA not available — response sequence is containment only"]
```
