# failure-modes

Common failure modes in incident-response incident response skills and how to handle them.

## FM01: RCA not available (no root cause identified)
- **Symptom:** `root-cause-analysis-recommendation` output not provided to incident-response.
- **Impact:** incident-response skills must operate from symptom evidence alone.
- **Handling:** Mark `evidence_profile.rca_available: false`. Use `confidence: low` on all hypothesis-dependent decisions. Still produce artifact.

## FM02: Rollback evidence absent
- **Symptom:** No rollback plan or rollback procedure provided.
- **Impact:** Hotfix-risk-assessment cannot confirm rollback safety (hard blocker).
- **Handling:** Mark `rollback_evidence: absent`. Add as mandatory blocker in `hotfix-risk-assessment`. Do not issue `go` without rollback evidence.

## FM03: Compliance branch activation
- **Symptom:** `event_type_branch` is or includes `compliance` or `data_consistency`.
- **Impact:** Standard mandatory→signoff_required demotion rules are restricted (see hotfix-risk-assessment demotion table).
- **Handling:** `rollback_evidence` and `compliance_exposure` checklist items remain mandatory. No demotion allowed.

## FM04: All fix paths blocked
- **Symptom:** Every `remediation_options[]` item evaluates to `no_go`.
- **Impact:** No automated fix path available.
- **Handling:** `containment_only` is always at least `conditional`. Escalate to engineering-director. Apply bridge SLA.

## FM05: Incident active > 4h without resolution
- **Symptom:** MTTR exceeds 4h threshold.
- **Impact:** Original `response_sequence[]` is stale.
- **Handling:** Apply rolling response sequence update (see on-call-response-recommendation MTTR extended protocol).

## FM06: Circuit breaker triggered
- **Symptom:** Skill re-invoked ≥ 3 times without resolving readiness.
- **Impact:** Further re-generation will not resolve the issue.
- **Handling:** Stop regeneration. Emit `readiness: red`. Escalate to release-manager. Require new evidence before reset.


---

## Degradation examples — red state

### readiness: red — T1 incident, incident commander unavailable

```yaml
metadata:
  readiness: red
  selected_mode: major_incident_command
evidence_profile:
  confirmed: [alert_payload, initial_metrics]
  missing_evidence: [incident_commander_confirmed, war_room_established]
  confidence_ceiling_applied: high
tier_auto_classification:
  tier: T1
  page_oncall: true
  escalation_sla: 5m
incident_command:
  commander: unassigned
  blocker: "No incident commander confirmed — T1 incident cannot proceed without command structure"
  escalation_chain: [sre-director, vp-engineering]
response_sequence:
  - step: 1
    action: "PAGE SRE director immediately — incident commander required for T1"
    timebox: 2m
    owner: first-responder
    on_failure: escalate_to_vp
self_check:
  passed: false
  failed_rules:
    - "SCR-ONCALLRE-055: T1 incident without confirmed incident commander — readiness: red"
    - "Escalate immediately: page director-level to assign incident commander"
```

### Confidence quantification rule
```yaml
confidence_quantification:
  tier_1_alert_only:
    ceiling: low
    tier_classification: T2_default
    note: "T1 only confirmable with explicit impact signals"
  tier_1_confirmed:
    ceiling: medium
    tier_classification: T1
    must_have: [incident_command, war_room, escalation_chain]
  tier_2_confirmed:
    ceiling: medium
    tier_classification: T2
    response_depth: targeted
  tier_3_full_rca:
    ceiling: high
    response_depth: specific_with_rca
```