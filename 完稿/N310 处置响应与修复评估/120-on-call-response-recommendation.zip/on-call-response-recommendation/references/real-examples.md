# real-examples

## Example 1: on-call-response-recommendation — minimum viable input (120)

**Scenario:** Single alert, no RCA or impact scope available.

**Input given:**
- Alert: `checkout-service HTTP 5xx rate > 5% for 3 min`
- Time: 02:14 UTC
- No root cause, no impact data

**Expected output shape:**
```yaml
selected_mode: quick_triage
readiness: partial
tier_auto_classification:
  recommended_tier: 2
  rationale: "User-visible checkout impact; no confirmed data harm or compliance breach"
event_type_branch: availability
response_sequence:
  - step_id: R1
    goal: Confirm blast radius
    action: "Check checkout error rate dashboard for affected user cohort size"
    owner_role: on-call-engineer
    timebox: 5 min
    verification_signal: "Error rate trend direction (rising / stable / falling)"
    fallback_if_unsuccessful: "Escalate to checkout-team lead"
  - step_id: R2
    goal: Attempt safe containment
    action: "Enable feature flag CHECKOUT_FALLBACK_MODE if available"
    owner_role: on-call-engineer
    timebox: 10 min
    verification_signal: "5xx rate returns to < 1%"
    fallback_if_unsuccessful: "Proceed to rollback decision — see R3"
```

**Key calibration:** Minimum input → Tier 2 (not Tier 0) unless compliance breach or irreversible data harm is confirmed. Always emit at least 3 response steps even with partial evidence.

---

## Example 2: remediation-plan-recommendation — multiple path comparison (121)

**Scenario:** DB connection pool exhaustion identified as root cause.

**Input given:**
- RCA: `db.pool.max-size` reduced from 100→20 at 14:15 UTC caused checkout failures
- On-call response: feature flag containment partially effective (50% error reduction)
- Rollback evidence: config change is reversible

**Expected output shape:**
```yaml
selected_mode: stabilize_now
decision_weight_profile:
  regulatory_impact: 0.30
  user_impact: 0.25
  rollbackability: 0.20
  implementation_scope: 0.15
  verification_cost: 0.10
remediation_options:
  - fix_id: FIX-001
    remediation_path: rollback_first_then_fix
    objective: "Revert db.pool.max-size to 100; then investigate correct production value"
    immediate_effect: "Checkout error rate returns to baseline within 1 restart cycle"
    rollback_path: "Git revert config commit; rolling restart of checkout-service"
    criticality_class: Critical
    weighted_score: 0.87
    recommended_when: "Rollback dry-run evidence exists"
  - fix_id: FIX-002
    remediation_path: hotfix
    objective: "Deploy corrected pool size as emergency config patch"
    weighted_score: 0.61
    recommended_when: "Rollback is blocked (e.g., irreversible schema change)"
selected_path_recommendation:
  selected: FIX-001
  rationale: "Highest weighted score; reversible; rollback path confirmed"
hotfix_trigger_decision:
  trigger_hotfix: false
  reason: "Rollback path preferred; hotfix not needed for config-only change"
```

---

## Example 3: hotfix-risk-assessment — multi-event-type (122)

**Scenario:** Proposed hotfix touches both availability fix AND compliance-adjacent audit log.

**Input given:**
- Proposed diff: fixes connection pool config AND adds audit log for payment events
- Primary issue: availability (checkout outage)
- Secondary concern: compliance (audit log completeness)

**Expected output shape:**
```yaml
event_type_branch: availability  # primary
metadata:
  event_type_branch_secondary: [compliance]
  note: "Secondary compliance branch requires additional checklist items"
per_type_checklist:
  # availability items
  - checklist_id: CK-AV-001
    event_type_branch: availability
    control_area: rollback_safety
    requirement_level: mandatory
    blocker_if_failed: true
  # compliance items (added due to audit log change)
  - checklist_id: CK-CO-001
    event_type_branch: compliance
    control_area: audit_completeness
    requirement_level: mandatory
    question: "Does the new audit log meet retention and tamper-evidence requirements?"
    blocker_if_failed: true
go_no_go_recommendation:
  recommendation: conditional_go
  conditions:
    - "Compliance team confirms audit log schema meets retention policy"
    - "Rollback tested in staging with audit log rollback included"
```

**Key calibration for multi-event-type:** Always declare ONE primary `event_type_branch`; list secondaries explicitly. Add checklist items for each secondary branch. A secondary compliance branch can escalate go → conditional_go or no_go even if primary branch passes.

---

## Example 4: major_incident_command — T1 incident, multiple responders

**Scenario:** Payment service completely down. Revenue impact $50K+/hour. Multiple teams needed.

```yaml
metadata:
  readiness: ready
  selected_mode: major_incident_command
  acceptance_scenario: standard_release
tier_auto_classification:
  tier: T1
  rationale: "Revenue impact >$50K/hour, core payment function unavailable, estimated 15,000 affected users"
  escalation_sla: 15min
  page_oncall: true
event_type_branch: availability_outage
incident_snapshot:
  service: payment-service
  symptom: "Complete checkout failure — HTTP 503 for all requests"
  time_detected: "2026-05-20T14:00:00Z"
  affected_users_estimate: 15000
  revenue_impact_estimate: "$50K+/hour"
incident_command:
  incident_commander: sre-lead
  communications_lead: engineering-manager
  technical_lead: payment-service-owner
  war_room: "Slack #incident-war-room + Zoom link"
response_sequence:
  - step: 1
    action: "Incident commander declares T1 — send page to all on-call roles"
    timebox: 2m
    owner: sre-lead
    success_criteria: "All on-call roles acknowledged in Slack"
    on_failure: escalate_tier
  - step: 2
    action: "Pull status page: check if payment-service pods are Running"
    timebox: 3m
    owner: technical-lead
    success_criteria: "Pod status determined (Running/Pending/CrashLoopBackOff)"
    on_failure: continue
  - step: 3
    action: "Check recent deployments in payment-service (last 2 hours)"
    timebox: 3m
    owner: payment-service-owner
    success_criteria: "Deployment history reviewed; deploy candidate identified or ruled out"
    on_failure: continue
  - step: 4
    action: "Post customer-facing status page update: 'Investigating payment issues'"
    timebox: 5m
    owner: communications-lead
    success_criteria: "Status page updated publicly"
    on_failure: continue
  - step: 5
    action: "If deployment found in last 2h: initiate rollback (run rollback-plan-generation)"
    timebox: 15m
    owner: devops-team
    on_failure: escalate_tier
  - step: 6
    action: "If no deployment: run log-analysis + monitoring-metric-interpretation"
    timebox: 10m
    owner: technical-lead
    on_failure: continue
communication_cadence:
  internal_updates_every: 15min
  customer_comms_triggers: [T+0, T+30min, T+1h, resolution]
  executive_notification: "T+15min if not resolved"
downstream_handoff:
  to_skill: remediation-plan-recommendation
  urgency: immediate
self_check:
  passed: true
```

---

## Example 5: containment_only mode — rollback decision pending

**Scenario:** Error rate spike. Root cause unclear. Team decides to throttle traffic while investigating.

```yaml
metadata:
  readiness: ready
  selected_mode: containment_only
tier_auto_classification:
  tier: T2
event_type_branch: application_error
response_sequence:
  - step: 1
    action: "Enable traffic throttling: reduce payment-service load by 50%"
    timebox: 5m
    owner: sre-oncall
    success_criteria: "Error rate drops below 5% within 3 minutes of throttling"
    on_failure: escalate_to_T1
  - step: 2
    action: "Gather evidence while throttled: log-analysis + monitoring-metric-interpretation"
    timebox: 10m
    owner: payment-service-owner
    success_criteria: "Root cause hypothesis formed with confidence >= medium"
  - step: 3
    action: "Hand to remediation-plan-recommendation for fix path selection"
    timebox: 5m
    owner: sre-lead
downstream_handoff:
  to_skill: remediation-plan-recommendation
  containment_status: active_throttling
  urgency: high
self_check:
  passed: true
```


---

## Scenario calibration
See `references/real-examples.md` for scenarios covering quick_triage (minimal input), major_incident_command (full evidence), and containment_only (rollback as primary action).

For tier classification rubrics (T1–T3), see `references/incident-response-tier-rubrics.md`.
For event type branches (application_error, infra_failure, data_corruption, etc.), see `references/incident-response-event-types.md`.
For shared incident-response contract fields, see `references/incident-response-shared-contract.md`.