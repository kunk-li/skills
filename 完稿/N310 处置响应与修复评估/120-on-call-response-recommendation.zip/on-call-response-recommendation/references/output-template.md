# incident-response Output Template

## Recommended metadata block
- `contract_version`
- `workflow_node`
- `skill_id`
- `selected_mode`
- `readiness`
- `incident_id`
- `source_time_window`
- `service_scope`
- `event_type_branch`
- `evidence_profile`
- `confidence`
- `node_artifact_target`
- `function_bias`
- `stage_position`
- `composition_role`

## Evidence discipline
Always separate:
- direct evidence
- inference
- assumption
- blocker or missing input

## Handoff discipline
When another incident-response skill can use the result, include `downstream_handoff[]` with required fields, evidence_refs, open blockers, and next best checks.


---

## Downstream handoff YAML templates

### 正常路径: T2 incident → remediation-plan-recommendation
```yaml
downstream_handoff:
  produced_by: on-call-response-recommendation
  artifact: 值班处置建议.md
  emit_event:
    event_name: produced.incident-response.on_call_response.v2
  handoffs:
    - target: remediation-plan-recommendation
      handoff_type: evidence
      summary: "T2 incident. Evidence collected: DB pool exhaustion confirmed. Root cause hypothesis forming."
      required_fields:
        - tier_auto_classification
        - response_sequence
        - evidence_collected
        - preliminary_hypothesis
      confidence: medium
      next_best_checks:
        - "121: evaluate rollback vs hotfix based on preliminary_hypothesis"
    - target: root-cause-analysis-recommendation
      handoff_type: evidence
      summary: "Evidence refs for RCA: db_pool_metrics, payment_service_logs"
      confidence: low
      next_best_checks:
        - "119: run RCA with evidence_refs from this artifact"
```

### T1 阻断路径: immediate escalation
```yaml
downstream_handoff:
  handoffs:
    - target: remediation-plan-recommendation
      handoff_type: routing
      summary: "T1 MAJOR INCIDENT — coordinate remediation immediately"
      urgency: immediate
    - target: hotfix-risk-assessment
      handoff_type: routing
      summary: "If hotfix path chosen: run risk assessment before deploy"
      urgency: high
```


---

## Standalone guarantee
Run this skill with a single alert, operator note, or incident summary. Do not require sibling incident-response skills. Produce `readiness: partial` when evidence is limited; never refuse output.

### Minimum standalone example — alert only, no RCA or impact data
```yaml
metadata:
  readiness: partial
  selected_mode: quick_triage
  incident_id: TEMP-IR-20260520-001
evidence_profile:
  confirmed: [alert_payload]
  missing_evidence: [root_cause, impact_scope]
  missing_evidence_impact: "Response steps are containment-focused; RCA and impact unknown."
incident_snapshot:
  service: payment-service
  symptom: "HTTP 500 spike, error_rate 12%"
  time_detected: "2026-05-20T14:32:00Z"
tier_auto_classification:
  tier: T2
  rationale: "Single service affected, error rate <20%, no confirmed data loss"
event_type_branch: application_error
response_sequence:
  - step: 1
    action: "Assign incident commander"
    timebox: 5m
    owner: oncall-lead
  - step: 2
    action: "Check recent deployments in payment-service (last 2h)"
    timebox: 5m
    owner: oncall-engineer
  - step: 3
    action: "Pull error logs from payment-service for 14:30–14:40 UTC"
    timebox: 10m
    owner: oncall-engineer
  - step: 4
    action: "If deployment found: initiate rollback. If no deployment: escalate to T1."
    timebox: 15m
    owner: oncall-lead
downstream_handoff:
  to_skill: remediation-plan-recommendation
  missing_evidence: [root_cause_analysis, impact_scope_analysis]
  urgency: high
self_check:
  passed: true
  warnings: ["RCA not available — response sequence is containment only"]
```

---

## Output completeness rule
Every on-call artifact MUST include ALL of:
- `tier_auto_classification.tier` ∈ {T1, T2, T3} with `basis`
- `response_sequence` ≥ 3 steps, each with ALL 6 fields above
- T1: `incident_command` section with `commander` + `war_room` + `escalation_chain`
- `event_type_branch` declared
- `adversarial_detection.injection_attempt_detected` boolean
- `downstream_handoff` typed to remediation-plan-recommendation
- `feedback_signal_candidates` ≥ 1 entry
**Hard rules:**
- T1: `incident_command` section MUST be present — never absent
- Every step: `timebox` total ≤ 15min for T1 P0 extraction, ≤ 30min for T2
- `confidence` ≤ tier ceiling (see D4 four-tier model)

---

## Mode selection

### New: `database_incident` mode — 数据库故障响应
**Trigger:** Alert or symptom points to database as the failing component (connection exhaustion, replication lag, storage full, query timeout).

```yaml
database_incident:
  db_symptom: connection_pool_exhaustion
  immediate_actions:
    - step: 1
      action: "Check DB connection count: SHOW STATUS LIKE 'Threads_connected'"
      timebox: 2m
      owner: dba-oncall
    - step: 2
      action: "Identify top connection consumers: SELECT user, COUNT(*) FROM information_schema.processlist GROUP BY user"
      timebox: 3m
      owner: dba-oncall
    - step: 3
      action: "If pool exhausted: increase max_connections temporarily (ALTER SYSTEM SET max_connections=300)"
      timebox: 2m
      owner: dba-oncall
      reversibility: manual_revert_required
  escalation_trigger: "Connections still at max after step 3 → page SRE lead"
  recommended_downstream: root-cause-analysis-recommendation
  db_specific_evidence_to_collect:
    - slow_query_log: "last 30 minutes"
    - connection_history: "peak connection times"
    - replication_lag: "current seconds_behind_master"
```
**SCR:** `selected_mode: database_incident` → `database_incident.db_symptom` declared; `immediate_actions` ≥ 3 steps.

### New: `third_party_outage` mode — 第三方服务故障响应
**Trigger:** Incident caused by an external/third-party service (payment gateway, CDN, cloud provider, external API) that the team cannot directly fix.

```yaml
third_party_outage:
  third_party_service: "stripe-payment-gateway"
  outage_confirmed_at: "2026-05-20T14:00:00Z"
  status_page_url: "https://status.stripe.com"
  current_status: "Degraded — payment processing delays"
  team_options:
    - option: circuit_breaker_open
      action: "Open circuit breaker to payment-service; return friendly error to users"
      time_to_implement: 5m
      recommended: true
    - option: fallback_provider
      action: "Switch to backup payment gateway (Braintree)"
      time_to_implement: 30m
      recommended: false
      blocker: "Braintree credentials need to be enabled"
  communication_template:
    status_page_update: "We are aware of issues with payment processing. Our provider is investigating. We will update in 30 minutes."
    internal_channel: "#incidents"
  monitoring_cadence: "Check third-party status page every 10 minutes"
```
**SCR:** `selected_mode: third_party_outage` → `third_party_outage.team_options` ≥ 2 options; `communication_template` present.