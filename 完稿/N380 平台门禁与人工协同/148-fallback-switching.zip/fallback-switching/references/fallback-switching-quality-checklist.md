# Fallback Switching Quality Checklist

Use `references/n380-shared-gate-platform-contract.md` section 24 for the shared 11-item N380 quality checklist. Apply the skill-specific checks below after the shared checklist passes.

## Skill-specific checks
- category is one of DATA_DEGRADATION, SERVICE_DEGRADATION, PROCESS_DEGRADATION, or POLICY_DEGRADATION.
- rehearsal_allowed and rehearsal_status satisfy the validator's matrix.
- ACTIVE, BLOCKED, and DISABLED rows use concrete hcn_ref values, not `待确认`.
- POLICY_DEGRADATION rows preserve audit visibility and require HCN linkage unless NOT_APPLICABLE.
- strict cascade mode should be used when FAIL gates must also carry concrete fallback_ref values.
