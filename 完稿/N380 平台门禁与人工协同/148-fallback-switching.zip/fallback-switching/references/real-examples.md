# Real Examples / 真实示例参考

These examples illustrate correctly formed fallback rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Pre-release fallback design — rollback action required

**Input**: A team is designing a fallback for a new invoice AI feature before releasing to production.

**Correct pattern**:
```
fallback_id: FB-invoice-ai-001
fallback_trigger: AI categorization service returns error rate > 5% over 5 minutes
primary_path: AI-powered invoice categorization
fallback_path: manual categorization prompt shown to user
activation_status: not_activated
rollback_action: disable AI feature flag and restore manual prompt; no data migration required
rehearsal_status: not_rehearsed
rehearsal_planned: yes
notes: Fallback designed before release. Rehearsal must be completed in staging before GA. (AP-FALLBACK-03)
```

**Anti-pattern to avoid (AP-FALLBACK-02)**: Omitting `rollback_action` — without a defined rollback path, recovery from the degraded state has no playbook and requires ad-hoc engineering under incident pressure.

---

## Example 2: Incident-triggered fallback — activation status must be accurate

**Input**: During a production incident, the payment gateway times out. The team wants to activate the pre-designed fallback.

**Correct pattern**:
```
fallback_id: FB-payment-gateway-001
activation_status: activated
activated_at: "2026-05-21T14:32:00Z"
activated_by: on-call-sre-001
trigger_event: payment-gateway-timeout-incident-001
fallback_path: show retry-later message and queue payment for async retry
rollback_action: re-enable live payment gateway once p95 latency returns below 500ms
```

**Anti-pattern to avoid (AP-FALLBACK-01)**: Marking `activation_status: not_activated` after the fallback has been triggered — downstream audit and HCN records will incorrectly assume the primary path is operational.

---

## Example 3: Policy degradation — rehearsal is mandatory before production

**Input**: A fallback policy routes all enterprise invoice exports to a manual queue if the export service is degraded.

**Correct pattern**:
```
fallback_id: FB-export-degradation-001
rehearsal_status: rehearsed
rehearsal_date: "2026-05-10"
rehearsal_environment: staging
rehearsal_outcome: manual queue processed 200 test invoices in 3 minutes; acceptable for short-term degradation
notes: Do not deploy policy degradation fallbacks without a completed staging rehearsal. (AP-FALLBACK-03)
```
