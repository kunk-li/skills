# Fallback Switching Anti-Patterns

Use this reference when validating or repairing N380 output. It records negative examples that should be rejected, corrected, or downgraded to partial readiness.

## 148-specific anti-patterns

### AP-148-1: rehearsal_allowed and rehearsal_status conflict
- Bad: `rehearsal_allowed=yes` with `rehearsal_status=FORBIDDEN`, or `rehearsal_allowed=no` with `rehearsal_status=PASSED`.
- Why it is wrong: rehearsal policy and observed rehearsal state contradict each other.
- Validator expectation: `scripts/validate_csv.py` enforces the rehearsal matrix.
- Correct pattern: use `FORBIDDEN` only when rehearsal is `not_allowed`; use `PASSED` or `FAILED` only when rehearsal is allowed or conditional.

### AP-148-2: active fallback without a concrete HCN
- Bad: `activation_status=ACTIVE` with `hcn_ref=待确认` or `not_applicable`.
- Why it is wrong: an active, blocked, or disabled fallback path changes operations and must have an accountable human confirmation link.
- Validator expectation: `scripts/validate_csv.py` rejects missing concrete HCN refs for `ACTIVE`, `BLOCKED`, and `DISABLED`.
- Correct pattern: link an actual `HCN-*` row, or keep the fallback in a non-active planning state.

### AP-148-3: policy degradation without human confirmation
- Bad: `category=POLICY_DEGRADATION` with a live status and no `hcn_ref`.
- Why it is wrong: policy degradation can weaken controls and must not bypass governance signoff.
- Validator expectation: `scripts/validate_csv.py` rejects this unless status is `NOT_APPLICABLE`.
- Correct pattern: create or link a STRONG/VERY_STRONG HCN row.

### AP-148-4: meaningless rollback text
- Bad: `rollback_action=foo` or `rollback_action=TBD` for an active fallback.
- Why it is wrong: rollback instructions must be operationally usable.
- Validator expectation: strict mode warns or rejects under release policy.
- Correct pattern: specify a concrete reversal action, owner, trigger condition, and audit reference.


## Shared anti-pattern seeds from N380 adversarial testing

The anti-patterns in this file were distilled from regression tests that validators now enforce. Use them before finalizing output:

1. Do not let `PASS` hide `not_assessed_count > 0`.
2. Do not let `PENDING` or `NOT_ASSESSED` override hard rule violations.
3. Do not emit `COND_GO` when `cond_go_count = 0` and aggregation expects `PASS`.
4. Do not use schema fields that are not present in the CSV body or output contract.
5. Do not combine `rehearsal_allowed=yes` with `rehearsal_status=FORBIDDEN`.
6. Do not combine `rehearsal_allowed=no` with successful rehearsal outcomes.
7. Do not activate, block, or disable fallback without a concrete `HCN-*` reference.
8. Do not use `POLICY_DEGRADATION` as a way to bypass HCN or audit visibility.
9. Do not use `MULTI_SIGN` with one required signer.
10. Do not leave `PENDING` or `ESCALATED` HCN rows without a concrete `due_at`.
11. Do not count duplicate signers as independent approvals.
12. Do not use non-canonical audit templates for audit-required HCN rows.
13. Do not let metadata `cross_artifact_refs` include the artifact's own ID.

When a user request contains one of these patterns, preserve the evidence, explain the conflict briefly, and either correct the row or set `readiness=partial` with a concrete `pending_clarifications` entry.

