# Selected Mode Decision Tree - Fallback Switching

Use this decision tree before creating `失败兜底切换记录.csv`. Record the chosen value in `metadata.selected_mode`.

```text
Is the user designing fallback paths before a release or gate event?
├── yes -> pre_release_fallback_design
└── no: is a gate failure, incident, or live degradation already present?
    ├── yes -> incident_triggered_fallback
    └── no: is the task about rehearsal planning or rehearsal status?
        ├── yes -> rehearsal_planning
        └── no: is the main issue a policy/process degradation path?
            ├── yes -> policy_degradation_mode
            └── no -> pre_release_fallback_design with readiness=partial
```

## Guardrails
- `incident_triggered_fallback` must keep concrete gate or incident references when available.
- `rehearsal_planning` must not mark destructive or policy-prohibited fallbacks as rehearsable.
- `policy_degradation_mode` cannot bypass hard rules; keep HCN and audit visibility.
