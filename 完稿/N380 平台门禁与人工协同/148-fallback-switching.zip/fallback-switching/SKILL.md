---
name: fallback-switching
display_name: 失败兜底切换 / Fallback Switching
description: Classify and record controlled fallback switching across data, service, process, and policy degradation with activation status, rehearsal status, rollback action, and audit linkage.
---

# Fallback Switching

Use this skill for N380 platform gate governance. Keep the work at the gate-control layer: preserve upstream evidence, make the governance artifact machine-readable, and avoid redoing the domain review performed by upstream N300-N370 skills.

## N380 v1.5.0 contract baseline

- contract_version: `n380-platform-gate-v1.5.0`
- workflow_node: `N380`
- skill_id: `148`
- csv_schema: `n380.fallback-switching.v2`
- artifact_family_id: `n380-platform-gate-suite`
- artifact_target: `失败兜底切换记录.csv`
- function_bias: `fallback_switch`
- dsl_used: `category_checklist`
- packaging rule: the skill is self-contained and must not depend on external node-level shared directories, external node-level tools, sibling skills, or hidden registries.
- composition rule: compose through `artifact_id`, row IDs, `gate_scope`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

## Primary output

Produce `失败兜底切换记录.csv` in the exact CSV order defined by the skill-specific schema reference and by `references/output-contract.yaml`. Pair canonical outputs with `fallback-activation-example.metadata.yaml` style sidecar metadata.

## Inline field contract

Primary artifact: `失败兜底切换记录.csv`  Schema: `n380.fallback-switching.v2`

Produce CSV rows in exact schema column order (see `references/output-contract.yaml`). Use `待确认` for missing human-knowledge fields; use `not_applicable` only when a reference is explicitly irrelevant.

| field | required | description |
| --- | --- | --- |
| `fallback_id` | required | stable fallback row id — `FB-<scope>-<nnn>` |
| `gate_scope` | required | scope of the gate control point |
| `fallback_category` | required | `data\|service\|process\|policy` |
| `activation_status` | required | `active\|inactive\|rehearsal\|待确认` |
| `rehearsal_status` | required | `rehearsed\|not_rehearsed\|planned\|待确认` |
| `rollback_action` | required | rollback action or `待确认` |
| `hcn_ref` | required | human confirmation node ID or `not_applicable` |
| `audit_event_template` | required | audit event template reference |
| `evidence_refs` | required | source anchors |
| `confidence` | required | `high\|medium\|low\|needs_human_review` |
| `open_questions` | required | unresolved questions or `none` |

## Execution workflow

1. Identify the governance control point and upstream IDs.
2. Select one `selected_mode` from `references/output-contract.yaml` using `references/selected-mode-decision-tree.md`.
3. Preserve upstream IDs in `upstream_id_aliases`; do not rewrite N360/N370/N250 IDs.
4. Produce CSV rows in exact schema order.
5. Produce sidecar metadata with `contract_version`, `artifact_id`, `csv_schema`, `gate_scope`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.
6. Run `scripts/validate_csv.py <csv-file>` whenever file execution is available.
7. Run `scripts/validate_metadata.py <metadata.yaml>` for sidecar metadata whenever file execution is available.
8. Run `scripts/validate_skill_md.py SKILL.md` during release checks to catch stale SKILL.md version headings.
9. For composed three-artifact checks, run `scripts/validate_release_consistency.py <gate.metadata.yaml> <fallback.metadata.yaml> <hcn.metadata.yaml>` and `scripts/validate_cascade.py <gate.csv> <fallback.csv> <hcn.csv>`.
10. Check that `cross_artifact_refs` does not include the artifact's own `artifact_id`.
11. Mark missing human knowledge as `待确认`, and use `not_applicable` only when a reference is explicitly irrelevant.

## Standalone and composition role

Standalone: produce a partial but useful N380 artifact from available evidence, lowering confidence and setting `readiness=partial` when inputs are incomplete.

Composition: strengthen the N380 control chain by joining this artifact with gate-pass-decision, human-confirmation-node-management, state-transition-mapping, audit-trail-management, N390. Use stable row IDs and sidecar metadata rather than prose-only links.

## Mode selection at a glance

| mode | when to use |
| --- | --- |
| `activation_record` | recording a fallback that has been activated |
| `pre_release_design` | designing fallback paths before go-live |
| `rehearsal_planning` | planning and tracking fallback rehearsals |
| `policy_degradation` | recording policy-level service degradation |

For detailed mode selection logic, consult `references/selected-mode-decision-tree.md`.

## References

- `references/n380-shared-gate-platform-contract.md`
- `references/n380-id-space.md`
- `references/output-contract.yaml`
- `references/metadata-schema.json`
- `references/selected-mode-decision-tree.md`
- `references/anti-patterns.md`
- `references/fallback-switching-quality-checklist.md`

Also use the original skill-specific schema/reference files and `scripts/validate_csv.py`, `scripts/validate_metadata.py`, `scripts/validate_metadata_schema.py`, `validate_decision_tree.py`, `scripts/validate_skill_md.py`, `scripts/validate_release_consistency.py`, `scripts/validate_cascade.py`, and the self-contained helper `scripts/n380_validators_common.py` for strict CSV, metadata, JSON Schema, SKILL.md, release, and cascade validation.

## Examples

- `examples/fallback-activation-example.csv`
- `examples/fallback-policy-degradation-example.csv`
- `examples/fallback-pre-release-design-example.csv`
- `examples/fallback-rehearsal-planning-example.csv`
- `examples/fallback-activation-example.metadata.yaml`
- `examples/fallback-policy-degradation-example.metadata.yaml`
- `examples/fallback-pre-release-design-example.metadata.yaml`
- `examples/fallback-rehearsal-planning-example.metadata.yaml`

Differences from the examples are allowed when the user's source material requires them, but field naming, metadata order, ID shape, gate scope, and handoff shape should stay compatible.

## Quality bar

Read `references/anti-patterns.md` before finalizing whenever the artifact contains non-PASS gates, active fallbacks, human confirmations, or audit handoff requirements.


Before finalizing, verify the shared 11-item checklist in `references/n380-shared-gate-platform-contract.md` section 24 and the skill-specific checklist in the referenced quality file, validate the CSV and metadata, preserve audit visibility, and do not silently convert non-PASS, active fallback, or human confirmation requirements into a permissive outcome.



## Skill-specific anti-patterns (AP-FALLBACK-*)

These supplement the shared anti-patterns in `references/anti-patterns.md`.

| id | anti-pattern | why harmful | correct pattern |
| --- | --- | --- | --- |
| AP-FALLBACK-01 | marking a fallback as inactive when activation has not been confirmed | downstream assumes the primary path is safe when it may not be | set activation_status accurately; use 待确认 if status is unknown |
| AP-FALLBACK-02 | designing a fallback without a rollback action | recovery from the degraded state has no defined path | every fallback row must include a rollback_action or mark it as 待确认 |
| AP-FALLBACK-03 | omitting rehearsal_status on production fallbacks | untested fallbacks create false confidence before a release | record rehearsal_status; mark not_rehearsed and explain why if skipped |

## Three-skill integration cascade

To validate the full gate/fallback/HCN three-skill cascade from the `examples/integration/` directory:

```bash
python scripts/validate_cascade.py \
    examples/integration/gate-fail-example.csv \
    examples/integration/fallback-activation-example.csv \
    examples/integration/hcn-escalation-example.csv
```

See `examples/integration/README.md` for the full six-skill N380→N390 cascade command.

## N380 v1.5.0 semantic guardrails
- Run `scripts/validate_decision_tree.py references/selected-mode-decision-tree.md` before release to prevent selected_mode drift.
- Run `scripts/validate_release_consistency.py` to validate SKILL.md, metadata JSON Schema, decision tree, and cross-artifact references together.
- Use strict CSV mode for production/CI gate, fallback, and HCN artifacts.
