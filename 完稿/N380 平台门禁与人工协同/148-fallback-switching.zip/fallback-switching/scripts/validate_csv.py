#!/usr/bin/env python3
"""Validate fallback switching CSV records."""

import csv
import sys
from pathlib import Path

from n380_validators_common import PLACEHOLDERS, print_errors

EXPECTED_COLUMNS = [
    "fb_id", "fb_name", "category", "trigger_ref", "gate_ref", "activation_status",
    "rehearsal_allowed", "rehearsal_status", "owner", "severity", "preconditions",
    "switch_action", "rollback_action", "hcn_ref", "audit_required", "evidence_ref", "notes",
]

CATEGORIES = {"DATA_DEGRADATION", "SERVICE_DEGRADATION", "PROCESS_DEGRADATION", "POLICY_DEGRADATION"}
STATUSES = {"READY", "ACTIVE", "PENDING", "BLOCKED", "DISABLED", "NOT_APPLICABLE"}
REHEARSAL_ALLOWED = {"yes", "no", "conditional", "not_allowed"}
REHEARSAL_STATUS = {"NOT_STARTED", "PASSED", "FAILED", "WAIVED", "FORBIDDEN", "NOT_APPLICABLE"}
REHEARSAL_MATRIX = {
    "yes": {"NOT_STARTED", "PASSED", "FAILED", "WAIVED", "NOT_APPLICABLE"},
    "no": {"NOT_STARTED", "WAIVED", "NOT_APPLICABLE", "FORBIDDEN"},
    "conditional": {"NOT_STARTED", "PASSED", "FAILED", "WAIVED", "NOT_APPLICABLE"},
    "not_allowed": {"FORBIDDEN"},
}
SEVERITY = {"P0", "P1", "P2", "P3"}
YES_NO = {"yes", "no"}
ROLLBACK_ACTION_TERMS = {
    "rollback", "roll back", "revert", "restore", "switch", "failover", "disable",
    "degrade", "freeze", "route", "manual", "回滚", "恢复", "切换", "禁用", "降级", "冻结"
}

REQUIRED = {
    "fb_id", "fb_name", "category", "trigger_ref", "activation_status", "rehearsal_allowed",
    "rehearsal_status", "owner", "severity", "preconditions", "switch_action",
    "rollback_action", "hcn_ref", "audit_required", "evidence_ref",
}


def validate(path: Path, strict: bool = False) -> int:
    errors = []
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != EXPECTED_COLUMNS:
            errors.append("header mismatch: expected " + ",".join(EXPECTED_COLUMNS))
            errors.append("actual: " + ",".join(reader.fieldnames or []))
            print_errors(errors)
            return 1
        rows = list(reader)

    if not rows:
        errors.append("CSV has no data rows")

    seen = set()
    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED:
            if not (row.get(field) or "").strip():
                errors.append(f"row {idx}: {field} is required")
        fb_id = (row.get("fb_id") or "").strip()
        if fb_id in seen:
            errors.append(f"row {idx}: duplicate fb_id {fb_id}")
        seen.add(fb_id)

        category = (row.get("category") or "").strip()
        if category not in CATEGORIES:
            errors.append(f"row {idx}: category must be one of {sorted(CATEGORIES)}")
        status = (row.get("activation_status") or "").strip()
        if status not in STATUSES:
            errors.append(f"row {idx}: activation_status must be one of {sorted(STATUSES)}")
        rehearsal_allowed = (row.get("rehearsal_allowed") or "").strip()
        if rehearsal_allowed not in REHEARSAL_ALLOWED:
            errors.append(f"row {idx}: rehearsal_allowed must be one of {sorted(REHEARSAL_ALLOWED)}")
        rehearsal_status = (row.get("rehearsal_status") or "").strip()
        if rehearsal_status not in REHEARSAL_STATUS:
            errors.append(f"row {idx}: rehearsal_status must be one of {sorted(REHEARSAL_STATUS)}")
        severity = (row.get("severity") or "").strip()
        if severity not in SEVERITY:
            errors.append(f"row {idx}: severity must be one of {sorted(SEVERITY)}")
        audit_required = (row.get("audit_required") or "").strip()
        if audit_required not in YES_NO:
            errors.append(f"row {idx}: audit_required must be yes or no")

        hcn_ref = (row.get("hcn_ref") or "").strip()
        gate_ref = (row.get("gate_ref") or "").strip()
        trigger_ref = (row.get("trigger_ref") or "").strip()
        if status in {"ACTIVE", "BLOCKED", "DISABLED"} and hcn_ref in PLACEHOLDERS:
            errors.append(f"row {idx}: {status} fallback requires a concrete hcn_ref (not 待确认)")
        if rehearsal_allowed in REHEARSAL_MATRIX and rehearsal_status not in REHEARSAL_MATRIX[rehearsal_allowed]:
            errors.append(
                f"row {idx}: rehearsal_allowed={rehearsal_allowed} forbids rehearsal_status={rehearsal_status} "
                f"(allowed: {sorted(REHEARSAL_MATRIX[rehearsal_allowed])})"
            )
        if status in {"ACTIVE", "BLOCKED", "DISABLED"} and audit_required != "yes":
            errors.append(f"row {idx}: {status} fallback requires audit_required=yes")
        if category == "POLICY_DEGRADATION" and audit_required != "yes":
            errors.append(f"row {idx}: POLICY_DEGRADATION requires audit_required=yes")
        if category == "POLICY_DEGRADATION" and status != "NOT_APPLICABLE" and hcn_ref in {"", "not_applicable"}:
            errors.append(f"row {idx}: POLICY_DEGRADATION requires hcn_ref unless NOT_APPLICABLE")
        if trigger_ref.startswith("GATE-") and gate_ref not in {"", "not_applicable", "待确认"}:
            trigger_parts = {x.strip() for x in trigger_ref.split("|")}
            if gate_ref not in trigger_parts:
                print(f"WARN: row {idx}: trigger_ref starts with GATE- but does not include gate_ref {gate_ref}", file=sys.stderr)
        if severity == "P0" and status == "DISABLED":
            print(f"WARN: row {idx}: P0 fallback is DISABLED; verify intentional", file=sys.stderr)
        rollback_action = (row.get("rollback_action") or "").strip()
        if strict and status == "ACTIVE":
            lowered_action = rollback_action.lower()
            has_action_term = any(term in lowered_action for term in ROLLBACK_ACTION_TERMS)
            if len(rollback_action) < 8 or not has_action_term:
                errors.append(
                    f"row {idx}: ACTIVE fallback requires a semantically meaningful rollback_action "
                    f"with a rollback/switch/restore/degrade action term"
                )

    if errors:
        print_errors(errors)
        return 1
    print(f"OK: {path} has {len(rows)} valid fallback rows")
    return 0



if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--strict"]
    strict = "--strict" in sys.argv[1:]
    if len(args) != 1:
        print("Usage: validate_csv.py [--strict] <fallback_records.csv>", file=sys.stderr)
        sys.exit(2)
    sys.exit(validate(Path(args[0]), strict=strict))
