# Human Confirmation Node Anti-Patterns

Use this reference when validating or repairing N380 output. It records negative examples that should be rejected, corrected, or downgraded to partial readiness.

## 149-specific anti-patterns

### AP-149-1: MULTI_SIGN with a single required signer
- Bad: `type=MULTI_SIGN` with `required_count=1`.
- Why it is wrong: the type semantics require more than one signer.
- Validator expectation: `scripts/validate_csv.py` rejects this for non-DRAFT rows.
- Correct pattern: set `required_count>=2`, or change the type to `APPROVAL` if single approval is intended.

### AP-149-2: pending HCN without a due date
- Bad: `status=PENDING` or `ESCALATED` with `due_at=待确认`.
- Why it is wrong: pending human approval without an SLA has no enforceable governance clock.
- Validator expectation: `scripts/validate_csv.py` rejects this.
- Correct pattern: set a concrete `due_at`, or downgrade the row to `DRAFT` until timing is known.

### AP-149-3: duplicate signers hiding insufficient coverage
- Bad: `signers=alice|alice|bob` with `required_count=3`.
- Why it is wrong: duplicate names do not create independent approvals.
- Validator expectation: `scripts/validate_csv.py` compares required count against unique signers.
- Correct pattern: list unique signer identities or reduce `required_count` only when governance allows it.

### AP-149-4: audit-required rows with non-canonical audit templates
- Bad: `audit_required=yes` and `audit_event_template=TODO`.
- Why it is wrong: N390 cannot materialize an audit row from a non-canonical template.
- Validator expectation: `scripts/validate_csv.py` requires templates to start with `AU:new actor=...`.
- Correct pattern: use the canonical audit event format from `references/hcn-schema-and-signing-strength.md`.


## Shared anti-pattern seeds from N380 adversarial testing

The anti-patterns in this file were distilled from regression tests that validators now enforce. Use them before finalizing output:

1. Do not let `PASS` hide `not_assessed_count > 0`.
2. Do not let `PENDING` or `NOT_ASSESSED` override hard rule violations.
3. Do not emit `COND_GO` when `cond_go_count = 0` and aggregation expects `PASS`.
4. Do not use schema fields that are not present in the CSV body or output contract.
5. Do not combine `rehearsal_allowed=yes` with `rehearsal_status=FORBIDDEN`.
6. Do not combine `rehearsal_allowed=no` with successful rehearsal outcomes.
7. Do not activate, block, or disable fallback without a concrete `HCN-*` reference.
8. Do not use `POLICY_DEGRADATION` as a way to bypass HCN or audit visibility.
9. Do not use `MULTI_SIGN` with one required signer.
10. Do not leave `PENDING` or `ESCALATED` HCN rows without a concrete `due_at`.
11. Do not count duplicate signers as independent approvals.
12. Do not use non-canonical audit templates for audit-required HCN rows.
13. Do not let metadata `cross_artifact_refs` include the artifact's own ID.

When a user request contains one of these patterns, preserve the evidence, explain the conflict briefly, and either correct the row or set `readiness=partial` with a concrete `pending_clarifications` entry.

