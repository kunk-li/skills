# N380 Platform Gate ID Space

Contract version: `n380-platform-gate-v1.5.0`

## Artifact IDs
- `GATE-LOG-<project_or_release>-<yyyyww_or_nn>` for gate decision registers.
- `FB-LOG-<project_or_release>-<yyyyww_or_nn>` for fallback switching registers.
- `HCN-LIST-<project_or_release>-<yyyyww_or_nn>` for human confirmation node registers.

## Row IDs
- `GATE-<project>-<nn>` for a gate decision row.
- `FB-<project>-<nn>` for a fallback switching row.
- `HCN-<project>-<nn>` for a human confirmation node row.
- `AU-<project>-<nn>` for N390 audit event rows when an audit node is available.
- Upstream N370 IDs such as `RT-RULESET-*`, `PIPELINE-*`, `STM-*`, and `SNAP-*` must be preserved rather than renamed.

## Row-level reference rule
`gate_ref`, `fallback_ref`, `hcn_ref`, `state_transition_ref`, and `audit_ref` point to row-level IDs. `cross_artifact_refs` points to sibling artifact-level IDs.

## Temporary IDs
Use `TEMP-N380-<date>-<source>` only when the user asks for a standalone draft and stable IDs are unavailable. Track temporary IDs in `pending_clarifications` or `upstream_id_aliases`.

## No-self-reference rule
An artifact's `cross_artifact_refs` must not contain its own artifact ID. Handoff refs should match metadata refs.
