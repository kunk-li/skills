# N380 Shared Gate Platform Contract

## 1. Contract version
`n380-platform-gate-v1.5.0` governs node-level metadata, ID space, handoff, composition, examples, packaging consistency, and audit handoff behavior for N380.

## 2. Node scope
N380 turns upstream routing, release, risk, blocker, state, and human signoff signals into three strongly linked gate-control artifacts: gate decisions, fallback switching records, and human confirmation node records.

## 3. Encapsulation governance
Each skill is self-contained. A standalone skill zip must include its own `SKILL.md`, `agents/openai.yaml`, references, scripts, examples, and validators. Do not depend on external external node-level shared directories, external node-level tools, hidden registries, or sibling skill files at runtime.

## 4. Release consistency rule
All N380 skills in one release must carry the same `contract_version` in SKILL.md, this shared contract, output-contract.yaml, examples, metadata, and release notes.

## 5. Dual schema governance
`contract_version` governs node-level protocol. Per-skill `csv_schema` governs the machine CSV body:
- `n380.gate-pass-decision.v2`
- `n380.fallback-switching.v2`
- `n380.human-confirmation-node-management.v2`
Column changes require a per-skill schema bump. Metadata, ID, handoff, audit, or composition changes require a node contract bump.

## 6. Shared metadata schema
Every canonical output should be paired with a sidecar `.metadata.yaml` containing: `contract_version`, `workflow_node`, `skill_id`, `skill_name`, `artifact_family_id`, `artifact_id`, `csv_schema`, `selected_mode`, `readiness`, `pipeline_scope`, `gate_scope`, `decision_scope`, `source_time_window`, `source_artifacts`, `upstream_id_aliases`, `evidence_refs`, `cross_artifact_refs`, `pending_clarifications`, `pending_decisions`, `open_blockers`, `owner_placeholders`, `confidentiality_level`, `confidence`, `composition_role`, `function_bias`, `stage_position`, `dsl_used`, `artifact_target`, `engine_consumable`, `audit_required`, `audit_handoff_required`, and `freshness`.

## 7. Artifact and row ID space
Artifact IDs identify a file-level register. Row IDs identify individual gate, fallback, or human confirmation rows.

| skill | artifact id | row id |
|---|---|---|
| 147 | `GATE-LOG-<project_or_release>-<yyyyww_or_nn>` | `GATE-<project>-<nn>` |
| 148 | `FB-LOG-<project_or_release>-<yyyyww_or_nn>` | `FB-<project>-<nn>` |
| 149 | `HCN-LIST-<project_or_release>-<yyyyww_or_nn>` | `HCN-<project>-<nn>` |

Use `TEMP-N380-<date>-<source>` only for standalone fallback, and record it in `pending_clarifications` or `upstream_id_aliases`.

## 8. Row-level reference rule
Fields such as `gate_ref`, `fallback_ref`, `hcn_ref`, `state_transition_ref`, and `audit_ref` point to row-level IDs, not file-level artifact IDs. Use `cross_artifact_refs` for file-level sibling references.

## 9. Gate aggregation governance
147 owns gate aggregation. Apply the aggregation DSL in this order: hard rule violations dominate; unresolved blockers or fail counts produce FAIL; conditional counts produce COND_GO only when no hard rule violation exists; pending and not-assessed counts must not silently become PASS; PASS is allowed only when the evidence supports it.

## 10. Fallback category governance
148 owns fallback switching. Fallback is not a bypass for a failed gate. It is a controlled degraded path with owner, preconditions, switch action, rollback action, HCN linkage where needed, rehearsal status, and audit visibility. `POLICY_DEGRADATION` and active/blocked/disabled fallback paths require audit visibility.

## 11. HCN signing strength taxonomy
149 owns human confirmation nodes. `WEAK`, `MEDIUM`, `STRONG`, and `VERY_STRONG` represent increasing approval burden. `VERY_STRONG` is expected for irreversible, hard-rule, legal, financial, compliance, or broad-customer-impact decisions and must remain audit-visible.

## 12. Cross-skill linkage rules
- Gate `FAIL` must link `hcn_ref` and should link `fallback_ref` unless fallback is explicitly `not_applicable`.
- Gate `COND_GO` must link conditions, owner, deadline, and fallback dependency.
- Fallback `ACTIVE`, `BLOCKED`, or `DISABLED` must link `hcn_ref` and set `audit_required=yes`.
- HCN `VERY_STRONG` must set `audit_required=yes` and should not be fully reversible.
- N380 artifacts must join through row IDs and sidecar metadata, not prose-only references.

## 13. Audit cross-node handoff
`audit_ref` is a cross-node reference to N390 audit-trail artifacts. N380 may generate an `audit_event_template`, but it does not complete the N390 audit row. Use `audit_handoff_required=yes` when N390 should materialize an audit event from N380 output.

## 14. Evidence reference schema
Use evidence refs with `ref_id`, `source_family`, `source_name`, `time_window_or_version`, `scope`, `upstream_id_aliases`, `excerpt_or_pointer`, `confidence`, and `layer`. Allowed layers: `confirmed_fact`, `bounded_inference`, `open_question`.

## 15. Cross-artifact join keys
Join with `artifact_id`, row IDs (`GATE-*`, `FB-*`, `HCN-*`), `state_transition_ref`, `audit_ref`, and upstream IDs from N250/N320/N340/N350/N360/N370. `cross_artifact_refs` must not include the artifact's own `artifact_id`.

## 16. Standard composition paths
- `gate-fail-cascade`: 147 gate FAIL -> 149 HCN escalation + 148 fallback ACTIVE -> N390 audit.
- `cond-go-fallback`: 147 gate COND_GO -> 148 fallback READY -> 149 HCN approval -> N390 audit.
- `canary-progression`: 147 CANARY PASS -> 149 multi-sign confirmation when required -> next gate.
- `hcn-rejection-rollback`: 149 HCN REJECTED -> 148 fallback ROLLBACK -> 147 re-gate -> N390 audit.
- `standalone-fallback`: any skill may run alone with `readiness=partial` when evidence is incomplete.

## 17. Standalone guarantee
Each skill can produce a useful artifact from partial inputs. Missing human knowledge must be preserved as `待确认`; missing non-applicable references must be marked `not_applicable`; low evidence lowers confidence rather than removing the row.

## 18. Composition guarantee
147 owns gate aggregation and gate outcomes. 148 owns fallback readiness and switch control. 149 owns human confirmation nodes and audit event templates. Composition uses IDs and sidecar metadata, not implicit prose references.

## 19. Downstream handoff schema
`downstream_handoff` should include `contract_version`, `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `artifact_family_id`, `artifact_id`, `artifact_target`, `required_fields`, `cross_artifact_refs`, `pending_clarifications`, `pending_decisions`, `readiness`, `confidence`, `next_best_checks`, `decision_target_node`, `engine_consumable`, `audit_required`, `gate_scope`, and `audit_handoff_required`.

## 20. Metadata, release, and cascade validation governance
Use the bundled validators as the executable contract layer. Shared constants live in `scripts/n380_validators_common.py` inside each self-contained skill package:
- `scripts/validate_csv.py <artifact.csv>` validates skill-specific CSV columns, enums, count logic, cross-field safety rules, and strict mode when requested.
- `scripts/validate_metadata.py <artifact.metadata.yaml>` validates required sidecar metadata fields, `artifact_id` format, quoted audit yes/no strings, handoff version consistency, and no self-reference in `cross_artifact_refs`.
- `scripts/validate_skill_md.py <SKILL.md>` validates the SKILL.md contract baseline heading and body contract version.
- `scripts/validate_release_consistency.py <gate.metadata.yaml> <fallback.metadata.yaml> <hcn.metadata.yaml>` validates release-level contract version consistency, sibling artifact references, and nearby SKILL.md version alignment across 147/148/149.
- `scripts/validate_cascade.py <gate.csv> <fallback.csv> <hcn.csv>` validates row-level references for gate-fail-cascade and related N380 compositions.

`audit_required` and `audit_handoff_required` must use explicit string values `"yes"` or `"no"` in metadata and handoff blocks to avoid YAML 1.1 boolean coercion.

## 21. Engine consumer guarantee
Canonical artifacts must be machine-readable CSV plus sidecar metadata YAML. Narrative summaries may be provided for humans, but CSV and metadata are the source of truth.

## 22. Common execution workflow
1. Normalize upstream signals and IDs.
2. Select the N380 skill and selected_mode.
3. Preserve upstream IDs in `upstream_id_aliases`.
4. Produce CSV rows in exact schema order.
5. Produce sidecar metadata and downstream handoff.
6. Validate CSV with the bundled validator.
7. Check cross-artifact refs for no self-reference.
8. Mark unresolved human knowledge as `待确认`.

## 23. Common self-check
Before finalizing, verify version consistency, schema order, row IDs, no self-reference, evidence refs, non-PASS escalation, HCN requirements, fallback safety, audit visibility, machine readability, standalone/composition readiness, and N390 audit handoff requirements.

## 24. Common quality checklist shared by 147/148/149
Use this shared 11-item checklist for every N380 artifact before applying the skill-specific checklist file:
1. Contract version is `n380-platform-gate-v1.5.0` in SKILL.md, output contract, metadata, and handoff.
2. CSV columns exactly match the skill-specific schema and bundled validator.
3. Artifact ID and row IDs follow `references/n380-id-space.md`.
4. `cross_artifact_refs` contains sibling artifacts only and never references the artifact itself.
5. `gate_scope` is present and aligns with row-level gate IDs.
6. Evidence refs include source, scope, time/version, pointer, confidence, and layer.
7. Non-PASS gate, active fallback, and STRONG/VERY_STRONG HCN paths preserve audit visibility.
8. Human knowledge is never fabricated; unknowns are marked `待确认`.
9. `downstream_handoff` declares N390 audit needs through `audit_handoff_required`.
10. Standalone use lowers readiness/confidence instead of inventing missing fields.
11. Composition joins through row IDs and sidecar metadata, not prose-only links.


## 25. Anti-pattern governance
Each skill includes `references/anti-patterns.md` with negative examples derived from prior N380 adversarial regression testing. Use it before finalization to catch false PASS, hard-rule override, missing HCN, invalid rehearsal, invalid multi-sign, non-canonical audit template, and metadata self-reference patterns. Anti-patterns are educational guidance plus validator-backed checks; when an anti-pattern is detected, correct the row or downgrade readiness with a concrete pending clarification.

## 26. Metadata JSON Schema governance
Each skill includes `references/metadata-schema.json` as a cross-language contract for sidecar `.metadata.yaml` files. The schema is skill-specific where needed: `skill_id`, `csv_schema`, `selected_mode`, `artifact_id` pattern, and `artifact_target` are pinned to the owning skill. Use `scripts/validate_metadata_schema.py <metadata.yaml>` to validate the sidecar against this JSON Schema without relying on external packages. The JSON Schema complements, rather than replaces, `validate_metadata.py`: the former is a portable schema artifact, while the latter contains N380-specific semantic checks such as no self-reference and handoff alignment.

## 27. Selected-mode decision tree governance
Each skill includes `references/selected-mode-decision-tree.md`. Use it before writing rows or metadata. The chosen `metadata.selected_mode` must match the user's source material and the example family. If multiple modes appear plausible, choose the one that preserves prior IDs and auditability; lower `readiness` and add `pending_clarifications` instead of selecting a permissive mode to make validation pass.

## 28. SKILL.md and description guardrail
`scripts/validate_skill_md.py` guards the contract baseline heading and body version. In v1.5.0, SKILL.md review also treats a missing or overly generic routing description as a release risk: descriptions should explain what the skill owns and explicitly redirect to sibling skills for non-owned work.

## Metadata schema strictness and release validation (v1.5.0)
- `metadata-schema.json` is strict for root, `metadata`, `downstream_handoff`, and common nested objects; unknown direct fields are invalid.
- `validate_release_consistency.py` must run SKILL.md, JSON Schema, and selected-mode decision-tree checks in addition to cross-artifact consistency.
- A valid release has no stale contract heading, no unexpected metadata fields, and no decision-tree mode drift.


## Strict gate/fallback/HCN semantic rules (v1.5.0)
- CANARY and GA gates require a concrete `state_transition_ref` in strict mode.
- ACTIVE fallback rows require a rollback action with an explicit rollback, restore, switch, failover, disable, degrade, or equivalent action term in strict mode.
- STRONG RELEASE / COMPLIANCE / ROLLBACK HCN rows cannot be fully reversible; use `partial` or `no`.

