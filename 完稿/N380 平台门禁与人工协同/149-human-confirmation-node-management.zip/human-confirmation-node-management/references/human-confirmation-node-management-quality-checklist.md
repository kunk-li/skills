# Human Confirmation Node Management Quality Checklist

Use `references/n380-shared-gate-platform-contract.md` section 24 for the shared 11-item N380 quality checklist. Apply the skill-specific checks below after the shared checklist passes.

## Skill-specific checks
- signing_strength matches the decision burden: WEAK, MEDIUM, STRONG, or VERY_STRONG.
- MULTI_SIGN rows require at least two required signers outside DRAFT.
- PENDING and ESCALATED rows carry concrete due_at values, not `待确认`.
- STRONG and VERY_STRONG rows preserve audit visibility through audit_required and audit_event_template.
- audit_event_template starts with `AU:new actor=...` whenever audit_required is `yes`.
