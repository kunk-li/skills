# Selected Mode Decision Tree - Human Confirmation Node Management

Use this decision tree before creating `人工确认节点清单.csv`. Record the chosen value in `metadata.selected_mode`.

```text
Are you creating a new human-confirmation register from gate/fallback evidence?
├── yes -> fresh_hcn_register
└── no: are you updating existing HCN rows, signers, status, or due dates?
    ├── yes -> delta_hcn_refresh
    └── no: is the request only about escalations or urgent approvals?
        ├── yes -> escalation_only_mode
        └── no: is the request primarily compliance, audit, or irreversible approval evidence?
            ├── yes -> compliance_audit_mode
            └── no -> fresh_hcn_register with readiness=partial
```

## Guardrails
- `MULTI_SIGN` and `ESCALATION` require the signer count and strength to match the meaning of the type.
- `compliance_audit_mode` must keep `audit_required=yes` and a canonical `audit_event_template`.
- `delta_hcn_refresh` preserves prior `hcn_id` values; do not reissue row IDs.
