# Real Examples / 真实示例参考

These examples illustrate correctly formed HCN rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Fresh HCN register — signing strength matches action irreversibility

**Input**: A finance admin requests a bulk deletion of 5,000 invoice records. The action is irreversible.

**Correct pattern**:
```
hcn_id: HCN-invoice-bulk-delete-001
action_description: bulk deletion of 5,000 invoice records for fiscal year 2023
irreversible: yes
signing_strength: strong
required_signers: [finance-lead, legal-compliance-officer]
sla_hours: 24
```

**Anti-pattern to avoid (AP-HCN-01)**: Setting `signing_strength: weak` for an irreversible bulk deletion — a single acknowledger can authorize an action that cannot be undone without legal and financial audit implications.

---

## Example 2: Escalation HCN — SLA required to prevent workflow stall

**Input**: A gate is blocked on a security review sign-off. No deadline has been set.

**Correct pattern**:
```
hcn_id: HCN-security-sign-off-001
action_description: security review sign-off for SSO integration before release
irreversible: no
signing_strength: medium
required_signers: [security-lead]
sla_hours: 48
escalation_path: if no sign-off within 48 hours, escalate to VP-Engineering
```

**Anti-pattern to avoid (AP-HCN-02)**: Omitting `sla_hours` on a blocking HCN — without a deadline, the workflow may stall indefinitely with no escalation trigger.

---

## Example 3: Delta HCN refresh — unique hcn_id per confirmation event

**Input**: The same security lead must re-confirm after a code change was made post the initial sign-off.

**Correct pattern**:
```
hcn_id: HCN-security-sign-off-002
action_description: re-confirmation of security sign-off after post-review code change (patch v2)
prior_hcn_ref: HCN-security-sign-off-001
selected_mode: delta_hcn_refresh
irreversible: no
signing_strength: medium
required_signers: [security-lead]
sla_hours: 24
```

**Anti-pattern to avoid (AP-HCN-03)**: Reusing `HCN-security-sign-off-001` for the re-confirmation — the audit trail cannot distinguish the original sign-off from the post-change confirmation, hiding the fact that a code change occurred between them.
