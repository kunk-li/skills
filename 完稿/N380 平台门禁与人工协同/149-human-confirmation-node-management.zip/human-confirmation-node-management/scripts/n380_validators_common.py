#!/usr/bin/env python3
"""Shared constants and helpers for N380 validators.

This file is intentionally copied into each skill so every skill remains fully
self-contained while avoiding version and placeholder drift inside the package.
"""

import re
import sys
from pathlib import Path

try:
    import yaml
except Exception as exc:  # pragma: no cover
    print(f"ERROR: PyYAML is required for N380 validation: {exc}", file=sys.stderr)
    sys.exit(2)

CONTRACT_VERSION = "n380-platform-gate-v1.5.0"
WORKFLOW_NODE = "N380"
PLACEHOLDERS = {"", "not_applicable", "待确认"}
YES_NO = {"yes", "no"}

REQUIRED_METADATA_FIELDS = {
    "contract_version", "workflow_node", "skill_id", "skill_name",
    "artifact_family_id", "artifact_id", "csv_schema", "selected_mode",
    "readiness", "pipeline_scope", "gate_scope", "decision_scope",
    "source_time_window", "source_artifacts", "upstream_id_aliases",
    "evidence_refs", "cross_artifact_refs", "pending_clarifications",
    "pending_decisions", "open_blockers", "owner_placeholders",
    "confidentiality_level", "confidence", "composition_role",
    "function_bias", "stage_position", "dsl_used", "artifact_target",
    "engine_consumable", "audit_required", "audit_handoff_required",
    "freshness",
}

ARTIFACT_ID_RE = {
    "147": re.compile(r"^GATE-LOG-[A-Za-z0-9_-]+-(\d{6}|\d{2})$"),
    "148": re.compile(r"^FB-LOG-[A-Za-z0-9_-]+-(\d{6}|\d{2})$"),
    "149": re.compile(r"^HCN-LIST-[A-Za-z0-9_-]+-(\d{6}|\d{2})$"),
}


def load_yaml(path):
    """Load YAML and return an empty mapping for empty files."""
    return yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}


def split_pipe(value):
    """Split N380 pipe-list fields while removing placeholders."""
    return [
        item.strip()
        for item in (value or "").split("|")
        if item.strip() and item.strip() not in PLACEHOLDERS
    ]


def is_placeholder(value):
    return (value or "").strip() in PLACEHOLDERS


def print_errors(errors):
    for error in errors:
        print("ERROR:", error, file=sys.stderr)


def print_warnings(warnings):
    for warning in warnings:
        print("WARN:", warning, file=sys.stderr)
