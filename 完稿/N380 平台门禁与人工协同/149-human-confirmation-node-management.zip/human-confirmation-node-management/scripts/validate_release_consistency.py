#!/usr/bin/env python3
"""Cross-skill release consistency check for N380 147/148/149 metadata, schemas, SKILL.md, and selected-mode trees."""

import sys
from pathlib import Path

from n380_validators_common import CONTRACT_VERSION, load_yaml, print_errors
from validate_skill_md import validate_skill_md
from validate_metadata_schema import validate_metadata_schema
from validate_decision_tree import validate_decision_tree


def find_skill_root_from_metadata(meta_path):
    path = Path(meta_path).resolve()
    for parent in [path.parent, *path.parents]:
        if (parent / "SKILL.md").exists() and (parent / "references").exists():
            return parent
    return None


def main(gate_meta, fb_meta, hcn_meta):
    errors = []
    meta_paths = {"147": gate_meta, "148": fb_meta, "149": hcn_meta}
    docs = {label: load_yaml(path) for label, path in meta_paths.items()}
    metadata = {k: (v.get("metadata") or {}) for k, v in docs.items()}
    versions = {k: v.get("contract_version") for k, v in metadata.items()}
    artifact_ids = {k: v.get("artifact_id") for k, v in metadata.items()}

    if len(set(versions.values())) > 1 or set(versions.values()) != {CONTRACT_VERSION}:
        errors.append(f"contract_version mismatch or unexpected version across skills: {versions}")

    for label, meta_path in meta_paths.items():
        root = find_skill_root_from_metadata(meta_path)
        if root is None:
            errors.append(f"{label}: unable to locate skill root near {meta_path}")
            continue
        skill_md = root / "SKILL.md"
        schema = root / "references" / "metadata-schema.json"
        tree = root / "references" / "selected-mode-decision-tree.md"
        output_contract = root / "references" / "output-contract.yaml"

        for err in validate_skill_md(skill_md, strict=True):
            errors.append(f"{label}: {err} (hint: re-run scripts/validate_skill_md.py --strict {skill_md})")
        for err in validate_metadata_schema(Path(meta_path), schema):
            errors.append(f"{label}: metadata schema: {err} (hint: re-run scripts/validate_metadata_schema.py {meta_path})")
        for err in validate_decision_tree(tree, output_contract):
            errors.append(f"{label}: decision tree: {err} (hint: re-run scripts/validate_decision_tree.py {tree})")

    required_refs = {
        "147": {artifact_ids.get("148"), artifact_ids.get("149")},
        "148": {artifact_ids.get("147"), artifact_ids.get("149")},
        "149": {artifact_ids.get("147"), artifact_ids.get("148")},
    }
    for label, required in required_refs.items():
        required = {r for r in required if r}
        refs = set(metadata[label].get("cross_artifact_refs") or [])
        if not required.issubset(refs):
            errors.append(f"{label} cross_artifact_refs must include {sorted(required)}; got {sorted(refs)}")
        if artifact_ids.get(label) in refs:
            errors.append(f"{label} cross_artifact_refs self-reference {artifact_ids[label]}")

    if errors:
        print_errors(errors)
        print("hint: run validate_skill_md.py, validate_metadata_schema.py, or validate_decision_tree.py for component details", file=sys.stderr)
        return 1
    print("OK: 147/148/149 release-consistency, SKILL.md, metadata schema, and decision-tree checks passed")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: validate_release_consistency.py <gate.metadata.yaml> <fallback.metadata.yaml> <hcn.metadata.yaml>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(*sys.argv[1:4]))
