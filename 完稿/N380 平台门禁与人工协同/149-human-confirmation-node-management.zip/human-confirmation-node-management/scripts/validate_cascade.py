#!/usr/bin/env python3
"""Verify gate-fail-cascade row-level references across 147/148/149 CSV outputs."""

import csv
import sys
from pathlib import Path

from n380_validators_common import PLACEHOLDERS, print_errors, split_pipe


def rows_by_id(path, id_col):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        return {row[id_col].strip(): row for row in csv.DictReader(f) if row.get(id_col, "").strip()}


def main(gate_csv, fb_csv, hcn_csv, strict=False):
    errors = []
    gate_rows = rows_by_id(gate_csv, "gate_id")
    fb_rows = rows_by_id(fb_csv, "fb_id")
    hcn_rows = rows_by_id(hcn_csv, "hcn_id")

    for gate_id, row in gate_rows.items():
        decision = (row.get("decision") or "").strip()
        for ref in split_pipe(row.get("hcn_ref")):
            if ref not in hcn_rows:
                errors.append(f"gate {gate_id}: hcn_ref {ref!r} not found in HCN CSV")
        for ref in split_pipe(row.get("fallback_ref")):
            if ref not in fb_rows:
                errors.append(f"gate {gate_id}: fallback_ref {ref!r} not found in fallback CSV")
        if decision == "FAIL":
            if not split_pipe(row.get("hcn_ref")):
                errors.append(f"gate {gate_id}: FAIL requires concrete hcn_ref")
            if strict and not split_pipe(row.get("fallback_ref")):
                errors.append(f"gate {gate_id}: strict mode requires FAIL to carry concrete fallback_ref")

    for fb_id, row in fb_rows.items():
        gate_ref = (row.get("gate_ref") or "").strip()
        hcn_ref = (row.get("hcn_ref") or "").strip()
        status = (row.get("activation_status") or "").strip()
        if gate_ref not in PLACEHOLDERS and gate_ref not in gate_rows:
            errors.append(f"fallback {fb_id}: gate_ref {gate_ref!r} not found in gate CSV")
        if hcn_ref not in PLACEHOLDERS and hcn_ref not in hcn_rows:
            errors.append(f"fallback {fb_id}: hcn_ref {hcn_ref!r} not found in HCN CSV")
        if status in {"ACTIVE", "BLOCKED", "DISABLED"} and hcn_ref in PLACEHOLDERS:
            errors.append(f"fallback {fb_id}: {status} requires concrete hcn_ref")

    for hcn_id, row in hcn_rows.items():
        gate_ref = (row.get("gate_ref") or "").strip()
        fallback_ref = (row.get("fallback_ref") or "").strip()
        if gate_ref not in PLACEHOLDERS and gate_ref not in gate_rows:
            errors.append(f"hcn {hcn_id}: gate_ref {gate_ref!r} not found in gate CSV")
        if fallback_ref not in PLACEHOLDERS and fallback_ref not in fb_rows:
            errors.append(f"hcn {hcn_id}: fallback_ref {fallback_ref!r} not found in fallback CSV")

    if errors:
        print_errors(errors)
        return 1
    print("OK: cascade refs resolve across 147/148/149")
    return 0


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--strict"]
    strict = "--strict" in sys.argv[1:]
    if len(args) != 3:
        print("Usage: validate_cascade.py [--strict] <gate.csv> <fallback.csv> <hcn.csv>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(*args, strict=strict))
