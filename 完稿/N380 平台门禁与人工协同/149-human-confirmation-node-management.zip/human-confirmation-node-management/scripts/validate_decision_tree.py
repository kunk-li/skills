#!/usr/bin/env python3
"""Validate selected-mode decision tree leaves against output-contract.yaml."""
import re
import sys
from pathlib import Path

from n380_validators_common import load_yaml, print_errors


def validate_decision_tree(tree_path: Path, output_contract_path: Path):
    text = tree_path.read_text(encoding="utf-8")
    contract = load_yaml(output_contract_path)
    expected = set(contract.get("selected_modes") or [])
    errors = []
    if not expected:
        errors.append("output-contract.yaml has no selected_modes")
        return errors
    missing = sorted(mode for mode in expected if mode not in text)
    for mode in missing:
        errors.append(f"decision tree missing selected_mode leaf {mode!r}")

    # Extract snake_case leaves used after arrows or in backticks, then flag suspicious uncontracted modes.
    found = set(re.findall(r"(?:->|`)\s*([a-z][a-z0-9]+(?:_[a-z0-9]+)+)", text))
    allowed_non_modes = {"readiness_partial", "pending_clarifications"}
    unexpected = sorted(found - expected - allowed_non_modes)
    for mode in unexpected:
        if mode.endswith("_mode") or mode.endswith("_evaluation") or mode.endswith("_refresh") or mode.endswith("_planning"):
            errors.append(f"decision tree contains non-contract mode-looking token {mode!r}")
    return errors


def main(argv):
    if len(argv) not in {1, 2}:
        print("Usage: validate_decision_tree.py <selected-mode-decision-tree.md> [output-contract.yaml]", file=sys.stderr)
        return 2
    tree = Path(argv[0])
    output = Path(argv[1]) if len(argv) == 2 else tree.parent / "output-contract.yaml"
    if not output.exists():
        output = tree.parent / ".." / "references" / "output-contract.yaml"
    errors = validate_decision_tree(tree, output.resolve())
    if errors:
        print_errors(errors)
        return 1
    print(f"OK: {tree} selected_mode leaves match {output.resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
