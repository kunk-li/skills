#!/usr/bin/env python3
"""Validate SKILL.md headers, frontmatter description, and contract baseline."""
import re
import sys
from pathlib import Path
from n380_validators_common import CONTRACT_VERSION, print_errors

EXPECTED_HEADING = f"## N380 {CONTRACT_VERSION.split('-')[-1]} contract baseline"
MIN_DESCRIPTION_CHARS = 160


def extract_description(text: str) -> str:
    m = re.search(r"^---\n(.*?)\n---", text, re.S)
    if not m:
        return ""
    block = m.group(1)
    line = re.search(r"^description:\s*(.*)$", block, re.M)
    return (line.group(1) if line else "").strip().strip('"').strip("'")


def validate_skill_md(path, strict: bool = True):
    text = Path(path).read_text(encoding="utf-8")
    errors = []

    if EXPECTED_HEADING not in text:
        errors.append(f"SKILL.md must contain heading {EXPECTED_HEADING!r}; found stale or missing version heading")

    m = re.search(r"contract_version:\s*`([^`]+)`", text)
    if not m:
        errors.append("SKILL.md body missing `contract_version:` line in baseline section")
    elif m.group(1) != CONTRACT_VERSION:
        errors.append(f"SKILL.md contract_version body says {m.group(1)!r}, expected {CONTRACT_VERSION!r}")

    description = extract_description(text)
    if strict:
        if len(description) < MIN_DESCRIPTION_CHARS:
            errors.append(f"frontmatter description is too short for reliable routing ({len(description)} chars; expected >= {MIN_DESCRIPTION_CHARS})")
        if "not for" not in description.lower() or "use " not in description.lower():
            errors.append("frontmatter description should include sibling-skill redirects such as 'not for ... use ...'")
    return errors


def main(argv) -> int:
    args = list(argv)
    strict = True
    if "--no-strict" in args:
        strict = False
        args.remove("--no-strict")
    if "--strict" in args:
        strict = True
        args.remove("--strict")
    if len(args) != 1:
        print("Usage: validate_skill_md.py [--strict|--no-strict] <SKILL.md>", file=sys.stderr)
        return 2
    errors = validate_skill_md(Path(args[0]), strict=strict)
    if errors:
        print_errors(errors)
        return 1
    mode = " strict" if strict else ""
    print(f"OK: {args[0]} skill metadata{mode} aligned with {CONTRACT_VERSION}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
