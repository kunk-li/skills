#!/usr/bin/env python3
"""Validate N380 sidecar metadata against the bundled JSON Schema.

The validator intentionally implements the small subset of JSON Schema used by
N380 without external dependencies, so each skill zip remains self-contained.
"""
import json
import re
import sys
from pathlib import Path

from n380_validators_common import load_yaml, print_errors

TYPE_CHECKS = {
    "object": lambda v: isinstance(v, dict),
    "array": lambda v: isinstance(v, list),
    "string": lambda v: isinstance(v, str),
    "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
    "boolean": lambda v: isinstance(v, bool),
}


def validate_value(value, schema, path):
    errors = []
    expected_type = schema.get("type")
    if expected_type:
        checker = TYPE_CHECKS.get(expected_type)
        if checker and not checker(value):
            return [f"{path}: expected {expected_type}, got {type(value).__name__}"]

    if "const" in schema and value != schema["const"]:
        errors.append(f"{path}: expected {schema['const']!r}, got {value!r}")
    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path}: expected one of {schema['enum']!r}, got {value!r}")
    if "pattern" in schema and isinstance(value, str) and not re.match(schema["pattern"], value):
        errors.append(f"{path}: value {value!r} does not match {schema['pattern']!r}")

    if isinstance(value, dict):
        props = schema.get("properties", {})
        required = schema.get("required", [])
        for field in required:
            if field not in value:
                errors.append(f"{path}: missing required field {field!r}")
        if schema.get("additionalProperties") is False:
            extras = sorted(set(value) - set(props))
            for extra in extras:
                errors.append(f"{path}: unexpected field {extra!r}")
        for field, spec in props.items():
            if field in value:
                errors.extend(validate_value(value[field], spec, f"{path}.{field}"))

    if isinstance(value, list) and "items" in schema:
        for idx, item in enumerate(value):
            errors.extend(validate_value(item, schema["items"], f"{path}[{idx}]"))
    return errors


def validate_metadata_schema(metadata_path: Path, schema_path: Path):
    data = load_yaml(metadata_path)
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    errors = validate_value(data, schema, "root")

    md = data.get("metadata", {}) if isinstance(data, dict) else {}
    handoff = data.get("downstream_handoff", {}) if isinstance(data, dict) else {}
    artifact_id = md.get("artifact_id") if isinstance(md, dict) else None
    if artifact_id and artifact_id in (md.get("cross_artifact_refs") or []):
        errors.append("metadata.cross_artifact_refs must not include artifact_id")
    if artifact_id and artifact_id in (handoff.get("cross_artifact_refs") or []):
        errors.append("downstream_handoff.cross_artifact_refs must not include artifact_id")
    if artifact_id and handoff.get("artifact_id") and handoff.get("artifact_id") != artifact_id:
        errors.append("downstream_handoff.artifact_id must match metadata.artifact_id")
    return errors


def main(argv):
    if len(argv) not in {1, 2}:
        print("Usage: validate_metadata_schema.py <metadata.yaml> [metadata-schema.json]", file=sys.stderr)
        return 2
    metadata = Path(argv[0])
    schema = Path(argv[1]) if len(argv) == 2 else Path(__file__).resolve().parent.parent / "references" / "metadata-schema.json"
    errors = validate_metadata_schema(metadata, schema)
    if errors:
        print_errors(errors)
        return 1
    print(f"OK: {metadata} conforms to {schema}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
