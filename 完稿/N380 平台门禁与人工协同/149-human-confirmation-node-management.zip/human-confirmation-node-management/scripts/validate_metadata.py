#!/usr/bin/env python3
"""Validate sidecar metadata YAML for N380 skills 147/148/149."""

import re
import sys
from pathlib import Path

from n380_validators_common import (
    ARTIFACT_ID_RE,
    CONTRACT_VERSION,
    REQUIRED_METADATA_FIELDS,
    WORKFLOW_NODE,
    YES_NO,
    load_yaml,
    print_errors,
)


def main(path: Path) -> int:
    raw = path.read_text(encoding="utf-8")
    data = load_yaml(path)
    errors = []
    md = data.get("metadata", {}) or {}
    handoff = data.get("downstream_handoff", {}) or {}

    missing = REQUIRED_METADATA_FIELDS - set(md.keys())
    if missing:
        errors.append(f"metadata missing required fields: {sorted(missing)}")

    if "contract_version" in md and md.get("contract_version") != CONTRACT_VERSION:
        errors.append(f"contract_version must be {CONTRACT_VERSION}, got {md.get('contract_version')!r}")
    if "workflow_node" in md and md.get("workflow_node") != WORKFLOW_NODE:
        errors.append(f"workflow_node must be {WORKFLOW_NODE}")

    skill_id = str(md.get("skill_id", ""))
    if "artifact_id" in md and skill_id in ARTIFACT_ID_RE:
        if not ARTIFACT_ID_RE[skill_id].match(str(md.get("artifact_id", ""))):
            errors.append(f"artifact_id {md.get('artifact_id')!r} does not match pattern for skill {skill_id}")

    artifact_id = md.get("artifact_id")
    if artifact_id:
        if artifact_id in (md.get("cross_artifact_refs") or []):
            errors.append("metadata.cross_artifact_refs must not include the artifact's own id")
        if artifact_id in (handoff.get("cross_artifact_refs") or []):
            errors.append("downstream_handoff.cross_artifact_refs must not include the artifact's own id")

    if handoff:
        if "contract_version" in handoff and "contract_version" in md and handoff.get("contract_version") != md.get("contract_version"):
            errors.append("downstream_handoff.contract_version mismatch with metadata")
        if "artifact_id" in handoff and "artifact_id" in md and handoff.get("artifact_id") != md.get("artifact_id"):
            errors.append("downstream_handoff.artifact_id mismatch with metadata")

    for key in ("audit_handoff_required", "audit_required"):
        if key in md:
            value = md.get(key)
            if value not in YES_NO:
                errors.append(f"metadata.{key} must be string 'yes' or 'no', got {value!r}")
        if handoff and key in handoff:
            if handoff.get(key) not in YES_NO:
                errors.append(f"downstream_handoff.{key} must be string 'yes' or 'no', got {handoff.get(key)!r}")
        if re.search(rf"^\s*{key}:\s*(yes|no)\s*$", raw, re.M):
            errors.append(f"{key} should be quoted ('yes' / 'no') to avoid YAML 1.1 boolean coercion")

    if errors:
        print_errors(errors)
        return 1
    print(f"OK: {path} passes N380 metadata contract")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: validate_metadata.py <artifact.metadata.yaml>", file=sys.stderr)
        sys.exit(2)
    sys.exit(main(Path(sys.argv[1])))
