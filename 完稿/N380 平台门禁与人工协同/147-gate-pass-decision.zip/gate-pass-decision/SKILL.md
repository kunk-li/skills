---
name: gate-pass-decision
display_name: 门禁放行决策 / Gate Pass Decision
description: aggregate gate dimensions into one pass/cond_go/fail/pending/not_assessed gate verdict using hard-rule-first aggregation. use when multi-dimension gate evidence needs a machine-readable decision row with hcn_ref, fallback_ref, state_transition_ref, and audit_ref linkage. not for designing fallback mechanics (use fallback-switching) or human signoff nodes (use human-confirmation-node-management).
---

# Gate Pass Decision

Use this skill for N380 platform gate governance. Keep the work at the gate-control layer: preserve upstream evidence, make the governance artifact machine-readable, and avoid redoing the domain review performed by upstream N300-N370 skills.

## N380 v1.5.0 contract baseline

- contract_version: `n380-platform-gate-v1.5.0`
- workflow_node: `N380`
- skill_id: `147`
- csv_schema: `n380.gate-pass-decision.v2`
- artifact_family_id: `n380-platform-gate-suite`
- artifact_target: `门禁放行记录.csv`
- function_bias: `gate_pass`
- dsl_used: `aggregation_dsl`
- packaging rule: the skill is self-contained and must not depend on external node-level shared directories, external node-level tools, sibling skills, or hidden registries.
- composition rule: compose through `artifact_id`, row IDs, `gate_scope`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.

## Primary output

Produce `门禁放行记录.csv` in the exact CSV order defined by the skill-specific schema reference and by `references/output-contract.yaml`. Pair canonical outputs with `gate-fail-example.metadata.yaml` style sidecar metadata.

## Execution workflow

1. Identify the governance control point and upstream IDs.
2. Select one `selected_mode` from `references/output-contract.yaml` using `references/selected-mode-decision-tree.md`.
3. Preserve upstream IDs in `upstream_id_aliases`; do not rewrite N360/N370/N250 IDs.
4. Produce CSV rows in exact schema order.
5. Produce sidecar metadata with `contract_version`, `artifact_id`, `csv_schema`, `gate_scope`, `evidence_refs`, `cross_artifact_refs`, and `downstream_handoff`.
6. Run `scripts/validate_csv.py <csv-file>` whenever file execution is available.
7. Run `scripts/validate_metadata.py <metadata.yaml>` for sidecar metadata whenever file execution is available.
8. Run `scripts/validate_skill_md.py SKILL.md` during release checks to catch stale SKILL.md version headings.
9. For composed three-artifact checks, run `scripts/validate_release_consistency.py <gate.metadata.yaml> <fallback.metadata.yaml> <hcn.metadata.yaml>` and `scripts/validate_cascade.py <gate.csv> <fallback.csv> <hcn.csv>`.
10. Check that `cross_artifact_refs` does not include the artifact's own `artifact_id`.
11. Mark missing human knowledge as `待确认`, and use `not_applicable` only when a reference is explicitly irrelevant.

## Standalone and composition role

Standalone: produce a partial but useful N380 artifact from available evidence, lowering confidence and setting `readiness=partial` when inputs are incomplete.

Composition: strengthen the N380 control chain by joining this artifact with fallback-switching, human-confirmation-node-management, state-transition-mapping, audit-trail-management, N390. Use stable row IDs and sidecar metadata rather than prose-only links.

## References

- `references/n380-shared-gate-platform-contract.md`
- `references/n380-id-space.md`
- `references/output-contract.yaml`
- `references/metadata-schema.json`
- `references/selected-mode-decision-tree.md`
- `references/anti-patterns.md`
- `references/gate-pass-decision-quality-checklist.md`

Also use the original skill-specific schema/reference files and `scripts/validate_csv.py`, `scripts/validate_metadata.py`, `scripts/validate_metadata_schema.py`, `validate_decision_tree.py`, `scripts/validate_skill_md.py`, `scripts/validate_release_consistency.py`, `scripts/validate_cascade.py`, and the self-contained helper `scripts/n380_validators_common.py` for strict CSV, metadata, JSON Schema, SKILL.md, release, and cascade validation.

## Examples

- `examples/gate-audit-replay-example.csv`
- `examples/gate-delta-refresh-example.csv`
- `examples/gate-fail-example.csv`
- `examples/gate-rollup-aggregation-example.csv`
- `examples/gate-audit-replay-example.metadata.yaml`
- `examples/gate-delta-refresh-example.metadata.yaml`
- `examples/gate-fail-example.metadata.yaml`
- `examples/gate-rollup-aggregation-example.metadata.yaml`

Differences from the examples are allowed when the user's source material requires them, but field naming, metadata order, ID shape, gate scope, and handoff shape should stay compatible.

## Quality bar

Read `references/anti-patterns.md` before finalizing whenever the artifact contains non-PASS gates, active fallbacks, human confirmations, or audit handoff requirements.


Before finalizing, verify the shared 11-item checklist in `references/n380-shared-gate-platform-contract.md` section 24 and the skill-specific checklist in the referenced quality file, validate the CSV and metadata, preserve audit visibility, and do not silently convert non-PASS, active fallback, or human confirmation requirements into a permissive outcome.



## Skill-specific anti-patterns (AP-GATE-*)

These supplement the shared anti-patterns in `references/anti-patterns.md`.

| id | anti-pattern | why harmful | correct pattern |
| --- | --- | --- | --- |
| AP-GATE-01 | marking a COND_GO gate as PASS to avoid manual review | audit trail loses conditional evidence; downstream cannot reconstruct the true gate state | emit COND_GO and populate hcn_ref so a human sign-off is recorded |
| AP-GATE-02 | reusing a gate artifact_id for a re-run | audit replay cannot distinguish the original run from the refresh | use delta_refresh mode and emit a new artifact_id with a cross_artifact_ref to the prior artifact |
| AP-GATE-03 | aggregating dimensions without evidence refs | gate verdict cannot be audited or challenged | every aggregated dimension row must carry evidence_refs |

## Three-skill integration cascade

To validate the full gate/fallback/HCN three-skill cascade from the `examples/integration/` directory:

```bash
python scripts/validate_cascade.py \
    examples/integration/gate-fail-example.csv \
    examples/integration/fallback-activation-example.csv \
    examples/integration/hcn-escalation-example.csv
```

See `examples/integration/README.md` for the full six-skill N380→N390 cascade command.

## N380 v1.5.0 semantic guardrails
- Run `scripts/validate_decision_tree.py references/selected-mode-decision-tree.md` before release to prevent selected_mode drift.
- Run `scripts/validate_release_consistency.py` to validate SKILL.md, metadata JSON Schema, decision tree, and cross-artifact references together.
- Use strict CSV mode for production/CI gate, fallback, and HCN artifacts.
