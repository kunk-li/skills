# Gate Pass Decision Quality Checklist

Use `references/n380-shared-gate-platform-contract.md` section 24 for the shared 11-item N380 quality checklist. Apply the skill-specific checks below after the shared checklist passes.

## Skill-specific checks
- aggregation DSL follows hard rule > blocker/fail > conditional > pending > not assessed > pass.
- hard_rule_violations is an integer count and cannot be overridden by COND_GO.
- FAIL and COND_GO rows include hcn_ref and fallback_ref unless explicitly not_applicable.
- gate_ref targets row-level gate IDs such as GATE-platform-001, not artifact IDs.
- strict mode should be used in CI when PASS rows must not carry hcn_ref.
