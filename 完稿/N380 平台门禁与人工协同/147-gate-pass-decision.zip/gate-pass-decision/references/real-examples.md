# Real Examples / 真实示例参考

These examples illustrate correctly formed gate decision rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Fresh gate evaluation — COND_GO must not be promoted to PASS

**Input**: Three of four gate dimensions pass; one dimension (security review) is pending sign-off.

**Correct pattern**:
```
gate_id: GATE-invoice-sso-001
overall_verdict: COND_GO
dimension_verdicts:
  - dimension: functional_quality | verdict: PASS | evidence_refs: QA-report-202605
  - dimension: performance | verdict: PASS | evidence_refs: perf-test-202605
  - dimension: data_compliance | verdict: PASS | evidence_refs: dpo-sign-off-202605
  - dimension: security_review | verdict: PENDING | evidence_refs: SEC-review-pending-001 | hcn_ref: HCN-security-sign-off-001
hcn_ref: HCN-security-sign-off-001
```

**Anti-pattern to avoid (AP-GATE-01)**: Setting `overall_verdict: PASS` when any dimension is PENDING or COND_GO — this erases the conditional evidence from the audit trail.

---

## Example 2: Delta refresh — never reuse the prior artifact_id

**Input**: A prior gate (GATE-invoice-export-001) had a FAIL on performance. The team fixed the issue and needs to re-run the gate.

**Correct pattern**:
```
gate_id: GATE-invoice-export-002
selected_mode: delta_gate_refresh
prior_gate_ref: GATE-invoice-export-001
cross_artifact_refs:
  - GATE-invoice-export-001
dimension_verdicts:
  - dimension: performance | verdict: PASS | evidence_refs: perf-retest-202605
  - dimension: functional_quality | verdict: PASS | evidence_refs: QA-report-202605 (unchanged from prior run)
overall_verdict: PASS
```

**Anti-pattern to avoid (AP-GATE-02)**: Overwriting `GATE-invoice-export-001` with the new results — audit replay cannot distinguish the original failure from the re-run, hiding the remediation history.

---

## Example 3: Rollup aggregation — every dimension row needs evidence_refs

**Input**: A release manager wants to aggregate gate verdicts from three feature teams into a release gate.

**Correct pattern**:
```
gate_id: GATE-release-q2-001
selected_mode: rollup_aggregation
dimension_verdicts:
  - dimension: feature_a | verdict: PASS | evidence_refs: GATE-feature-a-001
  - dimension: feature_b | verdict: PASS | evidence_refs: GATE-feature-b-001
  - dimension: feature_c | verdict: COND_GO | evidence_refs: GATE-feature-c-001 | hcn_ref: HCN-pm-sign-off-001
overall_verdict: COND_GO
```

**Anti-pattern to avoid (AP-GATE-03)**: Writing dimension rows without `evidence_refs` — the rollup gate cannot be audited or challenged without traceable source gate IDs.
