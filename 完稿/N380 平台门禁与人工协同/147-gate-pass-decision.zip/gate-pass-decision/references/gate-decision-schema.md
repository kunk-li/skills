# Gate decision schema and DSL

## CSV schema

Column order is mandatory:

| column | required | allowed / format | meaning |
|---|---:|---|---|
| gate_id | yes | non-empty, stable ID such as `GATE-001` | Gate record ID |
| gate_name | yes | text | Human-readable gate name |
| gate_type | yes | `NODE`, `PHASE`, `RELEASE`, `DECISION`, `CANARY`, `GA`, `CUSTOM` | Gate category |
| scope_ref | yes | text or upstream ID | Node, phase, release, decision, or state covered by the gate |
| decision | yes | `PASS`, `COND_GO`, `FAIL`, `PENDING`, `NOT_ASSESSED` | Gate result |
| confidence | yes | `HIGH`, `MEDIUM`, `LOW` | Confidence in the decision |
| pass_count | yes | integer >= 0 | Count of passed dimensions |
| cond_go_count | yes | integer >= 0 | Count of conditional-go dimensions |
| fail_count | yes | integer >= 0 | Count of failed dimensions |
| pending_count | yes | integer >= 0 | Count of pending dimensions |
| not_assessed_count | yes | integer >= 0 | Count of not assessed dimensions |
| blocker_pending | yes | integer >= 0 | Open blockers linked to this gate |
| hard_rule_violations | yes | integer >= 0 | Non-negotiable rule violations |
| hcn_ref | yes for non-PASS | `HCN-###` or `待确认`; pipe-list allowed | Human confirmation node to escalate or approve |
| fallback_ref | yes for FAIL/COND_GO unless not applicable | `FB-###`, `not_applicable`, or `待确认`; pipe-list allowed | Fallback dependency |
| state_transition_ref | optional | `STATE-###`, `TR-###`, or pipe-list | State transition controlled by gate |
| audit_ref | yes | `AU-###`, `new`, or `待确认` | Audit record reference |
| evidence_ref | yes | source IDs, URLs, file refs, or `待确认`; pipe-list allowed | Evidence backing the gate |
| rationale | yes | text | Short reason for the decision |
| next_action | yes | text | Required follow-up, owner, or release condition |

## Aggregation DSL

Evaluate in this order:

```text
if hard_rule_violations > 0: decision = FAIL
elif blocker_pending > 0: decision = FAIL
elif fail_count > 0: decision = FAIL
elif cond_go_count > 0: decision = COND_GO
elif pending_count > 0: decision = PENDING
elif not_assessed_count > 0: decision = NOT_ASSESSED
else: decision = PASS
```

## Confidence rubric

`HIGH`:
- all required evidence is present;
- no `待确认` in critical fields;
- at least one concrete source or upstream artifact supports the decision;
- counts and decision are consistent.

`MEDIUM`:
- decision is supported, but one or two non-critical details are inferred;
- minor fields contain `待确认`;
- evidence is enough to decide but not enough to close the gate permanently.

`LOW`:
- key evidence is missing;
- multiple assumptions are required;
- the row should be treated as a draft, not a final gate decision.

## Cross-skill linkage

- `hcn_ref` points to human-confirmation-node-management output.
- `fallback_ref` points to fallback-switching output.
- `state_transition_ref` points to state-transition-mapping output.
- `audit_ref` points to audit-trail-management output.
