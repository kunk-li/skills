# Gate Pass Decision Anti-Patterns

Use this reference when validating or repairing N380 output. It records negative examples that should be rejected, corrected, or downgraded to partial readiness.

## 147-specific anti-patterns

### AP-147-1: COND_GO without conditional evidence
- Bad: `decision=COND_GO` while `cond_go_count=0`, `pending_count=0`, `fail_count=0`, `hard_rule_violations=0`.
- Why it is wrong: the aggregation DSL would return `PASS`; COND_GO without conditional evidence is a false constraint.
- Validator expectation: `scripts/validate_csv.py` rejects this.
- Correct pattern: set `decision=PASS`, or increase `cond_go_count` and document the condition in `rationale` and `next_action`.

### AP-147-2: PENDING or NOT_ASSESSED overriding a hard rule
- Bad: `decision=PENDING` with `hard_rule_violations=1`.
- Why it is wrong: hard rules dominate all other outcomes and must produce `FAIL`.
- Validator expectation: `scripts/validate_csv.py` rejects this.
- Correct pattern: set `decision=FAIL`, link `hcn_ref`, and preserve the unresolved evidence in `rationale`.

### AP-147-3: PASS with unresolved not-assessed dimensions
- Bad: `decision=PASS` with `not_assessed_count>0`.
- Why it is wrong: PASS requires assessed evidence; unknown dimensions must not become silent approval.
- Validator expectation: `scripts/validate_csv.py` rejects this.
- Correct pattern: set `decision=NOT_ASSESSED` or `PENDING` and link the owner or HCN where needed.

### AP-147-4: stale DSL field names
- Bad: using fields such as `explicit_conditional_path` that are not in the CSV schema.
- Why it is wrong: engine consumers and validators cannot parse non-schema fields.
- Validator expectation: schema order and allowed columns remain fixed in `references/gate-decision-schema.md` and `references/output-contract.yaml`.
- Correct pattern: express conditional evidence through `cond_go_count`, `rationale`, `next_action`, and linked HCN/fallback rows.


## Shared anti-pattern seeds from N380 adversarial testing

The anti-patterns in this file were distilled from regression tests that validators now enforce. Use them before finalizing output:

1. Do not let `PASS` hide `not_assessed_count > 0`.
2. Do not let `PENDING` or `NOT_ASSESSED` override hard rule violations.
3. Do not emit `COND_GO` when `cond_go_count = 0` and aggregation expects `PASS`.
4. Do not use schema fields that are not present in the CSV body or output contract.
5. Do not combine `rehearsal_allowed=yes` with `rehearsal_status=FORBIDDEN`.
6. Do not combine `rehearsal_allowed=no` with successful rehearsal outcomes.
7. Do not activate, block, or disable fallback without a concrete `HCN-*` reference.
8. Do not use `POLICY_DEGRADATION` as a way to bypass HCN or audit visibility.
9. Do not use `MULTI_SIGN` with one required signer.
10. Do not leave `PENDING` or `ESCALATED` HCN rows without a concrete `due_at`.
11. Do not count duplicate signers as independent approvals.
12. Do not use non-canonical audit templates for audit-required HCN rows.
13. Do not let metadata `cross_artifact_refs` include the artifact's own ID.

When a user request contains one of these patterns, preserve the evidence, explain the conflict briefly, and either correct the row or set `readiness=partial` with a concrete `pending_clarifications` entry.

