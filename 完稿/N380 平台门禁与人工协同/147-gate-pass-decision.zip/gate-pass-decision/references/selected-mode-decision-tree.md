# Selected Mode Decision Tree - Gate Pass Decision

Use this decision tree before creating `门禁放行记录.csv`. Record the chosen value in `metadata.selected_mode`.

```text
Do you have current multi-dimension gate evidence for one control point?
├── yes: is this a first-time gate artifact for the release/control point?
│   ├── yes -> fresh_gate_evaluation
│   └── no: are you updating only changed counts, refs, or outcome fields?
│       ├── yes -> delta_gate_refresh
│       └── no: are you aggregating several gate rows into one rollup view?
│           ├── yes -> rollup_aggregation
│           └── no -> fresh_gate_evaluation with readiness=partial
└── no: are you replaying or auditing historical gate outcomes?
    ├── yes -> audit_replay_mode
    └── no -> fresh_gate_evaluation with readiness=partial and pending_clarifications
```

## Guardrails
- Never choose `fresh_gate_evaluation` merely to override a failed prior gate; use `delta_gate_refresh` if this is an update.
- `rollup_aggregation` summarizes multiple gate rows; it does not invent a stronger decision than the underlying rows support.
- `audit_replay_mode` preserves the historical decision and explains the audit basis; do not recompute the outcome unless the user asks for a new evaluation.
