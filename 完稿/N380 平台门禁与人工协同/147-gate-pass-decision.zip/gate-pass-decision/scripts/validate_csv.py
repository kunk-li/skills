#!/usr/bin/env python3
"""Validate gate decision CSV records for gate-pass-decision."""

import csv
import sys
from pathlib import Path

from n380_validators_common import PLACEHOLDERS, print_errors

EXPECTED_COLUMNS = [
    "gate_id", "gate_name", "gate_type", "scope_ref", "decision", "confidence",
    "pass_count", "cond_go_count", "fail_count", "pending_count", "not_assessed_count",
    "blocker_pending", "hard_rule_violations", "hcn_ref", "fallback_ref",
    "state_transition_ref", "audit_ref", "evidence_ref", "rationale", "next_action",
]

GATE_TYPES = {"NODE", "PHASE", "RELEASE", "DECISION", "CANARY", "GA", "CUSTOM"}
DECISIONS = {"PASS", "COND_GO", "FAIL", "PENDING", "NOT_ASSESSED"}
CONFIDENCE = {"HIGH", "MEDIUM", "LOW"}
INT_FIELDS = {
    "pass_count", "cond_go_count", "fail_count", "pending_count", "not_assessed_count",
    "blocker_pending", "hard_rule_violations",
}
REQUIRED_TEXT = {
    "gate_id", "gate_name", "gate_type", "scope_ref", "decision", "confidence",
    "audit_ref", "evidence_ref", "rationale", "next_action",
}


def to_int(row, field, row_num, errors):
    raw = (row.get(field) or "").strip()
    try:
        value = int(raw)
        if value < 0:
            errors.append(f"row {row_num}: {field} must be >= 0")
        return value
    except ValueError:
        errors.append(f"row {row_num}: {field} must be an integer")
        return 0


def expected_decision(values):
    if values["hard_rule_violations"] > 0 or values["blocker_pending"] > 0 or values["fail_count"] > 0:
        return "FAIL"
    if values["cond_go_count"] > 0:
        return "COND_GO"
    if values["pending_count"] > 0:
        return "PENDING"
    if values["not_assessed_count"] > 0:
        return "NOT_ASSESSED"
    return "PASS"


def validate(path: Path, strict: bool = False) -> int:
    errors = []
    with path.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != EXPECTED_COLUMNS:
            errors.append("header mismatch: expected " + ",".join(EXPECTED_COLUMNS))
            errors.append("actual: " + ",".join(reader.fieldnames or []))
            print_errors(errors)
            return 1
        rows = list(reader)

    if not rows:
        errors.append("CSV has no data rows")

    seen_ids = set()
    for idx, row in enumerate(rows, start=2):
        for field in REQUIRED_TEXT:
            if not (row.get(field) or "").strip():
                errors.append(f"row {idx}: {field} is required")
        gate_id = (row.get("gate_id") or "").strip()
        if gate_id in seen_ids:
            errors.append(f"row {idx}: duplicate gate_id {gate_id}")
        seen_ids.add(gate_id)

        gate_type = (row.get("gate_type") or "").strip()
        if gate_type not in GATE_TYPES:
            errors.append(f"row {idx}: gate_type must be one of {sorted(GATE_TYPES)}")
        decision = (row.get("decision") or "").strip()
        if decision not in DECISIONS:
            errors.append(f"row {idx}: decision must be one of {sorted(DECISIONS)}")
        confidence = (row.get("confidence") or "").strip()
        if confidence not in CONFIDENCE:
            errors.append(f"row {idx}: confidence must be one of {sorted(CONFIDENCE)}")

        values = {field: to_int(row, field, idx, errors) for field in INT_FIELDS}
        hcn_ref = (row.get("hcn_ref") or "").strip()
        fallback_ref = (row.get("fallback_ref") or "").strip()
        state_ref = (row.get("state_transition_ref") or "").strip()
        expected = expected_decision(values)

        if decision != expected:
            if decision == "PASS":
                errors.append(f"row {idx}: PASS conflicts with aggregation result {expected}")
            elif decision == "FAIL" and expected != "FAIL":
                errors.append(f"row {idx}: FAIL requires fail_count, blocker_pending, or hard_rule_violations")
            elif decision == "COND_GO" and expected != "COND_GO":
                errors.append(f"row {idx}: COND_GO requires cond_go_count >= 1 (aggregation expects {expected})")
            elif decision in {"PENDING", "NOT_ASSESSED"} and expected == "FAIL":
                errors.append(
                    f"row {idx}: {decision} cannot be set when hard_rule_violations, blocker_pending, or fail_count > 0 (must be FAIL)"
                )
            else:
                errors.append(f"row {idx}: decision {decision} conflicts with aggregation result {expected}")

        if decision == "COND_GO" and values["hard_rule_violations"] > 0:
            errors.append(f"row {idx}: COND_GO cannot override hard_rule_violations")
        if decision == "COND_GO" and values["cond_go_count"] == 0 and values["pending_count"] == 0:
            errors.append(f"row {idx}: COND_GO requires cond_go_count >= 1 or a pending conditional path")
        if decision in {"FAIL", "COND_GO", "PENDING", "NOT_ASSESSED"} and not hcn_ref:
            errors.append(f"row {idx}: non-PASS decision requires hcn_ref")
        if decision in {"FAIL", "COND_GO"} and not fallback_ref:
            errors.append(f"row {idx}: {decision} requires fallback_ref or not_applicable")
        if gate_type in {"CANARY", "GA"} and state_ref in PLACEHOLDERS:
            msg = f"row {idx}: {gate_type} gate requires a concrete state_transition_ref in strict mode"
            if strict:
                errors.append(msg)
            else:
                print(f"WARN: {msg}", file=sys.stderr)
        if strict and decision == "PASS" and hcn_ref and hcn_ref != "not_applicable":
            errors.append(f"row {idx}: PASS should leave hcn_ref empty or not_applicable")

    if errors:
        print_errors(errors)
        return 1
    print(f"OK: {path} has {len(rows)} valid gate decision rows")
    return 0



if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--strict"]
    strict = "--strict" in sys.argv[1:]
    if len(args) != 1:
        print("Usage: validate_csv.py [--strict] <gate_decisions.csv>", file=sys.stderr)
        sys.exit(2)
    sys.exit(validate(Path(args[0]), strict=strict))
