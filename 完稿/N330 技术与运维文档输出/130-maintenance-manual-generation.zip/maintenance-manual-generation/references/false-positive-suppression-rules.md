# False Positive Suppression Rules

Use this reference when constructing Section 6 (已知误报与抑制规则) of the maintenance manual, or when evaluating scenario cards' `false_positive_risk` field.

## false_positive_risk rating criteria
| Rating | Criteria |
|--------|----------|
| `high` | Alert fires more than once per week without a real incident; OR historically triggers during known routine operations |
| `medium` | Alert fires 1–4 times per month without a real incident |
| `low` | Alert reliably indicates real issues; false positives are rare (< 1 per month) |

## Suppression rule entry format
```yaml
suppression_rule:
  rule_id: SUP-001
  alert_name: "HIGH_MEMORY_ALERT"
  false_positive_risk: high
  suppression_condition:
    time_window: "01:50–04:10 UTC"
    additional_condition: "batch_job_running = true AND affected_service = batch-processor"
  suppression_rationale: "Nightly batch job causes expected memory spike; no service degradation"
  evidence: "INC-2023-041, INC-2024-007 both closed as false positive during this window"
  review_date: "Quarterly — re-evaluate if batch job schedule changes"
  suppression_type: time_based  # time_based | condition_based | combined
  auto_suppress: no  # yes = automated suppression; no = manual acknowledgment required
  suppression_owner_role: sre-team
```

## Suppression types
- `time_based`: suppress during known maintenance windows or scheduled operations
- `condition_based`: suppress when a specific system state makes the alert expected
- `combined`: suppress when time AND condition both match

## Auto-suppress rules
Only allow `auto_suppress: yes` when:
1. The condition is deterministic (not probabilistic)
2. A human-reviewable audit log of suppressions is maintained
3. The suppressed alert has `false_positive_risk: high` confirmed by at least 2 historical incidents
4. There is a separate escalation path if the condition changes unexpectedly

## Mandatory review triggers
A suppression rule must be reviewed if:
- The underlying system or batch job schedule changes
- A real incident occurs during a suppression window
- The alert definition changes
- 6 months have elapsed since last review

## Section 6 when no historical data is available
When no incident history or monitoring data is provided, Section 6 must state:
```
## 已知误报与抑制规则

当前无历史 incident 数据可供分析。以下为待补充项：

待收集信息：
- 监控平台告警历史（建议取近 90 天）
- 值班人员对高频无效告警的经验总结
- 现有静默/抑制规则配置（如 AlertManager silences）

责任人：[待确认]
收集截止：[待确认]
```
