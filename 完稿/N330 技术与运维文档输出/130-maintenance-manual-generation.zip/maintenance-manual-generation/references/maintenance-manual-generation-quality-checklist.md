# N330 Maintenance Manual Quality Checklist

Use this checklist before finalizing `maintenance-manual.md`. The skill is standalone, so all required checks must be answerable from files packaged in this skill and the user-provided inputs.

1. Metadata follows `references/n330-shared-doc-suite-contract.md` and includes all required fields.
2. `selected_mode` matches both the user request and the produced document body.
3. `doc_id` follows `DOC-{skill_id}-{project_id}-{nn}`; any fallback `DOC-{skill_id}-TEMP-{date}-{source}` appears in `pending_id_backfill`.
4. `upstream_id_aliases` preserves upstream IDs exactly; uncertain IDs are marked `TEMP-*` or `to_confirm` rather than invented.
5. `cross_doc_refs` use sibling `doc_id` values, not file paths; missing sibling documents are explicit stubs in `open_blockers`.
6. Verify screen-mode and print-mode outputs both exist, and every scenario card includes trigger_signal, first_checks, immediate_actions, escalation_rule, and related_runbook.
7. `source_artifacts` and `freshness` identify the evidence base, including `as_of_date`, `source_commit`, or explicit `unknown`.
8. `open_blockers` names unresolved gaps and their next best checks.
9. `owner_placeholders` use role/team names only; do not use personal blame or hard-coded individual ownership.
10. `downstream_handoff` includes `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `required_fields`, `readiness`, `confidence`, and `next_best_checks`.
11. Compare the produced maintenance manual's metadata key order, field naming, cross-link style, and section structure against the closest file under `examples/`. Differences are allowed but should be intentional.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- Section 6 (已知误报与抑制规则) always present; if no historical data: standardized placeholder template from `references/false-positive-suppression-rules.md`.
- `l1_triage_only` mode: triage tree depth ≤3 enforced; every leaf node has exactly `action` and `escalate_to`.
- All scenario cards have `false_positive_risk` field assigned; `unknown` triggers open_blocker.

## Output structure completeness checks
- Sections 1–3, 5–6 are always present (Sections 4, 7 require evidence).
- Section 2 (分诊树) has ≥3 nodes; `l1_triage_only` depth ≤3 layers.
- Section 6 (已知误报) present with placeholder when no historical data.
- Every scenario card has `false_positive_risk` assigned: low/medium/high (never blank).
- `l1_triage_only` mode: every leaf node has ONLY `action` and `escalate_to` — no additional fields.
