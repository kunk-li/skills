---
name: maintenance-manual-generation
description: 生成维护手册（值班运维手册）用于 n330 技术与运维文档输出。triggered when you need to produce the triage entry-point manual for l1–l4 on-call engineers, covering alert triage trees, scenario cards, false-positive suppression rules, and escalation paths. this skill produces the entry-point that organizes when and where to act — linked runbooks hold the detailed commands. use l1_triage_only mode when onboarding on-call engineers. do not use for deployment procedures (→ #129), api contracts (→ #126), module architecture (→ #127), or incident postmortems (→ n320 #124).
---

# 维护手册生成

## N330 contract baseline (n330-doc-suite-v1.2.1)

- contract_version: `n330-doc-suite-v1.2.1`
- workflow node: N330
- skill_id: 130
- primary artifact: `维护手册.md`
- family role: ops triage entry-point; consumes smoke_test_ids and alerts_to_monitor from #129; provides scenario_triggered handoff to N320 #123/#124
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: reference #129 for smoke_test_ids; emit downstream_handoff to N320 when scenario_triggered.

> **N330 skill boundary summary** — see `references/n330-shared-doc-suite-contract.md` for full boundary matrix:
> #125 aggregates · #126 API contracts · #127 module boundaries · #128 data fields · #129 deployment · **#130 ops manual**

## Role

作为 N330 文档家族中的**值班与维护手册生成器**，产出供 L1–L4 值班、实施支持和运维团队直接使用的维护手册。

具体职责：
- 构建 L1 可独立操作的场景卡片（分诊树深度 ≤3 层，每个叶节点只有 action 和 escalate_to 两个字段）
- 维护已知误报与抑制规则（Section 6 永不省略）
- 标注 `false_positive_risk`（low/medium/high）
- 在 N320 事故发生时，通过 `scenario_triggered` downstream_handoff 传递 `incident_id`、`triggered_scenario_id` 和 `evidence_snapshot` 给 N320 #123/#124

**不负责**：部署执行步骤（→ #129）、API 规范（→ #126）、服务边界定义（→ #127）、新功能需求（→ PRD/N090）、事故复盘（→ N320 #123/#124）。

## When NOT to use this skill

- **Not a deployment guide**: step-by-step deploy procedures belong in #129; #130 covers steady-state operations after deployment.
- **Not a module design document**: service topology is documented in #127; #130 references those for triage routing, not re-documents them.
- **Not an incident postmortem**: when an alert fires and an incident occurs, document it in N320 #123/#124; #130 covers triage guidance before and after incidents.
- **Not a full runbook**: #130 is the triage entry-point that organizes alerts and escalation paths, and points to detailed runbooks for step-by-step commands. Detailed operational commands and scripts belong in linked runbooks, not in this skill's output.

## Standalone and composition role

```yaml
standalone_goal: produce L1–L4 runbooks covering alert triage trees, scenario cards, false-positive suppression, and escalation paths
minimum_viable_input:
  any_of:
    - 监控指标或告警规则
    - 值班 runbook 或已有操作手册
    - 部署与回滚说明（来自 #129）
    - 来自 N300/N310/N320 的 incident、scenario、timeline、response 建议
    - 相关模块、接口、环境限制说明
partial_readiness_allowed: true
degradation_behavior: >
  If inputs are sparse, output skeleton with all 6 sections.
  Section 2 (triage tree): minimum 3-node tree with placeholder leaves.
  Section 3 (scenario cards): minimum 1 card using placeholder scenario.
  Section 6 (false-positive rules): use template from references/false-positive-suppression-rules.md.
  Never omit Section 6 — operational safety depends on it.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `operator_manual`: 完整手册，含分诊树、场景卡片、升级路径、详细 runbook 入口。
- `quick_reference_cards`: 仅场景卡片与升级路径，用于桌面贴或值班速查。
- `screen_and_print_dual`: 同时输出屏幕版与 A4 打印版骨架。
- `incident_fallback`: 仅有 incident 记录，从事后分析反推维护场景。
- **`l1_triage_only`**: 专为 L1 值班输出极简分诊树，最多 3 层决策，每个叶子节点只给"做什么"和"升级给谁"，不展开详细 runbook。

**Default routing**: new on-call engineer → `l1_triage_only`. Full ops documentation needed → `operator_manual`. Only incidents available → `incident_fallback`.

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | 手册摘要与适用班次 | Always | State target operator level (L1/L2/L3/L4) |
| 2 | 分诊树 | Always | Min 3-node tree; `l1_triage_only`: max 3 layers, leaf = action + escalate_to only |
| 3 | 快速场景卡片 | Always | Min 1 card; each card has `false_positive_risk` tag |
| 4 | 常用检查与命令入口 | Conditional (when runbook evidence available) | Note omission in Section 6 if absent |
| 5 | 升级与沟通路径 | Always | "升级联系人待确认" if missing |
| 6 | 已知误报与抑制规则 | **Always — never omit** | Use template from false-positive-suppression-rules.md when no history |

> Legend: Always = required in every mode; Conditional = required when evidence triggers it.

## N320 scenario_triggered handoff

When an alert fires and becomes an incident during a triage session, emit:

```yaml
downstream_handoff:
  consumer_skill_or_node: N320/incident-timeline-compilation
  triggered_scenario_id: SC-*-001
  incident_id: "[assign or leave TBD]"
  evidence_snapshot:
    - alert_fired: "[alert name + timestamp]"
    - operator_action: "[what L1 did]"
    - current_state: "[system state at trigger time]"
  readiness: partial | degraded
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** Section 6（误报与抑制规则）省略 → **永远必填**；即使无任何历史误报记录，也必须使用 `references/false-positive-suppression-rules.md` 模板输出占位条目。量化检验：Section 6 正文少于 2 个条目（含模板占位）视为违例。
- **AP-2** 分诊树叶节点超过 2 个字段（action + escalate_to）→ `l1_triage_only` 模式硬性约束叶节点只有这 2 个字段；其他模式的叶节点也应保持简洁，额外信息用链接指向详细 runbook，而非内联展开。检验：叶节点不应出现 `command:`、`code_block`、`step_by_step:` 等内联命令字段。量化检验：叶节点中出现 command:/code_block:/step_by_step: 字段的节点数 = FAIL 数。
- **AP-3** 场景卡片缺少 `false_positive_risk` 标注 → 每张场景卡片必须标注 low / medium / high 三级之一；未评估时写 `false_positive_risk: unknown` 并在 Section 6 标注待评估。量化检验：搜索每张卡片，缺少 `false_positive_risk` 字段的计入 open_blocker。
- **AP-4** 事故发生时 #130 试图做根因分析或直接写复盘结论 → 必须通过 `scenario_triggered` downstream_handoff 交给 N320 #123；#130 只记录触发场景、证据快照和当前系统状态，不输出"因为X导致Y"的因果结论。量化检验：正文中出现「因为…导致」/「根因是」/「root cause」等因果分析词组（非引用上下文）的段落数 = FAIL 数。
- **AP-5** `quick_reference_cards` 模式输出了完整 operator_manual 内容 → 该模式只输出场景卡片和升级路径，禁止包含分诊树详情、命令入口或 runbook 正文；超出内容转移到 operator_manual 模式输出。量化检验：quick_reference_cards 模式输出中，出现分诊树完整步骤/命令入口/runbook 正文段落的处数 = FAIL 数。
- **AP-6** 分诊树深度超过 3 层（l1_triage_only 模式）→ 超过 3 层的决策路径对 L1 工程师认知负担过重；第 3 层叶节点必须终止并给出 escalate_to，不可继续分叉。量化检验：l1_triage_only 模式下，决策树深度超过 3 层的分支数 = FAIL 数（层数从根节点起算）。

## Workflow position

```
Monitoring rules / existing runbooks / #129 smoke_test_ids + alerts_to_monitor / N300/N310/N320 incident records
  ↓ #130 (ops triage manual → 维护手册.md)
  → scenario_triggered → N320 #123 (incident timeline) when alert becomes incident
  → ops insights → N340 #133 (FAQ for recurring ops questions)
```

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n330-shared-doc-suite-contract.md` — shared contract, doc_id format, cross-link rules
- `references/n330-document-family-crosslinks.md` — cross-link structure between #125–#130
- `references/n330-composition-guide.md` — composition guide
- `references/n330-input-validation-rules.md` — when input quality is uncertain
- `references/false-positive-suppression-rules.md` — template for Section 6; always read for this skill
- `references/maintenance-output-modes.md` — mode-specific output guidance
- `references/triage-tree-template.md` — decision tree structure and leaf-node format
- `references/id-linkage-guide.md` — when linking to upstream IDs or #129 smoke_test_ids
- `references/maintenance-manual-generation-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/family-aligned-maintenance-manual.md` — operator_manual mode with full triage tree
- `examples/l1-triage-only-mode.md` — l1_triage_only with max 3-layer tree and 2-field leaves
- `examples/incident-fallback-mode.md` — incident_fallback with retrospective scenario reconstruction
