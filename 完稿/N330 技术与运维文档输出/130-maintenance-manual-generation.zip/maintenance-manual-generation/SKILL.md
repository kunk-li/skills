---
name: maintenance-manual-generation
description: generate maintenance manuals for the n330 technical and operations documentation node. use when ChatGPT needs to turn alerts, runbooks, deployment rules, monitoring signals, or operating scenarios into an operator-facing manual with configurable triage depth, quick scenario cards, and both screen-first and printable outputs.
---

# 维护手册生成

## Role
作为 N330 文档家族中的值班与维护手册生成器，产出供 L1-L4 值班、实施支持和运维团队直接使用的维护手册。默认同时考虑在线阅读与 A4 打印，不把文档只写成单一 markdown 长文。

## Selected mode
- `operator_manual`
- `quick_reference_cards`
- `screen_and_print_dual`
- `incident_fallback`

## Primary inputs
- 监控指标、告警规则、值班 runbook、部署与回滚说明、常见场景
- 来自 N300 / N310 / N320 的 incident、scenario、timeline、response 建议
- 相关模块、接口、环境限制

## Standalone rule
单独使用时也必须输出：
- 分诊树
- 高优先级场景卡片
- 升级路径
- 详细版或关联文档入口

## Core output contract
1. 手册摘要与适用班次
2. 分诊树（深度可配置）
3. 快速场景卡片
4. 常用检查与命令入口
5. 升级与沟通路径
6. 详细手册链接 / 二维码占位
7. screen_mode_html / print_mode_a4 说明
8. cross-links
9. 缺失与待确认

场景卡片至少给出：
- `scenario_id`
- `trigger_signal`
- `first_checks`
- `immediate_actions`
- `escalation_rule`
- `related_runbook`

## Design rules
- 分诊树深度使用 `{TRIAGE_DEPTH}` 参数，不写死 4 层。
- 维护手册要优先面向操作，不要写成长篇架构综述。
- 默认准备双输出：在线版与打印版。
- 尽量把复杂 runbook 通过链接或二维码占位挂到详细文档，而不是把所有细节硬塞进桌面贴。

## Execution workflow
1. 识别值班对象与使用场景。
2. 组装分诊树。
3. 生成场景卡片与升级路径。
4. 决定在线版与打印版差异。
5. 回链到部署文档、N300/N310 运行与处置文档。

## Dynamic completeness
- 只有监控与告警、没有正式 runbook 时：先出分诊树和场景卡片骨架。
- 只有详细 runbook、没有桌面贴版本时：主动收敛为 quick-reference 版本。

## Standalone use cases
- L1 值班手册
- 客服 / 支持分诊树
- 现场运维桌面贴
- 应急响应 SOP 速查卡

## Quality bar
- 是否给出可配置的分诊树深度
- 是否同时考虑屏幕版和打印版
- 是否给出场景卡片而不是纯长文
- 是否能和部署 / 告警 / 事件文档联动

## References
- `references/maintenance-output-modes.md`
- `references/triage-tree-template.md`
- `references/n330-document-family-crosslinks.md`

## N330 v1.2.0 contract baseline
Contract version: `n330-doc-suite-v1.2.0`.

This skill is self-contained. Standalone execution and multi-skill composition rely only on files packaged inside this skill plus artifacts exchanged through `cross_doc_refs` and `downstream_handoff`. Do not require outside-package shared directories, outside-package tools, external matrices, or hidden registries.

## Standalone and composition role
```yaml
standalone_contract:
  minimum_viable_input: alerts, runbooks, deployment rules, monitoring signals, incident notes, or operating scenarios
  partial_readiness_allowed: true
  degradation_behavior:
    - keep required sections stable even when evidence is partial
    - mark gaps in metadata.open_blockers
    - put temporary IDs in metadata.pending_id_backfill
composition_contract:
  composition_role: operator_manual_owner
  join_keys:
    - doc_family_id
    - doc_id
    - scope.project_id
    - scope.release_id
    - scope.service_scope
    - scope.module_scope
    - upstream_id_aliases
    - cross_doc_refs
  best_combines_with: ['129', '127', '126', '128', '125']
  consumes: ['deployment-documentation-generation', 'module-design-document-generation', 'api-documentation-generation', 'data-dictionary-generation', 'N300', 'N310', 'N320']
  produces_for: ['N340', 'N390', 'governance_kb']
  strengthens: converts deployment, monitoring, and incident knowledge into operator-facing triage trees and scenario cards
```

## Required metadata and handoff
Every output must start with a `metadata` YAML block that follows `references/n330-shared-doc-suite-contract.md`. Every output must also end with a `downstream_handoff` block containing `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `doc_id`, `cross_doc_refs`, `pending_id_backfill`, `readiness`, `confidence`, and `next_best_checks`.

## N330 references
- Always use `references/n330-shared-doc-suite-contract.md` for metadata, join keys, handoff, standalone, and composition rules.
- Use `references/output-contract.yaml` for this skill's required sections and machine-readable contract.
- Use `references/maintenance-manual-generation-quality-checklist.md` before finalizing the artifact.
- Use `examples/family-aligned-maintenance-manual.md` as the closest style and structure reference.
- Use `references/id-linkage-guide.md` when aligning upstream IDs.
- Use `references/n330-document-family-crosslinks.md` when linking sibling N330 documents.

