# Example: Maintenance Manual — L1 Triage Only Mode

Demonstrates `l1_triage_only` mode: max 3-layer decision tree, each leaf node has only `action` and `escalate_to`.

```yaml
metadata:
  contract_version: n330-doc-suite-v1.2.1
  skill_id: "130"
  selected_mode: l1_triage_only
  doc_id: DOC-130-PAY-L1
  doc_family_id: n330-rd-doc-suite
  readiness: complete
```

## 手册摘要

**适用**: L1 值班工程师（无 payment-service 深度背景）  
**范围**: payment-service 常见告警分诊  
**层深**: 最大 3 层，每叶节点仅含"做什么"和"升级给谁"

---

## 分诊树（L1 极简版，≤3层）

```
告警触发
│
├─ GET /health 返回 200？
│   ├─ 是 → 服务运行正常，检查具体告警指标 ──→ [场景卡片 SC-001]
│   └─ 否 → ⚠ 服务不可用
│            action: 立即拨打 on-call-sre PagerDuty
│            escalate_to: on-call-sre
│
├─ 告警名包含 "PAYMENT_LATENCY"？
│   ├─ P99 延迟 < 2s → 可能误报
│   │   action: 查看 `false_positive_risk` 规则（见 Section 6）
│   │   escalate_to: 若 5min 未恢复 → on-call-sre
│   └─ P99 延迟 ≥ 2s → 高延迟确认
│       action: 拨打 on-call-sre；收集 Grafana 截图
│       escalate_to: on-call-sre + backend-lead
│
└─ 告警名包含 "CART_LIMIT"？
    action: 查看 SC-002 场景卡片
    escalate_to: 若场景卡片步骤无效 → backend-lead
```

---

## 快速场景卡片

### SC-001: PAYMENT_HIGH_ERROR_RATE
| 字段 | 内容 |
|------|------|
| trigger_signal | 5xx 错误率 > 1% 持续 5 分钟 |
| first_checks | 1. 查看 Grafana payment-service dashboard<br>2. 确认是否有最近 deploy |
| immediate_actions | 若最近 30min 有 deploy → 执行 RB-001（见 DOC-129 hotfix 回滚）<br>否则 → 升级 |
| escalation_rule | 1 分钟内不能定位原因 → 升级 on-call-sre |
| false_positive_risk | low |
| related_runbook | runbook://payment/high-error-rate |

### SC-002: CART_LIMIT_WARNING
| 字段 | 内容 |
|------|------|
| trigger_signal | cart.size > 480 (接近 512 限制) |
| first_checks | 确认是真实用户行为还是测试账号 |
| immediate_actions | 若是测试账号 → 通知测试团队清理<br>若是真实用户 → 记录 user_id，通知 backend-lead |
| escalation_rule | 超过 512 限制导致 500 → 升级 backend-lead |
| false_positive_risk | **high**（测试账号频繁触发）|
| related_runbook | n/a |

---

## Section 6 — 已知误报与抑制规则

| rule_id | alert_name | false_positive_risk | suppression_condition | evidence |
|---------|-----------|--------------------|-----------------------|---------|
| SUP-001 | CART_LIMIT_WARNING | **high** | 触发账号 = 内部测试账号（user_id 前缀 `test-`）| INC-2024-089, INC-2025-003 |
| SUP-002 | PAYMENT_LATENCY_P99 | medium | 触发时间在 02:00–04:00 JST + batch_job_running=true | INC-2024-107 |

---

## 升级与沟通路径

| 角色 | 联系方式 | 响应 SLA |
|------|---------|---------|
| on-call-sre | PagerDuty #payment-oncall | 5min |
| backend-lead | Slack @backend-lead | 10min |
| ENG-lead | Slack @eng-lead (仅 P0 升级) | 15min |

## Cross-links

| doc_id | 关系 |
|--------|------|
| DOC-129-PAY | 部署文档（含 RB-001 回滚步骤）|
| DOC-127-PAY | 模块设计（服务拓扑图）|

```yaml
downstream_handoff:
  producer_skill: maintenance-manual-generation
  consumer_skill_or_node: incident-postmortem|N320
  readiness: complete
  confidence: high
  next_best_checks:
    - "SUP-001 高误报规则每季度复查：若测试账号 user_id 命名规则变化需更新"
    - "若 SC-001 触发但 RB-001 无效，postmortem 需更新此场景卡片"
```

## Downstream Handoff

```yaml
handoff_id: DOC-130-PAY-L1-HANDOFF
producer_skill: maintenance-manual-generation
consumer_skill_or_node: incident-timeline-compilation|N320
cross_doc_refs:
  - doc_id: DOC-129-PAY
    relationship: deployment_context
scenario_card_ids: [SC-001, SC-002]
false_positive_rules: [SUP-001, SUP-002]
readiness: complete
confidence: high
next_best_checks:
  - "Review SUP-001 (test account suppression) quarterly or when user_id naming changes"
  - "If SC-001 triggers incident, reference this manual's doc_id in timeline"
```
