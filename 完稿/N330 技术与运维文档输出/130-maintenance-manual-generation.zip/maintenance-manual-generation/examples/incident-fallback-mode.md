# Example: Maintenance Manual — Incident Fallback Mode (Minimal Input)

Demonstrates `incident_fallback` mode: producing a triage guide from a single recent incident report with no prior documentation.

```yaml
metadata:
  skill_id: "130"
  selected_mode: incident_fallback
  artifact_id: DOC-130-NOTIFY-INCIDENT-FALLBACK
  contract_version: n330-doc-suite-v1.2.1
  doc_id: DOC-130-NOTIFY-FALLBACK-001
  readiness: partial
  open_blockers:
    - "Section 6 (false positive rules): no history available — populated with 1 inferred rule"
    - "Escalation path L3: no runbook for external SMS provider escalation"
```

## L1 Triage Tree

```
ALERT: notification-service high error rate
├── Are errors 5xx from /send endpoint?
│   ├── YES → SC-001 (provider outage)
│   └── NO  → SC-002 (queue backlog)
└── Are errors all 429?
    └── YES → SC-003 (rate limit — check provider dashboard)
```

## Scenario Cards

### SC-001: SMS provider outage
- **symptom**: `POST /send` returning 503; provider status page shows incident
- **action**: set `NOTIFY_FALLBACK_MODE=email`; alert ENG-lead
- **escalate_to**: ENG-lead → provider support ticket
- **false_positive_risk**: low

### SC-002: Notification queue backlog
- **symptom**: high p99 latency; queue depth > 10,000
- **action**: scale up workers (`kubectl scale deploy/notify-worker --replicas=8`)
- **escalate_to**: ENG-lead if queue not draining within 10 min
- **false_positive_risk**: medium (check if batch job is running)

## Section 6: Known False Positives and Suppression Rules

| rule_id | alert | suppression_condition | added_from |
|---------|-------|-----------------------|-----------|
| SUP-001 | high_error_rate | During scheduled maintenance window (Sundays 02:00–04:00 UTC) | INC-2025-0601 |

*Note: rule set is minimal — built from single incident. Review after next 3 incidents.*

## Downstream Handoff

```yaml
handoff_id: DOC-130-NOTIFY-FALLBACK-HANDOFF
producer_skill: maintenance-manual-generation
consumer_skill_or_node: incident-timeline-compilation|N320
scenario_card_ids: [SC-001, SC-002, SC-003]
false_positive_rules: [SUP-001]
readiness: partial
confidence: low
next_best_checks:
  - "N320 #123: if SC-001 triggers, reference this doc_id in timeline"
  - "Expand Section 6 after next 3 incidents"
  - "Build SC-003 runbook for rate limit recovery"
```
