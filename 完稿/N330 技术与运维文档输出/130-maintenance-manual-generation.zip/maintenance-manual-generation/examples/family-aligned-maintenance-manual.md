metadata:
  contract_version: n330-doc-suite-v1.2.0
  workflow_node: N330
  skill_id: 130
  skill_name: maintenance-manual-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-130-claims-01
  selected_mode: screen_and_print_dual
  readiness: ready
  scope:
    project_id: claims-modernization
    release_id: REL-2026-claims-01
    service_scope: [claims-api, claims-worker]
    module_scope: [claims]
  source_artifacts: [architecture-brief.md, api-inventory.md, ddl.sql, release-plan.md]
  upstream_id_aliases: [FT-claims-01-01, BE-claims-01, API-claims-01, FLD-claims-P01-01, PRD-07]
  cross_doc_refs: [DOC-129-claims-01, DOC-127-claims-01, DOC-126-claims-01, DOC-128-claims-01, DOC-125-claims-01]
  pending_id_backfill: []
  freshness:
    as_of_date: 2026-05-07
    source_commit: abc1234
    expected_review_window: after every minor release
  open_blockers: []
  owner_placeholders: [claims-service-owner, platform-release-team]
  confidence: high
  composition_role: operator_manual_owner
  stage_position: documentation_family.technical_docs.example
  node_artifact_target: maintenance-manual.md

# Maintenance Manual Example

## Manual summary and shift scope
This manual supports on-call operation for claims modernization after REL-2026-claims-01. It has screen-mode and print-mode sections.

## Triage tree
1. If POST /claims error rate rises, check API-claims-01 status codes and claims-api logs.
2. If queue depth rises, check claims-worker consumer lag and deployment phase from DOC-129-claims-01.
3. If adjudication is delayed but API is healthy, escalate to the claims-worker owner role.

## Quick scenario cards
| scenario_id | trigger_signal | first_checks | immediate_actions | escalation_rule | related_runbook |
|---|---|---|---|---|---|
| SC-claims-api-errors | API-claims-01 5xx > threshold | dashboard, recent deploy, logs | pause ramp, notify release team | escalate after 10 minutes | RB-claims-01 |
| SC-claims-worker-lag | queue lag rising | consumer health, DB locks | pause new worker rollout | escalate after 15 minutes | RB-claims-02 |

## Screen mode HTML and print mode A4
- Screen mode: start with triage tree and scenario cards.
- Print mode: include rollback contact roles and offline commands.

downstream_handoff:
  contract_version: n330-doc-suite-v1.2.0
  handoff_id: HO-N330-REL-2026-claims-01-130
  producer_skill: maintenance-manual-generation
  consumer_skill_or_node: N390
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-130-claims-01
  release_id: REL-2026-claims-01
  required_fields: [doc_id, scope, upstream_id_aliases, cross_doc_refs]
  cross_doc_refs: ['DOC-129-claims-01', 'DOC-127-claims-01', 'DOC-126-claims-01', 'DOC-128-claims-01', 'DOC-125-claims-01']
  pending_id_backfill: []
  readiness: ready
  confidence: high
  next_best_checks: []
