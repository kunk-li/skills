# Sensitive Data Masking Patterns

Use this reference when `sensitive_data_tagging` mode is active, or when any field triggers the auto-tagging rule.

## Auto-tagging keyword triggers
Any field whose name contains one of these patterns (case-insensitive) must be tagged automatically:

| Keyword pattern | Default sensitivity_level | Default masking_strategy |
|----------------|--------------------------|--------------------------|
| `email` | PII | Show first 2 chars + `***@domain` |
| `phone`, `mobile`, `tel` | PII | Show last 4 digits only: `***-****-1234` |
| `id_card`, `national_id`, `ssn`, `nric` | PII | Show last 4 chars only |
| `password`, `passwd`, `pwd` | PII | Never display; always `***` |
| `token`, `api_key`, `secret`, `credential` | PII | Never display; always `***` |
| `credit_card`, `card_number`, `pan` | financial | Show last 4 digits: `****-****-****-1234` |
| `account_number`, `bank_account` | financial | Show last 4 digits only |
| `salary`, `income`, `balance`, `amount` (in financial context) | financial | Show to authorized roles only |
| `address`, `location`, `latitude`, `longitude` | PII | Truncate to city level for public display |
| `birth_date`, `birthday`, `dob` | PII | Show year only for public display |
| `ip_address`, `mac_address` | internal | Partial masking: first 3 octets only |

## sensitivity_level values
- `PII` — Personally Identifiable Information; subject to GDPR/PDPA/CCPA
- `financial` — Financial data; subject to PCI-DSS or equivalent
- `internal` — Internal only; not for external display
- `public` — Safe to display to all
- `unknown` — Requires classification before deployment; **always an `open_blocker`**

## masking_strategy field format
```yaml
field: users.email
sensitivity_level: PII
masking_strategy: "Show first 2 chars + ***@domain (e.g., jo***@example.com)"
applicable_roles: [admin, support]  # roles that see unmasked value
regulation_basis: GDPR Art. 4  # optional reference
```

## Fields requiring special treatment
- **Composite fields** (e.g., `full_name` combines first + last): tag as PII, mask to first name initial + `***`
- **Encrypted fields**: tag sensitivity_level based on the underlying data, not the encrypted form
- **Derived fields** (e.g., `age` from `birth_date`): tag same as source field unless derivation removes identifying information
- **Log fields**: if a sensitive field is logged, add `log_risk: true` and recommend log scrubbing rule

## Unknown fields
Any field with `sensitivity_level: unknown` must appear as an `open_blocker` in metadata:
```yaml
open_blockers:
  - "Field users.legacy_ref has sensitivity_level: unknown — data owner must classify before production deployment"
```
Do not deploy a data dictionary with unclassified sensitive fields.
