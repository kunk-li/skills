# N330 Data Dictionary Quality Checklist

Use this checklist before finalizing `data-dictionary.md`. The skill is standalone, so all required checks must be answerable from files packaged in this skill and the user-provided inputs.

1. Metadata follows `references/n330-shared-doc-suite-contract.md` and includes all required fields.
2. `selected_mode` matches both the user request and the produced document body.
3. `doc_id` follows `DOC-{skill_id}-{project_id}-{nn}`; any fallback `DOC-{skill_id}-TEMP-{date}-{source}` appears in `pending_id_backfill`.
4. `upstream_id_aliases` preserves upstream IDs exactly; uncertain IDs are marked `TEMP-*` or `to_confirm` rather than invented.
5. `cross_doc_refs` use sibling `doc_id` values, not file paths; missing sibling documents are explicit stubs in `open_blockers`.
6. Verify object coverage compares BE-*, API payload, FLD-*, and schema objects, and every field row includes meaning, source, constraints, defaults, and usage positions.
7. `source_artifacts` and `freshness` identify the evidence base, including `as_of_date`, `source_commit`, or explicit `unknown`.
8. `open_blockers` names unresolved gaps and their next best checks.
9. `owner_placeholders` use role/team names only; do not use personal blame or hard-coded individual ownership.
10. `downstream_handoff` includes `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `required_fields`, `readiness`, `confidence`, and `next_best_checks`.
11. Compare the produced data dictionary's metadata key order, field naming, cross-link style, and section structure against the closest file under `examples/`. Differences are allowed but should be intentional.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- `sensitive_data_tagging` mode: every field has `sensitivity_level` — `unknown` triggers open_blocker.
- Object coverage check always runs; "漏对象" list is explicit even if empty ("无漏对象").
- DDL completeness self-check always runs; "缺失约束" list is explicit even if empty.

## Output structure completeness checks
- Sections 1–4 and 6–10 are present (Section 5 requires evidence).
- Section 6 (对象覆盖度) states "无漏对象" or explicit gap list — never blank.
- Section 7 (DDL完整性) states "缺失约束: 无" or explicit list — never blank.
- Section 8 (敏感级别) present when any PII keyword field detected, regardless of mode.
- `sensitivity_level` assigned to every field — `unknown` triggers open_blocker.
