metadata:
  contract_version: n330-doc-suite-v1.2.0
  workflow_node: N330
  skill_id: 128
  skill_name: data-dictionary-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-128-claims-01
  selected_mode: ddl_aligned
  readiness: ready
  scope:
    project_id: claims-modernization
    release_id: REL-2026-claims-01
    service_scope: [claims-api, claims-worker]
    module_scope: [claims]
  source_artifacts: [architecture-brief.md, api-inventory.md, ddl.sql, release-plan.md]
  upstream_id_aliases: [FT-claims-01-01, BE-claims-01, API-claims-01, FLD-claims-P01-01, PRD-07]
  cross_doc_refs: [DOC-127-claims-01, DOC-126-claims-01, DOC-125-claims-01]
  pending_id_backfill: []
  freshness:
    as_of_date: 2026-05-07
    source_commit: abc1234
    expected_review_window: after every minor release
  open_blockers: []
  owner_placeholders: [claims-service-owner, platform-release-team]
  confidence: high
  composition_role: data_contract_catalog
  stage_position: documentation_family.technical_docs.example
  node_artifact_target: data-dictionary.md

# Data Dictionary Example

## Object index
| object_id | object_name | source | related_api |
|---|---|---|---|
| OBJ-claims-claim | claim | DDL claims.claim | API-claims-01, API-claims-02 |

## Field definition table
| field_id | object | field | meaning | type | constraints | default | used_by |
|---|---|---|---|---|---|---|---|
| FLD-claims-P01-01 | claim | claim_id | stable claim identifier | uuid | primary key | generated | API-claims-02 |
| FLD-claims-P01-02 | claim | status | lifecycle state | enum | received, adjudicating, approved, denied | received | API-claims-01 |

## Object coverage check
API-claims-01 and API-claims-02 both map to the `claim` object. No uncovered API payload fields remain.

## Cross links
- Module design: DOC-127-claims-01
- API documentation: DOC-126-claims-01

downstream_handoff:
  contract_version: n330-doc-suite-v1.2.0
  handoff_id: HO-N330-REL-2026-claims-01-128
  producer_skill: data-dictionary-generation
  consumer_skill_or_node: development-documentation-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-128-claims-01
  release_id: REL-2026-claims-01
  required_fields: [doc_id, scope, upstream_id_aliases, cross_doc_refs]
  cross_doc_refs: ['DOC-127-claims-01', 'DOC-126-claims-01', 'DOC-125-claims-01']
  pending_id_backfill: []
  readiness: ready
  confidence: high
  next_best_checks: []
