# Example: Data Dictionary — Sensitive Data Tagging Mode

Demonstrates `sensitive_data_tagging` mode for a payment service with PII and financial fields.

```yaml
metadata:
  contract_version: n330-doc-suite-v1.2.1
  skill_id: "128"
  selected_mode: sensitive_data_tagging
  doc_id: DD-PAY-001
  doc_family_id: n330-rd-doc-suite
  readiness: complete
  open_blockers: []
```

## 数据字典摘要

**服务**: payment-service  
**对象数**: 3 张表  
**字段总数**: 18 个  
**敏感字段**: 6 个（PII×4, financial×2）  
**覆盖度**: 3/3 对象（100%）

---

## 对象索引表

| object_id | 对象名 | 类型 | 敏感级别 | 覆盖状态 |
|-----------|--------|------|---------|---------|
| OBJ-PAY-001 | payments | TABLE | financial | ✓ complete |
| OBJ-PAY-002 | payment_users | TABLE | PII | ✓ complete |
| OBJ-PAY-003 | audit_log | TABLE | internal | ✓ complete |

---

## 字段说明表 — payments

| field_id | field_name | type | meaning | sensitivity_level | masking_strategy | auto_tagged |
|----------|-----------|------|---------|------------------|-----------------|-------------|
| FLD-PAY-001 | payment_id | varchar(36) | Stable payment reference (UUID) | public | — | — |
| FLD-PAY-002 | amount | decimal(12,2) | Transaction amount in JPY | **financial** | Show to authorized roles only | ✓ keyword: `amount` |
| FLD-PAY-003 | card_last_four | char(4) | Last 4 digits of payment card | **financial** | Display as `****{value}` | ✓ keyword: `card` |
| FLD-PAY-004 | status | enum | Payment lifecycle status | internal | — | — |
| FLD-PAY-005 | created_at | timestamp | Payment creation time | internal | — | — |
| FLD-PAY-006 | idempotency_key | varchar(128) | Client-supplied idempotency token | **PII** | Never display; always `***` | ✓ keyword: `key` |

## 字段说明表 — payment_users

| field_id | field_name | type | meaning | sensitivity_level | masking_strategy | auto_tagged |
|----------|-----------|------|---------|------------------|-----------------|-------------|
| FLD-PAY-007 | user_id | varchar(36) | Stable user reference | public | — | — |
| FLD-PAY-008 | email | varchar(255) | User contact email | **PII** | `jo***@example.com` | ✓ keyword: `email` |
| FLD-PAY-009 | phone | varchar(20) | User contact phone | **PII** | `***-****-1234` | ✓ keyword: `phone` |
| FLD-PAY-010 | billing_address | text | Full billing address | **PII** | Truncate to city level for public | ✓ keyword: `address` |

---

## データ敏感级别与脱敏策略汇总

| sensitivity_level | 字段数 | 处理原则 |
|------------------|--------|---------|
| PII | 4 | GDPR Art.4 适用；不得明文传输；日志脱敏 |
| financial | 2 | PCI-DSS 适用；仅授权角色可见原值 |
| internal | 3 | 内部可见；不对外暴露 |
| public | 3 | 无限制 |

**字段 FLD-PAY-006（idempotency_key）**: 虽为内部技术字段，但包含 `key` 关键词，自动触发 PII 标注。该字段本身不含用户身份信息，标注 PII 为保守处理，技术团队可申请降级为 internal（需数据 owner 确认）。

---

## 对象覆盖度检查

- 覆盖对象: 3/3 ✓
- **无漏对象**
- DDL 完整性: payments 表缺少 `amount` 字段的 CHECK constraint (amount > 0) — 已在 open_blockers 记录

---

## Cross-links

| doc_id | 关系 | 说明 |
|--------|------|------|
| API-PAY-001 | 使用方 | payment API response 包含 FLD-PAY-001/002/004 |
| DOC-127-PAY | 来源 | 服务边界定义来自模块设计文档 |

---

## 缺失与待确认

```yaml
open_blockers:
  - "payments.amount 字段缺少 CHECK constraint (amount > 0) — 需 DBA 确认是否在 DB 层或应用层 enforce"
  - "payment_users.phone: 国际号码格式未统一 — 脱敏策略中"最后4位"可能不适用所有格式"
```

## Downstream Handoff

```yaml
handoff_id: DD-PAY-SENSITIVE-HANDOFF-2025-0611
producer_skill: data-dictionary-generation
consumer_skill_or_node: development-documentation-generation|api-documentation-generation
cross_doc_refs:
  - doc_id: MOD-PAY-001
    relationship: object_ownership_source
    producer_skill: module-design-document-generation
sensitive_fields_detected:
  - "FLD-PAY-002: amount (financial) — PCI-DSS applicable"
  - "FLD-PAY-003: card_last_four (financial) — display as ****{value}"
  - "FLD-PAY-008: email (PII) — GDPR Art.4 applicable"
  - "FLD-PAY-009: phone (PII) — GDPR Art.4 applicable"
  - "FLD-PAY-010: billing_address (PII) — truncate to city level for public"
  - "FLD-PAY-006: idempotency_key (PII, conservative) — team review recommended"
open_blockers:
  - "payments.amount: missing CHECK constraint (amount > 0)"
  - "payment_users.phone: international format standardization needed"
readiness: complete
confidence: high
next_best_checks:
  - "#125 dev docs: Section 9 should include FLD-PAY-006 as 'known gotcha'"
  - "#126 API docs: confirm idempotency_key sensitivity classification with data owner"
  - "DBA: add CHECK constraint for amount > 0"
```
