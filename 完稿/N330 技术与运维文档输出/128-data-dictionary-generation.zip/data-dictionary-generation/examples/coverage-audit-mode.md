# Coverage Audit Mode Example — Data Dictionary #128

## Metadata

```yaml
artifact_id: DATA-DICT-AUDIT-001
skill_id: 128
contract_version: n330-doc-suite-v1.2.1
selected_mode: coverage_audit
prior_dict_id: DATA-DICT-001
audit_date: "2025-06-15"
service_scope: [order-service, payment-service]
readiness: partial
```

## Coverage Audit Report

**Scope**: Auditing existing data dictionary `DATA-DICT-001` against current DDL for `order-service` and `payment-service`.

### Object Coverage Check

| Object | In Dictionary | In DDL | Coverage Status |
|--------|:---:|:---:|:---|
| `orders` | ✅ | ✅ | Covered |
| `order_items` | ✅ | ✅ | Covered |
| `payments` | ❌ | ✅ | **Missing — added to DDL after dict was authored** |
| `payment_logs` | ❌ | ✅ | **Missing — new table in v2.3** |
| `refunds` | ✅ | ✅ | Covered |
| `archived_orders` | ✅ | ❌ | **Stale — table dropped in migration M-041** |

**Coverage rate**: 4 / 6 current DDL objects documented (67%) — `partial`

### Field-Level Gap Report (for documented objects)

| Object | Field | In Dictionary | In DDL | Gap Type |
|--------|-------|:---:|:---:|:---|
| `orders` | `idempotency_key` | ❌ | ✅ | Field added post-dict |
| `orders` | `metadata_json` | ❌ | ✅ | New JSONB column |
| `order_items` | `discount_amount` | ✅ | ✅ | OK |
| `refunds` | `processor_ref` | ❌ | ✅ | Undocumented field |

**Total missing fields**: 3 across 2 objects

### Stale Entry Report

| Object | Status | Reason |
|--------|--------|--------|
| `archived_orders` | Dropped | Migration M-041 (2025-04-10) removed table |

### DDL Completeness Self-Check

For documented objects only:

| Check | Result |
|-------|--------|
| Primary keys present | ✅ All documented objects have PK |
| Foreign key constraints | ⚠️ `order_items.payment_id` FK undocumented |
| NOT NULL constraints | ✅ Complete for `orders`, `order_items` |
| Index coverage | ❌ `payments` object not yet in dictionary |

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: api-documentation-generation / development-documentation-generation
  doc_id: DATA-DICT-AUDIT-001
  missing_objects: [payments, payment_logs]
  stale_objects: [archived_orders]
  missing_field_count: 3
  open_blockers:
    - "payments table not yet in dictionary — FLD-IDs cannot be assigned for #126 cross-link"
    - "payment_logs new table — sensitivity_level unknown pending security review"
  readiness: partial
```
