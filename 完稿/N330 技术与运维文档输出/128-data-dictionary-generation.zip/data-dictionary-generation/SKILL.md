---
name: data-dictionary-generation
description: 生成数据字典（字段级文档）用于 n330 技术与运维文档输出。triggered when you need to produce field-level documentation covering data types, constraints, sensitivity classification (pii/financial/public), and ddl completeness. use sensitive_data_tagging mode for compliance or security review. do not use for module boundaries (→ #127), api contracts (→ #126), deployment steps (→ #129), or compliance audit decisions (→ security/legal team).
---

# 数据字典生成

## N330 contract baseline (n330-doc-suite-v1.2.1)

- contract_version: `n330-doc-suite-v1.2.1`
- workflow node: N330
- skill_id: 128
- primary artifact: `数据字典.md`
- family role: field-level data detail source; feeds #125 (sensitivity summary) and #126 (FLD-* IDs)
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through `doc_id` and `FLD-*` IDs cross-linked to #126/#125.

> **N330 skill boundary summary** — see `references/n330-shared-doc-suite-contract.md` for full boundary matrix:
> #125 aggregates · #126 API contracts · #127 module boundaries · **#128 data fields** · #129 deployment · #130 ops manual

## Role

作为 N330 文档家族中的**数据字典生成器**，产出供研发、测试、DBA、数据治理共同消费的数据字典。

具体职责：
- 为每个数据对象生成完整的字段级条目（类型/约束/敏感度/来源）
- 标注 `sensitivity_level`（PII/financial/public/internal/unknown），未知时标 unknown 并触发 open_blocker
- 脱敏策略使用标准化字段格式：`mask_type: partial | full | hash | tokenize`
- 输出对象覆盖度检查和 DDL 完整性自检区块
- 为 #125/#126 提供字段 ID 和敏感字段摘要

**不负责**：模块边界定义（→ #127）、API 接口规范（→ #126）、部署步骤（→ #129）、字段权限管控的执行（→ 安全团队）。

## When NOT to use this skill

- **Not a module design document**: table ownership and service-boundary decisions belong in #127; #128 documents field-level details within those boundaries.
- **Not an API specification**: API request/response schemas belong in #126; #128 covers the underlying database objects that those APIs read from or write to.
- **Not a deployment guide**: database migration scripts and execution sequences belong in #129; #128 documents the static data model.
- **Not a compliance audit**: #128 tags sensitivity levels; compliance audit decisions on whether those levels are acceptable belong to the compliance/legal team outside N330.

## Standalone and composition role

```yaml
standalone_goal: produce field-level documentation covering data types, constraints, sensitivity classification, and DDL completeness
minimum_viable_input:
  any_of:
    - DDL（CREATE TABLE 语句）
    - ORM 实体定义
    - 字段清单或接口 payload
    - 上游 N080 FLD-* 或 BE-* 清单
    - 若已有 N160 产物，以其为表级事实来源
partial_readiness_allowed: true
degradation_behavior: >
  If inputs are sparse, output a skeleton with all 9 sections present.
  Section 3 can have minimal entries (name + type + description only).
  Section 8: if no sensitive fields can be confirmed, write "无敏感字段识别 — 待安全团队确认"
  and trigger open_blocker. Do not omit Sections 6 and 7 — output explicit gap lists.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `ddl_aligned`: 以 DDL 为事实来源，字段描述从 DDL + PRD 双向补齐。
- `orm_aligned`: 以 ORM 实体为主，补 DDL 约束。
- `field_inventory_fallback`: 只有字段清单，先生成字段级字典。
- `coverage_audit`: 专门检查现有字典覆盖度，输出"漏字段"和"漏对象"报告。
- **`sensitive_data_tagging`**: 专用于合规/安全场景，每个字段必须标注数据敏感级别（PII/财务/内部/公开）和脱敏策略（`mask_type`）。

**Default routing**: DDL available → `ddl_aligned`. ORM only → `orm_aligned`. Compliance review → `sensitive_data_tagging`. Checking existing dict → `coverage_audit`.

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | 数据字典摘要 | Always | "摘要待补充" if missing |
| 2 | 对象索引表 | Always | List known; mark coverage as `partial` |
| 3 | 字段说明表 | Always | Min: name + type + description per field |
| 4 | 主键/外键/索引/约束 | Always | "约束待从 DDL 确认" if missing |
| 5 | 来源与使用位置 | Conditional (when evidence available) | Note omission in Section 9 |
| 6 | 对象覆盖度检查 | Always | "无漏对象" or explicit gap list |
| 7 | DDL 完整性自检 | Always | "缺失约束: 无" or explicit list |
| 8 | 数据敏感级别与脱敏策略 | Always when sensitive fields present or sensitive_data_tagging mode | Use `mask_type` enum; "无敏感字段识别" only when confirmed + open_blocker |
| 9 | Cross-links | Always | Empty table with doc_id column |

> Legend: Always = required in every mode; Conditional = required when evidence triggers it.

**sensitivity_level 枚举**: `PII` · `financial` · `internal` · `public` · `unknown`
**mask_type 枚举**: `partial` · `full` · `hash` · `tokenize` — always use these standardized values in Section 8.

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** `sensitivity_level: unknown` 未触发 open_blocker → 每个 unknown 字段必须在 Section 9 生成 open_blocker，要求安全团队确认。量化检验：sensitivity_level=unknown 出现次数必须 ≤ open_blocker 条目数（不能有 unknown 但无对应 open_blocker）。
- **AP-2** 脱敏策略只写"脱敏处理"而不指定 mask_type → 必须使用枚举值（partial/full/hash/tokenize）；"脱敏处理"是无效值。量化检验：mask_type 字段的所有值必须 ∈ {partial, full, hash, tokenize}；出现其他字符串值的字段数 = open_blocker 数。
- **AP-3** Section 6（覆盖度检查）或 Section 7（DDL 自检）省略 → 两节均为 Always 必填；即使无问题也要写"无漏对象"或"缺失约束: 无"。量化检验：Section 6 和 Section 7 字符数各 < 5 时视为违例；任一整节缺失则 FAIL。
- **AP-4** `sensitive_data_tagging` 模式下有字段未标注 sensitivity_level → 该模式要求全字段覆盖；漏标字段视为 unknown 并触发 open_blocker。量化检验：sensitive_data_tagging 模式下，字段说明表中缺少 sensitivity_level 标注的字段数 = 需补充的 open_blocker 数。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n330-shared-doc-suite-contract.md` — shared contract, doc_id format, cross-link rules
- `references/n330-document-family-crosslinks.md` — cross-link structure between #125–#130
- `references/n330-composition-guide.md` — composition guide
- `references/n330-input-validation-rules.md` — when input quality is uncertain
- `references/sensitive-data-masking-patterns.md` — when tagging sensitivity levels or defining mask_type
- `references/ddl-completeness-rubric.md` — when running DDL completeness self-check
- `references/object-coverage-check.md` — when running object coverage audit
- `references/id-linkage-guide.md` — when linking to upstream FLD-*, BE-*, PRD-XX IDs
- `references/data-dictionary-generation-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/family-aligned-data-dictionary.md` — ddl_aligned mode with FLD-* cross-links to #126
- `examples/sensitive-data-tagging-mode.md` — sensitive_data_tagging with full mask_type annotations

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: api-documentation-generation / development-documentation-generation
  doc_id: DATA-DICT-*-001
  sensitive_field_ids: [FLD-012, FLD-017]
  open_blockers: ["sensitivity_level unknown on FLD-023 — awaiting security team", "coverage: 7/10 objects documented"]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all objects and fields documented, sensitivity tagged) / `partial` (some objects or fields pending) / `degraded` (field inventory only; no DDL constraints or sensitivity tags — must not be used for compliance decisions).

## Workflow position

```
DDL / ORM entities / field inventory / upstream FLD-* IDs
  ↓ #128 (field-level data dictionary → 数据字典.md)
  → #125 receives sensitivity summary
  → #126 references FLD-* IDs
```
