---
name: data-dictionary-generation
description: generate data dictionary documentation for the n330 technical and operations documentation node. use when ChatGPT needs to turn ddl, orm entities, field inventories, or api payloads into a grounded data dictionary with coverage checks, stable field and object ids, and explicit links back to upstream forms, backend objects, and product requirements.
---

# 数据字典生成

## Role
作为 N330 文档家族中的数据字典生成器，产出供研发、测试、DBA、数据治理共同消费的数据字典。默认要求和 N080 `FLD-*`、`BE-*` 以及 N090 `PRD-XX` 建立可追溯关联。

## Selected mode
- `ddl_aligned`
- `orm_aligned`
- `field_inventory_fallback`
- `coverage_audit`

## Primary inputs
- DDL、ORM 实体、字段清单、接口 payload、表结构建议
- 上游 N080 `FLD-*`、`BE-*`
- 上游 N090 `PRD-XX`
- 若有 N160 产物，优先以其为表级事实来源

## Standalone rule
单独使用时也必须输出“对象覆盖度”和“DDL 完整性自检”，不能只给字段名释义表。

## Core output contract
1. 数据字典摘要
2. 对象索引表
3. 字段说明表
4. 主键 / 外键 / 索引 / 默认值 / 枚举
5. 来源与使用位置
6. 对象覆盖度检查
7. DDL 完整性自检
8. cross-links
9. 缺失与待确认

对象或字段记录至少给出：
`field_or_object / type / meaning / source / enum_or_values / required / default_value / validation_rules / usage_positions / related_ids`

## Design rules
- 字段和对象必须尽量对齐 `FLD-*` 与 `BE-*`，不要重新发明平行命名空间。
- 不仅解释字段含义，还要说明来源、使用位置、约束和默认值。
- 必须显式做“漏对象检查”。
- 若只有 payload 或字段草表，没有最终 DDL，也允许先出数据字典稿，但要标注事实等级。

## Execution workflow
1. 先识别对象集合与字段集合。
2. 建对象索引表和字段说明表。
3. 做 DDL 完整性自检。
4. 做对象覆盖度检查，对比 `BE-*`、`FLD-*` 与当前 schema。
5. 输出 cross-links 和缺失项，方便后续开发与 DBA 消费。

## Dynamic completeness
- 只有字段清单时：先生成字段级字典，并要求后续补表级约束。
- 只有 DDL 没有业务含义时：先写结构事实，并把业务含义放进待确认。

## Standalone use cases
- 数据治理项目的元数据盘点
- 合规 / 安全数据识别
- ORM 或 DDL 反推数据字典
- 旧系统表结构整理

## Quality bar
- 是否做了对象覆盖度检查
- 是否做了 DDL 完整性自检
- 是否对齐 `FLD-*` / `BE-*`
- 是否能被开发、测试、DBA 同时消费

## References
- `references/ddl-completeness-rubric.md`
- `references/object-coverage-check.md`
- `references/id-linkage-guide.md`
- `references/n330-document-family-crosslinks.md`

## N330 v1.2.0 contract baseline
Contract version: `n330-doc-suite-v1.2.0`.

This skill is self-contained. Standalone execution and multi-skill composition rely only on files packaged inside this skill plus artifacts exchanged through `cross_doc_refs` and `downstream_handoff`. Do not require outside-package shared directories, outside-package tools, external matrices, or hidden registries.

## Standalone and composition role
```yaml
standalone_contract:
  minimum_viable_input: DDL, ORM entities, schema draft, API payloads, or field inventory
  partial_readiness_allowed: true
  degradation_behavior:
    - keep required sections stable even when evidence is partial
    - mark gaps in metadata.open_blockers
    - put temporary IDs in metadata.pending_id_backfill
composition_contract:
  composition_role: data_contract_catalog
  join_keys:
    - doc_family_id
    - doc_id
    - scope.project_id
    - scope.release_id
    - scope.service_scope
    - scope.module_scope
    - upstream_id_aliases
    - cross_doc_refs
  best_combines_with: ['127', '126', '125', '130']
  consumes: ['module-design-document-generation', 'api-documentation-generation']
  produces_for: ['development-documentation-generation', 'api-documentation-generation', 'maintenance-manual-generation', 'N340']
  strengthens: converts DDL, ORM, and payload evidence into object and field contracts that API and maintenance docs can cite
```

## Required metadata and handoff
Every output must start with a `metadata` YAML block that follows `references/n330-shared-doc-suite-contract.md`. Every output must also end with a `downstream_handoff` block containing `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `doc_id`, `cross_doc_refs`, `pending_id_backfill`, `readiness`, `confidence`, and `next_best_checks`.

## N330 references
- Always use `references/n330-shared-doc-suite-contract.md` for metadata, join keys, handoff, standalone, and composition rules.
- Use `references/output-contract.yaml` for this skill's required sections and machine-readable contract.
- Use `references/data-dictionary-generation-quality-checklist.md` before finalizing the artifact.
- Use `examples/family-aligned-data-dictionary.md` as the closest style and structure reference.
- Use `references/id-linkage-guide.md` when aligning upstream IDs.
- Use `references/n330-document-family-crosslinks.md` when linking sibling N330 documents.

