# Example: N330 Document Family Composition Flow

Shows how skills #127→#126→#128→#125→#129→#130 compose into a unified technical documentation suite.

**Scenario**: Payment service new module "checkout-v2" being documented for handoff.

---

## Step 1 — #127 Module Design Document

**Artifact**: `DOC-127-CHECKOUT-V2`

Key outputs:
- Service cards: `checkout-orchestrator`, `payment-gateway-adapter`, `inventory-lock-service`
- Dependency matrix: checkout → payment (sync REST), checkout → inventory (sync gRPC), checkout → order-event-bus (async)
- **Boundary dispute**: `refund-processing` responsibility unclear — checkout-team vs payment-team
- `doc_id: MOD-CHECKOUT-V2-001`

Passed to #126 and #128 via `cross_doc_refs: [MOD-CHECKOUT-V2-001]`.

---

## Step 2 — #126 API Documentation

**Input**: `DOC-127-CHECKOUT-V2` service boundaries  
**Artifact**: `DOC-126-CHECKOUT-V2`

Key outputs:
- API index: `API-CHK-001` POST /v2/checkout, `API-CHK-002` GET /v2/orders/{id}
- `API-CHK-001`: `breaking_change: no` (new endpoint), `idempotency: key_based` (X-Idempotency-Key header)
- `API-CHK-002`: `breaking_change: no`
- Changelog: v2 adds `order_ref` field; `legacy_id` deprecated (removal: 2025-Q4)
- `doc_id: API-CHECKOUT-V2-001`

---

## Step 3 — #128 Data Dictionary

**Input**: `DOC-127-CHECKOUT-V2` service data, `DOC-126-CHECKOUT-V2` API schemas  
**Artifact**: `DOC-128-CHECKOUT-V2`

Key outputs (excerpt):

| field_or_object | type | meaning | sensitivity_level | masking_strategy |
|----------------|------|---------|------------------|-----------------|
| orders.buyer_email | varchar(255) | Buyer contact for order notifications | PII | Show first 2 chars + ***@domain |
| orders.total_amount | decimal(12,2) | Order total in JPY | financial | Show to authorized roles only |
| orders.order_ref | varchar(36) | Stable public order reference (replaces legacy_id) | public | — |

- Object coverage: 5/5 tables covered
- DDL completeness: 3 missing indexes flagged
- `doc_id: DD-CHECKOUT-V2-001`

---

## Step 4 — #125 Development Documentation (entry point)

**Input**: All three prior docs  
**Artifact**: `DOC-125-CHECKOUT-V2` (developer entry point)

Key outputs:
- Tech stack: `{FRAMEWORK}: Spring Boot 3.x`, `{DB}: MySQL 8.0`, `{CACHE}: Redis 7`
- Service cards: aggregated from DOC-127
- Section 9 — Known Pitfalls:
  - ⚠ `POST /v2/checkout` requires `X-Idempotency-Key` header; missing key returns 400, not 200. Source: API-CHK-001. Confidence: confirmed.
  - ⚠ `orders.legacy_id` deprecated — use `order_ref`. Source: DOC-126 changelog. Confidence: confirmed.
  - ⚠ `refund-processing` boundary unresolved (boundary dispute in DOC-127 Section 9). Source: MOD-CHECKOUT-V2-001. Confidence: inferred.
- Cross-links: PRD-24, FT-CHK-001 ~ FT-CHK-008, API-CHK-001/002, DOC-127/126/128/129/130

---

## Step 5 — #129 Deployment Documentation

**Input**: `DOC-127-CHECKOUT-V2` module dependencies, `DOC-126-CHECKOUT-V2` breaking changes  
**Artifact**: `DOC-129-CHECKOUT-V2`

Key outputs:
- Canary stages: `{CANARY_STAGES}: 5% → 25% → 100%`, each with 30-min soak
- Smoke tests:
  - ST-001: `POST /v2/checkout → 201, order_ref present` | timeout: 8s | blocking: yes
  - ST-002: `GET /v2/orders/{id} → 200` | timeout: 3s | blocking: yes
  - ST-003: `GET /health → status:ok` | timeout: 2s | blocking: yes
- Rollback: `rollback_option_id: RB-001, trigger: any ST-00x fails, RTO: 5min`

---

## Step 6 — #130 Maintenance Manual

**Input**: `DOC-129-CHECKOUT-V2` alerts, `DOC-127` service topology  
**Artifact**: `DOC-130-CHECKOUT-V2`

Key outputs:
- L1 triage tree (3 layers): is service returning 5xx? → check pod restarts → escalate
- Scenario card SC-001: `HIGH_CHECKOUT_LATENCY`, `false_positive_risk: low`, related_runbook: runbook-checkout-latency
- Section 6 — False Positive Rules: `CHECKOUT_CACHE_MISS` has `false_positive_risk: high` during deploy warm-up window (mitigated by DOC-129 warm-up gate)

---

## Document Family Cross-links

```
DOC-127 (module design) ──→ DOC-126 (API contracts)
                         ──→ DOC-128 (data dictionary)
                         ──→ DOC-129 (deployment phases)
                         ──→ DOC-130 (maintenance scenarios)
All ──→ DOC-125 (developer entry point / aggregator)
```

`cross_doc_refs` in each artifact:
- DOC-125: consumes DOC-126, DOC-127, DOC-128, DOC-129, DOC-130
- DOC-126: consumes DOC-127 (service boundaries)
- DOC-128: consumes DOC-127 (module data), DOC-126 (API schemas)
- DOC-129: consumes DOC-127 (module deps), DOC-126 (breaking changes)
- DOC-130: consumes DOC-129 (deploy alerts), DOC-127 (service topology)

All artifacts cite by `doc_id` only. No duplication of service card content across docs.

## Downstream Handoff

```yaml
handoff_id: N330-FAMILY-FLOW-HANDOFF
producer_skill: development-documentation-generation
consumer_skill_or_node: N340|weekly-report-generation
cross_doc_refs:
  - doc_id: DOC-127-checkout-v2
    relationship: module_boundaries_source
  - doc_id: API-CHECKOUT-V2
    relationship: api_contracts
  - doc_id: DD-CHECKOUT-V2
    relationship: data_dictionary
  - doc_id: DOC-129-checkout-v2
    relationship: deployment_docs
  - doc_id: DOC-130-checkout-v2
    relationship: maintenance_manual
section_9_pitfall_count: 4
readiness: complete
confidence: high
next_best_checks:
  - "N340 #132: checkout-v2 family is complete — include in next weekly report"
  - "#133: FAQ entries for 'How does checkout-v2 differ from v1?' ready to extract"
```
