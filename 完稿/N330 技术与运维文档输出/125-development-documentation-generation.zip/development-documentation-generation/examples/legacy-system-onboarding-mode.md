# Example: Development Documentation — Legacy System Onboarding Mode

Demonstrates `legacy_system_onboarding` mode: reverse-engineering developer docs from existing code with no prior documentation.

```yaml
metadata:
  contract_version: n330-doc-suite-v1.2.1
  skill_id: "125"
  selected_mode: legacy_system_onboarding
  doc_id: DEV-LEGACY-PAYMENT-001
  doc_family_id: n330-rd-doc-suite
  readiness: partial
  文档来源: 逆向推断（源代码 + 配置文件），需团队成员验证
  验证责任人: backend-lead
  open_blockers:
    - "Section 4 技术栈: ORM 框架未从代码中明确识别，需确认"
    - "Section 9 第3条坑点: 需 DBA 确认 migrate.sh 的 prod 限制是否仍然有效"
```

## 1. 文档摘要

**系统**: legacy-payment-service（2019年遗留系统，无历史文档）  
**本文档来源**: 逆向推断自源代码、配置文件、migration 历史  
**推断置信度**: medium（核心结构 high；部分约束 low，需验证）  
**验证截止**: 2025-06-30

---

## 2. 读者与适用范围

- **主要读者**: 接手该系统的新任 backend 工程师
- **适用场景**: 首周上手（理解边界 + 避开已知坑）
- **不适用**: 生产运维（见 DOC-130-PAY，待创建）

---

## 3. 系统与模块总览

从代码目录结构逆向推断（confidence: inferred）:

| module | 职责（推断）| 入口文件 | confidence |
|--------|-----------|---------|-----------|
| payment-core | 支付流程主逻辑 | `src/payment/core/PaymentService.java` | high |
| cart-legacy | 购物车逻辑（疑似已被 cart-service 替代）| `src/cart/CartModule.java` | medium |
| notification | 通知发送 | `src/notify/NotificationSender.java` | high |

---

## 4. 技术栈占位符表

| 类别 | 推断值 | 来源 | confidence |
|------|--------|------|-----------|
| {LANGUAGE} | Java 11 | pom.xml: `<java.version>11</java.version>` | confirmed |
| {FRAMEWORK} | Spring Boot 2.7.x | pom.xml dependency | confirmed |
| {DB} | MySQL 8.0 | `application.properties`: `datasource.url` | confirmed |
| {ORM} | {ORM_UNKNOWN} | 未在 pom.xml 找到明确 ORM 声明 | **待确认** |
| {CACHE} | Redis 7 | `redis.host` in config | confirmed |
| {MQ} | RabbitMQ | `spring.rabbitmq` in config | confirmed |

---

## 5. 服务卡片汇总

```
service_id: legacy-payment-service
responsibility: 处理支付流程（推断），包含购物车、支付、通知三个模块
not_responsible_for: 库存管理（无相关代码）；用户认证（调用外部 auth-service）
confidence: medium（职责边界推断自代码，未经原团队确认）
```

---

## 6. 核心开发流程

```bash
# 本地启动（从 README 片段推断）
mvn spring-boot:run -Dspring.profiles.active=local

# 运行测试
mvn test

# 注意：无法在本地运行完整端到端测试，需连接 staging Redis
```

---

## 7. 关键约束/禁令/NFR

- **禁令（inferred from config）**: `config/local.yaml` 未被 `.gitignore` 覆盖 — 严禁提交含密钥的本地配置
- **禁令（inferred from history）**: 生产数据库迁移脚本 `migrate.sh` 含 `--prod` 标志 — 需 DBA 审批后方可执行
- **NFR（inferred from code）**: 支付接口有 idempotency token 机制，重试必须携带 `X-Idempotency-Key`

---

## 8. 本地开发与调试入口

- 本地 profile: `application-local.properties`（需从团队同步，**不在仓库中**）
- 调试端口: 默认 8080
- 健康检查: `GET /actuator/health`
- **待补充**: Swagger/OpenAPI 入口（未找到配置）

---

## 9. 常见问题与已知坑点（逆向推断，需验证）

| # | 坑点 | 来源 | 风险 | confidence |
|---|------|------|------|-----------|
| ⚠1 | `config/local.yaml` 未被 .gitignore — 提交会泄露 API key | `.gitignore` 检查 | 安全漏洞 | confirmed |
| ⚠2 | `migrate.sh --prod` 不可在未经 DBA 审批时执行 | 脚本注释（`# DANGER: prod only`）| 数据丢失 | high（需DBA确认当前政策） |
| ⚠3 | cart-legacy 模块可能已被 cart-service 替代，直接修改 CartModule.java 有双写风险 | `CartModule.java` import 分析 | 数据不一致 | medium（需原团队确认） |

---

## 10. Cross-links

| doc_id | 关系 | 状态 |
|--------|------|------|
| API-PAY-* | 接口文档（需创建，#126）| 待创建 |
| DD-PAY-* | 数据字典（需创建，#128）| 待创建 |
| DOC-129-PAY | 部署文档（需创建，#129）| 待创建 |
| DOC-130-PAY | 维护手册（需创建，#130）| 待创建 |

---

## 11. 缺失与待确认

```yaml
open_blockers:
  - "ORM 框架未识别 — backend-lead 确认"
  - "migrate.sh 生产审批政策 — DBA 确认"
  - "CartModule.java 是否已废弃 — 原团队确认"
  - "本地 profile 文件获取方式 — 待 backend-lead 提供"
pending_id_backfill:
  - API-PAY-*（接口 ID 待 #126 输出后回填）
  - DD-PAY-*（字段 ID 待 #128 输出后回填）
```

```yaml
downstream_handoff:
  handoff_id: DEV-DOC-LEGACY-PAY-HANDOFF
  producer_skill: development-documentation-generation
  consumer_skill_or_node: api-documentation-generation|data-dictionary-generation|N340
  cross_doc_refs: []  # siblings not yet created; to be populated
  section_9_pitfall_count: 3
  readiness: partial
  confidence: medium
  next_best_checks:
    - "#126: create API documentation for payment-service endpoints"
    - "#128: create data dictionary for MySQL tables (payments, payment_users, audit_log)"
    - "backend-lead: validate Section 9 pitfalls before sharing with new engineers"
    - "DBA: confirm migrate.sh approval policy"
```
