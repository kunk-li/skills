metadata:
  contract_version: n330-doc-suite-v1.2.0
  workflow_node: N330
  skill_id: 125
  skill_name: development-documentation-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-125-claims-01
  selected_mode: document_family_aligned
  readiness: ready
  scope:
    project_id: claims-modernization
    release_id: REL-2026-claims-01
    service_scope: [claims-api, claims-worker]
    module_scope: [claims]
  source_artifacts: [architecture-brief.md, api-inventory.md, ddl.sql, release-plan.md]
  upstream_id_aliases: [FT-claims-01-01, BE-claims-01, API-claims-01, FLD-claims-P01-01, PRD-07]
  cross_doc_refs: [DOC-127-claims-01, DOC-126-claims-01, DOC-128-claims-01, DOC-129-claims-01, DOC-130-claims-01]
  pending_id_backfill: []
  freshness:
    as_of_date: 2026-05-07
    source_commit: abc1234
    expected_review_window: after every minor release
  open_blockers: []
  owner_placeholders: [claims-service-owner, platform-release-team]
  confidence: high
  composition_role: developer_entrypoint
  stage_position: documentation_family.technical_docs.example
  node_artifact_target: development-documentation.md

# Development Documentation Example

## Document summary
This guide is the developer entry point for the claims modernization documentation family. It summarizes where to find module, API, data, deployment, and operations source-of-truth details.

## System and module overview
Claims modernization is split into `claims-api` and `claims-worker`. Service ownership, dependency type, and NFR expectations are defined in DOC-127-claims-01.

## Tech stack placeholder table
| layer | placeholder | current value | blocker |
|---|---|---|---|
| database | {DATABASE} | PostgreSQL | none |
| queue | {QUEUE} | managed queue | confirm retention window |

## Core development workflow
1. Review module boundaries in DOC-127-claims-01.
2. Implement or update API behavior using DOC-126-claims-01.
3. Update fields and schema according to DOC-128-claims-01.
4. Validate deployment and operations behavior with DOC-129-claims-01 and DOC-130-claims-01.

downstream_handoff:
  contract_version: n330-doc-suite-v1.2.0
  handoff_id: HO-N330-REL-2026-claims-01-125
  producer_skill: development-documentation-generation
  consumer_skill_or_node: N340
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-125-claims-01
  release_id: REL-2026-claims-01
  required_fields: [doc_id, scope, upstream_id_aliases, cross_doc_refs]
  cross_doc_refs: ['DOC-127-claims-01', 'DOC-126-claims-01', 'DOC-128-claims-01', 'DOC-129-claims-01', 'DOC-130-claims-01']
  pending_id_backfill: []
  readiness: ready
  confidence: high
  next_best_checks: []
