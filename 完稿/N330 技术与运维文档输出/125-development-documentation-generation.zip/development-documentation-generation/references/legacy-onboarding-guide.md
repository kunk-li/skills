# Legacy System Onboarding Guide

Use this guide when `legacy_system_onboarding` mode is selected, or when the primary input is existing code without documentation.

## When to use this mode
- No architecture document, README, or onboarding guide exists
- The primary evidence is source code, config files, or migration scripts
- The team inheriting the system has limited access to original authors

## Evidence sources and inference levels
| Source | Inference level | Usage |
|--------|----------------|-------|
| Config files (yaml, env, properties) | `inferred` | Tech stack, environment variables, service connections |
| Database migration files | `inferred` | Schema history, table relationships, data evolution |
| Code comments / docstrings | `inferred` | Original intent (treat with caution; may be stale) |
| CI/CD scripts | `inferred` | Build steps, deploy targets, test commands |
| Package manifests (pom.xml, package.json) | `confirmed` | Dependency versions, language runtime |
| README fragments | `confirmed` | Any verified description |

Always label inferred content with `[inferred from <source>]` in the document.

## Section 9 — Known Pitfalls: mandatory content rules
Section 9 must always be present. Content priority:
1. **Operational hazards**: scripts or commands that are irreversible (e.g., `migrate.sh --prod`, `DROP TABLE`)
2. **Security traps**: config files with secrets, hardcoded credentials, unrotated API keys
3. **Fragile dependencies**: services or tools with known compatibility constraints
4. **Historical failures**: if postmortem or incident data is available, extract top 3 recurrence patterns
5. **Placeholder**: if none of the above can be extracted, write: `"待从团队成员处收集"` — never omit the section

## Format for pitfall entries
```markdown
⚠ **[Pitfall title]**
- Source: [config file / code / incident INC-xxx / team knowledge]
- Risk: [what breaks if this is ignored]
- Rule: [what to do instead]
- Confidence: inferred | confirmed
```

## Document summary labeling
When content is reverse-engineered from code, the document summary (section 1) must include:
```
文档来源: 逆向推断（源代码 + 配置文件），需团队成员验证
验证责任人: [待确认]
验证截止: [待确认]
```
