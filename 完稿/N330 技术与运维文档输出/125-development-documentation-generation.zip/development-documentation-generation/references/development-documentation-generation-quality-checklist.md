# N330 Development Documentation Quality Checklist

Use this checklist before finalizing `development-documentation.md`. The skill is standalone, so all required checks must be answerable from files packaged in this skill and the user-provided inputs.

1. Metadata follows `references/n330-shared-doc-suite-contract.md` and includes all required fields.
2. `selected_mode` matches both the user request and the produced document body.
3. `doc_id` follows `DOC-{skill_id}-{project_id}-{nn}`; any fallback `DOC-{skill_id}-TEMP-{date}-{source}` appears in `pending_id_backfill`.
4. `upstream_id_aliases` preserves upstream IDs exactly; uncertain IDs are marked `TEMP-*` or `to_confirm` rather than invented.
5. `cross_doc_refs` use sibling `doc_id` values, not file paths; missing sibling documents are explicit stubs in `open_blockers`.
6. Verify the developer entry point links to module, API, data, deployment, and maintenance documents by doc_id instead of copying their source-of-truth tables.
7. `source_artifacts` and `freshness` identify the evidence base, including `as_of_date`, `source_commit`, or explicit `unknown`.
8. `open_blockers` names unresolved gaps and their next best checks.
9. `owner_placeholders` use role/team names only; do not use personal blame or hard-coded individual ownership.
10. `downstream_handoff` includes `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `required_fields`, `readiness`, `confidence`, and `next_best_checks`.
11. Compare the produced development document's metadata key order, field naming, cross-link style, and section structure against the closest file under `examples/`. Differences are allowed but should be intentional.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- `legacy_system_onboarding` mode: section 9 (Known Pitfalls) is never empty — minimum content is "待从团队成员处收集".
- `stack_placeholder_first` mode: all `{PLACEHOLDER}` items are listed in a table before any project-specific values.
- `cross-links` section is always present; links to 126/127/128/129/130 use doc_id format even if TBD.

## Output structure completeness checks
- All 11 mandatory sections are present; Section 9 never empty.
- Section 9 has ≥3 pitfalls with source attribution; `legacy_system_onboarding` pitfalls have confidence labels.
- Tech stack unknowns remain as {PLACEHOLDER}, not invented defaults.
- cross-links table populated with known doc_ids; empty only when no siblings exist yet.
- `downstream_handoff` contains `cross_doc_refs` listing all consumed sibling doc_ids.
- `legacy_system_onboarding` mode: document summary states "逆向推断，需验证" with responsible validator named.
