---
name: development-documentation-generation
description: Generate a developer entry-point onboarding document that aggregates module design, API contracts, data dictionary, deployment, and maintenance docs into a unified whole.
---

# 开发文档生成

## N330 contract baseline (n330-doc-suite-v1.2.1)

- contract_version: `n330-doc-suite-v1.2.1`
- workflow node: N330
- skill_id: 125
- primary artifact: `开发文档.md`
- family role: developer entry-point aggregator; references #126–#130 via cross-links
- downstream nodes: N340 #132 (weekly report upstream), N340 #133 (FAQ upstream)
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through cross-links using `doc_id` from #126–#130.

> **N330 skill boundary summary** — see `references/n330-shared-doc-suite-contract.md` for full boundary matrix:
> #125 aggregates · #126 API contracts · #127 module boundaries · #128 data fields · #129 deployment · #130 ops manual

## Role

作为 N330 文档家族中的**开发者入口文档生成器**，产出"新人 3 天能上手、已有成员能快速对齐"的开发文档。

具体职责：
- 聚合 #127（服务卡片）、#126（API 索引）、#128（敏感字段摘要）、#129/#130 的坑点，产出开发者一站式参考
- 维护第 9 章"常见问题与已知坑点"（永不省略，≥3 条项目特定陷阱）
- 用 `{PLACEHOLDER}` 保留未确认的技术栈选择
- 产出 N340 周报和 FAQ 的上游输入

**不负责**：模块边界定义（→ #127）、API 规范（→ #126）、数据字典（→ #128）、部署指南（→ #129）、运维手册（→ #130）。

## When NOT to use this skill

- **Not a module design document**: service boundaries and dependency diagrams belong in #127; #125 aggregates and presents them for developers — it does not re-define them.
- **Not an API specification**: interface schemas, error codes, and breaking change records belong in #126; #125 references them via cross-links.
- **Not a data dictionary**: field-level DDL details belong in #128; #125 surfaces the sensitivity summary and known pitfalls only.
- **Not a deployment guide**: step-by-step deployment procedures belong in #129; #125 links to them from the developer entry point.
- **Not a runbook**: operational triage belongs in #130; #125 may include a brief "first-day gotchas" section, not a full operations manual.
- **Not an ADR**: architecture decision records belong in a dedicated ADR system; #125 references the resulting constraints.

## Standalone and composition role

```yaml
standalone_goal: produce a developer-facing unified onboarding document from any available design material
minimum_viable_input:
  any_of:
    - 技术方案或设计文档
    - 服务列表或模块说明
    - 接口草稿或 API 说明
    - 部署说明或环境配置
    - 团队内部 wiki 或 onboarding notes
partial_readiness_allowed: true
degradation_behavior: >
  If inputs are sparse, output a skeleton with all 11 sections present.
  Mark unknowns as {PLACEHOLDER} in Section 4. Section 9 must still contain
  ≥1 entry — use "待从团队成员处收集" if nothing is available.
  Distinguish: confirmed tech stack | placeholder-retained choices | content pending #126–#130.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `document_family_aligned`: 已有 #126/#127/#128/#129/#130 或等价材料，适合做统一入口。
- `stack_placeholder_first`: 技术栈不完整，先保留 `{DATABASE}` 等占位符，不硬写具体产品。**最小输出标准**：Section 3（系统与模块总览）必须至少列出 1 个已知服务名（不得整节留空）；未知服务写 `{SERVICE_NAME}`。Section 4（技术栈占位符表）必须列出全部待确认技术栈条目，每行格式为 。其余章节可全量使用占位符，但标题行和占位符值必须存在。
- `direct_input_fallback`: 仅有零散设计材料，给出最小可读版本。
- **`legacy_system_onboarding`**: 面向遗留系统接手场景，优先列出"已知坑点"、"禁止事项"和"必须先读清单"，再补齐标准章节。Section 9 条目必须标注 source（config/code/incident）和 confidence level。

**Default routing**: All #126–#130 available → `document_family_aligned`. Partial materials available (some but not all of #126–#130) → `document_family_aligned` (fill gaps with `{PLACEHOLDER}`). No materials at all, only tech stack unknown → `stack_placeholder_first`. Inheriting legacy system → `legacy_system_onboarding`.

## Primary inputs

优先使用：
- 技术方案、模块设计、接口说明、数据字典、部署说明、维护手册
- 上游 N080 / N090 的 `FT-*`、`API-*`、`FLD-*`、`PRD-XX`
- 当前项目的技术栈、开发流程、环境约束、禁令或特殊规范

## Mandatory output sections

| # | Section | Required | Placeholder when missing |
|---|---------|----------|--------------------------|
| 1 | 文档摘要 | Always | "摘要待补充" |
| 2 | 读者与适用范围 | Always | State target reader type |
| 3 | 系统与模块总览 | Always | Minimal: list known services |
| 4 | 技术栈占位符表 | Always | All unknowns as `{PLACEHOLDER}` |
| 5 | 服务卡片汇总 | Always | Minimal card per service |
| 6 | 核心开发流程 | Always | "流程待从团队收集" |
| 7 | 关键约束/禁令/NFR | Always | "约束待确认" |
| 8 | 本地开发与调试入口 | Always | "调试入口待补充" |
| 9 | 常见问题与已知坑点 | **Always — never omit** | "待从团队成员处收集" — ≥3 specific traps required |
| 10 | Cross-links | Always | Empty table with doc_id column |
| 11 | 缺失与待确认 | Always | All open_blockers listed here |

> Legend: Always = required in every mode.

**Section 9 is the highest-value section for onboarding.** It must never be empty. `legacy_system_onboarding` mode: each entry must include source and confidence level.

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** Section 9 完全省略或只有"暂无"→ 违反 mandatory 规则；至少写"待补充"并在 Section 11 标注为 open_blocker。量化检验：Section 9 正文字符数 < 10 视为违例；若整个 Section 9 缺失则直接 FAIL。
- **AP-2** 把 API schema 或 DDL 详情直接写入 #125 → 应通过 cross-link 引用 #126/#128，不在 #125 中重写。量化检验：正文（非代码块）中出现 `requestBody`/`CREATE TABLE`/`DDL` 等 API schema 或 DDL 关键词时计入违例。
- **AP-3** 未确认的技术栈直接写成具体产品（如"使用 PostgreSQL"）→ 必须用 `{DATABASE}` 占位，在 Section 4 列入占位符表。量化检验：Section 4 中每个具体产品名（PostgreSQL/Redis/Kafka 等）必须对应一个 `{PLACEHOLDER}` 占位符，否则计入违例。
- **AP-4** `legacy_system_onboarding` 模式下 Section 9 条目缺少 source 字段 → 每条坑点必须标注来源（config/code/incident）和置信度。量化检验：legacy_system_onboarding 模式下，Section 9 中缺少 source 标注的条目数 = open_blocker 数。
- **AP-5** `stack_placeholder_first` 模式下 Section 3（系统与模块总览）整节为空 → Section 3 是永远必填节，即使技术栈完全未知也必须列出已知服务名（至少 1 个）或写明服务数量待确认；整节空白视为违例。量化检验：stack_placeholder_first 模式下 Section 3 字符数 < 20 且不含任何服务名 → FAIL。

## References

Read only when relevant to the request:
- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming IDs across skills
- `references/n330-shared-doc-suite-contract.md` — shared contract, doc_id format, cross-link rules, composition guide
- `references/n330-document-family-crosslinks.md` — cross-link structure between #125–#130
- `references/n330-composition-guide.md` — how #125–#130 compose and when to combine
- `references/n330-input-validation-rules.md` — when input quality is uncertain or selecting the appropriate skill
- `references/legacy-onboarding-guide.md` — when using legacy_system_onboarding mode
- `references/id-linkage-guide.md` — when linking to upstream FT-*, API-*, FLD-*, PRD-XX IDs
- `references/development-documentation-generation-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/family-aligned-development-documentation.md` — document_family_aligned mode with #126–#130 cross-links
- `examples/legacy-system-onboarding-mode.md` — legacy_system_onboarding with forbidden-list and must-read sections
- `examples/n330-doc-family-flow.md` — how #125–#130 compose across a full delivery cycle

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: N340/weekly-report-generation / N340/faq-generation
  doc_id: DEV-DOC-*-001
  open_blockers: ["Section 9 entry count below minimum", "tech stack unconfirmed"]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all 11 sections present with real content) / `partial` (some sections have placeholders) / `degraded` (skeleton only — all unknowns are {PLACEHOLDER}; downstream consumers must not treat as a reliable reference without team review).

## Workflow position

```
Tech specs / module design / API drafts / deployment notes
  ↓ #125 (developer entry-point aggregation → 开发文档.md)
  ↓ N340 #132 (weekly report upstream)
  ↓ N340 #133 (FAQ upstream)
```
