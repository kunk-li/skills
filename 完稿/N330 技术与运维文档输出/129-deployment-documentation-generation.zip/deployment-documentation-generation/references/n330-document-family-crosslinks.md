# N330 Document Family Crosslinks

## Goal
Make the six N330 documents readable alone and stronger as one documentation family.

## Common cross-link fields
Every artifact should expose these fields in metadata or body tables:
- `doc_family_id`: always `n330-rd-doc-suite`
- `doc_id`: stable ID for the current document
- `cross_doc_refs`: sibling N330 `doc_id` values
- `related_module_ids`: module or service IDs from module design or upstream artifacts
- `related_feature_ids`: upstream `FT-{module}-{page_seq}-{nn}` values
- `related_api_ids`: upstream `API-{module}-{nn}` values
- `related_field_ids`: upstream `FLD-{module}-P{page_seq}-{nn}` values
- `related_prd_sections`: upstream `PRD-XX` values
- `related_runbooks`: `RB-*` or `SC-*` runbook and scenario IDs

## Cross-node ID alignment
- Reuse N080 `FT-*`, `API-*`, `FLD-*`, and `BE-*` IDs when present.
- Reuse N090 `PRD-XX` sections when present.
- Reuse N300/N310/N320 incident or runbook references in maintenance documents when present.
- Temporary IDs must be marked with `TEMP-*` and listed in `pending_id_backfill`.

## Composition suggestions
- 127 defines module boundaries and service cards.
- 126 and 128 reuse 127 boundaries and service cards.
- 125 aggregates 126/127/128/129/130 as a developer entry point.
- 129 reuses 127 service dependencies and 126 endpoint inventory.
- 130 reuses 129 deployment and rollback paths plus N300/N310/N320 operating scenarios.
