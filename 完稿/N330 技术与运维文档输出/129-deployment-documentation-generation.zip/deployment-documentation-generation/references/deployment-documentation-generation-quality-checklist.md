# N330 Deployment Documentation Quality Checklist

Use this checklist before finalizing `deployment-documentation.md`. The skill is standalone, so all required checks must be answerable from files packaged in this skill and the user-provided inputs.

1. Metadata follows `references/n330-shared-doc-suite-contract.md` and includes all required fields.
2. `selected_mode` matches both the user request and the produced document body.
3. `doc_id` follows `DOC-{skill_id}-{project_id}-{nn}`; any fallback `DOC-{skill_id}-TEMP-{date}-{source}` appears in `pending_id_backfill`.
4. `upstream_id_aliases` preserves upstream IDs exactly; uncertain IDs are marked `TEMP-*` or `to_confirm` rather than invented.
5. `cross_doc_refs` use sibling `doc_id` values, not file paths; missing sibling documents are explicit stubs in `open_blockers`.
6. Verify canary stages, gates, verification checks, rollback options, and RTO ordering stay parameterized and cite module/API dependencies by doc_id.
7. `source_artifacts` and `freshness` identify the evidence base, including `as_of_date`, `source_commit`, or explicit `unknown`.
8. `open_blockers` names unresolved gaps and their next best checks.
9. `owner_placeholders` use role/team names only; do not use personal blame or hard-coded individual ownership.
10. `downstream_handoff` includes `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `required_fields`, `readiness`, `confidence`, and `next_best_checks`.
11. Compare the produced deployment documentation's metadata key order, field naming, cross-link style, and section structure against the closest file under `examples/`. Differences are allowed but should be intentional.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- Smoke test section always has ≥3 entries; if fewer available from input, remaining slots are `待补充` with `blocking: tbd`.
- `RTO-sorted rollback options` always present; minimum 1 rollback option even if estimated.
- `hotfix_deployment` mode: risk checklist items for DB migration and active session impact are always answered.

## Output structure completeness checks
- Sections 1–3 and 5–10 are present (Section 4 canary requires evidence).
- Section 8 (Smoke tests) has ≥3 entries; `hotfix_deployment` mode allows compressed but not omitted.
- Smoke test entries have `blocking` field assigned (yes/no/tbd) — never blank.
- Section 6 (rollback options) has ≥1 option, even if estimated RTO.
- Hotfix mode: all smoke tests are `blocking: yes`.
