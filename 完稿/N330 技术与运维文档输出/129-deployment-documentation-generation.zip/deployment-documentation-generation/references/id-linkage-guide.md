# N080 / N090 / N330 ID Linkage Guide

## Preferred upstream IDs
- Page: `P-{module}-{nn}`
- Feature: `FT-{module}-{page_seq}-{nn}`
- Backend capability: `BE-{module}-{nn}`
- API: `API-{module}-{nn}`
- Action: `ACT-{module}-P{page_seq}-{nn}`
- Field: `FLD-{module}-P{page_seq}-{nn}`
- PRD section: `PRD-XX`
- Runbook: `RB-{module}-{nn}`
- Scenario card: `SC-{scenario_id}`

## Usage rules
- Preserve existing upstream IDs exactly. Do not rewrite prefixes.
- If a relationship is uncertain, mark it as `unknown` or `to_confirm` rather than inventing a mapping.
- If no upstream ID exists, create a `TEMP-*` ID and include it in `pending_id_backfill` and `downstream_handoff.next_best_checks`.
- Deployment and maintenance docs should also use `RB-*` and `SC-*` IDs for runbooks and scenario cards.
