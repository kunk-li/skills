# Smoke Test Template

Use this reference to construct the mandatory smoke test section for every deployment document.

## Minimum requirement
Every deployment document must include at least 3 smoke tests covering:
1. One authentication or health check path
2. One core business transaction (the most critical user-facing flow)
3. One data integrity check or downstream dependency verification

## Smoke test entry schema
```yaml
smoke_test:
  test_id: ST-001
  description: "POST /auth/login returns valid session token"
  precondition: "Test user account exists in staging environment"
  steps:
    - "POST /auth/login with valid credentials"
  expected_result: "HTTP 200, response contains session_token field, token is non-empty"
  timeout_seconds: 5
  blocking: yes  # yes = deployment halts if this test fails; no = warning only
  owner_role: backend-team
  environment: [staging, production]
```

## blocking field rules
- `blocking: yes` — required for:
  - Authentication/authorization checks
  - Core revenue or compliance paths
  - Any test whose failure indicates systemic failure
- `blocking: no` — acceptable for:
  - Non-critical feature checks
  - Performance benchmarks (use separate load tests)
  - Monitoring/observability checks

At least 2 of the minimum 3 smoke tests must be `blocking: yes`.

## Hotfix deployment smoke test minimum
When using `hotfix_deployment` mode, the smoke test list is compressed to:
1. `GET /health` or equivalent — `blocking: yes`
2. Core transaction for the hotfixed feature — `blocking: yes`
3. Regression check on the most likely affected adjacent feature — `blocking: yes`

All hotfix smoke tests must be `blocking: yes`. Do not skip any.

## Smoke test pre-conditions
Document any state that must exist before the test:
- Database seed data required
- Feature flags that must be enabled
- External service stubs or mocks
- Test user accounts or API keys

## Rollback trigger from smoke tests
Specify the rollback trigger condition:
```yaml
rollback_trigger: "Any blocking smoke test fails within 10 minutes of deployment"
rollback_responsible_role: on-call-sre
rollback_max_time_minutes: 15
```

## Example smoke test set (3-test minimum)
```yaml
smoke_tests:
  - test_id: ST-001
    description: "Health check returns OK"
    expected_result: "GET /health → HTTP 200, status: ok"
    timeout_seconds: 3
    blocking: yes
  - test_id: ST-002
    description: "User can complete checkout flow"
    expected_result: "POST /orders → HTTP 201, order_id present"
    timeout_seconds: 8
    blocking: yes
  - test_id: ST-003
    description: "Inventory service responds to query"
    expected_result: "GET /inventory/check → HTTP 200, available field present"
    timeout_seconds: 5
    blocking: yes
rollback_trigger: "Any ST-00x blocking test fails"
```
