# Rollback Decision Rules

Use this reference when building the `RTO-sorted rollback options` section of deployment documentation.

## Rollback option types

| Type | When to use | RTO estimate | Data impact |
|------|-------------|-------------|-------------|
| Image rollback | Stateless service; no DB migration | 3-10 min | None |
| Feature flag off | Feature flag gated deployment | < 2 min | None |
| Config rollback | Config-only change (no code) | 2-5 min | None |
| Blue-green switch | Blue-green deployment active | 1-3 min | None |
| DB migration rollback | Reversible schema change | 10-30 min | Risk of data loss |
| Manual data fix | Non-reversible schema change | 30-120 min | High |

## Mandatory fields per rollback option

Every rollback option must include:
- `option_id`: stable reference ID (e.g., RB-001)
- `trigger_condition`: specific condition that triggers this option
- `operation`: exact command or step sequence
- `estimated_rto`: realistic time estimate
- `data_impact`: none / low / medium / high
- `owner_role`: who executes the rollback

## RTO-sorting rule

Always list rollback options in ascending RTO order (fastest first). The first option is the default rollback path.

## DB migration rollback classification

If a migration is **irreversible** (column drop, data transform with loss):
- `data_impact: high`
- Add to `deployment.open_blockers` with note: "不可逆迁移需 DBA sign-off"
- Smoke test must verify data integrity before proceeding past gate

## Hotfix deployment rollback rule

For `hotfix_deployment` mode: always include at least one rollback option with RTO ≤ 10 minutes. If no such option exists, escalate before deploying.

## validate_csv.py reference

When rollback options are in CSV format, validate:
- `option_id` follows RB-NNN format
- `estimated_rto` contains a numeric value in minutes
- `data_impact` is one of: none / low / medium / high
