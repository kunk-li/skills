---
name: deployment-documentation-generation
description: Produce deployment guides — pipeline stages, canary configuration, smoke tests, RTO-sorted rollback options, and hotfix procedures.
---

# 部署文档生成

## N330 contract baseline (n330-doc-suite-v1.2.1)

- contract_version: `n330-doc-suite-v1.2.1`
- workflow node: N330
- skill_id: 129
- primary artifact: `部署说明.md`
- family role: deployment execution guide; consumes breaking change signals from #126; feeds smoke_test_ids and alerts_to_monitor to #130
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through `doc_id`; reference #127 for service topology; signal #130 with smoke_test_ids.

> **N330 skill boundary summary** — see `references/n330-shared-doc-suite-contract.md` for full boundary matrix:
> #125 aggregates · #126 API contracts · #127 module boundaries · #128 data fields · **#129 deployment** · #130 ops manual

## Role

作为 N330 文档家族中的**部署说明生成器**，产出供 SRE、发布经理、值班人员消费的部署文档。

具体职责：
- 构建 RTO 排序的回滚选项清单（≥1 条，hotfix 模式要求 ≤10min 选项，并标注 RTO 估算依据）
- 维护 smoke test 节（永不省略；hotfix 允许压缩至 3 条但不可删除）
- 在 breaking change 场景下添加客户端迁移验证 gate
- 为 #130 提供 `smoke_test_ids` 和 `alerts_to_monitor` 字段

**不负责**：服务边界（→ #127）、API 规范（→ #126）、维护手册（→ #130）、数据字典（→ #128）、发版 go/no-go 决策（→ release-owner）。

## When NOT to use this skill

- **Not a release decision maker**: deployment documentation describes how to deploy; the go/no-go decision belongs to release owner and N360.
- **Not an incident postmortem**: if a deploy caused an incident, document in N320 #123/#124; reference incident_id in the rollback section.
- **Not a module design document**: service topology belongs in #127; #129 translates those dependencies into deployment phases and gates.
- **Not a runbook**: detailed operational procedures belong in #130; #129 focuses on the deployment execution path.

## Standalone and composition role

```yaml
standalone_goal: produce deployment guides with pipeline stages, canary config, smoke tests, RTO-sorted rollback, and hotfix procedures
minimum_viable_input:
  any_of:
    - 发布任务编排或环境说明
    - 部署流水线定义或 GitOps 配置
    - 回滚预案或 canary 策略
    - 上游 N090 非功能或发布要求
    - 若已有 N270/N280 产物，优先复用其 phase、gate、rollback 信息
partial_readiness_allowed: true
degradation_behavior: >
  If inputs are sparse, output a skeleton with all 10 sections present.
  Section 3 (deploy phases): minimum 1 phase with placeholder steps.
  Section 8 (smoke tests): minimum 3 entries with "ST-00x: 待补充" placeholders.
  Section 6 (rollback): minimum 1 option even if RTO is estimated — state estimation basis.
  Do not hard-code specific percentages (5%/25%/100%) as templates; parameterize them.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `pipeline_aligned`: 有完整流水线定义，按 pipeline 阶段映射。
- `gitops_aligned`: 基于 GitOps/ArgoCD 等声明式部署，重点描述 Git 触发与健康检查。
- `release_orchestration_fallback`: 只有发布流程文档，没有自动化工具描述。
- `rollback_first`: 优先输出回滚手册，部署 phase 次之。
- **`hotfix_deployment`**: 专用于紧急热修发版，输出压缩版部署步骤 + 热修专属风险检查清单，跳过非必要 canary 阶段，但保留强制 smoke test（≥3 条）和 RTO ≤10min 回滚选项（标注估算依据）。

**Default routing**: CI/CD pipeline available → `pipeline_aligned`. GitOps infra → `gitops_aligned`. Emergency release → `hotfix_deployment`. Rollback is priority concern → `rollback_first`.

Standalone rule: parameterize deployment phases and rollback paths first; then fill in project-specific values. Do not write `5% → 25% → 100%` as if it were the only valid canary template.

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | 部署范围与读者 | Always | State target env and audience |
| 2 | 环境与前置条件 | Always | "前置条件待确认" + open_blocker if missing |
| 3 | 部署 phase 清单 | Always | Min 1 phase with steps |
| 4 | Canary stages | Conditional (when pipeline or canary evidence present) | Use `{CANARY_STAGES}` placeholder if absent |
| 5 | Gate/verification rules | Always | "验证规则待补充" if missing |
| 6 | RTO-sorted rollback options | Always | Min 1 rollback option with `rto_estimate` + `rto_estimate_method` |
| 7 | 失败处理与升级路径 | Always | "升级联系人待确认" if missing |
| 8 | Smoke test 清单 | **Always — never omit** | Min 3 entries; `ST-00x: 待补充` allowed; hotfix: min 3 compressed entries |
| 9 | Cross-links | Always | Reference #127 service topology, #130 smoke_test_ids handoff |
| 10 | 缺失与待确认 | Always | All open_blockers here |

> Legend: Always = required in every mode; Conditional = required when evidence triggers it.

**RTO 规则**: 每个回滚选项必须包含 `rto_estimate`（预计时间）和 `rto_estimate_method`（估算依据：历史回滚记录/演练结果/理论估算）。`hotfix_deployment` 模式必须有 ≤10min 选项。

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** Smoke test 节省略 → Section 8 是**永远必填节**；hotfix 模式允许压缩至 3 条但不可删除。量化检验：至少出现 3 条以 `ST-` 开头的条目，hotfix 模式最低 3 条，否则视为违例。
- **AP-2** 回滚选项无 RTO 估算依据 → 每个回滚选项必须同时包含 `rto_estimate`（时间）和 `rto_estimate_method`（依据来源：历史回滚记录 / 演练结果 / 理论估算）；"尽快"和空值均为无效值。量化检验：回滚选项中 rto_estimate 为空或 rto_estimate_method 为空的条目数 = FAIL 数。
- **AP-3** Canary 百分比（如 5%→25%→100%）写死在模板中 → 必须参数化为 `{CANARY_STAGE_1}`、`{CANARY_STAGE_2}` 等占位符；项目实际百分比在 Section 4 填入，禁止把任何具体数字硬编码为"标准"比例。量化检验：模板中出现具体 Canary 百分比数字（5%/25%/100% 等）而非 `{CANARY_STAGE_N}` 占位符的处数 = FAIL 数。
- **AP-4** `hotfix_deployment` 模式无 ≤10min 回滚选项 → 该模式强制要求至少一个 RTO ≤10min 的回滚路径；若当前架构不支持，必须在 open_blockers 中显式标注风险并上报发版 owner。量化检验：hotfix_deployment 模式下，rto_estimate ≤ 10min 的回滚选项数必须 ≥ 1；否则 open_blockers 中必须有对应风险声明。
- **AP-5** Gate / verification rules 节留空或写"待确认" → 每个部署 phase 必须对应至少一条可执行的验证规则（如"等待 canary 错误率低于 0.1% 持续 5 分钟"）；"待确认"作为 open_blocker 列入 Section 10，不可直接留在 gate 节中。量化检验：Gate/verification rules 节中出现"待确认"字符串且无对应 open_blocker 记录的处数 = FAIL 数。
- **AP-6** breaking change 场景未设置客户端迁移验证 gate → 当 #126 传入 breaking_change_signals 时，Section 5 必须包含客户端版本检查或兼容性验证步骤，防止旧客户端在不感知的情况下命中 breaking API。量化检验：breaking_change_signals 传入时，Section 5 中缺少客户端版本检查或兼容性验证步骤的次数 = FAIL 数。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n330-shared-doc-suite-contract.md` — shared contract, doc_id format, cross-link rules
- `references/n330-document-family-crosslinks.md` — cross-link structure between #125–#130
- `references/n330-composition-guide.md` — composition guide
- `references/n330-input-validation-rules.md` — when input quality is uncertain
- `references/rollback-decision-rules.md` — when building RTO-sorted rollback options
- `references/smoke-test-template.md` — smoke test entry format and minimum requirements
- `references/deployment-parameterization.md` — how to parameterize phases and canary stages
- `references/id-linkage-guide.md` — when linking to upstream IDs
- `references/deployment-documentation-generation-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/family-aligned-deployment-documentation.md` — pipeline_aligned mode with canary + rollback
- `examples/hotfix-deployment-mode.md` — hotfix_deployment with compressed steps and ≤10min rollback
- `examples/rollback-first-mode.md` — rollback_first with RTO-sorted options

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: maintenance-manual-generation
  doc_id: DEPLOY-DOC-*-001
  smoke_test_ids: [ST-001, ST-002, ST-003]
  alerts_to_monitor: ["payment-service latency > 500ms", "error rate > 0.1%"]
  breaking_change_gates: [API-003]
  open_blockers: ["RTO estimate for rollback-option-2 unverified"]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all phases, gates, smoke tests, and rollback options documented) / `partial` (some phases or smoke tests pending) / `degraded` (phase skeleton only; no gates or rollback options — must not be used to execute a production deployment).

## Workflow position

```
Pipeline definitions / GitOps configs / rollback plans / breaking change signals from #126
  ↓ #129 (deployment guide → 部署说明.md)
  → #130 receives smoke_test_ids and alerts_to_monitor
```
