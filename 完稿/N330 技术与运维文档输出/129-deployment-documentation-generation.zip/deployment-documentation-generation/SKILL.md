---
name: deployment-documentation-generation
description: generate deployment documentation for the n330 technical and operations documentation node. use when ChatGPT needs to turn release orchestration, environment constraints, rollback options, and operating assumptions into a deployment guide with configurable canary stages, rto-sorted rollback paths, and explicit phase-to-gate links.
---

# 部署文档生成

## Role
作为 N330 文档家族中的部署说明生成器，产出供 SRE、发布经理、值班人员消费的部署文档。默认强调参数化阶段与回滚路径，而不是把某一个项目的 `3-stage canary` 或 `4-step rollback` 写死成唯一模板。

## Selected mode
- `pipeline_aligned`
- `gitops_aligned`
- `release_orchestration_fallback`
- `rollback_first`

## Primary inputs
- 发布任务编排、环境说明、部署流水线、回滚预案、canary 策略
- 上游 N090 非功能或发布要求
- 若已有 N270 / N280 产物，优先复用其 phase、gate、rollback 信息

## Standalone rule
单独使用时也必须先参数化阶段和回滚路径，再填当前项目值，不能直接把 `5% → 25% → 100%` 当成模板本身。

## Core output contract
1. 部署范围与读者
2. 环境与前置条件
3. 部署 phase 清单
4. `{CANARY_STAGES}` 与推进规则
5. gate / verification 规则
6. `RTO-sorted rollback options`
7. 失败处理与升级路径
8. cross-links
9. 缺失与待确认

rollback 部分至少给出：
- `rollback_option_id`
- `trigger_condition`
- `estimated_rto`
- `prerequisites`
- `data_impact`
- `owner_role`

## Design rules
- canary 阶段数必须可配置；阶段数、百分比、时长都属于当前项目填充值。
- rollback 路径按 RTO 排序，而不是固定 phase 数。
- 若存在 gate 判定，必须写出 phase 与 gate 的对应关系。
- 文档不负责发版决策，只负责把部署执行方式写清楚。

## Execution workflow
1. 收集环境、phase、gate、rollback、verification 五类信息。
2. 先参数化，再填当前项目具体值。
3. 输出部署 phase 与验证点。
4. 输出按 RTO 排序的回滚路径。
5. 回链到维护手册、发布文档与相关模块/API 文档。

## Dynamic completeness
- 只有粗粒度流程时：先给部署骨架与待确认参数，不伪造每个 phase 细节。
- 只有 rollback 方案、没有完整部署 phase 时：允许优先输出 rollback-first 版本。

## Standalone use cases
- 发布流水线文档
- 蓝绿 / 金丝雀 SOP
- 灰度与回滚 runbook
- GitOps 发布说明

## Quality bar
- 是否把阶段数与回滚数参数化
- 是否给出 phase-to-gate 链接
- 是否给出 RTO 排序的回滚列表
- 是否可被发布、运维和值班共同消费

## References
- `references/deployment-parameterization.md`
- `references/n330-document-family-crosslinks.md`

## N330 v1.2.0 contract baseline
Contract version: `n330-doc-suite-v1.2.0`.

This skill is self-contained. Standalone execution and multi-skill composition rely only on files packaged inside this skill plus artifacts exchanged through `cross_doc_refs` and `downstream_handoff`. Do not require outside-package shared directories, outside-package tools, external matrices, or hidden registries.

## Standalone and composition role
```yaml
standalone_contract:
  minimum_viable_input: deployment process, release orchestration notes, environment constraints, rollback plan, or canary strategy
  partial_readiness_allowed: true
  degradation_behavior:
    - keep required sections stable even when evidence is partial
    - mark gaps in metadata.open_blockers
    - put temporary IDs in metadata.pending_id_backfill
composition_contract:
  composition_role: deployment_execution_guide
  join_keys:
    - doc_family_id
    - doc_id
    - scope.project_id
    - scope.release_id
    - scope.service_scope
    - scope.module_scope
    - upstream_id_aliases
    - cross_doc_refs
  best_combines_with: ['127', '126', '128', '130']
  consumes: ['module-design-document-generation', 'api-documentation-generation', 'data-dictionary-generation']
  produces_for: ['maintenance-manual-generation', 'N340', 'N350']
  strengthens: turns module/API dependencies into deployment phases, gates, and rollback paths for release and operations users
```

## Required metadata and handoff
Every output must start with a `metadata` YAML block that follows `references/n330-shared-doc-suite-contract.md`. Every output must also end with a `downstream_handoff` block containing `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `doc_id`, `cross_doc_refs`, `pending_id_backfill`, `readiness`, `confidence`, and `next_best_checks`.

## N330 references
- Always use `references/n330-shared-doc-suite-contract.md` for metadata, join keys, handoff, standalone, and composition rules.
- Use `references/output-contract.yaml` for this skill's required sections and machine-readable contract.
- Use `references/deployment-documentation-generation-quality-checklist.md` before finalizing the artifact.
- Use `examples/family-aligned-deployment-documentation.md` as the closest style and structure reference.
- Use `references/id-linkage-guide.md` when aligning upstream IDs.
- Use `references/n330-document-family-crosslinks.md` when linking sibling N330 documents.

