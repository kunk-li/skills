# Example: Deployment Documentation — Hotfix Deployment Mode

Demonstrates `hotfix_deployment` mode for a P1 payment service fix. Smoke tests are compressed but never omitted.

```yaml
metadata:
  contract_version: n330-doc-suite-v1.2.1
  skill_id: "129"
  selected_mode: hotfix_deployment
  doc_id: DOC-129-PAY-HOTFIX-2025-0612
  doc_family_id: n330-rd-doc-suite
  readiness: complete
  open_blockers: []
```

## 部署范围与读者

**服务**: payment-service v2.3.1 → v2.3.2 (hotfix)  
**触发原因**: BUG-441 P1 — 购物车 >512 条时返回 500 而非 200+限制提示  
**读者**: on-call-sre, backend-lead  
**适用环境**: production  
**预计窗口**: 2025-06-12 23:00–23:30 JST（低流量窗口）

## 前置条件（Hotfix 风险核查）

| 核查项 | 状态 | 说明 |
|--------|------|------|
| 是否需要 DB 迁移？ | **否** | 仅修改应用层逻辑，无 DDL 变更 |
| 是否影响线上活跃会话？ | **否** | 无状态服务，Pod 重启不影响进行中请求（已有超时重试） |
| 是否有配置变更？ | 是 | `cart.max_items_limit=512` 需在发布前写入 ConfigMap |
| 是否需要缓存预热？ | **否** | BUG 不涉及缓存路径 |
| 回滚可行性？ | ✓ | v2.3.1 镜像保留，RTO 5min |

## 部署 Phase 清单（Hotfix 精简版）

| Phase | 步骤 | 验证点 |
|-------|------|--------|
| 1. 配置写入 | `kubectl apply -f configmap-cart-limit.yaml` | `kubectl get configmap cart-config -o yaml` 确认值 |
| 2. 镜像推送 | CI/CD push v2.3.2 到 registry | 镜像 digest 记录 |
| 3. 滚动更新 | `kubectl set image deploy/payment-service payment=v2.3.2` | Pod 全部 Running 状态 |
| 4. Smoke test | 执行 ST-001/002/003 | 全部通过后视为部署成功 |

> 注：Hotfix 模式跳过非必要 canary 阶段；完整 canary（5%→25%→100%）在下次常规发版中恢复。

## Smoke Test 清单（Hotfix 全部 blocking:yes）

| test_id | description | expected_result | timeout_seconds | blocking |
|---------|-------------|-----------------|-----------------|----------|
| ST-001 | GET /health → 服务健康检查 | HTTP 200, status: ok | 3 | **yes** |
| ST-002 | POST /cart/add 第 513 条商品 → 边界验证 | HTTP 200, body: {limited: true, current_count: 512} | 5 | **yes** |
| ST-003 | POST /checkout → 正常结账流程 | HTTP 201, order_id present, no 500 error | 8 | **yes** |

**回滚触发条件**: 任何 ST-00x 测试在 5 分钟内失败 → 立即执行 RB-001

## RTO-sorted Rollback Options

| option_id | 触发条件 | 操作 | estimated_rto | data_impact | owner_role |
|-----------|---------|------|--------------|------------|------------|
| RB-001 | ST-001/002/003 失败 | `kubectl set image deploy/payment-service payment=v2.3.1` | 5min | 无 | on-call-sre |

## 失败处理与升级路径

- ST 失败立即执行 RB-001
- 若回滚后问题仍存在 → 升级至 backend-lead + ENG-lead
- 联系人: on-call-sre (PagerDuty) → backend-lead (Slack #incidents)

## Cross-links

| doc_id | 关系 |
|--------|------|
| DOC-126-PAY | API 文档（POST /cart/add 接口规范）|
| INC-2025-0612-CART | 触发本 hotfix 的 incident |

## 缺失与待确认

无 open_blockers — hotfix 范围明确，核查项已全部确认。

```yaml
downstream_handoff:
  handoff_id: DEPLOY-HOTFIX-2025-0612
  producer_skill: deployment-documentation-generation
  consumer_skill_or_node: maintenance-manual-generation|incident-postmortem
  cross_doc_refs: [DOC-126-PAY]
  readiness: complete
  confidence: high
  next_best_checks:
    - "监控 P95 延迟 24h 无异常后关闭 incident"
    - "下次常规发版恢复完整 canary 阶段"
```
