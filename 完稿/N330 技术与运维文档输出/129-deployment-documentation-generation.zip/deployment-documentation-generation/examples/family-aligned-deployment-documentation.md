metadata:
  contract_version: n330-doc-suite-v1.2.0
  workflow_node: N330
  skill_id: 129
  skill_name: deployment-documentation-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-129-claims-01
  selected_mode: pipeline_aligned
  readiness: ready
  scope:
    project_id: claims-modernization
    release_id: REL-2026-claims-01
    service_scope: [claims-api, claims-worker]
    module_scope: [claims]
  source_artifacts: [architecture-brief.md, api-inventory.md, ddl.sql, release-plan.md]
  upstream_id_aliases: [FT-claims-01-01, BE-claims-01, API-claims-01, FLD-claims-P01-01, PRD-07]
  cross_doc_refs: [DOC-127-claims-01, DOC-126-claims-01, DOC-128-claims-01, DOC-130-claims-01]
  pending_id_backfill: []
  freshness:
    as_of_date: 2026-05-07
    source_commit: abc1234
    expected_review_window: after every minor release
  open_blockers: []
  owner_placeholders: [claims-service-owner, platform-release-team]
  confidence: high
  composition_role: deployment_execution_guide
  stage_position: documentation_family.technical_docs.example
  node_artifact_target: deployment-documentation.md

# Deployment Documentation Example

## Deployment scope and reader
This document guides release engineers deploying claims modernization for REL-2026-claims-01.

## Deployment phase inventory
| phase | target | gate | evidence |
|---|---|---|---|
| build | claims-api, claims-worker | tests green | CI build |
| canary | 5% traffic | error rate within SLO | dashboard |
| ramp | 50% then 100% | p95 and queue depth stable | monitoring |

## RTO sorted rollback options
| option | estimated RTO | prerequisite | data impact |
|---|---|---|---|
| disable claims-worker consumer | 5 minutes | queue pause allowed | no data loss |
| rollback claims-api image | 15 minutes | compatible schema | no data loss |
| restore previous schema | 60+ minutes | DBA approval | potential write freeze |

## Cross links
- Service dependency baseline: DOC-127-claims-01
- API inventory: DOC-126-claims-01
- Operator guide: DOC-130-claims-01

downstream_handoff:
  contract_version: n330-doc-suite-v1.2.0
  handoff_id: HO-N330-REL-2026-claims-01-129
  producer_skill: deployment-documentation-generation
  consumer_skill_or_node: maintenance-manual-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-129-claims-01
  release_id: REL-2026-claims-01
  required_fields: [doc_id, scope, upstream_id_aliases, cross_doc_refs]
  cross_doc_refs: ['DOC-127-claims-01', 'DOC-126-claims-01', 'DOC-128-claims-01', 'DOC-130-claims-01']
  pending_id_backfill: []
  readiness: ready
  confidence: high
  next_best_checks: []
