# Example: Deployment Documentation — Rollback-First Mode

Demonstrates `rollback_first` mode: rollback documentation is the primary deliverable (hotfix scenario where full deployment guide already exists).

```yaml
metadata:
  skill_id: "129"
  selected_mode: rollback_first
  artifact_id: DOC-129-PAY-ROLLBACK-V2-HOTFIX
  contract_version: n330-doc-suite-v1.2.1
  doc_id: DOC-129-PAY-ROLLBACK-V2
  readiness: complete
  cross_doc_refs:
    - doc_id: DOC-129-PAY-V2
      relationship: primary_deployment_guide
```

## Rollback Options (RTO-sorted)

| option_id | type | trigger_condition | operation | rto | data_impact | owner_role |
|-----------|------|-------------------|-----------|-----|-------------|-----------|
| RB-001 | feature_flag_off | P1 error rate > 0.5% | `launchdarkly set payments-v2-enabled false` | 2 min | none | on-call SRE |
| RB-002 | image_rollback | Feature flag unavailable OR P0 data corruption | `kubectl rollout undo deploy/payments-service` | 8 min | low (in-flight requests may fail) | on-call SRE + ENG-lead |
| RB-003 | db_migration_rollback | Schema migration caused data errors | Run `scripts/rollback_v2_migration.sql` — requires DBA | 45 min | **high** (potential data loss for v2-format records) | DBA + ENG-lead |

## Smoke Tests (minimal set for rollback verification)

| test_id | command | expected | blocking |
|---------|---------|----------|---------|
| ST-RB-001 | `curl /health` | HTTP 200 | yes |
| ST-RB-002 | `curl /payments/charge -d test_payload` | HTTP 200, no 500 | yes |
| ST-RB-003 | Check error rate in Datadog | < 0.1% for 5 min | yes |

## Downstream Handoff

```yaml
handoff_id: DOC-129-PAY-ROLLBACK-HANDOFF
producer_skill: deployment-documentation-generation
consumer_skill_or_node: maintenance-manual-generation
cross_doc_refs:
  - doc_id: DOC-130-PAY
    relationship: maintenance_context
rollback_option_ids: [RB-001, RB-002, RB-003]
high_risk_options: [RB-003]
readiness: complete
confidence: high
next_best_checks:
  - "#130: add RB-003 as a scenario card for DBA escalation path"
  - "Alert on-call if RB-001 is triggered — escalate to RB-002 if error rate persists"
```
