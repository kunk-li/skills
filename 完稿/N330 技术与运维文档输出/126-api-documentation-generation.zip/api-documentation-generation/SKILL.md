---
name: api-documentation-generation
description: 生成接口文档（接口契约）用于 n330 技术与运维文档输出。triggered when you need to produce or update api contracts covering endpoints, breaking changes, idempotency policies, and versioning. use breaking_change_audit mode when preparing a version upgrade. do not use for module boundary definitions (→ #127), data field details (→ #128), deployment steps (→ #129), or developer entry-point aggregation (→ #125).
---

# 接口文档生成

## N330 contract baseline (n330-doc-suite-v1.2.1)

- contract_version: `n330-doc-suite-v1.2.1`
- workflow node: N330
- skill_id: 126
- primary artifact: `接口文档.md`
- family role: API contract source; feeds #129 (breaking change signal) and #125 (API index)
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through `doc_id` cross-links; reference #127 for service boundaries.

> **N330 skill boundary summary** — see `references/n330-shared-doc-suite-contract.md` for full boundary matrix:
> #125 aggregates · #126 API contracts · #127 module boundaries · #128 data fields · #129 deployment · #130 ops manual

## Role

作为 N330 文档家族中的**接口契约文档生成器**，产出面向联调、集成、测试和客户端的 API 文档。

具体职责：
- 为每个端点生成完整 API 索引表（含 `breaking_change` 列）
- 标注所有 POST 端点的幂等性策略（`tbd` 自动触发 open_blocker）
- 维护变更历史与废弃通知节（永不省略）
- 为 #129 提供 breaking change 信号，为 #125 提供 API 索引

**不负责**：服务边界设计（→ #127）、数据字段详情（→ #128）、部署排序（→ #129）、开发者入口（→ #125）。

## When NOT to use this skill

- **Not a module design document**: if the primary question is about service boundaries and dependencies, use #127 first; #126 documents the API contracts that emerge from those boundaries.
- **Not a data dictionary**: field-level type and constraint details belong in #128; #126 references data objects by FLD-* ID.
- **Not a deployment guide**: API versioning and deprecation timelines are documented here; deployment rollout strategy belongs in #129.
- **Not a test plan**: #126 documents the API contract (what to test); test cases and regression scope belong elsewhere.

## Standalone and composition role

```yaml
standalone_goal: produce or update API contracts with endpoints, breaking change flags, idempotency policies, and versioning
minimum_viable_input:
  any_of:
    - 接口设计草案或 controller/service 草稿
    - OpenAPI 片段或 Swagger 定义
    - DTO / VO / validator / exception 类定义
    - 错误码定义或 i18n 模板
    - 上游 N080 API-* 或 N090 PRD-XX
partial_readiness_allowed: true
degradation_behavior: >
  If inputs are sparse, output a skeleton API index table with known endpoints.
  Mark idempotency as unknown for all POST endpoints (triggering open_blocker).
  State explicitly that output has not reached machine-readable OpenAPI level.
  Document granularity decision (api_level / module_level) before producing any content.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `api_level`: 关键接口逐个成文。
- `module_level`: 按业务模块分组。
- `hybrid`: 对外接口逐个成文，对内辅助接口按模块分组。
- `controller_fallback`: 只有 controller 或路由定义时，从代码反推。
- **`breaking_change_audit`**: 专用于版本升级场景，要求每个接口标注 `breaking_change: yes/no`，并给出迁移路径或废弃时间线。

**Default routing**: integration or release prep → `api_level`. Version upgrade → `breaking_change_audit`. Code-first reverse → `controller_fallback`.

Standalone rule: explicitly declare granularity level before producing output — do not produce a document that blends endpoint-level and module-level without a stated policy.

## Primary inputs

- 接口设计草案、controller/service 草稿、OpenAPI 片段、错误码定义
- 上游 N080 `API-*`、`BE-*`; 上游 N090 `PRD-XX`
- DTO / VO / validator / exception 类定义

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | 文档范围与粒度策略 | Always | Explicitly state api_level / module_level / hybrid |
| 2 | API 索引表 | Always | Must include `API-*` or temp ID + `breaking_change` column |
| 3 | 认证、鉴权、幂等、限流约定 | Always | POST endpoints: idempotency must be explicit or marked `unknown` |
| 4 | 请求参数与 schema | Always | Reference FLD-* IDs from #128 where available |
| 5 | 响应 schema 与状态码 | Always | — |
| 6 | 错误码与 i18n 模板 | Always | At least placeholder i18n keys |
| 7 | 版本与兼容性说明 | Always | — |
| 8 | 变更历史与废弃通知 | **Always — never omit** | Deprecated endpoints + replacement path; new endpoints with first-introduced version |
| 9 | Cross-links | Always | Reference #127 for service boundary, #128 for field detail |
| 10 | 缺失与待确认 | Always | All open_blockers here |

> Legend: Always = required in every mode.

**API 索引表必填字段**: `api_id` · `module` · `method` · `path` · `operation_summary` · `breaking_change` (yes/no/tbd) · `related_prd_sections` · `related_feature_ids`

**幂等性标注规则**: 所有 POST 接口必须显式标注幂等策略（幂等键、重试安全性）。不确定时标注 `idempotency: unknown` 并列为 open_blocker。

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** 未声明文档粒度就混用接口级和模块级描述 → 必须在 Section 1 显式声明粒度策略。量化检验：Section 1 中必须出现 `api_level`/`module_level`/`hybrid` 之一；缺失时 FAIL。
- **AP-2** POST 接口未标注幂等性 → 必须给出幂等键或标注 `unknown`；`tbd` 自动触发 open_blocker。量化检验：API 索引表中 method=POST 的行里，idempotency 字段缺失或为空的行数 = open_blocker 数。
- **AP-3** 变更历史节省略或为空 → Section 8 是永远必填节；最小可输出"首版，无废弃接口"。量化检验：Section 8（变更历史）字符数 < 5 视为违例；整节缺失时 FAIL。
- **AP-4** `breaking_change_audit` 模式下未给出迁移路径 → 每个 `breaking_change: yes` 条目必须有迁移指引或废弃时间线。量化检验：breaking_change_audit 模式下，`breaking_change: yes` 条目数必须 = 同一节内 migration_path/deprecation_timeline 说明数。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n330-shared-doc-suite-contract.md` — shared contract, doc_id format, cross-link rules
- `references/n330-document-family-crosslinks.md` — cross-link structure between #125–#130
- `references/n330-composition-guide.md` — composition guide
- `references/n330-input-validation-rules.md` — when input quality is uncertain
- `references/breaking-change-audit-rules.md` — when using breaking_change_audit mode
- `references/api-granularity-rules.md` — when deciding granularity level
- `references/openapi-3.1-example.md` — OpenAPI 3.1 reference structure
- `references/errors-i18n-template.md` — error code i18n template
- `references/id-linkage-guide.md` — when linking to upstream API-*, FLD-*, PRD-XX IDs
- `references/api-documentation-generation-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/family-aligned-api-documentation.md` — api_level mode with #127/#128 cross-links
- `examples/breaking-change-audit-mode.md` — breaking_change_audit with migration paths
- `examples/breaking-change-audit-sparse-input.md` — breaking_change_audit with incomplete input degradation

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: deployment-documentation-generation / development-documentation-generation
  doc_id: API-DOC-*-001
  breaking_change_signals: [API-003, API-007]
  open_blockers: ["idempotency unknown for POST /orders", "deprecation timeline unconfirmed"]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all endpoints documented, change history complete) / `partial` (some endpoints skeleton) / `degraded` (index table only; schemas not yet populated — downstream consumers must not use as integration reference).

## Workflow position

```
Controller / service drafts / OpenAPI fragments / error code definitions
  ↓ #126 (API contracts → 接口文档.md)
  → #129 receives breaking_change signals
  → #125 receives API index (doc_id cross-links)
```
