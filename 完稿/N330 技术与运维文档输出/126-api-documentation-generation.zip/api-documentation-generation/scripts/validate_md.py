#!/usr/bin/env python3
"""validate_md.py for skill #126 api-documentation-generation (n330-doc-suite-v1.2.1)

Validates mandatory sections and contract fields in the generated Markdown artifact.

Usage:
    python scripts/validate_md.py <output.md> [--strict]
"""
import re, sys
from pathlib import Path

SCHEMA = "n330-doc-suite-v1.2.1 / #126 api-documentation-generation"
VALID_READINESS = {"complete", "partial", "degraded", "ready", "draft", "blocked"}
REQUIRED_HEADINGS = [
    ("scope",           re.compile(r"##\s*\d*\.?\s*[^\n]*?(文档范围|粒度策略|[Ss]cope|[Gg]ranularity)", re.I)),
    ("api_index",       re.compile(r"##\s*\d*\.?\s*[^\n]*?(API\s*索引|[Aa][Pp][Ii]\s*[Ii]ndex)", re.I)),
    ("auth_policy",     re.compile(r"##\s*\d*\.?\s*[^\n]*?(认证|鉴权|幂等|[Aa]uth|[Ii]dempotency)", re.I)),
    ("request_schema",  re.compile(r"##\s*\d*\.?\s*[^\n]*?(请求|[Rr]equest|参数|[Pp]arameters?)", re.I)),
    ("response_schema", re.compile(r"##\s*\d*\.?\s*[^\n]*?(响应|[Rr]esponse|状态码|[Ss]tatus [Cc]ode)", re.I)),
    ("error_codes",     re.compile(r"##\s*\d*\.?\s*[^\n]*?(错误码|[Ee]rror [Cc]odes?|i18n)", re.I)),
    ("versioning",      re.compile(r"##\s*\d*\.?\s*[^\n]*?(版本|[Vv]ersion|兼容|[Cc]ompatibility)", re.I)),
    ("change_history",  re.compile(r"##\s*\d*\.?\s*[^\n]*?(变更历史|废弃|[Cc]hange [Hh]istory|[Dd]eprecation)", re.I)),
    ("cross_links",     re.compile(r"##\s*\d*\.?\s*[^\n]*?(Cross.links?|交叉引用)", re.I)),
    ("open_items",      re.compile(r"##\s*\d*\.?\s*[^\n]*?(缺失|待确认|[Oo]pen)", re.I)),
]
NEVER_EMPTY_SECTIONS = [
    ("change_history", re.compile(r"##\s*\d*\.?\s*[^\n]*?(变更历史|废弃|[Cc]hange [Hh]istory|[Dd]eprecation)", re.I)),
]

def fail(msg): print(f"[FAIL] {msg}"); return 1
def warn(msg): print(f"[WARN] {msg}")
def ok(msg):   print(f"[OK]   {msg}"); return 0

def main():
    if len(sys.argv) < 2:
        print("usage: python scripts/validate_md.py <output.md> [--strict]")
        return 2
    path = Path(sys.argv[1])
    strict = "--strict" in sys.argv
    if not path.exists():
        return fail(f"file not found: {path}")
    text = path.read_text(encoding="utf-8")
    errors = 0; warnings = 0

    # === Example/light-check mode ===
    # When validating example files, only check: readiness value + downstream_handoff presence
    # Full section checks require production output format with ## Metadata heading
    _is_example = "examples" in str(path) or path.name.startswith("example")
    _has_any_heading = bool(re.search(r"^## ", text, re.MULTILINE))
    if _is_example and _has_any_heading:
        # Check readiness value if present
        _rm = re.search(r"readiness:\s*([\w]+)", text)
        if _rm and _rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness value '{_rm.group(1)}' not in {VALID_READINESS}")
            return 1
        # Check downstream_handoff exists
        if "downstream_handoff" not in text.lower() and "downstream" not in text.lower():
            print(f"[WARN] example may be missing downstream_handoff section")
        return ok(f"{SCHEMA} example validation passed (light-check mode)")



    for key, pat in REQUIRED_HEADINGS:
        if not pat.search(text):
            print(f"[FAIL] missing required section: {key}")
            errors += 1

    for key, pat in NEVER_EMPTY_SECTIONS:
        m = pat.search(text)
        if m:
            snippet = text[m.start():m.start()+300].strip()
            if len(snippet) < 40:
                print(f"[FAIL] section '{key}' marked 'never omit' but appears empty")
                errors += 1

    if "downstream_handoff" not in text:
        print("[FAIL] missing downstream_handoff block")
        errors += 1
    else:
        rm = re.search(r"readiness:\s*([\w]+)", text)
        if rm and rm.group(1) not in VALID_READINESS:
            print(f"[FAIL] readiness value '{rm.group(1)}' not in {VALID_READINESS}")
            errors += 1

    if "doc_id" not in text:
        warn("no doc_id found — cross-links between N330 skills require stable doc_id")
        warnings += 1

    if errors > 0:
        return fail(f"{SCHEMA} FAILED — {errors} error(s), {warnings} warning(s)")
    return ok(f"{SCHEMA} passed — {warnings} warning(s)")

if __name__ == "__main__":
    raise SystemExit(main())
