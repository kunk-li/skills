# Breaking Change Audit Rules

Use this reference when `breaking_change_audit` mode is selected, or during any version upgrade that changes API contracts.

## Definition of breaking change
A change is **breaking** if it can cause existing clients to fail without modification:
- Removing a field from a response
- Renaming a field or parameter
- Changing a field's type (e.g., `string` → `int`)
- Changing an HTTP method (e.g., `GET` → `POST`)
- Removing or renaming an endpoint
- Changing authentication requirements
- Making a previously optional parameter required
- Changing error code structure or HTTP status semantics

A change is **non-breaking** if backward-compatible:
- Adding an optional field to a response
- Adding a new optional parameter
- Adding a new endpoint
- Loosening validation rules

## `breaking_change` field values
- `yes`: confirmed breaking change — migration path required
- `no`: confirmed non-breaking — no client action needed
- `tbd`: cannot be determined without further review — flag as `open_blocker`

## Required content when `breaking_change: yes`
Every breaking change entry must include:
```yaml
breaking_change: yes
migration_path: "Replace field X with field Y; X will be removed in v3.0"
deprecated_after: "2025-Q3"  # or specific date
breaking_change_type: field_removal | rename | type_change | endpoint_removal | auth_change | other
client_impact: "All clients using X must update to Y before the deprecated_after date"
```

## Changelog section format
```markdown
## 变更历史与废弃通知

### v2.1 → v2.2 (current)
| api_id | change_type | breaking | migration | deprecated_after |
|--------|-------------|---------|-----------|-----------------|
| API-PAY-003 | field_removal | YES | Use `order_ref` instead of `legacy_id` | 2025-Q3 |
| API-PAY-004 | new_endpoint | NO | — | — |

### Deprecated endpoints (still active, scheduled for removal)
| api_id | path | deprecated_since | removal_date | replacement |
|--------|------|-----------------|--------------|-------------|
| API-PAY-001 | POST /v1/pay | v2.0 | 2025-12-01 | POST /v2/payments |
```

## Idempotency annotation rules
All POST endpoints must declare one of:
- `idempotency: key_based` — client supplies idempotency key; include key field name
- `idempotency: natural` — operation is naturally idempotent (e.g., PUT with full resource)
- `idempotency: none` — not idempotent; warn clients against retry without deduplication
- `idempotency: unknown` — cannot determine without further review; flag as `open_blocker`

Never leave idempotency undeclared on a POST endpoint.
