# N330 Api Documentation Quality Checklist

Use this checklist before finalizing `api-documentation.md`. The skill is standalone, so all required checks must be answerable from files packaged in this skill and the user-provided inputs.

1. Metadata follows `references/n330-shared-doc-suite-contract.md` and includes all required fields.
2. `selected_mode` matches both the user request and the produced document body.
3. `doc_id` follows `DOC-{skill_id}-{project_id}-{nn}`; any fallback `DOC-{skill_id}-TEMP-{date}-{source}` appears in `pending_id_backfill`.
4. `upstream_id_aliases` preserves upstream IDs exactly; uncertain IDs are marked `TEMP-*` or `to_confirm` rather than invented.
5. `cross_doc_refs` use sibling `doc_id` values, not file paths; missing sibling documents are explicit stubs in `open_blockers`.
6. Verify API granularity is declared and every endpoint row has request schema, response schema, status codes, errors, and upstream API-* aliases or TEMP-API-* backfill.
7. `source_artifacts` and `freshness` identify the evidence base, including `as_of_date`, `source_commit`, or explicit `unknown`.
8. `open_blockers` names unresolved gaps and their next best checks.
9. `owner_placeholders` use role/team names only; do not use personal blame or hard-coded individual ownership.
10. `downstream_handoff` includes `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `required_fields`, `readiness`, `confidence`, and `next_best_checks`.
11. Compare the produced API documentation's metadata key order, field naming, cross-link style, and section structure against the closest file under `examples/`. Differences are allowed but should be intentional.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- `breaking_change_audit` mode: every endpoint row has `breaking_change` field; `tbd` is valid but triggers open_blocker.
- All POST endpoints have `idempotency` declared; `unknown` is valid but triggers open_blocker.
- `变更历史与废弃通知` section always present; if no changes: "本版本无接口变更".

## Output structure completeness checks
- API index table has `breaking_change` column populated for every row
- All POST endpoints in idempotency table (even if `tbd`)
- 变更历史 section present; "本版本无接口变更" if nothing changed
- downstream_handoff has `breaking_changes` list

## Mode-specific checks

### breaking_change_audit mode
- Breaking change 详情 section present for every `breaking_change: yes` entry
- `migration_path` field present in every breaking change entry
- `client_impact` explicitly stated
