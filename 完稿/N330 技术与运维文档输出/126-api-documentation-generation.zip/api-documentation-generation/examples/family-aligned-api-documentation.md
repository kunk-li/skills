metadata:
  contract_version: n330-doc-suite-v1.2.1
  workflow_node: N330
  skill_id: 126
  skill_name: api-documentation-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-126-claims-01
  selected_mode: hybrid
  readiness: ready
  scope:
    project_id: claims-modernization
    release_id: REL-2026-claims-01
    service_scope: [claims-api, claims-worker]
    module_scope: [claims]
  source_artifacts: [architecture-brief.md, api-inventory.md, ddl.sql, release-plan.md]
  upstream_id_aliases: [FT-claims-01-01, BE-claims-01, API-claims-01, FLD-claims-P01-01, PRD-07]
  cross_doc_refs: [DOC-127-claims-01, DOC-128-claims-01]
  pending_id_backfill: []
  freshness:
    as_of_date: 2026-05-07
    source_commit: abc1234
    expected_review_window: after every minor release
  open_blockers: []
  owner_placeholders: [claims-service-owner, platform-release-team]
  confidence: high
  composition_role: api_contract_owner
  stage_position: documentation_family.technical_docs.example
  node_artifact_target: api-documentation.md

# API Documentation Example

## Scope and granularity
Selected mode is `hybrid`: endpoint details are explicit for external consumers, while module-level notes summarize internal worker behavior.

## API index
| api_id | method | path | owner | source |
|---|---|---|---|---|
| API-claims-01 | POST | /claims | claims-api | FT-claims-01-01 |
| API-claims-02 | GET | /claims/{claim_id} | claims-api | FT-claims-01-02 |

## Request parameters and schema
`POST /claims` requires `claimant_id`, `policy_id`, `loss_date`, and `claim_items[]`. Field definitions are delegated to DOC-128-claims-01.

## Response schema and status
- `201`: claim accepted, includes `claim_id` and `status=received`.
- `400`: validation error with localized `error_code`.
- `409`: duplicate claim idempotency conflict.

## Cross links
- Module boundary source: DOC-127-claims-01
- Field dictionary: DOC-128-claims-01

downstream_handoff:
  contract_version: n330-doc-suite-v1.2.1
  handoff_id: HO-N330-REL-2026-claims-01-126
  producer_skill: api-documentation-generation
  consumer_skill_or_node: data-dictionary-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-126-claims-01
  release_id: REL-2026-claims-01
  required_fields: [doc_id, scope, upstream_id_aliases, cross_doc_refs]
  cross_doc_refs: ['DOC-127-claims-01', 'DOC-128-claims-01']
  pending_id_backfill: []
  readiness: ready
  confidence: high
  next_best_checks: []
