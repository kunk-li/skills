# Example: API Documentation — Breaking Change Audit Mode

Demonstrates `breaking_change_audit` mode for payment-service v2.3 → v2.4 upgrade.

```yaml
metadata:
  contract_version: n330-doc-suite-v1.2.1
  skill_id: "126"
  selected_mode: breaking_change_audit
  doc_id: API-PAY-AUDIT-V24
  doc_family_id: n330-rd-doc-suite
  readiness: complete
  open_blockers:
    - "API-PAY-007 idempotency: tbd — backend-team must confirm by 2025-06-20"
```

## API 文档摘要 — v2.3 → v2.4 升级审计

**服务**: payment-service  
**版本跨度**: v2.3 → v2.4  
**Breaking changes**: 2 个（API-PAY-002 字段移除，API-PAY-003 认证变更）  
**Non-breaking**: 3 个（新增端点、新增可选字段）

---

## API 索引表（含 breaking_change 标注）

| api_id | module | method | path | operation_summary | breaking_change | first_version |
|--------|--------|--------|------|------------------|-----------------|---------------|
| API-PAY-001 | checkout | POST | /v2/checkout | 发起结账流程 | **no** | v2.0 |
| API-PAY-002 | checkout | POST | /v2/checkout | legacy_id 字段移除 | **yes** | v2.0 |
| API-PAY-003 | auth | POST | /v2/auth/token | 认证改为 OAuth2.0 | **yes** | v2.1 |
| API-PAY-004 | orders | GET | /v2/orders/{id} | 获取订单详情 | **no** | v2.0 |
| API-PAY-005 | refunds | POST | /v2/refunds | 新建退款申请（新增）| **no** | v2.4 |
| API-PAY-006 | inventory | GET | /v2/inventory/check | 库存查询（新增可选字段）| **no** | v2.1 |
| API-PAY-007 | webhooks | POST | /v2/webhooks/register | 注册 Webhook（新增）| **no** | v2.4 |

---

## Breaking Change 详情

### API-PAY-002: checkout — legacy_id 字段移除

```yaml
api_id: API-PAY-002
breaking_change: yes
breaking_change_type: field_removal
affected_field: legacy_id (string, response body)
migration_path: "使用 order_ref 字段替代 legacy_id；order_ref 自 v2.1 起同时返回，可先双写再移除 legacy_id 消费"
deprecated_after: "v2.3 (已废弃)"
removal_version: v2.4
client_impact: "所有依赖 legacy_id 字段的客户端必须在 v2.4 上线前切换至 order_ref"
verification: "检查客户端代码是否有 .legacy_id 引用"
```

### API-PAY-003: auth — 认证机制变更

```yaml
api_id: API-PAY-003
breaking_change: yes
breaking_change_type: auth_change
old_auth: "Bearer token (proprietary)"
new_auth: "OAuth2.0 Client Credentials Flow"
migration_path: |
  1. 向 auth-service 申请 client_id 和 client_secret
  2. POST /v2/auth/token 获取 access_token
  3. 所有请求 Header: Authorization: Bearer {access_token}
  旧 token 格式在 v2.4 起不再接受
deprecated_after: "v2.3"
client_impact: "所有 API 调用方必须完成 OAuth2.0 迁移，否则 v2.4 起返回 401"
```

---

## 幂等性标注（所有 POST 端点）

| api_id | path | idempotency | 幂等键 | 重试安全 |
|--------|------|-------------|--------|---------|
| API-PAY-001 | POST /v2/checkout | key_based | X-Idempotency-Key header | ✓ 安全重试 |
| API-PAY-003 | POST /v2/auth/token | natural | — (client_credentials 天然幂等) | ✓ 安全重试 |
| API-PAY-005 | POST /v2/refunds | key_based | X-Idempotency-Key header | ✓ 安全重试 |
| API-PAY-007 | POST /v2/webhooks/register | **tbd** | 待 backend-team 确认 | ⚠ open_blocker |

**API-PAY-007 idempotency: tbd** — backend-team 需在 2025-06-20 前确认幂等策略，否则不可在 v2.4 上线。

---

## 变更历史与废弃通知

### v2.4（当前版本）
| api_id | 变更类型 | breaking | 迁移路径 | 废弃截止 |
|--------|---------|---------|---------|---------|
| API-PAY-002 | field_removal | **YES** | 使用 order_ref 替代 legacy_id | v2.4 移除 |
| API-PAY-003 | auth_change | **YES** | 切换至 OAuth2.0 | v2.4 生效 |
| API-PAY-005 | new_endpoint | NO | — | — |
| API-PAY-007 | new_endpoint | NO | — | — |

### 已废弃端点（仍可用，计划移除）
| api_id | path | deprecated_since | 计划移除 | 替代 |
|--------|------|-----------------|---------|------|
| API-PAY-001-V1 | POST /v1/checkout | v2.0 | v3.0 | POST /v2/checkout |

---

## Cross-links

| doc_id | 关系 |
|--------|------|
| DOC-127-PAY | 服务边界（checkout/auth 模块边界来源）|
| DOC-128-PAY | 数据字典（API 字段对应数据库字段）|

```yaml
downstream_handoff:
  handoff_id: API-AUDIT-HANDOFF-V24
  producer_skill: api-documentation-generation
  consumer_skill_or_node: development-documentation-generation|N350
  cross_doc_refs: [DOC-127-PAY, DOC-128-PAY]
  breaking_changes: [API-PAY-002, API-PAY-003]
  open_blockers:
    - "API-PAY-007 idempotency: tbd — 未解阻前不可发版"
  readiness: partial
  confidence: high
  next_best_checks:
    - "backend-team 在 2025-06-20 前确认 API-PAY-007 幂等策略"
    - "通知所有 API-PAY-002/003 消费方启动迁移"
```
