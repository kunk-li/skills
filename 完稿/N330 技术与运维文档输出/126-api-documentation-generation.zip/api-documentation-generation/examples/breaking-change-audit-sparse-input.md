# Example: API Documentation — Breaking Change Audit with Sparse Input

Demonstrates `breaking_change_audit` mode with minimal upstream input (no #127 service card, no DDL).

```yaml
metadata:
  skill_id: "126"
  selected_mode: breaking_change_audit
  artifact_id: API-PAYMENTS-BREAKING-V2
  contract_version: n330-doc-suite-v1.2.1
  doc_id: API-PAY-BREAKING-V2
  readiness: partial
  open_blockers:
    - "No MOD-127 service card available — service boundary assumed from existing v1 API"
    - "idempotency: payments/refund POST endpoint — confirmation required from ENG-lead"
```

## Breaking Change Index

| api_id | endpoint | method | breaking_change | client_impact | migration_path |
|--------|----------|--------|-----------------|--------------|----------------|
| API-PAY-001 | /payments/charge | POST | yes | Request body: `card_token` → `payment_method_id` | Update client field name; both accepted until v2.1 |
| API-PAY-002 | /payments/refund | POST | yes | Response drops `legacy_status` field | Remove legacy_status parsing; use `status` field |
| API-PAY-003 | /payments/status | GET | no | — | — |

## Breaking Change Details

### API-PAY-001: charge endpoint field rename
- **Affected clients**: mobile-app, partner-checkout-sdk
- **migration_path**: rename `card_token` → `payment_method_id` in request body
- **timeline**: both accepted until 2025-08-01 (v2.1 deprecation)
- **validation_gate**: confirm mobile-app team has updated before removing compat shim

### API-PAY-002: refund response field removal
- **Affected clients**: admin-dashboard, reconciliation-service
- **migration_path**: switch from `legacy_status` to `status` field (same values, different key)
- **timeline**: immediate (legacy_status removed in v2.0, no compat period)

## Idempotency Table (all POST endpoints)

| endpoint | idempotency | key_strategy |
|----------|------------|--------------|
| /payments/charge | key_based | X-Idempotency-Key header |
| /payments/refund | key_based | X-Idempotency-Key header |

## Open Blockers
- `API-PAY-002 idempotency`: field is `tbd` — ENG-lead must confirm before release

## Downstream Handoff

```yaml
handoff_id: API-PAY-BREAKING-V2-HANDOFF
producer_skill: api-documentation-generation
consumer_skill_or_node: deployment-documentation-generation
cross_doc_refs:
  - doc_id: MOD-PAY-001
    relationship: assumed_service_boundary
    note: no formal #127 available — boundary inferred from API surface
breaking_changes: [API-PAY-001, API-PAY-002]
migration_gates_required: [API-PAY-001-compat-shim-removal]
readiness: partial
confidence: medium
next_best_checks:
  - "#129: add migration_gate for API-PAY-001 compat shim removal (2025-08-01)"
  - "#127: generate service card for payments module to confirm boundary assumptions"
```
