# Dependency Matrix Rules

Use this reference when building the dependency matrix in module design documents.

## Matrix structure

The dependency matrix must cover ALL four dependency categories. Missing a category is not optional — write "none" explicitly if no dependency of that type exists.

### Required categories

| Category | Definition | Example |
|----------|-----------|---------|
| Synchronous calls | Direct API calls where caller waits for response | `order-service → POST /inventory/check (REST)` |
| Asynchronous events | Message queue, event bus, webhook | `order-service → order.created event → kafka.orders` |
| Shared data | Shared database tables, shared cache keys | `order-service, payment-service → shared orders table (MySQL)` |
| Shared constraints | Shared config, shared rate limits, shared auth | `all services → auth-service rate limit 1000/min` |

### Matrix row format

```markdown
| From | To | Type | Protocol/Topic | Shared resource | Direction | Notes |
|------|----|------|---------------|-----------------|-----------|-------|
| order-service | inventory-service | sync | REST POST /inventory/check | — | one-way | called on checkout |
| order-service | kafka.orders | async | kafka topic: orders | — | publish | on order creation |
| order-service | payment-service | shared_data | — | MySQL orders table (read) | bidirectional | both read order status |
| checkout-v2 | auth-service | shared_constraint | — | rate limit 1000 req/min | inbound | applies to all services |
```

## Bidirectional dependency detection

A bidirectional dependency exists when Service A calls Service B AND Service B calls Service A. This is a circular dependency.

Detection rule: scan all "sync" rows. If any service appears as both "From" and "To" with another service, mark `bidirectional: true` in that row.

Reporting rule: all bidirectional dependencies MUST appear in Section 9 (边界争议与待决事项) with:
- `circular_dependency_risk: HIGH | MEDIUM | LOW`
- At least one of the three decoupling options (events / coordinator / merge)
- `decision_owner` role for the decoupling decision

## Dependency matrix completeness check

Before finalizing:
1. Is there a row for EACH of the 4 categories? If a category has no dependencies, write a row stating "none" explicitly.
2. Are all services in the service card list represented as either source or destination in at least one row?
3. Are all bidirectional dependencies flagged?
4. Do shared data dependencies name the specific table/cache key, not just the database?

## Migration mode additions

When using `migration_architecture` mode, add a `migration_status` column:
- `STABLE` — dependency unchanged during migration
- `IN_MIGRATION` — old and new dependency coexist
- `MIGRATING_FROM` — this dependency will be replaced
- `MIGRATING_TO` — this is the replacement

See `references/migration-architecture-guide.md` for full migration mode rules.
