# N330 Document Family Composition Guide

Use this reference when producing documents as part of the N330 family or when linking sibling documents.

## Family composition order

```
#127 (module design — source of truth)
    ↓ service cards + boundaries
    ├─→ #126 (API contracts)
    ├─→ #128 (data dictionary)
    ├─→ #129 (deployment guide)
    └─→ #130 (maintenance manual)
              ↓
         #125 (developer entry point — aggregates all above)
```

## Cross-linking field conventions

Every N330 artifact uses these fields to link siblings:

| Field | Format | Purpose |
|-------|--------|---------|
| `doc_family_id` | always `n330-rd-doc-suite` | Family membership marker |
| `doc_id` | `DOC-{skill_id}-{project_id}-{nn}` | Stable artifact ID |
| `cross_doc_refs` | list of `doc_id` values | References to sibling artifacts |
| `related_module_ids` | from #127 service cards | Module/service traceability |
| `related_api_ids` | from #126 API index | API traceability |
| `related_field_ids` | from #128 data dict | Field-level traceability |

## When to produce the full family vs individual documents

| Scenario | Approach |
|---------|---------|
| New project kickoff | #127 first → #126/#128 → #129 → #130 → #125 last |
| API-first design | #126 first → #127 validates service boundaries → others follow |
| Legacy system onboarding | #125 first (skeleton) → fill in #126-#130 as discovered |
| Hotfix deployment only | #129 alone (standalone mode); link to existing siblings if available |
| Operational incident | #130 L1 triage alone; postmortem in N320 |

## Consistency rules

- If #127 changes service boundaries, #126/#128 must be reviewed for impact
- If #126 adds a breaking change, #129 must add a migration gate
- If #128 adds PII fields, #125 Section 9 must add a "known gotcha"

## Minimum viable cross-links per skill

| Skill | Minimum cross_doc_refs content |
|-------|-------------------------------|
| #126 | doc_id of the #127 that defines the API's service boundary |
| #128 | doc_id of the #127 that owns the data objects |
| #129 | doc_id of the #127 (service topology) and #126 (breaking changes) |
| #130 | doc_id of the #129 (smoke tests and alerts) |
| #125 | doc_ids of all available siblings in the family |
