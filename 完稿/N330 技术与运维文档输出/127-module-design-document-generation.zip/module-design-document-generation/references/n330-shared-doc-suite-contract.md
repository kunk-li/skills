# N330 Shared Doc Suite Contract

## Contract version
`n330-doc-suite-v1.2.1`

## Node scope
N330 turns architecture, product, API, data, deployment, and operations material into a self-contained documentation family. Each skill can produce its own document alone, and the six documents become stronger when joined by stable IDs and handoff records.

## Encapsulation governance
Each N330 skill is self-contained. Shared rules are packaged inside every skill under `references/`. Do not require node-level files, node-level scripts, external matrices, or hidden registries.

## Release consistency rule
A valid N330 release keeps the same `contract_version` in every SKILL.md instruction body, every `references/output-contract.yaml`, and every `references/n330-shared-doc-suite-contract.md`. The six skill-local copies of this shared contract should remain byte-identical before packaging.

## Shared metadata schema
Every N330 output artifact must start with a YAML metadata block containing these fields:

```yaml
metadata:
  contract_version: n330-doc-suite-v1.2.1
  workflow_node: N330
  skill_id: string                    # 125 | 126 | 127 | 128 | 129 | 130
  skill_name: string
  doc_family_id: n330-rd-doc-suite
  doc_id: string
  selected_mode: string
  readiness: draft | partial | ready | blocked
  scope:
    project_id: string | unknown
    release_id: string | unknown
    service_scope: [string]
    module_scope: [string]
  source_artifacts: [string]
  upstream_id_aliases: [string]
  cross_doc_refs: [string]
  pending_id_backfill: [string]
  freshness:
    as_of_date: iso8601 | unknown
    source_commit: string | null
    expected_review_window: string | unknown
  open_blockers: [string]
  owner_placeholders: [string]
  confidence: high | medium | low
  composition_role: string
  stage_position: documentation_family.<sub-stage>
  node_artifact_target: string
```

### Metadata enums
- `readiness`: `draft` means an early usable draft, `partial` means usable with explicit gaps, `ready` means ready for review or publication, and `blocked` means no valid artifact can be produced without named missing inputs.
- `confidence`: `high` means the source evidence is direct, `medium` means the artifact includes bounded inference, and `low` means the artifact is mostly a draft requiring confirmation.

## Doc id and family rules
- `doc_family_id` is always `n330-rd-doc-suite`.
- `doc_id` format is `DOC-{skill_id}-{project_id}-{nn}`, for example `DOC-127-claims-01`.
- If the skill runs without a stable project id, use `DOC-{skill_id}-TEMP-{date}-{source}` and add it to `pending_id_backfill`.

```yaml
doc_id_format:
  pattern: DOC-{skill_id}-{project_id}-{nn}
  fallback_pattern: DOC-{skill_id}-TEMP-{yyyy-mm-dd}-{source}
  fallback_must_be_in: pending_id_backfill
```

| skill_id | skill_name | node_artifact_target | ownership |
|---|---|---|---|
| 125 | development-documentation-generation | development-documentation.md | developer entry point and family summary |
| 126 | api-documentation-generation | api-documentation.md | API contracts and integration details |
| 127 | module-design-document-generation | module-design-documentation.md | module boundaries, service cards, dependency matrix |
| 128 | data-dictionary-generation | data-dictionary.md | object and field dictionary, DDL and coverage checks |
| 129 | deployment-documentation-generation | deployment-documentation.md | deployment phases, gates, rollback paths |
| 130 | maintenance-manual-generation | maintenance-manual.md | operator triage, scenario cards, screen and print manual |

## Upstream ID alias rules
Prefer upstream IDs from N080, N090, N160, N270, N280, N300, N310, or N320 when available. Preserve original prefixes and put all upstream IDs in `upstream_id_aliases`.

Common IDs:
- `P-{module}-{nn}` page id
- `FT-{module}-{page_seq}-{nn}` feature id
- `BE-{module}-{nn}` backend capability id
- `API-{module}-{nn}` API id
- `ACT-{module}-P{page_seq}-{nn}` action id
- `FLD-{module}-P{page_seq}-{nn}` field id
- `PRD-XX` product requirement section
- `RB-{module}-{nn}` runbook id
- `SC-{scenario_id}` scenario card id

Use `TEMP-*` only when a stable upstream ID is absent. Every temporary ID must be listed in `pending_id_backfill` with the next best check.

## Documentation evidence reference schema
Use compact evidence references in the artifact body when citing source documents, code snippets, tickets, or upstream artifacts.

```yaml
doc_evidence_ref:
  ref_id: string
  source_family: product | architecture | api | data | deployment | operations | incident | code | ticket | manual_note
  source_name: string
  query_or_source: string
  time_window_or_version: string | unknown
  service_scope: [string]
  module_scope: [string]
  upstream_id_aliases: [string]
  confidence: high | medium | low
  layer: confirmed_fact | bounded_inference | open_question
```

## Cross-document join keys
Use these keys when combining N330 outputs:
- `doc_family_id`
- `doc_id`
- `scope.project_id`
- `scope.release_id`
- `scope.service_scope`
- `scope.module_scope`
- `upstream_id_aliases`
- `cross_doc_refs`
- `pending_id_backfill`

`cross_doc_refs` must contain `doc_id` values, not local file paths. If a sibling document does not exist yet, use a planned `doc_id` and mark it as a stub in `open_blockers`.

## Standard composition paths
### Architecture-first family
module-design-document-generation -> api-documentation-generation -> data-dictionary-generation -> development-documentation-generation -> deployment-documentation-generation -> maintenance-manual-generation

### API-first family
api-documentation-generation -> data-dictionary-generation -> module-design-document-generation -> development-documentation-generation

### Deployment-to-operations family
deployment-documentation-generation -> maintenance-manual-generation -> development-documentation-generation

### Data-governance family
data-dictionary-generation -> api-documentation-generation -> development-documentation-generation

### Standalone fallback
Any one skill may run alone with partial readiness, provided it emits metadata, missing evidence, pending backfill IDs, and downstream handoff.

## Standalone guarantee
A skill must run with its own minimum viable input and no sibling artifacts. It must:
1. produce its target artifact with stable required sections,
2. set `readiness` accurately,
3. keep missing evidence in `open_blockers`,
4. list temporary IDs in `pending_id_backfill`,
5. avoid inventing project-specific stack choices not present in input,
6. emit a valid downstream handoff.

## Composition guarantee
When multiple skills are used together:
1. 127 owns service cards, module boundaries, and dependency baseline.
2. 126 and 128 reuse 127's service cards instead of redefining module boundaries.
3. 125 aggregates 126/127/128/129/130 as a developer entry point and cites sibling `doc_id` values.
4. 129 reuses 127 service dependencies and 126 endpoint inventory for deployment phases and gates.
5. 130 reuses 129 deployment and rollback paths plus N300/N310/N320 incident scenarios.
6. Later skills cite earlier artifacts through `cross_doc_refs` and `doc_evidence_ref` rather than redoing their analysis.
7. Conflicts between documents must remain visible with confidence labels and `open_blockers`.

## Downstream handoff schema
Every output must include a machine-readable `downstream_handoff` block:

```yaml
downstream_handoff:
  contract_version: n330-doc-suite-v1.2.1
  handoff_id: HO-N330-<release_id_or_project_id>-<seq>
  producer_skill: string
  consumer_skill_or_node: string
  doc_family_id: n330-rd-doc-suite
  doc_id: string
  release_id: string | unknown
  required_fields: [doc_id, scope, upstream_id_aliases, cross_doc_refs]
  cross_doc_refs: [string]
  pending_id_backfill: [string]
  readiness: draft | partial | ready | blocked
  confidence: high | medium | low
  next_best_checks: [string]
```

## Common execution workflow
1. Select the mode and write it to metadata.
2. Identify project, release, service, module, and upstream ID context.
3. Reuse stable upstream IDs and create temporary IDs only when necessary.
4. Draft the document's required sections.
5. Add `cross_doc_refs` to sibling N330 artifacts or planned stubs.
6. Add `pending_id_backfill`, `open_blockers`, and owner placeholders.
7. Produce `downstream_handoff` for sibling skills and downstream nodes.
8. Run the common self-check and the skill-specific quality checklist; compare against the closest example artifact.

## Common input handling
- Prefer direct source artifacts over second-hand summaries.
- If inputs conflict, keep both claims with confidence labels and identify the next best check.
- If input is incomplete, continue with `readiness: partial` instead of blocking, unless no target artifact can be produced.
- Use role/team placeholders for owners, not personal blame or private individual ownership.

## Common self-check
Before finalizing, verify:
1. metadata exists and follows the shared schema,
2. `contract_version` is exactly `n330-doc-suite-v1.2.1`,
3. `selected_mode` is declared and matches the artifact body,
4. all required sections are present or explicitly marked not applicable,
5. temporary IDs are listed in `pending_id_backfill`,
6. `cross_doc_refs` use doc IDs rather than file paths,
7. `owner_placeholders` use role or team names only,
8. `open_blockers` lists unresolved gaps,
9. `downstream_handoff` is present and complete,
10. sibling artifacts are cited rather than duplicated when composition inputs exist,
11. the artifact structure is compared with the closest example, and any intentional differences are clear.

## Quality checklist and examples
Each skill must include one skill-local quality checklist under `references/` and at least one example under `examples/`. The checklist is the final self-check for the artifact, while examples provide the expected metadata order, section shape, cross-document references, and downstream handoff style. Differences from examples are allowed, but they must be intentional and reflected in metadata, `open_blockers`, or `next_best_checks`.

## Tone and content rules
- Use placeholders for stack and deployment choices unless the input provides a project value.
- Keep documents operational and implementation-oriented.
- Do not hard-code one project's architecture, canary policy, runtime stack, or runbook pattern as a universal rule.
- Prefer stable IDs and structured tables over prose-only links.
