# N330 Input Validation Rules

Use this reference when input quality is uncertain or when deciding which mode to select.

## Minimum viable input per skill

| Skill | Minimum to produce useful output | Degradation when below minimum |
|-------|--------------------------------|-------------------------------|
| #125 dev docs | Architecture notes OR module list OR any existing partial docs | `legacy_system_onboarding` with inferred content; label confidence |
| #126 API docs | Endpoint list OR controller code OR OpenAPI fragment | `controller_fallback`; no invented paths or schemas |
| #127 module design | Service list OR dependency sketch OR API list | `api_backed_fallback`; mark boundary uncertainty explicitly |
| #128 data dict | DDL OR ORM entities OR field inventory | `field_inventory_fallback`; no invented constraints |
| #129 deployment | Deployment process notes OR rollback plan | `release_orchestration_fallback`; parameterize all unknowns |
| #130 maintenance | Alerts OR runbook OR monitoring signals | `incident_fallback`; section 6 uses placeholder from reference file |

## Input quality classification

**confirmed**: explicitly stated in input materials, can be directly cited  
**inferred**: derived from code, config, or structural analysis — must be labeled  
**placeholder**: unknown, requires team input — must use `{PLACEHOLDER}` or `待确认`  

Label ALL content with its quality level when using `legacy_system_onboarding` or `direct_input_fallback` modes.

## Rejection criteria (do not produce output if these conditions exist)

- Input consists only of a project name with no supporting materials → ask for minimum input
- Input explicitly contradicts itself without resolution → surface contradiction before producing output
- Requested mode requires specific prerequisite artifacts that are absent AND cannot be inferred → use fallback mode and document the switch

## Partial input handling per section

When a required section cannot be filled from available input:
1. Write the section header
2. Add: `> 📋 待补充: 此章节需要 [具体缺失内容]，当前暂无相关输入材料。`
3. Add the section to `metadata.open_blockers`
4. Set `readiness: partial` in metadata

Never skip a required section silently.
