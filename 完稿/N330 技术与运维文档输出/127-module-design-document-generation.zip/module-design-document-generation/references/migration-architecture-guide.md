# Migration Architecture Guide

Use this guide when `migration_architecture` mode is selected, or when the system is undergoing a refactor, re-platforming, or service extraction.

## When to use this mode
- Migrating from monolith to microservices
- Extracting a module into a standalone service
- Re-platforming (e.g., on-prem → cloud, v1 stack → v2 stack)
- Merging two services into one
- Any scenario requiring a before/after service boundary comparison

## Document structure for migration mode

### Before service cards (current state)
Label each card with `[CURRENT]` tag. Document the existing responsibilities even if messy or overlapping.

### After service cards (target state)
Label each card with `[TARGET]` tag. Show the intended clean boundaries.

### Migration phase column
Add `migration_phase` to each service card:
- `phase: decommission` — will be removed
- `phase: split` — responsibilities will be distributed to new services
- `phase: extract` — becomes its own service
- `phase: merge` — absorbed into another service
- `phase: stable` — no change planned

### Co-existence strategy
When old and new systems run in parallel, document:
```yaml
coexistence_strategy:
  approach: "Strangler fig — new endpoints route to new service; legacy endpoints remain until migration complete"
  traffic_routing: "Feature flag controls routing; 10% → 50% → 100% over 4 weeks"
  data_sync: "Dual-write to both databases during transition; new DB becomes primary at phase 3"
  rollback_trigger: "Error rate >1% on new service → revert feature flag"
  migration_complete_signal: "All legacy endpoints removed and deprecated; old DB decommissioned"
```

## Dependency matrix for migration
Add a `migration_status` column to the dependency matrix:
- `STABLE` — dependency unchanged
- `IN_MIGRATION` — both old and new dependency exist concurrently
- `MIGRATING_FROM` — this dependency is being replaced
- `MIGRATING_TO` — this is the replacement dependency

## Circular dependency handling
When circular dependencies (A→B and B→A) are detected:

1. Mark both entries `circular_dependency: true` in the dependency matrix
2. Add to Section 9 (边界争议与待决事项):
```markdown
### 循环依赖风险: [ServiceA] ↔ [ServiceB]
- 风险等级: HIGH / MEDIUM
- 当前影响: [describe what breaks or becomes fragile]
- 推荐解耦方案:
  Option 1: 事件化 — ServiceA 发布事件，ServiceB 订阅，消除直接调用
  Option 2: 引入第三方协调者 — 抽取 [ServiceC] 持有共享状态
  Option 3: 合并 — 若职责高度耦合，评估是否应合并为单一服务
- 决策责任人: [待确认]
- 决策截止: [待确认]
```

Never document a circular dependency without a recommended resolution path.
