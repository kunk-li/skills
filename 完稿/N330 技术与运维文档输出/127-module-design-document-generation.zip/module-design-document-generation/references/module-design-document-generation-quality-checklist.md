# N330 Module Design Documentation Quality Checklist

Use this checklist before finalizing `module-design-documentation.md`. The skill is standalone, so all required checks must be answerable from files packaged in this skill and the user-provided inputs.

1. Metadata follows `references/n330-shared-doc-suite-contract.md` and includes all required fields.
2. `selected_mode` matches both the user request and the produced document body.
3. `doc_id` follows `DOC-{skill_id}-{project_id}-{nn}`; any fallback `DOC-{skill_id}-TEMP-{date}-{source}` appears in `pending_id_backfill`.
4. `upstream_id_aliases` preserves upstream IDs exactly; uncertain IDs are marked `TEMP-*` or `to_confirm` rather than invented.
5. `cross_doc_refs` use sibling `doc_id` values, not file paths; missing sibling documents are explicit stubs in `open_blockers`.
6. Verify every core service has a six-field service card and every dependency is classified as sync call, async event, shared data, or shared constraint.
7. `source_artifacts` and `freshness` identify the evidence base, including `as_of_date`, `source_commit`, or explicit `unknown`.
8. `open_blockers` names unresolved gaps and their next best checks.
9. `owner_placeholders` use role/team names only; do not use personal blame or hard-coded individual ownership.
10. `downstream_handoff` includes `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `required_fields`, `readiness`, `confidence`, and `next_best_checks`.
11. Compare the produced module design document's metadata key order, field naming, cross-link style, and section structure against the closest file under `examples/`. Differences are allowed but should be intentional.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- `migration_architecture` mode: both CURRENT and TARGET service cards are present, labeled explicitly.
- Dependency matrix always covers sync/async/shared-data three categories; missing category triggers open_blocker.
- Section 9 (边界争议) always present; if no disputes: "当前无模块归属争议".

## Output structure completeness checks
- Sections 1–6 and 9–11 are present, even if placeholder.
- Section 9 (边界争议) present with explicit "当前无争议" if no disputes.
- If `migration_architecture` mode: CURRENT cards labeled `[CURRENT]` and TARGET cards labeled `[TARGET]`.
- Dependency matrix covers all 4 categories (sync/async/shared_data/shared_constraints); missing category explicitly states "none".
- Bidirectional dependencies marked `bidirectional: true`; each appears in Section 9.
