---
name: module-design-document-generation
description: generate module design documentation for the n330 technical and operations documentation node. use when ChatGPT needs to turn architecture notes, service boundaries, api relations, or dependency analysis into a module design document with standardized service cards, dependency matrices, and explicit links to upstream product and prototype ids.
---

# 模块设计说明生成

## Role
作为 N330 文档家族中的架构说明文档生成器，产出模块职责、边界、依赖与跨服务协作说明，并为 125/126/128 提供统一的服务卡片与依赖基线。

## Selected mode
- `service_architecture`
- `module_architecture`
- `api_backed_fallback`
- `boundary_review`

## Primary inputs
- 技术方案、服务列表、依赖关系、接口草稿、系统边界说明
- 上游 N080 `FT-*`、`API-*`
- 上游 N090 `PRD-XX`
- 若已有 orchestration / deployment 约束，也可作为补充

## Standalone rule
单独使用时也必须输出统一服务卡片和依赖矩阵，不要只给散乱描述段落。

## Core output contract
1. 模块设计摘要
2. 架构上下文
3. 模块 / 服务清单
4. 标准化服务卡片
5. 依赖矩阵与边界规则
6. 接口与事件触点
7. NFR 约束
8. sizing / 容量假设
9. cross-links
10. 缺失与待确认

服务卡片必须固定 6 字段：
`name / responsibilities / interfaces / dependencies / nfr_expectations / sizing_or_scale_assumption`

## Design rules
- 优先把模块描述组织成稳定服务卡片，不要用每个服务不同写法。
- 模块边界必须写“负责什么 / 不负责什么”。
- 依赖矩阵至少覆盖同步调用、异步事件、共享数据或共享约束。
- 若只能从 API 或服务名反推，也允许继续，但要把“不确定边界”暴露出来。

## Execution workflow
1. 识别模块或服务边界。
2. 归一为服务卡片。
3. 生成依赖矩阵和边界规则。
4. 补接口、事件和 NFR。
5. 回链到 `PRD-XX`、`FT-*`、`API-*` 和相关部署/维护文档。

## Dynamic completeness
- 只有接口清单、没有正式架构稿时：允许从 API 反推模块，但必须标注推断等级。
- 只有高层模块、没有服务级别细节时：可以输出模块级设计，但服务卡片中写待确认。

## Standalone use cases
- 微服务拆分与 review
- ADR 前置材料
- 系统容量规划输入
- 新团队快速理解系统边界

## Quality bar
- 是否使用统一服务卡片
- 是否有依赖矩阵
- 是否显式回链 `PRD-XX` 与 `API-*`
- 是否区分职责、边界与依赖，而不是混在同一段

## References
- `references/service-card-template.md`
- `references/id-linkage-guide.md`
- `references/n330-document-family-crosslinks.md`

## N330 v1.2.0 contract baseline
Contract version: `n330-doc-suite-v1.2.0`.

This skill is self-contained. Standalone execution and multi-skill composition rely only on files packaged inside this skill plus artifacts exchanged through `cross_doc_refs` and `downstream_handoff`. Do not require outside-package shared directories, outside-package tools, external matrices, or hidden registries.

## Standalone and composition role
```yaml
standalone_contract:
  minimum_viable_input: architecture notes, service list, dependency sketch, API list, or system boundary description
  partial_readiness_allowed: true
  degradation_behavior:
    - keep required sections stable even when evidence is partial
    - mark gaps in metadata.open_blockers
    - put temporary IDs in metadata.pending_id_backfill
composition_contract:
  composition_role: module_boundary_source_of_truth
  join_keys:
    - doc_family_id
    - doc_id
    - scope.project_id
    - scope.release_id
    - scope.service_scope
    - scope.module_scope
    - upstream_id_aliases
    - cross_doc_refs
  best_combines_with: ['126', '128', '125', '129', '130']
  consumes: ['upstream_architecture_or_product_inputs']
  produces_for: ['api-documentation-generation', 'data-dictionary-generation', 'development-documentation-generation', 'deployment-documentation-generation', 'maintenance-manual-generation']
  strengthens: provides the service-card and dependency baseline that sibling skills reuse instead of recreating module boundaries
```

## Required metadata and handoff
Every output must start with a `metadata` YAML block that follows `references/n330-shared-doc-suite-contract.md`. Every output must also end with a `downstream_handoff` block containing `handoff_id`, `producer_skill`, `consumer_skill_or_node`, `doc_id`, `cross_doc_refs`, `pending_id_backfill`, `readiness`, `confidence`, and `next_best_checks`.

## N330 references
- Always use `references/n330-shared-doc-suite-contract.md` for metadata, join keys, handoff, standalone, and composition rules.
- Use `references/output-contract.yaml` for this skill's required sections and machine-readable contract.
- Use `references/module-design-document-generation-quality-checklist.md` before finalizing the artifact.
- Use `examples/family-aligned-module-design.md` as the closest style and structure reference.
- Use `references/id-linkage-guide.md` when aligning upstream IDs.
- Use `references/n330-document-family-crosslinks.md` when linking sibling N330 documents.

