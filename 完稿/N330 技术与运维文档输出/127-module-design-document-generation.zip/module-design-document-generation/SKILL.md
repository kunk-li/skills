---
name: module-design-document-generation
description: 生成模块设计说明（架构说明文档）用于 n330 技术与运维文档输出。triggered when you need to document service responsibilities, inter-service dependencies, boundary disputes, and migration architecture. use boundary_review mode before an adr; use migration_architecture mode when splitting a monolith. do not use for api-level contracts (→ #126), field-level data dictionaries (→ #128), or developer entry-point docs (→ #125).
---

# 模块设计说明生成

## N330 contract baseline (n330-doc-suite-v1.2.1)

- contract_version: `n330-doc-suite-v1.2.1`
- workflow node: N330
- skill_id: 127
- primary artifact: `模块设计说明.md`
- family role: architecture source-of-truth; #125/#126/#128/#129/#130 all reference its doc_id
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: exchange artifacts through `doc_id`; #126/#128/#129/#130 reference #127 service cards.

> **N330 skill boundary summary** — see `references/n330-shared-doc-suite-contract.md` for full boundary matrix:
> #125 aggregates · #126 API contracts · **#127 module boundaries (source-of-truth)** · #128 data fields · #129 deployment · #130 ops manual

## Role

作为 N330 文档家族中的**架构说明文档生成器**，产出模块职责、边界、依赖与跨服务协作说明，并为全家族提供统一的服务卡片与依赖基线。

具体职责：
- 为每个服务生成标准 6 字段服务卡片（service_id/responsibility/not_responsible_for/tech_stack/api_ids/event_ids）
- 输出四类依赖矩阵（sync/async/shared_data/shared_constraint）并检测双向依赖
- 在 Section 9 记录所有边界争议与待决事项（永不省略）
- 作为 N330 架构事实来源，#125/#126/#128/#129/#130 均引用其 doc_id

**不负责**：API 接口规范（→ #126）、字段级数据字典（→ #128）、部署执行步骤（→ #129）、实现选型（→ ADR）。

## When NOT to use this skill

- **Not an API document**: interface details (request/response schemas, error codes) belong in #126; #127 documents service boundaries and module responsibilities.
- **Not a data dictionary**: field-level DDL details belong in #128; #127 documents data ownership at the service/module level.
- **Not an ADR**: architecture decision records for specific technology choices belong in a dedicated ADR system; #127 documents the resulting module structure.
- **Not a deployment topology**: infrastructure placement and scaling belong in #129; #127 documents logical module boundaries.

## Standalone and composition role

```yaml
standalone_goal: document service responsibilities, boundaries, dependencies, and cross-service collaboration for any team
minimum_viable_input:
  any_of:
    - 技术方案或服务列表
    - 依赖关系说明或接口草稿
    - 系统边界说明或架构图
    - 上游 N080 FT-* 或 API-* 清单
    - 若已有 orchestration 或 deployment 约束也可作为补充
partial_readiness_allowed: true
degradation_behavior: >
  If inputs are sparse, output service cards for known services only.
  Mark unknown dependencies as {TBD} in dependency matrix.
  Section 9 must still be present — "当前无争议，待补充" if nothing is known.
  Do not produce narrative paragraphs without the mandatory table structure.
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `service_architecture`: 以服务为单位拆分，适合微服务项目。
- `module_architecture`: 以代码模块为单位，适合单体或模块化单体项目。
- `api_backed_fallback`: 只有 API 清单，从接口反推模块边界。
- `boundary_review`: 专门用于模块边界讨论或 ADR 前置评审，重点输出"负责什么/不负责什么"和边界争议点。
- **`migration_architecture`**: 用于迁移/重构场景，输出 before/after 两套服务卡片，并标注迁移阶段与共存策略。

**Default routing**: microservices → `service_architecture`. Monolith → `module_architecture`. Pre-ADR review → `boundary_review`. Migration/refactor → `migration_architecture`.

## Mandatory output sections

| # | Section | Required | Notes |
|---|---------|----------|-------|
| 1 | 模块设计摘要 | Always | "摘要待补充" if missing |
| 2 | 架构上下文 | Always | "架构背景待补充" if missing |
| 3 | 模块/服务清单 | Always | List known; mark unknown as `{TBD}` |
| 4 | 标准化服务卡片 | Always | 6-field card per service; minimal card with name + responsibility is acceptable |
| 5 | 依赖矩阵与边界规则 | Always | sync/async/shared_data/shared_constraint; "依赖关系待确认" + open_blocker if missing |
| 6 | 接口与事件触点 | Always | Reference doc_id from #126 if available |
| 7 | NFR 约束 | Conditional (when evidence available) | Omit only if no evidence; note omission |
| 8 | Sizing/容量假设 | Conditional (when evidence available) | Omit only if no evidence; note omission |
| 9 | 边界争议与待决事项 | **Always — never omit** | "当前无争议" if none; add cross-link to ADR system |

> Legend: Always = required in every mode; Conditional = required when evidence triggers it.

**migration_architecture 模式**: Section 4 必须包含 before 和 after 两套服务卡片，并在每张卡片上标注迁移阶段（phase-1/phase-2/target-state）。

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** Section 9（边界争议）省略或为空 → 该 section 是**永不省略**项；即使无争议也必须写"当前无争议，待补充"。量化检验：Section 9 正文不足 10 字视为违例。
- **AP-2** 把 API schema 详情直接写入服务卡片 → 服务卡片只记录 `api_ids` 引用列表，详情留给 #126。检验：服务卡片内不应出现 `method:`、`path:` 等 API schema 字段。量化检验：服务卡片区块内出现 `method:`/`path:`/`requestBody:` 字符串的卡片数 = FAIL 数。
- **AP-3** 依赖关系只用叙述段落，不建依赖矩阵 → Standalone rule：必须输出四类依赖矩阵表格（sync / async / shared_data / shared_constraint）；即使某类为空也需保留表头行并注明"无"。量化检验：sync/async/shared_data/shared_constraint 四类标头必须全部出现在依赖矩阵 section，缺失任一则 FAIL。
- **AP-4** `migration_architecture` 模式只输出 target-state，无 before-state → 必须提供 before/after 对比两套服务卡片，并在每张卡片标注迁移阶段（phase-1 / phase-2 / target-state）和共存策略。检验：selected_mode=migration_architecture 时 Section 4 必须出现"before"和"after"两个子标题。量化检验：migration_architecture 模式下，before/after 子标题各缺失 1 个计 1 个 FAIL。
- **AP-5** `boundary_review` 模式未输出边界声明对比列 → 该模式必须包含至少一张含"responsible_for / not_responsible_for"两列的边界矩阵表。量化检验：boundary_review 模式下，responsible_for 和 not_responsible_for 两个字段任一缺失则 FAIL。
- **AP-6** 服务卡片缺少 6 字段中任意一个（service_id / responsibility / not_responsible_for / tech_stack / api_ids / event_ids）→ 未确认字段写 `{TBD}`，不可整列省略。量化检验：服务卡片中 service_id/responsibility/not_responsible_for/tech_stack/api_ids/event_ids 六字段任一整列缺失计 1 个 FAIL；`{TBD}` 为合法占位值。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n330-shared-doc-suite-contract.md` — shared contract, doc_id format, cross-link rules
- `references/n330-document-family-crosslinks.md` — cross-link structure between #125–#130
- `references/n330-composition-guide.md` — composition guide
- `references/n330-input-validation-rules.md` — when input quality is uncertain
- `references/dependency-matrix-rules.md` — when building or auditing dependency matrices
- `references/migration-architecture-guide.md` — when using migration_architecture mode
- `references/service-card-template.md` — standard 6-field service card format
- `references/id-linkage-guide.md` — when linking to upstream FT-*, API-*, PRD-XX IDs
- `references/module-design-document-generation-quality-checklist.md`
- `scripts/validate_md.py` — run before finalizing to auto-check mandatory sections, downstream_handoff readiness, and blameless rules — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/family-aligned-module-design.md` — service_architecture mode with full dependency matrix
- `examples/migration-architecture-mode.md` — migration_architecture with before/after service cards
- `examples/boundary-review-mode.md` — boundary_review with dispute table for ADR preparation

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: all N330 skills (#125/#126/#128/#129/#130)
  doc_id: MOD-DOC-*-001
  service_card_ids: [SVC-001, SVC-002, SVC-003]
  open_blockers: ["Section 9 boundary disputes unresolved", "dependency matrix incomplete"]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all service cards and dependency matrix populated) / `partial` (some dependencies TBD) / `degraded` (service list only; cards not yet structured — downstream skills must not use as architecture source-of-truth without team review).

## Workflow position

```
Tech specs / service lists / dependency diagrams / architecture docs
  ↓ #127 (module boundaries + service cards → 模块设计说明.md)
  → #125/#126/#128/#129/#130 all reference #127 service cards via doc_id
```
