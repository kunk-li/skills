metadata:
  contract_version: n330-doc-suite-v1.2.1
  workflow_node: N330
  skill_id: 127
  skill_name: module-design-document-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-127-claims-01
  selected_mode: service_architecture
  readiness: ready
  scope:
    project_id: claims-modernization
    release_id: REL-2026-claims-01
    service_scope: [claims-api, claims-worker]
    module_scope: [claims]
  source_artifacts: [architecture-brief.md, api-inventory.md, ddl.sql, release-plan.md]
  upstream_id_aliases: [FT-claims-01-01, BE-claims-01, API-claims-01, FLD-claims-P01-01, PRD-07]
  cross_doc_refs: [DOC-126-claims-01, DOC-128-claims-01, DOC-125-claims-01, DOC-129-claims-01, DOC-130-claims-01]
  pending_id_backfill: []
  freshness:
    as_of_date: 2026-05-07
    source_commit: abc1234
    expected_review_window: after every minor release
  open_blockers: []
  owner_placeholders: [claims-service-owner, platform-release-team]
  confidence: high
  composition_role: module_boundary_source_of_truth
  stage_position: documentation_family.technical_docs.example
  node_artifact_target: module-design-documentation.md

# Module Design Documentation Example

## Module design summary
Claims modernization defines two deployable services: `claims-api` and `claims-worker`. The API owns request validation and orchestration. The worker owns asynchronous adjudication and retry handling.

## Standardized service cards
| name | responsibilities | interfaces | dependencies | nfr_expectations | sizing_or_scale_assumption |
|---|---|---|---|---|---|
| claims-api | validate claim submissions and expose status reads | API-claims-01, API-claims-02 | identity, claims-db, claims-worker queue | p95 < 300ms for reads | scales by request rate |
| claims-worker | adjudicate submitted claims asynchronously | claims.submitted event | claims-db, payment-service | retry-safe processing | scales by queue depth |

## Dependency matrix and boundary rules
| source | target | dependency_type | reason | boundary note |
|---|---|---|---|---|
| claims-api | claims-worker | async event | avoids synchronous adjudication latency | API does not perform adjudication |
| claims-worker | payment-service | sync call | records approved reimbursement | worker owns retry/backoff only |

## Cross links
- Planned API document: DOC-126-claims-01
- Planned data dictionary: DOC-128-claims-01

downstream_handoff:
  contract_version: n330-doc-suite-v1.2.1
  handoff_id: HO-N330-REL-2026-claims-01-127
  producer_skill: module-design-document-generation
  consumer_skill_or_node: api-documentation-generation
  doc_family_id: n330-rd-doc-suite
  doc_id: DOC-127-claims-01
  release_id: REL-2026-claims-01
  required_fields: [doc_id, scope, upstream_id_aliases, cross_doc_refs]
  cross_doc_refs: ['DOC-126-claims-01', 'DOC-128-claims-01', 'DOC-125-claims-01', 'DOC-129-claims-01', 'DOC-130-claims-01']
  pending_id_backfill: []
  readiness: ready
  confidence: high
  next_best_checks: []
