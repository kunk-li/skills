# Example: Module Design Document — Migration Architecture Mode

Demonstrates `migration_architecture` mode: monolith cart module extraction to standalone cart-service.

```yaml
metadata:
  contract_version: n330-doc-suite-v1.2.1
  skill_id: "127"
  selected_mode: migration_architecture
  doc_id: MOD-CART-MIGRATION-001
  doc_family_id: n330-rd-doc-suite
  readiness: complete
```

## 模块设计摘要

**迁移场景**: 将 monolith 中的 cart 模块提取为独立 cart-service  
**迁移策略**: Strangler Fig — 新端点路由至 cart-service；旧端点保留至迁移完成  
**当前阶段**: Phase 2（50% 流量切换至 cart-service）  
**目标**: Phase 3（100% 切换，monolith cart 模块停用）

---

## 模块/服务清单

### [CURRENT] 现状（Before）

| service | 职责 | 状态 | migration_phase |
|---------|------|------|-----------------|
| monolith | 包含 cart、order、payment 等所有逻辑 | 运行中 | split |
| monolith.cart_module | 购物车 CRUD、数量限制、会话绑定 | 运行中（迁移中）| MIGRATING_FROM |

### [TARGET] 目标（After）

| service | 职责 | 状态 | migration_phase |
|---------|------|------|-----------------|
| cart-service | 购物车 CRUD、数量限制、会话绑定（独立服务）| 部署中 | MIGRATING_TO |
| monolith | order、payment（cart 模块移除后）| 运行中 | stable |
| order-service | 下单流程（下一阶段拆分，不在本次范围）| 运行中 | stable |

---

## 标准化服务卡片

### cart-service [TARGET]

```yaml
service_id: cart-service
version: v1.0
responsibility: "管理用户购物车生命周期：创建、添加商品、删除商品、清空、查询；强制最大512条数量限制"
not_responsible_for:
  - "下单流程（属于 order-service）"
  - "库存实时查询（仅做缓存读取，库存真实数据在 inventory-service）"
tech_stack: {FRAMEWORK}: Spring Boot 3.x, {DB}: Redis 7 (主存储), {FALLBACK_DB}: MySQL 8 (持久化备份)
api_ids: [API-CART-001, API-CART-002, API-CART-003]
event_ids: [EVT-CART-001]
owner_team: frontend-team + backend-team
migration_phase: MIGRATING_TO
coexistence_period: "2025-06-01 ~ 2025-07-15（与 monolith.cart_module 并存）"
```

### monolith.cart_module [CURRENT — 迁移中]

```yaml
service_id: monolith.cart_module
responsibility: "现有购物车逻辑（正在被 cart-service 替代）"
migration_phase: MIGRATING_FROM
decommission_date: "2025-07-15（Phase 3 完成后）"
remaining_traffic: "50%（Phase 2 状态）"
```

---

## 依赖矩阵（含 migration_status）

| From | To | Type | Protocol | migration_status | Notes |
|------|----|------|----------|-----------------|-------|
| cart-service | redis | sync | Redis Protocol | STABLE | 主存储 |
| cart-service | mysql | sync | JDBC | STABLE | 持久化备份 |
| cart-service | inventory-service | sync | REST GET | STABLE | 缓存读取库存 |
| order-service | cart-service | sync | REST POST | MIGRATING_TO | order 将从 monolith.cart 切换至 cart-service |
| order-service | monolith.cart_module | sync | Internal call | MIGRATING_FROM | Phase 3 停止 |
| monolith | cart-service | sync | REST (feature flag) | IN_MIGRATION | 50% 流量通过 FF 路由至 cart-service |

**双向依赖检查**: 无循环依赖（cart-service 不调用 order-service）✓

---

## 共存策略

```yaml
coexistence_strategy:
  approach: "Strangler Fig — feature flag 控制流量路由"
  traffic_routing: "CART_SERVICE_FF=true → cart-service; false → monolith.cart_module"
  data_sync: "双写：写入 cart-service 同时写入 monolith.cart_module（Phase 2）；Phase 3 停止双写"
  rollback_trigger: "cart-service 5xx > 1% 持续3分钟 → 关闭 feature flag，100% 回退到 monolith"
  rollback_rto: "5分钟（feature flag 切换）"
  migration_complete_signal: "feature flag 全量开启7天无异常 + monolith.cart_module 流量归零"
```

---

## Section 9 — 边界争议与待决事项

| 议题 | 当前状态 | 选项 | 决策截止 | 决策责任人 |
|------|---------|------|---------|-----------|
| cart-service 的会话管理：Redis vs JWT？ | 未决 | Redis session（当前 monolith 方式）vs JWT stateless | 2025-06-20 | ENG-lead |
| Phase 3 切换时间：7月15日是否现实？ | AT_RISK | 按计划 / 推迟至7月末 | 2025-06-25 | PM + ENG-lead |

---

## Cross-links

| doc_id | 关系 |
|--------|------|
| API-CART-001/002/003 | cart-service API（见 #126 文档）|
| DOC-128-CART | 数据字典（cart Redis schema）|
| DOC-129-CART | 部署文档（feature flag 切换步骤）|

```yaml
downstream_handoff:
  handoff_id: MOD-CART-MIGRATION-HANDOFF
  producer_skill: module-design-document-generation
  consumer_skill_or_node: api-documentation-generation|deployment-documentation-generation
  cross_doc_refs: [API-CART-001, DOC-128-CART, DOC-129-CART]
  migration_phase: phase_2
  pending_decisions:
    - "会话管理方案（Redis vs JWT）— 截止 2025-06-20"
    - "Phase 3 切换日期 — 截止 2025-06-25"
  readiness: partial
  confidence: high
  next_best_checks:
    - "ENG-lead 在 2025-06-20 确认会话管理方案"
    - "DOC-129-CART 更新 Phase 3 切换 runbook"
```
