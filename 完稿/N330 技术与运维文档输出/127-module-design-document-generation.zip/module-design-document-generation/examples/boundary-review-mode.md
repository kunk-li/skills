# Example: Module Design — Boundary Review of Existing Services

Demonstrates `boundary_review` mode: reviewing and clarifying disputed boundaries between two existing services.

```yaml
metadata:
  skill_id: "127"
  selected_mode: boundary_review
  artifact_id: MOD-REVIEW-AUTH-PROFILE-001
  contract_version: n330-doc-suite-v1.2.1
  readiness: partial
  open_blockers:
    - "AUTH-PROFILE boundary: user preference storage ownership unresolved"
```

## Boundary Dispute Summary

| dispute_id | service_a | service_b | disputed_responsibility | current_state |
|-----------|-----------|-----------|------------------------|---------------|
| DISP-001 | auth-service | profile-service | user preference storage | Both services store preferences — duplication |
| DISP-002 | auth-service | api-gateway | token validation | Auth validates + Gateway caches — unclear who owns cache invalidation |

## Section 9: Boundary Disputes and Pending Decisions

### DISP-001: user preference storage ownership
- **Observed behavior**: auth-service stores `notification_prefs`; profile-service stores `ui_prefs` + `notification_prefs` (duplicate)
- **Recommended resolution**: profile-service owns all preferences; auth-service reads via internal API
- **Decision owner**: ENG-lead (auth) + ENG-lead (profile)
- **Deadline**: 2025-06-25
- **decoupling_option**: event-driven sync (preference_updated event) or API delegation

### DISP-002: token cache invalidation
- **Observed behavior**: auth-service issues tokens; api-gateway caches for 5 minutes; no invalidation path exists
- **Recommended resolution**: auth-service exposes `/tokens/invalidate` endpoint; gateway subscribes to `token_revoked` event
- **Decision owner**: ENG-lead (platform)
- **Deadline**: 2025-06-20 (security requirement)

## Downstream Handoff

```yaml
handoff_id: MOD-REVIEW-AUTH-PROFILE-HANDOFF
producer_skill: module-design-document-generation
consumer_skill_or_node: api-documentation-generation|development-documentation-generation
boundary_disputes: [DISP-001, DISP-002]
pending_decisions:
  - DISP-001: preference storage ownership (deadline 2025-06-25)
  - DISP-002: token invalidation path (deadline 2025-06-20)
readiness: partial
confidence: medium
```
