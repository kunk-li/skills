# 幂等测试常见失败模式

## F1: 只测重复成功，不测冲突拒绝
修正：补同 key 不同 payload 场景。

## F2: 忽略时间窗边界
修正：覆盖窗口内、窗口外与 ttl 失效后的行为。

## F3: 忽略 consumer 去重
修正：对 mq 场景补 message_id 去重与重复投递验证。


# 通用失败模式

## F1: 把专项清单写成万能模板
症状：字段和描述对所有专项都一样。
修正：必须使用该专项的领域维度、术语和反模式。

## F2: 把推断写成事实
症状：没有日志或证据却写成“已通过”。
修正：改为 `待确认`、`假设` 或 `需要补证`。

## F3: 一行混多个检查点
症状：同一行同时包含多个对象和多个动作。
修正：拆成单一对象、单一条件、单一预期的最小单元。

## F4: 缺 owner 或 evidence_ref
症状：表格能看但不可追踪。
修正：补责任方、证据来源或显式标记 `todo`。

## v2 duplicate and routing failure modes
- Duplicate-generating both 097 same-key concurrency rows and 098 same-key idempotency outcome rows without shared IDs.
- Treating 094 operational readiness as the final 093 quality gate verdict.
- Emitting specialty rows without `shared_scenario_tag`, which prevents 093 from de-duplicating weighted score.
- Claiming `pass` when the correct state is `insufficient_evidence`.
- Failing to emit N005 signals for recurring release-blocking defects or regressions.
