# Artifact frontmatter contract v3.1.3

## Purpose
Provide a machine-readable metadata envelope for Markdown and CSV outputs so the N260 validator can enforce the same governance contract across file formats.

## Markdown pattern
Every Markdown artifact should start with YAML frontmatter:

```yaml
---
metadata:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  skill_id: "<skill-id>"
  workflow_node: "N260"
  selected_mode: "<mode>"
  readiness: "pass | constrained | blocked | insufficient_evidence"
  evidence_profile: "<short evidence summary>"
  routing:
    intent_tags: ["n260"]
    routing_keywords: []
  event_contract:
    produces_event: "produced.n260.<event>"
  signal_emission:
    to_n005: []
    emit_when: []
  human_review:
    sla_priority: "P0 | P1 | P2 | none"
  schema_evolution:
    compatibility: "backward_compatible | breaking"
items: []
---
```

## CSV pattern
Use one of two supported patterns:

1. A key/value metadata CSV with columns `key,value` and keys like `metadata.skill_id` or `metadata.event_contract.produces_event`.
2. A tabular artifact CSV where every row repeats the metadata columns and includes row-level STG fields such as `shared_scenario_tag`, `ownership_role`, and `canonical_owner_skill`.

## Enforcement
- Validate Markdown or CSV with `scripts/validate_n260_output.py` before handoff when the artifact is available as a file.
- Do not hand off Markdown or CSV that omits metadata only because the human-readable content looks complete.
- For CSV rows, prefer repeating metadata columns over separate sidecar files so the artifact remains portable.


## v3.1.3 YAML fallback guidance
The validator supports common YAML list styles even when PyYAML is unavailable:

```yaml
metadata:
  signal_emission:
    to_n005:
      - recurring_issue
      - release_blocker_repeat
items:
  - shared_scenario_tag: STG-QUALITY-GATE-ROLLUP
    ownership_role: canonical
    canonical_owner_skill: quality-gate-check
    related_specialty_refs: []
    deduplicated_links: []
```

Keep frontmatter simple: use mappings, scalar values, inline lists, or list-of-mapping rows. Do not rely on YAML anchors, aliases, custom tags, or advanced merge keys.


## v3.1.3 final handoff checks

For final Markdown, CSV, JSON, or YAML handoff artifacts, prefer:

```bash
python scripts/validate_n260_output.py --domain-mode complete --complete-min 2 <artifact>
```

Use a different `--complete-min` only when the release governance owner intentionally approves a stricter or lighter completeness bar.
