# N260 示例输入输出

## 示例 1：质量门禁检查（quality-gate-check）

### 输入
- 测试覆盖率 85%，缺陷密度 0.8/kloc，所有P0缺陷已关闭

### 输出
```yaml
gate_check_result:
  verdict: pass
  dimensions:
    coverage: pass (85% ≥ 80%)
    defect_density: pass (0.8 ≤ 1.0)
    p0_defects: pass (0 open)
  readiness: ready
  downstream_handoff:
    to: N270-release-coordination
```

## 示例 2：权限测试点生成（permission-test-point-generation）

### 输入
- 模型：RBAC，角色：admin/editor/viewer

### 输出
```yaml
permission_test_points:
  - tp_id: PTP-001
    model: RBAC
    scenario: admin可访问所有资源
    deny_path: viewer访问admin端点 → 403
  - tp_id: PTP-002
    scenario: IDOR尝试 — 用户A访问用户B的资源 → 403
```
