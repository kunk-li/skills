# N260 示例输入输出 v2（扩展场景）

## 示例 3：并发测试点生成（concurrency-test-point-generation）

### 输入
- 场景：订单服务，共享库存写操作

### 输出
```yaml
concurrency_test_points:
  - tp_id: CTP-001
    surface: 库存扣减
    pattern: 竞争写
    isolation_level: SERIALIZABLE
    test: 100并发请求同一SKU，库存不可为负
  - tp_id: CTP-002
    pattern: 死锁
    test: 订单A锁库存→锁账户 vs 订单B锁账户→锁库存
```

## 示例 4：性能测试场景生成（performance-test-scenario-generation）

### 输入
- SLO：p95 ≤ 500ms，吞吐量 ≥ 1000 rps

### 输出
```yaml
performance_scenarios:
  - type: load
    config: 1000 rps × 10min
    slo_assertion:
      metric: p95_latency
      threshold: 500ms
      window: 10min
    abort_condition: error_rate > 5%
  - type: stress
    config: ramp 100→2000 rps
    abort_condition: p95 > 2000ms
```

## 098 扩展示例输入输出

### Scenario C — Distributed idempotency (multi-channel)

**Input**: Webhook with retry — same event delivered via HTTP and message queue.

**Output** (`multi_channel_replay` mode):
```yaml
idempotency_test_points:
  - tp_id: ITP-MC001
    operation: process_webhook_event
    scenario: Same event via HTTP AND SQS simultaneously
    idempotency_key: event_id
    test: Deliver EVT-001 via HTTP; then via SQS within 10ms
    expected: Processed exactly once; second delivery returns 200 with cached result
  - tp_id: ITP-MC002
    scenario: Replay after TTL expiry on different channel
    test: Wait for TTL expiry; replay on different channel
    expected: Treated as new event (stale key expired)
    pending_ttl_confirmation: true
```



### Scenario D — Partial failure idempotency

**Input**: Saga step `charge_payment` succeeds but `update_order_status` fails mid-transaction.

**Output** (`distributed_coordination` mode):
```yaml
idempotency_test_points:
  - tp_id: ITP-PF001
    operation: order_saga_charge_then_update
    scenario: charge_payment succeeds; update_order_status fails
    idempotency_key: saga_correlation_id
    test: >
      Inject failure at update_order_status after charge completes.
      Retry full saga. Verify: charge NOT duplicated; update_order_status retried.
    expected: Idempotent charge; exactly one payment; order status eventually consistent
    compensation_check: If saga aborted — verify refund issued
  - tp_id: ITP-PF002
    scenario: Concurrent saga retries race to update the same order
    test: Fire 3 concurrent saga retries with same correlation_id
    expected: Only one update applied; others return 200 with cached result
```

### Scenario D — Partial failure idempotency (saga)

**Input**: Saga — `charge_payment` succeeds but `update_order_status` fails mid-transaction.

**Output** (`distributed_coordination` mode):
```yaml
idempotency_test_points:
  - tp_id: ITP-PF001
    operation: order_saga_charge_then_update
    scenario: charge_payment succeeds; update_order_status fails
    idempotency_key: saga_correlation_id
    test: >
      Inject failure at update_order_status after charge completes.
      Retry full saga. Verify: charge NOT duplicated; update retried.
    expected: Idempotent charge; exactly one payment; order eventually consistent
    compensation_check: If saga aborted — verify refund issued
  - tp_id: ITP-PF002
    scenario: Concurrent saga retries race to update same order
    test: Fire 3 concurrent retries with same correlation_id
    expected: Only one update applied; others return 200 with cached result
```

### Scenario D — Idempotency key TTL boundary

**Input**: Payment API with idempotency key TTL of 24h; replay after key expiry.

**Output** (TTL boundary test):
```yaml
idempotency_test_points:
  - tp_id: ITP-TTL-001
    operation: POST /api/v1/payments
    scenario: Replay within TTL window
    test: Submit payment with key K at T=0; replay at T=23h59m
    expected: Cached response returned; no duplicate charge
    idempotency_key_ttl: 24h
  - tp_id: ITP-TTL-002
    scenario: Replay after TTL expiry
    test: Submit payment with key K at T=0; replay at T=24h01m
    expected: New payment created (key expired); behavior documented in API contract
    note: Client must be warned that expired key creates new transaction
  - tp_id: ITP-TTL-003
    scenario: Clock skew between client and server
    test: Submit with key K; server clock 90s ahead of client; replay at T=23h59m (client time)
    expected: Key treated as expired by server; document in API contract
    cross_reference: 097-concurrency-test-point-generation
```
