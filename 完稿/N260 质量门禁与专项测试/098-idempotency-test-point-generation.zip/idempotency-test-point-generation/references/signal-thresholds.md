# N005 signal thresholds v3.1.3

## Purpose
Prevent noisy feedback loops by defining when a skill should emit durable learning signals to N005.

## Global thresholds
Emit a signal only when one or more conditions are true:
- `recurring_issue`: same root cause or same shared_scenario_tag appears at least 3 times in 30 days.
- `release_blocker_repeat`: same blocker family appears at least 2 times across 2 releases or within 14 days.
- `customer_visible`: production users, support, compliance, money, entitlement, security, data integrity, or SLO floor is affected.
- `regression`: metric or gate score worsens by more than 10% against baseline, or worsens for 3 consecutive runs.
- `manual_override_pattern`: same override type is used at least 2 times in 30 days.
- `stg_unmapped_abuse`: `STG-UNMAPPED` appears in more than 2 rows, more than 10% of rows in one artifact or release window, or appears in 2 consecutive runs for the same skill.

## Domain examples
- 093: emit for gate score drop > 10 points in 48h, 2 consecutive no_go results, repeated override, or recurring hard-rule trigger.
- 094: emit for repeated missing signoff, repeated freeze-period exception, rollback not tested in 2 releases, or operational blocker after 093 go.
- 095: emit for repeated data drift, orphan count > 0 in production, reconciliation failure repeated 3 times, or recovery runbook missing for critical data.
- 096: emit for IDOR/SoD/token/scope failure, sensitive field leak, break-glass audit gap, or repeat permission override.
- 097: emit for race detected in production-like test, deadlock repeat, isolation gap on critical flow, or flaky race regression >= 2 failures in 100 repeats.
- 098: emit for duplicate money/entitlement/external side effect, replay accepted, idempotency conflict mishandled, or L1/L2 fallback failure.
- 099: emit for p99/error/throughput regression > 10%, floor SLO breach, capacity ceiling below committed load, memory growth > 5% in soak, or resource leak trend.

## Non-emission rule
Do not emit to N005 for one-off low-risk findings, template-only assumptions, missing optional evidence, or speculative risks without supporting data. Record those locally as `downstream_handoff.missing_evidence` or `human_review_queue[]`.

## STG-UNMAPPED feedback rule
If `stg_unmapped_abuse` is triggered, do not mark the artifact as `pass`. Keep readiness at `constrained` or `insufficient_evidence`, add a human-review row, and emit a governance feedback signal to N005 unless the unmapped category is resolved before handoff.
