# Output Template: 幂等测试点

## 推荐 csv 字段
`it_id | key_pattern | object | trigger | expected_behavior | window | dedup_storage | evidence_ref | status`

## 必覆盖
- 至少覆盖一种 key 模式和一种冲突模式
- 明确同 key 同 payload 与同 key 不同 payload 的预期差异
- 对 mq 或异步消费链路写出去重存储位置

## 禁止
- ❌ 把“防重复提交”写成泛泛口号
- ❌ 不区分 key 模式与业务对象


## v2.1 shared contract fields
Include these fields when the output is row-based:
`schema_version | shared_scenario_tag | ownership_role | canonical_owner_skill | related_specialty_refs | deduplicated_links | human_review_required | sla_priority | signal_to_n005`

Use `status=insufficient_evidence` instead of implying pass/fail when proof is missing.

## v3.1 governance fields
- Include `metadata.governance_revision: "3.1"`.
- Validate required metadata and item de-dup fields against `validation-rules.md`.
- Use `classification-to-stg-map.md` to set `shared_scenario_tag`.
- Use `signal-thresholds.md` before emitting to N005.

## Markdown and CSV frontmatter
For Markdown or CSV outputs, apply `references/artifact-frontmatter-contract.md` so the same metadata can be validated by `scripts/validate_n260_output.py`.
