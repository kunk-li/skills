# Internal classification to STG map v3.1.3

## Purpose
Bind the skill's internal categories to shared N260 STG tags so generated rows are deduplicable by 093 and N370.

| internal classification | default shared_scenario_tag | ownership_role | notes |
|---|---|---|---|
| `IS01_retry_after_success` | `STG-IDEMPOTENCY-KEY-OUTCOME` | `canonical` | Own cached/same-result success semantics. |
| `IS02_retry_after_partial_failure` | `STG-IDEMPOTENCY-KEY-OUTCOME` | `canonical` | Own partial failure retry outcome and side-effect idempotence. |
| `IS03_same_key_diff_payload` | `STG-IDEMPOTENCY-PAYLOAD-EQUIVALENCE` | `canonical` | Own payload conflict and equivalence semantics. |
| `IS04_ttl_boundary_replay` | `STG-IDEMPOTENCY-KEY-OUTCOME` | `canonical` | Own TTL expiration/replay outcome; link to storage constraints as evidence. |
| `IS05_l1_down_l2_works` | `STG-IDEMPOTENCY-KEY-OUTCOME` | `canonical` | Own L1/L2 degradation outcome. |
| `IS06_both_layers_down` | `STG-IDEMPOTENCY-KEY-OUTCOME` | `canonical` | Own extreme store outage behavior and expected rejection/degradation. |
| `IS07_concurrent_same_key` | `STG-IDEMPOTENCY-KEY-OUTCOME / STG-CONCURRENCY-SAME-KEY-TRIGGER` | `canonical/supporting` | Own duplicate outcome; 097 owns simultaneous trigger mechanics. |
| `IS08_different_users_same_key` | `STG-IDEMPOTENCY-KEY-OUTCOME` | `canonical` | Own key namespace isolation. |
| `IS09_message_redelivery` | `STG-IDEMPOTENCY-KEY-OUTCOME` | `canonical` | Own message duplicate side-effect outcome; link to 095 for cross-service consistency. |
| `IS10_webhook_replay_attack` | `STG-IDEMPOTENCY-KEY-OUTCOME` | `canonical` | Own webhook replay rejection and signature/timestamp/key behavior. |

## Enforcement
- Every generated row should include the most specific internal classification and at least one default STG tag from this map.
- If a row spans multiple classifications, include multiple tags and mark only the canonical owner as `ownership_role: canonical`.
- If the map does not cover a new category, add a temporary `STG-UNMAPPED` note in `downstream_handoff` and mark readiness no stronger than `constrained` until the map is updated.

## STG-UNMAPPED governance limit
Use `STG-UNMAPPED` only as a temporary exception. More than 2 unmapped rows or more than 10% unmapped rows in one artifact is a governance signal and must keep readiness no stronger than `constrained` until the map is updated.


## v3.1.3 map integrity check
After editing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

The check fails if this file references an STG tag that is not defined in `references/cross-skill-orchestration.md`, except for the temporary `STG-UNMAPPED` exception.


## v3.1.3 owner-map consistency

After changing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

During artifact validation, `canonical_owner_skill` is checked against the canonical owner table in `cross-skill-orchestration.md`. Use `STG-UNMAPPED` only as a temporary constrained fallback, not as an owner bypass.
