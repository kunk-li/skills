# N260 shared field contract v2.1

## Shared fields
- `id`: unique row id, for example `gate_id`, `pre_id`, `dc_id`, `pt_id`, `ct_id`, `it_id`, or `pf_id`.
- `schema_version`: use `2.1` for this optimized contract.
- `shared_scenario_tag`: cross-skill tag used for de-duplication and aggregation.
- `ownership_role`: `canonical`, `supporting`, or `duplicate_reference`.
- `canonical_owner_skill`: skill responsible for the primary executable row.
- `related_specialty_refs[]`: supporting rows from other specialty skills.
- `deduplicated_links[]`: rows intentionally not duplicated.
- `priority`: `P0 / P1 / P2`.
- `severity`: `blocker / major / minor / info`.
- `owner`: team, role, or responsible person.
- `status`: `pending / pass / fail / waived / blocked / insufficient_evidence`.
- `evidence_ref`: screenshot, log, case id, metric panel, CI run, review note, or link.
- `acceptance_criteria`: machine-readable pass condition when possible.
- `human_review_required`: boolean.
- `sla_priority`: `P0 / P1 / P2` when human review is required.
- `signal_to_n005`: optional feedback signal if the row should feed future requirement or quality planning.

## Shared constraints
- One row expresses one assertion or readiness item.
- `status` describes validation state, not final launch approval.
- Missing evidence must be explicit: use `todo`, `tbd`, or `insufficient_evidence` with a reason.
- `priority` is handling urgency; `severity` is risk impact.
- Duplicate-linked rows must not be counted twice by 093.

## Specialty extension fields
- 093: `gate_type / gate_decision / blocking_reason / next_action / weighted_contribution`.
- 094: `category / verify_method / acceptance / time_window / signoff_role / operational_readiness_status`.
- 095: `consistency_type / expected_behavior / reconciliation_method / recovery / source_of_truth`.
- 096: `role / resource / action / expected_result / policy_type / audit_expectation`.
- 097: `race_type / concurrency_level / coordination_primitive / lock_strategy / isolation_expectation`.
- 098: `key_pattern / payload_equivalence / window / dedup_storage / duplicate_outcome`.
- 099: `scenario / load_model / slo / metric / baseline / bottleneck_hypothesis`.

## v3.1 required governance fields
- `metadata.governance_revision`: fixed value `3.1`.
- `metadata.event_contract.produces_event`: required and must match this skill.
- `metadata.signal_emission.to_n005`: required; may be empty only when thresholds are not met.
- `items[].shared_scenario_tag`: required for every overlap-capable row.
- `items[].ownership_role`: `canonical`, `supporting`, or `duplicate_reference`.
- `items[].canonical_owner_skill`: required for all rows with STG tags.
