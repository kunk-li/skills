# Idempotency pattern anchors

Recommended baseline patterns:
- same_key_same_payload
- same_key_diff_payload
- diff_key_same_payload
- key_missing_when_required
- key_format_invalid
- key_ttl_expired
- degraded_store_with_db_fallback
- fully_degraded_duplicate_store
- concurrent_same_key
- retry_after_timeout

## v2.1 ownership boundaries
- 098 owns duplicate outcome semantics for same key, payload conflict, TTL, in-progress, degraded store, replay, and redelivery.
- Use `STG-IDEMPOTENCY-KEY-OUTCOME` for same-key expected outcome rows.
- Use `STG-IDEMPOTENCY-PAYLOAD-EQUIVALENCE` for field ordering, whitespace, null-vs-missing, and canonical payload comparison.
- Link concurrent same-key trigger mechanics to 097 instead of duplicating the load/barrier design.
- Link persistent data invariant verification to 095 instead of generating reconciliation rows here.
