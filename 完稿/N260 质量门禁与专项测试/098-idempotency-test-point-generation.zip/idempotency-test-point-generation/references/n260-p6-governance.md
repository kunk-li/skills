# N260 v3.1.3 P6 Governance Enforcement

> This is the shared governance reference for all N260 skills.
> Do not duplicate this content in SKILL.md — reference this file instead.

- Treat `references/cross-skill-orchestration.md` as the single source of truth for STG ownership tags; do not copy the STG table into other references.
- Before final handoff, apply `references/validation-rules.md`; validate JSON/YAML artifacts with `scripts/validate_n260_output.py` when a file artifact is available.
- Select mode and evidence tier using `references/mode-input-tier-matrix.md`; never silently promote minimal inputs into full workflow readiness.
- Map every internal category to a default STG tag using `references/classification-to-stg-map.md`.
- Emit N005 signals only when `references/signal-thresholds.md` thresholds are met.
- Validate Markdown and CSV artifacts with `scripts/validate_n260_output.py`; use `references/artifact-frontmatter-contract.md` for required frontmatter and CSV metadata conventions.
- Use the validator domain profile inferred from `metadata.skill_id` or passed with `--skill`; for final handoff, run with `--domain-mode strict` when a machine-readable artifact is available.
- Track `STG-UNMAPPED` usage. If it exceeds thresholds in `references/signal-thresholds.md`, keep readiness no stronger than `constrained` and raise the configured feedback signal.
- Treat validator script version `3.1.3` as the governance implementation version for this package.
- For final handoff with multi-artifact composition, run `scripts/validate_n260_output.py --cross-validate <artifact_dir> --domain-mode complete`; after editing STG maps, run `scripts/validate_n260_output.py --validate-stg-map .`; use `--exclude PATTERN` for archive folders and `--complete-min N` only when a stricter/lighter final handoff threshold is intentionally required.

