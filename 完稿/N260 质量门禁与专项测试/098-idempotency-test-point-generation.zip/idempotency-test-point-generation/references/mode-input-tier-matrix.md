# Mode x input tier matrix v3.1

## Purpose
Prevent mode and input-tier ambiguity. `selected_mode` is the work style; input tier is the evidence depth. They are related but not synonyms.

| selected_mode | input tier | rule |
|---|---|---|
| `http_only` | `minimal_inputs` | Allowed. One endpoint plus key behavior expectation is enough. |
| `http_only` | `workflow_inputs` | Allowed. Use idempotency design, API specs, error codes, and related concurrency refs. |
| `http_only` | `enhancement_inputs` | Optional. Use TTL/store details and incident history. |
| `multi_channel` | `minimal_inputs` | Not sufficient. Generate a channel inventory template and mark missing consumers/webhooks. |
| `multi_channel` | `workflow_inputs` | Required. Include API specs, message/webhook/scheduler channels, error codes, and storage layers. |
| `multi_channel` | `enhancement_inputs` | Recommended. Use broker retry policy, webhook signature policy, and replay history. |
| `chaos_mode` | `minimal_inputs` | Not sufficient for execution. Produce conceptual tests only. |
| `chaos_mode` | `workflow_inputs` | Required. Include store failure behavior, retry policy, and expected duplicate outcome. |
| `chaos_mode` | `enhancement_inputs` | Required for executable plan. Include chaos tooling, store topology, and recovery metrics. |

## Enforcement
- If the requested mode is not legal for the available input tier, either downgrade the mode or mark the result `insufficient_evidence`.
- Never silently promote minimal inputs into a full workflow claim.
- Record the chosen mode and input tier in `metadata.selected_mode` and `metadata.evidence_profile.input_completeness`.
