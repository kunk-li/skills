# N260 cross-skill orchestration contract v3.1.3

## Purpose
Coordinate the seven N260 skills so each skill remains independently useful while the combined node output becomes stronger, non-duplicative, and machine-readable.

## Single source of STG ownership
This file is the single source of truth for shared scenario ownership tags. Other reference files must link here instead of copying the table.

## Execution order
1. Run specialty producers in parallel when inputs are available: 095 data consistency, 096 permission, 097 concurrency, 098 idempotency, and 099 performance.
2. Run 093 quality-gate-check after upstream evidence and specialty summaries are available. 093 consumes summaries and blocker states; it does not regenerate specialty test rows.
3. Run 094 pre-launch-checklist-generation as an operational readiness meta-check. 094 consumes 093 verdict and 095-099 completion/evidence state; it does not duplicate specialty assertions.
4. Re-run 093 if 094 identifies a release-blocking readiness issue that should alter the final release handoff.

## Canonical ownership rules
- 093 owns final quality gate verdict: `go`, `conditional`, `no_go`.
- 094 owns operational readiness status: `ready`, `ready_with_conditions`, `not_ready`.
- 095 owns data invariants, reconciliation, and recovery.
- 096 owns authorization and permission test coverage.
- 097 owns concurrency mechanics: simultaneous execution, lock/isolation/deadlock, and race triggering.
- 098 owns idempotency outcome semantics: key behavior, payload equivalence, TTL, duplicate/retry/webhook/message handling.
- 099 owns performance SLO, capacity, regression, bottleneck, and soak evidence.

## 093 aggregation inputs
093 must accept the following same-node summaries when present:
- `n094_checklist_summary`: operational readiness, blockers, signoffs, time windows, missing evidence.
- `n095_consistency_summary`: data consistency readiness, open drift, reconciliation coverage, recovery gaps.
- `n096_permission_summary`: authz matrix coverage, IDOR/SOD/escalation outcomes, sensitive data masking evidence.
- `n097_concurrency_summary`: race coverage, deadlock/isolation results, stability repeats, flaky risk.
- `n098_idempotency_summary`: duplicate outcome coverage, TTL/store degradation, channel coverage, replay risk.
- `n099_performance_summary`: SLO pass/fail, regression delta, capacity baseline, bottleneck and soak evidence.

## Verdict separation
- 093 `final_verdict` is the quality gate decision and is authoritative for release gating.
- 094 `operational_readiness_status` is a readiness meta-status and must not be called the final gate decision.
- When 094 finds operational blockers after 093 has produced `go`, the handoff should be `go_with_launch_blocker` until 093 re-evaluates or the blocker closes.

## De-duplication requirements
Every specialty row should include:
- `shared_scenario_tag`
- `ownership_role: canonical | supporting | duplicate_reference`
- `canonical_owner_skill`
- `related_specialty_refs[]`
- `deduplicated_links[]`

If two rows test the same assertion, keep the canonical row and convert the other row into a supporting link. Never count duplicate-linked rows twice in 093 weighted score.

## Shared scenario ownership tags

| shared_scenario_tag | canonical owner | non-owner behavior |
|---|---|---|
| `STG-QUALITY-GATE-ROLLUP` | 093 quality-gate-check | Other skills expose summaries and blocker state only. |
| `STG-LAUNCH-READINESS-META` | 094 pre-launch-checklist-generation | Other skills provide completion/evidence state; 094 tracks owner, time window, signoff. |
| `STG-DATA-REFERENTIAL-INTEGRITY` | 095 data-consistency-check-item-generation | Other skills link only if permission or concurrency triggers affect the data check. |
| `STG-DATA-AGGREGATE-INVARIANT` | 095 data-consistency-check-item-generation | 097 may supply race trigger; 098 may supply duplicate trigger; 095 owns invariant and reconciliation. |
| `STG-DATA-STATE-MACHINE-INVARIANT` | 095 data-consistency-check-item-generation | 097 owns concurrent transition trigger; 095 owns legal state and repair/reconciliation. |
| `STG-AUTHZ-MATRIX-IDOR-SOD` | 096 permission-test-point-generation | 094 references completion as signoff evidence; 093 aggregates result only. |
| `STG-CONCURRENCY-RACE-MECHANICS` | 097 concurrency-test-point-generation | 098 links duplicate-key outcome; 095 links data invariant impacted by race. |
| `STG-CONCURRENCY-SAME-KEY-TRIGGER` | 097 concurrency-test-point-generation | 097 owns simultaneous execution/barrier design; 098 owns idempotent outcome. |
| `STG-IDEMPOTENCY-KEY-OUTCOME` | 098 idempotency-test-point-generation | 097 must not duplicate expected key conflict semantics; it links to 098. |
| `STG-IDEMPOTENCY-PAYLOAD-EQUIVALENCE` | 098 idempotency-test-point-generation | 095 may reference semantic data implications but does not regenerate key tests. |
| `STG-PERFORMANCE-SLO-CAPACITY` | 099 performance-test-scenario-generation | 094 tracks readiness evidence; 097 only owns correctness under concurrency. |
| `STG-PERFORMANCE-REGRESSION` | 099 performance-test-scenario-generation | 093 may hard-veto release from summarized regression status. |

## 097 vs 099 boundary summary
- Use 097 when the primary assertion is correctness under concurrent execution: one winner, no oversell, no lost update, lock ordering, deadlock handling, isolation anomaly, or final state correctness.
- Use 099 when the primary assertion is performance under sustained traffic: p95/p99, throughput, error rate, capacity ceiling, autoscaling behavior, soak drift, or regression against baseline.
- If the same tool such as k6 is used, classify by assertion and duration, not by tool name. 097 typically uses synchronized race bursts and repeated correctness trials; 099 uses ramp/hold traffic profiles and SLO measurement windows.

## N005 signal threshold summary
Emit feedback to N005 only when at least one quantified threshold in `signal-thresholds.md` is met. Otherwise keep the finding local in `downstream_handoff` or `human_review_queue[]`.


## v3.1.3 cross-artifact validation
Before combining outputs from multiple N260 skills, run:

```bash
python scripts/validate_n260_output.py --cross-validate <artifact_dir>
```

The scan fails when the same STG tag is marked `ownership_role: canonical` by more than one skill. Multiple canonical rows from the same skill are allowed when they represent distinct rows within that skill's owned domain.


## v3.1.3 P6 validation additions

For final multi-artifact composition, run:

```bash
python scripts/validate_n260_output.py --cross-validate <artifact_dir> --exclude ".archive/**" --exclude "fixtures/**"
```

The validator now also compares each row's `canonical_owner_skill` against the canonical owner in this file. If a non-owner skill marks a canonical row for another skill's STG tag, the scan must fail.
