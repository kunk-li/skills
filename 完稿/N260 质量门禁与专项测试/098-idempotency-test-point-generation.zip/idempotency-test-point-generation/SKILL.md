---
name: idempotency-test-point-generation
description: Generate idempotency test points for retry safety, same-key semantics, payload conflicts, TTL boundaries, webhook replay, and message redelivery; owns duplicate side effects, links to concurrency.
---
# idempotency-test-point-generation


## Idempotency test routing table

| Situation | Action |
|---|---|
| HTTP POST/PUT operation | Generate replay test (same request × 3); check single side-effect |
| Message queue consumer | Generate duplicate message delivery test |
| Multi-channel delivery | Generate cross-channel replay test (HTTP + queue) |
| TTL-based idempotency key | Generate TTL boundary test (replay before and after expiry) |
| Distributed transaction | Generate partial failure and retry with idempotency guarantee |


## Idempotency routing decision table

| Situation | Action |
|---|---|
| HTTP POST/PUT | Generate replay test (same request × 3); verify single side-effect |
| Message queue consumer | Generate duplicate message delivery test |
| Multi-channel delivery | Generate cross-channel replay (HTTP + queue) |
| TTL-based idempotency key | Generate TTL boundary test (before and after expiry) |
| Distributed transaction | Generate partial-failure + retry with idempotency guarantee |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n260.idempotency-test.v2.2"
contract_version: "n260.specialty.v2.2"
workflow_node: "N260"
node_artifact_target: "幂等测试点.csv"
function_bias: "analysis"
```


## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 幂等测试点.csv. It delivers the idempotency specialty artifact for N260.

### Boundary
- Own duplicate-request, retry, TTL, multi-channel, and degraded-store idempotency cases.
- Consume idempotency design and test assets rather than restating API contracts generically.
- Do not reduce the topic to same-key/same-payload only; handle degraded and non-HTTP channels too.
- Make timeout and retry realism explicit where possible.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `http_only`: focus on HTTP APIs and request-key semantics.
- `multi_channel`: cover HTTP, consumer, webhook, scheduler, and saga-step idempotency surfaces.
- `chaos_mode`: combine retry and duplicate behavior with network disturbance or store outages.



## v2 reactive contract

> Full reactive contract spec (schema_version, governance_revision, produces_event, routing_keywords,
> signal_emission, human_review_sla, canonical_function) is in
> `references/n260-v2-reactive-contract.md`.

## Cross-skill integration map

| 上游 skill | 提供给 098 | 用途 |
|---|---|---|
| API/事件设计文档 | `idempotency_key_spec` | 幂等键规范是测试点的基础 |
| 097 concurrency-test-point-generation | 并发场景 | 并发+幂等交叉验证 |

| 下游 skill | 098 输出 | 如何使用 |
|---|---|---|
| 093 quality-gate-check | `idempotency_test_results` | 门禁的幂等性维度 |
| 086 api-test-script-generation | `idempotency_test_points[]` | 幂等点转为 API 重试测试脚本 |
| 095 data-consistency-check-item-generation | `idempotency_keys` | 幂等键一致性是数据一致性子集 |

**工作流位置**: 接口设计 → **098 幂等测试点** → 086 脚本/093 门禁。

## Standalone usage guide

**Minimum input:** an operation name (e.g., "place order", "process refund") — no API spec required.

**Standalone idempotency test generation:**
1. Infer idempotency key strategy from operation name (order_id, request_id, etc.).
2. Always include a replay scenario (same request × 3) and a TTL boundary if applicable.
3. Mark inferred key strategy as `key_strategy: inferred`.

**Minimum viable output:**
```yaml
idempotency_test_points:
  readiness: constrained
  key_strategy: inferred
  pending_spec_confirmation: true
  items:
    - tp_id: ITP-001
      operation: place_order
      scenario: replay_same_request
      idempotency_key: order_id (inferred)
      test: POST /orders × 3 with same payload → only 1 order created
      expect: 2nd and 3rd return 200 with same order_id
    - tp_id: ITP-002
      scenario: ttl_boundary
      test: Submit after idempotency key TTL expires → treated as new request
      pending_ttl_value_confirmation: true
```

## v3.1.3 P6 governance enforcement

See `references/n260-p6-governance.md` for the full governance enforcement rules (validator usage, STG mapping, signal thresholds, cross-validate commands).

## Input tiers / input tiers
### minimal_inputs
Accept an idempotency key rule, retry policy, webhook/message event id, or duplicate-risk API. Generate key, payload, TTL, and duplicate-outcome rows with unknowns marked.

### workflow_inputs
Prefer idempotency design, API specs, error codes, TTL policy, dedup storage, message/webhook/scheduler definitions, concurrency summary, and data consistency summary.

### enhancement_inputs
Use store outage history, duplicate-event history, retry storm incidents, network fault tooling, and downstream side-effect inventory.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 幂等设计建议.md
- 消息消费者定义
- webhook contracts
- scheduler retry policy
- TTL policy
- network fault tooling
- duplicate-event history

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `channel_scope_summary`
- `idempotency_test_patterns[]`
- `ttl_boundary_tests[]`
- `network_simulation_plan`
- `channel_coverage[]`
- `negative_case_matrix[]`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `payload_equivalence`
- `duplicate_outcome`
- `related_concurrency_ref`
- `related_consistency_ref`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


> `metadata` field requirements: see `references/n260-v2-reactive-contract.md`.



## Ownership and de-duplication / ownership and de-duplication
- Own idempotency outcome semantics: same-key/same-payload, same-key/different-payload, in-progress behavior, TTL expiry, degraded store, replay, redelivery, and duplicate side effects.
- For concurrent same-key rows, link to 097 for trigger mechanics and keep 098 as the canonical owner of expected duplicate outcome.
- For data invariants after duplicate prevention, link to 095 rather than regenerating reconciliation rows.
- Use `payload_equivalence` to separate idempotency semantics from generic data validation.

## Design rules / design rules
- Cover same-key same-payload, same-key different-payload, missing-key, invalid-key, TTL, degraded-store, concurrent duplicate, and timeout-retry cases.
- Treat HTTP, message, webhook, scheduler, and saga-step surfaces separately when they exist.
- Use realistic network or timeout simulation whenever retry safety depends on transport behavior.
- State what the canonical duplicate outcome should be: replay, reject, or reprocess.
- Mark any shared overlap with concurrency or data-consistency checks through shared IDs.

## Execution workflow / execution workflow
1. Read idempotency design, retry assumptions, testcase assets, and channel context.
2. Choose HTTP-only or multi-channel framing and map required patterns.
3. Add TTL boundary and degraded-store cases, then specify network simulation where valuable.
4. Define the expected outcome for each duplicate or retry pattern.
5. Emit gate-ready idempotency rows and downstream handoff for release and operations.

## Dynamic completeness / dynamic completeness
- Simple synchronous APIs can stay HTTP-focused; webhooks, consumers, and sagas require multi-channel coverage.
- If TTL policy is unknown, keep explicit open questions rather than assuming expiry behavior.
- If store-availability assumptions are weak, separate strong claims from exploratory chaos cases.



## Example usage

**Input**: payment charge endpoint with `idempotency_key` header; retry-on-timeout scenario.

**Output** (excerpt):
```yaml
idempotency_test_points:
  - tp_id: ITP-001
    operation: POST /payments/charge
    scenario: same_key_same_payload_retry
    description: Submit charge with key K1; simulate timeout; retry with same K1 and payload
    expected: second response returns same payment_id as first; no duplicate charge
    priority: P0
  - tp_id: ITP-002
    operation: POST /payments/charge
    scenario: same_key_different_payload
    description: Submit charge with K1 amount=100; retry with K1 amount=200
    expected: 422 or conflict response — key conflict detected
    priority: P0
  - tp_id: ITP-003
    operation: POST /payments/charge
    scenario: expired_key_reuse
    description: Reuse K1 after TTL expiry
    expected: treated as new request; new payment_id generated
    priority: P1
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Resilience and governance addendum

**Produced events**: Emit `produced_event: produced.n260.idempotency_test_points` in metadata when the artifact is complete or materially updated. Also emit `signal.n260.idempotency_gap` to N005 feedback loop when quantified thresholds in `references/signal-thresholds.md` are met.

**Confidence scoring**: Include `evidence_confidence: high/medium/low` in each item or dimension. Items with `evidence_confidence: low` must be flagged for `human_review_required: true` and must not be counted as passed in the quality gate.

**Circuit breaker**: circuit_breaker triggers when retry-safety test points for a critical endpoint are absent across 3 consecutive releases.

**Traceability**: Every item must carry `canonical_owner_skill` and a reference to the upstream artifact or evidence id that produced it, enabling end-to-end traceability from requirement through to gate verdict in N270 and N280.

**Escalation path**: When `readiness: blocked` on any P0 item, escalate immediately to the release manager and the owning team lead. Log the escalation in `downstream_handoff.escalation_log[]`.

## Auditable rules summary

- R01_scope_grounded: every idempotency test point must reference a specific table, endpoint, field, or service; on_violation: reject.
- R02_ownership_tagged: each item must carry `canonical_owner_skill` and `shared_scenario_tag` when overlap with another N260 skill exists; on_violation: reject.
- R03_evidence_slot: every item must have an evidence or verification field; on_violation: reject.
- R04_no_duplication: deduplicate against items from other N260 skills using STG tags; on_violation: merge_or_reference.
- R05_priority_declared: every item must have a priority (P0/P1/P2); on_violation: assign_default.
- R06_replay_safety_verified: every idempotency test point must include a replay scenario (same request, multiple times); on_violation: add_replay.
- R07_ttl_boundary_covered: for idempotency keys with TTL, boundary cases at key expiry must be included; on_violation: add_ttl_boundary.

## Algorithm

1. Parse inputs and identify scope: retry safety, same-key semantic, payload conflict, TTL boundary, or duplicate submission.
2. For each scope item, generate test points with owner tag (R02).
3. Assign evidence slot (R03) and priority (R05).
4. Deduplicate against other N260 skills using STG map (R04).
5. Validate each item references a specific artifact (R01).
6. Emit `test_points[]`, `ownership_map`, `dedup_log`.
7. Run `self_check`; set `readiness: blocked` if R01, R02, or R03 fires.

## Quality bar / quality bar
A good artifact makes duplicate handling expectations unambiguous, degraded cases explicit, and retry behavior believable under real transport conditions.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本（如 `n260.quality-gate-check.v2.2`），仅本 skill 字段变更时递增；
`governance_revision: "3.1.3"` — N260 组共享的 P6 治理框架修订号，修改 `n260-p6-governance.md` 时递增。
三套版本号独立变更，语义见 `references/n260-v2-reactive-contract.md`。

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/idempotency-key-patterns.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## Usage scenarios

- `retry_safety_sweep`: verify idempotency for all retry-capable operations.
- `ttl_boundary`: test idempotency key expiry edge cases.
- `multi_channel_replay`: test same operation via different channels.
- `distributed_coordination`: idempotency in distributed transaction flows.
