---
name: idempotency-test-point-generation
description: generate standalone or n260-composable idempotency test points for retry safety, same-key semantics, payload conflicts, ttl boundaries, degraded redis or db unique fallback, concurrent duplicate outcomes, webhook replay, message redelivery, and scheduler reentry. use when duplicate side effects or retry behavior must be owned by idempotency while race mechanics are linked to concurrency.
---
# idempotency-test-point-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 幂等测试点.csv. It delivers the idempotency specialty artifact for N260.

### Boundary
- Own duplicate-request, retry, TTL, multi-channel, and degraded-store idempotency cases.
- Consume idempotency design and test assets rather than restating API contracts generically.
- Do not reduce the topic to same-key/same-payload only; handle degraded and non-HTTP channels too.
- Make timeout and retry realism explicit where possible.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `http_only`: focus on HTTP APIs and request-key semantics.
- `multi_channel`: cover HTTP, consumer, webhook, scheduler, and saga-step idempotency surfaces.
- `chaos_mode`: combine retry and duplicate behavior with network disturbance or store outages.



## v2 reactive contract / v2 reactive contract
This skill is optimized for v2 reactive workflow and must remain useful both standalone and inside N260 composition.

```yaml
reactive_contract:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  produces_event: produced.n260.idempotency_test_points
  routing_keywords: ['n260', 'idempotency', 'retry-safety', 'dedup', 'same-key', 'ttl-boundary', 'webhook-replay', 'message-redelivery']
  signal_emission_to_n005: ['idempotency_conflict', 'duplicate_side_effect', 'retry_safety_gap', 'dedup_store_gap']
  human_review_sla: "P0 for duplicate money, duplicate entitlement, duplicate external call, or replay attack risk; P1 for incomplete TTL/store evidence; P2 for noncritical retry coverage"
  canonical_function: retry_safety_and_dedup_validation
```

- Owns duplicate-request outcomes, key semantics, payload equivalence, TTL, degraded idempotency storage, retry, webhook replay, message redelivery, and cross-channel dedup behavior.
- Always include `shared_scenario_tag`, `ownership_role`, and `canonical_owner_skill` when there is overlap with another N260 skill.
- Emit `produces_event` when the artifact is complete or materially updated.
- Emit N005 feedback signals only when quantified thresholds in `references/signal-thresholds.md` are met; otherwise keep findings local in `downstream_handoff`.



## v3.1.3 P6 governance enforcement
- Treat `references/cross-skill-orchestration.md` as the single source of truth for STG ownership tags; do not copy the STG table into other references.
- Before final handoff, apply `references/validation-rules.md`; validate JSON/YAML artifacts with `scripts/validate_n260_output.py` when a file artifact is available.
- Select mode and evidence tier using `references/mode-input-tier-matrix.md`; never silently promote minimal inputs into full workflow readiness.
- Map every internal category to a default STG tag using `references/classification-to-stg-map.md`.
- Emit N005 signals only when `references/signal-thresholds.md` thresholds are met.
- Validate Markdown and CSV artifacts with `scripts/validate_n260_output.py`; use `references/artifact-frontmatter-contract.md` for required frontmatter and CSV metadata conventions.
- Use the validator domain profile inferred from `metadata.skill_id` or passed with `--skill`; for final handoff, run with `--domain-mode strict` when a machine-readable artifact is available.
- Track `STG-UNMAPPED` usage. If it exceeds thresholds in `references/signal-thresholds.md`, keep readiness no stronger than `constrained` and raise the configured feedback signal.
- Treat validator script version `3.1.3` as the governance implementation version for this package.
- For final handoff with multi-artifact composition, run `scripts/validate_n260_output.py --cross-validate <artifact_dir> --domain-mode complete`; after editing STG maps, run `scripts/validate_n260_output.py --validate-stg-map .`; use `--exclude PATTERN` for archive folders and `--complete-min N` only when a stricter/lighter final handoff threshold is intentionally required.

## Input tiers / input tiers
### minimal_inputs
Accept an idempotency key rule, retry policy, webhook/message event id, or duplicate-risk API. Generate key, payload, TTL, and duplicate-outcome rows with unknowns marked.

### workflow_inputs
Prefer idempotency design, API specs, error codes, TTL policy, dedup storage, message/webhook/scheduler definitions, concurrency summary, and data consistency summary.

### enhancement_inputs
Use store outage history, duplicate-event history, retry storm incidents, network fault tooling, and downstream side-effect inventory.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 幂等设计建议.md
- 消息消费者定义
- webhook contracts
- scheduler retry policy
- TTL policy
- network fault tooling
- duplicate-event history

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `channel_scope_summary`
- `idempotency_test_patterns[]`
- `ttl_boundary_tests[]`
- `network_simulation_plan`
- `channel_coverage[]`
- `negative_case_matrix[]`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `payload_equivalence`
- `duplicate_outcome`
- `related_concurrency_ref`
- `related_consistency_ref`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: retry_safety_and_dedup_validation`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.idempotency_test_point_generation`
- `workflow_node: N260`
- `node_artifact_target: 幂等测试点.csv`
- `evidence_profile`
- `tool_collaboration_mode`
- `schema_version: 2.1`
- `governance_revision: 3.1.3`
- `event_contract.produces_event`
- `routing.intent_tags`
- `routing.routing_keywords`
- `signal_emission.to_n005`
- `human_review.sla_priority`
- `schema_evolution.compatibility`



## Ownership and de-duplication / ownership and de-duplication
- Own idempotency outcome semantics: same-key/same-payload, same-key/different-payload, in-progress behavior, TTL expiry, degraded store, replay, redelivery, and duplicate side effects.
- For concurrent same-key rows, link to 097 for trigger mechanics and keep 098 as the canonical owner of expected duplicate outcome.
- For data invariants after duplicate prevention, link to 095 rather than regenerating reconciliation rows.
- Use `payload_equivalence` to separate idempotency semantics from generic data validation.

## Design rules / design rules
- Cover same-key same-payload, same-key different-payload, missing-key, invalid-key, TTL, degraded-store, concurrent duplicate, and timeout-retry cases.
- Treat HTTP, message, webhook, scheduler, and saga-step surfaces separately when they exist.
- Use realistic network or timeout simulation whenever retry safety depends on transport behavior.
- State what the canonical duplicate outcome should be: replay, reject, or reprocess.
- Mark any shared overlap with concurrency or data-consistency checks through shared IDs.

## Execution workflow / execution workflow
1. Read idempotency design, retry assumptions, testcase assets, and channel context.
2. Choose HTTP-only or multi-channel framing and map required patterns.
3. Add TTL boundary and degraded-store cases, then specify network simulation where valuable.
4. Define the expected outcome for each duplicate or retry pattern.
5. Emit gate-ready idempotency rows and downstream handoff for release and operations.

## Dynamic completeness / dynamic completeness
- Simple synchronous APIs can stay HTTP-focused; webhooks, consumers, and sagas require multi-channel coverage.
- If TTL policy is unknown, keep explicit open questions rather than assuming expiry behavior.
- If store-availability assumptions are weak, separate strong claims from exploratory chaos cases.

## Quality bar / quality bar
A good artifact makes duplicate handling expectations unambiguous, degraded cases explicit, and retry behavior believable under real transport conditions.

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/idempotency-key-patterns.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`