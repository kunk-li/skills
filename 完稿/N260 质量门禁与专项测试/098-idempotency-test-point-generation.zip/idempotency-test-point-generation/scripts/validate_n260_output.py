#!/usr/bin/env python3
"""Validate a N260 v3.1.3 machine-readable or frontmatter artifact.

Usage:
    python scripts/validate_n260_output.py artifact.json
    python scripts/validate_n260_output.py --skill quality-gate-check artifact.yaml
    python scripts/validate_n260_output.py --domain-mode complete artifact.md
    python scripts/validate_n260_output.py --validate-stg-map .
    python scripts/validate_n260_output.py --cross-validate ./artifacts --exclude ".archive/**"
    python scripts/validate_n260_output.py --domain-mode complete --complete-min 3 artifact.md
    python scripts/validate_n260_output.py --version

Supported artifact formats:
    - JSON object
    - YAML object, including simple list-style YAML without PyYAML
    - Markdown with YAML frontmatter
    - CSV with metadata columns or metadata.* columns

The script validates common N260 governance fields, STG de-duplication fields,
STG-UNMAPPED thresholds, optional skill-specific domain sections, STG-map
integrity, and cross-artifact canonical ownership conflicts, canonical owner mismatches, and optional exclude patterns.
"""
from __future__ import annotations

import argparse
import fnmatch
import csv
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

__version__ = "3.1.3"
EXPECTED_SCHEMA_VERSION = "2.1"
EXPECTED_GOVERNANCE_REVISION = "3.1.3"

REQUIRED_METADATA = [
    "schema_version",
    "governance_revision",
    "skill_id",
    "workflow_node",
    "selected_mode",
    "readiness",
    "evidence_profile",
    "routing",
    "event_contract",
    "signal_emission",
    "human_review",
    "schema_evolution",
]
REQUIRED_ITEM_FIELDS = [
    "shared_scenario_tag",
    "ownership_role",
    "canonical_owner_skill",
    "related_specialty_refs",
    "deduplicated_links",
]
VALID_READINESS = {"pass", "constrained", "blocked", "insufficient_evidence"}
VALID_OWNERSHIP = {"canonical", "supporting", "duplicate_reference"}
SUPPORTED_SUFFIXES = {".json", ".yaml", ".yml", ".md", ".markdown", ".csv"}

DOMAIN_PROFILES = {
    "quality-gate-check": {
        "event": "produced.n260.quality_gate_check",
        "sections_any": ["gate_summary", "quality_gate", "gate_dimensions", "blocker_registry", "aggregation_algorithm", "final_verdict"],
        "item_fields_any": ["dimension_id", "verdict", "source_evidence"],
        "complete_min_sections": 2,
        "complete_min_item_fields": 2,
    },
    "pre-launch-checklist-generation": {
        "event": "produced.n260.pre_launch_checklist",
        "sections_any": ["pre_launch_checklist", "operational_readiness_status", "meta_check_items", "specialty_readiness_refs", "completion_summary"],
        "item_fields_any": ["blocking", "owner", "evidence_ref", "signoff_required"],
        "complete_min_sections": 2,
        "complete_min_item_fields": 2,
    },
    "data-consistency-check-item-generation": {
        "event": "produced.n260.data_consistency_checks",
        "sections_any": ["consistency_checks", "data_consistency_checks", "reconciliation_mechanism", "recovery_mechanism"],
        "item_fields_any": ["dimension", "reconciliation_mechanism", "verification_query", "recovery_mechanism"],
        "complete_min_sections": 2,
        "complete_min_item_fields": 2,
    },
    "permission-test-point-generation": {
        "event": "produced.n260.permission_test_points",
        "sections_any": ["permission_tps", "permission_test_points", "role_matrix", "idor_tests", "token_tests"],
        "item_fields_any": ["permission_test_kind", "resource", "action", "expected_behavior", "audit_required"],
        "complete_min_sections": 2,
        "complete_min_item_fields": 2,
    },
    "concurrency-test-point-generation": {
        "event": "produced.n260.concurrency_test_points",
        "sections_any": ["concurrency_tps", "concurrency_test_points", "scenario_tests", "timing_tests"],
        "item_fields_any": ["scenario_classification", "coordination_primitive", "concurrency_level", "correctness_assertion"],
        "complete_min_sections": 2,
        "complete_min_item_fields": 2,
    },
    "idempotency-test-point-generation": {
        "event": "produced.n260.idempotency_test_points",
        "sections_any": ["idempotency_tps", "idempotency_test_points", "idempotency_test_scenarios", "conflict_handling_tests"],
        "item_fields_any": ["idempotency_design_ref", "duplicate_outcome", "payload_equivalence", "idempotency_key_scope"],
        "complete_min_sections": 2,
        "complete_min_item_fields": 2,
    },
    "performance-test-scenario-generation": {
        "event": "produced.n260.performance_scenarios",
        "sections_any": ["perf_test_scenarios", "performance_scenarios", "slo_validation", "capacity_baseline"],
        "item_fields_any": ["test_kind", "target_slo", "load_configuration", "regression_detection"],
        "complete_min_sections": 2,
        "complete_min_item_fields": 2,
    },
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate a N260 v3.1.3 artifact")
    parser.add_argument("artifact", nargs="?", help="artifact file to validate")
    parser.add_argument("--skill", dest="skill_id", help="expected skill_id profile")
    parser.add_argument(
        "--domain-mode",
        choices=["off", "warn", "strict", "complete"],
        default="warn",
        help="how to enforce skill-specific domain sections",
    )
    parser.add_argument(
        "--strict-unmapped",
        action="store_true",
        help="fail if STG-UNMAPPED exceeds the governance threshold",
    )
    parser.add_argument(
        "--validate-stg-map",
        nargs="?",
        const=".",
        help="validate references/classification-to-stg-map.md against the canonical STG table in references/cross-skill-orchestration.md",
    )
    parser.add_argument(
        "--cross-validate",
        metavar="DIR",
        help="scan a directory of N260 artifacts and fail on cross-skill canonical STG ownership conflicts",
    )
    parser.add_argument(
        "--exclude",
        action="append",
        default=[],
        help="glob pattern to exclude during --cross-validate, matched against relative path and filename; repeatable",
    )
    parser.add_argument(
        "--complete-min",
        type=int,
        default=None,
        help="override complete domain threshold for both section and item-field hit counts",
    )
    parser.add_argument("--version", action="store_true", help="print validator version and exit")
    return parser.parse_args()


def strip_quotes(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and ((value[0] == value[-1] == '"') or (value[0] == value[-1] == "'")):
        return value[1:-1]
    return value


def coerce_scalar(value: Any) -> Any:
    if value is None:
        return value
    if not isinstance(value, str):
        return value
    text = strip_quotes(value.strip())
    if text == "":
        return text
    if text.lower() in {"true", "false"}:
        return text.lower() == "true"
    if text.lower() in {"null", "none"}:
        return None
    if text.startswith("[") or text.startswith("{"):
        try:
            return json.loads(text)
        except Exception:
            return text
    if "," in text and not text.startswith("http"):
        return [part.strip() for part in text.split(",") if part.strip()]
    return text


def _clean_yaml_lines(text: str) -> list[tuple[int, str]]:
    lines: list[tuple[int, str]] = []
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        lines.append((indent, raw.strip()))
    return lines


def simple_yaml_load(text: str) -> Any:
    """Small YAML fallback for common N260 frontmatter artifacts.

    Supports nested mappings, list-of-scalars, and list-of-mappings. It is not
    a full YAML implementation, but it is enough for the metadata/items shapes
    used by N260 artifacts when PyYAML is unavailable.
    """
    lines = _clean_yaml_lines(text)
    idx = 0

    def parse_block(indent: int) -> Any:
        nonlocal idx
        if idx >= len(lines):
            return {}
        current_indent, current_text = lines[idx]
        if current_indent < indent:
            return {}
        if current_text.startswith("-"):
            result: list[Any] = []
            while idx < len(lines):
                line_indent, line_text = lines[idx]
                if line_indent != indent or not line_text.startswith("-"):
                    break
                rest = line_text[1:].strip()
                idx += 1
                if rest == "":
                    if idx < len(lines) and lines[idx][0] > indent:
                        result.append(parse_block(lines[idx][0]))
                    else:
                        result.append(None)
                elif ":" in rest:
                    item: dict[str, Any] = {}
                    key, value = rest.split(":", 1)
                    key = strip_quotes(key.strip())
                    value = value.strip()
                    if value:
                        item[key] = coerce_scalar(value)
                    else:
                        if idx < len(lines) and lines[idx][0] > indent:
                            item[key] = parse_block(lines[idx][0])
                        else:
                            item[key] = {}
                    while idx < len(lines) and lines[idx][0] > indent:
                        continuation = parse_block(lines[idx][0])
                        if isinstance(continuation, dict):
                            item.update(continuation)
                        else:
                            item.setdefault("value", continuation)
                    result.append(item)
                else:
                    result.append(coerce_scalar(rest))
            return result
        result: dict[str, Any] = {}
        while idx < len(lines):
            line_indent, line_text = lines[idx]
            if line_indent < indent or line_text.startswith("-"):
                break
            if line_indent > indent:
                # Stray nested block; consume conservatively.
                nested = parse_block(line_indent)
                if isinstance(nested, dict):
                    result.update(nested)
                continue
            if ":" not in line_text:
                idx += 1
                continue
            key, value = line_text.split(":", 1)
            key = strip_quotes(key.strip())
            value = value.strip()
            idx += 1
            if value:
                result[key] = coerce_scalar(value)
            else:
                if idx < len(lines) and lines[idx][0] > line_indent:
                    result[key] = parse_block(lines[idx][0])
                else:
                    result[key] = {}
        return result

    if not lines:
        return None
    return parse_block(lines[0][0])


def load_yaml(text: str) -> Any:
    if yaml is not None and os.environ.get("N260_FORCE_SIMPLE_YAML") != "1":
        return yaml.safe_load(text)
    return simple_yaml_load(text)


def set_nested(target: dict[str, Any], dotted_key: str, value: Any) -> None:
    parts = dotted_key.split(".")
    cur = target
    for part in parts[:-1]:
        cur = cur.setdefault(part, {})
    cur[parts[-1]] = value


def parse_markdown(text: str) -> dict[str, Any]:
    if not text.startswith("---"):
        raise ValueError("Markdown artifacts must start with YAML frontmatter")
    lines = text.splitlines()
    end = None
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            end = idx
            break
    if end is None:
        raise ValueError("Markdown frontmatter closing --- not found")
    fm_text = "\n".join(lines[1:end])
    fm = load_yaml(fm_text) or {}
    if not isinstance(fm, dict):
        raise ValueError("Markdown frontmatter must be a mapping")
    if "metadata" in fm:
        return fm
    return {"metadata": fm}


def parse_csv(path: Path) -> dict[str, Any]:
    with path.open(newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    if not rows:
        raise ValueError("CSV artifact has no rows")
    metadata: dict[str, Any] = {}
    items = []
    if {"key", "value"}.issubset(rows[0].keys()):
        for row in rows:
            key = row.get("key", "").strip()
            if not key:
                continue
            value = coerce_scalar(row.get("value"))
            if key.startswith("metadata."):
                set_nested(metadata, key[len("metadata."):], value)
            elif key in REQUIRED_METADATA or "." in key:
                set_nested(metadata, key, value)
        return {"metadata": metadata, "items": []}
    first = rows[0]
    for key, raw_value in first.items():
        value = coerce_scalar(raw_value)
        if key.startswith("metadata."):
            set_nested(metadata, key[len("metadata."):], value)
        elif key in REQUIRED_METADATA:
            metadata[key] = value
        elif key in {"event_contract.produces_event", "signal_emission.to_n005", "routing.intent_tags", "human_review.sla_priority", "schema_evolution.compatibility"}:
            set_nested(metadata, key, value)
    for row in rows:
        item = {}
        for key, raw_value in row.items():
            if key.startswith("metadata.") or key in REQUIRED_METADATA:
                continue
            item[key] = coerce_scalar(raw_value)
        if any(v not in (None, "") for v in item.values()):
            items.append(item)
    return {"metadata": metadata, "items": items}


def load_doc(path: Path) -> dict[str, Any]:
    suffix = path.suffix.lower()
    text = path.read_text(encoding="utf-8") if suffix != ".csv" else ""
    if suffix == ".json":
        doc = json.loads(text)
    elif suffix in {".yaml", ".yml"}:
        doc = load_yaml(text)
    elif suffix in {".md", ".markdown"}:
        doc = parse_markdown(text)
    elif suffix == ".csv":
        doc = parse_csv(path)
    else:
        raise ValueError("supported formats: .json, .yaml, .yml, .md, .markdown, .csv")
    if not isinstance(doc, dict):
        raise ValueError("artifact root must be an object")
    return doc


def get_items(doc: dict[str, Any]) -> list[Any]:
    for key in ("items", "test_points", "checks", "scenarios", "consistency_checks", "permission_tps", "concurrency_tps", "idempotency_tps", "perf_test_scenarios"):
        val = doc.get(key)
        if isinstance(val, list):
            return val
    return []


def contains_key_deep(obj: Any, wanted: str) -> bool:
    if isinstance(obj, dict):
        if wanted in obj:
            return True
        return any(contains_key_deep(v, wanted) for v in obj.values())
    if isinstance(obj, list):
        return any(contains_key_deep(v, wanted) for v in obj)
    return False


def count_keys_deep(obj: Any, wanted: list[str]) -> set[str]:
    found: set[str] = set()
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in wanted:
                found.add(key)
            found.update(count_keys_deep(value, wanted))
    elif isinstance(obj, list):
        for value in obj:
            found.update(count_keys_deep(value, wanted))
    return found


def validate_common(doc: dict[str, Any], expected_skill: str | None) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    metadata = doc.get("metadata")
    if not isinstance(metadata, dict):
        return ["metadata must be present and must be an object"], warnings
    for field in REQUIRED_METADATA:
        if field not in metadata:
            errors.append(f"metadata.{field} is required")
    if metadata.get("schema_version") != EXPECTED_SCHEMA_VERSION:
        errors.append(f"metadata.schema_version must be {EXPECTED_SCHEMA_VERSION}")
    if metadata.get("governance_revision") != EXPECTED_GOVERNANCE_REVISION:
        errors.append(f"metadata.governance_revision must be {EXPECTED_GOVERNANCE_REVISION}")
    if metadata.get("workflow_node") != "N260":
        errors.append("metadata.workflow_node must be N260")
    if expected_skill and metadata.get("skill_id") != expected_skill:
        errors.append(f"metadata.skill_id must be {expected_skill}")
    readiness = metadata.get("readiness")
    if readiness is not None and readiness not in VALID_READINESS:
        errors.append(f"metadata.readiness must be one of {sorted(VALID_READINESS)}")
    event = metadata.get("event_contract", {}) if isinstance(metadata.get("event_contract"), dict) else {}
    produces_event = event.get("produces_event")
    if not produces_event:
        errors.append("metadata.event_contract.produces_event is required")
    skill_id = expected_skill or metadata.get("skill_id")
    if skill_id in DOMAIN_PROFILES and produces_event and produces_event != DOMAIN_PROFILES[skill_id]["event"]:
        errors.append(f"metadata.event_contract.produces_event must be {DOMAIN_PROFILES[skill_id]['event']}")
    signal = metadata.get("signal_emission", {}) if isinstance(metadata.get("signal_emission"), dict) else {}
    if "to_n005" not in signal:
        errors.append("metadata.signal_emission.to_n005 is required")
    return errors, warnings


def validate_items(doc: dict[str, Any], strict_unmapped: bool) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    items = get_items(doc)
    if not items:
        return errors, warnings
    unmapped_count = 0
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            errors.append(f"items[{idx}] must be an object")
            continue
        for field in REQUIRED_ITEM_FIELDS:
            if field not in item:
                errors.append(f"items[{idx}].{field} is required")
        if item.get("ownership_role") and item.get("ownership_role") not in VALID_OWNERSHIP:
            errors.append(f"items[{idx}].ownership_role must be one of {sorted(VALID_OWNERSHIP)}")
        tag_value = item.get("shared_scenario_tag")
        tags = tag_value if isinstance(tag_value, list) else [tag_value]
        if any(str(tag).strip() == "STG-UNMAPPED" for tag in tags if tag is not None):
            unmapped_count += 1
    if items:
        unmapped_rate = unmapped_count / len(items)
        if unmapped_count > 2 or unmapped_rate > 0.10:
            msg = f"STG-UNMAPPED threshold exceeded: {unmapped_count}/{len(items)} rows ({unmapped_rate:.1%})"
            if strict_unmapped:
                errors.append(msg)
            else:
                warnings.append(msg)
    return errors, warnings


def validate_domain(doc: dict[str, Any], skill_id: str | None, mode: str, complete_min: int | None = None) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if mode == "off" or not skill_id or skill_id not in DOMAIN_PROFILES:
        return errors, warnings
    profile = DOMAIN_PROFILES[skill_id]
    items = get_items(doc)
    section_hits = count_keys_deep(doc, profile["sections_any"])
    item_hits: set[str] = set()
    for item in items:
        if isinstance(item, dict):
            item_hits.update(field for field in profile["item_fields_any"] if field in item)
    has_section = bool(section_hits)
    has_item_field = bool(item_hits)
    if mode in {"warn", "strict"} and not has_section and not has_item_field:
        msg = (
            f"domain profile for {skill_id} expects at least one domain section "
            f"{profile['sections_any']} or item field {profile['item_fields_any']}"
        )
        if mode == "strict":
            errors.append(msg)
        else:
            warnings.append(msg)
    if mode == "complete":
        min_sections = int(complete_min if complete_min is not None else profile.get("complete_min_sections", 2))
        min_item_fields = int(complete_min if complete_min is not None else profile.get("complete_min_item_fields", 2))
        if len(section_hits) < min_sections and len(item_hits) < min_item_fields:
            errors.append(
                f"complete domain profile for {skill_id} requires at least {min_sections} domain sections "
                f"or {min_item_fields} domain item fields; found sections={sorted(section_hits)}, item_fields={sorted(item_hits)}"
            )
    return errors, warnings


def extract_stg_tags(text: str) -> set[str]:
    return set(re.findall(r"`?(STG-[A-Z0-9-]+)`?", text))


def extract_canonical_owner_map(cross_text: str) -> dict[str, str]:
    owners: dict[str, str] = {}
    for line in cross_text.splitlines():
        m = re.match(r"\|\s*`(STG-[^`]+)`\s*\|\s*(?:[0-9]{3}\s+)?([a-z0-9-]+)\s*\|", line)
        if m:
            owners[m.group(1)] = m.group(2)
    return owners


def resolve_references_root(raw: str | Path) -> Path:
    path = Path(raw).resolve()
    candidates = []
    if path.is_file():
        candidates.append(path.parent)
    candidates.extend([path / "references", path, Path(__file__).resolve().parents[1] / "references"])
    for candidate in candidates:
        if (candidate / "cross-skill-orchestration.md").exists() and (candidate / "classification-to-stg-map.md").exists():
            return candidate
    raise ValueError("cannot find references/cross-skill-orchestration.md and references/classification-to-stg-map.md")



def load_canonical_owner_map(root_arg: str | Path | None = None) -> dict[str, str]:
    candidates: list[Path] = []
    if root_arg is not None:
        raw = Path(root_arg)
        candidates.extend([raw, raw / "references", raw.parent if raw.is_file() else raw])
    candidates.append(Path(__file__).resolve().parents[1] / "references")
    for candidate in candidates:
        try:
            refs = resolve_references_root(candidate)
            cross = (refs / "cross-skill-orchestration.md").read_text(encoding="utf-8")
            owners = extract_canonical_owner_map(cross)
            if owners:
                return owners
        except Exception:
            continue
    return {}


def validate_owner_consistency(doc: dict[str, Any], owner_map: dict[str, str]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if not owner_map:
        warnings.append("canonical owner map unavailable; skipped canonical_owner_skill consistency checks")
        return errors, warnings
    metadata = doc.get("metadata") if isinstance(doc, dict) else None
    skill_id = str(metadata.get("skill_id", "")) if isinstance(metadata, dict) else ""
    for idx, item in enumerate(get_items(doc)):
        if not isinstance(item, dict):
            continue
        tag_value = item.get("shared_scenario_tag")
        tags = tag_value if isinstance(tag_value, list) else [tag_value]
        declared_owner = str(item.get("canonical_owner_skill", "")).strip()
        role = str(item.get("ownership_role", "")).strip()
        for raw_tag in tags:
            tag = str(raw_tag).strip()
            if not tag or tag == "STG-UNMAPPED":
                continue
            expected_owner = owner_map.get(tag)
            if not expected_owner:
                continue
            if declared_owner and declared_owner != expected_owner:
                errors.append(f"items[{idx}].canonical_owner_skill for {tag} must be {expected_owner}, got {declared_owner}")
            if role == "canonical" and skill_id and skill_id != expected_owner:
                errors.append(f"items[{idx}] marks {tag} as canonical but metadata.skill_id is {skill_id}; canonical owner is {expected_owner}")
    return errors, warnings


def validate_stg_map(root_arg: str) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    refs = resolve_references_root(root_arg)
    cross = (refs / "cross-skill-orchestration.md").read_text(encoding="utf-8")
    mapping = (refs / "classification-to-stg-map.md").read_text(encoding="utf-8")
    canonical = extract_stg_tags(cross)
    referenced = extract_stg_tags(mapping)
    allowed_special = {"STG-UNMAPPED"}
    if not canonical:
        errors.append("canonical STG table appears empty in cross-skill-orchestration.md")
    unknown = sorted(tag for tag in referenced if tag not in canonical and tag not in allowed_special)
    if unknown:
        errors.append(f"classification-to-stg-map.md references unknown STG tags: {unknown}")
    unused = sorted(tag for tag in canonical if tag not in referenced)
    if unused:
        warnings.append(f"canonical STG tags not referenced by this skill map: {unused}")
    return errors, warnings


def is_excluded(path: Path, root: Path, exclude_patterns: list[str]) -> bool:
    try:
        rel = path.relative_to(root).as_posix()
    except Exception:
        rel = path.name
    for pattern in exclude_patterns:
        if fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(path.name, pattern):
            return True
    return False


def iter_artifact_files(root: Path, exclude_patterns: list[str] | None = None) -> list[Path]:
    exclude_patterns = exclude_patterns or []
    if root.is_file():
        return [] if is_excluded(root, root.parent, exclude_patterns) else [root]
    return [p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in SUPPORTED_SUFFIXES and not is_excluded(p, root, exclude_patterns)]


def validate_cross_artifacts(root_arg: str, exclude_patterns: list[str] | None = None) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    root = Path(root_arg).resolve()
    canonical_rows: dict[str, list[tuple[str, Path]]] = {}
    owner_map = load_canonical_owner_map(root)
    parsed = 0
    for path in iter_artifact_files(root, exclude_patterns):
        try:
            doc = load_doc(path)
        except Exception:
            continue
        metadata = doc.get("metadata") if isinstance(doc, dict) else None
        if not isinstance(metadata, dict) or metadata.get("workflow_node") != "N260":
            continue
        skill_id = str(metadata.get("skill_id", ""))
        parsed += 1
        for item in get_items(doc):
            if not isinstance(item, dict) or item.get("ownership_role") != "canonical":
                continue
            tag_value = item.get("shared_scenario_tag")
            tags = tag_value if isinstance(tag_value, list) else [tag_value]
            for tag in tags:
                tag_text = str(tag).strip()
                if tag_text and tag_text != "STG-UNMAPPED":
                    expected_owner = owner_map.get(tag_text)
                    declared_owner = str(item.get("canonical_owner_skill", "")).strip()
                    if expected_owner and declared_owner and declared_owner != expected_owner:
                        errors.append(f"{path.name}: canonical_owner_skill for {tag_text} must be {expected_owner}, got {declared_owner}")
                    if expected_owner and skill_id and skill_id != expected_owner:
                        errors.append(f"{path.name}: {skill_id} marks {tag_text} canonical, but canonical owner is {expected_owner}")
                    canonical_rows.setdefault(tag_text, []).append((skill_id, path))
    if parsed == 0:
        warnings.append(f"no N260 artifacts found under {root}")
    for tag, entries in sorted(canonical_rows.items()):
        skills = sorted({skill for skill, _ in entries})
        if len(skills) > 1:
            locations = ", ".join(f"{skill}:{path.name}" for skill, path in entries)
            errors.append(f"cross-artifact canonical conflict for {tag}: {locations}")
    return errors, warnings


def main() -> int:
    args = parse_args()
    if args.version:
        print(f"validate_n260_output.py {__version__}")
        return 0
    errors: list[str] = []
    warnings: list[str] = []
    if args.validate_stg_map:
        e, w = validate_stg_map(args.validate_stg_map)
        errors.extend(e)
        warnings.extend(w)
    if args.cross_validate:
        e, w = validate_cross_artifacts(args.cross_validate, args.exclude)
        errors.extend(e)
        warnings.extend(w)
    if args.artifact:
        path = Path(args.artifact)
        try:
            doc = load_doc(path)
        except Exception as exc:
            print(f"INVALID: cannot parse artifact: {exc}")
            return 1
        metadata = doc.get("metadata") if isinstance(doc, dict) else None
        inferred_skill = args.skill_id or (metadata.get("skill_id") if isinstance(metadata, dict) else None)
        for check in (
            validate_common(doc, inferred_skill),
            validate_items(doc, args.strict_unmapped),
            validate_owner_consistency(doc, load_canonical_owner_map(path)),
            validate_domain(doc, inferred_skill, args.domain_mode, args.complete_min),
        ):
            e, w = check
            errors.extend(e)
            warnings.extend(w)
    if not args.artifact and not args.validate_stg_map and not args.cross_validate:
        print("Usage: validate_n260_output.py [--skill SKILL_ID] [--domain-mode off|warn|strict|complete] [--complete-min N] <artifact>")
        return 2
    if errors:
        print("INVALID")
        for err in errors:
            print(f"- {err}")
        for warn in warnings:
            print(f"WARNING: {warn}")
        return 1
    print("VALID")
    for warn in warnings:
        print(f"WARNING: {warn}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
