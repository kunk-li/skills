---
name: pre-launch-checklist-generation
description: generate standalone or n260-composable pre-launch readiness checklists focused on operational readiness, owners, time windows, evidence, and signoff. use before release preparation, environment validation, stakeholder review, freeze-window checks, rollback readiness, or when specialty skill completion must be referenced as meta-evidence rather than duplicated.
---
# pre-launch-checklist-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 上线前检查清单.csv. It delivers the high-level release-readiness checklist artifact for N260.

### Boundary
- Own cross-cutting release-readiness checks, timing windows, evidence capture, and signoff routing.
- Do not restate deep specialty assertions that belong to data consistency, permission, concurrency, idempotency, or performance skills.
- Consume gate and specialty completion status as meta-evidence.
- Keep launch timing, ownership, and proof requirements explicit.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `minimal_launch`: produce a small-project or low-risk release checklist with the minimum mandatory categories.
- `enterprise_launch`: produce a full multi-owner, evidence-rich checklist for larger or higher-risk releases.
- `template_by_industry`: adapt category emphasis and signoff pressure for industry-specific release governance.



## v2 reactive contract / v2 reactive contract
This skill is optimized for v2 reactive workflow and must remain useful both standalone and inside N260 composition.

```yaml
reactive_contract:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  produces_event: produced.n260.pre_launch_checklist
  routing_keywords: ['n260', 'pre-launch', 'release-readiness', 'operational-readiness', 'checklist', 'signoff', 'evidence']
  signal_emission_to_n005: ['operational_gap', 'missing_signoff', 'rollback_gap', 'launch_window_risk']
  human_review_sla: "P0 for unresolved blocking launch item; P1 for missing evidence or owner; P2 for warning-only readiness gaps"
  canonical_function: release_readiness_meta_checks
```

- Owns operational readiness, time windows, ownership, signoff, and evidence tracking. It references specialty completion status but does not repeat specialty assertions.
- Always include `shared_scenario_tag`, `ownership_role`, and `canonical_owner_skill` when there is overlap with another N260 skill.
- Emit `produces_event` when the artifact is complete or materially updated.
- Emit N005 feedback signals only when quantified thresholds in `references/signal-thresholds.md` are met; otherwise keep findings local in `downstream_handoff`.



## v3.1.3 P6 governance enforcement
- Treat `references/cross-skill-orchestration.md` as the single source of truth for STG ownership tags; do not copy the STG table into other references.
- Before final handoff, apply `references/validation-rules.md`; validate JSON/YAML artifacts with `scripts/validate_n260_output.py` when a file artifact is available.
- Select mode and evidence tier using `references/mode-input-tier-matrix.md`; never silently promote minimal inputs into full workflow readiness.
- Map every internal category to a default STG tag using `references/classification-to-stg-map.md`.
- Emit N005 signals only when `references/signal-thresholds.md` thresholds are met.
- Validate Markdown and CSV artifacts with `scripts/validate_n260_output.py`; use `references/artifact-frontmatter-contract.md` for required frontmatter and CSV metadata conventions.
- Use the validator domain profile inferred from `metadata.skill_id` or passed with `--skill`; for final handoff, run with `--domain-mode strict` when a machine-readable artifact is available.
- Track `STG-UNMAPPED` usage. If it exceeds thresholds in `references/signal-thresholds.md`, keep readiness no stronger than `constrained` and raise the configured feedback signal.
- Treat validator script version `3.1.3` as the governance implementation version for this package.
- For final handoff with multi-artifact composition, run `scripts/validate_n260_output.py --cross-validate <artifact_dir> --domain-mode complete`; after editing STG maps, run `scripts/validate_n260_output.py --validate-stg-map .`; use `--exclude PATTERN` for archive folders and `--complete-min N` only when a stricter/lighter final handoff threshold is intentionally required.

## Input tiers / input tiers
### minimal_inputs
Accept release type, target environment, and release scope. Generate a conservative readiness checklist with explicit missing-evidence rows.

### workflow_inputs
Prefer `quality_gate_summary`, `n095_consistency_summary`, `n096_permission_summary`, `n097_concurrency_summary`, `n098_idempotency_summary`, `n099_performance_summary`, deployment plan, rollback plan, monitoring plan, and release calendar.

### enhancement_inputs
Use on-call roster, freeze periods, communication plan, support briefing, customer-impact tier, deployment topology, and previous release postmortems.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 质量门禁检查单.md
- 发布说明草案
- change calendar constraints
- 值班排班计划
- rollback rehearsal evidence
- customer communication plan
- deployment topology
- environment inventory

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `launch_scope_summary`
- `category_summary[]`
- `checklist_items[]`
- `time_window_plan[]`
- `signoff_matrix`
- `evidence_requirements[]`
- `open_gaps[]`
- `downstream_handoff`
- `self_check`
- `operational_readiness_status`
- `specialty_readiness_refs[]`
- `meta_check_items[]`
- `launch_blocker_handoff`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: release_readiness_meta_checks`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.pre_launch_checklist_generation`
- `workflow_node: N260`
- `node_artifact_target: 上线前检查清单.csv`
- `evidence_profile`
- `tool_collaboration_mode`
- `schema_version: 2.1`
- `governance_revision: 3.1.3`
- `event_contract.produces_event`
- `routing.intent_tags`
- `routing.routing_keywords`
- `signal_emission.to_n005`
- `human_review.sla_priority`
- `schema_evolution.compatibility`



## Verdict and specialty boundary / verdict and specialty boundary
- Emit `operational_readiness_status: ready | ready_with_conditions | not_ready` instead of a final quality `go/no_go` verdict.
- Reference 093 `final_verdict` as input when present; never override it.
- For testing, security, compliance, performance, idempotency, concurrency, permission, and data items, track owner/evidence/signoff only; link to specialty rows instead of restating deep assertions.
- If 094 finds a launch blocker after 093 says `go`, emit `go_with_launch_blocker` in `downstream_handoff` and require re-evaluation or blocker closure.

## Design rules / design rules
- Group checks into clear pre-launch categories instead of one flat list.
- Separate T-14d, T-7d, T-3d, T-1d, T-1h, T+1h, and T+24h windows when relevant.
- Require evidence and named verifier for every non-trivial check item.
- Use signoff routing to make ownership and escalation visible.
- Reference specialty completion as meta-checks instead of duplicating specialty content.

## Execution workflow / execution workflow
1. Read gate status, specialty readiness, release scope, and environment context.
2. Choose minimal or enterprise framing and group checks by pre-launch category.
3. Assign each check a time window, verifier, evidence expectation, and signoff path.
4. Flag open gaps that must be resolved before release approval.
5. Emit checklist rows ready for N270 and N280 execution tracking.

## Dynamic completeness / dynamic completeness
- Small releases can keep the checklist lean, but still require code, environment, monitoring, rollback, and ownership visibility.
- If gate status is conditional or no-go, surface launch blockers directly in the checklist rather than burying them.
- If release context is incomplete, keep categories and signoffs stable while marking missing evidence explicitly.

## Quality bar / quality bar
A good artifact tells the team exactly what must be checked, by whom, when, with what evidence, and what still blocks launch.

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/launch-checklist-categories.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`