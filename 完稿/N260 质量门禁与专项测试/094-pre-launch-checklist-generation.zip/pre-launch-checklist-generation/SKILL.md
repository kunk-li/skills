---
name: pre-launch-checklist-generation
description: Generate pre-launch readiness checklists covering operational readiness, owners, time windows, evidence, and sign-off; reference specialty completion as meta-evidence before deployment.
---
# pre-launch-checklist-generation


## Checklist routing decision table

| Situation | Action |
|---|---|
| Hotfix release (< 2h window) | Abbreviated checklist: smoke + rollback + on-call only |
| Major version (breaking changes) | Full checklist + breaking change confirmation + consumer sign-off |
| Canary deployment | Pre-canary checklist: monitoring thresholds + SLO baseline confirmed |
| Rollback scenario | Rollback verification checklist: DB state + service health + traffic switch |
| External dependency unavailable | Flag item as `status: pending_external_confirmation` |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n260.pre-launch-checklist.v2.2"
contract_version: "n260.release-readiness.v2.2"
workflow_node: "N260"
node_artifact_target: "上线前检查清单.csv"
function_bias: "planning"
```


## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 上线前检查清单.csv. It delivers the high-level release-readiness checklist artifact for N260.

### Boundary
- Own cross-cutting release-readiness checks, timing windows, evidence capture, and signoff routing.
- Do not restate deep specialty assertions that belong to data consistency, permission, concurrency, idempotency, or performance skills.
- Consume gate and specialty completion status as meta-evidence.
- Keep launch timing, ownership, and proof requirements explicit.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `minimal_launch`: produce a small-project or low-risk release checklist with the minimum mandatory categories.
- `enterprise_launch`: produce a full multi-owner, evidence-rich checklist for larger or higher-risk releases.
- `template_by_industry`: adapt category emphasis and signoff pressure for industry-specific release governance.



## v2 reactive contract

> Full reactive contract spec (schema_version, governance_revision, produces_event, routing_keywords,
> signal_emission, human_review_sla, canonical_function) is in
> `references/n260-v2-reactive-contract.md`.

## Cross-skill integration map

| 上游 skill | 提供给 094 | 用途 |
|---|---|---|
| 093 quality-gate-check | `gate_verdict` | 门禁通过是发布前检查的前置条件 |
| 095–099 N260 专项 | `specialty_results` | 各专项检查结果汇入发布清单 |

| 下游 skill | 094 输出 | 如何使用 |
|---|---|---|
| 发布管理 | `pre_launch_checklist` | 发布决策的最终检查依据 |
| 运维 | `rollback_checklist` | 回滚操作指引 |

**工作流位置**: 门禁通过 → **094 发布前清单** → 正式发布。

## Standalone usage guide

**Minimum input:** release type and service name — no upstream N260 artifacts required.

**Standalone checklist generation:**
1. Select category template based on release type (hotfix / feature / major).
2. Mark items requiring external evidence as `status: pending`.
3. Set `readiness: constrained` until all P0 items are confirmed.

**Minimum viable output:**
```yaml
pre_launch_checklist:
  release_type: feature
  readiness: constrained
  categories:
    testing:
      - item: Smoke test on staging passed
        owner: qa_lead
        status: pending
    deployment:
      - item: Rollback plan documented
        owner: sre_lead
        status: pending
  pending_items: [smoke_test, rollback_plan]
```

## v3.1.3 P6 governance enforcement

See `references/n260-p6-governance.md` for the full governance enforcement rules (validator usage, STG mapping, signal thresholds, cross-validate commands).

## Input tiers / input tiers
### minimal_inputs
Accept release type, target environment, and release scope. Generate a conservative readiness checklist with explicit missing-evidence rows.

### workflow_inputs
Prefer `quality_gate_summary`, `n095_consistency_summary`, `n096_permission_summary`, `n097_concurrency_summary`, `n098_idempotency_summary`, `n099_performance_summary`, deployment plan, rollback plan, monitoring plan, and release calendar.

### enhancement_inputs
Use on-call roster, freeze periods, communication plan, support briefing, customer-impact tier, deployment topology, and previous release postmortems.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 质量门禁检查单.md
- 发布说明草案
- change calendar constraints
- 值班排班计划
- rollback rehearsal evidence
- customer communication plan
- deployment topology
- environment inventory

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `launch_scope_summary`
- `category_summary[]`
- `checklist_items[]`
- `time_window_plan[]`
- `signoff_matrix`
- `evidence_requirements[]`
- `open_gaps[]`
- `downstream_handoff`
- `self_check`
- `operational_readiness_status`
- `specialty_readiness_refs[]`
- `meta_check_items[]`
- `launch_blocker_handoff`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


> `metadata` field requirements: see `references/n260-v2-reactive-contract.md`.



## Verdict and specialty boundary / verdict and specialty boundary
- Emit `operational_readiness_status: ready | ready_with_conditions | not_ready` instead of a final quality `go/no_go` verdict.
- Reference 093 `final_verdict` as input when present; never override it.
- For testing, security, compliance, performance, idempotency, concurrency, permission, and data items, track owner/evidence/signoff only; link to specialty rows instead of restating deep assertions.
- If 094 finds a launch blocker after 093 says `go`, emit `go_with_launch_blocker` in `downstream_handoff` and require re-evaluation or blocker closure.

## Design rules / design rules
- Group checks into clear pre-launch categories instead of one flat list.
- Separate T-14d, T-7d, T-3d, T-1d, T-1h, T+1h, and T+24h windows when relevant.
- Require evidence and named verifier for every non-trivial check item.
- Use signoff routing to make ownership and escalation visible.
- Reference specialty completion as meta-checks instead of duplicating specialty content.

## Execution workflow / execution workflow
1. Read gate status, specialty readiness, release scope, and environment context.
2. Choose minimal or enterprise framing and group checks by pre-launch category.
3. Assign each check a time window, verifier, evidence expectation, and signoff path.
4. Flag open gaps that must be resolved before release approval.
5. Emit checklist rows ready for N270 and N280 execution tracking.

## Dynamic completeness / dynamic completeness
- Small releases can keep the checklist lean, but still require code, environment, monitoring, rollback, and ownership visibility.
- If gate status is conditional or no-go, surface launch blockers directly in the checklist rather than burying them.
- If release context is incomplete, keep categories and signoffs stable while marking missing evidence explicitly.



## Example usage

**Input**: payment service v2.4.1 preparing for production release; enterprise context.

**Output** (`enterprise_launch` mode, excerpt):
```markdown

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Pre-launch checklist — payment-service v2.4.1

### Operational readiness
- [ ] Runbook updated for new retry logic — Owner: SRE — Evidence: runbook PR link — Signoff: SRE Lead
- [ ] Monitoring dashboards updated — Owner: SRE — Evidence: dashboard URL — Signoff: SRE Lead

### Rollback readiness
- [ ] Rollback script tested in staging — Owner: DevOps — Evidence: staging rollback run log
- [ ] Rollback window: 30 min post-deploy

### Data readiness
- [ ] DB migration tested with production data volume — Owner: DBA — Evidence: migration log
```


## Resilience and governance addendum

**Produced events**: Emit `produced_event: produced.n260.pre_launch_checklist` in metadata when the artifact is complete or materially updated. Also emit `signal.n260.launch_readiness_gap` to N005 feedback loop when quantified thresholds in `references/signal-thresholds.md` are met.

**Confidence scoring**: Include `evidence_confidence: high/medium/low` in each item or dimension. Items with `evidence_confidence: low` must be flagged for `human_review_required: true` and must not be counted as passed in the quality gate.

**Circuit breaker**: circuit_breaker triggers when the same checklist category has unresolved items across 3 consecutive releases.

**Traceability**: Every item must carry `canonical_owner_skill` and a reference to the upstream artifact or evidence id that produced it, enabling end-to-end traceability from requirement through to gate verdict in N270 and N280.

**Escalation path**: When `readiness: blocked` on any P0 item, escalate immediately to the release manager and the owning team lead. Log the escalation in `downstream_handoff.escalation_log[]`.

## Auditable rules summary

- R01_owner_required: every checklist item must have a named owner or team; on_violation: reject.
- R02_evidence_slot: every item must have an evidence field (may be pending); on_violation: reject.
- R03_time_window_explicit: launch timing, freeze windows, and rollback windows must be declared; on_violation: warn.
- R04_no_specialty_duplication: do not restate deep assertions owned by 095-099; reference their completion status instead; on_violation: replace_with_reference.
- R05_signoff_tracked: items requiring sign-off must list the approver role; on_violation: warn.
- R06_category_coverage_complete: all declared checklist categories must have at least one item; empty categories must be removed or justified; on_violation: reject.
- R07_owner_assigned: each checklist item must have an assigned owner role; on_violation: add_owner_placeholder.

## Algorithm

1. Select mode (minimal_launch / enterprise_launch / template_by_industry).
2. Generate category groups: operational, infrastructure, data, security, communication, rollback.
3. For each item, assign owner (R01), evidence slot (R02), and signoff role (R05).
4. Reference specialty completion status without duplicating assertions (R04).
5. Declare timing windows and rollback window (R03).
6. Emit `checklist_categories[]`, `launch_timeline`, `signoff_matrix`.
7. Run `self_check`; set `readiness: blocked` if R01 or R02 fires.

## Quality bar / quality bar
A good artifact tells the team exactly what must be checked, by whom, when, with what evidence, and what still blocks launch.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本（如 `n260.quality-gate-check.v2.2`），仅本 skill 字段变更时递增；
`governance_revision: "3.1.3"` — N260 组共享的 P6 治理框架修订号，修改 `n260-p6-governance.md` 时递增。
三套版本号独立变更，语义见 `references/n260-v2-reactive-contract.md`。

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/launch-checklist-categories.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## Usage scenarios

- `release_gate_mode`: full pre-launch checklist for planned releases.
- `hotfix_checklist`: abbreviated checklist for P0/P1 hotfix deployments.
- `canary_pre_check`: pre-canary gate before traffic promotion.
- `rollback_verification`: post-rollback checklist to confirm system stability.
