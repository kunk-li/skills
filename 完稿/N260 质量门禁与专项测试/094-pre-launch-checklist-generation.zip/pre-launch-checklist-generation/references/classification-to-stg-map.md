# Internal classification to STG map v3.1.3

## Purpose
Bind the skill's internal categories to shared N260 STG tags so generated rows are deduplicable by 093 and N370.

| internal classification | default shared_scenario_tag | ownership_role | notes |
|---|---|---|---|
| `C01_code_quality_and_review` | `STG-LAUNCH-READINESS-META` | `canonical` | Track owner/evidence/signoff; do not rescore code quality. |
| `C02_testing_completeness` | `STG-LAUNCH-READINESS-META` | `canonical` | Reference specialty completion from 095/097/098/099; avoid duplicating assertions. |
| `C03_security` | `STG-LAUNCH-READINESS-META / STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical/supporting` | Track signoff and evidence; 096 owns executable permission/security authz tests. |
| `C04_compliance_and_audit` | `STG-LAUNCH-READINESS-META` | `canonical` | Track readiness and human approval; 093 owns final gate impact. |
| `C05_performance_readiness` | `STG-LAUNCH-READINESS-META / STG-PERFORMANCE-SLO-CAPACITY` | `canonical/supporting` | Track evidence availability; 099 owns SLO/capacity/regression detail. |
| `C06_operational_readiness` | `STG-LAUNCH-READINESS-META` | `canonical` | Own runbook, on-call, dashboards, logs, and operational readiness. |
| `C07_monitoring_and_observability` | `STG-LAUNCH-READINESS-META` | `canonical` | Own readiness of metrics, tracing, logs, and SLI/SLO visibility. |
| `C08_deployment_safety` | `STG-LAUNCH-READINESS-META` | `canonical` | Own rollback/canary/feature-flag/time-window readiness. |
| `C09_data_migration` | `STG-LAUNCH-READINESS-META / STG-DATA-REFERENTIAL-INTEGRITY` | `canonical/supporting` | Track migration readiness; 095 owns data consistency checks. |
| `C10_external_dependencies` | `STG-LAUNCH-READINESS-META` | `canonical` | Own dependency readiness and fallback signoff. |
| `C11_communication_and_notifications` | `STG-LAUNCH-READINESS-META` | `canonical` | Own release notes, support comms, and status page readiness. |
| `C12_post_launch_validation` | `STG-LAUNCH-READINESS-META` | `canonical` | Own post-launch checklist readiness and validation schedule. |

## Enforcement
- Every generated row should include the most specific internal classification and at least one default STG tag from this map.
- If a row spans multiple classifications, include multiple tags and mark only the canonical owner as `ownership_role: canonical`.
- If the map does not cover a new category, add a temporary `STG-UNMAPPED` note in `downstream_handoff` and mark readiness no stronger than `constrained` until the map is updated.

## STG-UNMAPPED governance limit
Use `STG-UNMAPPED` only as a temporary exception. More than 2 unmapped rows or more than 10% unmapped rows in one artifact is a governance signal and must keep readiness no stronger than `constrained` until the map is updated.


## v3.1.3 map integrity check
After editing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

The check fails if this file references an STG tag that is not defined in `references/cross-skill-orchestration.md`, except for the temporary `STG-UNMAPPED` exception.


## v3.1.3 owner-map consistency

After changing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

During artifact validation, `canonical_owner_skill` is checked against the canonical owner table in `cross-skill-orchestration.md`. Use `STG-UNMAPPED` only as a temporary constrained fallback, not as an owner bypass.
