# Launch checklist categories

Recommended universal categories:
- code_ready
- environment
- configuration
- data_migration
- monitoring_alerting
- rollback_readiness
- communication
- on_call_staffing
- runbook_documented
- stakeholder_signoff

## v2.1 meta-check boundary
094 should express specialty topics as readiness meta-checks only:
- `specialty_ref` points to 095-099 or 096 evidence.
- `evidence_required` states what proof or signoff is needed.
- `owner`, `time_window`, and `signoff_role` are owned by 094.
- Deep assertions such as exact idempotency conflict behavior, race outcome, SLO threshold, or permission matrix cell belong to the specialty skill.
