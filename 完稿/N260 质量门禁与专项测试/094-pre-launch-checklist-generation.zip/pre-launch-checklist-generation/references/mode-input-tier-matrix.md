# Mode x input tier matrix v3.1

## Purpose
Prevent mode and input-tier ambiguity. `selected_mode` is the work style; input tier is the evidence depth. They are related but not synonyms.

| selected_mode | input tier | rule |
|---|---|---|
| `minimal_launch` | `minimal_inputs` | Allowed. Release version, type, target environment, and rough blast radius are enough. |
| `minimal_launch` | `workflow_inputs` | Allowed. Use gate_result and deployment_plan if present, but keep checklist short. |
| `minimal_launch` | `enhancement_inputs` | Optional. Do not require historical release patterns. |
| `enterprise_launch` | `minimal_inputs` | Not sufficient. Produce a starter checklist and mark evidence as insufficient_evidence. |
| `enterprise_launch` | `workflow_inputs` | Required. Consume gate_result, deployment plan, specialty readiness refs, owners, and time windows. |
| `enterprise_launch` | `enhancement_inputs` | Recommended. Use compliance calendar, freeze periods, prior incidents, and stakeholder matrix. |
| `template_by_industry` | `minimal_inputs` | Allowed only for generic template drafting; mark assumptions. |
| `template_by_industry` | `workflow_inputs` | Allowed. Adapt checklist to actual release context. |
| `template_by_industry` | `enhancement_inputs` | Recommended. Use industry/regulatory profile and org-specific approval rules. |

## Enforcement
- If the requested mode is not legal for the available input tier, either downgrade the mode or mark the result `insufficient_evidence`.
- Never silently promote minimal inputs into a full workflow claim.
- Record the chosen mode and input tier in `metadata.selected_mode` and `metadata.evidence_profile.input_completeness`.
