# N260 v2 reactive contract

This reference makes the skill compatible with the v2 reactive workflow: event bus, artifact contract, three-layer routing, feedback loop, circuit breaker, progressive gate, and SLA human queue.

## Required result metadata
Every result should include these fields when the information is available:

```yaml
metadata:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  skill_id: "pre-launch-checklist-generation"
  workflow_node: N260
  node_artifact_target: "上线前检查清单.csv"
  selected_mode: "<mode>"
  readiness: pass | constrained | blocked | insufficient_evidence
  evidence_profile:
    input_completeness: complete | partial | minimal
    evidence_confidence: high | medium | low
    missing_evidence: []
  routing:
    intent_tags: []
    routing_keywords: []
  event_contract:
    produces_event: "produced.n260.pre_launch_checklist"
    event_payload_fields:
      - metadata
      - summary
      - items
      - blocker_state
      - downstream_handoff
  signal_emission:
    to_n005: []
    emit_when: []
  human_review:
    required: false
    sla_priority: P0 | P1 | P2
    trigger_reason: ""
  schema_evolution:
    compatibility: backward_compatible | breaking
    change_note: ""
```

## Readiness semantics
- `pass`: evidence supports the expected result and no blocking gap remains.
- `constrained`: work may continue, but a tracked condition, owner, or evidence gap remains.
- `blocked`: release or gate movement must stop until the blocker is resolved or formally overridden.
- `insufficient_evidence`: the skill can produce a useful artifact, but cannot claim pass/fail.

## Event bus and feedback loop
Emit the skill's `produces_event` whenever a final artifact is generated or materially updated. Emit N005 signals only for durable product/quality learning: recurring failures, release-blocking defects, customer-visible quality risk, repeated operational gaps, or regressions likely to affect future planning.

## SLA human queue
Use P0 when a release-blocking, compliance, security, money, entitlement, data corruption, severe SLO, or no-go condition exists. Use P1 when evidence/signoff is missing but the issue is expected to close in the current release window. Use P2 for preventive or informational follow-up.

## Schema evolution
Non-breaking changes may add optional fields or new enum values with fallback behavior. Breaking changes include renaming required fields, changing verdict semantics, or removing fields consumed by N260, N270, N280, N370, or N005.

## Shared scenario tags
The canonical shared scenario tag table is maintained only in `references/cross-skill-orchestration.md`. Do not copy the table into this file. Every item that overlaps with another N260 skill must reference a tag from that table.

## Runtime validation hook
Before finalizing a machine-readable artifact, validate it against `references/validation-rules.md`. If a JSON or YAML artifact file is available, run `scripts/validate_n260_output.py <artifact-file>` and fix reported errors or downgrade readiness to `insufficient_evidence`.

## Validator implementation version
Use `scripts/validate_n260_output.py --version` to confirm validator version `3.1.3` for this package. The schema remains `2.1`; governance enforcement is tracked separately by `governance_revision`.


## v3.1.3 governance implementation
`schema_version` remains `2.1`. `governance_revision` advances to `3.1.3` to represent P5 engineering controls: YAML fallback lists, STG map integrity validation, complete domain validation, and cross-artifact canonical conflict detection.


## v3.1.3 governance revision note

`governance_revision: "3.1.3"` keeps `schema_version: "2.1"` unchanged. The revision adds P6 validation controls only: complete threshold override, cross-validation excludes, and canonical owner consistency checks.


## 版本号语义对照表

N260 技能包中并存三套版本号，含义各不相同：

| 版本号字段 | 示例值 | 含义 | 变更时机 |
|---|---|---|---|
| `skill_version` | `"2.2"` | SKILL.md 内容版本（全批统一，跨 N220–N260） | 内容结构性变更时递增 |
| `schema_version` | `"n260.quality-gate-check.v2.2"` / `"2.1"` | 输出契约 schema 版本（每个 skill 独立） | 输出字段增删时递增 |
| `governance_revision` | `"3.1.3"` | P6 治理框架修订号（N260 组共享） | N260 治理规则变更时递增 |

**读者指引**
- 升级 `skill_version`：更新 SKILL.md 章节或规则时操作，范围全批。
- 升级 `schema_version`：修改输出 YAML 字段结构时操作，范围单个 skill。
- 升级 `governance_revision`：修改 `references/n260-p6-governance.md` 时操作，范围 N260 全组。

三套号**不需要同步**——它们跟踪的是独立的变更维度。


## 094 v2 Reactive Contract

This skill is optimized for v2 reactive workflow and must remain useful both standalone and inside N260 composition.

```yaml
reactive_contract:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  produces_event: produced.n260.pre_launch_checklist
  routing_keywords: ['n260', 'pre-launch', 'release-readiness', 'operational-readiness', 'checklist', 'signoff', 'evidence']
  signal_emission_to_n005: ['operational_gap', 'missing_signoff', 'rollback_gap', 'launch_window_risk']
  human_review_sla: "P0 for unresolved blocking launch item; P1 for missing evidence or owner; P2 for warning-only readiness gaps"
  canonical_function: release_readiness_meta_checks
```

- Owns operational readiness, time windows, ownership, signoff, and evidence tracking. It references specialty completion status but does not repeat specialty assertions.
- Always include `shared_scenario_tag`, `ownership_role`, and `canonical_owner_skill` when there is overlap with another N260 skill.
- Emit `produces_event` when the artifact is complete or materially updated.
- Emit N005 feedback signals only when quantified thresholds in `references/signal-thresholds.md` are met; otherwise keep findings local in `downstream_handoff`.

## 094 metadata must_contain

`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: release_readiness_meta_checks`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.pre_launch_checklist_generation`
- `workflow_node: N260`
- `node_artifact_target: 上线前检查清单.csv`
- `evidence_profile`
- `tool_collaboration_mode`
- `schema_version: 2.1`
- `governance_revision: 3.1.3`
- `event_contract.produces_event`
- `routing.intent_tags`
- `routing.routing_keywords`
- `signal_emission.to_n005`
- `human_review.sla_priority`
- `schema_evolution.compatibility`

