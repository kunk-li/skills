# Output Template: 上线前检查清单

## 推荐 csv 字段
`pre_id | category | item | severity | owner | verify_method | acceptance | evidence_ref | status`

## 必覆盖
- 代码 / 部署 / 安全 / 监控 / 回滚 五大维度各至少 1 组
- 每项必须有 `owner` 与 `acceptance`
- 缺证时用 `todo` 或 `待确认` 明示

## 规模参考
- 小版本：20-40 条
- 中版本：40-80 条
- 大版本：80-150 条

## 禁止
- ❌ 无 owner
- ❌ 无 acceptance
- ❌ 用泛泛描述替代可验证动作


## v2.1 shared contract fields
Include these fields when the output is row-based:
`schema_version | shared_scenario_tag | ownership_role | canonical_owner_skill | related_specialty_refs | deduplicated_links | human_review_required | sla_priority | signal_to_n005`

Use `status=insufficient_evidence` instead of implying pass/fail when proof is missing.

## v3.1 governance fields
- Include `metadata.governance_revision: "3.1"`.
- Validate required metadata and item de-dup fields against `validation-rules.md`.
- Use `classification-to-stg-map.md` to set `shared_scenario_tag`.
- Use `signal-thresholds.md` before emitting to N005.

## Markdown and CSV frontmatter
For Markdown or CSV outputs, apply `references/artifact-frontmatter-contract.md` so the same metadata can be validated by `scripts/validate_n260_output.py`.
