# N260 示例输入输出 v2（扩展场景）

## 示例 3：并发测试点生成（concurrency-test-point-generation）

### 输入
- 场景：订单服务，共享库存写操作

### 输出
```yaml
concurrency_test_points:
  - tp_id: CTP-001
    surface: 库存扣减
    pattern: 竞争写
    isolation_level: SERIALIZABLE
    test: 100并发请求同一SKU，库存不可为负
  - tp_id: CTP-002
    pattern: 死锁
    test: 订单A锁库存→锁账户 vs 订单B锁账户→锁库存
```

## 示例 4：性能测试场景生成（performance-test-scenario-generation）

### 输入
- SLO：p95 ≤ 500ms，吞吐量 ≥ 1000 rps

### 输出
```yaml
performance_scenarios:
  - type: load
    config: 1000 rps × 10min
    slo_assertion:
      metric: p95_latency
      threshold: 500ms
      window: 10min
    abort_condition: error_rate > 5%
  - type: stress
    config: ramp 100→2000 rps
    abort_condition: p95 > 2000ms
```

## 094 扩展示例输入输出

### Example B — Hotfix release checklist (T-0h to T+2h window)

**Input**: P0 hotfix release for auth service NullPointerException; team has 30-min deployment window.

**Output** (`release_gate_mode`, `hotfix` release type):
```yaml
pre_launch_checklist:
  release_type: hotfix
  time_window: T-0h to T+2h
  readiness: constrained
  categories:
    code_and_testing:
      - item: Unit test for NPE guard added and passing
        owner: developer
        status: done
        evidence: CI run #5821 green
      - item: Smoke test on staging passed
        owner: qa_lead
        status: done
        evidence: SMK-R001-R003 all pass
    deployment:
      - item: Rollback plan documented (revert commit + redeploy)
        owner: sre_lead
        status: done
      - item: On-call engineer notified and available
        owner: sre_lead
        status: done
    communication:
      - item: Incident INC-4821 status page updated
        owner: eng_manager
        status: pending
        deadline: T-10min
      - item: Customer notification sent (if user-facing impact)
        owner: support_team
        status: not_applicable
        reason: internal service only
  gate_verdict: conditional
  blocking_items:
    - item: Incident status page not yet updated
      owner: eng_manager
  required_actions:
    - Update INC-4821 status page before deployment
  readiness: constrained
```


### Scenario C — Major version release (full checklist)

**Input**: v3.0 major release — DB migration included, 3 deprecated APIs removed.

**Output** (`release_gate_mode`, `major`):
```yaml
pre_launch_checklist:
  release_type: major
  readiness: constrained
  categories:
    breaking_changes:
      - item: DB migration runbook tested on staging
        owner: dba_lead
        status: done
      - item: Consumer teams confirmed migration complete
        owner: partnerships
        status: pending
        deadline: T-48h
    rollback:
      - item: DB rollback script tested and timed less than 5min
        owner: dba_lead
        status: pending
  gate_verdict: conditional
  blocking_items: [consumer_migration_pending, rollback_not_tested]
```

### Scenario D — Major version release (breaking changes)

**Input**: v3.0 major release — DB migration + 3 deprecated APIs removed.

**Output** (`release_gate_mode`, `major`):
```yaml
pre_launch_checklist:
  release_type: major
  version: v3.0.0
  readiness: constrained
  categories:
    breaking_changes:
      - item: DB migration runbook tested on staging
        owner: dba_lead
        status: done
      - item: Consumer teams confirmed migration complete
        owner: partnerships
        status: pending
        deadline: T-48h
    rollback:
      - item: DB rollback script tested (timed < 5min)
        owner: dba_lead
        status: pending
  gate_verdict: conditional
  blocking_items: [consumer_migration_pending, rollback_not_tested]
```

### Scenario D — Emergency rollback (post-launch incident)

**Input**: v3.1 launched; P0 incident detected 30min after; need rollback checklist.

**Output** (`rollback_mode`):
```yaml
pre_launch_checklist:
  mode: rollback_emergency
  trigger: P0_incident_post_launch
  incident_ref: INC-5001
  readiness: constrained
  items:
    - category: immediate_actions
      items:
        - action: Route 100% traffic back to v3.0 via load balancer
          owner: sre_oncall
          sla: within_5min
          status: pending
        - action: Disable feature flag ff_v31_checkout globally
          owner: platform_team
          sla: within_5min
          status: pending
    - category: data_recovery
      items:
        - action: Assess data written during v3.1 window (30min)
          owner: dba_oncall
          sla: within_15min
          status: pending
        - action: Run data consistency check (095)
          owner: qa_lead
          sla: within_30min
          status: pending
  post_rollback_gate: run_093_quality_gate_check_before_re-deploy
```
