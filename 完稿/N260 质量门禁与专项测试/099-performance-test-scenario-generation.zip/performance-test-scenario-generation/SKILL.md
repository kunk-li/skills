---
name: performance-test-scenario-generation
description: Generate performance test scenarios for SLO validation, load, stress, spike, soak, breakpoint, and capacity baseline; treats high concurrency as capacity evidence, not concurrency correctness.
---
# performance-test-scenario-generation


## Performance test routing table

| Situation | Action |
|---|---|
| SLO validation required | Generate `load` test at target RPS; assert p95 ≤ threshold |
| Capacity planning | Generate `stress` test ramping to breaking point |
| Traffic spike concern | Generate `spike` test with sudden surge and recovery |
| Memory leak investigation | Generate `soak` test (4h+) with heap monitoring |
| Maximum throughput needed | Generate `breakpoint` test with binary search for max RPS |


## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n260.performance-test.v2.2"
contract_version: "n260.specialty.v2.2"
workflow_node: "N260"
node_artifact_target: "性能测试场景.csv"
function_bias: "analysis"
```


## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 性能测试场景.csv. It delivers the performance specialty artifact for N260.

### Boundary
- Own performance test-type selection, baseline comparison framing, data-volume alignment, monitoring stack requirements, and reproducibility rules.
- Consume performance-risk analysis and testcase assets from upstream nodes.
- Do not collapse performance into one generic load test; separate load, stress, spike, soak, and capacity purposes.
- Make benchmark quality and repeatability visible, not only latency targets.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `load_test_only`: focus on standard load validation against SLO or release thresholds.
- `full_spectrum`: cover load, stress, spike, soak, and capacity perspectives.
- `continuous_perf`: shape scenarios for recurring or CI-integrated performance validation.



## v2 reactive contract

> Full reactive contract spec (schema_version, governance_revision, produces_event, routing_keywords,
> signal_emission, human_review_sla, canonical_function) is in
> `references/n260-v2-reactive-contract.md`.

## Cross-skill integration map

| 上游 skill | 提供给 099 | 用途 |
|---|---|---|
| 系统 SLO/SLA 文档 | `performance_slo` | 性能场景的目标基准 |
| 084 regression-test-checklist-generation | `scope` | 性能测试覆盖回归范围 |

| 下游 skill | 099 输出 | 如何使用 |
|---|---|---|
| 093 quality-gate-check | `performance_test_results` | 门禁的性能 SLO 维度 |
| 088 test-automation-orchestration | `performance_scenarios[]` | 编排器集成性能测试执行 |

**工作流位置**: SLO 分析 → **099 性能场景** → 088 编排/093 门禁。

## Standalone usage guide

**Minimum input:** a service name and an SLO target (latency/throughput) — no k6 config required.

**Standalone performance scenario generation:**
1. Generate the five standard scenario types (load/stress/spike/soak/breakpoint).
2. Set SLO triplet from input; use conservative defaults if partial.
3. Flag `pending_baseline_confirmation` if no existing performance baseline is provided.

**Minimum viable output:**
```yaml
performance_scenarios:
  readiness: constrained
  pending_baseline_confirmation: true
  slo:
    metric: p95_latency
    threshold: 500ms
    window: 10min
  scenarios:
    - type: load
      config: 100 rps × 10min
      abort_condition: error_rate > 5% OR p95 > 2000ms
      source: standard_load_template
    - type: spike
      config: ramp 0 → 500 rps in 30s, hold 1min
      abort_condition: p95 > 3000ms
```

## v3.1.3 P6 governance enforcement

See `references/n260-p6-governance.md` for the full governance enforcement rules (validator usage, STG mapping, signal thresholds, cross-validate commands).

## Input tiers / input tiers
### minimal_inputs
Accept an API/service and at least one target SLO or capacity question. Generate a load/regression scenario with missing baseline limits called out.

### workflow_inputs
Prefer performance designs, SLO triplets, capacity model, API specs, historical performance data, environment inventory, monitoring stack, and release risk context.

### enhancement_inputs
Use production traffic distribution, previous benchmark runs, cost model, incident history, autoscaling policy, profiling data, and soak trend baselines.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 性能风险分析.md
- service SLO definitions
- production baseline history
- test environment capacity profile
- anonymized production snapshots
- monitoring dashboard links

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `perf_scope_summary`
- `scenario_rows[]`
- `perf_test_types[]`
- `baseline_comparison`
- `data_volume_alignment`
- `monitoring_stack`
- `reproducibility_plan`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `baseline_ref`
- `slo_triplet`
- `regression_delta`
- `abort_condition`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


> `metadata` field requirements: see `references/n260-v2-reactive-contract.md`.



## Ownership and de-duplication / ownership and de-duplication
- Own performance questions: SLO, throughput, latency, capacity, scaling, regression, bottleneck, soak, and abort criteria.
- Do not own concurrency correctness. If high concurrency reveals race or locking correctness risks, link to 097.
- 094 may track whether performance evidence exists and who signs it off; 099 owns the scenario and pass/fail criteria.
- 093 may hard-veto from 099 summary but must not recalculate raw performance metrics.

## Design rules / design rules
- Assign each scenario one performance test type and clear objective.
- Compare current targets against a baseline or state why no reliable baseline exists yet.
- Check data volume realism before trusting any result.
- Specify the full monitoring stack needed to interpret the run.
- Require reproducibility rules so outlier runs do not drive gate decisions blindly.

## Execution workflow / execution workflow
1. Read performance-risk evidence, target SLOs, testcase assets, and environment capacity context.
2. Choose the required performance test types and define scenario rows with load shape and acceptance thresholds.
3. Attach baseline comparison, data-volume alignment, and monitoring requirements.
4. Add reproducibility rules, warm-up assumptions, and repeat-run expectations.
5. Emit gate-ready performance rows and downstream release/operations handoff.

## Dynamic completeness / dynamic completeness
- At minimum, define load and stress perspectives; core services should extend into spike, soak, or capacity modes when risk justifies it.
- If production-like data volume is unavailable, surface trust limits explicitly.
- If monitoring is incomplete, mark the result as low-confidence rather than overstating pass claims.



## Example usage

**Input**: checkout API SLO — p95 latency < 500ms; peak load 1000 RPS; stress test to find breaking point.

**Output** (excerpt):
```yaml
performance_test_scenarios:
  - scenario_id: PTS-001
    type: load
    description: Sustain 1000 RPS on POST /checkout for 10 minutes
    slo_target: p95 < 500ms, error_rate < 0.1%
    tool: k6
    abort_criteria: error_rate > 1% OR p99 > 2000ms
    priority: P0
  - scenario_id: PTS-002
    type: stress
    description: Ramp from 1000 to 5000 RPS in 5 min steps; find saturation point
    expected: identify RPS at which p95 exceeds 500ms
    priority: P1
  - scenario_id: PTS-003
    type: spike
    description: Jump from 100 to 3000 RPS instantly; observe recovery time
    expected: service recovers to p95 < 500ms within 60s of spike
    priority: P1
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Resilience and governance addendum

**Produced events**: Emit `produced_event: produced.n260.performance_scenarios` in metadata when the artifact is complete or materially updated. Also emit `signal.n260.slo_regression` to N005 feedback loop when quantified thresholds in `references/signal-thresholds.md` are met.

**Confidence scoring**: Include `evidence_confidence: high/medium/low` in each item or dimension. Items with `evidence_confidence: low` must be flagged for `human_review_required: true` and must not be counted as passed in the quality gate.

**Circuit breaker**: circuit_breaker triggers when SLO validation scenarios are skipped or consistently fail across 3 consecutive releases without a documented reason.

**Traceability**: Every item must carry `canonical_owner_skill` and a reference to the upstream artifact or evidence id that produced it, enabling end-to-end traceability from requirement through to gate verdict in N270 and N280.

**Escalation path**: When `readiness: blocked` on any P0 item, escalate immediately to the release manager and the owning team lead. Log the escalation in `downstream_handoff.escalation_log[]`.

## Auditable rules summary

- R01_scope_grounded: every performance test scenario must reference a specific table, endpoint, field, or service; on_violation: reject.
- R02_ownership_tagged: each item must carry `canonical_owner_skill` and `shared_scenario_tag` when overlap with another N260 skill exists; on_violation: reject.
- R03_evidence_slot: every item must have an evidence or verification field; on_violation: reject.
- R04_no_duplication: deduplicate against items from other N260 skills using STG tags; on_violation: merge_or_reference.
- R05_priority_declared: every item must have a priority (P0/P1/P2); on_violation: assign_default.
- R06_abort_condition_defined: every scenario type (load/stress/spike/soak/breakpoint) must declare explicit abort conditions; on_violation: add_abort.
- R07_slo_triplet_complete: each SLO assertion must include all three components (metric, threshold, measurement_window); on_violation: reject_incomplete_slo.

## Algorithm

1. Parse inputs and identify scope: SLO validation, load, stress, spike, soak, breakpoint, or capacity baseline.
2. For each scope item, generate test points with owner tag (R02).
3. Assign evidence slot (R03) and priority (R05).
4. Deduplicate against other N260 skills using STG map (R04).
5. Validate each item references a specific artifact (R01).
6. Emit `test_points[]`, `ownership_map`, `dedup_log`.
7. Run `self_check`; set `readiness: blocked` if R01, R02, or R03 fires.

## Quality bar / quality bar
A good artifact states what performance question is being asked, what load shape answers it, how results compare to baseline, and whether the evidence is trustworthy enough for a gate decision.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本（如 `n260.quality-gate-check.v2.2`），仅本 skill 字段变更时递增；
`governance_revision: "3.1.3"` — N260 组共享的 P6 治理框架修订号，修改 `n260-p6-governance.md` 时递增。
三套版本号独立变更，语义见 `references/n260-v2-reactive-contract.md`。

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/performance-scenario-matrix.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/concurrency-performance-boundary.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## Usage scenarios

- `load_test`: sustained load at target RPS to validate SLO compliance.
- `stress_test`: ramp beyond capacity to find breaking point.
- `spike_test`: sudden traffic burst and recovery validation.
- `soak_test`: extended duration test for memory leaks and degradation.
- `breakpoint_test`: binary search for maximum sustainable throughput.

