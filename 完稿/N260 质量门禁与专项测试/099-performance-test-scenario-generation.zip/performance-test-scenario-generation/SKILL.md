---
name: performance-test-scenario-generation
description: generate standalone or n260-composable performance test scenarios for slo validation, load, stress, spike, soak, breakpoint, regression, capacity baseline, bottleneck hypotheses, monitoring, and abort criteria. use before release gating, capacity planning, performance regression review, or when high concurrency must be treated as capacity evidence rather than concurrency correctness.
---
# performance-test-scenario-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 性能测试场景.csv. It delivers the performance specialty artifact for N260.

### Boundary
- Own performance test-type selection, baseline comparison framing, data-volume alignment, monitoring stack requirements, and reproducibility rules.
- Consume performance-risk analysis and testcase assets from upstream nodes.
- Do not collapse performance into one generic load test; separate load, stress, spike, soak, and capacity purposes.
- Make benchmark quality and repeatability visible, not only latency targets.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `load_test_only`: focus on standard load validation against SLO or release thresholds.
- `full_spectrum`: cover load, stress, spike, soak, and capacity perspectives.
- `continuous_perf`: shape scenarios for recurring or CI-integrated performance validation.



## v2 reactive contract / v2 reactive contract
This skill is optimized for v2 reactive workflow and must remain useful both standalone and inside N260 composition.

```yaml
reactive_contract:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  produces_event: produced.n260.performance_scenarios
  routing_keywords: ['n260', 'performance', 'slo', 'load-test', 'stress-test', 'spike-test', 'soak-test', 'capacity', 'regression']
  signal_emission_to_n005: ['performance_regression', 'capacity_limit', 'slo_breach', 'resource_leak_risk']
  human_review_sla: "P0 for floor SLO breach, release-blocking regression, crash, data corruption, or severe leak; P1 for missing baseline or monitoring; P2 for capacity-planning improvements"
  canonical_function: performance_slo_and_capacity_validation
```

- Owns SLO validation, load shape, capacity baseline, regression comparison, bottleneck hypothesis, soak stability, and abort criteria. It does not own concurrency correctness.
- Always include `shared_scenario_tag`, `ownership_role`, and `canonical_owner_skill` when there is overlap with another N260 skill.
- Emit `produces_event` when the artifact is complete or materially updated.
- Emit N005 feedback signals only when quantified thresholds in `references/signal-thresholds.md` are met; otherwise keep findings local in `downstream_handoff`.



## v3.1.3 P6 governance enforcement
- Treat `references/cross-skill-orchestration.md` as the single source of truth for STG ownership tags; do not copy the STG table into other references.
- Before final handoff, apply `references/validation-rules.md`; validate JSON/YAML artifacts with `scripts/validate_n260_output.py` when a file artifact is available.
- Select mode and evidence tier using `references/mode-input-tier-matrix.md`; never silently promote minimal inputs into full workflow readiness.
- Map every internal category to a default STG tag using `references/classification-to-stg-map.md`.
- Emit N005 signals only when `references/signal-thresholds.md` thresholds are met.
- Validate Markdown and CSV artifacts with `scripts/validate_n260_output.py`; use `references/artifact-frontmatter-contract.md` for required frontmatter and CSV metadata conventions.
- Use the validator domain profile inferred from `metadata.skill_id` or passed with `--skill`; for final handoff, run with `--domain-mode strict` when a machine-readable artifact is available.
- Track `STG-UNMAPPED` usage. If it exceeds thresholds in `references/signal-thresholds.md`, keep readiness no stronger than `constrained` and raise the configured feedback signal.
- Treat validator script version `3.1.3` as the governance implementation version for this package.
- For final handoff with multi-artifact composition, run `scripts/validate_n260_output.py --cross-validate <artifact_dir> --domain-mode complete`; after editing STG maps, run `scripts/validate_n260_output.py --validate-stg-map .`; use `--exclude PATTERN` for archive folders and `--complete-min N` only when a stricter/lighter final handoff threshold is intentionally required.

## Input tiers / input tiers
### minimal_inputs
Accept an API/service and at least one target SLO or capacity question. Generate a load/regression scenario with missing baseline limits called out.

### workflow_inputs
Prefer performance designs, SLO triplets, capacity model, API specs, historical performance data, environment inventory, monitoring stack, and release risk context.

### enhancement_inputs
Use production traffic distribution, previous benchmark runs, cost model, incident history, autoscaling policy, profiling data, and soak trend baselines.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 性能风险分析.md
- service SLO definitions
- production baseline history
- test environment capacity profile
- anonymized production snapshots
- monitoring dashboard links

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `perf_scope_summary`
- `scenario_rows[]`
- `perf_test_types[]`
- `baseline_comparison`
- `data_volume_alignment`
- `monitoring_stack`
- `reproducibility_plan`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `baseline_ref`
- `slo_triplet`
- `regression_delta`
- `abort_condition`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: performance_baseline_and_slo_validation`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.performance_test_scenario_generation`
- `workflow_node: N260`
- `node_artifact_target: 性能测试场景.csv`
- `evidence_profile`
- `tool_collaboration_mode`
- `schema_version: 2.1`
- `governance_revision: 3.1.3`
- `event_contract.produces_event`
- `routing.intent_tags`
- `routing.routing_keywords`
- `signal_emission.to_n005`
- `human_review.sla_priority`
- `schema_evolution.compatibility`



## Ownership and de-duplication / ownership and de-duplication
- Own performance questions: SLO, throughput, latency, capacity, scaling, regression, bottleneck, soak, and abort criteria.
- Do not own concurrency correctness. If high concurrency reveals race or locking correctness risks, link to 097.
- 094 may track whether performance evidence exists and who signs it off; 099 owns the scenario and pass/fail criteria.
- 093 may hard-veto from 099 summary but must not recalculate raw performance metrics.

## Design rules / design rules
- Assign each scenario one performance test type and clear objective.
- Compare current targets against a baseline or state why no reliable baseline exists yet.
- Check data volume realism before trusting any result.
- Specify the full monitoring stack needed to interpret the run.
- Require reproducibility rules so outlier runs do not drive gate decisions blindly.

## Execution workflow / execution workflow
1. Read performance-risk evidence, target SLOs, testcase assets, and environment capacity context.
2. Choose the required performance test types and define scenario rows with load shape and acceptance thresholds.
3. Attach baseline comparison, data-volume alignment, and monitoring requirements.
4. Add reproducibility rules, warm-up assumptions, and repeat-run expectations.
5. Emit gate-ready performance rows and downstream release/operations handoff.

## Dynamic completeness / dynamic completeness
- At minimum, define load and stress perspectives; core services should extend into spike, soak, or capacity modes when risk justifies it.
- If production-like data volume is unavailable, surface trust limits explicitly.
- If monitoring is incomplete, mark the result as low-confidence rather than overstating pass claims.

## Quality bar / quality bar
A good artifact states what performance question is being asked, what load shape answers it, how results compare to baseline, and whether the evidence is trustworthy enough for a gate decision.

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/performance-scenario-matrix.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/concurrency-performance-boundary.md`