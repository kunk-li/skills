# Internal classification to STG map v3.1.3

## Purpose
Bind the skill's internal categories to shared N260 STG tags so generated rows are deduplicable by 093 and N370.

| internal classification | default shared_scenario_tag | ownership_role | notes |
|---|---|---|---|
| `PK1_load_test` | `STG-PERFORMANCE-SLO-CAPACITY` | `canonical` | Own target throughput and SLO validation over sustained windows. |
| `PK2_stress_test` | `STG-PERFORMANCE-SLO-CAPACITY` | `canonical` | Own breaking point/capacity discovery; link to 097 for correctness anomalies. |
| `PK3_spike_test` | `STG-PERFORMANCE-SLO-CAPACITY` | `canonical` | Own sudden traffic spike, autoscaling, and degradation behavior. |
| `PK4_soak_test` | `STG-PERFORMANCE-SLO-CAPACITY` | `canonical` | Own long-run memory/gc/latency/resource-leak evidence. |
| `PK5_breakpoint_test` | `STG-PERFORMANCE-SLO-CAPACITY` | `canonical` | Own hard capacity ceiling and failure/degrade behavior. |
| `PK6_regression_test` | `STG-PERFORMANCE-REGRESSION` | `canonical` | Own baseline comparison and release-blocking performance regression. |

## Enforcement
- Every generated row should include the most specific internal classification and at least one default STG tag from this map.
- If a row spans multiple classifications, include multiple tags and mark only the canonical owner as `ownership_role: canonical`.
- If the map does not cover a new category, add a temporary `STG-UNMAPPED` note in `downstream_handoff` and mark readiness no stronger than `constrained` until the map is updated.

## STG-UNMAPPED governance limit
Use `STG-UNMAPPED` only as a temporary exception. More than 2 unmapped rows or more than 10% unmapped rows in one artifact is a governance signal and must keep readiness no stronger than `constrained` until the map is updated.


## v3.1.3 map integrity check
After editing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

The check fails if this file references an STG tag that is not defined in `references/cross-skill-orchestration.md`, except for the temporary `STG-UNMAPPED` exception.


## v3.1.3 owner-map consistency

After changing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

During artifact validation, `canonical_owner_skill` is checked against the canonical owner table in `cross-skill-orchestration.md`. Use `STG-UNMAPPED` only as a temporary constrained fallback, not as an owner bypass.
