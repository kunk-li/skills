# Mode x input tier matrix v3.1

## Purpose
Prevent mode and input-tier ambiguity. `selected_mode` is the work style; input tier is the evidence depth. They are related but not synonyms.

| selected_mode | input tier | rule |
|---|---|---|
| `load_test_only` | `minimal_inputs` | Allowed. One SLO or target API plus rough traffic expectation is enough. |
| `load_test_only` | `workflow_inputs` | Allowed. Use performance design, SLO triplets, capacity model, and API specs. |
| `load_test_only` | `enhancement_inputs` | Optional. Use historical baseline when available. |
| `full_spectrum` | `minimal_inputs` | Not sufficient. Produce only a scaffold and mark missing capacity/SLO/env data. |
| `full_spectrum` | `workflow_inputs` | Required. Include performance design, SLO triplets, capacity model, API specs, and env requirements. |
| `full_spectrum` | `enhancement_inputs` | Recommended. Use historical performance, production mix, cost model, and profiler availability. |
| `continuous_perf` | `minimal_inputs` | Allowed for recurring smoke perf template only; mark baseline missing. |
| `continuous_perf` | `workflow_inputs` | Required. Include CI/nightly trigger, baseline, SLO, and regression thresholds. |
| `continuous_perf` | `enhancement_inputs` | Recommended. Use trend history, anomaly thresholds, and capacity forecast. |

## Enforcement
- If the requested mode is not legal for the available input tier, either downgrade the mode or mark the result `insufficient_evidence`.
- Never silently promote minimal inputs into a full workflow claim.
- Record the chosen mode and input tier in `metadata.selected_mode` and `metadata.evidence_profile.input_completeness`.
