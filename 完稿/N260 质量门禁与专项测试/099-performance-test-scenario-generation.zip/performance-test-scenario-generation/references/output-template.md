# Output Template: 性能测试场景

## 推荐 csv 字段
`pf_id | scenario | load_model | target_object | slo | metric | bottleneck_hint | evidence_ref | status`

## 必覆盖
- 吞吐、时延、资源占用至少覆盖两类
- 对关键链路写清负载模型与 slo
- 对高风险场景给出瓶颈观察点或降级触发点

## 禁止
- ❌ 只写“压测一下”不写负载模型
- ❌ 不写 p95/p99、吞吐或资源指标


## v2.1 shared contract fields
Include these fields when the output is row-based:
`schema_version | shared_scenario_tag | ownership_role | canonical_owner_skill | related_specialty_refs | deduplicated_links | human_review_required | sla_priority | signal_to_n005`

Use `status=insufficient_evidence` instead of implying pass/fail when proof is missing.

## v3.1 governance fields
- Include `metadata.governance_revision: "3.1"`.
- Validate required metadata and item de-dup fields against `validation-rules.md`.
- Use `classification-to-stg-map.md` to set `shared_scenario_tag`.
- Use `signal-thresholds.md` before emitting to N005.

## Markdown and CSV frontmatter
For Markdown or CSV outputs, apply `references/artifact-frontmatter-contract.md` so the same metadata can be validated by `scripts/validate_n260_output.py`.
