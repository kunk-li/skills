# Performance scenario matrix

Supported performance test types:
- `load`
- `stress`
- `spike`
- `soak`
- `capacity`

Each scenario should declare:
- target qps or concurrency
- duration
- success criteria
- required telemetry
- baseline reference or no-baseline note

## v2.1 boundary with concurrency
099 owns SLO, throughput, latency, capacity, cost, bottleneck, regression, soak, and abort criteria. 097 owns correctness under simultaneous execution. If a test uses high concurrency only to produce load, it belongs to 099. If it uses synchronized actors to expose race correctness, it belongs to 097.
