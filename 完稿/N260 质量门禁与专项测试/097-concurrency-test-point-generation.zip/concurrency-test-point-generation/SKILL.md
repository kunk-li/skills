---
name: concurrency-test-point-generation
description: Generate concurrency test points for race surfaces, contention, isolation anomalies, deadlocks, lock ordering, distributed claims, and cache stampede; validates concurrent mechanics, links idempotency overlap.
---
# concurrency-test-point-generation


## Concurrency test routing table

| Situation | Action |
|---|---|
| Shared mutable state detected | Generate concurrent write race condition test |
| Database locking used | Generate deadlock scenario with circular lock order |
| Cache layer present | Generate cache stampede and stale-while-revalidate tests |
| Message queue consumption | Generate concurrent consumer duplicate-processing test |
| Distributed system | Generate split-brain and network partition scenarios |


## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n260.concurrency-test.v2.2"
contract_version: "n260.specialty.v2.2"
workflow_node: "N260"
node_artifact_target: "n260.concurrency_test_points"
function_bias: "analysis"
```


## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 并发测试点.csv. It delivers the concurrency specialty artifact for N260.

### Boundary
- Own scenario discovery, concurrency intensity selection, workload composition, tool suggestions, and concurrency-specific assertions.
- Consume concurrency design outputs from N170 and test assets from N230/N240.
- Do not collapse concurrency into raw performance or generic idempotency-only testing.
- Keep business race surfaces explicit instead of treating everything as load testing.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `single_api_load`: focus on concurrency risk for one API or one resource surface.
- `full_scenario`: cover the broader scenario catalog across create, update, state transition, pool, schedule, and callback races.
- `chaos_load`: combine concurrency with injected failures, dependency slowdowns, or partial outages.



## v2 reactive contract

> Full reactive contract spec (schema_version, governance_revision, produces_event, routing_keywords,
> signal_emission, human_review_sla, canonical_function) is in
> `references/n260-v2-reactive-contract.md`.

## Cross-skill integration map

| 上游 skill | 提供给 097 | 用途 |
|---|---|---|
| 系统并发模型/锁策略文档 | `concurrency_model` | 并发测试点的技术来源 |
| 098 idempotency-test-point-generation | 幂等语义 | 并发+幂等交叉验证 |

| 下游 skill | 097 输出 | 如何使用 |
|---|---|---|
| 093 quality-gate-check | `concurrency_test_results` | 门禁的并发安全维度 |
| 086 api-test-script-generation | `concurrency_test_points[]` | 并发点转为 API 压力测试脚本 |

**工作流位置**: 并发模型分析 → **097 并发测试点** → 086 脚本/093 门禁。

## Standalone usage guide

**Minimum input:** a shared resource name — no architecture diagram required.

**Standalone concurrency test generation:**
1. Infer likely race surfaces from resource name (e.g., "inventory" → concurrent writes).
2. Always include at least one deadlock scenario and one isolation test.
3. Declare assumed isolation level; set `pending_schema_confirmation`.

**Minimum viable output:**
```yaml
concurrency_test_points:
  readiness: constrained
  pending_schema_confirmation: true
  items:
    - tp_id: CTP-001
      surface: inventory_quantity
      pattern: concurrent_write
      test: 50 concurrent requests decrement same SKU — quantity must not go negative
      isolation_level: SERIALIZABLE
      source: inferred_from_resource_name
    - tp_id: CTP-002
      pattern: deadlock
      test: Simulate circular lock: order→inventory vs inventory→order
      source: mandatory_concurrency_baseline
```

## v3.1.3 P6 governance enforcement

See `references/n260-p6-governance.md` for the full governance enforcement rules (validator usage, STG mapping, signal thresholds, cross-validate commands).

## Input tiers / input tiers
### minimal_inputs
Accept one API/resource/rule suspected of race risk. Generate a race-surface test with explicit coordination primitive and conservative assumptions.

### workflow_inputs
Prefer concurrency design, transaction boundaries, tables, API specs, lock/isolation strategy, hotspot entities, idempotency summary, and performance constraints.

### enhancement_inputs
Use historical race bugs, production traffic shape, chaos tooling, thread/race detector availability, and observability configuration.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 并发控制建议.md
- 审计留痕方案.md
- 幂等设计建议.md
- 资源池配置
- hotspot entity list
- load tool constraints
- historical race bugs

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `scenario_scope_summary`
- `scenario_catalog_bindings[]`
- `test_points[]`
- `concurrency_dimensions[]`
- `concurrency_intensity_plan`
- `tool_recommendation`
- `assertion_matrix[]`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `coordination_primitive`
- `related_idempotency_ref`
- `related_consistency_ref`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


> `metadata` field requirements: see `references/n260-v2-reactive-contract.md`.



## Ownership and de-duplication / ownership and de-duplication
- Own concurrent execution mechanics: barrier/latch design, race trigger, isolation anomaly, lock order, deadlock, and repeat stability.
- For same-key concurrent requests, 097 owns `STG-CONCURRENCY-SAME-KEY-TRIGGER` while 098 owns `STG-IDEMPOTENCY-KEY-OUTCOME`.
- For balance or state-machine races, 097 owns the race trigger; 095 owns the data invariant and reconciliation.
- For high-QPS capacity and SLO, 099 owns performance; 097 only records correctness assertions under concurrent load.

## Design rules / design rules
- Bind each row to an explicit concurrency scenario rather than vague “stress” language.
- Choose concurrency intensity from expected traffic and business criticality, not only tool defaults.
- Cover same-user, multi-user-same-resource, multi-user-different-resource, and read-write mixes where relevant.
- Use assertions that describe success distribution, final state, audit side effects, and latency bounds.
- Call out when an overlap should be de-duplicated with idempotency or permission checks.

## Execution workflow / execution workflow
1. Read concurrency design, testcase assets, and risk findings to discover candidate race surfaces.
2. Map those surfaces to a scenario catalog and choose concurrency intensity levels.
3. Expand rows into workload dimensions, tools, and expected result distributions.
4. Attach state, audit, uniqueness, and latency assertions.
5. Emit gate-ready concurrency rows with de-duplication notes and downstream handoff.

## Dynamic completeness / dynamic completeness
- Low-volume APIs may only need low or medium concurrency, while shared-resource or high-QPS APIs must include higher-intensity cases.
- If concurrency control design is missing, state the uncertainty explicitly and keep test rows conservative.
- When overlap with idempotency exists, keep one canonical shared point and reference it from both specialties.



## Example usage

**Input**: inventory service with stock decrement endpoint; concurrent purchase scenario.

**Output** (excerpt):
```yaml
concurrency_test_points:
  - tp_id: CTP-001
    surface: stock_decrement
    scenario: simultaneous_purchase
    description: 10 concurrent requests to decrement same SKU by 1 when stock=5; verify final stock=0, not negative
    isolation_anomaly: dirty_write
    expected: exactly 5 requests succeed, 5 receive 409 or out-of-stock response
    priority: P0
  - tp_id: CTP-002
    surface: order_creation
    scenario: duplicate_submit
    description: Same user submits order twice within 200ms
    expected: one order created, second returns 409 or idempotency key response
    priority: P0
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Resilience and governance addendum

**Produced events**: Emit `produced_event: produced.n260.concurrency_test_points` in metadata when the artifact is complete or materially updated. Also emit `signal.n260.concurrency_gap` to N005 feedback loop when quantified thresholds in `references/signal-thresholds.md` are met.

**Confidence scoring**: Include `evidence_confidence: high/medium/low` in each item or dimension. Items with `evidence_confidence: low` must be flagged for `human_review_required: true` and must not be counted as passed in the quality gate.

**Circuit breaker**: circuit_breaker triggers when the same race surface is left untested across 3 consecutive releases.

**Traceability**: Every item must carry `canonical_owner_skill` and a reference to the upstream artifact or evidence id that produced it, enabling end-to-end traceability from requirement through to gate verdict in N270 and N280.

**Escalation path**: When `readiness: blocked` on any P0 item, escalate immediately to the release manager and the owning team lead. Log the escalation in `downstream_handoff.escalation_log[]`.

## Auditable rules summary

- R01_scope_grounded: every concurrency test point must reference a specific table, endpoint, field, or service; on_violation: reject.
- R02_ownership_tagged: each item must carry `canonical_owner_skill` and `shared_scenario_tag` when overlap with another N260 skill exists; on_violation: reject.
- R03_evidence_slot: every item must have an evidence or verification field; on_violation: reject.
- R04_no_duplication: deduplicate against items from other N260 skills using STG tags; on_violation: merge_or_reference.
- R05_priority_declared: every item must have a priority (P0/P1/P2); on_violation: assign_default.
- R06_isolation_level_tested: for each concurrency scenario involving shared state, the required DB isolation level must be stated and tested; on_violation: add_isolation_note.
- R07_deadlock_scenario_included: at least one deadlock or lock-contention scenario must be present when shared locks are used; on_violation: flag_gap.

## Algorithm

1. Parse inputs and identify scope: race surface, deadlock scenario, isolation anomaly, lock ordering, or cache stampede.
2. For each scope item, generate test points with owner tag (R02).
3. Assign evidence slot (R03) and priority (R05).
4. Deduplicate against other N260 skills using STG map (R04).
5. Validate each item references a specific artifact (R01).
6. Emit `test_points[]`, `ownership_map`, `dedup_log`.
7. Run `self_check`; set `readiness: blocked` if R01, R02, or R03 fires.

## Quality bar / quality bar
A good artifact makes race surfaces concrete, load levels justified, assertions precise, and overlap with other specialties easy to understand.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本（如 `n260.quality-gate-check.v2.2`），仅本 skill 字段变更时递增；
`governance_revision: "3.1.3"` — N260 组共享的 P6 治理框架修订号，修改 `n260-p6-governance.md` 时递增。
三套版本号独立变更，语义见 `references/n260-v2-reactive-contract.md`。

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/concurrency-test-patterns.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/concurrency-performance-boundary.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## Usage scenarios

- `race_surface_sweep`: identify and test all shared-state race conditions.
- `deadlock_detection`: generate deadlock and lock-contention scenarios.
- `isolation_validation`: test database isolation level requirements.
- `cache_stampede`: concurrent cache miss and thundering-herd scenarios.
