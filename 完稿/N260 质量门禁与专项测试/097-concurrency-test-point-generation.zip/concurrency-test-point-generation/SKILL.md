---
name: concurrency-test-point-generation
description: generate standalone or n260-composable concurrency test points for race surfaces, contention, isolation anomalies, deadlocks, lock ordering, scheduled jobs, distributed claims, cache stampede, and state-transition races. use when concurrent execution mechanics must be validated separately from performance capacity and when overlap with idempotency outcomes must be linked rather than duplicated.
---
# concurrency-test-point-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 并发测试点.csv. It delivers the concurrency specialty artifact for N260.

### Boundary
- Own scenario discovery, concurrency intensity selection, workload composition, tool suggestions, and concurrency-specific assertions.
- Consume concurrency design outputs from N170 and test assets from N230/N240.
- Do not collapse concurrency into raw performance or generic idempotency-only testing.
- Keep business race surfaces explicit instead of treating everything as load testing.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `single_api_load`: focus on concurrency risk for one API or one resource surface.
- `full_scenario`: cover the broader scenario catalog across create, update, state transition, pool, schedule, and callback races.
- `chaos_load`: combine concurrency with injected failures, dependency slowdowns, or partial outages.



## v2 reactive contract / v2 reactive contract
This skill is optimized for v2 reactive workflow and must remain useful both standalone and inside N260 composition.

```yaml
reactive_contract:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  produces_event: produced.n260.concurrency_test_points
  routing_keywords: ['n260', 'concurrency', 'race-condition', 'deadlock', 'isolation-level', 'contention', 'state-transition-race', 'lock-order']
  signal_emission_to_n005: ['concurrency_race', 'deadlock_risk', 'isolation_gap', 'flaky_race_regression']
  human_review_sla: "P0 for money, inventory, entitlement, or irreversible race risks; P1 for deadlock/isolation evidence gaps; P2 for lower-risk contention coverage"
  canonical_function: concurrency_and_contention_validation
```

- Owns race-surface discovery, simultaneous execution mechanics, isolation anomalies, lock ordering, deadlock induction, and stability repeats. It links to idempotency for duplicate outcome semantics.
- Always include `shared_scenario_tag`, `ownership_role`, and `canonical_owner_skill` when there is overlap with another N260 skill.
- Emit `produces_event` when the artifact is complete or materially updated.
- Emit N005 feedback signals only when quantified thresholds in `references/signal-thresholds.md` are met; otherwise keep findings local in `downstream_handoff`.



## v3.1.3 P6 governance enforcement
- Treat `references/cross-skill-orchestration.md` as the single source of truth for STG ownership tags; do not copy the STG table into other references.
- Before final handoff, apply `references/validation-rules.md`; validate JSON/YAML artifacts with `scripts/validate_n260_output.py` when a file artifact is available.
- Select mode and evidence tier using `references/mode-input-tier-matrix.md`; never silently promote minimal inputs into full workflow readiness.
- Map every internal category to a default STG tag using `references/classification-to-stg-map.md`.
- Emit N005 signals only when `references/signal-thresholds.md` thresholds are met.
- Validate Markdown and CSV artifacts with `scripts/validate_n260_output.py`; use `references/artifact-frontmatter-contract.md` for required frontmatter and CSV metadata conventions.
- Use the validator domain profile inferred from `metadata.skill_id` or passed with `--skill`; for final handoff, run with `--domain-mode strict` when a machine-readable artifact is available.
- Track `STG-UNMAPPED` usage. If it exceeds thresholds in `references/signal-thresholds.md`, keep readiness no stronger than `constrained` and raise the configured feedback signal.
- Treat validator script version `3.1.3` as the governance implementation version for this package.
- For final handoff with multi-artifact composition, run `scripts/validate_n260_output.py --cross-validate <artifact_dir> --domain-mode complete`; after editing STG maps, run `scripts/validate_n260_output.py --validate-stg-map .`; use `--exclude PATTERN` for archive folders and `--complete-min N` only when a stricter/lighter final handoff threshold is intentionally required.

## Input tiers / input tiers
### minimal_inputs
Accept one API/resource/rule suspected of race risk. Generate a race-surface test with explicit coordination primitive and conservative assumptions.

### workflow_inputs
Prefer concurrency design, transaction boundaries, tables, API specs, lock/isolation strategy, hotspot entities, idempotency summary, and performance constraints.

### enhancement_inputs
Use historical race bugs, production traffic shape, chaos tooling, thread/race detector availability, and observability configuration.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 并发控制建议.md
- 审计留痕方案.md
- 幂等设计建议.md
- 资源池配置
- hotspot entity list
- load tool constraints
- historical race bugs

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `scenario_scope_summary`
- `scenario_catalog_bindings[]`
- `test_points[]`
- `concurrency_dimensions[]`
- `concurrency_intensity_plan`
- `tool_recommendation`
- `assertion_matrix[]`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `coordination_primitive`
- `related_idempotency_ref`
- `related_consistency_ref`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: concurrency_and_contention_validation`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.concurrency_test_point_generation`
- `workflow_node: N260`
- `node_artifact_target: 并发测试点.csv`
- `evidence_profile`
- `tool_collaboration_mode`
- `schema_version: 2.1`
- `governance_revision: 3.1.3`
- `event_contract.produces_event`
- `routing.intent_tags`
- `routing.routing_keywords`
- `signal_emission.to_n005`
- `human_review.sla_priority`
- `schema_evolution.compatibility`



## Ownership and de-duplication / ownership and de-duplication
- Own concurrent execution mechanics: barrier/latch design, race trigger, isolation anomaly, lock order, deadlock, and repeat stability.
- For same-key concurrent requests, 097 owns `STG-CONCURRENCY-SAME-KEY-TRIGGER` while 098 owns `STG-IDEMPOTENCY-KEY-OUTCOME`.
- For balance or state-machine races, 097 owns the race trigger; 095 owns the data invariant and reconciliation.
- For high-QPS capacity and SLO, 099 owns performance; 097 only records correctness assertions under concurrent load.

## Design rules / design rules
- Bind each row to an explicit concurrency scenario rather than vague “stress” language.
- Choose concurrency intensity from expected traffic and business criticality, not only tool defaults.
- Cover same-user, multi-user-same-resource, multi-user-different-resource, and read-write mixes where relevant.
- Use assertions that describe success distribution, final state, audit side effects, and latency bounds.
- Call out when an overlap should be de-duplicated with idempotency or permission checks.

## Execution workflow / execution workflow
1. Read concurrency design, testcase assets, and risk findings to discover candidate race surfaces.
2. Map those surfaces to a scenario catalog and choose concurrency intensity levels.
3. Expand rows into workload dimensions, tools, and expected result distributions.
4. Attach state, audit, uniqueness, and latency assertions.
5. Emit gate-ready concurrency rows with de-duplication notes and downstream handoff.

## Dynamic completeness / dynamic completeness
- Low-volume APIs may only need low or medium concurrency, while shared-resource or high-QPS APIs must include higher-intensity cases.
- If concurrency control design is missing, state the uncertainty explicitly and keep test rows conservative.
- When overlap with idempotency exists, keep one canonical shared point and reference it from both specialties.

## Quality bar / quality bar
A good artifact makes race surfaces concrete, load levels justified, assertions precise, and overlap with other specialties easy to understand.

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/concurrency-test-patterns.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/concurrency-performance-boundary.md`