# Output Template: 并发测试点

## 推荐 csv 字段
`ct_id | race_type | object | trigger | concurrency_level | expected_behavior | lock_strategy | evidence_ref | status`

## 必覆盖
- 写写冲突或唯一性竞争至少一类
- 对关键链路给出并发量级或压测档位
- 说明期望行为是串行化、拒绝、重试还是幂等吸收

## 禁止
- ❌ 只写“多点几次”这种不可执行描述
- ❌ 不写并发量级与触发方式


## v2.1 shared contract fields
Include these fields when the output is row-based:
`schema_version | shared_scenario_tag | ownership_role | canonical_owner_skill | related_specialty_refs | deduplicated_links | human_review_required | sla_priority | signal_to_n005`

Use `status=insufficient_evidence` instead of implying pass/fail when proof is missing.

## v3.1 governance fields
- Include `metadata.governance_revision: "3.1"`.
- Validate required metadata and item de-dup fields against `validation-rules.md`.
- Use `classification-to-stg-map.md` to set `shared_scenario_tag`.
- Use `signal-thresholds.md` before emitting to N005.

## Markdown and CSV frontmatter
For Markdown or CSV outputs, apply `references/artifact-frontmatter-contract.md` so the same metadata can be validated by `scripts/validate_n260_output.py`.
