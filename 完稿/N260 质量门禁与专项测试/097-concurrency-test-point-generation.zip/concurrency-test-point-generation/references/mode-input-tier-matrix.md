# Mode x input tier matrix v3.1

## Purpose
Prevent mode and input-tier ambiguity. `selected_mode` is the work style; input tier is the evidence depth. They are related but not synonyms.

| selected_mode | input tier | rule |
|---|---|---|
| `single_api_load` | `minimal_inputs` | Allowed. One API/resource/rule suspected of race risk is enough. |
| `single_api_load` | `workflow_inputs` | Allowed. Use concurrency design, transaction design, and API specs. |
| `single_api_load` | `enhancement_inputs` | Optional. Use historical race bugs and race detector availability. |
| `full_scenario` | `minimal_inputs` | Not sufficient. Produce a starter surface map and mark missing design/table context. |
| `full_scenario` | `workflow_inputs` | Required. Include tables, API specs, transaction/concurrency design, and idempotency summary. |
| `full_scenario` | `enhancement_inputs` | Recommended. Use production traffic shape, hotspot entities, and observability. |
| `chaos_load` | `minimal_inputs` | Not sufficient for execution. Generate concept only with low confidence. |
| `chaos_load` | `workflow_inputs` | Required. Include dependency failure modes, lock/isolation strategy, and rollback expectations. |
| `chaos_load` | `enhancement_inputs` | Required for executable plan. Include chaos tooling, env safety, and observability. |

## Enforcement
- If the requested mode is not legal for the available input tier, either downgrade the mode or mark the result `insufficient_evidence`.
- Never silently promote minimal inputs into a full workflow claim.
- Record the chosen mode and input tier in `metadata.selected_mode` and `metadata.evidence_profile.input_completeness`.
