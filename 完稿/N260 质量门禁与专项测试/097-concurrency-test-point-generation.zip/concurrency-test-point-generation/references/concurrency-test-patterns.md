# Concurrency scenario catalog

Suggested scenario anchors:
- create_unique
- update_same_record
- balance_adjustment
- state_transition
- sequential_operation
- scheduled_batch
- distributed_claim
- cache_refresh
- leader_election
- resource_pool
- fan_out_fan_in
- external_callback_race

## v2.1 ownership boundaries
- 097 owns trigger mechanics and correctness under simultaneous execution.
- Use `STG-CONCURRENCY-SAME-KEY-TRIGGER` for concurrent same-key trigger setup, then link expected duplicate outcome to 098.
- Use `STG-CONCURRENCY-RACE-MECHANICS` for lock ordering, isolation, deadlock, state transition race, and barrier/latch setup.
- Link to 095 for final data invariant or reconciliation checks.
- Link to 099 only when the question is SLO, capacity, bottleneck, or regression rather than race correctness.
