# N260 示例输入输出 v2（扩展场景）

## 示例 3：并发测试点生成（concurrency-test-point-generation）

### 输入
- 场景：订单服务，共享库存写操作

### 输出
```yaml
concurrency_test_points:
  - tp_id: CTP-001
    surface: 库存扣减
    pattern: 竞争写
    isolation_level: SERIALIZABLE
    test: 100并发请求同一SKU，库存不可为负
  - tp_id: CTP-002
    pattern: 死锁
    test: 订单A锁库存→锁账户 vs 订单B锁账户→锁库存
```

## 示例 4：性能测试场景生成（performance-test-scenario-generation）

### 输入
- SLO：p95 ≤ 500ms，吞吐量 ≥ 1000 rps

### 输出
```yaml
performance_scenarios:
  - type: load
    config: 1000 rps × 10min
    slo_assertion:
      metric: p95_latency
      threshold: 500ms
      window: 10min
    abort_condition: error_rate > 5%
  - type: stress
    config: ramp 100→2000 rps
    abort_condition: p95 > 2000ms
```

## 097 扩展示例输入输出

### Scenario B — Cache stampede (thundering herd)

**Input**: Product listing page with Redis cache, TTL=60s, 500 concurrent users.

**Output** (`cache_stampede` mode):
```yaml
concurrency_test_points:
  - tp_id: CTP-CS001
    pattern: thundering_herd
    scenario: Cache expires while 500 concurrent requests arrive
    test: Expire cache, fire 500 concurrent GET /products — verify only 1 DB query
    expected: Single DB query; all 500 return within 2x normal latency
    mitigation_check: Probabilistic early expiration or mutex lock implemented
  - tp_id: CTP-CS002
    pattern: stale_while_revalidate
    test: Trigger background refresh during high read load
    expected: Atomic cache write; no empty or partial cache entries served
```



### Scenario C — Distributed split-brain

**Input**: Payment service with 2-node active-active cluster; network partition possible.

**Output** (`split_brain` scenario):
```yaml
concurrency_test_points:
  - tp_id: CTP-SB001
    pattern: split_brain
    scenario: Network partition isolates Node A from Node B during payment processing
    test: >
      Simulate network partition using tc netem or iptables rules.
      Send payment request to Node A. Verify: Node B does not process duplicate.
      Resolve partition. Verify: only one charge in DB.
    expected: Exactly one successful charge; split-brain resolver prevents duplicate
    isolation_mechanism: distributed_lock_or_consensus
  - tp_id: CTP-SB002
    pattern: leader_election_race
    scenario: Both nodes believe they are leader during election
    test: Trigger concurrent leadership claims; verify idempotent election outcome
    cross_reference: 098-idempotency-test-point-generation
```

### Scenario D — Distributed split-brain (active-active cluster)

**Input**: Payment service with 2-node active-active cluster; network partition possible.

**Output** (`split_brain` scenario):
```yaml
concurrency_test_points:
  - tp_id: CTP-SB001
    pattern: split_brain
    scenario: Network partition isolates Node A from Node B during payment processing
    test: >
      Simulate partition via tc netem or iptables.
      Send payment to Node A. Verify Node B does not process duplicate.
      Resolve partition. Verify: exactly one charge in DB.
    expected: Single successful charge; split-brain resolver prevents duplicate
    isolation_mechanism: distributed_lock_or_consensus
  - tp_id: CTP-SB002
    pattern: leader_election_race
    test: Trigger concurrent leadership claims; verify idempotent election outcome
    cross_reference: 098-idempotency-test-point-generation
```

### Scenario D — Database connection pool exhaustion

**Input**: 200 concurrent requests; DB connection pool size = 50; each request holds connection 500ms.

**Output** (pool exhaustion concurrency test):
```yaml
concurrency_test_points:
  - tp_id: CTP-POOL-001
    pattern: connection_pool_exhaustion
    config:
      concurrent_requests: 200
      pool_size: 50
      hold_duration_ms: 500
    test: >
      Fire 200 concurrent POST /api/v1/orders requests via k6/Gatling.
      Monitor: connection wait time, queue depth, timeout rate.
    expected:
      - Requests beyond pool capacity queue (not fail immediately)
      - Queue timeout returns 503 with Retry-After header
      - Pool metrics exposed via /actuator/metrics (or equivalent)
      - No deadlock — pool recovers fully after load subsides
  - tp_id: CTP-POOL-002
    pattern: pool_leak_detection
    test: Run 1000 sequential requests; monitor pool.active count after each batch
    expected: pool.active returns to 0 after each batch (no leaked connections)
```
