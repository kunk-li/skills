# Internal classification to STG map v3.1.3

## Purpose
Bind the skill's internal categories to shared N260 STG tags so generated rows are deduplicable by 093 and N370.

| internal classification | default shared_scenario_tag | ownership_role | notes |
|---|---|---|---|
| `S01_create_unique` | `STG-CONCURRENCY-SAME-KEY-TRIGGER` | `canonical` | Own simultaneous trigger/barrier. 098 owns idempotent duplicate outcome. |
| `S02_update_same_record` | `STG-CONCURRENCY-RACE-MECHANICS` | `canonical` | Own lock/CAS/race mechanics and final state distribution. |
| `S03_balance_adjustment` | `STG-CONCURRENCY-RACE-MECHANICS / STG-DATA-AGGREGATE-INVARIANT` | `canonical/supporting` | Own race trigger; 095 owns balance invariant and reconciliation. |
| `S04_state_transition` | `STG-CONCURRENCY-RACE-MECHANICS / STG-DATA-STATE-MACHINE-INVARIANT` | `canonical/supporting` | Own concurrent transition trigger; 095 owns legal state invariant. |
| `S05_sequential_op` | `STG-CONCURRENCY-RACE-MECHANICS` | `canonical` | Own ordering and serialization mechanics. |
| `S06_scheduled_batch` | `STG-CONCURRENCY-RACE-MECHANICS` | `canonical` | Own multi-instance scheduler lock behavior. |
| `S07_distributed_claim` | `STG-CONCURRENCY-RACE-MECHANICS` | `canonical` | Own inventory/claim race mechanics; link to 095 for aggregate drift. |
| `S08_cache_refresh` | `STG-CONCURRENCY-RACE-MECHANICS` | `canonical` | Own cache stampede and single-flight mechanics. |
| `S09_leader_election` | `STG-CONCURRENCY-RACE-MECHANICS` | `canonical` | Own leader uniqueness and split-brain checks. |
| `S10_resource_pool` | `STG-CONCURRENCY-RACE-MECHANICS` | `canonical` | Own pool contention correctness and graceful exhaustion. |
| `S11_fan_out_fan_in` | `STG-CONCURRENCY-RACE-MECHANICS` | `canonical` | Own aggregation correctness under parallel fan-out. |
| `S12_external_callback_race` | `STG-CONCURRENCY-RACE-MECHANICS` | `canonical` | Own callback/user-action race mechanics; link to 098 if duplicate/replay semantics apply. |

## Enforcement
- Every generated row should include the most specific internal classification and at least one default STG tag from this map.
- If a row spans multiple classifications, include multiple tags and mark only the canonical owner as `ownership_role: canonical`.
- If the map does not cover a new category, add a temporary `STG-UNMAPPED` note in `downstream_handoff` and mark readiness no stronger than `constrained` until the map is updated.

## STG-UNMAPPED governance limit
Use `STG-UNMAPPED` only as a temporary exception. More than 2 unmapped rows or more than 10% unmapped rows in one artifact is a governance signal and must keep readiness no stronger than `constrained` until the map is updated.


## v3.1.3 map integrity check
After editing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

The check fails if this file references an STG tag that is not defined in `references/cross-skill-orchestration.md`, except for the temporary `STG-UNMAPPED` exception.


## v3.1.3 owner-map consistency

After changing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

During artifact validation, `canonical_owner_skill` is checked against the canonical owner table in `cross-skill-orchestration.md`. Use `STG-UNMAPPED` only as a temporary constrained fallback, not as an owner bypass.
