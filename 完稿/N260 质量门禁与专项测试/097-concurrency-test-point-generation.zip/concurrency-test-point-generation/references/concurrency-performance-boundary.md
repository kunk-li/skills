# Concurrency vs performance boundary decision table v3.1

## Core rule
097 owns correctness under concurrent execution. 099 owns SLO/capacity under sustained or shaped load. Tool choice does not determine ownership.

| Scenario cue | Owner | Default quantitative boundary | Primary assertion |
|---|---|---|---|
| Same-key or same-record synchronized burst | 097 | 2-500 simultaneous actors, barrier/latch start, repeated 20-100 times | Exactly one winner, no duplicate, no illegal final state |
| Lock ordering, deadlock, isolation anomaly | 097 | Any QPS, because correctness is primary | Deadlock detected/recovered, no dirty/lost/phantom anomaly beyond design |
| Inventory/balance/state transition race | 097 primary, 095 supporting | Finite race burst; final invariant linked to 095 | No oversell/negative balance/illegal transition |
| Sustained target load | 099 | Hold target traffic for >= 5 minutes, typically >= 100 QPS or product-specific SLO window | p95/p99, error rate, throughput, resource utilization |
| Stress or breakpoint capacity test | 099 | Ramp until SLO breaks, usually >= 15 minutes or >= 3 load steps | Breaking point, bottleneck, graceful degradation |
| Spike/autoscaling test | 099 | Traffic jump >= 2x baseline or peak within <= 5 minutes | Scale-up, queueing, error budget, recovery time |
| k6/gatling/jmeter script with correctness assertion only | 097 | Short coordinated execution; duration is incidental | Final state distribution and race safety |
| k6/gatling/jmeter script with SLO assertion only | 099 | Time-windowed traffic profile | Latency/throughput/error rate |
| Mixed correctness and SLO test | Both, deduplicated | Split one row into 097 trigger/correctness and 099 SLO/capacity refs | Use `related_specialty_refs[]` and never double-count |

## Default handoff
When a 099 performance run exposes a correctness issue, open a supporting reference to 097. When a 097 race test exposes sustained latency or capacity risk, open a supporting reference to 099.
