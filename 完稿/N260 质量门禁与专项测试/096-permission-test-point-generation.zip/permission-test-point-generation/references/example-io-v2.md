# N260 示例输入输出 v2（扩展场景）

## 示例 3：并发测试点生成（concurrency-test-point-generation）

### 输入
- 场景：订单服务，共享库存写操作

### 输出
```yaml
concurrency_test_points:
  - tp_id: CTP-001
    surface: 库存扣减
    pattern: 竞争写
    isolation_level: SERIALIZABLE
    test: 100并发请求同一SKU，库存不可为负
  - tp_id: CTP-002
    pattern: 死锁
    test: 订单A锁库存→锁账户 vs 订单B锁账户→锁库存
```

## 示例 4：性能测试场景生成（performance-test-scenario-generation）

### 输入
- SLO：p95 ≤ 500ms，吞吐量 ≥ 1000 rps

### 输出
```yaml
performance_scenarios:
  - type: load
    config: 1000 rps × 10min
    slo_assertion:
      metric: p95_latency
      threshold: 500ms
      window: 10min
    abort_condition: error_rate > 5%
  - type: stress
    config: ramp 100→2000 rps
    abort_condition: p95 > 2000ms
```

## 096 扩展示例输入输出

### Example B — ABAC and Separation of Duties (SoD) scenario

**Input**: Financial system with ABAC policy (attribute-based) and SoD requirement: approver cannot also be the initiator.

**Output** (ABAC + SoD mode):
```yaml
permission_test_points:
  model: ABAC_with_SoD
  points:
    - tp_id: PTP-A001
      model: ABAC
      scenario: User with department=finance AND clearance=level2 can view salary reports
      attributes_required: [department:finance, clearance:level2]
      deny_path: department=hr AND clearance=level1 → 403
      pass_criterion: HTTP 200 with full report data

    - tp_id: PTP-A002
      model: ABAC
      scenario: Data residency attribute enforced — EU users cannot access US-only data
      attributes_required: [data_residency:EU]
      deny_path: data_residency:US data requested by EU user → 403

    - tp_id: PTP-SoD001
      model: SoD
      scenario: Payment initiator cannot approve their own payment
      rule: initiator_id must not equal approver_id
      test: User A creates payment → User A attempts approval → 403
      pass_criterion: Approval rejected with CONFLICT_OF_INTEREST error

    - tp_id: PTP-SoD002
      model: SoD
      scenario: Four-eyes principle for transfers above $50k
      test: Single approver cannot authorise >$50k transfer without second approver
      pass_criterion: System requires second_approver_id before processing

  compliance_evidence:
    - SOX_4.2: PTP-SoD001, PTP-SoD002
    - GDPR_Art25: PTP-A002
```


### Scenario C — API-level vs UI-level permission gap

**Input**: Admin-only "Delete User" button hidden in UI for non-admins, but API not restricted.

**Output** (UI vs API gap scenario):
```yaml
permission_test_points:
  - tp_id: PTP-UI-API-001
    scenario: UI hides Delete button for viewer role
    test: Log in as viewer; inspect DOM — Delete button absent
    expect: Button not rendered
  - tp_id: PTP-UI-API-002
    scenario: Direct API call bypasses UI restriction
    test: Viewer calls DELETE /api/v1/users/{id} directly
    expect: HTTP 403 — not HTTP 204
    vulnerability: UI-only restriction without API guard
    priority: P0_security
  - tp_id: PTP-UI-API-003
    scenario: IDOR via direct object reference
    test: User A calls GET /api/v1/users/{user_B_id}
    expect: HTTP 403 — not HTTP 200
```

### Scenario D — UI vs API permission gap (hidden button bypass)

**Input**: "Delete User" button hidden for viewer role in UI, but API endpoint not restricted.

**Output** (UI-vs-API gap test points):
```yaml
permission_test_points:
  - tp_id: PTP-UI-001
    scenario: UI hides Delete button for viewer role
    test: Log in as viewer; verify Delete button absent in DOM
    expect: Button not rendered
  - tp_id: PTP-UI-002
    scenario: Direct API call bypasses UI restriction
    test: Viewer calls DELETE /api/v1/users/{id} directly
    expect: HTTP 403 — not HTTP 204
    vulnerability: UI-only restriction without API guard
    priority: P0_security
  - tp_id: PTP-UI-003
    scenario: IDOR — user A accesses user B resource via direct API
    test: GET /api/v1/users/{user_B_id} authenticated as user A
    expect: HTTP 403
```

### Scenario D — Horizontal privilege escalation (IDOR)

**Input**: Multi-tenant SaaS; user A (tenant 1) attempts to access user B's (tenant 2) resources.

**Output** (IDOR + tenant isolation test points):
```yaml
permission_test_points:
  - tp_id: PTP-IDOR-001
    scenario: Direct object reference — user accesses another user's order
    test: GET /api/v1/orders/{order_id_of_user_B} authenticated as user A
    expect: HTTP 403
    vulnerability_class: IDOR
    priority: P0_security
  - tp_id: PTP-IDOR-002
    scenario: Tenant cross-contamination via query param manipulation
    test: GET /api/v1/reports?tenant_id={tenant_2_id} authenticated as tenant_1 user
    expect: HTTP 403 (not tenant 2's data)
  - tp_id: PTP-IDOR-003
    scenario: Mass assignment — user elevates own role via PUT payload
    test: PUT /api/v1/users/me with body {"role": "admin"}
    expect: HTTP 403 or role field ignored
    note: Role must only be settable by admin via admin API
```
