# Output Template: 权限测试点

## 推荐 csv 字段
`pt_id | role | resource | action | expected_result | channel | mask_rule | evidence_ref | status`

## 必覆盖
- 至少包含允许与拒绝两个方向
- 高风险资源必须覆盖字段级与渠道级限制
- 对临时授权或撤销场景给出时效性测试点

## 禁止
- ❌ 只写“越权测试”而不写角色、资源和动作
- ❌ 忽略脱敏或字段可见性


## v2.1 shared contract fields
Include these fields when the output is row-based:
`schema_version | shared_scenario_tag | ownership_role | canonical_owner_skill | related_specialty_refs | deduplicated_links | human_review_required | sla_priority | signal_to_n005`

Use `status=insufficient_evidence` instead of implying pass/fail when proof is missing.

## v3.1 governance fields
- Include `metadata.governance_revision: "3.1"`.
- Validate required metadata and item de-dup fields against `validation-rules.md`.
- Use `classification-to-stg-map.md` to set `shared_scenario_tag`.
- Use `signal-thresholds.md` before emitting to N005.

## Markdown and CSV frontmatter
For Markdown or CSV outputs, apply `references/artifact-frontmatter-contract.md` so the same metadata can be validated by `scripts/validate_n260_output.py`.
