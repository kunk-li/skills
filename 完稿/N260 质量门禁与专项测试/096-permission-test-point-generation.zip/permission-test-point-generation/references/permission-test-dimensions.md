# Permission test dimensions

Minimum dimensions to consider:
- matrix completeness
- direct privilege escalation
- indirect privilege escalation
- horizontal access abuse
- contextual authorization
- delegation / temporary token lifecycle
- separation of duties

## v2.1 boundary notes
- Delegation is planned temporary authority with scoped duration and revocation checks.
- Break-glass is emergency elevated authority with justification, alerting, expiry, and post-use review.
- Field masking visibility is owned by 096; downstream consistency of replicated or indexed masked fields may link to 095.
- 094 may track permission signoff as launch readiness but must not duplicate permission matrix rows.
