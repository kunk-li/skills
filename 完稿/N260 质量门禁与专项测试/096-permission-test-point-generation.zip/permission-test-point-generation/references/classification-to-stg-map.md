# Internal classification to STG map v3.1.3

## Purpose
Bind the skill's internal categories to shared N260 STG tags so generated rows are deduplicable by 093 and N370.

| internal classification | default shared_scenario_tag | ownership_role | notes |
|---|---|---|---|
| `PT1_role_matrix` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own role-resource-action allow/deny matrix coverage. |
| `PT2_idor` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own instance ownership and cross-user access checks. |
| `PT3_sod` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own separation-of-duties conflict tests. |
| `PT4_break_glass` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own emergency access lifecycle, audit, and expiry tests. |
| `PT5_delegation` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own delegated access scope/expiry/revocation tests. |
| `PT6_privilege_escalation` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own role/token/chain escalation attack paths. |
| `PT7_token_manipulation` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own auth token failure modes. |
| `PT8_scope_enforcement` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own OAuth/API scope checks. |
| `PT9_api_level_auth` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own API-layer enforcement; 094 only tracks signoff readiness. |
| `PT10_field_level_masking` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `canonical` | Own field visibility/masking; link to 095 only for data retention/integrity impacts. |

## Enforcement
- Every generated row should include the most specific internal classification and at least one default STG tag from this map.
- If a row spans multiple classifications, include multiple tags and mark only the canonical owner as `ownership_role: canonical`.
- If the map does not cover a new category, add a temporary `STG-UNMAPPED` note in `downstream_handoff` and mark readiness no stronger than `constrained` until the map is updated.

## STG-UNMAPPED governance limit
Use `STG-UNMAPPED` only as a temporary exception. More than 2 unmapped rows or more than 10% unmapped rows in one artifact is a governance signal and must keep readiness no stronger than `constrained` until the map is updated.


## v3.1.3 map integrity check
After editing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

The check fails if this file references an STG tag that is not defined in `references/cross-skill-orchestration.md`, except for the temporary `STG-UNMAPPED` exception.


## v3.1.3 owner-map consistency

After changing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

During artifact validation, `canonical_owner_skill` is checked against the canonical owner table in `cross-skill-orchestration.md`. Use `STG-UNMAPPED` only as a temporary constrained fallback, not as an owner bypass.
