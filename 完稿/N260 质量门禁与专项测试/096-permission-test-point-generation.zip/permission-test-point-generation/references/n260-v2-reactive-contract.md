# N260 v2 reactive contract

This reference makes the skill compatible with the v2 reactive workflow: event bus, artifact contract, three-layer routing, feedback loop, circuit breaker, progressive gate, and SLA human queue.

## Required result metadata
Every result should include these fields when the information is available:

```yaml
metadata:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  skill_id: "permission-test-point-generation"
  workflow_node: N260
  node_artifact_target: "权限测试点.csv"
  selected_mode: "<mode>"
  readiness: pass | constrained | blocked | insufficient_evidence
  evidence_profile:
    input_completeness: complete | partial | minimal
    evidence_confidence: high | medium | low
    missing_evidence: []
  routing:
    intent_tags: []
    routing_keywords: []
  event_contract:
    produces_event: "produced.n260.permission_test_points"
    event_payload_fields:
      - metadata
      - summary
      - items
      - blocker_state
      - downstream_handoff
  signal_emission:
    to_n005: []
    emit_when: []
  human_review:
    required: false
    sla_priority: P0 | P1 | P2
    trigger_reason: ""
  schema_evolution:
    compatibility: backward_compatible | breaking
    change_note: ""
```

## Readiness semantics
- `pass`: evidence supports the expected result and no blocking gap remains.
- `constrained`: work may continue, but a tracked condition, owner, or evidence gap remains.
- `blocked`: release or gate movement must stop until the blocker is resolved or formally overridden.
- `insufficient_evidence`: the skill can produce a useful artifact, but cannot claim pass/fail.

## Event bus and feedback loop
Emit the skill's `produces_event` whenever a final artifact is generated or materially updated. Emit N005 signals only for durable product/quality learning: recurring failures, release-blocking defects, customer-visible quality risk, repeated operational gaps, or regressions likely to affect future planning.

## SLA human queue
Use P0 when a release-blocking, compliance, security, money, entitlement, data corruption, severe SLO, or no-go condition exists. Use P1 when evidence/signoff is missing but the issue is expected to close in the current release window. Use P2 for preventive or informational follow-up.

## Schema evolution
Non-breaking changes may add optional fields or new enum values with fallback behavior. Breaking changes include renaming required fields, changing verdict semantics, or removing fields consumed by N260, N270, N280, N370, or N005.

## Shared scenario tags
The canonical shared scenario tag table is maintained only in `references/cross-skill-orchestration.md`. Do not copy the table into this file. Every item that overlaps with another N260 skill must reference a tag from that table.

## Runtime validation hook
Before finalizing a machine-readable artifact, validate it against `references/validation-rules.md`. If a JSON or YAML artifact file is available, run `scripts/validate_n260_output.py <artifact-file>` and fix reported errors or downgrade readiness to `insufficient_evidence`.

## Validator implementation version
Use `scripts/validate_n260_output.py --version` to confirm validator version `3.1.3` for this package. The schema remains `2.1`; governance enforcement is tracked separately by `governance_revision`.


## v3.1.3 governance implementation
`schema_version` remains `2.1`. `governance_revision` advances to `3.1.3` to represent P5 engineering controls: YAML fallback lists, STG map integrity validation, complete domain validation, and cross-artifact canonical conflict detection.


## v3.1.3 governance revision note

`governance_revision: "3.1.3"` keeps `schema_version: "2.1"` unchanged. The revision adds P6 validation controls only: complete threshold override, cross-validation excludes, and canonical owner consistency checks.
