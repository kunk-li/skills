# Mode x input tier matrix v3.1

## Purpose
Prevent mode and input-tier ambiguity. `selected_mode` is the work style; input tier is the evidence depth. They are related but not synonyms.

| selected_mode | input tier | rule |
|---|---|---|
| `rbac_only` | `minimal_inputs` | Allowed. A permission matrix or a small role/resource/action set is enough. |
| `rbac_only` | `workflow_inputs` | Allowed. Use permissions, authorization model, API specs, and ownership resources. |
| `rbac_only` | `enhancement_inputs` | Optional. Use audit policy and incident history if present. |
| `abac_mode` | `minimal_inputs` | Not sufficient for pass. Generate contextual assumptions and mark missing policy context. |
| `abac_mode` | `workflow_inputs` | Required. Include policy attributes, request context, resource state, and API specs. |
| `abac_mode` | `enhancement_inputs` | Recommended. Use compliance rules, geo/org constraints, and dynamic policy store behavior. |
| `sod_audit` | `minimal_inputs` | Allowed for rule discovery only. Mark missing role ownership and workflow sequence. |
| `sod_audit` | `workflow_inputs` | Required. Include SoD rules, actions, approver model, delegation/break-glass design. |
| `sod_audit` | `enhancement_inputs` | Recommended. Use audit logs and prior override history. |

## Enforcement
- If the requested mode is not legal for the available input tier, either downgrade the mode or mark the result `insufficient_evidence`.
- Never silently promote minimal inputs into a full workflow claim.
- Record the chosen mode and input tier in `metadata.selected_mode` and `metadata.evidence_profile.input_completeness`.
