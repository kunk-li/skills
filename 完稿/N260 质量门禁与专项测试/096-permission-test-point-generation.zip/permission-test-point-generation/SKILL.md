---
name: permission-test-point-generation
description: generate standalone or n260-composable permission and authorization test points from permission matrices, api specs, ownership rules, scopes, tokens, delegation, break-glass, sod, idor, and field masking needs. use for rbac or abac coverage, compliance evidence, penetration-test preparation, or when authorization specialty rows must feed n260 gate aggregation.
---
# permission-test-point-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 权限测试点.csv. It delivers the authorization specialty artifact for N260.

### Boundary
- Own permission matrix coverage, denial coverage, escalation resistance, contextual authorization, delegation, and SoD checks.
- Consume permission design and matrix artifacts rather than re-deriving the model from scratch.
- Do not replace security architecture review; focus on executable or checklist-ready authorization test points.
- Make allow, deny, and delegated cases equally visible.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `rbac_only`: focus on role-resource-action matrix coverage and straightforward allow/deny cases.
- `abac_mode`: add contextual policies such as time, geography, org scope, or state-based access.
- `sod_audit`: focus on separation-of-duties, delegation, and high-risk authorization edges.



## v2 reactive contract / v2 reactive contract
This skill is optimized for v2 reactive workflow and must remain useful both standalone and inside N260 composition.

```yaml
reactive_contract:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  produces_event: produced.n260.permission_test_points
  routing_keywords: ['n260', 'permission', 'authorization', 'rbac', 'abac', 'idor', 'sod', 'delegation', 'break-glass', 'field-masking']
  signal_emission_to_n005: ['authz_failure', 'permission_gap', 'sod_violation', 'sensitive_access_risk']
  human_review_sla: "P0 for IDOR, privilege escalation, SoD bypass, or sensitive-data exposure; P1 for incomplete matrix or missing audit evidence; P2 for coverage improvements"
  canonical_function: authorization_and_sod_validation
```

- Owns executable authorization coverage across role, resource, action, scope, token, SoD, delegation, break-glass, and field masking.
- Always include `shared_scenario_tag`, `ownership_role`, and `canonical_owner_skill` when there is overlap with another N260 skill.
- Emit `produces_event` when the artifact is complete or materially updated.
- Emit N005 feedback signals only when quantified thresholds in `references/signal-thresholds.md` are met; otherwise keep findings local in `downstream_handoff`.



## v3.1.3 P6 governance enforcement
- Treat `references/cross-skill-orchestration.md` as the single source of truth for STG ownership tags; do not copy the STG table into other references.
- Before final handoff, apply `references/validation-rules.md`; validate JSON/YAML artifacts with `scripts/validate_n260_output.py` when a file artifact is available.
- Select mode and evidence tier using `references/mode-input-tier-matrix.md`; never silently promote minimal inputs into full workflow readiness.
- Map every internal category to a default STG tag using `references/classification-to-stg-map.md`.
- Emit N005 signals only when `references/signal-thresholds.md` thresholds are met.
- Validate Markdown and CSV artifacts with `scripts/validate_n260_output.py`; use `references/artifact-frontmatter-contract.md` for required frontmatter and CSV metadata conventions.
- Use the validator domain profile inferred from `metadata.skill_id` or passed with `--skill`; for final handoff, run with `--domain-mode strict` when a machine-readable artifact is available.
- Track `STG-UNMAPPED` usage. If it exceeds thresholds in `references/signal-thresholds.md`, keep readiness no stronger than `constrained` and raise the configured feedback signal.
- Treat validator script version `3.1.3` as the governance implementation version for this package.
- For final handoff with multi-artifact composition, run `scripts/validate_n260_output.py --cross-validate <artifact_dir> --domain-mode complete`; after editing STG maps, run `scripts/validate_n260_output.py --validate-stg-map .`; use `--exclude PATTERN` for archive folders and `--complete-min N` only when a stricter/lighter final handoff threshold is intentionally required.

## Input tiers / input tiers
### minimal_inputs
Accept a role-resource-action matrix, API list, or sensitive resource list. Generate allow/deny and IDOR baseline rows with missing matrix cells called out.

### workflow_inputs
Prefer permission matrix, authorization model, API specs, data objects with ownership, token/scope rules, delegation policy, SoD rules, and audit requirements.

### enhancement_inputs
Use tenant/org hierarchy, identity-provider claims, break-glass policy, compliance roles, and prior authz incidents.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 权限模型设计.md
- 审计留痕方案.md
- delegation policy
- temporary token policy
- 组织结构或租户边界
- identity provider claims mapping

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `matrix_scope_summary`
- `permission_cells[]`
- `test_points[]`
- `privilege_escalation_tests[]`
- `contextual_permission_tests[]`
- `delegation_tests[]`
- `sod_tests[]`
- `missing_matrix_cells[]`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `policy_type`
- `audit_expectation`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: authorization_and_sod_validation`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.permission_test_point_generation`
- `workflow_node: N260`
- `node_artifact_target: 权限测试点.csv`
- `evidence_profile`
- `tool_collaboration_mode`
- `schema_version: 2.1`
- `governance_revision: 3.1.3`
- `event_contract.produces_event`
- `routing.intent_tags`
- `routing.routing_keywords`
- `signal_emission.to_n005`
- `human_review.sla_priority`
- `schema_evolution.compatibility`



## Ownership and de-duplication / ownership and de-duplication
- Own authorization test rows across RBAC, ABAC, IDOR, SoD, break-glass, delegation, token, scope, API-level auth, and field masking.
- 094 may reference permission completion as launch evidence but must not duplicate permission rows.
- 095 may own data consistency of masked or replicated fields; 096 owns who can see or mutate sensitive fields.
- Delegation is planned temporary authority; break-glass is emergency elevated authority with special monitoring and post-use review.

## Design rules / design rules
- Ensure every role-resource-action cell has an allow or deny test representation.
- Test direct escalation, indirect escalation, and horizontal access abuse separately.
- Represent contextual rules with explicit clocks, state assumptions, or environment assumptions.
- Cover delegation and temporary-token lifecycles when they exist.
- Treat SoD rules as first-class test points rather than narrative notes.

## Execution workflow / execution workflow
1. Read the permission matrix, authorization design, testcase context, and gate needs.
2. Normalize the matrix into allow and deny cells, then identify missing or risky coverage.
3. Add escalation, contextual, delegation, and SoD scenarios where relevant.
4. Mark overlaps with data consistency or audit checks through shared IDs.
5. Emit gate-ready permission rows and downstream release notes.

## Dynamic completeness / dynamic completeness
- Simple RBAC modules can stay matrix-driven; richer ABAC or delegated-access flows must expand contextual coverage.
- If the permission matrix is incomplete, surface missing cells instead of pretending test completeness.
- If compliance or PII access is involved, elevate denial and audit assertions explicitly.

## Quality bar / quality bar
A good artifact makes it easy to see who should be allowed, who must be denied, where escalation could happen, and which permission edges still lack evidence.

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/permission-test-dimensions.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`