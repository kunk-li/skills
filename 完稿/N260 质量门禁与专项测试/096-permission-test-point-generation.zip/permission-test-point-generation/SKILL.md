---
name: permission-test-point-generation
description: generate standalone or n260-composable permission and authorization test points from permission matrices, api specs, ownership rules, scopes, tokens, delegation, break-glass, sod, idor, and field masking needs. use for rbac or abac coverage, compliance evidence, penetration-test preparation, or when authorization specialty rows must feed n260 gate aggregation. trigger on any request to generate permission test points, validate RBAC or ABAC coverage, test authorization boundaries, check IDOR risks, or verify field masking. [N260]
---
# permission-test-point-generation


## Permission test routing table

| Situation | Action |
|---|---|
| RBAC model | Generate role matrix; include at least one IDOR test and privilege escalation |
| ABAC model | Test attribute combinations; include data residency and clearance checks |
| SoD requirement | Generate conflict-of-interest scenarios (initiator cannot approve) |
| API-level permission | Test both authorised and unauthorised paths for each endpoint |
| UI-level permission | Test that hidden UI elements are not accessible via direct API calls |


## Permission routing decision table

| Situation | Action |
|---|---|
| RBAC model | Generate role matrix; include IDOR and privilege escalation tests |
| ABAC model | Test attribute combinations; include data residency and clearance checks |
| SoD requirement | Generate conflict-of-interest scenarios (initiator ≠ approver) |
| API-level permission | Test authorised and unauthorised paths for each endpoint |
| UI-level permission | Verify hidden UI elements are also blocked at API level |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n260.permission-test.v2.2"
contract_version: "n260.specialty.v2.2"
workflow_node: "N260"
node_artifact_target: "n260.permission_test_points"
function_bias: "analysis"
```


## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 权限测试点.csv. It delivers the authorization specialty artifact for N260.

### Boundary
- Own permission matrix coverage, denial coverage, escalation resistance, contextual authorization, delegation, and SoD checks.
- Consume permission design and matrix artifacts rather than re-deriving the model from scratch.
- Do not replace security architecture review; focus on executable or checklist-ready authorization test points.
- Make allow, deny, and delegated cases equally visible.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `rbac_only`: focus on role-resource-action matrix coverage and straightforward allow/deny cases.
- `abac_mode`: add contextual policies such as time, geography, org scope, or state-based access.
- `sod_audit`: focus on separation-of-duties, delegation, and high-risk authorization edges.



## v2 reactive contract

> Full reactive contract spec (schema_version, governance_revision, produces_event, routing_keywords,
> signal_emission, human_review_sla, canonical_function) is in
> `references/n260-v2-reactive-contract.md`.

## Cross-skill integration map

| 上游 skill | 提供给 096 | 用途 |
|---|---|---|
| 系统权限矩阵/RBAC 定义 | `role_definitions` | 权限测试点的角色来源 |

| 下游 skill | 096 输出 | 如何使用 |
|---|---|---|
| 093 quality-gate-check | `permission_test_results` | 门禁的权限测试维度 |
| 086 api-test-script-generation | `permission_test_points[]` | 权限点转为参数化 API 测试 |

**工作流位置**: RBAC 定义 → **096 权限测试点** → 086 API脚本/093 门禁。

## Standalone usage guide

**Minimum input:** a role name and resource name — no RBAC matrix required.

**Standalone permission test generation:**
1. Infer common access patterns (admin→full, viewer→read-only, editor→read-write).
2. Always include at least one IDOR test point and one privilege escalation attempt.
3. Mark inferred permissions as `source: inferred`; set `pending_matrix_confirmation`.

**Minimum viable output:**
```yaml
permission_test_points:
  readiness: constrained
  pending_matrix_confirmation: true
  items:
    - tp_id: PTP-001
      model: RBAC
      scenario: admin reads any resource
      expect: HTTP 200
      source: inferred_standard_pattern
    - tp_id: PTP-002
      scenario: IDOR — user A accesses user B resource
      expect: HTTP 403
      source: mandatory_security_baseline
    - tp_id: PTP-003
      scenario: viewer attempts write operation
      expect: HTTP 403
      source: inferred_from_role_name
```

## v3.1.3 P6 governance enforcement

See `references/n260-p6-governance.md` for the full governance enforcement rules (validator usage, STG mapping, signal thresholds, cross-validate commands).

## Input tiers / input tiers
### minimal_inputs
Accept a role-resource-action matrix, API list, or sensitive resource list. Generate allow/deny and IDOR baseline rows with missing matrix cells called out.

### workflow_inputs
Prefer permission matrix, authorization model, API specs, data objects with ownership, token/scope rules, delegation policy, SoD rules, and audit requirements.

### enhancement_inputs
Use tenant/org hierarchy, identity-provider claims, break-glass policy, compliance roles, and prior authz incidents.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 权限模型设计.md
- 审计留痕方案.md
- delegation policy
- temporary token policy
- 组织结构或租户边界
- identity provider claims mapping

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `matrix_scope_summary`
- `permission_cells[]`
- `test_points[]`
- `privilege_escalation_tests[]`
- `contextual_permission_tests[]`
- `delegation_tests[]`
- `sod_tests[]`
- `missing_matrix_cells[]`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `policy_type`
- `audit_expectation`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


> `metadata` field requirements: see `references/n260-v2-reactive-contract.md`.



## Ownership and de-duplication / ownership and de-duplication
- Own authorization test rows across RBAC, ABAC, IDOR, SoD, break-glass, delegation, token, scope, API-level auth, and field masking.
- 094 may reference permission completion as launch evidence but must not duplicate permission rows.
- 095 may own data consistency of masked or replicated fields; 096 owns who can see or mutate sensitive fields.
- Delegation is planned temporary authority; break-glass is emergency elevated authority with special monitoring and post-use review.

## Design rules / design rules
- Ensure every role-resource-action cell has an allow or deny test representation.
- Test direct escalation, indirect escalation, and horizontal access abuse separately.
- Represent contextual rules with explicit clocks, state assumptions, or environment assumptions.
- Cover delegation and temporary-token lifecycles when they exist.
- Treat SoD rules as first-class test points rather than narrative notes.

## Execution workflow / execution workflow
1. Read the permission matrix, authorization design, testcase context, and gate needs.
2. Normalize the matrix into allow and deny cells, then identify missing or risky coverage.
3. Add escalation, contextual, delegation, and SoD scenarios where relevant.
4. Mark overlaps with data consistency or audit checks through shared IDs.
5. Emit gate-ready permission rows and downstream release notes.

## Dynamic completeness / dynamic completeness
- Simple RBAC modules can stay matrix-driven; richer ABAC or delegated-access flows must expand contextual coverage.
- If the permission matrix is incomplete, surface missing cells instead of pretending test completeness.
- If compliance or PII access is involved, elevate denial and audit assertions explicitly.



## Example usage

**Input**: permission matrix — Admin can CRUD all resources; User can read own orders only; Guest can browse products.

**Output** (excerpt):
```yaml
permission_test_points:
  - tp_id: PTP-001
    role: user
    action: GET /orders/{id}
    scenario: access_own_order
    expected: 200
    priority: P0
  - tp_id: PTP-002
    role: user
    action: GET /orders/{other_user_id}
    scenario: idor_attempt
    expected: 403
    priority: P0
  - tp_id: PTP-003
    role: guest
    action: POST /orders
    scenario: unauthorized_create
    expected: 401
    priority: P0
  - tp_id: PTP-004
    role: admin
    action: DELETE /orders/{id}
    scenario: admin_delete
    expected: 200
    priority: P1
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Resilience and governance addendum

**Produced events**: Emit `produced_event: produced.n260.permission_test_points` in metadata when the artifact is complete or materially updated. Also emit `signal.n260.permission_gap` to N005 feedback loop when quantified thresholds in `references/signal-thresholds.md` are met.

**Confidence scoring**: Include `evidence_confidence: high/medium/low` in each item or dimension. Items with `evidence_confidence: low` must be flagged for `human_review_required: true` and must not be counted as passed in the quality gate.

**Circuit breaker**: circuit_breaker triggers when IDOR or privilege-escalation test points consistently lack coverage across 3 releases.

**Traceability**: Every item must carry `canonical_owner_skill` and a reference to the upstream artifact or evidence id that produced it, enabling end-to-end traceability from requirement through to gate verdict in N270 and N280.

**Escalation path**: When `readiness: blocked` on any P0 item, escalate immediately to the release manager and the owning team lead. Log the escalation in `downstream_handoff.escalation_log[]`.

## Auditable rules summary

- R01_scope_grounded: every permission test point must reference a specific table, endpoint, field, or service; on_violation: reject.
- R02_ownership_tagged: each item must carry `canonical_owner_skill` and `shared_scenario_tag` when overlap with another N260 skill exists; on_violation: reject.
- R03_evidence_slot: every item must have an evidence or verification field; on_violation: reject.
- R04_no_duplication: deduplicate against items from other N260 skills using STG tags; on_violation: merge_or_reference.
- R05_priority_declared: every item must have a priority (P0/P1/P2); on_violation: assign_default.
- R06_negative_test_required: for each permission boundary, at least one negative test (deny path) must be included; on_violation: add_negative.
- R07_privilege_escalation_covered: test points must include at least one privilege-escalation attempt scenario; on_violation: flag_gap.

## Algorithm

1. Parse inputs and identify scope: RBAC/ABAC matrix, IDOR risk, field masking, delegation, and break-glass scenario.
2. For each scope item, generate test points with owner tag (R02).
3. Assign evidence slot (R03) and priority (R05).
4. Deduplicate against other N260 skills using STG map (R04).
5. Validate each item references a specific artifact (R01).
6. Emit `test_points[]`, `ownership_map`, `dedup_log`.
7. Run `self_check`; set `readiness: blocked` if R01, R02, or R03 fires.

## Quality bar / quality bar
A good artifact makes it easy to see who should be allowed, who must be denied, where escalation could happen, and which permission edges still lack evidence.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本（如 `n260.quality-gate-check.v2.2`），仅本 skill 字段变更时递增；
`governance_revision: "3.1.3"` — N260 组共享的 P6 治理框架修订号，修改 `n260-p6-governance.md` 时递增。
三套版本号独立变更，语义见 `references/n260-v2-reactive-contract.md`。

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/permission-test-dimensions.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## Usage scenarios

- `rbac_sweep`: generate test points for role-based access control matrix.
- `abac_policy`: attribute-based access control policy test generation.
- `sod_validation`: separation of duties conflict test points.
- `idor_check`: insecure direct object reference test coverage.
