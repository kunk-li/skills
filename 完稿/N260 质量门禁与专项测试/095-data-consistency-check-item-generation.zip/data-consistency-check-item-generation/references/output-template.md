# Output Template: 数据一致性检查项

## 推荐 csv 字段
`dc_id | consistency_type | object | trigger | expected_behavior | recovery | evidence_ref | status`

## 必覆盖
- 缓存 / 消息 / 事务 / 最终一致性 四类至少覆盖相关项
- 说明触发条件、期望表现与恢复方式
- 结果缺证时必须保留 `待确认`

## 禁止
- ❌ 只写“数据一致”而不写对象和触发条件
- ❌ 忽略恢复或补偿路径


## v2.1 shared contract fields
Include these fields when the output is row-based:
`schema_version | shared_scenario_tag | ownership_role | canonical_owner_skill | related_specialty_refs | deduplicated_links | human_review_required | sla_priority | signal_to_n005`

Use `status=insufficient_evidence` instead of implying pass/fail when proof is missing.

## v3.1 governance fields
- Include `metadata.governance_revision: "3.1"`.
- Validate required metadata and item de-dup fields against `validation-rules.md`.
- Use `classification-to-stg-map.md` to set `shared_scenario_tag`.
- Use `signal-thresholds.md` before emitting to N005.

## Markdown and CSV frontmatter
For Markdown or CSV outputs, apply `references/artifact-frontmatter-contract.md` so the same metadata can be validated by `scripts/validate_n260_output.py`.
