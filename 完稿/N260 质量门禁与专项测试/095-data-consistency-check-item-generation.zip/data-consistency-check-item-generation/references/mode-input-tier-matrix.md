# Mode x input tier matrix v3.1

## Purpose
Prevent mode and input-tier ambiguity. `selected_mode` is the work style; input tier is the evidence depth. They are related but not synonyms.

| selected_mode | input tier | rule |
|---|---|---|
| `within_db_only` | `minimal_inputs` | Allowed. One table pair, FK, aggregate, or state field is enough. |
| `within_db_only` | `workflow_inputs` | Allowed. Use tables, data flows, and transaction design. |
| `within_db_only` | `enhancement_inputs` | Optional. Use historical drift if present. |
| `distributed_mode` | `minimal_inputs` | Not sufficient for final status. Generate assumed cross-service checks and mark missing topology. |
| `distributed_mode` | `workflow_inputs` | Required. Consume data flows, services, transaction/saga design, and source of truth. |
| `distributed_mode` | `enhancement_inputs` | Recommended. Use event schema, queue retention, replay history, and failure logs. |
| `continuous_reconciliation` | `minimal_inputs` | Allowed for template only. Require schedule assumptions and low confidence. |
| `continuous_reconciliation` | `workflow_inputs` | Required. Include frequency, coverage, metrics, and alerting. |
| `continuous_reconciliation` | `enhancement_inputs` | Recommended. Use production volume, drift rate, and alert history. |

## Enforcement
- If the requested mode is not legal for the available input tier, either downgrade the mode or mark the result `insufficient_evidence`.
- Never silently promote minimal inputs into a full workflow claim.
- Record the chosen mode and input tier in `metadata.selected_mode` and `metadata.evidence_profile.input_completeness`.
