# Data consistency kinds

- `CC01 within_database`
- `CC02 across_databases`
- `CC03 master_replica`
- `CC04 db_cache`
- `CC05 db_search_index`
- `CC06 cross_service`
- `CC07 external_system`

For each kind, declare whether the expected model is strong, eventual, or eventual-with-lag-bounds.

## v2.1 ownership boundaries
- 095 owns data invariants and reconciliation, not idempotency key behavior.
- Use `STG-DATA-AGGREGATE-INVARIANT` for balance, count, and derived-field checks.
- Use `STG-DATA-STATE-MACHINE-INVARIANT` for legal state and repair checks.
- Link to 098 for key, payload, TTL, retry, webhook replay, and message-redelivery outcome checks.
- Link to 097 for race-trigger, lock, isolation, and deadlock mechanics.
