# N260 示例输入输出 v2（扩展场景）

## 示例 3：并发测试点生成（concurrency-test-point-generation）

### 输入
- 场景：订单服务，共享库存写操作

### 输出
```yaml
concurrency_test_points:
  - tp_id: CTP-001
    surface: 库存扣减
    pattern: 竞争写
    isolation_level: SERIALIZABLE
    test: 100并发请求同一SKU，库存不可为负
  - tp_id: CTP-002
    pattern: 死锁
    test: 订单A锁库存→锁账户 vs 订单B锁账户→锁库存
```

## 示例 4：性能测试场景生成（performance-test-scenario-generation）

### 输入
- SLO：p95 ≤ 500ms，吞吐量 ≥ 1000 rps

### 输出
```yaml
performance_scenarios:
  - type: load
    config: 1000 rps × 10min
    slo_assertion:
      metric: p95_latency
      threshold: 500ms
      window: 10min
    abort_condition: error_rate > 5%
  - type: stress
    config: ramp 100→2000 rps
    abort_condition: p95 > 2000ms
```

## 095 扩展示例输入输出

### Scenario B — Saga boundary check

**Input**: Order saga: create_order → reserve_inventory → charge_payment → send_confirmation.

**Output** (`saga_boundary` mode):
```yaml
consistency_checks:
  mode: saga_boundary
  saga: order_fulfillment
  checks:
    - check_id: CC-S001
      type: saga_boundary
      boundary: reserve_inventory fails
      check: create_order must be compensated — order status set to CANCELLED
      compensation_action: OrderCompensationService.cancelOrder(order_id)
    - check_id: CC-S002
      boundary: send_confirmation fails
      check: payment must NOT be reversed — notification uses async retry
      idempotency_required: true
      cross_reference: 098-idempotency-test-point-generation
```



### Scenario C — Tenant isolation check

**Input**: Multi-tenant SaaS with shared DB; tenant_id column used for isolation.

**Output** (`multi_tenant` consistency mode):
```yaml
consistency_checks:
  mode: multi_tenant
  checks:
    - check_id: CC-T001
      type: tenant_isolation
      entity: orders
      check: No query returns rows from a different tenant_id than the authenticated user
      sql_template: |
        SELECT COUNT(*) FROM orders
        WHERE tenant_id != :current_tenant_id
        AND session_user_id = :user_id;
        -- Expected: 0
    - check_id: CC-T002
      type: cross_tenant_reference
      check: No FK references span tenant boundaries
      sql_template: |
        SELECT o.id FROM orders o
        JOIN customers c ON o.customer_id = c.id
        WHERE o.tenant_id != c.tenant_id;
        -- Expected: 0 rows
```

### Scenario D — Tenant isolation check (multi-tenant SaaS)

**Input**: Multi-tenant SaaS with shared DB; `tenant_id` column for isolation.

**Output** (`multi_tenant` consistency mode):
```yaml
consistency_checks:
  mode: multi_tenant
  checks:
    - check_id: CC-T001
      type: tenant_isolation
      entity: orders
      check: No query returns rows from a different tenant_id than the authenticated user
      sql_template: |
        SELECT COUNT(*) FROM orders
        WHERE tenant_id != :current_tenant_id AND session_user_id = :user_id;
        -- Expected: 0
    - check_id: CC-T002
      type: cross_tenant_reference
      check: No FK references span tenant boundaries
      sql_template: |
        SELECT o.id FROM orders o
        JOIN customers c ON o.customer_id = c.id
        WHERE o.tenant_id != c.tenant_id;
        -- Expected: 0 rows
```

### Scenario D — Event-driven saga consistency

**Input**: Order saga: `charge_payment` → `update_inventory` → `send_confirmation`. Inventory update failed mid-saga.

**Output** (saga consistency check):
```yaml
consistency_checks:
  mode: saga_compensation
  saga: order_creation
  checks:
    - check_id: CC-SAGA-001
      type: compensation_completeness
      check: If update_inventory fails, charge_payment is compensated (refunded)
      sql_template: |
        SELECT o.id FROM orders o
        WHERE o.status = 'INVENTORY_FAILED'
          AND NOT EXISTS (
            SELECT 1 FROM payments p
            WHERE p.order_id = o.id AND p.status = 'REFUNDED'
          );
        -- Expected: 0 rows (all failed orders must have refund)
    - check_id: CC-SAGA-002
      type: orphan_reservation
      check: No inventory reservation exists for a fully failed order
      sql_template: |
        SELECT r.id FROM inventory_reservations r
        JOIN orders o ON r.order_id = o.id
        WHERE o.status IN ('FAILED', 'CANCELLED')
          AND r.status != 'RELEASED';
        -- Expected: 0 rows
```
