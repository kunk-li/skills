---
name: data-consistency-check-item-generation
description: generate standalone or n260-composable data consistency and reconciliation check items for tables, aggregates, data flows, cross-service sagas, eventual consistency bounds, and recovery paths. use for fk orphan checks, balance or count invariants, source-of-truth comparison, drift detection, repair planning, or when overlapping idempotency and concurrency risks need de-duplicated links.
---
# data-consistency-check-item-generation

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 数据一致性检查项.csv. It delivers the specialty consistency-check artifact for N260.

### Boundary
- Own consistency-kind selection, reconciliation checks, failure scenarios, and remediation paths.
- Cover within-database, cross-database, cache, search index, cross-service, and external-system consistency without collapsing them into one generic list.
- Do not replace performance or permission testing; link overlap through de-duplication rather than repetition.
- Make eventual-vs-strong consistency expectations explicit.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `within_db_only`: focus on same-database consistency, constraints, and repair checks.
- `distributed_mode`: cover multi-database, cross-service, cache, and external-system consistency.
- `continuous_reconciliation`: design checks suitable for recurring or continuous reconciliation rather than one-off validation.



## v2 reactive contract / v2 reactive contract
This skill is optimized for v2 reactive workflow and must remain useful both standalone and inside N260 composition.

```yaml
reactive_contract:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  produces_event: produced.n260.data_consistency_checks
  routing_keywords: ['n260', 'data-consistency', 'reconciliation', 'referential-integrity', 'saga-consistency', 'aggregate-invariant', 'recovery']
  signal_emission_to_n005: ['data_drift', 'reconciliation_gap', 'recovery_gap', 'consistency_regression']
  human_review_sla: "P0 for money, entitlement, compliance, or customer-visible drift; P1 for recoverable reconciliation gaps; P2 for preventive checks"
  canonical_function: consistency_and_reconciliation_planning
```

- Owns data invariants, reconciliation, drift detection, and recovery paths. It links to idempotency or concurrency rows when those skills own duplicate-key or race-trigger mechanics.
- Always include `shared_scenario_tag`, `ownership_role`, and `canonical_owner_skill` when there is overlap with another N260 skill.
- Emit `produces_event` when the artifact is complete or materially updated.
- Emit N005 feedback signals only when quantified thresholds in `references/signal-thresholds.md` are met; otherwise keep findings local in `downstream_handoff`.



## v3.1.3 P6 governance enforcement
- Treat `references/cross-skill-orchestration.md` as the single source of truth for STG ownership tags; do not copy the STG table into other references.
- Before final handoff, apply `references/validation-rules.md`; validate JSON/YAML artifacts with `scripts/validate_n260_output.py` when a file artifact is available.
- Select mode and evidence tier using `references/mode-input-tier-matrix.md`; never silently promote minimal inputs into full workflow readiness.
- Map every internal category to a default STG tag using `references/classification-to-stg-map.md`.
- Emit N005 signals only when `references/signal-thresholds.md` thresholds are met.
- Validate Markdown and CSV artifacts with `scripts/validate_n260_output.py`; use `references/artifact-frontmatter-contract.md` for required frontmatter and CSV metadata conventions.
- Use the validator domain profile inferred from `metadata.skill_id` or passed with `--skill`; for final handoff, run with `--domain-mode strict` when a machine-readable artifact is available.
- Track `STG-UNMAPPED` usage. If it exceeds thresholds in `references/signal-thresholds.md`, keep readiness no stronger than `constrained` and raise the configured feedback signal.
- Treat validator script version `3.1.3` as the governance implementation version for this package.
- For final handoff with multi-artifact composition, run `scripts/validate_n260_output.py --cross-validate <artifact_dir> --domain-mode complete`; after editing STG maps, run `scripts/validate_n260_output.py --validate-stg-map .`; use `--exclude PATTERN` for archive folders and `--complete-min N` only when a stricter/lighter final handoff threshold is intentionally required.

## Input tiers / input tiers
### minimal_inputs
Accept table/schema or data-flow evidence. Generate referential integrity, aggregate invariant, and reconciliation checks with assumptions marked.

### workflow_inputs
Prefer data flows, table schemas, services, transaction boundaries, saga design, event/topic definitions, cache topology, and repair runbooks.

### enhancement_inputs
Use incident drift history, reconciliation job metrics, source-of-truth rules, audit design, idempotency summary, and concurrency race summary.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 表结构设计草案.sql
- 索引建议清单.csv
- 审计留痕方案.md
- 事件定义或topic清单
- cache topology
- external system contracts
- repair runbooks

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `consistency_scope_summary`
- `check_items[]`
- `consistency_kind_matrix[]`
- `failure_scenarios[]`
- `remediation_strategies[]`
- `deduplicated_links[]`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `related_specialty_refs[]`
- `reconciliation_owner`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: consistency_and_reconciliation_planning`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.data_consistency_check_item_generation`
- `workflow_node: N260`
- `node_artifact_target: 数据一致性检查项.csv`
- `evidence_profile`
- `tool_collaboration_mode`
- `schema_version: 2.1`
- `governance_revision: 3.1.3`
- `event_contract.produces_event`
- `routing.intent_tags`
- `routing.routing_keywords`
- `signal_emission.to_n005`
- `human_review.sla_priority`
- `schema_evolution.compatibility`



## Ownership and de-duplication / ownership and de-duplication
- Own data invariants, reconciliation, source-of-truth comparison, drift detection, and recovery.
- Do not own idempotency key semantics. For same-key/same-payload, TTL, payload equivalence, retry, webhook replay, or message redelivery, link to 098 using `STG-IDEMPOTENCY-*` tags.
- Do not own race-trigger mechanics. For concurrent state transition, balance deduction trigger, lock ordering, or deadlock, link to 097 using `STG-CONCURRENCY-*` tags.
- For balance or count consistency, 095 owns the invariant and reconciliation; 097 may own the race trigger that violates it.

## Design rules / design rules
- Assign one consistency_kind to every row and make the expected consistency model explicit.
- Cover both nominal and degraded scenarios such as replica lag, cache miss storms, message backlog, or network partitions.
- Prefer remediation-aware checks over alarm-only rows when a repair path is known.
- Mark overlaps with permission, concurrency, or idempotency checks instead of duplicating them blindly.
- Call out the data source, reconciliation method, and acceptance threshold for each check.

## Execution workflow / execution workflow
1. Read data-flow, schema, testcase, and nonfunctional context relevant to consistency surfaces.
2. Choose consistency kinds and enumerate check rows with method, threshold, and evidence expectations.
3. Add degraded or recovery scenarios for each important consistency surface.
4. Attach remediation or recovery guidance where feasible.
5. Emit de-duplicated rows ready for gate aggregation and release-readiness handoff.

## Dynamic completeness / dynamic completeness
- Simple services can focus on within-db and db-cache checks; distributed flows should expand into cross-service and external-system models.
- If topology is unclear, keep row structure stable and mark topology assumptions openly.
- When eventual consistency is accepted, define lag bounds and reconciliation cadence instead of pretending strong consistency.

## Quality bar / quality bar
A good artifact makes it clear what consistency promise is expected, how it will be checked, what failure modes matter, and how the team recovers when drift is found.

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/data-consistency-types.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`