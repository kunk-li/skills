---
name: data-consistency-check-item-generation
description: generate standalone or n260-composable data consistency and reconciliation check items for tables, aggregates, data flows, cross-service sagas, eventual consistency bounds, and recovery paths. use for fk orphan checks, balance or count invariants, source-of-truth comparison, drift detection, repair planning, or when overlapping idempotency and concurrency risks need de-duplicated links. trigger on any request to generate data consistency checks, produce reconciliation items, verify FK integrity, check cross-service data sync, or validate aggregate counts. [N260]
---
# data-consistency-check-item-generation


## Consistency check routing table

| Situation | Action |
|---|---|
| FK relationship detected | Generate FK orphan check for all child tables |
| Aggregate invariant in domain model | Generate balance/total consistency check |
| Distributed saga identified | Generate saga boundary compensation check |
| Soft-delete pattern present | Generate logical delete consistency check (exclude soft-deleted rows) |
| Multi-tenant system | Generate tenant isolation check (cross-tenant data leakage) |


## Consistency routing decision table

| Situation | Action |
|---|---|
| FK relationship present | Generate orphan check for all child tables |
| Aggregate invariant in domain | Generate balance/total check (e.g., order_total == sum of line items) |
| Distributed saga identified | Generate saga boundary compensation check |
| Soft-delete pattern used | Generate logical-delete consistency check |
| Multi-tenant data | Generate tenant isolation check (cross-tenant data leakage prevention) |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n260.data-consistency.v2.2"
contract_version: "n260.specialty.v2.2"
workflow_node: "N260"
node_artifact_target: "n260.consistency_check_items"
function_bias: "analysis"
```


## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 数据一致性检查项.csv. It delivers the specialty consistency-check artifact for N260.

### Boundary
- Own consistency-kind selection, reconciliation checks, failure scenarios, and remediation paths.
- Cover within-database, cross-database, cache, search index, cross-service, and external-system consistency without collapsing them into one generic list.
- Do not replace performance or permission testing; link overlap through de-duplication rather than repetition.
- Make eventual-vs-strong consistency expectations explicit.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `within_db_only`: focus on same-database consistency, constraints, and repair checks.
- `distributed_mode`: cover multi-database, cross-service, cache, and external-system consistency.
- `continuous_reconciliation`: design checks suitable for recurring or continuous reconciliation rather than one-off validation.



## v2 reactive contract

> Full reactive contract spec (schema_version, governance_revision, produces_event, routing_keywords,
> signal_emission, human_review_sla, canonical_function) is in
> `references/n260-v2-reactive-contract.md`.

## Cross-skill integration map

| 上游 skill | 提供给 095 | 用途 |
|---|---|---|
| 数据库 schema/迁移脚本 | `entity_definitions` | 一致性检查项的实体来源 |
| 098 idempotency-test-point-generation | `idempotency_keys` | 幂等键一致性是数据一致性子集 |

| 下游 skill | 095 输出 | 如何使用 |
|---|---|---|
| 093 quality-gate-check | `consistency_check_results` | 门禁的数据一致性维度 |
| 开发修复 | `consistency_violations[]` | 精确的违规位置加速修复 |

**工作流位置**: Schema 分析 → **095 一致性检查项** → 093 质量门禁。

## Standalone usage guide

**Minimum input:** a table name or entity name — no schema spec required.

**Standalone consistency check generation:**
1. Infer common consistency patterns from entity name (FK orphans, balance invariants).
2. Mark inferred checks as `source: inferred`; set `pending_schema_confirmation`.
3. Set `readiness: constrained` for all inferred items.

**Minimum viable output:**
```yaml
consistency_checks:
  readiness: constrained
  pending_schema_confirmation: true
  items:
    - check_id: CC-001
      type: fk_orphan
      entity: orders
      check: Every orders.customer_id must exist in customers.id
      source: inferred_from_entity_name
      pending_schema_confirmation: true
    - check_id: CC-002
      type: aggregate_invariant
      check: order_total == sum(order_items.unit_price * quantity)
      source: inferred_standard_pattern
```

## v3.1.3 P6 governance enforcement

See `references/n260-p6-governance.md` for the full governance enforcement rules (validator usage, STG mapping, signal thresholds, cross-validate commands).

## Input tiers / input tiers
### minimal_inputs
Accept table/schema or data-flow evidence. Generate referential integrity, aggregate invariant, and reconciliation checks with assumptions marked.

### workflow_inputs
Prefer data flows, table schemas, services, transaction boundaries, saga design, event/topic definitions, cache topology, and repair runbooks.

### enhancement_inputs
Use incident drift history, reconciliation job metrics, source-of-truth rules, audit design, idempotency summary, and concurrency race summary.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 表结构设计草案.sql
- 索引建议清单.csv
- 审计留痕方案.md
- 事件定义或topic清单
- cache topology
- external system contracts
- repair runbooks

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `consistency_scope_summary`
- `check_items[]`
- `consistency_kind_matrix[]`
- `failure_scenarios[]`
- `remediation_strategies[]`
- `deduplicated_links[]`
- `downstream_handoff`
- `self_check`
- `shared_scenario_tag`
- `ownership_role`
- `canonical_owner_skill`
- `related_specialty_refs[]`
- `reconciliation_owner`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


> `metadata` field requirements: see `references/n260-v2-reactive-contract.md`.



## Ownership and de-duplication / ownership and de-duplication
- Own data invariants, reconciliation, source-of-truth comparison, drift detection, and recovery.
- Do not own idempotency key semantics. For same-key/same-payload, TTL, payload equivalence, retry, webhook replay, or message redelivery, link to 098 using `STG-IDEMPOTENCY-*` tags.
- Do not own race-trigger mechanics. For concurrent state transition, balance deduction trigger, lock ordering, or deadlock, link to 097 using `STG-CONCURRENCY-*` tags.
- For balance or count consistency, 095 owns the invariant and reconciliation; 097 may own the race trigger that violates it.

## Design rules / design rules
- Assign one consistency_kind to every row and make the expected consistency model explicit.
- Cover both nominal and degraded scenarios such as replica lag, cache miss storms, message backlog, or network partitions.
- Prefer remediation-aware checks over alarm-only rows when a repair path is known.
- Mark overlaps with permission, concurrency, or idempotency checks instead of duplicating them blindly.
- Call out the data source, reconciliation method, and acceptance threshold for each check.

## Execution workflow / execution workflow
1. Read data-flow, schema, testcase, and nonfunctional context relevant to consistency surfaces.
2. Choose consistency kinds and enumerate check rows with method, threshold, and evidence expectations.
3. Add degraded or recovery scenarios for each important consistency surface.
4. Attach remediation or recovery guidance where feasible.
5. Emit de-duplicated rows ready for gate aggregation and release-readiness handoff.

## Dynamic completeness / dynamic completeness
- Simple services can focus on within-db and db-cache checks; distributed flows should expand into cross-service and external-system models.
- If topology is unclear, keep row structure stable and mark topology assumptions openly.
- When eventual consistency is accepted, define lag bounds and reconciliation cadence instead of pretending strong consistency.



## Example usage

**Input**: Order service with orders table and order_items table; saga pattern for distributed checkout.

**Output** (excerpt):
```yaml
consistency_check_items:
  - item_id: DCC-001
    check_type: fk_orphan
    description: Verify every order_items.order_id references a valid orders.id
    sql_template: "SELECT COUNT(*) FROM order_items oi LEFT JOIN orders o ON oi.order_id=o.id WHERE o.id IS NULL"
    expected: 0
    priority: P0
  - item_id: DCC-002
    check_type: aggregate_balance
    description: Verify SUM(order_items.subtotal) equals orders.total for each order
    sql_template: "SELECT o.id FROM orders o JOIN ... HAVING ABS(SUM(...)-o.total) > 0.01"
    priority: P0
  - item_id: DCC-003
    check_type: saga_boundary
    description: Verify no order exists in status=processing for more than 10 minutes
    priority: P1
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Resilience and governance addendum

**Produced events**: Emit `produced_event: produced.n260.data_consistency_check` in metadata when the artifact is complete or materially updated. Also emit `signal.n260.data_integrity_gap` to N005 feedback loop when quantified thresholds in `references/signal-thresholds.md` are met.

**Confidence scoring**: Include `evidence_confidence: high/medium/low` in each item or dimension. Items with `evidence_confidence: low` must be flagged for `human_review_required: true` and must not be counted as passed in the quality gate.

**Circuit breaker**: circuit_breaker triggers when the same FK orphan or balance reconciliation check fails across 3 consecutive releases.

**Traceability**: Every item must carry `canonical_owner_skill` and a reference to the upstream artifact or evidence id that produced it, enabling end-to-end traceability from requirement through to gate verdict in N270 and N280.

**Escalation path**: When `readiness: blocked` on any P0 item, escalate immediately to the release manager and the owning team lead. Log the escalation in `downstream_handoff.escalation_log[]`.

## Auditable rules summary

- R01_scope_grounded: every data consistency check must reference a specific table, endpoint, field, or service; on_violation: reject.
- R02_ownership_tagged: each item must carry `canonical_owner_skill` and `shared_scenario_tag` when overlap with another N260 skill exists; on_violation: reject.
- R03_evidence_slot: every item must have an evidence or verification field; on_violation: reject.
- R04_no_duplication: deduplicate against items from other N260 skills using STG tags; on_violation: merge_or_reference.
- R05_priority_declared: every item must have a priority (P0/P1/P2); on_violation: assign_default.
- R06_fix_path_documented: every consistency violation type must include a suggested remediation action; on_violation: add_fix_path.
- R07_saga_boundary_covered: for distributed transaction flows, at least one saga boundary consistency check must be present; on_violation: flag_gap.

## Algorithm

1. Parse inputs and identify scope: FK orphan check, balance reconciliation, saga boundary, or eventual consistency bound.
2. For each scope item, generate test points with owner tag (R02).
3. Assign evidence slot (R03) and priority (R05).
4. Deduplicate against other N260 skills using STG map (R04).
5. Validate each item references a specific artifact (R01).
6. Emit `test_points[]`, `ownership_map`, `dedup_log`.
7. Run `self_check`; set `readiness: blocked` if R01, R02, or R03 fires.

## Quality bar / quality bar
A good artifact makes it clear what consistency promise is expected, how it will be checked, what failure modes matter, and how the team recovers when drift is found.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本（如 `n260.quality-gate-check.v2.2`），仅本 skill 字段变更时递增；
`governance_revision: "3.1.3"` — N260 组共享的 P6 治理框架修订号，修改 `n260-p6-governance.md` 时递增。
三套版本号独立变更，语义见 `references/n260-v2-reactive-contract.md`。

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/data-consistency-types.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## Usage scenarios

- `fk_sweep`: check all foreign key constraints and orphan detection.
- `saga_boundary`: verify distributed transaction consistency boundaries.
- `aggregate_invariant`: check business object invariants (balance, totals).
- `full_consistency`: complete data consistency audit across all types.
