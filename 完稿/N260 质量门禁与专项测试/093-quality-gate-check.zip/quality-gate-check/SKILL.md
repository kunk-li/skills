---
name: quality-gate-check
description: Aggregate quality-gate evidence into go, conditional, or no-go decisions; roll up checklist, data-consistency, permission, concurrency, idempotency, and performance outputs, track blockers and override review.
---
# quality-gate-check


## Gate routing decision table

| Situation | Action |
|---|---|
| All dimensions pass | Verdict: `pass`; emit to N270 release coordination |
| Any P0 blocker open | Verdict: `no_go`; block pipeline; require P0 resolution |
| Coverage gap but no P0 defects | Verdict: `conditional`; list required actions with owners |
| what_if mode | Show before/after verdict per dimension; do not update live gate |
| Post-incident emergency | Use `post_incident_gate`; check only recovery-critical dimensions |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n260.quality-gate-check.v2.2"
contract_version: "n260.gate.v2.2"
workflow_node: "N260"
node_artifact_target: "n260.quality_gate_check_report"
function_bias: "gate_aggregation_and_decision"
```


## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 质量门禁检查单.md. It delivers the authoritative workflow-aligned gate artifact for N260.

### Boundary
- Own gate aggregation, weighting, veto logic, pass-condition tracking, and override framing.
- Consume specialty test outputs rather than duplicating them.
- Do not fabricate pass results for specialty areas that are still pending evidence.
- Express decision rationale transparently enough for N270, N280, and N370 to consume.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_check`: aggregate available inputs fast without full history or override analysis.
- `full_gate`: produce the complete decision packet with weights, blocker registry, conditions, history, and override review.
- `what_if`: simulate how the conclusion changes if blockers close, dimensions improve, or overrides apply.



## v2 reactive contract

> Full reactive contract spec (schema_version, governance_revision, produces_event, routing_keywords,
> signal_emission, human_review_sla, canonical_function) is in
> `references/n260-v2-reactive-contract.md`.

## Cross-skill integration map

| 上游 skill（门禁输入） | 消费维度 | 说明 |
|---|---|---|
| 085 smoke-test-checklist-generation | `smoke_test` | 部署后冒烟通过率 |
| 084 regression-test-checklist-generation | `regression` | 全量回归通过率 |
| 088 test-automation-orchestration | `pipeline` | CI 编排执行结果 |
| 090 defect-classification | `defect_profile` | 缺陷类型分布 |
| 091 defect-severity-assessment | `severity_distribution` | P0 否决维度 |
| 094–099 N260 专项 | `specialty_checks` | 各专项测试输入门禁聚合 |
| **built-vs-spec 核对(reality)** | **`built_vs_spec`** | **spec↔code 一致性发现器结果(见 §built_vs_spec);消费 N110 `032` 的 `AH-` 对照真实代码/运行** |
| **cross-service 契约核对(reality)** | **`cross_service_contract`** | **调用方↔服务端 求差;caller-no-server / shape-mismatch / callback-drift(见 §cross_service_contract)** |
| **money-flow 完整性核对(reality)** | **`money_flow_completeness`** | **每笔资金变更 vs commit/refund/reconcile 求差;丢钱红线(见 §money_flow_completeness)** |

| 下游 | 093 输出 | 用途 |
|---|---|---|
| 发布决策 | `gate_verdict` | go/no-go/conditional |
| N270（如存在） | `release_blocker[]` | 发布协调节点接收阻断信号 |

**工作流位置**: N220–N260 全链 → **093 质量门禁** → 发布决策。

## built_vs_spec 维度(reality 核对 · G2 实测校准 2026-06-02 · 真用反哺 2026-06-05 加 mechanism-substituted + code-hygiene-drift verdict · 见 D-018/D-019)
整套 SDLC 门禁原本全是 **doc-vs-doc**(查文档质量/一致性);本维度补 **doc-vs-reality**——把 N110 `032` 产的 `AH-` 验收断言**逐条拿到真实代码/运行**里核对,抓"该调的代码从没被调用 / 路径从没接线"这类**单测测不到**的缺陷(实测某真实全栈项目:抓出 失败不退款 / 成功不落库 / 预扣不对账 类资金红线)。
- **观测源(reality_adapter)**:`runtime-observation`(跑真应用)/ `static-frontend`(读已构建源或原型)/ `e2e-trace` / `manual`;观测不到的断言判 `unknown(needs:<adapter>)`,**绝不当 pass**。
- **单断言 verdict**:pass / fail(= spec↔reality 缺陷)/ unknown / spec-stale(反证 spec → 回 `032` 订正)/ **mechanism-substituted**(换机制但仍满足意图,见下)/ **code-hygiene-drift**(行为对但用了废弃契约,见下)。
- **mechanism-substituted(架构换 HOW → 核 WHAT,别 blanket-N/A)**:当实现用与 spec 规定**不同的机制/技术**满足同一断言时(架构是工程自由决策,HOW 可替换),**不要**因"找不到 spec 写的那个机制"判 fail 或直接 N/A。改为:从该 `AH-` 抽出底层**意图(WHAT / 红线)** → 核**替换后的机制是否仍满足该意图**——全满足判 `pass`(标 mechanism-substituted);只满足一部分则**列精确残留**(哪条子意图新机制没覆盖)判 `partial` 并单独 flag 该残留;完全不满足才 `fail`。核 WHAT,不只核 HOW。
- **code-hygiene-drift(行为对但契约旧)**:行为**满足** `AH-`(spec↔reality 对),但实现**依赖已废弃 / 被取代 / 与权威定义自相矛盾的内部契约**(抛已 deprecated 的错误码或常量、调已声明移除的路径、用与权威 taxonomy 冲突的标签)。**行为判 pass**,另发一条 `code-hygiene-drift` finding 交人裁定(迁到 canonical vs 接受);**不阻断**(行为正确),属技术债发现器价值——doc-vs-doc 门禁 + 合成 eval 抓不到(需读真代码 + 知废弃关系)。
- **⚠️ 定位 = 发现器,非 per-PR CI 硬门禁(G2 实测结论)**:本维度**非确定** + 偶发**高置信误报**(尤其运行时/并发——实测唯一误报偏是最高 P0)。故:① 仅 nightly / 上线前 RC 跑;② 运行时/并发断言一律 `evidence_confidence: low`、severity `provisional`,**不得直接驱动 `no_go`**;③ 必经人工裁定;④ **确认项沉淀成确定性测试/lint** 才进 CI(实测:某真实项目沉淀 14 个 PG 集成测试 + 2 条结构 lint)。
- **聚合纪律**:**未经人工裁定确认的 `built_vs_spec` fail 不得单独触发 `no_go`**,按 `insufficient_evidence`/`conditional` 计入;确认的红线 fail 才入 `blocker_registry`。

## reverse_coverage(code→spec 反向覆盖 · 真用反哺 2026-06-05)
built_vs_spec 默认方向 = **spec→reality**(`032` 的 `AH-` 逐条核代码)。但真实/成熟项目反复呈现**反向漂移:实现领先 spec,代码做了一堆 spec 从没立断言的事**(shipped 项目的主向)。spec→reality 对此**全盲**——没有 `AH-` 就不会去查。reverse_coverage 补这个方向。
- **方法**:从实现侧枚举**契约级 / 用户可观测**的行为——端点/路由、状态迁移、定时任务、对外副作用(钱/权限/数据/审计)——与 spec 的 `AH-`/需求集**求差**,浮现「代码有、spec 无」的块,发 `reverse_coverage` finding(= spec backfill 候选)。
- **聚焦,别全扫(防误报)**:只对**契约级/可观测**行为求差;**不**对内部 helper / 框架胶水 / 纯重构求差(那些本就不该有 spec 断言)。
- **定位 = 发现器,非门禁(D-018)**:多数「代码有/spec 无」是**有意演进**(团队知道、只是没回写 PRD),少数才是**未声明的越权/影子功能**(真风险)。故 ① 一律 `evidence_confidence: provisional`;② **绝不驱动 `no_go`**;③ 人裁分流 → 回写 PRD(spec 滞后)/ 保留(有意)/ 砍(影子功能)。
- **与 025 互补**:025 complete-feature 从 **spec 侧**推该有的功能;reverse_coverage 从 **code 侧**推该补的 spec。两侧夹逼 spec↔code 完整性。
- **与 spec-stale 之别**:spec-stale = **已有**断言被现实反证(改断言);reverse_coverage = **从无**断言(立新断言 / 回写 PRD)。

## cross_service_contract(跨服务/跨模块契约一致性 · code↔code 求差 · 真用反哺 2026-06-08)
built_vs_spec 比 spec↔code、reverse_coverage 比 code→spec;本镜头补**第三条 derive-then-diff 轴 = 调用方↔服务端**(同一系统内跨服务 / 跨模块 / 跨仓的契约一致性)。doc-vs-doc 门禁与单文件审查**结构上抓不到**:一个调用方 POST 的端点、调用的 RPC、触发器/定时任务/事件回调指向的路径——**对面有没有人接、形状对不对**——只有把「被调集」与「被服务集」求差才浮现(实测某真实系统:抓出多条"调用方仍在调、服务端已删/改名/改签名"的契约断 → 整条业务流静默失败或留下孤儿状态,doc-vs-doc + 合成 eval 全盲)。
- **方法**:枚举「被调集」= 客户端 / 网关路由 / 工作流触发动作 / 内部回调(`*Client`·`*Api` 消费侧、声明式路由、trigger action、`/internal/*` 回调)指向的端点路径 + 期望的 verb / 参数 / 枚举;枚举「被服务集」= 真实处理器映射;两集**求差**。发 `cross_service_contract` finding,分四型(④见下方独立 bullet):① **caller-no-server**(调用方在调、目标版本无对面处理器 = 移除/改名后调用方未同步)② **shape-mismatch**(path / verb / param / 枚举 在两侧不一致)③ **callback-contract-drift**(内部回调契约两侧分歧)。
- **第 4 型 · server-no-caller / wired-but-unused**(`caller-no-server` 的镜像):在「被服务集」却不在「被调集」= 已建 + 已装配(常有测试)的能力/处理器/服务方法**零生产调用方** = 死制品。范围不止端点——任何**声明/注册进系统**的能力(路由 / 服务方法 / 注册进 registry·DI 的模块 / `require_*` 访问器)若**全仓非测试零调用点**即此型。与 spec 侧两类区分:`absent_but_expected`=代码缺、`specified_not_implemented`=规则缺、**`wired_but_unused`=代码在且已装配、却没人调**(实测某真实系统:整套权限引擎 3 后端 + 单测全绿 + 已装配,核心 `check_permission` 生产零调用 → DoD 要求的门禁从未生效)。verdict 同 caller-no-server:一律 `provisional` 交人裁,唯确认"关键能力〔钱/权限/审批/状态机〕零生产调用"才升 blocker。
- **必须对发布 ref 求差,不是工作树(关键)**:被删的处理器常仍残留在本地工作树 / IDE 索引里 → 必须对**目标发布版本(release ref)**收集两集,否则假阴性。
- **聚焦,别全扫(防误报)**:只对**跨边界、契约级**调用求差(HTTP / RPC / 事件 / 回调,跨服务或跨模块);**不**对进程内、编译期已检查的直接方法调用求差(类型系统已兜)。
- **verdict 与定位(发现器非门禁,D-018)**:caller-no-server 是**高信号**(多半真断),但也可能是**未部署 / 特性开关后**的端点 → 一律 `provisional` 交人裁;唯**确认**"目标版本确无处理器 + 落在关键路径(钱 / 权限 / 审批 / 状态机)"的 caller-no-server 才入 `blocker_registry`(上线即断 = 真红线);shape / drift 类默认 `conditional` / 人裁,**不直接 `no_go`**。
- **三轴互补**:built_vs_spec(spec↔code)/ reverse_coverage(code→spec)/ cross_service_contract(code↔code 跨边界)三面夹逼"产物 vs 现实"完整性——单文件审查、doc-vs-doc、合成 eval 都抓不到这一类。

## money_flow_completeness(资金流生命周期完整性 · code↔lifecycle 求差 · 真用反哺 2026-06-08)
前三轴管 spec↔code / code→spec / 跨边界契约;本镜头补**第四轴 = 资金流生命周期完整性**:每一笔钱的动作,它的生命周期补全了吗?doc-vs-doc 与单文件审查抓不到——一笔 charge / 预扣写了,但**对应的 commit(成功落库)/ refund(失败退款)/ reconcile(对账)缺了一段**,只有把「每个资金变更」与「它该有的生命周期补全」求差才浮现(实测某真实系统:失败不退款 / 成功不落库 / 预扣不对账 —— 钱扣了但失败路径不退、成功路径不持久、异步不对账)。
- **方法**:枚举**资金变更集** = charge / reserve(预扣)/ debit / credit / settle / payout / refund 的真实写入点;对每笔**求差它的生命周期补全**:① 成功 → commit / 持久化(写没写最终态、落没落账)② 失败 / 异常 → refund / rollback / compensate(失败路径退没退、补没补偿)③ reserve(预扣)→ settle(实扣)或 release,且**异步 / 外部依赖 → reconcile(对账)**(预扣与实扣 / 外部回执对没对上)。发 `money_flow_completeness` finding,标缺哪段:`no-commit-on-success` / `no-refund-on-failure` / `no-reconcile`。
- **守边界,别重复造**:**幂等**(重复提交 → 重复副作用)归 `098` · **行锁 / 并发丢失更新**归 `074` · **事务边界 / outbox**归 `073`。本镜头只管**生命周期三段(commit / refund / reconcile)齐没齐**,不碰那三个。
- **聚焦,别全扫(防误报)**:只对**真改余额 / 真扣实付**的资金变更求差;不对纯查询、纯展示金额、或**同事务内原子完成**(charge + commit 一步落定)的求差。
- **verdict 与定位(发现器非门禁,D-018)**:缺段是**高信号**(失败路径不退 / 不对账 = 丢钱红线),但也可能**由上游 / 外部系统兜底**(如对账走独立批处理 job)→ 一律 `provisional` 交人裁;唯**确认**"失败路径确无退款 / 补偿 + 真改了余额"才入 `blocker_registry`(丢钱红线);`no-reconcile` 默认 `conditional` / 人裁,**不直接 `no_go`**。
- **四轴互补**:built_vs_spec(spec↔code)/ reverse_coverage(code→spec)/ cross_service_contract(code↔code 跨边界)/ money_flow_completeness(code↔lifecycle 资金补全)四面夹逼"产物 vs 现实"完整性。

## verify-before-claim 四道门预检(reality finding 确认前置纪律 · 非新镜头)

这是一层**纪律(discipline)**,不是又一条检测镜头。前四轴(§built_vs_spec / §reverse_coverage / §cross_service_contract / §money_flow_completeness)负责**找候选**;本节四道门负责**判定一个候选能否作为「确认」(confirmed)发出**——任一适用门没过,该 finding 不得报成 confirmed missing / not-implemented / implemented / requirement-unclear / fail,一律降级 `provisional` / `unknown` / `deviation` 交人裁。核心铁律:**分析不得跑在核对前面**(no analysis ahead of verification)。四道门与四轴正交——四轴决定「往哪看」,四道门决定「看到的能不能下断言」。

- **Gate 1 · canonical-first(下"需求未定义 / spec 没写 / 未规定"这类断言前)**:先**定位并读权威/规范版 spec**。"我手上那段代码里没有" / "我拿到的 spec 摘录里没有"**不等于**"未定义"——只是读得不全。仅在核过权威源后,才可把某条判成需求缺口(requirement gap)而非实现缺陷。**杀掉的失败模式**:把一条 spec 早已规定的规则误框成"待产品决策"。注意与 §reverse_coverage 的 spec-stale 相反:spec-stale 是**已有**断言被现实反证;Gate 1 防的是反向错——明明 canonical spec **写了**,却因没读全而判"未规定"。Gate 1 只约束 093 自身断言的发出纪律,不重跑也不覆盖 025 文档侧完整性评分(那是 025 独占;025 问"配对的另一侧文档里写没写",Gate 1 问"我判 missing 前,这需求是不是已在产物里以某名实现了")。

- **Gate 2 · 跨名反向覆盖 + 端到端可达(下"missing / 未实现"前)**:检测镜头见 §reverse_coverage 与 §cross_service_contract(本门不重述 derive-then-diff 求差法),本门只加**前置纪律**——发 `absent_but_expected` / `specified_not_implemented` 这类 missing 断言前:① 按**行为**(error-code marker / 状态迁移 / 副作用 / 日志标记 / 等价状态机)反查**全仓**,**不要只按 spec 给那个东西起的名字**查;同一意图常以**另一个标识符**落地,**名字没命中 ≠ 能力不存在**;② 确认候选**端到端可达**(在活路径上真被调用 / 真写入 / 真分支进入)。**对称陷阱(symmetric trap)**:implemented 方向同样易错——"我找到一个候选 symbol"**不证明**"这条路径真到得了它";**过度判 missing 与过度纠正成 implemented,两边都是假阳**。若名字找不到、但靠行为也无法证明其不存在 → missing **降级**为 `deviation` / `unknown`,**绝不**报 confirmed missing。(本门与 §cross_service_contract 第 4 型分工:Gate 2 = "在真实名字下它存在且端到端可达否"防假缺;第 4 型 `wired_but_unused` = "它存在且已装配、却零生产调用方"防假在;两者交叉引用,不合并。)

- **Gate 3 · 活码 vs 僵尸码(给一段已找到的实现评质量、或把它当作 spec 的「那个」实现 之前)**:先确认这段实现的**调用链在线(online)**。stub / placeholder / 被禁用的控制器 / 零调用方法 / 注释掉的 guard / 被短路的写路径都属**僵尸(zombie)**:它的内部 bug **不是**线上生产缺陷,它也**不是**该 spec 的真实实现。区分**活码**(在可达生产路径上)与**僵尸**(已声明/已装配但被短路或非测试零调用方)。**两个方向都会误读**:把僵尸内部 bug 当成线上高危、或把 stub 当成活实现,**都是假阳**。系统级"零生产调用方"镜头见 §cross_service_contract 第 4 型 `wired_but_unused`;进程内 / 单文件粒度的死 guard / 失效控制开关属 070 领域;本门只加"未证其在线前,不评其质量、不信其为真实现"这层前置纪律。

- **Gate 4 · 基线完整性(下任何关于「现状」的断言前)**:确认你查的产物**就是目标发布/版本**。落后于发布 ref 的工作树 / 本地 checkout / IDE 索引会让**每个行号、每条 present/absent 读数都不可信**——被删的代码会残留本地(假阴),**已修的代码可能上游早已存在**(假阳)。查的树 ≠ 目标 ref 时,改用**版本锚定的 ref 读**(对目标 release ref / sha / tag 做钉死的 show / grep),**绝不信工作树行号**——这直接强化「reality-finding 6 字段格式」里 `code_evidence` 的精确定位要求。§cross_service_contract 的 release-ref 提醒(只对发布 ref 收集两集)是本门的来源;Gate 4 把它从该镜头的局部 caveat **泛化(generalize)成横切所有 reality 断言**(built_vs_spec / reverse_coverage / money_flow_completeness 的每条 present/absent 读数与行号同受此约束),不重复推导工作树为何不可信。

- **Outcome 收口**:任一适用门未过 → 该 finding **不得**作为 confirmed missing / fail / unclear 发出,降级 `provisional` / `unknown` / `deviation` 交人裁。这与既有「定位 = 发现器、非 per-PR CI 硬门禁」(见 §built_vs_spec line 82)及 `evidence_confidence: low` 不得计 pass(见 Resilience and governance addendum)完全一致——四道门是 finding 的**置信/资格预检**,**不是**会阻断流水线的新硬门禁。

## reality-finding 6 字段格式(发现器 finding 输出契约 · fix-direction 故意省略)

适用于一切 reality-check / 发现器 finding(§built_vs_spec / §reverse_coverage / §cross_service_contract / §money_flow_completeness 及任何审计发现)。该格式是**发现器 finding 层的契约**,嵌套在 `gate_dimensions[]` 的 reality finding 之下——它**喂入**门禁聚合器,**不取代**聚合器的输出模板(`references/output-template.md` 的复查条件 / 建议动作仍是聚合器下游产物,本格式不约束它们)。每条 finding 恰带以下六个字段:

1. `symptom`(现象)——用**平白话**讲清**什么坏了** + 场景化后果;给人读,不堆术语。
2. `code_evidence`(代码证据)——**精确定位**:从仓库根写全的完整路径 + 行号 + symbol。**不写**类名 / "约第 X 行" / 裸文件名。(给外部团队的 finding,路径相对收件人自己的仓库根。)
3. `spec_basis`(PRD 依据)——它违反的权威 spec 条款 / 所依据的断言;同样精确定位。
4. `impact`(影响)——人话讲后果:**什么会出错、谁受影响**。
5. `regression_test`(回归测试)——**能逮住这条 finding 的确定性测试**(per-finding 粒度)。此字段是 §built_vs_spec line 82「确认项沉淀成确定性测试/lint 才进 CI」这条聚合纪律在**发现时刻、单条粒度**上的落地:发现时先写出**候选**确定性测试;一旦该 finding 经人工裁定**确认**,它即升格为 line 82 所述进 CI 的那条测试/lint。两者是**同一条 discoverer→confirm→distill 纪律的两个粒度**(单条撰写 vs 聚合晋升 CI),不是两条竞争规则。
6. `source`(来源)——哪条镜头 / 哪次 run / 哪个 reality_adapter 产的;可追溯。

**FIX-DIRECTION(修复方向)故意省略**:发现器只报 现象 + 证据,**修法由 owning team 定**。这正强化本 skill 既有的「发现器非门禁」站位(见 §built_vs_spec line 82、§reverse_coverage / §cross_service_contract 的 D-018 定位)。措辞分工:`symptom` + `impact` 用人话;`code_evidence` + `spec_basis` + `regression_test` + `source` 精确定位。

**与 `blocker_registry.resolution_path` 的关系(防自相矛盾)**:Example 里 `blocker_registry[].resolution_path`(见 Example usage)与 R03(见 Auditable rules summary)要求的 owner + resolution path,是**已确认 blocker 的清障/重门(blocker-clearance / re-gate)追踪**——记录"要发生什么才能清掉这个 blocker、重新过门",**不是**给定的代码修法。它处在 6 字段发现器 finding 的**下游**:发现器先按 6 字段报出 fix-direction-free 的 finding,经人裁确认成红线 fail 后才进 `blocker_registry` 并在那里挂 resolution_path。两者**不冲突、不互删**:6 字段格式只管发现器 finding 本身且保持无修复方向;resolution_path 只管已确认 blocker 的清障追踪。

## Standalone usage guide

**Minimum input:** any test result summary — even a single pass/fail signal.

**Standalone gate path:**
1. Accept partial evidence; score only available dimensions.
2. Mark unavailable dimensions as `pending_evidence`; do not count them as failures.
3. Apply `conditional` verdict when any dimension is pending; never auto-pass with missing data.

**Minimum viable output:**
```yaml
gate_check_result:
  mode: quick_gate
  readiness: constrained
  verdict: conditional
  evidence_completeness: partial
  dimensions:
    test_coverage: pending_evidence
    defect_density: pass (0.5 ≤ 1.0)
    p0_defects: pass (0 open)
  required_actions:
    - Provide test coverage data before final verdict
  pending_evidence: [test_coverage]
```

## v3.1.3 P6 governance enforcement

See `references/n260-p6-governance.md` for the full governance enforcement rules (validator usage, STG mapping, signal thresholds, cross-validate commands).

## Input tiers / input tiers
Use tiered input handling so this aggregator remains usable outside a full N260 run.

### minimal_inputs
Accept any one of: a previous gate report, a blocker list, a release evidence summary, or one specialty summary. Produce a conservative partial gate with unknown dimensions marked `insufficient_evidence`.

### workflow_inputs
Prefer upstream quality evidence plus same-node summaries:
- `n100_gate_result`
- `n130_review_gates`
- `n150_api_compliance`
- `n170_nfr_designs`
- `n210_code_quality_summary`
- `n240_test_results`
- `n250_defect_status`
- `n094_checklist_summary`
- `n095_consistency_summary`
- `n096_permission_summary`
- `n097_concurrency_summary`
- `n098_idempotency_summary`
- `n099_performance_summary`
- `built_vs_spec_report`  # G2 校准:spec↔code 核对发现器结果(见 §built_vs_spec)
- `cross_service_contract_report`  # 调用方↔服务端契约求差发现器结果(见 §cross_service_contract)
- `money_flow_completeness_report`  # 资金流生命周期补全求差发现器结果(见 §money_flow_completeness)

### enhancement_inputs
Use historical gate decisions, prior version baselines, incident feedback, override/waiver records, and release calendars to strengthen trend, circuit breaker, and PM override reasoning.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 上线前检查清单.csv
- 数据一致性检查项.csv
- 权限测试点.csv
- 并发测试点.csv
- 幂等测试点.csv
- 性能测试场景.csv
- blocker registry snapshots
- historical gate decisions
- release target or calendar context
- override requests or waiver records

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `gate_summary`
- `gate_dimensions[]`
- `aggregation_algorithm`
- `dimension_weights`
- `blocker_registry[]`
- `pass_conditions_machine_readable[]`
- `gate_history[]`
- `override_records[]`
- `decision_rationale`
- `downstream_handoff`
- `self_check`
- `specialty_summaries_consumed[]`
- `dedupe_rollup[]`
- `unknown_dimensions[]`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


> `metadata` field requirements: see `references/n260-v2-reactive-contract.md`.



## Same-node aggregation rules / same-node aggregation rules
- Treat 094 as operational readiness input, not a duplicate gate verdict.
- Map 095-099 summaries into gate dimensions and blocker registry explicitly.
- Do not count duplicate-linked specialty rows twice; use `shared_scenario_tag` and `canonical_owner_skill`.
- If specialty evidence is missing, mark the corresponding dimension as `insufficient_evidence` or `constrained`; do not infer pass.
- Preserve a transparent link from every hard veto to its source evidence.

## Design rules / design rules
- Declare one aggregation algorithm explicitly: all_pass, weighted_threshold, or veto_based.
- Treat compliance and other hard-veto dimensions as explicit vetoes instead of hiding them in prose.
- Represent conditional-go conditions as machine-readable checks, not only narrative bullets.
- Show which specialty outputs and blockers drive each dimension status.
- Highlight overrides with owner, expiry, documented risk, and reevaluation trigger.

## Execution workflow / execution workflow
1. Collect specialty outputs, blocker state, and readiness evidence.
2. Normalize all gate dimensions and bind supporting check items to each dimension.
3. Apply the declared aggregation algorithm and compute provisional gate status.
4. Evaluate blocker state, pass conditions, and any override records.
5. Emit the final gate artifact with rationale, open risks, and downstream release handoff.

## Dynamic completeness / dynamic completeness
- If only partial specialty evidence exists, keep the gate artifact stable but mark dimensions as pending or conditional with explicit reasons.
- If one hard-veto dimension fails, surface that immediately even when weighted totals look high.
- For release-critical slices, include gate history and trend framing so stakeholders see movement, not only a snapshot.



## Example usage

**Input**: N240 test results (47 passed, 2 failing), N250 defect status (DEF-5021 P0 open), smoke checklist (5/5 passed).

**Output** (`full_gate` mode, excerpt):
```yaml
gate_verdict: no_go
dimensions:
  - name: test_execution
    status: conditional
    weight: 0.30
    evidence: "47/49 passed; 2 failures under investigation"
  - name: defect_status
    status: fail
    weight: 0.25
    evidence: "DEF-5021 P0 open — hard veto"
  - name: smoke_validation
    status: pass
    weight: 0.20
    evidence: "5/5 smoke checks passed post-deploy"
blocker_registry:
  - blocker_id: BLK-001
    defect_ref: DEF-5021
    severity: P0
    owner: checkout_team
    resolution_path: "Fix and re-verify before re-gate"
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Resilience and governance addendum

**Produced events**: Emit `produced_event: produced.n260.quality_gate_check` in metadata when the artifact is complete or materially updated. Also emit `signal.n260.gate_regression` to N005 feedback loop when quantified thresholds in `references/signal-thresholds.md` are met.

**Confidence scoring**: Include `evidence_confidence: high/medium/low` in each item or dimension. Items with `evidence_confidence: low` must be flagged for `human_review_required: true` and must not be counted as passed in the quality gate.

**Circuit breaker**: circuit_breaker triggers when gate verdict regresses (pass→conditional or conditional→no_go) across 3 consecutive releases without a root-cause resolution.

**Traceability**: Every item must carry `canonical_owner_skill` and a reference to the upstream artifact or evidence id that produced it, enabling end-to-end traceability from requirement through to gate verdict in N270 and N280.

**Escalation path**: When `readiness: blocked` on any P0 item, escalate immediately to the release manager and the owning team lead. Log the escalation in `downstream_handoff.escalation_log[]`.

## Auditable rules summary

- R01_evidence_required: every gate dimension must cite at least one evidence item; on_violation: mark_insufficient_evidence.
- R02_no_fabricated_pass: do not mark a specialty dimension as passed without evidence from the owning skill; on_violation: reject.
- R03_veto_explicit: any hard veto must be listed in `blocker_registry[]` with owner and resolution path; on_violation: reject.
- R04_override_documented: conditional-go overrides must include approver, justification, and risk acknowledgement; on_violation: reject.
- R05_trend_regression_flagged: if a gate dimension regressed vs previous run, flag it even if still passing; on_violation: warn.
- R06_gate_verdict_immutable: once a gate verdict (pass/conditional/no_go) is recorded, it must not be silently overwritten; amendments require a new gate check run; on_violation: reject.
- R07_upstream_evidence_linked: every gate dimension must cite at least one upstream artifact ID as evidence; on_violation: flag_missing_evidence.
- R08_conditional_gate_requires_action: a conditional gate verdict must include at least one required_action item and an owner; on_violation: reject_conditional.
- R09_what_if_mode_produces_delta: in what_if mode, output must show before/after gate status for each affected dimension; on_violation: add_delta_comparison.
- R10_reality_finding_contract: any reality-check finding emitted as a confirmed missing/fail/unclear must (a) carry the 6-field format (symptom / code_evidence / spec_basis / impact / regression_test / source, with fix-direction omitted) where code_evidence and spec_basis are precise locators (repo-root full path + line number + symbol), and (b) have passed its applicable verify-before-claim four gates (see §verify-before-claim 四道门预检); if any applicable gate fails, the finding must be downgraded to provisional/unknown/deviation for human adjudication and must not be reported as confirmed; on_violation: downgrade_to_provisional.

## Algorithm

1. Collect evidence from all input tiers; apply mode selection matrix.
2. For each gate dimension, assign status: pass / conditional / fail / insufficient_evidence (R01, R02).
3. Aggregate weighted scores; compute overall verdict.
4. Populate `blocker_registry[]` for any hard veto (R03).
5. Document overrides with approver and justification (R04).
6. Compare against previous gate run; flag regressions (R05).
7. Emit `gate_verdict`, `dimension_summary[]`, `downstream_handoff` to N270.
8. Run `self_check`; set `readiness: blocked` if R02 or R03 fires.

## Quality bar / quality bar
A good artifact makes it obvious why the gate is pass, conditional-go, or no-go; which blockers remain; what must change to reach pass; and whether any override meaningfully changes risk.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本（如 `n260.quality-gate-check.v2.2`），仅本 skill 字段变更时递增；
`governance_revision: "3.1.3"` — N260 组共享的 P6 治理框架修订号，修改 `n260-p6-governance.md` 时递增。
三套版本号独立变更，语义见 `references/n260-v2-reactive-contract.md`。

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/gate-aggregation-models.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## Usage scenarios

- `full_gate`: aggregate all upstream N260 signals into a final gate verdict.
- `quick_gate`: lightweight check for hotfix or patch releases.
- `what_if`: simulate gate outcome under proposed threshold changes.
- `post_incident_gate`: emergency gate evaluation after P0 resolution.
