---
name: quality-gate-check
description: aggregate standalone or n260-composable quality gate evidence into go, conditional, or no-go decisions. use for release gates, conditional-go review, blocker tracking, override review, trend regression, or when specialty outputs from checklist, data consistency, permission, concurrency, idempotency, or performance skills must be rolled up without duplicating them. trigger on any request to run a quality gate, aggregate release evidence, decide go or no-go, track blockers, or produce a conditional-go verdict. [N260]
---
# quality-gate-check


## Gate routing decision table

| Situation | Action |
|---|---|
| All dimensions pass | Verdict: `pass`; emit to N270 release coordination |
| Any P0 blocker open | Verdict: `no_go`; block pipeline; require P0 resolution |
| Coverage gap but no P0 defects | Verdict: `conditional`; list required actions with owners |
| what_if mode | Show before/after verdict per dimension; do not update live gate |
| Post-incident emergency | Use `post_incident_gate`; check only recovery-critical dimensions |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n260.quality-gate-check.v2.2"
contract_version: "n260.gate.v2.2"
workflow_node: "N260"
node_artifact_target: "n260.quality_gate_check_report"
function_bias: "gate_aggregation_and_decision"
```


## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 质量门禁检查单.md. It delivers the authoritative workflow-aligned gate artifact for N260.

### Boundary
- Own gate aggregation, weighting, veto logic, pass-condition tracking, and override framing.
- Consume specialty test outputs rather than duplicating them.
- Do not fabricate pass results for specialty areas that are still pending evidence.
- Express decision rationale transparently enough for N270, N280, and N370 to consume.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_check`: aggregate available inputs fast without full history or override analysis.
- `full_gate`: produce the complete decision packet with weights, blocker registry, conditions, history, and override review.
- `what_if`: simulate how the conclusion changes if blockers close, dimensions improve, or overrides apply.



## v2 reactive contract

> Full reactive contract spec (schema_version, governance_revision, produces_event, routing_keywords,
> signal_emission, human_review_sla, canonical_function) is in
> `references/n260-v2-reactive-contract.md`.

## Cross-skill integration map

| 上游 skill（门禁输入） | 消费维度 | 说明 |
|---|---|---|
| 085 smoke-test-checklist-generation | `smoke_test` | 部署后冒烟通过率 |
| 084 regression-test-checklist-generation | `regression` | 全量回归通过率 |
| 088 test-automation-orchestration | `pipeline` | CI 编排执行结果 |
| 090 defect-classification | `defect_profile` | 缺陷类型分布 |
| 091 defect-severity-assessment | `severity_distribution` | P0 否决维度 |
| 094–099 N260 专项 | `specialty_checks` | 各专项测试输入门禁聚合 |
| **built-vs-spec 核对(reality)** | **`built_vs_spec`** | **spec↔code 一致性发现器结果(见 §built_vs_spec);消费 N110 `032` 的 `AH-` 对照真实代码/运行** |

| 下游 | 093 输出 | 用途 |
|---|---|---|
| 发布决策 | `gate_verdict` | go/no-go/conditional |
| N270（如存在） | `release_blocker[]` | 发布协调节点接收阻断信号 |

**工作流位置**: N220–N260 全链 → **093 质量门禁** → 发布决策。

## built_vs_spec 维度(reality 核对 · G2 实测校准 2026-06-02 · 真用反哺 2026-06-05 加 mechanism-substituted + code-hygiene-drift verdict · 见 D-018/D-019)
整套 SDLC 门禁原本全是 **doc-vs-doc**(查文档质量/一致性);本维度补 **doc-vs-reality**——把 N110 `032` 产的 `AH-` 验收断言**逐条拿到真实代码/运行**里核对,抓"该调的代码从没被调用 / 路径从没接线"这类**单测测不到**的缺陷(实测某真实全栈项目:抓出 失败不退款 / 成功不落库 / 预扣不对账 类资金红线)。
- **观测源(reality_adapter)**:`runtime-observation`(跑真应用)/ `static-frontend`(读已构建源或原型)/ `e2e-trace` / `manual`;观测不到的断言判 `unknown(needs:<adapter>)`,**绝不当 pass**。
- **单断言 verdict**:pass / fail(= spec↔reality 缺陷)/ unknown / spec-stale(反证 spec → 回 `032` 订正)/ **mechanism-substituted**(换机制但仍满足意图,见下)/ **code-hygiene-drift**(行为对但用了废弃契约,见下)。
- **mechanism-substituted(架构换 HOW → 核 WHAT,别 blanket-N/A)**:当实现用与 spec 规定**不同的机制/技术**满足同一断言时(架构是工程自由决策,HOW 可替换),**不要**因"找不到 spec 写的那个机制"判 fail 或直接 N/A。改为:从该 `AH-` 抽出底层**意图(WHAT / 红线)** → 核**替换后的机制是否仍满足该意图**——全满足判 `pass`(标 mechanism-substituted);只满足一部分则**列精确残留**(哪条子意图新机制没覆盖)判 `partial` 并单独 flag 该残留;完全不满足才 `fail`。核 WHAT,不只核 HOW。
- **code-hygiene-drift(行为对但契约旧)**:行为**满足** `AH-`(spec↔reality 对),但实现**依赖已废弃 / 被取代 / 与权威定义自相矛盾的内部契约**(抛已 deprecated 的错误码或常量、调已声明移除的路径、用与权威 taxonomy 冲突的标签)。**行为判 pass**,另发一条 `code-hygiene-drift` finding 交人裁定(迁到 canonical vs 接受);**不阻断**(行为正确),属技术债发现器价值——doc-vs-doc 门禁 + 合成 eval 抓不到(需读真代码 + 知废弃关系)。
- **⚠️ 定位 = 发现器,非 per-PR CI 硬门禁(G2 实测结论)**:本维度**非确定** + 偶发**高置信误报**(尤其运行时/并发——实测唯一误报偏是最高 P0)。故:① 仅 nightly / 上线前 RC 跑;② 运行时/并发断言一律 `evidence_confidence: low`、severity `provisional`,**不得直接驱动 `no_go`**;③ 必经人工裁定;④ **确认项沉淀成确定性测试/lint** 才进 CI(实测:某真实项目沉淀 14 个 PG 集成测试 + 2 条结构 lint)。
- **聚合纪律**:**未经人工裁定确认的 `built_vs_spec` fail 不得单独触发 `no_go`**,按 `insufficient_evidence`/`conditional` 计入;确认的红线 fail 才入 `blocker_registry`。

## Standalone usage guide

**Minimum input:** any test result summary — even a single pass/fail signal.

**Standalone gate path:**
1. Accept partial evidence; score only available dimensions.
2. Mark unavailable dimensions as `pending_evidence`; do not count them as failures.
3. Apply `conditional` verdict when any dimension is pending; never auto-pass with missing data.

**Minimum viable output:**
```yaml
gate_check_result:
  mode: quick_gate
  readiness: constrained
  verdict: conditional
  evidence_completeness: partial
  dimensions:
    test_coverage: pending_evidence
    defect_density: pass (0.5 ≤ 1.0)
    p0_defects: pass (0 open)
  required_actions:
    - Provide test coverage data before final verdict
  pending_evidence: [test_coverage]
```

## v3.1.3 P6 governance enforcement

See `references/n260-p6-governance.md` for the full governance enforcement rules (validator usage, STG mapping, signal thresholds, cross-validate commands).

## Input tiers / input tiers
Use tiered input handling so this aggregator remains usable outside a full N260 run.

### minimal_inputs
Accept any one of: a previous gate report, a blocker list, a release evidence summary, or one specialty summary. Produce a conservative partial gate with unknown dimensions marked `insufficient_evidence`.

### workflow_inputs
Prefer upstream quality evidence plus same-node summaries:
- `n100_gate_result`
- `n130_review_gates`
- `n150_api_compliance`
- `n170_nfr_designs`
- `n210_code_quality_summary`
- `n240_test_results`
- `n250_defect_status`
- `n094_checklist_summary`
- `n095_consistency_summary`
- `n096_permission_summary`
- `n097_concurrency_summary`
- `n098_idempotency_summary`
- `n099_performance_summary`
- `built_vs_spec_report`  # G2 校准:spec↔code 核对发现器结果(见 §built_vs_spec)

### enhancement_inputs
Use historical gate decisions, prior version baselines, incident feedback, override/waiver records, and release calendars to strengthen trend, circuit breaker, and PM override reasoning.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 上线前检查清单.csv
- 数据一致性检查项.csv
- 权限测试点.csv
- 并发测试点.csv
- 幂等测试点.csv
- 性能测试场景.csv
- blocker registry snapshots
- historical gate decisions
- release target or calendar context
- override requests or waiver records

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `gate_summary`
- `gate_dimensions[]`
- `aggregation_algorithm`
- `dimension_weights`
- `blocker_registry[]`
- `pass_conditions_machine_readable[]`
- `gate_history[]`
- `override_records[]`
- `decision_rationale`
- `downstream_handoff`
- `self_check`
- `specialty_summaries_consumed[]`
- `dedupe_rollup[]`
- `unknown_dimensions[]`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


> `metadata` field requirements: see `references/n260-v2-reactive-contract.md`.



## Same-node aggregation rules / same-node aggregation rules
- Treat 094 as operational readiness input, not a duplicate gate verdict.
- Map 095-099 summaries into gate dimensions and blocker registry explicitly.
- Do not count duplicate-linked specialty rows twice; use `shared_scenario_tag` and `canonical_owner_skill`.
- If specialty evidence is missing, mark the corresponding dimension as `insufficient_evidence` or `constrained`; do not infer pass.
- Preserve a transparent link from every hard veto to its source evidence.

## Design rules / design rules
- Declare one aggregation algorithm explicitly: all_pass, weighted_threshold, or veto_based.
- Treat compliance and other hard-veto dimensions as explicit vetoes instead of hiding them in prose.
- Represent conditional-go conditions as machine-readable checks, not only narrative bullets.
- Show which specialty outputs and blockers drive each dimension status.
- Highlight overrides with owner, expiry, documented risk, and reevaluation trigger.

## Execution workflow / execution workflow
1. Collect specialty outputs, blocker state, and readiness evidence.
2. Normalize all gate dimensions and bind supporting check items to each dimension.
3. Apply the declared aggregation algorithm and compute provisional gate status.
4. Evaluate blocker state, pass conditions, and any override records.
5. Emit the final gate artifact with rationale, open risks, and downstream release handoff.

## Dynamic completeness / dynamic completeness
- If only partial specialty evidence exists, keep the gate artifact stable but mark dimensions as pending or conditional with explicit reasons.
- If one hard-veto dimension fails, surface that immediately even when weighted totals look high.
- For release-critical slices, include gate history and trend framing so stakeholders see movement, not only a snapshot.



## Example usage

**Input**: N240 test results (47 passed, 2 failing), N250 defect status (DEF-5021 P0 open), smoke checklist (5/5 passed).

**Output** (`full_gate` mode, excerpt):
```yaml
gate_verdict: no_go
dimensions:
  - name: test_execution
    status: conditional
    weight: 0.30
    evidence: "47/49 passed; 2 failures under investigation"
  - name: defect_status
    status: fail
    weight: 0.25
    evidence: "DEF-5021 P0 open — hard veto"
  - name: smoke_validation
    status: pass
    weight: 0.20
    evidence: "5/5 smoke checks passed post-deploy"
blocker_registry:
  - blocker_id: BLK-001
    defect_ref: DEF-5021
    severity: P0
    owner: checkout_team
    resolution_path: "Fix and re-verify before re-gate"
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Resilience and governance addendum

**Produced events**: Emit `produced_event: produced.n260.quality_gate_check` in metadata when the artifact is complete or materially updated. Also emit `signal.n260.gate_regression` to N005 feedback loop when quantified thresholds in `references/signal-thresholds.md` are met.

**Confidence scoring**: Include `evidence_confidence: high/medium/low` in each item or dimension. Items with `evidence_confidence: low` must be flagged for `human_review_required: true` and must not be counted as passed in the quality gate.

**Circuit breaker**: circuit_breaker triggers when gate verdict regresses (pass→conditional or conditional→no_go) across 3 consecutive releases without a root-cause resolution.

**Traceability**: Every item must carry `canonical_owner_skill` and a reference to the upstream artifact or evidence id that produced it, enabling end-to-end traceability from requirement through to gate verdict in N270 and N280.

**Escalation path**: When `readiness: blocked` on any P0 item, escalate immediately to the release manager and the owning team lead. Log the escalation in `downstream_handoff.escalation_log[]`.

## Auditable rules summary

- R01_evidence_required: every gate dimension must cite at least one evidence item; on_violation: mark_insufficient_evidence.
- R02_no_fabricated_pass: do not mark a specialty dimension as passed without evidence from the owning skill; on_violation: reject.
- R03_veto_explicit: any hard veto must be listed in `blocker_registry[]` with owner and resolution path; on_violation: reject.
- R04_override_documented: conditional-go overrides must include approver, justification, and risk acknowledgement; on_violation: reject.
- R05_trend_regression_flagged: if a gate dimension regressed vs previous run, flag it even if still passing; on_violation: warn.
- R06_gate_verdict_immutable: once a gate verdict (pass/conditional/no_go) is recorded, it must not be silently overwritten; amendments require a new gate check run; on_violation: reject.
- R07_upstream_evidence_linked: every gate dimension must cite at least one upstream artifact ID as evidence; on_violation: flag_missing_evidence.
- R08_conditional_gate_requires_action: a conditional gate verdict must include at least one required_action item and an owner; on_violation: reject_conditional.
- R09_what_if_mode_produces_delta: in what_if mode, output must show before/after gate status for each affected dimension; on_violation: add_delta_comparison.

## Algorithm

1. Collect evidence from all input tiers; apply mode selection matrix.
2. For each gate dimension, assign status: pass / conditional / fail / insufficient_evidence (R01, R02).
3. Aggregate weighted scores; compute overall verdict.
4. Populate `blocker_registry[]` for any hard veto (R03).
5. Document overrides with approver and justification (R04).
6. Compare against previous gate run; flag regressions (R05).
7. Emit `gate_verdict`, `dimension_summary[]`, `downstream_handoff` to N270.
8. Run `self_check`; set `readiness: blocked` if R02 or R03 fires.

## Quality bar / quality bar
A good artifact makes it obvious why the gate is pass, conditional-go, or no-go; which blockers remain; what must change to reach pass; and whether any override meaningfully changes risk.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本（如 `n260.quality-gate-check.v2.2`），仅本 skill 字段变更时递增；
`governance_revision: "3.1.3"` — N260 组共享的 P6 治理框架修订号，修改 `n260-p6-governance.md` 时递增。
三套版本号独立变更，语义见 `references/n260-v2-reactive-contract.md`。

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/gate-aggregation-models.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`

## Usage scenarios

- `full_gate`: aggregate all upstream N260 signals into a final gate verdict.
- `quick_gate`: lightweight check for hotfix or patch releases.
- `what_if`: simulate gate outcome under proposed threshold changes.
- `post_incident_gate`: emergency gate evaluation after P0 resolution.
