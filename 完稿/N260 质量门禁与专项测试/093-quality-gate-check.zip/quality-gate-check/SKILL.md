---
name: quality-gate-check
description: aggregate standalone or n260-composable quality gate evidence into go, conditional, or no-go decisions. use for release gates, conditional-go review, blocker tracking, override review, trend regression, or when specialty outputs from checklist, data consistency, permission, concurrency, idempotency, or performance skills must be rolled up without duplicating them.
---
# quality-gate-check

## Role / role positioning
This skill aligns to testing & qa -> quality gate and specialty testing -> 质量门禁检查单.md. It delivers the authoritative workflow-aligned gate artifact for N260.

### Boundary
- Own gate aggregation, weighting, veto logic, pass-condition tracking, and override framing.
- Consume specialty test outputs rather than duplicating them.
- Do not fabricate pass results for specialty areas that are still pending evidence.
- Express decision rationale transparently enough for N270, N280, and N370 to consume.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_check`: aggregate available inputs fast without full history or override analysis.
- `full_gate`: produce the complete decision packet with weights, blocker registry, conditions, history, and override review.
- `what_if`: simulate how the conclusion changes if blockers close, dimensions improve, or overrides apply.



## v2 reactive contract / v2 reactive contract
This skill is optimized for v2 reactive workflow and must remain useful both standalone and inside N260 composition.

```yaml
reactive_contract:
  schema_version: "2.1"
  governance_revision: "3.1.3"
  produces_event: produced.n260.quality_gate_check
  routing_keywords: ['n260', 'quality-gate', 'gate-aggregation', 'conditional-go', 'no-go', 'release-blocker', 'override-review']
  signal_emission_to_n005: ['release_blocker', 'recurrent_defect', 'gate_regression', 'override_risk']
  human_review_sla: "P0 when hard veto or no_go; P1 when conditional with missing evidence; P2 for trend-only observations"
  canonical_function: gate_aggregation_and_decision
```

- Owns the authoritative quality verdict. It consumes 094-099 summaries and upstream evidence; it does not regenerate specialty rows.
- Always include `shared_scenario_tag`, `ownership_role`, and `canonical_owner_skill` when there is overlap with another N260 skill.
- Emit `produces_event` when the artifact is complete or materially updated.
- Emit N005 feedback signals only when quantified thresholds in `references/signal-thresholds.md` are met; otherwise keep findings local in `downstream_handoff`.



## v3.1.3 P6 governance enforcement
- Treat `references/cross-skill-orchestration.md` as the single source of truth for STG ownership tags; do not copy the STG table into other references.
- Before final handoff, apply `references/validation-rules.md`; validate JSON/YAML artifacts with `scripts/validate_n260_output.py` when a file artifact is available.
- Select mode and evidence tier using `references/mode-input-tier-matrix.md`; never silently promote minimal inputs into full workflow readiness.
- Map every internal category to a default STG tag using `references/classification-to-stg-map.md`.
- Emit N005 signals only when `references/signal-thresholds.md` thresholds are met.
- Validate Markdown and CSV artifacts with `scripts/validate_n260_output.py`; use `references/artifact-frontmatter-contract.md` for required frontmatter and CSV metadata conventions.
- Use the validator domain profile inferred from `metadata.skill_id` or passed with `--skill`; for final handoff, run with `--domain-mode strict` when a machine-readable artifact is available.
- Track `STG-UNMAPPED` usage. If it exceeds thresholds in `references/signal-thresholds.md`, keep readiness no stronger than `constrained` and raise the configured feedback signal.
- Treat validator script version `3.1.3` as the governance implementation version for this package.
- For final handoff with multi-artifact composition, run `scripts/validate_n260_output.py --cross-validate <artifact_dir> --domain-mode complete`; after editing STG maps, run `scripts/validate_n260_output.py --validate-stg-map .`; use `--exclude PATTERN` for archive folders and `--complete-min N` only when a stricter/lighter final handoff threshold is intentionally required.

## Input tiers / input tiers
Use tiered input handling so this aggregator remains usable outside a full N260 run.

### minimal_inputs
Accept any one of: a previous gate report, a blocker list, a release evidence summary, or one specialty summary. Produce a conservative partial gate with unknown dimensions marked `insufficient_evidence`.

### workflow_inputs
Prefer upstream quality evidence plus same-node summaries:
- `n100_gate_result`
- `n130_review_gates`
- `n150_api_compliance`
- `n170_nfr_designs`
- `n210_code_quality_summary`
- `n240_test_results`
- `n250_defect_status`
- `n094_checklist_summary`
- `n095_consistency_summary`
- `n096_permission_summary`
- `n097_concurrency_summary`
- `n098_idempotency_summary`
- `n099_performance_summary`

### enhancement_inputs
Use historical gate decisions, prior version baselines, incident feedback, override/waiver records, and release calendars to strengthen trend, circuit breaker, and PM override reasoning.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `测试用例集.xlsx`
- `回归测试清单.csv`
- `代码规范检查单.csv`
- `权限矩阵.csv`
- `数据流图.md`
- `幂等设计建议.md`
- `性能风险分析.md`

### optional enhancement inputs
- 上线前检查清单.csv
- 数据一致性检查项.csv
- 权限测试点.csv
- 并发测试点.csv
- 幂等测试点.csv
- 性能测试场景.csv
- blocker registry snapshots
- historical gate decisions
- release target or calendar context
- override requests or waiver records

## Standalone rule / standalone usage
This skill must still work on one module, one release slice, one risk surface, or one gate question.

Degradation rules:
- If only part of the preferred inputs are present, keep the output contract stable and mark missing dependencies in `downstream_handoff`.
- If specialty evidence is partial, separate known facts from pending checks instead of pretending a stronger conclusion.
- Keep artifacts conservative when release scope, environment context, or upstream nonfunctional detail is incomplete.

## Core output contract / core output contract
Default to Markdown or csv/yaml-friendly structures and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
- `gate_summary`
- `gate_dimensions[]`
- `aggregation_algorithm`
- `dimension_weights`
- `blocker_registry[]`
- `pass_conditions_machine_readable[]`
- `gate_history[]`
- `override_records[]`
- `decision_rationale`
- `downstream_handoff`
- `self_check`
- `specialty_summaries_consumed[]`
- `dedupe_rollup[]`
- `unknown_dimensions[]`
- `event_contract`
- `signal_emission`
- `human_review_queue[]`
- `schema_evolution`


`metadata` must contain:
- `selected_mode`
- `readiness`
- `function_bias: gate_aggregation_and_decision`
- `stage_position: testing_and_qa.quality_gate_and_specialty_testing.quality_gate_check`
- `workflow_node: N260`
- `node_artifact_target: 质量门禁检查单.md`
- `evidence_profile`
- `tool_collaboration_mode`
- `schema_version: 2.1`
- `governance_revision: 3.1.3`
- `event_contract.produces_event`
- `routing.intent_tags`
- `routing.routing_keywords`
- `signal_emission.to_n005`
- `human_review.sla_priority`
- `schema_evolution.compatibility`



## Same-node aggregation rules / same-node aggregation rules
- Treat 094 as operational readiness input, not a duplicate gate verdict.
- Map 095-099 summaries into gate dimensions and blocker registry explicitly.
- Do not count duplicate-linked specialty rows twice; use `shared_scenario_tag` and `canonical_owner_skill`.
- If specialty evidence is missing, mark the corresponding dimension as `insufficient_evidence` or `constrained`; do not infer pass.
- Preserve a transparent link from every hard veto to its source evidence.

## Design rules / design rules
- Declare one aggregation algorithm explicitly: all_pass, weighted_threshold, or veto_based.
- Treat compliance and other hard-veto dimensions as explicit vetoes instead of hiding them in prose.
- Represent conditional-go conditions as machine-readable checks, not only narrative bullets.
- Show which specialty outputs and blockers drive each dimension status.
- Highlight overrides with owner, expiry, documented risk, and reevaluation trigger.

## Execution workflow / execution workflow
1. Collect specialty outputs, blocker state, and readiness evidence.
2. Normalize all gate dimensions and bind supporting check items to each dimension.
3. Apply the declared aggregation algorithm and compute provisional gate status.
4. Evaluate blocker state, pass conditions, and any override records.
5. Emit the final gate artifact with rationale, open risks, and downstream release handoff.

## Dynamic completeness / dynamic completeness
- If only partial specialty evidence exists, keep the gate artifact stable but mark dimensions as pending or conditional with explicit reasons.
- If one hard-veto dimension fails, surface that immediately even when weighted totals look high.
- For release-critical slices, include gate history and trend framing so stakeholders see movement, not only a snapshot.

## Quality bar / quality bar
A good artifact makes it obvious why the gate is pass, conditional-go, or no-go; which blockers remain; what must change to reach pass; and whether any override meaningfully changes risk.

## Reference files / reference files
- `references/n260-v2-reactive-contract.md`
- `references/gate-aggregation-models.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/validation-rules.md`
- `references/signal-thresholds.md`
- `references/mode-input-tier-matrix.md`
- `references/classification-to-stg-map.md`
- `references/artifact-frontmatter-contract.md`