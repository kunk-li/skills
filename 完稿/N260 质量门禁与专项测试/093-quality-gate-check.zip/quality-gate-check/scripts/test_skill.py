#!/usr/bin/env python3
"""Self-test: validate the skill spec plus runtime evidence tier behavior."""
import json, os, subprocess, sys, tempfile

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")

skill_dir  = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
skill_md   = os.path.join(skill_dir, "SKILL.md")
validator  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "validate_skill.py")

result = subprocess.run(
    [sys.executable, validator, skill_md, "--strict"],
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="replace",
)
print(result.stdout)
if result.returncode != 0:
    print("STDERR:", result.stderr, file=sys.stderr)
    sys.exit(1)

runtime_validator = os.path.join(os.path.dirname(os.path.abspath(__file__)), "validate_n260_output.py")


def base_doc(readiness="pass"):
    return {
        "metadata": {
            "schema_version": "2.1",
            "governance_revision": "3.1.3",
            "skill_id": "quality-gate-check",
            "workflow_node": "N260",
            "selected_mode": "full_gate",
            "readiness": readiness,
            "evidence_profile": "direct_contract",
            "routing": {},
            "event_contract": {"produces_event": "produced.n260.quality_gate_check"},
            "signal_emission": {"to_n005": False},
            "human_review": {},
            "schema_evolution": {},
        },
        "gate_summary": {},
        "final_verdict": "pass",
        "release_gate": "pass",
    }


def run_doc(doc):
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as fh:
        json.dump(doc, fh, ensure_ascii=False)
        path = fh.name
    try:
        return subprocess.run(
            [sys.executable, runtime_validator, "--skill", "quality-gate-check", "--domain-mode", "complete", path],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


bad = base_doc(readiness="pass")
bad["runtime_integration_status"] = "runtime_integration_pass"
bad["runtime_boundary_evidence_rollup"] = [
    {
        "boundary_id": "B-DB",
        "boundary_type": "db",
        "evidence_tier": "self_contained_runtime",
        "evidence_mode": "standalone_smoke",
        "gate_effect": "block_release",
        "gate_decision": "pass",
    }
]
bad_result = run_doc(bad)
if bad_result.returncode == 0:
    print("Expected release-blocking self-contained runtime overclaim to fail", file=sys.stderr)
    print(bad_result.stdout, file=sys.stderr)
    sys.exit(1)

good = base_doc(readiness="pass")
good["self_contained_runtime_status"] = "pass"
good["runtime_integration_status"] = "not_applicable"
good["runtime_boundary_evidence_rollup"] = [
    {
        "boundary_id": "LOCAL-RUNTIME",
        "boundary_type": "local_runtime",
        "evidence_tier": "self_contained_runtime",
        "evidence_mode": "standalone_smoke",
        "gate_effect": "local_runtime_only",
        "gate_decision": "pass",
    }
]
good_result = run_doc(good)
if good_result.returncode != 0:
    print("Expected local_runtime_only self-contained runtime proof to pass", file=sys.stderr)
    print(good_result.stdout, file=sys.stderr)
    print(good_result.stderr, file=sys.stderr)
    sys.exit(1)

print("Self-test PASSED.")
