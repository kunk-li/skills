#!/usr/bin/env python3
"""Self-test: run validate_skill.py against this skill's own SKILL.md."""
import subprocess, os, sys

skill_dir  = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
skill_md   = os.path.join(skill_dir, "SKILL.md")
validator  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "validate_skill.py")

result = subprocess.run(
    [sys.executable, validator, skill_md, "--strict"],
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="replace",
)
print(result.stdout)
if result.returncode != 0:
    print("STDERR:", result.stderr, file=sys.stderr)
    sys.exit(1)
print("Self-test PASSED.")
