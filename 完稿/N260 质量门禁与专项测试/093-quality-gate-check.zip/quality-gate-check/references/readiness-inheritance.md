# Readiness Inheritance

若上游输入已经带有就绪度锚点，继承规则如下：
- `pass`: 可输出全量专项内容，但仍要把未验证事实与推断分开。
- `constrained`: 输出 `confirmed` 区和 `blocked/todo` 区，避免把未验证信息混入已确认内容。
- `blocked`: 只输出最小必要清单、主风险与补证建议，不声称已具备放行条件。

## Single-source-of-truth rule
- 不上调 readiness。
- 不把“建议做什么”写成“已经完成什么”。
- 不把专项生成结果误写成正式审批结论。
- 不把 `guarded_reference_status: pass` 或本地参考实现通过继承成 `runtime_integration_status: pass`；运行时边界未清时，093 readiness 最高只能是 `constrained`。

## Gate-aware mode
对于门禁链路，优先按照 `已确认事实 / 缺失证据 / 下一步动作` 三段组织输出。
