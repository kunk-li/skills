# N260 示例输入输出 v2（扩展场景）

## 示例 3：并发测试点生成（concurrency-test-point-generation）

### 输入
- 场景：订单服务，共享库存写操作

### 输出
```yaml
concurrency_test_points:
  - tp_id: CTP-001
    surface: 库存扣减
    pattern: 竞争写
    isolation_level: SERIALIZABLE
    test: 100并发请求同一SKU，库存不可为负
  - tp_id: CTP-002
    pattern: 死锁
    test: 订单A锁库存→锁账户 vs 订单B锁账户→锁库存
```

## 示例 4：性能测试场景生成（performance-test-scenario-generation）

### 输入
- SLO：p95 ≤ 500ms，吞吐量 ≥ 1000 rps

### 输出
```yaml
performance_scenarios:
  - type: load
    config: 1000 rps × 10min
    slo_assertion:
      metric: p95_latency
      threshold: 500ms
      window: 10min
    abort_condition: error_rate > 5%
  - type: stress
    config: ramp 100→2000 rps
    abort_condition: p95 > 2000ms
```

## 093 扩展示例输入输出

### Example B — what_if mode (simulating a gate under a proposed threshold change)

**Input**: Current gate: test coverage 72% (failing 80% threshold). Team proposes lowering threshold to 70% for this sprint.

**Output** (`what_if` mode):
```yaml
gate_check_result:
  mode: what_if
  verdict: conditional
  what_if_scenario:
    dimension: test_coverage
    current_threshold: 80%
    proposed_threshold: 70%
  status_before:
    test_coverage: fail (72% < 80%)
    overall_verdict: no_go
  status_after:
    test_coverage: pass (72% ≥ 70%)
    overall_verdict: conditional
  required_actions:
    - action: Obtain Tech Lead sign-off for threshold reduction
      owner: tech_lead
      deadline: before_merge
    - action: Create ticket to restore 80% coverage within 2 sprints
      owner: dev_team
      priority: P2
  readiness: constrained
  blocker_registry_entry:
    id: BLK-094
    gate_dimension: test_coverage
    status: threshold_exception_requested
    approver: pending
```


### Scenario C — Post-incident emergency gate

**Input**: P0 resolved; team wants minimal gate before restoring traffic.

**Output** (`post_incident_gate` mode):
```yaml
gate_check_result:
  mode: post_incident_gate
  verdict: conditional
  dimensions:
    incident_resolved: pass
    smoke_test: pass (SMK-R001-R003 green)
    p0_defects: pass (0 open)
    regression_scope: pending (deferred — run after traffic restored)
  required_actions:
    - Run full regression within 24h of traffic restore
    - Update incident post-mortem before next sprint
  readiness: constrained
```

### Scenario D — Post-incident emergency gate

**Input**: P0 incident resolved; team needs minimal gate before restoring traffic.

**Output** (`post_incident_gate` mode):
```yaml
gate_check_result:
  mode: post_incident_gate
  verdict: conditional
  evidence_completeness: partial
  dimensions:
    incident_resolved: pass
    smoke_test: pass (SMK-R001-R003 green)
    p0_defects: pass (0 open)
    full_regression: pending (deferred — run within 24h of traffic restore)
  required_actions:
    - Run full regression within 24h
    - Update incident post-mortem before next sprint
  readiness: constrained
  downstream_handoff:
    to: N270-release-coordination
    signal: conditional_pass_with_deferred_regression
```

### Scenario D — Incremental gate (CI check, not full release)

**Input**: Feature branch CI run, not release — partial evidence only.

**Output** (`ci_check` mode):
```yaml
gate_check_result:
  mode: ci_check
  verdict: pass
  scope: incremental_only
  evaluated_dimensions:
    smoke_test: pass (SMK-001-003 all green)
    p0_defects: pass (0 new P0 in this branch)
    regression: not_evaluated (full regression runs on main only)
    performance: not_evaluated (runs nightly only)
    security_scan: pass (SAST clean)
  not_evaluated_reason: ci_check mode evaluates smoke + P0 + SAST only
  readiness: ready
  downstream_handoff:
    to: pr_merge_approval
    signal: ci_gate_passed
  note: Full gate (all dimensions) runs on merge to main
```
