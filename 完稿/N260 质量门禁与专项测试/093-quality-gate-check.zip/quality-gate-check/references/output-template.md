# Output Template: 质量门禁检查

## 默认结构
- `门禁结论`
- `已确认事实`
- `阻塞与高风险问题`
- `缺失证据`
- `复查条件`
- `建议动作`

## 推荐字段
| gate_type | item | gate_decision | priority | blocking_reason | evidence_ref | owner | next_action |
|---|---|---|---|---|---|---|---|

## 聚合判定规则
- `pass`: 无 blocker，且关键证据完整。
- `constrained`: 可推进，但存在必须跟踪的缺口或条件。
- `blocked`: 关键证据缺失，或存在未缓解 blocker。

## 禁止
- ❌ 把“建议补测”写成“已经通过”。
- ❌ 没有依据就直接给 go/no-go。
- ❌ 混用专项状态与最终门禁审批状态。


## v2.1 shared contract fields
Include these fields when the output is row-based:
`schema_version | shared_scenario_tag | ownership_role | canonical_owner_skill | related_specialty_refs | deduplicated_links | human_review_required | sla_priority | signal_to_n005`

Use `status=insufficient_evidence` instead of implying pass/fail when proof is missing.

## v3.1 governance fields
- Include `metadata.governance_revision: "3.1"`.
- Validate required metadata and item de-dup fields against `validation-rules.md`.
- Use `classification-to-stg-map.md` to set `shared_scenario_tag`.
- Use `signal-thresholds.md` before emitting to N005.

## Markdown and CSV frontmatter
For Markdown or CSV outputs, apply `references/artifact-frontmatter-contract.md` so the same metadata can be validated by `scripts/validate_n260_output.py`.
