# Output Template: 质量门禁检查

## 默认结构
- `门禁结论`
- `已确认事实`
- `阻塞与高风险问题`
- `缺失证据`
- `复查条件`
- `建议动作`

## 推荐字段
| gate_type | item | gate_decision | priority | blocking_reason | evidence_ref | owner | next_action |
|---|---|---|---|---|---|---|---|

## Runtime boundary evidence rollup

When `runtime_integration_evidence_matrix[]` is provided by N240, include a dedicated rollup instead of burying runtime proof gaps in prose.

Top-level gate summary fields:
- `reference_execution_status`: `not_applicable | not_run | guarded_reference_pass | fail`
- `guarded_reference_status`: `not_applicable | not_run | pass | fail`
- `self_contained_runtime_status`: `not_applicable | not_run | pass | fail`
- `runtime_integration_status`: `not_applicable | not_cleared | partial | runtime_integration_pass`
- `release_gate`: `pass | conditional | blocked | no_go`

| boundary_id | boundary_type | production_surface | required_evidence | evidence_tier | evidence_mode | evidence_ref | status | gate_effect | gate_decision | next_action |
|---|---|---|---|---|---|---|---|---|---|---|

Rules:
- `evidence_tier` must be one of `reference_only | self_contained_runtime | production_external_integration`.
- `static_reference_only`, `guarded_reference`, `reference_only`, `local_reference`, `mock_only`, `in_memory`, `unit_only`, and `not_available` map to `reference_only`.
- `self_contained_runtime`, `local_adapter_runtime`, `standalone_smoke`, `http_smoke`, `maven_package`, and `self_contained_package` map to `self_contained_runtime`.
- `production_external_integration`, `real_db`, `real_auth`, `real_workflow`, `real_notification_gateway`, `real_key_management`, `real_alerting_platform`, `real_scheduler`, and `production_runtime_pass` map to `production_external_integration`.
- `gate_effect=block_release` with missing proof or `evidence_tier` below `production_external_integration` must become `gate_decision=insufficient_evidence`, `blocked`, `not_cleared`, or `conditional`.
- `gate_effect=local_runtime_only` may pass with `evidence_tier=self_contained_runtime`, but it must not set production `runtime_integration_status=runtime_integration_pass`.
- `guarded_reference_status=pass` does not imply `runtime_integration_status=runtime_integration_pass`.
- If `runtime_integration_status` is not pass/cleared, do not emit `metadata.readiness=pass`, `final_verdict=pass`, or `release_gate=pass`.
- Preserve the row for N270 release checklist handoff.

## 聚合判定规则
- `pass`: 无 blocker，且关键证据完整。
- `constrained`: 可推进，但存在必须跟踪的缺口或条件。
- `blocked`: 关键证据缺失，或存在未缓解 blocker。

## 禁止
- ❌ 把“建议补测”写成“已经通过”。
- ❌ 没有依据就直接给 go/no-go。
- ❌ 混用专项状态与最终门禁审批状态。


## v2.1 shared contract fields
Include these fields when the output is row-based:
`schema_version | shared_scenario_tag | ownership_role | canonical_owner_skill | related_specialty_refs | deduplicated_links | human_review_required | sla_priority | signal_to_n005`

Use `status=insufficient_evidence` instead of implying pass/fail when proof is missing.

## v3.1 governance fields
- Include `metadata.governance_revision: "3.1.3"`.
- Validate required metadata and item de-dup fields against `validation-rules.md`.
- Use `classification-to-stg-map.md` to set `shared_scenario_tag`.
- Use `signal-thresholds.md` before emitting to N005.

## Markdown and CSV frontmatter
For Markdown or CSV outputs, apply `references/artifact-frontmatter-contract.md` so the same metadata can be validated by `scripts/validate_n260_output.py`.
