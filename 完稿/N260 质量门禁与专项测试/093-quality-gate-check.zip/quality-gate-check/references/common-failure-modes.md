# 质量门禁常见失败模式

## F1: 直接放行，没有证据映射
修正：每个关键结论都要能回溯到专项结果、测试证据或规则条款。

## F2: 只列问题，不给复查条件
修正：说明补齐哪些证据、谁负责、补齐后如何判定。

## F3: 不区分 blocker 与一般问题
修正：至少拆成 `阻塞 / 高风险 / 一般问题` 三层。

## F4: 把专项生成结果当最终审批
修正：保持“本 skill 只做聚合判断，不代替正式签字”的边界。

## F5: 把 guarded reference 跑绿当生产运行时集成通过
修正：拆出 `guarded_reference_status` 与 `runtime_integration_status`。参考实现通过但 DB/cache/auth/external/audit/config/runtime 证据未清时，最终门禁不能是 `pass`。

## v2 duplicate and routing failure modes
- Duplicate-generating both 097 same-key concurrency rows and 098 same-key idempotency outcome rows without shared IDs.
- Treating 094 operational readiness as the final 093 quality gate verdict.
- Emitting specialty rows without `shared_scenario_tag`, which prevents 093 from de-duplicating weighted score.
- Claiming `pass` when the correct state is `insufficient_evidence`.
- Failing to emit N005 signals for recurring release-blocking defects or regressions.
