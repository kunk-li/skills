# N260 validation rules v3.1.3

## Purpose
Turn governance metadata into enforceable checks before a result is handed to N260, N370, N005, or a downstream release node.

## Common JSON Schema fragment
Use this fragment for JSON/YAML artifacts, Markdown frontmatter, or CSV metadata columns. See `artifact-frontmatter-contract.md` for Markdown and CSV conventions.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "quality-gate-check n260 v3.1.3 output contract",
  "type": "object",
  "required": ["metadata"],
  "properties": {
    "metadata": {
      "type": "object",
      "required": [
        "schema_version",
        "skill_id",
        "workflow_node",
        "selected_mode",
        "readiness",
        "evidence_profile",
        "routing",
        "event_contract",
        "signal_emission",
        "human_review",
        "schema_evolution"
      ],
      "properties": {
        "schema_version": {"type": "string"},
        "governance_revision": {"const": "3.1.3"},
        "skill_id": {"const": "quality-gate-check"},
        "workflow_node": {"const": "N260"},
        "selected_mode": {"enum": ["quick_check", "full_gate", "what_if"] },
        "readiness": {"enum": ["pass", "constrained", "blocked", "insufficient_evidence"]},
        "event_contract": {
          "type": "object",
          "required": ["produces_event"],
          "properties": {"produces_event": {"const": "produced.n260.quality_gate_check"}}
        },
        "signal_emission": {
          "type": "object",
          "required": ["to_n005", "emit_when"]
        }
      }
    },
    "items": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["shared_scenario_tag", "ownership_role", "canonical_owner_skill", "related_specialty_refs", "deduplicated_links"],
        "properties": {
          "ownership_role": {"enum": ["canonical", "supporting", "duplicate_reference"]}
        }
      }
    }
  }
}
```

## Runtime enforcement
1. Include a top-level `metadata` block in every artifact, even Markdown or CSV outputs.
2. Validate JSON/YAML/Markdown/CSV with `scripts/validate_n260_output.py --skill quality-gate-check <artifact-file>` when a file artifact is available. For final handoff, add `--domain-mode strict` when the artifact includes domain rows or sections.
3. If validation fails, fix the artifact before handoff. If evidence is missing and cannot be fixed, set `readiness: insufficient_evidence` or `constrained`; never claim `pass`.
4. Every item with possible overlap must use one STG tag from `cross-skill-orchestration.md` and must declare whether it is canonical, supporting, or duplicate_reference.
5. Duplicate-linked rows must not be counted twice in 093 rollup or 094 readiness completion.
6. Signal emission must meet thresholds in `signal-thresholds.md`.
7. Mode and input tier must be legal according to `mode-input-tier-matrix.md`.
8. Internal classification must map to a default STG tag according to `classification-to-stg-map.md`.
9. Guarded/reference execution evidence must not be counted as production runtime integration proof. If release-blocking runtime rows use reference-only evidence modes, keep row `gate_decision` at `insufficient_evidence`, `blocked`, `not_cleared`, or `conditional`, and keep final readiness/verdict below pass.

## Manual validation checklist
- [ ] Metadata block is present and includes governance fields.
- [ ] `selected_mode` is one of the allowed modes for this skill.
- [ ] `readiness` does not overstate evidence strength.
- [ ] Event and N005 signal fields are present.
- [ ] STG ownership and duplicate links are declared for overlapping rows.
- [ ] Human review SLA is set when blocker, override, compliance, security, data, entitlement, or SLO risk exists.


## Domain validation profile v3.1.3
The shared validator includes a profile for `quality-gate-check`.

- Expected event: `produced.n260.quality_gate_check`
- Accepted selected modes: `quick_check, full_gate, what_if`
- Domain sections accepted by the validator: `gate_summary, quality_gate, gate_dimensions, blocker_registry, aggregation_algorithm, final_verdict, runtime_boundary_evidence_rollup`
- Domain item fields accepted by the validator: `dimension_id, verdict, source_evidence, boundary_id, boundary_type, evidence_mode, gate_effect, gate_decision`
- Domain note: Gate artifacts should contain a gate summary, dimensions or blocker registry, and an explicit final verdict or aggregation algorithm.
- Runtime false-green control: `scripts/validate_n260_output.py` rejects `metadata.readiness=pass`, `final_verdict=pass`, or `release_gate=pass` when runtime proof is only `static_reference_only`, `guarded_reference`, `reference_only`, `local_reference`, `mock_only`, `in_memory`, `unit_only`, or `not_available`, or when `runtime_integration_status` is not cleared.

Use `--domain-mode warn` during drafting and `--domain-mode strict` for final machine-readable handoff. If strict validation fails only because the artifact is a human-readable summary, add Markdown frontmatter and a minimal `items[]` or domain section rather than bypassing validation.

## STG-UNMAPPED control v3.1.3
`STG-UNMAPPED` is a temporary exception, not a normal tag. If more than 2 rows or more than 10% of rows in one artifact use `STG-UNMAPPED`, keep `readiness` no stronger than `constrained`, add a human review item, and emit or queue the N005 signal described in `signal-thresholds.md`.


## v3.1.3 P6 validator extensions
Use the shared validator for four additional P5 controls:

- `--validate-stg-map .`: verify that `classification-to-stg-map.md` references only STG tags defined in `cross-skill-orchestration.md`, except the temporary `STG-UNMAPPED` exception.
- `--domain-mode complete`: require stronger domain coverage than `strict`; final full artifacts should pass complete mode whenever they claim full workflow readiness.
- `--cross-validate <artifact_dir>`: scan multiple N260 artifacts and fail when more than one skill marks the same STG tag as `ownership_role: canonical`.
- `N260_FORCE_SIMPLE_YAML=1`: optional test mode to exercise the validator's built-in YAML parser without PyYAML.
