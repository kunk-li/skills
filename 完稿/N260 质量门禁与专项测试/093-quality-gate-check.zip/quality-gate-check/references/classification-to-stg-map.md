# Internal classification to STG map v3.1.3

## Purpose
Bind the skill's internal categories to shared N260 STG tags so generated rows are deduplicable by 093 and N370.

| internal classification | default shared_scenario_tag | ownership_role | notes |
|---|---|---|---|
| `D01_requirement_completeness` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Treat as upstream evidence dimension; do not create specialty rows. |
| `D02_requirement_conflict` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Hard-rule dimension; aggregate conflict evidence only. |
| `D03_vulnerability` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Aggregate security/vulnerability blocker state; link to 096 if authorization-specific. |
| `D04_pending_items` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Aggregate unresolved pending blockers and transition conditions. |
| `D05_solution_review` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Aggregate N130 review readiness. |
| `D06_api_compliance` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Aggregate API compliance; link to specialty refs when affected. |
| `D07_nfr_design_coverage` | `STG-CONCURRENCY-RACE-MECHANICS / STG-IDEMPOTENCY-KEY-OUTCOME / STG-PERFORMANCE-SLO-CAPACITY / STG-AUTHZ-MATRIX-IDOR-SOD` | `supporting` | Consume specialty summaries; never regenerate specialty tests. |
| `D08_code_quality_bugs` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Aggregate N210 blocker/critical findings. |
| `D09_code_quality_smells` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Aggregate technical-debt signal. |
| `D10_transaction_safety` | `STG-DATA-AGGREGATE-INVARIANT` | `supporting` | Gate impact comes from N210/N170; link to 095 for invariant/reconciliation rows. |
| `D11_thread_safety` | `STG-CONCURRENCY-RACE-MECHANICS` | `supporting` | Gate impact comes from N210/N170; link to 097 for race rows. |
| `D12_test_coverage` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Aggregate N240/N230 coverage results. |
| `D13_test_pass_rate` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Aggregate N240 pass rate; P0 failure remains hard rule. |
| `D14_open_defects` | `STG-QUALITY-GATE-ROLLUP` | `canonical` | Aggregate N250 defect status and transition plan. |
| `D15_compliance_audit` | `STG-AUTHZ-MATRIX-IDOR-SOD` | `supporting` | Aggregate compliance evidence; link to 096 for permission-sensitive coverage. |

## Enforcement
- Every generated row should include the most specific internal classification and at least one default STG tag from this map.
- If a row spans multiple classifications, include multiple tags and mark only the canonical owner as `ownership_role: canonical`.
- If the map does not cover a new category, add a temporary `STG-UNMAPPED` note in `downstream_handoff` and mark readiness no stronger than `constrained` until the map is updated.

## STG-UNMAPPED governance limit
Use `STG-UNMAPPED` only as a temporary exception. More than 2 unmapped rows or more than 10% unmapped rows in one artifact is a governance signal and must keep readiness no stronger than `constrained` until the map is updated.


## v3.1.3 map integrity check
After editing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

The check fails if this file references an STG tag that is not defined in `references/cross-skill-orchestration.md`, except for the temporary `STG-UNMAPPED` exception.


## v3.1.3 owner-map consistency

After changing this map, run:

```bash
python scripts/validate_n260_output.py --validate-stg-map .
```

During artifact validation, `canonical_owner_skill` is checked against the canonical owner table in `cross-skill-orchestration.md`. Use `STG-UNMAPPED` only as a temporary constrained fallback, not as an owner bypass.
