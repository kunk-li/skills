# Gate aggregation models

- `all_pass`: every dimension must be pass.
- `weighted_threshold`: compute weighted score with pass=100, conditional=70, pending=50, fail=0.
- `veto_based`: any configured hard-veto dimension fail forces no-go before weighted scoring.

## Recommended defaults
- Use `veto_based` when compliance, security, or data integrity can block release independently.
- Use `weighted_threshold` for broader portfolio governance where some dimensions can be conditional.
- Keep `all_pass` for the strictest regulated flows.

## v2.1 same-node specialty rollup
093 must consume same-node summaries from 094-099 when available. Map them as follows:
- 094 -> operational readiness overlay and launch blocker handoff; do not treat as a duplicate quality verdict.
- 095 -> data consistency / reconciliation blockers and D07/D15 supporting evidence.
- 096 -> authorization, sensitive data, SoD, and audit-related gate evidence.
- 097 -> concurrency, isolation, deadlock, race, and thread-safety supporting evidence.
- 098 -> idempotency, duplicate side effect, retry safety, and transaction-safety supporting evidence.
- 099 -> performance SLO, capacity, regression, soak, and performance blocker evidence.
Duplicate-linked rows must be summarized once and must not inflate weighted scores.
