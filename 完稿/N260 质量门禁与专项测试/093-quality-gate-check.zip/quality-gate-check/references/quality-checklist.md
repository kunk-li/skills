# Quality Checklist

输出前自查：
- 是否明确区分“事实”“推断”“待确认”？
- 是否给出结构稳定、可复核、可追踪的字段？
- 是否体现该专项的独有维度，而不是泛化成通用测试清单？
- 是否明确 owner、evidence、acceptance 或下一步动作？
- 是否避免把专项草稿写成最终审批结论？
- 如果输入包含 `runtime_integration_evidence_matrix[]`，是否逐行保留到 `runtime_boundary_evidence_rollup[]`，并且没有把 `static_reference_only` / `not_available` 当作生产 runtime pass？
