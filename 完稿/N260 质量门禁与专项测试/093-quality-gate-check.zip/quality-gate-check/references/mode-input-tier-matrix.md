# Mode x input tier matrix v3.1

## Purpose
Prevent mode and input-tier ambiguity. `selected_mode` is the work style; input tier is the evidence depth. They are related but not synonyms.

| selected_mode | input tier | rule |
|---|---|---|
| `quick_check` | `minimal_inputs` | Allowed. At least one evidence source or one specialty summary is enough. Mark all unknown dimensions as insufficient_evidence. |
| `quick_check` | `workflow_inputs` | Allowed. Produce a compact gate rollup without full trend or override analysis unless requested. |
| `quick_check` | `enhancement_inputs` | Optional. Use only if present; do not block quick output. |
| `full_gate` | `minimal_inputs` | Not recommended. Downgrade to quick_check unless user explicitly requests a partial full gate. |
| `full_gate` | `workflow_inputs` | Required. Consume cross-node evidence plus n094-n099 summaries when available. |
| `full_gate` | `enhancement_inputs` | Recommended. Use history, override, baseline, and incident context for trend and risk. |
| `what_if` | `minimal_inputs` | Allowed. Simulate only the dimensions present and label missing evidence. |
| `what_if` | `workflow_inputs` | Allowed. Simulate transition plan changes across actual blockers. |
| `what_if` | `enhancement_inputs` | Recommended. Use trends and prior outcomes for projection. |

## Enforcement
- If the requested mode is not legal for the available input tier, either downgrade the mode or mark the result `insufficient_evidence`.
- Never silently promote minimal inputs into a full workflow claim.
- Record the chosen mode and input tier in `metadata.selected_mode` and `metadata.evidence_profile.input_completeness`.
