#!/usr/bin/env python3
import sys
from pathlib import Path
MODES=['module_benchmark',
 'workflow_benchmark',
 'page_benchmark',
 'rule_gap_analysis',
 'low_evidence_benchmark']
SCHEMA='planning.competitor-feature-benchmarking.v4'
PRIMARY='competitor-feature-benchmark.csv'

def collect_errors(skill_dir):
    d=Path(skill_dir); errors=[]
    text=(d/'references'/'selected-mode-decision-tree.md').read_text(encoding='utf-8')
    skill=(d/'SKILL.md').read_text(encoding='utf-8')
    for m in MODES:
        if m not in text: errors.append(f'mode {m} missing from decision tree')
        if m not in skill: errors.append(f'mode {m} missing from SKILL.md')
    if SCHEMA not in text: errors.append('schema missing from decision tree')
    if PRIMARY not in text: errors.append('primary artifact missing from decision tree')
    return errors

def main():
    d=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
    errors=collect_errors(d)
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f'OK: selected-mode decision tree aligned for competitor-feature-benchmarking')
    return 0
if __name__=='__main__': sys.exit(main())
