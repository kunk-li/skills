# Real Examples / 真实示例参考

These examples illustrate correctly formed benchmarking rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Module benchmark — confirmed vs. inferred parity

**Input**: Competitor X's public demo video shows a bulk-upload UI for invoices; our product has CSV import only.

**Correct pattern**:
```
benchmark_id: BENCH-upload-001
feature_module: bulk_data_import
our_capability: CSV file import only; no UI-based drag-and-drop
competitor_capability: drag-and-drop bulk upload via browser UI (Competitor X)
parity_status: gap
evidence_status: confirmed
confidence: medium
source_refs: SRC-demo-video-competitorX-202605
notes: Competitor capability confirmed via demo video. Our capability confirmed via product audit. Parity gap is real but severity depends on user segment.
open_questions: Does our target segment prioritize drag-and-drop over CSV import?
```

---

## Example 2: Feature gap analysis — not roadmap decision

**Input**: Competitor Y has AI-suggested invoice categories; we do not.

**Correct pattern**:
```
benchmark_id: BENCH-ai-category-001
feature_module: invoice_categorization
our_capability: manual category selection
competitor_capability: AI-suggested categories with one-click accept (Competitor Y)
parity_status: gap
evidence_status: confirmed
confidence: high
recommended_route: value_assessment
notes: This benchmark row identifies a capability gap. It does not recommend building the feature — route to value and cost assessment for that decision. (AP-08 + AP-CA-05)
```

**Anti-pattern to avoid (AP-CA-05)**: Writing `recommended_action: Add AI categorization to Q3 roadmap` — this crosses the skill boundary into roadmap commitment.

---

## Example 3: Positioning comparison — caveat on market edition

**Input**: Competitor Z's Enterprise tier includes a dedicated audit-log module; our product has basic activity logs on all plans.

**Correct pattern**:
```
benchmark_id: BENCH-auditlog-001
feature_module: audit_logging
our_capability: basic activity log on all plans; no structured audit export
competitor_capability: dedicated audit-log module with CSV export on Enterprise tier only (Competitor Z)
parity_status: partial_parity
edition_caveat: Competitor Z audit log requires Enterprise; our basic log available on all tiers
evidence_status: confirmed
confidence: high
source_refs: SRC-competitorZ-enterprise-docs-202605
notes: Parity comparison is edition-gated. Full-featured audit log is a premium capability for Competitor Z; our offering is more accessible but less structured.
```
