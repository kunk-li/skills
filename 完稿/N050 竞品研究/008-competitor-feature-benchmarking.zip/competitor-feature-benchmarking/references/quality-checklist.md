# Quality checklist for Competitor Feature Benchmarking

Start with the shared checklist in `shared-planning-assessment-contract.md#common-quality-checklist`, then apply these skill-specific checks:

- Benchmarking without a stable target module
- Using vague dimensions such as better experience
- Defaulting unknown internal state to absent
- Mixing capability existence with impact rating
- Ignoring non-comparable competitor editions

Before handoff, run `python scripts/validate_release_consistency.py .`.
