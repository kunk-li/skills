# Selected-mode decision tree

## `module_benchmark`
- Use when the input most closely matches `module benchmark`.
- Output schema: `planning.competitor-feature-benchmarking.v4`.
- Primary artifact: `competitor-feature-benchmark.csv`.

## `workflow_benchmark`
- Use when the input most closely matches `workflow benchmark`.
- Output schema: `planning.competitor-feature-benchmarking.v4`.
- Primary artifact: `competitor-feature-benchmark.csv`.

## `page_benchmark`
- Use when the input most closely matches `page benchmark`.
- Output schema: `planning.competitor-feature-benchmarking.v4`.
- Primary artifact: `competitor-feature-benchmark.csv`.

## `rule_gap_analysis`
- Use when the input most closely matches `rule gap analysis`.
- Output schema: `planning.competitor-feature-benchmarking.v4`.
- Primary artifact: `competitor-feature-benchmark.csv`.

## `low_evidence_benchmark`
- Use when the input most closely matches `low evidence benchmark`.
- Output schema: `planning.competitor-feature-benchmarking.v4`.
- Primary artifact: `competitor-feature-benchmark.csv`.
