# Output template for Competitor Feature Benchmarking

Primary artifact: `competitor-feature-benchmark.csv`

Required CSV header:

```csv
benchmark_id,target_module,comparison_dimension,our_current_state,competitor_state,gap_type,gap_impact,evidence_status,source_refs,confidence,recommended_route,open_questions,competitor_insight_ids,version_or_date,sample_name,benchmark_notes,related_requirement_ids
```

Recommended human-readable explanation:

## 1. Benchmark overview

- ...

## 2. Side-by-side table

- ...

## 3. Gap summary

- ...

## 4. Validation needs

- ...

