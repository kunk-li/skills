---
name: competitor-feature-benchmarking
display_name: 竞品功能对标 / Competitor Feature Benchmarking
description: Benchmark a specified module, page, workflow, or feature set against one or more competitors using explicit reusable comparison dimensions and a side-by-side structure. Use when the target scope is already known and the user needs a focused benchmark, gap analysis, or discussion-ready table. Not for broad competitor scanning, market strategy, final prioritization, or implementation design.
---

# 竞品功能对标 / Competitor Feature Benchmarking

## Contract baseline

- `skill_id`: `competitor-feature-benchmarking`
- `skill_family`: `planning-assessment-suite`
- `contract_version`: `planning-assessment-suite-v1.2.1`
- `schema`: `planning.competitor-feature-benchmarking.v4`
- `family_role`: `feature_benchmarking`
- `primary_artifact`: `competitor-feature-benchmark.csv`
- `composable_with`:
- `competitor-analysis`
- `requirement-value-assessment`
- `requirement-priority-assessment`

This skill is standalone. It may consume outputs from sibling planning, market-research, or requirement-definition skills when available, but it must not require a fixed upstream order.

## What this skill does

围绕一个已经明确的模块、页面、流程或功能集合做逐项对标。核心目标是产出可复用、可讨论、可落表的对比结果，而不是把局部模块对标扩展成完整市场策略结论。

Use this skill to create evidence-backed planning assessment artifacts with stable row contracts, metadata sidecars, route tokens, and handoff-ready identifiers.

## What this skill is not for

- broad competitor scan
- final market strategy
- roadmap ranking

## Operating rules

1. Define scope before assessment: target module, candidate requirement, competitor set, user segment, time window, and source boundary.
2. Mark each important conclusion as `confirmed`, `inferred`, or `unverified` when evidence status is required.
3. Keep route values semantic: use tokens such as `value_assessment` or `human_review`; do not write private workflow-node codes.
4. Do not encode prerequisites, stage gates, positional IDs, or hidden execution-order assumptions.
5. Preserve uncertainty as `open_questions` instead of silently filling gaps.
6. Never present an assessment recommendation as final roadmap, approval, staffing, or delivery commitment.

## Selected modes

- `module_benchmark`
- `workflow_benchmark`
- `page_benchmark`
- `rule_gap_analysis`
- `low_evidence_benchmark`

When unsure, select the closest low-evidence mode and explicitly list missing information.

## Required row contract

| Field | Level | Meaning |
| --- | --- | --- |
| `benchmark_id` | required | stable benchmark row id |
| `target_module` | required | module, page, workflow, or feature set |
| `comparison_dimension` | required | single comparable dimension |
| `our_current_state` | required | known internal state or unverified marker |
| `competitor_state` | required | competitor behavior for this dimension |
| `gap_type` | required | gap category |
| `gap_impact` | required | impact of the gap |
| `evidence_status` | required | confirmed, inferred, or unverified |
| `source_refs` | required | source anchors, URLs, doc ids, screenshots, or notes |
| `confidence` | required | confidence level |
| `recommended_route` | required | semantic next route token |
| `open_questions` | required | unresolved questions |
| `competitor_insight_ids` | recommended | competitor insight ids |
| `version_or_date` | recommended | version or date |
| `sample_name` | recommended | competitor or alternative sample |
| `benchmark_notes` | recommended | benchmark notes |
| `related_requirement_ids` | recommended | related requirement ids |

## Route tokens

- `value_assessment`
- `priority_assessment`
- `context_enrichment`
- `human_review`
- `monitor_only`

## Output shape

Produce `competitor-feature-benchmark.csv` by default. The user-facing explanation should cover:

- Benchmark overview
- Side-by-side table
- Gap summary
- Validation needs

## Validation workflow

Before treating an artifact as reusable:

```bash
python scripts/validate_artifact.py examples/<example>.csv
python scripts/validate_metadata.py examples/<example>.metadata.yaml
python scripts/validate_release_consistency.py .
```

For cross-skill handoff checks and node-neutrality guards, use:

```bash
python scripts/validate_handoff.py --auto examples --allow-unresolved-cross-refs
python scripts/check_node_neutrality.py examples/<example>.csv
python scripts/check_order_neutrality.py examples/<example>.csv
python scripts/self_test_ci_guards.py
```

## References

Load these only when needed:

- `references/shared-planning-assessment-contract.md` for suite-wide route, metadata, evidence, and quality rules.
- `references/planning-assessment-id-space.md` for artifact and row ID namespaces.
- `references/field-contract.yaml` for row-level fields.
- `references/metadata-schema.json` for metadata sidecar rules.
- `references/output-template.md` for output shape.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and corrections.
- `references/quality-checklist.md` for pre-handoff checks.
- `references/common-failure-modes.md` for review risks.

## B-family planning-assessment chain validation

To validate the full 6-skill planning-assessment chain:

```bash
python scripts/validate_planning_assessment_chain.py \
    --competitor    <007-dir>/examples/integration/search-competitor-analysis.metadata.yaml \
    --benchmarking  <008-dir>/examples/integration/search-feature-benchmarking.metadata.yaml \
    --value         <010-dir>/examples/integration/search-value-assessment.metadata.yaml \
    --cost          <011-dir>/examples/integration/search-cost-assessment.metadata.yaml \
    --risk          <012-dir>/examples/integration/search-risk-assessment.metadata.yaml \
    --priority      <009-dir>/examples/integration/search-priority-assessment.metadata.yaml
```

See `examples/integration/README.md` for the coherent search-feature bundle.

