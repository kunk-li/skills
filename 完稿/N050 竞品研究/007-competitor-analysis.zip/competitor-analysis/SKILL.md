---
name: competitor-analysis
description: Analyze competitors or internal alternatives by extracting comparable capabilities, rules, limitations, packaging differences, and workflow patterns for a defined business area or module. Use when the user provides notes, screenshots, public materials, demo observations, or experience records and needs a structured competitor comparison before feature benchmarking, value assessment, or priority discussion. Not for final roadmap decisions, market sizing, legal review, or implementation design.
---

# 竞品分析 / Competitor Analysis

## Contract baseline

- `skill_id`: `competitor-analysis`
- `skill_family`: `planning-assessment-suite`
- `contract_version`: `planning-assessment-suite-v1.2.1`
- `schema`: `planning.competitor-analysis.v4`
- `family_role`: `competitor_analysis`
- `primary_artifact`: `competitor-capability-scan.csv`
- `composable_with`:
- `competitor-feature-benchmarking`
- `requirement-value-assessment`
- `requirement-priority-assessment`
- `requirement-risk-assessment`
- `requirement-cost-estimation`

This skill is standalone. It may consume outputs from sibling planning, market-research, or requirement-definition skills when available, but it must not require a fixed upstream order.

## What this skill does

把一个或多个竞品或内部替代方案在指定业务问题、模块或场景上的做法整理成可比较的分析结果。重点是复原“它们怎么做、规则有什么差异、限制在哪里、这些差异意味着什么”，不直接替代我方路线决策。

Use this skill to create evidence-backed planning assessment artifacts with stable row contracts, metadata sidecars, route tokens, and handoff-ready identifiers.

## What this skill is not for

- final roadmap commitment
- formal market-size modeling
- implementation design

## Operating rules

1. Define scope before assessment: target module, candidate requirement, competitor set, user segment, time window, and source boundary.
2. Mark each important conclusion as `confirmed`, `inferred`, or `unverified` when evidence status is required.
3. Keep route values semantic: use tokens such as `feature_benchmarking` or `human_review`; do not write private workflow-node codes.
4. Do not encode prerequisites, stage gates, positional IDs, or hidden execution-order assumptions.
5. Preserve uncertainty as `open_questions` instead of silently filling gaps.
6. Never present an assessment recommendation as final roadmap, approval, staffing, or delivery commitment.

## Selected modes

- `market_scan`
- `alternative_comparison`
- `capability_pattern_scan`
- `packaging_rule_scan`
- `low_evidence_scan`

When unsure, select the closest low-evidence mode and explicitly list missing information.

## Required row contract

| Field | Level | Meaning |
| --- | --- | --- |
| `competitor_insight_id` | required | stable competitor insight row id |
| `analysis_scope` | required | scope being analyzed |
| `sample_name` | required | competitor or alternative sample |
| `dimension` | required | comparison dimension |
| `observation` | required | observed fact or inferred observation |
| `rule_or_limitation` | required | rule, constraint, plan, or limitation |
| `evidence_status` | required | confirmed, inferred, or unverified |
| `source_refs` | required | source anchors, URLs, doc ids, screenshots, or notes |
| `confidence` | required | confidence level |
| `recommended_route` | required | semantic next route token |
| `open_questions` | required | unresolved questions |
| `package_or_segment` | recommended | package or segment |
| `version_or_date` | recommended | version or date |
| `implication` | recommended | implication |
| `caveat` | recommended | caveat |
| `related_requirement_ids` | recommended | related requirement ids |
| `competitor_refs` | recommended | competitor refs |

## Route tokens

- `feature_benchmarking`
- `value_assessment`
- `priority_assessment`
- `risk_assessment`
- `cost_estimation`
- `human_review`
- `monitor_only`

## Output shape

Produce `competitor-capability-scan.csv` by default. The user-facing explanation should cover:

- Sample scope
- Comparison matrix
- Pattern summary
- Evidence gaps

## Validation workflow

Before treating an artifact as reusable:

```bash
python scripts/validate_artifact.py examples/<example>.csv
python scripts/validate_metadata.py examples/<example>.metadata.yaml
python scripts/validate_release_consistency.py .
```

For cross-skill handoff checks, use:

```bash
python scripts/validate_handoff.py --auto examples --allow-unresolved-cross-refs
```

## References

Load these only when needed:

- `references/shared-planning-assessment-contract.md` for suite-wide route, metadata, evidence, and quality rules.
- `references/planning-assessment-id-space.md` for artifact and row ID namespaces.
- `references/field-contract.yaml` for row-level fields.
- `references/metadata-schema.json` for metadata sidecar rules.
- `references/output-template.md` for output shape.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and corrections.
- `references/quality-checklist.md` for pre-handoff checks.
- `references/common-failure-modes.md` for review risks.

