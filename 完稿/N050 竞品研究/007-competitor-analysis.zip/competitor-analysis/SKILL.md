---
name: competitor-analysis
display_name: 竞品分析 / Competitor Analysis
description: Analyze competitors or internal alternatives by extracting capabilities, rules, limitations, and workflow patterns for a defined scope; broad structured comparison before benchmarking.
---

# 竞品分析 / Competitor Analysis

## Contract baseline

- `skill_id`: `competitor-analysis`
- `skill_family`: `planning-assessment-suite`
- `contract_version`: `planning-assessment-suite-v1.2.1`
- `schema`: `planning.competitor-analysis.v4`
- `family_role`: `competitor_analysis`
- `primary_artifact`: `competitor-capability-scan.csv`
- `composable_with`:
- `competitor-feature-benchmarking`
- `requirement-value-assessment`
- `requirement-priority-assessment`
- `requirement-risk-assessment`
- `requirement-cost-estimation`

This skill is standalone. It may consume outputs from sibling planning, market-research, or requirement-definition skills when available, but it must not require a fixed upstream order.

## What this skill does

把一个或多个竞品或内部替代方案在指定业务问题、模块或场景上的做法整理成可比较的分析结果。重点是复原“它们怎么做、规则有什么差异、限制在哪里、这些差异意味着什么”，不直接替代我方路线决策。

Use this skill to create evidence-backed planning assessment artifacts with stable row contracts, metadata sidecars, route tokens, and handoff-ready identifiers.

## What this skill is not for

- final roadmap commitment
- formal market-size modeling
- implementation design

## Operating rules

1. Define scope before assessment: target module, candidate requirement, competitor set, user segment, time window, and source boundary.
2. Mark each important conclusion as `confirmed`, `inferred`, or `unverified` when evidence status is required.
3. Keep route values semantic: use tokens such as `feature_benchmarking` or `human_review`; do not write private workflow-node codes.
4. Do not encode prerequisites, stage gates, positional IDs, or hidden execution-order assumptions.
5. Preserve uncertainty as `open_questions` instead of silently filling gaps.
6. Never present an assessment recommendation as final roadmap, approval, staffing, or delivery commitment.

## Selected modes

- `market_scan`
- `alternative_comparison`
- `capability_pattern_scan`
- `packaging_rule_scan`
- `low_evidence_scan`

When unsure, select the closest low-evidence mode and explicitly list missing information.

## Mode selection at a glance

| mode | signal in input | when to use |
| --- | --- | --- |
| `market_scan` | broad landscape, no specific scope | mapping the overall competitor landscape |
| `alternative_comparison` | specific alternatives to compare | side-by-side internal or direct alternatives |
| `capability_pattern_scan` | recurring patterns across competitors | extracting capability patterns and rules |
| `packaging_rule_scan` | pricing, tier, or packaging differences | comparing packaging or plan structures |
| `low_evidence_scan` | sparse or unverified sources only | low-confidence scan with explicit gaps |

For detailed selection logic, consult `references/selected-mode-decision-tree.md`.

## Required row contract

| Field | Level | Meaning |
| --- | --- | --- |
| `competitor_insight_id` | required | stable competitor insight row id |
| `analysis_scope` | required | scope being analyzed |
| `sample_name` | required | competitor or alternative sample |
| `dimension` | required | comparison dimension |
| `observation` | required | observed fact or inferred observation |
| `rule_or_limitation` | required | rule, constraint, plan, or limitation |
| `evidence_status` | required | confirmed, inferred, or unverified |
| `source_refs` | required | source anchors, URLs, doc ids, screenshots, or notes |
| `confidence` | required | confidence level |
| `recommended_route` | required | semantic next route token |
| `open_questions` | required | unresolved questions |
| `package_or_segment` | recommended | package or segment |
| `version_or_date` | recommended | version or date |
| `implication` | recommended | implication |
| `caveat` | recommended | caveat |
| `related_requirement_ids` | recommended | related requirement ids |
| `competitor_refs` | recommended | competitor refs |

## Route tokens

- `feature_benchmarking`
- `value_assessment`
- `priority_assessment`
- `risk_assessment`
- `cost_estimation`
- `human_review`
- `monitor_only`

## Skill-specific anti-patterns (AP-CA-*)

| id | anti-pattern | why harmful | correct pattern |
| --- | --- | --- |--- |
| AP-CA-01 | treating `inferred` observations as `confirmed` | planning decisions are made on unverified data | always mark `evidence_status` accurately; use `confirmed` only when source directly states the fact |
| AP-CA-02 | expanding a module scan into full market strategy | scope creep makes the artifact unactionable | keep `analysis_scope` narrow; create a separate artifact for broader strategy |
| AP-CA-03 | omitting `open_questions` when evidence is sparse | downstream teams cannot identify what needs validation | always populate `open_questions` with at least one entry when confidence is low |
| AP-CA-04 | fabricating competitor IDs or capabilities | misinformation enters planning artifacts | cite only verifiable sources; mark unverified with `evidence_status: unverified` |

## Output shape

Produce `competitor-capability-scan.csv` by default. The user-facing explanation should cover:

- Sample scope
- Comparison matrix
- Pattern summary
- Evidence gaps

## Validation workflow

Before treating an artifact as reusable:

```bash
python scripts/validate_artifact.py examples/<example>.csv
python scripts/validate_metadata.py examples/<example>.metadata.yaml
python scripts/validate_release_consistency.py .
```

For cross-skill handoff checks and node-neutrality guards, use:

```bash
python scripts/validate_handoff.py --auto examples --allow-unresolved-cross-refs
python scripts/check_node_neutrality.py examples/<example>.csv
python scripts/check_order_neutrality.py examples/<example>.csv
python scripts/self_test_ci_guards.py
```

## References

Load these only when needed:

- `references/shared-planning-assessment-contract.md` for suite-wide route, metadata, evidence, and quality rules.
- `references/planning-assessment-id-space.md` for artifact and row ID namespaces.
- `references/field-contract.yaml` for row-level fields.
- `references/metadata-schema.json` for metadata sidecar rules.
- `references/output-template.md` for output shape.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and corrections.
- `references/quality-checklist.md` for pre-handoff checks.
- `references/common-failure-modes.md` for review risks.


## B-family planning-assessment chain validation

To validate the full 6-skill planning-assessment chain:

```bash
python scripts/validate_planning_assessment_chain.py \
    --competitor    ../007-competitor-analysis/examples/integration/search-competitor-analysis.metadata.yaml \
    --benchmarking  ../008-competitor-feature-benchmarking/examples/integration/search-feature-benchmarking.metadata.yaml \
    --value         ../010-requirement-value-assessment/examples/integration/search-value-assessment.metadata.yaml \
    --cost          ../011-requirement-cost-estimation/examples/integration/search-cost-assessment.metadata.yaml \
    --risk          ../012-requirement-risk-assessment/examples/integration/search-risk-assessment.metadata.yaml \
    --priority      ../009-requirement-priority-assessment/examples/integration/search-priority-assessment.metadata.yaml
```

See `examples/integration/README.md` for the coherent search-feature bundle.

