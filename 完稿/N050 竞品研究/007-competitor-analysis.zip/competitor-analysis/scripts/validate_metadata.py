#!/usr/bin/env python3
import argparse, re, sys
from pathlib import Path
CONFIG={'artifact_id_re': '^CA-[a-z0-9_]+-\\d{6}$',
 'modes': ['market_scan',
           'alternative_comparison',
           'capability_pattern_scan',
           'packaging_rule_scan',
           'low_evidence_scan'],
 'name': 'competitor-analysis',
 'routes': ['feature_benchmarking', 'value_assessment', 'priority_assessment', 'human_review', 'monitor_only'],
 'schema': 'planning.competitor-analysis.v4'}
CONTRACT_VERSION='planning-assessment-suite-v1.2.1'
PRIVATE_NODE_RE=re.compile(r"\b[Nn]\d{3}\b")
PLACEHOLDERS={'host-workflow','tbd','todo','待确认','<host-workflow>','<由 host workflow 注入>','example'}
REQUIRED=['artifact_id','skill_id','contract_version','schema','workflow_node','selected_mode','readiness','confidence','source_artifacts','evidence_refs','downstream_routes']
ALLOWED=set(REQUIRED)|{'cross_artifact_refs','notes'}
CONF={'high','medium','low','needs_human_review'}
READY={'draft','review_ready','handoff_ready','needs_human_review'}

def parse_yaml_like(path):
    data = {}
    cur = None
    for raw in Path(path).read_text(encoding='utf-8').splitlines():
        line = raw.rstrip()
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        if line.startswith('  - ') and cur:
            data.setdefault(cur, []).append(line[4:].strip().strip("\"'"))
        elif ':' in line and not line.startswith(' '):
            k, v = line.split(':', 1)
            k = k.strip()
            v = v.strip().strip("\"'")
            if v == '':
                data[k] = []
                cur = k
            else:
                data[k] = v
                cur = None
    return data

def has_placeholder(v):
    return str(v).strip().lower() in PLACEHOLDERS

def validate(path):
    data=parse_yaml_like(path); errors=[]
    for k in REQUIRED:
        if k not in data or data[k] in ('',[]): errors.append(f'missing required metadata field {k}')
    for k in data:
        if k not in ALLOWED: errors.append(f'unknown metadata field {k}')
    if data.get('skill_id') != CONFIG['name']: errors.append(f"skill_id must be {CONFIG['name']}")
    if data.get('contract_version') != CONTRACT_VERSION: errors.append(f'contract_version must be {CONTRACT_VERSION}')
    if data.get('schema') != CONFIG['schema']: errors.append(f"schema must be {CONFIG['schema']}")
    aid=data.get('artifact_id','')
    if aid and not re.match(CONFIG['artifact_id_re'], aid, re.IGNORECASE): errors.append(f'artifact_id {aid!r} does not match expected pattern')
    if data.get('selected_mode') and data.get('selected_mode') not in CONFIG['modes']: errors.append('selected_mode not listed in decision tree modes')
    if data.get('confidence') and data.get('confidence') not in CONF: errors.append('confidence must be high/medium/low/needs_human_review')
    if data.get('readiness') and data.get('readiness') not in READY: errors.append('readiness has unsupported value')
    if has_placeholder(data.get('workflow_node','')): errors.append('workflow_node is a placeholder')
    for key,val in data.items():
        vals=val if isinstance(val,list) else [val]
        for item in vals:
            if PRIVATE_NODE_RE.search(str(item)): errors.append(f'private workflow-node code found in metadata field {key}')
    for route in data.get('downstream_routes',[]) if isinstance(data.get('downstream_routes'),list) else []:
        if route not in CONFIG['routes']: errors.append(f'downstream_route {route!r} is not allowed for this skill')
    return errors

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('metadata'); args=ap.parse_args()
    errors=validate(Path(args.metadata))
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: metadata valid for {CONFIG['name']} ({args.metadata})")
    return 0
if __name__=='__main__': sys.exit(main())
