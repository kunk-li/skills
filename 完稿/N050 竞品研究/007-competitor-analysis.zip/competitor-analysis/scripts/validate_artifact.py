#!/usr/bin/env python3

import argparse, csv, json, re, sys
from pathlib import Path

CONFIG = {'cn': '竞品分析',
 'composable': ['competitor-feature-benchmarking', 'requirement-value-assessment', 'requirement-priority-assessment', 'requirement-risk-assessment', 'requirement-cost-estimation'],
 'display': 'Competitor Analysis',
 'enums': {'confidence': ['high', 'medium', 'low', 'needs_human_review'],
           'evidence_status': ['confirmed', 'inferred', 'unverified'],
           'recommended_route': ['feature_benchmarking',
                                 'value_assessment',
                                 'priority_assessment',
                                 'risk_assessment',
                                 'cost_estimation',
                                 'human_review',
                                 'monitor_only']},
 'family_role': 'competitor_analysis',
 'id_field': 'competitor_insight_id',
 'id_re': '^CA-[a-z0-9_]+-\\d{3,}$',
 'modes': ['market_scan',
           'alternative_comparison',
           'capability_pattern_scan',
           'packaging_rule_scan',
           'low_evidence_scan'],
 'not_for': ['final roadmap commitment', 'formal market-size modeling', 'implementation design'],
 'primary': 'competitor-capability-scan.csv',
 'recommended': ['package_or_segment',
                 'version_or_date',
                 'implication',
                 'caveat',
                 'related_requirement_ids',
                 'competitor_refs'],
 'required': ['competitor_insight_id',
              'analysis_scope',
              'sample_name',
              'dimension',
              'observation',
              'rule_or_limitation',
              'evidence_status',
              'source_refs',
              'confidence',
              'recommended_route',
              'open_questions'],
 'routes': ['feature_benchmarking', 'value_assessment', 'priority_assessment', 'risk_assessment', 'cost_estimation', 'human_review', 'monitor_only'],
 'schema': 'planning.competitor-analysis.v4'}
CONTRACT_VERSION = 'planning-assessment-suite-v1.2.1'
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
SECRET_RE = re.compile(r"\b(?:sk|pk|api|secret)[-_][A-Za-z0-9]{12,}\b", re.IGNORECASE)

def read_rows(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def nonempty(v):
    return v is not None and str(v).strip() != ''

def validate(path, strict=False):
    rows = read_rows(path)
    errors=[]; warnings=[]; seen=set()
    if not rows:
        errors.append('artifact has no rows')
        return errors,warnings
    headers = set(rows[0].keys())
    missing_headers = [f for f in CONFIG['required'] if f not in headers]
    if missing_headers:
        errors.append(f'header missing required fields {missing_headers}')
    for idx,row in enumerate(rows,1):
        missing=[f for f in CONFIG['required'] if not nonempty(row.get(f))]
        if missing:
            errors.append(f'row {idx}: missing required fields {missing}')
        rid=str(row.get(CONFIG['id_field'],'')).strip()
        if rid:
            if not re.match(CONFIG['id_re'], rid, re.IGNORECASE):
                errors.append(f"row {idx}: {CONFIG['id_field']} {rid!r} does not match expected pattern {CONFIG['id_re']}")
            if rid in seen:
                errors.append(f"row {idx}: duplicate {CONFIG['id_field']} {rid!r}")
            seen.add(rid)
        for field, allowed in CONFIG['enums'].items():
            value=str(row.get(field,'')).strip()
            if value and value not in allowed:
                errors.append(f"row {idx}: {field} must be one of {allowed}, got {value!r}")
        for field,value in row.items():
            text=str(value or '')
            if PRIVATE_NODE_RE.search(text):
                errors.append(f'row {idx}: private workflow-node code found in {field}')
            if EMAIL_RE.search(text):
                warnings.append(f'row {idx}: possible email in {field}')
            if SECRET_RE.search(text):
                warnings.append(f'row {idx}: possible secret token in {field}')
        conf=str(row.get('confidence','')).strip()
        route=str(row.get('recommended_route','')).strip()
        if conf == 'low' and route not in ('human_review','monitor_only'):
            warnings.append(f'row {idx}: low confidence row should normally route to human_review or monitor_only')
    if strict and warnings:
        errors += [f'strict warning: {w}' for w in warnings]
    return errors,warnings

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('artifact', nargs='?')
    ap.add_argument('--strict', action='store_true')
    ap.add_argument('--summary', action='store_true')
    args=ap.parse_args()
    if args.summary:
        print(json.dumps(CONFIG | {'contract_version': CONTRACT_VERSION}, ensure_ascii=False, indent=2))
        return 0
    if not args.artifact:
        print('ERROR: artifact path required unless --summary is used', file=sys.stderr); return 2
    errors,warnings=validate(Path(args.artifact), args.strict)
    for w in warnings: print('WARN:', w)
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: {CONFIG['display']} artifact valid ({args.artifact})")
    return 0
if __name__=='__main__': sys.exit(main())
