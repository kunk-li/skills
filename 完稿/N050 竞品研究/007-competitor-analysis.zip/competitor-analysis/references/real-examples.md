# Real Examples / 真实示例参考

These examples illustrate correctly formed competitor scan rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Market scan — not observed vs. absent

**Input**: A reviewer scrolls through Competitor X's pricing page and does not see a bulk-export option.

**Correct pattern**:
```
competitor_id: COMP-X-001
competitor: Competitor X
feature_area: export
observed_capability: not_observed
evidence_status: inferred
confidence: low
source_refs: SRC-screenshot-pricing-001
notes: Bulk export was not visible on the pricing page screenshot reviewed 2026-05. Absence of evidence is not evidence of absence — confirm via trial or API docs.
```

**Anti-pattern to avoid (AP-CA-03)**: Writing `observed_capability: absent` or `not_available` — this overstates certainty and may mislead product decisions.

---

## Example 2: Market scan — edition caveats required

**Input**: Competitor Y's Enterprise plan includes SSO; Starter plan does not.

**Correct pattern**:
```
competitor_id: COMP-Y-001
competitor: Competitor Y
feature_area: authentication
observed_capability: SSO available on Enterprise plan only
edition_caveat: Starter and Growth plans do not include SSO per public pricing page as of 2026-05
evidence_status: confirmed
confidence: high
source_refs: SRC-competitorY-pricing-202605
```

**Anti-pattern to avoid (AP-CA-02)**: Writing `SSO: available` without noting it is edition-gated — this creates a misleading parity comparison.

---

## Example 3: Positioning comparison — scope and evidence boundary

**Input**: Competitor Z is described by a sales blog post as "the leader in AI-powered invoice automation."

**Correct pattern**:
```
competitor_id: COMP-Z-001
competitor: Competitor Z
positioning_claim: AI-powered invoice automation leader
source_type: self_claimed_marketing
evidence_status: unverified
confidence: low
notes: Self-reported positioning claim from competitor's sales blog. Not independently verified. Do not treat as market-research evidence without third-party confirmation. (AP-CA-01 + AP-09)
```
