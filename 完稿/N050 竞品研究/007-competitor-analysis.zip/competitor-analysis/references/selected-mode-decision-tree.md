# Selected-mode decision tree

## `market_scan`
- Use when the input most closely matches `market scan`.
- Output schema: `planning.competitor-analysis.v4`.
- Primary artifact: `competitor-capability-scan.csv`.

## `alternative_comparison`
- Use when the input most closely matches `alternative comparison`.
- Output schema: `planning.competitor-analysis.v4`.
- Primary artifact: `competitor-capability-scan.csv`.

## `capability_pattern_scan`
- Use when the input most closely matches `capability pattern scan`.
- Output schema: `planning.competitor-analysis.v4`.
- Primary artifact: `competitor-capability-scan.csv`.

## `packaging_rule_scan`
- Use when the input most closely matches `packaging rule scan`.
- Output schema: `planning.competitor-analysis.v4`.
- Primary artifact: `competitor-capability-scan.csv`.

## `low_evidence_scan`
- Use when the input most closely matches `low evidence scan`.
- Output schema: `planning.competitor-analysis.v4`.
- Primary artifact: `competitor-capability-scan.csv`.
