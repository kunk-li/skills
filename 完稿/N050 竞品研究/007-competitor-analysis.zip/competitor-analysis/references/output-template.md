# Output template for Competitor Analysis

Primary artifact: `competitor-capability-scan.csv`

Required CSV header:

```csv
competitor_insight_id,analysis_scope,sample_name,dimension,observation,rule_or_limitation,evidence_status,source_refs,confidence,recommended_route,open_questions,package_or_segment,version_or_date,implication,caveat,related_requirement_ids,competitor_refs
```

Recommended human-readable explanation:

## 1. Sample scope

- ...

## 2. Comparison matrix

- ...

## 3. Pattern summary

- ...

## 4. Evidence gaps

- ...

