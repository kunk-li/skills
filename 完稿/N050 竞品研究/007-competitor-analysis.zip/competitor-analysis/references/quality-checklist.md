# Quality checklist for Competitor Analysis

Start with the shared checklist in `shared-planning-assessment-contract.md#common-quality-checklist`, then apply these skill-specific checks:

- Treating one screenshot as a full-platform conclusion
- Mixing pricing/package constraints with feature capability
- Writing not observed as absent
- Comparing different market editions without a caveat
- Turning competitor behavior directly into our roadmap decision

Before handoff, run `python scripts/validate_release_consistency.py .`.
