# Scoring Rubric

## Excellent
- meeting-ready table is clear and deduplicated
- source kind and pending state add routing value
- deferred roadmap and ownership views are useful

## Good
- strong pending table with clear timing and owners
- decision items stand out

## Needs Work
- mixed questions, typos, and decisions in one pile
- duplicates remain unresolved

## Poor
- generic summary only
- no owner, no timing, no decision structure

## Numeric formula

### Pending score

pending 不是"差错指数",而是"就绪度指数":

  pending_score = 100 - (
    blocking_p0_pending × 15 +
    blocking_p1_pending × 5 +
    raised_without_owner × 3 +
    clarifying_over_7_days × 2 +
    deferred_without_version × 5
  )
  clip to [0, 100]

特殊规则:
- `decided` / `closed` / `answered` 状态的 item 不计入扣分(已解决)
- `rejected` 状态的 item 不计入扣分(已决策不做)
- `deferred` 状态的 item:若有 `deferred_to_version` → 不扣分;无则扣分

### Severity inference(从 pending 特征反推)

| 特征组合 | 推导 severity |
|---|---|
| `source_kind = decision_pending` + `blocking = true` | blocker |
| `source_kind = gap_detected` + `blocking = true` | major |
| `source_kind = cross_check` + 跨 ≥ 2 个 req | major |
| `source_kind = explicit_todo` + 无 owner | minor |
| `source_kind = external_signal` | note |

### 重复合并评分

若 `duplicate_of` 存在链接:合并为 1 个 item 计分,不累加。
若 `merge_duplicates` mode 下检测到 ≥ 3 个重复,降低 confidence 一级。

### 阻塞传播
pending item 若被 025/026/027/028 通过 `related_issue_ids` 引用时:
- 原 pending_score 扣分保持
- 但该 item 在 030 rollup 时的责任权重从 0.10 → 提升至 0.15(上游阻塞放大)
