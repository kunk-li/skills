# Pending State Machine

## States
- raised
- clarifying
- answered
- decided
- implemented
- verified
- closed
- deferred
- rejected

## Typical transitions
- raised -> clarifying -> answered -> decided
- decided -> implemented -> verified -> closed
- raised or clarifying -> deferred
- raised or clarifying -> rejected
