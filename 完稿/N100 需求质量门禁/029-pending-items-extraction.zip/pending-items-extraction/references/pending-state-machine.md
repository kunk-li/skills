# Pending State Machine

## States
- raised
- clarifying
- answered
- decided
- implemented
- verified
- closed
- deferred
- rejected

## Typical transitions
- raised -> clarifying -> answered -> decided
- decided -> implemented -> verified -> closed
- raised or clarifying -> deferred
- raised or clarifying -> rejected

---

## Pending Item 分类决策树 / Classification Decision Tree

```
Q1: 是否有明确的文字标注（TODO/TBD/待定/待确认）？
    YES → source_kind = explicit_todo
    NO  → Q2

Q2: 是否是两条需求描述相互矛盾、需要决策解决？
    YES → source_kind = decision_pending（证据不足时）
          或升级为 027 conflict（证据充分时）
    NO  → Q3

Q3: 是否因分析跨多个需求条目发现的隐含缺口？
    YES → source_kind = cross_check
    NO  → Q4

Q4: 是否来自线上信号、用户反馈、事故复盘的外部输入？
    YES → source_kind = external_signal
    NO  → source_kind = gap_detected（分析发现的隐含缺口）
```

### 状态转移决策规则

```
received → triaged:
  有 source_kind 且有 owner 赋值

triaged → clarifying:
  owner 开始向相关方确认细节

triaged → decided:
  owner 直接做出决定无需外部确认

clarifying → decided:
  确认完成，owner 做出 ACCEPTED/REJECTED/DEFERRED 决策

decided → closed:
  若 ACCEPTED：相关 PRD 章节已更新
  若 REJECTED：决策原因已记录
  若 DEFERRED：已有 deferred_to_version

任何状态 → escalated:
  超过 SLA（见 035/lifecycle-sla.md）或争议无法在 owner 层解决

escalated → decided:
  升级处理后达成决策（5 个工作日内）
```

### 边界 Case 对照表

| 场景 | source_kind | blocking | 处理方式 |
|---|---|---|---|
| PRD 里有"TODO: 确认审批规则" | explicit_todo | true | 直接分类，不需要进一步分析 |
| 规则 A 说"实时同步"，规则 B 说"异步处理" | decision_pending | true | 证据不足升级前先挂 pending |
| 分析发现支付超时无补偿 | gap_detected | true | 与 025/D5 关联，cross-skill |
| 用户反馈说"搜索太慢" | external_signal | false | 不直接作为需求缺口，需 PM 决策 |
| 问题已有 deferred_to_version | deferred | false | 不计入扣分（有版本号）|
