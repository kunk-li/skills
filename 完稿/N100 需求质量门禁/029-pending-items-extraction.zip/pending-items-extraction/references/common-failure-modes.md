# Common Failure Modes

1. Mixing confirmed facts with unresolved questions.
2. Extracting the same pending item many times in different wording.
3. Turning severe confirmed conflicts or risks into vague meeting notes.
4. Missing the source kind, which makes routing harder.
5. Producing a pending list without state, timing, or owner guidance.
