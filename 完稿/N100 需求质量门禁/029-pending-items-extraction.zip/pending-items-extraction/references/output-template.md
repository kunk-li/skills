# Output Template

When the result will be consumed by workflow v2, emit the machine-readable CSV artifact first and then the narrative summary.

## 0. artifact contract header
- `artifact_type`: `n100.pending-items`
- `schema_version`: `2.1.1`
- `producer_skill`: `pending-items-extraction`
- `consumer_nodes`: `N100`, `N110`, `N180`, `N370`
- `workflow_alias`: `待确认项清单.csv`
- `produced_event_name`: `produced.n100.pending-items`
- `issue_namespace`: default `N100`
- `parse_cache_ref`: nullable
- `decision_ref`: nullable
- `re_gate_session_id`: nullable

## 1. machine-readable artifact
Produce or simulate a CSV named `待确认项清单.csv` with these columns in this exact order:
| issue_id | issue_category | issue_subtype | source_kind | pending_state | severity | severity_matrix.overall | artifact | object | question | why_unresolved | impact | owner_candidate | target_timing | needs_decision | blocking | resolution_id | deferred_to_version | parse_cache_ref | issue_namespace | decision_ref | re_gate_session_id |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## 2. document purpose and input inventory
- explain that this is a pending-item extraction report
- list inputs and active modes

## 3. pending summary
- counts by `source_kind`
- counts by `pending_state`
- counts by severity

## 4. meeting-ready pending table
| issue_id | source_kind | pending_state | object | question | impact | owner_candidate | target_timing |
|---|---|---|---|---|---|---|---|

## 5. decision-focused view
- only items with `needs_decision=yes`

## 6. deferred roadmap view
| version or bucket | items | reason |
|---|---|---|

## 7. responsibility matrix
| owner_candidate | open items | overdue items | next action |
|---|---:|---:|---|

## 8. next-step recommendation
- what to clarify before review
- what to decide during review
- what may wait safely
