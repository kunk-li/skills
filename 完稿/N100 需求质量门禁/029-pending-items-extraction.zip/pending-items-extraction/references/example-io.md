# Example IO

## Example: 商品描述页迁移的多类 pending items

### Input (excerpt)
> PRD § 4:商品详情页重构
> - 需要支持富文本 [TODO: 允许哪些 HTML 标签?白名单待定]  
> - 现有 500 万 SKU 数据迁移方案 TBD
> - Review 意见 1(PM-Li):"上架审核流程是否也需要变更?待与运营团队确认"
> - Review 意见 2(PM-Zhang):"迁移期间旧页面是否保留?"
> - FIXME:性能指标目标值未给出

### Output: 待确认项清单.csv

```
issue_id,issue_category,source_kind,pending_state,severity,severity_matrix.overall,artifact,object,question,why_unresolved,impact,owner_candidate,target_timing,needs_decision,blocking,resolution_id,deferred_to_version
CHECK-PEND-PRD-001,pending,explicit_todo,raised,major,major,PRD.md §4,富文本白名单,允许哪些 HTML 标签?,PRD 已标注 TODO 未定义,XSS 风险 + 前端解析行为不明,security_lead + pm_zhang,pre-review,true,false,,
CHECK-PEND-PRD-002,pending,explicit_todo,raised,blocker,blocker,PRD.md §4,500 万 SKU 迁移方案,迁移策略是什么?,TBD 标记,方案不定无法估时,tech_lead + dba,pre-review,true,true,,
CHECK-PEND-PRD-003,pending,decision_pending,clarifying,major,major,PRD.md §4 + Review comment,上架审核流程变更,审核流程是否需要同步变更?,PM-Li 已提出但待运营确认,影响 REQ-REVIEW-002 范围,pm_li + ops_director,in-review,true,false,,
CHECK-PEND-PRD-004,pending,decision_pending,raised,minor,minor,Review comment,迁移期间新旧共存,迁移中旧页面保留吗?,PM-Zhang 提出无人回答,用户体验一致性待定,pm_zhang,in-review,true,false,,
CHECK-PEND-PRD-005,pending,gap_detected,raised,major,major,PRD.md §4,性能指标,性能目标值是多少?,FIXME 标记无具体数字,无法设计压测方案,pm_zhang + tech_lead,pre-review,true,false,,
CHECK-PEND-PRD-006,pending,cross_check,raised,note,note,PRD.md §4 + 025 finding CHECK-COMP-DESC-003,富文本白名单,详见 025 completeness finding,此处与 025 完整性 D6 gap 同源,以 025 为主,不独立计提 severity,security_lead,pre-review,false,false,CHECK-COMP-DESC-003,

```

### Output: 摘要

```
## 待确认项提取结论

- **pending_score**: 68
- **total items**: 6(其中 1 条通过 cross_check 与 025 联动)
- **urgent (pre-review)**: 3 条
- **can wait (in-review)**: 2 条

### 按状态分布

| pending_state | count | 说明 |
|---|---:|---|
| raised | 4 | 未开始澄清 |
| clarifying | 1 | 已提出但等待 |
| answered | 0 | 已答复未决议 |
| decided | 0 | — |
| deferred | 0 | — |

### 按 source_kind 分布

| source_kind | count |
|---|---:|
| explicit_todo | 2 |
| decision_pending | 2 |
| gap_detected | 1 |
| cross_check | 1 |

### 下游路由建议

- CHECK-PEND-PRD-002 (blocker) → N180 前置决议任务槽
- CHECK-PEND-PRD-001, 005 (major) → N180 本迭代决议
- CHECK-PEND-PRD-003, 004 → 下次评审会话
- CHECK-PEND-PRD-006 → 关联 025 finding,030 rollup 时不重复计提
```
