# Orchestration

## Standalone path
1. Read the baseline and explicit review notes.
2. Extract pending items and merge duplicates.
3. Produce a meeting-ready decision log.

## Combined path
1. Use this skill when the team needs a clean unresolved-item backlog.
2. Combine with other review skills when pending items should influence gate or handover decisions.
3. Preserve source kind, state, and duplicate linkage for 030 or downstream trackers.
4. Send `decision_pending` + `blocking` items to N180 as pre-decision planning slots:
   - blocker unresolved items must be decided before scheduling starts
   - items with `deferred_to_version` move into the later-version roadmap
   - unresolved but non-blocking items stay visible as tracked planning risks
