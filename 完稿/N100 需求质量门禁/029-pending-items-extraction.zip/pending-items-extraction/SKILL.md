---
name: pending-items-extraction
description: Extract pending questions, unresolved decisions, deferred items, and ownership gaps from a requirement baseline into a meeting-ready decision log.
---
# pending-items-extraction

## Role
Turn unresolved material into a decision-ready backlog.
This skill must work on any baseline that contains explicit TODOs, implied gaps, pending approvals, or deferred scope.

## N090 intake / N090 上游接收

029 的**主要分析对象**是 PRD-15（待确认项）+ GAP 清单（023）+ 评审问题清单（024）。启动前检查 N090 就绪状态：

```yaml
n090_intake:
  prd_version:              # 从 PRD artifact header 读取
  prd_sections_available:   # 至少需要 PRD-15；PRD-14 有助于识别 blocking pending
  gap_list_available: true | false   # 影响分析深度；缺失时降为 Partial Mode
  gap_count:                         # 023 输出的 GAP 总数
  q_list_available: true | false     # 024 的 Q-XXX 清单
  high_urgency_questions:            # question_urgency_score ≥ 12 的 Q-XXX
    - q_id:
      related_prd:
      urgency_score:
```

若 PRD-15 缺失 → 在 `confidence` 中标注 `partial_mode: true`，并说明哪些来源受限。

## Standalone and combined use

### Standalone
Produce a meeting-ready issue log that can be used without any other skill.
It must include source, state, owner suggestion, timing, and duplicate merging where possible.

**Standalone SLA guidance（无上游工作流上下文时）：**
- `blocking = true` 且 `owner_candidate = null` 的条目必须标注 `raised_without_owner: true`，并在输出第一行显示。
- `clarifying` 状态无更新超过 7 天的条目标注 `stale_clarifying: true`。
- `source_kind = decision_pending` 且无 `target_timing` 的条目默认 `target_timing = pre-review`。

### Combined
Expose pending-item structure cleanly so 030 or other workflows can turn it into gate conditions, handover gaps, or roadmap inputs.
When combined:
- 继承上游 `re_gate_session_id`，产出 `closed_since_last / still_open / new_in_this_scan` delta 视图。
- 在 `n090_intake` 中标注 GAP 清单就绪状态；当 `gap_list_available = true` 时，每个来自 023 的 pending item 必须携带 `source_gap_id`。
- 输出中的 `source_gap_id` 字段与 cross-node-bridge-contract.md §2.1 格式保持一致。

## Shared interoperability contract
When this skill is used with other requirement-review skills, keep the native specialty fields but also preserve these shared fields whenever the evidence supports them:
- `issue_id`
- `issue_category`
- `issue_subtype`
- `severity` = blocker / major / minor / note
- `severity_matrix.overall` plus any supported sub-dimensions
- `artifact`
- `object`
- `evidence`
- `finding`
- `impact`
- `owner_candidate`
- `needs_decision`
- `blocking`
- `related_issue_ids` when there is an obvious upstream or downstream link

Do not drop the skill-specific fields just to fit the shared schema. Keep both when useful.

## Light composition runtime contract
When this skill is run as part of a composed N100 review, carry these lightweight runtime fields whenever available:
- `parse_cache_ref`
- `issue_namespace` (default `N100`)
- `decision_ref`
- `re_gate_session_id`
- `produced_event_name`

Keep them nullable when the upstream workflow does not provide them. Do not invent values.

## Shared node-level references
When these bundled references are present, consult them before inventing local behavior:
- `_shared/parse-cache-contract.md` for cache lifecycle, hit/miss handling, and integrity fallback
- `_shared/cross-skill-disambiguation.md` for ownership boundaries, duplicate prevention, and `related_issue_ids` linkage

## Workflow v2 input aliases
Prefer the workflow names directly when they exist:
- `PRD.md`（主输入，重点消费 PRD-15 和 PRD-14）
- `需求结构树.md`
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`

Also accept TODO-marked drafts, reviewer notes, or upstream check outputs as additional evidence.

## Inputs / 允许输入
Preferred package when available:
- `hub_requirement_breakdown.md`
- `hub_business_rules.md`
- `hub_state_transition_mapping.md`
- `hub_permission_matrix.md`

Fallback inputs may be any baseline plus reviewer notes, TODO-marked drafts, or structured analysis outputs.

## Source kinds
Run the Q1–Q4 classification tree in `references/pending-state-machine.md` before assigning. Summary:

| source_kind | when to use |
|---|---|
| `explicit_todo` | visible marker: TODO / TBD / 待定 / 待确认 |
| `decision_pending` | two statements conflict; evidence insufficient for 027 confirmed conflict |
| `cross_check` | gap discovered by cross-referencing ≥2 requirement items |
| `external_signal` | user feedback / incident postmortem / NPS — needs PM decision before becoming a requirement |
| `gap_detected` | implied gap found during analysis, no visible marker |

If evidence is strong enough to confirm a `decision_pending` as a logical conflict, escalate to 027 instead of keeping it here.

## Pending states
Full transitions in `references/pending-state-machine.md`:
- `raised` → `clarifying` → `answered` → `decided` → `implemented` → `verified` → `closed`
- `raised` or `clarifying` → `deferred` (requires `deferred_to_version`)
- `raised` or `clarifying` → `rejected` (requires reason recorded)
- Any state → `escalated` (SLA breach or owner-level dispute)

`decided`, `closed`, `answered`, `rejected` items do not count toward pending_score deductions.

## source_gap_id linkage / GAP 溯源字段

当 pending item 来自或对应 023 的 GAP-XXX 时，必须填写：

```yaml
- issue_id: N100-029-003
  issue_category: pending
  source_kind: gap_detected
  source_gap_id: GAP-006         # 与 023 gap_list 中的 GAP-006 对应
  source_gap_skill: "023"
  new_gap: false                 # false = 已在 023 中记录；true = 029 新发现
  gap_type_match: missing_error_handling
```

当 `new_gap: true` 且 `severity ∈ {blocker, major}` 时，须在输出末尾的 `remediation_hints` 中写明：
```
"Suggest creating GAP-XXX in 023 for issue N100-029-{n}: {finding summary}"
```
030 将把这条记录纳入 `cross_node_trace.remediation_plan`。

## Downstream contribution to 031 open_questions[]

029 输出中 `blocking = true` 的条目是 031 `open_questions[]` 的 P0 来源（详见 handoff-to-n110.md §4.1）。
为确保 031 可以无损继承，每个 `blocking = true` 条目必须具备：
- `issue_id`（格式：`N100-029-{n}`）
- `owner_candidate`
- `finding`（简明、一句话可读）
- `impact`

031 继承后的格式示例（仅供参考，无需 029 产出）：
```yaml
- question_id: Q-031-INH-001
  source_type: n100_issue
  source_id: N100-029-003
  source_skill: "029"
  blocking: true
  resolution_owner: PM
```

## Duplicate merging rules
Merging is required before output. Apply in this order:
1. 完全文本匹配（规范化后）→ 无条件合并，保留最早的 `issue_id`。
2. 语义匹配（相同 object + 相同问题意图，措辞不同）→ 保守合并；标注 `merge_confidence = medium`，两条原文放入 `evidence`。
3. 同一 object 但决策面不同 → 不合并；用 `related_issue_ids` 链接。
4. `merge_duplicates` mode 下：若发现 ≥3 个语义相近条目，`merge_confidence` 降一级并在输出中说明。
5. 合并后在 `duplicate_of` 中指向保留条目的 `issue_id`。

## Decision log transformation
When the user asks for "decision log" or "决策清单"：
1. 仅包含 `needs_decision = yes` 的条目。
2. 排序：`target_timing`（pre-review 优先）→ `severity`（blocker 优先）。
3. 补充 `decision_due`：
   - `pre-review` → ASAP / 下次评审会前
   - `in-review` → 评审会中
   - `post-review` → 评审后一个 sprint 内
4. 每条加 `decision_format` 提示：ACCEPTED / REJECTED / DEFERRED。
5. 独立输出 "Decision Log" 表，置于主 pending 表之后。

## Workflow v2 artifact contract
Declare this contract explicitly in the output header when the result is intended for workflow consumption:
- `artifact_type`: `n100.pending-items`
- `schema_version`: `2.1.1`
- `producer_skill`: `pending-items-extraction`
- `consumer_nodes`: `N100`, `N110`, `N180`, `N370`
- `workflow_alias`: `待确认项清单.csv`
- `produced_event_name`: `produced.n100.pending-items`
- `canonical_fields`: `issue_id`, `issue_category`, `issue_subtype`, `source_kind`, `pending_state`, `severity`, `severity_matrix.overall`, `artifact`, `object`, `question`, `why_unresolved`, `impact`, `owner_candidate`, `target_timing`, `needs_decision`, `blocking`, `resolution_id`, `deferred_to_version`, `source_gap_id`, `source_gap_skill`, `new_gap`, `duplicate_of`, `merge_confidence`, `decision_due`, `raised_without_owner`, `stale_clarifying`, `parse_cache_ref`, `issue_namespace`, `decision_ref`, `re_gate_session_id`

## Output contract
Default to a dual output unless the user explicitly asks for only one representation:
1. a machine-readable CSV-first artifact named `待确认项清单.csv`
2. a concise Markdown summary following `references/output-template.md`

Each CSV row must include all `canonical_fields` above.
When evidence supports it, also include:
- `state_history[]`
- `roadmap_bucket`

If the user only wants prose, keep the rows directly convertible into the same CSV columns.

## Modes
- `format_detection`: detect TODO, FIXME, TBD, open question markers automatically
- `merge_duplicates`: merge semantically duplicated pending items per the merging rules above
- `decision_log`: produce filtered, sorted decision-log view for `needs_decision = yes` items
- `export_mode`: shape output for Jira, GitLab issues, or another tracker when requested
- `re_gate_mode`: compare against a prior issue set; mark `closed_since_last / still_open / new_in_this_scan`

## Workflow
1. Check `n090_intake`；若 PRD-15 / gap_list 缺失，降为 Partial Mode 并标注。
2. Collect explicit and implicit pending items from PRD-15, GAP 清单, Q 清单。
3. Run Q1–Q4 tree（`references/pending-state-machine.md`）to assign `source_kind`。
4. Fill `source_gap_id` for items traceable to 023 GAP-XXX；mark `new_gap: true` for genuinely new finds。
5. Merge duplicates per the merging rules。
6. Separate true decision items from wording cleanup。
7. Assign `pending_state`, `owner_candidate`, `target_timing`, `decision_due`；flag `raised_without_owner` and `stale_clarifying`。
8. Emit workflow CSV rows first when workflow consumption is expected。
9. Output Decision Log view for all `needs_decision = yes` items。
10. Output deferred roadmap view when version deferral appears。
11. Output `remediation_hints` for all `new_gap: true` + blocker/major items。

## Boundary rules
- Do not turn decided facts into pending items.
- Do not hide confirmed conflicts or vulnerabilities here — route to 027 or 028.
- Merge before emit; never duplicate the same decision in multiple wordings.
- Do not emit `external_signal` items as requirement gaps directly; flag as needing PM decision.
- Do not carry blocking open_questions to 031 without `owner_candidate` and `finding`.

## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认，并按 `references/scoring-rubric.md` 计算 pending_score：
- `n090_intake` 已填写，Partial Mode 已标注（如适用）
- 所有 `blocking = true` + `owner_candidate = null` 条目已标注 `raised_without_owner: true`
- `stale_clarifying` 检查已执行（clarifying > 7 天）
- `source_gap_id` 已填写（来自 023 的条目）
- `new_gap: true` 条目已在 `remediation_hints` 中登记
- Decision Log 视图已输出（仅 `needs_decision = yes`）
- 重复合并已执行，`duplicate_of` 已填写
- `deferred` 条目均有 `deferred_to_version`（否则计入扣分）
- scoring-rubric.md 公式已计算，pass_readiness 已标注

## Key references
- `../../022-prd-generation/prd-generation/references/handoff-to-n100.md`：**N090→N100 节点交接协议（PRD-15 主输入 + GAP 清单消费 + source_gap_id 映射 + n090_intake 格式）（必读，见 022）**
- `../025-requirement-completeness-check/requirement-completeness-check/references/node-guide.md`：**N100 节点导航——6 个 skill 量化公式速查（必读，见 025）**
- `references/scoring-rubric.md`：**pending_score 公式 + severity 推导表 + 重复合并规则 + 阻塞传播规则（必读）**
- `references/pending-state-machine.md`：**状态机 + source_kind 分类决策树（Q1-Q4）+ 状态转移规则 + 边界 case 表（必读）**
- `references/output-template.md`：输出结构（含 Decision Log 视图位置）
- `../references/cross-node-bridge-contract.md`：**N090→N100 source_gap_id 字段格式 + new_gap 回写规则 + 031 open_questions 继承格式（必读）**
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
