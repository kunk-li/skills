---
name: pending-items-extraction
description: extract pending questions, unresolved decisions, deferred items, and ownership gaps from any document-oriented requirement baseline. use when the input is a prd, design baseline, contract-like specification, sop, policy, or structured requirement package and the user needs a standalone meeting-ready decision log or a composable pending-item signal for broader quality gating.
---
# pending-items-extraction

## Role
Turn unresolved material into a decision-ready backlog.
This skill must work on any baseline that contains explicit TODOs, implied gaps, pending approvals, or deferred scope.

## Standalone and combined use
### Standalone
Produce a meeting-ready issue log that can be used without any other skill.
It must include source, state, owner suggestion, timing, and duplicate merging where possible.

### Combined
Expose pending-item structure cleanly so 030 or other workflows can turn it into gate conditions, handover gaps, or roadmap inputs.

## Shared interoperability contract
When this skill is used with other requirement-review skills, keep the native specialty fields but also preserve these shared fields whenever the evidence supports them:
- `issue_id`
- `issue_category`
- `issue_subtype`
- `severity` = blocker / major / minor / note
- `severity_matrix.overall` plus any supported sub-dimensions
- `artifact`
- `object`
- `evidence`
- `finding`
- `impact`
- `owner_candidate`
- `needs_decision`
- `blocking`
- `related_issue_ids` when there is an obvious upstream or downstream link

Do not drop the skill-specific fields just to fit the shared schema. Keep both when useful.

## Light composition runtime contract
When this skill is run as part of a composed N100 review, carry these lightweight runtime fields whenever available:
- `parse_cache_ref`
- `issue_namespace` (default `N100`)
- `decision_ref`
- `re_gate_session_id`
- `produced_event_name`

Keep them nullable when the upstream workflow does not provide them. Do not invent values.

## Shared node-level references
When these bundled references are present, consult them before inventing local behavior:
- `_shared/parse-cache-contract.md` for cache lifecycle, hit/miss handling, and integrity fallback
- `_shared/cross-skill-disambiguation.md` for ownership boundaries, duplicate prevention, and `related_issue_ids` linkage

## Workflow v2 input aliases
Prefer the workflow names directly when they exist:
- `PRD.md`
- `需求结构树.md`
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`

Also accept TODO-marked drafts, reviewer notes, or upstream check outputs as additional evidence.

## Preferred inputs
Preferred package when available:
- `hub_requirement_breakdown.md`
- `hub_business_rules.md`
- `hub_state_transition_mapping.md`
- `hub_permission_matrix.md`

Fallback inputs may be any baseline plus reviewer notes, TODO-marked drafts, or structured analysis outputs.

## Source kinds
Use one of:
- `explicit_todo`
- `gap_detected`
- `cross_check`
- `external_signal`
- `decision_pending`

## Pending states
Use this lifecycle when possible:
- `raised`
- `clarifying`
- `answered`
- `decided`
- `implemented`
- `verified`
- `closed`
- `deferred`
- `rejected`

## Workflow v2 artifact contract
Declare this contract explicitly in the output header when the result is intended for workflow consumption:
- `artifact_type`: `n100.pending-items`
- `schema_version`: `2.1.1`
- `producer_skill`: `pending-items-extraction`
- `consumer_nodes`: `N100`, `N110`, `N180`, `N370`
- `workflow_alias`: `待确认项清单.csv`
- `produced_event_name`: `produced.n100.pending-items`
- `canonical_fields`: `issue_id`, `issue_category`, `issue_subtype`, `source_kind`, `pending_state`, `severity`, `severity_matrix.overall`, `artifact`, `object`, `question`, `why_unresolved`, `impact`, `owner_candidate`, `target_timing`, `needs_decision`, `blocking`, `resolution_id`, `deferred_to_version`, `parse_cache_ref`, `issue_namespace`, `decision_ref`, `re_gate_session_id`

## Output contract
Default to a dual output unless the user explicitly asks for only one representation:
1. a machine-readable CSV-first artifact aligned to workflow v2 and named `待确认项清单.csv`
2. a concise Markdown summary that follows `references/output-template.md`

Each CSV row must include:
- `issue_id`
- `issue_category` = pending
- `issue_subtype`
- `source_kind`
- `pending_state`
- `severity`
- `severity_matrix.overall`
- `artifact`
- `object`
- `question`
- `why_unresolved`
- `impact`
- `owner_candidate`
- `target_timing` = pre-review / in-review / post-review
- `needs_decision`
- `blocking`
- `resolution_id`
- `deferred_to_version`
- `parse_cache_ref`
- `issue_namespace`
- `decision_ref`
- `re_gate_session_id`

When evidence supports it, also include:
- `state_history[]`
- `duplicate_of`
- `roadmap_bucket`

If the user only wants prose, keep the rows directly convertible into the same CSV columns.

## Modes
- `format_detection`: detect TODO, FIXME, TBD, open question, and similar markers automatically
- `merge_duplicates`: merge semantically duplicated pending items
- `export_mode`: shape output for Jira, GitLab issues, or another tracker when requested
- `re_gate_mode`: compare against a prior issue set and mark closed_since_last / still_open / new_in_this_scan when such evidence exists

## Workflow
1. Collect explicit and implicit pending items.
2. Label each item with a source kind.
3. Merge duplicates conservatively.
4. Separate true decision items from wording cleanup.
5. Assign a pending state, owner suggestion, and timing.
6. Emit the workflow CSV rows first when workflow consumption is expected.
7. Build a deferred roadmap view when version deferral appears.

## Boundary rules
- Do not turn decided facts into pending items.
- Do not hide serious confirmed conflicts or vulnerabilities here when the real issue belongs in another skill.
- Do not duplicate the same decision in multiple wordings when a merged item is sufficient.
- When a pending item is already mapped to a BLK / MAJ / MIN style resolution, keep that mapping visible instead of opening a second issue thread.

## References
- `references/output-template.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/pending-state-machine.md`
