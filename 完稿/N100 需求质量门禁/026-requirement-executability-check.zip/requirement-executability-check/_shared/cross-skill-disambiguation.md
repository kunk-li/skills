# Cross-Skill Disambiguation (N100)

本文档规定:同一问题在 025-030 各技能中的唯一归属判别规则。
消除重叠是 030 rollup 正确性的前提。

## 问题类型 × 归属决策表

| 问题情境 | 归属技能 | 判别规则 |
|---|---|---|
| 规则 A 与规则 B 文字相反 | 027 | 证据双向充分 → `confirmed`;单向弱证据 → `potential` |
| 规则 A 与规则 B 看似矛盾但 PM 未澄清 | **029** | 先挂 `decision_pending`;一旦 PM 澄清为矛盾,升级转入 027 |
| 并发场景有规则但冲突解法未定义 | 028 | 可构造 exploit path → `business_logic vulnerability` |
| 并发场景完全未涉及 | 025 | `D5 exception_handling` 的 `implicit_gap` |
| 并发场景有决议需求但未决议 | **029** | `source_kind: decision_pending` + `blocking: true` |
| 权限范围定义与实际需求不符 | 027 | 归 `permission` conflict |
| 权限缺少角色归属 | 025 | 归 `D6 security_compliance` 的 `missing_field` |
| 权限可被绕过 | 028 | 归 `authorization_drift` vulnerability |
| 异常路径完全未定义 | 025 | `D5 exception_handling` missing |
| 异常路径部分定义但关键缺失 | 028 | `failure_path_holes` vulnerability |
| 某个功能点描述中含 "TODO" / "TBD" | 029 | `source_kind: explicit_todo` |
| 某个功能点描述模糊但无 TODO 标记 | 025 | `vague_content` finding |
| 某个功能点模糊且阻塞研发 | **同时归 025 + 029** | 025 记 completeness gap,029 记 decision_pending,但**通过 related_issue_ids 互指**,030 在 rollup 时仅计 1 次 |
| 一条规则与合规法规冲突 | 028 | 归 `compliance` vulnerability,严重性 P0 |
| 一条规则未涉及合规考虑 | 025 | `D6 security_compliance` gap |
| 源真相(source of truth)不清 | 026 | `NE-02 underspecified` |
| 源真相不清且已导致规则矛盾 | 027 | 升级为 `semantic` conflict |

## 重叠处理原则

### Principle 1: 证据强度决定归属
- 证据充分 → 落入具体技能(027 conflict / 028 vulnerability / 025 missing)
- 证据不足但需澄清 → 029 pending
- 从 029 升级到其他技能的条件:澄清后证据充分

### Principle 2: 一题一记,跨技能互指
当同一根因横跨多维度时(常见于 complex requirement):
- 主归属由 "证据最直接指向的维度" 决定
- 次要维度通过 `related_issue_ids` 链接,不独立计提 severity
- 030 rollup 时:同一 root issue 的 severity 取最大,不做加和

### Principle 3: 029 是 "暂存区" 不是 "垃圾桶"
- 029 必须有 `source_kind` 明确其来源
- 029 必须有 `resolution path`:升级到其他技能 / 独立关闭 / 延期到下版本
- 不得把已能在 027/028 中确认的问题丢进 029 规避分级责任

## 重叠检测工具(供 030 使用)

030 rollup 前应运行以下检测:

```
for each pair (issue_a from skill_X, issue_b from skill_Y):
  if skill_X != skill_Y
     and issue_a.object == issue_b.object
     and cosine_similarity(issue_a.finding, issue_b.finding) > 0.85:
     flag as potential_duplicate
     require related_issue_ids link OR downgrade one side
```

检测到未链接的重叠时:
- 030 在 rollup_trace 中标注 `duplicate_risk_count`
- 若超过阈值(默认 3)→ 降低 confidence 等级为 `medium`
