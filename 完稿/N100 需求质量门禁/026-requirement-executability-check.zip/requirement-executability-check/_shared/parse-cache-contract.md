# Parse Cache Contract (N100 Node-Level)

## Purpose
六个 N100 子技能(025-030)在同一 Gate 会话内共享 baseline 的结构化解析结果,
避免每个技能独立解析 PRD / 需求结构树 / 业务规则清单 / 状态流转表 / 权限矩阵。

## Cache Key Derivation
cache_key = sha256(
  concat(
    content_hash(PRD.md),
    content_hash(需求结构树.md),
    content_hash(业务规则清单.csv),
    content_hash(状态流转表.csv),
    content_hash(权限矩阵.csv),
    glossary_hash,          # 可空,nullable
    scan_mode               # baseline | diff | tracking | re_gate
  )
)

## Cache Schema

```yaml
parse_cache:
  cache_key: string                      # 上述 sha256
  created_at: iso8601
  gate_session_id: string                # 与 re_gate_session_id 对应
  baseline_version: string               # 若可识别

  parsed_requirements:
    - req_id: string
      title: string
      description: string
      scope: string
      source_artifact: string            # PRD 章节 / 需求结构树 节点
      owner: string | null

  parsed_rules:
    - rule_id: string
      statement: string
      applies_to: [req_id, ...]
      source_artifact: string

  parsed_states:
    - object: string
      states: [string, ...]
      transitions:
        - from: string
          to: string
          trigger: string
          guard: string | null

  parsed_permissions:
    - role: string
      resource: string
      action: string
      constraint: string | null

  parsed_acs:                            # 若 PRD 已有 AC
    - ac_id: string
      req_id: string
      given: string
      when: string
      then: string

  parsed_open_questions:                 # 显式 TODO / TBD / FIXME
    - location: string
      text: string
      marker_type: enum[TODO, TBD, FIXME, OPEN, NOTE]

  normalization_notes:                   # 解析过程中的 normalize 记录
    - original: string
      normalized: string
      reason: string
```

## Access Protocol

### 读取者(consumers: 025-030)
1. 接收 `parse_cache_ref` 字段(nullable)
2. 若 `parse_cache_ref` 有值 → 优先使用该缓存,跳过独立解析
3. 若 `parse_cache_ref` 为 null → 回落到独立解析,并回写新 cache 供后续使用
4. 不得修改缓存内容;只读

### 写入者(producer: 首个被调用的技能 或 N100 orchestrator)
1. 若当前 gate_session 无现存缓存 → 执行完整解析并回写
2. 若已存在相同 cache_key → 复用,不重写
3. 解析失败时 → 必须输出 normalization_notes 说明哪些段落未能解析

## Lifecycle

| 事件 | 动作 |
|---|---|
| 同一 gate_session 内所有 skill 运行完毕 | 保留缓存 |
| re_gate_session_id 为全新值 | 失效旧缓存,强制重建 |
| baseline 内容变化(cache_key 变) | 自动失效,新 key 触发重建 |
| 超过 TTL(默认 24h) | 自动失效 |

## Failure Modes

1. **缓存不可用**:任何 skill 必须能在 `parse_cache_ref = null` 时独立工作,
   不得因缓存缺失而失败。parse_cache 是性能优化,不是功能前提。

2. **缓存污染检测**:消费者读取后发现字段严重不一致时,应写入
   `cache_integrity_warning` 到 findings,并降级为独立解析。

3. **并发写入**:同一 gate_session 内不应出现多个技能同时触发 cache 创建;
   通过 orchestrator 在 session 初始化时先跑一遍轻量解析,保证 cache 先于
   025-030 任一技能执行而存在。

## Measurement
- 命中率目标:re_gate_mode 下 ≥ 80%,首次 baseline_mode 下 ≥ 60%(除 029)
- 重复解析节省:6 skills × PRD size → 1 次解析,节省 60-70% token
- Cache hit 时单个 skill 的延迟减少目标:≥ 40%

## Integration with Workflow v2 Event Bus
parse_cache 的创建与失效应作为事件广播:
- `produced.n100.parse-cache` → 首次缓存就绪
- `invalidated.n100.parse-cache` → baseline 变更导致失效
横切订阅者(N330 文档 / N390 治理)可订阅这些事件做审计与追溯。
