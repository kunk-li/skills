# Scoring Rubric

## Excellent
- clear overall status and four-perspective matrix
- strong reason-code usage
- preconditions and estimates are actionable
- report works standalone and in combination

## Good
- clear status and blockers
- most constrained items have reasons and next steps

## Needs Work
- only says yes or no without preconditions
- perspectives are mixed together
- no clear next-step boundary

## Poor
- guesses missing contracts
- no reason codes
- no distinction between conditional and impossible

## Numeric formula

### Per-perspective score

四个视角独立打分(design / engineering / test / risk):

  perspective_score[v] = 100 - (
    not_executable_count[v] × 20 +
    conditionally_count[v] × 5 +
    ne_04_dependency_missing[v] × 5    # 额外加重,依赖缺失穿透设计&工程
  )
  clip to [0, 100]

### Overall executability score

  if min(perspective_score) < 50:
    overall = min(perspective_score)   # 任一视角重度阻塞 → 整体受限
  else:
    overall = weighted_mean(
      design × 0.20,
      engineering × 0.30,
      test × 0.25,
      risk × 0.25
    )

### Reason code 权重

| reason | base_penalty | 适用视角扩散 |
|---|---:|---|
| NE-01 ambiguous | 10 | design + engineering |
| NE-02 underspecified | 15 | engineering + test |
| NE-03 conflicting | 20 | 全部四个视角(升级至 027 归属) |
| NE-04 dependency_missing | 20 | design + engineering |
| NE-05 out_of_scope | 5 | 单视角(通常是 PM) |
| NE-06 technology_gap | 15 | engineering + risk |
| NE-07 resource_insufficient | 10 | risk |
| NE-08 compliance_blocker | 25 | 全部 + 升级至 028 vulnerability |

### 执行态判定(per requirement)

  if any_blocker_precondition_exists:
    status = not_executable
  elif soft_preconditions_only:
    status = conditionally_executable
  else:
    status = executable

### pass_readiness 映射

| overall_executability | 映射 |
|---:|---|
| ≥ 85 | executable |
| 60-84 | conditionally_executable(必须列出 preconditions[]) |
| < 60 | not_executable |
