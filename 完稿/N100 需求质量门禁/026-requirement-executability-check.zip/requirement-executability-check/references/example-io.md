# Example IO

## Example: 外部支付回调功能的可执行性扫描

### Input (excerpt)
PRD 定义支付成功流程 + 提及"对接银行回调",但回调合约未定义、失败行为未定义。

### Output: 可执行性检查单.csv (selected rows)

```
issue_id,issue_category,executability,non_executable_reason,perspective,severity,severity_matrix.overall,artifact,object,evidence,finding,impact,recommendation,owner_candidate,needs_decision,blocking
CHECK-EXEC-PAY-001,executability,conditionally_executable,NE-04,design,major,major,PRD.md §5.1,REQ-PAY-003 银行回调,PRD §5.1 提及'对接银行回调'但无合约,回调字段与时序不明,设计可启动但接口 mock 与错误分支待定,获取银行方接口文档或约定 mock 合约,tech_lead,true,false
CHECK-EXEC-PAY-002,executability,not_executable,NE-02,engineering,blocker,blocker,PRD.md §5.1,REQ-PAY-003 银行回调失败行为,PRD 未定义回调失败后订单状态,失败场景完全缺失,工程无法实现失败分支,定义 3 类失败(签名错 / 超时 / 银行异常)的处理规则,pm_zhang + tech_lead,true,true
CHECK-EXEC-PAY-003,executability,not_executable,NE-02,test,blocker,blocker,PRD.md §5.1,REQ-PAY-003 回调验收,无 AC 定义失败路径,测试无法编写负路径用例,测试阻塞 → 配合 CHECK-EXEC-PAY-002 补 AC,qa_lead,true,true
CHECK-EXEC-PAY-004,executability,conditionally_executable,NE-06,risk,minor,minor,PRD.md §5.1,REQ-PAY-003 并发回调,未提及同笔订单并发回调处理,潜在幂等性风险,风险视角需预研,预研幂等方案并出设计方案,tech_lead,false,false
```

### Output: 可执行性摘要

```
## 可执行性审查结论

- **overall_executability_score**: 52
- **status**: conditionally_executable(整体);test 维度 not_executable
- **earliest safe next step**: 先补回调合约 + 失败行为,再进入 engineering + test

### 四视角矩阵

| perspective | score | status | blockers |
|---|---:|---|---|
| design | 72 | conditionally_executable | NE-04 dep missing |
| engineering | 40 | not_executable | NE-02 失败行为未定义 |
| test | 30 | not_executable | 无 AC 负路径 |
| risk | 75 | conditionally_executable | NE-06 并发幂等预研 |

### preconditions

| dep_id | dep_kind | dep_readiness | dep_blocker_severity | description |
|---|---|---|---|---|
| DEP-001 | external_service | pending | hard | 银行回调接口文档 |
| DEP-002 | decision | pending | hard | 失败场景处理规则 |
| DEP-003 | knowledge | in_progress | soft | 并发幂等方案预研 |

### execution_estimate

- effort_pd: 8 person-days(含预研 3pd)
- complexity: high
- skill_level: senior
- team_size: 2 (1 backend + 1 qa)
- knowledge_risk: medium(并发幂等方案不确定)
```
