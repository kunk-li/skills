# Delivery Checklist

- Is the result usable without any other skill?
- Are design, engineering, test, and risk views evaluated separately?
- Does each constrained item use a reason code?
- Are preconditions explicit for conditionally executable items?
- Are effort estimates coarse and honest rather than fake precision?
- Does the report say what can proceed now versus what must wait?
- Are shared fields preserved for later aggregation?
