# Orchestration Guidance

## Standalone path
1. Evaluate the baseline directly.
2. Produce overall status, perspective matrix, blockers, and preconditions.
3. End with the earliest safe next step.

## Combined path
1. Use this skill when the team needs to know whether execution may begin.
2. Combine with completeness, conflict, vulnerability, and pending-item skills when a broader gate is needed.
3. Preserve issue ids and precondition structure so 030 can reuse them.
