# Common Failure Modes

1. Treating every missing detail as equally blocking.
2. Mixing design readiness with test readiness.
3. Calling something executable without naming preconditions.
4. Giving exact estimates that the evidence cannot support.
5. Letting a combined run erase the standalone execution conclusion.
