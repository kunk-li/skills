# Output Template

When the result will be consumed by workflow v2, emit the machine-readable CSV artifact first and then the narrative summary.

## 0. artifact contract header
- `artifact_type`: `n100.executability-check`
- `schema_version`: `2.1.1`
- `producer_skill`: `requirement-executability-check`
- `consumer_nodes`: `N100`, `N110`, `N180`
- `workflow_alias`: `可执行性检查单.csv`
- `produced_event_name`: `produced.n100.executability-check`
- `issue_namespace`: default `N100`
- `parse_cache_ref`: nullable
- `decision_ref`: nullable
- `re_gate_session_id`: nullable

## 1. machine-readable artifact
Produce or simulate a CSV named `可执行性检查单.csv` with these columns in this exact order:
| issue_id | issue_category | issue_subtype | executability | non_executable_reason | perspective | severity | severity_matrix.overall | artifact | object | evidence | finding | impact | recommendation | owner_candidate | needs_decision | blocking | parse_cache_ref | issue_namespace | decision_ref | re_gate_session_id |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## 2. document purpose and input inventory
- explain that this is an execution-readiness report
- list inputs used and any major missing inputs
- state mode: default / deep_mode / what_if / batch_mode / re_gate_mode

## 3. overall execution-readiness conclusion
- overall status: `executable | conditionally_executable | not_executable`
- one-paragraph rationale
- earliest safe next step

## 4. four-perspective matrix
| perspective | status | strongest evidence | key blocker ids | what can proceed now |
|---|---|---|---|---|
| design |  |  |  |  |
| engineering |  |  |  |  |
| test |  |  |  |  |
| risk |  |  |  |  |

## 5. blocker and conditional items
| issue_id | executability | reason code | object | finding | impact | preconditions | recommendation |
|---|---|---|---|---|---|---|---|

## 6. dependency and precondition table
| dep_id | dep_kind | dep_readiness | hard or soft | description |
|---|---|---|---|---|

## 7. execution estimate summary
- effort range
- complexity
- skill level
- knowledge risk
- note that this is an early signal, not a committed N180 plan

## 8. next-step recommendation
- what can start now
- what must wait
- what to clarify first
