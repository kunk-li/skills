# Dependency Taxonomy

## dep_kind values
- external_service
- internal_service
- data
- infrastructure
- knowledge
- regulatory
- decision

## dep_readiness values
- ready
- in_progress
- pending
- blocked

## dep_blocker_severity values
- hard: work cannot safely start without it
- soft: some work can start but not end-to-end delivery
