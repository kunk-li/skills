---
name: requirement-executability-check
description: Assess whether a requirement baseline (PRD, spec, SOP, policy, breakdown, rules, states) is executable enough for design, delivery, and test prep; emits an execution-readiness decision.
---
# requirement-executability-check

## Role
Answer one question: can real work start from this baseline, and under what conditions?
This skill must work on any requirement-like baseline, not only PRDs.

## Standalone and combined use
### Standalone
Produce an execution-readiness report that PM, design, engineering, QA, and reviewers can use immediately.
The report must include status, blockers, preconditions, and effort hints.

### Combined
Preserve the specialty answer to "can this be executed now" while exposing shared fields for 030 and related skills.
Do not downgrade into a generic quality summary.

## Shared interoperability contract
When this skill is used with other requirement-review skills, keep the native specialty fields but also preserve these shared fields whenever the evidence supports them:
- `issue_id`
- `issue_category`
- `issue_subtype`
- `severity` = blocker / major / minor / note
- `severity_matrix.overall` plus any supported sub-dimensions
- `artifact`
- `object`
- `evidence`
- `finding`
- `impact`
- `owner_candidate`
- `needs_decision`
- `blocking`
- `related_issue_ids` when there is an obvious upstream or downstream link

Do not drop the skill-specific fields just to fit the shared schema. Keep both when useful.

## Light composition runtime contract
When this skill is run as part of a composed N100 review, carry these lightweight runtime fields whenever available:
- `parse_cache_ref`
- `issue_namespace` (default `N100`)
- `decision_ref`
- `re_gate_session_id`
- `produced_event_name`

Keep them nullable when the upstream workflow does not provide them. Do not invent values.

## Shared node-level references
When these bundled references are present, consult them before inventing local behavior:
- `_shared/parse-cache-contract.md` for cache lifecycle, hit/miss handling, and integrity fallback
- `_shared/cross-skill-disambiguation.md` for ownership boundaries, duplicate prevention, and `related_issue_ids` linkage

## Workflow v2 input aliases
Prefer the workflow names directly when they exist:
- `PRD.md`
- `需求结构树.md`
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`

Also accept equivalent analyst-friendly aliases such as requirement breakdown, business rules, state transition mapping, and permission matrix.

## Inputs / 允许输入
Preferred package when available:
- `hub_requirement_breakdown.md`
- `hub_business_rules.md`
- `hub_state_transition_mapping.md`
- `hub_permission_matrix.md`

Fallback inputs may be any baseline that is intended to drive implementation, procedure execution, or operational rollout.

## Executability states
Use exactly one per requirement or major finding:
- `executable`
- `conditionally_executable`
- `not_executable`

`conditionally_executable` requires `preconditions[]`.

## ★ 架构决策不算 not_executable（2026-07-22 修正 · 见 references/executability-criteria.md）

判 engineering 视角 not_executable 前，先分缺口是**架构决策**（裁决算法/事务策略/表schema/错误码/分层/orchestration——工程师自己拍，PRD 不写是对的）还是**产品决策**（角色数/风险偏好/KMS基建/业务规则含义/外部依赖——须 PM/基建/业务方）。**只有产品决策缺失且高危才驱动 not_executable；架构决策缺失判 conditionally 并交 design/impl（owner_candidate=design/impl），绝不因架构未声明单独判 not_executable。** 把架构误当 not_executable 会把核心业务全推成 stub（实测核心 0/41 可跑）。

## Non-executable reason codes
Use these enums when the item is conditionally executable or not executable:
- `NE-01 ambiguous`
- `NE-02 underspecified`
- `NE-03 conflicting`
- `NE-04 dependency_missing`
- `NE-05 out_of_scope`
- `NE-06 technology_gap`
- `NE-07 resource_insufficient`
- `NE-08 compliance_blocker`

## Workflow v2 artifact contract
Declare this contract explicitly in the output header when the result is intended for workflow consumption:
- `artifact_type`: `n100.executability-check`
- `schema_version`: `2.1.1`
- `producer_skill`: `requirement-executability-check`
- `consumer_nodes`: `N100`, `N110`, `N180`
- `workflow_alias`: `可执行性检查单.csv`
- `produced_event_name`: `produced.n100.executability-check`
- `canonical_fields`: `issue_id`, `issue_category`, `issue_subtype`, `executability`, `non_executable_reason`, `perspective`, `severity`, `severity_matrix.overall`, `artifact`, `object`, `evidence`, `finding`, `impact`, `recommendation`, `owner_candidate`, `needs_decision`, `blocking`, `parse_cache_ref`, `issue_namespace`, `decision_ref`, `re_gate_session_id`

## Output contract
Default to a dual output unless the user explicitly asks for only one representation:
1. a machine-readable CSV-first artifact aligned to workflow v2 and named `可执行性检查单.csv`
2. a concise Markdown summary that follows `references/output-template.md`

Each CSV row must include:
- `issue_id`
- `issue_category` = executability
- `issue_subtype`
- `executability`
- `non_executable_reason`
- `perspective` = design / engineering / test / risk
- `severity`
- `severity_matrix.overall`
- `artifact`
- `object`
- `evidence`
- `finding`
- `impact`
- `recommendation`
- `owner_candidate`
- `needs_decision`
- `blocking`
- `parse_cache_ref`
- `issue_namespace`
- `decision_ref`
- `re_gate_session_id`

When relevant also include:
- `preconditions[]`
- `execution_estimate.effort_pd`
- `execution_estimate.complexity`
- `execution_estimate.skill_level`
- `execution_estimate.team_size`
- `execution_estimate.knowledge_risk`

If the user only wants prose, keep the rows directly convertible into the same CSV columns.

## Preconditions contract
Each precondition should include:
- `dep_id`
- `dep_kind` = external_service / internal_service / data / infrastructure / knowledge / regulatory / decision
- `dep_readiness` = ready / in_progress / pending / blocked
- `dep_blocker_severity` = hard / soft
- `description`

## Workflow
1. Read the baseline and separate confirmed facts from implied assumptions.
2. Evaluate design, engineering, test, and risk perspectives independently.
3. Assign `executable`, `conditionally_executable`, or `not_executable`.
4. For constrained items, name the reason codes and preconditions.
5. Estimate effort and complexity only at a coarse, reusable level.
6. Emit the workflow CSV rows first when workflow consumption is expected.
7. End with the earliest safe next step.

## Advanced modes
- `deep_mode`: include effort estimates and dependency breakdowns
- `what_if`: show how status changes if named preconditions become ready
- `batch_mode`: compare execution readiness across multiple baselines
- `re_gate_mode`: compare against a prior issue set and mark closed_since_last / still_open / new_in_this_scan when such evidence exists

## Boundary rules
- Do not use common sense to invent missing contracts.
- Do not collapse every problem into vague wording; use reason codes.
- Do not call something executable when failure handling, authority, or source of truth is materially blocked.
- Do not replace conflict analysis or vulnerability analysis with this skill.
- Treat `execution_estimate` as an early readiness signal for N180, not as a replacement for task planning or committed delivery estimation.


## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认，并按 `references/scoring-rubric.md` 中的 Numeric formula 计算实际分数。
确认：scoring-rubric.md 中的公式已全部计算，所有 hard rules 已检查，pass_readiness 已标注。

## Key references
- `../../022-prd-generation/prd-generation/references/handoff-to-n100.md`：**N090→N100 节点交接协议（source_gap_id + GAP 路由）（必读，见 022）**
- `../025-requirement-completeness-check/requirement-completeness-check/references/node-guide.md`：**N100 节点导航——6 个 skill 量化公式速查、override 规则、N100→N110 映射表（必读，见 025）**

- `references/scoring-rubric.md`：**4 视角独立评分公式 + min-blocker 规则 + NE-01..NE-08 扣分权重表 + executable 判定决策树（必读）**
- `references/executability-criteria.md`：**可执行性判别标准及问题清单（必读）**
- `references/dependency-taxonomy.md`：依赖类型分类
- `references/output-template.md`：输出结构
- `../references/cross-node-bridge-contract.md`：issue 中 source_gap_id 字段 + new_gap 回写规则（与 030 rollup 协同）
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
