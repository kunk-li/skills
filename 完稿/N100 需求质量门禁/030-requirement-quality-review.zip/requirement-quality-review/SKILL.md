---
name: requirement-quality-review
description: Aggregate direct evidence and optional specialized review outputs into a requirement-quality gate report with transparent rollup logic; standalone, partial, or full multi-skill decision.
---
# requirement-quality-review

## Role
Produce the final quality review or gate-style conclusion.
This skill must be usable in three ways:
- alone on a baseline
- partially with some upstream skill outputs
- fully with all specialized review outputs

## Standalone and combined use
### Standalone
When only the baseline is available, run a conservative direct review and clearly mark confidence limits.

### Combined
When specialized skill outputs are available, reuse them instead of flattening them into a generic summary.
Keep rollup logic explicit and auditable.

## Workflow / 执行流程
- `Standalone Mode`
- `Partial Mode (X/5 inputs)`
- `Full Mode`

## Shared interoperability contract
When this skill is used with other requirement-review skills, keep the native specialty fields but also preserve these shared fields whenever the evidence supports them:
- `issue_id`
- `issue_category`
- `issue_subtype`
- `severity` = blocker / major / minor / note
- `severity_matrix.overall` plus any supported sub-dimensions
- `artifact`
- `object`
- `evidence`
- `finding`
- `impact`
- `owner_candidate`
- `needs_decision`
- `blocking`
- `related_issue_ids` when there is an obvious upstream or downstream link

Do not drop the skill-specific fields just to fit the shared schema. Keep both when useful.

## Light composition runtime contract
When this skill is run as part of a composed N100 review, carry these lightweight runtime fields whenever available:
- `parse_cache_ref`
- `issue_namespace` (default `N100`)
- `decision_ref`
- `re_gate_session_id`
- `produced_event_name`

Keep them nullable when the upstream workflow does not provide them. Do not invent values.

## Shared node-level references
When these bundled references are present, consult them before inventing local behavior:
- `_shared/parse-cache-contract.md` for cache lifecycle, hit/miss handling, and integrity fallback
- `_shared/cross-skill-disambiguation.md` for ownership boundaries, duplicate prevention, and `related_issue_ids` linkage

## Workflow v2 input aliases
Prefer the workflow names directly when they exist:
- `PRD.md`
- `需求结构树.md`
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`
- `完整性检查单.csv`
- `可执行性检查单.csv`
- `需求矛盾问题单.csv`
- `需求漏洞清单.csv`
- `待确认项清单.csv`

Also accept equivalent analyst-friendly aliases and earlier Markdown versions when those are the only available inputs.

## Inputs / 允许输入
Preferred specialized inputs:
- `requirement-completeness-check`
- `requirement-executability-check`
- `requirement-conflict-detection`
- `requirement-vulnerability-scan`
- `pending-items-extraction`

Use direct baseline scanning when some or all are missing.

## Rollup rule
Always state `rollup_rule` explicitly.
Default algorithm:
- `algorithm`: `weighted_max_severity`
- `weights.completeness`: 0.25
- `weights.executability`: 0.20
- `weights.conflict`: 0.25
- `weights.vulnerability`: 0.20
- `weights.pending`: 0.10

Default thresholds:
- `go`: no unresolved blocker and overall score >= 85
- `conditional-go`: no unresolved blocker-level stop condition and overall score >= 60
- `no-go`: any unresolved blocker-level stop condition or overall score < 60

These defaults may be adjusted when the user explicitly requests a different weighting or industry posture.

## Workflow v2 artifact contract
Declare this contract explicitly in the output header when the result is intended for workflow consumption:
- `artifact_type`: `n100.quality-review`
- `schema_version`: `2.1.1`
- `producer_skill`: `requirement-quality-review`
- `consumer_nodes`: `N110`, `N370`, `N380`
- `workflow_alias`: `需求质量审查单.md`
- `secondary_alias`: `N100_Gate_Report.md`
- `produced_event_name`: `produced.n100.quality-review`
- `canonical_fields`: `rollup_rule`, `rollup_trace`, `overall_score`, `gate`, `maximum_readiness_stage`, `transition_plan`, `confidence`, `parse_cache_ref`, `issue_namespace`, `decision_ref`, `re_gate_session_id`

## Output contract
Always produce a primary Markdown artifact named `需求质量审查单.md` and shape it using `references/output-template-v2.md`.
When the user explicitly asks for a gate brief or automation-friendly alias, also allow `N100_Gate_Report.md` as a secondary title.

The Markdown report must include:
- `rollup_rule`
- `rollup_trace`
- `overall_score`
- `gate` = no-go / conditional-go / go
- `maximum_readiness_stage`
- `transition_plan`
- `confidence`
- `parse_cache_ref`
- `issue_namespace`
- `decision_ref`
- `re_gate_session_id`
- `produced_event_name`

When evidence supports it, also include:
- `version_trend[]`
- `benchmark`
- `view_mode` = engineer_view / tester_view / compliance_view / pm_view / all
- `re_gate_delta` = closed_since_last / still_open / new_in_this_scan
- `pass_conditions[]`
- `overrides_applied[]`
- `overrides_expiring_within_7_days[]`

If the user also wants machine-readable output, provide an appendix table or companion CSV that is directly traceable back to the report sections. Keep the Markdown artifact as the source of truth for workflow v2.

## Mandatory behavior
1. Pick the correct mode and state it explicitly.
2. Reuse upstream findings when present.
3. Normalize fields conservatively using `references/field_alias_map.md`.
4. Keep blocker logic and weighting visible.
5. Produce a transition path, not only a gate label.
6. Keep the report useful for PM, QA, engineering, and review facilitators.
7. Make the report directly consumable by N110 and N370 without requiring a second interpretation pass.
8. Scan and load valid overrides using `references/override-policy.md`.
   - Unexpired overrides temporarily downgrade the matched finding severity by one level.
   - Every applied override and every override expiring within 7 days must appear in `rollup_trace`.
   - Hard-rule veto conditions cannot be bypassed by override.
   - If `approved_by` is empty, `expiry` has passed, or `documented_risk` / `mitigation` is missing, treat the override as invalid and restore the original severity.

## Transition plan
If the gate is `conditional-go` or `no-go`, always include:
- `to_go_conditions[]`
- `estimated_effort`
- `earliest_retest_date` when it can be inferred responsibly
- `expected_result`

## Boundary rules / 边界规则
- This skill stops at gate aggregation, transition planning, and readiness communication.
- Do not directly replace N110 handover-package generation.
- Do not directly replace N180 effort planning or dependency management.
- Do not directly replace N370 routing, state-machine orchestration, or platform gate execution.
- Do not silently strengthen a conclusion beyond the evidence.
- Do not bury blockers in prose.
- Do not flatten specialized findings so much that upstream skill meaning is lost.
- Do not claim high confidence when only sparse direct evidence exists.
- Override is an exception path, not the default operating mode; if more than 3 overrides are needed in one run, escalate to architecture review instead.
- Compliance-dimension P0 vulnerabilities cannot be overridden.
- Override cannot be used to waive a confirmed blocker conflict.


## Self-check / 节点内自检

交付前按 `references/checklist.md` 逐项确认，并按 `references/scoring-rubric.md` 中的 Numeric formula 计算实际分数。
确认：scoring-rubric.md 中的公式已全部计算，所有 hard rules 已检查，pass_readiness 已标注。

## Key references
- `../../025-requirement-completeness-check/requirement-completeness-check/references/node-guide.md`：**N100 节点导航——6 个 skill 量化公式速查、override 规则（必读，见 025）**
- `references/handoff-to-n110.md`：**N100→N110 节点交接协议（gate→mode 映射 + open_questions 继承 + N110 兄弟 skill 触发）（必读）**

- `references/scoring-rubric.md`：**加权求和公式（0.25/0.20/0.25/0.20/0.10）+ hard rule veto 触发条件 + gate 决策树（必读）**
- `references/override-policy.md`：**override 许可条件 + 失效恢复规则（override 失效 → restore original severity）（必读）**
- `references/rollup-policy.md`：各子维度分数汇总策略
- `references/cross-node-bridge-contract.md`：**030 rollup 中 cross_node_trace 段（N090 GAP coverage + N100 新发现 issue → GAP 回写）（必读）**
- `references/output-template-v2.md`：标准输出结构 v2（推荐）
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
