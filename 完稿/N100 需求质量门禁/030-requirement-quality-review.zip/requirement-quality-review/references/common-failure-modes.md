# Common Failure Modes

1. Picking a stronger mode than the input supports.
2. Emitting a gate label without a visible rollup rule.
3. Flattening specialized findings until their meaning is lost.
4. Giving no path from `conditional-go` or `no-go` to `go`.
5. Claiming strong confidence on sparse inputs.
