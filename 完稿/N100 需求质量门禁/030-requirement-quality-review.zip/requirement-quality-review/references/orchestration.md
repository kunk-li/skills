# Orchestration Guidance

## Standalone Mode
1. Read the baseline directly.
2. Run a conservative multi-dimension fast scan.
3. Output gate, readiness matrix, blockers, and transition plan.

## Partial Mode
1. Reuse available upstream skill outputs.
2. Fast-scan missing dimensions conservatively.
3. Mark confidence accordingly.

## Full Mode
1. Read all specialized outputs.
2. Normalize fields with the alias map.
3. Deduplicate, roll up, and emit downstream rules.
