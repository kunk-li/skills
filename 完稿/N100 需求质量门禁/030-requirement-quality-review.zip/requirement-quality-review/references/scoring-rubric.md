# Scoring Rubric

## Excellent
- correct mode selection
- transparent rollup rule and trace
- readiness matrix, blockers, and transition plan are all decision-ready
- specialized findings remain recognizable after aggregation

## Good
- strong gate decision with clear next steps
- most rollup reasoning is visible

## Needs Work
- gate label exists but weighting or blocker logic is unclear
- transition plan is vague

## Poor
- black-box aggregation
- blockers hidden in prose
- confidence overstated

## Numeric formula

### 总分聚合(weighted_max_severity 算法)

  overall_score_raw = (
    0.25 × completeness_score +
    0.20 × executability_score +
    0.25 × conflict_score +
    0.20 × vulnerability_score +
    0.10 × pending_score
  )

  overall_score = overall_score_raw × industry_adjustment_factor

industry_adjustment_factor:
| profile | factor | 说明 |
|---|---:|---|
| generic | 1.00 | 默认 |
| saas | 1.00 | 同 generic |
| ecommerce | 0.98 | 并发敏感,轻度下压 |
| fintech | 0.95 | compliance 权重放大后的净影响 |
| gov | 0.93 | compliance + documentation 双放大 |
| healthcare | 0.90 | compliance × 3 的净影响 |

实际实现时,行业 factor 通过 028 vulnerability_score 和 025 D6 的
权重已经部分反映。此处 factor 用于二次确认,避免重复放大。

### Hard rule veto(优先于 score 判决)

按优先级依次评估,任一触发即 gate = no-go:

1. 任一 confirmed blocker conflict(来自 027) → no-go
2. 任一 unresolved p0 compliance vulnerability(来自 028) → no-go
3. 任一 `accepted` vulnerability 无有效 `approved_by` 或 `expiry` 已过 → no-go
4. completeness_score < 50 → no-go
5. conflict_score < 50 → no-go

Hard rule veto 触发时,仍正常计算 overall_score 以供趋势分析,
但 gate 字段强制为 no-go,且 rollup_trace.hard_rule_triggered 标注原因。

### Gate 阈值决策树(无 hard veto 时)

  if overall_score >= 85:
    if all sub-scores >= 75 and no major unresolved findings:
      gate = go
    else:
      gate = conditional-go
  elif overall_score >= 60:
    gate = conditional-go
  else:
    gate = no-go

### confidence 等级

| 情境 | confidence |
|---|---|
| Full Mode + 所有 sub-scores 有数值 | high |
| Partial Mode 3-4/5 inputs | medium |
| Partial Mode 1-2/5 inputs | low |
| Standalone Mode | low(明确标注"直接扫描,建议运行专项技能") |
| 检测到 ≥ 3 处潜在重复未链接 | 降一级 |
| Hard rule veto 触发 | 提升至 high(确定性否决) |

### rollup_trace 必填字段

每次产出必须完整展示:

  rollup_trace:
    algorithm: weighted_max_severity
    weights: {completeness: 0.25, ..., pending: 0.10}
    industry_profile: {string}
    industry_adjustment_factor: {number}
    sub_scores:
      completeness: {score, p0_count, p1_count, dimensions_below_60}
      executability: {score, not_exec_count, cond_exec_count, reason_breakdown}
      conflict: {score, confirmed_count, potential_count, resolved_count}
      vulnerability: {score, by_dim_min_taken, p0_count, p1_count, p2_count}
      pending: {score, blocking_count, raised_count, clarifying_count}
    hard_rule_triggered: {list or null}
    duplicate_risk_count: {integer}
    confidence: {high | medium | low}

### 可验证性
给定 025-029 全部原始 CSV,任何审计者应能手算出 overall_score,
与 030 输出值的误差 ≤ 1 分。若超过 1 分,视为 030 实现错误。
