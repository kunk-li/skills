# Rollup Policy

## Default algorithm
weighted_max_severity

## Default weights
- completeness: 0.25
- executability: 0.20
- conflict: 0.25
- vulnerability: 0.20
- pending: 0.10

## Default threshold intent
- go: clear for the next stage with no unresolved blocker
- conditional-go: limited progress allowed under stated constraints
- no-go: unsafe to advance because blockers remain or the baseline is too weak overall

## Notes
- Conflict and completeness usually deserve high weight because they can invalidate downstream work broadly.
- Pending items should not dominate unless they represent real blocker decisions.
- Adjust weights only when the user or domain context justifies it.
