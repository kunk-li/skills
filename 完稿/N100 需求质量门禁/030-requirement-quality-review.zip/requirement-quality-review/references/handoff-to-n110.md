# N100 → N110 节点交接协议

> 本文件定义 N100（需求质量门禁）向 N110（需求交接与验收）的正式交接规范。

---

## 1. N100 输出捆绑包 / Upstream Output Bundle

N110 消费以下 N100 产物：

| 产物 | 来源 Skill | 关键字段 | N110 用途 |
|---|---|---|---|
| 质量评审报告（Gate Report） | 030 | gate + overall_score + top_blockers | 031 readiness_score 计算的 blocker_score 来源 |
| 完整性检查报告 | 025 | completeness_score + D1-D8 细节 | 031 completeness_score 计算 |
| 可执行性检查报告 | 026 | executability_score + NE-* findings | 031/032 验收标准中的前置条件 |
| 冲突检测报告 | 027 | conflict findings + confirmed blockers | 031 open_questions[] 的来源 |
| 漏洞扫描报告 | 028 | vulnerability findings + severity | 031/032 中的合规风险说明 |
| 未决项提取报告 | 029 | pending_items[] + blocking items | 031 open_questions[] 的主要来源 |
| N090→N100 GAP 回写清单 | 030 | cross_node_trace.remediation_plan | 031 中需跟踪的回写动作 |

---

## 2. 030 Gate 到 N110 执行模式映射（权威版）

此映射由 `031/references/readiness-scoring.md` 定义，此处为汇总引用：

```
N100 gate_status → N110 031 execution_mode:

  go             → formal_mode
                   条件：handover_readiness_score ≥ 75

  conditional-go → formal_mode（带 warnings）
                   必须输出 conditional_go_conditions[]
                   条件：任何让 gate 为 conditional-go 的约束已在 031 output 中引用

  no-go          → blocked_mode
                   必须在 gate_checks[] 中列出每个 no-go 原因
                   可以生成 minimal handover skeleton，但标记为 blocked

  未提供          → minimal_mode
                   标注 upstream_gate_status: unknown
```

### 2.1 `conditional_go_conditions[]` 格式

```yaml
conditional_go_conditions:
  - condition_id: CGC-001
    source_issue: N100-025-003           # 触发 conditional-go 的 N100 issue
    source_dimension: D5_exception_handling
    description: "PRD-11 的支付超时补偿逻辑需在交接后 3 个工作日内补充"
    owner: PM
    deadline: "2026-05-02"
    verification_method: "在 023 中创建 GAP-013 并关联 N100-025-003"
```

---

## 3. N110 入场校验 / Downstream Intake Protocol

031 启动前执行以下入场检查：

```yaml
n100_intake_check:
  # Step 1: 确认 N100 输出可用性
  available_reports:
    quality_review_030: true | false   # 必须：030 gate report
    completeness_025: true | false     # 影响 completeness_score 计算精度
    executability_026: true | false    # 影响 AC 生成（032）
    conflict_027: true | false
    vulnerability_028: true | false    # 影响合规风险说明
    pending_029: true | false          # 影响 open_questions[]

  # Step 2: Gate 信息
  gate_status: go | conditional-go | no-go | unknown
  gate_overall_score: <数值>
  unresolved_p0_blockers: 0           # P0 blocker 数（影响 blocker_score）
  unresolved_p1_blockers: 2

  # Step 3: 确认 N090 PRD 仍然有效
  prd_version: "n090.prd.v2"
  prd_last_modified: "2026-04-20"
  prd_refresh_required: false         # 若 N100 发现重大缺陷导致 PRD 需修订 → true

  # Step 4: GAP 回写清单接收
  pending_gap_writebacks:             # 来自 030.cross_node_trace.remediation_plan
    - action: "Create GAP-013 in 023"
    - action: "Update GAP-007 priority to blocker"
```

---

## 4. N100 issue 到 N110 产物的传递规则

### 4.1 open_questions[] 的来源与格式

031 的 `open_questions[]` 汇总自以下来源（按优先级）：

```
Priority P0（必须在 formal_mode 下解决）：
  来源 1: 029 的 pending_items[] 中 blocking=true 的条目
  来源 2: 030 的 top_blockers（severity=blocker）
  来源 3: 027 的 confirmed conflict（type=blocker）

Priority P1（conditional_mode 下必须解决）：
  来源 4: 025 的 D3/D6 维度的 major finding
  来源 5: 028 的 P0/P1 vulnerability findings

Priority P2（可在交接后跟踪）：
  来源 6: 024 的 Q-XXX（high urgency_score）
  来源 7: cross_node_trace.remediation_plan（GAP 回写动作）
```

### 4.2 N100 issue 在 031 中的继承格式

```yaml
open_questions:
  - question_id: Q-031-001
    source_type: n100_issue            # n100_issue | n090_gap | n090_q | n100_remediation
    source_id: N100-029-003            # 原始 N100 issue ID
    source_skill: "029"
    original_finding: "支付超时 pending item 缺少 deferred_to_version"
    blocking: true
    resolution_owner: PM
    deadline_proximity: before_sprint_start
    status: open                       # open | in_progress | resolved
    resolved_at: null

  - question_id: Q-031-002
    source_type: n100_remediation
    source_id: GAP-013                 # 需要创建的 GAP
    action_required: "在 023 中创建 GAP-013"
    owner: tech_lead
    blocking: false
    status: open
```

### 4.3 handover_readiness_score 与 N100 的关联

031 的 `blocker_score` 直接来自 N100 的 unresolved blockers：

```
blocker_score = 100 - (
  n100_unresolved_p0_blockers × 30 +
  n100_unresolved_p1_blockers × 10 +
  open_questions_blocking × 5          # 031 自身的 open_questions blocking=true
)
```

---

## 5. N111 并行流程 / N110 Sibling Execution Protocol

031 完成后触发 N110 兄弟 skill：

```
031（handover-package）完成
  ↓
  ├─ 032（acceptance-criteria）：消费 031 + 026 executability + 025 D3 的联合输入
  │   规则：032 的 AC 必须覆盖 030 top_blockers 中被标为 acceptance_coverage_gap 的条目
  │
  ├─ 如有变更 → 033（change-impact）→ 034（change-sync）
  │   触发条件：N100 发现的 new_gap（new_gap: true）触发 PRD 修订后
  │
  └─ 如有工程反馈 → 035（engineering-feedback-return）
      触发条件：工程侧对 031/032 输出提出质疑或变更请求时

032 与 031 的强耦合规则：
  - 032 的每条 AC 必须可回溯到 031 handover package 中的 FT-* 或 REQ-*
  - 031 的 acceptance_readiness 字段 = (032 AC 数量 / 030 top_blockers 需要 AC 的数量)
```

---

## 6. 交接完成信号 / Handoff Completion Signal

031 完成后，输出 N100→N110 汇总：

```yaml
n100_to_n110_handoff:
  gate_inherited: conditional-go
  execution_mode: formal_mode
  blockers_inherited: 5               # 从 N100 继承的 blocking open_questions 数
  blockers_resolved_before_handoff: 2 # 031 生成前已解决的
  blockers_in_open_questions: 3       # 仍需跟踪的
  gap_writebacks_pending: 2           # 需要回写到 023 的 GAP 创建动作
  handover_readiness_score: 78.5
  pass_readiness: conditional_ready
  n110_siblings_triggered: [032]      # 已触发的兄弟 skill
  ready_for_engineering: true         # pass_readiness ∈ {ready, conditional_ready}
```
