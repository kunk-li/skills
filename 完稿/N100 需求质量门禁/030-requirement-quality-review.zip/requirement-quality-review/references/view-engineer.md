# Engineer View Template

## 目标
将 N100 gate 结论翻译为工程视角的"可行动清单"。

## 聚焦维度
- 026 executability_score(尤其 engineering perspective)
- 026 non_executable_reasons,尤其:
  - NE-02 underspecified
  - NE-04 dependency_missing
  - NE-06 technology_gap
- 028 vulnerability(engineering 维度)
- 025 D2 inputs_outputs + D5 exception_handling

## 输出结构

```
# 工程视角摘要 · N100 Gate {gate_session_id}

## 可以现在启动的工作
- [list of executable requirements,可直接进入编码]
- [list of conditionally_executable,可进入设计但编码待定]

## 阻塞的工作
| issue_id | object | reason_code | 解除条件 | estimated_unblock_effort |
|---|---|---|---|---|
| ... | ... | NE-04 | 等银行接口文档 | 依赖方 ETA |

## 技术预研项
- [list of NE-06 technology_gap items]

## 设计前必须回答的问题
- [list of NE-02 underspecified items]

## 对架构的影响
- [concurrency concerns from 028]
- [data consistency concerns]
- [dependency topology changes]

## 建议的工程动作(优先级)
1. ...
2. ...

## 与其他角色的协同需求
- 需 PM 决议:{count} 项
- 需 DBA 支持:{count} 项
- 需 security 评审:{count} 项
```

## 使用原则
- 不重复输出已在完整 Gate Report 中的原文
- 聚焦"工程视角此刻需要什么",不做全面叙事
- 按"能做"/"不能做"/"待研"三段式组织,便于工程 standup 直接引用
