# Output Template

Use this lighter template when the user wants a shorter narrative summary.

## 1. mode and input inventory
## 2. final gate decision
## 3. rollup rationale
## 4. readiness matrix or simplified equivalent
## 5. top blockers
## 6. transition plan
## 7. next-step recommendation
