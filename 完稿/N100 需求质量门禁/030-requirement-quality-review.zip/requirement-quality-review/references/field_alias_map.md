# Field Alias Map

Use this map only during aggregation. Do not force upstream skills to rename their native fields.

## action_to_take
- `025.recommendation`
- `026.recommendation`
- `027.resolution_suggestion`
- `028.mitigation`
- `029.question + why_unresolved` (compose into an action-oriented prompt when needed)

## evidence
- `025.evidence`
- `026.evidence`
- `027.evidence_a + evidence_b`
- `028.evidence`
- `029.why_unresolved` plus direct quote if present

## artifact
- `025.artifact`
- `026.artifact`
- `027.artifact_a + artifact_b`
- `028.artifact`
- `029.artifact`

## finding
- `025.finding`
- `026.finding`
- `027.finding`
- `028.finding`
- `029.question` normalized into pending finding wording

## severity
- Preserve original severity when present.
- If an upstream source has no explicit severity, derive conservatively from blocking / timing / impact wording and note that the severity was normalized by 030.
