# Cross-Node Bridge Contract / 跨节点 ID 桥接契约

本文件定义 N080 → N090 → N100 的 ID 命名空间如何在各节点输出中保持可追溯。

---

## 1. N080 → N090 桥接规则

### 1.1 PRD 章节中的 upstream_refs

每个 PRD 章节（PRD-01..PRD-16）的 section metadata 中需增加 `upstream_refs[]` 字段，记录该章节直接引用的 N080 产物：

```yaml
sections:
  - section_id: PRD-05
    section_title: 业务流程 / 页面或能力概览
    status: confirmed
    upstream_refs:
      - ref_type: page
        ref_id: P-ORDER-01
        ref_skill: "018"
        relationship: primary_source    # primary_source / supporting / contradicted
      - ref_type: feature
        ref_id: FT-ORDER-01-001
        ref_skill: "018"
        relationship: primary_source
      - ref_type: action
        ref_id: ACT-ORDER-P01-003
        ref_skill: "020"
        relationship: supporting
```

### 1.2 N080 ID 在 PRD 正文中的嵌入方式

当 N080 产物直接成为 PRD 某功能描述的来源时：

```markdown
## 6. 功能需求清单 [PRD-06]

| requirement_id | description | upstream_ref | source_skill |
|---|---|---|---|
| REQ-ORDER-001 | 用户可以提交包含多个商品的订单 | FT-ORDER-01-001 | 018 |
| REQ-ORDER-002 | 系统自动计算订单总价 | FT-ORDER-01-002 | 018 |
```

**规则**：
- N080 ID 不得被重命名为 PRD 内部 ID，只能作为 `upstream_ref` 附加
- 若原型中有对应的 N080 条目但 PRD 未引用 → 记为 `coverage_gap`，在 PRD-16 附录中列出
- N080 ID 与 N070 ID 均可同时出现在 upstream_refs 中，按 ref_type 区分

### 1.3 GAP 的溯源字段

023 的 gap_list 中，每个 GAP-XXX 必须记录它是针对哪个 PRD-XX 的：

```yaml
- gap_id: GAP-003
  gap_type: missing_business_rule
  related_prd_sections: [PRD-07]
  upstream_refs:
    - ref_id: FT-ORDER-01-003    # 若 gap 源自原型但 PRD 未覆盖
      ref_skill: "018"
  finding: "......"
```

---

## 2. N090 → N100 桥接规则

### 2.1 N100 issue 与 GAP-XXX 的映射

N100（025-029）发现的问题使用 `issue_id`（如 `N100-025-001`），与 N090 的 `GAP-XXX` 体系不同。当 N100 发现的问题直接对应已知 GAP 时，使用 `source_gap_id` 字段建立链接：

```yaml
# 025 / 026 / 027 / 028 / 029 的 issue 格式扩展
- issue_id: N100-025-003
  issue_category: completeness
  finding: "PRD-07 缺少异常路径处理规则"
  source_gap_id: GAP-006     # 若此 issue 对应已知 GAP，填写；否则为 null
  source_gap_skill: "023"    # 产出该 GAP 的 skill
  new_gap: false             # false = 已在 023 中记录; true = N100 新发现
```

### 2.2 N100 新发现 issue 的 GAP 回写规则

当 `new_gap: true` 时（N100 发现了 N090 没有捕获到的问题）：

```
回写触发条件：
  issue 的 severity ∈ {blocker, major}
  AND source_gap_id = null（确认不是已有 GAP 的重复）

回写动作（由 030 在 rollup_trace 中记录，需人工执行）：
  1. 在 023 的 gap_list 中创建新 GAP 条目
     gap_type = <按 gap-taxonomy.md 12 类分类>
     gap_source = "n100_escalation"
     source_issue_id = <N100 issue_id>
  2. 在 030 输出的 remediation_plan 中列出：
     "Create GAP-XXX in 023 for issue N100-025-003"
  3. 031 的 open_questions[] 中追加该 GAP（若已进入 N110 阶段）
```

### 2.3 030 输出中的跨节点追溯段

030 的输出（output-template-v2.md）section 3（rollup）应增加：

```yaml
cross_node_trace:
  n090_gap_coverage:
    total_gaps: 12           # 023 输出的 GAP 总数
    covered_by_n100: 9      # N100 对应处理的 GAP 数
    uncovered_gaps: [GAP-002, GAP-007, GAP-011]  # N100 未直接覆盖的 GAP
    new_issues_from_n100: 2  # N100 新发现、N090 未记录的 issue 数
  remediation_plan:
    - action: "Create GAP-013 in 023 for issue N100-028-001 (compliance_vulnerability)"
    - action: "Update GAP-007 priority to blocker based on N100-027-003"
```

---

## 3. N100 → N110 桥接规则（补充）

此部分已在 `031/references/readiness-scoring.md` 中定义（gate_status → execution_mode 映射）。

本契约补充：当 N100 的 `open_questions[]` 中有未解决项时，031 的 `open_questions[]` 必须继承这些项（不得丢失），并在 `handover_readiness_breakdown.blocker_score` 中相应扣分。

```yaml
# 031 open_questions[] 中继承自 N100 的条目格式
- question_id: Q-031-INH-001
  inherited_from: N100-029-003      # 来源的 N100 issue_id
  inherited_at: "2026-04-24"
  blocking: true
  resolution_owner: PM
  deadline_proximity: before_sprint_start
```

---

## 4. 适用范围

本契约文件适用于以下 skill 的输出：
- 022（prd-generation）：PRD 章节中的 upstream_refs
- 023（prd-completion）：GAP 条目中的 upstream_refs
- 025–029（N100 各 skill）：issue 中的 source_gap_id 字段
- 030（quality-review）：rollup 中的 cross_node_trace 段
- 031（handover）：open_questions 中继承自 N100 的条目

每个适用 skill 应在其 SKILL.md 的 Key references 中引用本文件。
