# 0. artifact contract header
- `artifact_type`: `n100.quality-review`
- `schema_version`: `2.1.1`
- `producer_skill`: `requirement-quality-review`
- `consumer_nodes`: `N110`, `N370`, `N380`
- `workflow_alias`: `需求质量审查单.md`
- `secondary_alias`: `N100_Gate_Report.md`
- `produced_event_name`: `produced.n100.quality-review`
- `issue_namespace`: default `N100`
- `parse_cache_ref`: nullable
- `decision_ref`: nullable
- `re_gate_session_id`: nullable

# 1. document purpose and input inventory
- mode: `Standalone Mode | Partial Mode (X/5 inputs) | Full Mode`
- objective:
- inputs used:
- missing upstream inputs:
- confidence:

# 2. final gate decision
- gate: `no-go | conditional-go | go`
- rationale:
- maximum readiness stage:
- overall_score:

# 3. rollup rule and trace
- algorithm:
- weights:
- thresholds:
- blocker logic summary:
- category statistics:

# 4. overall quality assessment / readiness matrix
| dimension | status | evidence | blocking issue ids |
|---|---|---|---|
| scope stability |  |  |  |
| source of truth |  |  |  |
| owner clarity |  |  |  |
| state orchestration |  |  |  |
| permissions and approvals |  |  |  |
| failure handling |  |  |  |
| audit and traceability |  |  |  |
| acceptance-input readiness |  |  |  |

# 5. top blockers
| issue_id | issue_category | object | finding | impact | recommendation |
|---|---|---|---|---|---|

# 6. transition plan
- to_go_conditions:
- estimated_effort:
- earliest_retest_date:
- expected_result:

# 7. next-step recommendation
- immediate next step:
- who should act:
- what can proceed now:
- what must wait:

# 8. version trend (optional)
| version | score | gate | note |
|---|---:|---|---|

# 9. benchmark (optional)
- industry:
- similar_projects_score_range:
- percentile:

# 10. stakeholder views (optional)
- engineer_view:
- tester_view:
- compliance_view:
- pm_view:

# 11. re-gate delta (optional)
- closed_since_last:
- still_open:
- new_in_this_scan:

# 12. downstream generation rules
- handover mode allowed:
- acceptance mode allowed:
- change-analysis mode allowed:
- change-sync mode allowed:
- engineering-feedback mode allowed:

# 13. guardrail statement
- this artifact communicates gate and transition intent only
- it does not replace N110 handover generation
- it does not replace N180 task planning
- it does not replace N370 routing or platform execution

# 14. overrides
| override_id | dimension | reason | approved_by | expiry | documented_risk | mitigation | review_date |
|---|---|---|---|---|---|---|---|

# shared references
- `_shared/parse-cache-contract.md`
- `_shared/cross-skill-disambiguation.md`
