# Example IO

## Example A: Full Mode · fintech profile · conditional-go 判定

### Input (5 specialized outputs + industry_profile)

```yaml
completeness_result:  {overall_score: 82, p0: 0, p1: 3, d3_score: 58}
executability_result: {overall_score: 78, not_exec: 2, cond_exec: 10}
conflict_result:      {overall_score: 95, confirmed: 0, potential: 2}
vulnerability_result: {overall_score: 72, p0_compliance: 0, p1: 3, p2: 5}
pending_result:       {overall_score: 84, blocking_p0: 1, raised: 5}
industry_profile:     fintech
```

### Output: 需求质量审查单.md(key sections)

```
# N100 Gate Report · rgs_20260422_001

## 1. Gate 结论
- **gate**: conditional-go
- **overall_score**: 81
- **confidence**: high (Full Mode + 5/5 inputs)
- **maximum_readiness_stage**: test_prep_with_constraints

## 2. Rollup trace

algorithm: weighted_max_severity
weights:
  completeness: 0.25, executability: 0.20, conflict: 0.25,
  vulnerability: 0.20, pending: 0.10
industry_profile: fintech
industry_adjustment_factor: 0.95

sub_scores:
  completeness: {score: 82, p0: 0, p1: 3, dims_below_60: [D3]}
  executability: {score: 78, not_exec: 2, ne_04_count: 1}
  conflict: {score: 95, confirmed: 0, potential: 2}
  vulnerability: {score: 72, p0_compliance: 0, p1_count: 3, by_dim_min: to_engineering=72}
  vulnerability_fintech_adjustment: "compliance × 2 applied(当前无 p0_compliance,无实际扣分)"
  pending: {score: 84, blocking_p0: 1(CHECK-PEND-PRD-002)}

formula_trace:
  raw = 0.25 × 82 + 0.20 × 78 + 0.25 × 95 + 0.20 × 72 + 0.10 × 84
      = 20.50 + 15.60 + 23.75 + 14.40 + 8.40
      = 82.65
  with_industry = 82.65 × 0.95 = 78.52
  # 注:fintech factor 在 028 内部已部分反映,此处保守降级
  # 最终取整 + hard rule 检查后定为 81

hard_rule_triggered: null
overrides_applied: []
overrides_expiring_within_7_days: []
duplicate_risk_count: 0

## 3. Top blockers

| issue_id | skill | object | finding | recommendation |
|---|---|---|---|---|
| CHECK-PEND-PRD-002 | 029 | SKU 迁移方案 | TBD,阻塞估时 | 本周决议 |
| CHECK-COMP-ORDER-007 | 025 | 大额订单 AC 缺失 | blocker | 补 AC,0.5pd |
| (来自 028 的 p1 合规) | 028 | 审计日志保留 | p1 | 本迭代补 |

## 4. Transition plan

to_go_conditions:
  - COND-001: 关闭 CHECK-PEND-PRD-002(SKU 迁移方案决议), 1d, manual
  - COND-002: 补齐 3 条 AC(025 D3 < 60), 1pd, automated check
  - COND-003: 关闭 3 条 P1 vulnerability, 2pd, automated check
  - COND-004: 澄清 2 条 potential conflict(027), 0.5d, manual

estimated_effort: 5 person-days
earliest_retest_date: 2026-04-28
expected_result: go

## 5. 四视图摘要(详情见 view-* 文件)
- engineer_view: NE-04 依赖缺失 1 条,幂等设计 1 条
- tester_view: D3 < 60,需补 3 条 AC
- compliance_view: 0 p0 合规漏洞,3 条 p1 待修
- pm_view: 2 potential conflict,5 pending items
```

## Example B: Partial Mode (2/5 inputs) · no-go 判定

### Input
仅有 025 completeness_result 和 029 pending_result,其他 3 个未运行。

### Output (关键段)

```
# N100 Gate Report

## 1. Gate 结论
- **gate**: no-go
- **overall_score**: 不计算(样本不足)
- **confidence**: low (Partial Mode 2/5)

## 2. 判定依据
触发 hard rule #4: completeness_score < 50(本例为 42)
- D3 acceptance_criteria = 30(4 条核心需求无 AC)
- D5 exception_handling = 35

Partial Mode 下即便其他技能未运行,completeness < 50 本身已是阻塞。

## 3. 建议行动
1. 立即补齐 AC(pm_zhang,2pd)
2. 运行 026 executability + 027 conflict(1 小时)
3. 完成后重新 gate

earliest_retest_date: 2026-04-24
```

## Example C: Hard rule veto · no-go 判定

### Input
Full Mode, overall = 83 但存在 1 条 confirmed blocker conflict。

### Output (关键段)

```
- gate: no-go(hard rule veto)
- overall_score: 83(仅供趋势)
- hard_rule_triggered: 
    rule_1_confirmed_blocker_conflict: 
      issue_id: CHECK-CONF-APPR-002
      summary: 一级审批人权限与规则定义冲突
- 说明:分数达标但 hard rule 触发 → 强制 no-go
  必须在重测前解决 CHECK-CONF-APPR-002
```
