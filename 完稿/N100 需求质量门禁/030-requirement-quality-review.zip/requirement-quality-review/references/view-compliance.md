# Compliance View Template

## 聚焦维度
- 028 vulnerability 的 `compliance` 子维度
- 025 D6 security_compliance 与 D7 operational(审计/告警)
- 025 D8 traceability
- 任何带 `regulator` threat_actor 的 vuln
- Override 中的 compliance 类豁免

## 输出结构

```
# 合规视角摘要 · N100 Gate {gate_session_id}

## 合规风险总览
- P0 compliance vulnerability: {count}
- P1 compliance vulnerability: {count}
- 已接受(accepted,有签字): {count}
- 待修复: {count}

## 审计覆盖度
- 关键业务操作有审计要求: {n}
- 审计设计已完整: {m}({m/n × 100}%)
- 审计缺失位置:
  - [list,对应 025 D6 findings]

## 数据保护
- 含 PII/PHI/PCI 字段的功能: {count}
- 数据分类已明确: {m}
- 保留周期已定义: {k}

## 合规映射(按法规)
| 法规 | 相关要求 | 满足状态 | 缺口 |
|---|---|---|---|
| GDPR / PIPL / 个保法 | 用户数据删除权 | 部分 | 缺软删除 + 彻底删除 SOP |
| SOX / 内控 | 审批留痕 | 完整 | — |
| (行业特定) | ... | ... | ... |

## Override 审查(compliance 类)
| override_id | finding | expiry | 风险说明 | 下次复查 |
|---|---|---|---|---|
| OVR-... | ... | ... | ... | ... |

## 阻塞放行的合规项
1. ...

## 建议的合规动作
1. 本周内: ...
2. 本迭代: ...
3. 下版本前: ...

## 外部沟通建议
- 是否需要向 DPO / legal 披露:{yes/no + 理由}
- 是否需要向监管预沟通:{yes/no + 理由}
```

## 使用原则
- 优先暴露 P0 compliance vuln,哪怕总分高
- 明确列出每条 override 的到期日,合规视角对过期零容忍
- 与法规条款映射,便于 DPO / legal 直接使用
