# PM View Template

## 聚焦维度
- 027 confirmed + potential conflicts(影响范围判断)
- 029 pending items,尤其 decision_pending
- 030 transition_plan
- 整体 gate 结论与 earliest_retest_date

## 输出结构

```
# PM 视角摘要 · N100 Gate {gate_session_id}

## 一句话结论
Gate = {gate}。{overall_score}/100。
{n} 个阻塞项需本周决议,预计 {effort} 后可重测,目标 {expected_result}。

## 我现在最需要决定的事(Top 3)
1. [highest severity pending decision,含 owner 与决议窗口]
2. ...
3. ...

## 跨团队需要协调的事
- 需架构侧决议:{count} 项
- 需设计侧补齐:{count} 项
- 需运营侧配合:{count} 项
- 需安全侧评估:{count} 项

## 范围风险
- Potential conflicts(可能导致范围变更): {count}
- Deferred 到下版本: {count}
- Out of scope 但用户提出: {count}

## 时间线
- 本次 gate: {current_gate_result}
- 预计重测日: {earliest_retest_date}
- 若重测通过,最早可进入开发: {date}
- 若继续 no-go,影响预期上线: {date}

## 资源诉求
- 本次补齐需 {effort} pd
- 建议优先分配: {owner_candidates}

## 不用我关心但需要知晓的
- 编码层面风险 {count} 条(详见 engineer_view)
- 测试准备度 {count}(详见 tester_view)
- 合规风险 {count}(详见 compliance_view)

## 给上级的一句话汇报
"{gate} · {overall_score}/100 · {main_blocker_summary} · 预计 {date} 可推进"
```

## 使用原则
- PM 只看 3 类信息:我要决定什么 / 我要协调什么 / 什么时候能推进
- 不暴露工程细节,但明确告诉 PM 工程/测试/合规侧"还有别的事正在处理"
- "给上级的一句话" 必须可直接复制到邮件/汇报
