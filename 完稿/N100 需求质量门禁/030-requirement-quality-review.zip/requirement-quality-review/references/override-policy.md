# Override / Waiver Policy

## 定义
override(或称 waiver)是允许某个本应阻塞的 finding **有条件放行**的显式决策。
override 不等于忽略——它是一种"承认风险 + 限期复查 + 责任落地"的机制。

## 允许的 override 对象

| 对象类型 | 可 override 条件 |
|---|---|
| 完整性 blocker(025) | D4/D5/D7 类可 override;D1/D3/D6/D8 原则上不可 |
| 可执行性 blocker(026) | NE-05 out_of_scope / NE-07 resource_insufficient 可 override |
| 冲突 confirmed(027) | 原则上不允许 override;`naming` kind 的 minor 例外 |
| 漏洞 p0(028) | 仅 `engineering` 维度可 override;`compliance` 维度不可 |
| 未决项 blocker(029) | 可 override 为 deferred + 明确下版本 |

## Override 字段契约

每条 override 必须包含:

```yaml
override_id: "OVR-{yyyymmdd}-{nnn}"    # 唯一,按日期流水
issue_id: string                        # 被 override 的 finding
dimension: enum[completeness, executability, conflict, vulnerability, pending]
sub_dimension: string | null            # 如 D5 / NE-05 / permission / p1_business
reason: string                          # 业务理由,≥ 20 字
approved_by: string                     # 签字人(必填,auditable identity)
approved_role: enum[pm_director, tech_director, compliance_officer, cto, exec]
approved_at: iso8601
expiry: date                            # 必填,最长 90 天
review_date: date                       # 必填,expiry 前至少 7 天
documented_risk: string                 # 明确说明放行带来的风险
mitigation: string                      # 临时缓解措施
follow_up_skill: string | null          # 后续由哪个技能复查(如 N310)
```

## 失效规则

| 事件 | 结果 |
|---|---|
| 当前日期 > expiry | override 自动失效,原 finding 重新计入 gate |
| 当前日期 = review_date | 030 在下次运行时触发提醒,但不失效 |
| `approved_by` 为空或格式错误 | override 立即无效,作为未放行处理 |
| `documented_risk` 或 `mitigation` 为空 | override 立即无效 |
| baseline 发生变更(cache_key 变) | override 保留但需人工确认是否仍适用 |

## Gate 决策中的作用

计算 gate 时:
1. 先加载所有未失效 overrides
2. 对匹配的 finding,其 severity **临时降一级**(blocker → major → minor → note)
3. 若临时降级后仍阻塞,按正常逻辑处理
4. 在 rollup_trace 中显式记录 `overrides_applied: [list]`
5. `overrides_expiring_within_7_days: [list]` 必须出现在 030 输出

## 审计约束

- override 记录不可删除,只能被 `revoked_by` + `revoked_at` 标记作废
- 同一 finding 不可 override 超过 2 次(第 3 次必须升级到架构评审)
- `compliance_officer` 签字的 override 必须同时抄送 N390 治理节点
- override 的 `documented_risk` 作为风险资产进入组织风险库

## 禁止事项

1. 不得用 override 绕过 hard rule veto(confirmed blocker conflict / 
   p0 compliance vuln 不可 override)
2. 不得用 override 批量放行(单次 gate 最多 override 3 条)
3. 不得用 override 替代 transition_plan(override 是例外,transition_plan 是正道)
