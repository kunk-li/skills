# Tester View Template

## 聚焦维度
- 025 D3 acceptance_criteria 得分
- 025 D5 exception_handling 得分
- 026 test perspective score
- 028 vulnerability 中标注 verification_method 的条目

## 输出结构

```
# 测试视角摘要 · N100 Gate {gate_session_id}

## 当前可测性评分
- D3 acceptance_criteria: {score} / 100
- test perspective executability: {score} / 100

## AC 完整性
- 总需求数: {n}
- 已有完整 AC: {m}({m/n × 100}%)
- AC 缺失的需求(blocker):
  - REQ-xxx-001: 大额订单自动拦截(推荐 AC: given-when-then 句式)
  - ...

## 负路径覆盖
- 已定义失败/异常路径: {count}
- 未定义失败路径的流程:
  - REQ-xxx-002: 缺失拒绝路径
  - REQ-xxx-003: 缺失超时路径

## 权限测试边界
- 已明确权限边界的功能: {count}
- 权限模糊的功能: {count}(需 pm 澄清)

## 并发/幂等测试点(来自 028)
- {issue_id}: 单点登录并发测试
- {issue_id}: 重复提交幂等测试

## 验证方法一览(verification_method)
| vuln id | 推荐测试类型 | 估时 |
|---|---|---|
| CHECK-VULN-AUTH-001 | 并发 fuzz 测试 | 1pd |
| ... | ... | ... |

## 测试进入条件检查
- [ ] 所有 blocker AC 已补齐
- [ ] 所有 p0 vulnerability 已有 verification_method
- [ ] 所有关键权限边界已澄清
- [ ] 测试环境依赖已就绪

## 建议的测试动作(优先级)
1. ...
```

## 使用原则
- 以"能否出完整 test plan"为核心判据
- 不复述 Gate Report 的总分
- 着重暴露"看不见 AC 就写不出测试用例"的风险
