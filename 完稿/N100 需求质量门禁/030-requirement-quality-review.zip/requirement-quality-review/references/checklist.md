# Checklist

- Is the selected mode explicit and correct?
- Is the gate decision supported by visible rollup logic?
- Are blockers surfaced separately from minor issues?
- Is there a transition plan when the result is not `go`?
- Is confidence honest about input completeness?
- Are specialized upstream findings reused rather than diluted?
- Does the report still work in standalone mode?
