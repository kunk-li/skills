# Delivery Checklist

- Is omission separated from contradiction?
- Does every confirmed conflict show both sides of the evidence?
- Are conflict kind, status, and scope all present?
- Are potential conflicts kept separate from confirmed blockers?
- Do resolution hints help the reviewer move forward?
- Is the result still usable without other skills?
- Are shared fields preserved for aggregation?
