# Orchestration

## Standalone path
1. Compare the relevant artifacts or versions directly.
2. Separate confirmed and potential conflicts.
3. Provide resolution hints and owners.

## Combined path
1. Run this skill when the team needs a precise contradiction signal.
2. Combine with completeness, executability, vulnerability, and pending-item skills for broader gating.
3. Preserve evidence pairs and conflict status so 030 does not flatten them.
4. Send confirmed `resource`, `permission`, and `temporal` conflicts to N170 as concurrency, permission, and sequencing design alerts.
5. Send `conflict_score` and `versioning` conflicts to N260 as one of the aggregated gate dimensions.
