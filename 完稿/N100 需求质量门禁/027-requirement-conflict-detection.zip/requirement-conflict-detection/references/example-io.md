# Example IO

## Example: 审批时限与人工审核规则的 triple temporal conflict

### Input
- A 文档:"审批操作应在 72 小时内完成"
- B 文档:"夜间(22:00-06:00)禁止执行审批操作"  
- C 文档:"每笔审批需两级签字按顺序完成"

### Output: 需求矛盾问题单.csv

```
issue_id,issue_category,conflict_kind,conflict_status,conflict_scope,severity,severity_matrix.overall,artifact_a,artifact_b,object,evidence_a,evidence_b,finding,impact,resolution_hints,owner_candidate,needs_decision,blocking
CHECK-CONF-APPR-001,conflict,temporal,potential,triple,major,major,A规则文档 §2.1,B规则文档 §4.3,审批时序,"审批操作应在 72 小时内完成","夜间(22:00-06:00)禁止执行审批操作","三份规则联合约束下,某些周末提交的审批物理上不可能在 72h + 非夜间 + 两级顺序完成",SLA 与合规规则相互阻塞,三选一决策:scope_differently(不同审批类型不同 SLA)/ prioritize(SLA 优先,允许夜间特批)/ escalate(架构评审),process_owner,true,false
CHECK-CONF-APPR-002,conflict,permission,confirmed,pair,blocker,blocker,A规则文档 §2.1,权限矩阵.csv,一级审批人,"A文档:'一级审批人为 role=supervisor'","权限矩阵:'supervisor 无 approve 权限,只有 review 权限'",权限定义与审批规则冲突,审批流程无法启动,choose_one:修正权限矩阵 OR 修正 A 文档规则,permission_admin,true,true
```

### 关键点
- CHECK-001 是 **triple** scope(三个文档的联合约束才构成矛盾),
  在仅 pair 比对时不会发现;deep_mode 才能检测
- CHECK-001 的 status 为 potential 是因为"某些周末"的 evidence 需要业务数据确认
- CHECK-002 是 confirmed blocker,来自同源 triangulation(A + 权限矩阵)
- resolution_hints 至少给 2 个选项,不擅自下结论
