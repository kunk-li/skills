# Scoring Rubric

## Excellent
- clear confirmed versus potential separation
- conflict kind and scope add real routing value
- resolution hints are practical
- standalone and combined use both work well

## Good
- strong evidence for confirmed conflicts
- most potential items handled conservatively

## Needs Work
- omissions mislabeled as conflicts
- no clear routing for decision owners

## Poor
- one-sided evidence only
- no conflict status
- generic prose instead of review-ready conflict tables

## Numeric formula

### Score formula

  conflict_score = 100 - (
    confirmed_blocker × 30 +
    confirmed_major × 15 +
    confirmed_minor × 5 +
    potential_major × 5 +
    potential_minor × 2
  )
  clip to [0, 100]

### Hard rules (override score)

1. 任一 `confirmed` + `blocker` severity → conflict_score ≤ 40
   无论其他 finding 数量如何,此规则优先
2. `versioning` kind 的 confirmed conflict 存在 → 同时触发 030 的 
   `hard_rule_veto`,gate 直接降为 no-go

### Kind-specific 权重调整

某些 conflict kind 对下游影响更大,建议在严重性评估时倾斜:

| kind | severity 倾向 | 下游影响节点 |
|---|---|---|
| logical | 保持 | — |
| temporal | 若涉及 deadline / SLA → +1 级 | N240 回归编排 |
| precedence | 保持 | — |
| resource | 保持 | N170 并发设计 |
| permission | 默认至少 major | N170 权限设计 + 028 |
| naming | 默认 minor(除非公开 API) | — |
| semantic | 默认至少 major | N260 质量门禁 |
| cardinality | 保持 | N160 数据模型 |
| versioning | 默认 blocker | 030 hard veto |

### confirmed vs potential 判别公式

  evidence_strength = (
    direct_quote_a_exists ? 1 : 0 +
    direct_quote_b_exists ? 1 : 0 +
    ref_id_a_verifiable ? 1 : 0 +
    ref_id_b_verifiable ? 1 : 0 +
    context_explicit ? 1 : 0
  )

  if evidence_strength >= 4:  status = confirmed
  elif evidence_strength >= 2: status = potential
  else: do not emit  # 证据不足不上报
