# Conflict Taxonomy

## logical
Two statements cannot both be true.

## temporal
Timing, sequencing, or deadline logic makes the combined behavior impossible or inconsistent.

## precedence
Two rules claim priority without a tie-break rule.

## resource
Multiple actions or rules compete for exclusive capacity or ownership.

## permission
Allow and deny boundaries expand or shrink one another inconsistently.

## naming
Same name, different meaning.

## semantic
Different names, same intended concept or conflicting definitions.

## cardinality
One-to-one, one-to-many, or multiplicity definitions do not match.

## versioning
Version changes introduce unresolved migration or coexistence ambiguity.
