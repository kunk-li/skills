# Conflict Taxonomy

## logical
Two statements cannot both be true.

## temporal
Timing, sequencing, or deadline logic makes the combined behavior impossible or inconsistent.

## precedence
Two rules claim priority without a tie-break rule.

## resource
Multiple actions or rules compete for exclusive capacity or ownership.

## permission
Allow and deny boundaries expand or shrink one another inconsistently.

## naming
Same name, different meaning.

## semantic
Different names, same intended concept or conflicting definitions.

## cardinality
One-to-one, one-to-many, or multiplicity definitions do not match.

## versioning
Version changes introduce unresolved migration or coexistence ambiguity.

---

## 判别边界说明 / Disambiguation Rules

以下 kind 之间边界容易混淆，使用前请先核对：

### `logical` vs `semantic`
- `logical`：两条陈述在同一语义下**不能同时成立**（数学矛盾）
- `semantic`：两个词/表达**意图相同但定义不同**，或定义相同但词不同
- 判断方式：如果把两条放在同一条件下，会产生逻辑不一致 → logical；如果只是命名混乱 → semantic

### `precedence` vs `logical`
- `precedence`：两条规则都可能成立，但**缺少优先级顺序**
- `logical`：两条规则**不可能同时成立**（互斥）
- 判断方式：如果同时应用会产生矛盾 → logical；如果同时应用会导致歧义而非矛盾 → precedence

### `resource` vs `precedence`
- `resource`：多个规则**竞争同一资源**（容量/所有权/锁）
- `precedence`：多个规则在**优先级上**冲突（不涉及资源竞争）
- 判断方式：是否存在一个具体的"资源/容量/对象"被多方争夺？有 → resource；无 → precedence

### `naming` vs `semantic`
- `naming`：**完全相同的名称**，但在不同上下文中指不同的东西
- `semantic`：**不同的名称**，但实际描述的是同一个概念；或定义范围的包含/交叉关系
- 判断方式：名字一样意思不同 → naming；名字不同意思相同或相近 → semantic

### `cardinality` vs `logical`
- `cardinality`：对同一关系的**数量关系**（1:1 vs 1:N）定义不一致
- `logical`：整个命题不可能同时成立
- 判断方式：如果改成"无限制数量"后矛盾消失 → cardinality；否则 → logical

---

## conflict_scope 决策规则 / Scope Selection Rules

```
Q1: 本次冲突涉及几个独立的需求条目（artifact_a, artifact_b, ...）？

  恰好 2 个 → scope = pair
  恰好 3 个 → scope = triple
  ≥ 4 个    → scope = multi
```

**补充规则：**
- 同一需求条目内部（字段 A 与字段 B 在同一 row 内）也计为 pair，因为有两个属性参与冲突。
- 若某个 rule 隐式引用了整个 domain 的所有条目（如"所有审批类需求"），且与另一条 rule 冲突，按实际影响到的最小子集计数（若无法枚举，标注 `scope = multi` 并说明 scope_note）。
- `triple` 和 `multi` 必须在 `evidence_a`/`evidence_b` 之外额外提供 `evidence_c[]` 列举每个参与方的证据。
- `multi` scope 冲突应考虑启用 `deep_mode` 进行完整分析。

---

## 严重度判定参考

| conflict_kind | 默认严重度下限 | 可升为 blocker 的条件 |
|---|---|---|
| `logical` | major | 影响核心业务流或合规 |
| `temporal` | major | 导致死锁或 SLA 不可达 |
| `precedence` | minor | 无 tie-break 导致不确定行为 |
| `resource` | major | 独占资源竞争 |
| `permission` | major | allow/deny 边界扩展到安全红线 |
| `naming` | minor | 跨多个 L2 或影响 API 契约 |
| `semantic` | minor | 影响下游系统集成理解 |
| `cardinality` | major | 影响数据模型或 API 契约 |
| `versioning` | major | 迁移路径未定义 |
