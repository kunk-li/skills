# Output Template

When the result will be consumed by workflow v2, emit the machine-readable CSV artifact first and then the narrative summary.

## 0. artifact contract header
- `artifact_type`: `n100.conflict-detection`
- `schema_version`: `2.1.1`
- `producer_skill`: `requirement-conflict-detection`
- `consumer_nodes`: `N100`, `N110`, `N170`, `N260`, `N370`
- `workflow_alias`: `需求矛盾问题单.csv`
- `produced_event_name`: `produced.n100.conflict-detection`
- `issue_namespace`: default `N100`
- `parse_cache_ref`: nullable
- `decision_ref`: nullable
- `re_gate_session_id`: nullable

## 1. machine-readable artifact
Produce or simulate a CSV named `需求矛盾问题单.csv` with these columns in this exact order:
| issue_id | issue_category | issue_subtype | conflict_kind | conflict_status | conflict_scope | severity | severity_matrix.overall | artifact_a | artifact_b | object | evidence_a | evidence_b | finding | impact | resolution_hints | owner_candidate | needs_decision | blocking | parse_cache_ref | issue_namespace | decision_ref | re_gate_session_id |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## 2. document purpose and input inventory
- explain that this is a conflict report
- list the artifacts or versions compared
- state mode: `pair_mode | deep_mode | cross_version_check | re_gate_mode`

## 3. conflict summary
- count by `conflict_status`
- count by `conflict_kind`
- one-paragraph conclusion

## 4. confirmed conflict table
| issue_id | conflict_kind | conflict_scope | object | evidence_a | evidence_b | impact | resolution_hints |
|---|---|---|---|---|---|---|---|

## 5. potential conflicts and decision items
| issue_id | why not confirmed yet | owner_candidate | next decision needed |
|---|---|---|---|

## 6. version or migration conflicts
- include only when cross-version evidence exists

## 7. resolution path
- what must be unified now
- what may be deferred safely
- who should decide
