# Common Failure Modes

1. Treating a missing requirement as a conflict.
2. Confirming a conflict when the evidence only supports a question.
3. Ignoring triple or multi-condition interactions.
4. Reporting the clash without suggesting a resolution path.
5. Flattening all conflict kinds into one vague type.
