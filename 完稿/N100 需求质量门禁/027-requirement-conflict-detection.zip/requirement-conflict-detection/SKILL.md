---
name: requirement-conflict-detection
description: detect conflicts inside or across any document-oriented requirement baseline, including rules, timing, ownership, permissions, naming, semantics, dependencies, and version changes. use when the input is a prd, design baseline, contract-like specification, sop, policy, or structured requirement package and the user needs a standalone conflict report or a composable conflict signal for broader quality gating.
---
# requirement-conflict-detection

## Role
Detect genuine conflicts, not ordinary omissions.
This skill must work on any requirement-like baseline and must still be useful when used alone.

## Standalone and combined use
### Standalone
Produce a review-ready conflict report with confirmed conflicts, potential conflicts, and resolution hints.

### Combined
Expose a normalized conflict structure so 030 or reviewers can merge the result with other skills without losing conflict-specific meaning.

## Shared interoperability contract
When this skill is used with other requirement-review skills, keep the native specialty fields but also preserve these shared fields whenever the evidence supports them:
- `issue_id`
- `issue_category`
- `issue_subtype`
- `severity` = blocker / major / minor / note
- `severity_matrix.overall` plus any supported sub-dimensions
- `artifact`
- `object`
- `evidence`
- `finding`
- `impact`
- `owner_candidate`
- `needs_decision`
- `blocking`
- `related_issue_ids` when there is an obvious upstream or downstream link

Do not drop the skill-specific fields just to fit the shared schema. Keep both when useful.

## Light composition runtime contract
When this skill is run as part of a composed N100 review, carry these lightweight runtime fields whenever available:
- `parse_cache_ref`
- `issue_namespace` (default `N100`)
- `decision_ref`
- `re_gate_session_id`
- `produced_event_name`

Keep them nullable when the upstream workflow does not provide them. Do not invent values.

## Shared node-level references
When these bundled references are present, consult them before inventing local behavior:
- `_shared/parse-cache-contract.md` for cache lifecycle, hit/miss handling, and integrity fallback
- `_shared/cross-skill-disambiguation.md` for ownership boundaries, duplicate prevention, and `related_issue_ids` linkage

## Workflow v2 input aliases
Prefer the workflow names directly when they exist:
- `PRD.md`
- `需求结构树.md`
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`

Also accept equivalent analyst-friendly aliases such as requirement breakdown, business rules, state transition mapping, and permission matrix.

## Preferred inputs
Preferred package when available:
- `hub_requirement_breakdown.md`
- `hub_business_rules.md`
- `hub_state_transition_mapping.md`
- `hub_permission_matrix.md`

Fallback inputs may be any document pair or set that defines rules, states, authority, obligations, or versioned behavior.

## Conflict kinds
Use these enums:
- `logical`
- `temporal`
- `precedence`
- `resource`
- `permission`
- `naming`
- `semantic`
- `cardinality`
- `versioning`

## Conflict status
Use these lifecycle states:
- `confirmed`
- `potential`
- `false_positive`
- `resolved`

## Conflict scope
Use one of:
- `pair`
- `triple`
- `multi`

## Workflow v2 artifact contract
Declare this contract explicitly in the output header when the result is intended for workflow consumption:
- `artifact_type`: `n100.conflict-detection`
- `schema_version`: `2.1.1`
- `producer_skill`: `requirement-conflict-detection`
- `consumer_nodes`: `N100`, `N110`, `N170`, `N260`, `N370`
- `workflow_alias`: `需求矛盾问题单.csv`
- `produced_event_name`: `produced.n100.conflict-detection`
- `canonical_fields`: `issue_id`, `issue_category`, `issue_subtype`, `conflict_kind`, `conflict_status`, `conflict_scope`, `severity`, `severity_matrix.overall`, `artifact_a`, `artifact_b`, `object`, `evidence_a`, `evidence_b`, `finding`, `impact`, `resolution_hints`, `owner_candidate`, `needs_decision`, `blocking`, `parse_cache_ref`, `issue_namespace`, `decision_ref`, `re_gate_session_id`

## Output contract
Default to a dual output unless the user explicitly asks for only one representation:
1. a machine-readable CSV-first artifact aligned to workflow v2 and named `需求矛盾问题单.csv`
2. a concise Markdown summary that follows `references/output-template.md`

Each CSV row must include:
- `issue_id`
- `issue_category` = conflict
- `issue_subtype`
- `conflict_kind`
- `conflict_status`
- `conflict_scope`
- `severity`
- `severity_matrix.overall`
- `artifact_a`
- `artifact_b`
- `object`
- `evidence_a`
- `evidence_b`
- `finding`
- `impact`
- `resolution_hints[]`
- `owner_candidate`
- `needs_decision`
- `blocking`
- `parse_cache_ref`
- `issue_namespace`
- `decision_ref`
- `re_gate_session_id`

If the user only wants prose, keep the rows directly convertible into the same CSV columns.

## Resolution hints
Prefer one or more of:
- `choose_one`
- `merge`
- `scope_differently`
- `prioritize`
- `rename`
- `version_migrate`
- `escalate`
- `defer`

## Workflow
1. Extract confirmed facts by artifact before comparing across artifacts.
2. Separate omission from contradiction.
3. Detect pair conflicts first.
4. When the scenario meaning depends on joint constraints, test for triple or multi conflicts.
5. Mark weak-evidence items as `potential`, not `confirmed`.
6. Emit the workflow CSV rows first when workflow consumption is expected.
7. End with resolution hints and decision owners.

## Optional modes
- `pair_mode`: fast two-way comparison
- `deep_mode`: include triple and multi conflict reasoning
- `cross_version_check`: compare versions for versioning conflicts and migration gaps
- `graph_output`: add a conflict graph or Mermaid sketch when the relationship map helps
- `re_gate_mode`: compare against a prior issue set and mark closed_since_last / still_open / new_in_this_scan when such evidence exists

## Boundary rules
- Do not call a pure omission a conflict.
- Do not resolve conflicts by guessing intent.
- Do not mix conflict severity with vulnerability severity without explanation.
- Do not treat `potential` conflicts as confirmed blockers unless the evidence supports it.

## References
- `references/output-template.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/conflict-taxonomy.md`
