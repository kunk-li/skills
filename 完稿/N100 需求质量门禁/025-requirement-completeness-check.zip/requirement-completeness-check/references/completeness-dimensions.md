# Completeness Dimensions

## D1 functional_scope
What business scenarios and boundaries are included or excluded.

## D2 inputs_outputs
Required inputs, outputs, events, visible results, and data handoff points.

## D3 acceptance_criteria
Observable pass/fail conditions and testability.

## D4 non_functional
Performance, availability, maintainability, capacity, reliability, and similar quality attributes.

## D5 exception_handling
Failure paths, timeout behavior, retries, compensation, and rollback.

## D6 security_compliance
Authorization, audit expectation, data protection, segregation, and compliance controls.

## D7 operational
Deployment, monitoring, alerting, support handling, and rollback readiness.

## D8 traceability
Source references, ownership, decision trail, version trail, and downstream linkage.

---

## 维度适用决策树 / Dimension Application Decision Tree

```
对每条需求（REQ-*），判断哪些维度需要重点检查：

Q1: 需求是否定义了用户可感知的边界（in/out scope）？
    NO → D1（functional_scope）需要重点检查
    YES → D1 通过

Q2: 需求是否明确了所有输入/输出和关键数据交换点？
    NO → D2（inputs_outputs）需要重点检查
    YES → D2 通过

Q3: 需求是否有可验证的完成条件？
    NO → D3（acceptance_criteria）需要重点检查——通常是 P0 缺口
    YES → D3 通过

Q4: 需求是否涉及性能/可用性/容量等质量属性？
    YES 但未量化 → D4（non_functional）需要重点检查
    NO 或已量化 → D4 通过

Q5: 需求是否涉及失败路径、超时、幂等、补偿？
    YES 但未说明 → D5（exception_handling）需要重点检查
    NO 或已说明 → D5 通过

Q6: 需求是否在金融/医疗/政府等强监管场景？
    YES → D6（security_compliance）权重翻倍，必须检查
    NO → D6 标准权重检查

Q7: 需求是否需要运维/监控/回滚支持？
    YES 但未说明 → D7（operational）需要重点检查
    NO → D7 通过

Q8: 每个需求是否可追溯到来源（PRD/原型/业务决策）？
    NO → D8（traceability）需要重点检查
    YES → D8 通过
```

## 边界 Case 对照表

| 场景 | 维度 | 常见误判 | 正确处理 |
|---|---|---|---|
| "系统要快" | D4（non_functional） | D1 | 未量化的性能要求归 D4 |
| "支持手机号或邮件登录" | D2（inputs_outputs） | D1 | 输入形式变体归 D2 |
| "合规报告按月生成" | D7（operational）+ D6 | D1 | 运营节奏归 D7；法规要求归 D6 |
| "超时自动取消" | D5（exception_handling） | D2 | 失败路径归 D5 |
| "接口文档链接" | D8（traceability） | D2 | 来源追溯归 D8 |
| 医疗系统的"患者隐私保护" | D6 × 3 | D6 × 1 | 强监管乘数放大 |
