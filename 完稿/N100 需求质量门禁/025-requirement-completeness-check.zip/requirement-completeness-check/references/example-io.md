# Example IO

## Example: 订单自动拦截功能的完整性扫描

### Input (excerpt from PRD.md)
> 3.2 大额订单自动拦截
> 当订单金额超过阈值时,系统应自动拦截并标记为待审核。
> 审核通过后订单正常进入支付流程。

### Input (excerpt from 业务规则清单.csv)
```
rule_id,statement,applies_to
RULE-ORDER-007,订单金额 > 10000 元时触发拦截,REQ-ORDER-005
RULE-ORDER-008,拦截后订单状态变为 PENDING_REVIEW,REQ-ORDER-005
```

### Output: 完整性检查单.csv (selected rows)

```
issue_id,issue_category,issue_subtype,completeness_dimension,severity,severity_matrix.overall,artifact,object,evidence,finding,impact,recommendation,owner_candidate,needs_decision,blocking,parse_cache_ref,issue_namespace,decision_ref,re_gate_session_id
CHECK-COMP-ORDER-007,completeness,missing_field,D3_acceptance_criteria,blocker,blocker,PRD.md §3.2,REQ-ORDER-005 大额订单自动拦截,PRD §3.2 无 AC;RULE-ORDER-007/008 无 given-when-then,该需求无任何可测 AC,无法进入测试准备阶段,补 AC:given 订单金额 > 10000 when 提交订单 then 状态=PENDING_REVIEW 且审计事件发布,pm_zhang,true,true,cache_key_abc123,N100,,rgs_20260422_001
CHECK-COMP-ORDER-012,completeness,implicit_miss,D5_exception_handling,major,major,PRD.md §3.2,REQ-ORDER-005,仅定义"通过"路径,未定义审核拒绝与超时,审核拒绝/超时无处理规则(IC-02),客服与运营无法处理拒绝场景,补充:拒绝 → 订单 CANCELLED + 用户通知;超时 48h → 自动释放,pm_zhang,true,false,cache_key_abc123,N100,,rgs_20260422_001
CHECK-COMP-ORDER-018,completeness,symmetry_miss,D1_functional_scope,major,major,PRD.md §3.2,REQ-ORDER-005,"有'触发拦截',无'取消拦截'或'解除拦截'",对称缺失:触发 vs 解除,运营无法撤销误触发,补充 REQ-ORDER-006:运营可在审核前 1h 内主动解除拦截,ops_director,true,false,cache_key_abc123,N100,,rgs_20260422_001
```

### Output: 完整性检查摘要 (Markdown)

```
## 完整性审查结论

- **overall_score**: 72
- **pass_readiness**: dev_prep_with_constraints(design 可启动,test 阻塞)
- **mode**: baseline_mode

### 维度得分

| 维度 | 得分 | 关键 gap |
|---|---:|---|
| D1 functional_scope | 75 | 对称缺口:拦截缺解除 |
| D2 inputs_outputs | 85 | — |
| D3 acceptance_criteria | 45 | **缺 AC(blocker)** |
| D4 non_functional | 80 | 拦截响应时间未定义 |
| D5 exception_handling | 55 | 拒绝/超时路径缺失 |
| D6 security_compliance | 80 | — |
| D7 operational | 70 | 监控告警未定义 |
| D8 traceability | 85 | — |

### 放行条件

若下列 3 条满足即可推进到 test_prep:
1. CHECK-COMP-ORDER-007:补齐 AC(估时 0.5d,PM)
2. CHECK-COMP-ORDER-012:定义拒绝/超时路径(估时 1d,PM + 运营)
3. CHECK-COMP-ORDER-018:补充解除拦截需求(估时 0.5d,PM)
```

### Why this is a "good" output
- 三种 finding_type(missing_field / implicit_miss / symmetry_miss)都有实例
- 每条 finding 的 severity 与 dimension 一致(D3 缺 AC 自动 blocker)
- evidence 精确指向源文档位置(PRD.md §3.2)
- recommendation 可直接转为任务(given-when-then 句式)
- 放行条件按阶段(dev_prep / test_prep)分级给出
- parse_cache_ref 复用同一缓存键
