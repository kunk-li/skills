# N100 需求质量门禁 — 节点导航

> **节点定位**：对 N090 产出的 PRD 做全方位质量检查，输出 gate 决策（go / conditional-go / no-go），为 N110 交接提供依据。N100 是整个需求流程的质量关卡，所有 skill 均有完整的量化评分公式（必须阅读各自的 references/scoring-rubric.md）。

---

## Skills 一览

| ID | Skill | 主要输出 | 核心量化公式位置 |
|---|---|---|---|
| 025 | requirement-completeness-check | completeness_score + D1-D8 | scoring-rubric.md §Numeric formula |
| 026 | requirement-executability-check | executability_score + NE-* findings | scoring-rubric.md §Numeric formula |
| 027 | requirement-conflict-detection | conflict_score + conflict_kind 清单 | scoring-rubric.md |
| 028 | requirement-vulnerability-scan | vulnerability_score + severity 清单 | scoring-rubric.md §Numeric formula |
| 029 | pending-items-extraction | pending_score + pending_item 清单 | scoring-rubric.md §Numeric formula |
| 030 | requirement-quality-review | gate 决策 + overall_score + rollup | scoring-rubric.md §Numeric formula |

> ⚠️ **所有 N100 skill 的量化公式均在 `references/scoring-rubric.md` 中定义，SKILL.md 仅提供工作流描述。评分时必须读对应的 scoring-rubric.md。**

---

## 推荐执行顺序

```
025 → 026 → 027 → 028 → 029 → 030（汇总 gate 决策）
（025-029 可并行，030 依赖全部前五项）
```

---

## 各 Skill 核心公式速查

### 025 completeness_score
```
overall = mean(D1..D8)  # 默认等权
# 行业调整：fintech D6×2；healthcare D6×3 + D8×2
# Hard cap：D3 < 50 → overall ≤ 70；D1 < 40 → overall ≤ 65
pass_readiness 阈值：≥90=excellent, ≥80=pass, ≥70=needs_attention, ≥60=at_risk, <60=failing
D1-D8 定义见 references/completeness-dimensions.md
```

### 026 executability_score
```
perspective_score[v] = 100 - (NE_count × penalty)  # 见 NE-01..NE-08 权重表
if min(perspective_score) < 50: overall = min(perspective_score)
else: overall = 0.20×design + 0.30×engineering + 0.25×test + 0.25×risk
执行态：blocker_precondition → not_executable; soft_preconditions_only → conditionally; else → executable
```

### 027 conflict_score
```
9 种 conflict_kind：logical / semantic / precedence / resource / naming / versioning / temporal / scope / coverage
scope 决策：2 需求 → pair；3 → triple；≥4 → multi  (见 conflict-taxonomy.md)
```

### 028 vulnerability_score
```
dim_score[v] = 100 - (p0×30 + p1×10 + p2×3 + p3×1)  # 每维度独立
overall = min(business, compliance, engineering)  # min 原则：任一维度 P0 不能被稀释
行业调整：healthcare compliance×3；fintech compliance×2
```

### 029 pending_score
```
pending_score = 100 - (blocking_p0×15 + blocking_p1×5 + without_owner×3 + over_7_days×2 + deferred_without_version×5)
deferred 有 deferred_to_version → 不扣分；无 → 扣 5
被 025/026/027/028 引用的 pending item 在 030 rollup 时权重 0.10→0.15
```

### 030 overall_score（gate 决策）
```
overall = 0.25×completeness + 0.20×executability + 0.25×conflict + 0.20×vulnerability + 0.10×pending
industry_adjustment_factor：healthcare 0.90；fintech 0.95；gov 0.93；ecommerce 0.98

Hard rule veto（优先于 score）：
  1. confirmed blocker conflict → no-go
  2. unresolved p0 compliance vulnerability → no-go
  3. accepted vulnerability 无 approved_by 或 expiry 过期 → no-go
  4. completeness_score < 50 → no-go
  5. conflict_score < 50 → no-go

gate 决策：
  overall ≥ 85 且 all sub-scores ≥ 75 → go
  overall ≥ 60（或 85 但 sub-score < 75）→ conditional-go
  overall < 60 → no-go
```

---

## 030 Override 规则

**必须阅读 `references/override-policy.md`**：
- Override 失效条件：`approved_by` 为空 / `expiry` 已过 / 缺 `documented_risk` 或 `mitigation`
- Override 失效后：**恢复原 severity**（restore the original severity）
- 同一次运行中 override ≥3 条 → 升级至架构评审

---

## 与 N110 的交接规则

030 的 gate_status → 031 的 execution_mode 映射（见 031/references/readiness-scoring.md）：

| gate_status | execution_mode | 附加要求 |
|---|---|---|
| `go` | formal_mode | — |
| `conditional-go` | formal_mode（带 warnings）| 必须列出 conditional_go_conditions[] |
| `no-go` | blocked_mode | 必须列出每个 no-go 原因 |
| 未提供 N100 | minimal_mode | 标注 upstream_gate_status: unknown |

---

## 跨节点交接协议

- 上游：参见 `transitions/N090-N100-transition.md`（如何接收 PRD 和 GAP 清单）
- 下游：参见 `transitions/N100-N110-transition.md`（gate 决策如何流入 N110）

**N100 入场校验**：030 启动前需要执行 `n090_readiness_gate` 检查（见 N090-N100-transition.md §4）。  
**GAP 回写**：当 `new_gap: true` 时，030 的 `cross_node_trace.remediation_plan` 记录需回写到 023 的 GAP 条目。

## 常见误用

| 误用 | 正确做法 |
|---|---|
| 直接给 gate 决策，不提供量化 sub-score | 每个 skill 必须输出对应的分数和 rollup_trace |
| 028 使用加权平均聚合三维 severity | 使用 min 原则：overall = min(business, compliance, engineering) |
| 030 的 override 失效后保留降级后的 severity | override 失效 → 必须恢复原 severity |
| 跳过 025-029 直接运行 030 | 030 需要所有前五项的分数作为输入；缺少的用 partial mode 并标注 confidence |
