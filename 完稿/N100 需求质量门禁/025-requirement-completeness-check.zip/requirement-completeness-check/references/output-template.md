# Output Template

Use this default structure unless the user explicitly asks for another format.
When the result will be consumed by workflow v2, emit the machine-readable CSV artifact first and then the narrative summary.

## 0. artifact contract header
- `artifact_type`: `n100.completeness-check`
- `schema_version`: `2.1.1`
- `producer_skill`: `requirement-completeness-check`
- `consumer_nodes`: `N100`, `N110`, `N180`, `N370`
- `workflow_alias`: `完整性检查单.csv`
- `produced_event_name`: `produced.n100.completeness-check`
- `issue_namespace`: default `N100`
- `parse_cache_ref`: nullable
- `decision_ref`: nullable
- `re_gate_session_id`: nullable

## 1. machine-readable artifact
Produce or simulate a CSV named `完整性检查单.csv` with these columns in this exact order:
| issue_id | issue_category | issue_subtype | completeness_dimension | severity | severity_matrix.overall | artifact | object | evidence | finding | impact | recommendation | owner_candidate | needs_decision | blocking | parse_cache_ref | issue_namespace | decision_ref | re_gate_session_id |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## 2. document purpose and input inventory
- state that this is a completeness review, not a full gate review
- list inputs used and missing inputs
- state evaluation mode: `baseline_mode | diff_mode | tracking_mode | re_gate_mode`

## 3. overall completeness conclusion
- `completeness_score.overall`
- `pass_readiness`
- one-paragraph rationale

## 4. completeness score by dimension
| dimension | score | status | evidence summary | key gap ids |
|---|---:|---|---|---|
| D1 functional_scope |  |  |  |  |
| D2 inputs_outputs |  |  |  |  |
| D3 acceptance_criteria |  |  |  |  |
| D4 non_functional |  |  |  |  |
| D5 exception_handling |  |  |  |  |
| D6 security_compliance |  |  |  |  |
| D7 operational |  |  |  |  |
| D8 traceability |  |  |  |  |

## 5. blockers and conditional items
| issue_id | completeness_dimension | object | finding | impact | recommendation | severity |
|---|---|---|---|---|---|---|

## 6. implicit and symmetry gaps
| issue_id | kind | object | missing counterpart or expectation | why it matters |
|---|---|---|---|---|

## 7. pass conditions
- exact missing pieces that would move the baseline to the next stage

## 8. next-step recommendation
- what can proceed now
- what must wait
- who should fill the missing content
