# Orchestration

## Standalone path
1. Read the baseline package.
2. Score the eight completeness dimensions.
3. Output blockers, conditional items, and pass conditions.

## Combined path
1. Run this skill first or early when the team needs to know what is missing.
2. Combine with executability, conflict, vulnerability, or pending-item skills as needed.
3. Preserve issue ids and shared fields so 030 can aggregate without semantic rewriting.
4. Send P0 and P1 completeness findings to N180 as task-planning seeds:
   - `D1 functional_scope` blocker → trigger a new scope-definition task
   - `D3 acceptance_criteria` gap → trigger an AC completion task
   - `D5 exception_handling` gap → trigger an exception-flow task
   - `D7 operational` gap → trigger an operational-readiness task

## Combination note
This skill answers "what is missing".
Do not let 030 turn a weak completeness result into a guessed stronger conclusion.
