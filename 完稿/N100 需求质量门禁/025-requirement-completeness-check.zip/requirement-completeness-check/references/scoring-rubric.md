# Scoring Rubric

## Excellent
- eight dimensions covered clearly
- dimension scores are evidence-based and conservative
- implicit and symmetry gaps add real value
- pass conditions are specific and stage-aware

## Good
- most dimensions covered
- blockers and conditional items are usable
- some scoring nuance exists

## Needs Work
- only narrative feedback without dimension mapping
- scores feel arbitrary or unexplained
- pass conditions are vague

## Poor
- generic summary only
- no dimension score table
- no distinction between missing, conflicting, and risky issues

## Numeric formula

### Per-dimension score (D1..D8)

每个维度基于三类 finding 独立打分,范围 0-100:

  d_i_score = 100 - (
    explicit_missing_count × 10 +
    implicit_gap_count × 5 +
    symmetry_gap_count × 5 +
    vague_content_count × 3
  )
  clip to [0, 100]

### Overall score

默认等权:

  completeness_score.overall = mean(d1_score, d2_score, ..., d8_score)

特殊封顶规则(hard caps):
- 若 D3 acceptance_criteria < 50 → overall ≤ 70(AC 缺失直接限制发布准备)
- 若 D8 traceability < 40 → overall ≤ 75(追溯断链限制审计)
- 若任何 severity = blocker 的 finding 存在 → overall ≤ 60

### pass_readiness 映射

| overall_score | 其他条件 | pass_readiness |
|---:|---|---|
| ≥ 90 | 无 blocker,D3 ≥ 70 | ready_for_handover |
| 80-89 | 无 blocker,D3/D5 ≥ 60 | test_prep_with_constraints |
| 70-79 | D1/D2 ≥ 70 | dev_prep_with_constraints |
| 60-69 | D1 ≥ 60 | design_prep_only |
| < 60 | — | review_only |

### Industry adjustment
- fintech / gov:D6 security_compliance 权重 × 2,其他维度自动重归一
- healthcare:D6 × 3,D8 × 2
- saas / ecommerce / generic:等权(默认)

### 可验证性
此公式中所有变量均来自输出 CSV 字段。测试方法:
对同一 baseline 人工标注 findings,手算 overall,与 SKILL 输出对比,误差应 ≤ 2 分。
