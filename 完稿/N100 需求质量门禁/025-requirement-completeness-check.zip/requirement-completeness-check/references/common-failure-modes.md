# Common Failure Modes

1. Treating every weakness as a blocker instead of using dimension-based scoring.
2. Calling a contradiction when the real issue is a missing counterpart or missing exception path.
3. Ignoring implicit completeness expectations such as failure paths or rollback behavior.
4. Writing a narrative review without a coverage matrix.
5. Making the output depend on 030 instead of producing a complete standalone report.
