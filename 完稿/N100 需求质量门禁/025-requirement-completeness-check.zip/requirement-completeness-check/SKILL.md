---
name: requirement-completeness-check
description: check whether any document-oriented requirement baseline is complete enough for review, design, implementation planning, or test design. use when the input is a prd, design baseline, contract-like specification, sop, policy, or structured requirement package such as requirement breakdown, business rules, state transition mapping, and permission matrix, and the user needs a structured completeness report that can work standalone or combine cleanly with executability, conflict, vulnerability, and gate-review skills.
---
# requirement-completeness-check

## Role
Judge whether the current baseline is complete enough for the next stage.
This skill must work on any document-style baseline: requirement, design, contract, SOP, policy, workflow spec, or review package.
Use PRD and N70-style artifacts as preferred examples, not as a hard dependency.

## Standalone and combined use
### Standalone
Produce a self-contained completeness report with dimension scores, blocking gaps, conditional gaps, and an explicit next-step recommendation.
The result must still be usable even if no other skill runs.

### Combined
Keep the completeness specialty strong, but expose normalized fields so `requirement-quality-review` can aggregate the result without rewriting meaning.
Never assume 030 will fix a weak completeness report.

## Shared interoperability contract
When this skill is used with other requirement-review skills, keep the native specialty fields but also preserve these shared fields whenever the evidence supports them:
- `issue_id`
- `issue_category`
- `issue_subtype`
- `severity` = blocker / major / minor / note
- `severity_matrix.overall` plus any supported sub-dimensions
- `artifact`
- `object`
- `evidence`
- `finding`
- `impact`
- `owner_candidate`
- `needs_decision`
- `blocking`
- `related_issue_ids` when there is an obvious upstream or downstream link

Do not drop the skill-specific fields just to fit the shared schema. Keep both when useful.

## Light composition runtime contract
When this skill is run as part of a composed N100 review, carry these lightweight runtime fields whenever available:
- `parse_cache_ref`
- `issue_namespace` (default `N100`)
- `decision_ref`
- `re_gate_session_id`
- `produced_event_name`

Keep them nullable when the upstream workflow does not provide them. Do not invent values.

## Shared node-level references
When these bundled references are present, consult them before inventing local behavior:
- `_shared/parse-cache-contract.md` for cache lifecycle, hit/miss handling, and integrity fallback
- `_shared/cross-skill-disambiguation.md` for ownership boundaries, duplicate prevention, and `related_issue_ids` linkage

## Workflow v2 input aliases
Prefer the workflow names directly when they exist:
- `PRD.md`
- `需求结构树.md`
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`

Also accept equivalent analyst-friendly aliases such as requirement breakdown, business rules, state transition mapping, and permission matrix.

## Preferred inputs
Preferred package when available:
- `hub_requirement_breakdown.md`
- `hub_business_rules.md`
- `hub_state_transition_mapping.md`
- `hub_permission_matrix.md`

Fallback inputs may be any requirement-like or policy-like document set.
When the package is incomplete, state which dimensions were evaluated with direct evidence and which were evaluated conservatively.

## Mandatory completeness dimensions
Every finding must belong to one of these fixed dimensions:
- `D1 functional_scope`
- `D2 inputs_outputs`
- `D3 acceptance_criteria`
- `D4 non_functional`
- `D5 exception_handling`
- `D6 security_compliance`
- `D7 operational`
- `D8 traceability`

## Workflow v2 artifact contract
Declare this contract explicitly in the output header when the result is intended for workflow consumption:
- `artifact_type`: `n100.completeness-check`
- `schema_version`: `2.1.1`
- `producer_skill`: `requirement-completeness-check`
- `consumer_nodes`: `N100`, `N110`, `N180`, `N370`
- `workflow_alias`: `完整性检查单.csv`
- `produced_event_name`: `produced.n100.completeness-check`
- `canonical_fields`: `issue_id`, `issue_category`, `issue_subtype`, `completeness_dimension`, `severity`, `severity_matrix.overall`, `artifact`, `object`, `evidence`, `finding`, `impact`, `recommendation`, `owner_candidate`, `needs_decision`, `blocking`, `parse_cache_ref`, `issue_namespace`, `decision_ref`, `re_gate_session_id`

## Output contract
Default to a dual output unless the user explicitly asks for only one representation:
1. a machine-readable CSV-first artifact aligned to workflow v2 and named `完整性检查单.csv`
2. a concise Markdown summary that follows `references/output-template.md`

Required CSV columns:
- `issue_id`
- `issue_category` = completeness
- `issue_subtype`
- `completeness_dimension`
- `severity`
- `severity_matrix.overall`
- `artifact`
- `object`
- `evidence`
- `finding`
- `impact`
- `recommendation`
- `owner_candidate`
- `needs_decision`
- `blocking`
- `parse_cache_ref`
- `issue_namespace`
- `decision_ref`
- `re_gate_session_id`

Also produce:
- `completeness_score.overall` = 0-100
- `completeness_score.by_dimension`
- `coverage_summary`
- `pass_readiness` = review_only / design_prep_only / dev_prep_with_constraints / test_prep_with_constraints / ready_for_handover

If the user only wants prose, keep the rows directly convertible into the same CSV columns.

## Score guidance
Use a conservative 0-100 score per dimension.
Suggested criteria for each dimension:
- required content exists
- required content is non-empty
- acceptance or verification intent is testable
- exception or edge handling is covered when relevant
- traceability or ownership is present when relevant

Do not invent precision. If the evidence is thin, score conservatively and explain why.

## Implicit completeness rules
Check these built-in expectation rules when relevant:
- success path implies failure path
- create implies delete, archive, or retention handling
- apply implies revoke, rollback, or withdraw handling
- event intake implies format, retry, and failure handling
- timeout implies timeout aftermath
- state definition implies legal and illegal transitions
- external dependency implies degradation or fallback behavior
- configuration implies default value and change behavior
- numeric rule implies boundary and precision behavior
- approval workflow implies rejection, resubmission, and audit behavior

Flag these as `implicit_gap`, not as confirmed contradiction.

## Symmetry check
When the baseline defines one side of an expected pair but not the other, emit a `symmetry_gap` finding.
Typical pairs include create/delete, enable/disable, grant/revoke, lock/unlock, submit/withdraw, start/end, send/receive, freeze/unfreeze, archive/restore.

## Modes
- `baseline_mode`: evaluate one baseline version
- `diff_mode`: compare two versions and report completeness movement
- `tracking_mode`: summarize trend across versions when prior scores or reports are available
- `re_gate_mode`: compare against a prior issue set and mark closed_since_last / still_open / new_in_this_scan when such evidence exists

## Workflow
1. Inventory the input artifacts and the evidence strength.
2. Build a compact coverage matrix for the eight dimensions.
3. Mark explicit gaps, implicit gaps, and symmetry gaps separately.
4. Score each dimension conservatively.
5. Emit the workflow CSV rows first when workflow consumption is expected.
6. End with exact pass conditions for the next stage.

## Boundary rules
- Do not label contradiction unless two statements actually conflict.
- Do not turn every open decision into a completeness issue when the real problem is governance or timing.
- Do not treat code-level security flaws as completeness findings.
- Do not claim `ready_for_handover` if D3, D5, or D8 is materially blocked.
- Do not rewrite the baseline; report only the gaps and pass conditions.

## References
- `references/output-template.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/completeness-dimensions.md`
