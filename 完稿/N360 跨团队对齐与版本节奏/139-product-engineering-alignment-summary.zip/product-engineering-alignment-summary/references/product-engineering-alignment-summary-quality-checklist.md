# 产研对齐摘要 quality checklist

1. Metadata is complete and `contract_version` is `n360-cross-team-v1.1.2`.
2. `selected_mode` is one of the modes in `references/output-contract.yaml`.
3. `stance` is `summarize_not_judge` and matches the skill boundary.
4. `artifact_id` and row IDs follow the N360 naming rule or are explicitly temporary.
5. CSV headers exactly match `n360.product-engineering-alignment.v2` when CSV is emitted.
6. Multi-value CSV fields use `|`, not bare commas.
7. Evidence refs include source, confidence, layer, and pointer where possible.
8. `cross_artifact_refs` use stable IDs from N340/N350/N360/N330/N320 rather than file paths.
9. `pending_decisions`, `open_blockers`, and `owner_placeholders` are explicit when evidence is incomplete.
10. downstream_handoff contains `handoff_id`, consumer, `decision_target_node` when relevant, required_fields, readiness, confidence, and next_best_checks.
11. Compare the produced artifact against the most relevant example under `examples/`; differences are allowed but should be intentional.

## Skill-specific checks
- Product and engineering views are separated before synthesis.
- Each open topic has decision_owner, deadline, evidence_ref, and action_ref or an explicit gap.
- Aligned topics are not re-opened as disputes.
- Risk hints remain hints and do not replace scope-trim recommendations.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- All `alignment_status = unresolved` topics are in `downstream_handoff.pending_decisions` — not just in body text.
- `decision_deadline` and `impact_if_unresolved` are filled for every unresolved topic; `待确认` is valid but triggers open_blocker.
- `pre_release_alignment_check` mode: every feature in release scope has at least one alignment topic.

## Output structure completeness checks
- All 5 mandatory sections present per the mandatory section table
- `alignment_status: unresolved` topics appear in BOTH body AND `downstream_handoff.pending_decisions`
- `decision_deadline` and `decision_owner` present for all unresolved topics; `待确认` triggers open_blocker
- `pre_release_alignment_check` mode: Feature Coverage Check table present before individual topics
- `delta_topic_refresh` mode: `change_summary` field present for every changed topic
