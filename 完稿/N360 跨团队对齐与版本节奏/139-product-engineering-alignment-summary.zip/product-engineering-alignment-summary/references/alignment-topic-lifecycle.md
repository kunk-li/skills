# Alignment Topic Lifecycle Guide

Use this reference to manage the lifecycle of individual alignment topics across multiple sessions.

## Topic lifecycle states

```
DRAFT → OPEN → PARTIAL → ALIGNED
                ↓
             DEFERRED → (future sprint)
                ↓
           UNRESOLVED → escalate → #141 scope trim
```

| State | Definition | Required fields |
|-------|-----------|-----------------|
| DRAFT | Topic identified but not yet discussed | topic_id, title, source |
| OPEN | Discussed; gap confirmed; decision pending | + alignment_status, decision_owner |
| PARTIAL | Progress made; partial agreement | + partial_agreement_summary |
| ALIGNED | Full agreement reached | + agreement_summary, evidence |
| DEFERRED | Moved to later milestone | + deferred_to, deferred_reason |
| UNRESOLVED | Cannot resolve in current cycle | + decision_deadline, impact_if_unresolved |

## State transition rules

- `OPEN → ALIGNED`: requires explicit confirmation from both sides (product + engineering)
- `OPEN → DEFERRED`: requires PM approval and milestone update
- `OPEN → UNRESOLVED` after deadline: automatically escalate to `downstream_handoff.pending_decisions`
- `UNRESOLVED` for >2 cycles: trigger N360 #141 scope trim review

## delta_topic_refresh mode rules

When refreshing existing topics:
1. Preserve topic_id — never reassign IDs
2. Only update changed fields; record `last_updated` timestamp
3. Add `change_summary` field noting what changed this cycle
4. Topics that changed state must appear in `## 对齐议题变化汇总`

## pre_release_alignment_check mode requirements

- Every feature in release scope must have ≥1 alignment topic
- Feature with no topics → create DRAFT topic with `source: release_scope_check`
- UNRESOLVED topics with `impact_if_unresolved` containing "release" → flag for #141 immediately
- Output Feature Coverage Check table before individual topic details

## Anti-patterns

**Do not reuse topic_ids** across different incidents/releases — each alignment session generates new IDs or continues existing ones via delta_topic_refresh.
**Do not mark as ALIGNED** without documenting what specifically was agreed — `agreement_summary` must be explicit.
