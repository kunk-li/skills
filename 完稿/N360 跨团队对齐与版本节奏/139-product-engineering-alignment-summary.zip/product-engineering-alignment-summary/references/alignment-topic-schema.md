# product-engineering alignment topic schema v2.1

schema: `n360.product-engineering-alignment.v2`

## default markdown table
| topic_id | 议题 | 产品视角 | 研发视角 | 当前差异 | alignment_status | 待决方 | decision_deadline | impact_if_unresolved | action_ref | evidence_ref |
|---|---|---|---|---|---|---|---|---|---|---|

## csv columns
`topic_id,topic,product_view,engineering_view,current_gap,alignment_status,decision_owner,decision_deadline,impact_if_unresolved,evidence_ref,action_ref`

## field rules
- `topic_id`: 稳定 id，如 `PEA-001`
- `product_view`: 产品期望、业务目标、范围要求或时间要求
- `engineering_view`: 技术约束、依赖、资源、实现路径或交付窗口
- `current_gap`: 只描述当前差异，不给裁判结论
- `alignment_status`: `aligned` | `partial` | `unresolved` | `deferred`
- `decision_owner`: 负责人、角色或小组；未知时写 `待确认`
- `decision_deadline`: 明确日期、周期标签或 `待确认` — **必填当 alignment_status = unresolved**
- `impact_if_unresolved`: 若此议题未在截止日期前决策，将产生什么影响 — **必填当 alignment_status = unresolved**
- `evidence_ref` / `action_ref`: 多值时统一 `|`
- `action_ref`: 推荐格式 `meeting:<meeting_id>#action:<n>` 或 `task:TASK-001`

## alignment_status transition rules
- `unresolved → aligned`: 需要有 `decision_owner` 的明确决定，且决定已在 `action_ref` 中引用
- `unresolved → deferred`: 需要记录 deferred 理由和目标版本
- `partial → aligned`: 需要列明哪些子议题已对齐，哪些仍需跟进
- 不可从 `aligned` 直接变回 `unresolved` 而不说明原因

## downstream_handoff.pending_decisions format
All `alignment_status = unresolved` topics MUST appear here:
```yaml
downstream_handoff:
  pending_decisions:
    - topic_id: PEA-007
      decision_owner: PM|ENG-lead
      deadline: 2025-06-12
      impact_if_missed: "联调无法按计划启动，M3 延期 5 天"
```

## csv rules
- RFC-4180, UTF-8
- 列表字段不用裸逗号，统一 `|`

## example (with new fields)
```csv
topic_id,topic,product_view,engineering_view,current_gap,alignment_status,decision_owner,decision_deadline,impact_if_unresolved,evidence_ref,action_ref
PEA-001,购物车数量上限,产品希望无上限,Redis 单 key 最大 512 条,功能期望与技术约束冲突,unresolved,PM|ENG-lead,2025-06-10,发版后用户购物车>512件会报错且无回滚方案,meeting:weekly-2025-06-03#topic:4,meeting:weekly-2025-06-03#action:6
PEA-002,灰度阶段是否保留高级筛选,首版保留以支撑客户演示,实现会压缩回归窗口,时间窗口冲突,deferred,PM,2025-07-01,推迟至 v2.1 版本,meeting:weekly-2025-05-28#topic:3,
```
