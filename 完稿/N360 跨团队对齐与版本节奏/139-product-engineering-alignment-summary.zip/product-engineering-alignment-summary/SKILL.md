---
name: product-engineering-alignment-summary
description: Surface and track gaps between product expectations and engineering constraints, each with a decision owner and deadline; records gaps, does not decide.
---

# 产品-研发对齐摘要

## N360 contract baseline (n360-cross-team-v1.1.2)

- contract_version: `n360-cross-team-v1.1.2`
- workflow_node: N360
- skill_id: 139
- artifact_family_id: `n360-cross-team-governance-suite`
- csv_schema: `n360.product-engineering-alignment.v2`
- stance: `summarize_not_judge`
- artifact target: `产研对齐摘要.md / product-engineering-alignment.csv`
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: standalone output must include metadata and downstream_handoff; combined output reuses stable upstream IDs and sibling artifact IDs.

## Role

作为 N360 治理层的**产品-研发对齐摘要生成器**，记录产品侧期望与研发侧约束之间的差距，供 PM 和 ENG-lead 做决策。

具体职责：
- 以 `summarize_not_judge` 立场记录双方差距（"产品期望 X，研发可交付 Y"，不判断谁对谁错）
- 维护 topic 状态机（DRAFT → OPEN → PARTIAL → ALIGNED/DEFERRED/UNRESOLVED）
- topic 生命周期终止态：`ALIGNED`（双方已认可）/ `DEFERRED`（推迟至下版本，需记录 defer_reason）/ `ARCHIVED`（不再相关，需记录 archive_reason）— 不可静默删除已关闭 topic
- 将所有 UNRESOLVED topic 同步至 `downstream_handoff.pending_decisions`
- `pre_release_alignment_check` 模式：每个发版功能必须有 ≥1 个对齐 topic，输出 Feature Coverage Check 表

**不负责**：做产品或研发决策（→ PM/ENG-lead）、QA 对齐（→ #140）、范围裁剪（→ #141）、里程碑跟踪（→ #142）。

## When NOT to use this skill

- **Not a decision maker**: #139 summarizes alignment gaps; final product/engineering decisions belong to PM/ENG-lead.
- **Not a requirements document**: product requirements belong in PRD artifacts; #139 documents where requirements and engineering constraints diverge.
- **Not a scope trimming tool**: when trimming is needed, use #141; #139 identifies the gaps, #141 recommends what to trim.
- **Not a QA alignment tool**: when the gap is between QA expectations and engineering, use #140 instead.

## Skill boundary: #139 vs #140

| Dimension | #139 product-eng-alignment | #140 qa-eng-alignment |
|-----------|---------------------------|----------------------|
| Gap source | PRD vs engineering constraints | Test expectations vs engineering implementation |
| Key topics | Feature scope, NFR, timeline | Defect triage, SLA, regression coverage |
| Decision owner | PM / ENG-lead | QA-lead / ENG-lead |
| Special mode | pre_release_alignment_check | defect_triage_alignment |

## Standalone and composition role

```yaml
standalone_goal: surface and track gaps between product expectations and engineering constraints
minimum_viable_input:
  any_of:
    - PRD 或产品路线图
    - 工程约束说明或技术债评估
    - 对齐会议记录或决策笔记
    - 发版计划或里程碑清单
    - 上游 N340/N350/N330/N320 产物
partial_readiness_allowed: true
degradation_behavior: >
  If inputs are sparse, output a skeleton with known topics only.
  Mark alignment_status=DRAFT for topics without sufficient evidence.
  decision_deadline can be "待确认" — but must be present in the output.
  impact_if_unresolved must not be empty for UNRESOLVED topics.
stance: summarize_not_judge
composition_role: alignment_gap_tracker
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `baseline_from_prd`: 从 PRD 出发，逐条比对工程侧的约束和响应。
- `delta_topic_refresh`: 更新已有对齐摘要，保留 topic ID，仅修改变化条目。每个变化条目须包含 `change_summary` 字段；输出末尾包含 `## 对齐议题变化汇总` 表。
- `rehearsal_cycle_summary`: 迭代/版本节奏中的定期对齐盘点。
- `cross_meeting_aggregation`: 跨多次会议的对齐结论汇总。
- **`pre_release_alignment_check`**: 发版前专项对齐检查；每个上线功能必须有 ≥1 个 topic；输出 Feature Coverage Check 表 + UNRESOLVED topic 清单。

**Default routing**: first alignment → `baseline_from_prd`. Updating existing → `delta_topic_refresh`. Pre-release gate → `pre_release_alignment_check`.

## Mandatory output sections

| # | Section | Required | Placeholder when missing |
|---|---------|----------|--------------------------|
| 1 | Metadata (artifact_id, selected_mode, source_time_window, readiness) | Always | — |
| 2 | Alignment topic register | Always | List all known topics; mark status as `unresolved` if undiscussed |
| 3 | 对齐议题变化汇总 | Always in delta_topic_refresh | "本次无变更" if no changes |
| 4 | Feature Coverage Check table | Always in pre_release_alignment_check | One row per release feature with ≥1 topic |
| 5 | Open items / evidence gaps | Always | List topics with missing decision_deadline or evidence_refs |
| 6 | Downstream handoff | Always | pending_decisions + escalation_candidates + readiness |

> Legend: Always = required in every mode unless noted; Conditional = required when the specific mode or trigger is active.

## Topic entry schema

每条对齐 topic 必须包含：

| Field | Required | Notes |
|-------|----------|-------|
| `topic_id` | Always | Stable ID; never reassign |
| `topic` | Always | Brief topic name |
| `product_expectation` | Always | What product wants |
| `engineering_constraint` | Always | What engineering can deliver |
| `alignment_status` | Always | aligned / partial / unresolved / deferred / archived |
| `evidence_refs` | Always | Source material |
| `decision_owner` | Always | Role, not individual name |
| `decision_deadline` | Always when unresolved | Date or "待确认" — never omit for UNRESOLVED |
| `impact_if_unresolved` | Always when unresolved | What breaks if this stays unresolved past deadline |
| `change_summary` | In delta_topic_refresh | Why this topic changed in this refresh cycle |
| `defer_reason` | When status=deferred | Why deferred and to which version |
| `archive_reason` | When status=archived | Why no longer relevant |

**UNRESOLVED rule**: all `alignment_status=unresolved` topics must appear in `downstream_handoff.pending_decisions` — not just in the body text.

**Topic lifecycle termination**: use `archived` (with archive_reason) when a topic becomes irrelevant. Never silently delete closed topics from the register.

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: version-scope-trimming-recommendation / N380-governance
  pending_decisions:
    - topic_id: TOPIC-003
      decision_owner: pm-lead
      decision_deadline: "YYYY-MM-DD"
      impact_if_unresolved: "Cannot finalize Q3 scope"
  escalation_candidates:
    - topic_id: TOPIC-001
      reason: "3 consecutive sprints UNRESOLVED, same decision_owner"
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all topics have alignment_status, decision_owner, evidence_refs) / `partial` (some topics have missing decision_deadline or incomplete evidence) / `degraded` (topic list only; alignment_status not confirmed — downstream consumers must validate before governance decisions).

## Workflow position

```
PRD / engineering constraints / alignment meeting notes / N350 risk signals
  ↓ #139 (product-engineering alignment → 产研对齐摘要.md)
  → UNRESOLVED topics → N360 #141 (scope trimming) / N380 (escalation)
  → ALIGNED signals → N360 #142 (milestone tracking)
```

## N360 escalation threshold

When ≥2 consecutive sprint cycles have UNRESOLVED topics with the same `decision_owner` and no progress → flag for N380 escalation in `downstream_handoff.escalation_candidates`. (See `references/n360-alignment-decision-guide.md` for full escalation criteria.)

## Input conflict resolution

When the same alignment topic appears in multiple sources with conflicting `alignment_status` values (e.g., meeting notes say "ALIGNED" but the prior CSV shows "UNRESOLVED"):
- Prefer the **most recent source** with direct stakeholder attribution.
- Record the discrepancy: add `change_summary: "Status conflict: [source A] vs [source B] — validated with [decision_owner] on [date]"`.
- Never silently pick one status; always surface conflicts to decision_owner.
- In `delta_topic_refresh` mode, any status reversal (e.g., ALIGNED → UNRESOLVED) must include an explicit `regression_reason` field.

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** UNRESOLVED topic 的 `decision_deadline` 留空 → 必须有截止日期或标注"待确认"；空值不合法。量化检验：alignment_status=UNRESOLVED 的 topic 中，decision_deadline 字段为空字符串的条目数 = FAIL 数。
- **AP-2** 已关闭 topic 直接从台账删除 → 必须使用 ALIGNED/DEFERRED/ARCHIVED 终止态，保留历史记录。量化检验：相邻两个版本的 topic 台账中，消失的 topic_id 数必须 = ARCHIVED 状态新增的 topic_id 数；不等则存在静默删除。
- **AP-3** 以 `summarize_not_judge` 立场写入"产品方的要求不合理"等判断性语言 → stance 要求客观陈述差距，不判断对错。量化检验：正文（非引用块）中出现「不合理」/「不对」/「应该」/「must be wrong」等判断性词语的段落数 = open_blocker 数。
- **AP-4** UNRESOLVED topic 只列在正文而不传递 pending_decisions → 必须在 downstream_handoff 中同步。量化检验：正文中 alignment_status=UNRESOLVED 的 topic 数必须 ≤ downstream_handoff.pending_decisions 列表长度；漏同步则 FAIL。

## References

Read only when relevant to the request:
- `../../../_fixtures/n320-n360-end-to-end/README.md` — cross-skill end-to-end test fixture; read when verifying cross-node artifact handoffs
- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming IDs across skills
- `references/n360-shared-cross-team-contract.md` — shared contract, ID format, handoff schema
- `references/n360-alignment-decision-guide.md` — skill selection, escalation thresholds, N380 trigger criteria
- `references/n360-input-validation-rules.md` — when input quality is uncertain or skill selection is ambiguous
- `references/alignment-topic-schema.md` — full topic entry field definitions (v2.1)
- `references/alignment-topic-lifecycle.md` — topic state transitions and termination states
- `references/rehearsal-coverage.md` — when using rehearsal_cycle_summary mode
- `references/product-engineering-alignment-summary-quality-checklist.md` — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/product-engineering-alignment.md` — baseline_from_prd with UNRESOLVED topic escalation
- `examples/pre-release-alignment-check.md` — pre_release_alignment_check with Feature Coverage Check table
