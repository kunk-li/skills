# Example: Product-Engineering Alignment — Pre-Release Alignment Check Mode

Demonstrates `pre_release_alignment_check` mode: systematically scanning all release features for product-engineering gaps before go/no-go.

```yaml
metadata:
  contract_version: n360-cross-team-v1.1.2
  skill_id: "139"
  selected_mode: pre_release_alignment_check
  artifact_id: PE-ALIGN-PRERELEASE-V24
  version: Platform v2.4
  release_date: 2025-07-15
  days_to_release: 34
  readiness: partial
  open_blockers:
    - PEA-V24-003 decision_deadline 待确认
```

## 产研对齐摘要 — Platform v2.4 发版前全检

**快照日期**: 2025-06-11  
**覆盖范围**: v2.4 所有 7 个功能（来自 PRD-v2.4-001）

---

## Feature Coverage Check

| feature_id | 功能名 | 产研对齐状态 | topic_ids |
|-----------|--------|------------|---------|
| FT-V24-001 | OAuth 第三方登录 | ALIGNED | PEA-V24-001 |
| FT-V24-002 | 购物车数量可配置化 | UNRESOLVED | PEA-V24-002 |
| FT-V24-003 | 实时库存推送 | DEFERRED to v2.5 | PEA-V24-003 |
| FT-V24-004 | 支付方式扩展 | ALIGNED | PEA-V24-004 |
| FT-V24-005 | 退款申请 API | PARTIAL | PEA-V24-005 |
| FT-V24-006 | 监控指标暴露 | ALIGNED | PEA-V24-006 |
| FT-V24-007 | 性能压测目标 | UNRESOLVED | PEA-V24-007 |

**Coverage**: 7/7 功能已有对应 topic ✓

---

## 对齐议题

### PEA-V24-001 OAuth 第三方登录实现方式
- **产品**: 支持 Google + Apple 登录，首版 v2.4
- **研发**: OAuth2.0 Client Credentials 已实现，Google 已联调，Apple 需额外 2 周
- **alignment_status**: aligned
- **结论**: Apple 登录推至 v2.4.1 patch；v2.4 仅 Google，PRD 已更新

### PEA-V24-002 购物车数量上限可配置化
- **产品**: 产品要求上限可通过管理后台配置，范围 10-9999
- **研发**: Redis 单 key 硬限 512；可配置上限需引入分片方案，技术评估 3 天
- **alignment_status**: unresolved
- **decision_owner**: PM + ENG-lead
- **decision_deadline**: 2025-06-18
- **impact_if_unresolved**: FT-V24-002 无法进入开发，v2.4 发版目标受影响

### PEA-V24-003 实时库存推送
- **产品**: 希望 v2.4 包含
- **研发**: WebSocket 基础设施未完成，最早 v2.5
- **alignment_status**: deferred
- **deferred_to**: v2.5
- **evidence_ref**: scope-trim:ST-M-001

### PEA-V24-005 退款申请 API 超时策略
- **产品**: 退款响应时间 ≤3s
- **研发**: 第三方支付通道超时不可控，通常 5-8s；可做异步 + webhook
- **alignment_status**: partial
- **decision_owner**: PM + ENG-lead
- **decision_deadline**: 2025-06-20
- **impact_if_unresolved**: API 响应时间 SLA 无法承诺，影响合同条款

### PEA-V24-007 v2.4 性能压测目标
- **产品**: 要求 TPS ≥ 1000（来自销售承诺）
- **研发**: 当前架构压测结果 TPS = 680；达到 1000 需要 2 个 Sprint 优化
- **alignment_status**: unresolved
- **decision_owner**: PM + ENG-lead + Sales
- **decision_deadline**: 待确认（Sales 需参与）
- **impact_if_unresolved**: 发版后 SLA 违约风险；如不能达标，需调整合同承诺

---

## Downstream Handoff

```yaml
handoff_id: PE-ALIGN-PRERELEASE-V24-HANDOFF
producer_skill: product-engineering-alignment-summary
consumer_skill_or_node: version-scope-trimming-recommendation|release-owner|N350
pending_decisions:
  - topic_id: PEA-V24-002
    decision_owner: PM|ENG-lead
    deadline: 2025-06-18
    impact_if_missed: "FT-V24-002 无法进入开发，v2.4 功能缺失"
  - topic_id: PEA-V24-005
    decision_owner: PM|ENG-lead
    deadline: 2025-06-20
    impact_if_missed: "退款 API SLA 无法承诺，影响合同"
  - topic_id: PEA-V24-007
    decision_owner: PM|ENG-lead|Sales
    deadline: 待确认
    impact_if_missed: "发版后 SLA 违约风险"
coverage_check:
  features_in_scope: 7
  features_aligned: 3
  features_unresolved: 2
  features_deferred: 1
  features_partial: 1
readiness: partial
confidence: high
next_best_checks:
  - "#141 scope trim: PEA-V24-007 performance gap may require scope negotiation"
  - "PM: confirm Sales participation for PEA-V24-007 decision by 2025-06-15"
  - "ENG-lead: complete technical evaluation for PEA-V24-002 by 2025-06-17"
```
