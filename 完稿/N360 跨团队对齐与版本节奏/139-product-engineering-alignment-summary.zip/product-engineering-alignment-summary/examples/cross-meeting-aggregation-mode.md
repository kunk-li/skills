# Example: Product-Engineering Alignment — Cross-Meeting Aggregation Mode

## Metadata

```yaml
artifact_id: ALIGN-PROD-ENG-003
skill_id: 139
contract_version: n360-cross-team-v1.1.2
selected_mode: cross_meeting_aggregation
source_time_window: "2025-06 sprint-10 through sprint-12"
source_meetings:
  - "Sprint-10 Product Review 2025-05-30"
  - "Sprint-11 Scope Refinement 2025-06-06"
  - "Sprint-12 Pre-release Check 2025-06-13"
readiness: complete
```

## Alignment Topic Register

| topic_id | topic | product_expectation | engineering_constraint | alignment_status | decision_owner | decision_deadline | evidence_refs |
|----------|-------|--------------------|-----------------------|-----------------|----------------|-------------------|---------------|
| TOPIC-001 | 搜索响应时间 SLA | ≤200ms p95 | 当前 p95=310ms；需索引优化 | unresolved | eng-lead | 2025-06-20 | Sprint-10 Review transcript |
| TOPIC-002 | 批量导出功能范围 | 支持最多 10000 条记录导出 | 内存限制建议 ≤1000 条；超限需流式处理（额外 2 周） | partial | pm-lead + eng-lead | 2025-06-18 | Sprint-11 Scope Refinement notes |
| TOPIC-003 | 多语言 i18n 支持 | v2.3 上线需覆盖简中+英文 | 简中已完成；英文 copy 待 content team 提交 | partial | content-team | 2025-06-16 | Sprint-11 notes + Slack thread |
| TOPIC-004 | 移动端 push 通知 | iOS/Android 同步支持 | iOS 已完成；Android 需额外 1 sprint | deferred | pm-lead | — | Sprint-12 Pre-release notes |
| TOPIC-005 | 数据迁移无停机要求 | 零停机蓝绿迁移 | 已完成；蓝绿切换验证通过 | aligned | — | — | Sprint-12 Pre-release notes |

## 对齐议题变化汇总（Sprint-10 → Sprint-12）

| topic_id | 变化类型 | Sprint-10 状态 | Sprint-12 状态 | 变化说明 |
|----------|---------|---------------|---------------|---------|
| TOPIC-001 | 持续未解决 | unresolved | unresolved | 三个 sprint 同一 decision_owner；触发升级候选 |
| TOPIC-002 | 状态降级 | aligned | partial | 工程侧重新评估后发现内存约束；需重新对齐 |
| TOPIC-003 | 进展 | unresolved | partial | 简中已交付，仅英文 copy 待确认 |
| TOPIC-004 | 推迟 | unresolved | deferred | PM 与工程侧确认推迟至 v2.4 |
| TOPIC-005 | 达成一致 | partial | aligned | 蓝绿验证完成 |

## Open Items / Evidence Gaps

- TOPIC-001：decision_deadline 为 2025-06-20；三个连续 sprint UNRESOLVED 且同一 decision_owner（eng-lead）→ 触发升级候选
- TOPIC-002：impact_if_unresolved 未填写 → 需 PM 补充「若 10000 条导出不支持，哪些客户合同受影响」
- TOPIC-003：content-team 不在团队内部，decision_deadline 可能滑期 → 需外部确认

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: version-scope-trimming-recommendation / N380-governance
  pending_decisions:
    - topic_id: TOPIC-001
      decision_owner: eng-lead
      decision_deadline: "2025-06-20"
      impact_if_unresolved: "Search SLA contractual breach risk for enterprise customers"
    - topic_id: TOPIC-002
      decision_owner: pm-lead
      decision_deadline: "2025-06-18"
      impact_if_unresolved: "Bulk export scope unclear — QA cannot finalize test plan"
    - topic_id: TOPIC-003
      decision_owner: content-team
      decision_deadline: "2025-06-16"
      impact_if_unresolved: "English copy missing on launch day"
  escalation_candidates:
    - topic_id: TOPIC-001
      reason: "3 consecutive sprints UNRESOLVED, same decision_owner (eng-lead)"
  readiness: complete
```
