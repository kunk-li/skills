---
name: qa-engineering-alignment-summary
description: 生成测研对齐摘要（测试-研发对齐）用于 n360 跨团队治理。triggered when a QA-lead or ENG-lead needs to consolidate defect triage decisions, performance sla gaps, and test coverage disagreements between qa and engineering teams. use defect_triage_alignment mode for defect review meetings; use performance_sla_alignment for sla negotiation. stance is always summarize_not_judge — this skill records qa vs engineering gaps, it does not make release decisions. do not use for product-engineering alignment (→ #139), defect tracking system operations, or go/no-go release decisions (→ release-owner).
---

# 测试-研发对齐摘要

## N360 contract baseline (n360-cross-team-v1.1.2)

- contract_version: `n360-cross-team-v1.1.2`
- workflow_node: N360
- skill_id: 140
- artifact_family_id: `n360-cross-team-governance-suite`
- csv_schema: `n360.qa-engineering-alignment.v2`
- stance: `summarize_not_judge`
- artifact target: `测研对齐摘要.md / qa-engineering-alignment.csv`
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: standalone output must include metadata and downstream_handoff; combined output reuses stable upstream IDs and sibling artifact IDs.

## Role

作为 N360 治理层的**测试-研发对齐摘要生成器**，记录 QA 验收期望与研发实现之间的差距，聚焦缺陷分类和性能 SLA 对齐。

具体职责：
- 对每条缺陷进行 triage 分类（confirmed_bug/needs_repro/wont_fix/by_design）
- `wont_fix` 强制要求 `wont_fix_reason + decision_owner + risk_if_shipped` 三件套
- `performance_sla_alignment` 模式：每个 SLA 指标计算差距百分比，输出汇总表（✅/❌）
- topic 生命周期终止态：`ALIGNED`/`DEFERRED`（需 defer_reason）/`ARCHIVED`（需 archive_reason）— 不可静默删除
- 将 UNRESOLVED topic 同步至 `downstream_handoff.pending_decisions`

**不负责**：产品-研发对齐（→ #139）、发版决策（→ release-owner）、缺陷追踪（→ 缺陷管理系统）、测试计划（→ QA 团队）。

## When NOT to use this skill

- **Not a product-engineering alignment tool**: when the gap is between product expectations and engineering constraints (not QA), use #139 instead.
- **Not a defect tracking system**: #140 summarizes alignment on defect decisions; individual defect details belong in the defect management system.
- **Not a release decision maker**: #140 surfaces QA vs engineering gaps; the go/no-go release decision belongs to the release owner and N380.
- **Not a test plan**: test case design and coverage planning belong elsewhere; #140 only aligns on acceptance criteria and defect classification.
- **wont_fix boundary**: `defect_triage_label: wont_fix` requires `wont_fix_reason` AND `decision_owner` AND `risk_if_shipped` — all three are mandatory.

## Skill boundary: #139 vs #140

| Dimension | #139 product-eng-alignment | #140 qa-eng-alignment |
|-----------|---------------------------|----------------------|
| Gap source | PRD vs engineering constraints | Test expectations vs engineering implementation |
| Key topics | Feature scope, NFR, timeline | Defect triage, SLA, regression coverage |
| Decision owner | PM / ENG-lead | QA-lead / ENG-lead |
| Special mode | pre_release_alignment_check | defect_triage_alignment, performance_sla_alignment |

## Standalone and composition role

```yaml
standalone_goal: consolidate defect triage decisions, SLA gaps, and test coverage disagreements
minimum_viable_input:
  any_of:
    - QA 测试计划或验收标准
    - 缺陷列表或 bug triage 会议记录
    - 性能测试结果或 SLA 目标定义
    - 对齐会议记录或工程响应
partial_readiness_allowed: true
degradation_behavior: >
  If defect list is incomplete, output partial alignment with known topics.
  wont_fix topics without all three mandatory fields → mark as PENDING_CONFIRMATION.
  SLA gaps: if actual measurement is unavailable, mark as "待测量" and note open_blocker.
stance: summarize_not_judge
```

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `baseline_from_qa_notes`: 从 QA 测试计划或验收标准出发，逐条比对工程实现。
- `delta_topic_refresh`: 更新已有对齐摘要，保留 topic ID。变化条目须包含 `change_summary`。
- `faq_aware_consolidation`: 将 FAQ 中已覆盖的测试问题合并，避免重复讨论。
- `rehearsal_cycle_summary`: 迭代/版本节奏中的定期测研对齐盘点。
- **`defect_triage_alignment`**: 专用于缺陷分级会对齐，区分已确认 bug/待确认 bug/wont_fix，输出各类别数量汇总和 wont_fix risk summary。
- **`performance_sla_alignment`**: 专用于 SLA 协商，每个指标计算差距百分比（actual vs target），输出 ✅/❌ 汇总表，classification from `references/qa-sla-classification-guide.md`。

**Default routing**: defect review meeting → `defect_triage_alignment`. SLA negotiation → `performance_sla_alignment`. First alignment → `baseline_from_qa_notes`. Updating existing → `delta_topic_refresh`.

## Mandatory output sections

| # | Section | Required | Placeholder when missing |
|---|---------|----------|--------------------------|
| 1 | Metadata (artifact_id, selected_mode, source_time_window, readiness) | Always | — |
| 2 | Defect / SLA alignment topic register | Always | List all known topics; mark `wont_fix` items with three-field suite |
| 3 | wont_fix risk summary | Always in defect_triage_alignment | "本次无 wont_fix 条目" if none |
| 4 | SLA gap table (✅/❌ with gap_percentage) | Always in performance_sla_alignment | One row per SLA metric with target vs actual |
| 5 | 对齐议题变化汇总 | Always in delta_topic_refresh | "本次无变更" if no changes |
| 6 | Open items / evidence gaps | Always | Topics missing decision_owner or risk_if_shipped |
| 7 | Downstream handoff | Always | pending_decisions + wont_fix_risk_summary + readiness |

> Legend: Always = required in every mode unless noted; Conditional = required when the specific mode or trigger is active.

## Topic entry schema

每条对齐 topic 必须包含：

| Field | Required | Notes |
|-------|----------|-------|
| `topic_id` | Always | Stable ID; never reassign |
| `topic` | Always | Brief topic name |
| `qa_expectation` | Always | What QA expects |
| `engineering_response` | Always | What engineering delivered or committed to |
| `alignment_status` | Always | aligned / partial / unresolved / deferred / archived |
| `evidence_refs` | Always | Source material |
| `decision_owner` | Always | Role, not individual name |
| `defect_triage_label` | In defect_triage_alignment | confirmed_bug / needs_repro / wont_fix / by_design |
| `wont_fix_reason` | When wont_fix | Why not fixing; mandatory when defect_triage_label=wont_fix |
| `risk_if_shipped` | When wont_fix | What risk to users if shipped with defect; mandatory when wont_fix |
| `regression_scope_impact` | When topic affects regression | Which test suites or modules are impacted |
| `defer_reason` | When status=deferred | Why deferred |
| `archive_reason` | When status=archived | Why no longer relevant |

**N360 escalation threshold**: ≥2 consecutive sprint cycles with UNRESOLVED topics for the same decision_owner → flag for N380 escalation.

## Input conflict resolution

When the same defect or alignment topic appears in multiple sources with conflicting `alignment_status` or `defect_triage_label` values:
- Prefer the **most recent source** with QA-lead or ENG-lead attribution.
- Record the discrepancy: add `change_summary: "Triage conflict: [source A says wont_fix] vs [source B says confirmed_bug] — validated with QA-lead on [date]"`.
- Never silently resolve triage label conflicts; always surface to decision_owner.
- `wont_fix → confirmed_bug` reversals require a `regression_reason` field documenting what new evidence changed the decision.

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: version-scope-trimming-recommendation / N380-governance
  pending_decisions:
    - topic_id: QA-TOPIC-005
      decision_owner: qa-lead
      decision_deadline: "YYYY-MM-DD"
      impact_if_unresolved: "Release blocked pending defect triage resolution"
  wont_fix_risk_summary:
    - topic_id: QA-TOPIC-002
      risk_if_shipped: "10% of payment flows may fail under edge case X"
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all topics triaged, wont_fix entries have full three-element data) / `partial` (some defects PENDING_CONFIRMATION) / `degraded` (defect list only; no triage decisions confirmed — must not use as release gate input).

## Workflow position

```
QA test plans / defect lists / performance test results / SLA targets
  ↓ #140 (QA-engineering alignment → 测研对齐摘要.md)
  → UNRESOLVED topics → N360 #141 (scope trimming) / N380 (escalation)
  → wont_fix risk summary → release-owner go/no-go decision
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** `wont_fix` 条目缺少三件套之一（wont_fix_reason/decision_owner/risk_if_shipped）→ 所有三项均强制必填；缺一项则标为 PENDING_CONFIRMATION。量化检验：defect_triage_label=wont_fix 的条目中，wont_fix_reason/decision_owner/risk_if_shipped 任一缺失的条目数 = PENDING_CONFIRMATION 条目数；不等则 FAIL。
- **AP-2** `performance_sla_alignment` 模式未给出差距百分比 → 每个指标必须计算 (actual - target) / target × 100%；无数据时标"待测量"并触发 open_blocker。量化检验：performance_sla_alignment 模式下，gap_percentage 字段缺失（非空且非「待测量」）的指标数 = open_blocker 数。
- **AP-3** 已关闭 topic 直接删除 → 必须使用 ALIGNED/DEFERRED/ARCHIVED 终止态保留历史。量化检验：同 #139 AP-2 — 消失的 topic_id 数 = ARCHIVED 状态新增数，不等则存在静默删除。
- **AP-4** UNRESOLVED topic 只在正文列出而不传递 pending_decisions → 必须在 downstream_handoff 中同步。量化检验：正文中 alignment_status=UNRESOLVED 的 topic 数必须 ≤ downstream_handoff.pending_decisions 列表长度；漏同步则 FAIL。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n360-shared-cross-team-contract.md` — shared contract, ID format, handoff schema
- `references/n360-alignment-decision-guide.md` — skill selection and escalation thresholds
- `references/n360-input-validation-rules.md` — when input quality is uncertain
- `references/alignment-topic-schema.md` — topic field definitions (v2.1)
- `references/qa-sla-classification-guide.md` — when using performance_sla_alignment mode
- `references/rehearsal-coverage.md` — when using rehearsal_cycle_summary mode
- `references/qa-engineering-alignment-summary-quality-checklist.md` — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/qa-engineering-alignment.md` — defect_triage_alignment with wont_fix risk summary
- `examples/performance-sla-alignment-mode.md` — performance_sla_alignment with gap percentage table
