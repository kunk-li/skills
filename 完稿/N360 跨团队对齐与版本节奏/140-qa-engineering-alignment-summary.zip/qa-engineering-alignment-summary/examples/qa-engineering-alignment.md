# Example: QA-Engineering Alignment — Platform v2.3 Defect Triage

Demonstrates `defect_triage_alignment` mode with wont_fix rules, regression_scope_impact, and summary table.

```yaml
metadata:
  contract_version: n360-cross-team-v1.1.2
  skill_id: "140"
  selected_mode: defect_triage_alignment
  artifact_id: QEA-2025-06-11-V23
  version: Platform v2.3
  stance: summarize_not_judge
  readiness: complete
```

## 测研对齐摘要 — Platform v2.3 缺陷分级

**快照日期**: 2025-06-11  
**触发原因**: SIT 阶段发现 17 个缺陷，需在发版前完成分级决策

---

## 对齐议题

### QEA-001 订单超时返回错误码不一致
- **QA 期望**: 超时 60s 应返回 `408 Request Timeout`
- **研发视角**: 当前实现返回 `500 Internal Server Error`；框架层面修改影响全局异常处理
- **alignment_status**: unresolved
- **defect_triage_label**: confirmed_bug
- **decision_owner**: ENG-lead
- **decision_deadline**: 2025-06-12
- **regression_scope_impact**: 全局异常处理修改影响 payment、cart、inventory 三个模块的回归测试集
- **evidence_ref**: sit-report-2025-06-10#defect:BUG-441

### QEA-002 购物车超过 512 条时报错信息不友好
- **QA 期望**: 应显示用户可理解的错误提示，而非原始异常栈
- **研发视角**: 错误信息优化，2h 工时，低风险
- **alignment_status**: aligned
- **defect_triage_label**: confirmed_bug
- **decision_owner**: backend-team
- **regression_scope_impact**: 仅影响 cart-error-handling 测试集（12 个用例）
- **evidence_ref**: sit-report-2025-06-10#defect:BUG-442

### QEA-003 历史订单列表第 2 页偶现重复数据
- **QA 期望**: 分页数据不应有重复
- **研发视角**: 仅在特定并发条件下复现，本地环境未复现
- **alignment_status**: partial
- **defect_triage_label**: needs_repro
- **decision_owner**: backend-team
- **decision_deadline**: 2025-06-13（提供稳定复现步骤）
- **regression_scope_impact**: n/a（未确认为 bug）
- **evidence_ref**: sit-report-2025-06-10#defect:BUG-443

### QEA-004 Safari 15 下支付按钮样式偏移 2px
- **QA 期望**: 所有主流浏览器视觉一致
- **研发视角**: Safari 15 市场占有率 0.3%（内部数据），修复需引入 polyfill，有兼容性风险
- **alignment_status**: aligned
- **defect_triage_label**: wont_fix
- **wont_fix_reason**: "影响用户<0.3%，无功能性损失，仅视觉偏移2px；修复引入 polyfill 有兼容性风险；下版本优先修复"
- **decision_owner**: PM-role
- **regression_scope_impact**: n/a
- **evidence_ref**: sit-report-2025-06-10#defect:BUG-447

### QEA-005 库存查询 API 响应格式与接口文档不符（多余字段）
- **QA 期望**: 响应应严格符合接口文档 API-INV-003
- **研发视角**: 多余字段为内部调试字段，不影响客户端，移除需更新接口文档
- **alignment_status**: aligned
- **defect_triage_label**: by_design
- **decision_owner**: ENG-lead + API-owner
- **decision_deadline**: 2025-06-14（更新接口文档）
- **regression_scope_impact**: n/a（by design 确认后更新文档即可）
- **evidence_ref**: sit-report-2025-06-10#defect:BUG-449

---

## 缺陷分级汇总

| 类别 | 数量 | 备注 |
|-----|-----|-----|
| confirmed_bug | 2 | BUG-441 (P1, 待决), BUG-442 (P2, 已对齐) |
| needs_repro | 1 | BUG-443, 截止 2025-06-13 确认 |
| wont_fix | 1 | BUG-447, reason 已记录，decision_owner: PM-role |
| by_design | 1 | BUG-449, 更新接口文档关闭 |
| **合计** | **5** | |

---

## Downstream Handoff

```yaml
handoff_id: QEA-HANDOFF-2025-06-11
consumer_skill_or_node: N350|release-owner
pending_decisions:
  - topic_id: QEA-001
    decision_owner: ENG-lead
    deadline: 2025-06-12
    impact_if_missed: "BUG-441 P1 缺陷未决策，发版存在 P1 open 风险"
  - topic_id: QEA-003
    decision_owner: backend-team
    deadline: 2025-06-13
    impact_if_missed: "BUG-443 复现情况不明，无法评估回归范围"
readiness: complete
confidence: high
next_best_checks:
  - QEA-001 decision by 2025-06-12 (P1 gate)
  - QEA-003 repro steps by 2025-06-13
  - wont_fix BUG-447 signed off by PM-role before release
```
