# Performance SLA Alignment Mode Example — QA-Engineering Alignment #140

## Metadata

```yaml
artifact_id: QA-ENG-SLA-001
skill_id: 140
contract_version: n360-cross-team-v1.1.2
selected_mode: performance_sla_alignment
source_time_window: "2025-06-sprint-12"
decision_owner: qa-lead + eng-lead
readiness: partial
```

## SLA Alignment Summary Table

| Metric | Target | Actual (P95) | Gap | Status | Classification |
|--------|--------|-------------|-----|--------|---------------|
| API response time /checkout | ≤200ms | 310ms | +55% | ❌ | HARD_SLA — release blocker |
| API response time /search | ≤500ms | 480ms | −4% | ✅ | Within tolerance |
| Error rate (5xx) | ≤0.1% | 0.08% | −20% | ✅ | Compliant |
| Page load time (P99) | ≤3s | 4.2s | +40% | ❌ | SOFT_SLA — degraded UX |
| Background job completion | ≤30min | 28min | −7% | ✅ | Compliant |
| DB query p95 (order lookup) | ≤50ms | 87ms | +74% | ❌ | HARD_SLA — blocks /checkout |

**Gap calculation method**: `(actual - target) / target × 100%`

### Hard SLA Violations (Release Blockers)

**QA-SLA-003**: `/checkout` p95 response time 310ms vs target 200ms (+55%)
- **QA expectation**: ≤200ms required per NFR-007 (customer-facing checkout SLA)
- **Engineering response**: DB query optimization needed; query plan shows full table scan on `order_items.status`; index migration M-044 not yet deployed
- **alignment_status**: unresolved
- **decision_owner**: eng-lead
- **decision_deadline**: 2025-06-13 (sprint 12 end)
- **impact_if_unresolved**: Release gated — /checkout SLA breach in production constitutes contractual violation with 3 enterprise customers

**QA-SLA-006**: DB query p95 (order lookup) 87ms vs target 50ms (+74%)
- **QA expectation**: ≤50ms per backend NFR; directly causes /checkout regression above
- **Engineering response**: Root cause is missing composite index on `(user_id, status, created_at)`; fix is in PR #891 pending review
- **alignment_status**: partial — fix identified, not yet deployed
- **decision_owner**: eng-lead
- **decision_deadline**: 2025-06-12

### Soft SLA Degradations (Acceptable with Tracking)

**QA-SLA-004**: Page load time p99 4.2s vs target 3s (+40%)
- **QA expectation**: ≤3s per UX guideline (not contractual)
- **Engineering response**: Caused by unoptimized bundle size; bundler optimization planned for sprint 13
- **alignment_status**: deferred
- **defer_reason**: Not a release blocker; sprint 13 work item created
- **decision_owner**: eng-lead

## Risk Summary

| Severity | Count | Action |
|----------|-------|--------|
| Hard SLA violation (release blocker) | 2 | Must resolve before release gate |
| Soft SLA degradation (deferred) | 1 | Tracked in sprint 13 |
| Compliant | 3 | No action |

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: version-scope-trimming-recommendation / release-owner
  pending_decisions:
    - topic_id: QA-SLA-003
      decision_owner: eng-lead
      decision_deadline: "2025-06-13"
      impact_if_unresolved: "Release gated — contractual SLA breach"
    - topic_id: QA-SLA-006
      decision_owner: eng-lead
      decision_deadline: "2025-06-12"
      impact_if_unresolved: "Root cause of QA-SLA-003; unblocks checkout"
  wont_fix_risk_summary: []
  readiness: partial
```
