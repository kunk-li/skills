# Example: QA-Engineering Alignment — FAQ-Aware Consolidation Mode

## Metadata

```yaml
artifact_id: ALIGN-QA-ENG-003
skill_id: 140
contract_version: n360-cross-team-v1.1.2
selected_mode: faq_aware_consolidation
source_time_window: "2025-06-sprint-12"
faq_source_ids: [FAQ-QA-001, FAQ-QA-002, FAQ-QA-007, FAQ-QA-012]
readiness: complete
```

## QA-Engineering Alignment Topic Register

| topic_id | topic | qa_expectation | engineering_response | alignment_status | decision_owner | evidence_refs |
|----------|-------|---------------|---------------------|-----------------|----------------|---------------|
| QA-TOPIC-001 | /checkout 响应时间 p95 | ≤200ms（NFR-007 合同 SLA） | 当前 310ms；索引优化 PR #891 待部署 | unresolved | eng-lead | FAQ-QA-001, SLA-report-2025-06-12 |
| QA-TOPIC-002 | 支付回调幂等性验证 | 重复回调必须返回 200，不重复处理 | 已实现幂等键（idempotency_key）；逻辑验证通过 | aligned | — | FAQ-QA-002, PR-887 |
| QA-TOPIC-003 | 移动端兼容性覆盖 | iOS 15+ / Android 10+ | iOS 覆盖完整；Android 仅测 Android 12+ | partial | qa-lead | FAQ-QA-007 |
| QA-TOPIC-004 | 数据迁移回滚验证 | 迁移失败时 10min 内可完整回滚 | RTO 已演练，结果 8min；演练报告已归档 | aligned | — | FAQ-QA-012, rollback-drill-2025-06-10 |

## FAQ 已覆盖问题合并说明

以下来自 N340 #133 的 FAQ 条目已在本次对齐中被处理，**不再重复讨论**：

| faq_item_id | 原始问题 | 合并方式 | 对应 topic_id |
|-------------|---------|---------|--------------|
| FAQ-QA-001 | /checkout 慢的问题什么时候修？ | 转化为 QA-TOPIC-001 UNRESOLVED 对齐议题 | QA-TOPIC-001 |
| FAQ-QA-002 | 重复点击支付会不会扣两次钱？ | 已确认 aligned，FAQ 条目标记为 stale_risk=low | QA-TOPIC-002 |
| FAQ-QA-007 | Android 9 设备能用吗？ | 转化为 QA-TOPIC-003 partial 对齐议题 | QA-TOPIC-003 |
| FAQ-QA-012 | 数据迁移如果失败怎么办？ | 已确认 aligned（演练通过），FAQ 条目标记为 complete | QA-TOPIC-004 |

**4 个 FAQ 条目处理完毕，避免在对齐会议中重复讨论已解答问题。**

## Open Items / Evidence Gaps

- QA-TOPIC-001：decision_deadline 未确认 → 需 eng-lead 在 2025-06-14 前给出 PR #891 部署时间表
- QA-TOPIC-003：Android 9 覆盖决策待 QA-lead 确认：是否 wont_fix 或推迟至 v2.4

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: version-scope-trimming-recommendation / N380-governance
  pending_decisions:
    - topic_id: QA-TOPIC-001
      decision_owner: eng-lead
      decision_deadline: "2025-06-14"
      impact_if_unresolved: "SLA contractual breach — HARD release blocker"
    - topic_id: QA-TOPIC-003
      decision_owner: qa-lead
      decision_deadline: "2025-06-15"
      impact_if_unresolved: "Android 9 compatibility unclear for affected customer segment"
  wont_fix_risk_summary: []
  faq_items_consolidated: [FAQ-QA-001, FAQ-QA-002, FAQ-QA-007, FAQ-QA-012]
  readiness: complete
```
