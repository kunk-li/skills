# 测研对齐摘要 quality checklist

1. Metadata is complete and `contract_version` is `n360-cross-team-v1.1.2`.
2. `selected_mode` is one of the modes in `references/output-contract.yaml`.
3. `stance` is `summarize_not_judge` and matches the skill boundary.
4. `artifact_id` and row IDs follow the N360 naming rule or are explicitly temporary.
5. CSV headers exactly match `n360.qa-engineering-alignment.v2` when CSV is emitted.
6. Multi-value CSV fields use `|`, not bare commas.
7. Evidence refs include source, confidence, layer, and pointer where possible.
8. `cross_artifact_refs` use stable IDs from N340/N350/N360/N330/N320 rather than file paths.
9. `pending_decisions`, `open_blockers`, and `owner_placeholders` are explicit when evidence is incomplete.
10. downstream_handoff contains `handoff_id`, consumer, `decision_target_node` when relevant, required_fields, readiness, confidence, and next_best_checks.
11. Compare the produced artifact against the most relevant example under `examples/`; differences are allowed but should be intentional.

## Skill-specific checks
- QA and engineering views are separated before synthesis.
- FAQ-covered items are referenced rather than re-created as new disputes.
- No pass rate, severity, or coverage is invented without evidence.
- High-risk or gate-fail signals are routed to scope review rather than decided here.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- `defect_triage_alignment` mode: every defect has `defect_triage_label` assigned — no blank labels.
- `wont_fix` label always accompanied by `wont_fix_reason` and `decision_owner` — missing either triggers open_blocker.
- Summary table (confirmed_bug/needs_repro/wont_fix/by_design) always present at end of defect_triage output.

## Output structure completeness checks
- All 6 mandatory sections present per mandatory section table
- `defect_triage_label` assigned to every defect topic
- Defect summary table present in defect_triage_alignment mode

## Mode-specific checks

### defect_triage_alignment mode
- wont_fix entries have reason + decision_owner + risk_if_shipped (all 3)
- Defect summary table: confirmed_bug/needs_repro/wont_fix/by_design counts correct

### performance_sla_alignment mode
- SLA汇总表 present with ✅/❌ status for each metric
- Gap percentage calculated for every unresolved metric
