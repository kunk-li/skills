# qa-engineering alignment topic schema v2.1

schema: `n360.qa-engineering-alignment.v2`

## default markdown table
| topic_id | 议题 | QA视角 | 研发视角 | 当前差异 | alignment_status | defect_triage_label | 待决方 | decision_deadline | regression_scope_impact | evidence_ref |
|---|---|---|---|---|---|---|---|---|---|---|

## csv columns
`topic_id,topic,qa_view,engineering_view,current_gap,alignment_status,defect_triage_label,wont_fix_reason,decision_owner,decision_deadline,regression_scope_impact,evidence_ref`

## field rules
- `topic_id`: 稳定 id，如 `QEA-001`
- `qa_view`: QA 期望、验收标准、测试要求或缺陷描述
- `engineering_view`: 技术实现、约束、修复成本或设计意图
- `current_gap`: 只描述当前差异，不给裁判结论
- `alignment_status`: `aligned` | `partial` | `unresolved` | `deferred`
- `defect_triage_label`: `confirmed_bug` | `needs_repro` | `wont_fix` | `by_design` | `n/a`
- `wont_fix_reason`: 仅当 `defect_triage_label = wont_fix` 时必填；说明不修复的依据
- `decision_owner`: 负责拍板的角色；未知时写 `待确认`
- `decision_deadline`: **必填当 alignment_status = unresolved**
- `regression_scope_impact`: 此议题影响的回归范围（测试集名称、模块、用例 ID）；`n/a` 如不影响

## defect_triage_label rules
- `confirmed_bug`: QA 和 ENG 均确认是缺陷；必须有修复计划或 scope_trim decision
- `needs_repro`: 缺陷尚未稳定复现；ENG 需提供复现步骤确认
- `wont_fix`: 决定不修复；**必须填写 `wont_fix_reason` 和 `decision_owner`**
- `by_design`: 当前行为符合设计意图；需 PM 或 ENG-lead 签字确认
- `n/a`: 非缺陷类议题（如验收标准对齐、测试范围讨论）

## wont_fix mandatory content
```yaml
wont_fix_reason: "影响范围<0.01%用户，无安全风险，本版本修复成本超过3人天，下版本优先修复"
decision_owner: PM-role
# Note: wont_fix WITHOUT reason is not allowed — use open_blocker instead
```

## defect triage summary table
Append this at the end of `defect_triage_alignment` mode output:
```markdown
| 类别 | 数量 | 备注 |
|-----|-----|-----|
| confirmed_bug | N | [P0: X, P1: Y, P2: Z] |
| needs_repro | N | |
| wont_fix | N | 均已记录 reason |
| by_design | N | |
```

## csv rules
- RFC-4180, UTF-8
- 列表字段不用裸逗号，统一 `|`
