# QA-Engineering Alignment: SLA Classification Guide

Use this reference when classifying QA performance expectations vs engineering measurements in `performance_sla_alignment` mode.

## SLA gap classification

| Gap level | Definition | Action |
|-----------|-----------|--------|
| Aligned | Measured value meets or exceeds QA expectation | Document as `alignment_status: aligned` |
| Minor gap (< 20%) | Close to expectation; may resolve with optimization | `alignment_status: partial`; include optimization plan |
| Major gap (20-50%) | Significant deviation; requires architecture decision | `alignment_status: unresolved`; escalate to PM + ENG-lead |
| Critical gap (> 50%) | Cannot be bridged without scope or contract change | `alignment_status: unresolved`; include Sales/PM/ENG-lead |

## Required fields for `performance_sla_alignment` mode

Every SLA topic must include:
- `QA 期望`: the exact SLA requirement (number + unit + source document)
- `研发实测`: the measured result (number + test conditions + date)
- `测试条件`: environment, load level, warm-up status
- `alignment_status`: aligned / partial / unresolved
- `decision_deadline` and `decision_owner`: for all unresolved topics
- `impact_if_unresolved`: specific consequence for the release

## Performance SLA汇总表 (mandatory for defect_triage_alignment mode)

At the end of the artifact, always include a summary table:

| SLA 指标 | QA 期望 | 实测结果 | 状态 | 差距 |
|---------|---------|---------|------|------|
| ... | ... | ... | ✅/❌ | % |

**Aligned**: N/M | **Unresolved**: M-N/M

## defect_triage_alignment汇总表 (mandatory)

At the end of defect_triage mode:

| Label | Count |
|-------|-------|
| confirmed_bug | N |
| needs_repro | N |
| wont_fix | N |
| by_design | N |
| **Total** | **N** |

## Interaction with #139 (product-engineering-alignment)

- #139 covers product expectation vs engineering constraints (feature-level)
- #140 covers QA expectation vs engineering implementation (test/defect-level)
- When a defect reveals a product-engineering misalignment, escalate to #139

## wont_fix mandatory fields

A `wont_fix` classification requires ALL of:
1. `wont_fix_reason`: specific technical or business reason
2. `decision_owner`: role (not person) who approved the wont_fix
3. `risk_if_shipped`: what the consequence is of shipping without fixing

Missing any of these makes the wont_fix classification incomplete.
