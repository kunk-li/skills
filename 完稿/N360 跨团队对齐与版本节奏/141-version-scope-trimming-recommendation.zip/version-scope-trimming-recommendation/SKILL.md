---
name: version-scope-trimming-recommendation
description: 生成版本范围裁剪建议（版本裁剪方案）用于 n360 发版治理。triggered when a release-owner, PM, or ENG-lead needs a structured trim recommendation after scope_trim_candidate=yes signals arrive from n350 #138, or when release gate failures require a minimum-cut analysis. produces mandatory and optional trim tables with release_date_impact and dependency_chain for each option. stance is always recommend_not_decide — final trim decisions belong to the release-owner, never to this skill. use emergency_trim mode inside T-3 days. do not use for risk identification (→ n350 #138), milestone tracking (→ #142), or making trim decisions (→ release-owner).
---

# 版本范围裁剪建议

## N360 contract baseline (n360-cross-team-v1.1.2)

- contract_version: `n360-cross-team-v1.1.2`
- workflow_node: N360
- skill_id: 141
- artifact_family_id: `n360-cross-team-governance-suite`
- csv_schema: `n360.version-scope-trimming.v2`
- stance: `recommend_not_decide`
- artifact target: `版本范围裁剪建议.md / version-scope-trimming.csv`
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: standalone output must include metadata and downstream_handoff; combined output reuses stable upstream IDs and sibling artifact IDs.

## Role

作为 N360 治理层的**版本范围裁剪建议生成器**，基于风险信号和对齐缺口提出裁剪建议，但不做最终决策。

具体职责：
- 以 `recommend_not_decide` 立场产出建议（mandatory/optional 两档严格分离，不可合并）
- 每条建议必须包含 `release_date_impact`（量化影响天数或"无影响"）
- 每条建议必须包含 `dependency_chain`（裁剪此功能会连锁影响哪些其他功能）
- 接收 N350 #138 的 `scope_trim_candidate=YES` 信号并转化为结构化建议
- `emergency_trim` 模式：使用压缩输出格式（仅 mandatory/optional 两张表格），保护 release-owner 的决策权

**不负责**：做裁剪决策（→ release-owner）、识别风险（→ #138）、对齐确认（→ #139/#140）、里程碑跟踪（→ #142）。

## When NOT to use this skill

- **Not a risk register**: risk identification belongs in N350 #138; #141 acts on risk signals to recommend trimming.
- **Not a product requirements tool**: which features to build belongs in PRD; #141 recommends what to trim from an already-defined scope.
- **Not a release decision maker**: #141 recommends and does not decide; final trim decision belongs to release-owner and N380.
- **Not a project plan**: #141 responds to a specific version's scope; project-level planning belongs to N360 #142.

## Standalone and composition role

```yaml
standalone_goal: produce structured trim recommendations with mandatory/optional separation and release_date_impact for each option
minimum_viable_input:
  any_of:
    - N350 #138 输出的 scope_trim_candidates（含 risk_score）
    - 当前版本 scope 清单或功能列表
    - 发版计划或里程碑清单
    - 质量门失败记录（gate_triggered_review 模式）
    - release gate 失败原因说明
partial_readiness_allowed: true
degradation_behavior: >
  If scope list is incomplete, produce recommendations for known scope items only.
  release_date_impact can be "待评估" — but field must be present.
  dependency_chain can be empty list [] — but field must be present.
  emergency_trim mode: use compressed output (2 tables only) — skip non-essential sections.
stance: recommend_not_decide
```


## Mandatory output sections

| # | Section | Required | Placeholder when missing |
|---|---------|----------|--------------------------|
| 1 | Metadata (artifact_id, selected_mode, readiness) | Always | — |
| 2 | Mandatory trim table | Always | "本次无强制裁剪建议" if none |
| 3 | Optional trim table | Always | "本次无可选裁剪建议" if none |
| 4 | release_date_impact per item | Always | "待评估" if unknown |
| 5 | dependency_chain per item | Always | `[]` if no cascade |
| 6 | Downstream handoff (signoff_required_from, readiness) | Always | — |

> Note: mandatory_trim and optional_trim MUST be separate tables — never merged. emergency_trim mode outputs only these two tables.

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `fresh_assessment`: 全量评估，从当前范围清单开始。
- `delta_recommendation`: 更新已有裁剪建议，保留 item ID，仅修改变化条目。
- `gate_triggered_review`: 由门禁失败触发的强制评审，重点覆盖失败原因和最小裁剪路径。
- `signoff_chain_refresh`: 刷新签署链状态，识别已签和待签条目。
- **`emergency_trim`**: 发版 T-3 天内的紧急裁剪。使用**压缩输出格式**：仅输出 mandatory_trim 和 optional_trim 两张表格，每张表格各列 `item_id`/`feature_or_scope`/`trim_reason`/`release_date_impact`/`dependency_chain`。跳过其他非必要 sections。

**Default routing**: first trim assessment → `fresh_assessment`. Gate failure → `gate_triggered_review`. T-3 days → `emergency_trim`.

## Decision option schema

每个裁剪选项必须包含：

| Field | Required | Notes |
|-------|----------|-------|
| `item_id` | Always | Stable ID |
| `feature_or_scope` | Always | What is being considered for trim |
| `recommendation` | Always | keep / trim / split / defer |
| `trigger_reason` | Always | Why this item is flagged |
| `tradeoff` | Always | What is gained and lost by this recommendation |
| `confidence` | Always | high / medium / low |
| `signoff_required_from` | Always | Role(s) that must approve |
| `release_date_impact` | Always | "无影响" / "延期N天" / "提前N天" / "待评估" |
| `dependency_chain` | Always | List of other features impacted if this is trimmed; `[]` if none |

## Emergency trim output format

When `selected_mode=emergency_trim`, use this compressed structure only:

```
## Mandatory Trim (不裁则违反 hard rule)
| item_id | feature_or_scope | trim_reason | release_date_impact | dependency_chain |

## Optional Trim (可选裁剪，由 release-owner 决定)
| item_id | feature_or_scope | trim_reason | release_date_impact | dependency_chain |
```

Do not produce full mandatory output sections in emergency_trim — time pressure means the release-owner needs a decision-ready 2-table format, not a full report.

**Emergency trim two-tier rule**:
- `mandatory_trim`: 不裁则无法满足 hard rule（P0 缺陷未修复、安全漏洞、合规要求）
- `optional_trim`: 裁减有益但非强制；release-owner 自行决定

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: release-owner / N380-governance
  mandatory_trim_items: [TRIM-001, TRIM-002]
  optional_trim_items: [TRIM-003]
  signoff_required_from: [pm-lead, eng-lead]
  readiness: complete | partial | degraded
```

`readiness` values: `complete` (all items have recommendation, release_date_impact, dependency_chain, and signoff_required_from populated) / `partial` (some items have 待评估 for release_date_impact) / `degraded` (item list only; no tradeoff or release_date_impact analysis — must not be used for release decisions without further triage).

## Workflow position

```
N350 #138 scope_trim_candidates / release gate failures / alignment UNRESOLVED topics
  ↓ #141 (scope trimming recommendation → 版本范围裁剪建议.md)
  → mandatory/optional trim recommendation → release-owner decision
  → unresolved scope → N380 (governance escalation)
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** mandatory_trim 与 optional_trim 合并为一张表 → 两档必须严格分离；保护 release-owner 的决策空间。量化检验：输出中 mandatory_trim 和 optional_trim 必须各自独立为表格；混入同一表格的条目数 = FAIL 数。
- **AP-2** `release_date_impact` 留空 → 字段必须存在；未知时写"待评估"。量化检验：裁剪条目中，release_date_impact 字段缺失或为空字符串的条目数 = FAIL 数；「待评估」为合法占位值。
- **AP-3** `dependency_chain` 省略 → 字段必须存在；无级联影响时写 `[]`。量化检验：裁剪条目中，dependency_chain 字段完全缺失的条目数 = FAIL 数；`[]` 为合法值（表示无级联）。
- **AP-4** 在建议中直接写"应该裁剪"等决策性语言 → stance 为 recommend_not_decide；所有建议必须给 release-owner 留决策空间（如"建议考虑裁剪…"）。量化检验：正文（非 Metadata/Reference 节）中出现「应该裁剪」/「必须裁剪」/「must trim」/「should trim」（不含「建议」前缀）的句子数 = FAIL 数。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n360-shared-cross-team-contract.md` — shared contract, ID format, handoff schema
- `references/n360-alignment-decision-guide.md` — skill selection and escalation thresholds
- `references/n360-input-validation-rules.md` — when input quality is uncertain
- `references/decision-option-schema.md` — full decision option field definitions
- `references/trigger-rules-dsl.md` — when evaluating scope_trim_candidate trigger conditions
- `references/hard-rule-violation.md` — when classifying mandatory vs optional trim
- `references/scope-trim-dependency-chain.md` — when analyzing cascading effects of trimming
- `references/version-scope-trimming-recommendation-quality-checklist.md` — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/version-scope-trimming.md` — fresh_assessment with mandatory/optional separation
- `examples/n350-to-n360-governance-flow.md` — #138 scope_trim_candidate → #141 recommendation flow
