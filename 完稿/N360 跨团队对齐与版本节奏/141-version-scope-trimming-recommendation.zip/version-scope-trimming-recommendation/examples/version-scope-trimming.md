---
artifact_id: SCOPE-TRIM-2025-06-11
contract_version: n360-cross-team-v1.1.2
skill_id: 141
producer_skill: version-scope-trimming-recommendation
selected_mode: emergency_trim
stance: recommend_not_decide
version: Platform v2.3
days_to_release: 3
readiness: complete
---

# 版本范围裁剪建议 — Platform v2.3 紧急评估

**日期**: 2025-06-11（距发版 T-3）  
**触发原因**: gate_triggered_review — SIT 阶段发现 2 个 P1 缺陷，当前版本无法按时修复全部问题  
**模式**: emergency_trim  

## 当前风险摘要
- 高危风险: 3 个（RISK-003, RISK-007, RISK-009）
- 已确认 P1 缺陷: 2 个（BUG-441, BUG-447）
- 未对齐议题: 1 个（PEA-003 购物车上限）

---

## 必须裁剪（Mandatory Trim）
不裁则无法满足 hard rule

| item_id | feature | 裁剪理由 | 依赖链 | 发版影响 |
|---------|---------|---------|-------|---------|
| ST-M-001 | 实时库存推送 | BUG-441 P1 缺陷，修复需 5 天，超出发版窗口 | 库存告警通知（必须同裁） | 若不裁：发版延期 5 天 |
| ST-M-002 | 库存告警通知 | 与实时推送共用 WebSocket 基础设施，不可单独保留 | — | 与 ST-M-001 绑定 |

**dependency_chain 说明**: ST-M-001 和 ST-M-002 共用同一 WebSocket 服务层，技术上不可拆分。裁剪 ST-M-001 必须同时裁剪 ST-M-002。

---

## 可选裁剪（Optional Trim）
裁掉可降低发版风险，不裁也满足 hard rule

| item_id | feature | 裁剪理由 | 依赖链 | 发版影响（若裁） |
|---------|---------|---------|-------|-------------|
| ST-O-001 | 购物车数量上限配置 | PEA-003 未决策，风险残留 | 无 | 提前 1 天；规避上限 bug 风险 |
| ST-O-002 | 高级筛选高级模式 | BUG-447 P1 影响此功能，修复不确定 | 无 | 减少 1 天 QA 工作量 |

---

## 组合场景发版影响

| 场景 | 内容 | 预计发版日期 |
|-----|-----|-----------|
| 最小裁剪（仅必须） | 裁 ST-M-001 + ST-M-002 | 2025-06-14（准时） |
| 全裁 | 必须 + 全部可选 | 2025-06-13（提前 1 天） |
| 不裁 | 保留所有功能 | 2025-06-19（延期 5 天） |

---

## downstream_handoff
```yaml
handoff_id: SCOPE-TRIM-HANDOFF-001
consumer_skill_or_node: release-owner|N370|N380
decision_target_node: release-owner
required_fields:
  - 决定裁剪组合（最小 / 全裁 / 不裁）
  - 签署裁剪决策记录
  - 通知受影响的产品方和客户
confidence: high
next_best_checks:
  - release-owner 签署裁剪决策（ST-M-001 + ST-M-002 必须裁）
  - PM 确认 PEA-003 是否接受推迟（ST-O-001）
  - QA-lead 确认 BUG-447 影响范围（ST-O-002）
```
