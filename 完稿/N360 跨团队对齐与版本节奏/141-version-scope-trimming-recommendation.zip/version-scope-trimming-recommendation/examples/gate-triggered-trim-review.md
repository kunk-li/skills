# Gate-Triggered Trim Review Example — Version Scope Trimming #141

## Metadata

```yaml
artifact_id: TRIM-GATE-001
skill_id: 141
contract_version: n360-cross-team-v1.1.2
selected_mode: gate_triggered_review
trigger_source: "QA release gate failure — 2 hard SLA violations"
trigger_date: "2025-06-13"
version: v2.4.0
signoff_required_from: [pm-lead, eng-lead, release-owner]
readiness: complete
```

## Gate Failure Summary

**Gate**: Pre-release quality gate — Sprint 12 exit criteria
**Failures**:
1. `/checkout` p95 response time: 310ms (target ≤200ms) — Hard SLA
2. DB order lookup p95: 87ms (target ≤50ms) — Hard SLA root cause

**Available fix timeline**: DB index PR #891 requires 2 days to deploy + validate. Release date is T+1.

**Trim analysis objective**: Identify minimum scope reduction to enable on-time release OR recommend delay.

---

## Mandatory Trim (不裁则违反 hard rule)

| item_id | feature_or_scope | trim_reason | release_date_impact | dependency_chain |
|---------|-----------------|-------------|--------------------:|:----------------|
| TRIM-001 | 批量订单导出功能 (FEAT-089) | 使用 `orders` 全表扫描，加剧 DB 查询负载，与 SLA 修复竞争索引资源 | 无影响（独立功能，无下游依赖） | [] |

**Rationale**: FEAT-089 uses an unindexed full-table scan pattern identical to the failing query. Deploying it alongside the SLA fix creates risk of regression. Trim enables clean SLA validation window.

---

## Optional Trim (可选裁剪，由 release-owner 决定)

| item_id | feature_or_scope | trim_reason | release_date_impact | dependency_chain |
|---------|-----------------|-------------|--------------------:|:----------------|
| TRIM-002 | 高级搜索过滤器 v2 (FEAT-091) | 功能已可用，v2 仅增加 3 个过滤维度，可延至 v2.4.1 | 无影响 | [] |
| TRIM-003 | 管理后台报表导出 (FEAT-094) | 低优先级，仅内部用户；推迟不影响 SLA 修复窗口 | 无影响 | [FEAT-096 依赖此报表数据] |

**Note**: TRIM-003 has downstream dependency FEAT-096 — if trimmed, verify FEAT-096 is also out of scope or can proceed independently.

---

## Recommendation (recommend_not_decide)

Based on the gate failure analysis, the minimum viable path to on-time release is:
- **Apply TRIM-001** (mandatory) to reduce DB load during SLA fix validation
- **Consider TRIM-002** if sprint capacity is tight for v2.4.1 prep
- **Defer TRIM-003** decision pending FEAT-096 dependency check with PM

The final trim decision belongs to the release-owner. This document provides structured options only.

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: release-owner / N380-governance
  mandatory_trim_items: [TRIM-001]
  optional_trim_items: [TRIM-002, TRIM-003]
  signoff_required_from: [pm-lead, eng-lead, release-owner]
  dependency_warnings:
    - "TRIM-003 removal may impact FEAT-096 — confirm with PM before deciding"
  readiness: complete
```
