# Example: N350→N360 Governance Flow

Shows how RISK-007 (scope_trim=YES from #138) triggers #141 emergency_trim,
which feeds back into #139 pre_release_alignment and #142 rhythm snapshot.

---

## Trigger

From `RISK-S23-W24` (#138 output):
- RISK-007: `risk_score=16`, `scope_trim_candidate=YES`, auth-team dependency
- System sent to N360 for version governance review (T-14 days to release)

---

## #141 Version Scope Trimming Recommendation

**Mode**: `emergency_trim` (T-14 days)

### 必须裁剪

| item_id | feature | 裁剪理由 | dependency_chain | release_date_impact |
|---------|---------|---------|-----------------|---------------------|
| — | 无必须裁剪项 | 当前无 hard rule 违反（P0缺陷已修复，合规门已通过） | — | — |

### 可选裁剪

| item_id | feature | 裁剪理由 | dependency_chain | 发版影响（若裁） |
|---------|---------|---------|-----------------|-------------|
| ST-O-001 | OAuth 第三方登录（依赖 auth-team spec） | RISK-007 score=16，外部依赖 BLK-008 未解阻；mock-first 方案仅能覆盖内部联调，无法支撑完整第三方场景 | 影响"合作方 ABC 集成"（T-034）；co_trim_required: yes | 提前 2 天，同时裁掉 T-034 |
| ST-O-002 | 购物车数量上限可配置化 | PEA-003 未决策（截止 2025-06-12 逾期），技术约束明确（512条硬限制） | 无 | 减少 1 天 QA 回归工作 |

### 组合场景发版影响

| 场景 | 内容 | 预计发版日期 |
|-----|-----|-----------|
| 不裁剪任何功能 | 等待 BLK-008 解阻 | 2025-06-28（延期 3 天，若 spec 不来） |
| 仅裁 ST-O-001 | OAuth 推至 v2.4 | 2025-06-25（准时） |
| 全裁 ST-O-001+ST-O-002 | OAuth + 购物车上限均推迟 | 2025-06-24（提前 1 天） |

```yaml
downstream_handoff:
  handoff_id: SCOPE-TRIM-HANDOFF-2025-06-11
  consumer_skill_or_node: release-owner|N370
  decision_target_node: release-owner
  pending_decisions:
    - item_id: ST-O-001
      decision_owner: PM|ENG-lead
      deadline: 2025-06-13
      impact_if_missed: "若 BLK-008 未解阻且不裁剪，发版延期至 2025-06-28"
  confidence: high
```

---

## #139 Product-Engineering Alignment (pre_release check)

Updated to reflect scope trim decision:

### PEA-003 购物车数量上限 → Status updated

```yaml
topic_id: PEA-003
topic: 购物车数量上限
alignment_status: deferred  # was: unresolved
decision_owner: PM
decision_deadline: 2025-06-13 (scope trim decision deadline)
impact_if_unresolved: n/a (now deferred to v2.4 per ST-O-002 trim decision)
evidence_ref: scope-trim:ST-O-002|SCOPE-TRIM-HANDOFF-2025-06-11
```

### PEA-007 OAuth 第三方登录 → New topic added

```yaml
topic_id: PEA-007
topic: OAuth 第三方登录是否纳入 v2.3
product_view: 合作方 ABC 期望 v2.3 上线，已有合同承诺
engineering_view: auth-team spec 延期，mock-first 方案无法覆盖完整第三方场景
current_gap: 合同承诺 vs 技术就绪度冲突
alignment_status: unresolved
decision_owner: PM|ENG-lead|BD-role
decision_deadline: 2025-06-13
impact_if_unresolved: 若保留功能但 spec 仍未到，发版延期 3 天；若裁剪，需 BD 与合作方沟通推迟
evidence_ref: RISK-S23-W24#RISK-007|scope-trim:ST-O-001
```

---

## #142 Project Rhythm Snapshot Update (delta_mode)

**变更摘要（相比 2025-06-11 快照）**

- 状态变化: RM-004 at_risk → slipped（BLK-008 未在 2025-06-14 解阻）
- scope trim decision: ST-O-001 accepted — RM-004 scope reduced to internal OAuth only
- 新完成: 无
- ID 保留确认: RM-001 ~ RM-008 均保留

```
rhythm_id: RM-004
milestone_name: 联调完成（scope adjusted: OAuth 第三方场景移至 v2.4）
planned_date: 2025-06-14
current_forecast: 2025-06-17 (slippage reduced from 3→3 days; scope trim prevents further slip)
status: at_risk
slippage_days: 3
slippage_root_cause: dependency_delay
recovery_plan: ST-O-001 trim accepted; internal OAuth联调 scope 内完成，目标不变
```

---

## Cross-Node Flow Summary

```
RISK-S23-W24 (N350 #138)
  RISK-007 scope_trim=YES
      ↓ N360 triggered
#141 emergency_trim
  ST-O-001 optional trim recommended (OAuth deferred to v2.4)
  ST-O-002 optional trim recommended (购物车上限 deferred)
      ↓ decision: ST-O-001 accepted, ST-O-002 accepted
#139 pre_release_alignment
  PEA-003 unresolved → deferred (closed)
  PEA-007 new topic: OAuth contractual vs technical gap
      ↓ pending decision PEA-007 by 2025-06-13
#142 delta rhythm snapshot
  RM-004 scope reduced; slippage managed
      ↓ readiness: YELLOW maintained (not escalated to RED)
release-owner
  Sign off on ST-O-001 + ST-O-002 trim decisions
  Notify BD re: ABC OAuth timeline shift
```

All artifacts cite each other by `artifact_id`. No content duplication across nodes.
