# 版本范围裁剪建议 quality checklist

1. Metadata is complete and `contract_version` is `n360-cross-team-v1.1.1`.
2. `selected_mode` is one of the modes in `references/output-contract.yaml`.
3. `stance` is `recommend_not_decide` and matches the skill boundary.
4. `artifact_id` and row IDs follow the N360 naming rule or are explicitly temporary.
5. CSV headers exactly match `n360.version-scope-trimming.v2` when CSV is emitted.
6. Multi-value CSV fields use `|`, not bare commas.
7. Evidence refs include source, confidence, layer, and pointer where possible.
8. `cross_artifact_refs` use stable IDs from N340/N350/N360/N330/N320 rather than file paths.
9. `pending_decisions`, `open_blockers`, and `owner_placeholders` are explicit when evidence is incomplete.
10. downstream_handoff contains `handoff_id`, consumer, `decision_target_node` when relevant, required_fields, readiness, confidence, and next_best_checks.
11. Compare the produced artifact against the most relevant example under `examples/`; differences are allowed but should be intentional.

## Skill-specific checks
- Every recommendation is backed by a trigger rule in DSL syntax, not plain prose only.
- Hard-rule violations never continue to recommend A_KEEP_SCOPE_WITH_MITIGATION.
- Confidence and tradeoffs are explicit and evidence-backed.
- Required signoff is visible but not fabricated.
