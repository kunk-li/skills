# Scope Trim Dependency Chain Guide

Use this reference when populating the `dependency_chain` field, or when analyzing the cascading effects of a scope trim recommendation.

## What is a dependency chain?
A dependency chain identifies all features or components that would be **co-affected** if a given feature is trimmed. Trimming one item without trimming its dependents leaves the system in an inconsistent state.

## How to identify dependencies
Ask for each feature under consideration:
1. **Technical dependency**: Does another feature call this one's API, event, or shared DB table?
2. **UX dependency**: Does a UI flow require this feature to be present to make sense?
3. **Release gate dependency**: Does this feature gate a customer demo, contractual milestone, or compliance requirement?
4. **Shared infrastructure dependency**: Do multiple features share a service, database, or config that this feature controls?

## dependency_chain field format
```yaml
# In CSV row
dependency_chain: "实时库存推送|库存告警通知|补货触发流程"
# Pipe-separated list of feature names or IDs that must be co-trimmed or co-kept

# In markdown explanation
dependency_chain:
  - feature: "库存告警通知"
    dependency_type: "shared_infrastructure"
    reason: "与实时库存推送共用同一 WebSocket 基础设施；若前者裁剪，告警推送功能也无基础设施支撑"
    co_trim_required: yes
  - feature: "补货触发流程"
    dependency_type: "technical"
    reason: "补货逻辑依赖实时库存状态更新事件；若实时推送裁剪，补货触发将退化为轮询（架构变化）"
    co_trim_required: no
    alternative: "可改为5分钟轮询，接受延迟"
```

## Co-trim vs alternative
- `co_trim_required: yes` — these features **must** be trimmed together; trimming the root feature alone creates a broken user experience or technical inconsistency
- `co_trim_required: no` — the dependent feature can survive with an alternative approach; document the alternative and its tradeoff

## release_date_impact field format
```yaml
# Options:
release_date_impact: "无影响"
release_date_impact: "延期3天（减少回归范围）"  # trim makes things faster
release_date_impact: "提前2天"  # trim saves work
release_date_impact: "无法评估（需ENG进一步分析）"  # always needs to be resolved
```

## emergency_trim output format
For `emergency_trim` mode, output two tables:

```markdown
### 必须裁剪（Mandatory Trim）
不裁剪则无法满足发版 hard rule（P0缺陷未修、安全漏洞未闭、强制依赖未就绪）

| item_id | feature | 裁剪理由 | 依赖链 | 发版影响 |
|---------|---------|---------|-------|---------|

### 可选裁剪（Optional Trim）
裁剪可降低发版风险，但不裁也满足发版 hard rule

| item_id | feature | 裁剪理由 | 依赖链 | 发版影响（若裁） |
|---------|---------|---------|-------|-------------|

### 组合场景影响
- 仅执行必须裁剪：发版预计 YYYY-MM-DD
- 执行全部裁剪：发版预计 YYYY-MM-DD（提前 N 天）
- 不裁剪任何功能：发版预计 YYYY-MM-DD（延期 N 天）
```
