---
name: project-rhythm-tracking
description: 追踪项目节奏与里程碑滑坡（项目节奏跟踪）用于 n360 发版治理。triggered when a release-owner, PM, or delivery lead needs to monitor delivery cadence at milestone granularity, compute slippage_days, assign slippage root causes from the 6-category taxonomy (dependency_delay / scope_growth / resource_shortage / quality_gate_fail / external / other), and trigger scope_trim_recommended when ≥50% milestones slip or are at_risk. use gate_triggered_review mode when a quality gate fails. do not use for individual task status tracking (→ n350 #136) or scope trimming decisions (→ #141).
---

# 项目节奏跟踪

## N360 contract baseline (n360-cross-team-v1.1.2)

- contract_version: `n360-cross-team-v1.1.2`
- workflow_node: N360
- skill_id: 142
- artifact_family_id: `n360-cross-team-governance-suite`
- csv_schema: `n360.project-rhythm-tracking.v2`
- stance: `track_not_re_rule`
- artifact target: `项目节奏跟踪.md / project-rhythm-tracking.csv`
- packaging rule: self-contained; do not rely on node-level files outside this skill package.
- composition rule: standalone output must include metadata and downstream_handoff; combined output reuses stable upstream IDs and sibling artifact IDs.

## Role

作为 N360 治理层的**项目节奏跟踪生成器**，以里程碑粒度追踪交付节奏，识别系统性滑坡并触发范围裁剪。

具体职责：
- 为每个里程碑计算 `slippage_days`（current_forecast − planned_date 的天数差）并从 6 类分类法赋 `slippage_root_cause`
- 当 ≥50% 里程碑 slipped/at_risk 时，强制输出 `## 节奏健康度预警` 区块
- 每个 slipped/at_risk 里程碑必须有 `recovery_plan`（"接受延期"是合法值）
- 向 #141 传递 `scope_trim_recommended` 和 `rhythm_health` 字段

**不负责**：单条任务状态（→ N350 #136）、裁剪建议（→ #141）、风险台账（→ N350 #138）、项目计划创建（→ 项目管理工具）。

## When NOT to use this skill

- **Not a task tracker**: individual task status belongs in N350 #136; #142 tracks milestone-level rhythm aggregated from tasks.
- **Not a scope trimming tool**: when slippage requires scope changes, trigger N360 #141; #142 identifies the problem, #141 recommends the solution.
- **Not a risk register**: risk items belong in N350 #138; #142 tracks milestone status, not risk inventory.
- **Not a project plan**: #142 tracks progress against an existing plan; creating milestone plans belongs to project planning tools.

## Standalone and composition role

```yaml
standalone_goal: monitor delivery cadence, compute slippage_days, and trigger scope_trim when rhythm health deteriorates
minimum_viable_input:
  any_of:
    - 里程碑清单或发版计划
    - 当前进展更新或状态报告
    - 旧节奏快照 + 新更新（delta 模式）
    - 质量门失败记录（gate_triggered_review 模式）
    - 上游 N350 #136 任务状态快照
partial_readiness_allowed: true
degradation_behavior: >
  If milestone dates are incomplete, mark status=at_risk and slippage_days=待评估.
  If current_forecast is entirely unknown, output a skeleton row with planned_date from
  the input and current_forecast=待确认; do not omit the milestone row. Mark readiness=degraded
  when more than half of milestones lack current_forecast. recovery_plan can be "待制定" —
  but field must be present for slipped/at_risk milestones.
  slippage_root_cause must be assigned for every slipped milestone — use "other" only when
  none of the 6 categories fit, and add a note explaining why.
stance: track_not_re_rule
```


## Mandatory output sections

| # | Section | Required | Placeholder when missing |
|---|---------|----------|--------------------------|
| 1 | Metadata (artifact_id, selected_mode, version, readiness) | Always | — |
| 2 | Milestone register table | Always | All known milestones with slippage_days and status |
| 3 | 节奏健康度预警 | Always when ≥50% milestones slipped/at_risk | Triggered automatically |
| 4 | slippage_root_cause (6-category) | Always per slipped milestone | `other` with explanation if uncertain |
| 5 | recovery_plan per slipped/at_risk milestone | Always | "接受延期" is a valid value |
| 6 | Downstream handoff (rhythm_health, scope_trim_recommended) | Always | — |

> Legend: Always = required in every mode; gate_triggered_review adds gate failure items as mandatory.

## Mode selection

Modes are mutually exclusive — choose exactly one and set it in metadata `selected_mode`:

- `snapshot_mode`: 完整快照，从头生成当前里程碑状态。
- `delta_mode`: 增量更新，保留 rhythm ID，只更新变化条目。
- **`gate_triggered_review`**: 质量门或发版 gate 失败触发的节奏紧急评审。必须输出：① 触发 gate 的失败项、② 受影响里程碑、③ recovery_plan、④ 是否触发 #141 scope trim。
- **`slippage_analysis`**: 专门分析延期原因，为每个滑期里程碑输出 `slippage_days`、`slippage_root_cause` 和 `recovery_plan`，区分一次性延期与系统性节奏问题。

**Consolidated modes**: `milestone_anchor_refresh` has been merged into `delta_mode` (use delta_mode with milestone date fields updated). `rehearsal_window_expansion` and its daily cadence heatmap output are available as an extended view — see `references/n360-alignment-decision-guide.md` for when to activate.

**Default routing**: first tracking → `snapshot_mode`. Regular update → `delta_mode`. Gate failure → `gate_triggered_review`. Root cause deep-dive → `slippage_analysis`.

## Rhythm entry schema

每条节奏跟踪条目必须包含：

| Field | Required | Notes |
|-------|----------|-------|
| `rhythm_id` | Always | Stable ID; never reassign |
| `milestone_name` | Always | — |
| `planned_date` | Always | — |
| `current_forecast` | Always | — |
| `status` | Always | on_track / at_risk / slipped / completed |
| `slippage_days` | Always when status≠on_track/completed | current_forecast − planned_date in days; 0=on time; negative=early |
| `slippage_root_cause` | Always when slippage_days > 0 | See 6-category taxonomy below |
| `recovery_plan` | Always when status=slipped/at_risk | "接受延期" is a valid value |
| `blocker_refs` | Conditional | Link to #137 blocker IDs |
| `risk_refs` | Conditional | Link to #138 risk IDs |
| `evidence_refs` | Always | Source material |

## Slippage root cause taxonomy (6 categories)

Use these categories from `references/slippage-root-cause-taxonomy.md`:

1. `dependency_delay` — upstream dependency not delivered on time
2. `scope_growth` — feature scope expanded after baseline
3. `resource_shortage` — team capacity below plan (leave, attrition, competing priorities)
4. `quality_gate_fail` — blocked by test failure, defect, or compliance gate
5. `external` — third-party, customer, regulatory, or infrastructure delay
6. `other` — does not fit categories 1–5; must include explanation note


## Rhythm health warning trigger

When ≥50% of milestones are `slipped` or `at_risk` → output `## 节奏健康度预警` block containing:
- rhythm_health score (percentage of on-track milestones)
- Top 2–3 systemic root causes
- Recommendation to trigger #141 scope trim review
- `scope_trim_recommended: true` in downstream_handoff

## Downstream handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: N360/version-scope-trimming-recommendation
  rhythm_health: on_track | degraded | critical
  scope_trim_recommended: true | false
  slipped_milestone_ids: [RM-001, RM-003]
  recovery_plans_needed: [RM-002]
  readiness: complete | partial | degraded
```

## Input conflict resolution

When the same milestone appears in multiple sources with conflicting `current_forecast` or `status` values (e.g., PM says on_track but engineering standup notes say at_risk):
- Prefer the **most conservative status** (at_risk > on_track; slipped > at_risk) to avoid masking real delivery risk.
- Record the discrepancy in `progress_summary`: `"Status conflict on RM-001: on_track per PM update vs at_risk per engineering standup — validate with release-owner"`.
- Never silently resolve by picking the optimistic value.
- In `delta_mode`, any status improvement (e.g., slipped → on_track) requires a `recovery_evidence` field documenting what changed.

## Workflow position

```
Milestone plans / N340 #132 weekly report milestone signals / N350 #138 risk signals / gate failure events
  ↓ #142 (project rhythm tracking → 项目节奏跟踪.md / project-rhythm-tracking.csv)
  → slipped milestones + scope_trim_recommended → N360 #141 (scope trimming)
  → rhythm_health: critical → N380 (governance escalation)
```

## Anti-patterns

Verify all anti-patterns are avoided before output.

- **AP-1** `slippage_root_cause` 留空或写"复杂原因"→ 每个 slippage_days > 0 的条目必须给出 6 类分类法中的一个值；不确定时用 `other` 并附说明。量化检验：slippage_days > 0 的里程碑条目中，slippage_root_cause 字段不在 6 类枚举（dependency_delay/scope_growth/resource_shortage/quality_gate_fail/external/other）内的条目数 = FAIL 数。
- **AP-2** slipped/at_risk 里程碑无 `recovery_plan` → 字段必须存在；"接受延期"是合法值，空值不合法。量化检验：status=slipped 或 at_risk 的里程碑中，recovery_plan 字段为空字符串的条目数 = FAIL 数。
- **AP-3** ≥50% 里程碑 slipped/at_risk 但未输出 `## 节奏健康度预警` → 该区块在触发条件满足时强制输出。量化检验：当 slipped+at_risk 里程碑数 / 总里程碑数 ≥ 0.5 时，输出必须包含「节奏健康度预警」section；缺失则 FAIL。
- **AP-4** 使用"milestone_anchor_refresh"作为 selected_mode → 该模式已合并入 delta_mode；使用 delta_mode 并更新里程碑日期字段。量化检验：selected_mode 字段出现「milestone_anchor_refresh」字符串时直接 FAIL（该模式已废弃，应使用 delta_mode）。

## References

- `references/global-id-namespace.md` — cross-node ID prefix registry; reference when assigning or consuming artifact IDs across N320–N360 skills

Read only when relevant to the request:
- `references/n360-shared-cross-team-contract.md` — shared contract, ID format, handoff schema
- `references/n360-alignment-decision-guide.md` — skill selection, escalation thresholds, rehearsal window expansion guidance
- `references/n360-input-validation-rules.md` — when input quality is uncertain
- `references/csv-schema.md` — column definitions for n360.project-rhythm-tracking.v2
- `references/csv-list-field-escape.md` — when multi-value fields contain | characters
- `references/slippage-root-cause-taxonomy.md` — 6-category taxonomy and assignment rules
- `references/project-rhythm-tracking-quality-checklist.md` — self-check before finalizing
- `references/output-contract.yaml` — when a machine-readable artifact contract is needed

## Examples

- `examples/project-rhythm-tracking.md` — snapshot_mode with health warning triggered
- `examples/delta-milestone-update.md` — delta_mode with slippage analysis and recovery plans
