---
name: project-rhythm-tracking
description: track project rhythm, milestone slippage, blockers, risks, and key checkpoints for n360 coordination. use when generating RFC-4180 csv snapshots or delta updates with stable rhythm ids, exact schema validation, pipe-separated references, N350 blocker/risk refs, release milestones, and downstream N370/N390 consumption.
---

# 项目节奏跟踪

Use this skill to produce the N360 artifact target: **项目节奏跟踪.md / project-rhythm-tracking.csv**.

## N360 v1.1.1 contract baseline
- contract_version: `n360-cross-team-v1.1.1`
- workflow_node: `N360`
- skill_id: `142`
- artifact_family_id: `n360-cross-team-governance-suite`
- csv_schema: `n360.project-rhythm-tracking.v2`
- stance: `track_not_re_rule`
- artifact target: `项目节奏跟踪.md / project-rhythm-tracking.csv`
- packaging rule: this skill is self-contained and must not rely on external node-level folders, hidden registries, or files outside the skill package.
- composition rule: standalone output must still include metadata and downstream_handoff; combined output should reuse stable upstream IDs and sibling artifact IDs.

## References
Read only what is relevant to the request:
- `references/n360-shared-cross-team-contract.md`
- `references/output-contract.yaml`
- `references/project-rhythm-tracking-quality-checklist.md`
- `references/csv-schema.md`
- `references/csv-list-field-escape.md`

## Selected modes
- `snapshot_mode`
- `delta_mode`
- `rehearsal_window_expansion`
- `milestone_anchor_refresh`

## Standalone and composition role
Standalone: use direct PRD, roadmap, QA notes, release plan, meeting notes, task status, blocker/risk ledgers, or user-provided snippets to create a partial but structured artifact.

Composition: join with sibling N360 artifacts and upstream N340/N350/N330/N320 IDs through `artifact_id`, row IDs, `upstream_id_aliases`, `evidence_refs`, and `cross_artifact_refs`.

## Operating workflow
1. Identify whether the user needs markdown summary, CSV, decision memo, rhythm table, or downstream handoff.
2. Select one mode from the list above and include it in metadata.
3. Set `stance: track_not_re_rule` and keep the artifact inside that boundary.
4. Extract facts, views, constraints, risks, deadlines, evidence, and open questions separately.
5. Preserve existing row IDs in delta mode.
6. Use `n360.project-rhythm-tracking.v2` when CSV output is requested.
7. Fill missing but required values with `待确认`, `待核对`, or `UNKNOWN` according to the schema.
8. Add `downstream_handoff` for N350, N370, N380, N390, release owner, or sibling N360 skills as appropriate.
9. Run `scripts/validate_csv.py` when producing the skill-specific CSV.

## Output contract
Every artifact must include:
- metadata matching `references/n360-shared-cross-team-contract.md`
- the required sections in `references/output-contract.yaml`
- the skill-specific CSV schema when machine consumption is requested
- `downstream_handoff` with `handoff_id`, `consumer_skill_or_node`, `decision_target_node` when relevant, `required_fields`, `confidence`, and `next_best_checks`

## Strict boundaries
- Do not make final product, engineering, QA, release, compliance, or scope decisions.
- Do not fabricate metrics, dates, signoff, gate results, risk scores, blocker IDs, or owner names.
- Use role/team placeholders rather than individual blame.
- Keep recommendations, summaries, and tracking views visibly distinct from approved decisions.

## Examples
Use the bundled examples as structure references and regression samples:
- `examples/project-rhythm-tracking.csv`
- `examples/platform-project-rhythm-tracking.metadata.yaml`

Differences from the examples are allowed when the user's source material requires them, but field naming, metadata order, and handoff shape should stay compatible.

## Quality gate
Before responding, check `references/project-rhythm-tracking-quality-checklist.md`. If CSV is emitted, validate it with `scripts/validate_csv.py`. If evidence is insufficient, keep the artifact useful but set `readiness: partial` and list `pending_decisions` or `open_blockers`.
