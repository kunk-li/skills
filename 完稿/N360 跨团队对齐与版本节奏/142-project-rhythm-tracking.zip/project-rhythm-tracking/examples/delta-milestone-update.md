# Example: Project Rhythm Tracking — Delta Mode

Demonstrates `delta_mode`: weekly milestone update preserving rhythm IDs, with 变化汇总.

```yaml
metadata:
  contract_version: n360-cross-team-v1.1.2
  skill_id: "142"
  selected_mode: delta_mode
  artifact_id: RHYTHM-PLATFORM-V24-W26
  prior_artifact_id: RHYTHM-PLATFORM-V24-W25
  version: Platform v2.4
  as_of: 2025-06-18
  readiness: complete
```

## 里程碑状态更新（仅变化条目）

| rhythm_id | 里程碑 | 上周状态 | 本周状态 | 变化原因 | slippage_days |
|-----------|--------|---------|---------|---------|--------------|
| RM-003 | 购物车可配置化开发完成 | on_track | **at_risk** | ENG-lead 确认 Redis 分片方案需额外3天 | +3 |
| RM-004 | OAuth 联调完成 | at_risk | **slipped** | auth-team spec 未到，联调无法开始 | +7 |
| RM-007 | v2.4 发版 | on_track | **at_risk** | RM-003/004 联动影响 | +5（预测）|

## 对齐议题变化汇总

| rhythm_id | 变化类型 | 变化详情 |
|-----------|---------|---------|
| RM-003 | on_track → at_risk | Redis 分片方案技术评估结果影响工期 |
| RM-004 | at_risk → slipped | auth-team 外部依赖未解阻（BLK-S24-001 仍 OPEN）|
| RM-007 | 新增 at_risk | 上游 RM-003/004 联动影响发版里程碑 |

## 不变条目确认

RM-001（已完成）、RM-002（已完成）、RM-005（on_track，无变化）、RM-006（on_track，无变化）均无变化，不在本次 delta 中展示。

## 节奏健康度预警

**状态**: YELLOW（3/7 里程碑存在风险）

| 风险类型 | 里程碑数 | 说明 |
|---------|---------|------|
| slipped | 1（RM-004） | auth-team 外部依赖系统性阻塞 |
| at_risk | 2（RM-003/007） | 技术评估结果 + 联动风险 |

**系统性风险识别**: `dependency_delay` 连续2轮（RM-004）→ 建议 PM 升级外部依赖协调。

**建议**: 若 BLK-S24-001 在 2025-06-20 前未解阻，触发 skill #141 评估 RM-004 是否裁剪。

## Downstream Handoff

```yaml
handoff_id: RHYTHM-PLATFORM-V24-W26-HANDOFF
producer_skill: project-rhythm-tracking
consumer_skill_or_node: version-scope-trimming-recommendation|release-owner
changed_milestones: [RM-003, RM-004, RM-007]
rhythm_health: YELLOW
scope_trim_recommended: false  # not yet ≥50%
slipped_milestones: [RM-004]
at_risk_milestones: [RM-003, RM-007]
readiness: complete
confidence: high
next_best_checks:
  - "If BLK-S24-001 unresolved by 2025-06-20 → trigger #141 for RM-004"
  - "RM-003 ETA confirmed by ENG-lead by 2025-06-20"
  - "Update RM-007 slippage forecast once RM-003/004 resolved"
```
