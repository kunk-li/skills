# Example: Project Rhythm Tracking — Platform v2.3

Demonstrates `slippage_analysis` mode with 节奏健康度预警 triggered by >50% slippage.

```yaml
metadata:
  contract_version: n360-cross-team-v1.1.2
  skill_id: "142"
  selected_mode: slippage_analysis
  artifact_id: RHYTHM-2025-06-11-V23
  version: Platform v2.3
  stance: track_not_re_rule
  readiness: complete
```

## 项目节奏跟踪 — Platform v2.3

**快照日期**: 2025-06-11  
**版本目标发版日期**: 2025-06-25  
**距发版**: 14 天

---

## 里程碑状态

| rhythm_id | milestone_name | planned_date | current_forecast | status | slippage_days | slippage_root_cause | recovery_plan | blocker_refs | evidence_refs |
|-----------|---------------|-------------|-----------------|--------|--------------|--------------------|-|---|---|
| RM-001 | 需求冻结 | 2025-05-30 | 2025-05-30 | completed | 0 | — | — | — | sprint:S22-review |
| RM-002 | 模块设计评审 | 2025-06-03 | 2025-06-03 | completed | 0 | — | — | — | meeting:arch-review-0603 |
| RM-003 | 后端开发完成 | 2025-06-10 | 2025-06-13 | slipped | 3 | estimation_error | 支付模块复杂度低估；已压缩 RM-004 留出 2 天缓冲，目标发版日期不变 | — | sprint:S23-status |
| RM-004 | 联调完成 | 2025-06-14 | 2025-06-17 | at_risk | 3 | dependency_delay | Auth team API spec 未交付（BLK-008）；PM 2025-06-12 前发出正式请求，若逾期升级 EM | BLK-008 | meeting:sync-0610 |
| RM-005 | SIT 开始 | 2025-06-15 | 2025-06-18 | at_risk | 3 | dependency_delay | 依赖 RM-004；无独立恢复路径，与 RM-004 联动 | BLK-008 | — |
| RM-006 | SIT 完成 | 2025-06-20 | 2025-06-23 | at_risk | 3 | dependency_delay | 与 RM-005 联动；已压缩 SIT 至 5 天（原 7 天），QA 确认范围可行 | BLK-008 | meeting:qa-sync-0610 |
| RM-007 | 发版审批 | 2025-06-23 | 2025-06-24 | on_track | 0 | — | — | — | — |
| RM-008 | 正式发版 | 2025-06-25 | 2025-06-25 | on_track | 0 | — | — | — | — |

**延期/风险里程碑**: RM-003 slipped + RM-004/005/006 at_risk = 4/8 = **50%**

---

## 节奏健康度预警

**预警级别**: YELLOW — 50% 里程碑延期或 AT_RISK

**当前状态**: 本版本共 8 个里程碑，4 个延期或 AT_RISK（50%），触发节奏健康度预警阈值

### 根因分析

| 根因类别 | 受影响里程碑数 | 代表案例 |
|---------|------------|--------|
| dependency_delay | 3 | RM-004, RM-005, RM-006 — 均因 auth-team API spec 延期 (BLK-008) |
| estimation_error | 1 | RM-003 — 支付模块复杂度低估 |

### 系统性判断

- **Auth 团队依赖链**: HIGH 系统性风险 — 3 个里程碑均阻塞于同一 blocker BLK-008（auth-team API spec）。单一团队成为多里程碑关键路径，属系统性问题。
- **estimation_error**: 偶发性 — 仅 RM-003 受影响，不属于系统性问题。

### 建议行动

1. **[立即]** PM 在 2025-06-12 前向 auth-team TL 发出正式书面请求，要求 API spec v1 在 2025-06-14 交付；若逾期，升级至 EM 介入
2. **[本周]** 评估是否启动版本范围裁剪（见 skill #141 `emergency_trim` 模式）；BLK-008 解阻失败将导致最终发版延期 3 天
3. **[结构性]** 下版本立项时避免单一外部团队成为多里程碑串联关键路径；考虑依赖提前锁定或功能开关隔离

---

## Downstream Handoff

```yaml
handoff_id: RHYTHM-HANDOFF-2025-06-11
consumer_skill_or_node: release-owner|N350|N370
pending_decisions:
  - rhythm_id: RM-004
    blocker: BLK-008 (auth-team API spec)
    decision_deadline: 2025-06-14
    impact_if_missed: "RM-004/005/006 联动延期，发版推迟至 2025-06-28"
rhythm_health: YELLOW
systemic_risk: auth-team single-team bottleneck (dependency_delay x3)
readiness: complete
confidence: high
next_best_checks:
  - PM 确认 2025-06-12 书面请求已发送
  - 若 BLK-008 未解阻，启动 skill #141 emergency_trim
  - 更新快照时使用 delta_mode，保留所有 RM-* ID
```
