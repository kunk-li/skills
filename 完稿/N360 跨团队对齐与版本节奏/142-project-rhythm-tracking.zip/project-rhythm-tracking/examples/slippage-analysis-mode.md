# Example: Project Rhythm Tracking — Slippage Analysis Mode

## Metadata

```yaml
artifact_id: RHYTHM-SLIP-001
skill_id: 142
contract_version: n360-cross-team-v1.1.2
selected_mode: slippage_analysis
version: v2.3.0
analysis_date: "2025-06-14"
analysis_scope: "all milestones with slippage_days > 0"
readiness: complete
```

## Slippage Analysis — Milestone-Level Detail

| rhythm_id | milestone | planned_date | current_forecast | slippage_days | slippage_root_cause | recovery_plan | scope_trim_candidate | status |
|-----------|-----------|-------------|-----------------|:-------------:|--------------------:|---------------|:--------------------:|--------|
| RHYTHM-003 | 支付模块联调完成 | 2025-06-06 | 2025-06-13 | 7 | dependency_delay | 等待 ops 团队测试环境恢复（已恢复），联调重排至 W25 | NO | at_risk |
| RHYTHM-004 | 数据迁移脚本验证 | 2025-06-09 | 2025-06-20 | 11 | resource_shortage | DBA 团队 sprint-11 被临时调配至 hotfix；sprint-12 全力投入，ETA 2025-06-20 | NO | slipped |
| RHYTHM-005 | QA 回归测试完成 | 2025-06-13 | 2025-06-23 | 10 | quality_gate_fail | /checkout SLA 未达标（PR #891 部署后重新执行回归），QA 需额外 5 天 | YES | slipped |
| RHYTHM-006 | 发版 go/no-go 决策 | 2025-06-16 | 2025-06-25 | 9 | dependency_delay | RHYTHM-003/004/005 三个前置里程碑延期的级联效应；recovery 依赖上游解决 | NO | at_risk |

## 滑坡根因分布

| slippage_root_cause | 里程碑数 | 累计 slippage_days | 占总延期天数 |
|--------------------|:-------:|:-----------------:|:----------:|
| dependency_delay | 2 | 16 | 43% |
| quality_gate_fail | 1 | 10 | 27% |
| resource_shortage | 1 | 11 | 30% |

**根因分析结论**：本次延期呈现**级联型**特征——测试环境不可用（dependency_delay）导致联调延期，联调延期导致 QA 回归延期（quality_gate_fail），最终 go/no-go 延期 9 天。这不是多个独立延期，而是同一根源的传导。

## 节奏健康度预警 ⚠️

**触发条件**：4/4 里程碑（100%）处于 slipped 或 at_risk 状态，超过 50% 阈值。

**节奏健康度：CRITICAL（critical）**

| 指标 | 值 |
|------|---|
| 总里程碑数 | 4 |
| slipped + at_risk 数 | 4 (100%) |
| 最大单里程碑延期 | 11 天（RHYTHM-004） |
| 预计发版延期 | 9 天（2025-06-25 vs 计划 2025-06-16） |
| scope_trim_candidate 数 | 1（RHYTHM-005 → 触发 #141 评估） |

## 系统性 vs 一次性延期判断

**判断：系统性滑坡（非孤立事件）**

根因：测试环境可用性（ops 依赖）在本版本 sprint-11 成为单点瓶颈，同时 DBA 资源被临时调配，两个外部依赖同时失效形成级联。这是 **流程/资源协调** 层面的系统性问题，建议在下版本规划中引入「关键路径资源锁定」机制。

## Downstream Handoff

```yaml
downstream_handoff:
  consumer_skill_or_node: N360/version-scope-trimming-recommendation
  rhythm_health: critical
  scope_trim_recommended: true
  scope_trim_candidates:
    - rhythm_id: RHYTHM-005
      reason: "quality_gate_fail — QA SLA 回归需额外 10 天，可评估 /checkout SLA fix 是否推至 v2.3.1"
  release_date_impact: "+9 days (2025-06-25 vs planned 2025-06-16)"
  systemic_slippage_signal: true
  readiness: complete
```
