# N360 contracts quick pointer

This file is retained as a compatibility pointer from earlier packages.
For the canonical N360 contract, read `references/n360-shared-cross-team-contract.md`.

- contract_version: `n360-cross-team-v1.1.2`
- artifact_family_id: `n360-cross-team-governance-suite`
- contract scope: metadata, artifact IDs, row IDs, CSV schema governance, handoff, stance, rehearsal coverage, composition paths, and self-checks.
- packaging rule: every N360 skill is self-contained and must not rely on node-level external assets.
