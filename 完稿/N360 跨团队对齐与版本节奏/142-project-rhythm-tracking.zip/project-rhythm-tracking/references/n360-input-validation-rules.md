# N360 Input Validation and Trigger Rules

Use this reference when determining which N360 skill to invoke and what inputs are sufficient.

## Skill selection decision tree

```
Input arrives at N360 scope
│
├─ Contains alignment gap between product expectations and engineering constraints?
│   └─ → skill #139 (product-engineering-alignment-summary)
│
├─ Contains QA vs engineering gap (defects, acceptance, test scope)?
│   └─ → skill #140 (qa-engineering-alignment-summary)
│
├─ Contains scope/feature trimming decision need?
│   ├─ T-3 days or less to release → emergency_trim mode (#141)
│   └─ Earlier in cycle → fresh_assessment or gate_triggered_review (#141)
│
├─ Contains milestone status and slippage data?
│   └─ → skill #142 (project-rhythm-tracking)
│
└─ Multiple of the above → invoke multiple skills; link via cross_artifact_refs
```

## N350 → N360 trigger rules

| N350 signal | Threshold | Triggered N360 skill |
|-------------|-----------|---------------------|
| `scope_trim_candidate = YES` in risk register | Any single YES | #141 fresh_assessment or emergency_trim |
| Blocker count HIGH (`severity: high`) | ≥2 open high-severity blockers | #142 milestone_anchor_refresh |
| Milestone slippage | ≥50% at_risk or slipped | #142 slippage_analysis + optional #141 |
| Unresolved alignment topics from N350 | ≥3 unresolved | #139 or #140 depending on type |

## Minimum viable input per N360 skill

| Skill | Minimum input | What is produced without full input |
|-------|--------------|-------------------------------------|
| #139 | PRD sections OR product expectations | `readiness: partial`, unresolved topics marked with `待确认` |
| #140 | QA notes OR defect list | `readiness: partial`; `defect_triage_label: needs_repro` used for unconfirmed defects |
| #141 | Risk register OR gate failure report | `readiness: partial`; all recommendations have `confidence: low` |
| #142 | Milestone dates OR task status snapshot | `readiness: partial`; `current_forecast = planned_date` assumed until evidence available |

## Partial input handling for N360

When evidence is insufficient:
- Set `readiness: partial` in metadata
- Fill unknown fields with `UNKNOWN`, `待确认`, or `待核对` per alignment-topic-schema rules
- List missing inputs in `open_blockers`
- Set `confidence: low` in downstream_handoff when producing with partial input

Never invent milestone dates, risk scores, defect IDs, or alignment decisions.
