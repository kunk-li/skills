# Slippage Root Cause Taxonomy

Use this reference when assigning `slippage_root_cause` to delayed milestones, or when writing the `## 节奏健康度预警` block.

## slippage_root_cause values

| Value | Definition | Signals |
|-------|------------|---------|
| `dependency_delay` | An external team, service, or supplier did not deliver on time | "Auth team API spec delayed", "Third party SDK bug not fixed" |
| `scope_growth` | New requirements or scope changes added after milestone baseline | "PM added features mid-sprint", "Customer requested changes" |
| `resource_shortage` | Insufficient people, compute, or tooling to complete the work | "Engineer sick leave", "Staging environment unavailable" |
| `quality_gate_fail` | Milestone blocked by failing tests, security review, or compliance gate | "P0 bug found in regression", "Security scan failed", "Performance below threshold" |
| `technical_debt` | Pre-existing technical issues slowed down delivery | "Legacy code made refactor harder than estimated", "Flaky tests reduced confidence" |
| `estimation_error` | Original estimate was significantly wrong | "Complexity underestimated", "Missing requirements discovered during implementation" |
| `external` | External factor beyond team control | "Cloud provider incident", "Regulatory change", "Market event" |
| `other` | None of the above; requires `recovery_plan` to explain | |

## recovery_plan field format
When `slippage_days > 0`, `recovery_plan` is required:

```yaml
# Recovery achievable
recovery_plan: "压缩 RM-006 SIT 阶段至 3 天（原 5 天），目标发版日期不变；QA 团队同意并已确认测试范围可缩减"

# Recovery not achievable (accept delay)
recovery_plan: "无法压缩后续阶段；预计最终发版日期延期 5 天至 2025-06-25；已知会 PM 和业务方"

# Recovery under evaluation
recovery_plan: "正在评估是否可并行执行 RM-007 和 RM-008；评估结果将在 2025-06-12 前确认"
```

## 节奏健康度预警 trigger and format
Trigger: ≥50% of milestones have `slippage_days > 0` OR `status = at_risk` in current snapshot.

```markdown
## 节奏健康度预警

**预警级别**: YELLOW（多个里程碑延期）| RED（≥50% 延期且无恢复计划）

**当前状态**: 本版本共 8 个里程碑，5 个延期或 AT_RISK（62.5%）

### 根因分析
| 根因类别 | 受影响里程碑数 | 代表案例 |
|---------|------------|--------|
| dependency_delay | 3 | RM-004, RM-005, RM-007 — 均因 auth-team 延期 |
| quality_gate_fail | 1 | RM-006 — P1 缺陷导致 SIT 延期 |
| estimation_error | 1 | RM-003 — 前端复杂度低估 |

### 系统性判断
- Auth 团队依赖链: HIGH — 本版本 3 个里程碑均依赖 auth-team，属系统性瓶颈
- 建议：与 PM 启动 N360 版本裁剪评估（skill #141），考虑移除强依赖 auth-team 的功能

### 建议行动
1. [IMMEDIATE] EM 介入 auth-team 资源排期，优先保证本版本核心依赖
2. [THIS WEEK] PM 评估是否启动范围裁剪（见 skill #141 emergency_trim 模式）
3. [STRUCTURAL] 下版本避免单一团队成为多里程碑的关键路径
```

## Systemic vs one-off classification
- **Systemic** (系统性): same `slippage_root_cause` appears in ≥3 milestones, OR same blocking team appears in ≥2 milestones
- **One-off** (偶发性): single milestone slippage with a unique root cause
Systemic issues must generate the `## 节奏健康度预警` block even if total slippage ratio is < 50%.
