# N360 Shared Cross-Team Governance Contract

## Contract version
`n360-cross-team-v1.1.2`

## Node scope
N360 turns product, engineering, QA, release, gate, task, blocker, risk, and rhythm signals into cross-team governance artifacts. The node produces product/engineering alignment, QA/engineering alignment, version scope-trim recommendations, and project rhythm tracking. Each skill is standalone; the node is strongest when all four artifacts are joined through stable artifact IDs, row IDs, evidence refs, and downstream handoffs.

## Encapsulation governance
Each N360 skill is self-contained. Shared rules are packaged inside each skill's `references/` folder. Do not rely on external node-level folders, external matrices, hidden registries, or files outside the skill package.

## Release consistency rule
A valid N360 release keeps the same `contract_version` in every `SKILL.md` body, `references/output-contract.yaml`, and `references/n360-shared-cross-team-contract.md`. Skill-local copies of this shared contract should remain byte-identical before packaging.

## CSV schema governance
N360 uses two version tracks:
- `contract_version` governs node-level protocol, metadata, handoff, shared rules, and composition behavior.
- `csv_schema` governs each skill's CSV column set and validator behavior.
Column changes require a `csv_schema` bump. Metadata, handoff, governance, or composition changes require a `contract_version` bump.

## Shared metadata schema
Every N360 artifact should start with or carry a machine-readable metadata block:

```yaml
metadata:
  contract_version: n360-cross-team-v1.1.2
  workflow_node: N360
  skill_id: 139 | 140 | 141 | 142
  skill_name: product-engineering-alignment-summary | qa-engineering-alignment-summary | version-scope-trimming-recommendation | project-rhythm-tracking
  artifact_family_id: n360-cross-team-governance-suite
  artifact_id: string
  csv_schema: string | null
  selected_mode: string
  readiness: draft | partial | ready | blocked
  source_time_window:
    start: iso8601 | unknown
    end: iso8601 | unknown
    timezone: string
  project_scope: string | unknown
  team_scope: [string]
  sprint_or_release: string | unknown
  rehearsal_window:
    cycle_count: integer
    cycles: [string]
  audience_scope: [product | engineering | qa | pm | release_owner | leadership | governance]
  source_artifacts: [string]
  upstream_id_aliases: [string]
  evidence_refs: [artifact_evidence_ref]
  cross_artifact_refs: [string]
  pending_decisions: [string]
  open_blockers: [string]
  owner_placeholders: [string]
  confidentiality_level: public_internal | restricted_internal | confidential
  confidence: high | medium | low
  composition_role: string
  stance: summarize_not_judge | recommend_not_decide | track_not_re_rule
  function_bias: string
  stage_position: string
  artifact_target: string
  freshness:
    as_of_date: iso8601 | unknown
    source_commit: string | null
    expected_review_window: string
```

## Artifact id and row id rules
| skill_id | skill | artifact_id pattern | row id pattern | artifact target |
|---|---|---|---|---|
| 139 | product-engineering-alignment-summary | PE-ALIGN-<project>-<yyyyww> | PEA-<project>-<nn> | product-engineering-alignment.csv |
| 140 | qa-engineering-alignment-summary | QE-ALIGN-<project>-<yyyyww> | QEA-<project>-<nn> | qa-engineering-alignment.csv |
| 141 | version-scope-trimming-recommendation | STR-REC-<project>-<yyyyww> | STR-<project>-<nn> | version-scope-trimming.csv |
| 142 | project-rhythm-tracking | RHY-TRK-<project>-<yyyyww> | RHY-<project>-<nn> | project-rhythm-tracking.csv |

Fallback IDs use `TEMP-N360-<date>-<source>` and must appear in `upstream_id_aliases` or `pending_decisions` with a clear backfill note.

## Evidence reference schema
```yaml
artifact_evidence_ref:
  ref_id: string
  source_family: prd | roadmap | qa_plan | n350_task | n350_status | n350_blocker | n350_risk | n340_action | n340_faq | n330_doc | n320_postmortem | meeting | chat | gate | release_calendar
  source_name: string
  time_window_or_version: string
  scope: string
  upstream_id_aliases: [string]
  confidence: high | medium | low
  layer: confirmed_fact | bounded_inference | open_question
  excerpt_or_pointer: string | null
```

## Cross-artifact join keys
- `artifact_id` joins whole N360 artifacts.
- `PEA-*` and `QEA-*` rows are alignment topics.
- `STR-*` rows are scope-trim recommendation points, not final release decisions.
- `RHY-*` rows track rhythm and reference `BLK-*`, `RISK-*`, `HCN-*`, `PEA-*`, `QEA-*`, and `STR-*` IDs without renaming them.
- Upstream N340 `ACT-*`, N350 `TASK-*`, `BLK-*`, and `RISK-*`, N250 gate IDs, and N270 release window IDs must be preserved as aliases.

## Standard composition paths
1. **Cross-team-baseline**: PRD + roadmap + QA notes -> 139 + 140 baseline artifacts.
2. **Weekly-alignment**: N350 status + N340 weekly/action items -> 139 + 140 -> 142.
3. **Gate-driven-trim**: N250 gate fail + N350 risk -> 141 trigger DSL -> N370/N380/release owner.
4. **Rehearsal-cycle**: roadmap -> 139 + 140 + 142 across 5-7 rehearsal cycles.
5. **Standalone fallback**: any skill can run with direct notes, producing `readiness: partial` when evidence is incomplete.

## Stance governance
N360 is a governance node, not a final decision maker:
- 139 and 140 use `summarize_not_judge`: summarize product/engineering or QA/engineering positions without deciding who is right.
- 141 uses `recommend_not_decide`: recommend KEEP/TRIM/SPLIT options and required signoff, without final release approval.
- 142 uses `track_not_re_rule`: track schedule/rhythm movement without re-planning or overruling owners.

## Rehearsal coverage rule
When release rehearsal evidence is available, cover at least five cycles before treating rhythm as stable: baseline, next sprint, pre-release, release, and canary. Use seven cycles when migration, compliance, or multi-region rollout risk is present.

## Standalone guarantee
- Each skill can produce a useful artifact from direct user-provided notes, even when upstream nodes are absent.
- Missing fields must be marked `待确认`, `待核对`, or `UNKNOWN`; never invent commitments, dates, QA metrics, signoff, or gate results.
- Standalone outputs must still include metadata, stable IDs, evidence_refs, confidence, stance, and downstream_handoff.

## Composition guarantee
- 139 and 140 own alignment topics and do not make final product, engineering, QA, or release decisions.
- 141 owns scope-trim option recommendation and trigger-rule explanation, but not final signoff.
- 142 owns rhythm tracking and must reuse N350 blocker/risk IDs instead of redefining them.
- Cross-skill references should use IDs, not file paths.
- Evidence and confidence should travel forward through `downstream_handoff.next_best_checks`.

## Downstream handoff schema
```yaml
downstream_handoff:
  contract_version: n360-cross-team-v1.1.2
  handoff_id: HO-N360-<artifact_id>-<seq>
  producer_skill: string
  consumer_skill_or_node: string
  decision_target_node: string | null
  artifact_family_id: n360-cross-team-governance-suite
  artifact_id: string
  artifact_target: string
  csv_schema: string | null
  required_fields: [string]
  cross_artifact_refs: [string]
  pending_decisions: [string]
  readiness: draft | partial | ready | blocked
  confidence: high | medium | low
  next_best_checks: [string]
```

## Common execution workflow
1. Identify user goal: alignment summary, CSV, decision memo, rhythm tracker, or handoff.
2. Determine `selected_mode` and mark it in metadata.
3. Set `stance` according to the skill boundary.
4. Extract evidence and preserve upstream IDs.
5. Separate facts from bounded inferences and open questions.
6. Build the artifact using the skill-specific schema.
7. Add cross_artifact_refs to sibling or upstream artifacts when available.
8. Add downstream_handoff with required_fields, decision_target_node when relevant, and next_best_checks.
9. Run the skill-specific CSV validator when a CSV artifact is produced.

## Common input handling
- Prefer existing stable IDs over generated IDs.
- If old ledgers or prior artifacts exist, use delta mode and preserve row IDs.
- If only raw notes exist, use baseline or snapshot mode and mark confidence lower.
- Keep list fields pipe-separated in CSV; avoid bare commas in list cells.

## Common self-check
1. Metadata is present and `contract_version` matches `n360-cross-team-v1.1.2`.
2. `selected_mode` appears in the skill's output contract.
3. `stance` matches the skill boundary.
4. Stable artifact and row IDs follow the naming rules or are explicitly temporary.
5. CSV headers match the skill-specific schema exactly.
6. List fields use `|`, not bare commas.
7. No final release decision, QA decision, product decision, owner signoff, or schedule replan is fabricated.
8. Evidence_refs include source, confidence, layer, and pointer.
9. Cross_artifact_refs use IDs, not local file paths.
10. downstream_handoff includes handoff_id, consumer, required_fields, decision_target_node when relevant, confidence, and next_best_checks.
11. The result is comparable to the most relevant file under `examples/`; differences are intentional.

## Tone and content rules
- Use neutral, non-blaming language.
- State uncertainty directly.
- Do not make final decisions for PM, QA, engineering, release owner, compliance, or leadership.
- Keep scope-trim recommendations visibly separate from approved release decisions.


## Cross-node composition protocol (v1.1.2 addition)

### N350→N360 trigger flow
N360 skills are triggered by upstream N350 signals:

| N350 signal | Triggers N360 skill | Mode |
|-------------|-------------------|------|
| `scope_trim_candidate=YES` in RISK-* | #141 version-scope-trimming | emergency_trim or fresh_assessment |
| ≥50% milestones slipped or at_risk | #142 project-rhythm-tracking | slippage_analysis |
| Multiple unresolved alignment topics | #139 or #140 alignment summary | pre_release_alignment_check |
| Blocker count HIGH in BLOCKER-* | #142 + #141 | milestone_anchor_refresh + gate_triggered_review |

### How N360 consumes N350 artifacts
1. Reference N350 artifacts by `artifact_id` and row ID (e.g., `RISK-S23-W24#RISK-007`)
2. Do not recompute risk scores — cite N350 scores directly
3. Add `upstream_id_aliases` to link N350 row IDs to N360 topic or item IDs

### N360 internal skill composition
```
#139 product-engineering alignment  ←→  #140 QA-engineering alignment
         ↓ pending_decisions                    ↓ defect triage decisions
#141 version-scope-trimming  ←────────────────────────────────────────┘
         ↓ trim decisions
#142 project-rhythm-tracking (delta update reflecting scope change)
```

### Cross-node end-to-end example
See `examples/n350-to-n360-governance-flow.md` in skill #141 for a complete example:
RISK-007 (N350 #138) → #141 emergency_trim → #139 pre_release_check → #142 delta snapshot.
