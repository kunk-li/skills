# 项目节奏跟踪 quality checklist

1. Metadata is complete and `contract_version` is `n360-cross-team-v1.1.2`.
2. `selected_mode` is one of the modes in `references/output-contract.yaml`.
3. `stance` is `track_not_re_rule` and matches the skill boundary.
4. `artifact_id` and row IDs follow the N360 naming rule or are explicitly temporary.
5. CSV headers exactly match `n360.project-rhythm-tracking.v2` when CSV is emitted.
6. Multi-value CSV fields use `|`, not bare commas.
7. Evidence refs include source, confidence, layer, and pointer where possible.
8. `cross_artifact_refs` use stable IDs from N340/N350/N360/N330/N320 rather than file paths.
9. `pending_decisions`, `open_blockers`, and `owner_placeholders` are explicit when evidence is incomplete.
10. downstream_handoff contains `handoff_id`, consumer, `decision_target_node` when relevant, required_fields, readiness, confidence, and next_best_checks.
11. Compare the produced artifact against the most relevant example under `examples/`; differences are allowed but should be intentional.

## Skill-specific checks
- The exact CSV header is preserved.
- blocker_refs, risk_refs, hcn_refs, and evidence_ref use pipe separators.
- N350 blocker/risk IDs are reused rather than renamed.
- Rhythm rows track milestones without replacing scope or schedule decisions.

## Partial-input degradation checks
- When input is incomplete, `readiness` is set to `partial` — never omit this field.
- All required sections present even with placeholder content; no section silently skipped.
- Missing evidence recorded in `open_blockers`, not silently dropped.
- Fields that cannot be determined use `待确认` or `待核对` — never invented values.
- `downstream_handoff.next_best_checks` lists what additional input would raise `readiness` to `complete`.

- `slippage_analysis` mode: `slippage_days` computed for every milestone; `slippage_root_cause` filled for all slipped items.
- `recovery_plan` is always present for slipped and at_risk milestones; "无法恢复，接受延期" is valid.
- `## 节奏健康度预警` block triggered when ≥50% milestones are slipped or at_risk — never omitted when threshold is met.

## Output structure completeness checks
- All 5 mandatory sections present per the mandatory section table
- `slippage_days` computed for every milestone with known planned date; never blank
- `slippage_root_cause` assigned from 7-category taxonomy for all slipped milestones
- `## 节奏健康度预警` block present when ≥50% milestones slipped/at_risk
- `recovery_plan` present for every slipped and at_risk milestone; "接受延期" is a valid entry

## Mode-specific checks

### gate_triggered_review mode
- Failed gate items explicitly listed with gate_id references
- Affected milestones linked to failing gate
- `scope_trim_recommended` field present

### slippage_analysis mode
- `slippage_root_cause` from taxonomy for every slipped milestone
- Systemic vs isolated slippage explicitly assessed
