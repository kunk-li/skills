# 项目节奏跟踪 quality checklist

1. Metadata is complete and `contract_version` is `n360-cross-team-v1.1.1`.
2. `selected_mode` is one of the modes in `references/output-contract.yaml`.
3. `stance` is `track_not_re_rule` and matches the skill boundary.
4. `artifact_id` and row IDs follow the N360 naming rule or are explicitly temporary.
5. CSV headers exactly match `n360.project-rhythm-tracking.v2` when CSV is emitted.
6. Multi-value CSV fields use `|`, not bare commas.
7. Evidence refs include source, confidence, layer, and pointer where possible.
8. `cross_artifact_refs` use stable IDs from N340/N350/N360/N330/N320 rather than file paths.
9. `pending_decisions`, `open_blockers`, and `owner_placeholders` are explicit when evidence is incomplete.
10. downstream_handoff contains `handoff_id`, consumer, `decision_target_node` when relevant, required_fields, readiness, confidence, and next_best_checks.
11. Compare the produced artifact against the most relevant example under `examples/`; differences are allowed but should be intentional.

## Skill-specific checks
- The exact CSV header is preserved.
- blocker_refs, risk_refs, hcn_refs, and evidence_ref use pipe separators.
- N350 blocker/risk IDs are reused rather than renamed.
- Rhythm rows track milestones without replacing scope or schedule decisions.
