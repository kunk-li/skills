# N360 Alignment Decision Guide

Use this reference when determining which N360 skill to invoke and how to escalate across the N360 layer.

## N360 skill selection matrix

| Input signal | Primary skill | Secondary |
|-------------|--------------|-----------|
| Product expectation ≠ engineering constraint | #139 | → #141 if scope_trim needed |
| QA acceptance ≠ engineering implementation | #140 | → #141 if quality gate blocks release |
| Milestone slippage or at_risk pattern | #142 | → #141 if ≥50% threshold |
| scope_trim_candidate=YES from N350 #138 | #141 | — |
| Release gate failure | #141 gate_triggered_review | → #142 milestone update |

## Cross-skill handoff protocols

### #139 → #141
When UNRESOLVED product-engineering topics exceed 2 cycles OR involve release-blocking features:
- Include topic_ids in downstream_handoff.pending_decisions
- Set `scope_trim_recommended: true` if feature must be deferred

### #140 → #141
When UNRESOLVED QA topics include P0/P1 defects or wont_fix decisions that block release:
- Include `defect_summary.critical_open` count in handoff
- If critical_open > 0 → trigger #141 emergency review

### #142 → #141
When ≥50% milestones slipped/at_risk OR slippage_days > release_buffer:
- Set `scope_trim_recommended: true`
- Include `systemic_risk` assessment in handoff

## Escalation thresholds

| Condition | Escalation |
|-----------|-----------|
| Unresolved topic > 2 cycles | PM → EM (level 2) |
| ≥2 UNRESOLVED blocking release | PM → release-owner → N380 |
| scope_trim recommended | release-owner → #141 immediately |
| Milestone slippage > 14 days | PM → ENG-lead → executive sponsor |

## stance: summarize_not_judge (N360 universal rule)

All N360 skills (except #141) must maintain `stance: summarize_not_judge`. This means:
- Report gaps, not verdicts ("product expects X, engineering can deliver Y" not "product is wrong")
- Provide decision options, not decisions
- The decision authority always belongs to PM, ENG-lead, or release-owner — never to the N360 skill
