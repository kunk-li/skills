---
name: code-review-comment-generation
description: generate workflow-aligned code review comments from git diffs, task context, static-analysis outputs, and project conventions. use when Claude works in coding & implementation / code review and submission collaboration and must produce the workflow-aligned review comment artifact for N220 after N210 static checks and before PR description or merge collaboration. trigger on any request to review code, generate PR comments, annotate a diff, or produce reviewer-ready feedback.
---
# code-review-comment-generation


## Review boundary decision table

| Situation | Action |
|---|---|
| File has test changes alongside prod code | Treat test changes as validation evidence; do not generate test coverage comments |
| PR author is same as reviewer (self-review) | Set `reviewer_assignment_hint.conflict: true`; recommend reassignment |
| Comment would duplicate an existing inline comment | Suppress duplicate; reference the existing comment ID if available |
| Diff is >500 lines | Activate `senior_mode` automatically; focus on architectural and risk-level blockers |
| No diff context available (merge commit only) | Set `readiness: constrained`; comment only on metadata issues |
| Hotfix PR with `urgent` label | Prioritise blocker identification; skip style/educational comments |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n220.code-review-comment.v2.2"
contract_version: "n220.v2.2"
workflow_node: "N220"
```


## Role / role positioning
This skill aligns to coding & implementation -> code review and submission collaboration -> CodeReview评论.md. It delivers a workflow-aligned artifact for N220.

### Boundary
- Focus on reviewer-ready comments, not generic static analysis duplication.
- Convert findings into consistent reviewer language with action level and teaching value.
- Do not impersonate final approval, merge authority, or release judgement.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `learning_mode`: explanation-heavy, suitable for junior authors.
- `senior_mode`: concise, architecture-focused comments.
- `batch_mode`: multiple PRs or multiple patch groups in one run.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `代码规范检查单.csv`
- `开发任务拆分表.csv`
- `git diff/改动列表`

### optional enhancement inputs
- `Diff风险点评.md`
- project conventions or coding guidelines
- ticket ids, task ids, branch names
- reviewer preferences or team collaboration norms

## Standalone rule / standalone usage
This skill must still work on a single diff hunk, a patch summary, or one changed file.

Degradation rules:
- If no upstream static issues are available, state that duplication filtering is limited.
- If code context is partial, comment on confirmed evidence only.
- Use `pending_context` when the reviewer would need broader codebase context.
- Keep the output shape stable even for tiny diffs.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_review_and_submission_collaboration.code_review_comment_generation`
  - `workflow_node: N220`
  - `node_artifact_target: CodeReview评论.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `pr_size_assessment`
- `review_focus`
- `comments[]`
- `suppressed_duplicates[]`
- `teaching_notes[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every comment must carry one `comment_type`; use `references/review-comment-types.md` for legacy quick labels and `references/comment-taxonomy-and-ratio.md` as the authoritative taxonomy in N220 v2 or `n220_full_chain` mode.
- Do not restate N210 issues verbatim; reference them via `source_issue_id` or summarize once.
- Use project conventions when available; otherwise downgrade taste-based comments to `question` or omit them.
- Keep blocker comments concrete: problem, why, suggested change, risk.
- Include at least some positive or clarifying comments when deserved; do not turn review into pure negativity.
- Use the PR-size guidance in `references/review-load-guidance.md` to calibrate comment density.
- Link comments to task ids, rule ids, or risk ids when evidence exists.

## Execution workflow / execution workflow
1. Read the diff and identify the change intent and touched modules.
2. Filter out issues already fully covered by N210 or formatting tools.
3. Classify remaining comments by `comment_type` and action strength.
4. Add teaching context for blocker and high-value suggestions.
5. Group comments so a reviewer can paste or adapt them directly.
6. Prepare downstream hints for PR description and merge collaboration.

## Dynamic completeness / dynamic completeness
- Small diff: keep only the highest-signal comments.
- Medium diff: add traceability and suppressed-duplicate notes.
- Large diff: group by module or risk theme, not by raw line order.
- If input is only a static issue list without code, produce comment seeds, not fake line-level comments.


## Example usage

**Input**: git diff adding a Redis cache layer to a user-profile service; no static-analysis issues from N210.

**Output** (`senior_mode`, excerpt):
```markdown
[suggestion] cache/profile_cache.go:42 — TTL is hardcoded to 3600. Consider making it
configurable via env var so different environments can tune expiry without a redeploy.

[blocker] cache/profile_cache.go:67 — Cache miss falls back to DB but does not set the
fetched value back in Redis. This defeats the purpose of the cache and will cause repeated
DB load under high traffic. Fix: call Set() after the DB fetch with the same TTL.

[question] cache/profile_cache.go:88 — Is there a cache invalidation strategy when the
underlying profile is updated? The PR description does not mention it.
```
`downstream_handoff.pr_description_seeds`: ["Adds Redis cache for user profiles (TTL configurable)", "Known gap: invalidation strategy TBD"]

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Quality bar / quality bar
A good result should help reviewers focus on machine-blind issues, communicate clearly with authors, and avoid review fatigue. The artifact must be directly reusable in a PR conversation.


## Auditable rules

Apply these rules in order; record outcomes in `self_check.passed_rules` and `self_check.failed_rules`.

- R01_no_n210_duplication: never restate a finding already fully covered by N210 static checks; reference by `source_issue_id` instead; on_violation: suppress_and_cite.
- R02_blocker_must_be_concrete: every `blocker` comment must state problem, root cause, suggested change, and risk; on_violation: downgrade_to_suggestion.
- R03_comment_type_required: every comment must carry exactly one `comment_type` from the authorized taxonomy; on_violation: reject.
- R04_convention_gate: taste-based style comments require a project convention reference; without one, downgrade to `question` or omit; on_violation: downgrade.
- R05_density_calibrated: comment count must align with PR-size tier from `references/review-load-guidance.md`; on_violation: trim_or_expand.
- R06_positive_balance: include at least one positive or clarifying comment when the diff warrants it; on_violation: warn.
- R07_traceability_when_evidence: link to task id, rule id, or risk id when upstream evidence exists; on_violation: warn.

## Algorithm

1. Parse the diff; identify change intent, touched modules, and PR size tier.
2. Filter issues fully covered by N210; record suppressed items in `suppressed_duplicates[]`.
3. Apply R01–R07 to each candidate comment; keep, downgrade, or discard accordingly.
4. Classify surviving comments by `comment_type` and action strength (blocker / suggestion / question / praise).
5. Add teaching context for blockers and high-value suggestions.
6. Group by module or risk theme for large diffs; keep raw line order for small diffs.
7. Populate `downstream_handoff` with PR description seeds and reviewer routing hints.
8. Run `self_check` against all rules; set `readiness` to `blocked` if any R0x_reject fires.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/field-contract.md`
- `references/readiness-inheritance.md`
- `references/n220-integration-map.md`
- `references/traceability-chain.md`
- `references/review-comment-types.md`
- `references/review-load-guidance.md`
- `references/project-convention-boundary.md`
- `references/template-skeleton.md`

## N220 v2 optimization addendum

Always load the shared N220 references before producing the final artifact:
- `references/n220-shared-handoff.md`
- `references/n220-produced-events.md`
- `references/n220-downstream-contract.md`
- `references/n220-readiness-and-self-check.md`
- `references/n220-orchestration-policy.md`

Then apply the code-review specific v2 references:
- `references/comment-taxonomy-and-ratio.md`
- `references/conventional-comments-format.md`
- `references/educational-comment-content.md`
- `references/noise-suppression-rules.md`
- `references/comment-self-check-rules.md`

Every final output must include `n220_handoff`, `produced_event`, and `self_check_result`. In full N220 orchestration mode, cite upstream `DIFR-*` risk ids from diff-risk-review rather than creating parallel risk ids.



## Cross-skill integration map

| 上游 skill | 提供给 076 | 用途 |
|---|---|---|
| 077 diff-risk-review | `risk_items[]`, `difr_id` | 高风险区域优先生成审查评论 |
| 078 pull-request-description-generation | `pr_description` | 评论与 PR 描述保持语义一致 |

| 下游 skill | 076 输出 | 如何使用 |
|---|---|---|
| 078 | `review_comments[]` | PR 描述中引用审查要点 |
| N230 测试设计 | `suggested_tests[]` | 审查发现的测试缺口转交测试设计 |

**工作流位置**: Diff 提交 → **076 审查评论** → 078 PR描述 → 合并。

## Standalone usage guide

**Minimum input:** any diff — no PR context or upstream N220 artifacts required.

**Standalone decision path:**
1. Analyse diff directly; infer file purpose from path and naming.
2. If no diff context → set `readiness: constrained`; emit comment on metadata issues only.
3. Apply `senior_mode` automatically when diff > 500 lines.

**Minimum viable output:**
```yaml
review_comments:
  readiness: constrained
  mode: senior_mode
  comments:
    - id: RC-001
      type: blocker
      confidence: 0.82
      location: PaymentService.java:89
      issue: Null check missing on optional transaction reference
      suggestion: Add null guard before dereferencing transaction.getRef()
  suppressed_categories: [style]
  pending_pr_context: true
```
**Downstream:** review comments → 078 PR description (testing evidence) → 077 diff risk review.

## Resilience and governance

**Confidence scoring**: Every `comment_type: blocker` must include a `confidence` score (0–1) reflecting evidence strength. Comments derived solely from partial diffs use `confidence < 0.7` and are flagged for human review before merge blocking.

**SLA guidance**: In `release_gate` scenario mode, unresolved blockers trigger an `sla_queue_hint: P0`; unresolved suggestions trigger `P2`. Human reviewer must acknowledge before the gate closes.

**Circuit breaker**: If the same blocker pattern recurs across 3 or more consecutive PRs from the same module, emit `circuit_breaker: open` in `self_check` and recommend pausing merges until the root cause is resolved.

**Escalation path**: When `readiness: blocked` and no reviewer acknowledgement is received within the declared SLA window, escalate to the designated `reviewer_assignment_hint.escalation_target`.

**Human review routing**: Set `human_review_required: true` when confidence < 0.6 on any blocker, or when `pr_context: hotfix` and risk level is high.

## N220 v2 usage scenarios

Use these scenario labels when they better describe the task than a reader-profile mode:
- `pr_review`: standard pull request review and collaboration.
- `design_review`: architecture or design-level review when line-level code is secondary.
- `onboarding_review`: review for a new or junior contributor; preserve stronger teaching context.
- `release_gate`: pre-release or hotfix gate; focus on blockers, risk, rollback, and evidence.

Scenario labels may be combined with existing mode labels. For example: `selected_mode: learning_mode + onboarding_review` or `selected_mode: senior_mode + release_gate`.
