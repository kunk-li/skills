# N220 Produced Event Contract v2.0.0

Every N220 skill must include a `produced_event` block in its output. This lets the workflow_v2 event bus and cross-cutting subscribers consume artifacts without relying on file names alone.

## Event schema

```yaml
produced_event:
  schema_id: n220.produced_event
  schema_version: 2.0.0
  event_id: string
  event_type: produced.n220.diff_risk_review.v2 | produced.n220.code_review_comments.v2 | produced.n220.pr_description.v2 | produced.n220.commit_message.v2
  occurred_at: string
  workflow_node: N220
  producer_skill: string
  artifact:
    artifact_name: DiffRiskReview.md | CodeReviewComments.md | PullRequestDescription.md | CommitMessage.txt
    artifact_kind: diff_risk_review | code_review_comments | pr_description | commit_message
    artifact_contract_id: n220.diff_risk_review.v2 | n220.code_review_comments.v2 | n220.pr_description.v2 | n220.commit_message.v2
    artifact_schema_version: 2.0.0
    artifact_uri: string | null
  readiness: pass | constrained | blocked
  traceability:
    ticket_ids: []
    branch_name: string | null
    pr_id: string | null
    commit_ids: []
  subscriber_hints:
    downstream_nodes: [N240, N270, N300]
    crosscut_subscribers: [N330, N340, N350, N390]
```

## Event type mapping

| Skill | Event type | Artifact contract id |
|---|---|---|
| diff-risk-review | produced.n220.diff_risk_review.v2 | n220.diff_risk_review.v2 |
| code-review-comment-generation | produced.n220.code_review_comments.v2 | n220.code_review_comments.v2 |
| pull-request-description-generation | produced.n220.pr_description.v2 | n220.pr_description.v2 |
| commit-message-generation | produced.n220.commit_message.v2 | n220.commit_message.v2 |

## Rules

```yaml
rules:
  E01_event_required:
    description: Every final answer must include produced_event unless the user explicitly asks for a rough draft only.
    on_violation: reject

  E02_event_readiness_matches_handoff:
    description: produced_event.readiness must equal n220_handoff.readiness.
    on_violation: reject

  E03_artifact_contract_id_required:
    description: Artifact consumers must be able to route by artifact_contract_id.
    on_violation: reject
```
