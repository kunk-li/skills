# Noise Suppression Rules v2.0.0

Suppress review noise before generating comments.

```yaml
noise_suppression:
  auto_lint_comments_suppressed:
    description: Lint, formatting, or auto-fixable style should be delegated to pre-commit hooks or CI.
  duplicate_similar_suppressed:
    description: Explain the first occurrence in detail, then reference the pattern for repeated cases.
  style_discussion_suppressed:
    description: Do not argue personal taste. Use project conventions or downgrade to a question.
```

Rules:
- Do not restate static-analysis findings verbatim.
- Do not comment on whitespace-only issues unless the diff makes behavior ambiguous.
- Do not invent a team convention when none is provided.
