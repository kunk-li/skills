# Comment Taxonomy and Ratio Rules v2.0.0

## Categories

| Category | Meaning | Default decoration | Target ratio |
|---|---|---|---|
| blocker | Must be fixed before merge. Use only for security, data loss, compliance, transaction integrity, or correctness failures. | blocking | <=20% |
| suggestion | Strong improvement that should usually be accepted. | non-blocking or if-minor | 30-50% |
| nitpick | Small issue that can be accepted as-is. Prefix as `nit:`. | non-blocking | 10-20% |
| question | Clarification request; not necessarily a required change. Prefix as `question:`. | non-blocking | 10-20% |
| praise | Evidence-based positive feedback. Prefix as `praise:`. | non-blocking | >=5% |

## Priority mapping

```yaml
priority_mapping:
  P0:
    comment_category: blocker
    blocking: true
  P1:
    comment_category: suggestion
    blocking: contextual
  P2:
    comment_category: suggestion | question
    blocking: false
  Nit:
    comment_category: nitpick
    blocking: false
  Praise:
    comment_category: praise
    blocking: false
```

## Rebalancing rules

- If blocker ratio exceeds 20%, verify every blocker has direct evidence and merge-blocking impact. Downgrade weak blockers to suggestion.
- If praise is 0 and there is direct evidence of good design, add one concise praise. Never fabricate praise.
- Do not create comments purely to satisfy ratios on tiny diffs.
