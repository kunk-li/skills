> **V2 note**: This legacy quick list is preserved for backward compatibility. In N220 v2 or full-chain mode, use `references/comment-taxonomy-and-ratio.md` as the authoritative comment taxonomy and ratio policy.

# Review comment types

Use one comment_type per review item:
- blocker: must fix before merge
- suggestion: recommended improvement
- nitpick: tiny non-blocking issue
- question: reviewer needs clarification
- praise: positive feedback worth preserving
