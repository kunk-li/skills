# N220 Downstream Contract v2.0.0

Use this file to preserve field-level lineage across the N220 chain and downstream workflow nodes.

## Canonical field lineage

```yaml
field_lineage:
  - from: 077.risk_assessment.high_risk_areas_touched[]
    to:
      - 076.cr_comments[].context.relates_to_finding
      - 078.pr_description.sections.S6_risk_and_mitigation.identified_risks[]
      - N270.release-risk-assessment.input.risk_items[]

  - from: 077.risk_assessment.cross_file_consistency.related_changes_needed[]
    to:
      - N240.regression-test-checklist-generation.input.focus_areas[]
      - N260.quality-gate-check.input.consistency_risks[]

  - from: 076.cr_comments[comment_category=blocker]
    to:
      - 078.pr_description.sections.S6_risk_and_mitigation.identified_risks[]
      - N260.gate.blocking_items[]

  - from: 078.pr_description.final_markdown
    to:
      - 079.commit_message.body.source_pr_description
      - N270.release-note-generation.input.pr_description

  - from: 079.commit_message.type.version_bump
    to:
      - N270.version_bump.input.commit_semver_signal
      - semantic_release.input.commit_message
```

## Do-not-duplicate ownership

```yaml
canonical_owners:
  risk_summary: 077.diff-risk-review
  test_focus: 077.diff-risk-review
  monitoring_focus: 077.diff-risk-review
  rollback_notes: 077.diff-risk-review
  reviewer_ready_comments: 076.code-review-comment-generation
  pr_narrative: 078.pull-request-description-generation
  final_squash_commit_message: 079.commit-message-generation
```

A downstream skill may cite, summarize, or transform upstream fields, but it must not create a conflicting parallel source of truth.
