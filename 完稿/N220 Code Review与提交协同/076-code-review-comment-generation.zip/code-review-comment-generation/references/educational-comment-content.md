# Educational Comment Content v2.0.0

For every non-trivial comment, include what, why, and how.

```yaml
educational_content:
  what: string
  why:
    rationale: string
  how:
    concrete_steps: []
  references:
    - link_kind: internal_wiki | project_convention | general_docs | book_reference | stackoverflow | rfc
      url: string | null
      description: string
  teaching_level: junior | mid | senior
```

Rules:
- `blocker`, `suggestion`, and high-impact `question` comments require `why`.
- `nitpick` may omit long teaching content.
- Project conventions must be cited by id when available.
- Prefer official or internal references over generic web links.
