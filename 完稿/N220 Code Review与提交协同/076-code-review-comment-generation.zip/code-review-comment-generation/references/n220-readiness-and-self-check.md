# N220 Readiness and Self-check Rules v2.0.0

## Readiness states

- `pass`: The artifact is complete enough for its intended downstream consumer and all blocking questions are resolved.
- `constrained`: The artifact is useful but has missing evidence, inferred fields, or pending questions.
- `blocked`: The artifact should not be used downstream until a blocking issue is resolved.

## Required self-check block

```yaml
self_check_result:
  schema_id: n220.self_check
  schema_version: 2.0.0
  overall: pass | constrained | blocked
  checks:
    - check_id: string
      status: pass | warn | fail
      evidence: string
      on_violation: reject | warn | auto_format | suppress | block
```

## Common checks

```yaml
common_checks:
  C01_schema_present:
    on_violation: reject
  C02_required_sections_present:
    on_violation: reject
  C03_no_fabricated_evidence:
    on_violation: reject
  C04_traceability_preserved:
    on_violation: warn
  C05_open_questions_visible:
    on_violation: warn
  C06_downstream_handoff_present:
    on_violation: reject
  C07_produced_event_present:
    on_violation: reject
```
