# N220 Orchestration Policy v2.0.0

## Chain order

```text
077 diff-risk-review
  -> 076 code-review-comment-generation
  -> 078 pull-request-description-generation
  -> 079 commit-message-generation
```

## Mode policy

```yaml
orchestration_modes:
  standalone:
    description: A single skill is invoked directly.
    missing_upstream_artifacts: allowed
    behavior: keep_schema_and_mark_constrained

  n220_full_chain:
    description: The full N220 node flow is executed.
    missing_upstream_artifacts: warn_or_block_by_importance
    required_handoff:
      077_to_076:
        required: true
        fields: [risk_assessment, review_recommendations, validation_focus, rollback_notes]
      076_to_078:
        required: true
        fields: [blocker_comments, unresolved_questions, references_project_convention]
      078_to_079:
        required: true
        fields: [final_markdown, breaking_change_items, related_tickets_and_prs, change_categorization]
```

## Dependency rule for PR description

`CodeReviewComments.md` is optional in standalone mode and required or strongly recommended in full N220 orchestration mode. If it is missing in full-chain mode, mark the PR description as `constrained` and list the missing upstream artifact in `open_questions`.
