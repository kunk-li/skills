# Example IO v2

## Input

```yaml
pull_request:
  pr_id: PR-456
  title: "feat/order: add create order API"
  diff:
    total_lines_changed: 180
    files_changed: 5
risk_assessment_from_077:
  risk_items:
    - id: DIFR-001
      category: data_integrity
      severity: high
      evidence: ["OrderService.createOrder removes idempotency guard"]
project_conventions:
  - convention_id: STD-PROJ-IDEMPOTENCY
    description: "Write operations must be idempotent when clients may retry."
```

## Output

```yaml
selected_mode: senior_mode + pr_review
readiness: constrained
cr_comments:
  - comment_id: CR-001
    source_risk_id: DIFR-001
    comment_category: blocker
    conventional_comment:
      label: issue
      decorations: [blocking]
      subject: "restore idempotency guard for order creation"
      body: |
        **issue (blocking):** Restore idempotency protection before merging.
        This write path can be retried by clients, but the diff removes the guard that prevents duplicate order creation.
    educational_content:
      what: "The create-order path can execute twice for the same client retry."
      why: "Duplicate order creation can corrupt business state and violates STD-PROJ-IDEMPOTENCY."
      how:
        concrete_steps:
          - "Require an idempotency key for createOrder."
          - "Persist the key with a unique constraint or equivalent lock."
          - "Add a retry test that proves the second request returns the first result."
      references:
        - link_kind: project_convention
          description: "STD-PROJ-IDEMPOTENCY"
          url: null
      teaching_level: mid
    location:
      file_path: OrderService.java
      line_number: 87
      comment_scope: line
    actionable:
      clear_action: true
      estimated_effort_minutes: 30
ratio_enforcement:
  total_comments: 4
  by_category:
    blocker: 1
    suggestion: 2
    nitpick: 0
    question: 0
    praise: 1
  ratio_violations: []
n220_handoff:
  schema_id: n220.shared_handoff
  schema_version: 2.0.0
  artifact_kind: code_review_comments
  readiness: constrained
  evidence: ["DIFR-001", "STD-PROJ-IDEMPOTENCY"]
  confidence: direct
  open_questions: ["Confirm whether an upstream gateway already enforces idempotency keys."]
produced_event:
  event_type: produced.n220.code_review_comments.v2
  artifact_contract_id: n220.code_review_comments.v2
self_check_result:
  passed: false
  failed_checks: ["unresolved_open_question_present"]
```

## 076 扩展示例输入输出

### Scenario B — Security-critical review (hotfix mode)

**Input**: Hotfix PR fixing auth bypass — diff touches AuthController.java; `[urgent]` label.

**Output** (`hotfix_mode`, `security_focus`):
```yaml
review_comments:
  mode: hotfix_mode
  focus: security_blocker_first
  comments:
    - id: RC-001
      type: blocker
      confidence: 0.92
      location: SecurityFilter.java:88
      issue: Removed role-check guard without equivalent enforcement downstream
      risk: privilege escalation risk
      suggestion: Restore guard or add equivalent check in AuthController.requireRole()
    - id: RC-002
      type: blocker
      confidence: 0.85
      location: AuthController.java:45
      issue: New bypass path lacks audit log entry
      suggestion: Add SecurityAuditLogger.log(event) before returning success
  suppressed_categories: [style, educational]
  sla_queue_hint: P0
```



### Scenario C — Large diff architectural review (senior_mode)

**Input**: PR with 600-line diff refactoring authentication module across 8 files.

**Output** (`senior_mode`, auto-activated):
```yaml
review_comments:
  mode: senior_mode
  auto_activated_reason: diff_lines_gt_500
  comments:
    - id: RC-003
      type: architectural_concern
      confidence: 0.88
      scope: auth_module
      issue: Responsibility split across AuthController and SecurityFilter now ambiguous
      suggestion: Document which layer owns token validation; consider a single AuthGateway facade
    - id: RC-004
      type: blocker
      confidence: 0.91
      location: TokenRefreshService.java:45
      issue: Clock skew not accounted for in token expiry check — fails under distributed deployments
      suggestion: Use server-side UTC time with 30s grace period
  reviewer_assignment_hint:
    recommended_reviewer: senior-engineer
    reason: Architectural scope
```

### Scenario D — Large diff architectural review (auto senior_mode)

**Input**: PR with 620-line diff refactoring the authentication module across 9 files.

**Output** (`senior_mode`, auto-activated):
```yaml
review_comments:
  mode: senior_mode
  auto_activated_reason: diff_lines_gt_500
  readiness: ready
  comments:
    - id: RC-S001
      type: architectural_concern
      confidence: 0.88
      scope: auth_module
      issue: >
        Responsibility split between AuthController and SecurityFilter now ambiguous —
        token validation logic lives in both.
      suggestion: >
        Consolidate token validation into a single AuthGateway facade;
        document which layer is authoritative.
    - id: RC-S002
      type: blocker
      confidence: 0.92
      location: TokenRefreshService.java:45
      issue: Clock skew not accounted for in token expiry check
      suggestion: Use server-side UTC + 30s grace period
  reviewer_assignment_hint:
    recommended_reviewer: senior-engineer
    reason: Architectural scope exceeds normal review
```

### Scenario D — Security-critical change (auth refactor)

**Input**: PR refactoring JWT validation logic across 6 files; security label; DIFR-007 flags auth bypass risk.

**Output** (`security_review` mode):
```yaml
review_comments:
  mode: security_review
  readiness: constrained
  comments:
    - id: RC-SEC-001
      type: security_blocker
      confidence: 0.95
      location: JwtValidator.java:88
      issue: Algorithm switching attack — `alg` header accepted from JWT without allowlist
      suggestion: Enforce `alg=RS256` server-side; reject tokens specifying other algorithms
      human_review_required: true
    - id: RC-SEC-002
      type: security_blocker
      confidence: 0.91
      location: AuthFilter.java:144
      issue: Null token treated as anonymous — attacker can bypass auth with malformed header
      suggestion: Reject all requests where parsed token is null; return 401
  security_gate: blocked
  sla_queue_hint: P0
```
