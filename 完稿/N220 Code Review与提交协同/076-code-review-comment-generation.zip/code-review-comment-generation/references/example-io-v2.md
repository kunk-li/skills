# Example IO v2

## Input

```yaml
pull_request:
  pr_id: PR-456
  title: "feat/order: add create order API"
  diff:
    total_lines_changed: 180
    files_changed: 5
risk_assessment_from_077:
  risk_items:
    - id: DIFR-001
      category: data_integrity
      severity: high
      evidence: ["OrderService.createOrder removes idempotency guard"]
project_conventions:
  - convention_id: STD-PROJ-IDEMPOTENCY
    description: "Write operations must be idempotent when clients may retry."
```

## Output

```yaml
selected_mode: senior_mode + pr_review
readiness: constrained
cr_comments:
  - comment_id: CR-001
    source_risk_id: DIFR-001
    comment_category: blocker
    conventional_comment:
      label: issue
      decorations: [blocking]
      subject: "restore idempotency guard for order creation"
      body: |
        **issue (blocking):** Restore idempotency protection before merging.
        This write path can be retried by clients, but the diff removes the guard that prevents duplicate order creation.
    educational_content:
      what: "The create-order path can execute twice for the same client retry."
      why: "Duplicate order creation can corrupt business state and violates STD-PROJ-IDEMPOTENCY."
      how:
        concrete_steps:
          - "Require an idempotency key for createOrder."
          - "Persist the key with a unique constraint or equivalent lock."
          - "Add a retry test that proves the second request returns the first result."
      references:
        - link_kind: project_convention
          description: "STD-PROJ-IDEMPOTENCY"
          url: null
      teaching_level: mid
    location:
      file_path: OrderService.java
      line_number: 87
      comment_scope: line
    actionable:
      clear_action: true
      estimated_effort_minutes: 30
ratio_enforcement:
  total_comments: 4
  by_category:
    blocker: 1
    suggestion: 2
    nitpick: 0
    question: 0
    praise: 1
  ratio_violations: []
n220_handoff:
  schema_id: n220.shared_handoff
  schema_version: 2.0.0
  artifact_kind: code_review_comments
  readiness: constrained
  evidence: ["DIFR-001", "STD-PROJ-IDEMPOTENCY"]
  confidence: direct
  open_questions: ["Confirm whether an upstream gateway already enforces idempotency keys."]
produced_event:
  event_type: produced.n220.code_review_comments.v2
  artifact_contract_id: n220.code_review_comments.v2
self_check_result:
  passed: false
  failed_checks: ["unresolved_open_question_present"]
```
