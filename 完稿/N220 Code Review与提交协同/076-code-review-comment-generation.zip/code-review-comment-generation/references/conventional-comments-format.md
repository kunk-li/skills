# Conventional Comments Format v2.0.0

Use Conventional Comments for every review comment.

```markdown
**<label> (<decoration>):** <subject>

<body>
```

Allowed labels: `issue`, `suggestion`, `nitpick`, `question`, `praise`, `note`, `todo`, `thought`, `chore`.

Allowed decorations: `blocking`, `non-blocking`, `if-minor`.

## Required fields

```yaml
conventional_comment:
  label: issue | suggestion | nitpick | question | praise | note | todo | thought | chore
  decorations: [blocking | non-blocking | if-minor]
  subject: string
  body: string
```

## Example

```markdown
**suggestion (non-blocking):** make nullable intent explicit

The current behavior is valid, but using an explicit null-handling branch makes the edge case easier to review and test.
```
