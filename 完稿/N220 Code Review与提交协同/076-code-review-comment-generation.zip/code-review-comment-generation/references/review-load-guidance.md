# Review load guidance

> **V2 note**: This file now uses the N220 v2 PR size thresholds. The previous XS/S/M/L/XL thresholds are superseded to avoid tier drift.

## PR size tiers

| Tier | Lines changed | Review guidance |
| --- | ---: | --- |
| tiny | < 50 | 3-5 min review; comment only on critical correctness, security, data, or merge-blocking issues. |
| small | 50-200 | 15-30 min normal review; include focused suggestions and at least one praise when deserved. |
| medium | 200-500 | 45-60 min detailed review; group comments by risk theme and ensure test evidence is explicit. |
| large | 500-1000 | 2h+ review burden; recommend PR split unless the change is mechanically generated or tightly scoped. |
| extra_large | > 1000 | Treat as too large for normal review; recommend split before merge unless an explicit release-gate exception exists. |

## Calibration rules

- Use effective changed lines when available; count test-only bulk changes at 0.5 weight.
- Do not create style-only comments for large or extra-large PRs; delegate lint and format concerns to CI.
- For `large` and `extra_large`, add a PR split recommendation to `n220_handoff.open_questions` or `review_guidance`.
- When tier cannot be computed, set `confidence: unknown` and explain the missing size evidence.
