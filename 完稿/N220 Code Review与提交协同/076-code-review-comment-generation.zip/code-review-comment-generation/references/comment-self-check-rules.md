# Code Review Comment Self-check Rules v2.0.0

```yaml
checks:
  R01_category_required:
    on_violation: reject
  R02_blocker_has_direct_justification:
    on_violation: reject
  R03_ratio_balanced_or_tiny_diff_exempt:
    on_violation: auto_rebalance
  R04_nontrivial_comment_has_why:
    on_violation: reject
  R05_project_convention_has_id_when_cited:
    on_violation: reject
  R06_conventional_comments_format:
    on_violation: auto_format
  R07_lint_delegated_to_ci:
    on_violation: suppress
  R08_extra_large_pr_recommends_split:
    on_violation: block
  R09_suggestion_prefers_actionable_fix:
    on_violation: warn
  R10_no_personal_preference:
    on_violation: reject
```
