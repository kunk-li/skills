# N220 Shared Handoff Contract v2.0.0

Use this contract in every N220 skill result. It is the minimum shared schema that makes the four N220 skills independently usable and stronger when composed.

## Required handoff block

```yaml
n220_handoff:
  schema_id: n220.shared_handoff
  schema_version: 2.0.0
  workflow_node: N220
  source_skill: diff-risk-review | code-review-comment-generation | pull-request-description-generation | commit-message-generation
  artifact_kind: diff_risk_review | code_review_comments | pr_description | commit_message
  artifact_contract_id: n220.<artifact_kind>.v2
  readiness: pass | constrained | blocked
  evidence:
    - evidence_id: string
      kind: diff | file | line | test | ticket | convention | upstream_artifact | user_context
      value: string
      confidence: direct | inferred | unknown
  open_questions:
    - question: string
      blocks_readiness: true | false
  severity: info | low | medium | high | critical | blocker
  category: string
  traceability_links:
    - item_kind: ticket | branch | commit | pr | issue | rfc | finding | release | risk | comment
      item_id: string
      relation: closes | fixes | refs | depends_on | blocks | derived_from | validates | explains
```

## Recommended extension fields

```yaml
recommended_fields:
  object_name: string
  action_name: string
  trigger: string
  preconditions: []
  constraints: []
  roles: []
  impact: string
  validation_focus: []
  monitoring_focus: []
  rollback_notes: []
```

## Contract rules

```yaml
rules:
  H01_same_schema_in_all_skills:
    description: All four N220 skills must use this same shared handoff block.
    on_violation: reject

  H02_no_readiness_upgrade_without_new_evidence:
    description: A downstream skill must not raise readiness from constrained to pass unless it cites new direct evidence.
    on_violation: reject

  H03_open_questions_must_propagate_or_close:
    description: Unresolved upstream open questions must be propagated or explicitly closed with evidence.
    on_violation: reject

  H04_no_fabricated_traceability:
    description: Do not invent ticket ids, PR ids, commit hashes, test status, reviewers, or release facts.
    on_violation: reject

  H05_confidence_values_are_normalized:
    description: Use direct, inferred, or unknown. Treat explicit as an alias for direct when reading older artifacts.
    on_violation: auto_normalize
```
