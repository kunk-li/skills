---
name: commit-message-generation
description: generate workflow-aligned commit messages from git diffs, task context, ticket ids, and PR summaries. use when Claude works in coding & implementation / code review and submission collaboration and must produce the workflow-aligned commit message artifact for N220 while preserving traceability into PR, release, and defect workflows. trigger on any request to write a commit message, follow conventional commits, or suggest a squash strategy.
---
# commit-message-generation


## Routing decision table

| Situation | Action |
|---|---|
| Multiple commits to squash | Use `squash_merge` mode; generate consolidated subject and body |
| Commit touches breaking API | Add `BREAKING CHANGE` footer; set `breaking_change: true` |
| No ticket reference available | Omit `Refs` footer; set `pending_ticket_reference: true` |
| Commit message already written | Validate against conventional-commits; return diff if non-conforming |
| Commit subject > 72 chars | Truncate at last word boundary; move remainder to body |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n220.commit-message.v2.2"
contract_version: "n220.v2.2"
workflow_node: "N220"
```


## Role / role positioning
This skill aligns to coding & implementation -> code review and submission collaboration -> 提交信息.txt. It delivers a workflow-aligned artifact for N220.

### Boundary
- Focus on commit history quality and traceability.
- Prefer standardized commit candidates and split guidance over prose essays.
- Do not rewrite repository history beyond the scope the user provided.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `auto_draft`: suggest one or more commit candidates from diff evidence.
- `single`: emit one best commit message.
- `multi_commit_refine`: suggest split, reorder, or squash strategy.
- `changelog_extract`: format commits for downstream release-note use.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `git diff/改动列表`
- `PR描述.md` when generating a squash commit
- branch name, ticket ids, or existing commits when available

### optional workflow context
- `开发任务拆分表.csv`
- `代码规范检查单.csv` only when it materially explains commit scope

### optional enhancement inputs
- `PR描述.md`
- ticket ids, branch names, release labels
- risk notes or reviewer summary
- commit policy documents

## Standalone rule / standalone usage
This skill must still work on a small diff, a single logical change, or a task title.

Degradation rules:
- If scope is unclear, lower certainty and prefer generic-but-accurate scope names.
- If multiple unrelated themes exist, recommend split commits rather than forcing one message.
- If no ticket id exists, do not fabricate a footer.
- Keep output format stable even when body and footer are absent.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_review_and_submission_collaboration.commit_message_generation`
  - `workflow_node: N220`
  - `node_artifact_target: 提交信息.txt`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `suggested_strategy`
- `commit_candidates[]`
- `linked_ticket_ids[]`
- `breaking_flags[]`
- `merge_strategy_hint`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Enforce the structure in `references/conventional-commits.md` unless the user explicitly overrides it.
- Distinguish `type`, `scope`, `subject`, `body`, and `footer` clearly.
- Prefer accurate scope over flashy wording.
- For complex changes, include `What / Why / How / Impact` guidance in the body.
- Use issue and ticket footers when evidence exists; never invent ids.
- Surface breaking changes explicitly and consistently.
- Recommend squash, merge, or rebase strategy based on change granularity.

## Execution workflow / execution workflow
1. Detect the dominant logical change and likely commit type.
2. Infer or confirm scope from touched modules.
3. Draft one or more conventional-commit candidates.
4. Add body and footer when the change is complex or traceability requires it.
5. If the diff contains multiple unrelated themes, recommend a split strategy.
6. Hand off traceability to PR and release workflows.

## Dynamic completeness / dynamic completeness
- Tiny change: one concise candidate may be enough.
- Medium change: add body guidance and ticket footers.
- Multi-theme diff: produce split suggestions instead of one overloaded title.
- If breaking-change evidence is uncertain, phrase it as pending confirmation.


## Example usage

**Input**: git diff refactoring the authentication middleware to support JWT refresh tokens.

**Output** (`auto_draft` mode):
```
refactor(auth): add JWT refresh token support to middleware

Replaces session-based token renewal with a sliding refresh-token flow.
Access token TTL reduced to 15 min; refresh token valid for 7 days.
Existing login/logout endpoints unchanged.

BREAKING CHANGE: clients must handle 401 + refresh_token_required response
and call POST /auth/refresh to obtain a new access token.

Refs: PROJ-388
```
`suggested_strategy`: single commit; no split needed (single logical change).

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Quality bar / quality bar
A good result should be short enough to use, strong enough to preserve traceability, and aligned with downstream PR and release generation.


## Auditable rules

Apply these rules in order; record outcomes in `self_check.passed_rules` and `self_check.failed_rules`.

- R01_conventional_format: commit subject must follow `<type>(<scope>): <subject>` from `references/conventional-commits.md` unless user explicitly overrides; on_violation: reformat.
- R02_no_fabricated_ids: issue and ticket footers must not be invented; omit footer if no id evidence exists; on_violation: reject.
- R03_breaking_explicit: breaking changes must appear as `BREAKING CHANGE:` footer or `!` modifier; never buried in body prose; on_violation: surface.
- R04_scope_accurate: scope must reflect the actual module touched, not a generic placeholder; on_violation: warn_and_suggest.
- R05_multi_theme_split: when the diff contains multiple unrelated logical themes, recommend split commits rather than one overloaded title; on_violation: split_suggested.
- R06_squash_context_from_pr: for squash commits, prefer `PR_DESCRIPTION.final_markdown` as context when available; on_violation: warn.
- R07_body_for_complex: changes with significant why/impact context must include a body section; on_violation: warn.

## Algorithm

1. Detect the dominant logical change type (feat/fix/refactor/chore/docs/perf/test).
2. Infer scope from touched modules; apply R04 accuracy check.
3. Check for multiple unrelated themes; if found, recommend split (R05).
4. Draft commit subject in conventional format (R01).
5. Add body (What/Why/How/Impact) when complexity warrants (R07).
6. Add footer for ticket ids (R02) and breaking changes (R03).
7. Recommend squash/merge/rebase strategy based on change granularity.
8. Run `self_check`; surface any rule violations in `self_check.warnings` or `failed_rules`.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/field-contract.md`
- `references/readiness-inheritance.md`
- `references/n220-integration-map.md`
- `references/traceability-chain.md`
- `references/conventional-commits.md`
- `references/merge-strategy-guidance.md`
- `references/template-skeleton.md`

## N220 v2 optimization addendum

Always load the shared N220 references before producing the final artifact:
- `references/n220-shared-handoff.md`
- `references/n220-produced-events.md`
- `references/n220-downstream-contract.md`
- `references/n220-readiness-and-self-check.md`
- `references/n220-orchestration-policy.md`

Then apply the commit-message specific v2 references:
- `references/conventional-commits-v2.md`
- `references/type-version-bump-map.md`
- `references/subject-body-footer-rules.md`
- `references/breaking-change-commit-rules.md`
- `references/multi-commit-management.md`
- `references/commitlint-enforcement.md`

Prefer `PR_DESCRIPTION.final_markdown` as source context for squash commits when available. Every final output must include `n220_handoff`, `produced_event`, and `self_check_result`.



## Cross-skill integration map

| 上游 skill | 提供给 079 | 用途 |
|---|---|---|
| 076 code-review-comment-generation | 审查结论 | 提交信息准确反映审查要点 |
| 077 diff-risk-review | `risk_level` | 高风险提交添加警告标记 |

| 下游 skill | 079 输出 | 如何使用 |
|---|---|---|
| 078 | `commit_message` | PR 描述的变更章节引用提交信息 |
| N230 081 test-case-generation | `breaking_change` | 破坏性变更触发额外测试用例生成 |

**工作流位置**: 代码修改 → **079 提交信息** → 078 PR描述 → CI/CD。

## Standalone usage guide

**Minimum input:** a diff, staged changes, or even a plain description of what changed.

**Standalone decision path:**
1. If only a description → generate a conventional commit message; set `scope_confidence: inferred`.
2. If no ticket reference available → omit `footer.refs`; set `pending_ticket_reference: true`.
3. If squash scenario → generate one combined message; list constituent commits in body.

**Minimum viable output:**
```yaml
commit_message:
  subject: "fix(auth): handle null token on session expiry"
  body: "Session expiry path returned null token causing NPE at SessionManager:142."
  footer: ""
  scope_confidence: inferred
  pending_ticket_reference: true
  readiness: constrained
```
**Cross-skill:** feeds 078 PR description and N260 release notes.

## Resilience and governance

**Confidence scoring**: When commit scope is inferred (no explicit ticket or task ref), set `scope_confidence: inferred` in metadata. Downstream release note generators must treat inferred scopes as unverified.

**SLA guidance**: Breaking-change commits (`BREAKING CHANGE` footer) trigger `sla_queue_hint: P0` requiring author and reviewer acknowledgement before merge. Non-breaking commits default to `P2`.

**Circuit breaker**: If the same repository produces more than 5 consecutive commits violating the conventional-commit format, emit `circuit_breaker: warn` and recommend commitlint enforcement in CI.

**Escalation path**: When `readiness: blocked` due to unresolvable scope ambiguity on a release-critical commit, escalate to the release manager.

**Human review routing**: Set `human_review_required: true` for any commit with `BREAKING CHANGE` or when `multi_commit_refine` mode detects irreconcilable themes.

## N220 v2 usage scenarios

Use these scenario labels when they better describe the task than a reader-profile mode:
- `pr_review`: standard pull request review and collaboration.
- `design_review`: architecture or design-level review when line-level code is secondary.
- `onboarding_review`: review for a new or junior contributor; preserve stronger teaching context.
- `release_gate`: pre-release or hotfix gate; focus on blockers, risk, rollback, and evidence.

Scenario labels may be combined with existing mode labels. For example: `selected_mode: learning_mode + onboarding_review` or `selected_mode: senior_mode + release_gate`.
