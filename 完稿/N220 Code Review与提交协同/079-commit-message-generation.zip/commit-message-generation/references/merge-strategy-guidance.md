> **V2 note**: This legacy merge strategy note is preserved for backward compatibility. In N220 v2 or full-chain mode, use `references/multi-commit-management.md` as the authoritative multi-commit cleanup policy.

# Merge strategy guidance

Suggested defaults:
- squash and merge for small or medium single-theme PRs
- merge commit for larger feature branches with meaningful logical commits
- rebase and merge for teams that require linear history

If the diff contains multiple unrelated themes, recommend split commits before merge.
