# Example IO v2

## Input

```yaml
pr_description:
  summary: "Implement create-order API with retry-safe order creation."
  related_tickets:
    closes: [ORDER-123]
  change_categorization: [new_feature, tests]
  breaking_change_items: []
branch_name: feat/ORDER-123-create-api
```

## Output

```yaml
selected_mode: auto_draft + pr_review
readiness: pass
commit_message:
  type:
    value: feat
    version_bump: minor
  scope: order
  subject: "implement retry-safe create order API"
  format:
    full_message: |
      feat(order): implement retry-safe create order API

      - Add create-order endpoint and service path
      - Preserve retry safety with idempotency handling
      - Cover unit and integration tests

      Closes ORDER-123
  body:
    style: multi_change
    bullets:
      - "Add create-order endpoint and service path"
      - "Preserve retry safety with idempotency handling"
      - "Cover unit and integration tests"
  footer:
    closes:
      - ORDER-123
  breaking: false
  multi_commit_management:
    strategy: squash
    cleanup:
      fixup_commits_squashed: true
      wip_commits_removed: true
      empty_commits_removed: true
n220_handoff:
  schema_id: n220.shared_handoff
  schema_version: 2.0.0
  artifact_kind: commit_message
  readiness: pass
  evidence: ["PR description", "ORDER-123"]
  confidence: inferred
  traceability_links:
    - item_kind: ticket
      item_id: ORDER-123
      relation: closes
produced_event:
  event_type: produced.n220.commit_message.v2
  artifact_contract_id: n220.commit_message.v2
self_check_result:
  passed: true
```

## Breaking change variant

```text
feat(auth)!: migrate session auth to JWT

BREAKING CHANGE: Session cookies are no longer accepted. Clients must send an Authorization bearer token.

Closes AUTH-456
```

## 079 扩展示例输入输出

### Scenario B — Squash merge (feature branch)

**Input**: Feature branch with 6 commits to squash before merging to main.

**Output** (`squash_merge` mode):
```yaml
commit_message:
  mode: squash_merge
  subject: "feat(checkout): add promo code support with validation and discount calc"
  body: |
    Implements promo code entry on checkout form.
    - Add PromoCodeValidator with expiry and usage-limit checks
    - Integrate discount calculation into OrderTotal service
    - Add unit tests (PromoCodeValidatorTest, OrderTotalServiceTest)
  footer: "Closes #4821"
  breaking_change: false
  constituent_count: 6
```



### Scenario C — Breaking change commit

**Input**: Remove deprecated `GET /api/v1/users/search` endpoint.

**Output** (breaking change):
```yaml
commit_message:
  subject: "feat(api)!: remove deprecated /api/v1/users/search endpoint"
  body: |
    Endpoint deprecated since v2.1 and announced for removal in v2.8 changelog.
    Migration path: use POST /api/v2/users/query (see docs/migration/v2-to-v3.md).
  footer: |
    BREAKING CHANGE: GET /api/v1/users/search is removed.
    Refs: #3892
  breaking_change: true
  migration_guide: docs/migration/v2-to-v3.md
```

### Scenario D — Breaking change commit

**Input**: Remove deprecated `GET /api/v1/users/search` endpoint.

**Output** (breaking change conventional commit):
```yaml
commit_message:
  subject: "feat(api)!: remove deprecated /api/v1/users/search endpoint"
  body: |
    Endpoint deprecated since v2.1; removal announced in v2.8 changelog.
    Migration: use POST /api/v2/users/query (docs/migration/v2-to-v3.md).
  footer: |
    BREAKING CHANGE: GET /api/v1/users/search is removed.
    Refs: #3892
  breaking_change: true
  migration_guide: docs/migration/v2-to-v3.md
```

### Scenario D — Revert commit

**Input**: Reverting previous commit that introduced a regression; must reference original commit and reason.

**Output** (revert conventional commit):
```yaml
commit_message:
  subject: "revert: feat(payment): add retry logic for payment gateway"
  body: |
    This reverts commit a3f9c21b.

    Reason: Retry logic introduced duplicate charges under high latency conditions
    (INC-4821). Reverting to restore stable state while a safe fix is developed.
  footer: |
    Refs: INC-4821
    Reverts: a3f9c21b
  revert_commit: a3f9c21b
  incident_ref: INC-4821
  readiness: ready
```
