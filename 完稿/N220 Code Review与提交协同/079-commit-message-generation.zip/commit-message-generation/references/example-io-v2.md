# Example IO v2

## Input

```yaml
pr_description:
  summary: "Implement create-order API with retry-safe order creation."
  related_tickets:
    closes: [ORDER-123]
  change_categorization: [new_feature, tests]
  breaking_change_items: []
branch_name: feat/ORDER-123-create-api
```

## Output

```yaml
selected_mode: auto_draft + pr_review
readiness: pass
commit_message:
  type:
    value: feat
    version_bump: minor
  scope: order
  subject: "implement retry-safe create order API"
  format:
    full_message: |
      feat(order): implement retry-safe create order API

      - Add create-order endpoint and service path
      - Preserve retry safety with idempotency handling
      - Cover unit and integration tests

      Closes ORDER-123
  body:
    style: multi_change
    bullets:
      - "Add create-order endpoint and service path"
      - "Preserve retry safety with idempotency handling"
      - "Cover unit and integration tests"
  footer:
    closes:
      - ORDER-123
  breaking: false
  multi_commit_management:
    strategy: squash
    cleanup:
      fixup_commits_squashed: true
      wip_commits_removed: true
      empty_commits_removed: true
n220_handoff:
  schema_id: n220.shared_handoff
  schema_version: 2.0.0
  artifact_kind: commit_message
  readiness: pass
  evidence: ["PR description", "ORDER-123"]
  confidence: inferred
  traceability_links:
    - item_kind: ticket
      item_id: ORDER-123
      relation: closes
produced_event:
  event_type: produced.n220.commit_message.v2
  artifact_contract_id: n220.commit_message.v2
self_check_result:
  passed: true
```

## Breaking change variant

```text
feat(auth)!: migrate session auth to JWT

BREAKING CHANGE: Session cookies are no longer accepted. Clients must send an Authorization bearer token.

Closes AUTH-456
```
