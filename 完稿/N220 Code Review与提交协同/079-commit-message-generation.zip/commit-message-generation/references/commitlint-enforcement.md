# Commitlint Enforcement v2.0.0

Recommended enforcement:

```yaml
enforcement:
  tool: commitlint
  pre_commit_hook:
    enabled: true
    validate_on_commit: true
  ci_validation:
    enabled: true
    block_merge_on_violation: true
```

The skill should generate messages likely to pass commitlint, but it must not claim CI has passed unless the user provides evidence.
