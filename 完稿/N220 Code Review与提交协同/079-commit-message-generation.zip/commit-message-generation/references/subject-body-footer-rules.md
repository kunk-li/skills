# Subject, Body, and Footer Rules v2.0.0

## Subject

```yaml
subject:
  max_length: 72
  style:
    - imperative_mood
    - lowercase_first_letter
    - no_trailing_period
  forbidden_starters: [Fixed, Added, Changed, Updated]
```

## Body templates

```text
- Change 1
- Change 2
- Change 3
```

```text
Previously, <old behavior>.

Now, <new behavior>.

Because <reason>.
```

## Footer elements

Allowed footers:
- `BREAKING CHANGE: <description>`
- `Closes <ticket-or-issue>`
- `Fixes <ticket-or-issue>`
- `Refs <ticket-or-issue>`
- `Co-authored-by: Name <email>`
- `Signed-off-by: Name <email>`
