> **V2 note**: This legacy Conventional Commits primer is preserved for backward compatibility. In N220 v2 or full-chain mode, also load `references/type-version-bump-map.md`, `references/subject-body-footer-rules.md`, and `references/conventional-commits-v2.md`.

# Conventional Commits v2.0.0

This skill follows the Conventional Commits structure:

```text
<type>(<scope>): <subject>

<body>

<footer>
```

See also:
- `references/type-version-bump-map.md`
- `references/subject-body-footer-rules.md`
- `references/breaking-change-commit-rules.md`
- `references/multi-commit-management.md`
- `references/commitlint-enforcement.md`
