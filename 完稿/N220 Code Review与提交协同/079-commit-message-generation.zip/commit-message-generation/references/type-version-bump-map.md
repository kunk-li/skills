# Type to Version Bump Map v2.0.0

```yaml
types:
  feat:
    meaning: new feature
    version_bump: minor
  fix:
    meaning: bug fix
    version_bump: patch
  docs:
    version_bump: none
  style:
    version_bump: none
  refactor:
    version_bump: none
  perf:
    version_bump: patch
  test:
    version_bump: none
  build:
    version_bump: none
  ci:
    version_bump: none
  chore:
    version_bump: none
  revert:
    special: true
breaking_change:
  marker: "! or BREAKING CHANGE footer"
  version_bump: major
```
