# Conventional Commits v2.0.0

```text
<type>(<scope>): <subject>

<body>

<footer>
```

`scope` is recommended when it can be inferred from a module or feature area. Use lowercase noun scopes with hyphens, no spaces.

Use a body when the subject alone cannot explain what changed and why.
