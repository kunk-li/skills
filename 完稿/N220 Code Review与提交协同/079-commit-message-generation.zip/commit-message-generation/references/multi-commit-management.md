# Multi-commit Management v2.0.0

```yaml
strategy:
  squash:
    best_for: small PR or single logical feature
    final_message_generation: use PR description when available
  merge_commit:
    best_for: clear incremental history
  rebase:
    best_for: linear structured history
commit_cleanup:
  fixup_commits_squashed: true
  wip_commits_removed: true
  empty_commits_removed: true
```

If a diff contains unrelated themes, recommend split commits instead of forcing one overloaded message.
