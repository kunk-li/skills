# Breaking Change Commit Rules v2.0.0

A breaking commit must use one of these forms:

```text
feat(api)!: change order creation response
```

or

```text
feat(api): change order creation response

BREAKING CHANGE: Clients must read `orderId` from `data.id` instead of top-level `id`.
```

Rules:
- Include migration instructions when known.
- Include backward compatibility notes when known.
- If breaking evidence is uncertain, produce a candidate marked `pending_breaking_confirmation` rather than claiming it is breaking.
