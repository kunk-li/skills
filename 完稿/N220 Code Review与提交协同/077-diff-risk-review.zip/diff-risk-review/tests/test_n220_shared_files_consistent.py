"""Guard N220 shared reference files against cross-skill drift."""
from __future__ import annotations

import hashlib
from pathlib import Path
import unittest


SHARED_FILES = [
    "n220-shared-handoff.md",
    "n220-orchestration-policy.md",
    "n220-readiness-and-self-check.md",
    "n220-produced-events.md",
    "n220-downstream-contract.md",
    "n220-integration-map.md",
]

SKILL_DIRS = [
    "code-review-comment-generation",
    "diff-risk-review",
    "pull-request-description-generation",
    "commit-message-generation",
]


def _workspace_root() -> Path:
    # .../diff-risk-review/tests/test_file.py -> .../n220_round3_work
    return Path(__file__).resolve().parents[2]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class N220SharedFilesConsistencyTest(unittest.TestCase):
    def test_n220_shared_reference_files_are_identical_across_skills(self) -> None:
        root = _workspace_root()
        missing_skill_dirs = [skill for skill in SKILL_DIRS if not (root / skill).exists()]
        if missing_skill_dirs:
            self.skipTest(
                "shared-file drift check requires the full N220 workspace; "
                f"missing: {', '.join(missing_skill_dirs)}"
            )

        for filename in SHARED_FILES:
            digests = {}
            for skill in SKILL_DIRS:
                path = root / skill / "references" / filename
                self.assertTrue(path.exists(), f"missing shared file: {path}")
                digests[skill] = _sha256(path)
            self.assertEqual(
                len(set(digests.values())),
                1,
                f"shared file drift for {filename}: {digests}",
            )


if __name__ == "__main__":
    unittest.main()
