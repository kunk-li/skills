#!/usr/bin/env python3
"""Universal SKILL.md validator — see references/template-skeleton.md for spec."""
import sys, re, os

def validate(path):
    c = open(path).read(); lo = c.lower()
    in_code = False; real_hs = []
    for line in c.splitlines():
        if line.startswith("```"): in_code = not in_code
        if not in_code and line.startswith("## "): real_hs.append(line.lower().strip())
    errors = []
    if in_code: errors.append("unclosed_block")
    for f in ["skill_version","schema_version","contract_version","workflow_node"]:
        if f not in lo: errors.append(f"miss:{f}")
    for pats, lbl in [
        ([r"## (auditable rules|auditable rules summary|design rules)"],"auditable"),
        ([r"## (algorithm|execution workflow)"],"algorithm"),
        ([r"## (quality bar)"],"quality_bar"),
        ([r"## (reference files|references)"],"refs"),
        ([r"## (example usage|example)"],"example"),
    ]:
        if not any(any(re.match(p,h) for p in pats) for h in real_hs):
            errors.append(f"miss_section:{lbl}")
    ref_dir = os.path.join(os.path.dirname(path),"references")
    for line in c.splitlines():
        m = re.search(r"`references/([^`]+)`", line)
        if m and not os.path.exists(os.path.join(ref_dir,m.group(1))):
            errors.append(f"broken:{m.group(1)[:30]}")
    sv = re.search(r'skill_version:\s*"([^"]+)"',c)
    if sv and sv.group(1) != "2.2": errors.append(f"ver:{sv.group(1)}")
    skill = os.path.basename(os.path.dirname(path))
    if errors:
        print(f"FAIL [{skill}]: {errors}")
        return False
    print(f"OK   [{skill}]: {len(c.splitlines())}L {len(real_hs)}sec")
    return True

if __name__ == "__main__":
    paths = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not paths: paths = [os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),"SKILL.md")]
    results = [validate(p) for p in paths]
    sys.exit(0 if all(results) else 1)
