import json
import subprocess
import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts' / 'diff_signal_extractor.py'
FIXTURE = ROOT / 'tests' / 'fixtures' / 'sample.diff'


class DiffSignalExtractorTest(unittest.TestCase):
    def test_json_output_contains_expected_categories(self):
        out = subprocess.check_output([sys.executable, str(SCRIPT), '--input', str(FIXTURE), '--format', 'json'], text=True)
        payload = json.loads(out)
        categories = {item['category'] for item in payload['risk_signals']}
        self.assertIn('data_schema', categories)
        self.assertIn('async_retry', categories)
        self.assertTrue(payload['summary']['missing_test_hint'])


    def test_json_output_contains_v2_categories(self):
        out = subprocess.check_output([sys.executable, str(SCRIPT), '--input', str(FIXTURE), '--format', 'json'], text=True)
        payload = json.loads(out)
        self.assertIn('v2_risk_categories', payload)
        categories = {item['category'] for item in payload['v2_risk_categories']}
        self.assertTrue({'data_integrity', 'performance_critical'} & categories)

    def test_markdown_output_renders_summary(self):
        out = subprocess.check_output([sys.executable, str(SCRIPT), '--input', str(FIXTURE), '--format', 'markdown'], text=True)
        self.assertIn('# Diff signal summary', out)
        self.assertIn('risk signals', out)


if __name__ == '__main__':
    unittest.main()
