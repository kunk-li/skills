> **V2 note**: This legacy scoring guide is preserved for backward compatibility. In N220 v2 or full-chain mode, use `references/risk-scoring-formula.md` as the authoritative weighted scoring contract.

# Diff risk scoring

Suggested factors:
- files changed
- lines added and deleted
- high-risk files touched
- test changes present or absent
- migration included
- breaking api changes
- dependency or config changes

Suggested score bands:
- 0 to 3: low
- more than 3 to 6: medium
- more than 6 to 8: high
- more than 8: critical
