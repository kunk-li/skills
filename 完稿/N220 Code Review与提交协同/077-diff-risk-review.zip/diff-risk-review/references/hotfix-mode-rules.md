> **V2 note**: This legacy hotfix guide is preserved for backward compatibility. In N220 v2 or full-chain mode, use `references/hotfix-safeguards.md` for structured safeguards and completion flags.

# Hotfix mode rules

For hotfix reviews:
- prefer the minimum necessary diff
- require rollback clarity
- require test focus even if time is compressed
- highlight config and data risks immediately
- do not pad with nonessential refactor suggestions
