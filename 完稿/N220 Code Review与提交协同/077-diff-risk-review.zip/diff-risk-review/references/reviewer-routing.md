# Reviewer Routing v2.0.0

```yaml
reviewer_recommendation:
  financial: [finance_tech_lead, architect]
  security: [security_team_member]
  compliance: [compliance_officer]
  core_business: [domain_lead]
  data_integrity: [dba, architect]
  third_party_integration: [integration_expert]
  performance_critical: [perf_specialist]
  release_infrastructure: [release_engineer]
```

If the actual organization roles are unknown, output role names rather than people names.
