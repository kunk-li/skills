# Example IO v2

## Input

```yaml
diff:
  files_changed:
    - src/main/java/order/OrderService.java
    - src/main/resources/db/migration/V42__orders.sql
  additions: 120
  deletions: 60
is_hotfix: false
high_risk_modules:
  - module_name: order
    risk_category: core_business
bug_history:
  hotspot_files:
    - file: OrderService.java
      bug_count_last_6_months: 5
```

## Output

```yaml
selected_mode: deep_analysis + pr_review
readiness: constrained
risk_assessment:
  assessment_id: DIFR-001
  high_risk_areas_touched:
    - module_name: order
      risk_category: core_business
      files_affected: ["OrderService.java"]
      reviewer_requirement: mandatory_senior
  diff_risk_score:
    total_score: 7.2
    risk_tier: high
    factors:
      scale_factor:
        lines_changed: 180
        files_changed: 2
        score_contribution: 1.2
      risk_area_factor:
        high_risk_touched: true
        categories: [core_business, data_integrity]
        score_contribution: 3.0
      historical_bug_factor:
        hotspot_files_touched: ["OrderService.java"]
        score_contribution: 1.2
      complexity_factor:
        score_contribution: 0.8
      test_coverage_factor:
        tests_added: false
        score_contribution: 0.8
      timing_factor:
        is_hotfix: false
        score_contribution: 0.2
  cross_file_consistency:
    related_changes_needed:
      - pattern: entity_and_migration
        status: partial
        files_expected: ["Entity", "Migration", "Repository/Validator"]
        files_found: ["Migration"]
        missing_files: ["Entity", "Validator"]
  review_recommendations:
    required_reviewers:
      - role: domain_lead
        rationale: "core_business change in order flow"
    review_focus_areas:
      - area: "Idempotency and duplicate order prevention"
        priority: 1
        specific_questions:
          - "Can a retry create two orders?"
    suggested_testing:
      - "Add retry/idempotency integration test."
    canary_recommendation:
      canary_required: true
      canary_percentage: "5%"
      canary_duration: "2h"
n220_handoff:
  schema_id: n220.shared_handoff
  schema_version: 2.0.0
  artifact_kind: diff_risk_review
  readiness: constrained
  evidence: ["OrderService.java", "V42__orders.sql"]
  confidence: inferred
  validation_focus: ["retry idempotency", "migration/entity consistency"]
  rollback_notes: ["Prepare rollback for V42 migration before release."]
produced_event:
  event_type: produced.n220.diff_risk_review.v2
  artifact_contract_id: n220.diff_risk_review.v2
self_check_result:
  passed: true
```
