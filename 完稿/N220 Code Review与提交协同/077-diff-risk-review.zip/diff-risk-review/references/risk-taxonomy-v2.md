# Diff Risk Taxonomy v2.0.0

Use these canonical risk categories.

| Category | Meaning | Default reviewer requirement |
|---|---|---|
| financial | Money movement, billing, ledger, settlement, reconciliation. | mandatory_senior |
| security | Authn, authz, encryption, secrets, permission gates. | mandatory_security |
| compliance | Audit, PII, retention, regulatory reporting. | mandatory_senior |
| user_data | User privacy data, profile data, exports, deletion. | mandatory_senior |
| core_business | Critical user or business workflows. | mandatory_senior |
| data_integrity | Transactions, migrations, schemas, validators, idempotency. | mandatory_dba or mandatory_senior |
| third_party_integration | Payment providers, identity providers, external APIs, webhooks. | optional or integration_expert |
| performance_critical | Hot paths, async retries, queues, cache, bulk jobs. | optional or perf_specialist |
| release_infrastructure | CI/CD, config, feature flags, deploy scripts, rollback paths. | optional |

`observability` is allowed as an auxiliary signal, but map final risk to one of the canonical categories above when possible.
