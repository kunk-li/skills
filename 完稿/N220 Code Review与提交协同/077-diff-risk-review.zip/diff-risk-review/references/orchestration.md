> **V2 note**: This orchestration guide is preserved for backward compatibility. In N220 v2 or full-chain mode, use `references/n220-orchestration-policy.md` as the authoritative cross-skill handoff policy.

# 跨 skill 编排说明（标准别名）

本文件与 `cross-skill-orchestration.md` 保持同义，供偏好标准命名的 skill 工具读取。

## N220 推荐链路

1. `diff-risk-review`
2. `code-review-comment-generation`
3. `pull-request-description-generation`
4. `commit-message-generation`

## 最小交接字段

- `id`
- `name`
- `evidence`
- `confidence`
- `open_questions`
- `severity`
- `validation_focus`
- `monitoring_focus`
- `rollback_notes`
