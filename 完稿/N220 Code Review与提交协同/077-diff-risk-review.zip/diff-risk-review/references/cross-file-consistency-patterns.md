# Cross-file Consistency Patterns v2.0.0

Run these checks when matching signals appear in the diff.

```yaml
patterns:
  api_and_dto:
    trigger: API route, OpenAPI, public controller, request/response signature changed
    expected: [OpenAPI spec, Controller, Request DTO, Response DTO]
  entity_and_migration:
    trigger: Entity, ORM model, table schema, column, index changed
    expected: [Entity or model, Migration or schema change]
  config_and_default:
    trigger: New config key, renamed config key, feature flag, env var
    expected: [Config declaration, Default value, Documentation or sample config]
  interface_and_implementation:
    trigger: Interface, abstract class, public contract changed
    expected: [Interface, Implementation, tests or callers]
  proto_and_generated:
    trigger: .proto, thrift, OpenAPI generated model changed
    expected: [Schema, Generated code, compatibility note]
  schema_and_validator:
    trigger: Request schema, form schema, DB schema, validation rule changed
    expected: [Schema, Validator, negative tests]
```

Output shape:

```yaml
cross_file_consistency:
  related_changes_needed:
    - pattern: api_and_dto | entity_and_migration | config_and_default | interface_and_implementation | proto_and_generated | schema_and_validator
      status: consistent | partial | inconsistent
      files_expected: []
      files_found: []
      missing_files: []
      blocking: true | false
```
