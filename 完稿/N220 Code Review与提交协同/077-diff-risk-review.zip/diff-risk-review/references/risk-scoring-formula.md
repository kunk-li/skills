# Risk Scoring Formula v2.0.0

Calculate a 0-10 score with this weighted formula.

```text
total = (scale*0.15 + risk_area*0.35 + historical_bug*0.20 + complexity*0.15 + test_coverage*0.10 + timing*0.05) * 10
```

Each factor is normalized to 0.0-1.0.

```yaml
risk_tier:
  low: total < 3
  medium: 3 <= total < 6
  high: 6 <= total <= 8
  critical: total > 8
```

If an input is missing, mark that factor as `unknown` and keep readiness `constrained`; do not fabricate history or coverage.
