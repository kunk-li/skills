# 脚本使用、测试样例与限制说明

可用脚本：`scripts/diff_signal_extractor.py`

## 适合做什么

- 作为**预处理器 / 粗信号提取器 / 草稿生成器**。
- 帮助 ChatGPT 更快整理输入，但不能替代最终判断。

## 建议使用方式

1. 先运行脚本获取草稿输出。
2. 再结合业务上下文、原始材料和本 skill 的字段 contract 做人工整理。
3. 若脚本输出与原文冲突，以原文证据和人工判断为准。

## 已补充的样例测试

- `tests/fixtures/`：最小样例输入。
- `tests/test_*.py`：基于 `unittest` 的代表性测试。
- 运行方式：`python -m unittest discover -s tests -p 'test_*.py'`

## 已知限制
- 关键词命中只能说明“值得关注”，不能自动等价为风险结论。
- 无法真正理解跨文件控制流、隐式依赖、运行时配置组合。
- 缺少测试变更不一定代表没有测试，只能作为提示。

## V2 JSON output fields

When invoked with `--json`, the extractor now returns both legacy and v2 signals:
- `risk_signals`: legacy 7-category keyword signal map, preserved for backward compatibility.
- `v2_risk_categories`: N220 v2 9-category signal map: `financial`, `security`, `compliance`, `user_data`, `core_business`, `data_integrity`, `third_party_integration`, `performance_critical`, and `release_infrastructure`.

Treat both fields as coarse evidence only. They are not final gate decisions; the skill must still reason over context, tests, hotfix state, and project conventions before assigning `risk_tier` or `readiness`.
