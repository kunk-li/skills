# Hotfix Safeguards v2.0.0

When `is_hotfix=true`, include the following safeguard checklist.

```yaml
required_safeguards:
  - safeguard: dual_approval
    completed: true | false | unknown
  - safeguard: expedited_prod_monitoring
    completed: true | false | unknown
  - safeguard: rapid_rollback_ready
    completed: true | false | unknown
  - safeguard: follow_up_test_suite
    completed: true | false | unknown
  - safeguard: develop_branch_sync
    completed: true | false | unknown
```

Hotfix risks to check: rushed_testing, minimal_review, direct_to_prod, no_canary, hotfix_only_main_branch, future_merge_conflict.
