# Canary and Rollback Handoff v2.0.0

For high or critical risk, output release-ready hints.

```yaml
canary_recommendation:
  canary_required: true | false | unknown
  canary_percentage: string | null
  canary_duration: string | null
  rationale: string

rollback_focus:
  - rollback_action: string
    precondition: string | null
    validation_after_rollback: string | null
```

Do not claim a rollback plan exists unless the input provides one. If it is needed but absent, mark readiness constrained or blocked.
