> **V2 note**: This legacy risk-area guide is preserved for backward compatibility. In N220 v2 or full-chain mode, use `references/risk-taxonomy-v2.md` as the authoritative 9-category risk taxonomy.

# High risk area policy

Treat changes in these kinds of areas as risk amplifiers when evidence exists:
- audit or compliance logic
- authorization and permission logic
- money, amount, settlement, or pricing logic
- schema migrations and data backfills
- configuration and feature-flag centers
- core state machines and irreversible transitions
