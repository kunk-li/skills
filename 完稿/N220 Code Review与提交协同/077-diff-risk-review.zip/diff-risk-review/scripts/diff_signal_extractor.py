#!/usr/bin/env python3
"""Extract coarse risk signals from a unified diff.

This helper script is intentionally heuristic.
Use it to surface areas that deserve manual review, not as a final risk verdict.
"""
import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

V2_CATEGORY_RULES = {
    'financial': [r'payment', r'billing', r'ledger', r'settlement', r'invoice', r'charge', r'refund'],
    'security': [r'permission', r'forbidden', r'unauthorized', r'role', r'auth', r'token', r'secret'],
    'compliance': [r'audit', r'pii', r'privacy', r'retention', r'gdpr', r'compliance'],
    'user_data': [r'user.*data', r'profile', r'email', r'phone', r'idcard', r'address'],
    'core_business': [r'status', r'state', r'approve', r'reject', r'callback', r'transition', r'order'],
    'data_integrity': [r'alter table', r'create table', r'drop table', r'migration', r'schema', r'index', r'transaction', r'rollback', r'commit'],
    'third_party_integration': [r'webhook', r'provider', r'client', r'callback', r'external api', r'sdk'],
    'performance_critical': [r'queue', r'kafka', r'consumer', r'async', r'retry', r'scheduler', r'cache', r'redis'],
    'release_infrastructure': [r'feature flag', r'config', r'\.ya?ml', r'\.env', r'deploy', r'ci', r'rollback'],
}

CATEGORY_RULES = {
    'permission': [r'permission', r'forbidden', r'unauthorized', r'role', r'auth'],
    'state_flow': [r'status', r'state', r'approve', r'reject', r'callback', r'transition'],
    'data_schema': [r'alter table', r'create table', r'drop table', r'migration', r'schema', r'index'],
    'async_retry': [r'queue', r'kafka', r'consumer', r'async', r'retry', r'scheduler'],
    'cache_config': [r'cache', r'redis', r'feature flag', r'config', r'\.ya?ml', r'\.env'],
    'observability': [r'logger', r'metric', r'trace', r'prometheus', r'alarm', r'monitor'],
    'transaction_sql': [r'transaction', r'rollback', r'commit', r'delete from', r'update .* set', r'insert into'],
}


def parse_args():
    ap = argparse.ArgumentParser(description='Extract coarse risk signals from unified diff.')
    ap.add_argument('--input', required=True, help='Path to diff file')
    ap.add_argument('--format', choices=['json', 'markdown'], default='json')
    return ap.parse_args()


def level_for(category, evidence_count):
    base = {
        'permission': 'high',
        'data_schema': 'high',
        'transaction_sql': 'high',
        'state_flow': 'medium',
        'async_retry': 'medium',
        'cache_config': 'medium',
        'observability': 'low',
    }[category]
    if evidence_count >= 4 and base == 'medium':
        return 'high'
    return base


def to_markdown(payload):
    lines = ['# Diff signal summary']
    lines.append(f"- changed_files: {payload['summary']['changed_file_count']}")
    lines.append(f"- additions: {payload['summary']['added_lines']}")
    lines.append(f"- deletions: {payload['summary']['deleted_lines']}")
    lines.append(f"- missing_test_hint: {payload['summary']['missing_test_hint']}")
    lines.append('')
    lines.append('## risk signals')
    for item in payload['risk_signals']:
        lines.append(f"- [{item['level']}] {item['category']}: {item['reason']}")
    if payload['observability_gaps']:
        lines.append('')
        lines.append('## observability gaps')
        for gap in payload['observability_gaps']:
            lines.append(f'- {gap}')
    return '\n'.join(lines)


def main():
    args = parse_args()
    lines = Path(args.input).read_text(encoding='utf-8', errors='replace').splitlines()
    current_file = None
    changed_files = []
    file_stats = defaultdict(lambda: {'added': 0, 'deleted': 0})
    all_added = []
    all_deleted = []

    for line in lines:
        if line.startswith('diff --git '):
            parts = line.split()
            if len(parts) >= 4:
                current_file = parts[3][2:]
                changed_files.append(current_file)
        elif line.startswith('+++ b/'):
            current_file = line[6:]
            if current_file not in changed_files:
                changed_files.append(current_file)
        elif current_file and line.startswith('+') and not line.startswith('+++'):
            file_stats[current_file]['added'] += 1
            all_added.append((current_file, line[1:]))
        elif current_file and line.startswith('-') and not line.startswith('---'):
            file_stats[current_file]['deleted'] += 1
            all_deleted.append((current_file, line[1:]))

    risk_signals = []
    category_hits = defaultdict(list)
    v2_category_hits = defaultdict(list)
    for file_name, line in all_added + all_deleted:
        lower = line.lower()
        for category, rules in CATEGORY_RULES.items():
            if any(re.search(rule, lower) for rule in rules):
                category_hits[category].append({'file': file_name, 'line': line[:180]})
        for category, rules in V2_CATEGORY_RULES.items():
            if any(re.search(rule, lower) for rule in rules):
                v2_category_hits[category].append({'file': file_name, 'line': line[:180]})

    for category, hits in sorted(category_hits.items()):
        risk_signals.append({
            'category': category,
            'level': level_for(category, len(hits)),
            'reason': f'{category} related changes observed in {len({h["file"] for h in hits})} file(s)',
            'evidence': hits[:5],
        })

    deleted_guards = [x for x in all_deleted if re.search(r'if\s*\(|forbidden|unauthorized|permission', x[1], re.I)]
    if deleted_guards:
        risk_signals.append({
            'category': 'removed_guard',
            'level': 'high',
            'reason': 'guard / permission / conditional logic removed in diff',
            'evidence': [{'file': f, 'line': l[:180]} for f, l in deleted_guards[:5]],
        })

    changed_set = set(changed_files)
    has_prod_code = any(not re.search(r'test|spec|__tests__', f, re.I) for f in changed_set)
    has_test_code = any(re.search(r'test|spec|__tests__', f, re.I) for f in changed_set)
    observability_gaps = []
    if has_prod_code and not has_test_code:
        observability_gaps.append('prod code changed but no test file changes observed')
    if any(re.search(r'migration|schema|sql', f, re.I) for f in changed_set) and not any(re.search(r'rollback|down', l, re.I) for _, l in all_added + all_deleted):
        observability_gaps.append('schema/data related change observed without obvious rollback hint')

    payload = {
        'summary': {
            'changed_file_count': len(changed_set),
            'added_lines': sum(v['added'] for v in file_stats.values()),
            'deleted_lines': sum(v['deleted'] for v in file_stats.values()),
            'missing_test_hint': has_prod_code and not has_test_code,
        },
        'changed_files': [
            {'file': f, 'added': file_stats[f]['added'], 'deleted': file_stats[f]['deleted']}
            for f in sorted(changed_set)
        ],
        'risk_signals': risk_signals,
        'v2_risk_categories': [
            {
                'category': category,
                'evidence_count': len(hits),
                'files': sorted({h['file'] for h in hits}),
                'evidence': hits[:5],
            }
            for category, hits in sorted(v2_category_hits.items())
        ],
        'observability_gaps': observability_gaps,
    }

    if args.format == 'json':
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(to_markdown(payload))


if __name__ == '__main__':
    main()
