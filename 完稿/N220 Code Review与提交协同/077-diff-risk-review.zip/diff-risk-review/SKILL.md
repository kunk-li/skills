---
name: diff-risk-review
description: Assess change risk from git diffs and static-analysis findings; score a diff, flag high-risk areas, and give rollback and test-focus guidance.
---
# diff-risk-review


## Routing decision table

| Situation | Action |
|---|---|
| Risk level = critical AND test_focus absent | Set `readiness: blocked`; require QA sign-off before merge |
| PR is a hotfix (urgent label) | Run `hotfix_mode`; surface critical/high risks only |
| Diff > 300 lines in a single file | Flag for architectural review; add `large_diff_warning` |
| Same high-risk pattern seen in prior 3 diffs | Emit `circuit_breaker: warn`; recommend team discussion |
| No diff context available | Set `readiness: constrained`; emit risk items as hypotheses only |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n220.diff-risk-review.v2.2"
contract_version: "n220.v2.2"
workflow_node: "N220"
```


## Role / role positioning
This skill aligns to coding & implementation -> code review and submission collaboration -> Diff风险点评.md. It delivers a workflow-aligned artifact for N220.

### Boundary
- Focus on change risk, not generic requirement analysis or runtime RCA.
- Score risk from actual diff evidence, touched areas, and consistency checks.
- Do not claim production impact has already happened unless the user provides that evidence.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_scan`: high-risk areas and fast reviewer routing.
- `deep_analysis`: cross-file consistency, history, and richer test/monitor focus.
- `hotfix_mode`: emergency change rules and rollback-first framing.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `代码规范检查单.csv`
- `开发任务拆分表.csv`
- `git diff/改动列表`

### optional enhancement inputs
- `技术方案分析.md`
- `风险检查清单.csv`
- migration files, config diffs, dependency lockfile changes
- bug history or incident notes

## Standalone rule / standalone usage
This skill must still work on one patch file, one migration diff, or one hotfix snippet.

Degradation rules:
- If history data is absent, do not fabricate bug density.
- If only a summary is available, mark line-level inferences as inferred.
- If cross-file context is missing, keep consistency checks partial and explicit.
- Preserve output schema even under limited evidence.
- Use `pending_inference` when risk scoring relies on diffstat only, without actual line-level diff context.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_review_and_submission_collaboration.diff_risk_review`
  - `workflow_node: N220`
  - `node_artifact_target: Diff风险点评.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `diff_context`
- `risk_summary`
- `risk_items[]`
- `cross_file_checks[]`
- `test_focus[]`
- `monitoring_focus[]`
- `rollback_focus[]`
- `reviewer_assignment_hint`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Score each review using `references/diff-risk-scoring.md`.
- Always identify whether a touched area matches `references/high-risk-area-policy.md`.
- Perform cross-file consistency checks when schema, DTO, API, enum, i18n, config, or dependency changes appear together.
- Distinguish `pr_context` such as normal, bugfix, hotfix, refactor, dependency, docs_only.
- Use historical bug density only when evidence exists.
- Include explicit test focus and rollback focus for high and critical items.
- Keep the artifact directly consumable by reviewers, QA, release, and monitoring stakeholders.

## Execution workflow / execution workflow
1. Parse the change scope and touched modules.
2. Apply high-risk area and context rules.
3. Score the diff and normalize severity.
4. Run cross-file consistency checks.
5. Emit targeted test, monitoring, and rollback focus.
6. Hand off the summary to PR description and reviewer routing.

## Dynamic completeness / dynamic completeness
- Tiny patch: highlight only concrete risks and skip speculative filler.
- Mixed diff: group risks by module and risk family.
- Hotfix: prioritize minimal-change compliance and rollback clarity.
- If evidence is only a diffstat, keep the review at hypothesis level.


## Example usage

**Input**: git diff modifying a payment processing endpoint and its DB migration file.

**Output** (`deep_analysis` mode, excerpt):
```yaml
risk_summary:
  overall_risk: high
  pr_context: bugfix
risk_items:
  - id: DIFR-001
    area: database_migration
    severity: high
    finding: Migration adds NOT NULL column without default — will fail on non-empty table.
    test_focus: Run migration on staging with production-like data volume.
    rollback_focus: Confirm migration is reversible; check if down() is implemented.
  - id: DIFR-002
    area: payment_logic
    severity: medium
    finding: Retry logic on payment gateway timeout does not check idempotency key.
    test_focus: Simulate gateway timeout; verify no duplicate charge occurs.
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Quality bar / quality bar
A good result should let the team know whether this diff is low, medium, high, or critical risk, why, and what must be tested or watched next.


## Auditable rules

Apply these rules in order; record outcomes in `self_check.passed_rules` and `self_check.failed_rules`.

- R01_evidence_only: score risk only from diff evidence, touched area policy, and consistency signals; never fabricate historical bug density; on_violation: reject.
- R02_high_risk_area_checked: always check whether touched files match `references/high-risk-area-policy.md`; on_violation: reject.
- R03_consistency_check_required: when schema, DTO, API, enum, i18n, config, or dependency changes appear together, run cross-file consistency check; on_violation: reject.
- R04_severity_normalized: risk severity must use the four-level scale (low/medium/high/critical) from `references/diff-risk-scoring.md`; on_violation: remap.
- R05_test_focus_for_high: every high or critical item must include explicit `test_focus` and `rollback_focus`; on_violation: reject.
- R06_no_production_claim: do not assert production impact unless the user supplies runtime evidence; on_violation: downgrade_to_hypothesis.
- R07_hotfix_rollback_first: in `hotfix_mode`, rollback feasibility must appear before test focus; on_violation: reorder.

## Algorithm

1. Parse diff scope; classify `pr_context` (normal / bugfix / hotfix / refactor / dependency / docs_only).
2. Apply high-risk area policy (R02); flag matching files immediately.
3. Score each risk item using the formula in `references/diff-risk-scoring.md` (R01, R04).
4. Run cross-file consistency checks when mixed-change signals present (R03).
5. For high/critical items, emit `test_focus[]` and `rollback_focus[]` (R05).
6. In hotfix mode, apply `references/hotfix-mode-rules.md` and reorder sections (R07).
7. Populate `downstream_handoff` for PR description and reviewer routing.
8. Run `self_check`; set `readiness: blocked` if any reject-class rule fires.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files / reference files
- `references/field-contract.md`
- `references/output-template.md`
- `references/quality-checklist.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/cross-skill-orchestration.md`
- `references/orchestration.md`
- `references/script-usage-and-limitations.md`
- `references/readiness-inheritance.md`
- `references/n220-integration-map.md`
- `references/traceability-chain.md`
- `references/high-risk-area-policy.md`
- `references/diff-risk-scoring.md`
- `references/hotfix-mode-rules.md`
- `references/template-skeleton.md`

## N220 v2 optimization addendum

Always load the shared N220 references before producing the final artifact:
- `references/n220-shared-handoff.md`
- `references/n220-produced-events.md`
- `references/n220-downstream-contract.md`
- `references/n220-readiness-and-self-check.md`
- `references/n220-orchestration-policy.md`

Then apply the diff-risk specific v2 references:
- `references/risk-taxonomy-v2.md`
- `references/risk-scoring-formula.md`
- `references/cross-file-consistency-patterns.md`
- `references/hotfix-safeguards.md`
- `references/reviewer-routing.md`
- `references/canary-and-rollback-handoff.md`

Every final output must include `n220_handoff`, `produced_event`, and `self_check_result`. This skill is the canonical source for `risk_summary`, `test_focus`, `monitoring_focus`, and `rollback_notes` in N220.



## Cross-skill integration map

| 上游 skill | 提供给 077 | 用途 |
|---|---|---|
| 076 code-review-comment-generation | 审查评论上下文 | 风险点与审查发现对齐 |

| 下游 skill | 077 输出 | 如何使用 |
|---|---|---|
| 076 | `risk_items[]`, `difr_id` | 高风险区域优先生成审查评论 |
| 078 | `risk_summary` | PR 描述的风险评估章节 |
| N240 085 smoke-test | `rollback_guidance` | 部署后烟雾测试范围 |

**工作流位置**: Diff 提交 → **077 风险评估** → 076 审查 → 078 PR描述。

## Standalone usage guide

**Minimum input:** a diff (unified diff or file list) — no upstream N220 artifacts required.

**When operating without diff-risk-review context:**
1. Infer risk areas from file names, change size, and commit message.
2. Use `inferred_risk_level` (not `confirmed`); set `confidence < 0.7`.
3. Set `readiness: constrained` and flag `pending_impact_confirmation`.

**Minimum viable output:**
```yaml
diff_risk_review:
  readiness: constrained
  confidence: 0.60
  pending_impact_confirmation: true
  risk_items:
    - difr_id: DIFR-001
      area: payment_gateway
      risk_level: high
      evidence_source: inferred_from_filename
      human_review_required: true
```
**Downstream:** DIFR-* IDs → 076 code-review-comment-generation → 078 PR description.

## Resilience and governance

**Confidence scoring**: Every `risk_item` must include a `confidence` score (0–1). Items with `confidence < 0.6` are flagged as `hypothesis_level` and must not block merges without human review.

**SLA guidance**: `critical` risk items trigger `sla_queue_hint: P0` requiring immediate reviewer action. `high` items trigger `P1`. Unacknowledged P0 items within the SLA window escalate automatically.

**Circuit breaker**: If the same high-risk area pattern fires on 3 or more consecutive diffs from the same module, emit `circuit_breaker: open` and recommend an architectural review before further merges.

**Escalation path**: When `readiness: blocked` (e.g., critical risk with no test focus confirmed), escalate to `reviewer_assignment_hint.escalation_target`.

**Human review routing**: Set `human_review_required: true` when overall risk is high or critical, or when cross-file consistency checks find unresolved schema divergence.

## N220 v2 usage scenarios

Use these scenario labels when they better describe the task than a reader-profile mode:
- `pr_review`: standard pull request review and collaboration.
- `design_review`: architecture or design-level review when line-level code is secondary.
- `onboarding_review`: review for a new or junior contributor; preserve stronger teaching context.
- `release_gate`: pre-release or hotfix gate; focus on blockers, risk, rollback, and evidence.

Scenario labels may be combined with existing mode labels. For example: `selected_mode: learning_mode + onboarding_review` or `selected_mode: senior_mode + release_gate`.
