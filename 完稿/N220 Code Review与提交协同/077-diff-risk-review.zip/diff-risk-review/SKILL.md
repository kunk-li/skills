---
name: diff-risk-review
description: generate workflow-aligned diff risk reviews from git diffs, task context, static-analysis findings, and project risk rules. use when chatgpt works in coding & implementation / code review and submission collaboration and must produce the workflow-aligned risk review artifact for n220 before pr description, review routing, test focus, or release collaboration.
---
# diff-risk-review

## Role / role positioning
This skill aligns to coding & implementation -> code review and submission collaboration -> Diff风险点评.md. It delivers a workflow-aligned artifact for N220.

### Boundary
- Focus on change risk, not generic requirement analysis or runtime RCA.
- Score risk from actual diff evidence, touched areas, and consistency checks.
- Do not claim production impact has already happened unless the user provides that evidence.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `quick_scan`: high-risk areas and fast reviewer routing.
- `deep_analysis`: cross-file consistency, history, and richer test/monitor focus.
- `hotfix_mode`: emergency change rules and rollback-first framing.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `代码规范检查单.csv`
- `开发任务拆分表.csv`
- `git diff/改动列表`

### optional enhancement inputs
- `技术方案分析.md`
- `风险检查清单.csv`
- migration files, config diffs, dependency lockfile changes
- bug history or incident notes

## Standalone rule / standalone usage
This skill must still work on one patch file, one migration diff, or one hotfix snippet.

Degradation rules:
- If history data is absent, do not fabricate bug density.
- If only a summary is available, mark line-level inferences as inferred.
- If cross-file context is missing, keep consistency checks partial and explicit.
- Preserve output schema even under limited evidence.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_review_and_submission_collaboration.diff_risk_review`
  - `workflow_node: N220`
  - `node_artifact_target: Diff风险点评.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `diff_context`
- `risk_summary`
- `risk_items[]`
- `cross_file_checks[]`
- `test_focus[]`
- `monitoring_focus[]`
- `rollback_focus[]`
- `reviewer_assignment_hint`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Score each review using `references/diff-risk-scoring.md`.
- Always identify whether a touched area matches `references/high-risk-area-policy.md`.
- Perform cross-file consistency checks when schema, DTO, API, enum, i18n, config, or dependency changes appear together.
- Distinguish `pr_context` such as normal, bugfix, hotfix, refactor, dependency, docs_only.
- Use historical bug density only when evidence exists.
- Include explicit test focus and rollback focus for high and critical items.
- Keep the artifact directly consumable by reviewers, QA, release, and monitoring stakeholders.

## Execution workflow / execution workflow
1. Parse the change scope and touched modules.
2. Apply high-risk area and context rules.
3. Score the diff and normalize severity.
4. Run cross-file consistency checks.
5. Emit targeted test, monitoring, and rollback focus.
6. Hand off the summary to PR description and reviewer routing.

## Dynamic completeness / dynamic completeness
- Tiny patch: highlight only concrete risks and skip speculative filler.
- Mixed diff: group risks by module and risk family.
- Hotfix: prioritize minimal-change compliance and rollback clarity.
- If evidence is only a diffstat, keep the review at hypothesis level.

## Quality bar / quality bar
A good result should let the team know whether this diff is low, medium, high, or critical risk, why, and what must be tested or watched next.

## Reference files / reference files
- `references/field-contract.md`
- `references/output-template.md`
- `references/quality-checklist.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/cross-skill-orchestration.md`
- `references/orchestration.md`
- `references/script-usage-and-limitations.md`
- `references/readiness-inheritance.md`
- `references/n220-integration-map.md`
- `references/traceability-chain.md`
- `references/high-risk-area-policy.md`
- `references/diff-risk-scoring.md`
- `references/hotfix-mode-rules.md`

## N220 v2 optimization addendum

Always load the shared N220 references before producing the final artifact:
- `references/n220-shared-handoff.md`
- `references/n220-produced-events.md`
- `references/n220-downstream-contract.md`
- `references/n220-readiness-and-self-check.md`
- `references/n220-orchestration-policy.md`

Then apply the diff-risk specific v2 references:
- `references/risk-taxonomy-v2.md`
- `references/risk-scoring-formula.md`
- `references/cross-file-consistency-patterns.md`
- `references/hotfix-safeguards.md`
- `references/reviewer-routing.md`
- `references/canary-and-rollback-handoff.md`

Every final output must include `n220_handoff`, `produced_event`, and `self_check_result`. This skill is the canonical source for `risk_summary`, `test_focus`, `monitoring_focus`, and `rollback_notes` in N220.

## N220 v2 usage scenarios

Use these scenario labels when they better describe the task than a reader-profile mode:
- `pr_review`: standard pull request review and collaboration.
- `design_review`: architecture or design-level review when line-level code is secondary.
- `onboarding_review`: review for a new or junior contributor; preserve stronger teaching context.
- `release_gate`: pre-release or hotfix gate; focus on blockers, risk, rollback, and evidence.

Scenario labels may be combined with existing mode labels. For example: `selected_mode: learning_mode + onboarding_review` or `selected_mode: senior_mode + release_gate`.
