---
name: pull-request-description-generation
description: generate workflow-aligned pull request descriptions from git diffs, task context, risk reviews, review notes, and validation evidence. use when chatgpt works in coding & implementation / code review and submission collaboration and must produce the workflow-aligned pr description artifact for n220 before test orchestration, release note preparation, or merge collaboration.
---
# pull-request-description-generation

## Role / role positioning
This skill aligns to coding & implementation -> code review and submission collaboration -> PR描述.md. It delivers a workflow-aligned artifact for N220.

### Boundary
- Focus on PR communication and traceability, not release execution.
- Produce reviewer-friendly and release-aware PR text from confirmed evidence.
- Do not mark unverified testing or rollback steps as already completed.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `full`: complete PR description.
- `minimal`: lean PR for small or low-risk diffs.
- `template_strict`: all required sections present and explicit.
- `bot_integration`: machine-readable structure for PR bots or templates.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `代码规范检查单.csv`
- `开发任务拆分表.csv`
- `git diff/改动列表`

### optional enhancement inputs
- `Diff风险点评.md`
- `CodeReview评论.md` (optional in standalone mode; required or strongly recommended in full N220 orchestration mode)
- testing evidence, screenshots, CI results
- branch name, ticket id, release or migration notes

## Standalone rule / standalone usage
This skill must still work from a diff summary plus ticket text.

Degradation rules:
- If testing evidence is missing, keep the section but mark it pending.
- If breaking-change evidence is weak, phrase it as a possible compatibility concern.
- If no ticket id is present, do not invent one; keep traceability blank or pending.
- Maintain section order even in minimal mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_review_and_submission_collaboration.pull_request_description_generation`
  - `workflow_node: N220`
  - `node_artifact_target: PR描述.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `summary_section`
- `related_items_section`
- `change_details_section`
- `breaking_changes_section`
- `testing_section`
- `checklist_section`
- `deployment_notes_section`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Follow `references/pr-template-contract.md` for legacy standalone GitHub-style drafts; in N220 v2 or `n220_full_chain` mode, `references/pr-description-v2-template.md` supersedes it as the authoritative S1-S8 contract.
- Auto-summarize the diff, but keep the summary behavior-focused, not file-list spam.
- Pull ticket ids, branch ids, and related items into a single traceability section when evidence exists.
- Highlight breaking changes prominently and include migration or rollback notes when available.
- Structure testing evidence clearly and separate automated from manual proof.
- Keep PR descriptions aligned with N220 upstream findings and ready for N270 release preparation.

## Execution workflow / execution workflow
1. Read the change intent and linked tasks.
2. Summarize the functional or technical behavior change.
3. Bring in diff risk, reviewer concerns, and evidence.
4. Populate the required PR sections in stable order.
5. Surface breaking changes and deployment notes clearly.
6. Hand off traceability and change summary to commit and release workflows.

## Dynamic completeness / dynamic completeness
- Minimal change: keep the mandatory sections compact.
- Medium change: add explicit risk and test details.
- High-risk change: expand breaking, rollback, and deployment notes.
- If screenshots or manual proof are absent, mark them pending instead of fabricating proof.

## Quality bar / quality bar
A good result should let a reviewer, release owner, or downstream writer understand what changed, why, how it was validated, and what needs special attention.

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/field-contract.md`
- `references/readiness-inheritance.md`
- `references/n220-integration-map.md`
- `references/traceability-chain.md`
- `references/pr-template-contract.md`
- `references/testing-evidence-guidance.md`
- `references/breaking-change-highlighting.md`

## N220 v2 optimization addendum

Always load the shared N220 references before producing the final artifact:
- `references/n220-shared-handoff.md`
- `references/n220-produced-events.md`
- `references/n220-downstream-contract.md`
- `references/n220-readiness-and-self-check.md`
- `references/n220-orchestration-policy.md`

Then apply the PR-description specific v2 references:
- `references/pr-description-v2-template.md`
- `references/ticket-association-rules.md`
- `references/diff-summary-categorization.md`
- `references/breaking-change-detection.md`
- `references/testing-evidence-policy.md`
- `references/final-markdown-template.md`

In standalone mode, `CodeReviewComments.md` is optional. In full N220 orchestration mode, missing `CodeReviewComments.md` makes readiness at most `constrained`. Every final output must include `n220_handoff`, `produced_event`, and `self_check_result`.

## N220 v2 usage scenarios

Use these scenario labels when they better describe the task than a reader-profile mode:
- `pr_review`: standard pull request review and collaboration.
- `design_review`: architecture or design-level review when line-level code is secondary.
- `onboarding_review`: review for a new or junior contributor; preserve stronger teaching context.
- `release_gate`: pre-release or hotfix gate; focus on blockers, risk, rollback, and evidence.

Scenario labels may be combined with existing mode labels. For example: `selected_mode: learning_mode + onboarding_review` or `selected_mode: senior_mode + release_gate`.
