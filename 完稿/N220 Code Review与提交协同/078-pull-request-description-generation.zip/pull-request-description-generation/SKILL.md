---
name: pull-request-description-generation
description: generate workflow-aligned pull request descriptions from git diffs, task context, risk reviews, review notes, and validation evidence. use when Claude works in coding & implementation / code review and submission collaboration and must produce the workflow-aligned PR description artifact for N220 before test orchestration, release note preparation, or merge collaboration. trigger on any request to draft a PR, write a pull request body, or produce change documentation for review.
---
# pull-request-description-generation


## Routing decision table

| Situation | Action |
|---|---|
| PR has `breaking_changes: true` | Require breaking change section; set `readiness: constrained` until documented |
| Hotfix PR | Use `release_gate_mode`; suppress non-essential sections |
| No testing evidence available | Set `evidence_confidence: low`; flag `pending_testing_evidence` |
| PR description already exists | Treat as enhancement mode; preserve existing content where valid |
| PR author has no linked ticket | Flag `pending_ticket_reference`; still generate description |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n220.pull-request-description.v2.2"
contract_version: "n220.v2.2"
workflow_node: "N220"
```


## Role / role positioning
This skill aligns to coding & implementation -> code review and submission collaboration -> PR描述.md. It delivers a workflow-aligned artifact for N220.

### Boundary
- Focus on PR communication and traceability, not release execution.
- Produce reviewer-friendly and release-aware PR text from confirmed evidence.
- Do not mark unverified testing or rollback steps as already completed.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `full`: complete PR description.
- `minimal`: lean PR for small or low-risk diffs.
- `template_strict`: all required sections present and explicit.
- `bot_integration`: machine-readable structure for PR bots or templates.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `代码规范检查单.csv`
- `开发任务拆分表.csv`
- `git diff/改动列表`

### optional enhancement inputs
- `Diff风险点评.md`
- `CodeReview评论.md` (optional in standalone mode; required or strongly recommended in full N220 orchestration mode)
- testing evidence, screenshots, CI results
- branch name, ticket id, release or migration notes

## Standalone rule / standalone usage
This skill must still work from a diff summary plus ticket text.

Degradation rules:
- If testing evidence is missing, keep the section but mark it pending.
- If breaking-change evidence is weak, phrase it as a possible compatibility concern.
- If no ticket id is present, do not invent one; keep traceability blank or pending.
- Maintain section order even in minimal mode.

## Core output contract / core output contract
Default to Markdown and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: coding_and_implementation.code_review_and_submission_collaboration.pull_request_description_generation`
  - `workflow_node: N220`
  - `node_artifact_target: PR描述.md`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `summary_section`
- `related_items_section`
- `change_details_section`
- `breaking_changes_section`
- `testing_section`
- `checklist_section`
- `deployment_notes_section`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Follow `references/pr-template-contract.md` for legacy standalone GitHub-style drafts; in N220 v2 or `n220_full_chain` mode, `references/pr-description-v2-template.md` supersedes it as the authoritative S1-S8 contract.
- Auto-summarize the diff, but keep the summary behavior-focused, not file-list spam.
- Pull ticket ids, branch ids, and related items into a single traceability section when evidence exists.
- Highlight breaking changes prominently and include migration or rollback notes when available.
- Structure testing evidence clearly and separate automated from manual proof.
- Keep PR descriptions aligned with N220 upstream findings and ready for N270 release preparation.

## Execution workflow / execution workflow
1. Read the change intent and linked tasks.
2. Summarize the functional or technical behavior change.
3. Bring in diff risk, reviewer concerns, and evidence.
4. Populate the required PR sections in stable order.
5. Surface breaking changes and deployment notes clearly.
6. Hand off traceability and change summary to commit and release workflows.

## Dynamic completeness / dynamic completeness
- Minimal change: keep the mandatory sections compact.
- Medium change: add explicit risk and test details.
- High-risk change: expand breaking, rollback, and deployment notes.
- If screenshots or manual proof are absent, mark them pending instead of fabricating proof.


## Example usage

### Scenario A — Feature PR with test evidence

**Input**: PR adding user profile avatar upload; diff: 3 files changed, +120/-8 lines; all unit tests passing.

**Output** (`feature_pr` mode):
```markdown
**Summary:**
Add avatar upload capability to user profiles. Users can now upload JPEG/PNG images up to 5MB via the profile settings page.

**Changes:**
- `ProfileService.java`: Added `uploadAvatar(userId, file)` method with file-type and size validation
- `ProfileController.java`: New `POST /api/v1/profile/avatar` endpoint
- `StorageAdapter.java`: S3 upload integration with signed URL generation

**Testing evidence:**
- Unit: `ProfileServiceTest` — 12 new tests covering validation paths ✅
- Integration: `ProfileControllerIT` — file upload/retrieve cycle tested ✅
- Manual: Avatar renders correctly in browser on Chrome/Firefox ✅

**Risk assessment:**
- Risk level: low
- Rollback: revert commit; avatar field degrades gracefully to default icon

**Checklist:**
- [x] Tests added and passing
- [x] No breaking API changes
- [x] Documentation updated (API spec v2.3)
```

> 更多场景示例（Breaking Change PR / Hotfix PR）见 `references/example-io-v2.md`。

## Quality bar / quality bar
A good result should let a reviewer, release owner, or downstream writer understand what changed, why, how it was validated, and what needs special attention.


## Auditable rules

Apply these rules in order; record outcomes in `self_check.passed_rules` and `self_check.failed_rules`.

- R01_behavior_summary: the summary section must describe behavior change, not file list; on_violation: rewrite.
- R02_traceability_section: ticket ids, branch ids, and related items must be collected into one `related_items_section`; on_violation: reject.
- R03_breaking_change_prominent: breaking changes must appear in a dedicated section with migration or rollback notes; on_violation: reject.
- R04_testing_evidence_separated: automated and manual testing evidence must be listed in distinct sub-sections; on_violation: merge_flagged.
- R05_pending_not_fabricated: absent screenshots, CI results, or test evidence must be marked `pending`, not invented; on_violation: reject.
- R06_section_order_stable: output sections must follow the canonical S1-S8 order from the v2 template; on_violation: reorder.
- R07_minimal_mode_complete: even in `minimal` mode, all mandatory sections must be present (may be compact); on_violation: expand.

## Algorithm

1. Read diff and linked tasks; identify change intent and functional behavior delta.
2. Apply R01: draft a behavior-focused summary (not a file inventory).
3. Collect ticket ids, branch names, and related items (R02).
4. Detect breaking changes and check for migration/rollback notes (R03).
5. Separate automated vs manual testing evidence; mark absent proof as pending (R04, R05).
6. Populate all S1-S8 sections in canonical order (R06); ensure minimal mode has all sections (R07).
7. Populate `downstream_handoff` with commit message seeds and release note stubs.
8. Run `self_check`; set `readiness: blocked` if any reject-class rule fires.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files / reference files
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/field-contract.md`
- `references/readiness-inheritance.md`
- `references/n220-integration-map.md`
- `references/traceability-chain.md`
- `references/pr-template-contract.md`
- `references/testing-evidence-guidance.md`
- `references/breaking-change-highlighting.md`
- `references/template-skeleton.md`

## N220 v2 optimization addendum

Always load the shared N220 references before producing the final artifact:
- `references/n220-shared-handoff.md`
- `references/n220-produced-events.md`
- `references/n220-downstream-contract.md`
- `references/n220-readiness-and-self-check.md`
- `references/n220-orchestration-policy.md`

Then apply the PR-description specific v2 references:
- `references/pr-description-v2-template.md`
- `references/ticket-association-rules.md`
- `references/diff-summary-categorization.md`
- `references/breaking-change-detection.md`
- `references/testing-evidence-policy.md`
- `references/final-markdown-template.md`

In standalone mode, `CodeReviewComments.md` is optional. In full N220 orchestration mode, missing `CodeReviewComments.md` makes readiness at most `constrained`. Every final output must include `n220_handoff`, `produced_event`, and `self_check_result`.



## Cross-skill integration map

| Signal source | Provides to 078 | How used |
|---|---|---|
| 077 diff-risk-review | `risk_items[]`, DIFR-* IDs | Populate risk_assessment section; reference DIFR IDs in PR description |
| 076 code-review-comment-generation | `blockers[]`, `suggestions[]` | Summarise open review items in testing_evidence section |
| N230 test-point-generation | `test_point_list[]` | Populate testing evidence with coverage summary |
| N250 defect-classification | `odc_type`, `defect_id` | Link defect fixes to PR description for traceability |

**Downstream consumers of 078 output:**
- Release notes generators (extract `summary` and `breaking_changes`)
- Change management systems (consume `risk_assessment.risk_level`)
- N260 quality-gate-check (consumes PR description completeness as a gate signal)


## Standalone usage guide

**Minimum input:** a diff or change description — no PR or upstream artifacts required.

**Standalone PR description path:**
1. Generate summary from diff or description; infer change type from file paths.
2. Set `evidence_confidence: low` if no test results available; flag `pending_testing_evidence`.
3. Generate all required sections (summary, changes, risk, testing, checklist); use `pending_*` for unknowns.

**Minimum viable output:**
```yaml
pr_description:
  readiness: constrained
  pending_testing_evidence: true
  evidence_confidence: low
  sections:
    summary: "Fix null pointer exception in OrderService.java:142"
    changes: "Add null guard before order.getCustomer() dereference"
    testing_evidence: pending_ci_run
    risk_assessment:
      risk_level: low
      rollback: revert commit
  checklist:
    - "[x] Code change is targeted and minimal"
    - "[ ] Tests added — pending CI run"
```

## Resilience and governance

**Confidence scoring**: When testing evidence is marked `pending`, set `evidence_confidence: low` in metadata. Downstream release owners must not treat a pending-evidence PR as fully validated.

**SLA guidance**: PRs with unresolved `breaking_changes_section` items trigger `sla_queue_hint: P1`. PRs missing required sections entirely trigger `P0` for the author to remediate before review.

**Circuit breaker**: If a release-gate scenario produces consecutive incomplete PR descriptions (missing testing or rollback sections) from the same team, emit `circuit_breaker: warn` and recommend a PR template enforcement check.

**Escalation path**: When `readiness: blocked` due to missing mandatory sections, escalate to the PR author and, if unresolved within SLA, to the team lead.

**Human review routing**: Set `human_review_required: true` for all `release_gate` scenario PRs and any PR with `breaking_changes: true`.

## N220 v2 usage scenarios

Use these scenario labels when they better describe the task than a reader-profile mode:
- `pr_review`: standard pull request review and collaboration.
- `design_review`: architecture or design-level review when line-level code is secondary.
- `onboarding_review`: review for a new or junior contributor; preserve stronger teaching context.
- `release_gate`: pre-release or hotfix gate; focus on blockers, risk, rollback, and evidence.

Scenario labels may be combined with existing mode labels. For example: `selected_mode: learning_mode + onboarding_review` or `selected_mode: senior_mode + release_gate`.