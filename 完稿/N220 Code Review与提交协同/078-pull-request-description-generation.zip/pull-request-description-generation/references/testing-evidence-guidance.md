> **V2 note**: This legacy testing guidance is preserved for backward compatibility. In N220 v2 or full-chain mode, use `references/testing-evidence-policy.md` as the authoritative testing evidence contract.

# Testing evidence guidance

Separate automated and manual evidence.
Prefer concrete items such as unit, integration, e2e, screenshots, logs, or CI results.
If evidence is missing, mark the gap explicitly instead of implying success.
