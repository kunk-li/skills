# Ticket Association Rules v2.0.0

Extract ticket references only from direct evidence.

```yaml
patterns:
  from_branch_name: "(feat|fix|refactor|perf|test|docs)/([A-Z]+-[0-9]+)-"
  from_commit_messages: "(Closes|Fixes|Resolves|Refs) ([A-Z]+-[0-9]+)"
  from_pr_title: "^\\[([A-Z]+-[0-9]+)\\]"
```

Output shape:

```yaml
auto_ticket_association:
  extracted_tickets:
    - ticket_id: string
      source: branch_name | commit_message | pr_title | user_input
      action: closes | fixes | resolves | refs | unknown
  validation:
    tickets_exist: true | false | unknown
    tickets_accessible: true | false | unknown
```

Never invent ticket ids.
