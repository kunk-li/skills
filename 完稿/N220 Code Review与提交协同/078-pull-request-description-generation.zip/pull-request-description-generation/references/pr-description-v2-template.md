# PR Description v2 Template

Use this S1-S8 template for N220 orchestration. Keep all required sections even when evidence is missing; mark missing evidence as `pending` instead of deleting the section.

```yaml
pr_description:
  sections:
    S1_summary:
      required: true
      max_length: 200
      content: string
    S2_context_and_motivation:
      required: true
      problem: string | pending
      goal: string | pending
      why_now: string | pending
    S3_changes_overview:
      required: true
      change_categorization:
        - category: new_feature | bug_fix | refactoring | performance | security | documentation | tests | infrastructure | dependency_update | breaking_change
          summary: string
    S4_breaking_changes:
      required_if_applicable: true
      items:
        - kind: api_signature_changed | removed_feature | schema_migration_required | config_key_renamed | behavior_changed | dependency_bumped_major
          description: string
          migration_instructions: string | pending
    S5_testing:
      required: true
      unit_tests: count | pending
      integration_tests: count | pending
      e2e_tests: count | pending
      manual_tests: string | pending
      ci_status: passing | failing | pending | unknown
    S6_risk_and_mitigation:
      required: true
      risk_level: low | medium | high | critical
      identified_risks:
        - risk: string
          mitigation: string | pending
          rollback_plan: string | pending
      canary_required: true | false | unknown
      feature_flag_controlled: true | false | unknown
    S7_screenshots_and_evidence:
      required_if_ui: true
      screenshots: []
      logs_evidence: []
    S8_related_tickets_and_prs:
      required: true
      closes: []
      references: []
      depends_on: []
      blocks: []
  final_markdown: string
```
