> **V2 note**: This GitHub-style template is preserved for backward compatibility. In N220 v2 or full-chain mode, `references/pr-description-v2-template.md` supersedes it as the authoritative S1-S8 PR description contract.

# PR Template Contract v2.0.0

This file supersedes the older GitHub-only PR template. In N220 orchestration, use the v2 S1-S8 product delivery template.

See `references/pr-description-v2-template.md` for the full schema.

## Required section order

1. S1 Summary
2. S2 Context and Motivation
3. S3 Changes Overview
4. S4 Breaking Changes
5. S5 Testing
6. S6 Risk and Mitigation
7. S7 Screenshots and Evidence
8. S8 Related Tickets and PRs

## Compatibility note

For standalone GitHub templates, older sections map as follows:

| Older section | v2 section |
|---|---|
| summary | S1_summary |
| related items | S8_related_tickets_and_prs |
| type | S3_changes_overview.change_categorization |
| breaking changes | S4_breaking_changes |
| change details | S3_changes_overview |
| testing | S5_testing |
| checklist | S5/S6 pending confirmations |
| deployment notes | S6_risk_and_mitigation |
