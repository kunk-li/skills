# Breaking Change Detection v2.0.0

Check for these signals:

- Public API path, method, or signature changed.
- Public class, method, endpoint, or feature removed.
- DB column dropped, renamed, or made non-null without migration path.
- Config key renamed or removed.
- Behavior changed in a way existing clients may notice.
- Dependency bumped to a major version.
- Proto or schema field removed or reused unsafely.

If breaking risk is possible but not confirmed, mark it as `possible_breaking_change` and set readiness to constrained.
