> **V2 note**: This legacy highlighting guide is preserved for backward compatibility. In N220 v2 or full-chain mode, use `references/breaking-change-detection.md` for the complete detection signals and possible-breaking state.

# Breaking change highlighting

Highlight breaking changes near the top of the PR description.
Include affected api, config, schema, migration notes, and rollback or upgrade guidance when available.
Avoid burying breaking changes deep inside the details section.
