# Final Markdown Template v2.0.0

```markdown
## Summary
<one sentence, <= 200 chars>

## Context and Motivation
**Problem:** <problem or pending>
**Goal:** <goal or pending>
**Why now:** <why now or pending>

## Changes Overview
- <category>: <summary>

## Breaking Changes
<none detected / possible / confirmed list with migration instructions>

## Testing
- Unit: <count or pending>
- Integration: <count or pending>
- E2E: <count or pending>
- Manual: <description or pending>
- CI: <status or pending>

## Risk and Mitigation
**Risk level:** <low|medium|high|critical>
- Risk: <risk>
- Mitigation: <mitigation or pending>
- Rollback: <plan or pending>

## Screenshots and Evidence
<screenshots/logs/demo links or pending>

## Related Tickets and PRs
- Closes/Fixes/Refs: <ids or pending>
- Depends on: <ids or none>
- Blocks: <ids or none>
```
