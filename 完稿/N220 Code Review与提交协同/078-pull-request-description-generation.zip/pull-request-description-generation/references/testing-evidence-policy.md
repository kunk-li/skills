# Testing Evidence Policy v2.0.0

Rules:
- Do not write "all tests pass" unless CI or user evidence says so.
- Separate automated evidence from manual evidence.
- If evidence is missing, keep S5_testing and mark fields as `pending`.
- For high-risk diffs, include edge cases and rollback validation expectations.

```yaml
testing:
  unit_tests: count | pending
  integration_tests: count | pending
  e2e_tests: count | pending
  manual_tests: string | pending
  ci_pipeline_url: string | null
  all_passing: true | false | unknown
  edge_cases_covered: []
```
