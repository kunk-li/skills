# Diff Summary Categorization v2.0.0

## File summary buckets

```yaml
auto_diff_summary:
  files_summary:
    by_category:
      production_code:
        files_changed: integer
        lines_changed: integer
      tests:
        files_changed: integer
        lines_changed: integer
      documentation:
        files_changed: integer
      configuration:
        files_changed: integer
  hotspot_modules: []
  key_files_modified: []
```

## Change categories

Allowed categories: new_feature, bug_fix, refactoring, performance, security, documentation, tests, infrastructure, dependency_update, breaking_change.

Heuristics:
- New production files plus controllers/services often indicate new_feature.
- Null checks, edge cases, error handling, or failing-test context often indicate bug_fix.
- Only tests changed indicates tests.
- Only docs changed indicates documentation.
- Public API, schema, config rename, or major dependency bump may indicate breaking_change.
