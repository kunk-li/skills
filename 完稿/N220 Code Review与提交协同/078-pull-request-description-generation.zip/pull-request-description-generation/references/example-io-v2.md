# Example IO v2

## Input

```yaml
pull_request:
  branch_name: feat/ORDER-123-create-api
  commits:
    - "feat(order): add create order API"
risk_assessment:
  source: DIFR-001
  risk_level: high
code_review_comments:
  blockers: [CR-001]
test_evidence:
  unit_tests_added: 12
  integration_tests_added: 3
```

## Output

```yaml
selected_mode: full + pr_review
readiness: constrained
pr_description:
  sections:
    S1_summary:
      content: "Implement create-order API with retry-safe order creation."
    S2_context_and_motivation:
      problem: "Clients currently cannot create orders through a stable API."
      goal: "Expose order creation while preserving retry safety."
      why_now: "Required for ORDER-123 checkout integration."
    S3_changes_overview:
      change_categorization:
        - category: new_feature
          summary: "Add create-order API and service path."
        - category: tests
          summary: "Add unit and integration coverage."
    S4_breaking_changes:
      content: "No breaking changes detected from available evidence."
      breaking_change_items: []
    S5_testing:
      test_types_added:
        unit_tests:
          count: 12
        integration_tests:
          count: 3
      test_results:
        all_passing: unknown
      edge_cases_covered:
        - "idempotent retry"
    S6_risk_and_mitigation:
      risk_level: high
      identified_risks:
        - risk: "Duplicate order creation on retry"
          source_ids: [DIFR-001, CR-001]
          mitigation: "Require idempotency key and persistence guard."
          rollback_plan: "Disable API route or rollback service change."
      canary_required: true
      feature_flag_controlled: unknown
    S7_screenshots_and_evidence:
      screenshots: []
      logs_evidence:
        before_after: pending
    S8_related_tickets_and_prs:
      closes:
        - ticket_id: ORDER-123
          action: closes
      references: []
      depends_on: []
      blocks: []
  final_markdown: |
    ## Summary
    Implement create-order API with retry-safe order creation.

    ## Context and motivation
    Problem: Clients currently cannot create orders through a stable API.
    Goal: Expose order creation while preserving retry safety.
    Why now: Required for ORDER-123 checkout integration.

auto_ticket_association:
  extracted_tickets: [ORDER-123]
author_burden_reduction:
  auto_filled_percentage: 85%
n220_handoff:
  schema_id: n220.shared_handoff
  schema_version: 2.0.0
  artifact_kind: pr_description
  readiness: constrained
  evidence: ["ORDER-123", "DIFR-001", "CR-001"]
  confidence: direct
  open_questions: ["Attach CI pipeline URL before merge."]
produced_event:
  event_type: produced.n220.pr_description.v2
  artifact_contract_id: n220.pr_description.v2
self_check_result:
  passed: false
  failed_checks: ["ci_pipeline_url_missing"]
```

## 078 扩展示例输入输出

## 078 扩展示例

### Scenario B (PR描述生成) — Breaking change PR

**Input**: PR removing deprecated `/api/v1/users/search` endpoint; diff: 2 files; DIFR-003 flags API contract change.

**Output** (`release_gate_mode` with `breaking_changes: true`):
```markdown
**Summary:**
**BREAKING CHANGE**: Remove deprecated `/api/v1/users/search` endpoint (deprecated since v2.1, removal announced in v2.8 changelog).

**Changes:**
- `UserController.java`: Removed `GET /api/v1/users/search` handler
- `UserControllerTest.java`: Removed associated tests; added 404-assertion test for legacy callers

**Breaking change details:**
| Field | Value |
|---|---|
| Endpoint removed | `GET /api/v1/users/search` |
| Replacement | `POST /api/v2/users/query` |
| Migration guide | `docs/migration/v2-to-v3.md` |
| Consumer impact | 3 internal services (identified via grep) |

**Testing evidence:**
- Regression: Verified 3 internal consumer services updated ✅
- Contract test: `/api/v2/users/query` covers all prior search params ✅

**Risk assessment:**
- Risk level: high (external consumers not yet migrated may break)
- Rollback: revert commit + redeploy; no DB migration required
- readiness: constrained — confirm external consumer migration before merge

**Checklist:**
- [x] Breaking change section completed
- [x] Migration guide linked
- [x] All known consumers identified and notified
- [ ] External consumer sign-off pending
```

### Scenario C (PR描述生成) — Hotfix PR

**Input**: Single-line fix for critical NullPointerException in payment processing; must merge in 20 min.

**Output** (`release_gate_mode`, hotfix):
```markdown
**Summary:**
**HOTFIX**: Fix NullPointerException in `PaymentService.processRefund()` causing P0 production incident INC-4821.

**Changes:**
- `PaymentService.java:142`: Added null guard for `transaction.getRefundRef()`

**Incident reference:**
- Incident: INC-4821 (P0, affecting 12% of refund transactions)
- Root cause: Null refund reference when payment provider returns empty response

**Testing evidence:**
- Unit: `PaymentServiceTest::testRefundWithNullRef` added and passing ✅
- Smoke: POST /api/v1/refunds manual test on staging ✅
- Regression scope: defer full regression — smoke only per hotfix protocol

**Risk assessment:**
- Risk level: medium (single-line change, well-contained)
- Rollback: revert commit; re-triggers incident condition
- readiness: ready — smoke passed, approver sign-off obtained
```
