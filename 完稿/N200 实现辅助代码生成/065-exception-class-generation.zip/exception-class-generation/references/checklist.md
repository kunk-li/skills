# Exception 交付检查清单 v2.4

## 基础完整性 (must-pass)

- [ ] 每个错误码或失败语义都有对应的具体异常类
- [ ] 异常继承层次合理：BusinessException / SystemException 二分
- [ ] 类名以 Exception 结尾（不是 Error / Failure）
- [ ] 异常类含至少 1 个 (String message) 构造器
- [ ] 异常类含 (String message, Throwable cause) 构造器（保留 cause 链）

## 错误码绑定 (must-pass)

- [ ] 每个异常关联 ErrorCode（通过字段或继承）
- [ ] error_code 与 enum-definition-generation 输出的 ErrorCode enum 对齐
- [ ] 不在错误码清单.csv 中的异常进 `pending[]` 等待编码分配
- [ ] 异常的 httpStatus 与 error_code 的 httpStatus 一致

## checked vs unchecked 决策 (must-pass)

- [ ] 业务异常（用户可恢复）使用 RuntimeException 子类
- [ ] 不强制 caller try/catch（避免 try/catch 污染 service 层）
- [ ] checked exception 仅用于真正需要 caller 处理的情况（非常少）
- [ ] 决策依据已写入 javadoc

## 异常信息质量 (must-pass)

- [ ] message 含具体上下文（订单 ID / 用户 ID / 操作类型）
- [ ] 不在 message 中暴露敏感信息（密码 / token / SSN）
- [ ] message 支持 i18n（使用 messageKey + args）或显式标注英文 only
- [ ] toString() 不包含 cause stack（避免日志爆炸）

## 全局处理对接 (must-pass)

- [ ] 全局 @ControllerAdvice 含本异常类的 handler
- [ ] handler 返回的 Response body 与 dto-vo-generation 的 ErrorResponse 类型对齐
- [ ] 4xx / 5xx 区分清晰；不把业务异常映射成 500

## 序列化 (recommended)

- [ ] 异常字段 (errorCode / args) 可序列化为 JSON
- [ ] cause 不直接序列化（避免暴露内部栈）
- [ ] @JsonIgnore 标记 stackTrace / suppressed

## 输出禁止项 (must-not)

- [ ] 异常类不含业务逻辑方法
- [ ] 异常类不在构造器中做 IO（DB / HTTP）
- [ ] 异常类不抛出其他异常（构造失败会很难调试）

## 跨 skill 协作 (recommended)

- [ ] 与 N190 service-draft-generation 的 thrown_types[] 一一对应
- [ ] 与 N190 controller-draft-generation 的 @ApiResponse 错误码对齐
- [ ] 与 N210 transaction-boundary-check 的 rollback_for 配置一致
