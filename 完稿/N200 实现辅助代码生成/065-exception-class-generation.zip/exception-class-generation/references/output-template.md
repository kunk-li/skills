# Output template: exception classes

Start every response with `artifact_contract`, `self_gate`, and `produced_event`.

## Required sections

0. `quality_self_score`

1. `exception_hierarchy`
2. `error_code_binding`
3. `structured_context_payload`
4. `unchecked_policy`
5. `stacktrace_policy`
6. `handler_skeleton`
7. `response_mapping_contract`
8. `metric_and_audit_notes`
9. `tech_stack_adapter`
10. `downstream_handoff`

## Java example pattern

```java
public abstract class BaseException extends RuntimeException {
    private final ErrorCode errorCode;
    private final Map<String, Object> context;
    private final String traceId;
}
```

Base layers: `ValidationException`, `BusinessException`, `AuthorizationException`, `InfrastructureException`, `ExternalServiceException`.

## Boundary rules

- Do not use `AuthException` as the primary class name; use `AuthorizationException`.
- Do not expose sensitive context values.
- Handler skeleton is a draft, not runtime wiring proof.

## Quality self-score block

Use `references/scoring-rubric.md`. Score each dimension from 0 to 2, then assign `overall_level: S | A | B | C`. Do not hide weak dimensions; list improvement notes.
