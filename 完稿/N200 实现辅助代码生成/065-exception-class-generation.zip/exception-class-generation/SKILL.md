---
name: exception-class-generation
description: generate reusable exception hierarchy drafts from error code contracts, failure semantics, validator outcomes, api response rules, and infrastructure error handling policies. use for standalone exception design or n200 implementation-assist output 异常类.java with structured context, handler skeleton, contract, and downstream handoff.
---
# exception-class-generation

## Role / 角色定位
生成统一异常层次与错误码绑定草稿。单独使用时可从错误码或失败语义建立异常体系；在 N200 内负责交付 `异常类.java`，并向 validator、DTO error response、controller advice 和监控文档提供一致错误契约。

它是 `direct_result` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: direct_result
workflow_node: N200
node_artifact_target: 异常类.java
node_artifact_role: exception hierarchy and handler skeleton code draft
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## Boundary / 边界
- 负责基础异常层次、ErrorCode 绑定、结构化 context、trace_id、stacktrace policy 和 handler skeleton。
- 负责输出 GlobalExceptionHandler / advice 的 mapping skeleton 与响应契约。
- 不负责运行时 wiring、日志平台配置或完整业务修复逻辑。
- 不通过无限派生异常类表达所有业务差异，优先用 ErrorCode 和 context 控制粒度。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `base_hierarchy_only`：仅生成基础异常层次。
- `from_errorcodes`：以错误码清单为主派生异常类型和 context。
- `failure_semantics_mode`：以失败语义和规则为主生成骨架。
- `retrofit_existing`：重构已有异常体系并归并到五层层次。
- `contract_merge_mode`：综合 error codes、validator outcomes、api response 和基础设施规则输出。

## Inputs / 输入分级
### core_required / 最小可执行输入
- `error_codes` 或 `failure_semantics` 任一项即可作为最小输入。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160

### optional_enrichment / 可选增强输入
- `api_specs` / error response format
- validator 草稿
- existing exception classes
- handler/advice 约定
- tracing/logging policy

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: exception-class-generation
  producer_node: N200
  artifact_name: 异常类.java
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.异常类
  contract_version: n200.artifact.v2
  artifact_ref: 异常类.java
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `exception_hierarchy`
- `error_code_binding`
- `structured_context_payload`
- `unchecked_policy`
- `stacktrace_policy`
- `handler_skeleton`
- `response_mapping_contract`
- `metric_and_audit_notes`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### Five-layer hierarchy
默认五层：`ValidationException`、`BusinessException`、`AuthorizationException`、`InfrastructureException`、`ExternalServiceException`。不要使用旧名 `AuthException` 作为主类名。

### Unchecked policy
默认全 extends RuntimeException，除非用户明确要求 checked API。

### ErrorCode bound
每个具体异常或失败类别必须绑定 ErrorCode；没有稳定 ErrorCode 时输出 pending_decisions。

### Structured context
异常内容优先 `errorCode + context + traceId + occurredAt + cause`，不要只堆 message。

### Stacktrace policy
业务/校验/鉴权异常可关闭或采样 stack；基础设施和外部依赖异常保留 stack。

### Handler skeleton
输出全局 handler / advice skeleton、HTTP/gRPC/GraphQL mapping，但不声称已完成运行时接线。

### Handler skeleton boundary
GlobalExceptionHandler / advice 只输出 mapping skeleton：异常类型、状态码/协议码、Problem Details 或 ErrorResponse 格式、日志级别、metric 名称和审计事件。不得声称完成可直接上线的完整运行时接线；框架注解示例必须标注为 sample skeleton。

### Sensitive data
context 中不得包含未脱敏 PII/secret。

## Execution workflow / 执行流程
1. 识别 selected_mode、error source 和 readiness。
2. 把失败语义归并到五层异常层次。
3. 建立 ErrorCode 到异常类型、状态码、日志级别、metric 的绑定。
4. 设计 structured context payload 和 stacktrace policy。
5. 输出 handler skeleton 与 DTO error response handoff。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。

## Tech stack adapter / 多语言适配层
java: RuntimeException + RestControllerAdvice/problem details; typescript: custom Error + error code union; python: custom Exception + pydantic error response; go: error wrapper + typed code.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- 五层层次完整
- AuthorizationException 命名一致
- 全 unchecked 或例外说明
- 每异常绑定 ErrorCode
- context 结构化且无敏感泄露
- 业务异常 stack 策略明确
- handler skeleton 覆盖五层
- validator/DTO/error response handoff 已写明

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: exception-class-generation` 与运行时 `producer_skill: exception-class-generation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）
