#!/usr/bin/env python3
"""Validate SQL persistence-depth and seed-cardinality evidence.

The script consumes JSON from stdin or a file path. It deliberately avoids YAML
dependencies so it can run inside minimal skill-package validation harnesses.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


ALLOWED_KINDS = {
    "aggregate_root",
    "child_entity",
    "source_lineage",
    "snapshot",
    "workflow_state",
    "baseline_seed",
    "read_model",
    "external_reference",
    "no_persistence",
}

ALLOWED_COVERAGE = {"covered", "scoped_deferred", "blocked", "uncovered"}
ALLOWED_SEED_STATUS = {
    "exact",
    "minimum_met",
    "scoped_deferred",
    "blocked",
    "missing",
    "not_applicable",
}

PDM_BASE_FIELDS = {
    "persistence_id",
    "source_refs",
    "n180_core_flow_refs",
    "domain_object",
    "persistence_kind",
    "table_refs",
    "migration_refs",
    "repository_refs",
    "mapper_or_query_refs",
    "seed_trace_refs",
    "rollback_or_irreversible_refs",
    "positive_test_handoff_refs",
    "negative_test_handoff_refs",
    "runtime_boundary_refs",
    "coverage_status",
    "gap_reason",
}

PDM_REQUIRED_REFS = {
    "aggregate_root": {
        "table_refs",
        "migration_refs",
        "repository_refs",
        "rollback_or_irreversible_refs",
        "positive_test_handoff_refs",
        "negative_test_handoff_refs",
        "runtime_boundary_refs",
    },
    "child_entity": {
        "table_refs",
        "migration_refs",
        "repository_refs",
        "rollback_or_irreversible_refs",
        "positive_test_handoff_refs",
        "negative_test_handoff_refs",
    },
    "source_lineage": {
        "table_refs",
        "migration_refs",
        "seed_trace_refs",
        "runtime_boundary_refs",
    },
    "snapshot": {
        "table_refs",
        "migration_refs",
        "rollback_or_irreversible_refs",
        "runtime_boundary_refs",
    },
    "workflow_state": {
        "table_refs",
        "migration_refs",
        "repository_refs",
        "positive_test_handoff_refs",
        "negative_test_handoff_refs",
        "runtime_boundary_refs",
    },
    "baseline_seed": {
        "table_refs",
        "migration_refs",
        "seed_trace_refs",
        "rollback_or_irreversible_refs",
        "positive_test_handoff_refs",
    },
    "read_model": {
        "table_refs",
        "migration_refs",
        "mapper_or_query_refs",
        "positive_test_handoff_refs",
        "runtime_boundary_refs",
    },
    "external_reference": {
        "table_refs",
        "migration_refs",
        "runtime_boundary_refs",
    },
    "no_persistence": {"source_refs", "gap_reason"},
}

SEED_FIELDS = {
    "seed_id",
    "source_refs",
    "domain_object",
    "target_tables",
    "expected_row_count",
    "actual_seed_refs",
    "idempotency_key_refs",
    "ordering_or_parent_refs",
    "rollback_refs",
    "verification_refs",
    "cardinality_status",
    "gap_reason",
}

SEED_SUCCESS_REQUIRED = {
    "source_refs",
    "target_tables",
    "actual_seed_refs",
    "idempotency_key_refs",
    "rollback_refs",
    "verification_refs",
}


def _present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set, dict)):
        return bool(value)
    return True


def _contract(document: dict[str, Any]) -> dict[str, Any]:
    if isinstance(document.get("artifact_contract"), dict):
        return document["artifact_contract"]
    return document


def validate(document: dict[str, Any]) -> list[str]:
    contract = _contract(document)
    errors: list[str] = []
    pdm = contract.get("persistence_depth_matrix")
    seeds = contract.get("seed_cardinality_trace")

    if not isinstance(pdm, list) or not pdm:
        errors.append("persistence_depth_matrix must be a non-empty list")
    else:
        errors.extend(_validate_persistence_rows(pdm))

    if not isinstance(seeds, list):
        errors.append("seed_cardinality_trace must be a list")
    else:
        errors.extend(_validate_seed_rows(seeds))

    baseline_rows = [
        row for row in pdm or []
        if isinstance(row, dict) and row.get("persistence_kind") == "baseline_seed"
    ]
    if baseline_rows and not seeds:
        errors.append("baseline_seed persistence rows require seed_cardinality_trace rows")

    return errors


def _validate_persistence_rows(rows: list[Any]) -> list[str]:
    errors: list[str] = []
    seen: set[str] = set()
    for idx, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            errors.append(f"persistence row {idx}: must be an object")
            continue
        missing = sorted(PDM_BASE_FIELDS - set(row))
        if missing:
            errors.append(f"persistence row {idx}: missing fields {', '.join(missing)}")
        persistence_id = row.get("persistence_id")
        if not _present(persistence_id):
            errors.append(f"persistence row {idx}: persistence_id is empty")
        elif persistence_id in seen:
            errors.append(f"persistence row {idx}: duplicate persistence_id {persistence_id}")
        else:
            seen.add(str(persistence_id))
        kind = row.get("persistence_kind")
        status = row.get("coverage_status")
        if kind not in ALLOWED_KINDS:
            errors.append(f"persistence row {idx}: invalid persistence_kind {kind!r}")
            continue
        if status not in ALLOWED_COVERAGE:
            errors.append(f"persistence row {idx}: invalid coverage_status {status!r}")
            continue
        if status == "covered":
            for field in sorted(PDM_REQUIRED_REFS[kind]):
                if not _present(row.get(field)):
                    errors.append(
                        f"persistence row {idx}: covered {kind} missing required {field}"
                    )
        elif not _present(row.get("gap_reason")):
            errors.append(f"persistence row {idx}: {status} row must explain gap_reason")
    return errors


def _validate_seed_rows(rows: list[Any]) -> list[str]:
    errors: list[str] = []
    seen: set[str] = set()
    for idx, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            errors.append(f"seed row {idx}: must be an object")
            continue
        missing = sorted(SEED_FIELDS - set(row))
        if missing:
            errors.append(f"seed row {idx}: missing fields {', '.join(missing)}")
        seed_id = row.get("seed_id")
        if not _present(seed_id):
            errors.append(f"seed row {idx}: seed_id is empty")
        elif seed_id in seen:
            errors.append(f"seed row {idx}: duplicate seed_id {seed_id}")
        else:
            seen.add(str(seed_id))
        status = row.get("cardinality_status")
        if status not in ALLOWED_SEED_STATUS:
            errors.append(f"seed row {idx}: invalid cardinality_status {status!r}")
            continue
        if status in {"exact", "minimum_met"}:
            expected = row.get("expected_row_count")
            if not isinstance(expected, int) or expected < 0:
                errors.append(
                    f"seed row {idx}: expected_row_count must be a non-negative integer"
                )
            for field in sorted(SEED_SUCCESS_REQUIRED):
                if not _present(row.get(field)):
                    errors.append(f"seed row {idx}: {status} missing required {field}")
        elif status != "not_applicable" and not _present(row.get("gap_reason")):
            errors.append(f"seed row {idx}: {status} row must explain gap_reason")
    return errors


def _load_document() -> dict[str, Any]:
    if len(sys.argv) > 1 and sys.argv[1] not in {"-", "--"}:
        return json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    return json.loads(sys.stdin.read())


def main() -> int:
    errors = validate(_load_document())
    if errors:
        print("SQL-PERSISTENCE-SEED status=fail")
        for error in errors:
            print(f"- {error}")
        return 1
    print("SQL-PERSISTENCE-SEED status=pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
