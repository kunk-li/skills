#!/usr/bin/env python3
"""Self-tests for validate_sql_persistence_seed.py."""

from __future__ import annotations

from validate_sql_persistence_seed import validate


def _valid_contract() -> dict:
    return {
        "artifact_contract": {
            "persistence_depth_matrix": [
                {
                    "persistence_id": "SQL-PDM-MENU-001",
                    "source_refs": ["n180.menu_flow"],
                    "n180_core_flow_refs": ["TASK-MENU-CRUD"],
                    "domain_object": "Menu",
                    "persistence_kind": "aggregate_root",
                    "table_refs": ["sys_menu"],
                    "migration_refs": ["V1__create_sys_menu.sql"],
                    "repository_refs": ["MenuRepository"],
                    "mapper_or_query_refs": ["selectMenuTree"],
                    "seed_trace_refs": ["V2__seed_menu.sql"],
                    "rollback_or_irreversible_refs": ["U2__delete_menu.sql"],
                    "positive_test_handoff_refs": ["N240:menu_tree_visible"],
                    "negative_test_handoff_refs": ["N240:menu_permission_denied"],
                    "runtime_boundary_refs": ["DB-MENU"],
                    "coverage_status": "covered",
                    "gap_reason": "",
                },
                {
                    "persistence_id": "SQL-PDM-SEED-001",
                    "source_refs": ["seed.menu_baseline"],
                    "n180_core_flow_refs": ["TASK-MENU-CRUD"],
                    "domain_object": "MenuPermissionBaseline",
                    "persistence_kind": "baseline_seed",
                    "table_refs": ["sys_menu", "sys_permission"],
                    "migration_refs": ["V2__seed_menu.sql"],
                    "repository_refs": [],
                    "mapper_or_query_refs": [],
                    "seed_trace_refs": ["V2__seed_menu.sql"],
                    "rollback_or_irreversible_refs": ["U2__delete_menu.sql"],
                    "positive_test_handoff_refs": ["N240:seed_menu_count"],
                    "negative_test_handoff_refs": [],
                    "runtime_boundary_refs": ["DB-MENU"],
                    "coverage_status": "covered",
                    "gap_reason": "",
                },
            ],
            "seed_cardinality_trace": [
                {
                    "seed_id": "SEED-MENU-BASELINE",
                    "source_refs": ["seed.menu_baseline"],
                    "domain_object": "MenuPermissionBaseline",
                    "target_tables": ["sys_menu", "sys_permission"],
                    "expected_row_count": 5,
                    "actual_seed_refs": ["V2__seed_menu.sql"],
                    "idempotency_key_refs": ["uk_sys_menu_code"],
                    "ordering_or_parent_refs": ["sys_menu.parent_code"],
                    "rollback_refs": ["U2__delete_menu.sql"],
                    "verification_refs": ["N240:seed_menu_count_equals_5"],
                    "cardinality_status": "exact",
                    "gap_reason": "",
                }
            ],
        }
    }


def test_valid_contract_passes() -> None:
    assert validate(_valid_contract()) == []


def test_baseline_seed_requires_seed_trace() -> None:
    doc = _valid_contract()
    doc["artifact_contract"]["persistence_depth_matrix"][1]["seed_trace_refs"] = []
    errors = validate(doc)
    assert any("missing required seed_trace_refs" in error for error in errors)


def test_successful_seed_requires_verification_refs() -> None:
    doc = _valid_contract()
    doc["artifact_contract"]["seed_cardinality_trace"][0]["verification_refs"] = []
    errors = validate(doc)
    assert any("missing required verification_refs" in error for error in errors)


def test_baseline_persistence_requires_seed_rows() -> None:
    doc = _valid_contract()
    doc["artifact_contract"]["seed_cardinality_trace"] = []
    errors = validate(doc)
    assert any("baseline_seed persistence rows require" in error for error in errors)


def main() -> int:
    test_valid_contract_passes()
    test_baseline_seed_requires_seed_trace()
    test_successful_seed_requires_verification_refs()
    test_baseline_persistence_requires_seed_rows()
    print("SQL-PERSISTENCE-SEED-SELFTEST status=pass tests=4")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
