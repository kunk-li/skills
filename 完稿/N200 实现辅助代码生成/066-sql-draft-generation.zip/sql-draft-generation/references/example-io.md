# Example inputs and outputs for sql draft generation

## Example 1: Read query with paging
Input:
- filter by eid and status
- return recent 20 rows ordered by created time

Output shape:
- explicit column list
- where clause note and paging comment

## Example 2: State transition write
Input:
- update status only when current status is ACTIVE

Output shape:
- CAS-style update predicate note
- affected-row handling comment

## Example 3: Partial schema
Input:
- only table and field hints are known

Output shape:
- assumption-marked SQL skeleton
- DBA review checklist for missing joins or indexes

## Example 4: Menu baseline seed
Input:
- core flow requires one menu root, three child menu actions, and one permission dictionary entry
- repository persistence matrix names `Menu`, `MenuAction`, and `MenuPermissionBaseline`

Output shape:
```yaml
persistence_depth_matrix:
  - persistence_id: SQL-PDM-MENU-001
    source_refs: [n180.menu_flow]
    n180_core_flow_refs: [TASK-MENU-CRUD]
    domain_object: Menu
    persistence_kind: aggregate_root
    table_refs: [sys_menu]
    migration_refs: [V20260908_01__create_sys_menu.sql]
    repository_refs: [MenuRepository]
    mapper_or_query_refs: [selectMenuTree, upsertMenu]
    seed_trace_refs: [V20260908_02__seed_menu_baseline.sql]
    rollback_or_irreversible_refs: [U20260908_02__delete_menu_baseline.sql]
    positive_test_handoff_refs: [N240:menu_tree_visible]
    negative_test_handoff_refs: [N240:menu_permission_denied]
    runtime_boundary_refs: [schema_runtime_boundary_manifest.DB-MENU]
    coverage_status: covered
    gap_reason: ""
seed_cardinality_trace:
  - seed_id: SEED-MENU-BASELINE
    source_refs: [n180.menu_flow]
    domain_object: MenuPermissionBaseline
    target_tables: [sys_menu, sys_permission]
    expected_row_count: 5
    actual_seed_refs: [V20260908_02__seed_menu_baseline.sql]
    idempotency_key_refs: [uk_sys_menu_code, uk_sys_permission_code]
    ordering_or_parent_refs: [sys_menu.parent_code]
    rollback_refs: [U20260908_02__delete_menu_baseline.sql]
    verification_refs: [N240:seed_menu_count_equals_5]
    cardinality_status: exact
    gap_reason: ""
```
