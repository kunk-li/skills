# SQL 与 Migration 交付检查清单 v2.4

## DDL 完整性 (must-pass)

- [ ] 每张表含主键定义（PRIMARY KEY）
- [ ] 主键类型明确：BIGINT auto-increment / UUID / 业务 id（外键不能用 auto-increment）
- [ ] 字段含 NOT NULL / NULL 显式声明
- [ ] 字符串字段含 VARCHAR(N) 长度（不用 TEXT 除非真的需要）
- [ ] 时间字段标 DEFAULT CURRENT_TIMESTAMP / ON UPDATE CURRENT_TIMESTAMP
- [ ] 含 created_at / updated_at 审计字段（除非显式说明不需要）
- [ ] 软删除字段 deleted_at 或 is_deleted（与项目约定一致）

## 索引设计 (must-pass)

- [ ] 外键字段含索引
- [ ] 高频查询字段含索引（基于 N200 query-optimization-recommendation 输入）
- [ ] 复合索引顺序合理（最左前缀原则）
- [ ] 索引名含 idx_ 前缀 + 表名 + 字段名（如 `idx_order_user_id_status`）
- [ ] 不创建低基数字段单独索引（如 status 单独索引意义不大）
- [ ] 唯一约束使用 UNIQUE INDEX，不用 UNIQUE constraint（命名灵活）

## 方言适配 (must-pass)

- [ ] dialect_declaration 已确定（mysql / postgresql / oracle / sqlite）
- [ ] 方言敏感语法标 dialect-specific（如 MySQL 的 `UNSIGNED`）
- [ ] 字符集 / 排序规则显式声明（如 `utf8mb4_general_ci`）
- [ ] 引擎选择明确（InnoDB / MyISAM / PostgreSQL默认）

## Migration 安全 (must-pass)

- [ ] migration 文件命名遵循 Flyway / Liquibase 约定（V1.0.1__add_order_status.sql）
- [ ] DDL 操作含 IF NOT EXISTS / IF EXISTS（幂等）
- [ ] 大表 ALTER 标 `requires_online_migration: true`（pt-osc 或 gh-ost）
- [ ] 数据迁移含 batch size 控制 + 预估时长
- [ ] 含 rollback 脚本（DOWN migration）

## DML 与查询 (recommended)

- [ ] SELECT 不用 `SELECT *`，列出具体字段
- [ ] WHERE 条件命中索引（标 `index_used: idx_xxx`）
- [ ] LIMIT 防止全表扫描（除非显式 OLAP）
- [ ] JOIN 使用显式 JOIN ... ON（不用隐式逗号）

## 业务规则验证 (recommended)

- [ ] CHECK 约束体现业务规则（如 `CHECK (amount > 0)`）
- [ ] 触发器仅用于审计 / 同步，不含业务逻辑
- [ ] 视图（VIEW）有清晰的语义边界，不滥用

## 输出禁止项 (must-not)

- [ ] 不输出 DROP TABLE 在 production migration（除非显式 cleanup）
- [ ] 不输出 TRUNCATE（破坏性 + 绕过 trigger）
- [ ] 不输出 DELETE 不含 WHERE
- [ ] 不在 production migration 中含未经测试的 stored procedure

## 跨 skill 协作 (recommended)

- [ ] 与 N190 repository-draft-generation 的 entity 字段一一对应
- [ ] 与 dto-vo-generation 的字段命名兼容（avoid impedance mismatch）
- [ ] 输出 required_indexes[] 给 query-optimization-recommendation
