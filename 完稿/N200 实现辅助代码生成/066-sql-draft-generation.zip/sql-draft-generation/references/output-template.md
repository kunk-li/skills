# Output template: SQL drafts

Start every response with `artifact_contract`, `self_gate`, and `produced_event`.

## Required sections

0. `quality_self_score`

1. `migration_framework`
2. `migration_catalog[]`
3. `dialect_compatibility`
4. `forward_sql`
5. `rollback_sql`
6. `online_ddl_strategy`
7. `index_redundancy_check`
8. `parameterization_rules`
9. `approval_requirements`
10. `schema_runtime_boundary_manifest[]`
11. `tech_stack_adapter`
12. `downstream_handoff`

## SQL header pattern

```sql
-- Migration: V{version}__{description}.sql
-- Dialect: {mysql | postgres | oracle | sql_server}
-- Readiness: {pass | provisional | constrained | blocked}
-- Evidence: {direct_contract | inferred_from_schema | heuristic_only | mixed}
-- Rollback: {safe | data_loss | irreversible}
```

## Boundary rules

- Do not output unversioned production SQL.
- Do not omit rollback or irreversible rationale.
- Do not claim DBA approval or staging validation unless provided.
- Do not let release-critical DB/schema proof disappear; emit `schema_runtime_boundary_manifest[]` for N240/N260/N270.

## Quality self-score block

Use `references/scoring-rubric.md`. Score each dimension from 0 to 2, then assign `overall_level: S | A | B | C`. Do not hide weak dimensions; list improvement notes.
