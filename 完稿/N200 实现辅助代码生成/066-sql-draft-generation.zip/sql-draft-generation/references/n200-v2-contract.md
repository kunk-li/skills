# N200 optimized local contract v2

This reference applies to all N200 implementation-assist skills.

## Identity policy

Use stable skill names, such as `dto-vo-generation`, as content identity. Archive positions, zip filename prefixes, and UI ordering are distribution-time hints only. Do not require numeric IDs in `SKILL.md`, `artifact_contract`, cross-skill checks, or collaboration rules.

## Recommended local order

1. `enum-definition-generation`
2. `exception-class-generation`
3. `dto-vo-generation`
4. `validator-code-generation`
5. `sql-draft-generation`
6. `query-optimization-recommendation`

This order is preferred, not a hard dependency chain. Each skill must remain independently usable with a minimal input and must expose assumptions when upstream context is missing.

## Node-level rewrite fuse

`query-optimization-recommendation` may propose rewrites back to `sql-draft-generation`, but the local loop must be capped:

```yaml
n200_rewrite_fuse:
  sql_query_rewrite_loop:
    max_rewrite_iteration: 2
    stop_when:
      - no_new_critical_issue
      - rewrite_repeats_previous_advice
      - dba_or_human_review_required
    escalation_artifact: pending_decisions[]
```

## Required artifact contract block

Every N200 skill output must include this block before the skill-specific result:

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: "<skill-name>"
  producer_node: N200
  artifact_name: "<node artifact>"
  artifact_type: code_draft | analysis_report | migration_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  schema_runtime_boundary_manifest: []   # 066: release-critical DB/schema proof handoff to N240/N260/N270
  downstream_consumers: [N210, N330]
```

## Required self gate block

```yaml
self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []
```

## Required produced event block

```yaml
produced_event:
  event_type: produced.N200.<artifact_slug>
  contract_version: n200.artifact.v2
  artifact_ref: "<artifact_name>"
  emitted_for: [N210, N330, N390]
```

## Cross-skill consistency checks

At node aggregation time, check:

- enum codes used by DTO fields exist in enum catalog.
- validator allowed values match enum catalog and do not duplicate enum i18n keys.
- validation error codes map to exception/error response contracts.
- DTO nullability and validator annotations agree.
- SQL columns and DTO storage-alignment notes do not silently diverge.
- query optimization rewrites are capped by `max_rewrite_iteration`.
- i18n namespaces are isolated: `enum.*`, `validation.*`, `error.*`.


## Cross-skill check execution authority

The cross-skill checks above are executed after individual skill artifacts are produced, at N200 node aggregation time. The authorized executor is the N200 node-level aggregator, typically implemented by N370 platform routing or N380 platform gate.

This delegation does not violate the skill-internal source-of-truth policy: each skill remains independently usable, and the aggregator only coordinates already produced artifacts. The aggregator may record mismatches in `self_gate.drift_watchlist[]`, gate artifacts, or node-level handoff notes, but it must not silently overwrite a skill artifact.

## Readiness inheritance

- Do not upgrade a constrained or blocked upstream input to pass.
- If only one core input exists, mark output `provisional` unless the user asks for a final draft and assumptions are explicit.
- If an output is based on heuristics rather than evidence, use `evidence_profile: heuristic_only` and list `pending_validations[]`.

## Workflow anchors required in SKILL.md body

Every N200 skill must state these anchors in the body, not frontmatter:

```yaml
function_bias: direct_result | analysis_with_direct_handoff
workflow_node: N200
node_artifact_target: "<node artifact>"
composition_policy: standalone_first_composable_stronger
```

## Required quality self-score block

Every result must include a `quality_self_score` block using `references/scoring-rubric.md`:

```yaml
quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: 0|1|2
    contract_completeness: 0|1|2
    uncertainty_handling: 0|1|2
    downstream_handoff: 0|1|2
  overall_level: S | A | B | C
  improvement_notes: []
```
