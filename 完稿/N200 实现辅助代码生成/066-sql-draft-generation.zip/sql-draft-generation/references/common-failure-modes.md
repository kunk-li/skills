# Common failure modes for sql draft generation

## F1. Use SELECT * by default
Symptom: drafts expose all columns and ignore field-level intent.
Fix: select only the required columns.

## F2. Hide index assumptions
Symptom: where clauses appear without any note on index usage or performance.
Fix: cite the intended index or candidate index explicitly.

## F3. Forget dialect differences
Symptom: syntax is written as if all databases behave the same.
Fix: note dialect-specific upsert, pagination, or locking semantics.

## F4. Generate unsafe writes
Symptom: update or delete statements miss precise predicates.
Fix: keep write scopes explicit and defensive.

## F5. Overstate readiness
Symptom: draft language implies the SQL was benchmarked or production-approved.
Fix: keep it clearly positioned as a reviewable draft.

## F6. Collapse persistence breadth
Symptom: draft DDL covers one compact local table but drops source-lineage, child rows, workflow state, snapshots, read models, or external references.
Fix: emit `persistence_depth_matrix[]`; `covered` requires table, migration, repository or mapper/query, rollback or irreversible, test handoff, and runtime-boundary refs required by the selected object kind.

## F7. Hide seed cardinality
Symptom: menu/config/dictionary/tenant baseline rows are mentioned, but no expected count, seed script, idempotency key, parent ordering, rollback, or verification evidence is visible.
Fix: emit `seed_cardinality_trace[]`; only use `exact` or `minimum_met` when count evidence and verification refs are present.
