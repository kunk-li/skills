# Orchestration for sql draft generation

## Upstream inputs
- Table design and column semantics
- Index strategy and query goals
- Validation and state-transition requirements
- API or report output fields
- N190 repository `persistence_depth_matrix[]` when available
- N180 core-flow domain objects, source-lineage requirements, and baseline seed requirements

## Downstream consumers
- Optimization analysis consumes these statements, indexes, and bottlenecks.
- DTO design may need returned column alignment.
- Service or repository code may embed or call these statements later.
- Test and release stages consume `persistence_depth_matrix[]`, `seed_cardinality_trace[]`, and `schema_runtime_boundary_manifest[]` to decide what must be proven in production-equivalent runtime.

## Collaboration details
- Load [n200-collaboration-matrix.md](n200-collaboration-matrix.md) when coordinating with dto, enum, validator, exception, or optimization skills.
- Load [n200-java-conventions.md](n200-java-conventions.md) only when SQL is being wrapped into Java repository or mapper code.
- When repository or N180 inputs expose source-lineage, aggregate child, workflow state, baseline seed, snapshot, read model, or external reference obligations, reconcile them into `persistence_depth_matrix[]` before final readiness.
- When baseline/config/menu/dictionary/tenant seed is required, emit `seed_cardinality_trace[]` even if the seed is deferred; missing count evidence must lower readiness or enter `self_gate.pending_decisions`.
