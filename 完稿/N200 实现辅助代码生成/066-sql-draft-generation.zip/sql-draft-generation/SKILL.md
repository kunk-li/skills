---
name: sql-draft-generation
description: generate reusable sql and migration drafts from table schemas, schema diffs, index requirements, dialect constraints, business rules, enum values, and query changes. use standalone for ddl or migration work, or for n200 output sql草稿.sql with rollback, online ddl, contract, and downstream handoff.
---
# sql-draft-generation

## Role / 角色定位
生成 SQL / migration 草稿。单独使用时可从表结构、schema diff 或 SQL 片段生成 DDL/DML；在 N200 内负责交付 `SQL草稿.sql`，并为发布、静态检查、文档与查询优化提供可追溯 migration contract。

它是 `direct_result` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: direct_result
workflow_node: N200
node_artifact_target: SQL草稿.sql
node_artifact_role: versioned sql and migration draft
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## Boundary / 边界
- 负责 DDL/DML 草稿、migration 版本化、rollback、方言兼容、online DDL、索引冗余和参数化规则。
- 负责 enum 值到 CHECK/ENUM constraint 的候选映射。
- 不替代 DBA 最终审批，不声称已在生产压测或 staging 验证。
- 不脱离 schema contract 随意设计表结构。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `schema_first`：从 table schema 生成 SQL。
- `diff_based`：从新旧 schema diff 生成 migration。
- `online_only`：大表改动或锁表风险专项。
- `prod_approval_flow`：输出 DBA/staging/approval 需要的信息。
- `query_change_mode`：围绕查询改写和索引调整输出 SQL 草稿。

## Inputs / 输入分级
### core_required / 最小可执行输入
- `tables`、`schema_diff`、`migration_intent` 或 `sql_fragment` 任一项即可作为最小输入。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160

### optional_enrichment / 可选增强输入
- `indexes`
- `stack_declaration` / target dialect
- `existing_schema`
- enum catalog
- DTO storage alignment notes
- query patterns / slow query samples
- release window and rollback requirements

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: sql-draft-generation
  producer_node: N200
  artifact_name: SQL草稿.sql
  artifact_type: migration_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.SQL草稿
  contract_version: n200.artifact.v2
  artifact_ref: SQL草稿.sql
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `migration_framework`
- `migration_catalog[]`
- `dialect_compatibility`
- `forward_sql`
- `rollback_sql`
- `online_ddl_strategy`
- `index_redundancy_check`
- `parameterization_rules`
- `approval_requirements`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### Versioned migration
必须使用 Flyway/Liquibase/Goose/Alembic/TypeORM 或受控版本化脚本；不要输出不可追溯裸 SQL。

### Rollback required
每个 migration 都要给 rollback 或明确标注 irreversible，并给 backup/dual-write/data-preservation 策略。

### Configurable large table threshold
大表阈值不得硬编码为唯一标准；默认建议 `large_table_threshold` 可配置，若未知则标为 pending_decisions。

### Online DDL
大表或锁表风险必须给 online/concurrent/batch 策略和锁影响。

### Dialect compatibility
显式标注目标方言、版本要求、不可移植语法和替代方案。

### Index redundancy
新增索引必须检查重复、前缀冗余和覆盖索引机会。

### Enum to CHECK contract
当收到 enum catalog 或 enum-definition-generation 输出时，必须把稳定 `code` 值集转成 CHECK/ENUM constraint 候选，并写明数据库方言差异、兼容迁移策略和 drift 风险。若 enum 值集缺失，只能输出 pending check placeholder，不得臆造枚举值。

### Injection defense
动态 SQL 必须参数化或白名单化，不输出字符串拼接示例。

### Approval requirements
生产迁移必须暴露 DBA、staging 验证和发布窗口审批状态。

## Execution workflow / 执行流程
1. 识别 schema source、目标方言、migration tool 和 readiness。
2. 抽取 schema diff、索引需求、enum constraints 和 DTO storage alignment。
3. 生成 forward_sql、rollback_sql、执行顺序、pre/post checks。
4. 评估 online DDL、锁影响、注入风险和审批要求。
5. 把 query-optimization rewrite 作为候选输入，受 max_rewrite_iteration 控制。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。

## Tech stack adapter / 多语言适配层
java: flyway/liquibase; go: goose; python: alembic; node: typeorm/prisma migrations; postgres/mysql/oracle/sql server dialect notes.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- migration 工具已声明
- rollback 或 irreversible 说明齐全
- data loss 有保护方案
- 大表阈值可配置
- 方言和版本已标注
- 索引冗余已检查
- 无动态 SQL 拼接
- DBA/staging/approval 状态明确

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: sql-draft-generation` 与运行时 `producer_skill: sql-draft-generation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）
