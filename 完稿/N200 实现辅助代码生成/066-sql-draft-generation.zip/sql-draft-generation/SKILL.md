---
name: sql-draft-generation
description: Generate SQL DDL and migration drafts from schemas and diffs — ALTER TABLE with rollback, index strategy, datatype mapping, online DDL safety, flyway/liquibase files.
---
# sql-draft-generation

## Role / 角色定位
生成 SQL / migration 草稿。单独使用时可从表结构、schema diff 或 SQL 片段生成 DDL/DML；在 N200 内负责交付 `SQL草稿.sql`，并为发布、静态检查、文档与查询优化提供可追溯 migration contract。

它是 `direct_result` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: direct_result
workflow_node: N200
node_artifact_target: SQL草稿.sql
node_artifact_role: versioned sql and migration draft
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## 使用场景 / When to use

**直接触发（standalone）：**
- 提供实体类或字段列表，要求生成建表 DDL
- 需要 ALTER TABLE 加列/改类型并附带回滚脚本
- 要求设计索引方案（复合索引、覆盖索引）
- 需要 Flyway/Liquibase 格式的迁移文件

**工作流触发（N200 节点）：**
- `技术方案分析.md` 或 `接口设计草案.yaml` 完成后，进入数据层实现阶段
- `dto-vo-generation` 输出后，需要对应的表结构落地

**不触发（边界外）：**
- 查询优化或 EXPLAIN 分析 → 使用 `query-optimization-recommendation`
- ORM 层 Repository 方法生成 → 使用 `repository-draft-generation`

## Boundary / 边界
- 负责 DDL/DML 草稿、migration 版本化、rollback、方言兼容、online DDL、索引冗余和参数化规则。
- 负责 enum 值到 CHECK/ENUM constraint 的候选映射。
- 不替代 DBA 最终审批，不声称已在生产压测或 staging 验证。
- 不脱离 schema contract 随意设计表结构。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `schema_first`：从 table schema 生成 SQL。
- `diff_based`：从新旧 schema diff 生成 migration。
- `online_only`：大表改动或锁表风险专项。
- `prod_approval_flow`：输出 DBA/staging/approval 需要的信息。
- `query_change_mode`：围绕查询改写和索引调整输出 SQL 草稿。


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 数据模型 + 索引需求 + dialect + migration 工具 全部齐备 | 完整 DDL + index + migration 脚本 + rollback |
| `provisional` | 数据模型齐备但 dialect 未确定 | 输出 dialect-agnostic DDL，dialect-specific 部分进 pending |
| `constrained` | 仅有字段名和类型，缺业务约束（如金额非负） | 输出基础 DDL，CHECK 约束进 inferred[] |
| `blocked` | 仅有"需要存储一些数据"，无字段定义 | 输出 `request_for_inputs[]` |

**特别提示**：
- 大表 ALTER 但缺 online migration 工具确认 → `provisional`
- 缺索引使用频率信息 → `constrained`（无法做索引建议）
- migration tool（Flyway/Liquibase）未确认 → `provisional`

## Inputs / 输入分级
### core_required / 最小可执行输入
- `tables`、`schema_diff`、`migration_intent` 或 `sql_fragment` 任一项即可作为最小输入。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160
- `审计留痕方案.md` from n170 — **审计字段驱动 DDL**：当提供此文件时，必须将其中声明的审计字段（如 `created_at`, `updated_at`, `created_by`, `deleted_at`, `operation_type` 等）自动纳入 DDL 的 `forward_sql`，并在 `audit_field_mapping[]` 中记录每个字段的来源规则。若未提供此文件，设置 `audit_field_mapping: unavailable` 并在 `pending_decisions[]` 中提示。

### optional_enrichment / 可选增强输入
- `indexes`
- `stack_declaration` / target dialect
- `existing_schema`
- enum catalog
- DTO storage alignment notes
- query patterns / slow query samples
- release window and rollback requirements

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: sql-draft-generation
  producer_node: N200
  artifact_name: SQL草稿.sql
  artifact_type: migration_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.SQL草稿
  contract_version: n200.artifact.v2
  artifact_ref: SQL草稿.sql
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `migration_framework`
- `migration_catalog[]`
- `dialect_compatibility`
- `forward_sql`
- `rollback_sql`
- `online_ddl_strategy`
- `index_redundancy_check`
- `parameterization_rules`
- `approval_requirements`
- `audit_field_mapping[]`  — 每条来自 `审计留痕方案.md` 的审计字段映射：`{field_name, source_rule, column_type, nullable, default_value, applies_to_tables[]}`；若无来源文件则设为 `unavailable`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### Versioned migration
必须使用 Flyway/Liquibase/Goose/Alembic/TypeORM 或受控版本化脚本；不要输出不可追溯裸 SQL。

### Rollback required
每个 migration 都要给 rollback 或明确标注 irreversible，并给 backup/dual-write/data-preservation 策略。

### Configurable large table threshold
大表阈值不得硬编码为唯一标准；默认建议 `large_table_threshold` 可配置，若未知则标为 pending_decisions。

### Online DDL
大表或锁表风险必须给 online/concurrent/batch 策略和锁影响。

### Dialect compatibility
显式标注目标方言、版本要求、不可移植语法和替代方案。

### Index redundancy
新增索引必须检查重复、前缀冗余和覆盖索引机会。

### Enum to CHECK contract
当收到 enum catalog 或 enum-definition-generation 输出时，必须把稳定 `code` 值集转成 CHECK/ENUM constraint 候选，并写明数据库方言差异、兼容迁移策略和 drift 风险。若 enum 值集缺失，只能输出 pending check placeholder，不得臆造枚举值。

### Injection defense
动态 SQL 必须参数化或白名单化，不输出字符串拼接示例。

### Approval requirements
生产迁移必须暴露 DBA、staging 验证和发布窗口审批状态。

## Execution workflow / 执行流程
1. 识别 schema source、目标方言、migration tool 和 readiness。
2. 抽取 schema diff、索引需求、enum constraints 和 DTO storage alignment。
3. 生成 forward_sql、rollback_sql、执行顺序、pre/post checks。
4. 评估 online DDL、锁影响、注入风险和审批要求。
5. 把 query-optimization rewrite 作为候选输入，受 max_rewrite_iteration 控制。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。

## Tech stack adapter / 多语言适配层
java: flyway/liquibase; go: goose; python: alembic; node: typeorm/prisma migrations; postgres/mysql/oracle/sql server dialect notes.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Machine-readable self_check rules

- `R01_artifact_contract_first`: 每次输出必须以 `artifact_contract` YAML 块开头; `on_violation: reject`
- `R02_readiness_set`: `readiness` 必须是 `pass | provisional | constrained | blocked` 之一; `on_violation: reject`
- `R03_migration_framework_declared`: 必须声明 migration 工具（Flyway/Liquibase/Goose/Alembic/TypeORM）; `on_violation: reject`
- `R04_rollback_or_irreversible`: 每个 migration 必须有 `rollback_sql` 或 `irreversible: true` 声明; `on_violation: reject`
- `R05_large_table_threshold_configurable`: 大表阈值不得硬编码；必须声明为可配置或 `pending_decisions[]`; `on_violation: warn`
- `R06_online_ddl_on_large_table`: 超阈值表的 ALTER 必须给 online/concurrent 策略; `on_violation: warn`
- `R07_no_dynamic_sql_concat`: 不得输出字符串拼接 SQL 示例；动态 SQL 必须参数化; `on_violation: reject`
- `R08_index_redundancy_checked`: 新增索引必须检查重复/前缀冗余; `on_violation: warn`
- `R09_audit_field_mapping_declared`: 提供 `审计留痕方案.md` 时必须输出 `audit_field_mapping[]`; `on_violation: warn`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff`; `on_violation: reject`

## Cross-skill drift enforcement

N200 节点内多 skill 组合时，以下漂移必须在 `self_gate` 阶段拦截（而非静默通过）：

| 漂移类型 | 检测点 | 严重度 |
|---|---|---|
| Enum code 不一致 | `enum-definition-generation` 输出 vs DTO 字段 enum 值 | high |
| ErrorCode 孤儿 | `exception-class-generation` 输出的 ErrorCode 未在 DTO error response 中映射 | medium |
| Nullable 不一致 | `validator-code-generation` `@NonNull` vs `dto-vo-generation` `null_handling_policy` | high |
| SQL column 类型漂移 | `sql-draft-generation` DDL 列类型 vs DTO 字段 Java 类型 | medium |
| Validator-DTO 解耦失败 | validator 直接引用 DTO 内部字段而非通过接口 | low |

发现漂移时：优先写入 `drift_watchlist[]`；blocking 漂移（high 及以上）必须同时进入 `self_gate.failed_rules[]`，将 `self_gate.status` 设为 `block`。

## Common failure modes

1. **裸 SQL 无版本** — 输出未包装在 Flyway/Liquibase migration 文件中的裸 DDL，无法追溯执行历史和回滚。修复：`versioned migration` 规则在所有 DDL 输出前检查 migration framework 是否已声明；未声明时设 `readiness: constrained`。
2. **大表无 Online DDL 策略** — 在大表上生成 `ALTER TABLE ADD COLUMN` 而不评估锁影响，可能导致生产长时间锁表。修复：超过配置阈值的表必须触发 `online_ddl_strategy`；无法确定行数时标 `pending_validations[]` 并要求 DBA 确认。
3. **Rollback 缺失** — migration 只有 `forward_sql`，没有 `rollback_sql` 或 `irreversible` 声明，回滚时只能手工推测。修复：每个 migration 必须输出 rollback_sql 或明确标 `irreversible: true` 并给出数据保护策略（backup/dual-write）；缺失时自检标 `severity: high`。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- migration 工具已声明
- rollback 或 irreversible 说明齐全
- data loss 有保护方案
- 大表阈值可配置
- 方言和版本已标注
- 索引冗余已检查
- 无动态 SQL 拼接
- DBA/staging/approval 状态明确

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: sql-draft-generation` 与运行时 `producer_skill: sql-draft-generation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/sql-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/sql-self-check.yaml`: R01-R10 机读门禁规则
- `references/sql-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）
