# Output template: validator code

Start every response with `artifact_contract`, `self_gate`, and `produced_event`.

## Required sections

0. `quality_self_score`

1. `standard_validator_bundle`
2. `business_specific_validators[]`
3. `rule_source_mapping[]`
4. `cross_field_constraints[]`
5. `validation_groups`
6. `i18n_message_keys[]`
7. `error_code_mapping[]`
8. `test_skeleton[]`
9. `performance_hints`
10. `tech_stack_adapter`
11. `downstream_handoff`

## Java custom annotation pattern

```java
@Documented
@Constraint(validatedBy = ValidXValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidX {
    String message() default "{validation.x.invalid}";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
```

## Boundary rules

- Validators must have no side effects.
- DB-backed validators must state performance and index assumptions.
- Every custom validator must include test skeletons.

## Quality self-score block

Use `references/scoring-rubric.md`. Score each dimension from 0 to 2, then assign `overall_level: S | A | B | C`. Do not hide weak dimensions; list improvement notes.
