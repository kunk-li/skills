# Validator 交付检查清单 v2.4

## Bean Validation 注解 (must-pass)

- [ ] 每个 Request DTO 含 `@Valid` 或 `@Validated` 触发点
- [ ] 必填字段标 @NotNull / @NotBlank / @NotEmpty（按类型选择）
- [ ] 字符串长度标 @Size(min, max)
- [ ] 数值范围标 @Min / @Max / @Range / @Positive / @Negative
- [ ] 邮箱用 @Email；URL 用 @URL；正则用 @Pattern
- [ ] 嵌套对象标 @Valid 触发深度校验
- [ ] 集合元素标 @Valid 配合 @Size

## 自定义校验器 (must-pass when applicable)

- [ ] 跨字段校验（如"开始时间 < 结束时间"）使用类级 @ConstraintValidator
- [ ] 涉及 DB 查询的校验（如"用户名唯一"）使用自定义 validator + ApplicationContext
- [ ] 业务规则校验通过 rule_id 关联 RULE-XXX
- [ ] 自定义 annotation 含 message + groups + payload 字段

## 错误信息 (must-pass)

- [ ] message 使用 i18n key（{order.amount.positive}）
- [ ] messages.properties 含对应 key 的翻译（至少 zh_CN + en_US）
- [ ] message 不暴露内部字段名（不友好）
- [ ] 默认 message 是开发可用，生产替换为 i18n

## 校验时机 (must-pass)

- [ ] controller 层 @Valid 配合 BindingResult 处理
- [ ] BindingResult.hasErrors() 后返回 400 而非继续执行
- [ ] 全局 @ExceptionHandler MethodArgumentNotValidException 统一返回格式
- [ ] service 层只做业务规则校验，不重复字段校验

## 校验组 (recommended)

- [ ] 区分 Create / Update / Delete 校验组（@Validated(Create.class)）
- [ ] update 时不强制要求所有字段（仅校验提供的字段）
- [ ] PATCH 半量更新有专门组

## 测试覆盖 (recommended)

- [ ] 每个自定义 validator 含单元测试
- [ ] 边界值测试（min - 1, min, max, max + 1）
- [ ] null / empty / whitespace 测试
- [ ] i18n message 测试

## 性能与缓存 (recommended)

- [ ] DB 查询型 validator 不在每次调用都做查询（用 cache 或 batch）
- [ ] 复杂正则预编译为 static Pattern
- [ ] 跨字段 validator 不做大数据 IO

## 输出禁止项 (must-not)

- [ ] validator 不修改入参（应只读）
- [ ] validator 不抛业务异常（应返回 false 让框架处理）
- [ ] 不在 validator 中做权限检查（那是 security filter 的职责）
- [ ] 不重复 controller / service 的校验逻辑

## 跨 skill 协作 (recommended)

- [ ] 与 dto-vo-generation 的字段约束一一映射
- [ ] 与 N070 业务规则清单.csv 通过 rule_id 关联
- [ ] 与 N210 code-standard-check 的 NAMING / VALIDATION 规则对齐
