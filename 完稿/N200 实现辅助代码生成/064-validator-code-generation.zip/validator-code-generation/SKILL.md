---
name: validator-code-generation
description: generate reusable validation annotations, validators, rule traceability maps, cross-field checks, i18n messages, and test skeletons from api contracts, dto fields, business rules, enum values, and error semantics. use standalone or for n200 output 校验器代码.java with readiness and downstream handoff.
---
# validator-code-generation

## Role / 角色定位
生成参数校验和业务校验草稿。单独使用时可从字段清单、OpenAPI 或规则表生成 validator；在 N200 内负责交付 `校验器代码.java`，并把 DTO 字段、enum 值、exception/error code 与测试用例串起来。

它是 `direct_result` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: direct_result
workflow_node: N200
node_artifact_target: 校验器代码.java
node_artifact_role: validation annotation and validator code draft
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## Boundary / 边界
- 负责标准 validator、业务规则派生 validator、跨字段 class-level annotation、i18n message key、validation groups、test skeleton。
- 负责 rule-to-validator traceability 和 validator-to-error-code mapping。
- 不负责完整 Controller/Service 实现，也不替代数据库约束。
- 复杂业务判断可输出 validator skeleton 和调用位置，不要把有副作用逻辑塞进 validator。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `standard_library_only`：只用标准库校验。
- `from_rules`：从业务规则批量派生 validator。
- `from_dto_fields`：从 DTO 字段、nullability、enum 和嵌套对象生成注解。
- `i18n_add_locale`：为现有 validators 补 message key 和 locale。
- `retrofit`：为老代码补校验草稿。

## Inputs / 输入分级
### core_required / 最小可执行输入
- `business_rules`、`dto_fields`、`openapi_schema` 或 `field_constraints` 任一项即可作为最小输入。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160

### optional_enrichment / 可选增强输入
- `DTO_VO草稿.zip`
- enum catalog
- error code / exception contract
- i18n locale list
- existing validator library
- DB index assumptions for DB-backed validation

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: validator-code-generation
  producer_node: N200
  artifact_name: 校验器代码.java
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.校验器代码
  contract_version: n200.artifact.v2
  artifact_ref: 校验器代码.java
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `standard_validator_bundle`
- `business_specific_validators[]`
- `rule_source_mapping[]`
- `cross_field_constraints[]`
- `validation_groups`
- `i18n_message_keys[]`
- `error_code_mapping[]`
- `test_skeleton[]`
- `performance_hints`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### Standard first
能用标准 Bean Validation / framework validator 时优先用标准库。

### Rule traceability
业务规则必须映射到 validator、字段、message key 和 error code。

### Cross-field constraints
跨字段约束使用 class-level / object-level validator；不要退化成 controller 内散乱 if。

### No side effects
validator 不修改数据、不发事件、不做写操作。

### DB-backed validation
涉及 DB 查询时必须写索引、缓存和性能风险；不要把 DB validator 当免费。

### i18n namespace
validation message key 使用 `validation.<domain>.<field>.<violation>`，避免与 enum/error 冲突。

### Tests required
每个 custom validator 输出至少一个正例、一个反例和边界例 test skeleton。

### Composable reuse
相同校验组合出现 3 次以上，建议提取 composable annotation。

## Execution workflow / 执行流程
1. 识别输入来源、字段级约束和跨字段规则。
2. 先映射标准 validators，再生成业务特定 validators。
3. 建立 rule_source_mapping、error_code_mapping 和 i18n keys。
4. 输出 cross_field constraints、validation groups 和 test_skeleton。
5. 标出 DTO/DB/enum/exception drift 和 pending decisions。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。

## Tech stack adapter / 多语言适配层
java: jakarta bean validation/jsr-380; typescript: zod/yup/class-validator; python: pydantic validators; go: validator tags + custom functions.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- 标准优先
- 业务规则已派生
- 跨字段在类级/object 级
- message key 已 namespace 隔离
- 无副作用
- custom validator 有测试骨架
- DB validator 写明性能风险
- validator 与 DTO/enum/exception 一致

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: validator-code-generation` 与运行时 `producer_skill: validator-code-generation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）
