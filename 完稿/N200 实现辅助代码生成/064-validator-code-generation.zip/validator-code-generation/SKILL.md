---
name: validator-code-generation
description: Generate Bean Validation annotations, custom ConstraintValidators, and cross-field class-level validators from business rules — rule traceability, error-code mapping, i18n messages, test skeletons.
---
# validator-code-generation

## Role / 角色定位
生成参数校验和业务校验草稿。单独使用时可从字段清单、OpenAPI 或规则表生成 validator；在 N200 内负责交付 `校验器代码.zip`，并把 DTO 字段、enum 值、exception/error code 与测试用例串起来。

它是 `direct_result` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: direct_result
workflow_node: N200
node_artifact_target: 校验器代码.zip
node_artifact_role: validation annotation and validator code draft
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## 使用场景 / When to use

**直接触发（standalone）：**
- 提供 DTO 字段列表，要求生成 Bean Validation 注解
- 提供业务规则文档，要求转化为 ConstraintValidator 实现
- 需要跨字段校验（如结束时间必须晚于开始时间）
- 需要 i18n 国际化 message key
- 需要为老代码补全缺失的校验逻辑

**工作流触发（N200 节点）：**
- `dto-vo-generation` 输出后，为 DTO 补充校验层
- `exception-class-generation` 输出后，将 validator 错误映射到错误码

**不触发（边界外）：**
- 数据库约束设计 → 使用 `sql-draft-generation`
- Controller 路由逻辑 → 使用 `controller-draft-generation`

## Boundary / 边界
- 负责标准 validator、业务规则派生 validator、跨字段 class-level annotation、i18n message key、validation groups、test skeleton。
- 负责 rule-to-validator traceability 和 validator-to-error-code mapping。
- 不负责完整 Controller/Service 实现，也不替代数据库约束。
- 复杂业务判断可输出 validator skeleton 和调用位置，不要把有副作用逻辑塞进 validator。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `standard_library_only`：只用标准库校验。
- `from_rules`：从业务规则批量派生 validator。
- `from_dto_fields`：从 DTO 字段、nullability、enum 和嵌套对象生成注解。
- `i18n_add_locale`：为现有 validators 补 message key 和 locale。
- `retrofit`：为老代码补校验草稿。


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | DTO 字段约束 + 业务规则 + i18n 配置 全部齐备 | 完整 validator + i18n message + 全局 ExceptionHandler |
| `provisional` | 字段约束齐备但 i18n key 未规划 | 输出 validator + 默认 message，i18n key 进 pending_i18n[] |
| `constrained` | 仅有字段名，缺类型 / 范围 | 输出 @NotNull 等基础注解，业务约束进 inferred[] |
| `blocked` | 仅有"需要校验"但无字段或规则 | 输出 `request_for_inputs[]` |

**特别提示**：
- 跨字段校验缺业务规则文档 → `provisional`
- 缺 messages.properties 配置 → `provisional`
- DTO 类型缺失（依赖 dto-vo-generation 输出）→ `constrained`

## Inputs / 输入分级
### core_required / 最小可执行输入
- `business_rules`、`dto_fields`、`openapi_schema` 或 `field_constraints` 任一项即可作为最小输入。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160

### optional_enrichment / 可选增强输入
- `DTO_VO草稿.zip`
- enum catalog
- error code / exception contract
- i18n locale list
- existing validator library
- DB index assumptions for DB-backed validation

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: validator-code-generation
  producer_node: N200
  artifact_name: 校验器代码.zip
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.校验器代码
  contract_version: n200.artifact.v2
  artifact_ref: 校验器代码.zip
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `standard_validator_bundle`
- `business_specific_validators[]`
- `rule_source_mapping[]`
- `cross_field_constraints[]`
- `validation_groups`
- `i18n_message_keys[]`
- `error_code_mapping[]`
- `test_skeleton[]`
- `performance_hints`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### Standard first
能用标准 Bean Validation / framework validator 时优先用标准库。

### Rule traceability
业务规则必须映射到 validator、字段、message key 和 error code。

### Cross-field constraints
跨字段约束使用 class-level / object-level validator；不要退化成 controller 内散乱 if。

### No side effects
validator 不修改数据、不发事件、不做写操作。

### DB-backed validation
涉及 DB 查询时必须写索引、缓存和性能风险；不要把 DB validator 当免费。

### i18n namespace
validation message key 使用 `validation.<domain>.<field>.<violation>`，避免与 enum/error 冲突。

### Tests required
每个 custom validator 输出至少一个正例、一个反例和边界例 test skeleton。

### Composable reuse
相同校验组合出现 3 次以上，建议提取 composable annotation。

## Execution workflow / 执行流程
1. 识别输入来源、字段级约束和跨字段规则。
2. 先映射标准 validators，再生成业务特定 validators。
3. 建立 rule_source_mapping、error_code_mapping 和 i18n keys。
4. 输出 cross_field constraints、validation groups 和 test_skeleton。
5. 标出 DTO/DB/enum/exception drift 和 pending decisions。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。


Load `references/validator-algorithms.yaml` before step 1. Use `annotation_selection` table for field annotations, `business_rule_to_validator_mapping` for rule-derived validators, and `cross_field_validator_pattern` for class-level constraints.

## Tech stack adapter / 多语言适配层
java: jakarta bean validation/jsr-380; typescript: zod/yup/class-validator; python: pydantic validators; go: validator tags + custom functions.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Machine-readable self_check rules

- `R01_artifact_contract_first`: 每次输出必须以 `artifact_contract` YAML 块开头; `on_violation: reject`
- `R02_readiness_set`: `readiness` 必须是 `pass | provisional | constrained | blocked` 之一; `on_violation: reject`
- `R03_standard_first`: 能用标准 Bean Validation 时必须优先；自定义 validator 须说明标准库无法覆盖的原因; `on_violation: warn`
- `R04_rule_traceability`: 每个业务 validator 必须在 `rule_source_mapping[]` 中映射到业务规则 ID; `on_violation: reject`
- `R05_no_side_effects`: validator 不得包含 `save/delete/publish/sendMessage` 等副作用操作; `on_violation: reject`
- `R06_cross_field_class_level`: 跨字段约束必须用 class-level annotation，不得退化为 Controller if 语句; `on_violation: warn`
- `R07_i18n_namespace_isolated`: message key 必须使用 `validation.<domain>.<field>.<violation>` 命名空间; `on_violation: warn`
- `R08_db_validator_has_index_hint`: DB-backed validator 必须在 `performance_hints` 中声明依赖索引; `on_violation: warn`
- `R09_test_skeleton_per_custom`: 每个 custom validator 必须有正例+反例+边界例 test skeleton; `on_violation: warn`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff`; `on_violation: reject`

## Cross-skill drift enforcement

N200 节点内多 skill 组合时，以下漂移必须在 `self_gate` 阶段拦截（而非静默通过）：

| 漂移类型 | 检测点 | 严重度 |
|---|---|---|
| Enum code 不一致 | `enum-definition-generation` 输出 vs DTO 字段 enum 值 | high |
| ErrorCode 孤儿 | `exception-class-generation` 输出的 ErrorCode 未在 DTO error response 中映射 | medium |
| Nullable 不一致 | `validator-code-generation` `@NonNull` vs `dto-vo-generation` `null_handling_policy` | high |
| SQL column 类型漂移 | `sql-draft-generation` DDL 列类型 vs DTO 字段 Java 类型 | medium |
| Validator-DTO 解耦失败 | validator 直接引用 DTO 内部字段而非通过接口 | low |

发现漂移时：优先写入 `drift_watchlist[]`；blocking 漂移（high 及以上）必须同时进入 `self_gate.failed_rules[]`，将 `self_gate.status` 设为 `block`。

## Common failure modes

1. **DB-backed validator 无索引声明** — 生成了唯一性校验（`@UniqueEmail`）但未说明依赖的 DB 索引，高并发下查询成为性能瓶颈。修复：DB-backed validator 必须在 `performance_hints` 中声明依赖的索引名、查询计划预期和缓存建议；缺少索引时标 `pending_decisions[]`。
2. **副作用注入** — 在 validator 中执行了数据库写操作或发布了领域事件，导致校验阶段产生不可回滚的副作用。修复：`no_side_effects` 规则检测 validator 中的 `save/delete/publish/sendMessage` 调用；发现时标 `severity: critical`。
3. **跨字段约束退化到 Controller** — 需要跨字段校验（如 `endDate > startDate`）但未使用 class-level annotation，散落在 Controller if 语句中，导致 Service 层可绕过校验调用。修复：检测 Controller 中的跨字段 if 判断；建议提取为 class-level `@ValidDateRange` annotation 并在 `cross_field_constraints[]` 中声明。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- 标准优先
- 业务规则已派生
- 跨字段在类级/object 级
- message key 已 namespace 隔离
- 无副作用
- custom validator 有测试骨架
- DB validator 写明性能风险
- validator 与 DTO/enum/exception 一致

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: validator-code-generation` 与运行时 `producer_skill: validator-code-generation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）


## Language-agnostic artifact packaging(CAND-B5 · 2026-07-18)

本 skill 的产物是「校验器 / validator 代码的一组源文件」,打包为**语言无关容器** `校验器代码.zip`,而非单个语言专属文件。

- **不写死语言后缀**:容器内文件的语言与后缀由 `tech_stack.language` 决定(见 `references/shared-codegen-enums.yaml` 的 language 枚举:java / go / node / python / rust / kotlin / other)—— 落地为 `.java` / `.py` / `.go` / `.ts` / `.rs` / `.kt` / … 。这遵守本 skill 的 Genericity rule(不绑定 node-specific / 语言专属文件名)。
- **为什么是容器不是单文件**:真实模块的校验器 / validator 代码通常是多个文件(多个类 / 多个源文件);单个 `.java` 既装不下多类、又把实现语言写死。容器形态与本节点已有的 058 `工程骨架.zip` / 062 `DTO_VO草稿.zip` 一致。
- **落地**:每个文件的路径 / 包 / 后缀遵循 `tech_stack` 的 package_layout 与 language 约定;由节点编排(如 scaffold-package-aggregator)合成到完整工程。
- **历史**:此前产物名写死 `.java`,与库的多语言 `shared.language` 枚举 + 本 skill 的通用性声明矛盾(非 java 团队用此节点产不出对的东西);已改为语言无关容器。
