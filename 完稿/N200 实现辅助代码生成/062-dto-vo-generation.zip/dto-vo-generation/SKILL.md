---
name: dto-vo-generation
description: Generate DTO, VO, Request, Response, Command, Query, and Event transport models from API contracts and entities — Jackson annotations, nullability contracts, CQRS separation.
---
# dto-vo-generation

## Role / 角色定位
生成跨层传输模型草稿。单独使用时可从 OpenAPI、字段清单或实体/表结构推导 DTO；在 N200 内负责交付 `DTO_VO草稿.zip`，并把字段、nullability、嵌套对象、mapper 和脱敏策略交给 validator、sql、文档与静态检查消费。

它是 `direct_result` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: direct_result
workflow_node: N200
node_artifact_target: DTO_VO草稿.zip
node_artifact_role: transport-model code draft package
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## Boundary / 边界
- 负责 request、response、command、query、event、view 等传输对象草稿。
- 负责字段命名、嵌套对象抽取、基础类型约定、null 策略、脱敏和 mapper 策略。
- 不负责 persistence entity 本身，不把 Entity 直接暴露给 API 层。
- 不负责 Controller / Service 完整实现。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `from_openapi`：以 API request/response schema 为主生成 transport models。
- `from_entity_or_table`：以 entity/table schema 为主派生传输模型，并标注 storage alignment assumptions。
- `cqrs_separation`：拆分 command/query/view/event。
- `contract_merge_mode`：综合 API contract、业务规则、enum、exception 和 schema 做一致性输出。


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

输出顶部必须声明 `readiness`，按下表确定具体值：

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | API 契约 + 字段约束 + 业务规则 + 存储 hint 全部齐备 | 完整 dto_catalog[] + drift_watchlist[] + 全部约束注解 |
| `provisional` | 主要契约齐备但缺约束细节（如长度、范围未指定） | 输出 dto_catalog[] 但约束字段进 `pending_constraints[]` |
| `constrained` | 仅有 API 名称/字段名，缺类型或语义 | 仅输出 dto_kind_policy + 推断结构进 `inferred[]` |
| `blocked` | 仅有功能描述，无字段定义 | 输出 `request_for_inputs[]` + 不写入任何 dto |

**升降级规则**：
- 单字段缺约束 → `pass` 仍可（约束字段进 pending）
- 整类 dto 缺字段定义 → `provisional`
- 缺 API 契约 → `constrained`
- 缺业务上下文 → `blocked`

## Inputs / 输入分级
### core_required / 最小可执行输入
- `api_specs` 或 `openapi_spec`: request/response schema，最小可执行输入之一。
- `field_schema` 或 `data_objects`: 字段和对象语义，最小可执行输入之一。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160

### optional_enrichment / 可选增强输入
- `tables` / `表结构设计草案.sql`
- `enums` from `enum-definition-generation`
- `error_response_contract` from `exception-class-generation`
- `scaffold` from N190
- 脱敏规则、分页规范、命名规范

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: dto-vo-generation
  producer_node: N200
  artifact_name: DTO_VO草稿.zip
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.DTO_VO草稿
  contract_version: n200.artifact.v2
  artifact_ref: DTO_VO草稿.zip
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `dto_kind_policy`
- `dto_catalog[]`
- `shared_nested_objects[]`
- `null_handling_policy`
- `primitive_type_conventions`
- `masking_policy`
- `mapper_strategy`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### DTO kind naming
默认使用语义后缀 `Request` / `Response` / `Command` / `Query` / `Event` / `View`。不要默认生成模糊的 `XxxDTO` / `XxxVO` / `XxxData`；只有当用户团队已有明确约定时，才可作为 compatibility alias，并必须记录在 `naming_aliases[]`。

### Primitive conventions
时间默认 ISO 8601 UTC；金额用定点 decimal 类型；ID wire format 优先 String；enum wire format 用 code string；集合字段默认不返回 null。

### Null policy
每个字段必须显式标注 `never_null`、`optional` 或 `default_value`，并与 validator 注解保持一致。

### Shared nested objects
相似 shape 出现 3 次以上，或相似度超过 0.8，应列为共享嵌套对象候选。

### Mapper strategy
Java 默认推荐 MapStruct；TypeScript 可用 schema mapper / zod transform；Python 可用 pydantic model_validate。手写 mapper 只能作为 fallback，并需说明原因。

### Sensitive data
Response/View 中的 PII/PCI 字段必须有 masking/remove/hash 策略。

## Execution workflow / 执行流程
1. 识别 selected_mode、core input、readiness 和 source of truth。
2. 区分 request / response / command / query / event / view。
3. 抽取字段、nullability、enum、分页、嵌套对象和脱敏需求。
4. 对齐 enum、validator、exception 和 SQL 的兄弟契约。
5. 生成 DTO catalog、shared objects、mapper strategy 和 drift watchlist。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。

## Tech stack adapter / 多语言适配层
java: record/lombok + mapstruct + jackson; typescript: interfaces/types + zod/io-ts adapters; python: pydantic/dataclasses; go: struct tags + validation tags.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Machine-readable self_check rules

- `R01_artifact_contract_first`: 每次输出必须以 `artifact_contract` YAML 块开头; `on_violation: reject`
- `R02_readiness_set`: `readiness` 必须是 `pass | provisional | constrained | blocked` 之一; `on_violation: reject`
- `R03_no_entity_exposure`: 不得把 JPA Entity 直接作为 response 类型输出; `on_violation: reject`
- `R04_semantic_suffix_required`: 传输对象必须使用语义后缀（Request/Response/Command/Query/Event/View）；模糊后缀（DTO/VO/Data）须有团队约定说明; `on_violation: warn`
- `R05_null_policy_per_field`: 每个字段必须声明 `never_null / optional / default_value`; `on_violation: warn`
- `R06_pii_masking_declared`: response/view 中含 PII/PCI 字段时必须有 masking/remove/hash 策略; `on_violation: reject`
- `R07_mapper_strategy_stated`: 必须声明 mapper 策略（MapStruct/手写/pydantic）; `on_violation: warn`
- `R08_drift_watchlist_present`: 必须输出 `drift_watchlist[]`; `on_violation: reject`
- `R09_produced_event_declared`: 必须声明 `produced_event` 块; `on_violation: reject`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff`; `on_violation: reject`

## Cross-skill drift enforcement

N200 节点内多 skill 组合时，以下漂移必须在 `self_gate` 阶段拦截（而非静默通过）：

| 漂移类型 | 检测点 | 严重度 |
|---|---|---|
| Enum code 不一致 | `enum-definition-generation` 输出 vs DTO 字段 enum 值 | high |
| ErrorCode 孤儿 | `exception-class-generation` 输出的 ErrorCode 未在 DTO error response 中映射 | medium |
| Nullable 不一致 | `validator-code-generation` `@NonNull` vs `dto-vo-generation` `null_handling_policy` | high |
| SQL column 类型漂移 | `sql-draft-generation` DDL 列类型 vs DTO 字段 Java 类型 | medium |
| Validator-DTO 解耦失败 | validator 直接引用 DTO 内部字段而非通过接口 | low |

发现漂移时：优先写入 `drift_watchlist[]`；blocking 漂移（high 及以上）必须同时进入 `self_gate.failed_rules[]`，将 `self_gate.status` 设为 `block`。

## Common failure modes

1. **模糊后缀滥用** — 所有传输对象都命名为 `XxxDTO` / `XxxVO`，无法区分 request/response/command/query 语义，下游 validator 无法按类型施策。修复：强制使用语义后缀 `Request / Response / Command / Query / Event / View`；兼容别名只在团队已有约定时追加。
2. **Entity 直接暴露** — 把 JPA Entity 作为 API response 返回，导致懒加载触发 N+1、内部字段泄漏、序列化循环引用。修复：`dto-vo-generation` 必须声明 `entity_exposure_check: forbidden`；发现 Entity 直接作为 response 类型时标 `severity: high`。
3. **Null 策略未声明** — 字段缺少 `never_null / optional / default_value` 标注，导致 validator 和前端各自做不同假设。修复：每个字段必须在 `null_handling_policy` 中显式声明；无法确定时进 `pending_decisions[]`。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- dto kind 后缀合规
- 无默认模糊 DTO/VO/Data 后缀
- null 策略明示
- 时间/金额/ID/enum 类型约定明确
- PII 脱敏
- shared nested 已识别
- mapper 策略已声明
- 与 validator / enum / sql 的 drift 已记录

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: dto-vo-generation` 与运行时 `producer_skill: dto-vo-generation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/dto-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/dto-self-check.yaml`: R01-R10 机读门禁规则
- `references/dto-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）
