---
name: dto-vo-generation
description: generate reusable dto, vo, request, response, command, query, event, and view model drafts from api contracts, field schemas, business rules, and storage hints. use for standalone transport-model design or n200 implementation-assist output dto_vo草稿.zip with explicit readiness, evidence, contract, and downstream handoff.
---
# dto-vo-generation

## Role / 角色定位
生成跨层传输模型草稿。单独使用时可从 OpenAPI、字段清单或实体/表结构推导 DTO；在 N200 内负责交付 `DTO_VO草稿.zip`，并把字段、nullability、嵌套对象、mapper 和脱敏策略交给 validator、sql、文档与静态检查消费。

它是 `direct_result` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: direct_result
workflow_node: N200
node_artifact_target: DTO_VO草稿.zip
node_artifact_role: transport-model code draft package
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## Boundary / 边界
- 负责 request、response、command、query、event、view 等传输对象草稿。
- 负责字段命名、嵌套对象抽取、基础类型约定、null 策略、脱敏和 mapper 策略。
- 不负责 persistence entity 本身，不把 Entity 直接暴露给 API 层。
- 不负责 Controller / Service 完整实现。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `from_openapi`：以 API request/response schema 为主生成 transport models。
- `from_entity_or_table`：以 entity/table schema 为主派生传输模型，并标注 storage alignment assumptions。
- `cqrs_separation`：拆分 command/query/view/event。
- `contract_merge_mode`：综合 API contract、业务规则、enum、exception 和 schema 做一致性输出。

## Inputs / 输入分级
### core_required / 最小可执行输入
- `api_specs` 或 `openapi_spec`: request/response schema，最小可执行输入之一。
- `field_schema` 或 `data_objects`: 字段和对象语义，最小可执行输入之一。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160

### optional_enrichment / 可选增强输入
- `tables` / `表结构设计草案.sql`
- `enums` from `enum-definition-generation`
- `error_response_contract` from `exception-class-generation`
- `scaffold` from N190
- 脱敏规则、分页规范、命名规范

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: dto-vo-generation
  producer_node: N200
  artifact_name: DTO_VO草稿.zip
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.DTO_VO草稿
  contract_version: n200.artifact.v2
  artifact_ref: DTO_VO草稿.zip
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `dto_kind_policy`
- `dto_catalog[]`
- `shared_nested_objects[]`
- `null_handling_policy`
- `primitive_type_conventions`
- `masking_policy`
- `mapper_strategy`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### DTO kind naming
默认使用语义后缀 `Request` / `Response` / `Command` / `Query` / `Event` / `View`。不要默认生成模糊的 `XxxDTO` / `XxxVO` / `XxxData`；只有当用户团队已有明确约定时，才可作为 compatibility alias，并必须记录在 `naming_aliases[]`。

### Primitive conventions
时间默认 ISO 8601 UTC；金额用定点 decimal 类型；ID wire format 优先 String；enum wire format 用 code string；集合字段默认不返回 null。

### Null policy
每个字段必须显式标注 `never_null`、`optional` 或 `default_value`，并与 validator 注解保持一致。

### Shared nested objects
相似 shape 出现 3 次以上，或相似度超过 0.8，应列为共享嵌套对象候选。

### Mapper strategy
Java 默认推荐 MapStruct；TypeScript 可用 schema mapper / zod transform；Python 可用 pydantic model_validate。手写 mapper 只能作为 fallback，并需说明原因。

### Sensitive data
Response/View 中的 PII/PCI 字段必须有 masking/remove/hash 策略。

## Execution workflow / 执行流程
1. 识别 selected_mode、core input、readiness 和 source of truth。
2. 区分 request / response / command / query / event / view。
3. 抽取字段、nullability、enum、分页、嵌套对象和脱敏需求。
4. 对齐 enum、validator、exception 和 SQL 的兄弟契约。
5. 生成 DTO catalog、shared objects、mapper strategy 和 drift watchlist。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。

## Tech stack adapter / 多语言适配层
java: record/lombok + mapstruct + jackson; typescript: interfaces/types + zod/io-ts adapters; python: pydantic/dataclasses; go: struct tags + validation tags.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- dto kind 后缀合规
- 无默认模糊 DTO/VO/Data 后缀
- null 策略明示
- 时间/金额/ID/enum 类型约定明确
- PII 脱敏
- shared nested 已识别
- mapper 策略已声明
- 与 validator / enum / sql 的 drift 已记录

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: dto-vo-generation` 与运行时 `producer_skill: dto-vo-generation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）
