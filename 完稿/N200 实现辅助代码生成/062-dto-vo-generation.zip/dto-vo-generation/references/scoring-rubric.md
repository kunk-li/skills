# Scoring rubric for N200 skill outputs

Score each category from 0 to 2 and include the result in `quality_self_score`.

## dimensions

### standalone_usability
- 0: cannot run without full N200 context
- 1: usable with assumptions, but gaps are vague
- 2: usable from minimal core input with explicit readiness and assumptions

### contract_completeness
- 0: missing artifact contract or downstream consumers
- 1: contract exists but omits schema/evidence/event details
- 2: includes artifact_contract, self_gate, produced_event, and artifact-specific sections

### uncertainty_handling
- 0: hides missing evidence or overclaims certainty
- 1: mentions uncertainty but not as structured fields
- 2: includes readiness, evidence_profile, assumptions, pending_decisions, pending_validations, and drift_watchlist

### downstream_handoff
- 0: no clear handoff to sibling skills or N210/N330/N390
- 1: partial handoff with unresolved conflicts
- 2: clear handoff plus conflict/drift reporting and node-level consistency notes

## Overall level mapping
- S: total 8 and no dimension below 2
- A: total 6-7 and no dimension below 1
- B: total 4-5 or any dimension equals 0 but output is still usable
- C: total below 4 or output is unsafe to use
