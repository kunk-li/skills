# N200 Contract and Verification Versioning

This file prevents ambiguity between contract schema version and implementation alignment rounds.

## Versioning model

- `n200-v2-contract.md` is the shared artifact contract specification. The `v2` suffix means contract schema version, not the package implementation round.
- `n200-v4-verification.md` is the static/runtime verification checklist introduced during the v4 alignment round. It remains a valid checklist for later packages unless replaced by a newer verification contract.
- This package is an actual artifact update after v4 acceptance feedback. Treat package identity by the released ZIP hash and the `artifact_contract.schema_version`, not by the reference filename alone.

## Required behavior

- Keep `references/n200-v2-contract.md` as the first reference file for backward compatibility with existing N200 routing.
- Keep `references/n200-v4-verification.md` as the verification checklist unless a newer checklist is explicitly introduced.
- When reporting implementation status, distinguish `analysis_report_version`, `contract_schema_version`, `verification_checklist_version`, and `artifact_package_version`.

## Content identity vs archive position

The stable content identity of each skill is the skill name in `SKILL.md` and the `producer_skill` field emitted at runtime. Archive positions, zip filename prefixes, and UI ordering are non-authoritative distribution metadata. They may be preserved for user convenience, but must not be required by the skill content contract.

## Status fields to emit when relevant

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```

## External file policy

Do not use external reports, checksum files, or bundle-level docs as authoritative constraints. Any new constraint must be embedded in the individual skill package, preferably in `SKILL.md`; use `references/` only for supporting material loaded from within the same skill.

## Shared governance asset coordination

These files are shared coordination assets. They are physically bundled inside each N200 skill package to satisfy the skill-internal source-of-truth policy, but they are semantically managed as one canonical shared version across all six N200 skills:

- `n200-v2-contract.md`
- `n200-v4-verification.md`
- `n200-collaboration-matrix.md`
- `scoring-rubric.md`
- `n200-v5-change-log.md`
- `n200-contract-versioning.md`

When any shared coordination asset changes, propagate the same content to all six N200 skill packages in the same release. Per-skill divergence is forbidden for these shared assets. Skill-specific files such as `readiness-inheritance.md` and `package-manifest.md` may differ by skill.

Equality checks across packages are release hygiene, not runtime dependencies. Do not rely on external reports, external checksum files, or bundle-level documents as authoritative constraints. The authoritative text is the copy of each shared asset inside the current skill package.
