# N200 workflow-aligned collaboration matrix

## Workflow node alignment

- `workflow_node`: `N200`
- `stage`: `编码与实现 / 实现辅助代码生成`
- workflow downstream: `N210`, `N330`, `N390`

## Identity policy

Reference skills by stable skill name only. Archive positions, zip filename prefixes, and UI ordering may change and must not be treated as content identity.

## Standard node inputs

- `接口设计草案.yaml`
- `业务规则清单.csv`
- `错误码清单.csv`
- `表结构设计草案.sql`

These are workflow-enrichment inputs. A single skill may run with fewer inputs when it has a valid standalone core input.

## Recommended execution order

1. `enum-definition-generation`
2. `exception-class-generation`
3. `dto-vo-generation`
4. `validator-code-generation`
5. `sql-draft-generation`
6. `query-optimization-recommendation`

This is the preferred local order, not a hard dependency chain. If inputs are partial, generate the local artifact with explicit assumptions and keep unresolved gaps visible.

## Sibling handoffs

| From | To | Handoff |
|---|---|---|
| `enum-definition-generation` | `dto-vo-generation` | enum code, wire format, lifecycle notes, i18n keys |
| `enum-definition-generation` | `validator-code-generation` | allowed values, categorical/flag/ordered semantics |
| `enum-definition-generation` | `sql-draft-generation` | check constraints or enum column candidates |
| `exception-class-generation` | `dto-vo-generation` | error response payload conventions |
| `exception-class-generation` | `validator-code-generation` | validation failure mapping and error code binding |
| `dto-vo-generation` | `validator-code-generation` | field names, nullability, nested object candidates |
| `dto-vo-generation` | `sql-draft-generation` | transport-to-storage alignment notes |
| `sql-draft-generation` | `query-optimization-recommendation` | statements, indexes, migrations, dialect notes |
| `query-optimization-recommendation` | `sql-draft-generation` | rewrite proposals capped by `max_rewrite_iteration: 2` |

## Shared design rules

- Treat API schema, DB schema, business rules, and error-code catalog as source-of-truth inputs.
- Preserve conflicts in `drift_watchlist[]`; do not silently pick a side.
- Use `readiness`, `evidence_profile`, `pending_decisions[]`, and `pending_validations[]` to make uncertainty explicit.
- Emit `artifact_contract`, `self_gate`, and `produced_event` blocks in every result.
