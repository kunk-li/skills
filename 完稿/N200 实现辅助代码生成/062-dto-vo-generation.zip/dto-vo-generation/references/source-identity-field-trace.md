# Source identity field trace for transport models

When an API DTO carries a multi-stage lifecycle command or callback, compare the canonical source fields in requirements, business rules and state transitions with the API and schema artifacts. Emit a field-level trace from each source identity component to the generated request/event field. A callback may add an approval-instance identity; keep it separate from the external event/callback id used for delivery idempotency and from any retry counter.

Do not infer that workflow-instance reference, ticket reference, stage code, or callback id is equivalent to a source field unless an explicit owner/API mapping says so. Where names or mappings are unresolved, retain the source identity in the trace, list the exact pending mapping, preserve distinct existing fields, and keep readiness blocked. Do not silently drop fields or invent aliases that change the owner wire contract.
