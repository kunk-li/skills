# N200 v5 Artifact Change Log

## Editorial rule

Refer to skills by stable skill name, such as `enum-definition-generation`, never by archive position number. Archive positions belong in `package-manifest.md` only as non-authoritative distribution hints.


This package applies actual artifact-level changes after the v4 final acceptance review.

## Changes

1. Adds explicit ordered enum method schema requirements to `enum-definition-generation`.
2. Moves query optimization cache boundary text under the `Caching boundary` rule and keeps advisory output separate.
3. Adds shared contract/versioning guidance so readers do not confuse `n200-v2-contract.md` with an implementation round.
4. Adds a package-level versioning status block requirement for future audits.

## Non-goals

- Do not rename `n200-v2-contract.md`; it is kept as the canonical contract schema filename.
- Do not rename `n200-v4-verification.md`; it is kept as the canonical verification checklist until replaced by a later checklist.


## v6 internal constraints update

This package applies the user's delivery constraint: do not add constraint, verification, changelog, or governance files outside the skills.

Changes:

1. Embeds the external-file policy directly in every `SKILL.md` under `Artifact packaging constraint / skill 内约束`.
2. Updates each `package-manifest.md` to `artifact_package_version: v6-internal-constraints-update`.
3. Updates `n200-contract-versioning.md` so `versioning_status` exposes `external_files_policy: no_external_constraint_files`.
4. Keeps all maintenance and verification constraints inside each skill package.

Non-goals:

- Do not create standalone delivery reports, external verification files, external SHA files, or bundle-level governance documents for this update.
- Do not move constraints out of individual skill packages.

## v7 light governance fix

This release keeps the v6 skill-internal constraint policy and adds three governance clarifications inside each skill package:

1. Shared coordination assets must be propagated identically to all six N200 skill packages in the same release.
2. Cross-skill consistency checks are executed at N200 node aggregation time by the N200 node-level aggregator, N370 platform routing, or N380 platform gate after individual skill artifacts are produced.
3. Conversation reports about the current released version are historical reference only; improvement suggestions from conversation may become future constraints only after they are written into the skill package and reflected in `package-manifest.md`.

No external report, checksum, bundle note, or delivery document is required for this release. All constraints are embedded inside each individual skill package.

## v8 content id decoupling

This release keeps user-provided archive filename sequence unchanged while removing numeric archive positions from authoritative skill identity. Stable skill names are the only content identity. Numeric archive positions may appear only in `package-manifest.md` as non-authoritative distribution hints.
