# N200 v4 Alignment Verification

This skill is part of the fully aligned N200 v4 package. It must satisfy the shared v2 contract and the delta checks from the v3 analysis report.

## Required static checks
- SKILL.md references `references/n200-v2-contract.md` as the first reference file.
- SKILL.md includes `Workflow anchors`, `Required v2 reactive output blocks`, `Inputs / 输入分级`, `Standalone rule`, `Uncertainty management`, `N200 composition rules`, and `Tech stack adapter`.
- Outputs include `artifact_contract`, `self_gate`, `produced_event`, and `quality_self_score`.
- `scoring-rubric.md` uses the unified four dimensions: `standalone_usability`, `contract_completeness`, `uncertainty_handling`, and `downstream_handoff`.
- N200 sibling dependencies are enhancement paths only; each skill remains independently usable.

## Required runtime checks
- Emit `produced_event` for N210, N330, and N390.
- Put unresolved cross-skill mismatch into `drift_watchlist[]`.
- Use `readiness` and `evidence_profile` to make uncertainty visible.
- Respect the N200 rewrite fuse: `max_rewrite_iteration: 2`.
