# Output template: DTO / VO drafts

Start every response with `artifact_contract`, `self_gate`, and `produced_event`.

## Required sections

0. `quality_self_score`

1. `dto_kind_policy`
2. `dto_catalog[]`
3. `shared_nested_objects[]`
4. `null_handling_policy`
5. `primitive_type_conventions`
6. `masking_policy`
7. `mapper_strategy`
8. `tech_stack_adapter`
9. `downstream_handoff`

## Java example pattern

```java
/**
 * Source: {api contract or schema reference}
 * Readiness: {pass | provisional | constrained | blocked}
 * Evidence: {direct_contract | inferred_from_schema | heuristic_only | mixed}
 */
public record {Object}Response(
    String id,
    String statusCode,
    Instant createdAt
) {}
```

## Boundary rules

- Do not expose persistence Entity directly.
- Do not use ambiguous `XxxDTO` / `XxxVO` unless it is a declared compatibility alias.
- Do not claim generated code has been compiled or tested unless evidence is provided.

## Quality self-score block

Use `references/scoring-rubric.md`. Score each dimension from 0 to 2, then assign `overall_level: S | A | B | C`. Do not hide weak dimensions; list improvement notes.
