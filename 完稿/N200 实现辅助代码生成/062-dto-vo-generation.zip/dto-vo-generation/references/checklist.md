# DTO/VO 交付检查清单 v2.4

## 基础完整性 (must-pass)

- [ ] 每个 API endpoint 都有对应的 Request 和 Response 类型
- [ ] 缺失的 Request/Response 在 `pending[]` 列出原因（非 silent skip）
- [ ] 类名使用语义后缀（Request / Response / Command / Query / Event / View）
- [ ] 模糊后缀（DTO / VO / Data）有团队约定文档说明，且不与语义后缀混用
- [ ] 字段命名与上游 OpenAPI / 接口意图清单对齐
- [ ] 没有把 JPA Entity 直接作为 Request/Response 类型

## 字段约束完整性 (must-pass)

- [ ] 必填字段标 `@NotNull` 或文档明确"required"
- [ ] 字符串字段含长度约束 (`@Size`) 或注释说明无限制原因
- [ ] 数值字段含范围约束 (`@Min` / `@Max` / `@DecimalMin`) 或显式标"无范围"
- [ ] 正则约束（邮箱、手机、url）已使用 `@Pattern` 或 `@Email`
- [ ] 每个字段声明 null 策略：never_null / optional / default_value
- [ ] 业务规则约束（如"金额必须 > 0"）已映射到 `@Positive` 或自定义 validator

## 枚举与关联 (must-pass)

- [ ] 枚举字段引用 N200 enum-definition-generation 输出的具体 enum 类型
- [ ] 关联引用（如 user_id 指向 User）已在 javadoc 注明，不破坏 transport 层抽象

## 安全与脱敏 (recommended)

- [ ] PII / PCI 字段（身份证 / 银行卡 / 邮箱 / 手机）有 masking 策略声明
- [ ] Response 类型不暴露 entity 内部字段（version / createdBy 等元数据）
- [ ] 敏感字段在 toString() 中用 `@ToString.Exclude` 或 `***`

## 嵌套与分页 (recommended)

- [ ] 嵌套对象超过 2 层时，扁平化或拆分为独立 DTO
- [ ] 分页响应使用统一 PageResponse<T> 而非每个 endpoint 重复定义
- [ ] 列表响应明确是否包含 total 字段（影响性能）

## Mapper 与转换 (recommended)

- [ ] 声明 mapper 策略：MapStruct / 手写 / Pydantic / 其他
- [ ] entity → DTO 转换在 service 层不在 controller 层
- [ ] mapper 不含业务逻辑（仅字段映射 + 类型转换）

## 输出禁止项 (must-not)

- [ ] DTO 不继承 Entity（绕过会造成 lazy load proxy 序列化）
- [ ] DTO 不含业务方法（如 `calculateTotal()` 应在 service）
- [ ] DTO 不含上线时间承诺或 release 标记

## drift 防护 (recommended)

- [ ] 输出 `drift_watchlist[]` 列出可能与 entity 字段漂移的高危点
- [ ] 输出 `downstream_handoff` 标识 N210 / N240 应消费的字段
