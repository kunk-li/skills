---
name: enum-definition-generation
description: Generate enum definitions from value sets, state machines, and error catalogs — DB column mapping, @JsonValue serialization, deprecation lifecycle, i18n display labels.
---
# enum-definition-generation

## Role / 角色定位
生成稳定闭集值域的枚举草稿。单独使用时可从值域列表、状态机、错误码或 DB constraint 推导 enum；在 N200 内负责交付 `枚举定义.zip`，并为 DTO、validator、SQL 和文档提供 code-first 值集。

它是 `direct_result` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: direct_result
workflow_node: N200
node_artifact_target: 枚举定义.zip
node_artifact_role: code-first enum definition draft
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## Boundary / 边界
- 负责 categorical、flag、ordered、constant_set 四类 enum 草稿。
- 负责 code-first DB/wire mapping、i18n key、生命周期、兼容性与职责单一检查。
- 不负责异常处理、DTO、validator 或 SQL 的完整实现。
- 不把开放集合、频繁变化的字典表或用户可配置数据硬枚举化。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `from_state_machine`：从状态流转表生成 status enum。
- `from_value_set`：从闭集值域列表生成 enum。
- `from_error_codes`：从错误码目录生成 ErrorCode enum 或 failure category enum。
- `from_schema`：从表约束、代码表或 CHECK constraint 反推 enum。
- `contract_merge_mode`：综合 API、规则、schema 和 i18n 做一致性输出。


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 枚举值集合稳定 + 业务语义清晰 + 持久化策略已定 | 完整 enum + transition 图（状态机型）+ DB/JSON 序列化策略 |
| `provisional` | 枚举值已知但持久化策略待定（ordinal vs name） | 输出 enum 主体，序列化策略进 pending |
| `constrained` | 仅有部分枚举值（如来自 DDL 的 CHECK 约束）但语义文档缺失 | 仅输出已知值 + 标 missing_semantic[] |
| `blocked` | 仅有"需要一个状态枚举"但无值集合 | 输出 `request_for_inputs[]` + 不写入 enum |

**特别提示**：
- 状态机型 enum 缺转换图 → `provisional`
- ErrorCode 枚举缺 httpStatus 映射 → `provisional`
- 跨服务共享 enum 缺统一来源 → `constrained`

## Inputs / 输入分级
### core_required / 最小可执行输入
- `value_set`、`state_machines`、`error_codes`、`business_rules` 或 `table_constraints` 任一项即可作为最小输入。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160

### optional_enrichment / 可选增强输入
- `api_specs` / `接口设计草案.yaml`
- `data_objects`
- `i18n_locales`
- existing enum code
- frontend exposure policy

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: enum-definition-generation
  producer_node: N200
  artifact_name: 枚举定义.zip
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.枚举定义
  contract_version: n200.artifact.v2
  artifact_ref: 枚举定义.zip
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `enum_kind_policy`
- `enum_catalog[]`
- `wire_and_db_mapping`
- `state_transition_notes`
- `ordered_comparison_methods`
- `i18n_bundle`
- `lifecycle_compatibility_rules`
- `anti_pattern_detection`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### Enum kind
必须区分 `categorical`、`flag`、`ordered`、`constant_set`；不要混型。

### Code-first mapping
每个值必须有稳定唯一 `code`；DB 和 wire format 默认传 code string；禁止依赖 ordinal。

### Ordered enum methods
`ordered` 类型必须输出 `ordered_comparison_methods` 结构，而不只是在 self-check 中提示。至少包含：

```yaml
ordered_comparison_methods:
  rank_field: rank | priority | level
  compare_method:
    name: compareByRank
    signature: compareByRank(left, right) -> int
    ordering: lower_rank_means_smaller | higher_rank_means_smaller
  predicate_methods:
    - isAtLeast
    - isAtMost
    - isHigherThan
    - isLowerThan
  equality_policy: compare_by_code_then_rank
  unknown_value_policy: reject | map_to_unknown_lowest | map_to_unknown_highest
  sample_code: optional
```

若用户只给出有序值列表但未给 rank，必须从顺序推断 provisional rank，并把该推断写入 `pending_validations[]`。

### Flag enum values
`flag` 类型 bit value 必须是 2 的幂，或明确改用 `Set<Enum>`。

### i18n namespace
用户可见 enum 使用 `enum.<domain>.<name>.<code>` 命名空间，避免与 `validation.*` 或 `error.*` 冲突。

### Lifecycle
deprecated value 必须有 replacement 或兼容读取策略。

### Single responsibility
不要把状态、错误码、权限和展示大对象塞进同一个 enum。

## Execution workflow / 执行流程
1. 识别闭集、开放集和 source of truth。
2. 选择 enum_kind 并分离混型值域。
3. 分配稳定 code、wire/db mapping 和 i18n key。
4. 生成生命周期规则、deprecated/replacement 和 unknown fallback。
5. 对齐 DTO、validator、SQL、exception 的引用需求。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。

## Tech stack adapter / 多语言适配层
java: enum + @JsonValue + fromCode; typescript: const enum/as const union; python: enum.Enum/str enum; go: typed const + stringer-style helpers.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Machine-readable self_check rules

- `R01_artifact_contract_first`: 每次输出必须以 `artifact_contract` YAML 块开头; `on_violation: reject`
- `R02_readiness_set`: `readiness` 必须是 `pass | provisional | constrained | blocked` 之一; `on_violation: reject`
- `R03_enum_kind_declared`: 每个 enum 必须标注 `categorical | flag | ordered | constant_set`; `on_violation: reject`
- `R04_no_ordinal_persistence`: 不得使用 ordinal() 或数组索引存储 enum 值; `on_violation: reject`
- `R05_stable_code_per_value`: 每个值必须有唯一稳定 `code`; `on_violation: reject`
- `R06_open_set_rejected`: 开放集合不得被硬枚举化; `on_violation: reject`
- `R07_flag_power_of_two`: `flag` 类型 bit value 必须是 2 的幂; `on_violation: warn`
- `R08_ordered_comparison_methods`: `ordered` 类型必须输出 `ordered_comparison_methods` 结构; `on_violation: warn`
- `R09_deprecated_has_replacement`: deprecated 值必须有 replacement 或兼容读取策略; `on_violation: warn`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff`; `on_violation: reject`

## Cross-skill drift enforcement

N200 节点内多 skill 组合时，以下漂移必须在 `self_gate` 阶段拦截（而非静默通过）：

| 漂移类型 | 检测点 | 严重度 |
|---|---|---|
| Enum code 不一致 | `enum-definition-generation` 输出 vs DTO 字段 enum 值 | high |
| ErrorCode 孤儿 | `exception-class-generation` 输出的 ErrorCode 未在 DTO error response 中映射 | medium |
| Nullable 不一致 | `validator-code-generation` `@NonNull` vs `dto-vo-generation` `null_handling_policy` | high |
| SQL column 类型漂移 | `sql-draft-generation` DDL 列类型 vs DTO 字段 Java 类型 | medium |
| Validator-DTO 解耦失败 | validator 直接引用 DTO 内部字段而非通过接口 | low |

发现漂移时：优先写入 `drift_watchlist[]`；blocking 漂移（high 及以上）必须同时进入 `self_gate.failed_rules[]`，将 `self_gate.status` 设为 `block`。

## Common failure modes

1. **开放集被枚举化** — 把频繁新增值的字典表（如城市列表、标签分类）硬枚举，每次新增都需发版。修复：区分闭集（用 enum）和开放集（用 DB lookup table）；开放集出现在输入时必须拒绝枚举化并写入 `pending_decisions[]`。
2. **Ordinal 持久化** — 使用 `ordinal()` 或数组索引存储 enum 值，导致增减成员后数据损坏。修复：`code-first mapping` 规则强制每个值有稳定唯一 `code`；自检中检测任何依赖 ordinal 的映射并标 `severity: critical`。
3. **混型 enum** — 把状态、错误码、权限级别塞进同一个 enum，导致 validator 和 DB mapping 无法分离。修复：`single responsibility` 规则触发时必须拆分并在 `anti_pattern_detection[]` 中记录；混型 enum 标 `severity: medium`。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- enum_kind 已标注
- code 唯一且稳定
- 未使用 ordinal 持久化
- i18n namespace 隔离
- deprecated 有替代或兼容策略
- flag 值为 2 的幂
- ordered 有比较语义
- 开放集合未被枚举化

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: enum-definition-generation` 与运行时 `producer_skill: enum-definition-generation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/enum-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/enum-self-check.yaml`: R01-R10 机读门禁规则
- `references/enum-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）


## Language-agnostic artifact packaging(CAND-B5 · 2026-07-18)

本 skill 的产物是「枚举 / 常量定义的一组源文件」,打包为**语言无关容器** `枚举定义.zip`,而非单个语言专属文件。

- **不写死语言后缀**:容器内文件的语言与后缀由 `tech_stack.language` 决定(见 `references/shared-codegen-enums.yaml` 的 language 枚举:java / go / node / python / rust / kotlin / other)—— 落地为 `.java` / `.py` / `.go` / `.ts` / `.rs` / `.kt` / … 。这遵守本 skill 的 Genericity rule(不绑定 node-specific / 语言专属文件名)。
- **为什么是容器不是单文件**:真实模块的枚举 / 常量定义通常是多个文件(多个类 / 多个源文件);单个 `.java` 既装不下多类、又把实现语言写死。容器形态与本节点已有的 058 `工程骨架.zip` / 062 `DTO_VO草稿.zip` 一致。
- **落地**:每个文件的路径 / 包 / 后缀遵循 `tech_stack` 的 package_layout 与 language 约定;由节点编排(如 scaffold-package-aggregator)合成到完整工程。
- **历史**:此前产物名写死 `.java`,与库的多语言 `shared.language` 枚举 + 本 skill 的通用性声明矛盾(非 java 团队用此节点产不出对的东西);已改为语言无关容器。
