---
name: enum-definition-generation
description: generate reusable enum definitions from bounded value sets, state machines, error code catalogs, business rules, table constraints, and api contracts. use for standalone enum design or n200 implementation-assist output 枚举定义.java with code-first mapping, i18n, lifecycle, contract, and downstream handoff.
---
# enum-definition-generation

## Role / 角色定位
生成稳定闭集值域的枚举草稿。单独使用时可从值域列表、状态机、错误码或 DB constraint 推导 enum；在 N200 内负责交付 `枚举定义.java`，并为 DTO、validator、SQL 和文档提供 code-first 值集。

它是 `direct_result` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: direct_result
workflow_node: N200
node_artifact_target: 枚举定义.java
node_artifact_role: code-first enum definition draft
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## Boundary / 边界
- 负责 categorical、flag、ordered、constant_set 四类 enum 草稿。
- 负责 code-first DB/wire mapping、i18n key、生命周期、兼容性与职责单一检查。
- 不负责异常处理、DTO、validator 或 SQL 的完整实现。
- 不把开放集合、频繁变化的字典表或用户可配置数据硬枚举化。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `from_state_machine`：从状态流转表生成 status enum。
- `from_value_set`：从闭集值域列表生成 enum。
- `from_error_codes`：从错误码目录生成 ErrorCode enum 或 failure category enum。
- `from_schema`：从表约束、代码表或 CHECK constraint 反推 enum。
- `contract_merge_mode`：综合 API、规则、schema 和 i18n 做一致性输出。

## Inputs / 输入分级
### core_required / 最小可执行输入
- `value_set`、`state_machines`、`error_codes`、`business_rules` 或 `table_constraints` 任一项即可作为最小输入。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160

### optional_enrichment / 可选增强输入
- `api_specs` / `接口设计草案.yaml`
- `data_objects`
- `i18n_locales`
- existing enum code
- frontend exposure policy

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: enum-definition-generation
  producer_node: N200
  artifact_name: 枚举定义.java
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.枚举定义
  contract_version: n200.artifact.v2
  artifact_ref: 枚举定义.java
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `enum_kind_policy`
- `enum_catalog[]`
- `wire_and_db_mapping`
- `state_transition_notes`
- `ordered_comparison_methods`
- `i18n_bundle`
- `lifecycle_compatibility_rules`
- `anti_pattern_detection`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### Enum kind
必须区分 `categorical`、`flag`、`ordered`、`constant_set`；不要混型。

### Code-first mapping
每个值必须有稳定唯一 `code`；DB 和 wire format 默认传 code string；禁止依赖 ordinal。

### Ordered enum methods
`ordered` 类型必须输出 `ordered_comparison_methods` 结构，而不只是在 self-check 中提示。至少包含：

```yaml
ordered_comparison_methods:
  rank_field: rank | priority | level
  compare_method:
    name: compareByRank
    signature: compareByRank(left, right) -> int
    ordering: lower_rank_means_smaller | higher_rank_means_smaller
  predicate_methods:
    - isAtLeast
    - isAtMost
    - isHigherThan
    - isLowerThan
  equality_policy: compare_by_code_then_rank
  unknown_value_policy: reject | map_to_unknown_lowest | map_to_unknown_highest
  sample_code: optional
```

若用户只给出有序值列表但未给 rank，必须从顺序推断 provisional rank，并把该推断写入 `pending_validations[]`。

### Flag enum values
`flag` 类型 bit value 必须是 2 的幂，或明确改用 `Set<Enum>`。

### i18n namespace
用户可见 enum 使用 `enum.<domain>.<name>.<code>` 命名空间，避免与 `validation.*` 或 `error.*` 冲突。

### Lifecycle
deprecated value 必须有 replacement 或兼容读取策略。

### Single responsibility
不要把状态、错误码、权限和展示大对象塞进同一个 enum。

## Execution workflow / 执行流程
1. 识别闭集、开放集和 source of truth。
2. 选择 enum_kind 并分离混型值域。
3. 分配稳定 code、wire/db mapping 和 i18n key。
4. 生成生命周期规则、deprecated/replacement 和 unknown fallback。
5. 对齐 DTO、validator、SQL、exception 的引用需求。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。

## Tech stack adapter / 多语言适配层
java: enum + @JsonValue + fromCode; typescript: const enum/as const union; python: enum.Enum/str enum; go: typed const + stringer-style helpers.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- enum_kind 已标注
- code 唯一且稳定
- 未使用 ordinal 持久化
- i18n namespace 隔离
- deprecated 有替代或兼容策略
- flag 值为 2 的幂
- ordered 有比较语义
- 开放集合未被枚举化

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: enum-definition-generation` 与运行时 `producer_skill: enum-definition-generation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）
