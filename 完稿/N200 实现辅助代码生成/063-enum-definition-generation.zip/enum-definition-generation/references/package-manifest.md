# Skill Package Manifest

skill: enum-definition-generation
artifact_package_version: v8-content-id-decoupling
contract_schema_version: n200.artifact.v2
verification_checklist: n200-v4-verification.md
source_base: n200_v7_light_governance_fix
status: content_identity_decoupled_and_repackaged

external_files_policy: no_external_constraint_files
source_of_truth: skill_package_internal_files

shared_asset_policy: shared_assets_must_remain_identical_across_all_six_n200_skills

## Distribution metadata

skill_identity: enum-definition-generation
archive_position: 063
archive_filename: 063-enum-definition-generation.zip
archive_position_note: non_authoritative_distribution_hint_only
