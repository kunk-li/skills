# Output template: enum definitions

Start every response with `artifact_contract`, `self_gate`, and `produced_event`.

## Required sections

0. `quality_self_score`

1. `enum_kind_policy`
2. `enum_catalog[]`
3. `wire_and_db_mapping`
4. `state_transition_notes`
5. `i18n_bundle`
6. `lifecycle_compatibility_rules`
7. `anti_pattern_detection`
8. `tech_stack_adapter`
9. `downstream_handoff`

## Java example pattern

```java
public enum OrderStatus {
    PENDING("PENDING", 10),
    APPROVED("APPROVED", 20);

    private final String code;
    private final int rank;

    @JsonValue
    public String getCode() { return code; }
}
```

## Boundary rules

- Do not force open-ended data into enums.
- Do not persist or serialize enum ordinal.
- Use `enum.*` i18n namespace for user-facing values.

## Quality self-score block

Use `references/scoring-rubric.md`. Score each dimension from 0 to 2, then assign `overall_level: S | A | B | C`. Do not hide weak dimensions; list improvement notes.
