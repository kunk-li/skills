# Enum 交付检查清单 v2.4

## 基础完整性 (must-pass)

- [ ] 只对稳定闭集生成 enum；开放集合改用 String + lookup table
- [ ] 枚举值与上游 contract / DDL check / 业务规则一致
- [ ] 枚举类型语义清晰：Status / Type / Category / ErrorCode 不混装
- [ ] 类名以 Type 结尾（OrderStatus 不是 Order_status）
- [ ] 枚举值常量使用 SCREAMING_SNAKE_CASE
- [ ] 含 `@Schema(description=...)` 或类级 javadoc 说明用途

## 状态机型 enum (must-pass when applicable)

- [ ] 含合法转换图（在类级 javadoc 或独立 transition() 方法）
- [ ] 终态明确标识 (`isTerminal()`)
- [ ] 非法转换抛 IllegalStateTransitionException 而非静默失败
- [ ] 含 `transitionsTo()` 或 `canTransitionTo(target)` 查询方法

## 序列化与持久化 (must-pass)

- [ ] DB 持久化使用 ordinal() 还是 name() 已明确（推荐 name() + @Enumerated(EnumType.STRING)）
- [ ] JSON 序列化使用 name 还是 code 已明确（@JsonValue / @JsonCreator）
- [ ] 反序列化容错：未知 enum 值是抛异常还是用默认值
- [ ] 如果有 `code` 字段（用于 DB / API），反查方法 `fromCode()` 已实现

## ErrorCode 专项 (must-pass when applicable)

- [ ] error_code 格式统一（如 `MOD-NNNN`）
- [ ] 含 `httpStatus` 字段映射到 4xx/5xx
- [ ] 含 `messageKey` 用于 i18n
- [ ] 与 `错误码清单.csv` 一一对应；新增不在清单中的进 pending[]

## 演进与兼容 (recommended)

- [ ] 新增枚举值标 `@Since(version)`；删除走 deprecation cycle
- [ ] 重命名时保留旧 name 作为 alias（用于 DB 已有数据兼容）
- [ ] enum value 顺序变更影响 ordinal 持久化的，标 `breaking_change`

## 输出禁止项 (must-not)

- [ ] enum 不含可变字段（final 字段除外）
- [ ] enum 不含业务计算方法（如 `calculatePrice()`）
- [ ] enum 不含数据库连接、HTTP 调用等 IO

## 跨 skill 协作 (recommended)

- [ ] 被 dto-vo-generation 引用的 enum 标 `consumed_by_dto: true`
- [ ] 被 controller / service 引用的 enum 不重复定义
- [ ] 输出 `downstream_handoff` 标识 N190 / N210 / N240 消费点
