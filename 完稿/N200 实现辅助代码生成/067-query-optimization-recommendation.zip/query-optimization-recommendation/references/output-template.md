# Output template: query optimization recommendation

Start every response with `artifact_contract`, `self_gate`, and `produced_event`.

## Required sections

0. `quality_self_score`

1. `bottleneck_summary`
2. `evidence_profile_notes`
3. `explain_analysis[]`
4. `n_plus_one_detection[]`
5. `covering_index_analysis`
6. `index_recommendations[]`
7. `pagination_analysis`
8. `rewrite_candidates[]`
9. `cache_recommendation_optional`
10. `performance_baseline`
11. `tech_stack_adapter`
12. `downstream_handoff`

## Required behavior

- Without real EXPLAIN, use `evidence_profile: heuristic_only`.
- For every index recommendation, include benefit, write cost, redundancy risk, and validation step.
- SQL rewrite feedback to `sql-draft-generation` must respect `max_rewrite_iteration: 2`.

## Boundary rules

- Do not claim benchmark results that were not provided.
- Do not treat advisory output as DBA approval.
- Cache recommendations are optional candidates, not architecture decisions.

## Quality self-score block

Use `references/scoring-rubric.md`. Score each dimension from 0 to 2, then assign `overall_level: S | A | B | C`. Do not hide weak dimensions; list improvement notes.
