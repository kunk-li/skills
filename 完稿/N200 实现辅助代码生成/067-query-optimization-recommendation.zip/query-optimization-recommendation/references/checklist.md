# Query Optimization 交付检查清单 v2.4

## 查询识别 (must-pass)

- [ ] 列出所有受影响的 SQL（含 file:line + method 上下文）
- [ ] 每条 SQL 标当前 EXPLAIN 输出（含 type / rows / key）
- [ ] 标识查询类型：point query / range scan / aggregation / join
- [ ] 标识查询频率（hot / warm / cold）以决定优化优先级

## 优化建议 (must-pass)

- [ ] 每条建议含 before SQL + after SQL（diff 风格）
- [ ] 建议含预估收益（rows 减少倍数 / 时间从 X ms 到 Y ms）
- [ ] 建议含改动成本（仅查询改写 / 加索引 / 改 schema）
- [ ] 建议按 ROI（收益/成本）排序

## 索引建议 (must-pass when applicable)

- [ ] 索引建议含：表名 + 字段顺序 + index type (btree/hash/gin)
- [ ] 复合索引列顺序符合查询的最左前缀
- [ ] 索引大小估算 + 写性能影响评估
- [ ] 检查是否已有 redundant index 可以删除

## N+1 问题专项 (must-pass when applicable)

- [ ] 检测 lazy loading 触发的 N+1（典型 @OneToMany）
- [ ] 推荐方案：@EntityGraph / JOIN FETCH / batch_size hint
- [ ] 给出 trade-off：fetch graph 增加内存消耗

## 分页 (recommended)

- [ ] 大 OFFSET 分页（OFFSET > 1000）建议改为 keyset pagination
- [ ] 含 keyset 实现示例（WHERE created_at < :last AND id < :last_id）
- [ ] 列表 + count 分页给出 caching count 建议

## 数据库特性 (recommended)

- [ ] 推荐物化视图 / 部分索引（partial index）适用场景
- [ ] 标识可用 covering index 的查询
- [ ] PostgreSQL 项目识别 BRIN / GiST / GIN 适用场景
- [ ] MySQL 项目识别 prefix index / fulltext / spatial

## 测试与验证 (recommended)

- [ ] 提供测试 SQL 验证优化效果（含 sample data setup）
- [ ] 推荐 EXPLAIN ANALYZE 时机
- [ ] 标识压测场景（QPS / 数据量级）

## 风险控制 (must-pass)

- [ ] 索引添加在大表（>100万行）标 `requires_online_ddl: true`
- [ ] 查询改写改变结果集（如 LEFT JOIN -> INNER JOIN）显式 warning
- [ ] 不推荐 force index hint 除非确认 optimizer 持续选错

## 输出禁止项 (must-not)

- [ ] 不推荐"删除索引提升写性能"除非确认索引未被使用
- [ ] 不推荐"加 SELECT FOR UPDATE"除非确认事务边界正确
- [ ] 不推荐 NoSQL 替代关系型查询（那是架构改造，不是 query 优化）

## 跨 skill 协作 (recommended)

- [ ] 与 sql-draft-generation 的 required_indexes[] 一致
- [ ] 与 N190 repository-draft-generation 的 method 一一对应
- [ ] 与 N210 thread-safety-risk-check 的事务边界协调
