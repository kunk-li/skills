---
name: query-optimization-recommendation
description: Analyze slow queries from SQL, EXPLAIN plans, and repository methods — N+1 detection, index strategy, non-sargable rewrites, deep-pagination (OFFSET) fixes, covering indexes, before/after examples.
---
# query-optimization-recommendation

## Role / 角色定位
生成查询优化分析与交接建议。单独使用时可从 SQL、EXPLAIN、慢查询或 repository 模式分析瓶颈；在 N200 内负责交付 `查询优化建议.md`，向 SQL、repository、测试和文档提供可验证的优化候选。

它是 `analysis_with_direct_handoff` 型技能：单个 skill 必须通用、可独立执行；多个 N200 skills 组合时必须通过契约增强，而不是互相硬绑定。

## Workflow anchors / 工作流锚点

```yaml
function_bias: analysis_with_direct_handoff
workflow_node: N200
node_artifact_target: 查询优化建议.md
node_artifact_role: advisory query optimization report
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
```

这些锚点只用于 N200 编排和治理。单独使用本 skill 时仍以用户提供的最小输入和当前 selected_mode 为准。

## 使用场景 / When to use

**直接触发（standalone）：**
- 粘贴一段 SQL 查询，要求分析性能或改写
- 提供 EXPLAIN 输出，要求解读瓶颈
- 提到"接口很慢"、"查询超时"、"N+1 问题"
- 要求设计分页方案或索引策略

**工作流触发（N200 节点）：**
- `表结构设计草案.sql` + `接口设计草案.yaml` 已完成，进入 Repository 层查询优化
- `repository-draft-generation` 输出包含复杂 JOIN 或 OFFSET 分页时

**不触发（边界外）：**
- 请求 DDL 创建或迁移脚本 → 使用 `sql-draft-generation`
- 请求 ORM 实体类生成 → 使用 `repository-draft-generation`

## Boundary / 边界
- 负责 EXPLAIN 分析、N+1 检测、索引建议、分页策略、SQL rewrite 候选和有限缓存建议。
- 缓存建议属于 optional extension；涉及架构级缓存时应移交 N170/N300，不在本 skill 内直接定案。
- 不替代生产压测、DBA 审批或真实容量评估。
- 没有 EXPLAIN 时只能做 heuristic analysis，不能伪装成实测结论。

## Selected mode / 模式选择
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许模式：
- `single_query`：针对一条 SQL 深度分析。
- `explain_mode`：以 EXPLAIN/ANALYZE 为主做瓶颈分析。
- `batch_scan`：批量扫描 repository/query patterns。
- `post_incident`：慢查询告警后专项分析。
- `migration_prep`：迁移前性能基线与风险评估。


## Readiness 决策表

本 skill 支持的 readiness 取值：

- readiness: pass
- readiness: provisional
- readiness: constrained
- readiness: blocked

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | SQL 列表 + EXPLAIN 输出 + 数据量级 + 业务热度 全部齐备 | 完整优化建议 + 索引建议 + 预估收益 |
| `provisional` | SQL 齐备但缺 EXPLAIN（无法执行测试环境） | 输出基于 schema 的静态建议，dynamic 部分进 pending_explain[] |
| `constrained` | 仅有 SQL 文本，缺数据量级 + 业务热度 | 输出通用优化模式建议（如 N+1、SELECT *），优先级保守 |
| `blocked` | 仅有"性能差"但无具体 SQL | 输出 `request_for_inputs[]` |

**特别提示**：
- 缺 query 频率信息 → `constrained`（无法决定 ROI）
- 缺生产数据量级估算 → `provisional`（建议保守）
- 缺数据库版本 / dialect → `constrained`

## Inputs / 输入分级
### core_required / 最小可执行输入
- `query_sql`、`explain_plan`、`repository_method`、`slow_query_sample` 或 `query_pattern` 任一项即可作为最小输入。

### workflow_enrichment / N200 推荐增强输入
- `接口设计草案.yaml` from n150
- `业务规则清单.csv` from n070
- `错误码清单.csv` from n150
- `表结构设计草案.sql` from n160

### optional_enrichment / 可选增强输入
- `tables` / `indexes`
- `performance_designs`
- ORM mappings / traces
- row counts and cardinality
- SQL drafts from `sql-draft-generation`
- production metrics or latency baseline

## Standalone rule / 独立使用规则
即使只有一个 core input，也可以单独使用本 skill。缺失其他输入时：

- 不阻塞输出，但必须把 `readiness` 降为 `provisional` 或 `constrained`。
- 必须写出 `assumptions[]`、`pending_decisions[]`、`pending_validations[]` 和 `drift_watchlist[]`。
- 不得把启发式建议伪装成已验证结论。


## Required v2 reactive output blocks / 必需 v2 输出块
每次输出必须先给出以下结构，再进入 skill-specific 内容：

```yaml
artifact_contract:
  schema_version: n200.artifact.v2
  producer_skill: query-optimization-recommendation
  producer_node: N200
  artifact_name: 查询优化建议.md
  artifact_type: analysis_report
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N210, N330]

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending_decisions: []
  drift_watchlist: []

produced_event:
  event_type: produced.N200.查询优化建议
  contract_version: n200.artifact.v2
  artifact_ref: 查询优化建议.md
  emitted_for: [N210, N330, N390]


quality_self_score:
  rubric_version: n200.skill_quality.v1
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
  improvement_notes: []
```

## Uncertainty management / 不确定性管理
必须恢复并显式输出 v1 的不确定性字段：

- `readiness`: `pass`、`provisional`、`constrained`、`blocked`。
- `evidence_profile`: `direct_contract`、`inferred_from_schema`、`heuristic_only`、`mixed`。
- `assumptions[]`: 明确假设。
- `pending_decisions[]`: 需要用户、DBA、架构师或研发确认的事项。
- `pending_validations[]`: 需要真实编译、EXPLAIN、staging、测试或审批验证的事项。
- `drift_watchlist[]`: 与 API、DB、DTO、enum、validator、exception 或文档可能漂移的点。

不要在输入不足时假装 final。输出可以有用，但必须让不确定性可见。


## Skill-specific output sections / 专属输出结构
除公共契约块外，结果至少包含：

- `quality_self_score`
- `versioning_status`

`versioning_status` 至少包含：

```yaml
versioning_status:
  contract_schema_version: n200.artifact.v2
  verification_checklist: n200-v4-verification.md
  artifact_package_version: v8-content-id-decoupling
  implementation_delta: content_identity_decoupled_from_archive_position
  external_files_policy: no_external_constraint_files
  source_of_truth: skill_package_internal_files
```


- `bottleneck_summary`
- `evidence_profile_notes`
- `explain_analysis[]`
- `n_plus_one_detection[]`
- `covering_index_analysis`
- `index_recommendations[]`
- `pagination_analysis`
- `rewrite_candidates[]`
- `cache_recommendation_optional`
- `performance_baseline`
- `tech_stack_adapter`
- `downstream_handoff`

## Design rules / 设计规则
### Evidence labeling
没有真实 EXPLAIN/ANALYZE 时不 reject；允许输出，但必须标注 `evidence_profile: heuristic_only` 并列 `pending_validations[]`。

### Explain required when available
用户提供执行计划时必须解析；不要忽略 key/type/rows/extra 或 seq scan/sort 等信号。

### N+1 detection
检查循环查询、lazy loading、序列化触发查询、batch size 缺失。

### Index advice tradeoff
每条索引建议都必须写目标查询、收益、写入代价、冗余风险和是否需 DBA review。

### Deep pagination
OFFSET 大或游标缺失时评估 keyset/cursor pagination。

### SELECT star and function-on-column
识别 SELECT *、函数包索引列、隐式转换、前导通配 LIKE、大 IN 等问题。

### Rewrite loop fuse
回写 SQL 建议时必须受 `max_rewrite_iteration: 2` 限制。

### Caching boundary
缓存建议只作为候选，并且必须输出到 `cache_recommendation_optional`；架构级缓存、缓存一致性、失效策略和容量决策交给 N170/N300。不得把 cache key、TTL 或 invalidation 写成最终落地方案，除非用户明确提供架构约束和线上验证证据。

### Advisory output discipline
本 skill 的 `function_bias` 固定为 `analysis_with_direct_handoff`。除非用户提供真实 EXPLAIN/ANALYZE、索引定义和容量基线，否则不要把优化候选写成最终落地方案；输出应以候选、证据、风险、验证计划和 handoff 为主。


## Distributed and emerging query optimization

### Distributed query patterns
When evidence of distributed data access is present (cross-DB joins, ShardingSphere config, federated queries):

```yaml
distributed_query_analysis:
  pattern: cross_shard_join | federated_query | cross_db_transaction
  finding: "Cross-shard ORDER BY without shard key causes full scatter query"
  severity: high
  recommendation: "Add shard key to WHERE clause; or denormalize into single shard"
  validation_required: true
  evidence_profile: heuristic_only   # Without actual execution plan from sharding layer
```

Scope boundary: This skill provides advisory analysis only. Sharding strategy decisions belong to N140/N170. Do not recommend specific shard counts or rebalancing plans.

### Vector / embedding search optimization (optional extension)
When embedding similarity search patterns are detected (pgvector `<->` operator, Elasticsearch kNN, Milvus queries):

```yaml
vector_search_hints:
  - pattern: "pgvector cosine similarity without IVFFlat/HNSW index"
    severity: high
    recommendation: "Create IVFFlat or HNSW index for approximate nearest-neighbor search"
    pending_validation: "Measure recall@10 vs exact search before applying"
  - pattern: "Full-table embedding scan with no pre-filter"
    severity: medium
    recommendation: "Apply metadata pre-filter (WHERE category = ?) before vector similarity"
```

These findings go into `cache_recommendation_optional` with `scope: vector_search` to distinguish from SQL cache recommendations. Full vector index design belongs to N170.

## Execution workflow / 执行流程
1. 识别输入证据级别和 selected_mode。
2. 归类瓶颈：全表扫、filesort、临时表、N+1、深分页、索引不匹配等。
3. 输出 explain_analysis、n_plus_one_detection、pagination_analysis。
4. 给出 rewrite、index、cache optional 和验证计划。
5. 把 SQL rewrite 回传给 sql-draft-generation，但受 node-level fuse 限制。
6. 输出 artifact_contract、self_gate、produced_event 和 downstream_handoff。

## Tech stack adapter / 多语言适配层
java: jpa/hibernate query count and fetch plans; typescript/node: typeorm/prisma explain hooks; python: sqlalchemy query plans; db: mysql/postgres/oracle/sql server explain patterns.

默认输出可以使用 Java 示例，但不要把 Java-only 方案当成唯一正确方案。若用户上下文显示是 TypeScript、Python、Go 或其他技术栈，必须切换到对应 adapter。

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`（若输出契约中包含该字段）：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可产出可用结果 | 依赖推荐输入才可用 | 输入不足时直接 blocked |
| `contract_completeness` | 所有必填字段填写，无 null 遗漏 | 大部分字段填写 | 超过 30% 必填字段为 null |
| `uncertainty_handling` | 推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明内容 |
| `downstream_handoff` | 下游消费字段精确命名，可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。

## Machine-readable self_check rules

- `R01_artifact_contract_first`: 每次输出必须以 `artifact_contract` YAML 块开头; `on_violation: reject`
- `R02_readiness_set`: `readiness` 必须是 `pass | provisional | constrained | blocked` 之一; `on_violation: reject`
- `R03_evidence_profile_set`: 无真实 EXPLAIN/ANALYZE 时必须设 `evidence_profile: heuristic_only`; `on_violation: reject`
- `R04_explain_parsed_when_provided`: 用户提供执行计划时必须解析 key/type/rows/extra 等信号; `on_violation: reject`
- `R05_n_plus_one_checked`: 必须输出 `n_plus_one_detection[]`（可为空列表但必须存在）; `on_violation: warn`
- `R06_index_advice_has_tradeoff`: 每条索引建议必须包含写入代价和冗余风险; `on_violation: warn`
- `R07_cache_boundary_respected`: 缓存建议只能进 `cache_recommendation_optional`；架构级缓存必须标 `escalation: N170`; `on_violation: reject`
- `R08_rewrite_iteration_limited`: SQL rewrite 循环不得超过 `max_rewrite_iteration: 2`; `on_violation: reject`
- `R09_pending_validations_listed`: 所有需实测验证的结论必须进 `pending_validations[]`; `on_violation: warn`
- `R10_downstream_handoff_present`: 必须输出 `downstream_handoff`; `on_violation: reject`

## Cross-skill drift enforcement

N200 节点内多 skill 组合时，以下漂移必须在 `self_gate` 阶段拦截（而非静默通过）：

| 漂移类型 | 检测点 | 严重度 |
|---|---|---|
| Enum code 不一致 | `enum-definition-generation` 输出 vs DTO 字段 enum 值 | high |
| ErrorCode 孤儿 | `exception-class-generation` 输出的 ErrorCode 未在 DTO error response 中映射 | medium |
| Nullable 不一致 | `validator-code-generation` `@NonNull` vs `dto-vo-generation` `null_handling_policy` | high |
| SQL column 类型漂移 | `sql-draft-generation` DDL 列类型 vs DTO 字段 Java 类型 | medium |
| Validator-DTO 解耦失败 | validator 直接引用 DTO 内部字段而非通过接口 | low |

发现漂移时：优先写入 `drift_watchlist[]`；blocking 漂移（high 及以上）必须同时进入 `self_gate.failed_rules[]`，将 `self_gate.status` 设为 `block`。

## Common failure modes

1. **无 EXPLAIN 时伪装实测** — 仅凭代码审查声称"此查询存在全表扫描"，未标注 `evidence_profile: heuristic_only`，误导开发者认为是已验证结论。修复：无真实 EXPLAIN/ANALYZE 时必须设 `evidence_profile: heuristic_only` 并在 `pending_validations[]` 中要求补充执行计划。
2. **缓存越界定案** — 在 `cache_recommendation_optional` 中给出了具体的 Redis key 设计、TTL 和失效策略，越过了本 skill 的 advisory 边界，冲突于 N170/N300 的架构决定。修复：缓存建议只输出候选和驱动因素；架构级缓存（key schema/TTL/invalidation）必须标 `escalation: N170` 并列入 `pending_decisions[]`。
3. **Rewrite 无限循环** — 查询改写与 `sql-draft-generation` 之间来回修改超过 2 次，消耗大量 context 且结果发散。修复：严格遵守 `max_rewrite_iteration: 2`；第 2 次迭代后若仍无法收敛，在 `drift_watchlist[]` 中标注分歧并停止改写。

## N200 composition rules / 节点内组合规则
- 遵循 `references/n200-v2-contract.md` 和 `references/n200-collaboration-matrix.md`。
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- 组合顺序优先为：`enum -> exception -> dto -> validator -> sql -> query-optimization`。
- sibling dependency 只用于增强，不得让本 skill 失去独立执行能力。
- query-opt 回写 sql 的循环必须遵守 `max_rewrite_iteration: 2`。
- 跨 skill 冲突必须进入 `drift_watchlist[]`，不得静默覆盖。

## Self check / 自检清单
- evidence_profile 明确
- 无 EXPLAIN 时标 heuristic_only
- N+1 已检查
- 全表扫/深分页/SELECT * 已识别
- 索引建议有代价和 DBA 风险
- 缓存建议未越界定案
- rewrite loop 受限
- pending_validations 已列出

## Quality bar / 质量门槛
合格结果应满足：单独看能被用户直接使用；放入 N200 节点内能被 N210 静态检查、N330 文档输出和 N390 治理审计消费；输入不足时仍能安全降级并暴露不确定性。

### Artifact packaging constraint / skill 内约束
- 不依赖 skill 包外的报告、校验文件、SHA 文件、总包说明或外部治理文档作为执行约束。
- 本 skill 的约束源只允许是当前 skill 包内的 `SKILL.md` 与 `references/` 文件。
- 后续优化本 skill 时，不生成独立于 skill 包之外的交付说明、校验报告、hash 清单或额外约束文件，除非用户明确要求。
- 任何新增约束、验收规则、版本规则、协作规则、维护规则，都必须内嵌到 `SKILL.md` 或当前 skill 自己的 `references/` 中。
- 如果外层 bundle 仅用于传输，bundle 元数据不作为权威约束；以每个 skill 包内的 `package-manifest.md` 与本 `SKILL.md` 为准。
- 对话中针对当前已发布版本的分析报告只能作为历史参考，不能替代本 skill 包内的可执行约束。
- 对话中产生的改进建议可以作为下一轮修订输入；只有当该建议被写入本 `SKILL.md`、当前 skill 自己的 `references/`，并通过 `package-manifest.md` 升级后，才成为本 skill 的执行约束。
- 归档序号、zip 文件名前缀、UI 排序和外层传输顺序都只是分发层提示，不能成为本 skill 的内容身份。
- 本 skill 的稳定身份是 `name: query-optimization-recommendation` 与运行时 `producer_skill: query-optimization-recommendation`；不要在执行约束、artifact_contract 或协作规则中使用数字序号作为身份。

## Reference files / 参考文件
- `references/query-opt-algorithms.yaml`: mode 选择决策表、readiness 决策规则、不确定性处理规范
- `references/query-opt-self-check.yaml`: R01-R10 机读门禁规则
- `references/query-opt-input-contract.yaml`: 三级输入分类与降级矩阵（含纯文字/部分输入场景）
- `references/n200-v2-contract.md`
- `references/n200-v4-verification.md`
- `references/n200-contract-versioning.md`
- `references/n200-v5-change-log.md`
- `references/package-manifest.md`
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/example-io.md`
- `references/orchestration.md`
- `references/readiness-inheritance.md`
- `references/scoring-rubric.md`
- `references/n200-collaboration-matrix.md`
- `references/n200-java-conventions.md` （如存在）
