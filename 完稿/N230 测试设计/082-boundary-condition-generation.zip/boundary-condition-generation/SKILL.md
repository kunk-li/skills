---
name: boundary-condition-generation
description: generate workflow-aligned boundary-condition coverage from acceptance criteria, requirement structure, schemas, and testcase context. use when chatgpt works in testing & qa / test design and must produce the workflow-aligned boundary artifact for n230 to protect thresholds, limits, combinations, and environment edges before automation or gate review.
---
# boundary-condition-generation

## Role / role positioning
This skill aligns to testing & qa -> test design -> 边界条件清单.csv. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on thresholds, extremes, paradox values, and combinational edge coverage.
- Extend core scenarios with edge cases; do not replace full executable testcases.
- Do not drift into generic performance planning or chaos orchestration unless the edge itself is the verified boundary.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `numeric_only`: focus on numeric, precision, and threshold boundaries.
- `text_only`: focus on strings, encoding, and input-shape limits.
- `full_spectrum`: cover all relevant boundary kinds including environment and combinations.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `测试点清单.csv`
- `测试用例集.xlsx`
- `接口设计草案.yaml`
- `表结构设计草案.sql`
- `业务规则清单.csv`
- threshold configs, limit tables, rate-limit definitions, or data dictionaries

## Standalone rule / standalone usage
This skill must still work on one field, one threshold rule, or one operation.

Degradation rules:
- If schema or field constraints are missing, emit only confirmed boundary families and tag missing thresholds as `pending_limit_definition`.
- If testcase context is absent, reference the target object or acceptance criterion directly.
- If combinational coverage would explode, prefer pairwise or representative combinations and state the reduction logic.
- Keep the output shape stable even when only one boundary family is known.

## Core output contract / core output contract
Default to csv-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.boundary_condition_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 边界条件清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `boundary_summary`
- `boundary_items[]`
- `combination_plan[]`
- `env_boundary_notes[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every boundary item must declare one `boundary_kind` from `references/boundary-kind-taxonomy.md`.
- Cover both `valid-but-fragile` and `invalid-but-plausible` edge values when the domain supports them.
- Include paradox cases where reasonable values are often rejected or bad values often slip through.
- Use pairwise or focused combination logic from `references/combinatorial-guidance.md` instead of brute-force explosion.
- Add environment boundaries only when the feature truly depends on time, capacity, concurrency, or resource ceilings.

## Execution workflow / execution workflow
1. Read requirements, testcase context, and limit definitions.
2. Identify boundary-bearing fields, states, and environment constraints.
3. Expand them by boundary kind and edge-value catalog.
4. Add combination candidates where cross-field extremes matter.
5. Normalize traceability back to rules, acceptance criteria, or testcase ids.
6. Emit handoff notes for automation and gate review.

## Dynamic completeness / dynamic completeness
- Small scope: enumerate direct min/max/empty/default cases.
- Medium scope: add paradox values and selected combinations.
- Large scope: group by object or field family and explicitly document reduction strategy.
- If environment boundaries are material, show them separately from pure input-field boundaries.

## Quality bar / quality bar
A good result should prevent easy-to-miss production defects around thresholds, precision, rare encodings, or resource limits. The artifact must be specific enough that downstream teams can automate or manually verify the edge behavior without guessing which values matter.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/boundary-kind-taxonomy.md`
- `references/combinatorial-guidance.md`
- `references/n230-integration-map.md`

## v2 optimization addendum / boundary-depth contract
Use this addendum as the controlling rule when it conflicts with older lightweight fields.

### Universal-first positioning
This skill must remain useful outside N230. Treat `workflow_node: N230` as an adapter tag, not as a hard dependency. It may start from a field rule, DTO/schema constraint, API parameter, state rule, rate limit, production defect, or a TP/TC link.

### V2 required upgrades
- Emit `contract_version: n230.test-design-artifact.v2` in metadata.
- Emit canonical `boundary_id`, while accepting legacy `bc_id` as an alias.
- Use BK01-BK10 `boundary_kind` values from `references/boundary-kind-taxonomy.md`.
- Always distinguish `null`, empty, blank, missing, zero, and default values when relevant.
- Treat off-by-one as a required specialty for count, index, size, page, limit, and inclusive/exclusive rules.
- Include `equivalence_classes` with valid and invalid representatives.
- Include temporal and i18n/security catalogs when the target field is time-sensitive or user-entered text.
- Include `event` metadata using `references/event-feedback-interface-v2.md`.

### Composition rules
- Boundary items linked to TP3 should feed data-driven rows in `test-case-generation`.
- Invalid boundary values should hand off to `exception-scenario-generation` when they require error codes, rollback, alerts, or security behavior.
- Security-sensitive strings do not always require rejection; assert safe persistence, escaping, parameterization, and no destructive side effects.
- P0 boundary gaps should set `gate_status: block` unless there is an explicit waiver.

### Node-level self-check
When multiple N230 artifacts are present, use `references/n230-node-checker-v2.md` to verify TP3 to BND coverage and BND to TC data-driven consumption.

### Updated reference files
- `references/shared-artifact-contract-v2.md`
- `references/event-feedback-interface-v2.md`
- `references/n230-node-checker-v2.md`
- `references/edge-catalogs-v2.md`

### v2.0.1 release-candidate polish
- Use `references/shared-artifact-contract-v2.md` output file defaults for exported boundary sheets.
- Use `references/edge-catalogs-v2.md` auto-boundary generation pseudo-code when schemas or explicit constraints are available.

### v2.0.2 release polish
- `references/boundary-types-matrix.md` was removed because `references/boundary-kind-taxonomy.md` is the canonical BK01-BK10 source.
- Use the contract evolution policy in `references/shared-artifact-contract-v2.md` for legacy alias and schema-change handling.

