# output template v2

## required sections
1. metadata
2. boundary_summary
3. boundary_items
4. equivalence_classes
5. off_by_one_analysis
6. temporal_boundaries
7. string_i18n_boundaries
8. combination_plan
9. downstream_handoff
10. event
11. self_check

## required columns
| boundary_id | target_object | target_field | target_rule | boundary_kind | test_values | category | expected_behavior | equivalence_class | related_tc_or_tp | gate_status | notes |
|---|---|---|---|---|---|---|---|---|---|---|---|

## expected_behavior values
- `accept`
- `reject`
- `transform`
- `error_specific_code`
- `degrade`
- `throttle`
