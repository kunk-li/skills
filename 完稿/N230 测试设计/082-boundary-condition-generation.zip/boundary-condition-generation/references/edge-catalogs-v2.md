# edge catalogs v2

Use these catalogs to avoid classic omissions.

## off-by-one catalog
- 0
- 1
- n-1
- n
- n+1
- first item
- last item
- after last item
- inclusive boundary
- exclusive boundary

## null and empty catalog
- missing field
- explicit null
- empty string
- whitespace-only string
- empty array
- empty object
- default value omitted
- default value explicitly set

## string and i18n catalog
- ascii
- unicode BMP
- supplementary-plane emoji
- right-to-left text
- combining characters
- zero-width joiner and non-joiner
- homoglyph characters
- control characters
- null byte
- long repeated grapheme clusters

## security-sensitive strings
These values do not always need rejection; often the correct behavior is accepting safely and escaping or parameterizing output.
- SQL metacharacters
- XSS-like markup
- path traversal sequences
- command separators
- CSV formula prefix
- CRLF injection characters

## temporal catalog
- one second before and after boundary
- start/end of day
- start/end of month
- start/end of year
- leap day
- DST spring-forward and fall-back
- UTC, UTC+14, UTC-12
- weekend vs weekday when business calendars matter

## decimal and money catalog
- exact scale value
- extra decimal digits
- half-up rounding edge
- half-even ambiguity
- negative zero
- very large integer part
- currency minor unit mismatch

## concurrency boundary catalog
- sequential requests
- simultaneous duplicate requests
- high-concurrency burst
- thread pool exhaustion
- DB connection pool exhaustion
- rate-limit threshold and threshold+1

## Auto boundary generation algorithm (v2.0.1)
Use this lightweight pseudo-code when constraints are present. Keep the result explainable; do not generate a Cartesian explosion.

```text
for each target_field in schema_or_rules:
  constraints = collect range, length, size, enum, regex, nullable, uniqueness, time, precision, state, and concurrency constraints
  infer boundary_kind using BK01-BK10 taxonomy

  if numeric range [min, max]:
    add min-1, min, min+1, representative_mid, max-1, max, max+1
    add null or missing when field is nullable or required semantics matter

  if length or size limit n:
    add 0, 1, n-1, n, n+1
    add null, empty, blank, and missing where semantically distinct

  if enum or state machine:
    add every valid value, invalid unknown value, wrong-case value, terminal state, initial state, and illegal transition

  if temporal:
    add one unit before boundary, exact boundary, one unit after boundary
    include day/month/year edge, leap day, DST, and timezone edge when relevant

  if decimal or money:
    add exact scale, extra precision, rounding half edge, negative zero, and currency minor-unit mismatch

  if user-entered text:
    add ascii, unicode, emoji, RTL, combining marks, zero-width, homoglyph, control chars, null byte, and security-sensitive strings

  build equivalence_classes:
    valid_classes = classes that should be accepted or safely transformed
    invalid_classes = classes that should be rejected with specific behavior

  reduce combinations:
    use pairwise for independent dimensions
    use max-min pairing for high-risk limits
    always keep P0 invalid edges and security-sensitive values
    document omitted combinations as an explicit reduction rule
```

### Generation safeguards
- Prefer 6-12 boundary rows per field by default; exceed this only for P0, security, compliance, money, or time-critical fields.
- When constraints are ambiguous, emit representative rows and mark `gate_status: warn` with `pending_limit_definition`.
- Never assume destructive security payloads must be rejected; assert safe handling, escaping, parameterization, rollback, and no data damage.

