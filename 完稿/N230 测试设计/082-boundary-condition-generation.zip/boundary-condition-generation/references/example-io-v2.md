# N230 示例输入输出 v2（扩展场景）

## 示例 3：异常场景生成（exception-scenario-generation）

### 输入
- 依赖服务：payment-gateway（外部 REST API）
- 失败注入成熟度目标：L2

### 输出
```yaml
exception_scenarios:
  - dependency: payment-gateway
    scenario: connection_timeout
    inject: delay 5000ms
    expected_behavior: retry × 3 then return 503
    idempotency_required: true
  - dependency: payment-gateway
    scenario: invalid_response_schema
    inject: return malformed JSON
    expected_behavior: parse error caught, fallback to cached price
```

## 示例 4：测试用例生成（test-case-generation）

### 输入
- 测试点：TP-001（有效登录）

### 输出
```yaml
test_case:
  tc_id: TC-001
  source_tp: TP-001
  given: 注册用户，密码正确
  when: POST /auth/login
  then:
    - HTTP 200
    - response.token 存在
    - redirect_url == /dashboard
  automation_suitability: automated
  pyramid_layer: e2e
```

## 082 扩展示例输入输出

### Example B — Multi-field combination boundary (checkout form)

**Input**: Checkout form with fields: `promo_code` (optional, 6–12 chars), `quantity` (1–99), `delivery_date` (future dates only, max +30 days).

**Output** (combination boundary mode):
```yaml
boundary_list:
  # Individual field boundaries
  - field: promo_code
    boundary_type: min_length
    value: 6
    expect: accepted
  - field: promo_code
    boundary_type: max_length
    value: 12
    expect: accepted
  - field: promo_code
    boundary_type: empty_optional
    value: ""
    expect: accepted  # optional field
  - field: quantity
    boundary_type: min
    value: 1
    expect: accepted
  - field: quantity
    boundary_type: max
    value: 99
    expect: accepted
  - field: quantity
    boundary_type: zero
    value: 0
    expect: rejected
  - field: delivery_date
    boundary_type: min_future
    value: today+1day
    expect: accepted
  - field: delivery_date
    boundary_type: max_future
    value: today+30days
    expect: accepted
  - field: delivery_date
    boundary_type: past
    value: yesterday
    expect: rejected
  # Combination boundaries (field interactions)
  - combination: [promo_code, quantity]
    boundary_type: promo_at_max_quantity
    scenario: Valid promo + quantity=99 → promo discount applies to all units
    expect: discount = promo_rate × 99
    combination_boundary_flagged: true
  - combination: [promo_code, delivery_date]
    boundary_type: promo_expired_at_max_date
    scenario: Promo valid today + delivery_date=today+30days → promo may expire before delivery
    expect: system validates promo validity at order_date not delivery_date
    combination_boundary_flagged: true
  - combination: [quantity, delivery_date]
    boundary_type: high_quantity_affects_lead_time
    scenario: quantity=99 + delivery_date=today+1day → may violate fulfilment lead time
    expect: rejected or warned by business rule
    combination_boundary_flagged: true
```


### Scenario C — Nullable optional field with combination

**Input**: `delivery_instructions` (optional, max 500 chars) + `delivery_type` enum.

**Output**:
```yaml
boundary_list:
  - field: delivery_instructions
    boundary_type: max_length
    value: 500
    expect: accepted
  - field: delivery_instructions
    boundary_type: exceeds_max
    value: 501
    expect: rejected
  - combination: [delivery_instructions, delivery_type]
    boundary_type: instructions_with_pickup
    scenario: Non-null instructions + delivery_type=pickup
    expect: accepted but instructions stored with pickup_ignored_flag
    combination_boundary_flagged: true
```

### Scenario D — Enum field boundaries

**Input**: `delivery_type` enum field with values: `standard | express | pickup | same_day`.

**Output** (enum boundary mode):
```yaml
boundary_list:
  field: delivery_type
  field_type: enum
  items:
    - boundary_type: valid_member
      value: standard
      expect: accepted
    - boundary_type: valid_member
      value: same_day
      expect: accepted
    - boundary_type: invalid_value
      value: overnight
      expect: rejected
      error_code: INVALID_DELIVERY_TYPE
    - boundary_type: empty
      value: ""
      expect: rejected
      error_code: DELIVERY_TYPE_REQUIRED
    - boundary_type: null_optional_vs_required
      value: null
      expect: rejected
      note: delivery_type is required; null not accepted
    - boundary_type: case_sensitivity
      value: Standard
      expect: rejected
      note: Enum values are case-sensitive
```

### Scenario D — Date/time boundary (timezone + DST)

**Input**: `scheduled_at` field accepting ISO-8601 datetime; scheduler runs across timezones.

**Output** (datetime boundary with DST):
```yaml
boundary_list:
  field: scheduled_at
  field_type: datetime_iso8601
  items:
    - boundary_type: dst_spring_forward
      value: "2024-03-10T02:30:00-05:00"
      expect: accepted or rejected consistently (no ambiguous time)
      note: US Eastern spring forward — 2:00–3:00 AM does not exist
    - boundary_type: dst_fall_back
      value: "2024-11-03T01:30:00-04:00"
      expect: resolved to earlier occurrence or error; must not silently duplicate
    - boundary_type: leap_second
      value: "2024-06-30T23:59:60Z"
      expect: accepted if parser supports leap seconds; rejected gracefully otherwise
    - boundary_type: far_future
      value: "9999-12-31T23:59:59Z"
      expect: accepted (system max representable datetime)
    - boundary_type: unix_epoch_zero
      value: "1970-01-01T00:00:00Z"
      expect: accepted as valid historical datetime
```
