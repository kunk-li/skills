# orchestration v2

## role
`boundary-condition-generation` extends TP and TC artifacts with edge values, equivalence classes, off-by-one coverage, time/i18n/security catalogs, and combinational reduction notes.

## standalone use
The skill may run from one field, one constraint, one API parameter, one state rule, or one production defect.

## composition
- TP3 boundary points should produce BND rows.
- BND rows should feed `test-case-generation` as data-driven tables.
- Invalid or security-sensitive BND rows should also feed `exception-scenario-generation` when expected behavior requires error mapping, rollback, alerting, or security proof.
- P0 boundary gaps should produce `gate_status: block` unless waived.

## handoff
- To N240: exact values, data table rows, environment conditions.
- To N260: threshold coverage, regulated limit coverage, off-by-one/null-empty/i18n status.
