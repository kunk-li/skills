# boundary kind taxonomy v2

Emit exactly one primary `boundary_kind` per boundary item. Legacy short labels may be kept as aliases.

| kind | alias | standard coverage |
|---|---|---|
| `BK01_numeric_range` | `numeric` | min-1, min, min+1, normal, max-1, max, max+1, negative, overflow |
| `BK02_off_by_one` | `cardinality` | 0, 1, n-1, n, n+1, inclusive vs exclusive, index 0 vs 1 |
| `BK03_empty_vs_null` | `empty_null` | null, empty string, whitespace, empty array, empty object |
| `BK04_single_vs_multiple` | `single_multiple` | 1 item, 2 items, N items, duplicate items |
| `BK05_string_length` | `string_length` | 0, 1, max-1, max, max+1, ascii, unicode, emoji, rtl, combining, zero-width |
| `BK06_collection_size` | `collection` | empty, singleton, full page, max set, max+1, duplicate, unordered |
| `BK07_time_boundary` | `temporal` | now, midnight, month/year edge, leap day, DST, timezone UTC+14/UTC-12 |
| `BK08_decimal_precision` | `precision` | exact scale, extra digits, rounding edge, negative zero, integer overflow |
| `BK09_concurrency_boundary` | `concurrency` | sequential, simultaneous, high concurrency, pool/thread exhaustion |
| `BK10_state_boundary` | `state` | initial, terminal, transition moment, rollback moment, forbidden transition |

Rules:
- Use BK02 for counts, indexes, pagination, limits, loops, offsets, and any inclusive/exclusive rule.
- Use BK03 whenever null, empty, blank, missing, or default values may differ.
- Use BK05 for user-entered text even when there is no explicit i18n requirement.
- Use BK07 whenever dates, time windows, timezones, expirations, or deadlines exist.
