# Semantic boundary-to-test trace

Use this check when boundary artifacts are composed with test cases or when a boundary claims downstream test coverage.

## Match contract

For each boundary-to-TC link, compare the boundary's target object, target field, and concrete edge condition with the TC's fixture, action, and observable assertions. A TC earns direct coverage credit only when the action reaches that object and the assertion distinguishes the boundary value or state.

Record one relation type for each edge:

- `covers_boundary`: same object, field, and edge condition are exercised; may count as direct coverage.
- `parent_test_point`: source/coverage context only; does not count as direct boundary coverage.
- `positive_control`: proves the adjacent valid edge; does not replace the negative/boundary edge.
- `control_only`: idempotency, delivery, or other control behavior; no direct credit for this boundary.
- `supporting_constraint`: related schema or shared constraint evidence that does not execute this boundary.
- `not_coverage`: the object, field, or condition does not match; record why and remove it from the coverage set.

Do not infer semantic equivalence from IDs, shared feature names, generic uniqueness, or a common parent TP. For a multi-part identity boundary, list which dimensions each TC exercises; a case that varies workflow id while keeping no attempt field does not cover a stale-attempt edge.

## Uncovered conditions and handoff

When no TC directly covers an edge, preserve the exact boundary values and expected source behavior, mark direct coverage missing, and hand the case to 081. Keep the boundary artifact blocked until the relevant case and any required execution evidence exist. This is traceability analysis, not proof that the code or test passed.
