# field contract v2 for boundary-condition-generation

Use this file with `shared-artifact-contract-v2.md`.

| field | requirement |
|---|---|
| `boundary_id` | canonical `BND-{DOMAIN}-{NNN}` id; `bc_id` accepted as alias |
| `target_object` | feature, API, DTO, table, state, or resource |
| `target_field` | field, parameter, state, count, time window, or resource |
| `target_rule` | rule or constraint reference when available |
| `boundary_kind` | BK01-BK10 from `boundary-kind-taxonomy.md` |
| `test_values` | exact values with expected behavior and rationale |
| `category` | `valid_edge`, `invalid_edge`, or `transition` |
| `equivalence_classes` | valid and invalid classes with representative values |
| `off_by_one_analysis` | required for counts, index, pagination, ranges, and sizes |
| `temporal_boundaries` | required for time-sensitive behavior |
| `string_i18n_boundaries` | required for user-entered text |
| `related_tc_or_tp` | linked TP, TC, AC, rule, or API ids |
| `gate_status` | pass, warn, or block |
