# field contract v2 for boundary-condition-generation

Use this file with `shared-artifact-contract-v2.md`.

| field | requirement |
|---|---|
| `boundary_id` | canonical `BND-{DOMAIN}-{NNN}` id; `bc_id` accepted as alias |
| `target_object` | feature, API, DTO, table, state, or resource |
| `target_field` | field, parameter, state, count, time window, or resource |
| `target_rule` | rule or constraint reference when available |
| `boundary_kind` | BK01-BK10 from `boundary-kind-taxonomy.md` |
| `test_values` | exact values with expected behavior and rationale |
| `category` | `valid_edge`, `invalid_edge`, or `transition` |
| `equivalence_classes` | valid and invalid classes with representative values |
| `off_by_one_analysis` | required for counts, index, pagination, ranges, and sizes |
| `temporal_boundaries` | required for time-sensitive behavior |
| `string_i18n_boundaries` | required for user-entered text |
| `related_tc_or_tp` | linked TP, TC, AC, rule, or API ids; claimed coverage must align semantically to this boundary, with relation role recorded in `traceability_links[]` |
| `gate_status` | pass, warn, or block |

## Semantic testcase trace

For each linked TC, record `relation_type` and whether it receives direct coverage credit. A parent TP, a delivery-idempotency control, or a schema test for another object may remain useful context but does not prove this boundary. See `semantic-boundary-test-trace.md`.

## Temporal boundary tuple

Each item in `temporal_boundaries` must retain the source rule's dimensions when present:

| field | requirement |
|---|---|
| `source_rule_ref` | source requirement/business-rule identifier or exact source location |
| `anchor` | event or timestamp from which the rule is measured |
| `quantity` + `unit` | numeric value and source unit (for example, 30 calendar days or 5 business days) |
| `interval_kind` | `deadline_offset`, `elapsed_age`, `validity_window`, or `rolling_duration` when supported by the source |
| `calendar_basis` | `calendar_days`, named business calendar, `calendar_months`, or `not_specified` |
| `comparator` + `inclusive` | exact relation such as `gte` and whether the boundary is included |
| `source_conflict_refs` | derived artifacts that disagree; empty when none |

Do not substitute an inferred unit or anchor for an unspecified source dimension. Mark the boundary unresolved and add a coverage gap.
