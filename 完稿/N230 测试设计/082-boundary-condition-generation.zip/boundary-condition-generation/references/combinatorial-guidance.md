# combinatorial guidance v2

Use combinations selectively:
- pairwise for most multi-field boundaries
- max-min combinations for high-risk numeric or temporal pairs
- null-plus-value when one field is optional and another has a limit
- valid-edge plus invalid-edge for each mandatory field family
- avoid full-cartesian explosion unless the scope is tiny

When reducing coverage, explain:
- selected pair or family
- omitted combinations
- why omitted combinations are lower risk
- which N240 or manual tests should cover the remaining risk if needed
