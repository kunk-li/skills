---
name: boundary-condition-generation
description: generate workflow-aligned boundary-condition coverage from acceptance criteria, requirement structure, schemas, and testcase context. use when Claude works in testing & qa / test design and must produce the workflow-aligned boundary artifact for N230 to protect thresholds, limits, combinations, and environment edges before automation or gate review. trigger on any request to test edge cases, boundary values, min/max inputs, or limit conditions.
---
# boundary-condition-generation


## Routing decision table

| Situation | Action |
|---|---|
| Numeric field with min/max | Generate: min, max, below_min, above_max, zero (if applicable) |
| String field with length constraint | Generate: min_length, max_length, below_min, above_max, empty |
| Optional field | Add: empty/null case as `expect: accepted` |
| Two or more constrained fields interact | Set `combination_boundary_flagged: true`; generate interaction case |
| Enum field | Generate one valid value, one invalid value, and empty |
| Input is a path / filename / file content / locale-sensitive value that may arrive from a different environment than the runtime (cross-OS / cross-encoding / cross-locale / client→server / host→container) | Set `boundary_kind: BK11`; generate: alternate path separators + root forms, alternate text encoding + BOM, CRLF/LF, locale number/date format, origin-OS-mismatch |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n230.boundary-condition.v2.2"
contract_version: "n230.v2.2"
workflow_node: "N230"
```


## Role / role positioning
This skill aligns to testing & qa -> test design -> 边界条件清单.csv. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on thresholds, extremes, paradox values, and combinational edge coverage.
- Extend core scenarios with edge cases; do not replace full executable testcases.
- Do not drift into generic performance planning or chaos orchestration unless the edge itself is the verified boundary.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `numeric_only`: focus on numeric, precision, and threshold boundaries.
- `text_only`: focus on strings, encoding, and input-shape limits.
- `full_spectrum`: cover all relevant boundary kinds including environment and combinations.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `测试点清单.csv`
- `测试用例集.xlsx`
- `接口设计草案.yaml`
- `表结构设计草案.sql`
- `业务规则清单.csv`
- threshold configs, limit tables, rate-limit definitions, or data dictionaries

## Standalone rule / standalone usage
This skill must still work on one field, one threshold rule, or one operation.

Degradation rules:
- If schema or field constraints are missing, emit only confirmed boundary families and tag missing thresholds as `pending_limit_definition`.
- If testcase context is absent, reference the target object or acceptance criterion directly.
- If combinational coverage would explode, prefer pairwise or representative combinations and state the reduction logic.
- Keep the output shape stable even when only one boundary family is known.

## Core output contract / core output contract
Default to csv-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.boundary_condition_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 边界条件清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `boundary_summary`
- `boundary_items[]`
- `combination_plan[]`
- `env_boundary_notes[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every boundary item must declare one `boundary_kind` from `references/boundary-kind-taxonomy.md`.
- Cover both `valid-but-fragile` and `invalid-but-plausible` edge values when the domain supports them.
- Include paradox cases where reasonable values are often rejected or bad values often slip through.
- Use pairwise or focused combination logic from `references/combinatorial-guidance.md` instead of brute-force explosion.
- Add environment boundaries only when the feature truly depends on time, capacity, concurrency, or resource ceilings.
- Add **portability boundaries** (`BK11`) whenever an input may originate in a different environment than the runtime — different OS path conventions, text encoding/BOM, line endings, or locale formats. The trigger is a client→server or host→container hop, not the feature's resource needs; this is a separate axis from the capacity limits above and a frequent source of "works on my machine" production defects.

## Execution workflow / execution workflow
1. Read requirements, testcase context, and limit definitions.
2. Identify boundary-bearing fields, states, and environment constraints.
3. Expand them by boundary kind and edge-value catalog.
4. Add combination candidates where cross-field extremes matter.
5. Normalize traceability back to rules, acceptance criteria, or testcase ids.
6. Emit handoff notes for automation and gate review.

## Dynamic completeness / dynamic completeness
- Small scope: enumerate direct min/max/empty/default cases.
- Medium scope: add paradox values and selected combinations.
- Large scope: group by object or field family and explicitly document reduction strategy.
- If environment boundaries are material, show them separately from pure input-field boundaries.

## Quality bar / quality bar
A good result should prevent easy-to-miss production defects around thresholds, precision, rare encodings, or resource limits. The artifact must be specific enough that downstream teams can automate or manually verify the edge behavior without guessing which values matter.



## Auditable rules

- R01_boundary_pair: every numeric or date field must have at least lower-boundary-valid, upper-boundary-valid, below-min, and above-max cases; on_violation: flag_gap.
- R02_null_required_check: required fields must include null/absent test; optional fields must include null/default test; on_violation: reject.
- R03_type_coercion_check: boundary cases must include wrong-type inputs when the field accepts user input; on_violation: warn.
- R04_combination_coverage: when two or more boundary fields interact, include at least one combined-boundary case; on_violation: warn.
- R05_environment_edge: include environment-specific limits (max payload size, timeout threshold, concurrent user cap) when schema or NFR evidence exists; on_violation: warn.
- R06_no_redundant_cases: remove duplicate boundary pairs that are already covered by a more specific case; on_violation: deduplicate.
- R07_combination_boundary_flagged: when two or more constrained fields interact, combination boundary cases must be explicitly flagged; on_violation: add_combination_note.
- R08_portability_boundary: when an input (path, filename, file content, text, or locale-sensitive value) may originate from a different environment than the runtime — different OS, text encoding, locale, or a client→server / host→container hop — generate BK11 portability cases (path separators + root forms, text encoding + BOM, CRLF/LF, locale number/date formats); on_violation: flag_gap.

## Algorithm

1. Identify all bounded fields (numeric, date, length, enum, required) from schemas and ACs.
2. Apply R01: generate lower/upper/below/above boundary pairs for each numeric field.
3. Apply R02: add null/absent cases for required fields; null/default for optional fields.
4. Apply R03: add type-coercion cases for user-facing inputs.
5. Detect interacting boundary fields; generate combination cases (R04).
6. Check NFR evidence for environment-specific thresholds (R05).
7. Apply R08: for any path / file / text / locale-sensitive input whose origin environment may differ from the runtime, add BK11 portability cases (separators + root forms, encoding/BOM, line endings, locale formats).
8. Deduplicate against existing test cases from 081 (R06).
9. Produce `boundary_conditions[]` grouped by field; update `coverage_gaps[]`.

## Example usage

**Input**: API field `age` with schema `integer, min: 0, max: 150, required: true`.

**Output test points** (seed):
- `age = 0` → lower boundary, valid (should accept)
- `age = 150` → upper boundary, valid (should accept)
- `age = -1` → below min, invalid (expect 400 or validation error)
- `age = 151` → above max, invalid (expect 400 or validation error)
- `age = null` / field absent → required violation (expect 422)
- `age = "abc"` → wrong type (expect 400 type error)

Combine with state and actor perspectives when upstream `test_points[]` are available.

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
 / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/boundary-kind-taxonomy.md`
- `references/combinatorial-guidance.md`
- `references/n230-integration-map.md`
- `references/template-skeleton.md`


- `references/example-io.md`
- `references/example-io-v2.md`


## Cross-skill integration map

| 上游 skill | 提供给 082 | 用途 |
|---|---|---|
| 080 test-point-generation | `boundary_test_points[]` | 边界测试点转为具体边界条件列表 |

| 下游 skill | 082 输出 | 如何使用 |
|---|---|---|
| 081 test-case-generation | `boundary_list[]` | 边界用例的 Given/When/Then 展开 |
| 086 api-test-script-generation | `boundary_list[]` | 参数化边界测试脚本 |
| 098 idempotency-test-point-generation | `boundary_list[]` | 边界+幂等交叉验证 |

**工作流位置**: 测试点 → **082 边界条件** → 081 用例/086 脚本 → 084 回归。

## Standalone usage guide

**Minimum input:** a field name with type and constraints — no upstream artifacts required.

**Standalone decision path:**
1. Parse field constraints (type, min, max, nullable, enum) from any source.
2. Generate boundary pairs for each constraint; mark `source: inferred` where constraints are assumed.
3. Flag `combination_boundary_flagged: true` when multiple constrained fields interact.

**Minimum viable output (single field):**
```yaml
boundary_list:
  readiness: constrained
  pending_ac_confirmation: true
  items:
    - field: quantity
      boundary_type: min
      value: 1
      expect: accepted
      source: inferred_from_field_name
    - field: quantity
      boundary_type: zero
      value: 0
      expect: rejected
      source: inferred_from_field_name
```
**Downstream:** boundary list → 081 test-case-generation (parameter variants).

## Resilience and governance

**Produced events**: Emit `produced_event: produced.n230.boundary_condition_list` in metadata when the artifact is complete or materially updated.

**SLA guidance**: P0 when a required numeric field has no boundary pair; P1 when null/required check is missing

**Circuit breaker**: If the same field repeatedly lacks boundary coverage across 3 feature iterations, emit circuit_breaker: warn.

**Confidence scoring**: confidence scoring: boundary cases inferred from schema alone (no AC confirmation) use confidence: 0.65 and require human review.

**Escalation path**: When readiness: blocked due to missing required boundary pairs, escalate to the QA lead.

**Human review routing**: Set `human_review_required: true` when confidence on any P0 item falls below 0.8, or when coverage gaps exceed 15% of total ACs.

**Traceability**: All produced test points must carry `source_ac_id` or `source_req_id` to enable downstream traceability in test management tools and N260 gate aggregation.


## Usage scenarios

- `schema_boundary_sweep`: generate boundary cases for all constrained fields in an API schema.
- `ac_threshold_coverage`: verify every limit in acceptance criteria has explicit boundary coverage.
- `combination_boundary`: identify interacting fields and produce combination boundary test points.
- `environment_edge`: capture system-level limits (max payload, timeout, concurrent sessions).
- `n230_chain_supplement`: boundary artifacts consumed by 081 test-case-generation as parameter variants.

## v2 optimization addendum / boundary-depth contract
Use this addendum as the controlling rule when it conflicts with older lightweight fields.

### Universal-first positioning
This skill must remain useful outside N230. Treat `workflow_node: N230` as an adapter tag, not as a hard dependency. It may start from a field rule, DTO/schema constraint, API parameter, state rule, rate limit, production defect, or a TP/TC link.

### V2 required upgrades
- Emit `contract_version: n230.test-design-artifact.v2` in metadata.
- Emit canonical `boundary_id`, while accepting legacy `bc_id` as an alias.
- Use BK01-BK11 `boundary_kind` values from `references/boundary-kind-taxonomy.md`.
- Always distinguish `null`, empty, blank, missing, zero, and default values when relevant.
- Treat off-by-one as a required specialty for count, index, size, page, limit, and inclusive/exclusive rules.
- Include `equivalence_classes` with valid and invalid representatives.
- Include temporal and i18n/security catalogs when the target field is time-sensitive or user-entered text.
- Include `event` metadata using `references/event-feedback-interface-v2.md`.

### Composition rules
- Boundary items linked to TP3 should feed data-driven rows in `test-case-generation`.
- Invalid boundary values should hand off to `exception-scenario-generation` when they require error codes, rollback, alerts, or security behavior.
- Security-sensitive strings do not always require rejection; assert safe persistence, escaping, parameterization, and no destructive side effects.
- P0 boundary gaps should set `gate_status: block` unless there is an explicit waiver.

### Node-level self-check
When multiple N230 artifacts are present, use `references/n230-node-checker-v2.md` to verify TP3 to BND coverage and BND to TC data-driven consumption.

### Updated reference files
- `references/shared-artifact-contract-v2.md`
- `references/event-feedback-interface-v2.md`
- `references/n230-node-checker-v2.md`
- `references/edge-catalogs-v2.md`
