# exception taxonomy v2

Use `exception-categories.md` for exact naming. Cover exception scenarios by four views:

1. User-correctable failures: input, authentication, authorization, business rule.
2. System-side failures: external dependency, infrastructure, resource exhaustion.
3. Data safety failures: data conflict, data corruption, rollback and compensation.
4. Security failures: injection, replay, abuse, tenant break, privacy violation.

For write operations, always evaluate retry safety and idempotency under timeout, duplicate request, and partial response.
