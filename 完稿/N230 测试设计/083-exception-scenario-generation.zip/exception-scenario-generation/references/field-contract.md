# field contract v2 for exception-scenario-generation

Use this file with `shared-artifact-contract-v2.md`.

| field | requirement |
|---|---|
| `scenario_id` | canonical `EXC-{DOMAIN}-{NNN}` id; `es_id` accepted as alias |
| `scenario_kind` | ES01-ES10 from `exception-categories.md` |
| `title` | short failure behavior title |
| `description` | exact abnormal path and scope |
| `trigger` | precise failure or injected condition |
| `fault_injection` | injection kind, tool, layer, target |
| `chaos_testing` | applies, kind, blast radius, expected behavior, measured SLI |
| `external_failure_matrix` | dependency by failure mode and expected behavior |
| `resource_exhaustion` | resource, test method, expected result |
| `data_corruption` | corruption kind, detection method, recovery strategy |
| `expected_system_response` | http/status, error code, log, alert, side effects, UX |
| `recovery_strategy` | retry, fallback, circuit break, compensate, fail fast, manual intervention |
| `related_tc_or_tp` | linked TP, TC, AC, API, dependency, vulnerability, or N005 evidence |
| `safe_execution_scope` | `unit`, `integration`, `staging`, `non_prod_only`, or `approved_prod_game_day` |
| `gate_status` | pass, warn, or block |
