# expected system response contract

For each exception scenario, describe observable response instead of vague failure statements.

```yaml
expected_system_response:
  error_code: <code or pending_policy_definition>
  error_message: <safe user-facing message>
  http_status: <status if API>
  logging:
    log_level: error|warn|info
    log_includes: [trace_id, dependency, timeout_ms]
  alerting:
    alert_triggered: true|false
    alert_severity: critical|high|medium|low|none
  side_effects:
    rollback_happened: true|false|not_applicable
    compensation_triggered: true|false|not_applicable
    retry_scheduled: true|false|not_applicable
    dlq_used: true|false|not_applicable
  user_experience:
    user_sees: <message>
    preserves_user_work: true|false|not_applicable
```

If a policy is missing, mark `pending_policy_definition` and do not invent the error code, retry count, or fallback path.
