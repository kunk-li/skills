# output template v2

## required sections
1. metadata
2. exception_summary
3. exception_scenarios
4. fault_injection_plan
5. external_failure_matrix
6. resource_exhaustion_scenarios
7. data_corruption_scenarios
8. propagation_checks
9. recovery_checks
10. downstream_handoff
11. event
12. self_check

## required columns
| scenario_id | target_flow | scenario_kind | trigger | fault_injection | expected_system_response | recovery_strategy | safe_execution_scope | related_tc_or_tp | gate_status | notes |
|---|---|---|---|---|---|---|---|---|---|---|
