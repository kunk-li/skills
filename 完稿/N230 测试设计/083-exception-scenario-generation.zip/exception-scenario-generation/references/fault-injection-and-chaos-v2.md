# fault injection and chaos v2

Declare how a scenario should be tested. Do not recommend destructive tests in production unless the user provided explicit approval.

## injection kinds
- `mock_exception`
- `network_delay`
- `network_partition`
- `http_error_response`
- `timeout`
- `slow_response`
- `resource_exhausted`
- `data_corruption`
- `disk_full`
- `clock_skew`

## tools
- `mockito`: Java mock or similar local mock
- `wiremock`: HTTP dependency simulation
- `toxiproxy`: network latency, timeout, or partition simulation
- `chaos_monkey`: service or instance failure experiment
- `litmus`: Kubernetes chaos experiment
- `jepsen`: distributed consistency experiment
- `custom_test`: explicit custom harness when no standard tool fits

## injection point layers
- `service`
- `repository`
- `external_api`
- `database`
- `queue`
- `cache`
- `network`
- `kernel`

## chaos blast radius
- `single_instance`
- `service_wide`
- `system_wide`

## safety rules
- Default chaos, data corruption, disk full, and resource exhaustion tests to `non_prod_only`.
- Mark production game-day style scenarios as `approved_prod_game_day` only when approval evidence is provided.
- Include cleanup and rollback for every chaos or corruption scenario.

## Chaos maturity levels (v2.0.1)
Use maturity levels to keep resilience tests proportional to organizational readiness.

| level | name | trigger style | allowed scope | required safeguards | suitable scenarios |
|---|---|---|---|---|---|
| L1 | game_day_manual | manually scheduled and supervised | staging or approved non-prod | named owner, rollback plan, cleanup checklist, live observation | first-time dependency outage, DB pool exhaustion rehearsal, runbook validation |
| L2 | scheduled_chaos | periodic automated experiment | non-prod by default, limited production only with approval | blast radius cap, alert suppression rules, automatic stop condition, post-run report | latency injection, pod restart, retry/fallback validation |
| L3 | continuous_chaos | always-on or frequent controlled experiments | narrow production slices only after proven L2 | SLO guardrail, automated rollback, experiment registry, audit trail | mature service resilience verification |
| L4 | production_experiments | hypothesis-driven production experiments | explicitly approved production blast radius | executive or service-owner approval, real-time monitoring, abort switch, user-impact cap, postmortem requirement | critical-platform resilience, failover proof, region-level recovery rehearsal |

### Level selection rules
- Default every chaos-style scenario to L1 unless the user provides evidence of existing chaos maturity.
- Do not recommend L3 or L4 for new systems, unknown owners, missing observability, or unclear rollback.
- `safe_execution_scope` takes precedence over maturity level. A high maturity level never overrides `non_prod_only` unless approval evidence is present.
- Include the selected maturity level in each chaos scenario as `chaos_maturity_level`.

