# N230 示例输入输出 v2（扩展场景）

## 示例 3：异常场景生成（exception-scenario-generation）

### 输入
- 依赖服务：payment-gateway（外部 REST API）
- 失败注入成熟度目标：L2

### 输出
```yaml
exception_scenarios:
  - dependency: payment-gateway
    scenario: connection_timeout
    inject: delay 5000ms
    expected_behavior: retry × 3 then return 503
    idempotency_required: true
  - dependency: payment-gateway
    scenario: invalid_response_schema
    inject: return malformed JSON
    expected_behavior: parse error caught, fallback to cached price
```

## 示例 4：测试用例生成（test-case-generation）

### 输入
- 测试点：TP-001（有效登录）

### 输出
```yaml
test_case:
  tc_id: TC-001
  source_tp: TP-001
  given: 注册用户，密码正确
  when: POST /auth/login
  then:
    - HTTP 200
    - response.token 存在
    - redirect_url == /dashboard
  automation_suitability: automated
  pyramid_layer: e2e
```

## 083 扩展示例输入输出

### Scenario B — Distributed timeout chain

**Input**: order-orchestration-service; dependencies: inventory, payment, notification.

**Output**:
```yaml
exception_scenarios:
  - dependency: inventory-service
    scenario: service_timeout
    inject: delay > 3000ms
    expected_behavior: return 503; no order created
    idempotency_required: true
  - dependency: payment-gateway
    scenario: partial_success_ambiguity
    inject: charge succeeds but response lost
    expected_behavior: query gateway status before retry
    fault_injection_maturity: L3
  - dependency: notification-service
    scenario: non_critical_failure
    inject: returns 500
    expected_behavior: order still created; notification queued for async retry
```



### Scenario C — Idempotency cross-reference

**Input**: Payment retry path with potential duplicate charge risk.

**Output** (with idempotency cross-reference to 098):
```yaml
exception_scenarios:
  - dependency: payment-gateway
    scenario: retry_after_network_timeout
    inject: First request times out; client retries with same payload
    expected_behavior: Gateway must deduplicate — only one charge processed
    idempotency_required: true
    cross_reference_skill: 098-idempotency-test-point-generation
    idempotency_test_points:
      - ITP-001: Same request_id × 3 — verify single charge
      - ITP-002: TTL boundary — replay after idempotency key expiry
    fault_injection_maturity: L3
```

### Scenario D — Idempotency cross-reference

**Input**: Payment retry path with duplicate charge risk; references 098.

**Output** (with idempotency cross-reference):
```yaml
exception_scenarios:
  - dependency: payment-gateway
    scenario: retry_after_network_timeout
    inject: First POST times out; client retries with same payload
    expected_behavior: Gateway deduplicates — only 1 charge processed
    idempotency_required: true
    cross_reference_skill: 098-idempotency-test-point-generation
    idempotency_test_points:
      - ITP-001: Same request_id × 3 → verify single charge
      - ITP-002: TTL boundary → replay after idempotency key expiry
    fault_injection_maturity: L3
```

### Scenario D — Cascading failure (chain of dependencies)

**Input**: Service C depends on B which depends on A; A is down.

**Output** (cascading dependency failure):
```yaml
exception_scenarios:
  - scenario_id: EX-CASCADE-001
    pattern: cascading_dependency_failure
    chain: Service A → Service B → Service C
    inject: Service A returns 503
    expected_behavior:
      service_b: circuit_breaker opens after 3 failures; returns cached/degraded response
      service_c: receives degraded signal from B; returns partial response with warning
      monitoring: circuit_breaker_open alert fires within 30s
    fault_injection_maturity: L3
    cross_reference: 088-test-automation-orchestration
    idempotency_note: Retry from C must not amplify failures at A
  - scenario_id: EX-CASCADE-002
    pattern: thundering_herd_on_recovery
    inject: Service A recovers; all pending retries fire simultaneously
    expected_behavior: Rate limiting or jitter prevents overload on A recovery
```
