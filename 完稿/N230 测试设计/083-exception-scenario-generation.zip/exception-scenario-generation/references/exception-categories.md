# exception scenario categories v2

Emit exactly one primary `scenario_kind`. Legacy `exception_category` values may be retained as aliases.

| scenario_kind | alias | meaning |
|---|---|---|
| `ES01_input_validation_failure` | `input_validation` | malformed input, missing required field, invalid JSON, invalid format |
| `ES02_authentication_failure` | `authentication` | missing identity, expired token, invalid signature |
| `ES03_authorization_failure` | `authorization` | forbidden operation, role mismatch, IDOR, tenant isolation failure |
| `ES04_business_rule_violation` | `business_rule` | domain rule rejection, illegal amount, illegal transition |
| `ES05_data_conflict` | `data_conflict` | uniqueness, optimistic lock, duplicate request, version conflict |
| `ES06_external_service_failure` | `external_dependency` | partner timeout, 5xx, rate limit, invalid response, SSL or DNS failure |
| `ES07_resource_exhaustion` | `resource_exhaustion` | DB pool, thread pool, memory, disk, file descriptor, socket exhaustion |
| `ES08_infrastructure_failure` | `infrastructure` | DB outage, queue outage, network partition, cache unavailable |
| `ES09_data_corruption` | `data_corruption` | inconsistent state, orphan record, dangling reference, encoding or schema mismatch |
| `ES10_security_attack` | `security_attack` | SQLi, XSS, CSRF, SSRF, path traversal, abuse, replay |

Rules:
- Use ES05 for concurrency conflicts even when they surface as 409 or 422.
- Use ES07 for capacity exhaustion, not generic infrastructure.
- Use ES10 for malicious input or abuse even if the immediate surface looks like validation.
