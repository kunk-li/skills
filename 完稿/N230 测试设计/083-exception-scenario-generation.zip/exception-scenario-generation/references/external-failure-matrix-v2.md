# external failure matrix v2

Use this matrix for every required external dependency.

| failure mode | expected behavior options |
|---|---|
| `timeout` | retry, fallback, circuit_break, fail_fast |
| `5xx_error` | retry, fallback, circuit_break, fail_fast |
| `rate_limit` | backoff, queue, fail_fast, degrade |
| `invalid_response` | reject, fallback, alert, quarantine |
| `ssl_error` | fail_fast, alert |
| `dns_failure` | retry, circuit_break, fail_fast |

For each dependency, list likelihood, expected behavior, safe test method, and linked TC/TP.
