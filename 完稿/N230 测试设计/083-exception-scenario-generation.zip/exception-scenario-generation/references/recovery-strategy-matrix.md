# recovery strategy matrix v2

| strategy | use when | verify |
|---|---|---|
| `retry_automatic` | transient dependency or infrastructure failure | bounded retry, idempotency, no duplicate side effect |
| `retry_user_initiated` | user can safely resubmit | safe duplicate handling and clear UX |
| `fallback` | alternate cache, degraded mode, or default path exists | trigger, result, and exit from fallback |
| `circuit_break` | repeated dependency failures | open, half-open, close behavior and metrics |
| `compensate` | partial write or saga rollback needed | rollback, compensation, audit trail |
| `fail_fast` | retry would be unsafe or useless | immediate error and no side effect |
| `manual_intervention` | human repair or approval needed | alert, runbook link, queue entry |
| `ignore_and_continue` | non-critical failure tolerated | log/metric and no user harm |

For each scenario, verify both trigger and exit behavior.
