# orchestration v2

## role
`exception-scenario-generation` turns failure paths into explicit scenarios with category, trigger, fault injection, expected response, recovery strategy, and safe execution scope.

## standalone use
The skill may run from one API, one dependency, one failure mode, one vulnerability, one production incident, or one TP/TC.

## composition
- TP2 negative, TP7 security, and external dependency points should produce EXC rows.
- Invalid BND values can produce ES01, ES04, or ES10 scenarios when behavior must be tested beyond simple rejection.
- EXC rows should feed `test-case-generation` as negative or resilience GWT cases.
- High-risk incident-derived EXC rows should feed N260 as gate evidence.

## handoff
- To N240: fault-injection method, tool, layer, target, safe execution scope.
- To N250: defect category, trigger, reproduction hints, recovery behavior.
- To N260: recovery coverage, fallback/idempotency evidence, non-prod safety status.
