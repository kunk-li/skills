---
name: exception-scenario-generation
description: Generate exception scenarios from acceptance criteria, dependency assumptions, and testcase context; cover error handling, failure modes, dependency outages, and resilience.
---
# exception-scenario-generation


## Routing decision table

| Situation | Action |
|---|---|
| External HTTP dependency | Generate: timeout, 500 error, schema mismatch, rate limit scenarios |
| Database dependency | Generate: connection failure, deadlock, slow query, constraint violation |
| Message queue dependency | Generate: queue full, consumer lag, poison message scenarios |
| Non-critical dependency | Tag `resilience_pattern: async_retry_with_dead_letter` |
| Retry path identified | Set `idempotency_required: true`; cross-reference to 098 |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n230.exception-scenario.v2.2"
contract_version: "n230.v2.2"
workflow_node: "N230"
```


## Role / role positioning
This skill aligns to testing & qa -> test design -> 异常场景清单.csv. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on failure, propagation, recovery, retry, fallback, and degraded behavior.
- Extend core scenarios with abnormal paths and resilience checks.
- Do not drift into generic production incident response planning or performance-only workloads unless the exception behavior requires it.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `category_scan`: broad exception coverage across standard categories.
- `chain_testing`: emphasize layered propagation and mapping.
- `chaos_style`: emphasize injected dependency or infrastructure failures.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `测试点清单.csv`
- `测试用例集.xlsx`
- `错误码清单.csv`
- `幂等设计建议.md`
- `并发控制建议.md`
- `性能风险分析.md`
- `安全风险分析.md`
- external dependency catalogs, timeout assumptions, or fallback rules

## Standalone rule / standalone usage
This skill must still work on one api, one dependency path, or one failure mode.

Degradation rules:
- If downstream dependency details are partial, describe the exception class and observable expectations without inventing internals.
- If no retry or fallback policy exists in the evidence, mark recovery as `pending_policy_definition` instead of making up behavior.
- If only one layer is visible, keep propagation checks scoped to that layer and note missing links.
- Keep the output shape stable even when only a few scenarios are confirmed.

## Core output contract / core output contract
Default to csv-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.exception_scenario_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 异常场景清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `exception_summary`
- `exception_scenarios[]`
- `propagation_checks[]`
- `recovery_checks[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every scenario must declare one `exception_category` from `references/exception-categories.md`.
- Distinguish user-fixable failures from system-side failures.
- For write operations, explicitly consider idempotency under timeout, retry, or partial-response conditions.
- Where fallback or compensation exists, verify the trigger, observable behavior, and recovery exit path.
- Map exception expectations to error codes, trace ids, or audit signals when such evidence exists.

## Execution workflow / execution workflow
1. Read the acceptance criteria, requirement structure, and dependency context.
2. Identify exception categories relevant to the feature or api.
3. Derive propagation expectations across layers when evidence exists.
4. Add retry, fallback, compensation, or manual-intervention checks.
5. Normalize traceability links and note policy gaps.
6. Prepare handoff for automation, defect attribution, and gate review.

## Dynamic completeness / dynamic completeness
- Small scope: cover the most likely user-facing failure and one system-side failure.
- Medium scope: include propagation and recovery expectations.
- Large scope: group by dependency or exception family and separate user-correctable vs system-correctable behavior.
- If resilience policies are immature, state that clearly and keep the scenarios evidence-bound.

## Quality bar / quality bar
A good result should make failure behavior explicit enough that teams can test retry safety, fallback quality, and error mapping before release instead of learning them from production incidents.



## Auditable rules

- R01_dependency_typed: every exception scenario must identify the dependency type (external_api / database / cache / queue / filesystem / network); on_violation: reject.
- R02_failure_class_required: every scenario must carry a `failure_class` (timeout / error_response / malformed_response / unavailable / partial_failure); on_violation: reject.
- R03_expected_behavior_explicit: expected system behavior (retry / fallback / circuit_open / user_notification / data_preserved) must be stated; on_violation: reject.
- R04_idempotency_flag: scenarios involving retries must flag whether the operation is expected to be idempotent; on_violation: warn.
- R05_data_integrity_check: scenarios where failure occurs mid-transaction must include a data-integrity assertion; on_violation: warn.
- R06_no_speculation: do not invent dependencies not evidenced by the requirement or architecture inputs; on_violation: remove.
- R07_idempotency_retry_flagged: exception scenarios covering retry paths must be annotated with `idempotency_required: true` and cross-referenced to 098; on_violation: add_annotation.

## Algorithm

1. Extract dependency assumptions from ACs, architecture notes, and testcase context.
2. For each dependency, enumerate failure classes (R02): timeout, error, malformed, unavailable, partial.
3. Apply R01: tag dependency type for every scenario.
4. State expected system behavior per R03.
5. Flag retry-path scenarios with idempotency expectation (R04).
6. Add data-integrity assertions for mid-transaction failures (R05).
7. Remove speculative scenarios not supported by evidence (R06).
8. Produce `exception_scenarios[]` grouped by dependency; link to test cases from 081.

## Example usage

**Input**: payment service with dependency on external payment gateway.

**Output exception scenarios** (seed):
- Gateway timeout (>5s) → expect retry with exponential backoff, user sees "processing" state
- Gateway returns 500 → expect fallback to queued payment, notify user
- Network partition mid-transaction → expect idempotency key prevents double charge
- Malformed response body → expect graceful parse error, no state mutation
- Auth token expired during retry → expect token refresh before next attempt

Mark each scenario with `dependency_type`, `failure_class`, and `expected_system_behavior`. Cross-reference `concurrency` or `idempotency` scenarios when overlap exists.

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
 / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/exception-taxonomy.md`
- `references/exception-categories.md`
- `references/recovery-strategy-matrix.md`
- `references/n230-integration-map.md`
- `references/template-skeleton.md`


- `references/example-io.md`
- `references/example-io-v2.md`


## Cross-skill integration map

| 上游 skill | 提供给 083 | 用途 |
|---|---|---|
| 080 test-point-generation | `exception_test_points[]` | 异常测试点转为场景 |

| 下游 skill | 083 输出 | 如何使用 |
|---|---|---|
| 081 test-case-generation | `exception_scenarios[]` | 异常场景转为具体用例 |
| 086 api-test-script-generation | `fault_injection_specs[]` | 依赖失败注入测试脚本 |
| 092 defect-reproduction-steps-generation | `exception_scenarios[]` | 已知异常场景加速复现步骤生成 |

**工作流位置**: 测试点 → **083 异常场景** → 081 用例/086 脚本 → 084 回归。

## Standalone usage guide

**Minimum input:** a service or component name — external dependencies will be inferred.

**Standalone decision path:**
1. If no explicit dependency list → infer from service name (e.g., "payment-service" → network, DB, provider).
2. Set `dependency_source: inferred`; set `readiness: constrained`.
3. Generate failure scenarios at L1 maturity; flag `pending_dependency_confirmation`.

**Minimum viable output:**
```yaml
exception_scenarios:
  readiness: constrained
  pending_dependency_confirmation: true
  items:
    - dependency: database
      scenario: connection_timeout
      inject: delay > configured_timeout
      expected_behavior: retry × 3, then return 503
      idempotency_required: true
      dependency_source: inferred
    - dependency: external_payment_provider
      scenario: invalid_response_schema
      inject: malformed JSON response
      expected_behavior: parse error caught, fallback triggered
      dependency_source: inferred
```
**Downstream:** exception scenarios → 081 test-cases (negative paths) → 089 failure attribution.

## Resilience and governance

**Produced events**: Emit `produced_event: produced.n230.exception_scenario_list` in metadata when the artifact is complete or materially updated.

**SLA guidance**: P0 when a critical dependency has no failure-mode coverage; P1 when idempotency flag is missing on retry paths

**Circuit breaker**: If the same external dependency consistently lacks exception coverage, emit circuit_breaker: warn and recommend a dependency failure runbook.

**Confidence scoring**: confidence scoring: scenarios inferred from architecture notes (not AC) use confidence: 0.65.

**Escalation path**: When readiness: blocked, escalate to the QA and architecture leads.

**Human review routing**: Set `human_review_required: true` when confidence on any P0 item falls below 0.8, or when coverage gaps exceed 15% of total ACs.

**Traceability**: All produced test points must carry `source_ac_id` or `source_req_id` to enable downstream traceability in test management tools and N260 gate aggregation.


## Usage scenarios

- `dependency_failure_sweep`: enumerate all external dependencies and generate failure scenarios for each.
- `resilience_validation`: verify retry, fallback, circuit-breaker, and timeout behaviors are covered.
- `idempotency_cross_check`: flag retry-path scenarios requiring idempotency validation.
- `data_integrity_gate`: ensure mid-transaction failure scenarios include data-integrity assertions.
- `n230_chain_supplement`: exception artifacts consumed by 081 as negative-path test cases.

## v2 optimization addendum / resilience-depth contract
Use this addendum as the controlling rule when it conflicts with older lightweight fields.

### Universal-first positioning
This skill must remain useful outside N230. Treat `workflow_node: N230` as an adapter tag, not as a hard dependency. It may start from an API, dependency, flow step, error code, vulnerability, production incident, or TC/TP link.

### V2 required upgrades
- Emit `contract_version: n230.test-design-artifact.v2` in metadata.
- Emit canonical `scenario_id`, while accepting legacy `es_id` as an alias.
- Use ES01-ES10 `scenario_kind` values from `references/exception-categories.md`.
- Declare `fault_injection` for every scenario or explain why it is not testable.
- Treat resource exhaustion, data conflict, data corruption, and security attack as first-class categories.
- For external dependencies, include `external_failure_matrix` from `references/external-failure-matrix-v2.md`.
- For chaos-style or destructive tests, include blast radius, cleanup, and safe execution scope from `references/fault-injection-and-chaos-v2.md`.
- Describe observable behavior using `references/expected-response-contract.md`.
- Include `event` metadata using `references/event-feedback-interface-v2.md`.

### Composition rules
- TP2 negative and TP7 security points should hand off directly into this skill.
- Invalid boundary items from `boundary-condition-generation` should become ES01, ES04, or ES10 scenarios when they require error mapping, rollback, alerts, or security behavior.
- Exception scenarios should become negative or resilience TCs in `test-case-generation` with explicit fault-injection setup.
- Any unsafe chaos, corruption, or resource-exhaustion scenario must default to `non_prod_only` unless explicit approval evidence exists.

### Node-level self-check
When multiple N230 artifacts are present, use `references/n230-node-checker-v2.md` to verify negative, security, external dependency, and recovery coverage.

### Updated reference files
- `references/shared-artifact-contract-v2.md`
- `references/event-feedback-interface-v2.md`
- `references/n230-node-checker-v2.md`
- `references/fault-injection-and-chaos-v2.md`
- `references/expected-response-contract.md`
- `references/external-failure-matrix-v2.md`
