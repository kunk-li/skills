---
name: exception-scenario-generation
description: generate workflow-aligned exception scenarios from acceptance criteria, requirement structure, dependency assumptions, and testcase context. use when chatgpt works in testing & qa / test design and must produce the workflow-aligned exception-scenario artifact for n230 before automation orchestration, defect attribution, or gate review.
---
# exception-scenario-generation

## Role / role positioning
This skill aligns to testing & qa -> test design -> 异常场景清单.csv. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on failure, propagation, recovery, retry, fallback, and degraded behavior.
- Extend core scenarios with abnormal paths and resilience checks.
- Do not drift into generic production incident response planning or performance-only workloads unless the exception behavior requires it.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `category_scan`: broad exception coverage across standard categories.
- `chain_testing`: emphasize layered propagation and mapping.
- `chaos_style`: emphasize injected dependency or infrastructure failures.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `测试点清单.csv`
- `测试用例集.xlsx`
- `错误码清单.csv`
- `幂等设计建议.md`
- `并发控制建议.md`
- `性能风险分析.md`
- `安全风险分析.md`
- external dependency catalogs, timeout assumptions, or fallback rules

## Standalone rule / standalone usage
This skill must still work on one api, one dependency path, or one failure mode.

Degradation rules:
- If downstream dependency details are partial, describe the exception class and observable expectations without inventing internals.
- If no retry or fallback policy exists in the evidence, mark recovery as `pending_policy_definition` instead of making up behavior.
- If only one layer is visible, keep propagation checks scoped to that layer and note missing links.
- Keep the output shape stable even when only a few scenarios are confirmed.

## Core output contract / core output contract
Default to csv-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.exception_scenario_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 异常场景清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `exception_summary`
- `exception_scenarios[]`
- `propagation_checks[]`
- `recovery_checks[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every scenario must declare one `exception_category` from `references/exception-categories.md`.
- Distinguish user-fixable failures from system-side failures.
- For write operations, explicitly consider idempotency under timeout, retry, or partial-response conditions.
- Where fallback or compensation exists, verify the trigger, observable behavior, and recovery exit path.
- Map exception expectations to error codes, trace ids, or audit signals when such evidence exists.

## Execution workflow / execution workflow
1. Read the acceptance criteria, requirement structure, and dependency context.
2. Identify exception categories relevant to the feature or api.
3. Derive propagation expectations across layers when evidence exists.
4. Add retry, fallback, compensation, or manual-intervention checks.
5. Normalize traceability links and note policy gaps.
6. Prepare handoff for automation, defect attribution, and gate review.

## Dynamic completeness / dynamic completeness
- Small scope: cover the most likely user-facing failure and one system-side failure.
- Medium scope: include propagation and recovery expectations.
- Large scope: group by dependency or exception family and separate user-correctable vs system-correctable behavior.
- If resilience policies are immature, state that clearly and keep the scenarios evidence-bound.

## Quality bar / quality bar
A good result should make failure behavior explicit enough that teams can test retry safety, fallback quality, and error mapping before release instead of learning them from production incidents.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/exception-taxonomy.md`
- `references/exception-categories.md`
- `references/recovery-strategy-matrix.md`
- `references/n230-integration-map.md`

## v2 optimization addendum / resilience-depth contract
Use this addendum as the controlling rule when it conflicts with older lightweight fields.

### Universal-first positioning
This skill must remain useful outside N230. Treat `workflow_node: N230` as an adapter tag, not as a hard dependency. It may start from an API, dependency, flow step, error code, vulnerability, production incident, or TC/TP link.

### V2 required upgrades
- Emit `contract_version: n230.test-design-artifact.v2` in metadata.
- Emit canonical `scenario_id`, while accepting legacy `es_id` as an alias.
- Use ES01-ES10 `scenario_kind` values from `references/exception-categories.md`.
- Declare `fault_injection` for every scenario or explain why it is not testable.
- Treat resource exhaustion, data conflict, data corruption, and security attack as first-class categories.
- For external dependencies, include `external_failure_matrix` from `references/external-failure-matrix-v2.md`.
- For chaos-style or destructive tests, include blast radius, cleanup, and safe execution scope from `references/fault-injection-and-chaos-v2.md`.
- Describe observable behavior using `references/expected-response-contract.md`.
- Include `event` metadata using `references/event-feedback-interface-v2.md`.

### Composition rules
- TP2 negative and TP7 security points should hand off directly into this skill.
- Invalid boundary items from `boundary-condition-generation` should become ES01, ES04, or ES10 scenarios when they require error mapping, rollback, alerts, or security behavior.
- Exception scenarios should become negative or resilience TCs in `test-case-generation` with explicit fault-injection setup.
- Any unsafe chaos, corruption, or resource-exhaustion scenario must default to `non_prod_only` unless explicit approval evidence exists.

### Node-level self-check
When multiple N230 artifacts are present, use `references/n230-node-checker-v2.md` to verify negative, security, external dependency, and recovery coverage.

### Updated reference files
- `references/shared-artifact-contract-v2.md`
- `references/event-feedback-interface-v2.md`
- `references/n230-node-checker-v2.md`
- `references/fault-injection-and-chaos-v2.md`
- `references/expected-response-contract.md`
- `references/external-failure-matrix-v2.md`

### v2.0.1 release-candidate polish
- Use `references/shared-artifact-contract-v2.md` output file defaults for exported exception sheets.
- Use `references/fault-injection-and-chaos-v2.md` chaos maturity levels L1-L4 for chaos-style scenarios.

### v2.0.2 release polish
- Use the contract evolution policy in `references/shared-artifact-contract-v2.md` when handling canonical fields, legacy aliases, schema changes, and compatibility.
