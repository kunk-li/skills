# 测试质量检查清单

> 本文件为 N230 测试设计技能组共享参考。

## 测试点质量标准

- [ ] 每个测试点有明确的 intent（happy_path / negative / boundary / nfr_*）
- [ ] 每个测试点标注 priority（P0/P1/P2）
- [ ] 每个测试点标注 automation_suitability（automated / semi / manual）
- [ ] 每个测试点标注 pyramid_layer（unit / integration / e2e / performance）
- [ ] coverage_gaps[] 列出所有未覆盖的 AC 条目

## 测试用例质量标准

- [ ] Given/When/Then 格式，每步可独立验证
- [ ] 断言精确到字段级（非仅 HTTP 状态码）
- [ ] 测试数据与生产数据隔离
- [ ] 无隐式依赖（测试可独立运行）

## 边界条件覆盖要求

- [ ] 每个约束字段覆盖：min、max、below_min、above_max
- [ ] 可选字段有 empty/null 情况
- [ ] 多字段交互边界标注 combination_boundary_flagged: true

## 异常场景覆盖要求

- [ ] 每个外部依赖有至少 1 个失败场景
- [ ] 重试路径标注 idempotency_required: true
- [ ] 非关键依赖失败场景包含降级预期行为
