# field contract v2 for test-point-generation

Use this file with `shared-artifact-contract-v2.md`.

## canonical item fields
| field | requirement |
|---|---|
| `test_point_id` | canonical `TP-{DOMAIN}-{NNN}` id; `tp_id` is accepted as alias |
| `title` | concise validation title |
| `description` | concrete validation intent |
| `test_point_kind` | one of TP1-TP8 from `test-intent-taxonomy.md` |
| `test_perspective` | one or more V01-V10 perspectives |
| `priority_scoring` | five-factor score, total, and mapped priority |
| `priority` | derived P0/P1/P2/P3, not hand-assigned without score |
| `pyramid_tier` | unit, integration, e2e, or contract |
| `derived_from` | AC, rule, API, state machine, NFR, vulnerability, or N005 feedback refs |
| `coverage_requirement` | code/branch target if known; merge/release mandate flags |
| `test_data_requirements` | fixture, mock, generated, or production_like with sensitivity |
| `gate_status` | pass, warn, or block |

## priority scoring factors
Each factor is 0-5.
- `business_criticality`
- `risk_severity_if_fails`
- `likelihood_of_failure`
- `regression_history`
- `compliance_required`

Add +2 when compliance is mandatory. Map total score to priority in `priority-rules.md`.

## aliases
Legacy `tp_intent` can be retained, but always also emit `test_point_kind`.
Legacy `tp_perspective` can be retained, but always also emit `test_perspective`.
