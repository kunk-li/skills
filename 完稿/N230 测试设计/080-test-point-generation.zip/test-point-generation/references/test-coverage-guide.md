# test coverage guide v2

## AC to TP expansion
For every confirmed acceptance criterion:
- create at least one `TP1_functional_positive`
- create one `TP2_functional_negative` for each confirmed rejection or error path
- create one to three `TP3_boundary` items when ranges, counts, sizes, dates, or limits exist
- create one `TP4_state_transition` per material state transition

A typical AC produces 3-8 test points. If fewer are produced, explain the evidence limit in `coverage_gaps`.

## P0 baseline
For each P0 AC or release-blocking rule, require at least:
- positive path
- negative path
- boundary or state path
- one side-effect or data-integrity perspective when the feature writes data

## NFR coverage
Add mandatory points when evidence exists:
- concurrency design -> `TP5_concurrency`
- idempotency design -> `TP6_idempotency`
- authorization or vulnerability evidence -> `TP7_security`
- latency, load, or capacity target -> `TP8_performance`

## coverage analysis output
Include:
- `per_ac`: number of generated TPs and completeness status
- `per_nfr`: coverage percentage or gap note by NFR family
- `gaps`: missing kind, reason, and recommended next skill
