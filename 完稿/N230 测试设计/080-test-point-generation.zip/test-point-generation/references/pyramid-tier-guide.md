# pyramid tier guide

Assign one `pyramid_tier` to every test point.

| tier | use when | expected share |
|---|---|---|
| `unit` | pure function, validator, mapper, small domain method | about 70 percent |
| `integration` | service plus DB/cache/queue, external mock, transaction behavior | about 20 percent |
| `e2e` | full user journey or browser-visible workflow | about 10 percent |
| `contract` | service-to-service or API compatibility behavior | as needed |

Rules:
- Prefer the lowest tier that can prove the behavior.
- Use `contract` for cross-service API expectations.
- Use `integration` for idempotency, concurrency, DB transaction, or external mock behavior.
- Use `e2e` only when the behavior cannot be validated below the user-flow level.
