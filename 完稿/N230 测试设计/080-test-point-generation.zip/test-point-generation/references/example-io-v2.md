# N230 示例输入输出 v2（扩展场景）

## 示例 3：异常场景生成（exception-scenario-generation）

### 输入
- 依赖服务：payment-gateway（外部 REST API）
- 失败注入成熟度目标：L2

### 输出
```yaml
exception_scenarios:
  - dependency: payment-gateway
    scenario: connection_timeout
    inject: delay 5000ms
    expected_behavior: retry × 3 then return 503
    idempotency_required: true
  - dependency: payment-gateway
    scenario: invalid_response_schema
    inject: return malformed JSON
    expected_behavior: parse error caught, fallback to cached price
```

## 示例 4：测试用例生成（test-case-generation）

### 输入
- 测试点：TP-001（有效登录）

### 输出
```yaml
test_case:
  tc_id: TC-001
  source_tp: TP-001
  given: 注册用户，密码正确
  when: POST /auth/login
  then:
    - HTTP 200
    - response.token 存在
    - redirect_url == /dashboard
  automation_suitability: automated
  pyramid_layer: e2e
```

## 080 扩展示例输入输出

### Scenario B — Degraded (AC incomplete, standalone)

**Input**: Only a feature name and brief description: "Checkout flow with promo code support."

**Output** (`acceptance_criteria_seed` mode, degraded):
```yaml
test_point_list:
  readiness: constrained
  confidence: 0.55
  pending_ac_confirmation: true
  points:
    - tp_id: TP-D001
      intent: happy_path
      description: Valid promo code applied → discount reflected in total
      priority: P0
      source: inferred_from_feature_name
    - tp_id: TP-D002
      intent: negative
      description: Invalid/expired promo code → error message shown
      priority: P0
      source: inferred_from_feature_name
  coverage_gaps:
    - "No AC provided for promo stacking rules"
    - "No AC provided for promo + loyalty points interaction"
  human_review_required: true
```

### Scenario C — NFR test points (performance SLO)

**Input**: AC: "API p95 latency ≤ 300ms under 500 concurrent users at checkout."

**Output** (`nfr_performance` intent):
```yaml
test_point_list:
  source_ac_id: AC-NFR-001
  readiness: ready
  points:
    - tp_id: TP-NFR-001
      intent: nfr_performance
      description: p95 latency ≤ 300ms at 500 concurrent users during checkout
      priority: P1
      automation_suitability: automated
      pyramid_layer: performance
      slo_triplet:
        metric: p95_latency
        threshold: 300ms
        window: 10min_sustained
    - tp_id: TP-NFR-002
      intent: nfr_performance
      description: Zero order loss under peak load (no 5xx errors)
      priority: P0
      automation_suitability: automated
```

### Scenario D — Migration test points (DB schema change)

**Input**: PR adds `NOT NULL` column `order_status_code` to `orders` table; existing rows need backfill.

**Output** (`migration` intent):
```yaml
test_point_list:
  source: db_migration_script
  mode: migration
  readiness: ready
  points:
    - tp_id: TP-MIG-001
      intent: migration_data_integrity
      description: Backfill script sets correct `order_status_code` for all existing rows
      priority: P0
      check: SELECT COUNT(*) FROM orders WHERE order_status_code IS NULL — expect 0
      automation_suitability: automated
      pyramid_layer: integration
    - tp_id: TP-MIG-002
      intent: migration_rollback
      description: Down migration restores table without data loss
      priority: P0
      check: Row count identical before/after up+down cycle
      automation_suitability: automated
    - tp_id: TP-MIG-003
      intent: new_column_constraint
      description: Inserting row without `order_status_code` is rejected
      priority: P1
      check: INSERT without field → ConstraintViolationException
      automation_suitability: automated
```
