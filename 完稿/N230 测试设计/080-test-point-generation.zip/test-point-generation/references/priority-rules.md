# priority rules v2

Use quantified scoring before assigning P0/P1/P2/P3.

## five-factor score
Each factor is 0-5.

| factor | scoring guidance |
|---|---|
| `business_criticality` | 5 for money, identity, authorization, data write, compliance, or core transaction |
| `risk_severity_if_fails` | 5 for data corruption, breach, irreversible loss, or legal exposure |
| `likelihood_of_failure` | 5 for new, complex, concurrent, distributed, or historically flaky logic |
| `regression_history` | 5 for recurring defects or production incidents in the same area |
| `compliance_required` | 5 for mandatory audit, retention, masking, consent, or regulatory control |

Formula:

```text
total = business_criticality + risk_severity_if_fails + likelihood_of_failure + regression_history + compliance_required
if compliance_required >= 4: total = total + 2
```

## priority mapping
- `P0`: total > 18, or any mandatory compliance, security exposure, financial loss, data corruption, or release blocker.
- `P1`: total 12-18, or core user/business path with high impact.
- `P2`: total 6-11, important but non-blocking coverage.
- `P3`: total < 6, low-impact or exploratory coverage.

## automatic rules
- P0 always sets `mandatory_for_merge: true` unless explicitly marked manual-only and approved.
- P0 and compliance coverage always sets `mandatory_for_release: true`.
- Production incident, severe defect, or N005 high-severity signal increases priority by at least one level.
- Never downgrade security, data integrity, or compliance coverage without explicit evidence.
