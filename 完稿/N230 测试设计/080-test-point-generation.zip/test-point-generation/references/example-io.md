# N230 示例输入输出

## 示例 1：从验收标准生成测试点（test-point-generation）

### 输入
- AC: "用户使用有效凭据登录后，2秒内跳转至仪表盘"
- 优先级模式：standard

### 输出（TP 列表节选）
```yaml
test_point_list:
  source_ac_id: AC-LOGIN-001
  points:
    - tp_id: TP-001
      intent: happy_path
      description: 有效凭据 → 仪表盘跳转 ≤2s
      priority: P0
      automation_suitability: automated
```

## 示例 2：边界条件生成（boundary-condition-generation）

### 输入
- 字段：password（字符串，4–128位）

### 输出
```yaml
boundary_list:
  - field: password
    boundary_type: min_length
    value: 4
    expect: accepted
  - field: password
    boundary_type: max_length
    value: 128
    expect: accepted
  - field: password
    boundary_type: below_min
    value: 3
    expect: rejected
```
