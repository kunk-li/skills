# output template v2

Use a csv-friendly table plus short analysis sections.

## required sections
1. metadata
2. scope_summary
3. test_points
4. coverage_analysis
5. coverage_gaps
6. downstream_handoff
7. event
8. self_check

## required test_points columns
| test_point_id | title | module | test_point_kind | test_perspective | priority | priority_total | pyramid_tier | mandatory_for_merge | mandatory_for_release | derived_from | test_data_requirements | gate_status | notes |
|---|---|---|---|---|---|---:|---|---|---|---|---|---|---|

## scale guidance
- small feature: 10-25 rows
- medium feature: 25-60 rows
- large workflow: 60-150 rows

## event envelope
Use `event-feedback-interface-v2.md` for produced event metadata.
