# orchestration v2

## role
`test-point-generation` defines the coverage scaffold: what should be validated, why it matters, and how it should flow into cases, boundaries, exceptions, automation, and gates.

## standalone use
The skill may run from one AC, one feature summary, one API, one rule, one NFR, or one production-signal theme. Keep the output shape stable and mark partial evidence.

## n230 composition
Recommended flow:
1. Run `test-point-generation` to create TP coverage, priorities, pyramid tier, and gaps.
2. Run `test-case-generation` for P0/P1 and release-critical TP items.
3. Run `boundary-condition-generation` in parallel for TP3 or any rule/schema/time/count boundary.
4. Run `exception-scenario-generation` in parallel for TP2, TP7, external dependency, recovery, or production incident evidence.
5. Re-run `test-case-generation` to fold BND and EXC rows into data-driven and negative/resilience cases when executable cases are required.
6. Run the node-level checker from `n230-node-checker-v2.md` before N240 or N260 handoff.

## handoff
- To N240: pyramid tier, automation tier hints, fixture and data requirements, generated-code readiness.
- To N260: P0 coverage, NFR coverage, gate status, mandatory flags, unresolved gaps.
- To N005 feedback loop: regression or incident-derived coverage additions.
