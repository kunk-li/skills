# test intent taxonomy v2

Emit exactly one primary `test_point_kind`. Keep legacy intent aliases only as secondary labels.

| kind | alias | meaning |
|---|---|---|
| `TP1_functional_positive` | `functional_positive` | normal successful behavior |
| `TP2_functional_negative` | `functional_negative` | expected rejection, error, or invalid path |
| `TP3_boundary` | `boundary` | range, size, count, time, precision, or edge values |
| `TP4_state_transition` | `state_transition` | allowed and forbidden state changes |
| `TP5_concurrency` | `concurrency` | simultaneous access, ordering, locking, race conditions |
| `TP6_idempotency` | `idempotency` | safe retry, duplicate request, same key behavior |
| `TP7_security` | `security` | authentication, authorization, injection, abuse, privacy |
| `TP8_performance` | `performance` | latency, throughput, load, capacity, degradation |

## perspectives
Emit one or more `test_perspective` values.

| perspective | meaning |
|---|---|
| `V01_input_validation` | type, format, range, required fields |
| `V02_output_correctness` | status, response, calculation, visible result |
| `V03_side_effects` | DB writes, events, logs, audit, notifications |
| `V04_error_handling` | error code, message, rollback, retry surface |
| `V05_edge_cases` | edge, rare, paradox, min/max, empty/null |
| `V06_concurrent_access` | parallel access and race behavior |
| `V07_data_integrity` | consistency, reconciliation, no corruption |
| `V08_security_authorization` | authn, authz, privacy, abuse prevention |
| `V09_performance_latency` | response time, throughput, degradation |
| `V10_integration_with_external` | partner, queue, cache, DB, external system contract |
