---
name: test-point-generation
description: generate workflow-aligned test points from acceptance criteria, requirement structure, and quality-review materials. use when chatgpt works in testing & qa / test design and must produce the workflow-aligned test-point artifact for n230 before executable cases, automation planning, or gate aggregation.
---
# test-point-generation

## Role / role positioning
This skill aligns to testing & qa -> test design -> 测试点清单.csv. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on test intent, not full executable steps.
- Turn requirements into coverage-ready test points with priority and traceability.
- Do not expand into full scripts, regression orchestration, or release sign-off.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `seed_mode`: fast acceptance-criteria to test-point seed generation.
- `comprehensive_mode`: full multi-perspective expansion with nfr coverage and traceability.
- `export_ready_mode`: optimize the output for test-management import formats.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`
- `需求漏洞清单.csv`
- `并发控制建议.md`
- `幂等设计建议.md`
- `性能风险分析.md`
- `安全风险分析.md`
- known blockers, incident learnings, or historical defect themes

## Standalone rule / standalone usage
This skill must still work on one acceptance criterion, one requirement section, or one feature summary.

Degradation rules:
- If acceptance criteria are missing, derive provisional points from confirmed requirement structure and clearly mark `pending_acceptance_alignment`.
- If only a feature summary is available, emit test-point seeds and a coverage-gap section instead of pretending full completeness.
- If quality-review inputs are missing, keep priority conservative and mark blocker or compliance coverage as partially confirmed.
- Keep the output shape stable even when the source material is sparse.

## Core output contract / core output contract
Default to Markdown or csv-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.test_point_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 测试点清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `scope_summary`
- `test_points[]`
- `coverage_matrix_seed[]`
- `coverage_gaps[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every test point must have one `tp_intent` from `references/test-intent-taxonomy.md`.
- Every core acceptance criterion should be challenged from at least `input_output`, `actor`, and `state` perspectives when evidence exists.
- Add `concurrency`, `performance`, `security`, or `compliance` intents when the upstream materials clearly indicate them.
- Each test point must reference `acceptance_criteria`, `business_rules`, `blockers`, or `nfr_items` when those ids are available.
- Use `references/priority-rules.md` to normalize P0/P1/P2/P3 assignment instead of ad hoc judgement.
- Prefer precise wording like “验证 xxx 在 yyy 条件下 zzz” over vague phrases like “验证功能正常”.

## Execution workflow / execution workflow
1. Read the acceptance criteria and requirement structure to identify feature scope, actors, states, and critical rules.
2. Derive seed test intents from happy-path requirements.
3. Expand each core area across perspectives: input-output, actor, state, time, and concurrency when applicable.
4. Add nfr-aware points for security, compliance, performance, and resilience based on the evidence.
5. Normalize priority and attach traceability links.
6. Emit coverage gaps and handoff notes for N240 and N260.

## Dynamic completeness / dynamic completeness
- Small feature: keep the list compact but still cover positive, negative, and boundary intent.
- Medium feature: include traceability and explicit gap notes.
- Large workflow: group points by module or acceptance bundle and add coverage-matrix seeds.
- If blockers or regulated rules exist, explicitly show which test points defend them.

## Quality bar / quality bar
A good result should give downstream testcase authors and gate owners a reliable coverage scaffold, not just a brainstorm list. The artifact must be directly reusable as the source for `测试用例集.xlsx`, boundary expansions, and gate coverage checks.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/test-coverage-guide.md`
- `references/test-intent-taxonomy.md`
- `references/priority-rules.md`
- `references/n230-integration-map.md`

## v2 optimization addendum / contract-first behavior
Use this addendum as the controlling rule when it conflicts with older lightweight fields.

### Universal-first positioning
This skill must remain useful outside N230. Treat `workflow_node: N230` as an adapter tag, not as a hard dependency. When N230 inputs are absent, work from AC, rule, API, NFR, defect, or production-signal evidence and mark the source profile explicitly.

### V2 required upgrades
- Emit `contract_version: n230.test-design-artifact.v2` in metadata.
- Emit canonical `test_point_id`, while accepting legacy `tp_id` as an alias.
- Emit `test_point_kind` using TP1-TP8 from `references/test-intent-taxonomy.md`.
- Emit `test_perspective` using V01-V10 from `references/test-intent-taxonomy.md`.
- Score priority with the five-factor matrix in `references/priority-rules.md`.
- Assign `pyramid_tier` using `references/pyramid-tier-guide.md`.
- Mark P0 and compliance points with merge/release mandate flags.
- Include `event` metadata using `references/event-feedback-interface-v2.md`.

### Composition rules
- A TP3 boundary point should be consumable by `boundary-condition-generation`.
- A TP2 negative or TP7 security point should be consumable by `exception-scenario-generation`.
- A P0 test point should be consumable by `test-case-generation` or reported as a gate blocker.
- Use the shared ID namespace in `references/shared-artifact-contract-v2.md`.

### Node-level self-check
When multiple N230 artifacts are present, use `references/n230-node-checker-v2.md` to summarize aggregate pass/warn/block status instead of only checking this skill's own output.

### Updated reference files
- `references/shared-artifact-contract-v2.md`
- `references/event-feedback-interface-v2.md`
- `references/n230-node-checker-v2.md`
- `references/pyramid-tier-guide.md`

### v2.0.1 release-candidate polish
- Use `references/shared-artifact-contract-v2.md` output file defaults for CSV, XLSX, Markdown, YAML, and JSON exports.
- Keep canonical machine-readable headers stable even when the narrative summary is localized.

### v2.0.2 release polish
- Use the contract evolution policy in `references/shared-artifact-contract-v2.md` when handling canonical fields, legacy aliases, schema changes, and compatibility.
