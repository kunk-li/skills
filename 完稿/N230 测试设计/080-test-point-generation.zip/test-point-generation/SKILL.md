---
name: test-point-generation
description: generate workflow-aligned test points from acceptance criteria, requirement structure, and quality-review materials. use when Claude works in testing & qa / test design and must produce the workflow-aligned test-point artifact for N230 before executable cases, automation planning, or gate aggregation. trigger on any request to derive test coverage, list test intentions, or produce a test point seed from requirements.
---
# test-point-generation


## Routing decision table

| Situation | Action |
|---|---|
| AC available | Primary mode — derive test points from AC; set `source: ac_derived` |
| Only user story available | Infer test points; set `source: inferred`; list assumptions in `coverage_gaps[]` |
| No input at all | Return error: minimum one AC, user story, or feature description required |
| NFR (performance, security) mentioned | Generate dedicated NFR test points; tag `intent: nfr_*` |
| Duplicate AC coverage detected | Merge overlapping test points; note deduplication in output |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n230.test-point.v2.2"
contract_version: "n230.v2.2"
workflow_node: "N230"
```


## Role / role positioning
This skill aligns to testing & qa -> test design -> 测试点清单.csv. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on test intent, not full executable steps.
- Turn requirements into coverage-ready test points with priority and traceability.
- Do not expand into full scripts, regression orchestration, or release sign-off.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `seed_mode`: fast acceptance-criteria to test-point seed generation.
- `comprehensive_mode`: full multi-perspective expansion with nfr coverage and traceability.
- `export_ready_mode`: optimize the output for test-management import formats.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`
- `需求漏洞清单.csv`
- `并发控制建议.md`
- `幂等设计建议.md`
- `性能风险分析.md`
- `安全风险分析.md`
- known blockers, incident learnings, or historical defect themes

## Standalone rule / standalone usage
This skill must still work on one acceptance criterion, one requirement section, or one feature summary.

Degradation rules:
- If acceptance criteria are missing, derive provisional points from confirmed requirement structure and clearly mark `pending_acceptance_alignment`.
- If only a feature summary is available, emit test-point seeds and a coverage-gap section instead of pretending full completeness.
- If quality-review inputs are missing, keep priority conservative and mark blocker or compliance coverage as partially confirmed.
- Keep the output shape stable even when the source material is sparse.

## Core output contract / core output contract
Default to Markdown or csv-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.test_point_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 测试点清单.csv`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `scope_summary`
- `test_points[]`
- `coverage_matrix_seed[]`
- `coverage_gaps[]`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every test point must have one `tp_intent` from `references/test-intent-taxonomy.md`.
- Every core acceptance criterion should be challenged from at least `input_output`, `actor`, and `state` perspectives when evidence exists.
- Add `concurrency`, `performance`, `security`, or `compliance` intents when the upstream materials clearly indicate them.
- Each test point must reference `acceptance_criteria`, `business_rules`, `blockers`, or `nfr_items` when those ids are available.
- Use `references/priority-rules.md` to normalize P0/P1/P2/P3 assignment instead of ad hoc judgement.
- Prefer precise wording like “验证 xxx 在 yyy 条件下 zzz” over vague phrases like “验证功能正常”.

## Execution workflow / execution workflow
1. Read the acceptance criteria and requirement structure to identify feature scope, actors, states, and critical rules.
2. Derive seed test intents from happy-path requirements.
3. Expand each core area across perspectives: input-output, actor, state, time, and concurrency when applicable.
4. Add nfr-aware points for security, compliance, performance, and resilience based on the evidence.
5. Normalize priority and attach traceability links.
6. Emit coverage gaps and handoff notes for N240 and N260.

## Dynamic completeness / dynamic completeness
- Small feature: keep the list compact but still cover positive, negative, and boundary intent.
- Medium feature: include traceability and explicit gap notes.
- Large workflow: group points by module or acceptance bundle and add coverage-matrix seeds.
- If blockers or regulated rules exist, explicitly show which test points defend them.


## Example usage

### Scenario A — From acceptance criteria (standard mode)

**Input**: AC for a user login feature: "Given a registered user, when they enter valid credentials, then they are redirected to dashboard within 2s. Given invalid credentials, then error message displays."

**Output** (`acceptance_criteria_seed` mode):
```yaml
test_point_list:
  source_ac_id: AC-LOGIN-001
  readiness: ready
  confidence: 0.92
  points:
    - tp_id: TP-001
      intent: happy_path
      description: Valid credentials → dashboard redirect within 2s
      priority: P0
      automation_suitability: automated
      pyramid_layer: e2e
    - tp_id: TP-002
      intent: negative
      description: Invalid password → error message displayed
      priority: P0
      automation_suitability: automated
      pyramid_layer: integration
    - tp_id: TP-003
      intent: boundary
      description: Password exactly at max length (128 chars) → accepted
      priority: P1
      automation_suitability: automated
      pyramid_layer: unit
    - tp_id: TP-004
      intent: nfr_performance
      description: Login response time < 2s under 100 concurrent users
      priority: P1
      automation_suitability: semi_automated
      pyramid_layer: performance
  coverage_gaps: []
  downstream_handoff:
    to: 081-test-case-generation
    artifact: test_point_list
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Quality bar / quality bar
A good result should give downstream testcase authors and gate owners a reliable coverage scaffold, not just a brainstorm list. The artifact must be directly reusable as the source for `测试用例集.xlsx`, boundary expansions, and gate coverage checks.


## Auditable rules

- R01_intent_required: every test point must carry exactly one `tp_intent` from the authorized taxonomy; on_violation: reject.
- R02_ac_coverage: every core acceptance criterion must be covered by at least one test point; on_violation: flag_gap.
- R03_perspective_expansion: each AC must be challenged from at least `input_output`, `actor`, and `state` perspectives when evidence supports it; on_violation: warn.
- R04_no_vague_wording: test point descriptions must be specific (e.g. "验证 X 在 Y 条件下 Z") not generic ("验证功能正常"); on_violation: rewrite.
- R05_priority_normalized: priority must follow P0/P1/P2/P3 rules from `references/priority-rules.md`; on_violation: remap.
- R06_traceability_when_ids: each point must reference `acceptance_criteria`, `business_rules`, `blockers`, or `nfr_items` when those ids exist; on_violation: warn.
- R07_coverage_gap_explicit: identified coverage gaps must be listed in `coverage_gaps[]`; on_violation: add_gap_entry.

## Algorithm

1. Read ACs and requirement structure; identify actors, states, rules, and NFR signals.
2. Derive seed intents (happy-path first) for each AC.
3. Expand each seed across `input_output`, `actor`, `state` perspectives (R03).
4. Apply R04 wording rules; rewrite vague descriptions.
5. Assign priority per R05; flag P0 items for immediate review.
6. Link traceability refs where ids exist (R06); record missing links in `coverage_gaps[]`.
7. Produce `coverage_matrix_seed[]` and `coverage_gaps[]`.
8. Run `self_check`; set `readiness: blocked` if R01 or R02 fires.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
 / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/test-coverage-guide.md`
- `references/test-intent-taxonomy.md`
- `references/priority-rules.md`
- `references/n230-integration-map.md`
- `references/template-skeleton.md`


- `references/example-io.md`
- `references/example-io-v2.md`


## Cross-skill integration map

| 上游 skill | 提供给 080 | 用途 |
|---|---|---|
| 076–079 N220 | `review_summary`, `risk_items` | 审查发现的测试盲区转为测试点 |

| 下游 skill | 080 输出 | 如何使用 |
|---|---|---|
| 081 test-case-generation | `test_point_list[]` | 每个测试点展开为具体用例 |
| 082 boundary-condition-generation | `boundary_test_points[]` | 边界点生成具体边界用例 |
| 083 exception-scenario-generation | `exception_test_points[]` | 异常点生成异常场景 |
| 084 regression-test-checklist-generation | `test_point_list[]` | 回归清单的输入来源 |

**工作流位置**: 需求/AC → **080 测试点** → 081/082/083 → 084 回归清单。

## Standalone usage guide

**When used without upstream ACs or full requirements:**

1. Accept any of: user story, feature description, PR diff, existing failing test, or informal spec note.
2. Generate test points at the highest inferrable precision; mark inferred points with `source: inferred`.
3. Set `readiness: constrained` and populate `coverage_gaps[]` with missing AC items.
4. Do not fabricate acceptance criteria — list them as `pending_ac_confirmation`.

**Minimum viable input example:**
> "Add a promo code field to checkout"

**Minimum viable output:**
```yaml
test_point_list:
  readiness: constrained
  confidence: 0.55
  pending_ac_confirmation: true
  points:
    - tp_id: TP-D001
      intent: happy_path
      source: inferred
      description: Valid promo code applied → discount reflected in total
      priority: P0
    - tp_id: TP-D002
      intent: negative
      source: inferred
      description: Expired promo code → clear error message
      priority: P0
  coverage_gaps:
    - No AC for promo stacking rules
    - No AC for promo + loyalty points interaction
```

**Downstream chain:** TP list → 081 test-case-generation → 082 boundary-condition-generation → 083 exception-scenario-generation → 084 regression-test-checklist-generation.

## Resilience and governance

**Produced events**: Emit `produced_event: produced.n230.test_point_list` in metadata when the artifact is complete or materially updated.

**SLA guidance**: P0 when any required AC has no test point coverage; P1 when priority remap fires on more than 20% of points

**Circuit breaker**: If three consecutive test-point runs for the same feature produce coverage gaps on the same ACs, emit circuit_breaker: warn and flag the AC as persistently undertested.

**Confidence scoring**: confidence scoring on priority assignment: P0 items require confidence ≥ 0.8; lower confidence forces human_review_required: true.

**Escalation path**: When readiness: blocked due to missing AC coverage, escalate to the QA lead.

**Human review routing**: Set `human_review_required: true` when confidence on any P0 item falls below 0.8, or when coverage gaps exceed 15% of total ACs.

**Traceability**: All produced test points must carry `source_ac_id` or `source_req_id` to enable downstream traceability in test management tools and N260 gate aggregation.


## Usage scenarios

- `acceptance_criteria_seed`: generate test points directly from AC documents before test cases exist.
- `requirement_gap_detection`: surface missing or untestable ACs in `coverage_gaps[]`.
- `nfr_integration`: incorporate performance, security, or compliance intents alongside functional points.
- `pre_automation_review`: produce a structured list for QA leads to review before test case authoring.
- `n230_chain_start`: first artifact in the N230 chain, feeding 081 and 082.

## v2 optimization addendum / contract-first behavior
Use this addendum as the controlling rule when it conflicts with older lightweight fields.

### Universal-first positioning
This skill must remain useful outside N230. Treat `workflow_node: N230` as an adapter tag, not as a hard dependency. When N230 inputs are absent, work from AC, rule, API, NFR, defect, or production-signal evidence and mark the source profile explicitly.

### V2 required upgrades
- Emit `contract_version: n230.test-design-artifact.v2` in metadata.
- Emit canonical `test_point_id`, while accepting legacy `tp_id` as an alias.
- Emit `test_point_kind` using TP1-TP8 from `references/test-intent-taxonomy.md`.
- Emit `test_perspective` using V01-V10 from `references/test-intent-taxonomy.md`.
- Score priority with the five-factor matrix in `references/priority-rules.md`.
- Assign `pyramid_tier` using `references/pyramid-tier-guide.md`.
- Mark P0 and compliance points with merge/release mandate flags.
- Include `event` metadata using `references/event-feedback-interface-v2.md`.

### Composition rules
- A TP3 boundary point should be consumable by `boundary-condition-generation`.
- A TP2 negative or TP7 security point should be consumable by `exception-scenario-generation`.
- A P0 test point should be consumable by `test-case-generation` or reported as a gate blocker.
- Use the shared ID namespace in `references/shared-artifact-contract-v2.md`.

### Node-level self-check
When multiple N230 artifacts are present, use `references/n230-node-checker-v2.md` to summarize aggregate pass/warn/block status instead of only checking this skill's own output.

### Updated reference files
- `references/shared-artifact-contract-v2.md`
- `references/event-feedback-interface-v2.md`
- `references/n230-node-checker-v2.md`
- `references/pyramid-tier-guide.md`
