---
name: test-case-generation
description: Write executable test cases with concrete QA steps from acceptance criteria, test points, and requirement structure; the runnable-scenario artifact downstream of test points.
---
# test-case-generation


## Routing decision table

| Situation | Action |
|---|---|
| Upstream test points available (from 080) | Use as primary seed; expand each TP into 1–3 test cases |
| No test points; AC available | Generate test cases directly; set `source: standalone_inferred` |
| Automation suitability unclear | Default to `semi_automated`; add note for human review |
| Test case would require production data | Mark `data_requirement: synthetic`; add sanitization note |
| GWT steps exceed 5 actions | Split into multiple test cases; maintain atomic scope |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n230.test-case.v2.2"
contract_version: "n230.v2.2"
workflow_node: "N230"
```


## Role / role positioning
This skill aligns to testing & qa -> test design -> 测试用例集.xlsx. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on executable cases with setup, steps, assertions, and automation tier.
- Convert test intent into runnable or reviewable cases without pretending tests were executed.
- Do not switch into regression scheduling, release sign-off, or defect triage.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `from_ac_mode`: derive cases directly from acceptance criteria.
- `from_tp_mode`: expand curated test points into cases.
- `bdd_mode`: generate Gherkin-style cases while preserving workflow metadata.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `测试点清单.csv`
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`
- `接口设计草案.yaml`
- `错误码清单.csv`
- known fixtures or environment assumptions

## Standalone rule / standalone usage
This skill must still work on a single test point, one acceptance criterion, or one API operation.

Degradation rules:
- If upstream test points are missing, derive a minimal testcase registry directly from acceptance criteria and tag each case as `seeded_without_tp`.
- If setup data is unclear, emit fixture proposals instead of inventing real environment facts.
- If assertions beyond response-level are uncertain, keep them explicit as `pending_state_assertion` or `pending_side_effect_assertion`.
- Preserve the same output shape even when only one case can be confirmed.

## Core output contract / core output contract
Default to spreadsheet-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.test_case_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 测试用例集.xlsx`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `case_summary`
- `fixtures[]`
- `test_cases[]`
- `automation_distribution`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every testcase must have a stable `tc_id` and should reference at least one `tp_id` or `ac_id`.
- Use `references/granularity-rules.md` to keep each case between 3 and 15 observable steps.
- Every important testcase should include assertions at response level, state level, and side-effect level when evidence exists.
- Prefer reusable fixtures over copy-pasted data setup.
- Cases must be order-independent unless explicitly declared as sharing a named fixture.
- Assign one `automation_tier` from `references/automation-tier-guide.md`.

## Execution workflow / execution workflow
1. Read acceptance criteria and available test points.
2. Group the scope into scenarios and derive reusable fixtures.
3. Write executable cases with preconditions, steps, data, and multilayer assertions.
4. Normalize independence and teardown expectations.
5. Assign automation tiers and downstream automation hints.
6. Emit traceability and readiness notes for N240 and N260.

## Dynamic completeness / dynamic completeness
- Small scope: produce a compact workbook-style set with direct traceability.
- Medium scope: add reusable fixtures, multilayer assertions, and automation distribution.
- Large scope: cluster cases by scenario or module and avoid bloated monolithic cases.
- If only smoke coverage is possible, mark missing negative, boundary, or exception expansions explicitly.


## Example usage

**Input**: test point TP-002 — "验证切换分类时列表局部刷新而非整页重载".

**Output** (`comprehensive_mode`, excerpt):
```yaml
tc_id: TC-002
tp_ref: TP-002
priority: P0
automation_suitability: automated
preconditions:
  - User is on /products page
  - At least 2 categories with products exist
steps:
  - Select category A; observe network requests
  - Select category B; observe network requests
expected_result:
  - Only XHR/fetch requests fire (no document reload)
  - Product list updates within 500ms
  - URL updates with ?category=B query param
cleanup: None required (read-only operation)
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Quality bar / quality bar
A good result should be close enough for qa or engineers to execute or automate without first re-deriving fixtures, assertions, or scope. The artifact must reduce ambiguity, not merely restate requirements.


## Auditable rules

- R01_executable_format: every test case must include preconditions, steps, expected result, and cleanup; on_violation: reject.
- R02_tp_traceability: each case must reference its parent test point id when available; on_violation: warn.
- R03_no_fabricated_data: test data must use synthetic, fixture, or parameterized values; never real PII or production data; on_violation: reject.
- R04_priority_from_tp: case priority must inherit from or be justified against parent test point priority; on_violation: warn.
- R05_automation_tag: each case must carry an `automation_suitability` tag (automated/manual/hybrid); on_violation: reject.
- R06_boundary_integration: boundary conditions from 082 must be reflected as dedicated cases or parameter variants; on_violation: flag_gap.
- R07_exception_integration: exception scenarios from 083 must produce at least one negative-path case each; on_violation: flag_gap.

## Algorithm

1. Read test points and ACs; map each point to one or more executable cases.
2. Apply R01: ensure every case has preconditions, steps, expected result, and cleanup.
3. Tag each case with `automation_suitability` (R05).
4. Integrate boundary and exception signals (R06, R07); create dedicated negative-path cases.
5. Assign and validate priority (R04); link to parent test point ids (R02).
6. Validate test data is synthetic (R03).
7. Produce `test_cases[]`, `coverage_matrix[]`, `automation_candidates[]`.
8. Run `self_check`; set `readiness: blocked` if R01, R03, or R05 fires.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files
- `references/quality-checklist.md`
- `references/common-failure-modes.md`
 / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/test-case-examples.md`
- `references/granularity-rules.md`
- `references/automation-tier-guide.md`
- `references/assertion-layers.md`
- `references/n230-integration-map.md`
- `references/template-skeleton.md`


- `references/example-io.md`
- `references/example-io-v2.md`



## Standalone usage guide

**Minimum input:** test point list from 080, or directly from AC / user story.

**When no upstream test points exist:**
1. Parse AC or user story directly; generate test cases with `source: standalone_inferred`.
2. Set `readiness: constrained` and `pending_tp_review: true`.
3. Tag all cases with `automation_suitability` based on step complexity.

**Minimum viable output:**
```yaml
test_case:
  tc_id: TC-S001
  source: standalone_inferred
  readiness: constrained
  pending_tp_review: true
  given: Registered user with valid credentials
  when: POST /auth/login
  then:
    - HTTP 200
    - response.token exists and is valid JWT
  automation_suitability: automated
  pyramid_layer: integration
```
**Downstream chain:** 081 test-cases → 082 boundary → 083 exception → 084 regression scope.

## Cross-skill integration map

| From skill | Provides | Consumed as |
|---|---|---|
| 080 test-point-generation | `test_point_list[]` | Seed for test case expansion |
| 082 boundary-condition-generation | `boundary_list[]` | Additional parameter variants per field |
| 083 exception-scenario-generation | `exception_scenarios[]` | Negative-path and failure-mode test cases |
| 089 test-failure-attribution | `failure_signature` | Regression backfill — new test cases for defect prevention |

**Standalone mode:** When no upstream test points are available, generate test cases directly from AC, user story, or feature description. Mark cases with `source: standalone_inferred` and set `readiness: constrained`.

**Minimum standalone output:**
```yaml
test_case:
  tc_id: TC-S001
  source: standalone_inferred
  readiness: constrained
  given: User with valid credentials
  when: POST /auth/login
  then:
    - HTTP 200
    - token present in response
  automation_suitability: automated
  pyramid_layer: integration
```

## Resilience and governance

**Produced events**: Emit `produced_event: produced.n230.test_case_list` in metadata when the artifact is complete or materially updated.

**SLA guidance**: P0 when any P0 test point has no executable test case; P1 when automation_suitability is missing

**Circuit breaker**: If boundary or exception integration gaps (R06/R07) persist across 3 runs, emit circuit_breaker: warn.

**Confidence scoring**: confidence scoring on automation_suitability: hybrid cases require human_review_required: true if confidence < 0.7.

**Escalation path**: When readiness: blocked due to missing P0 coverage, escalate to the test lead.

**Human review routing**: Set `human_review_required: true` when confidence on any P0 item falls below 0.8, or when coverage gaps exceed 15% of total ACs.

**Traceability**: All produced test points must carry `source_ac_id` or `source_req_id` to enable downstream traceability in test management tools and N260 gate aggregation.


## Usage scenarios

- `tp_expansion`: expand test points from 080 into fully executable step-by-step test cases.
- `automation_candidate_selection`: tag test cases with `automation_suitability` for CI integration.
- `regression_backfill`: create test cases from defect reproduction evidence to prevent recurrence.
- `boundary_integration`: consume boundary-condition output from 082 as additional parameter variants.
- `exception_integration`: consume exception-scenario output from 083 as negative-path cases.
- `n230_chain_middle`: central artifact in N230 chain, consuming 080 and feeding 084-088.

## v2 optimization addendum / executable-case contract
Use this addendum as the controlling rule when it conflicts with older lightweight fields.

### Universal-first positioning
This skill must remain useful outside N230. Treat `workflow_node: N230` as an adapter tag, not as a hard dependency. It may start from a TP, AC, API operation, state transition, boundary item, or exception scenario.

### V2 required upgrades
- Emit `contract_version: n230.test-design-artifact.v2` in metadata.
- Emit canonical `test_case_id`, while accepting legacy `tc_id` as an alias.
- Use explicit Given-When-Then for every testcase; see `references/gwt-data-driven-template.md`.
- Use `data_driven.enabled: true` when three or more rows share the same action/assertion pattern.
- Include `fixture_lifecycle` and teardown that matches setup.
- Include `assertion_coverage` across response, state, side-effect, observability, and governance layers when evidence exists.
- Include `pyramid_tier` plus `automation_tier` using `references/automation-tier-guide.md`.
- Include optional generated code templates from `references/code-template-catalog.md` when the user or N240 handoff asks for automation-ready output.
- Include `event` metadata using `references/event-feedback-interface-v2.md`.

### Composition rules
- In `from_tp_mode`, inherit priority, `pyramid_tier`, and merge/release mandate from the TP unless there is explicit evidence to override.
- Boundary rows from `boundary-condition-generation` should become data-driven rows where possible.
- Exception scenarios from `exception-scenario-generation` should become negative or resilience cases with fault-injection notes.
- P0 manual-only cases must be marked `gate_status: warn` unless explicitly approved.

### Node-level self-check
When multiple N230 artifacts are present, use `references/n230-node-checker-v2.md` to verify P0 TP to TC coverage, boundary-to-data-table usage, exception coverage, and N240/N260 readiness.

### Updated reference files
- `references/shared-artifact-contract-v2.md`
- `references/event-feedback-interface-v2.md`
- `references/n230-node-checker-v2.md`
- `references/gwt-data-driven-template.md`
- `references/code-template-catalog.md`
