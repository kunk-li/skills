---
name: test-case-generation
description: generate workflow-aligned executable test cases from acceptance criteria, test points, and requirement structure. use when chatgpt works in testing & qa / test design and must produce the workflow-aligned test-case artifact for n230 before automation orchestration, defect attribution, or quality-gate aggregation.
---
# test-case-generation

## Role / role positioning
This skill aligns to testing & qa -> test design -> 测试用例集.xlsx. It delivers a workflow-aligned artifact for N230.

### Boundary
- Focus on executable cases with setup, steps, assertions, and automation tier.
- Convert test intent into runnable or reviewable cases without pretending tests were executed.
- Do not switch into regression scheduling, release sign-off, or defect triage.

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `from_ac_mode`: derive cases directly from acceptance criteria.
- `from_tp_mode`: expand curated test points into cases.
- `bdd_mode`: generate Gherkin-style cases while preserving workflow metadata.

## Primary inputs / primary inputs
### workflow-aligned preferred inputs
- `验收标准.md`
- `需求质量审查单.md`
- `需求结构树.md`

### optional enhancement inputs
- `测试点清单.csv`
- `业务规则清单.csv`
- `状态流转表.csv`
- `权限矩阵.csv`
- `接口设计草案.yaml`
- `错误码清单.csv`
- known fixtures or environment assumptions

## Standalone rule / standalone usage
This skill must still work on a single test point, one acceptance criterion, or one API operation.

Degradation rules:
- If upstream test points are missing, derive a minimal testcase registry directly from acceptance criteria and tag each case as `seeded_without_tp`.
- If setup data is unclear, emit fixture proposals instead of inventing real environment facts.
- If assertions beyond response-level are uncertain, keep them explicit as `pending_state_assertion` or `pending_side_effect_assertion`.
- Preserve the same output shape even when only one case can be confirmed.

## Core output contract / core output contract
Default to spreadsheet-friendly tables and prioritize `references/output-template.md`.

The result must include at least:
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: testing_and_qa.test_design.test_case_generation`
  - `workflow_node: N230`
  - `node_artifact_target: 测试用例集.xlsx`
  - `evidence_profile`
  - `tool_collaboration_mode`
- `case_summary`
- `fixtures[]`
- `test_cases[]`
- `automation_distribution`
- `traceability_links[]`
- `downstream_handoff`
- `self_check`

## Design rules / design rules
- Every testcase must have a stable `tc_id` and should reference at least one `tp_id` or `ac_id`.
- Use `references/granularity-rules.md` to keep each case between 3 and 15 observable steps.
- Every important testcase should include assertions at response level, state level, and side-effect level when evidence exists.
- Prefer reusable fixtures over copy-pasted data setup.
- Cases must be order-independent unless explicitly declared as sharing a named fixture.
- Assign one `automation_tier` from `references/automation-tier-guide.md`.

## Execution workflow / execution workflow
1. Read acceptance criteria and available test points.
2. Group the scope into scenarios and derive reusable fixtures.
3. Write executable cases with preconditions, steps, data, and multilayer assertions.
4. Normalize independence and teardown expectations.
5. Assign automation tiers and downstream automation hints.
6. Emit traceability and readiness notes for N240 and N260.

## Dynamic completeness / dynamic completeness
- Small scope: produce a compact workbook-style set with direct traceability.
- Medium scope: add reusable fixtures, multilayer assertions, and automation distribution.
- Large scope: cluster cases by scenario or module and avoid bloated monolithic cases.
- If only smoke coverage is possible, mark missing negative, boundary, or exception expansions explicitly.

## Quality bar / quality bar
A good result should be close enough for qa or engineers to execute or automate without first re-deriving fixtures, assertions, or scope. The artifact must reduce ambiguity, not merely restate requirements.

## Reference files / reference files
- `references/output-template.md`
- `references/field-contract.md`
- `references/orchestration.md`
- `references/test-case-examples.md`
- `references/granularity-rules.md`
- `references/automation-tier-guide.md`
- `references/assertion-layers.md`
- `references/n230-integration-map.md`

## v2 optimization addendum / executable-case contract
Use this addendum as the controlling rule when it conflicts with older lightweight fields.

### Universal-first positioning
This skill must remain useful outside N230. Treat `workflow_node: N230` as an adapter tag, not as a hard dependency. It may start from a TP, AC, API operation, state transition, boundary item, or exception scenario.

### V2 required upgrades
- Emit `contract_version: n230.test-design-artifact.v2` in metadata.
- Emit canonical `test_case_id`, while accepting legacy `tc_id` as an alias.
- Use explicit Given-When-Then for every testcase; see `references/gwt-data-driven-template.md`.
- Use `data_driven.enabled: true` when three or more rows share the same action/assertion pattern.
- Include `fixture_lifecycle` and teardown that matches setup.
- Include `assertion_coverage` across response, state, side-effect, observability, and governance layers when evidence exists.
- Include `pyramid_tier` plus `automation_tier` using `references/automation-tier-guide.md`.
- Include optional generated code templates from `references/code-template-catalog.md` when the user or N240 handoff asks for automation-ready output.
- Include `event` metadata using `references/event-feedback-interface-v2.md`.

### Composition rules
- In `from_tp_mode`, inherit priority, `pyramid_tier`, and merge/release mandate from the TP unless there is explicit evidence to override.
- Boundary rows from `boundary-condition-generation` should become data-driven rows where possible.
- Exception scenarios from `exception-scenario-generation` should become negative or resilience cases with fault-injection notes.
- P0 manual-only cases must be marked `gate_status: warn` unless explicitly approved.

### Node-level self-check
When multiple N230 artifacts are present, use `references/n230-node-checker-v2.md` to verify P0 TP to TC coverage, boundary-to-data-table usage, exception coverage, and N240/N260 readiness.

### Updated reference files
- `references/shared-artifact-contract-v2.md`
- `references/event-feedback-interface-v2.md`
- `references/n230-node-checker-v2.md`
- `references/gwt-data-driven-template.md`
- `references/code-template-catalog.md`

### v2.0.1 release-candidate polish
- Use `references/shared-artifact-contract-v2.md` output file defaults for CSV/XLSX exports and automation handoff sheets.
- Keep IDs as text and keep data-table rows machine-readable for N240 ingestion.

### v2.0.2 release polish
- Use the contract evolution policy in `references/shared-artifact-contract-v2.md` when handling canonical fields, legacy aliases, schema changes, and compatibility.
- Use the worked order-creation example in `references/test-case-examples.md` when a user needs a concrete GWT, data-driven, fixture, and assertion-layer pattern.

### v2.0.3 hotfix

- Align the worked example in `references/test-case-examples.md` with the canonical automation tier enum. Use `t2_automated_integration`; avoid non-canonical service/API-specific aliases unless they are explicitly listed in `references/automation-tier-guide.md`.
