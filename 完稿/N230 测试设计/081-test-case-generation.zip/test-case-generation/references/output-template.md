# output template v2

Use workbook-friendly sheets or markdown sections that can be exported to xlsx.

## required sections
1. metadata
2. case_summary
3. fixtures
4. test_cases
5. data_driven_tables
6. automation_distribution
7. generated_code_templates
8. assertion_coverage
9. downstream_handoff
10. event
11. self_check

## required testcase columns
| test_case_id | title | test_point_ref | pyramid_tier | automation_tier | given | when | then_assertions | fixture_id | data_driven | expected_duration | ci_triggers | gate_status | notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

## optional generated_code columns
| framework | file_path | template_name | code_snippet |
|---|---|---|---|
