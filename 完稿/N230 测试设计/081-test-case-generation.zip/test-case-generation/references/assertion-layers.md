# assertion layers v2

Important cases should assert across multiple layers when evidence exists.

## response layer
- `response_status`
- `response_body`
- `response_header`
- error code and error details

## state layer
- `db_state`
- cache state
- event store state
- no unintended row changes

## side-effect layer
- `event_published`
- `external_call_made`
- notification sent or not sent
- compensation or rollback happened

## observability layer
- `log_emitted`
- `metric_emitted`
- trace id propagation
- alert signal

## governance layer
- `audit_event_created`
- authorization decision recorded
- data masking or retention control verified
