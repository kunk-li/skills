# Lifecycle-attempt callback regression cases

Use this reference only when an approved requirement, business rule, state transition, API contract, or schema defines lifecycle attempt or approval-instance identity.

## Required case shape

1. Derive the canonical identity fields from approved sources; do not infer aliases from generated code or existing tests.
2. Create a stale-callback negative where ticket, stage, and workflow references match the current binding, but the callback carries an older lifecycle attempt and/or approval instance after a newer binding is active. Keep signature validity and event delivery id distinct so they do not mask the identity condition.
3. Assert the source-defined stale rejection, no business-state advance, and the required rejection audit. Assert separately that no success event or success audit is emitted.
4. Pair the negative with a valid current-attempt positive control. Keep the existing duplicate-delivery/idempotency case as a separate control: callback event ids and retries are transport delivery identity, not lifecycle attempts.
5. If a required field or owner-wire alias is unresolved, list the exact mapping as pending and block readiness. Do not fabricate a field name or claim runtime behavior.

## Scope

This is a test-design requirement. It does not claim that generated code compiles, that a database constraint exists, or that a real callback integration passes. A generated implementation may be the subject under test, but approved source artifacts remain the oracle for expected behavior.
