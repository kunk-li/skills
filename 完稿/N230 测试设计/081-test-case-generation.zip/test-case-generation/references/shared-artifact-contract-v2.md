# N230 shared artifact contract v2

Use this contract in every N230 testing-design skill. The contract keeps each skill useful alone while making multiple skills stronger together.

## Contract identity
- `contract_version`: `n230.test-design-artifact.v2`
- `schema_version`: semantic version of the produced artifact, default `2.0.0`
- `producer_skill`: one of `test-point-generation`, `test-case-generation`, `boundary-condition-generation`, `exception-scenario-generation`
- `artifact_kind`: one of `test_points`, `test_cases`, `boundary_conditions`, `exception_scenarios`
- `workflow_node`: optional adapter value, default `N230`; do not make the skill unusable outside N230.
- `function_bias`: `direct_result`
- `selected_mode`: the mode used for this invocation
- `readiness`: `ready`, `constrained`, or `blocked`
- `evidence_profile`: `direct`, `mixed`, or `partial`
- `tool_collaboration_mode`: `standalone`, `chained`, or `gate_support`

## ID namespace
Use stable, human-readable ids. The domain segment must be shared across artifacts for the same feature or module.

| artifact | canonical pattern | accepted legacy alias |
|---|---|---|
| test point | `TP-{DOMAIN}-{NNN}` | none |
| test case | `TC-{DOMAIN}-{NNN}` | none |
| boundary item | `BND-{DOMAIN}-{NNN}` | `BC-{DOMAIN}-{NNN}` |
| exception scenario | `EXC-{DOMAIN}-{NNN}` | `ES-{DOMAIN}-{NNN}` |

Rules:
- Keep `{DOMAIN}` short and stable, such as `ORDER`, `USER`, `PAYMENT`, or `AUTH`.
- Preserve upstream ids when regenerating an artifact; append only when adding coverage.
- Every TC should link to at least one TP or AC.
- Every BND and EXC should link to at least one TP, TC, AC, rule, or dependency.

## Common traceability links
Each output item should carry the relevant subset of:
- `ac_refs`
- `rule_refs`
- `api_refs`
- `state_machine_refs`
- `nfr_refs`
- `vulnerability_refs`
- `tp_refs`
- `tc_refs`
- `dependency_refs`
- `source_artifacts`

If the source id does not exist, use a short evidence label and mark confidence as `partial` instead of inventing ids.

## Gate readiness
Every artifact should expose:
- `gate_status`: `pass`, `warn`, or `block`
- `gate_blockers`: list of missing evidence, missing links, or unsafe assumptions
- `mandatory_for_merge`: boolean for P0 or release-blocking coverage
- `mandatory_for_release`: boolean for release-critical coverage
- `confidence`: `high`, `medium`, or `low`

## Produced events
When the artifact is complete enough for a workflow handoff, include a lightweight event envelope:

```yaml
event:
  type: produced.n230.<artifact_kind>.v2
  contract_version: n230.test-design-artifact.v2
  producer_skill: <skill-name>
  artifact_id: <artifact-or-batch-id>
  readiness: ready|constrained|blocked
  gate_status: pass|warn|block
  consumed_by: [N240, N260]
```

Recommended event types:
- `produced.n230.test_points.v2`
- `produced.n230.test_cases.v2`
- `produced.n230.boundary_conditions.v2`
- `produced.n230.exception_scenarios.v2`
- `gate.n230.coverage.warn`
- `gate.n230.coverage.block`

## N005 feedback input adapter
If production signals are supplied, treat them as optional evidence and do not require N230-only context.

Accepted signal bundles:
- `defect_classification_table`
- `frequent_error_summary`
- `incident_postmortem`
- `user_feedback_cluster`
- `release_validation_failure`

Use production signals to increase priority, add regression coverage, and create missing exception or boundary scenarios. Mark items generated primarily from production feedback with `feedback_origin: N005`.

## Node-level aggregation checks
When multiple N230 artifacts are available, run these checks:
1. All artifacts declare `contract_version` and producer skill.
2. ID namespace is consistent across TP, TC, BND, and EXC artifacts.
3. Every P0 TP has at least one TC or a `gate_blocker` explaining the gap.
4. Every TP3 boundary point has at least one BND item or explicit waiver.
5. Every TP2 negative, TP7 security, external dependency, or failure path has at least one EXC item or explicit waiver.
6. Every mandatory item has traceability to AC, rule, API, NFR, vulnerability, dependency, or production feedback.
7. N240 handoff has automation tier, fixture, data, or fault-injection hints.
8. N260 handoff has P0 coverage, NFR coverage, boundary coverage, and exception coverage status.

## Output file format defaults (v2.0.1)
Use these defaults whenever the user or downstream workflow does not specify a stricter format.

### CSV defaults
- Encoding: UTF-8 without BOM.
- Delimiter: comma `,`.
- Quote character: double quote `"`; quote fields containing commas, newlines, or quotes.
- Line ending: LF (`\n`).
- Header row: required; use canonical English snake_case column names.
- Localized labels: optional second sheet or companion markdown table; do not replace canonical headers.
- Null value: empty cell for CSV, explicit `null` for JSON/YAML examples.
- Boolean values: `true` / `false` lowercase.
- Percent values: decimal ratio when machine-read, display percent only in narrative summaries.

### XLSX workbook defaults
- First sheet should be the canonical artifact sheet: `test_points`, `test_cases`, `boundary_conditions`, or `exception_scenarios`.
- Optional supporting sheets: `coverage_summary`, `traceability`, `gate_readiness`, `data_tables`, `fault_injection`.
- Keep IDs as text cells to preserve leading zeros.
- Freeze the header row and avoid merged headers in machine-consumed sheets.

### Markdown, YAML, and JSON defaults
- Markdown is for human review; YAML or JSON is for contract examples and event envelopes.
- Keep canonical IDs, contract_version, schema_version, producer_skill, artifact_kind, and gate_status visible in every structured export.

## Contract evolution policy (v2.0.2)
Treat this contract as the stable interface between standalone skills and N230 orchestration.

### Versioning rules
- `contract_version` identifies the cross-skill artifact contract. Breaking changes must create a new major contract, for example `n230.test-design-artifact.v3`.
- `schema_version` identifies the artifact shape inside the current contract. Additive, backward-compatible fields may increase the minor or patch version.
- Field removals, field renames, enum meaning changes, ID namespace changes, or requiredness changes are breaking and require a major version bump.
- New optional fields, new explanatory fields, new examples, or new non-blocking checks are backward-compatible.

### Legacy alias lifecycle
- Canonical IDs are `test_point_id`, `test_case_id`, `boundary_id`, and `scenario_id`.
- Legacy aliases such as `tp_id`, `tc_id`, `bc_id`, and `es_id` may be read through the whole v2 lifecycle.
- Producers should emit canonical fields in v2.0.2 and later; aliases may be emitted only for compatibility notes.
- Plan to remove legacy alias emission in the next major contract. Continue reading at least one previous major contract during migration unless explicitly impossible.

### Compatibility expectations
- Skills should read artifacts from the current major contract and at least one previous major contract when practical.
- When reading an older artifact, normalize legacy fields into canonical fields before applying node-level checks.
- When a downstream consumer cannot process a newer optional field, it should ignore the field rather than blocking the artifact.
- When a producer lacks evidence for a required field, it must emit a `gate_blocker` or `pending_*` tag rather than inventing data.

### Change governance
- Contract changes should be reviewed by owners of test-point, test-case, boundary, exception, automation, and quality-gate consumers.
- Any schema change must document: changed fields, migration impact, accepted aliases, expected downstream behavior, and rollback plan.
- Any major contract change must include at least one worked example and one aggregate checker example.
- Do not create per-skill minor versions for ordinary wording or reference updates; only contract-impacting changes should update contract metadata.

