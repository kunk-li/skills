# field contract v2 for test-case-generation

Use this file with `shared-artifact-contract-v2.md`.

## fixture fields
| field | requirement |
|---|---|
| `fixture_id` | stable reusable fixture name |
| `setup` | ordered setup actions |
| `teardown` | cleanup actions that match setup |
| `fixture_lifecycle` | `per_test`, `per_class`, or `per_suite` |
| `rationale` | why this lifecycle is safe |
| `sensitivity` | `none`, `pii_safe`, or `requires_anonymization` |

## testcase fields
| field | requirement |
|---|---|
| `test_case_id` | canonical `TC-{DOMAIN}-{NNN}` id; `tc_id` accepted as alias |
| `test_point_ref` | one or more `TP-*` ids when available |
| `title` | should-style or behavior title |
| `gwt.given` | setup and preconditions |
| `gwt.when` | exact action: api_call, method_invocation, event_publish, or command_execute |
| `gwt.then` | observable assertions |
| `fixture` | setup, teardown, lifecycle |
| `data_driven` | enabled, parameters, data_table, framework_syntax |
| `generated_code` | optional framework, file_path, and code template |
| `pyramid_tier` | unit, integration, e2e, or contract |
| `automation_tier` | t1-t4 execution strategy, mapped from pyramid tier |
| `execution_attributes` | duration, flakiness, tags, CI triggers |
| `assertion_coverage` | response, DB/state, events, external calls, audit |
| `gate_status` | pass, warn, or block |

## assertion kinds
Use one or more:
- `response_status`
- `response_body`
- `response_header`
- `db_state`
- `event_published`
- `side_effect_occurred`
- `external_call_made`
- `no_change_occurred`
- `exception_thrown`
- `log_emitted`
- `metric_emitted`
- `audit_event_created`
