# testcase examples v2

Use behavior-first titles and GWT structure.

## example title patterns
- `should create order when active user submits valid amount`
- `should reject order when amount exceeds maximum limit`
- `should keep database unchanged when validation fails`

## minimum good case
A good case includes:
- explicit fixture or precondition
- exact action
- concrete input values
- response assertion
- state or side-effect assertion when the behavior writes data
- teardown or isolation rule

## data-driven example families
Use data-driven cases for boundaries, validation matrices, role permissions, status transitions, and error-code tables.

## authoritative-state decision pair

When an API decision depends on an authoritative source, pair a valid-source positive with an adversarial caller-claim negative. The negative must vary the source fact or request claim and assert both the denial and the absence of success-side state or side effects.

```yaml
test_case_id: TC-AUTH-001
traceability_links:
  api_refs: [API-NOMINATION-001]
  rule_refs: [RULE-ELIGIBILITY-001]
  source_artifacts: [approved-eligibility-source]
priority: P0
pyramid_tier: integration
automation_tier: t2_automated_integration
fixture:
  lifecycle: per_test
  setup: [no eligible source record exists]
  teardown: [remove request, audit, and event fixtures]
gwt:
  given:
    description: caller sends eligible=true while the authoritative source has no current eligibility record
  when:
    action:
      kind: api_call
      http_method: POST
      path: /api/nomination
      body: {candidate_id: C-001, eligible: true}
  then:
    assertions:
      - assertion_kind: response_status
        layer: response
        expected_value: eligibility_denied
        comparison: equals
      - assertion_kind: db_state
        layer: state
        expected_value: no nomination ticket or idempotency reservation exists
        comparison: equals
      - assertion_kind: event_published
        layer: side_effect
        expected_value: no nomination success event was emitted
        comparison: equals
      - assertion_kind: audit_event_created
        layer: side_effect
        expected_value: no success audit was emitted
        comparison: equals
      - assertion_kind: external_call_made
        layer: side_effect
        expected_value: authoritative source lookup occurred at the decision boundary
        comparison: equals
companion_positive_case: TC-AUTH-000
```

## worked example: order creation with valid amount and boundary table

Use this example as the default shape for a high-quality `test-case-generation` output. It is intentionally compact but complete enough to show GWT, fixture, three assertion layers, data-driven rows, automation tier, pyramid tier, and a realistic `pending_*` tag.

### input context
```yaml
feature: order_creation
acceptance_criteria:
  - ac_id: AC-ORDER-001
    text: authenticated users can create an order when amount is within 1..500000 and at least one item is present
  - ac_id: AC-ORDER-002
    text: invalid order amount returns a specific validation error and must not create an order
linked_test_points:
  - test_point_id: TP-ORDER-001
    test_point_kind: TP1_functional_positive
    priority: P0
    pyramid_tier: integration
  - test_point_id: TP-ORDER-002
    test_point_kind: TP3_boundary
    priority: P0
    pyramid_tier: integration
api:
  method: POST
  path: /api/v1/orders
```

### generated test case item
```yaml
test_case_id: TC-ORDER-001
test_point_ref: TP-ORDER-001
title: should create order when active user submits valid amount
description: verifies the happy path for authenticated order creation and confirms response, database state, and audit side effects.
priority: P0
pyramid_tier: integration
automation_tier: t2_automated_integration
contract_version: n230.test-design-artifact.v2
schema_version: 2.0.2

fixture:
  lifecycle: per_test
  rationale: order creation writes database rows and audit events; isolation prevents cross-test leakage.
  setup:
    - kind: db_seed
      action: create active user user-123
    - kind: mock_setup
      action: mock inventory service to reserve sku-001 successfully
  teardown:
    - kind: db_cleanup
      action: delete orders, order_items, and audit_events for user-123

gwt:
  given:
    description: active user exists, inventory service is available, and order table is empty for this user.
    setup_refs: [fixture.setup]
  when:
    action:
      kind: api_call
      http_method: POST
      path: /api/v1/orders
      headers:
        Authorization: Bearer valid-user-123
        X-Idempotency-Key: idem-order-001
      body:
        amount: 100
        items:
          - sku: sku-001
            quantity: 1
  then:
    assertions:
      - assertion_kind: response_status
        layer: response
        expected_value: 201
        comparison: equals
      - assertion_kind: response_body
        layer: response
        expected_value:
          status: CREATED
          amount: 100
        comparison: contains
      - assertion_kind: db_state
        layer: state
        expected_value: one order row exists for user-123 with amount 100 and status CREATED
        comparison: equals
      - assertion_kind: event_published
        layer: side_effect
        expected_value: OrderCreated event emitted once with trace_id
        comparison: contains
      - assertion_kind: audit_event_created
        layer: side_effect
        expected_value: audit event ORDER_CREATED exists for user-123
        comparison: equals

execution_attributes:
  expected_duration: 500ms
  flakiness_tolerance: zero
  tags: [regression, critical_path]
  ci_integration:
    run_on_pr: true
    run_on_commit: true
    run_nightly: false
    run_on_release: true

traceability_links:
  ac_refs: [AC-ORDER-001]
  tp_refs: [TP-ORDER-001]
  api_refs: [POST /api/v1/orders]

gate_status: pass
gate_blockers: []
pending_tags:
  - tag: pending_contract_assertion
    reason: no formal consumer contract for OrderCreated event was supplied; verify event payload shape after API contract is available.
```

### data-driven companion case
Use a companion parameterized case when the same action and assertion shape covers multiple boundary values.

```yaml
test_case_id: TC-ORDER-002
test_point_ref: TP-ORDER-002
title: should validate order amount boundary values
data_driven:
  enabled: true
  parameters:
    - name: amount
      type: decimal
    - name: expected_status
      type: integer
    - name: expected_error_code
      type: string|null
    - name: expected_db_delta
      type: integer
  data_table:
    - [0, 422, ORDER_AMOUNT_OUT_OF_RANGE, 0]
    - [1, 201, null, 1]
    - [500000, 201, null, 1]
    - [500001, 422, ORDER_AMOUNT_OUT_OF_RANGE, 0]
    - [null, 400, AMOUNT_REQUIRED, 0]
  framework_syntax:
    junit5: '@ParameterizedTest + @CsvSource'
    pytest: '@pytest.mark.parametrize'
    jest: 'test.each([...])'
```

### implementation notes
- Put response assertions first because they explain user-visible behavior.
- Add state assertions whenever the behavior writes or must not write data.
- Add side-effect assertions for events, audit, metrics, logs, or external calls.
- Keep `pending_*` tags explicit; do not silently omit unverifiable assertions.
- In `from_tp_mode`, inherit TP priority, pyramid tier, and merge/release mandates unless explicit evidence justifies override.



## lifecycle-attempt callback pair

Use this pair only when an approved source defines attempt or approval-instance identity. Keep ticket, stage and workflow equal in the stale callback so the test isolates the missing lifecycle dimension. A source-defined stale-rejection audit is not a success-side event.

```yaml
test_case_id: TC-WF-ATTEMPT-001
test_point_ref: TP-WF-CALLBACK-001
priority: P0
gwt:
  given: the current binding is ticket T1, stage S2, workflow W1, attempt 2, approval instance A2; a validly signed callback carries the same ticket/stage/workflow but attempt 1 and instance A1
  when: the stale callback arrives with a unique delivery event id
  then:
    - response_status: stale_attempt_rejected
    - db_state: current attempt 2 and its approval instance remain active; business stage does not advance
    - audit_event_created: the source-prescribed stale-callback rejection is recorded once
    - event_published: no approval-success event is emitted
companion_positive_case: TC-WF-ATTEMPT-002
gate_status: block
```

The positive companion accepts attempt 2/A2; replaying the same delivery event id does not apply a second business mutation. Replace field names or expected error codes only when an explicit owner/API mapping supplies them.
