# testcase examples v2

Use behavior-first titles and GWT structure.

## example title patterns
- `should create order when active user submits valid amount`
- `should reject order when amount exceeds maximum limit`
- `should keep database unchanged when validation fails`

## minimum good case
A good case includes:
- explicit fixture or precondition
- exact action
- concrete input values
- response assertion
- state or side-effect assertion when the behavior writes data
- teardown or isolation rule

## data-driven example families
Use data-driven cases for boundaries, validation matrices, role permissions, status transitions, and error-code tables.

## worked example: order creation with valid amount and boundary table

Use this example as the default shape for a high-quality `test-case-generation` output. It is intentionally compact but complete enough to show GWT, fixture, three assertion layers, data-driven rows, automation tier, pyramid tier, and a realistic `pending_*` tag.

### input context
```yaml
feature: order_creation
acceptance_criteria:
  - ac_id: AC-ORDER-001
    text: authenticated users can create an order when amount is within 1..500000 and at least one item is present
  - ac_id: AC-ORDER-002
    text: invalid order amount returns a specific validation error and must not create an order
linked_test_points:
  - test_point_id: TP-ORDER-001
    test_point_kind: TP1_functional_positive
    priority: P0
    pyramid_tier: integration
  - test_point_id: TP-ORDER-002
    test_point_kind: TP3_boundary
    priority: P0
    pyramid_tier: integration
api:
  method: POST
  path: /api/v1/orders
```

### generated test case item
```yaml
test_case_id: TC-ORDER-001
test_point_ref: TP-ORDER-001
title: should create order when active user submits valid amount
description: verifies the happy path for authenticated order creation and confirms response, database state, and audit side effects.
priority: P0
pyramid_tier: integration
automation_tier: t2_automated_integration
contract_version: n230.test-design-artifact.v2
schema_version: 2.0.2

fixture:
  lifecycle: per_test
  rationale: order creation writes database rows and audit events; isolation prevents cross-test leakage.
  setup:
    - kind: db_seed
      action: create active user user-123
    - kind: mock_setup
      action: mock inventory service to reserve sku-001 successfully
  teardown:
    - kind: db_cleanup
      action: delete orders, order_items, and audit_events for user-123

gwt:
  given:
    description: active user exists, inventory service is available, and order table is empty for this user.
    setup_refs: [fixture.setup]
  when:
    action:
      kind: api_call
      http_method: POST
      path: /api/v1/orders
      headers:
        Authorization: Bearer valid-user-123
        X-Idempotency-Key: idem-order-001
      body:
        amount: 100
        items:
          - sku: sku-001
            quantity: 1
  then:
    assertions:
      - assertion_kind: response_status
        layer: response
        expected_value: 201
        comparison: equals
      - assertion_kind: response_body
        layer: response
        expected_value:
          status: CREATED
          amount: 100
        comparison: contains
      - assertion_kind: db_state
        layer: state
        expected_value: one order row exists for user-123 with amount 100 and status CREATED
        comparison: equals
      - assertion_kind: event_published
        layer: side_effect
        expected_value: OrderCreated event emitted once with trace_id
        comparison: contains
      - assertion_kind: audit_event_created
        layer: side_effect
        expected_value: audit event ORDER_CREATED exists for user-123
        comparison: equals

execution_attributes:
  expected_duration: 500ms
  flakiness_tolerance: zero
  tags: [regression, critical_path]
  ci_integration:
    run_on_pr: true
    run_on_commit: true
    run_nightly: false
    run_on_release: true

traceability_links:
  ac_refs: [AC-ORDER-001]
  tp_refs: [TP-ORDER-001]
  api_refs: [POST /api/v1/orders]

gate_status: pass
gate_blockers: []
pending_tags:
  - tag: pending_contract_assertion
    reason: no formal consumer contract for OrderCreated event was supplied; verify event payload shape after API contract is available.
```

### data-driven companion case
Use a companion parameterized case when the same action and assertion shape covers multiple boundary values.

```yaml
test_case_id: TC-ORDER-002
test_point_ref: TP-ORDER-002
title: should validate order amount boundary values
data_driven:
  enabled: true
  parameters:
    - name: amount
      type: decimal
    - name: expected_status
      type: integer
    - name: expected_error_code
      type: string|null
    - name: expected_db_delta
      type: integer
  data_table:
    - [0, 422, ORDER_AMOUNT_OUT_OF_RANGE, 0]
    - [1, 201, null, 1]
    - [500000, 201, null, 1]
    - [500001, 422, ORDER_AMOUNT_OUT_OF_RANGE, 0]
    - [null, 400, AMOUNT_REQUIRED, 0]
  framework_syntax:
    junit5: '@ParameterizedTest + @CsvSource'
    pytest: '@pytest.mark.parametrize'
    jest: 'test.each([...])'
```

### implementation notes
- Put response assertions first because they explain user-visible behavior.
- Add state assertions whenever the behavior writes or must not write data.
- Add side-effect assertions for events, audit, metrics, logs, or external calls.
- Keep `pending_*` tags explicit; do not silently omit unverifiable assertions.
- In `from_tp_mode`, inherit TP priority, pyramid tier, and merge/release mandates unless explicit evidence justifies override.

