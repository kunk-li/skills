# GWT and data-driven template

## GWT structure
Use this structure for each executable testcase.

```yaml
gwt:
  given:
    description: <preconditions>
    setup:
      - step: 1
        action: <fixture or mock setup>
        data_needed: <object>
  when:
    description: <action>
    action:
      api_call:
        http_method: POST
        path: /example
        headers: {}
        body: {}
  then:
    description: <expected observable result>
    assertions:
      - assertion_kind: response_status
        expected_value: 201
        comparison: equals
        error_message_if_fail: <message>
```

## when action types
- `api_call`
- `method_invocation`
- `event_publish`
- `command_execute`

## data-driven rule
Use data-driven form when three or more cases share the same action and assertion pattern.

```yaml
data_driven:
  enabled: true
  parameters:
    - param_name: amount
      type: BigDecimal
    - param_name: expected_status
      type: int
  data_table:
    - [0, 422]
    - [1, 201]
    - [500000, 201]
    - [500001, 422]
  framework_syntax:
    junit5: "@ParameterizedTest + @CsvSource"
    pytest: "@pytest.mark.parametrize"
    jest: "test.each([...])"
```
