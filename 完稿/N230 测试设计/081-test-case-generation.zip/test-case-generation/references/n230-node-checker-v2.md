# N230 node-level checker v2

Use this checker after one or more N230 skills have produced artifacts. It is a design-time and review-time checklist, not a runtime test execution report.

## Inputs
Accept any subset of these artifacts:
- test point artifact from `test-point-generation`
- test case artifact from `test-case-generation`
- boundary artifact from `boundary-condition-generation`
- exception artifact from `exception-scenario-generation`
- production signal adapter evidence from N005

## Output
Return `n230_aggregate_check` with:
- `overall_status`: `pass`, `warn`, or `block`
- `contract_status`
- `traceability_status`
- `coverage_status`
- `n240_handoff_status`
- `n260_gate_status`
- `open_gaps[]`
- `recommended_next_skill_calls[]`

## Required checks
| check_id | check | block condition |
|---|---|---|
| C01 | all artifacts expose `contract_version` and `schema_version` | missing on final handoff |
| C02 | ids follow the shared namespace | duplicate or conflicting ids |
| C03 | every P0 TP has one or more TC links | P0 TP has no TC and no waiver |
| C04 | P0 AC has positive, negative, and boundary coverage | missing kind without waiver |
| C05 | every TP3 boundary has BND coverage | missing BND for mandatory boundary |
| C06 | every TP2, TP7, external dependency, or failure path has EXC coverage | missing EXC for mandatory failure path |
| C07 | automation handoff contains tier, fixture, data, or code-template hints | N240 cannot consume artifact |
| C08 | gate handoff contains P0, NFR, boundary, and exception status | N260 cannot decide gate |
| C09 | production-signal-derived items are traceable to N005 evidence | feedback coverage cannot be audited |
| C10 | unsafe chaos, resource, or destructive tests are marked non-prod unless explicitly approved | unsafe execution guidance |

## Status mapping
- `pass`: all mandatory checks pass; only minor optional gaps remain.
- `warn`: output is useful but has non-blocking gaps or partial evidence.
- `block`: downstream automation or gate cannot safely consume the artifact.

## Recommended next skill calls
When gaps are found, recommend the next targeted skill:
- Missing coverage scaffold -> call `test-point-generation`.
- Missing executable case -> call `test-case-generation`.
- Missing edge values -> call `boundary-condition-generation`.
- Missing failure or recovery behavior -> call `exception-scenario-generation`.
