# 测试质量检查清单

> 本文件为 N230 测试设计技能组共享参考。

## 测试点质量标准

- [ ] 每个测试点有明确的 intent（happy_path / negative / boundary / nfr_*）
- [ ] 每个测试点标注 priority（P0/P1/P2）
- [ ] 每个测试点标注 automation_suitability（automated / semi / manual）
- [ ] 每个测试点标注 pyramid_layer（unit / integration / e2e / performance）
- [ ] coverage_gaps[] 列出所有未覆盖的 AC 条目

## 测试用例质量标准

- [ ] Given/When/Then 格式，每步可独立验证
- [ ] 断言精确到字段级（非仅 HTTP 状态码）
- [ ] 测试数据与生产数据隔离
- [ ] 无隐式依赖（测试可独立运行）

## 边界条件覆盖要求

- [ ] 每个约束字段覆盖：min、max、below_min、above_max
- [ ] 可选字段有 empty/null 情况
- [ ] 多字段交互边界标注 combination_boundary_flagged: true

## 异常场景覆盖要求

- [ ] 每个外部依赖有至少 1 个失败场景
- [ ] 重试路径标注 idempotency_required: true
- [ ] 非关键依赖失败场景包含降级预期行为

## 权威状态与伪造输入

- [ ] 当资格、授权、归属、审批或账户状态取决于服务端权威记录时，覆盖调用方声称有利状态但来源缺失、过期、冲突、越权或状态不合格的负例，并保留有效来源正例。
- [ ] 负例断言服务端在决策边界重读来源、拒绝或忽略调用方声明，且没有成功侧状态写入、成功事件或成功审计。
- [ ] 请求允许携带权威字段时，改变该字段并证明它不能覆盖来源事实；请求不允许该字段时，断言契约拒绝或忽略它。


## Lifecycle-attempt callbacks

- [ ] If an approved source defines a callback key containing a lifecycle attempt or approval instance, include a stale-attempt case with ticket, stage and workflow held constant while only the prior attempt/instance is stale.
- [ ] Assert rejection and no business-state advance; assert the source-prescribed rejection audit separately from success events.
- [ ] Pair the stale negative with a valid current-attempt control; keep delivery event ids/retries distinct from lifecycle attempts.
- [ ] If required source fields or wire aliases are unresolved, preserve them as pending and keep readiness blocked rather than inventing fields.
