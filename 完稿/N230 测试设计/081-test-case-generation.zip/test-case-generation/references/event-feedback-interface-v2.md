# Event and feedback interface v2

Use this interface to align N230 skills with the reactive workflow model.

## Produced events
Every final artifact should include an event envelope in metadata. Do not actually publish the event unless the runtime platform provides an event bus; include it as a handoff object.

```yaml
event:
  type: produced.n230.test_points.v2
  producer_skill: test-point-generation
  contract_version: n230.test-design-artifact.v2
  artifact_kind: test_points
  readiness: ready
  gate_status: pass
  consumed_by: [N240, N260, N390]
```

## Event consumers
- N240 consumes test cases, automation tiers, fixtures, generated code hints, data tables, boundary values, and fault-injection hints.
- N250 consumes failure categories, reproduction hints, recovery expectations, and defect taxonomy mappings.
- N260 consumes P0 coverage, NFR coverage, boundary coverage, exception coverage, and gate blockers.
- N390 consumes quality scoring, template conformance, and audit evidence.

## Feedback signals from N005
When production or test feedback is present, use it as evidence to strengthen coverage:
- frequent errors -> add negative, exception, or regression test points
- incident postmortems -> add recovery and resource-exhaustion scenarios
- defect classification -> increase priority and add regression tests
- NPS or user feedback clusters -> add user-visible failure or journey tests

## Feedback handling rules
- Never overwrite requirement-derived coverage with feedback-derived coverage; add linked regression coverage.
- Mark feedback-derived artifacts with `feedback_origin: N005`.
- If a feedback signal is severe but source details are incomplete, emit a `gate_status: warn` item and add a clarification gap.
- If a feedback signal indicates data loss, security exposure, compliance breach, or financial loss, raise the affected item to P0 unless evidence disproves it.
