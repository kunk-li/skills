# orchestration v2

## role
`test-case-generation` converts coverage intent into executable or reviewable cases with GWT, fixtures, data tables, assertions, and automation hints.

## standalone use
The skill may run from one TP, one AC, one API operation, one boundary item, or one exception scenario. If TP input is missing, tag cases as `seeded_without_tp`.

## composition
- Consume TP priority, pyramid tier, and mandatory flags when available.
- Convert BND rows into data-driven tables when three or more rows share the same action/assertion pattern.
- Convert EXC scenarios into negative or resilience test cases with explicit fault-injection setup.
- Keep TC independence and teardown strict so N240 can automate safely.

## handoff
- To N240: fixture setup, data tables, automation tier, CI trigger hints, optional code templates.
- To N260: P0 case coverage, assertion completeness, independence status, manual-only warnings.
