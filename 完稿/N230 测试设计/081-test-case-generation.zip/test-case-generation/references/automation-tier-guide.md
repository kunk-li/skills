# automation tier guide v2

Keep both automation tier and pyramid tier.

| automation_tier | pyramid_tier | default trigger |
|---|---|---|
| `t1_automated_unit` | `unit` | every commit |
| `t2_automated_integration` | `integration` or `contract` | every PR |
| `t3_automated_e2e` | `e2e` | nightly or release |
| `t4_manual` | any, only with rationale | release or exploratory session |

Rules:
- Prefer automated coverage for P0/P1.
- P0 manual-only coverage requires a `gate_status: warn` or explicit approval note.
- Use `contract` for service-to-service assertions.
- Put flaky, slow, destructive, and chaos-style cases outside commit triggers unless isolated.
