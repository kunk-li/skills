# code template catalog

Generate code only when the user asks for code or when N240 automation handoff requires it. Keep templates compilable in spirit, but do not claim they were executed.

## junit5 unit template
```java
@Test
@DisplayName("{title}")
void {methodName}() {
    // Given
    {setupCode}
    // When
    {actionCode}
    // Then
    {assertionCode}
}
```

## junit5 parameterized template
```java
@ParameterizedTest
@CsvSource({
    "{row1}",
    "{row2}"
})
void {methodName}({params}) {
    // Given
    {setupCode}
    // When
    {actionCode}
    // Then
    {assertionCode}
}
```

## pytest template
```python
@pytest.mark.parametrize("{params}", [
    {rows}
])
def test_{name}({params}):
    # Given
    {setup_code}
    # When
    {action_code}
    # Then
    {assertion_code}
```

## playwright template
```ts
test('{title}', async ({ page }) => {
  // Given
  {setupCode}
  // When
  {actionCode}
  // Then
  {assertionCode}
});
```
