# N230 示例输入输出 v2（扩展场景）

## 示例 3：异常场景生成（exception-scenario-generation）

### 输入
- 依赖服务：payment-gateway（外部 REST API）
- 失败注入成熟度目标：L2

### 输出
```yaml
exception_scenarios:
  - dependency: payment-gateway
    scenario: connection_timeout
    inject: delay 5000ms
    expected_behavior: retry × 3 then return 503
    idempotency_required: true
  - dependency: payment-gateway
    scenario: invalid_response_schema
    inject: return malformed JSON
    expected_behavior: parse error caught, fallback to cached price
```

## 示例 4：测试用例生成（test-case-generation）

### 输入
- 测试点：TP-001（有效登录）

### 输出
```yaml
test_case:
  tc_id: TC-001
  source_tp: TP-001
  given: 注册用户，密码正确
  when: POST /auth/login
  then:
    - HTTP 200
    - response.token 存在
    - redirect_url == /dashboard
  automation_suitability: automated
  pyramid_layer: e2e
```

## 081 扩展示例输入输出

### Scenario B — Test case from boundary condition

**Input**: Boundary condition from 082: `password` field, min_length=4, max_length=128.

**Output** (`boundary_integration` mode):
```yaml
test_cases:
  mode: boundary_integration
  source_boundary_ref: BC-password-001
  cases:
    - tc_id: TC-B001
      given: Password of exactly 4 characters (minimum boundary)
      when: POST /auth/register with password="abcd"
      then: [HTTP 201, account created]
      automation_suitability: automated
    - tc_id: TC-B002
      given: Password of exactly 128 characters (maximum boundary)
      when: POST /auth/register with password=(128 chars)
      then: [HTTP 201]
    - tc_id: TC-B003
      given: Password of 3 characters (below minimum)
      then: [HTTP 400, error.code=="MIN_LENGTH_VIOLATION"]
```



### Scenario C — Regression backfill from defect

**Input**: Defect: order total calculated incorrectly when promo code applied to discount-ineligible item.

**Output** (`regression_backfill` mode):
```yaml
test_cases:
  mode: regression_backfill
  source_defect: DEF-4821
  cases:
    - tc_id: TC-REG-001
      purpose: prevent_recurrence
      given: Cart with 1 eligible item ($20) and 1 ineligible item ($15), promo code SAVE10
      when: POST /api/v1/checkout/calculate-total
      then:
        - total == 18.00 (10% off $20 only; $15 not discounted)
        - HTTP 200
      automation_suitability: automated
      pyramid_layer: integration
      regression_marker: DEF-4821
```

### Scenario D — Regression backfill from defect

**Input**: Defect DEF-4821 — order total calculated incorrectly when promo applied to ineligible item.

**Output** (`regression_backfill` mode):
```yaml
test_cases:
  mode: regression_backfill
  source_defect: DEF-4821
  cases:
    - tc_id: TC-REG-001
      purpose: prevent_recurrence
      given: Cart with 1 eligible item ($20) and 1 ineligible item ($15), promo SAVE10
      when: POST /api/v1/checkout/calculate-total
      then:
        - total == 18.00 (10% off $20 only; $15 excluded)
        - HTTP 200
      automation_suitability: automated
      pyramid_layer: integration
      regression_marker: DEF-4821
    - tc_id: TC-REG-002
      purpose: boundary_around_defect
      given: Cart with only ineligible items, promo SAVE10
      when: POST /api/v1/checkout/calculate-total
      then:
        - No discount applied
        - HTTP 200
```
