# Quality checklist

First apply the common checklist in `shared-requirement-definition-contract.md`.

## Skill-specific checks

- A newcomer can understand why, who, what, and not-what.
- Facts and assumptions are separated.
- Scope/non-scope is explicit.

- Metadata `workflow_node` is a real host workflow identifier, not a placeholder.
- Anti-patterns AP-01 through AP-10 and the five skill-specific AP rows have been checked.
