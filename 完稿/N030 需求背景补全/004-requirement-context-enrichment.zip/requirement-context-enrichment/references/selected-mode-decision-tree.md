# Selected-mode decision tree

Choose exactly one selected_mode:

- `prd_context_brief`: use when prd context brief is the closest operating mode.
- `cluster_context_enrichment`: use when cluster context enrichment is the closest operating mode.
- `scope_boundary_clarification`: use when scope boundary clarification is the closest operating mode.
- `newcomer_preread`: use when newcomer preread is the closest operating mode.
- `partial_context_gap_analysis`: use when partial context gap analysis is the closest operating mode.

Validation rule: metadata `selected_mode` must match one of the modes above and the schema enum.
