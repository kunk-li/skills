# Requirement-definition id space

## Artifact id

Use `CONTEXT-ARTIFACT-<scope>-<yyyymm>` for sidecar `artifact_id`.

Example: `CONTEXT-ARTIFACT-checkout-202605`.

## Row or section id

Primary id field: `context_id`.
Expected pattern: `^CTX-[a-z0-9_]+-\d{3,}$`.
Example: `CTX-checkout-001`.

## Multi-value cells

Use `|` as the delimiter in CSV multi-value cells. Do not use bare commas inside machine-readable id lists.
