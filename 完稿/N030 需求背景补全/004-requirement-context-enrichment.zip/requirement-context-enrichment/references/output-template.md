# Output template

Produce `requirement-context-brief.md` as Markdown.

# Requirement Context Enrichment Output

artifact id: <artifact_id>  
context_id: <id>

## Business Background And Goal

- confirmed facts:
- reasonable assumptions:
- open questions:

## Scope And Non-Scope

- confirmed facts:
- reasonable assumptions:
- open questions:

## Actors And Responsibilities

- confirmed facts:
- reasonable assumptions:
- open questions:

## Key Terms

- confirmed facts:
- reasonable assumptions:
- open questions:

## End-To-End Scenario

- confirmed facts:
- reasonable assumptions:
- open questions:

## Confirmed Facts Assumptions And Open Questions

- confirmed facts:
- reasonable assumptions:
- open questions:

## Newcomer Misunderstandings

- confirmed facts:
- reasonable assumptions:
- open questions:


Keep evidence labels visible. Do not write unsupported conclusions as facts.
