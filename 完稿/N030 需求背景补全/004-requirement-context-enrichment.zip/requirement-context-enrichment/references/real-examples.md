# Real Examples / 真实示例参考

These examples illustrate correct context brief sections and common enrichment patterns.

---

## Example 1: Scope boundary clarification

**Scenario**: A requirement cluster covers "invoice title persistence during checkout" but reviewers are unsure whether the mobile app and the web app are both in scope.

**Correct pattern for `## Scope boundaries`**:
```markdown
## Scope boundaries

In scope:
- Web checkout flow (confirmed via REQ-checkout-001)
- Mobile checkout flow (inferred from REQ-checkout-003; confirm with engineering)

Out of scope (explicitly):
- Invoice template design
- Payment method changes
- Third-party billing integrations

[evidence: REQ-checkout-003 is reasonable_assumption for mobile; confirm before implementation]
```

**Anti-pattern**: Writing "all checkout flows" without distinguishing web from mobile — this hides a scope uncertainty that could delay delivery.

---

## Example 2: Newcomer pre-read with domain terms

**Scenario**: A new designer joins the team and needs to understand "invoice title" in the context of the checkout requirement.

**Correct pattern for `## Key terms and definitions`**:
```markdown
## Key terms and definitions

- **Invoice title**: The label displayed on the invoice PDF, set by the buyer during checkout. Must match the company name registered in the tax system.
- **Billing address edit**: The step in checkout where buyers update the shipping or billing address. Triggers a re-render of the checkout summary, which may reset certain fields.
- **Finance admin**: The buyer role responsible for managing invoices and tax compliance for their organization.
```

---

## Example 3: Partial context gap analysis

**Scenario**: The context brief is requested for a vague requirement with no evidence of user roles.

**Correct pattern**:
```
readiness: partial
confidence: low
## Actors and roles
[evidence: open question] — No source material specifies who initiates or completes this action. Assumed to be a general user until confirmed.
## Open questions
1. Which user role is primarily affected?
2. Is this a new feature or a fix to existing behavior?
```
