# Anti-patterns

## v1.3.0 release guard note

This version adds upstream metadata sidecars, 7-in-1 release consistency with handoff integration, and retired-version checks. Do not reintroduce v1.1/v1.2 contract tokens, placeholder workflow identifiers, private workflow-node codes, or order-bound skill ids.


Use this file as both review guidance and regression-test seed material. The first ten checks are shared across the suite; the last five are skill-specific.

| id | anti-pattern | why harmful | validator/check coverage | correct pattern |
| --- | --- | --- | --- | --- |
| AP-01 | inventing evidence or source ids | downstream cannot trace the claim | artifact and metadata validators require evidence refs | add a source anchor or mark needs_human_review |
| AP-02 | using private workflow node codes in artifacts | breaks host-workflow portability | node-neutrality guard fails it | use semantic route tokens |
| AP-03 | using depends_on or blocks fields | implies hidden order and violates standalone use | order-neutrality guard fails it | use composable_with in SKILL.md only |
| AP-04 | overconfident output from one weak source | looks reliable but is not | confidence/readiness checks and review checklist | mark low or needs_human_review |
| AP-05 | turning analysis into roadmap ranking | crosses skill boundary | quality checklist flags it | handoff to planning route without ranking |
| AP-06 | leaving metadata sidecar stale | audit and routing disagree with the artifact | validate_metadata and release_consistency catch drift | update metadata with the artifact |
| AP-07 | using placeholder workflow identifiers | host context becomes ambiguous | metadata validator rejects placeholder workflow_node | supply an actual host workflow identifier |
| AP-08 | hiding open questions | uncertainty disappears from later analysis | required open question fields or sections | state unresolved questions explicitly |
| AP-09 | mixing facts and assumptions | reviewers cannot tell evidence from inference | quality checklist and markdown section checks | separate confirmed facts, assumptions, and open questions |
| AP-10 | embedding private contact or secret data | privacy and security risk | artifact validator warns on email/token patterns | redact private data and keep source anchors |
| AP-CTX-01 | inventing business rules | brief becomes false authority | facts/assumptions sections required | mark as assumption or open question |
| AP-CTX-02 | omitting non-scope | scope creep reaches planning | scope and non-scope section required | write explicit non-scope boundaries |
| AP-CTX-03 | skipping actors | journey and pain analysis lose role context | actors section required | list actors and responsibilities |
| AP-CTX-04 | using jargon without terms | newcomers cannot review | key terms section required | define terms with evidence |
| AP-CTX-05 | missing context id | handoff cannot reference the brief | markdown id pattern warning | include CTX-<scope>-<nnn> |
