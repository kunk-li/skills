---
name: requirement-context-enrichment
display_name: 需求背景补全 / Requirement Context Enrichment
description: enrich requirement or prd material into a readable business-context brief covering goals, actors, scope boundaries, terms, scenarios, assumptions, and open questions. use when reviewers, designers, engineers, or stakeholders need the context behind a requirement for user insight, competitor research, planning, or structured modeling. not for inventing unsupported rules, making prioritization decisions, or writing technical design.
---

# Requirement Context Enrichment / 需求背景补全

## Contract baseline

- contract_version: `requirement-definition-suite-v1.3.0`
- skill_id: `requirement-context-enrichment`
- schema: `requirement.context.v4`
- artifact_target: `requirement-context-brief.md`
- selected_mode: `prd_context_brief / cluster_context_enrichment / scope_boundary_clarification / newcomer_preread / partial_context_gap_analysis`
- composable_with: `requirement-collection-consolidation, requirement-deduplication-and-clustering, user-pain-point-analysis, user-journey-analysis`
- downstream_route_tokens: `pain_analysis, journey_analysis, planning_intake, structured_modeling`

This skill is self-contained and can run directly on partial input. It may compose with sibling skills, but it must not require them as prerequisites or encode private workflow node ids.

## Use this skill to

- Convert messy input into the skill's contracted deliverable while keeping source traceability.
- Preserve uncertainty, conflict, missing context, and evidence boundaries.
- Produce artifacts that can be validated locally before handoff.

## Do not use this skill to

- technical design; quality gate approval; roadmap commitment.
- Invent facts, user needs, source ids, evidence, priorities, or delivery commitments.
- Replace downstream planning, technical design, quality gates, or final approval.

## Required output sections

The `requirement-context-brief.md` must contain these sections. Mark any section as `[evidence: assumption]` or `[evidence: open question]` when the content is not confirmed.

| section | required | content |
| --- | --- | --- |
| `## Overview` | required | one-paragraph summary of the requirement or cluster |
| `## Goals and success criteria` | required | what success looks like, with evidence status |
| `## Actors and roles` | required | user roles, system actors, and stakeholders |
| `## Scope boundaries` | required | what is in scope and what is explicitly out of scope |
| `## Key terms and definitions` | required | domain terms needed to understand the requirement |
| `## Scenarios and examples` | required | at least one concrete usage scenario |
| `## Assumptions` | required | stated assumptions with evidence status |
| `## Open questions` | required | unresolved questions that must be answered before handoff |
| `## Evidence and source refs` | required | source anchors and evidence references |
| `## Downstream handoff` | required | route tokens and next recommended skill or gate |

## Required output

Produce `requirement-context-brief.md` as Markdown using `references/output-template.md`; keep required sections and evidence labels.

Always produce a sidecar metadata file with the same basename and `.metadata.yaml` suffix. Metadata must include `artifact_id`, `skill_id`, `contract_version`, `schema`, `workflow_node`, `selected_mode`, `readiness`, `confidence`, `source_artifacts`, `evidence_refs`, and `downstream_routes`.

## Workflow

1. Identify source materials, evidence anchors, roles, scope, dates, and uncertainty.
2. Select one `selected_mode` using `references/selected-mode-decision-tree.md`.
3. Read `references/anti-patterns.md` and avoid the listed failure modes.
4. Produce `requirement-context-brief.md` using the Required output sections table above and `references/output-template.md`.
5. Produce sidecar metadata using `references/metadata-schema.json`.
6. Run `python3 scripts/validate_artifact.py <artifact.md>` and `python3 scripts/validate_metadata.py <artifact.metadata.yaml>`.
7. Run `python3 scripts/check_node_neutrality.py <artifact.md>` and `python3 scripts/check_order_neutrality.py <artifact.md>`.
8. Run `python3 scripts/validate_release_consistency.py .` before packaging
9. To validate the full 5-skill requirement-definition chain, run `python3 scripts/validate_requirement_definition_chain.py --collection <002.metadata.yaml> --dedup <003.metadata.yaml> --context <004.metadata.yaml> --pain <005.metadata.yaml> --journey <006.metadata.yaml>`. See `examples/integration/README.md` for a ready-made checkout example. or final handoff when working inside the skill directory.

## Mode selection quick guide

| signal in input | recommended mode |
| --- | --- |
| Existing PRD or spec needing background annotation | `prd_context_brief` |
| Clustered requirements needing shared context | `cluster_context_enrichment` |
| Unclear in-scope vs out-of-scope boundary | `scope_boundary_clarification` |
| New team member onboarding material | `newcomer_preread` |
| Missing information, low evidence | `partial_context_gap_analysis` |

## References

Consult these files only when needed:

- `references/shared-requirement-definition-contract.md` for common contract, route tokens, and quality baseline.
- `references/requirement-id-space.md` for artifact and row id naming.
- `references/field-contract.yaml` for row/schema fields.
- `references/output-template.md` for default deliverable structure.
- `references/metadata-schema.json` for metadata sidecar contract.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and correct patterns.
- `references/common-failure-modes.md` for debugging weak outputs.
- `examples/upstream/` for generic upstream cascade samples when testing intake from feedback-loop artifacts.
- `references/quality-checklist.md` for final self-check.

## Boundary rules

- Use `composable_with` to describe optional sibling composition; do not use prerequisite/order fields.
- Use semantic route tokens such as `deduplication`, `context_enrichment`, `pain_analysis`, `journey_analysis`, `planning_intake`, or `human_review`.
- Keep private host workflow mappings outside the skill package.
- Prefer a partial but well-labeled result over an overconfident complete-looking artifact.
