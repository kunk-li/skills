#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
CONFIG = {'display': 'Requirement Context Enrichment', 'cn': '需求背景补全', 'family_role': 'context', 'artifact_type': 'markdown', 'primary_artifact': 'requirement-context-brief.md', 'schema': 'requirement.context.v4', 'id_field': 'context_id', 'id_re': '^CTX-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['business background and goal', 'scope and non-scope', 'actors and responsibilities', 'key terms', 'end-to-end scenario', 'confirmed facts assumptions and open questions', 'newcomer misunderstandings'], 'modes': ['prd_context_brief', 'cluster_context_enrichment', 'scope_boundary_clarification', 'newcomer_preread', 'partial_context_gap_analysis'], 'description': 'enrich requirement or prd material into a readable business-context brief covering goals, actors, scope boundaries, terms, scenarios, assumptions, and open questions. use when reviewers, designers, engineers, or stakeholders need the context behind a requirement for user insight, competitor research, planning, or structured modeling. not for inventing unsupported rules, making prioritization decisions, or writing technical design.', 'route_tokens': ['pain_analysis', 'journey_analysis', 'planning_intake', 'structured_modeling'], 'composable': ['requirement-collection-consolidation', 'requirement-deduplication-and-clustering', 'user-pain-point-analysis', 'user-journey-analysis'], 'not_for': ['technical design', 'quality gate approval', 'roadmap commitment'], 'skill_id': 'requirement-context-enrichment', 'contract_version': 'requirement-definition-suite-v1.3.0'}
PLACEHOLDERS = {'tbd','todo','host-workflow','待确认','<host-workflow>','<由 host workflow 注入>'}
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")

def parse_scalar(v):
    v=v.strip()
    if not v: return ''
    if v.startswith('[') and v.endswith(']'):
        body=v[1:-1].strip()
        if not body: return []
        return [x.strip().strip('"\'') for x in body.split(',')]
    return v.strip('"\'')

def load_yaml_like(path):
    data={}
    current=None
    for raw in path.read_text(encoding='utf-8').splitlines():
        line=raw.rstrip()
        if not line.strip() or line.lstrip().startswith('#'): continue
        if not line.startswith(' ') and ':' in line:
            k,v=line.split(':',1); k=k.strip(); v=v.strip()
            if v=='':
                data[k]=[]; current=k
            else:
                data[k]=parse_scalar(v); current=None
        elif current and line.strip().startswith('- '):
            data[current].append(parse_scalar(line.strip()[2:]))
    return data

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('metadata')
    args=ap.parse_args(); path=Path(args.metadata)
    if not path.exists(): print(f"ERROR: metadata not found: {path}", file=sys.stderr); return 2
    data = json.loads(path.read_text(encoding='utf-8')) if path.suffix.lower()=='.json' else load_yaml_like(path)
    errors=[]
    required=['artifact_id','skill_id','contract_version','schema','workflow_node','selected_mode','readiness','confidence','source_artifacts','evidence_refs','downstream_routes']
    for f in required:
        if f not in data or data[f] in ('',[],None): errors.append(f"missing metadata.{f}")
    allowed_keys=set(required)|{'cross_artifact_refs','notes'}
    for k in data:
        if k not in allowed_keys: errors.append(f"unexpected metadata field {k!r}")
    if data.get('skill_id') != CONFIG['skill_id']: errors.append(f"skill_id must be {CONFIG['skill_id']}")
    if data.get('contract_version') != CONFIG['contract_version']: errors.append(f"contract_version must be {CONFIG['contract_version']}")
    if data.get('schema') != CONFIG['schema']: errors.append(f"schema must be {CONFIG['schema']}")
    if data.get('selected_mode') not in CONFIG['modes']: errors.append('selected_mode not in allowed modes')
    if data.get('readiness') not in ['ready','needs_human_review','blocked']: errors.append('readiness invalid')
    if data.get('confidence') not in ['high','medium','low','needs_human_review']: errors.append('confidence invalid')
    for field in ['source_artifacts','evidence_refs','downstream_routes','cross_artifact_refs']:
        if field in data and not isinstance(data[field], list): errors.append(f"metadata.{field} must be a list")
    for r in data.get('downstream_routes',[]) if isinstance(data.get('downstream_routes'),list) else []:
        if r not in set(CONFIG['route_tokens'])|{'human_review','monitor_only'}: errors.append(f"unknown downstream route {r!r}")
    text='\n'.join(f'{k}: {v}' for k,v in data.items())
    if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in metadata')
    if str(data.get('artifact_id','')).lower() in PLACEHOLDERS: errors.append('artifact_id is a placeholder')
    if str(data.get('workflow_node','')).lower() in PLACEHOLDERS: errors.append('workflow_node is a placeholder')
    if not str(data.get('workflow_node','')).strip(): errors.append('workflow_node is required')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: metadata valid for {CONFIG['skill_id']} ({path.name})")
    return 0
if __name__=='__main__': sys.exit(main())
