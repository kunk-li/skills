#!/usr/bin/env python3
import csv, json, re, sys
from pathlib import Path

CONFIG = {'display': 'Requirement Context Enrichment', 'cn': '需求背景补全', 'family_role': 'context', 'artifact_type': 'markdown', 'primary_artifact': 'requirement-context-brief.md', 'schema': 'requirement.context.v4', 'id_field': 'context_id', 'id_re': '^CTX-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['business background and goal', 'scope and non-scope', 'actors and responsibilities', 'key terms', 'end-to-end scenario', 'confirmed facts assumptions and open questions', 'newcomer misunderstandings'], 'modes': ['prd_context_brief', 'cluster_context_enrichment', 'scope_boundary_clarification', 'newcomer_preread', 'partial_context_gap_analysis'], 'description': 'enrich requirement or prd material into a readable business-context brief covering goals, actors, scope boundaries, terms, scenarios, assumptions, and open questions. use when reviewers, designers, engineers, or stakeholders need the context behind a requirement for user insight, competitor research, planning, or structured modeling. not for inventing unsupported rules, making prioritization decisions, or writing technical design.', 'route_tokens': ['pain_analysis', 'journey_analysis', 'planning_intake', 'structured_modeling'], 'composable': ['requirement-collection-consolidation', 'requirement-deduplication-and-clustering', 'user-pain-point-analysis', 'user-journey-analysis'], 'not_for': ['technical design', 'quality gate approval', 'roadmap commitment'], 'skill_id': 'requirement-context-enrichment', 'contract_version': 'requirement-definition-suite-v1.3.0'}
CONFIDENCE = {"high","medium","low","needs_human_review"}
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")
EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
API_KEY_RE = re.compile(r"\b(?:sk|api|key|token)[-_]?[A-Za-z0-9]{16,}\b", re.I)


def split_multi(value):
    return [x.strip() for x in str(value or "").split("|") if x.strip()]


def load_rows(path):
    suffix = path.suffix.lower()
    if suffix == '.json':
        data = json.loads(path.read_text(encoding='utf-8'))
        if isinstance(data, dict):
            data = data.get('rows') or data.get('items') or [data]
        if not isinstance(data, list):
            raise ValueError('json artifact must be a list or an object with rows/items')
        return data
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def validate_csv_or_json(path):
    rows = load_rows(path)
    errors=[]; warnings=[]
    if not rows:
        errors.append('artifact has no rows')
        return errors,warnings
    required = CONFIG['required']
    id_field = CONFIG['id_field']
    id_re = re.compile(CONFIG['id_re'], re.I)
    seen=set()
    header=set(rows[0].keys())
    missing_header = [f for f in required if f not in header]
    if missing_header:
        errors.append(f"missing required columns: {missing_header}")
    extra_private=[]
    for i,row in enumerate(rows,1):
        for k,v in row.items():
            if PRIVATE_NODE_RE.search(str(v or '')):
                extra_private.append(f"row {i} field {k}")
        missing = [f for f in required if not str(row.get(f,'')).strip()]
        if missing:
            errors.append(f"row {i}: missing required fields {missing}")
        rid=str(row.get(id_field,'')).strip()
        if rid:
            if not id_re.match(rid): errors.append(f"row {i}: {id_field} {rid!r} does not match expected pattern")
            if rid in seen: errors.append(f"row {i}: duplicate {id_field} {rid!r}")
            seen.add(rid)
        for field,allowed in CONFIG.get('enums',{}).items():
            val=str(row.get(field,'')).strip()
            if val and val not in allowed:
                errors.append(f"row {i}: {field} must be one of {allowed}, got {val!r}")
        if id_field == 'requirement_id':
            if len(str(row.get('normalized_requirement','')).strip()) < 8:
                errors.append(f"row {i}: normalized_requirement is too short")
            if not split_multi(row.get('source_ids')):
                errors.append(f"row {i}: source_ids must contain at least one id")
        if id_field == 'cluster_id':
            members = split_multi(row.get('member_requirement_ids'))
            if not members:
                errors.append(f"row {i}: member_requirement_ids must contain at least one id")
            if row.get('relation_strength') == 'exact_duplicate' and len(members) < 2:
                warnings.append(f"row {i}: exact_duplicate cluster has fewer than two members")
            if row.get('relation_strength') == 'theme_related' and row.get('merge_recommendation') == 'merge':
                warnings.append(f"row {i}: theme_related cluster should not be auto-merged")
        text=' '.join(str(v or '') for v in row.values())
        if EMAIL_RE.search(text): warnings.append(f"row {i}: possible email/private contact data")
        if API_KEY_RE.search(text): warnings.append(f"row {i}: possible secret token")
    if extra_private:
        errors.append('private workflow-node code found in artifact fields: ' + ', '.join(extra_private[:10]))
    return errors,warnings


def validate_markdown(path):
    text = path.read_text(encoding='utf-8')
    errors=[]; warnings=[]
    lower = text.lower()
    if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in markdown artifact')
    for sec in CONFIG['required_sections']:
        if sec.lower() not in lower:
            errors.append(f"missing required section phrase: {sec}")
    id_field = CONFIG['id_field']
    id_re = re.compile(CONFIG['id_re'].strip('^$'), re.I)
    ids = id_re.findall(text)
    if not ids:
        warnings.append(f"no {id_field} matching expected pattern found")
    if 'confirmed facts' not in lower and '已确认' not in text:
        warnings.append('confirmed facts label not found')
    if 'open questions' not in lower and '待确认' not in text:
        warnings.append('open questions label not found')
    if EMAIL_RE.search(text): warnings.append('possible email/private contact data')
    if API_KEY_RE.search(text): warnings.append('possible secret token')
    return errors,warnings


def main():
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('artifact', nargs='?')
    ap.add_argument('--strict',action='store_true')
    ap.add_argument('--summary', action='store_true', help='print validator contract/config and exit')
    args=ap.parse_args()
    if args.summary:
        print(json.dumps(CONFIG, ensure_ascii=False, indent=2))
        return 0
    if not args.artifact:
        print('ERROR: artifact path is required unless --summary is used', file=sys.stderr)
        return 2
    path=Path(args.artifact)
    if not path.exists():
        print(f"ERROR: artifact not found: {path}", file=sys.stderr); return 2
    if CONFIG['artifact_type']=='markdown' or path.suffix.lower() in {'.md','.markdown'}:
        errors,warnings = validate_markdown(path)
    else:
        errors,warnings = validate_csv_or_json(path)
    if args.strict and warnings:
        errors.extend('strict warning: '+w for w in warnings)
    for w in warnings: print('WARN:', w)
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: {CONFIG['skill_id']} artifact valid ({path.name})")
    return 0

if __name__ == '__main__':
    sys.exit(main())
