#!/usr/bin/env python3
import re, sys
from pathlib import Path
CONFIG={'display': 'Requirement Context Enrichment', 'cn': '需求背景补全', 'family_role': 'context', 'artifact_type': 'markdown', 'primary_artifact': 'requirement-context-brief.md', 'schema': 'requirement.context.v4', 'id_field': 'context_id', 'id_re': '^CTX-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['business background and goal', 'scope and non-scope', 'actors and responsibilities', 'key terms', 'end-to-end scenario', 'confirmed facts assumptions and open questions', 'newcomer misunderstandings'], 'modes': ['prd_context_brief', 'cluster_context_enrichment', 'scope_boundary_clarification', 'newcomer_preread', 'partial_context_gap_analysis'], 'description': 'enrich requirement or prd material into a readable business-context brief covering goals, actors, scope boundaries, terms, scenarios, assumptions, and open questions. use when reviewers, designers, engineers, or stakeholders need the context behind a requirement for user insight, competitor research, planning, or structured modeling. not for inventing unsupported rules, making prioritization decisions, or writing technical design.', 'route_tokens': ['pain_analysis', 'journey_analysis', 'planning_intake', 'structured_modeling'], 'composable': ['requirement-collection-consolidation', 'requirement-deduplication-and-clustering', 'user-pain-point-analysis', 'user-journey-analysis'], 'not_for': ['technical design', 'quality gate approval', 'roadmap commitment'], 'skill_id': 'requirement-context-enrichment', 'contract_version': 'requirement-definition-suite-v1.3.0'}
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")
RETIRED_VERSION_TOKENS = (
    "requirement-definition-suite-v" + "1.1.0",
    "requirement-definition-suite-v" + "1.2.0",
    "requirement.collection.v" + "2", "requirement.collection.v" + "3",
    "requirement.deduplication.v" + "2", "requirement.deduplication.v" + "3",
    "requirement.context.v" + "2", "requirement.context.v" + "3",
    "user.pain-point.v" + "2", "user.pain-point.v" + "3",
    "user.journey.v" + "2", "user.journey.v" + "3",
)

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    args=ap.parse_args(); d=Path(args.skill_dir); p=d/'SKILL.md'
    errors=[]
    if not p.exists(): errors.append('SKILL.md missing')
    else:
        text=p.read_text(encoding='utf-8')
        if not text.startswith('---'): errors.append('missing YAML frontmatter')
        if f"name: {CONFIG['skill_id']}" not in text: errors.append('frontmatter name mismatch')
        if 'description:' not in text: errors.append('frontmatter description missing')
        if 'TODO' in text or '[TODO' in text: errors.append('TODO placeholder remains')
        if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in SKILL.md')
        for token in RETIRED_VERSION_TOKENS:
            if token in text:
                errors.append(f'retired contract or schema token remains in SKILL.md: {token}')
        forbidden=['depends' + '_on','blo' + 'cks']
        for word in forbidden:
            if re.search(rf"(^|[\s`'\"]){word}(\s*:|[`'\"])", text, re.I): errors.append(f'forbidden order field {word!r}')
        for req in ['references/shared-requirement-definition-contract.md','scripts/validate_artifact.py','scripts/validate_metadata.py']:
            if req not in text: errors.append(f'SKILL.md does not reference {req}')
    for rel in ['agents/openai.yaml','references/metadata-schema.json','references/anti-patterns.md','scripts/validate_release_consistency.py']:
        if not (d/rel).exists(): errors.append(f'missing {rel}')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: SKILL.md baseline for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
