#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
CONFIG={'display': 'Requirement Context Enrichment', 'cn': '需求背景补全', 'family_role': 'context', 'artifact_type': 'markdown', 'primary_artifact': 'requirement-context-brief.md', 'schema': 'requirement.context.v4', 'id_field': 'context_id', 'id_re': '^CTX-[a-z0-9_]+-\\d{3,}$', 'required_sections': ['business background and goal', 'scope and non-scope', 'actors and responsibilities', 'key terms', 'end-to-end scenario', 'confirmed facts assumptions and open questions', 'newcomer misunderstandings'], 'modes': ['prd_context_brief', 'cluster_context_enrichment', 'scope_boundary_clarification', 'newcomer_preread', 'partial_context_gap_analysis'], 'description': 'enrich requirement or prd material into a readable business-context brief covering goals, actors, scope boundaries, terms, scenarios, assumptions, and open questions. use when reviewers, designers, engineers, or stakeholders need the context behind a requirement for user insight, competitor research, planning, or structured modeling. not for inventing unsupported rules, making prioritization decisions, or writing technical design.', 'route_tokens': ['pain_analysis', 'journey_analysis', 'planning_intake', 'structured_modeling'], 'composable': ['requirement-collection-consolidation', 'requirement-deduplication-and-clustering', 'user-pain-point-analysis', 'user-journey-analysis'], 'not_for': ['technical design', 'quality gate approval', 'roadmap commitment'], 'skill_id': 'requirement-context-enrichment', 'contract_version': 'requirement-definition-suite-v1.3.0'}

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    d=Path(ap.parse_args().skill_dir)
    errors=[]
    dt=d/'references/selected-mode-decision-tree.md'
    ms=d/'references/metadata-schema.json'
    sm=d/'SKILL.md'
    if not dt.exists(): errors.append('selected-mode-decision-tree.md missing')
    else:
        text=dt.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if f'`{m}`' not in text: errors.append(f'mode {m} missing from decision tree')
    if ms.exists():
        meta=json.loads(ms.read_text(encoding='utf-8'))
        enum=meta.get('properties',{}).get('selected_mode',{}).get('enum',[])
        if set(enum)!=set(CONFIG['modes']): errors.append('metadata selected_mode enum mismatch')
    else: errors.append('metadata-schema.json missing')
    if sm.exists():
        s=sm.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if m not in s: errors.append(f'mode {m} missing from SKILL.md')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: selected-mode decision tree aligned for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
