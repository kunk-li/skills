---
name: requirement-collection-consolidation
display_name: 需求输入归档 / Requirement Collection Consolidation
description: consolidate requirement inputs from notes, chats, tickets, feedback, spreadsheets, screenshots, or pasted requests into a source-aware raw requirement pool. use when inputs need stable ids, evidence references, conflict flags, and a traceable intake table for deduplication, context enrichment, user research, planning, or handoff. not for priority ranking, final scope decisions, or solution design.
---

# Requirement Collection Consolidation / 需求输入归档

## Contract baseline

- contract_version: `requirement-definition-suite-v1.3.0`
- skill_id: `requirement-collection-consolidation`
- schema: `requirement.collection.v4`
- artifact_target: `raw-requirement-pool.csv`
- selected_mode: `multi_source_intake / meeting_notes_consolidation / feedback_backlog_intake / spreadsheet_cleanup / partial_evidence_triage`
- composable_with: `requirement-deduplication-and-clustering, requirement-context-enrichment, user-pain-point-analysis, user-journey-analysis`
- downstream_route_tokens: `deduplication, context_enrichment, planning_intake`

This skill is self-contained and can run directly on partial input. It may compose with sibling skills, but it must not require them as prerequisites or encode private workflow node ids.

## Use this skill to

- Convert messy input into the skill's contracted deliverable while keeping source traceability.
- Preserve uncertainty, conflict, missing context, and evidence boundaries.
- Produce artifacts that can be validated locally before handoff.

## Do not use this skill to

- ranking business value; deciding roadmap priority; inventing requirements without evidence.
- Invent facts, user needs, source ids, evidence, priorities, or delivery commitments.
- Replace downstream planning, technical design, quality gates, or final approval.

## Required row contract

The following fields are required in every `raw-requirement-pool.csv` row. Use `|` for multi-value cells.

| field | required | enum / format |
| --- | --- | --- |
| `requirement_id` | required | `REQ-<scope>-<nnn>` |
| `normalized_requirement` | required | clear user/business need statement |
| `source_ids` | required | `\|`-separated source anchors |
| `source_types` | required | `chat\|support_ticket\|meeting_note\|app_review\|…` |
| `requester_or_role` | required | role or team name |
| `category` | required | feature area or business domain |
| `evidence_refs` | required | `\|`-separated evidence anchors |
| `confidence` | required | `high\|medium\|low\|needs_human_review` |
| `conflict_status` | required | `none\|possible_conflict\|confirmed_conflict\|needs_human_review` |
| `open_questions` | required | free text or `none` |
| `original_text` | recommended | verbatim or paraphrased source text |
| `received_at` | recommended | ISO-8601 date |
| `business_area` | recommended | top-level business domain |
| `assumptions` | recommended | assumptions made during normalization |
| `notes` | recommended | additional context |

## Required output

Produce `raw-requirement-pool.csv` as CSV using `references/field-contract.yaml`; use `|` for multi-value cells.

Always produce a sidecar metadata file with the same basename and `.metadata.yaml` suffix. Metadata must include `artifact_id`, `skill_id`, `contract_version`, `schema`, `workflow_node`, `selected_mode`, `readiness`, `confidence`, `source_artifacts`, `evidence_refs`, and `downstream_routes`.

## Workflow

1. Identify source materials, evidence anchors, roles, scope, dates, and uncertainty.
2. Select one `selected_mode` using `references/selected-mode-decision-tree.md`.
3. Read `references/anti-patterns.md`; pay special attention to AP-COL-01 through AP-COL-05.
4. Produce `raw-requirement-pool.csv` using the Required row contract table above and `references/field-contract.yaml`.
5. Produce sidecar metadata using `references/metadata-schema.json`.
6. Run `python3 scripts/validate_artifact.py <artifact>` and `python3 scripts/validate_metadata.py <artifact.metadata.yaml>`. Use `python3 scripts/validate_artifact.py --summary` to inspect the local row/section contract.
7. Run `python3 scripts/check_node_neutrality.py <artifact>` and `python3 scripts/check_order_neutrality.py <artifact>` to confirm no private workflow IDs or order-binding fields leaked in.
8. Run `python3 scripts/validate_release_consistency.py .` before packaging
9. To validate the full 5-skill requirement-definition chain, run `python3 scripts/validate_requirement_definition_chain.py --collection <002.metadata.yaml> --dedup <003.metadata.yaml> --context <004.metadata.yaml> --pain <005.metadata.yaml> --journey <006.metadata.yaml>`. See `examples/integration/README.md` for a ready-made checkout example. or final handoff when working inside the skill directory.

## Mode selection quick guide

| signal in input | recommended mode |
| --- | --- |
| Multiple source types mixed together | `multi_source_intake` |
| Primarily meeting notes or chat transcripts | `meeting_notes_consolidation` |
| Feedback backlog or ticket export | `feedback_backlog_intake` |
| Messy spreadsheet or existing table | `spreadsheet_cleanup` |
| Sparse evidence, low confidence | `partial_evidence_triage` |

## References

Consult these files only when needed:

- `references/shared-requirement-definition-contract.md` for common contract, route tokens, and quality baseline.
- `references/requirement-id-space.md` for artifact and row id naming.
- `references/field-contract.yaml` for row/schema fields.
- `references/output-template.md` for default deliverable structure.
- `references/metadata-schema.json` for metadata sidecar contract.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and correct patterns.
- `references/common-failure-modes.md` for debugging weak outputs.
- `examples/upstream/` for generic upstream cascade samples when testing intake from feedback-loop artifacts.
- `references/quality-checklist.md` for final self-check.

## Boundary rules

See also `scripts/cross_family_cascade.py` for cross-family pipeline validation.

## Cross-family cascade validation

To validate the full pipeline from feedback-loop through requirement-definition to planning-assessment:
```bash
python scripts/cross_family_cascade.py \
    --feedback <feedback-loop-artifact.metadata.yaml> \
    --requirement examples/checkout-requirements.metadata.yaml \
    --planning <planning-assessment-artifact.metadata.yaml>
```


- Use `composable_with` to describe optional sibling composition; do not use prerequisite/order fields.
- Use semantic route tokens such as `deduplication`, `context_enrichment`, `pain_analysis`, `journey_analysis`, `planning_intake`, or `human_review`.
- Keep private host workflow mappings outside the skill package.
- Prefer a partial but well-labeled result over an overconfident complete-looking artifact.
