---
name: requirement-collection-consolidation
description: consolidate requirement inputs from notes, chats, tickets, feedback, spreadsheets, screenshots, or pasted requests into a source-aware raw requirement pool. use when inputs need stable ids, evidence references, conflict flags, and a traceable intake table for deduplication, context enrichment, user research, planning, or handoff. not for priority ranking, final scope decisions, or solution design.
---

# Requirement Collection Consolidation

## Contract baseline

- contract_version: `requirement-definition-suite-v1.3.0`
- skill_id: `requirement-collection-consolidation`
- schema: `requirement.collection.v4`
- artifact_target: `raw-requirement-pool.csv`
- selected_mode: `multi_source_intake / meeting_notes_consolidation / feedback_backlog_intake / spreadsheet_cleanup / partial_evidence_triage`
- composable_with: `requirement-deduplication-and-clustering, requirement-context-enrichment, user-pain-point-analysis, user-journey-analysis`
- downstream_route_tokens: `deduplication, context_enrichment, planning_intake`

This skill is self-contained and can run directly on partial input. It may compose with sibling skills, but it must not require them as prerequisites or encode private workflow node ids.

## Use this skill to

- Convert messy input into the skill's contracted deliverable while keeping source traceability.
- Preserve uncertainty, conflict, missing context, and evidence boundaries.
- Produce artifacts that can be validated locally before handoff.

## Do not use this skill to

- ranking business value; deciding roadmap priority; inventing requirements without evidence.
- Invent facts, user needs, source ids, evidence, priorities, or delivery commitments.
- Replace downstream planning, technical design, quality gates, or final approval.

## Required output

Produce `raw-requirement-pool.csv` as CSV using `references/field-contract.yaml`; use `|` for multi-value cells.

Always produce a sidecar metadata file with the same basename and `.metadata.yaml` suffix. Metadata must include `artifact_id`, `skill_id`, `contract_version`, `schema`, `workflow_node`, `selected_mode`, `readiness`, `confidence`, `source_artifacts`, `evidence_refs`, and `downstream_routes`.

## Workflow

1. Identify source materials, evidence anchors, roles, scope, dates, and uncertainty.
2. Select one `selected_mode` using `references/selected-mode-decision-tree.md`.
3. Read `references/anti-patterns.md` and avoid the listed failure modes.
4. Produce the required artifact using `references/output-template.md` and `references/field-contract.yaml` where applicable.
5. Produce sidecar metadata using `references/metadata-schema.json`.
6. Run `python3 scripts/validate_artifact.py <artifact>` and `python3 scripts/validate_metadata.py <artifact.metadata.yaml>`. Use `python3 scripts/validate_artifact.py --summary` to inspect the local row/section contract.
7. Run `python3 scripts/validate_release_consistency.py .` before packaging or final handoff when working inside the skill directory.

## References

Consult these files only when needed:

- `references/shared-requirement-definition-contract.md` for common contract, route tokens, and quality baseline.
- `references/requirement-id-space.md` for artifact and row id naming.
- `references/field-contract.yaml` for row/schema fields.
- `references/output-template.md` for default deliverable structure.
- `references/metadata-schema.json` for metadata sidecar contract.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and correct patterns.
- `references/common-failure-modes.md` for debugging weak outputs.
- `examples/upstream/` for generic upstream cascade samples when testing intake from feedback-loop artifacts.
- `references/quality-checklist.md` for final self-check.

## Boundary rules

- Use `composable_with` to describe optional sibling composition; do not use prerequisite/order fields.
- Use semantic route tokens such as `deduplication`, `context_enrichment`, `pain_analysis`, `journey_analysis`, `planning_intake`, or `human_review`.
- Keep private host workflow mappings outside the skill package.
- Prefer a partial but well-labeled result over an overconfident complete-looking artifact.
