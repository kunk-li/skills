#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
CONFIG={'display': 'Requirement Collection Consolidation', 'cn': '需求收集归并', 'family_role': 'collection', 'artifact_type': 'csv', 'primary_artifact': 'raw-requirement-pool.csv', 'schema': 'requirement.collection.v4', 'id_field': 'requirement_id', 'id_re': '^REQ-[a-z0-9_]+-\\d{3,}$', 'required': ['requirement_id', 'normalized_requirement', 'source_ids', 'source_types', 'requester_or_role', 'category', 'evidence_refs', 'confidence', 'conflict_status', 'open_questions'], 'recommended': ['original_text', 'received_at', 'business_area', 'assumptions', 'notes'], 'enums': {'confidence': ['high', 'medium', 'low', 'needs_human_review'], 'conflict_status': ['none', 'possible_conflict', 'confirmed_conflict', 'needs_human_review']}, 'modes': ['multi_source_intake', 'meeting_notes_consolidation', 'feedback_backlog_intake', 'spreadsheet_cleanup', 'partial_evidence_triage'], 'description': 'consolidate requirement inputs from notes, chats, tickets, feedback, spreadsheets, screenshots, or pasted requests into a source-aware raw requirement pool. use when inputs need stable ids, evidence references, conflict flags, and a traceable intake table for deduplication, context enrichment, user research, planning, or handoff. not for priority ranking, final scope decisions, or solution design.', 'route_tokens': ['deduplication', 'context_enrichment', 'planning_intake'], 'composable': ['requirement-deduplication-and-clustering', 'requirement-context-enrichment', 'user-pain-point-analysis', 'user-journey-analysis'], 'not_for': ['ranking business value', 'deciding roadmap priority', 'inventing requirements without evidence'], 'skill_id': 'requirement-collection-consolidation', 'contract_version': 'requirement-definition-suite-v1.3.0'}

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    d=Path(ap.parse_args().skill_dir)
    errors=[]
    dt=d/'references/selected-mode-decision-tree.md'
    ms=d/'references/metadata-schema.json'
    sm=d/'SKILL.md'
    if not dt.exists(): errors.append('selected-mode-decision-tree.md missing')
    else:
        text=dt.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if f'`{m}`' not in text: errors.append(f'mode {m} missing from decision tree')
    if ms.exists():
        meta=json.loads(ms.read_text(encoding='utf-8'))
        enum=meta.get('properties',{}).get('selected_mode',{}).get('enum',[])
        if set(enum)!=set(CONFIG['modes']): errors.append('metadata selected_mode enum mismatch')
    else: errors.append('metadata-schema.json missing')
    if sm.exists():
        s=sm.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if m not in s: errors.append(f'mode {m} missing from SKILL.md')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: selected-mode decision tree aligned for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
