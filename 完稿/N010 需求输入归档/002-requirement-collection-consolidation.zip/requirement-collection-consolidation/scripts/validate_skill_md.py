#!/usr/bin/env python3
import re, sys
from pathlib import Path
CONFIG={'display': 'Requirement Collection Consolidation', 'cn': '需求收集归并', 'family_role': 'collection', 'artifact_type': 'csv', 'primary_artifact': 'raw-requirement-pool.csv', 'schema': 'requirement.collection.v4', 'id_field': 'requirement_id', 'id_re': '^REQ-[a-z0-9_]+-\\d{3,}$', 'required': ['requirement_id', 'normalized_requirement', 'source_ids', 'source_types', 'requester_or_role', 'category', 'evidence_refs', 'confidence', 'conflict_status', 'open_questions'], 'recommended': ['original_text', 'received_at', 'business_area', 'assumptions', 'notes'], 'enums': {'confidence': ['high', 'medium', 'low', 'needs_human_review'], 'conflict_status': ['none', 'possible_conflict', 'confirmed_conflict', 'needs_human_review']}, 'modes': ['multi_source_intake', 'meeting_notes_consolidation', 'feedback_backlog_intake', 'spreadsheet_cleanup', 'partial_evidence_triage'], 'description': 'consolidate requirement inputs from notes, chats, tickets, feedback, spreadsheets, screenshots, or pasted requests into a source-aware raw requirement pool. use when inputs need stable ids, evidence references, conflict flags, and a traceable intake table for deduplication, context enrichment, user research, planning, or handoff. not for priority ranking, final scope decisions, or solution design.', 'route_tokens': ['deduplication', 'context_enrichment', 'planning_intake'], 'composable': ['requirement-deduplication-and-clustering', 'requirement-context-enrichment', 'user-pain-point-analysis', 'user-journey-analysis'], 'not_for': ['ranking business value', 'deciding roadmap priority', 'inventing requirements without evidence'], 'skill_id': 'requirement-collection-consolidation', 'contract_version': 'requirement-definition-suite-v1.3.0'}
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")
RETIRED_VERSION_TOKENS = (
    "requirement-definition-suite-v" + "1.1.0",
    "requirement-definition-suite-v" + "1.2.0",
    "requirement.collection.v" + "2", "requirement.collection.v" + "3",
    "requirement.deduplication.v" + "2", "requirement.deduplication.v" + "3",
    "requirement.context.v" + "2", "requirement.context.v" + "3",
    "user.pain-point.v" + "2", "user.pain-point.v" + "3",
    "user.journey.v" + "2", "user.journey.v" + "3",
)

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    args=ap.parse_args(); d=Path(args.skill_dir); p=d/'SKILL.md'
    errors=[]
    if not p.exists(): errors.append('SKILL.md missing')
    else:
        text=p.read_text(encoding='utf-8')
        if not text.startswith('---'): errors.append('missing YAML frontmatter')
        if f"name: {CONFIG['skill_id']}" not in text: errors.append('frontmatter name mismatch')
        if 'description:' not in text: errors.append('frontmatter description missing')
        if 'TODO' in text or '[TODO' in text: errors.append('TODO placeholder remains')
        if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in SKILL.md')
        for token in RETIRED_VERSION_TOKENS:
            if token in text:
                errors.append(f'retired contract or schema token remains in SKILL.md: {token}')
        forbidden=['depends' + '_on','blo' + 'cks']
        for word in forbidden:
            if re.search(rf"(^|[\s`'\"]){word}(\s*:|[`'\"])", text, re.I): errors.append(f'forbidden order field {word!r}')
        for req in ['references/shared-requirement-definition-contract.md','scripts/validate_artifact.py','scripts/validate_metadata.py']:
            if req not in text: errors.append(f'SKILL.md does not reference {req}')
    for rel in ['agents/openai.yaml','references/metadata-schema.json','references/anti-patterns.md','scripts/validate_release_consistency.py']:
        if not (d/rel).exists(): errors.append(f'missing {rel}')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: SKILL.md baseline for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
