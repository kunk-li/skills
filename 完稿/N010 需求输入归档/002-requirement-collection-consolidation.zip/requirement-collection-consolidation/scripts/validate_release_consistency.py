#!/usr/bin/env python3
import csv, runpy, sys
from pathlib import Path


def run_script(script, args):
    old_argv = sys.argv[:]
    try:
        sys.argv = [str(script)] + [str(a) for a in args]
        try:
            runpy.run_path(str(script), run_name='__main__')
            return []
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else 1
            if code == 0 or code is None:
                return []
            return [f"command failed: {script.name} {' '.join(str(a) for a in args)}"]
    finally:
        sys.argv = old_argv


def csv_headers(path):
    try:
        with Path(path).open(encoding='utf-8-sig', newline='') as f:
            reader = csv.reader(f)
            return next(reader, [])
    except Exception:
        return []


def build_handoff_args(examples):
    args = ['--allow-unresolved-cross-refs']
    for art in sorted(list(examples.glob('*.csv')) + list(examples.glob('*.md')) + list(examples.glob('*.json'))):
        if art.name.endswith('.metadata.yaml'):
            continue
        if art.suffix.lower() == '.csv':
            headers = set(csv_headers(art))
            if 'requirement_id' in headers:
                args += ['--collection', str(art)]
            elif 'cluster_id' in headers:
                args += ['--deduplication', str(art)]
        elif art.suffix.lower() == '.md':
            text = art.read_text(encoding='utf-8', errors='ignore')
            if 'CTX-' in text:
                args += ['--context', str(art)]
            elif 'PAIN-' in text:
                args += ['--pain', str(art)]
            elif 'JNY-' in text:
                args += ['--journey', str(art)]
    return args if len(args) > 1 else []


def validate_upstream_sidecars(examples):
    errors = []
    upstream = examples / 'upstream'
    if not upstream.exists():
        return errors
    private = 'N'
    import re
    private_re = re.compile(r"\b" + private + r"\d{3}\b", re.I)
    placeholders = {'host-workflow','tbd','todo','待确认','<host-workflow>','<由 host workflow 注入>'}
    for art in sorted(upstream.glob('*.csv')):
        meta = art.with_suffix('.metadata.yaml')
        if not meta.exists():
            errors.append(f'missing upstream metadata sidecar for {art.name}')
            continue
        text = meta.read_text(encoding='utf-8', errors='ignore')
        for key in ['artifact_id:', 'skill_id:', 'contract_version:', 'schema:', 'workflow_node:', 'selected_mode:', 'readiness:', 'confidence:', 'source_artifacts:', 'evidence_refs:', 'downstream_routes:']:
            if key not in text:
                errors.append(f'invalid upstream metadata sidecar for {art.name}: missing {key}')
        if private_re.search(text):
            errors.append(f'private workflow-node code in upstream metadata sidecar for {art.name}')
        lowered = text.lower()
        for ph in placeholders:
            if f'workflow_node: {ph}' in lowered or f'artifact_id: {ph}' in lowered:
                errors.append(f'placeholder value in upstream metadata sidecar for {art.name}')
    return errors


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('skill_dir', nargs='?', default='.')
    d = Path(ap.parse_args().skill_dir).resolve()
    scripts = d / 'scripts'
    errors = []
    for script, args in [
        (scripts / 'validate_skill_md.py', [d]),
        (scripts / 'check_node_neutrality.py', [d]),
        (scripts / 'check_order_neutrality.py', [d]),
        (scripts / 'validate_decision_tree.py', [d]),
    ]:
        errors += run_script(script, args)
    examples = d / 'examples'
    if examples.exists():
        for art in sorted(list(examples.glob('*.csv')) + list(examples.glob('*.md')) + list(examples.glob('*.json'))):
            if art.name.endswith('.metadata.yaml'):
                continue
            errors += run_script(scripts / 'validate_artifact.py', [art])
            meta = art.with_suffix('.metadata.yaml')
            if meta.exists():
                errors += run_script(scripts / 'validate_metadata.py', [meta])
            else:
                errors.append(f'missing metadata sidecar for {art.name}')
        handoff_args = build_handoff_args(examples)
        errors += validate_upstream_sidecars(examples)
        if handoff_args:
            errors += run_script(scripts / 'validate_handoff.py', handoff_args)
    if errors:
        for e in errors:
            print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: release consistency passed for {d.name} (7-in-1)")
    return 0

if __name__ == '__main__':
    sys.exit(main())
