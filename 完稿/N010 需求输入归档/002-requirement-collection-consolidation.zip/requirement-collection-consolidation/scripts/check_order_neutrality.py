#!/usr/bin/env python3
import re, sys
from pathlib import Path
TEXT_EXTS={'.md','.yaml','.yml','.json','.csv','.py','.txt','.log'}
SKIP={'__pycache__','.git'}
SELF='check_order_neutrality.py'
DEPENDS='depends' + '_on'
BLOCKS='blocks'
ORDER_RE = re.compile(r"(^|[\s`'\"])("+DEPENDS+r"|"+BLOCKS+r")(\s*:|[`'\"])", re.I)
POSITION_RE = re.compile(r"\b[a-z][a-z0-9_-]*-[sS]\d{2,}\b|\b[sS]\d{2,}\b")
DESC_RE = re.compile(r"^description\s*:.*\b(before|after)\b", re.I)

def collect_errors(skill_dir):
    skill_dir=Path(skill_dir); errs=[]
    for p in skill_dir.rglob('*'):
        if not p.is_file() or p.name==SELF or p.suffix.lower() not in TEXT_EXTS: continue
        if any(part in SKIP for part in p.parts): continue
        txt=p.read_text(encoding='utf-8',errors='ignore')
        for i,line in enumerate(txt.splitlines(),1):
            if ORDER_RE.search(line): errs.append(f"{p.relative_to(skill_dir)}:{i}: prerequisite/order field is not allowed")
            if POSITION_RE.search(line): errs.append(f"{p.relative_to(skill_dir)}:{i}: positional skill id is not allowed")
            if p.name=='SKILL.md' and DESC_RE.search(line): errs.append(f"{p.relative_to(skill_dir)}:{i}: before/after sequence language in description")
    return errs

def main():
    d=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
    errs=collect_errors(d)
    if errs:
        print(f"FAIL: {len(errs)} order-binding references remain", file=sys.stderr)
        for e in errs[:20]: print('  '+e, file=sys.stderr)
        return 1
    print(f"OK: order-neutral skill package for {d}")
    return 0
if __name__=='__main__': sys.exit(main())
