#!/usr/bin/env python3
import re, sys
from pathlib import Path
TOKEN = 'N'
PRIVATE_NODE_RE = re.compile(r"\b" + TOKEN + r"\d{3}\b", re.I)
TEXT_EXTS={'.md','.yaml','.yml','.json','.csv','.py','.txt','.log'}
SKIP={'__pycache__','.git'}
SELF='check_node_neutrality.py'

def collect_errors(skill_dir):
    skill_dir=Path(skill_dir); errs=[]
    for p in skill_dir.rglob('*'):
        if not p.is_file() or p.name==SELF or p.suffix.lower() not in TEXT_EXTS: continue
        if any(part in SKIP for part in p.parts): continue
        txt=p.read_text(encoding='utf-8',errors='ignore')
        for i,line in enumerate(txt.splitlines(),1):
            if PRIVATE_NODE_RE.search(line): errs.append(f"{p.relative_to(skill_dir)}:{i}: private workflow-node code")
    return errs

def main():
    d=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
    errs=collect_errors(d)
    if errs:
        print(f"FAIL: {len(errs)} private workflow-node references remain", file=sys.stderr)
        for e in errs[:20]: print('  '+e, file=sys.stderr)
        return 1
    print(f"OK: no private workflow-node references in {d}")
    return 0
if __name__=='__main__': sys.exit(main())
