#!/usr/bin/env python3
"""
Validate the intra-A-family requirement-definition chain.

Checks that artifacts from the 5-step requirement-definition pipeline form a
coherent chain:

  002 collection → 003 deduplication → 004 context → 005 pain → 006 journey

Checks:
  1. Each artifact carries the correct contract_version.
  2. IDs follow the expected namespace (REQ-*, CLU-*, CTX-*, PAIN-*, JNY-*).
  3. downstream_routes / evidence in each artifact contain tokens that match
     the next skill's expected intake pattern.
  4. No artifact's artifact_id appears in its own cross_artifact_refs.
  5. evidence_refs are non-empty at each stage.

Usage:
    python validate_requirement_definition_chain.py \\
        --collection  <002-artifact.metadata.yaml> \\
        --dedup       <003-artifact.metadata.yaml> \\
        --context     <004-artifact.metadata.yaml> \\
        --pain        <005-artifact.metadata.yaml> \\
        --journey     <006-artifact.metadata.yaml>

All five arguments are optional; omit a stage to skip its checks.
"""
from __future__ import annotations
import argparse, sys, re
from pathlib import Path

try:
    import yaml
    def _load(p: Path) -> dict:
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
except ImportError:
    def _load(p: Path) -> dict:
        data: dict = {}
        cur = None
        for raw in p.read_text(encoding="utf-8").splitlines():
            line = raw.rstrip()
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            if line.startswith("  - ") and cur:
                data.setdefault(cur, []).append(line[4:].strip().strip("\"'"))
            elif ":" in line and not line.startswith(" "):
                k, v = line.split(":", 1)
                k = k.strip(); v = v.strip().strip("\"'")
                data[k] = [] if v == "" else v
                cur = k if v == "" else None
        return data


CONTRACT = "requirement-definition-suite-v1.3.0"

STAGE_CONFIG = {
    "collection":  {"contract": CONTRACT, "id_prefix": re.compile(r"^COLLECTION-ARTIFACT-|^REQ-")},
    "dedup":       {"contract": CONTRACT, "id_prefix": re.compile(r"^DEDUPLICATION-ARTIFACT-|^CLU-")},
    "context":     {"contract": CONTRACT, "id_prefix": re.compile(r"^CONTEXT-ARTIFACT-|^CTX-")},
    "pain":        {"contract": CONTRACT, "id_prefix": re.compile(r"^PAIN-ARTIFACT-|^PAIN-")},
    "journey":     {"contract": CONTRACT, "id_prefix": re.compile(r"^JOURNEY-ARTIFACT-|^JNY-")},
}

HANDOFF_TOKENS = {
    ("collection", "dedup"):    {"deduplication", "context_enrichment"},
    ("dedup",      "context"):  {"context_enrichment", "planning_intake"},
    ("context",    "pain"):     {"pain_analysis", "journey_analysis"},
    ("pain",       "journey"):  {"journey_analysis", "value_assessment"},
    ("journey",    None):       {"value_assessment", "prioritization", "human_review"},
}


def _routes(data: dict) -> list[str]:
    raw = data.get("downstream_routes") or []
    if isinstance(raw, list):
        return [str(r) for r in raw]
    return [str(raw)] if raw else []


def check_stage(path: Path, stage: str, errors: list[str]) -> dict:
    data = _load(path)
    cfg = STAGE_CONFIG[stage]

    cv = data.get("contract_version")
    if cv != CONTRACT:
        errors.append(
            f"{path.name} [{stage}]: contract_version {cv!r} != expected {CONTRACT!r}"
        )

    aid = str(data.get("artifact_id") or "")
    if aid and not cfg["id_prefix"].match(aid):
        errors.append(
            f"{path.name} [{stage}]: artifact_id {aid!r} does not match expected "
            f"prefix pattern {cfg['id_prefix'].pattern}"
        )

    refs = list(data.get("cross_artifact_refs") or [])
    if aid and aid in refs:
        errors.append(f"{path.name} [{stage}]: self-reference in cross_artifact_refs ({aid})")

    evs = list(data.get("evidence_refs") or [])
    if not evs:
        errors.append(f"{path.name} [{stage}]: evidence_refs is empty")

    return data


def check_handoff(src_path: Path, src: str, dst: str | None, src_data: dict,
                  errors: list[str]) -> None:
    routes = _routes(src_data)
    expected = HANDOFF_TOKENS.get((src, dst), set())
    if expected and not any(r in expected for r in routes):
        errors.append(
            f"{src_path.name} [{src}→{dst or 'terminal'}]: "
            f"no matching handoff token in downstream_routes {routes}. "
            f"Expected one of: {sorted(expected)}"
        )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--collection", metavar="YAML", help="002 requirement-collection-consolidation metadata")
    ap.add_argument("--dedup",      metavar="YAML", help="003 requirement-deduplication-and-clustering metadata")
    ap.add_argument("--context",    metavar="YAML", help="004 requirement-context-enrichment metadata")
    ap.add_argument("--pain",       metavar="YAML", help="005 user-pain-point-analysis metadata")
    ap.add_argument("--journey",    metavar="YAML", help="006 user-journey-analysis metadata")
    args = ap.parse_args()

    stage_args = {
        "collection": args.collection,
        "dedup":      args.dedup,
        "context":    args.context,
        "pain":       args.pain,
        "journey":    args.journey,
    }

    if not any(stage_args.values()):
        ap.print_help()
        return 1

    errors: list[str] = []
    data: dict[str, dict] = {}
    stages = list(stage_args.keys())

    for stage, arg in stage_args.items():
        if arg:
            p = Path(arg)
            if not p.exists():
                errors.append(f"file not found: {p}")
            else:
                data[stage] = check_stage(p, stage, errors)

    present = [s for s in stages if s in data]
    for i, stage in enumerate(present):
        nxt = present[i + 1] if i + 1 < len(present) else None
        check_handoff(Path(stage_args[stage]), stage, nxt, data[stage], errors)

    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        return 1

    stage_labels = " → ".join(present)
    print(f"OK: requirement-definition chain passes ({stage_labels})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
