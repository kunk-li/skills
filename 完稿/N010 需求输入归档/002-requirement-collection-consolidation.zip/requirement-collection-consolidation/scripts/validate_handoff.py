#!/usr/bin/env python3
import csv, re, sys
from pathlib import Path

REQ_RE = re.compile(r"\bREQ-[a-z0-9_]+-\d{3,}\b", re.I)
CLUSTER_RE = re.compile(r"\bRCL-[a-z0-9_]+-\d{3,}\b", re.I)
CTX_RE = re.compile(r"\bCTX-[a-z0-9_]+-\d{3,}\b", re.I)
PAIN_RE = re.compile(r"\bPAIN-[a-z0-9_]+-\d{3,}\b", re.I)
JNY_RE = re.compile(r"\bJNY-[a-z0-9_]+-\d{3,}\b", re.I)
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")
ROUTE_TOKENS = {
    "collection", "deduplication", "context_enrichment", "pain_analysis",
    "journey_analysis", "planning_intake", "structured_modeling",
    "human_review", "monitor_only", "value_assessment", "prioritization"
}


def read_csv(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def split(v):
    return [x.strip() for x in str(v or '').split('|') if x.strip()]


def parse_scalar(v):
    v = v.strip()
    if v.startswith('[') and v.endswith(']'):
        body = v[1:-1].strip()
        if not body:
            return []
        return [x.strip().strip('"\'') for x in body.split(',')]
    return v.strip('"\'')


def load_yaml_like(path):
    data = {}
    current = None
    p = Path(path)
    if not p.exists():
        return data
    for raw in p.read_text(encoding='utf-8').splitlines():
        line = raw.rstrip()
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        if not line.startswith(' ') and ':' in line:
            k, v = line.split(':', 1)
            k = k.strip(); v = v.strip()
            if v == '':
                data[k] = []
                current = k
            else:
                data[k] = parse_scalar(v)
                current = None
        elif current and line.strip().startswith('- '):
            data[current].append(parse_scalar(line.strip()[2:]))
    return data


def sidecar_for(path):
    return Path(path).with_suffix('.metadata.yaml')


def scan_markdown(path, pattern, label, errors):
    text = Path(path).read_text(encoding='utf-8', errors='ignore')
    if PRIVATE_NODE_RE.search(text):
        errors.append(f"{path}: private workflow-node code found in markdown")
    found = set(m.group(0) for m in pattern.finditer(text))
    if not found:
        errors.append(f"{path}: no {label} matching expected id pattern found")
    return found


def collect_artifact_id(path, warnings):
    meta = load_yaml_like(sidecar_for(path))
    artifact_id = str(meta.get('artifact_id', '')).strip()
    if not artifact_id:
        warnings.append(f"{path}: metadata sidecar missing or has no artifact_id; cross_artifact_refs cannot be checked")
    return artifact_id, meta


def main():
    import argparse
    ap = argparse.ArgumentParser(description='validate optional cross-skill handoff references')
    ap.add_argument('--collection', action='append', default=[])
    ap.add_argument('--deduplication', action='append', default=[])
    ap.add_argument('--context', action='append', default=[])
    ap.add_argument('--pain', action='append', default=[])
    ap.add_argument('--journey', action='append', default=[])
    ap.add_argument('--allow-unresolved-cross-refs', action='store_true', help='warn instead of failing when a sidecar references an artifact not supplied in this invocation')
    args = ap.parse_args()

    errors = []
    warnings = []
    req_ids = set(); cluster_ids = set(); context_ids = set(); pain_ids = set(); journey_ids = set()
    known_artifact_ids = set()
    metas = []

    for group in [args.collection, args.deduplication, args.context, args.pain, args.journey]:
        for f in group:
            aid, meta = collect_artifact_id(f, warnings)
            if aid:
                known_artifact_ids.add(aid)
                metas.append((f, meta))

    for f in args.collection:
        for r in read_csv(f):
            rid = r.get('requirement_id', '').strip()
            if rid:
                req_ids.add(rid)
    for f in args.deduplication:
        for r in read_csv(f):
            cid = r.get('cluster_id', '').strip()
            if cid:
                cluster_ids.add(cid)
            if req_ids:
                for rid in split(r.get('member_requirement_ids')):
                    if rid not in req_ids:
                        errors.append(f"{f}: member_requirement_id {rid!r} not found in collection artifacts")
    for f in args.context:
        context_ids |= scan_markdown(f, CTX_RE, 'context_id', errors)
    for f in args.pain:
        pain_ids |= scan_markdown(f, PAIN_RE, 'pain_id', errors)
    for f in args.journey:
        journey_ids |= scan_markdown(f, JNY_RE, 'journey_id', errors)

    if known_artifact_ids:
        for f, meta in metas:
            refs = meta.get('cross_artifact_refs', [])
            if isinstance(refs, str):
                refs = [refs]
            for ref in refs or []:
                if not ref or ref in ROUTE_TOKENS:
                    continue
                if ref not in known_artifact_ids:
                    msg = f"{f}: cross_artifact_ref {ref!r} not found among provided artifact metadata"
                    if args.allow_unresolved_cross_refs:
                        continue
                    else:
                        errors.append(msg)

    for w in warnings:
        print('WARN:', w)
    if errors:
        for e in errors:
            print('ERROR:', e, file=sys.stderr)
        return 1
    print('OK: requirement-definition handoff references are consistent for provided artifacts')
    return 0

if __name__ == '__main__':
    sys.exit(main())
