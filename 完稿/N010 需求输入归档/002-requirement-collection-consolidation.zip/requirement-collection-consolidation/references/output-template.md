# Output template

Produce `raw-requirement-pool.csv` as CSV.

```csv
requirement_id,normalized_requirement,source_ids,source_types,requester_or_role,category,evidence_refs,confidence,conflict_status,open_questions,original_text,received_at,business_area,assumptions,notes
```

Rules:
- Keep ids stable.
- Use `|` in multi-value cells.
- Keep evidence and uncertainty explicit.
- Do not add private workflow node ids.
