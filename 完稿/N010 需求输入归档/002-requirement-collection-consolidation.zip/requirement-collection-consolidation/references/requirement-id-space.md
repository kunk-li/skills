# Requirement-definition id space

## Artifact id

Use `COLLECTION-ARTIFACT-<scope>-<yyyymm>` for sidecar `artifact_id`.

Example: `COLLECTION-ARTIFACT-checkout-202605`.

## Row or section id

Primary id field: `requirement_id`.
Expected pattern: `^REQ-[a-z0-9_]+-\d{3,}$`.
Example: `REQ-checkout-001`.

## Multi-value cells

Use `|` as the delimiter in CSV multi-value cells. Do not use bare commas inside machine-readable id lists.
