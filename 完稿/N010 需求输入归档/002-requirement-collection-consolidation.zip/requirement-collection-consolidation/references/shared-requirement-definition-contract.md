# Shared requirement-definition contract

## Skill family identity

```yaml
skill_family: requirement-definition-suite
contract_version: requirement-definition-suite-v1.3.0
private_workflow_node_policy: do_not_embed_node_ids_in_skill_artifacts
order_policy: skills_are_standalone_and_composable
```

## Semantic route tokens

Use route tokens rather than host workflow node numbers:

- `collection`
- `deduplication`
- `context_enrichment`
- `pain_analysis`
- `journey_analysis`
- `planning_intake`
- `structured_modeling`
- `human_review`
- `monitor_only`

Host workflows may map these tokens to their own nodes outside the skill package.

## Host workflow identifier

Metadata must include `workflow_node` as a host-supplied workflow identifier. Do not use placeholders such as `host-workflow`, `TBD`, or `待确认`, and do not embed private numeric workflow-node codes.

## Upstream cascade samples

`examples/upstream/` contains generic feedback-loop sample artifacts that can be used for cascade testing. These samples are not additional skills and do not create ordering requirements.

## Evidence and confidence

Allowed confidence values: `high`, `medium`, `low`, `needs_human_review`.
Every important row or section should carry evidence references or an explicit open question.

## Common quality checklist

1. Use source/evidence references for every major claim.
2. Separate confirmed facts, reasonable assumptions, and open questions.
3. Keep output machine-readable when the contract requires CSV/JSON.
4. Do not invent requirements, scope, user roles, evidence, dates, or priorities.
5. Preserve differences that affect scope, role, rule, or journey boundary.
6. Use route tokens rather than private workflow node codes.
7. Avoid prerequisite/order language; each skill must be usable on its own.
8. Make handoff identifiers stable and traceable.
9. Flag low evidence instead of hiding uncertainty.
10. Keep recommendations distinct from facts.
11. Run bundled validators before final handoff when artifacts are produced.

## Common failure modes

| id | failure mode | prevention |
| --- | --- | --- |
| fabricated_evidence | Claiming a requirement, pain, journey stage, or rule without source evidence. | Require evidence_refs or an open question. |
| overmerge | Merging items that share theme but differ in actor, rule, trigger, or scope. | Use preserved_differences and human_review. |
| hidden_conflict | Flattening contradictory inputs into one clean statement. | Set conflict_status or open_questions. |
| solution_leakage | Writing features or designs instead of user need/problem/context. | Move solution ideas to notes and mark as suggestion. |
| priority_overreach | Turning analysis into roadmap ranking. | Use route tokens or handoff notes only. |
| private_node_leak | Embedding host workflow node ids in skill artifacts. | Use role/route tokens and host mapping outside the skill. |
| order_binding | Using depends_on/blocks or positional ids that imply the skill cannot stand alone. | Use composable_with only. |
| metadata_drift | Artifact and metadata disagree on schema, version, mode, or ids. | Run release consistency validation. |

## v1.3.0 A+ guardrail additions

- Upstream cascade fixtures include metadata sidecars so artifact ids resolve without warning.
- Release consistency is 7-in-1: skill metadata, node neutrality, order neutrality, decision tree, artifact examples, metadata sidecars, and handoff smoke validation.
- Retired v1.1/v1.2 contract or schema tokens must not appear in SKILL.md.
