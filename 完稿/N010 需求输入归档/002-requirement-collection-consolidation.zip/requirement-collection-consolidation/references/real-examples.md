# Real Examples / 真实示例参考

These examples illustrate correctly formed rows and common edge cases. Use them as regression seeds alongside the bundled `examples/` files.

---

## Example 1: Multi-source intake — conflicting sources

**Input**: A chat message says "invoice title must be saved after address edit"; a support ticket says "invoice title resets after address edit".

**Correct pattern**:
```
requirement_id: REQ-checkout-002
normalized_requirement: Users need invoice title to persist after editing billing address
conflict_status: possible_conflict
open_questions: Chat says "saved" (implying it works), ticket says "resets" (implying it fails); confirm current behavior with QA.
confidence: medium
```

**Anti-pattern to avoid (AP-COL-01)**: Dropping one source and writing `conflict_status: none` to make the row look clean.

---

## Example 2: Meeting notes — requirement vs. solution

**Input**: "Product director said we should add a bulk export button."

**Correct pattern**:
```
requirement_id: REQ-export-001
normalized_requirement: Finance admins need to export multiple records at once for offline processing
original_text: "product director said we should add a bulk export button"
notes: "bulk export button" is a proposed solution; normalized as the underlying need
```

**Anti-pattern to avoid (AP-COL-03)**: Writing `normalized_requirement: Add a bulk export button` — this records a solution commitment, not a requirement.

---

## Example 3: Partial evidence triage — single vague source

**Input**: Someone pasted "users say search is slow" with no ticket ID.

**Correct pattern**:
```
requirement_id: REQ-search-001
normalized_requirement: Users experience slow response times when using search
source_ids: SRC-paste-001
confidence: low
open_questions: No ticket ID or frequency data. Needs confirmation from analytics or support batch.
readiness: partial
```

**Anti-pattern to avoid (AP-COL-05)**: Discarding the row because the source is weak. Low-confidence rows belong in the pool with `confidence: low` and `readiness: partial`.
