# Quality checklist

First apply the common checklist in `shared-requirement-definition-contract.md`.

## Skill-specific checks

- Every normalized requirement has source ids.
- Conflict status is explicit.
- No priority decisions are made.

- Metadata `workflow_node` is a real host workflow identifier, not a placeholder.
- Anti-patterns AP-01 through AP-10 and the five skill-specific AP rows have been checked.
