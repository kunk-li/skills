# Common failure modes

| failure | symptom | recovery |
| --- | --- | --- |
| fabricated_evidence | Claiming a requirement, pain, journey stage, or rule without source evidence. | Require evidence_refs or an open question. |
| overmerge | Merging items that share theme but differ in actor, rule, trigger, or scope. | Use preserved_differences and human_review. |
| hidden_conflict | Flattening contradictory inputs into one clean statement. | Set conflict_status or open_questions. |
| solution_leakage | Writing features or designs instead of user need/problem/context. | Move solution ideas to notes and mark as suggestion. |
| priority_overreach | Turning analysis into roadmap ranking. | Use route tokens or handoff notes only. |
| private_node_leak | Embedding host workflow node ids in skill artifacts. | Use role/route tokens and host mapping outside the skill. |
| order_binding | Using depends_on/blocks or positional ids that imply the skill cannot stand alone. | Use composable_with only. |
| metadata_drift | Artifact and metadata disagree on schema, version, mode, or ids. | Run release consistency validation. |
