# Selected-mode decision tree

Choose exactly one selected_mode:

- `multi_source_intake`: use when multi source intake is the closest operating mode.
- `meeting_notes_consolidation`: use when meeting notes consolidation is the closest operating mode.
- `feedback_backlog_intake`: use when feedback backlog intake is the closest operating mode.
- `spreadsheet_cleanup`: use when spreadsheet cleanup is the closest operating mode.
- `partial_evidence_triage`: use when partial evidence triage is the closest operating mode.

Validation rule: metadata `selected_mode` must match one of the modes above and the schema enum.
