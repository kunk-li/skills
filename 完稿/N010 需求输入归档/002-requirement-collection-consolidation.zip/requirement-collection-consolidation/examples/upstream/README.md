# Upstream sample artifacts

These are generic upstream feedback-loop samples for cascade tests. They are not additional skills and do not define host workflow nodes. Use them when testing intake from feedback mining into requirement collection or triage.

Files:

- `feedback-clusters-sample.csv`: clustered user feedback themes.
- `production-signals-sample.csv`: normalized product or runtime signals.
- `requirement-hypotheses-sample.csv`: evidence-backed requirement candidates.

## v1.3.0 update

Each upstream CSV sample now has a lightweight `.metadata.yaml` sidecar so cascade smoke tests can resolve artifact ids without warnings. These sidecars are regression fixtures only and do not define additional skills.
