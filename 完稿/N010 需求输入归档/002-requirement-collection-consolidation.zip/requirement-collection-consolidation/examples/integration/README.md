# Integration Examples / 集成示例

This directory contains a five-artifact integration example demonstrating how all five A-family requirement-definition skills chain together for a checkout feature.

## Checkout Requirement Definition Chain

| Skill | Artifact | File |
| --- | --- | --- |
| 002 requirement-collection-consolidation | COLLECTION-ARTIFACT-checkout-202605 | `checkout-requirements.csv` + `.metadata.yaml` |
| 003 requirement-deduplication-and-clustering | DEDUPLICATION-ARTIFACT-checkout-202605 | `checkout-clusters.csv` + `.metadata.yaml` |
| 004 requirement-context-enrichment | CONTEXT-ARTIFACT-checkout-202605 | `checkout-context-brief.md` + `.metadata.yaml` |
| 005 user-pain-point-analysis | PAIN-ARTIFACT-checkout-202605 | `checkout-pain-points.md` + `.metadata.yaml` |
| 006 user-journey-analysis | JOURNEY-ARTIFACT-checkout-202605 | `checkout-journey.md` + `.metadata.yaml` |

## Downstream handoff chain

```
collection → deduplication → context_enrichment → pain_analysis → journey_analysis → value_assessment
```

## Validate the chain

Run from any A-family skill directory:

```bash
python scripts/validate_requirement_definition_chain.py \
    --collection examples/integration/checkout-requirements.metadata.yaml \
    --dedup      examples/integration/checkout-clusters.metadata.yaml \
    --context    examples/integration/checkout-context-brief.metadata.yaml \
    --pain       examples/integration/checkout-pain-points.metadata.yaml \
    --journey    examples/integration/checkout-journey.metadata.yaml
```
