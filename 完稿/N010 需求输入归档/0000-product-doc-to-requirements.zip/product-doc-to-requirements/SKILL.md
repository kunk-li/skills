---
name: product-doc-to-requirements
description: Convert PRDs, meeting notes, and prototype links into a three-column CSV (module, feature point, backend-ready scenario) for Java development requirements.
---

# Product Doc To Java Requirements

Transform product documents or accessible prototype links into a fixed three-column CSV for Java development requirements.

Use the bundled template in `references/java-backend-requirements-template.md`, the decomposition guidance in `references/section-6-guidance.md`, and validate the result against `references/quality-checklist.md` before finalizing.

## Workflow

Follow this sequence every time:

1. Read the available source material.
   - Accept uploaded project documents, pasted text, screenshots, or accessible prototype links.
   - If a link is inaccessible, continue with the available information and state the limitation inside the CSV detail field when relevant.
   - If the input is a prototype link or screenshot, extract backend-relevant intent from pages, forms, buttons, tables, states, and role differences.

2. Extract grounded product facts.
   - Capture business background, goals, scope, actors, flows, business rules, constraints, and obvious backend implications.
   - Separate source-grounded facts from inferred engineering details.

3. Decompose the material into three-level rows.
   - Column 1: `大类模块`
   - Column 2: `需实现功能点`
   - Column 3: `功能场景详情`
   - Split rows by independently buildable capability, not by vague business themes.
   - Repeat the module value for every row. Do not rely on merged cells.

4. Write the output as CSV only.
   - The header row must be exactly: `大类模块,需实现功能点,功能场景详情`
   - Output must contain exactly three columns in every row.
   - Always wrap every field in double quotes.
   - Escape embedded double quotes by doubling them.
   - Do not output markdown tables.
   - By default, place the CSV inside a fenced `csv` code block unless the user explicitly requests raw CSV only.

5. Run the quality check.
   - Review the rows using `references/quality-checklist.md`.
   - Make sure each row is useful to backend engineering, QA, and project management.

## Output Rules

Apply these rules in every output:

- Write in Chinese unless the user requests another language.
- Output the requirement result as CSV with exactly three columns.
- Keep one implementable feature point per row.
- Use `大类模块` for the high-level business domain or subsystem.
- Use `需实现功能点` for the concrete capability that can be developed, tested, or estimated.
- Use `功能场景详情` for backend-ready detail. Prefer this mini-structure inside the field:
  - `场景：...；`
  - `触发：...；`
  - `规则：...；`
  - `校验：...；`
  - `异常：...；`
  - `权限：...；`
  - `数据影响：...；`
  - `假设：...；` when needed
  - `待确认：...；` when needed
- If a sub-part is not supported by the source, do not invent facts. Use `待确认` or `假设` explicitly.
- If the user provided a preferred style or example table, mirror that style while preserving valid CSV output.
- Prefer semicolon-separated clauses in `功能场景详情` so the CSV remains compact but implementation-ready.
- Sort rows by module and by logical business flow within the module.
- When the source is thin, produce the best possible draft but make uncertainty obvious in the detail field.

## Default Technical Assumptions

Unless the user specifies otherwise, assume:

- Java backend service
- Spring Boot style layering
- RESTful interaction pattern
- Relational database
- Standard enterprise concerns: authentication, authorization, validation, logging, monitoring, idempotency where needed, and auditability for important operations

Place these only in `功能场景详情` as `假设` when they are not confirmed by the source.

## Row Construction Rules

For each CSV row:

- `大类模块` should be stable, short, and business-readable, such as `内容基础管理`, `审批中心`, `招聘管理`, or `移动端`.
- `需实现功能点` should be an independently understandable feature point such as `组织架构管理`, `岗位管理`, `招聘申请`, or `面试管理`.
- `功能场景详情` must capture enough detail for implementation. Cover, when relevant:
  - who triggers the behavior
  - under what conditions it can happen
  - what data or key fields matter
  - what validations and business rules apply
  - what exceptions must be handled
  - what permission constraints apply
  - what data is created, updated, or synchronized
  - what is assumed or still unknown

Do not collapse multiple unrelated behaviors into a single row when they have different rules, roles, or state transitions.

## References

- Template: `references/java-backend-requirements-template.md`
- Decomposition guidance: `references/section-6-guidance.md`
- Checklist: `references/quality-checklist.md`
- Example: `references/example.md`
