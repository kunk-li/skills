# API script output template

```yaml
metadata:
  skill_id: api-test-script-generation
  skill_version: "2.2.1"
  contract_version: n240.api_test_scripts.v2
  selected_mode: from_openapi_mode
  readiness: pass
  confidence: medium
  produced_events: [produced.n240.api_test_scripts.v2.2]

test_scripts:
  - script_id: ATS-ORDER-001
    framework: rest_assured
    script_bundle_manifest:
      - path: src/test/java/com/company/api/OrderApiTest.java
        purpose: order API contract and functional checks
        traceability_refs: [api:POST /api/v1/orders, tc:TC-ORDER-001]
    auth_handling:
      strategy: shared_token
    fixture_management:
      teardown_strategy: {automatic_cleanup: true, methods: [db_rollback]}
    assertion_chaining:
      multi_level_assertions:
        level_1_status: HTTP 201
        level_2_response_schema: OrderResponse
        level_3_response_content: order_id non-null
        level_4_side_effects: orders.count == 1
        level_5_performance: < 500ms
```


## v2.2 output fields

```yaml
feedback_used:
  contracts: []
  signal_ids: []
  influence:
    added_scopes_or_tests: []
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals: []
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied: []
    final_score: integer
```
