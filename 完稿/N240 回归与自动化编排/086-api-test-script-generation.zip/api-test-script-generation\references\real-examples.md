# API script examples

## Example: rest_assured order creation

```yaml
test_scripts:
  - script_id: ATS-ORDER-001
    framework: rest_assured
    auth_handling:
      strategy: shared_token
      implementation:
        token_acquisition:
          method: test_login_endpoint
          caching: {enabled: true, ttl: 5min}
    fixture_management:
      setup_strategy: per_test
      db_setup: {approach: test_containers, isolation: transaction_rollback}
      teardown_strategy: {automatic_cleanup: true, methods: [db_rollback]}
    assertion_chaining:
      multi_level_assertions:
        level_1_status: HTTP 201
        level_2_response_schema: OrderResponse
        level_3_response_content: order_id non-null and status=PENDING
        level_4_side_effects: orders table row exists
        level_5_performance: response < 500ms
    generated_script:
      file_path: src/test/java/com/company/api/OrderApiTest.java
      dependencies: [rest-assured, testcontainers, junit]
```


## v2.2 feedback example fragment

```yaml
feedback_used:
  contracts:
    - feedback.n250.defect_signal.v1
  signal_ids:
    - DEFECT-HIST-001
  influence:
    added_scopes_or_tests:
      - "added historical hotspot coverage for payment retry path"
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals:
    - signal_id: OLD-FLAKY-2019
      reason: "stale signal over 90 days and no recent recurrence"
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied:
      - "missing_traceability_id: -15"
    final_score: 85
```
