# API Framework Code Templates v2.2

Use this file only when `test_framework` is selected or requested. Keep generated code runnable in principle, but adapt package names, endpoints, payloads, auth helpers, and environment variables to the user-provided project.

## Rest Assured Java template

```java
@ExtendWith(SpringExtension.class)
@SpringBootTest
@Testcontainers
class OrderApiTest {
  private static String token;

  @BeforeAll
  static void setupAuth() {
    token = AuthHelper.obtainToken(TestUser.CUSTOMER);
  }

  @Test
  @DisplayName("create order returns 201 and persists side effect")
  void createOrder_validPayload_returns201() {
    CreateOrderRequest request = OrderTestDataFactory.validOrder();

    given()
      .auth().oauth2(token)
      .header("X-Idempotency-Key", UUID.randomUUID().toString())
      .contentType(ContentType.JSON)
      .body(request)
    .when()
      .post("/api/v1/orders")
    .then()
      .statusCode(201)
      .body("order_id", notNullValue())
      .body("status", equalTo("PENDING"))
      .time(lessThan(500L));
  }
}
```

## Postman JavaScript template

```javascript
pm.test("status is expected", function () {
  pm.response.to.have.status(pm.iterationData.get("expected_status"));
});

pm.test("schema is valid", function () {
  const schema = pm.collectionVariables.get("response_schema");
  pm.response.to.have.jsonSchema(JSON.parse(schema));
});

pm.test("business fields are valid", function () {
  const json = pm.response.json();
  pm.expect(json.order_id).to.exist;
  pm.expect(json.status).to.eql("PENDING");
});
```

## k6 JavaScript template

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<500'],
  },
};

export default function () {
  const res = http.get(`${__ENV.BASE_URL}/api/v1/orders`, {
    headers: { Authorization: `Bearer ${__ENV.API_TOKEN}` },
  });
  check(res, {
    'status is 200': (r) => r.status === 200,
    'latency under budget': (r) => r.timings.duration < 500,
  });
  sleep(1);
}
```

## Supertest TypeScript template

```typescript
import request from 'supertest';
import { app } from '../../src/app';
import { authTokenFor } from '../support/auth';

describe('Order API', () => {
  it('creates an order with valid payload', async () => {
    const token = await authTokenFor('customer');
    const response = await request(app)
      .post('/api/v1/orders')
      .set('Authorization', `Bearer ${token}`)
      .set('X-Idempotency-Key', crypto.randomUUID())
      .send(validOrderPayload())
      .expect(201);

    expect(response.body.order_id).toBeDefined();
    expect(response.body.status).toBe('PENDING');
  });
});
```

## pytest-httpx Python template

```python
def test_create_order_returns_201(api_client, auth_token, valid_order_payload):
    response = api_client.post(
        "/api/v1/orders",
        json=valid_order_payload,
        headers={
            "Authorization": f"Bearer {auth_token}",
            "X-Idempotency-Key": str(uuid.uuid4()),
        },
    )
    assert response.status_code == 201
    body = response.json()
    assert body["order_id"]
    assert body["status"] == "PENDING"
```

## Template binding rules

- Always bind generated files to `script_bundle_manifest[].path`.
- Always include auth helper, data factory, fixture setup, teardown, schema validation, and side-effect assertion notes.
- Use k6 primarily for load/smoke adaptation, not full functional coverage.
- If a framework is not supplied, recommend one using project language and CI constraints instead of guessing silently.
