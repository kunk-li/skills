---
name: api-test-script-generation
description: generate openapi-derived api test script bundles from api specifications, test cases, error codes, dto definitions, auth strategy, and framework choice. use for rest assured, postman, k6, supertest, or pytest-httpx automation assets that need fixtures, teardown, assertion chaining, contract checks, ci reporting, and n240 orchestration handoff. trigger on any request to generate API test scripts, write REST or HTTP tests, produce Postman or pytest-httpx bundles, or automate endpoint validation. [N240]
---
# api-test-script-generation

## Role and boundary

Deliver the N240 artifact `接口测试脚本.zip` as an independently usable, workflow-aligned skill. Keep this skill generic enough for a single pull request, hotfix, release, module, endpoint group, or CI modernization task, while making its output stronger when composed with the other N240 skills.

Own: Generate OpenAPI-derived API test bundles with framework templates, auth fixtures, teardown, assertions, and contract tests.

Do not claim runtime results unless execution evidence is supplied. Do not regenerate upstream artifacts when they are already provided; consume and reference them through stable IDs.

This skill aligns to testing & qa → regression and automation planning → API测试脚本. It delivers executable API test bundles for N240.

### Boundary
- Focus on planning artifacts, not runtime execution results.
- Consume upstream N230 and N240 artifacts by reference; do not regenerate them.
- Do not fabricate test results unless execution evidence is supplied.


## Routing decision table

| Situation | Action |
|---|---|
| OpenAPI spec available | Parse spec; generate tests for all documented endpoints |
| No spec; endpoint path known | Generate inferred tests; set `schema_source: inferred` |
| Auth strategy = custom | Set `human_review_required: true` for auth fixture design |
| Contract test requested | Add schema validation assertion to every response test |
| Hardcoded secrets detected | Reject; replace with `os.environ.get('SECRET_NAME')` pattern |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n240.api-test-script.v2.2"
contract_version: "n240.test_scripts.v2.2"
artifact_target: "接口测试脚本.zip"
workflow_node: "N240"
node_artifact_target: "n240.api_test_bundle"
function_bias: "execution"
compatible_with:
  - n240.test_scripts.v2
consumed_signal_contracts:
  - feedback.n005.production_signal_package.v1
  - feedback.n250.defect_signal.v1
  - feedback.n300.api_error_signal.v1
  - feedback.n150.api_contract_signal.v1
produced_events:
  - produced.n240.api_test_scripts.v2.2
  - state.n240.api_scripts.readiness
  - exception.n240.api_scripts.contract_violation
downstream_consumers:
  - 087 trigger strategy
  - 088 orchestration
  - N260 quality gate
  - N300 monitoring baseline
```

Keep frontmatter limited to `name` and `description`; versioning lives in the body and output metadata so packaging validators remain compatible.

## Mode selection

Every result must start with `metadata.selected_mode`, `metadata.readiness`, `metadata.confidence`, and `metadata.evidence_profile`.

Allowed modes:
- `from_openapi_mode`: derive contract-first tests from current OpenAPI operations.
- `functional_mode`: focus on business flows and side-effect assertions.
- `data_driven_mode`: generate parameterized scripts and fixture/data factories.
- `framework_migration`: translate an existing API suite into a supported framework shape.

## Inputs

Required or strongly preferred inputs:
- `openapi_spec`
- `test_cases`
- `error_codes`
- `dtos`
- `test_framework`
- `auth_strategy`

Optional enhancement inputs:
- database schema
- environment variables
- service dependency contracts
- example payloads
- existing postman collections

Standalone behavior:
- If only one diff, module, endpoint group, or release slice is available, still produce the same output shape.
- If a required input is missing, mark `readiness: constrained` or `blocked`, list missing evidence, and avoid overclaiming certainty.
- If upstream N240 artifacts are present, preserve their `suite_id`, `tc_id`, `script_id`, `api_ref`, `risk_ref`, and `task_ref` values.


### Degradation rules

- If the OpenAPI spec is incomplete or absent, generate test stubs marked `pending_spec_confirmation` and flag missing endpoint definitions.
- If auth strategy is unspecified, produce placeholder auth fixtures marked `pending_auth_strategy` rather than hardcoding credentials.
- Keep the output schema stable even with minimal inputs; prefer explicit `pending_*` fields over silent omissions.


## Core output contract

Default to YAML-friendly Markdown and follow `references/output-template.md`.

The result must include:
- metadata (selected_mode, readiness, framework, evidence_profile)
- test_script_bundle
- fixture_catalog
- runner_config
- downstream_handoff
- self_check
- `readiness: ready | constrained | blocked`

## Hard gates and v2 rules

Load and apply `references/v2-rules.md` before finalizing. For any rule with `on_violation: reject`, set `readiness: blocked` unless the user explicitly asks for a draft or advisory-only artifact. Put all rule outcomes in `self_check.passed_rules`, `self_check.failed_rules`, and `self_check.warnings`.

## Execution workflow

1. If multiple N240 skills could apply, consult `references/node-routing-contract.md`; otherwise run this skill standalone.
2. Select the mode from the available evidence and user intent.
3. Normalize inputs into the common field contract in `references/field-contract.md`.
4. Load `references/feedback-input-contract.md` before using historical defects, production signals, CI runtime data, flaky metrics, or postmortems.
5. Apply the detailed schema and enums from `references/v2-output-contract.md`.
6. Produce the artifact using `references/output-template.md` and the richer examples in `references/real-examples.md`.
7. Emit `downstream_handoff` using the field-level map in `references/cross-skill-orchestration.md`.
8. Apply readiness inheritance from `references/readiness-inheritance.md`, confidence scoring from `references/confidence-scoring.md`, and finish with `self_check`.

## Event, SLA, and circuit hooks

See `references/n240-event-sla-hooks.md` for event emission, SLA queue hints, circuit hook patterns, and feedback contract handling.

## Example usage

**Input**: OpenAPI spec for GET /users/{id} with Bearer auth, returns User schema.

**Output** (`pytest-httpx` framework):
```python
import pytest
from httpx import AsyncClient

BASE_URL = os.environ["API_BASE_URL"]
TOKEN = os.environ["TEST_BEARER_TOKEN"]

@pytest.mark.asyncio
async def test_get_user_authenticated():
    async with AsyncClient(base_url=BASE_URL) as client:
        resp = await client.get("/users/1", headers={"Authorization": f"Bearer {TOKEN}"})
    assert resp.status_code == 200
    data = resp.json()
    assert "id" in data and "email" in data

@pytest.mark.asyncio
async def test_get_user_unauthenticated():
    async with AsyncClient(base_url=BASE_URL) as client:
        resp = await client.get("/users/1")
    assert resp.status_code == 401

@pytest.mark.asyncio
async def test_get_user_not_found():
    async with AsyncClient(base_url=BASE_URL) as client:
        resp = await client.get("/users/99999", headers={"Authorization": f"Bearer {TOKEN}"})
    assert resp.status_code == 404
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Usage scenarios

- rest_assured: Java REST Assured test class generation.
- postman: Postman collection JSON with environment variables.
- k6: k6 JS script for API performance testing.
- pytest_httpx: Python pytest + httpx async test module.
- supertest: Node.js supertest suite.


## Cross-skill integration map

| 上游 skill | 提供给 086 | 用途 |
|---|---|---|
| 080 test-point-generation | `test_point_list[]` | 测试点转为 API 测试脚本 |
| 082 boundary-condition-generation | `boundary_list[]` | 参数化边界值 |
| 083 exception-scenario-generation | `fault_injection_specs[]` | 依赖失败注入场景 |

| 下游 skill | 086 输出 | 如何使用 |
|---|---|---|
| 088 test-automation-orchestration | `test_scripts[]` | 编排器执行脚本 |
| 093 quality-gate-check | `api_test_results` | API 测试通过率维度 |

**工作流位置**: 测试点 → **086 API脚本** → 088 编排 → 093 质量门禁。

## Standalone usage guide

**Minimum input:** an API endpoint path + HTTP method — no OpenAPI spec required.

**Standalone decision path:**
1. Infer request/response schema from endpoint naming conventions.
2. Set `schema_source: inferred`; mark `pending_spec_confirmation: true`.
3. Default to `pytest_httpx` framework unless specified; generate stubs.

**Minimum viable output:**
```yaml
api_test_bundle:
  readiness: constrained
  framework: pytest_httpx
  pending_spec_confirmation: true
  tests:
    - test_id: AT-001
      endpoint: POST /api/v1/orders
      scenario: happy_path
      arrange: valid order payload
      act: POST with auth header
      assert: HTTP 201 + order_id in response
      schema_source: inferred
    - test_id: AT-002
      scenario: auth_missing
      act: POST without Authorization header
      assert: HTTP 401
```
**Downstream:** test bundle → 087 trigger recommendation → 088 pipeline orchestration.

## Resilience and governance

**Circuit breaker**: If generated scripts consistently fail to run in the target framework across 3 iterations, emit circuit_breaker: warn and flag the framework configuration.

**SLA guidance**: P0 when a protected endpoint has no auth test; P1 when fixture or cleanup is missing.

**Human review routing**: Set human_review_required: true when auth strategy is custom or when schema complexity exceeds documented thresholds.

**Confidence scoring**: When confidence on scope selection or tier assignment falls below 0.7, mark `readiness: constrained` and require human confirmation before the artifact is consumed downstream.

**Escalation path**: When `readiness: blocked`, escalate to the QA lead and CI owner. For release-gate mode, also notify the release manager.

Traceability: each generated test references its source endpoint_id and schema_version for contract validation.

## Auditable rules summary

- R01_framework_idiomatic: generated code must follow the target framework's conventions; on_violation: rewrite.
- R02_fixture_included: every test must include or reference a data fixture or factory; on_violation: reject.
- R03_auth_variants_covered: scripts must include at least one authenticated and one unauthenticated case per protected endpoint; on_violation: flag_gap.
- R04_error_codes_asserted: expected HTTP error codes (4xx, 5xx) must be asserted, not just noted; on_violation: add_assertion.
- R05_no_hardcoded_secrets: secrets, tokens, and passwords must use environment variables or fixtures, never hardcoded; on_violation: reject.
- R06_cleanup_included: test scripts that create or mutate data must include teardown or cleanup; on_violation: reject.
- R07_contract_test_required: for each external API integration, at least one contract/schema validation test must be included; on_violation: add_contract_test.

## Algorithm

1. Parse API spec (OpenAPI, Postman, or description); identify endpoints, methods, schemas, and auth strategy.
2. For each endpoint, generate happy-path, auth-variant, and error-code cases (R03, R04).
3. Generate fixture setup and teardown (R02, R06).
4. Apply framework-idiomatic patterns (R01); use env-vars for secrets (R05).
5. Bundle scripts with runner config (pytest.ini / postman collection / k6 options).
6. Emit `test_script_bundle`, `fixture_catalog`, `runner_config`.
7. Run `self_check`; set `readiness: blocked` if R02, R05, or R06 fires.

## Quality bar

A good result generates runnable, framework-idiomatic test code that covers happy paths, auth variants, error codes, and fixture setup. The bundle must be directly importable into the target framework without manual restructuring.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files

- `references/node-routing-contract.md`
- `references/feedback-input-contract.md`
- `references/confidence-scoring.md`
- `references/framework-code-templates.md`
- `references/v2-output-contract.md`
- `references/v2-rules.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/template-skeleton.md`

- `references/example-io.md`
- `references/example-io-v2.md`