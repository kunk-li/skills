# API script rules v2.2.1

| Rule | Requirement | on_violation |
|---|---|---|
| R01_from_openapi | Tests must derive from OpenAPI when a spec is present. | reject |
| R02_auth_unified | Auth must be centralized, not repeated in every test. | reject |
| R03_cleanup_guaranteed | Teardown/cleanup must be declared. | reject |
| R04_schema_validation | Response schema validation must be included. | reject |
| R05_contract_test_for_cross_service | Cross-service APIs must include contract tests. | reject |
| R06_data_factory_pattern | Use builder/factory patterns instead of hard-coded values. | reject |
| R07_multi_level_assertions | Do not only assert status; include deeper assertions where evidence allows. | reject |
| R08_flaky_retry_limited | Retry count must be <= 2. | reject |


## v2.2.1 reactive addendum rules

| Rule | Requirement | on_violation |
|---|---|---|
| R09_feedback_contracts_defined | Every value in `consumed_signal_contracts` and `feedback_used.contracts` must be defined in `references/feedback-input-contract.md`. | reject |
| R10_feedback_used_traceable | When feedback signals influence scope, scripts, triggers, stages, retries, gates, or confidence, output `feedback_used.contracts`, `feedback_used.signal_ids`, and `feedback_used.influence`. | reject |
| R11_confidence_score_calculated | Apply `references/confidence-scoring.md`, include final score and penalties, and map score to `confidence`. | reject |
| R12_stale_or_conflicting_feedback_handled | Stale, conflicting, or low-confidence feedback must be recorded in `ignored_signals` or `evidence_profile.stale_or_conflicting_feedback` before it can affect decisions. | reject |
