# API script output contract v2.2.1

## Supported frameworks

| Framework | Language | Primary use |
|---|---|---|
| `rest_assured` | Java | backend integration and contract-heavy API tests |
| `postman` | JavaScript | collection-driven API smoke and team sharing |
| `k6` | JavaScript | load testing and API smoke under traffic |
| `supertest` | TypeScript | Node.js service/API tests |
| `pytest_httpx` | Python | Python services and HTTP client tests |

## Required shape

```yaml
test_scripts:
  - script_id: ATS-001
    framework: enum[rest_assured, postman, k6, supertest, pytest_httpx]
    generated_script:
      file_path: string
      full_code: string
      dependencies: array
      imports: array
    auth_handling:
      strategy: enum[shared_token, per_test_login, service_account]
      token_injection: {header_name: Authorization, format: "Bearer {token}"}
    fixture_management:
      test_data_factory: {pattern: builder}
      setup_strategy: enum[per_test, per_class, per_suite, shared]
      teardown_strategy: {automatic_cleanup: true, methods: array}
    assertion_chaining:
      multi_level_assertions:
        level_1_status: string
        level_2_response_schema: string
        level_3_response_content: string
        level_4_side_effects: string
        level_5_performance: string
    contract_testing:
      enabled: bool
      contract_kind: enum[consumer_driven, provider_driven, openapi]
    ci_integration:
      run_triggers: {on_pr: bool, on_commit_to_main: bool, nightly: bool}
      reporting: [html, junit_xml, allure]
```

## OpenAPI generation path

For each operation, generate: happy path, each declared 4xx response, missing auth 401, insufficient auth 403, not found 404 when path includes an id, validation 400 or 422, and schema validation.


## v2.2.1 additions

```yaml
contract_version: "n240.test_scripts.v2.2"
compatibility:
  backward_compatible_with: "n240.test_scripts.v2"
  change_type: additive
feedback_inputs:
  consumed_signal_contracts:
    - feedback.n005.production_signal_package.v1
    - feedback.n250.defect_signal.v1
    - feedback.n300.api_error_signal.v1
    - feedback.n150.api_contract_signal.v1
  feedback_used_required_when_signals_used: true
confidence_scoring:
  policy_ref: references/confidence-scoring.md
  high_min_score: 85
  medium_min_score: 60
  low_below: 60
node_routing:
  policy_ref: references/node-routing-contract.md
```


## v2.2 framework template binding

```yaml
framework_code_templates_ref: references/framework-code-templates.md
framework_template_selection:
  rest_assured: java_junit_testcontainers
  postman: javascript_collection_tests
  k6: javascript_load_and_smoke
  supertest: typescript_node_api_tests
  pytest_httpx: python_api_client_tests
required_generated_bundle_files:
  - auth_helper
  - test_data_factory
  - teardown_or_cleanup_hook
  - schema_validation_helper
  - framework_specific_test_file
```
