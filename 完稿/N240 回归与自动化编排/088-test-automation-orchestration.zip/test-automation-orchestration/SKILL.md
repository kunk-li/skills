---
name: test-automation-orchestration
description: Design CI pipeline orchestration and YAML stage gates from regression, smoke, API scripts, and triggers; includes full_chain_verification_playbook mode staging structural scan, chain-walk, and integration.
---
# test-automation-orchestration

## Role and boundary

Deliver the N240 artifact `自动化测试编排.yaml` as an independently usable, workflow-aligned skill. Keep this skill generic enough for a single pull request, hotfix, release, module, endpoint group, or CI modernization task, while making its output stronger when composed with the other N240 skills.

Own: Generate pipeline-ready orchestration with stage gates, suite bindings, isolation strategy, retry classification, dashboards, and notifications.

Do not claim runtime results unless execution evidence is supplied. Do not regenerate upstream artifacts when they are already provided; consume and reference them through stable IDs.

This skill aligns to testing & qa → regression and automation planning → CI流水线设计.yaml. It delivers pipeline design and YAML skeleton artifacts for N240.

### Boundary
- Focus on planning artifacts, not runtime execution results.
- Consume upstream N230 and N240 artifacts by reference; do not regenerate them.
- Do not fabricate test results unless execution evidence is supplied.


## Routing decision table

| Situation | Action |
|---|---|
| GitHub Actions target | Generate `.github/workflows/` YAML skeleton |
| GitLab CI target | Generate `.gitlab-ci.yml` skeleton |
| Jenkins target | Generate `Jenkinsfile` declarative pipeline |
| Parallel design requested | Group tests into balanced parallel jobs within 20% time variance |
| No regression plan available | Use `pending_regression_plan: true`; generate skeleton with default stages |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n240.test-automation-orchestration.v2.2"
contract_version: "n240.orchestration_plan.v2.2"
artifact_target: "自动化测试编排.yaml"
workflow_node: "N240"
node_artifact_target: "自动化测试编排.yaml"
function_bias: "execution"
compatible_with:
  - n240.orchestration_plan.v2
consumed_signal_contracts:
  - feedback.n005.production_signal_package.v1
  - feedback.n250.failure_signal.v1
  - feedback.n300.ci_runtime_signal.v1
  - feedback.n300.infrastructure_failure_signal.v1
produced_events:
  - produced.n240.orchestration_plan.v2.2
  - state.n240.orchestration.readiness
  - exception.n240.orchestration.contract_violation
  - sla.n240.pipeline.escalation
downstream_consumers:
  - CI platform
  - N250 failure triage
  - N260 quality gate
  - N270 release pipeline
  - N300 CI monitoring
```

Keep frontmatter limited to `name` and `description`; versioning lives in the body and output metadata so packaging validators remain compatible.

## Mode selection

Every result must start with `metadata.selected_mode`, `metadata.readiness`, `metadata.confidence`, and `metadata.evidence_profile`.

Allowed modes:
- `minimal_ci`: create a compact pipeline for smaller projects while preserving gates.
- `enterprise_ci`: build multi-stage CI with isolation, caching, cleanup, dashboard, and notifications.
- `gitops_mode`: express environment promotion, approvals, canary checks, and rollback hooks.
- `cost_reduction`: optimize an existing pipeline for speed and cost without losing gates.
- `full_chain_verification_playbook`: **(G2/D-019 增)** 编排逐功能全链验证流水:静态(093)→走通(113/112)→对(086),fail-fast 由轻到重。见 §full_chain_verification_playbook。

## Inputs

Required or strongly preferred inputs:
- `regression_plan`
- `smoke_checklist`
- `test_scripts`
- `trigger_strategy`
- `infrastructure`

Optional enhancement inputs:
- environment topology
- container/runtime constraints
- historical CI duration metrics
- release notes
- deployment strategy

Standalone behavior:
- If only one diff, module, endpoint group, or release slice is available, still produce the same output shape.
- If a required input is missing, mark `readiness: constrained` or `blocked`, list missing evidence, and avoid overclaiming certainty.
- If upstream N240 artifacts are present, preserve their `suite_id`, `tc_id`, `script_id`, `api_ref`, `risk_ref`, and `task_ref` values.


### Degradation rules

- If the target CI system is unspecified, produce a system-agnostic YAML skeleton marked `pending_ci_target` with inline adaptation notes.
- If stage environment details are absent, use placeholder environment names marked `pending_environment_config`.
- Keep the output schema stable even with minimal inputs; prefer explicit `pending_*` fields over silent omissions.


## Core output contract

Default to YAML-friendly Markdown and follow `references/output-template.md`.

The result must include:
- metadata (selected_mode, readiness, ci_system, evidence_profile)
- pipeline_design
- yaml_skeleton
- stage_summary[]
- runtime_integration_evidence_matrix[] when repository/schema/adapter runtime boundary manifests are provided
- feature_depth_test_matrix[] when service/repository feature depth obligations or read-side security filters are provided
- downstream_handoff
- self_check
- `readiness: ready | constrained | blocked`

## Hard gates and v2 rules

Load and apply `references/v2-rules.md` before finalizing. For any rule with `on_violation: reject`, set `readiness: blocked` unless the user explicitly asks for a draft or advisory-only artifact. Put all rule outcomes in `self_check.passed_rules`, `self_check.failed_rules`, and `self_check.warnings`.

## Execution workflow

1. If multiple N240 skills could apply, consult `references/node-routing-contract.md`; otherwise run this skill standalone.
2. Select the mode from the available evidence and user intent.
3. Normalize inputs into the common field contract in `references/field-contract.md`.
4. Load `references/feedback-input-contract.md` before using historical defects, production signals, CI runtime data, flaky metrics, or postmortems.
5. Apply the detailed schema and enums from `references/v2-output-contract.md`.
6. Produce the artifact using `references/output-template.md` and the richer examples in `references/real-examples.md`.
7. Convert any `production_boundary_manifest[]` or `schema_runtime_boundary_manifest[]` into `runtime_integration_evidence_matrix[]`; if production evidence is absent, keep release-critical rows at `gate_decision: insufficient_evidence` instead of pass.
8. Convert any `feature_depth_obligations[]` and `read_side_security_filters[]` into `feature_depth_test_matrix[]`; every row must include positive and negative/denied cases, fixtures/source refs, and executed evidence or a blocking reason.
8. Emit `downstream_handoff` using the field-level map in `references/cross-skill-orchestration.md`.
9. Apply readiness inheritance from `references/readiness-inheritance.md`, confidence scoring from `references/confidence-scoring.md`, and finish with `self_check`.

## Event, SLA, and circuit hooks

See `references/n240-event-sla-hooks.md` for event emission, SLA queue hints, circuit hook patterns, and feedback contract handling.

## Example usage

### Scenario A — GitHub Actions: full pipeline with parallel jobs

**Input**: Regression plan (38 automated, 9 manual), smoke checklist (5 items), GitHub Actions.

**Output** (`github_actions` mode):
```yaml
# .github/workflows/test-pipeline.yml
name: Test Pipeline
on:
  pull_request:
    branches: [main, release/*]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm run lint

  unit:
    needs: lint
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@v4
      - run: npm test -- --testPathPattern=unit

  integration-payment:
    needs: unit
    runs-on: ubuntu-latest
    timeout-minutes: 10
    services:
      postgres:
        image: postgres:15
        env:
          POSTGRES_PASSWORD: test
    steps:
      - uses: actions/checkout@v4
      - run: npm test -- --testPathPattern=integration/payment

  e2e:
    needs: [unit, integration-payment]
    runs-on: ubuntu-latest
    environment: staging
    timeout-minutes: 15
    steps:
      - uses: actions/checkout@v4
      - run: npx playwright test --project=chromium

  notify-on-failure:
    if: failure()
    needs: [lint, unit, integration-payment, e2e]
    runs-on: ubuntu-latest
    steps:
      - name: Slack alert
        run: |
          curl -X POST ${{ secrets.SLACK_WEBHOOK }} \
            -d '{"text":"Pipeline failed on ${{ github.ref }}"}'
      - name: Trigger rollback
        run: ./scripts/rollback.sh ${{ github.sha }}
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Usage scenarios

- github_actions: GitHub Actions workflow YAML generation.
- gitlab_ci: GitLab CI pipeline YAML generation.
- jenkins: Jenkins declarative pipeline skeleton.
- fail_fast_audit: reorder existing pipeline for fail-fast optimization.
- parallel_design: design parallel job groups for wall-clock time reduction.


## Cross-skill integration map

| 上游 skill | 提供给 088 | 用途 |
|---|---|---|
| 084 | `regression_checklist[]` | 回归测试执行范围 |
| 085 | `smoke_checklist[]` | 烟雾测试执行范围 |
| 086 | `test_scripts[]` | 可执行的 API 测试脚本 |
| 087 | `trigger_strategy`, `pipeline_config` | 执行触发策略 |

| 下游 skill | 088 输出 | 如何使用 |
|---|---|---|
| 093 quality-gate-check | `orchestration_result`, `test_summary` | 门禁聚合编排执行结果 |
| 089 test-failure-attribution | `failed_test_ids[]` | 失败用例归因分析 |

**工作流位置**: 084/085/086/087 → **088 自动化编排** → 093 门禁/089 归因。

## full_chain_verification_playbook mode(全链验证编排 · G2/D-019 增)

把本 session 落地的四个全链验证法**串成一条编排流水**(本 skill 是编排器,正是其家):逐功能、fail-fast 由轻到重 ——

| stage | skill(现有) | 验 | 跑不跑 |
|---|---|---|---|
| 1 静态 | `093 built_vs_spec`(execution-chain) | 代码结构断链(没 handler/stub) | 不跑(最便宜,先筛) |
| 2 走通 | `113 trace-call-chain-analysis`(首选)/ `112 log-analysis`(无 trace fallback)的 `chain_completeness_verify` | 触发功能 → 链是否端到端走通、断在哪 | 跑一次/读 telemetry(轻) |
| 3 对 | `086 api-test-script-generation` 的 `full_chain_integration` | 链路结果对不对(含 DB 副作用) | 跑集成测试(重) |

- **fail-fast**:沿用本 skill"轻→重"哲学(lint→unit→integration→e2e 同构);stage1 断的功能不必进 stage2/3。
- **聚合**:逐功能产 `chain_verdict`(`static_break` / `not_walked_through@hop` / `result_mismatch` / `pass` / `unknown`)→ 喂 `093` 质量门禁的 `built_vs_spec` 维度。

**⚠️ 定位 = 周期/上线前发现器流水,非 per-PR CI 硬门禁(D-018)**
- stage1-2 非确定 + 偶有高置信误报 → 本 playbook **nightly / RC 切点跑**,出报告 + 人工裁定。
- **进 per-PR CI 的只是 stage3 里裁定确认过的确定性集成测试**(`086` 产物),不是整条 playbook。
- 覆盖 = 仅被触发的功能(`coverage` 显式列未覆盖)。

**输出**:在现有 `pipeline_design`/`yaml_skeleton` 形态上增 `full_chain_verification` stages + 每功能 `chain_verdict` 聚合 + discoverer-vs-CI 分层说明。**additive,不动 required 字段。**

## Standalone usage guide

**Minimum input:** CI system name + list of test types — no regression plan required.

**Standalone decision path:**
1. Apply default fail-fast stage order: lint → unit → integration → e2e.
2. If no stage timing data → use default estimates (unit: 5min, integration: 12min, e2e: 15min).
3. Set `timing_source: estimated`; flag `pending_regression_plan`.

**Minimum viable output:**
```yaml
pipeline_design:
  ci_system: github_actions
  readiness: constrained
  pending_regression_plan: true
  timing_source: estimated
  stages:
    - name: lint
      estimated_time: 2min
      fail_fast: true
    - name: unit
      estimated_time: 5min
      fail_fast: true
    - name: integration
      estimated_time: 12min
    - name: notify_on_failure
      trigger: on_failure
```
**Downstream:** pipeline design → 093 quality-gate-check (CI gate signals).

## Resilience and governance

**Circuit breaker**: If pipeline execution fails at the same stage across 3 consecutive runs due to environment issues, emit circuit_breaker: open and block further deployments until the stage is stabilized.

**SLA guidance**: P0 when a deployment stage has no rollback hook; P1 when gate condition is missing on any stage.

**Human review routing**: Set human_review_required: true when the CI infrastructure differs from the declared target or when rollback steps are not testable.

**Confidence scoring**: When confidence on scope selection or tier assignment falls below 0.7, mark `readiness: constrained` and require human confirmation before the artifact is consumed downstream.

**Escalation path**: When `readiness: blocked`, escalate to the QA lead and CI owner. For release-gate mode, also notify the release manager.

Traceability: each pipeline stage references its source regression_plan_id and trigger_strategy_id for N260 gate audit.

## Auditable rules summary

- R01_stage_sequence_justified: pipeline stages must be ordered fail-fast first (lint → unit → integration → e2e); on_violation: reorder.
- R02_parallel_declared: parallel execution groups must be explicitly declared with estimated wall-clock time; on_violation: warn.
- R03_environment_per_stage: each stage must declare its target environment or container; on_violation: reject.
- R04_gate_condition_explicit: pass condition for each stage gate must be stated; on_violation: reject.
- R05_yaml_compatible: output must be adaptable to the declared CI system (GitHub Actions / GitLab CI / Jenkins); on_violation: reformat.
- R06_rollback_hook_present: pipeline must include a rollback or notification step on failure for deployment stages; on_violation: add_hook.
- R07_parallel_groups_time_balanced: parallel job groups must have estimated times within 20% of each other to avoid idle runners; on_violation: rebalance.
- R08_runtime_matrix_complete: every release-critical repository/schema/adapter boundary manifest row must appear in `runtime_integration_evidence_matrix[]`; self-contained/local evidence is allowed only for `gate_effect: local_runtime_only`, not release clearance; on_violation: block.
- R09_feature_depth_matrix_complete: every source-backed eligibility, business-calendar temporal policy, enumerated detector breadth, and read-side security filter obligation must appear in `feature_depth_test_matrix[]` with at least one positive and one negative/denied case; happy-path-only coverage is insufficient; on_violation: block.

## Algorithm

1. Parse regression plan, smoke checklist, trigger strategy, and CI infrastructure.
2. Sequence stages fail-fast: lint → unit → integration → e2e → deploy (R01).
3. Declare parallel groups and estimate wall-clock time (R02).
4. Assign environment per stage (R03); set gate conditions (R04).
5. Add rollback/notification hooks for deployment stages (R06).
6. Format as YAML skeleton compatible with the target CI system (R05).
7. Emit `pipeline_design`, `yaml_skeleton`, `stage_summary`, `runtime_integration_evidence_matrix[]` when runtime boundary manifests exist, and `feature_depth_test_matrix[]` when feature-depth obligations exist.
8. Run `self_check`; set `readiness: blocked` if R03, R04, or R08 fires.

## Quality bar

A good result delivers a pipeline design that is feasible within the described CI infrastructure, sequences stages to fail fast, and preserves traceability back to test cases and risk evidence. The output must be ready for direct YAML adaptation.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files

- `references/node-routing-contract.md`
- `references/feedback-input-contract.md`
- `references/confidence-scoring.md`
- `references/v2-output-contract.md`
- `references/v2-rules.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/template-skeleton.md`

- `references/example-io.md`
- `references/example-io-v2.md`
