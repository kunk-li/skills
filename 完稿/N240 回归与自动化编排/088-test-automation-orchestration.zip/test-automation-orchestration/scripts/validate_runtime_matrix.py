#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


SAFE_NON_PASS = {"insufficient_evidence", "blocked", "not_cleared", "conditional"}


def load_doc(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize(value: Any) -> str:
    return str(value or "").strip().lower().replace("-", "_").replace(" ", "_")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact")
    args = parser.parse_args()
    doc = load_doc(Path(args.artifact))
    manifests = []
    for key in ("production_boundary_manifest", "schema_runtime_boundary_manifest", "adapter_runtime_boundary_manifest"):
        value = doc.get(key, [])
        if isinstance(value, list):
            manifests.extend(value)
    matrix = doc.get("runtime_integration_evidence_matrix", [])
    if not isinstance(matrix, list):
        print("INVALID: runtime_integration_evidence_matrix must be a list")
        return 1

    errors: list[str] = []
    release_critical_ids = {
        str(row.get("boundary_id"))
        for row in manifests
        if isinstance(row, dict) and row.get("release_critical") is True and row.get("boundary_id")
    }
    matrix_ids = {str(row.get("boundary_id")) for row in matrix if isinstance(row, dict)}
    missing = sorted(release_critical_ids - matrix_ids)
    if missing:
        errors.append(f"missing matrix rows for release-critical boundaries: {missing}")

    for row in matrix:
        if not isinstance(row, dict):
            errors.append("runtime matrix row must be object")
            continue
        boundary_id = str(row.get("boundary_id", "<unknown>"))
        gate_effect = normalize(row.get("gate_effect"))
        gate_decision = normalize(row.get("gate_decision"))
        evidence_tier = normalize(row.get("evidence_tier"))
        if gate_effect == "block_release" and evidence_tier != "production_external_integration" and gate_decision not in SAFE_NON_PASS:
            errors.append(
                f"{boundary_id} uses evidence_tier={evidence_tier} for block_release; "
                "gate_decision must be insufficient_evidence, blocked, not_cleared, or conditional"
            )

    if errors:
        print("INVALID")
        for err in errors:
            print(f"- {err}")
        return 1
    print("VALID")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
