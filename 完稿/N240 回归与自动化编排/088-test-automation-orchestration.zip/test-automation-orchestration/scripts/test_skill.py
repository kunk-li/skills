#!/usr/bin/env python3
"""Self-test: run structural, runtime, feature-depth, and reverse-coverage validators."""
import json, os, subprocess, sys, tempfile

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")

skill_dir  = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
skill_md   = os.path.join(skill_dir, "SKILL.md")
validator  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "validate_skill.py")

result = subprocess.run([sys.executable, validator, skill_md, "--strict"],
                        capture_output=True, text=True)
print(result.stdout)
if result.returncode != 0:
    print("STDERR:", result.stderr, file=sys.stderr)
    sys.exit(1)

runtime_validator = os.path.join(os.path.dirname(os.path.abspath(__file__)), "validate_runtime_matrix.py")
feature_depth_validator = os.path.join(os.path.dirname(os.path.abspath(__file__)), "validate_feature_depth_matrix.py")
reverse_coverage_validator = os.path.join(os.path.dirname(os.path.abspath(__file__)), "validate_reverse_coverage_matrix.py")


def run_doc(doc, validator_path=runtime_validator):
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as fh:
        json.dump(doc, fh)
        path = fh.name
    try:
        return subprocess.run([sys.executable, validator_path, path], capture_output=True, text=True, encoding="utf-8")
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


bad_missing = {
    "production_boundary_manifest": [{"boundary_id": "DB-001", "release_critical": True}],
    "runtime_integration_evidence_matrix": [],
}
if run_doc(bad_missing).returncode == 0:
    print("Expected missing runtime matrix row to fail", file=sys.stderr)
    sys.exit(1)

bad_overclaim = {
    "production_boundary_manifest": [{"boundary_id": "DB-001", "release_critical": True}],
    "runtime_integration_evidence_matrix": [{
        "boundary_id": "DB-001",
        "evidence_tier": "self_contained_runtime",
        "gate_effect": "block_release",
        "gate_decision": "pass",
    }],
}
if run_doc(bad_overclaim).returncode == 0:
    print("Expected self-contained block_release overclaim to fail", file=sys.stderr)
    sys.exit(1)

good = {
    "production_boundary_manifest": [{"boundary_id": "DB-001", "release_critical": True}],
    "runtime_integration_evidence_matrix": [{
        "boundary_id": "DB-001",
        "evidence_tier": "production_external_integration",
        "gate_effect": "block_release",
        "gate_decision": "pass",
    }],
}
good_result = run_doc(good)
if good_result.returncode != 0:
    print("Expected production_external_integration row to pass", file=sys.stderr)
    print(good_result.stdout, file=sys.stderr)
    sys.exit(1)

bad_depth_missing = {
    "feature_depth_obligations": [{
        "obligation_id": "FD-001",
        "obligation_type": "source_backed_eligibility",
    }],
    "feature_depth_test_matrix": [],
}
if run_doc(bad_depth_missing, feature_depth_validator).returncode == 0:
    print("Expected missing feature-depth matrix row to fail", file=sys.stderr)
    sys.exit(1)

bad_depth_happy_only = {
    "feature_depth_obligations": [{
        "obligation_id": "FD-002",
        "obligation_type": "business_calendar_temporal_policy",
    }],
    "feature_depth_test_matrix": [{
        "obligation_id": "FD-002",
        "obligation_type": "business_calendar_temporal_policy",
        "positive_case_refs": ["TC-allow"],
        "negative_case_refs": [],
        "executed_evidence_ref": "junit://TC-allow",
        "status": "pass",
        "gate_decision": "pass",
    }],
}
if run_doc(bad_depth_happy_only, feature_depth_validator).returncode == 0:
    print("Expected happy-path-only feature-depth coverage to fail", file=sys.stderr)
    sys.exit(1)

good_depth = {
    "feature_depth_obligations": [{
        "obligation_id": "FD-003",
        "obligation_type": "enumerated_detector_breadth",
    }],
    "read_side_security_filters": [{
        "filter_id": "RSF-001",
        "query_ref": "query.listProtectedRecords",
    }],
    "feature_depth_test_matrix": [
        {
            "obligation_id": "FD-003",
            "obligation_type": "enumerated_detector_breadth",
            "positive_case_refs": ["TC-detector-positive"],
            "negative_case_refs": ["TC-detector-no-signal"],
            "executed_evidence_ref": "junit://TC-detector",
            "status": "pass",
            "gate_decision": "pass",
        },
        {
            "obligation_id": "RSF-001",
            "obligation_type": "read_side_security_filter",
            "positive_case_refs": ["TC-read-allowed"],
            "negative_case_refs": ["TC-read-denied"],
            "executed_evidence_ref": "junit://TC-read-filter",
            "status": "pass",
            "gate_decision": "pass",
        },
    ],
}
good_depth_result = run_doc(good_depth, feature_depth_validator)
if good_depth_result.returncode != 0:
    print("Expected feature-depth matrix with positive+negative evidence to pass", file=sys.stderr)
    print(good_depth_result.stdout, file=sys.stderr)
    sys.exit(1)

bad_reverse_missing = {
    "required_feature_coverage": [{
        "feature_id": "FEATURE-001",
        "release_critical": True,
    }],
    "reverse_test_coverage_matrix": [],
}
if run_doc(bad_reverse_missing, reverse_coverage_validator).returncode == 0:
    print("Expected missing reverse coverage matrix row to fail", file=sys.stderr)
    sys.exit(1)

bad_reverse_overclaim = {
    "reverse_test_coverage_matrix": [{
        "feature_id": "FEATURE-002",
        "prd_anchor": "prd.section.2",
        "test_point_id": "TP-002",
        "test_case_id": "TC-002",
        "script_id": "",
        "pipeline_stage_id": "stage.integration",
        "runtime_boundary_id": "DB-002",
        "execution_evidence_id": "",
        "evidence_tier": "self_contained_runtime",
        "coverage_status": "pass",
        "downstream_gate_effect": "block_release",
    }],
}
if run_doc(bad_reverse_overclaim, reverse_coverage_validator).returncode == 0:
    print("Expected block_release reverse coverage overclaim to fail", file=sys.stderr)
    sys.exit(1)

good_reverse = {
    "required_feature_coverage": [{
        "feature_id": "FEATURE-003",
        "release_critical": True,
    }],
    "reverse_test_coverage_matrix": [{
        "feature_id": "FEATURE-003",
        "prd_anchor": "prd.section.3",
        "cmp_feature_row_id": "CMP-FEATURE-003",
        "test_point_id": "TP-003",
        "test_case_id": "TC-003",
        "script_id": "SCRIPT-003",
        "pipeline_stage_id": "stage.integration",
        "runtime_boundary_id": "DB-003",
        "execution_evidence_id": "junit://SCRIPT-003",
        "evidence_tier": "production_external_integration",
        "coverage_status": "pass",
        "downstream_gate_effect": "block_release",
    }],
}
good_reverse_result = run_doc(good_reverse, reverse_coverage_validator)
if good_reverse_result.returncode != 0:
    print("Expected production-external reverse coverage row to pass", file=sys.stderr)
    print(good_reverse_result.stdout, file=sys.stderr)
    sys.exit(1)

print("Self-test PASSED.")
