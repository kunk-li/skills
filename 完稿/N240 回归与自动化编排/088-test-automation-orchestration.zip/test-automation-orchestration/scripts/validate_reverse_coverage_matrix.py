#!/usr/bin/env python3
"""Validate reverse feature-to-test-to-runtime coverage for 088 outputs."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


PASS = "pass"
BLOCK_RELEASE = "block_release"
PRODUCTION_TIER = "production_external_integration"
NON_PASS = {"insufficient_evidence", "blocked", "not_cleared", "unknown"}
REQUIRED_PASS_FIELDS = [
    "feature_id",
    "prd_anchor",
    "test_point_id",
    "test_case_id",
    "script_id",
    "pipeline_stage_id",
    "runtime_boundary_id",
    "execution_evidence_id",
]


def as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def nested(doc: dict[str, Any], key: str) -> Any:
    if key in doc:
        return doc[key]
    plan = doc.get("orchestration_plan")
    if isinstance(plan, dict):
        return plan.get(key)
    return None


def feature_id(row: Any) -> str:
    if not isinstance(row, dict):
        return ""
    for key in ("feature_id", "cmp_feature_row_id", "prd_anchor"):
        value = row.get(key)
        if value:
            return str(value)
    return ""


def required_features(doc: dict[str, Any]) -> set[str]:
    result: set[str] = set()
    for key in ("required_feature_coverage", "cmp_feature_rows", "feature_coverage_requirements"):
        for row in as_list(nested(doc, key)):
            if not isinstance(row, dict):
                continue
            release_critical = row.get("release_critical") is True or row.get("required") is True
            if release_critical:
                ident = feature_id(row)
                if ident:
                    result.add(ident)
    return result


def validate(doc: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    rows = as_list(nested(doc, "reverse_test_coverage_matrix"))
    required = required_features(doc)
    if required and not rows:
        errors.append("missing reverse_test_coverage_matrix rows for release-critical features")
        return errors
    seen = {feature_id(row) for row in rows if isinstance(row, dict)}
    for ident in sorted(required - seen):
        errors.append(f"missing reverse coverage row for {ident}")

    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            errors.append(f"row {index} is not an object")
            continue
        status = str(row.get("coverage_status", "unknown"))
        effect = str(row.get("downstream_gate_effect", "advisory"))
        if status != PASS and status not in NON_PASS:
            errors.append(f"row {index} has unsupported coverage_status={status}")
        if effect == BLOCK_RELEASE and status == PASS:
            missing = [field for field in REQUIRED_PASS_FIELDS if not row.get(field)]
            if missing:
                errors.append(f"row {index} block_release pass missing fields: {','.join(missing)}")
            if row.get("evidence_tier") != PRODUCTION_TIER:
                errors.append(f"row {index} block_release pass requires evidence_tier={PRODUCTION_TIER}")
    return errors


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: validate_reverse_coverage_matrix.py output.json", file=sys.stderr)
        return 2
    doc = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    if not isinstance(doc, dict):
        print("input must be a JSON object", file=sys.stderr)
        return 2
    errors = validate(doc)
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("reverse coverage matrix OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
