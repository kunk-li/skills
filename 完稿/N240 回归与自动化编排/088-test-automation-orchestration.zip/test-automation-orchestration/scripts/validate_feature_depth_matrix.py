#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


SAFE_NON_PASS = {"insufficient_evidence", "blocked", "conditional", "insufficient_coverage"}


def load_doc(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize(value: Any) -> str:
    return str(value or "").strip().lower().replace("-", "_").replace(" ", "_")


def as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact")
    args = parser.parse_args()
    doc = load_doc(Path(args.artifact))

    obligations = as_list(doc.get("feature_depth_obligations"))
    filters = as_list(doc.get("read_side_security_filters"))
    matrix = as_list(doc.get("feature_depth_test_matrix"))
    if "feature_depth_test_matrix" in doc and not isinstance(doc.get("feature_depth_test_matrix"), list):
        print("INVALID: feature_depth_test_matrix must be a list")
        return 1

    required_ids: set[str] = set()
    for row in obligations:
        if isinstance(row, dict) and row.get("obligation_id"):
            required_ids.add(str(row["obligation_id"]))
    for row in filters:
        if isinstance(row, dict) and row.get("filter_id"):
            required_ids.add(str(row["filter_id"]))

    matrix_ids = {str(row.get("obligation_id")) for row in matrix if isinstance(row, dict)}
    errors: list[str] = []
    missing = sorted(required_ids - matrix_ids)
    if missing:
        errors.append(f"missing feature-depth test rows for obligations: {missing}")

    for row in matrix:
        if not isinstance(row, dict):
            errors.append("feature-depth matrix row must be object")
            continue
        obligation_id = str(row.get("obligation_id", "<unknown>"))
        gate_decision = normalize(row.get("gate_decision"))
        status = normalize(row.get("status"))
        positive = as_list(row.get("positive_case_refs"))
        negative = as_list(row.get("negative_case_refs"))
        evidence_ref = str(row.get("executed_evidence_ref") or "").strip()
        if gate_decision == "pass":
            if not positive:
                errors.append(f"{obligation_id} pass without positive_case_refs")
            if not negative:
                errors.append(f"{obligation_id} pass without negative_case_refs")
            if not evidence_ref:
                errors.append(f"{obligation_id} pass without executed_evidence_ref")
            if status != "pass":
                errors.append(f"{obligation_id} gate_decision pass but status={status}")
        elif required_ids and gate_decision not in SAFE_NON_PASS and obligation_id in required_ids:
            errors.append(f"{obligation_id} has unsafe gate_decision={gate_decision}")

    if errors:
        print("INVALID")
        for err in errors:
            print(f"- {err}")
        return 1
    print("VALID")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
