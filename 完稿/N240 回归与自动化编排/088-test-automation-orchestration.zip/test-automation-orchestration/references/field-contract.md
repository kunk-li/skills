
# N240 common field contract v2.2.1

This file defines the minimum shared contract used by all N240 regression-and-automation skills. Treat it as the local copy of the N240 artifact contract registry. If a field is renamed or removed, increment the skill body `contract_version` and add migration notes in `downstream_handoff`.

## Common metadata fields

```yaml
metadata:
  skill_id: string
  skill_version: "2.2.1"
  contract_version: "n240.<artifact>.v2.2"
  workflow_node: "N240"
  selected_mode: string
  readiness: enum[pass, constrained, blocked]
  confidence: enum[high, medium, low]
  evidence_profile:
    present: array
    missing: array
    assumptions: array
  produced_events: array
  blocking_behavior: enum[blocking, advisory, informational]
```

## Shared traceability fields

Use these keys consistently across regression, smoke, scripts, triggers, and orchestration:

| Field | Meaning | Required when |
|---|---|---|
| `suite_id` | Stable test suite identifier | Any selected suite or pipeline binding |
| `tc_id` | Test case identifier | Any checklist row based on a test case |
| `tp_id` | Test point identifier | Any generated test point or scenario |
| `script_id` | Generated automation script identifier | API script bundles and orchestration jobs |
| `api_ref` | OpenAPI operation or endpoint reference | API, smoke, or contract tests |
| `risk_ref` | Diff risk, release risk, or defect reference | Any risk-driven inclusion or exclusion |
| `task_ref` | Development task or work item reference | Any task-derived test scope |
| `module_or_flow` | Module, service, resource, or user journey | All suite and stage decisions |
| `evidence` | Source artifact, line, file, or assumption | All non-trivial decisions |

## Execution policy fields

```yaml
execution_policy:
  tier: enum[T0_fast_blocking, T1_pr_blocking, T2_release_blocking, T3_nightly_or_advisory]
  max_duration: duration
  dependencies: array
  cleanup_requirements: array
  isolation_strategy: enum[database_per_job, schema_per_job, transaction_rollback, namespace_prefix, not_applicable]
  retry_policy:
    flaky_retry_count: integer
    infrastructure_retry_count: integer
    real_failure_retry: false
```

## Handoff fields

Every skill must emit `downstream_handoff` with machine-readable keys:

```yaml
downstream_handoff:
  produced_artifact: string
  artifact_contract: string
  consumed_by:
    - target: string
      fields: array
      required: bool
  unresolved_dependencies: array
  gate_notes: array
  migration_notes: array
```


## v2.2.1 feedback and confidence additions

```yaml
contract_version: "n240.orchestration_plan.v2.2"
compatible_with:
  - "n240.orchestration_plan.v2"
consumed_signal_contracts:
  - feedback.n005.production_signal_package.v1
  - feedback.n250.failure_signal.v1
  - feedback.n300.ci_runtime_signal.v1
  - feedback.n300.infrastructure_failure_signal.v1
evidence_profile:
  present: []
  missing: []
  assumptions: []
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied: []
    final_score: integer
feedback_used:
  contracts: []
  signal_ids: []
  influence:
    added_scopes_or_tests: []
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals: []
migration_notes:
  from: "n240.orchestration_plan.v2"
  to: "n240.orchestration_plan.v2.2"
  compatibility: "backward-compatible additive fields"
```
