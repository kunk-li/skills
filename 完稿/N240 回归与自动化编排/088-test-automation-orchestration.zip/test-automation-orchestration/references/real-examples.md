# Orchestration examples

## Example: enterprise pipeline for order module

```yaml
orchestration_plan:
  plan_id: ORCH-ORDER-012
  pipeline_stages:
    - stage_number: 1
      stage_name: lint_and_compile
      stage_purpose: fast failure
      parallel_jobs:
        - job_name: lint
          timeout: 2min
        - job_name: compile
          timeout: 3min
      exit_gate:
        success_criteria: {all_jobs_pass: true}
        on_failure: {action: stop_pipeline, notifications: [email_author]}
    - stage_number: 2
      stage_name: unit_tests
      entry_gate:
        prerequisites:
          - condition: stage_1 passed
            required: true
      parallel_jobs:
        - job_name: unit_order_module
          test_scripts_executed: [REG-ORDER-042.unit]
          timeout: 3min
    - stage_number: 3
      stage_name: smoke_and_contract
      parallel_jobs:
        - job_name: api_smoke
          test_scripts_executed: [SMK-ORDER-CANARY-009]
          timeout: 5min
        - job_name: contract_test
          test_scripts_executed: [ATS-ORDER-001]
          timeout: 3min
  data_isolation:
    strategy: database_per_job
    test_container_strategy: container_per_class
    cleanup_guarantee: {enabled: true, method: automatic_rollback}
  unified_dashboard:
    dashboards:
      realtime_execution: {url: https://ci-dashboard.example/live}
      historical_trends: {retention: 90d}
```


## v2.2 feedback example fragment

```yaml
feedback_used:
  contracts:
    - feedback.n250.defect_signal.v1
  signal_ids:
    - DEFECT-HIST-001
  influence:
    added_scopes_or_tests:
      - "added historical hotspot coverage for payment retry path"
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals:
    - signal_id: OLD-FLAKY-2019
      reason: "stale signal over 90 days and no recent recurrence"
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied:
      - "missing_traceability_id: -15"
    final_score: 85
```
