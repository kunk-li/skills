# Orchestration output template

```yaml
metadata:
  skill_id: test-automation-orchestration
  skill_version: "2.2.1"
  contract_version: n240.orchestration_plan.v2.2
  selected_mode: enterprise_ci
  readiness: pass
  confidence: medium
  produced_events: [produced.n240.orchestration_plan.v2.2]

orchestration_plan:
  plan_id: ORCH-001
  pipeline_stages:
    - stage_number: 1
      stage_name: lint_and_compile
      entry_gate: {prerequisites: []}
      parallel_jobs:
        - job_name: lint
          timeout: 2min
      exit_gate:
        success_criteria: {all_jobs_pass: true, critical_tests_pass: true}
        on_failure: {action: stop_pipeline, notifications: [author]}
  data_isolation:
    strategy: database_per_job
    cleanup_guarantee: {enabled: true, method: automatic_rollback}
  runtime_integration_evidence_matrix:
    - boundary_id: DB-001
      boundary_type: db
      production_surface: primary_repository
      source_manifest_ref: production_boundary_manifest.DB-001
      required_evidence: [real_db_migration_applied, repository_integration_test, transaction_boundary_verified]
      evidence_tier: production_external_integration | self_contained_runtime | reference_only
      evidence_mode: real_db | standalone_smoke | not_available
      evidence_ref: ""
      status: pass | not_cleared | insufficient_evidence
      gate_effect: block_release | local_runtime_only
      gate_decision: pass | insufficient_evidence | blocked | not_cleared | conditional
  feature_depth_test_matrix:
    - obligation_id: FD-001
      obligation_type: source_backed_eligibility
      source_obligation_ref: feature_depth_obligations.FD-001
      positive_case_refs: [TC-FD-001-allow-active]
      negative_case_refs: [TC-FD-001-deny-frozen]
      fixture_or_source_refs: [fixture-authoritative-source-snapshot]
      executed_evidence_ref: junit://TC-FD-001
      status: pass | insufficient_coverage | blocked
      gate_decision: pass | insufficient_evidence | blocked | conditional
  intelligent_retry:
    retry_policy:
      infrastructure_error: {retry: true, max_attempts: 3}
      flaky_test: {retry: true, max_attempts: 2}
      real_failure: {retry: false, action: report_and_stop}
```


## v2.2 output fields

```yaml
feedback_used:
  contracts: []
  signal_ids: []
  influence:
    added_scopes_or_tests: []
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals: []
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied: []
    final_score: integer
```

Rules:
- Preserve every release-critical `production_boundary_manifest[]`, `schema_runtime_boundary_manifest[]`, or adapter boundary row in `runtime_integration_evidence_matrix[]`.
- `self_contained_runtime` may pass only `gate_effect: local_runtime_only`; production release clearance requires `production_external_integration`.
- Preserve every `feature_depth_obligations[]` and `read_side_security_filters[]` row in `feature_depth_test_matrix[]`; each row needs positive and negative/denied coverage before pass.
