# Orchestration output template

```yaml
metadata:
  skill_id: test-automation-orchestration
  skill_version: "2.2.1"
  contract_version: n240.orchestration_plan.v2.2
  selected_mode: enterprise_ci
  readiness: pass
  confidence: medium
  produced_events: [produced.n240.orchestration_plan.v2.2]

orchestration_plan:
  plan_id: ORCH-001
  pipeline_stages:
    - stage_number: 1
      stage_name: lint_and_compile
      entry_gate: {prerequisites: []}
      parallel_jobs:
        - job_name: lint
          timeout: 2min
      exit_gate:
        success_criteria: {all_jobs_pass: true, critical_tests_pass: true}
        on_failure: {action: stop_pipeline, notifications: [author]}
  data_isolation:
    strategy: database_per_job
    cleanup_guarantee: {enabled: true, method: automatic_rollback}
  intelligent_retry:
    retry_policy:
      infrastructure_error: {retry: true, max_attempts: 3}
      flaky_test: {retry: true, max_attempts: 2}
      real_failure: {retry: false, action: report_and_stop}
```


## v2.2 output fields

```yaml
feedback_used:
  contracts: []
  signal_ids: []
  influence:
    added_scopes_or_tests: []
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals: []
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied: []
    final_score: integer
```
