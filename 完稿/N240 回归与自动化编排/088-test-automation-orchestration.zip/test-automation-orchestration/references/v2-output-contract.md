# Orchestration output contract v2.2.1

## Required shape

```yaml
orchestration_plan:
  plan_id: ORCH-001
  pipeline_stages:
    - stage_number: integer
      stage_name: string
      stage_purpose: string
      entry_gate:
        prerequisites:
          - condition: string
            required: bool
      parallel_jobs:
        - job_name: string
          test_scripts_executed: array
          timeout: duration
          resource_requirements: {cpu: string, memory: string, container_image: string}
          environment: {env_vars: object, secrets_needed: array}
      exit_gate:
        success_criteria: {all_jobs_pass: bool, min_pass_rate: percentage, critical_tests_pass: bool}
        on_failure: {action: enum[stop_pipeline, continue_with_warning, retry], notifications: array}
  dependency_management:
    dependency_graph: {stage_dependencies: array}
    critical_path: array
    parallelization_max: {by_stage: integer, overall: integer}
  data_isolation:
    strategy: enum[database_per_job, schema_per_job, transaction_rollback, namespace_prefix]
    test_container_strategy: enum[container_per_test, container_per_class, shared_container]
    cleanup_guarantee: {enabled: true, method: enum[automatic_rollback, explicit_cleanup, tear_down_hook]}
  result_aggregation:
    collection_method: enum[junit_xml, allure, custom]
    final_report: {dashboard_url: string, notification_channels: array, artifacts: array}
  intelligent_retry:
    retry_policy:
      infrastructure_error: {retry: true, max_attempts: 3, backoff: exponential}
      flaky_test: {retry: true, max_attempts: 2, mark_as_flaky_threshold: 3}
      real_failure: {retry: false, action: report_and_stop}
  unified_dashboard:
    dashboards: [realtime_execution, historical_trends, failure_analysis, coverage_dashboard]
```

## Retry classification hints

- `connection_timeout`, transient DNS, runner crash -> infrastructure error.
- test timeout without deterministic assertion -> flaky candidate.
- assertion failure, compilation error, schema mismatch -> real failure.


## v2.2.1 additions

```yaml
contract_version: "n240.orchestration_plan.v2.2"
compatibility:
  backward_compatible_with: "n240.orchestration_plan.v2"
  change_type: additive
feedback_inputs:
  consumed_signal_contracts:
    - feedback.n005.production_signal_package.v1
    - feedback.n250.failure_signal.v1
    - feedback.n300.ci_runtime_signal.v1
    - feedback.n300.infrastructure_failure_signal.v1
  feedback_used_required_when_signals_used: true
confidence_scoring:
  policy_ref: references/confidence-scoring.md
  high_min_score: 85
  medium_min_score: 60
  low_below: 60
node_routing:
  policy_ref: references/node-routing-contract.md
```
