
# Quality checklist v2.1

Before finalizing output, verify:

- Metadata includes `skill_version`, `contract_version`, `selected_mode`, `readiness`, `confidence`, and `produced_events`.
- All IDs are stable and reusable by downstream skills.
- Required v2 enums are used exactly as defined in `v2-output-contract.md`.
- All hard rules from `v2-rules.md` are evaluated in `self_check`.
- `downstream_handoff` maps fields to explicit consumers.
- Missing evidence is represented as `constrained` or `blocked`, not silently ignored.
- Runtime boundary manifests from 061/066/adapter design are preserved as `runtime_integration_evidence_matrix[]`.
- Release-critical matrix rows without `production_external_integration` evidence are not marked pass.
- Feature-depth obligations from 060 and read-side security filters from 061 are preserved as `feature_depth_test_matrix[]` with positive and negative/denied cases.
- Events, SLA tags, and escalation hints are present when relevant.

## Skill-specific checks

- Every stage has entry and exit gates.
- Isolation uses v2 enum, not L1/L2/L3.
- Retry is classified into infrastructure, flaky, and real failure.
- Result aggregation and dashboard outputs are explicit.
