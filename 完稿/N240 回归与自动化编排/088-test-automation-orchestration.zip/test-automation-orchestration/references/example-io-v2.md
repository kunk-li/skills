# N240 示例输入输出 v2（扩展场景）

## 示例 3：触发策略推荐（test-automation-trigger-recommendation）

### 输入
- 60个测试（40单元，12集成，8 e2e）；CI预算15分钟

### 输出
```yaml
trigger_recommendation:
  on_pull_request:
    - group: unit_tests
      count: 40
      estimated_time: 3min
    - group: integration_payment
      count: 6
      estimated_time: 8min
  ci_total_budget_used: 11min / 15min
```

## 示例 4：CI流水线编排（test-automation-orchestration）

### 输入
- 38个自动化测试，GitHub Actions，回归计划已就绪

### 输出
```yaml
# .github/workflows/test-pipeline.yml（骨架）
jobs:
  lint:
    runs-on: ubuntu-latest
  unit:
    needs: lint
    timeout-minutes: 5
  integration:
    needs: unit
    timeout-minutes: 10
  notify-on-failure:
    if: failure()
    needs: [unit, integration]
```

## 088 扩展示例输入输出

### Scenario B — GitLab CI: fail-fast with cache

**Input**: 80 tests, GitLab CI, 20-min budget, Python/pytest stack.

**Output** (`gitlab_ci` mode):
```yaml
# .gitlab-ci.yml
stages: [lint, unit, integration, e2e, notify]

default:
  cache:
    paths: [.venv/]

lint:
  stage: lint
  script: [pip install -r requirements.txt, flake8 src/]

unit:
  stage: unit
  needs: [lint]
  script: [pytest tests/unit/ -x --timeout=30]
  timeout: 5 minutes

integration:
  stage: integration
  needs: [unit]
  services: [postgres:15]
  script: [pytest tests/integration/ --timeout=60]
  timeout: 12 minutes

e2e:
  stage: e2e
  needs: [integration]
  script: [pytest tests/e2e/ -k "smoke"]
  only: [main, /^release\/.*/]
  timeout: 8 minutes

notify_failure:
  stage: notify
  script: [./scripts/notify_slack.sh]
  when: on_failure
```

### Scenario C — Parallel design: wall-clock optimisation

**Input**: 150 integration tests currently running serially (45 min); target 15 min wall-clock.

**Output** (`parallel_design` mode):
```yaml
parallel_groups:
  - group: auth_and_user
    tests: [TC-001..TC-038]
    estimated_time: 12min
    runner: ubuntu-latest
  - group: payment_and_orders
    tests: [TC-039..TC-092]
    estimated_time: 14min
    runner: ubuntu-latest
  - group: notifications_and_reporting
    tests: [TC-093..TC-150]
    estimated_time: 13min
    runner: ubuntu-latest
wall_clock_estimate: 14min  # max of parallel groups
speedup_factor: 3.2x
downstream_handoff:
  to: 093-quality-gate-check
  artifact: pipeline_execution_summary
```


### Scenario D — Jenkins declarative pipeline with parallel stages

**Input**: 150 tests (70 unit, 50 integration, 30 e2e); Jenkins; 25-min budget; parallel design requested.

**Output** (`jenkins` + `parallel_design` mode):
```groovy
// Jenkinsfile
pipeline {
    agent any
    options { timeout(time: 30, unit: 'MINUTES') }

    stages {
        stage('Lint') {
            steps { sh 'npm run lint' }
        }
        stage('Unit') {
            steps { sh 'npm test -- --testPathPattern=unit' }
            post { failure { error 'Unit tests failed — aborting pipeline' } }
        }
        stage('Parallel Integration') {
            parallel {
                stage('Integration: auth') {
                    steps { sh 'npm test -- --testPathPattern=integration/auth' }
                }
                stage('Integration: payment') {
                    steps { sh 'npm test -- --testPathPattern=integration/payment' }
                }
            }
        }
        stage('E2E') {
            when { branch 'main' }
            steps { sh 'npx playwright test' }
            post { always { publishHTML([reportDir: 'playwright-report']) } }
        }
    }
    post {
        failure {
            slackSend(color: 'danger',
                message: "Pipeline FAILED: \${env.JOB_NAME} #\${env.BUILD_NUMBER}")
            sh './scripts/rollback.sh \${env.GIT_COMMIT}'
        }
    }
}
```
**Parallel wall-clock estimate**: lint(1min) + unit(5min) + parallel-integration(8min) + e2e(12min) = **26min** — within 30min budget.

### Scenario D — Flaky test quarantine workflow

**Input**: 3 tests have >30% flakiness rate in last 30 runs; blocking CI.

**Output** (`quarantine_mode`):
```yaml
orchestration_result:
  mode: quarantine
  flaky_tests_identified:
    - test_id: TC-PAY-088
      flakiness_rate: 0.42
      failure_pattern: timing_sensitive
      action: quarantine_and_label
    - test_id: TC-INT-033
      flakiness_rate: 0.35
      failure_pattern: external_dependency
      action: quarantine_and_label
  quarantine_actions:
    - Remove from blocking gate (move to non-blocking suite)
    - Add @Flaky annotation with ticket ref
    - Schedule fix sprint within 2 iterations
  pipeline_adjusted:
    blocking_gate: excludes quarantined tests
    monitoring_suite: includes quarantined tests (results logged, not blocking)
  readiness: ready
  circuit_breaker: open_if_quarantine_gt_5pct_of_suite
```
