# Orchestration rules v2.2.1

| Rule | Requirement | on_violation |
|---|---|---|
| R01_stages_have_gates | Every stage must have entry and exit gates. | reject |
| R02_data_isolation_guaranteed | Data isolation strategy must be declared. | reject |
| R03_cleanup_always | Cleanup must run even after failure. | reject |
| R04_retry_classified | Retry must distinguish infrastructure, flaky, and real failures. | reject |
| R05_critical_path_identified | Critical path stages must be named. | reject |
| R06_notifications_not_noise | Success notifications should avoid noise; failure notifications need actionable context. | reject |
| R07_dashboard_unified | Result aggregation must feed one unified dashboard or report. | reject |
| R08_ephemeral_for_pr | Prefer ephemeral PR environments when feasible. | warn |


## v2.2.1 reactive addendum rules

| Rule | Requirement | on_violation |
|---|---|---|
| R09_feedback_contracts_defined | Every value in `consumed_signal_contracts` and `feedback_used.contracts` must be defined in `references/feedback-input-contract.md`. | reject |
| R10_feedback_used_traceable | When feedback signals influence scope, scripts, triggers, stages, retries, gates, or confidence, output `feedback_used.contracts`, `feedback_used.signal_ids`, and `feedback_used.influence`. | reject |
| R11_confidence_score_calculated | Apply `references/confidence-scoring.md`, include final score and penalties, and map score to `confidence`. | reject |
| R12_stale_or_conflicting_feedback_handled | Stale, conflicting, or low-confidence feedback must be recorded in `ignored_signals` or `evidence_profile.stale_or_conflicting_feedback` before it can affect decisions. | reject |
