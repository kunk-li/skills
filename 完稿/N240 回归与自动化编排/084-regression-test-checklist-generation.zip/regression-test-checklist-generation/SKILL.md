---
name: regression-test-checklist-generation
description: generate impact-based regression test checklists and regression plans from change impact, test cases, bug history, critical journeys, release type, api contracts, and diff risk evidence. use for pull requests, releases, hotfixes, or n240 workflows that need regression scope, suite tiering, automation layering, execution strategy, and gate handoff before trigger selection or orchestration.
---
# regression-test-checklist-generation

## Purpose and boundary

Deliver the N240 artifact `回归测试清单.csv` as an independently usable, workflow-aligned skill. Keep this skill generic enough for a single pull request, hotfix, release, module, endpoint group, or CI modernization task, while making its output stronger when composed with the other N240 skills.

Own: Generate impact-based regression scope, suite tiers, automation layers, and gate-ready regression handoff.

Do not claim runtime results unless execution evidence is supplied. Do not regenerate upstream artifacts when they are already provided; consume and reference them through stable IDs.

## Version and artifact contract

```yaml
skill_version: "2.2.1"
contract_version: "n240.regression_plan.v2.2"
artifact_target: "回归测试清单.csv"
workflow_node: "N240"
compatible_with:
  - n240.regression_plan.v2
consumed_signal_contracts:
  - feedback.n005.production_signal_package.v1
  - feedback.n250.defect_signal.v1
  - feedback.n300.monitoring_signal.v1
  - feedback.n320.postmortem_signal.v1
produced_events:
  - produced.n240.regression_plan.v2.2
  - state.n240.regression.readiness
  - exception.n240.regression.contract_violation
downstream_consumers:
  - 087 trigger strategy
  - 088 orchestration
  - N260 quality gate
  - N270 release readiness
```

Keep frontmatter limited to `name` and `description`; versioning lives in the body and output metadata so packaging validators remain compatible.

## Mode selection

Every result must start with `metadata.selected_mode`, `metadata.readiness`, `metadata.confidence`, and `metadata.evidence_profile`.

Allowed modes:
- `quick_impact_scan`: derive the smallest safe regression set from one diff or module change.
- `full_suite`: build a tiered regression plan for merge or release decisions.
- `flaky_cleanup`: focus on unstable tests, quarantine logic, and hotspot-driven additions.
- `release_gate_mode`: optimize evidence for N260 quality gate and N270 release readiness.

## Inputs

Required or strongly preferred inputs:
- `change_impact_analysis`
- `test_cases`
- `critical_user_journeys`
- `release_type`

Optional enhancement inputs:
- bug_history
- recent production defects
- flaky metrics
- api contract deltas
- release risk notes

Standalone behavior:
- If only one diff, module, endpoint group, or release slice is available, still produce the same output shape.
- If a required input is missing, mark `readiness: constrained` or `blocked`, list missing evidence, and avoid overclaiming certainty.
- If upstream N240 artifacts are present, preserve their `suite_id`, `tc_id`, `script_id`, `api_ref`, `risk_ref`, and `task_ref` values.

## Required output sections

Default to YAML-friendly Markdown. The result must include:
- `metadata`
- `regression_plan`
- `regression_scope.selected_scopes[]`
- `tc_selection_strategy`
- `bug_history_enrichment`
- `automation_layers`
- `execution_strategy`
- `results_analysis`
- `downstream_handoff`
- `self_check`

Metadata must include:
```yaml
metadata:
  skill_id: regression-test-checklist-generation
  skill_version: "2.2.1"
  contract_version: "n240.regression_plan.v2.2"
  selected_mode: string
  readiness: enum[pass, constrained, blocked]
  confidence: enum[high, medium, low]
  function_bias: scope_and_confidence_planning
  stage_position: testing_and_qa.regression_and_automation.regression_test_checklist_generation
  workflow_node: N240
  node_artifact_target: "回归测试清单.csv"
  evidence_profile: {present: [], missing: [], assumptions: [], stale_or_conflicting_feedback: [], scoring: {base: 100, penalties_applied: [], final_score: 100}}
  consumed_signal_contracts: []
  confidence_scoring_policy: references/confidence-scoring.md
  feedback_used: {contracts: [], signal_ids: [], influence: {}, ignored_signals: []}
  produced_events: [produced.n240.regression_plan.v2.2, state.n240.regression.readiness, exception.n240.regression.contract_violation]
```

## Hard gates and v2 rules

Load and apply `references/v2-rules.md` before finalizing. For any rule with `on_violation: reject`, set `readiness: blocked` unless the user explicitly asks for a draft or advisory-only artifact. Put all rule outcomes in `self_check.passed_rules`, `self_check.failed_rules`, and `self_check.warnings`.

## Execution workflow

1. If multiple N240 skills could apply, consult `references/node-routing-contract.md`; otherwise run this skill standalone.
2. Select the mode from the available evidence and user intent.
3. Normalize inputs into the common field contract in `references/field-contract.md`.
4. Load `references/feedback-input-contract.md` before using historical defects, production signals, CI runtime data, flaky metrics, or postmortems.
5. Apply the detailed schema and enums from `references/v2-output-contract.md`.
6. Produce the artifact using `references/output-template.md` and the richer examples in `references/real-examples.md`.
7. Emit `downstream_handoff` using the field-level map in `references/cross-skill-orchestration.md`.
8. Apply readiness inheritance from `references/readiness-inheritance.md`, confidence scoring from `references/confidence-scoring.md`, and finish with `self_check`.

## Event, SLA, and circuit hooks

Emit the produced/state/exception events listed above in metadata. When a rule blocks release, add an `sla_queue_hint` with priority `P0`, `P1`, or `P2`, a recommended human action, and escalation target if known. When retry or loop behavior is discussed, cap it explicitly with `max_iter`, `cooldown`, and escalation guidance instead of leaving an unbounded loop. When feedback contracts are consumed, fill `feedback_used`, record stale/conflicting signals, and avoid letting low-confidence historical signals override current release evidence.

## Reference files

- `references/node-routing-contract.md`
- `references/feedback-input-contract.md`
- `references/confidence-scoring.md`
- `references/v2-output-contract.md`
- `references/v2-rules.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
