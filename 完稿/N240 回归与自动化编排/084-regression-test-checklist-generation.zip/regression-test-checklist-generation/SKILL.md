---
name: regression-test-checklist-generation
description: Build impact-based regression checklists and plans from change impact, bug history, and diff risk; scope, tier, and layer what to re-test after a change.
---
# regression-test-checklist-generation

## Role and boundary

Deliver the N240 artifact `回归测试清单.csv` as an independently usable, workflow-aligned skill. Keep this skill generic enough for a single pull request, hotfix, release, module, endpoint group, or CI modernization task, while making its output stronger when composed with the other N240 skills.

Own: Generate impact-based regression scope, suite tiers, automation layers, and gate-ready regression handoff.

Do not claim runtime results unless execution evidence is supplied. Do not regenerate upstream artifacts when they are already provided; consume and reference them through stable IDs.

This skill aligns to testing & qa → regression and automation planning → 回归测试清单.csv. It delivers the workflow-aligned regression scope and tier artifact for N240.

### Boundary
- Focus on planning artifacts, not runtime execution results.
- Consume upstream N230 and N240 artifacts by reference; do not regenerate them.
- Do not fabricate test results unless execution evidence is supplied.


## Routing decision table

| Situation | Action |
|---|---|
| Hotfix release | Use `quick_impact_scan`; scope = directly modified + first-order downstream only |
| Full release with change-impact data | Use `full_suite`; include bug history enrichment |
| Flaky tests present in prior runs | Use `flaky_cleanup`; quarantine or remove flaky tests before scope finalisation |
| No tc_ids available | Produce module-level scope; set `pending_tc_mapping: true` |
| Release gate context | Set `release_gate_mode: true`; emit evidence fields for N260 |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n240.regression-test-checklist.v2.2"
contract_version: "n240.regression_plan.v2.2"
artifact_target: "回归测试清单.csv"
workflow_node: "N240"
node_artifact_target: "n240.regression_plan"
function_bias: "planning"
compatible_with:
  - n240.regression_plan.v2
consumed_signal_contracts:
  - feedback.n005.production_signal_package.v1
  - feedback.n250.defect_signal.v1
  - feedback.n300.monitoring_signal.v1
  - feedback.n320.postmortem_signal.v1
produced_events:
  - produced.n240.regression_plan.v2.2
  - state.n240.regression.readiness
  - exception.n240.regression.contract_violation
downstream_consumers:
  - 087 trigger strategy
  - 088 orchestration
  - N260 quality gate
  - N270 release readiness
```

Keep frontmatter limited to `name` and `description`; versioning lives in the body and output metadata so packaging validators remain compatible.

## Mode selection

Every result must start with `metadata.selected_mode`, `metadata.readiness`, `metadata.confidence`, and `metadata.evidence_profile`.

Allowed modes:
- `quick_impact_scan`: derive the smallest safe regression set from one diff or module change.
- `full_suite`: build a tiered regression plan for merge or release decisions.
- `flaky_cleanup`: focus on unstable tests, quarantine logic, and hotspot-driven additions.
- `release_gate_mode`: optimize evidence for N260 quality gate and N270 release readiness.

## Inputs

Required or strongly preferred inputs:
- `change_impact_analysis`
- `test_cases`
- `critical_user_journeys`
- `release_type`

Optional enhancement inputs:
- bug_history
- recent production defects
- flaky metrics
- api contract deltas
- release risk notes

Standalone behavior:
- If only one diff, module, endpoint group, or release slice is available, still produce the same output shape.
- If a required input is missing, mark `readiness: constrained` or `blocked`, list missing evidence, and avoid overclaiming certainty.
- If upstream N240 artifacts are present, preserve their `suite_id`, `tc_id`, `script_id`, `api_ref`, `risk_ref`, and `task_ref` values.


### Degradation rules

- If only a diff or a module name is available without full change-impact analysis, produce a minimal regression seed marked `readiness: constrained` and flag `pending_impact_confirmation`.
- If test cases are absent, emit placeholder scope items marked `pending_tc_mapping` rather than fabricating coverage claims.
- Keep the output schema stable even with minimal inputs; prefer explicit `pending_*` fields over silent omissions.


## Core output contract

Default to YAML-friendly Markdown and follow `references/output-template.md`.

The result must include:
- metadata (selected_mode, readiness, confidence, evidence_profile)
- regression_plan
- regression_scope.selected_scopes[]
- tc_selection_strategy
- bug_history_enrichment
- new_tests_required (R13: touched behaviors with no existing tc to select — regression coverage is not only re-running existing tests)
- automation_layers
- downstream_handoff
- self_check
- `readiness: ready | constrained | blocked`

## Hard gates and v2 rules

Load and apply `references/v2-rules.md` before finalizing. For any rule with `on_violation: reject`, set `readiness: blocked` unless the user explicitly asks for a draft or advisory-only artifact. Put all rule outcomes in `self_check.passed_rules`, `self_check.failed_rules`, and `self_check.warnings`.

## Execution workflow

1. If multiple N240 skills could apply, consult `references/node-routing-contract.md`; otherwise run this skill standalone.
2. Select the mode from the available evidence and user intent.
3. Normalize inputs into the common field contract in `references/field-contract.md`.
4. Load `references/feedback-input-contract.md` before using historical defects, production signals, CI runtime data, flaky metrics, or postmortems.
5. Apply the detailed schema and enums from `references/v2-output-contract.md`.
6. Produce the artifact using `references/output-template.md` and the richer examples in `references/real-examples.md`.
7. Emit `downstream_handoff` using the field-level map in `references/cross-skill-orchestration.md`.
8. Apply readiness inheritance from `references/readiness-inheritance.md`, confidence scoring from `references/confidence-scoring.md`, and finish with `self_check`.

## Event, SLA, and circuit hooks

See `references/n240-event-sla-hooks.md` for event emission, SLA queue hints, circuit hook patterns, and feedback contract handling.

## Example usage

### Scenario A — Full suite (PR merge: checkout refactor)

**Input**: PR merging a checkout refactor; high-risk diff review (DIFR-001 DB migration, DIFR-002 payment retry).

**Output** (`full_suite` mode, excerpt):
```yaml
regression_plan:
  mode: full_suite
  readiness: ready
  regression_scope:
    - module: checkout_flow
      reason: directly modified
      priority: P0
    - module: payment_gateway_integration
      reason: DIFR-002 retry logic change
      priority: P0
    - module: order_history
      reason: downstream of checkout
      priority: P1
  tc_selection_strategy:
    total_selected: 47
    automation_tier: 38
    manual_tier: 9
  automation_layers:
    - layer: unit
      count: 22
      trigger: on_push
    - layer: integration
      count: 16
      trigger: on_pr
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Usage scenarios

- quick_impact_scan: fast regression scoping for a single diff or hotfix.
- full_suite: tiered regression plan for merge or release decisions.
- flaky_cleanup: focus on unstable tests and quarantine logic.
- release_gate_mode: evidence-ready artifact for N260 quality gate.


## Cross-skill integration map

| 上游 skill | 提供给 084 | 用途 |
|---|---|---|
| 080–083 N230 | `test_point_list[]` | 回归清单的候选测试点来源 |
| 077 diff-risk-review | `changed_modules[]` | 变更模块决定回归范围 |

| 下游 skill | 084 输出 | 如何使用 |
|---|---|---|
| 085 smoke-test-checklist-generation | `regression_scope[]` | 烟雾清单区分冒烟 vs 回归 |
| 087 test-automation-trigger-recommendation | `regression_checklist[]` | 触发策略基于回归清单规模 |
| 088 test-automation-orchestration | `regression_checklist[]` | 编排器消费清单执行 |
| 093 quality-gate-check | `regression_results` | 质量门禁的回归通过率维度 |

**工作流位置**: 变更分析 → **084 回归清单** → 085 冒烟/087 触发/088 编排 → 093 门禁。

## Standalone usage guide

**Minimum input:** a PR diff, module name, or change description — no upstream N230 artifacts required.

**Standalone decision path:**
1. If only diff available → `quick_impact_scan` mode; scope = directly modified + first-order downstream.
2. If historical defect data unavailable → omit `bug_history_enrichment`; set `pending_bug_history`.
3. If no tc_ids available → produce scope items by module name; mark `pending_tc_mapping`.

**Minimum viable standalone output:**
```yaml
regression_plan:
  mode: quick_impact_scan
  readiness: constrained
  pending_tc_mapping: true
  regression_scope:
    - module: auth_service
      reason: directly modified (diff confirms)
      priority: P0
    - module: user_profile
      reason: reads from auth_service
      priority: P1
  tc_selection_strategy:
    total_selected: 0
    note: tc_ids unavailable; scope is module-level only
  self_check:
    no_fabricated_results: true
    scope_grounded_in: diff_content
```

**Cross-skill chain:** 080 test-points → 081 test-cases → **084 regression-plan** → 087 trigger-strategy → 088 pipeline.

## Resilience and governance

**Circuit breaker**: If regression scope selection misses a high-impact module on 3 consecutive releases, emit circuit_breaker: warn and require manual scope review.

**SLA guidance**: P0 when a blocking defect is not included in regression scope; P1 when automation tier count drops below target.

**Human review routing**: Set human_review_required: true when release_type is hotfix or when confidence on change-impact analysis is below 0.7.

**Confidence scoring**: When confidence on scope selection or tier assignment falls below 0.7, mark `readiness: constrained` and require human confirmation before the artifact is consumed downstream.

**Escalation path**: When `readiness: blocked`, escalate to the QA lead and CI owner. For release-gate mode, also notify the release manager.

Traceability: each regression item must reference its source tc_id, suite_id, or risk_ref to enable N260 gate consumption.

## Auditable rules summary

- R01_impact_required: regression scope must be grounded in change-impact evidence; on_violation: flag_gap.
- R02_tier_separation: regression items must be separated into automation / manual / exploratory tiers; on_violation: reject.
- R03_no_runtime_claim: do not claim pass/fail results unless execution evidence is provided; on_violation: downgrade_to_planned.
- R04_bug_history_gated: historical defect enrichment requires evidence; do not fabricate bug density; on_violation: omit.
- R05_upstream_ids_preserved: preserve `suite_id`, `tc_id`, `script_id` from upstream N240 artifacts; on_violation: warn.
- R06_flaky_quarantine_explicit: flaky tests identified in prior runs must be explicitly quarantined or flagged; on_violation: flag_gap.
- R07_hotfix_scope_constrained: quick_impact_scan mode must limit scope to directly modified and first-order downstream modules only; on_violation: reject_overscope.
- R13_touched_undercovered_new_test: coverage of a change-touched behavior is judged at branch/negative-path granularity by test intent (a positive-path tc does NOT cover the symbol's guard/negative branches). A touched guard branch with no driving tc must produce a `new_tests_required[]` entry (`uncovered_branch`) and set `readiness: constrained`. Fires only on `touched ∩ under-covered`, enumerating only guard branches; matches semantically (never by method-name prefix); honors `evidence_profile.test_pool_scope` (cross-module coverage → warn, not a hard false fire). Three-tier degrade: branch → reject; symbol-only → warn+`coverage_gap{partial}`; module-only → warn. When service + test source are available, compute the branch-coverage judgment **deterministically** via the assertion-intent engine (enumerate guard branches incl. recursively through guard helpers; a branch is covered iff a test asserts its exception while its lambda invokes the method — by content, never by name), rather than reasoning it by hand; it is more precise than naïve line coverage for shared guards and has been validated against runtime ground truth. on_violation: reject (branch granularity) / warn (else). See `references/v2-rules.md` v2.2.2 addendum (incl. the deterministic engine spec).
- R14_stub_subject_zero_executable_coverage: the R13 branch-coverage engine requires runnable service source. When the被测 service is a STUB / draft (method bodies throw UnsupportedOperationException or are pseudo-code, `impl_status != implemented`), the engine has NO branches to enumerate — this is NOT 'coverage satisfied' and MUST NOT degrade silently to pass. Emit `executable_coverage: 0% · subject_is_stub · engine_cannot_run`, set `readiness: blocked`, and state that regression coverage is undefined until the implementation exists (implement mode of 060). A regression checklist that reports green/covered over stub subjects掩盖s the un-testable core (the指标-mismatch that let a 0/41-runnable module pass). on_violation: reject.

## Algorithm

1. Parse change impact, release type, and available test case evidence.
2. Select mode based on input richness and release context.
3. Build regression scope: identify affected modules, critical journeys, and API contracts.
4. Tier test cases into automation / manual / exploratory (R02).
5. Enrich with bug history and flaky metrics when evidence exists (R04).
6. Preserve upstream ids from N230 and N240 inputs (R05).
7. Cross-check `change_impact_analysis.touched[]` against the existing `test_cases` pool; for any touched behavior with no covering tc, emit `new_tests_required[]` and set `readiness: constrained` (R13).
8. Emit `regression_plan`, `tc_selection_strategy`, `new_tests_required`, `automation_layers`.
9. Run `self_check`; set `readiness: blocked` if R01 or R02 fires, `constrained` if R13 fires.

## Quality bar

A good result gives the team clear scope for regression, separates automated from manual tiers, and ties every selected test back to a change-impact or bug-history rationale. The artifact must be directly actionable by trigger-selection (087) and orchestration (088).

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files

- `references/node-routing-contract.md`
- `references/feedback-input-contract.md`
- `references/confidence-scoring.md`
- `references/v2-output-contract.md`
- `references/v2-rules.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/template-skeleton.md`

- `references/example-io.md`
- `references/example-io-v2.md`