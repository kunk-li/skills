
# N240 cross-skill orchestration contract v2.2.1

Use this mapping when multiple N240 skills are composed. The intended order is:

```text
084 regression + 085 smoke + 086 api scripts -> 087 trigger strategy -> 088 orchestration -> N250/N260/N270/N300
```

## Field-level handoff map

| Producer | Output fields | Consumer | Consumer fields |
|---|---|---|---|
| 084 regression | `regression_plan.plan_id`, `selected_suites[].suite_id`, `selected_suites[].tc_id`, `regression_scope.selected_scopes[]`, `automation_layers`, `execution_strategy`, `results_analysis.success_criteria` | 087 trigger | `trigger_strategy.candidate_suites[]`, `layered_strategy.tier_2_pr_loop.tests`, `coverage_gates` |
| 084 regression | `execution_strategy.execution_order`, `timeout_strategy`, `retry_policy` | 088 orchestration | `pipeline_stages[].parallel_jobs[]`, `stage_graph`, `intelligent_retry` |
| 085 smoke | `smoke_checklist.checklist_id`, `smoke_scope.scopes`, `minimal_critical_path.core_journey`, `five_minute_principle`, `failure_response` | 087 trigger | `triggers.T4_on_pr_creation`, `triggers.T6_pre_release`, post-deploy trigger rows |
| 085 smoke | `health_probes`, `environment_variations`, `failure_response` | 088 orchestration | first-stage smoke job, post-deploy verification job, rollback hook |
| 086 api scripts | `test_scripts[].script_id`, `framework`, `script_bundle_manifest[].path`, `environment_contract`, `fixture_management`, `auth_handling` | 087 trigger | duration and cost assumptions, suite eligibility, framework-specific placement |
| 086 api scripts | `script_bundle_manifest[].path`, `dependencies`, `imports`, `ci_integration.reporting` | 088 orchestration | `suite_registry_bindings[]`, job image/runtime/cache keys/report collection |
| 087 trigger | `trigger_strategy.strategy_id`, `triggers`, `layered_strategy`, `time_cost_analysis`, `feedback_speed_targets`, `failure_handling` | 088 orchestration | pipeline schedules, blocking gates, retry policy, notification strategy |
| 088 orchestration | `orchestration_plan.plan_id`, `pipeline_stages`, `result_aggregation`, `intelligent_retry` | N250/N260/N270/N300 | failure triage, quality gate inputs, release readiness, CI monitoring baselines |

## Composition rules

1. Never let 088 regenerate regression/smoke/script scope when 084/085/086 artifacts exist; it must consume and bind them.
2. 087 decides when and under what blocking behavior to run suites; 088 decides how to execute them.
3. All suite and job references must preserve `suite_id`, `tc_id`, `script_id`, `api_ref`, and `risk_ref` when available.
4. If a producer artifact is missing, the consumer may continue in `constrained` readiness only when it records the missing artifact in `downstream_handoff.unresolved_dependencies`.
5. Emit produced events using the artifact contract names so N330/N340/N350/N390 can subscribe without waiting for the whole DAG.


## v2.2.1 node-level routing

For skill selection, load `node-routing-contract.md`. It defines the N240 5-skill decision table and the composite chains for minimal hotfix, PR gate, release gate, CI cost optimization, and API automation modernization.

## v2.2.1 feedback handoff

Any producer that used feedback signals must pass `feedback_used.contracts`, `feedback_used.signal_ids`, and `evidence_profile.stale_or_conflicting_feedback` downstream. Consumers must preserve these fields and may downgrade confidence if upstream feedback was stale, conflicting, or low confidence.
