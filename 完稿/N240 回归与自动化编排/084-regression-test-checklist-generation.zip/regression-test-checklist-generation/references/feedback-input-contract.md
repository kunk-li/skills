# Feedback Input Contract v2.2.1

Use this file whenever historical defects, production signals, CI runtime data, flaky metrics, postmortems, monitoring, or N005 feedback-loop artifacts are used. These signals enrich decisions but must not override hard evidence from current specs, test cases, and release artifacts.

## Accepted upstream signal contracts

```yaml
feedback_contracts:
  feedback.n005.production_signal_package.v1:
    source_node: N005
    fields:
      - signal_id
      - source_type: enum[monitoring, postmortem, defect, nps, customer_feedback, ci_history]
      - module_or_flow
      - severity: enum[P0, P1, P2, P3]
      - frequency_30d
      - recency_days
      - confidence: enum[high, medium, low]
      - linked_artifacts: []

  feedback.n250.defect_signal.v1:
    source_node: N250
    fields:
      - defect_id
      - affected_module
      - defect_kind: enum[regression_real_bug, test_flakiness, environmental_issue, known_failure]
      - severity
      - reproduction_status
      - linked_tc_ids: []
      - linked_suite_ids: []

  feedback.n300.monitoring_signal.v1:
    source_node: N300
    fields:
      - metric_or_alert_id
      - service
      - endpoint_or_job
      - anomaly_pattern
      - impact_scope
      - first_seen
      - last_seen
      - related_logs_or_traces: []

  feedback.n300.ci_runtime_signal.v1:
    source_node: N300
    fields:
      - pipeline_id
      - suite_id
      - avg_duration
      - p95_duration
      - flakiness_rate
      - cost_per_run
      - failure_kind_breakdown

  feedback.n320.postmortem_signal.v1:
    source_node: N320
    fields:
      - incident_id
      - root_cause_area
      - missed_test_gap
      - permanent_regression_required: bool
      - recommended_tc_or_suite_ids: []
```

## Skill-specific usage map

| Skill | Feedback to consume | How to use it | Guardrail |
|---|---|---|---|
| 084 regression | N005, N250, N300, N320 | add hotspot, missed scenario, fragile module, release scope adjustments | Never exclude P0 current tests due to old pass history |
| 085 smoke | N005, N300, N280/N290 deploy signals | tune health probes, canary smoke, post-deploy sanity checks | Production probes must remain read-only |
| 086 api-test | N250, N300 API errors, N150 contract changes | add negative cases, contract tests, auth/validation cases | Do not invent endpoints absent from OpenAPI |
| 087 trigger | CI runtime, flaky metrics, defect recurrence | tune trigger placement, cost budget, nightly vs PR split | Do not hide real failures as flaky |
| 088 orchestration | CI runtime, infra failures, flaky classification | tune retry, isolation, resource sizing, dashboards | Cap retries; never loop indefinitely |

## Output requirements when feedback is used

```yaml
feedback_used:
  contracts: []
  signal_ids: []
  influence:
    added_scopes_or_tests: []
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals:
    - signal_id: string
      reason: string
```

If feedback signals conflict with current release evidence, prefer current release evidence and record the conflict in `evidence_profile.assumptions`.


## v2.2.1 extended upstream signal contracts

The following contracts are valid additions to the v2.2 feedback registry. They are included here so every value listed in `consumed_signal_contracts` has a field definition and can be validated before use.

```yaml
feedback_contracts:
  feedback.n150.api_contract_signal.v1:
    source_node: N150
    fields:
      - contract_signal_id
      - openapi_spec_ref
      - api_ref
      - contract_version
      - changed_operations: []
      - breaking_changes: []
      - deprecated_endpoints: []
      - error_codes_changed: []
      - generated_at

  feedback.n250.failure_signal.v1:
    source_node: N250
    fields:
      - failure_id
      - suite_id
      - failed_stage
      - failure_kind: enum[regression_real_bug, test_flakiness, environmental_issue, known_failure]
      - severity: enum[P0, P1, P2, P3]
      - defect_ref
      - regression_detected: bool
      - recommended_action

  feedback.n280.deployment_signal.v1:
    source_node: N280
    fields:
      - deployment_id
      - release_id
      - environment: enum[dev, test, staging, prod]
      - deployment_strategy: enum[blue_green, canary, rolling, manual]
      - deployed_version
      - deployment_status: enum[success, failed, rolled_back, partial]
      - smoke_status: enum[pass, constrained, blocked, not_run]
      - rollback_status: enum[not_needed, available, executed, failed]
      - timestamp

  feedback.n290.acceptance_signal.v1:
    source_node: N290
    fields:
      - acceptance_id
      - release_id
      - acceptance_status: enum[accepted, rejected, conditional, pending]
      - failed_criteria: []
      - approver
      - acceptance_notes
      - timestamp

  feedback.n300.api_error_signal.v1:
    source_node: N300
    fields:
      - api_error_signal_id
      - api_ref
      - endpoint
      - method
      - status_code
      - error_code
      - error_rate
      - sample_trace_ids: []
      - first_seen
      - last_seen

  feedback.n300.flaky_test_signal.v1:
    source_node: N300
    fields:
      - flaky_signal_id
      - suite_id
      - test_id
      - flakiness_rate
      - recent_failures
      - infrastructure_correlation
      - quarantine_status: enum[none, candidate, quarantined, resolved]
      - sample_pipeline_ids: []

  feedback.n300.infrastructure_failure_signal.v1:
    source_node: N300
    fields:
      - infrastructure_failure_id
      - ci_platform
      - runner_pool
      - error_pattern
      - affected_jobs: []
      - retry_success_rate
      - duration_impact
      - first_seen
      - last_seen
```

## v2.2.1 validation rules for feedback contracts

1. Every value in `consumed_signal_contracts` must appear in either `Accepted upstream signal contracts` or `v2.2.1 extended upstream signal contracts` above.
2. Every `feedback_used.contracts[]` entry must match a defined feedback contract.
3. If a signal is stale, conflicting, or low-confidence, keep it in `ignored_signals` unless the user explicitly asks for exploratory analysis.
4. If a feedback signal affects scope, trigger placement, retry, isolation, or gate status, record that effect in `feedback_used.influence`.
