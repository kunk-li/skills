# Confidence and Readiness Scoring v2.2

Use this scoring policy before finalizing `metadata.confidence` and `metadata.readiness`. It makes evidence quality explicit and prevents high-confidence claims when required inputs are missing.

## Confidence score

Start from 100 and subtract penalties:

```yaml
penalties:
  missing_required_input: 25
  missing_traceability_id: 15
  stale_feedback_signal_over_90d: 10
  unverified_assumption: 10
  conflicting_sources: 15
  rule_warning: 5
  non_blocking_optional_gap: 5
```

Map score to confidence:

| Score | confidence | Required behavior |
|---:|---|---|
| 85-100 | high | May produce release-grade artifact if no reject rule failed |
| 60-84 | medium | Produce usable artifact, mark assumptions and constrained areas |
| 0-59 | low | Produce draft/advisory artifact only, or block if reject rules failed |

## Readiness mapping

```yaml
readiness_policy:
  blocked:
    when:
      - any reject rule failed
      - mandatory artifact is absent and cannot be degraded safely
      - production safety rule is violated
  constrained:
    when:
      - confidence is medium or low but no reject rule failed
      - optional enhancement inputs are missing
      - feedback signals are stale or conflict with current evidence
  pass:
    when:
      - no reject rule failed
      - confidence is high
      - required traceability IDs are preserved
```

## Evidence profile requirements

Always fill:

```yaml
evidence_profile:
  present: []
  missing: []
  assumptions: []
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied: []
    final_score: integer
```

Do not use `confidence: high` if `evidence_profile.missing` has two or more required inputs, or if any current release artifact conflicts with feedback history.
