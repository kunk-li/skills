# Evidence-bound upstream repair backedge

Use this contract when regression analysis blocks a release-relevant behavior because a local upstream artifact, implementation, or test-design gap is traceable. It closes the gap between detecting a risk and getting the responsible artifact corrected; it does not implement upstream work or claim that a repair passed.

For each actionable producer gap, emit one `upstream_repair_handoff` entry containing:

- `finding_id`: stable finding or `new_tests_required` identifier.
- `source_refs`: exact artifact IDs or paths that show the missing or conflicting behavior.
- `cause_stage`: the earliest evidenced producer stage for this handoff; do not claim it is the first divergence unless the chain evidence proves that.
- `target_skill_id` and `target_artifact`: set only when the artifact graph identifies them. If not, use null and `owner_resolution: unresolved`.
- `requested_change`: concrete correction scoped to the evidence.
- `expected_artifact`: the revised source artifact expected back from the owner.
- `completion_evidence`: assertions or fields that can be checked on return.
- `return_gate`: rerun 084 with a same-object, same-field, same-condition check.
- `status`: `open`, `in_progress`, or `resolved`; only the return check can mark resolved.

Keep `readiness: blocked` until all required return checks pass. A repair handoff is not a runtime result, test pass, or release approval. Keep missing runtime, database, identity-provider, CI, or external-service receipts in `downstream_handoff.unresolved_dependencies`; do not create a skill defect or fabricate an owner for them.

When multiple stages contributed, create separate handoffs for separately actionable gaps and preserve evidence for each. Do not rewrite upstream artifacts. The handoff asks the owner to correct them and supplies the exact condition that 084 will recheck.

## Worked finding shape

```yaml
upstream_repair_handoff:
  - finding_id: NTR-EXAMPLE-002
    source_refs: [EXC-EXAMPLE-012, TC-EXAMPLE-004, D-code/service-slice] 
    cause_stage: S4-code-to-test
    target_skill_id: 060-service-draft-generation
    target_artifact: generated service callback handler
    owner_resolution: resolved
    requested_change: preserve and compare the lifecycle attempt identity on callback application
    expected_artifact: regenerated service source and identity field trace
    completion_evidence: [stale-attempt callback is rejected, current-attempt callback advances once]
    return_gate:
      skill_id: 084-regression-test-checklist-generation
      required_recheck: [same ticket, stage, workflow, and attempt; distinguish callback delivery retry]
    status: open
```
