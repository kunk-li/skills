# Regression output contract v2.2.1

## Required shape

```yaml
regression_plan:
  plan_id: "REG-001"
  regression_scope:
    selected_scopes:
      - scope_kind: enum[S1_direct_impact, S2_cascading_impact, S3_critical_path, S4_historical_fragile, S5_recent_changes, S6_compliance_critical, S7_smoke_baseline]
        rationale: string
        tc_count: integer
  tc_selection_strategy:
    approach: enum[impact_based, risk_based, priority_based, full_regression, smoke_only]
    selected_tcs:
      total_count: integer
      breakdown:
        by_pyramid: {unit: integer, integration: integer, e2e: integer}
        by_priority: {P0: integer, P1: integer, P2: integer}
    excluded_tcs:
      - tc_id: string
        exclusion_reason: string
        reviewer_approved: bool
  bug_history_enrichment:
    bug_hotspots: array
    previously_missed_scenarios: array
    regression_bug_pattern: array
  new_tests_required:            # R13: change-touched guard branches with no driving tc
    - behavior: string           # the touched old behavior lacking branch coverage
      why_uncovered: string      # no tc drives this branch (positive-path tc != negative-branch covered)
      touched_by: string         # which change/symbol touches it
      uncovered_branch: string   # the specific guard branch lacking a driving tc (authz / status / exception exit)
      proposed_intent: enum[negative, state, boundary, concurrency, authorization, idempotency, other]
      reviewer_waived: bool
  automation_layers:
    fully_automated: {percentage: percentage, execution_time: duration, ci_integration: bool, run_trigger: enum[every_commit, every_pr, nightly, release]}
    semi_automated: {percentage: percentage, human_verification_points: array}
    manual: {percentage: percentage, reason: string, manual_effort_pd: number}
  execution_strategy:
    parallelization: {max_parallel_jobs: integer, parallel_strategy: enum[by_module, by_tc, by_pyramid]}
    execution_order: [smoke, unit_regression, integration_regression, e2e_critical_path]
    timeout_strategy: {total_budget: duration, per_tc_timeout: duration, abort_if_over_budget: bool}
    retry_policy: {flaky_retry_count: 2, quarantine_after_n_failures: 5}
  results_analysis:
    success_criteria: {all_p0_pass: true, p1_pass_rate_min: "95%", p2_pass_rate_min: "85%", no_new_failures: true}
```

## Scope enum semantics

- `S1_direct_impact`: directly modified modules; cover 100% related test cases.
- `S2_cascading_impact`: downstream dependencies; run interface and contract tests.
- `S3_critical_path`: core business journeys; run critical E2E paths.
- `S4_historical_fragile`: historical bug hotspots; include targeted cases.
- `S5_recent_changes`: changed in the last 30 days; include recent additions.
- `S6_compliance_critical`: compliance/security/privacy flows; always include.
- `S7_smoke_baseline`: baseline smoke; include to connect with 085.

## Algorithms

`hotspot_score = bug_count_last_6mo * 0.4 + recent_bug_recency * 0.3 + change_frequency * 0.2 + module_criticality * 0.1`

Release type adjustment:
- `patch`: direct impact + smoke, target <= 30 min.
- `minor`: direct + cascading + critical path, target 2-4 h.
- `major`: full regression, target 1 d or more.
- `hotfix`: smoke + direct impact, target <= 15 min.


## v2.2.1 additions

```yaml
contract_version: "n240.regression_plan.v2.2"
compatibility:
  backward_compatible_with: "n240.regression_plan.v2"
  change_type: additive
feedback_inputs:
  consumed_signal_contracts:
    - feedback.n005.production_signal_package.v1
    - feedback.n250.defect_signal.v1
    - feedback.n300.monitoring_signal.v1
    - feedback.n320.postmortem_signal.v1
  feedback_used_required_when_signals_used: true
confidence_scoring:
  policy_ref: references/confidence-scoring.md
  high_min_score: 85
  medium_min_score: 60
  low_below: 60
node_routing:
  policy_ref: references/node-routing-contract.md
```
