# N240 示例输入输出

## 示例 1：回归测试清单生成（regression-test-checklist-generation）

### 输入
- PR：checkout 重构，DIFR-001 DB迁移、DIFR-002 支付重试
- 模式：full_suite

### 输出
```yaml
regression_plan:
  mode: full_suite
  readiness: ready
  regression_scope:
    - module: checkout_flow
      priority: P0
      reason: 直接修改
    - module: payment_gateway_integration
      priority: P0
      reason: DIFR-002 重试逻辑变更
  tc_selection_strategy:
    total_selected: 47
    automation_tier: 38
    manual_tier: 9
```

## 示例 2：冒烟测试清单生成（smoke-test-checklist-generation）

### 输入
- 部署：payment-service v2.4.1，生产环境，预算10分钟

### 输出
```yaml
smoke_checklist:
  mode: post_deploy
  time_budget: 10min
  items:
    - id: SMK-001
      journey: 用户完成支付
      check: POST /api/v1/payments → 200
      pass_criterion: HTTP 200 + transaction_id 存在
```
