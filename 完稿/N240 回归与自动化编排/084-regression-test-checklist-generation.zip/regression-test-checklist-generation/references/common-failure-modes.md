
# Common failure modes v2.1

Avoid these errors in every N240 skill:

1. Emitting a checklist without stable IDs (`suite_id`, `tc_id`, `script_id`, or `api_ref`).
2. Treating missing upstream artifacts as if full evidence was available.
3. Mixing blocker, advisory, and informational checks in one undifferentiated list.
4. Dropping `downstream_handoff`, which prevents the next skill from consuming the artifact.
5. Using prose-only rules where a hard gate or enum should be emitted.
6. Renaming fields without updating `contract_version` and migration notes.
7. Retrying real assertion failures as if they were flaky or infrastructure failures.
8. Rebuilding an upstream skill's decision instead of consuming its artifact.
