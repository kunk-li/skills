# N240 Event, SLA, and Circuit Hooks

> Shared reference for all N240 skills. Reference this file; do not duplicate in SKILL.md.


Emit the produced/state/exception events listed above in metadata. When a rule blocks release, add an `sla_queue_hint` with priority `P0`, `P1`, or `P2`, a recommended human action, and escalation target if known. When retry or loop behavior is discussed, cap it explicitly with `max_iter`, `cooldown`, and escalation guidance instead of leaving an unbounded loop. When feedback contracts are consumed, fill `feedback_used`, record stale/conflicting signals, and avoid letting low-confidence historical signals override current release evidence.




