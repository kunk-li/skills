# Regression rules v2.2.1

| Rule | Requirement | on_violation |
|---|---|---|
| R01_scope_declared | `regression_scope.selected_scopes` must be present. | reject |
| R02_p0_tcs_always_included | P0 test cases must always be included or explicitly blocked. | reject |
| R03_critical_path_included | `S3_critical_path` must be included for release and major changes. | reject |
| R04_compliance_always_included | `S6_compliance_critical` must be included when compliance is touched. | reject |
| R05_automation_tracked | Automation percentage and manual effort must be tracked. | reject |
| R06_exclusion_reviewed | Every excluded test case needs reviewer approval. | reject |
| R07_historical_hotspot_included | Hotspots above threshold need extra coverage. | reject |
| R08_execution_budget_capped | Total execution budget must be capped. | reject |


## v2.2.1 reactive addendum rules

| Rule | Requirement | on_violation |
|---|---|---|
| R09_feedback_contracts_defined | Every value in `consumed_signal_contracts` and `feedback_used.contracts` must be defined in `references/feedback-input-contract.md`. | reject |
| R10_feedback_used_traceable | When feedback signals influence scope, scripts, triggers, stages, retries, gates, or confidence, output `feedback_used.contracts`, `feedback_used.signal_ids`, and `feedback_used.influence`. | reject |
| R11_confidence_score_calculated | Apply `references/confidence-scoring.md`, include final score and penalties, and map score to `confidence`. | reject |
| R12_stale_or_conflicting_feedback_handled | Stale, conflicting, or low-confidence feedback must be recorded in `ignored_signals` or `evidence_profile.stale_or_conflicting_feedback` before it can affect decisions. | reject |
