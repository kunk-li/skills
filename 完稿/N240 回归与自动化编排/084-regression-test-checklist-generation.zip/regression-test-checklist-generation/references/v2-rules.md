# Regression rules v2.2.1

| Rule | Requirement | on_violation |
|---|---|---|
| R01_scope_declared | `regression_scope.selected_scopes` must be present. | reject |
| R02_p0_tcs_always_included | P0 test cases must always be included or explicitly blocked. | reject |
| R03_critical_path_included | `S3_critical_path` must be included for release and major changes. | reject |
| R04_compliance_always_included | `S6_compliance_critical` must be included when compliance is touched. | reject |
| R05_automation_tracked | Automation percentage and manual effort must be tracked. | reject |
| R06_exclusion_reviewed | Every excluded test case needs reviewer approval. | reject |
| R07_historical_hotspot_included | Hotspots above threshold need extra coverage. | reject |
| R08_execution_budget_capped | Total execution budget must be capped. | reject |


## v2.2.1 reactive addendum rules

| Rule | Requirement | on_violation |
|---|---|---|
| R09_feedback_contracts_defined | Every value in `consumed_signal_contracts` and `feedback_used.contracts` must be defined in `references/feedback-input-contract.md`. | reject |
| R10_feedback_used_traceable | When feedback signals influence scope, scripts, triggers, stages, retries, gates, or confidence, output `feedback_used.contracts`, `feedback_used.signal_ids`, and `feedback_used.influence`. | reject |
| R11_confidence_score_calculated | Apply `references/confidence-scoring.md`, include final score and penalties, and map score to `confidence`. | reject |
| R12_stale_or_conflicting_feedback_handled | Stale, conflicting, or low-confidence feedback must be recorded in `ignored_signals` or `evidence_profile.stale_or_conflicting_feedback` before it can affect decisions. | reject |


## v2.2.2 change-touched coverage addendum

> Rationale: this skill is a test-case *selector* (`selected_tcs` / `excluded_tcs`). A selector can only re-run tests that already exist. When a change modifies old code and touches a behavior that has **no** existing test case, `S1_direct_impact`'s "cover 100% related test cases" passes trivially (100% of zero), `R02_p0_tcs_always_included` has no object to fire on, and the touched-but-uncovered behavior is silently dropped from the plan — the exact failure mode where a fix breaks an untested sibling behavior and nothing goes red until a later detection round. Regression coverage = re-running existing tests for touched code **plus** creating tests for touched behaviors that lack coverage.

| Rule | Requirement | on_violation |
|---|---|---|
| R13_touched_undercovered_new_test | Cross-check every `change_impact_analysis.touched[]` behavior/symbol against the existing `test_cases` pool. Coverage is judged at **branch / negative-path granularity, by test intent — not by symbol name and not by "≥1 tc exists"**: a tc covers a touched branch only when its assertions actually drive that branch's outcome (its `assertThrows` / exception exit, authz gate, or status gate). A touched symbol carrying only positive-path tcs is **not** covered for its guard/negative branches. For any touched behavior whose guard branch has **no driving tc**, emit a `new_tests_required[]` entry (`behavior` / `why_uncovered` / `touched_by` / `proposed_intent` / `uncovered_branch`) and set `readiness: constrained` until created or `reviewer_waived`. Selecting only from the existing pool while a touched-but-under-covered branch remains does **not** satisfy `S1_direct_impact`. Scope: fires only on `touched ∩ under-covered` (both) — never whole-module/whole-suite expansion; enumerate only the touched symbol's **guard branches** (exception exits, authz/status gates), not all branches. Matching is **semantic**: bind a tc to a behavior by what it asserts/drives, never by method-name prefix (one tc may drive several behaviors; one behavior may be covered by the union of differently-named tcs). Declare pool scope in `evidence_profile.test_pool_scope` (`module` \| `whole_suite`). | reject (when branch granularity is available) |

**Degrade ladder (three tiers, most→least impact granularity):**
- **behavior/branch granularity** — impact names the touched guard branch. Judge per R13 above; a guard branch missing a driving tc → **reject** + `new_tests_required`.
- **symbol granularity, no branch granularity** (MIDDLE TIER — the common real-tool case, e.g. "correctEntry changed"). Do **not** silently pass as covered because the symbol has a positive-path tc. Enumerate the symbol's guard branches; for each lacking a driving tc → **warn** + `coverage_gap{symbol, uncovered_branch, coverage_class: partial, manual_branch_review: required}` and `readiness: constrained`. If the symbol source is unavailable so guard branches can't be enumerated → **warn** + `coverage_gap{symbol, coverage_class: partial_unverifiable}` (never upgrade an unverifiable branch to reject, never downgrade to silent-covered).
- **module granularity only** — as before: **warn** + `coverage_gap{touched_module, behavior_level_impact: unavailable, manual_coverage_review: required}`.

**Pool scope / cross-module visibility (eliminates name-based false fires):** if a touched symbol's coverage is not found in the declared pool but the symbol is driven by another module's flow (e.g. `creditForRedemption` driven only by a coupon module's `redeem_*`/`void_*` tests), record `coverage_visibility: cross_module_unavailable` and **warn** — do **not** emit a hard `uncovered`/`new_tests_required`. Cross-module coverage that exists but is out of pool scope is *unverified-here*, not *absent*.

**Deterministic branch-coverage engine (use when service source + test source are available — do NOT reason branch coverage by hand).** The "covered by test intent, not by name" judgment above is a mechanical assertion-intent analysis; compute it deterministically (a reference implementation parses with tree-sitter):
1. **Enumerate the touched method's guard branches.** Collect exception types the method constructs (`throw new X` / `orElseThrow(() -> new X)`). For calls to same-class guard helpers (`require*`, access-policy checks), **recursively** read the exceptions those helpers raise. Classify each branch: `authz` (the access-denied exception), `status` (state-gate exceptions), else `exception`.
2. **Read each test's assertion intent.** For every `assertThrows(E.class, () -> …)` (or the framework's equivalent), extract the asserted exception type `E` and the target method(s) the lambda actually invokes.
3. **Match by content, never by name.** A branch `(method T, exception E)` is COVERED iff some test asserts exception `E` **while its lambda invokes T**. A method carrying only positive-path assertions leaves its authz/status guard branches UNCOVERED.
4. Feed the UNCOVERED guard branches into R13: `authz`/`status` uncovered → `new_tests_required` + `readiness: constrained`; other uncovered exception exits → `coverage_gap{partial}` advisory.

This engine is **more precise than naïve line/branch coverage** for method-specific guard coverage: a shared guard helper's deny branch is hit by *other* methods' tests, so line coverage falsely reports the touched method's authz as covered — the intent match does not. Its verdict has been **validated against runtime ground truth**: stack-trace instrumentation recording which method actually triggers each authz deny at runtime matched the static intent verdict exactly (the methods whose authz-negative path was never exercised were exactly those the engine marked UNCOVERED). Honest limits: recognizes `assertThrows`-style intent only (try/catch+`fail`, AssertJ, parameterized tests need their own adapters — degrade to the middle tier when unrecognized); guard resolution is intra-file (cross-file base-class guards fall back to `partial_unverifiable`); a test that invokes the method but whose mock skips the guard could read covered (not observed in validation but possible) — treat the engine as a strong signal, not a runtime proof.
