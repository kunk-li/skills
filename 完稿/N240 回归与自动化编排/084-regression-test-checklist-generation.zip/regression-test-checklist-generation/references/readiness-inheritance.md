
# Readiness inheritance and gate behavior v2.2.1

## Readiness values

- `pass`: required evidence is present, hard rules pass, and downstream can consume the artifact without special handling.
- `constrained`: the artifact is useful but some evidence is missing or assumptions were required; downstream may consume it only with visible caveats.
- `blocked`: a required input, contract, or hard rule failed; do not present the artifact as production-ready.

## Inheritance rules

1. A downstream skill cannot raise readiness above the weakest required upstream artifact unless it adds new evidence that resolves the weakness.
2. If any `on_violation: reject` rule fires, set `readiness: blocked` and include the rule id in `self_check.failed_rules`.
3. If only optional enhancement inputs are missing, keep `readiness: constrained` or `pass` based on risk impact.
4. If a skill emits `blocked`, 087 and 088 must not convert it into a blocking CI gate; they may create an advisory remediation stage instead.
5. Record all assumptions in `metadata.evidence_profile.assumptions`; do not hide assumptions in prose.

## Gate outputs

```yaml
self_check:
  passed_rules: array
  failed_rules: array
  warnings: array
  readiness_reason: string
  next_human_action: string | null
```


## v2.2.1 confidence inheritance

Downstream confidence cannot exceed upstream confidence when the downstream artifact depends on that upstream artifact as a blocking prerequisite. A downstream skill may raise confidence only when it adds fresh evidence that resolves upstream missing inputs or assumptions. Use `confidence-scoring.md` to document the score change.
