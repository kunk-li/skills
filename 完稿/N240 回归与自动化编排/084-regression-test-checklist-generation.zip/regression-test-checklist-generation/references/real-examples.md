# Regression examples

## Example: minor release touching orders and payment audit

Input summary:
- Changed modules: `OrderService`, order API, audit event producer.
- Release type: `minor`.
- Historical bug hotspot: `PaymentService` concurrency, 8 defects in last 6 months.

Expected output excerpt:

```yaml
regression_plan:
  plan_id: REG-ORDER-042
  regression_scope:
    selected_scopes:
      - scope_kind: S1_direct_impact
        rationale: OrderService and POST /orders changed.
        tc_count: 45
      - scope_kind: S2_cascading_impact
        rationale: Payment and Audit depend on order events.
        tc_count: 25
      - scope_kind: S3_critical_path
        rationale: Create order -> pay -> audit is a core journey.
        tc_count: 10
      - scope_kind: S4_historical_fragile
        rationale: Payment concurrency hotspot is above threshold.
        tc_count: 8
      - scope_kind: S7_smoke_baseline
        rationale: Feed 085 and first orchestration phase.
        tc_count: 20
  bug_history_enrichment:
    bug_hotspots:
      - module_or_feature: PaymentService
        historical_bug_count: 8
        recommended_extra_tcs:
          - tc_id: TC-PAYMENT-RACE-001
            rationale: prior double-charge incident
```


## v2.2 feedback example fragment

```yaml
feedback_used:
  contracts:
    - feedback.n250.defect_signal.v1
  signal_ids:
    - DEFECT-HIST-001
  influence:
    added_scopes_or_tests:
      - "added historical hotspot coverage for payment retry path"
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals:
    - signal_id: OLD-FLAKY-2019
      reason: "stale signal over 90 days and no recent recurrence"
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied:
      - "missing_traceability_id: -15"
    final_score: 85
```
