
# Quality checklist v2.1

Before finalizing output, verify:

- Metadata includes `skill_version`, `contract_version`, `selected_mode`, `readiness`, `confidence`, and `produced_events`.
- All IDs are stable and reusable by downstream skills.
- Required v2 enums are used exactly as defined in `v2-output-contract.md`.
- All hard rules from `v2-rules.md` are evaluated in `self_check`.
- `downstream_handoff` maps fields to explicit consumers.
- Missing evidence is represented as `constrained` or `blocked`, not silently ignored.
- Events, SLA tags, and escalation hints are present when relevant.

## Skill-specific checks

- S1-S7 regression scope is explicit.
- P0, critical path, compliance, and historical hotspot checks are included.
- Excluded test cases include reviewer approval and rationale.
- Execution budget and retry policy are capped.
