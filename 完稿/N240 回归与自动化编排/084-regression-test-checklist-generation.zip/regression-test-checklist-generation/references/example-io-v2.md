# N240 示例输入输出 v2（扩展场景）

## 示例 3：触发策略推荐（test-automation-trigger-recommendation）

### 输入
- 60个测试（40单元，12集成，8 e2e）；CI预算15分钟

### 输出
```yaml
trigger_recommendation:
  on_pull_request:
    - group: unit_tests
      count: 40
      estimated_time: 3min
    - group: integration_payment
      count: 6
      estimated_time: 8min
  ci_total_budget_used: 11min / 15min
```

## 示例 4：CI流水线编排（test-automation-orchestration）

### 输入
- 38个自动化测试，GitHub Actions，回归计划已就绪

### 输出
```yaml
# .github/workflows/test-pipeline.yml（骨架）
jobs:
  lint:
    runs-on: ubuntu-latest
  unit:
    needs: lint
    timeout-minutes: 5
  integration:
    needs: unit
    timeout-minutes: 10
  notify-on-failure:
    if: failure()
    needs: [unit, integration]
```

## 084 扩展示例输入输出

### Scenario B — Quick impact scan (hotfix: session token bug)

**Input**: Single-file hotfix to session token expiry logic; no diff-risk-review available; release in 30 min.

**Output** (`quick_impact_scan` mode):
```yaml
regression_plan:
  mode: quick_impact_scan
  readiness: constrained
  pending_impact_confirmation: true
  regression_scope:
    - module: auth_session
      reason: directly modified
      priority: P0
    - module: user_profile
      reason: reads session token
      priority: P1
  tc_selection_strategy:
    total_selected: 8
    automation_tier: 6
    manual_tier: 2
    rationale: Minimal scope — hotfix window 30 min
  self_check:
    - no_fabricated_results: true
    - scope_grounded_in: diff_content
```

### Scenario C — Flaky cleanup (pre-release stabilisation)

**Input**: 12 flaky tests identified in last 5 CI runs; release gate requires <2% flakiness.

**Output** (`flaky_cleanup` mode):
```yaml
regression_plan:
  mode: flaky_cleanup
  flaky_candidates:
    - tc_id: TC-0412
      flaky_rate: 34%
      quarantine_action: skip_in_gate
    - tc_id: TC-0178
      flaky_rate: 18%
      quarantine_action: isolate_and_rerun
  recommendation: stabilise TC-0412 root cause before next release gate
  downstream_handoff:
    to: 085-smoke-test-checklist-generation
    signal: flaky_quarantine_list
```

### Scenario D — Post-hotfix regression (urgent scoping)

**Input**: Hotfix merged for P0 INC-4821; need minimal regression scope before re-deploy.

**Output** (`hotfix_regression` mode):
```yaml
regression_checklist:
  mode: hotfix_regression
  readiness: ready
  scope_rationale: Hotfix touches PaymentService.java only — scope minimized
  items:
    - id: REG-HOT-001
      test_case_id: TC-PAY-042
      scope: direct_change
      description: PaymentService.processRefund() null guard — smoke + regression
      priority: P0
      automation: automated
    - id: REG-HOT-002
      test_case_id: TC-PAY-010
      scope: adjacent_affected
      description: PaymentService.processPayment() — adjacent path in same class
      priority: P1
      automation: automated
    - id: REG-HOT-003
      scope: not_included
      reason: Full regression deferred — smoke coverage sufficient for hotfix protocol
  deferred_to: next_sprint_regression_cycle
  estimated_time: 8min
```
