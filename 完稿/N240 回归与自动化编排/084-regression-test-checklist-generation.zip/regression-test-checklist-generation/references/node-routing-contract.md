# N240 Node Routing Contract v2.2.1

Use this file only when choosing which N240 skill or skill chain to run. It does not replace the five standalone skills. Each skill remains individually usable; this contract only makes composition deterministic.

## Single-skill routing table

| User intent or available evidence | Route first | Do not use instead | Required handoff key |
|---|---|---|---|
| Need change-impact regression scope, release regression list, historical bug hotspots, or P0/P1/P2 test selection | 084 regression-test-checklist-generation | 085 smoke-only validation | `regression_plan.plan_id` |
| Need a fast deploy or post-deploy validation checklist, health/readiness probes, production-safe smoke, or canary switch checks | 085 smoke-test-checklist-generation | 084 full regression | `smoke_checklist.checklist_id` |
| Need OpenAPI-derived executable API tests, framework-specific script bundles, fixtures, auth setup, teardown, or contract tests | 086 api-test-script-generation | 088 pipeline orchestration | `test_scripts[].script_id` and `script_bundle_manifest[].path` |
| Need to decide when tests should run, which suites block PR/release, cost/time tradeoffs, or dev-loop feedback targets | 087 test-automation-trigger-recommendation | 088 final pipeline YAML | `trigger_strategy.strategy_id` |
| Need CI stage graph, execution ordering, data isolation, retry classification, dashboards, notifications, or environment orchestration | 088 test-automation-orchestration | 087 trigger policy | `orchestration_plan.plan_id` |

## Composite route patterns

```yaml
routes:
  minimal_hotfix:
    chain: [085, 087, 088]
    use_when: "hotfix, small diff, urgent deploy, smoke + direct tests only"
    blocking_artifacts: [smoke_checklist, trigger_strategy, orchestration_plan]

  pr_gate:
    chain: [084, 086, 087, 088]
    use_when: "pull request with code/API changes and CI gate needed"
    blocking_artifacts: [regression_plan, test_scripts, trigger_strategy, orchestration_plan]

  release_gate:
    chain: [084, 085, 086, 087, 088]
    use_when: "minor/major release, production rollout, compliance or core journey risk"
    blocking_artifacts: [regression_plan, smoke_checklist, test_scripts, trigger_strategy, orchestration_plan]

  ci_cost_optimization:
    chain: [084, 087, 088]
    use_when: "pipeline is too slow or expensive; prioritize affected regression and trigger placement"

  api_automation_modernization:
    chain: [086, 087, 088]
    use_when: "OpenAPI exists and the goal is API automation asset plus CI integration"
```

## Routing rules

- Prefer the smallest chain that can satisfy the requested artifact. Add downstream skills only when the user asks for trigger or execution behavior.
- Never let 088 regenerate regression, smoke, or API scripts when upstream artifacts exist. It must consume stable IDs.
- Never let 087 produce final CI/YAML stage graphs. It decides timing and blocking policy; 088 turns that policy into a stage graph.
- When multiple routes are valid, prefer the route that preserves user-supplied artifacts and IDs over recreating them.
- If a route is uncertain, output `routing_confidence: medium` and include the skipped skills with reasons.
