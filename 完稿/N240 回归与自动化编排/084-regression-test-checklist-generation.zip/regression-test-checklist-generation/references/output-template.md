# Regression output template

```yaml
metadata:
  skill_id: regression-test-checklist-generation
  skill_version: "2.2.1"
  contract_version: n240.regression_plan.v2.2
  selected_mode: quick_impact_scan
  readiness: pass
  confidence: medium
  produced_events: [produced.n240.regression_plan.v2.2]

regression_plan:
  plan_id: REG-001
  regression_scope:
    selected_scopes:
      - scope_kind: S1_direct_impact
        rationale: OrderService changed by TASK-17
        tc_count: 45
  tc_selection_strategy:
    approach: impact_based
    selected_tcs:
      total_count: 115
      breakdown:
        by_pyramid: {unit: 60, integration: 40, e2e: 15}
        by_priority: {P0: 50, P1: 45, P2: 20}
  automation_layers:
    fully_automated: {percentage: "90%", execution_time: 25min, ci_integration: true, run_trigger: every_pr}
  execution_strategy:
    execution_order: [smoke, unit_regression, integration_regression, e2e_critical_path]
    timeout_strategy: {total_budget: 45min, per_tc_timeout: 2min, abort_if_over_budget: true}

downstream_handoff:
  consumed_by:
    - target: 087 trigger strategy
      fields: [regression_plan.plan_id, selected_suites, execution_strategy]
self_check:
  passed_rules: [R01_scope_declared, R02_p0_tcs_always_included]
  failed_rules: []
```


## v2.2 output fields

```yaml
feedback_used:
  contracts: []
  signal_ids: []
  influence:
    added_scopes_or_tests: []
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals: []
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied: []
    final_score: integer
```
