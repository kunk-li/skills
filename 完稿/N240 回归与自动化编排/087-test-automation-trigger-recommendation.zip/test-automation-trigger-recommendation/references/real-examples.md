# Trigger examples

## Example: PR update touching order API

```yaml
trigger_strategy:
  strategy_id: TRIG-ORDER-PR-007
  triggers:
    T2_pre_commit_hook:
      which_tests: [changed unit tests, lint]
      duration_budget: 30s
    T4_on_pr_creation:
      which_tests: [full unit, impacted integration, SMK-ORDER-CANARY-009, REG-ORDER-042]
      duration_budget: 12min
      blocking: true
    T5_scheduled_nightly:
      which_tests: [full regression, payment concurrency hotspot, load smoke]
      duration_budget: 4h
  layered_strategy:
    tier_2_pr_loop:
      feedback_time: 12min
      tests: [unit, integration, contract, smoke, impact_based_regression]
  failure_handling:
    flaky_test_policy: {retry_count: 2, quarantine_threshold: 3 consecutive failures, auto_ticket: true}
    real_failure: {block_merge: true, notify_author: immediate}
```


## v2.2 feedback example fragment

```yaml
feedback_used:
  contracts:
    - feedback.n250.defect_signal.v1
  signal_ids:
    - DEFECT-HIST-001
  influence:
    added_scopes_or_tests:
      - "added historical hotspot coverage for payment retry path"
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals:
    - signal_id: OLD-FLAKY-2019
      reason: "stale signal over 90 days and no recent recurrence"
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied:
      - "missing_traceability_id: -15"
    final_score: 85
```
