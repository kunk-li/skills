# Affected Test Detection Tools v2.2

Use this file when recommending impact-based triggers or affected-only execution. The tool choice must match repository structure, language, dependency graph quality, and CI platform.

## Tool mapping

| Context | Recommended tool | Use for | Required evidence |
|---|---|---|---|
| Bazel monorepo | `bazel query` + `bazel test --build_tests_only` | reverse dependency affected tests | BUILD graph is maintained |
| Nx workspace | `nx affected -t test` | JS/TS monorepo affected projects | base/head refs and project graph |
| Turborepo | `turbo run test --filter=...[HEAD^]` | package-level affected tasks | package graph and lockfile changes |
| Gradle multi-project | Gradle incremental + test filters | JVM module-level test selection | subproject boundaries and source sets |
| Maven multi-module | `-pl` and `-am` module selection | module-level impacted test runs | reliable module dependency tree |
| Jest | `jest --findRelatedTests` | changed file to related test mapping | changed file list and jest config |
| pytest | `pytest-testmon` or `pytest --lf` | changed Python code or last failures | testmon database or historical run data |
| GitHub Actions | `paths` / `paths-ignore` + matrix | workflow-level trigger filtering | changed paths and branch policy |
| GitLab CI | `rules:changes` | job-level trigger filtering | changed paths and branch policy |

## Selection algorithm

```yaml
affected_test_detection:
  step_1: identify changed files and modules
  step_2: map files to owning modules or packages
  step_3: expand reverse dependencies when service contracts or shared libraries changed
  step_4: add mandatory smoke, P0, compliance, and historical hotspot tests
  step_5: compare duration and cost against trigger budget
  step_6: record skipped tests with reviewer approval when blocking gate is affected
```

## Safety rules

- Never use affected-only as the sole release gate for major releases.
- Never skip compliance, P0, production smoke, or critical path tests solely because the dependency graph says they are unaffected.
- If dependency graph quality is unknown, use affected-first followed by full scheduled/nightly coverage.
- For docs-only changes, use minimal lint/docs validation and explicitly record why test suites were skipped.
