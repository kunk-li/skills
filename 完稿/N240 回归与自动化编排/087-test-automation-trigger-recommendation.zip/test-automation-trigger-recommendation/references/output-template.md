# Trigger output template

```yaml
metadata:
  skill_id: test-automation-trigger-recommendation
  skill_version: "2.2.1"
  contract_version: n240.trigger_strategy.v2.2
  selected_mode: diff_analyzer
  readiness: pass
  confidence: medium
  produced_events: [produced.n240.trigger_strategy.v2.2]

trigger_strategy:
  strategy_id: TRIG-001
  triggers:
    T4_on_pr_creation:
      which_tests: [unit full, integration impacted, smoke, impact_based_regression]
      selected_suite_ids: [REG-ORDER-042, SMK-ORDER-CANARY-009, ATS-ORDER-001]
      duration_budget: 12min
      blocking: true
  time_cost_analysis:
    per_trigger:
      - trigger: T4_on_pr_creation
        avg_duration: 12min
        cost_per_run_usd: 0.5
        frequency_per_day: 15
  fail_fast_optimization:
    test_ordering: [lint, compile, unit, integration, smoke, e2e]
```


## v2.2 output fields

```yaml
feedback_used:
  contracts: []
  signal_ids: []
  influence:
    added_scopes_or_tests: []
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals: []
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied: []
    final_score: integer
```
