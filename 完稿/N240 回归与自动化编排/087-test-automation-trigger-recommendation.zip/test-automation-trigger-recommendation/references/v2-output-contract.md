# Trigger strategy contract v2.2.1

## Trigger enum

- `T1_on_file_save`: IDE/watch feedback; affected unit tests; target < 5s.
- `T2_pre_commit_hook`: lint and changed unit tests; target < 30s.
- `T3_on_push_to_feature_branch`: full unit and impacted integration; target < 5min.
- `T4_on_pr_creation`: full unit, integration, smoke, affected E2E, impact regression; target < 15min; blocking.
- `T5_scheduled_nightly`: full regression, load, chaos, security; target 4-8h; non-immediate feedback.
- `T6_pre_release`: full E2E, performance, security, compliance, production-like smoke; target 2-4h; blocking.

## Required shape

```yaml
trigger_strategy:
  strategy_id: TRIG-001
  triggers:
    T1_on_file_save: {which_tests: array, duration_budget: "< 5s", blocking: false}
    T2_pre_commit_hook: {which_tests: array, duration_budget: "< 30s", blocking: true}
    T3_on_push_to_feature_branch: {which_tests: array, duration_budget: "< 5min"}
    T4_on_pr_creation: {which_tests: array, duration_budget: "< 15min", blocking: true}
    T5_scheduled_nightly: {which_tests: array, duration_budget: "4-8h"}
    T6_pre_release: {which_tests: array, duration_budget: "2-4h", blocking: true}
  time_cost_analysis:
    per_trigger: array
    total_monthly_cost: string
  layered_strategy:
    tier_1_developer_loop: {feedback_time: "< 5s", triggers: [T1, T2]}
    tier_2_pr_loop: {feedback_time: "< 15min", triggers: [T3, T4]}
    tier_3_nightly: {feedback_time: next_day, triggers: [T5]}
    tier_4_release: {feedback_time: on_demand, triggers: [T6]}
  fail_fast_optimization:
    test_ordering: [lint, compile, unit, integration, smoke, e2e]
  coverage_gates:
    pr_gate: {no_coverage_decrease: true, min_absolute_coverage: "70%"}
    release_gate: {min_coverage: "80%", critical_path_coverage: "95%"}
```

## Cost formula

`per_run_cost = duration_hours * concurrent_jobs * cost_per_job_hour`

`monthly_cost = per_run_cost * runs_per_day * 30`


## v2.2.1 additions

```yaml
contract_version: "n240.trigger_strategy.v2.2"
compatibility:
  backward_compatible_with: "n240.trigger_strategy.v2"
  change_type: additive
feedback_inputs:
  consumed_signal_contracts:
    - feedback.n005.production_signal_package.v1
    - feedback.n250.defect_signal.v1
    - feedback.n300.ci_runtime_signal.v1
    - feedback.n300.flaky_test_signal.v1
  feedback_used_required_when_signals_used: true
confidence_scoring:
  policy_ref: references/confidence-scoring.md
  high_min_score: 85
  medium_min_score: 60
  low_below: 60
node_routing:
  policy_ref: references/node-routing-contract.md
```


## v2.2 affected test detection binding

```yaml
affected_test_detection_tools_ref: references/affected-test-detection-tools.md
affected_test_detection:
  supported_tools:
    - bazel
    - nx
    - turborepo
    - gradle_incremental
    - maven_multi_module
    - jest_find_related_tests
    - pytest_testmon
    - github_actions_paths
    - gitlab_rules_changes
  fallback_when_graph_unknown: affected_first_then_nightly_full
  never_skip:
    - P0
    - compliance
    - critical_path
    - production_smoke
```
