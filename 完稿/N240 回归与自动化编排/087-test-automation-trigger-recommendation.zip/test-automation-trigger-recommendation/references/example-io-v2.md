# N240 示例输入输出 v2（扩展场景）

## 示例 3：触发策略推荐（test-automation-trigger-recommendation）

### 输入
- 60个测试（40单元，12集成，8 e2e）；CI预算15分钟

### 输出
```yaml
trigger_recommendation:
  on_pull_request:
    - group: unit_tests
      count: 40
      estimated_time: 3min
    - group: integration_payment
      count: 6
      estimated_time: 8min
  ci_total_budget_used: 11min / 15min
```

## 示例 4：CI流水线编排（test-automation-orchestration）

### 输入
- 38个自动化测试，GitHub Actions，回归计划已就绪

### 输出
```yaml
# .github/workflows/test-pipeline.yml（骨架）
jobs:
  lint:
    runs-on: ubuntu-latest
  unit:
    needs: lint
    timeout-minutes: 5
  integration:
    needs: unit
    timeout-minutes: 10
  notify-on-failure:
    if: failure()
    needs: [unit, integration]
```

## 087 扩展示例输入输出

### Scenario B — Budget optimisation (over-budget CI)

**Input**: Full suite 45 min; budget 20 min; 120 tests across unit/integration/e2e.

**Trigger decision tree applied**:
```
Is test unit? → on_push (always)
Is test integration AND touches changed module? → on_PR
Is test e2e AND is release branch? → on_merge_to_main
Is test e2e AND is feature branch? → scheduled (nightly)
```

**Output** (`budget_optimization` mode):
```yaml
trigger_recommendation:
  mode: budget_optimization
  original_budget: 45min
  target_budget: 20min
  decision_tree_applied: true
  on_push:
    - group: unit_all
      count: 70
      estimated_time: 4min
  on_pull_request:
    - group: unit_all
      count: 70
    - group: integration_affected
      count: 15
      estimated_time: 10min
      note: Only modules in diff scope
  on_merge_to_main:
    - group: integration_all
      count: 35
    - group: e2e_critical
      count: 8
      estimated_time: 12min
  scheduled_nightly:
    - group: e2e_full
      count: 12
      estimated_time: 18min
  total_pr_budget: 18min / 20min
```

### Scenario C — Scheduled suite (nightly regression)

**Input**: 200 integration + e2e tests; no diff available; nightly full-suite required.

**Output** (`scheduled` mode):
```yaml
trigger_recommendation:
  mode: scheduled
  schedule: nightly 02:00 UTC
  groups:
    - group: integration_all
      count: 140
      estimated_time: 25min
    - group: e2e_all
      count: 60
      estimated_time: 35min
  total_estimated_time: 60min
  parallel_suggestion: split into 2 parallel jobs to fit 35-min window
```

### Scenario D — Feature flag gated deployment (partial rollout)

**Input**: Feature flag `ff_new_checkout` at 20%; changes in checkout flow only.

**Output** (`feature_flag` trigger strategy):
```yaml
trigger_strategy:
  mode: feature_flag
  flag: ff_new_checkout
  rollout_percentage: 20
  pipeline_config:
    smoke_test:
      scope: checkout_module_only
      trigger_condition: flag_enabled_sessions_only
      estimated_time: 4min
    regression:
      scope: checkout + payment integration
      trigger_condition: rollout_gt_50pct
      estimated_time: 22min
    full_regression:
      trigger_condition: rollout_eq_100pct
      estimated_time: 65min
  monitoring:
    error_rate_threshold: 0.5pct
    rollback_trigger: error_rate_exceeds_threshold_for_5min
  readiness: ready
  downstream_handoff:
    to: 088-test-automation-orchestration
    signal: trigger_strategy_ready
```
