# Trigger rules v2.2.1

| Rule | Requirement | on_violation |
|---|---|---|
| R01_6_tiers_covered | All T1-T6 trigger kinds must be considered. | reject |
| R02_fast_feedback_tier_1_2 | T1/T2 feedback must stay under 1 minute. | reject |
| R03_pr_gate_under_15min | PR trigger must target <= 15 minutes or mark constrained. | reject |
| R04_cost_budgeted | Monthly CI cost must be estimated or marked missing. | reject |
| R05_fail_fast_ordered | Fast and likely-to-fail checks must run before expensive checks. | reject |
| R06_flaky_policy | Flaky handling and quarantine policy must be explicit. | reject |
| R07_heavy_tests_nightly | Load/chaos/large E2E must not block every PR by default. | reject |
| R08_release_gate_strict | Release gates must include strict blocking tests. | reject |


## v2.2.1 reactive addendum rules

| Rule | Requirement | on_violation |
|---|---|---|
| R09_feedback_contracts_defined | Every value in `consumed_signal_contracts` and `feedback_used.contracts` must be defined in `references/feedback-input-contract.md`. | reject |
| R10_feedback_used_traceable | When feedback signals influence scope, scripts, triggers, stages, retries, gates, or confidence, output `feedback_used.contracts`, `feedback_used.signal_ids`, and `feedback_used.influence`. | reject |
| R11_confidence_score_calculated | Apply `references/confidence-scoring.md`, include final score and penalties, and map score to `confidence`. | reject |
| R12_stale_or_conflicting_feedback_handled | Stale, conflicting, or low-confidence feedback must be recorded in `ignored_signals` or `evidence_profile.stale_or_conflicting_feedback` before it can affect decisions. | reject |
