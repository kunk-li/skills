---
name: test-automation-trigger-recommendation
description: Recommend which tests run on save, commit, push, PR, nightly, or pre-release from cases, pyramid distribution, CI budget, and diff risk.
---
# test-automation-trigger-recommendation

## Role and boundary

Deliver the N240 artifact `自动化触发建议.md` as an independently usable, workflow-aligned skill. Keep this skill generic enough for a single pull request, hotfix, release, module, endpoint group, or CI modernization task, while making its output stronger when composed with the other N240 skills.

Own: Recommend when to run each test suite using trigger tiers, cost budgets, fail-fast ordering, flaky policy, and gate mapping.

Do not claim runtime results unless execution evidence is supplied. Do not regenerate upstream artifacts when they are already provided; consume and reference them through stable IDs.

This skill aligns to testing & qa → regression and automation planning → 自动化触发策略.md. It delivers CI trigger mapping and budget recommendations for N240.

### Boundary
- Focus on planning artifacts, not runtime execution results.
- Consume upstream N230 and N240 artifacts by reference; do not regenerate them.
- Do not fabricate test results unless execution evidence is supplied.


## Trigger routing decision table

| Situation | Action |
|---|---|
| Unit tests only | All triggers: on_push for maximum fast feedback |
| Mixed pyramid (unit+integration+e2e) | Apply decision tree: unit→push, integration→PR, e2e→merge |
| CI budget exceeded | Move lowest-risk integration tests to scheduled_nightly |
| High-risk diff area identified | Ensure at least one fast trigger covers the affected modules |
| Same test triggered by multiple events | Deduplicate per R05; keep highest-frequency trigger only |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n240.test-automation-trigger.v2.2"
contract_version: "n240.trigger_strategy.v2.2"
artifact_target: "自动化触发建议.md"
workflow_node: "N240"
node_artifact_target: "n240.trigger_strategy"
function_bias: "planning"
compatible_with:
  - n240.trigger_strategy.v2
consumed_signal_contracts:
  - feedback.n005.production_signal_package.v1
  - feedback.n250.defect_signal.v1
  - feedback.n300.ci_runtime_signal.v1
  - feedback.n300.flaky_test_signal.v1
produced_events:
  - produced.n240.trigger_strategy.v2.2
  - state.n240.trigger.readiness
  - exception.n240.trigger.contract_violation
downstream_consumers:
  - 088 orchestration
  - CI config generation
  - N260 gate
  - DevOps dashboard
```

Keep frontmatter limited to `name` and `description`; versioning lives in the body and output metadata so packaging validators remain compatible.

## Mode selection

Every result must start with `metadata.selected_mode`, `metadata.readiness`, `metadata.confidence`, and `metadata.evidence_profile`.

Allowed modes:
- `trigger_designer`: design a project-level multi-trigger strategy.
- `diff_analyzer`: select tests and blocking behavior for a specific diff.
- `release_gate_mode`: optimize trigger policy for release and post-deploy confidence.
- `cost_optimization`: reduce CI cost while preserving feedback and gate quality.

## Inputs

Required or strongly preferred inputs:
- `test_cases`
- `pyramid_distribution`
- `ci_budget`
- `team_preferences`

Optional enhancement inputs:
- regression_plan
- smoke_checklist
- test_scripts
- flaky metrics
- duration baselines
- release calendar

Standalone behavior:
- If only one diff, module, endpoint group, or release slice is available, still produce the same output shape.
- If a required input is missing, mark `readiness: constrained` or `blocked`, list missing evidence, and avoid overclaiming certainty.
- If upstream N240 artifacts are present, preserve their `suite_id`, `tc_id`, `script_id`, `api_ref`, `risk_ref`, and `task_ref` values.


### Degradation rules

- If CI budget or infrastructure details are missing, produce a generic trigger map marked `pending_budget_confirmation` with best-practice defaults.
- If test pyramid data is unavailable, use a 70/20/10 default and mark it `pending_pyramid_data`.
- Keep the output schema stable even with minimal inputs; prefer explicit `pending_*` fields over silent omissions.


## Core output contract

Default to YAML-friendly Markdown and follow `references/output-template.md`.

The result must include:
- metadata (selected_mode, readiness, ci_budget, evidence_profile)
- trigger_recommendation_table[]
- ci_time_estimate
- risk_coverage_map
- downstream_handoff
- self_check
- `readiness: ready | constrained | blocked`

## Hard gates and v2 rules

Load and apply `references/v2-rules.md` before finalizing. For any rule with `on_violation: reject`, set `readiness: blocked` unless the user explicitly asks for a draft or advisory-only artifact. Put all rule outcomes in `self_check.passed_rules`, `self_check.failed_rules`, and `self_check.warnings`.

## Execution workflow

1. If multiple N240 skills could apply, consult `references/node-routing-contract.md`; otherwise run this skill standalone.
2. Select the mode from the available evidence and user intent.
3. Normalize inputs into the common field contract in `references/field-contract.md`.
4. Load `references/feedback-input-contract.md` before using historical defects, production signals, CI runtime data, flaky metrics, or postmortems.
5. Apply the detailed schema and enums from `references/v2-output-contract.md`.
6. Produce the artifact using `references/output-template.md` and the richer examples in `references/real-examples.md`.
7. Emit `downstream_handoff` using the field-level map in `references/cross-skill-orchestration.md`.
8. Apply readiness inheritance from `references/readiness-inheritance.md`, confidence scoring from `references/confidence-scoring.md`, and finish with `self_check`.

## Event, SLA, and circuit hooks

See `references/n240-event-sla-hooks.md` for event emission, SLA queue hints, circuit hook patterns, and feedback contract handling.

## Example usage

### Scenario A — Standard PR-based trigger mapping

**Input**: 60 test cases (40 unit, 12 integration, 8 e2e); CI budget 15 min; high-risk diff in payment module.

**Output** (`pull_request` mode):
```yaml
trigger_recommendation:
  mode: pull_request
  ci_budget: 15min
  ci_total_budget_used: 14min
  on_push_to_feature_branch:
    - group: unit_tests
      count: 40
      estimated_time: 3min
      justification: Fast feedback on every commit
  on_pull_request:
    - group: unit_tests
      count: 40
      estimated_time: 3min
    - group: integration_payment
      count: 6
      estimated_time: 8min
      justification: DIFR-002 payment retry — must validate before merge
  on_merge_to_main:
    - group: full_regression
      count: 60
      estimated_time: 14min
  downstream_handoff:
    to: 088-test-automation-orchestration
    artifact: trigger_recommendation_table
```

> 更多场景示例（Scenario B/C/D）见 `references/example-io-v2.md`。


## Usage scenarios

- file_save: on-push triggers for immediate developer feedback.
- pull_request: select tests for pre-merge gating.
- merge_to_main: full suite triggers on merge.
- scheduled: nightly or weekly suite configuration.
- budget_optimization: rebalance triggers to fit CI time budget.


## Cross-skill integration map

| 上游 skill | 提供给 087 | 用途 |
|---|---|---|
| 077 diff-risk-review | `risk_level`, `changed_modules` | 高风险变更提升触发策略 |
| 084 regression-test-checklist-generation | `regression_checklist[]` | 清单规模决定触发阈值 |

| 下游 skill | 087 输出 | 如何使用 |
|---|---|---|
| 088 test-automation-orchestration | `trigger_strategy`, `pipeline_config` | 编排器的执行触发依据 |
| 093 quality-gate-check | `pipeline_trigger_result` | 门禁消费触发执行结果 |

**工作流位置**: 变更评估 → **087 触发策略** → 088 自动化编排 → 093 质量门禁。

## Standalone usage guide

**Minimum input:** list of test cases with type labels (unit/integration/e2e) and a CI budget. No upstream N240 artifacts required.

**Trigger decision tree (applied in budget_optimization mode):**

```
For each test case:
  IF type == unit           → ALWAYS on_push (fast feedback, cheap)
  IF type == integration:
    IF touches changed module → on_pull_request
    ELSE                     → scheduled_nightly
  IF type == e2e:
    IF is release/main branch → on_merge_to_main
    ELSE                     → scheduled_nightly (never on every push)
  IF total PR budget exceeded:
    Move lowest-risk integration tests → scheduled_nightly
    Keep at least 1 e2e smoke on PR   → mandatory
```

**Standalone output (budget_optimization with decision tree):**
```yaml
trigger_recommendation:
  mode: budget_optimization
  decision_tree_applied: true
  on_push:
    - group: unit_all
      count: 40
      estimated_time: 3min
      rule: all unit tests always on push
  on_pull_request:
    - group: unit_all
      count: 40
    - group: integration_affected_modules
      count: 8
      estimated_time: 7min
      note: Only modules in diff — decision tree applied
  on_merge_to_main:
    - group: e2e_critical
      count: 5
      estimated_time: 8min
  scheduled_nightly:
    - group: integration_unaffected
      count: 32
    - group: e2e_full
      count: 15
      estimated_time: 22min
      note: Moved from merge trigger to stay within budget
  total_pr_budget_used: 18min / 20min
  removed_from_pr:
    - group: integration_unaffected
      reason: not in diff scope; scheduled to nightly per decision tree
```

## Resilience and governance

**Circuit breaker**: If CI budget is exceeded on 3 consecutive builds due to trigger overlap, emit circuit_breaker: warn and recommend trigger deduplication.

**SLA guidance**: P0 when a high-risk area has no fast trigger; P1 when pyramid alignment is significantly off.

**Human review routing**: Set human_review_required: true when trigger mapping covers less than 80% of test cases or when CI budget conflicts are unresolvable automatically.

**Confidence scoring**: When confidence on scope selection or tier assignment falls below 0.7, mark `readiness: constrained` and require human confirmation before the artifact is consumed downstream.

**Escalation path**: When `readiness: blocked`, escalate to the QA lead and CI owner. For release-gate mode, also notify the release manager.

Traceability: each trigger recommendation references its source test_group_id and risk_ref from diff-risk-review.

## Auditable rules summary

- R01_trigger_event_mapped: every test group must map to a specific CI trigger event (push / PR / merge / schedule / manual); on_violation: reject.
- R02_budget_respected: total CI time estimate must stay within declared budget; on_violation: propose_split_or_parallel.
- R03_pyramid_aligned: trigger distribution must reflect test pyramid (more unit triggers, fewer e2e); on_violation: warn.
- R04_risk_weighted: high-risk areas from diff-risk-review must be covered by at least one fast trigger; on_violation: flag_gap.
- R05_no_redundant_triggers: the same test must not be triggered by multiple events without justification; on_violation: deduplicate.
- R06_decision_tree_documented: when budget optimisation is applied, the trigger decision tree logic must be included in the output; on_violation: add_decision_summary.
- R07_scheduled_isolation: tests moved to nightly/scheduled triggers must be explicitly listed and not silently removed from faster trigger groups; on_violation: flag_missing.

## Algorithm

1. Parse test pyramid distribution, regression plan, smoke checklist, and CI budget.
2. Map each test group to a trigger event (R01).
3. Estimate total CI time; adjust for parallelism (R02).
4. Check pyramid alignment (R03) and risk coverage (R04).
5. Deduplicate overlapping triggers (R05).
6. Emit `trigger_recommendation_table`, `ci_time_estimate`, `risk_coverage_map`.
7. Run `self_check`; set `readiness: blocked` if R01 fires.

## Quality bar

A good result maps each test group to the right trigger event, respects CI budget constraints, and avoids both under-testing (missing regressions) and over-testing (blocking pipelines). Recommendations must cite evidence from test pyramid, risk, and historical runtime data.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files

- `references/node-routing-contract.md`
- `references/feedback-input-contract.md`
- `references/confidence-scoring.md`
- `references/affected-test-detection-tools.md`
- `references/v2-output-contract.md`
- `references/v2-rules.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/template-skeleton.md`

- `references/example-io.md`
- `references/example-io-v2.md`