---
name: test-automation-trigger-recommendation
description: generate automation trigger recommendations from test cases, pyramid distribution, regression plans, smoke checklists, api script bundles, ci budget, team preferences, and diff risk evidence. use when deciding which tests run on file save, commit, push, pull request, nightly, pre-release, or n240 workflows before final pipeline orchestration.
---
# test-automation-trigger-recommendation

## Purpose and boundary

Deliver the N240 artifact `自动化触发建议.md` as an independently usable, workflow-aligned skill. Keep this skill generic enough for a single pull request, hotfix, release, module, endpoint group, or CI modernization task, while making its output stronger when composed with the other N240 skills.

Own: Recommend when to run each test suite using trigger tiers, cost budgets, fail-fast ordering, flaky policy, and gate mapping.

Do not claim runtime results unless execution evidence is supplied. Do not regenerate upstream artifacts when they are already provided; consume and reference them through stable IDs.

## Version and artifact contract

```yaml
skill_version: "2.2.1"
contract_version: "n240.trigger_strategy.v2.2"
artifact_target: "自动化触发建议.md"
workflow_node: "N240"
compatible_with:
  - n240.trigger_strategy.v2
consumed_signal_contracts:
  - feedback.n005.production_signal_package.v1
  - feedback.n250.defect_signal.v1
  - feedback.n300.ci_runtime_signal.v1
  - feedback.n300.flaky_test_signal.v1
produced_events:
  - produced.n240.trigger_strategy.v2.2
  - state.n240.trigger.readiness
  - exception.n240.trigger.contract_violation
downstream_consumers:
  - 088 orchestration
  - CI config generation
  - N260 gate
  - DevOps dashboard
```

Keep frontmatter limited to `name` and `description`; versioning lives in the body and output metadata so packaging validators remain compatible.

## Mode selection

Every result must start with `metadata.selected_mode`, `metadata.readiness`, `metadata.confidence`, and `metadata.evidence_profile`.

Allowed modes:
- `trigger_designer`: design a project-level multi-trigger strategy.
- `diff_analyzer`: select tests and blocking behavior for a specific diff.
- `release_gate_mode`: optimize trigger policy for release and post-deploy confidence.
- `cost_optimization`: reduce CI cost while preserving feedback and gate quality.

## Inputs

Required or strongly preferred inputs:
- `test_cases`
- `pyramid_distribution`
- `ci_budget`
- `team_preferences`

Optional enhancement inputs:
- regression_plan
- smoke_checklist
- test_scripts
- flaky metrics
- duration baselines
- release calendar

Standalone behavior:
- If only one diff, module, endpoint group, or release slice is available, still produce the same output shape.
- If a required input is missing, mark `readiness: constrained` or `blocked`, list missing evidence, and avoid overclaiming certainty.
- If upstream N240 artifacts are present, preserve their `suite_id`, `tc_id`, `script_id`, `api_ref`, `risk_ref`, and `task_ref` values.

## Required output sections

Default to YAML-friendly Markdown. The result must include:
- `metadata`
- `trigger_strategy`
- `triggers`
- `time_cost_analysis`
- `layered_strategy`
- `fail_fast_optimization`
- `resource_budget`
- `feedback_speed_targets`
- `failure_handling`
- `coverage_gates`
- `downstream_handoff`
- `self_check`

Metadata must include:
```yaml
metadata:
  skill_id: test-automation-trigger-recommendation
  skill_version: "2.2.1"
  contract_version: "n240.trigger_strategy.v2.2"
  selected_mode: string
  readiness: enum[pass, constrained, blocked]
  confidence: enum[high, medium, low]
  function_bias: trigger_policy_design
  stage_position: testing_and_qa.regression_and_automation.test_automation_trigger_recommendation
  workflow_node: N240
  node_artifact_target: "自动化触发建议.md"
  evidence_profile: {present: [], missing: [], assumptions: [], stale_or_conflicting_feedback: [], scoring: {base: 100, penalties_applied: [], final_score: 100}}
  consumed_signal_contracts: []
  confidence_scoring_policy: references/confidence-scoring.md
  feedback_used: {contracts: [], signal_ids: [], influence: {}, ignored_signals: []}
  produced_events: [produced.n240.trigger_strategy.v2.2, state.n240.trigger.readiness, exception.n240.trigger.contract_violation]
```

## Hard gates and v2 rules

Load and apply `references/v2-rules.md` before finalizing. For any rule with `on_violation: reject`, set `readiness: blocked` unless the user explicitly asks for a draft or advisory-only artifact. Put all rule outcomes in `self_check.passed_rules`, `self_check.failed_rules`, and `self_check.warnings`.

## Execution workflow

1. If multiple N240 skills could apply, consult `references/node-routing-contract.md`; otherwise run this skill standalone.
2. Select the mode from the available evidence and user intent.
3. Normalize inputs into the common field contract in `references/field-contract.md`.
4. Load `references/feedback-input-contract.md` before using historical defects, production signals, CI runtime data, flaky metrics, or postmortems.
5. Apply the detailed schema and enums from `references/v2-output-contract.md`.
6. Produce the artifact using `references/output-template.md` and the richer examples in `references/real-examples.md`.
7. Emit `downstream_handoff` using the field-level map in `references/cross-skill-orchestration.md`.
8. Apply readiness inheritance from `references/readiness-inheritance.md`, confidence scoring from `references/confidence-scoring.md`, and finish with `self_check`.

## Event, SLA, and circuit hooks

Emit the produced/state/exception events listed above in metadata. When a rule blocks release, add an `sla_queue_hint` with priority `P0`, `P1`, or `P2`, a recommended human action, and escalation target if known. When retry or loop behavior is discussed, cap it explicitly with `max_iter`, `cooldown`, and escalation guidance instead of leaving an unbounded loop. When feedback contracts are consumed, fill `feedback_used`, record stale/conflicting signals, and avoid letting low-confidence historical signals override current release evidence.

## Reference files

- `references/node-routing-contract.md`
- `references/feedback-input-contract.md`
- `references/confidence-scoring.md`
- `references/affected-test-detection-tools.md`
- `references/v2-output-contract.md`
- `references/v2-rules.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
