# Smoke rules v2.2.1

| Rule | Requirement | on_violation |
|---|---|---|
| R01_under_5_minutes | Total duration target must be <= 5 minutes unless explicitly constrained. | reject |
| R02_health_probes_required | SS1, SS2, and SS3 must be considered and declared. | reject |
| R03_prod_smoke_read_only | Production smoke checks must be read-only and no-side-effect. | reject |
| R04_fast_fail_on_critical | SS1 and SS2 failures must stop critical rollout. | reject |
| R05_parallel_execution | Parallelize independent checks or explain why not. | auto_optimize |
| R06_env_variations | Environment differences must be explicit. | reject |
| R07_failure_triggers_alert | Any failed critical smoke check must trigger alert and deployment block/rollback guidance. | reject |


## v2.2.1 reactive addendum rules

| Rule | Requirement | on_violation |
|---|---|---|
| R09_feedback_contracts_defined | Every value in `consumed_signal_contracts` and `feedback_used.contracts` must be defined in `references/feedback-input-contract.md`. | reject |
| R10_feedback_used_traceable | When feedback signals influence scope, scripts, triggers, stages, retries, gates, or confidence, output `feedback_used.contracts`, `feedback_used.signal_ids`, and `feedback_used.influence`. | reject |
| R11_confidence_score_calculated | Apply `references/confidence-scoring.md`, include final score and penalties, and map score to `confidence`. | reject |
| R12_stale_or_conflicting_feedback_handled | Stale, conflicting, or low-confidence feedback must be recorded in `ignored_signals` or `evidence_profile.stale_or_conflicting_feedback` before it can affect decisions. | reject |
