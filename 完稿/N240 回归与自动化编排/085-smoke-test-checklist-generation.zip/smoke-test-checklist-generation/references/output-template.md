# Smoke output template

```yaml
metadata:
  skill_id: smoke-test-checklist-generation
  skill_version: "2.2.1"
  contract_version: n240.smoke_checklist.v2.2
  selected_mode: release_gate_smoke
  readiness: pass
  confidence: high
  produced_events: [produced.n240.smoke_checklist.v2.2]

smoke_checklist:
  checklist_id: SMK-001
  smoke_scope:
    scopes:
      SS1_health_endpoints:
        checks:
          - endpoint: /health
            expected_status: 200
            timeout: 5s
      SS4_core_api_smoke:
        checks:
          - api: /api/v1/orders
            method: GET
            expected_status: 200
            max_latency: 500ms
  five_minute_principle:
    total_duration_target: 5min
    parallel_execution: true
  fast_fail_strategy:
    fail_fast_on_categories: [SS1_health, SS2_database]

downstream_handoff:
  consumed_by:
    - target: 088 orchestration
      fields: [smoke_checklist.checklist_id, smoke_scope.scopes, failure_response]
```


## v2.2 output fields

```yaml
feedback_used:
  contracts: []
  signal_ids: []
  influence:
    added_scopes_or_tests: []
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals: []
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied: []
    final_score: integer
```
