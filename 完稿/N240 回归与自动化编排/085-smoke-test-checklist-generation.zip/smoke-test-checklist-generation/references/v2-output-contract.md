# Smoke output contract v2.2.1

## Required shape

```yaml
smoke_checklist:
  checklist_id: "SMK-001"
  smoke_scope:
    scopes:
      SS1_health_endpoints: {required: true, checks: array}
      SS2_database_connectivity: {required: true, checks: array}
      SS3_external_dependencies: {required: true, checks: array}
      SS4_core_api_smoke: {required: true, checks: array}
      SS5_critical_user_journey: {required: true, journey_summary: object}
      SS6_data_integrity_sanity: {required: false, checks: array}
  five_minute_principle:
    total_duration_target: 5min
    time_allocation:
      SS1_health: 30s
      SS2_database: 30s
      SS3_external: 1min
      SS4_core_api: 2min
      SS5_journey: 1min
      SS6_data_integrity: 30s
    parallel_execution: true
    stop_on_critical_fail: true
  fast_fail_strategy:
    fail_fast_on_categories: [SS1_health, SS2_database]
    aggregation_rule: {all_critical_pass_required: true, partial_ok_threshold: "90% of SS4"}
  environment_variations:
    dev: {scope_included: [SS1, SS2, SS4], reduced_checks: true}
    test: {scope_included: [SS1, SS2, SS3, SS4, SS5]}
    staging: {scope_included: all, production_like: true}
    prod: {scope_included: all, safety: {read_only_probes: true, no_side_effects: true}}
  health_probes:
    liveness_probe: object
    readiness_probe: object
    startup_probe: object
    deep_health: object
```

## Scope semantics

- `SS1_health_endpoints`: `/health`, `/ready`, `/metrics`, or platform equivalents.
- `SS2_database_connectivity`: DB reachability and pool sanity, not deep data validation.
- `SS3_external_dependencies`: critical dependency pings, handshakes, or safe API calls.
- `SS4_core_api_smoke`: smallest set of core APIs proving service usability.
- `SS5_critical_user_journey`: minimum journey steps that prove user value.
- `SS6_data_integrity_sanity`: low-cost sanity queries; advisory unless specified.


## v2.2.1 additions

```yaml
contract_version: "n240.smoke_checklist.v2.2"
compatibility:
  backward_compatible_with: "n240.smoke_checklist.v2"
  change_type: additive
feedback_inputs:
  consumed_signal_contracts:
    - feedback.n005.production_signal_package.v1
    - feedback.n300.monitoring_signal.v1
    - feedback.n280.deployment_signal.v1
    - feedback.n290.acceptance_signal.v1
  feedback_used_required_when_signals_used: true
confidence_scoring:
  policy_ref: references/confidence-scoring.md
  high_min_score: 85
  medium_min_score: 60
  low_below: 60
node_routing:
  policy_ref: references/node-routing-contract.md
```
