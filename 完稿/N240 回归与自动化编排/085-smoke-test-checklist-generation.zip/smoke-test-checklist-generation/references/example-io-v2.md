# N240 示例输入输出 v2（扩展场景）

## 示例 3：触发策略推荐（test-automation-trigger-recommendation）

### 输入
- 60个测试（40单元，12集成，8 e2e）；CI预算15分钟

### 输出
```yaml
trigger_recommendation:
  on_pull_request:
    - group: unit_tests
      count: 40
      estimated_time: 3min
    - group: integration_payment
      count: 6
      estimated_time: 8min
  ci_total_budget_used: 11min / 15min
```

## 示例 4：CI流水线编排（test-automation-orchestration）

### 输入
- 38个自动化测试，GitHub Actions，回归计划已就绪

### 输出
```yaml
# .github/workflows/test-pipeline.yml（骨架）
jobs:
  lint:
    runs-on: ubuntu-latest
  unit:
    needs: lint
    timeout-minutes: 5
  integration:
    needs: unit
    timeout-minutes: 10
  notify-on-failure:
    if: failure()
    needs: [unit, integration]
```

## 085 扩展示例输入输出

### Scenario B — Incident recovery check (auth service outage resolved)

**Input**: Auth service recovered from P0 outage; verify core paths before traffic restore.

**Output** (`incident_recovery` mode):
```yaml
smoke_checklist:
  service: auth-service
  mode: incident_recovery
  time_budget: 5min
  priority_override: P0_paths_only
  items:
    - id: SMK-R001
      journey: Login with valid credentials
      check: POST /auth/login returns 200 + valid JWT
      pass_criterion: HTTP 200, token.exp > now + 3600s
    - id: SMK-R002
      journey: Token refresh works
      check: POST /auth/refresh returns 200
      pass_criterion: HTTP 200, new_token present
    - id: SMK-R003
      journey: Logout invalidates session
      check: POST /auth/logout returns 200
      pass_criterion: HTTP 200, subsequent requests return 401
  readiness: ready
  downstream_handoff:
    to: 084-regression-test-checklist-generation
    signal: smoke_passed — proceed to full regression
```

### Scenario C — Pre-canary gate (feature flag rollout)

**Input**: Canary deployment of recommendation engine v3.1 to 5% traffic; must validate before increasing traffic.

**Output** (`pre_canary` mode):
```yaml
smoke_checklist:
  service: recommendation-engine
  mode: pre_canary
  canary_percentage: 5%
  items:
    - id: SMK-C001
      journey: Recommendations load without error
      check: GET /api/v1/recommendations?userId=test returns 200
      pass_criterion: HTTP 200, items.length >= 3
    - id: SMK-C002
      journey: No latency regression vs baseline
      check: p95 latency < 300ms over 50 requests
      pass_criterion: p95 < 300ms
  readiness: ready
```

### Scenario D — Standalone degraded (service name only)

**Input**: No journey definitions available; only service name known.

**Output** (`post_deploy` mode, degraded):
```yaml
smoke_checklist:
  service: billing-service
  mode: post_deploy
  readiness: constrained
  pending_journey_confirmation: true
  time_budget: 5min
  items:
    - id: SMK-001
      journey: Primary API endpoint responds
      check: GET /health → 200
      pass_criterion: HTTP 200 within 2s
      source: inferred_from_service_name
    - id: SMK-002
      journey: Authentication accepted
      check: POST /auth/login with test credentials
      pass_criterion: No 5xx errors
      source: inferred_standard_pattern
  note: Journeys inferred — confirm with service owner before production use
```

