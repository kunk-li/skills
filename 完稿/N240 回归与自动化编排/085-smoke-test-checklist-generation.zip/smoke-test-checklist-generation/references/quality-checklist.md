
# Quality checklist v2.1

Before finalizing output, verify:

- Metadata includes `skill_version`, `contract_version`, `selected_mode`, `readiness`, `confidence`, and `produced_events`.
- All IDs are stable and reusable by downstream skills.
- Required v2 enums are used exactly as defined in `v2-output-contract.md`.
- All hard rules from `v2-rules.md` are evaluated in `self_check`.
- `downstream_handoff` maps fields to explicit consumers.
- Missing evidence is represented as `constrained` or `blocked`, not silently ignored.
- Events, SLA tags, and escalation hints are present when relevant.

## Skill-specific checks

- SS1-SS3 health, DB, and dependency checks are present.
- Total smoke target is at or below 5 minutes unless explicitly constrained.
- Production checks are read-only and no-side-effect.
- Failure response includes alert, block, and rollback hooks where applicable.
