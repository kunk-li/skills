# Smoke examples

## Example: canary switch for order service

```yaml
smoke_checklist:
  checklist_id: SMK-ORDER-CANARY-009
  smoke_scope:
    scopes:
      SS1_health_endpoints:
        checks:
          - endpoint: /health/ready
            expected_status: 200
            timeout: 5s
      SS2_database_connectivity:
        checks:
          - probe: SELECT 1
            timeout: 3s
      SS3_external_dependencies:
        checks:
          - dependency: payment-gateway
            probe_method: api_call
            fallback_ok: false
      SS5_critical_user_journey:
        journey_summary:
          name: simplified order read journey
          steps: [GET /api/v1/users/me, GET /api/v1/orders]
  environment_variations:
    prod:
      safety:
        read_only_probes: true
        no_side_effects: true
  failure_response:
    immediate_actions: [alert_oncall, block_further_deployment, auto_rollback_trigger]
```


## v2.2 feedback example fragment

```yaml
feedback_used:
  contracts:
    - feedback.n250.defect_signal.v1
  signal_ids:
    - DEFECT-HIST-001
  influence:
    added_scopes_or_tests:
      - "added historical hotspot coverage for payment retry path"
    changed_priorities: []
    changed_triggers_or_stages: []
  ignored_signals:
    - signal_id: OLD-FLAKY-2019
      reason: "stale signal over 90 days and no recent recurrence"
evidence_profile:
  stale_or_conflicting_feedback: []
  scoring:
    base: 100
    penalties_applied:
      - "missing_traceability_id: -15"
    final_score: 85
```
