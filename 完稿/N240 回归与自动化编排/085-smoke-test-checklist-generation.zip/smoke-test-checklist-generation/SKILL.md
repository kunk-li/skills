---
name: smoke-test-checklist-generation
description: generate fast smoke test checklists from critical user journeys, core api specs, deployment targets, environment constraints, and diff risk evidence. use for post-deploy validation, pre-canary switch checks, incident recovery confirmation, or n240 workflows that need health probes, critical journey smoke, five-minute budgets, and release gate handoff. trigger on any request to build a smoke test list, validate a deployment, create post-deploy checks, or confirm a service is alive after release. [N240]
---
# smoke-test-checklist-generation

## Role and boundary

Generate a **time-boxed smoke validation checklist** confirming that a deployed service is alive and its critical user journeys are functional. Smoke tests are **not regression tests**: they cover only the highest-priority happy-paths and must complete within a declared time budget (typically 5–15 min).

**Key distinction from 084 regression-test-checklist-generation**:
- 084 selects *which tests to run* from an existing suite based on change impact.
- 085 defines *what to verify* immediately after deployment to confirm the system is operational — often before any regression suite runs.
- 085 items are binary (pass/fail observable in <2 min each); 084 items reference tc_ids and automation tiers.

This skill aligns to testing & qa → regression and automation planning → 冒烟测试清单.csv. It delivers the workflow-aligned smoke validation artifact for N240.

### Boundary
- Focus on planning artifacts, not runtime execution results.
- Consume upstream N230 and N240 artifacts by reference; do not regenerate them.
- Do not fabricate test results unless execution evidence is supplied.


## Routing decision table

| Situation | Action |
|---|---|
| Post-deployment validation | Use `post_deploy`; include only binary pass/fail items ≤ 2 min each |
| Pre-canary traffic switch | Use `pre_canary`; focus on latency and error rate checks |
| Incident recovery | Use `incident_recovery`; include only P0 critical journeys |
| No journey definitions available | Infer from service name; set `pending_journey_confirmation` |
| Time budget not specified | Default to 10-minute budget; flag `pending_budget_confirmation` |

## Version and artifact contract

```yaml
skill_version: "2.2"
schema_version: "n240.smoke-test-checklist.v2.2"
contract_version: "n240.smoke_checklist.v2.2"
artifact_target: "冒烟测试清单.csv"
workflow_node:
node_artifact_target: "n240.smoke_checklist"
function_bias: "planning" "N240"
compatible_with:
  - n240.smoke_checklist.v2
consumed_signal_contracts:
  - feedback.n005.production_signal_package.v1
  - feedback.n300.monitoring_signal.v1
  - feedback.n280.deployment_signal.v1
  - feedback.n290.acceptance_signal.v1
produced_events:
  - produced.n240.smoke_checklist.v2.2
  - state.n240.smoke.readiness
  - exception.n240.smoke.contract_violation
downstream_consumers:
  - 087 trigger strategy
  - 088 orchestration
  - N280 deployment execution
  - N290 acceptance
  - N300 monitoring
```

Keep frontmatter limited to `name` and `description`; versioning lives in the body and output metadata so packaging validators remain compatible.

## Mode selection

Every result must start with `metadata.selected_mode`, `metadata.readiness`, `metadata.confidence`, and `metadata.evidence_profile`.

Allowed modes:
- `health_only`: produce minimal liveness/readiness/startup/deep health probes.
- `production_probe`: create safe read-only production smoke checks.
- `release_gate_smoke`: build a blocking smoke checklist for release or canary decisions.

## Inputs

Required or strongly preferred inputs:
- `critical_user_journeys`
- `api_specs`
- `deployment_target`

Optional enhancement inputs:
- dependency map
- database probes
- deployment strategy
- feature flags
- post-deploy metric baselines

Standalone behavior:
- If only one diff, module, endpoint group, or release slice is available, still produce the same output shape.
- If a required input is missing, mark `readiness: constrained` or `blocked`, list missing evidence, and avoid overclaiming certainty.
- If upstream N240 artifacts are present, preserve their `suite_id`, `tc_id`, `script_id`, `api_ref`, `risk_ref`, and `task_ref` values.


### Degradation rules

- If critical journey definitions are unavailable, derive smoke items from API specs or deployment targets and mark them `pending_journey_confirmation`.
- If time budget is unspecified, default to a 10-minute constraint and mark it `pending_budget_confirmation`.
- Keep the output schema stable even with minimal inputs; prefer explicit `pending_*` fields over silent omissions.


## Core output contract

Default to YAML-friendly Markdown and follow `references/output-template.md`.

The result must include:
- metadata (selected_mode, readiness, time_estimate, environment_metadata)
- smoke_checklist[]
- time_estimate
- environment_metadata
- downstream_handoff
- self_check
- `readiness: ready | constrained | blocked`

## Hard gates and v2 rules

Load and apply `references/v2-rules.md` before finalizing. For any rule with `on_violation: reject`, set `readiness: blocked` unless the user explicitly asks for a draft or advisory-only artifact. Put all rule outcomes in `self_check.passed_rules`, `self_check.failed_rules`, and `self_check.warnings`.

## Execution workflow

1. If multiple N240 skills could apply, consult `references/node-routing-contract.md`; otherwise run this skill standalone.
2. Select the mode from the available evidence and user intent.
3. Normalize inputs into the common field contract in `references/field-contract.md`.
4. Load `references/feedback-input-contract.md` before using historical defects, production signals, CI runtime data, flaky metrics, or postmortems.
5. Apply the detailed schema and enums from `references/v2-output-contract.md`.
6. Produce the artifact using `references/output-template.md` and the richer examples in `references/real-examples.md`.
7. Emit `downstream_handoff` using the field-level map in `references/cross-skill-orchestration.md`.
8. Apply readiness inheritance from `references/readiness-inheritance.md`, confidence scoring from `references/confidence-scoring.md`, and finish with `self_check`.

## Event, SLA, and circuit hooks

See `references/n240-event-sla-hooks.md` for event emission, SLA queue hints, circuit hook patterns, and feedback contract handling.

## Example usage

### Scenario A — Post-deploy validation (payment service v2.4.1)

**Input**: Deployment of payment-service v2.4.1 to production; 10-minute smoke budget.

**Output** (`post_deploy` mode):
```yaml
smoke_checklist:
  service: payment-service
  version: v2.4.1
  environment: production
  time_budget: 10min
  mode: post_deploy
  items:
    - id: SMK-001
      journey: User can complete checkout payment
      check: POST /api/v1/payments returns 200 within 2s
      pass_criterion: HTTP 200 + transaction_id present
      estimated_time: 1min
    - id: SMK-002
      journey: Payment history visible
      check: GET /api/v1/payments/history returns non-empty list
      pass_criterion: HTTP 200 + items.length > 0
      estimated_time: 30s
    - id: SMK-003
      journey: Refund initiation accepted
      check: POST /api/v1/refunds returns 202
      pass_criterion: HTTP 202 + refund_id present
      estimated_time: 1min
  total_estimated_time: 8min
  readiness: ready
  downstream_handoff:
    to: 093-quality-gate-check
    signal: smoke_passed
```

> 更多场景示例（Scenario B 故障恢复 / Scenario C 预金丝雀）见 `references/example-io-v2.md`。

## Usage scenarios

- `post_deploy`: validate a deployment immediately after it completes; binary pass/fail items only.
- `pre_canary`: verify service readiness before shifting canary traffic.
- `incident_recovery`: confirm critical P0 journeys are restored after an incident.
- `quick_check`: abbreviated smoke for hotfix/patch releases with tight time windows.
- `standalone_inferred`: generate smoke items from service name alone when no journey definitions exist.

## Cross-skill integration map

| From skill | Provides to 085 | How used |
|---|---|---|
| 084 regression-test-checklist-generation | `regression_scope[]` | Determines which modules are in scope after smoke passes |
| 087 test-automation-trigger-recommendation | `trigger_strategy` | Determines when smoke runs (post_deploy vs pre_merge) |
| N230 test-case-generation | `critical_journey_ids[]` | Seeds smoke item selection with known P0 test cases |
| 093 quality-gate-check | Consumes `smoke_passed` signal | Smoke result is one gate dimension |

**Downstream chain:** Deploy event → **085 smoke-checklist** → `smoke_passed` → 084 regression scope → 087/088 pipeline → 093 gate.

## Standalone usage guide

**Key distinction from 084 regression-test-checklist-generation:**
- 084 selects *which existing test cases to run* based on change impact analysis.
- 085 defines *what to verify immediately after deployment* to confirm the service is alive — binary checks executable in <2 min each, independent of any test suite.

**Minimum input:** deployment event + service name. No N230 or N240 artifacts required.

**Standalone decision path:**
1. If no journey definitions → infer from service name; set `pending_journey_confirmation: true`.
2. Set `readiness: constrained`; never fabricate pass/fail results.
3. Always include at least one health-check item and one auth item.

**Minimum viable output:**
```yaml
smoke_checklist:
  service: auth-service
  mode: post_deploy
  readiness: constrained
  pending_journey_confirmation: true
  time_budget: 5min
  items:
    - id: SMK-001
      journey: Primary API endpoint responds
      check: GET /health → 200
      pass_criterion: HTTP 200 within 2s
      source: inferred_from_service_name
  note: Journeys inferred — confirm with service owner before production use
```

## Resilience and governance

**Circuit breaker**: If post-deploy smoke consistently times out or fails on the same check across 3 consecutive deployments, emit `circuit_breaker: open` and block the deploy pipeline until the check is fixed.

**SLA guidance**: P0 when a critical journey item fails; P1 when time budget is exceeded.

**Human review routing**: Set `human_review_required: true` when any smoke item cannot be assigned a binary pass/fail criterion.

**Confidence scoring**: When confidence on scope selection falls below 0.7, mark `readiness: constrained` and require human confirmation before the artifact is consumed downstream.

**Escalation path**: When `readiness: blocked`, escalate to QA lead and CI owner. For release-gate mode, also notify the release manager.

Traceability: each smoke item references its source `critical_journey_id` and target `environment_id` for audit.

## Auditable rules summary

- R01_time_budget_respected: every checklist item must be executable within the declared smoke time budget; on_violation: remove_or_flag.
- R02_core_journey_first: critical user journeys must appear before supplemental checks; on_violation: reorder.
- R03_no_deep_regression: smoke items must not duplicate full regression scope; on_violation: remove.
- R04_environment_explicit: target environment and base URL must be declared in metadata; on_violation: reject.
- R05_binary_pass_fail: every item must have a clear binary pass/fail criterion, not a subjective observation; on_violation: rewrite.
- R06_no_regression_duplication: smoke items must not duplicate items already covered by the regression scope from 084; on_violation: remove_duplicate.
- R07_incident_recovery_p0_only: in incident_recovery mode, only P0 critical journeys are included; on_violation: downgrade_to_supplemental.

## Algorithm

1. Parse critical journeys, API specs, deployment targets, and time budget.
2. Select the smallest set of checks that confirm core functionality is alive (R03).
3. Order by journey priority (R02); enforce time budget per item (R01).
4. Assign binary pass/fail criteria to each item (R05).
5. Declare environment and base URL (R04).
6. Emit `smoke_checklist[]`, `time_estimate`, `environment_metadata`.
7. Run `self_check`; set `readiness: blocked` if R04 or R05 fires.

## Quality bar

A good smoke checklist is short, fast, and immediately usable by the post-deploy team. Every item must be verifiable within the declared time budget, have a binary pass/fail criterion, and confirm the service is alive — not a substitute for full regression testing.

## 版本号说明

`skill_version: "2.2"` — 全批统一的 SKILL.md 内容版本；
`schema_version` — 本 skill 输出契约版本，仅本 skill 变更时递增；
`contract_version` — 节点路由契约版本。
完整版本号语义见 `references/template-skeleton.md`。

## Reference files

- `references/node-routing-contract.md`
- `references/feedback-input-contract.md`
- `references/confidence-scoring.md`
- `references/v2-output-contract.md`
- `references/v2-rules.md`
- `references/output-template.md`
- `references/field-contract.md`
- `references/cross-skill-orchestration.md`
- `references/quality-checklist.md`
- `references/readiness-inheritance.md`
- `references/common-failure-modes.md`
- `references/real-examples.md`
- `references/n240-event-sla-hooks.md`
- `references/example-io.md`
- `references/example-io-v2.md`
- `references/template-skeleton.md`
