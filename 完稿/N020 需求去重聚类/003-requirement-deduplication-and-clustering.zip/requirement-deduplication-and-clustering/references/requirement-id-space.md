# Requirement-definition id space

## Artifact id

Use `DEDUPLICATION-ARTIFACT-<scope>-<yyyymm>` for sidecar `artifact_id`.

Example: `DEDUPLICATION-ARTIFACT-checkout-202605`.

## Row or section id

Primary id field: `cluster_id`.
Expected pattern: `^RCL-[a-z0-9_]+-\d{3,}$`.
Example: `RCL-checkout-001`.

## Multi-value cells

Use `|` as the delimiter in CSV multi-value cells. Do not use bare commas inside machine-readable id lists.
