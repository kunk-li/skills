# Real Examples / 真实示例参考

These examples illustrate correct clustering decisions and common edge cases.

---

## Example 1: Exact duplicate across two sources

**Input**: REQ-checkout-003 ("Mobile checkout should preserve invoice title after address edit") and REQ-checkout-001 ("Checkout should preserve selected invoice title after address edit") describe the same behavior.

**Correct pattern**:
```
cluster_id: CLU-checkout-001
duplicate_type: exact
member_requirement_ids: REQ-checkout-001|REQ-checkout-003
canonical_requirement_id: REQ-checkout-001
preserved_differences: REQ-checkout-003 is mobile-specific; REQ-checkout-001 covers all platforms. Canonical covers both.
overmerge_risk: low
```

---

## Example 2: Theme-related — same feature area, different scope

**Input**: REQ-search-001 ("Search is slow") and REQ-search-002 ("Search results include archived items").

**Correct pattern**:
```
cluster_id: CLU-search-001
duplicate_type: theme_related
member_requirement_ids: REQ-search-001|REQ-search-002
canonical_requirement_id: none
preserved_differences: REQ-search-001 is a performance problem; REQ-search-002 is a relevance/filter problem. Do not merge into one requirement.
overmerge_risk: high
open_questions: Are these caused by the same underlying search service or different components?
```

**Anti-pattern to avoid**: Merging performance and relevance into "improve search" — this hides two distinct problems with potentially different solutions.

---

## Example 3: Overmerge risk review

**Input**: Six requirements all mention "dashboard" but span different user roles and data types.

**Correct pattern**:
```
overmerge_risk: high
open_questions: Do all six describe the same dashboard page or different dashboards? Confirm with product before merging.
duplicate_type: overmerge_risk_review
```
