# Selected-mode decision tree

Choose exactly one selected_mode:

- `exact_duplicate_scan`: use when exact duplicate scan is the closest operating mode.
- `theme_clustering`: use when theme clustering is the closest operating mode.
- `source_aware_deduplication`: use when source aware deduplication is the closest operating mode.
- `overmerge_risk_review`: use when overmerge risk review is the closest operating mode.
- `partial_pool_triage`: use when partial pool triage is the closest operating mode.

Validation rule: metadata `selected_mode` must match one of the modes above and the schema enum.
