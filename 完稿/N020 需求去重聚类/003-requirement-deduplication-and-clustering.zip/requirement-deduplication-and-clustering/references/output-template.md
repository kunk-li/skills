# Output template

Produce `requirement-clusters.csv` as CSV.

```csv
cluster_id,representative_requirement,member_requirement_ids,relation_strength,merge_recommendation,preserved_differences,evidence_refs,confidence,open_questions,theme,source_count,duplicate_count,cluster_rationale,risk_of_overmerge
```

Rules:
- Keep ids stable.
- Use `|` in multi-value cells.
- Keep evidence and uncertainty explicit.
- Do not add private workflow node ids.
