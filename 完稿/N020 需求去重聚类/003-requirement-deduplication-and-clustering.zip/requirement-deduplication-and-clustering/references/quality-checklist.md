# Quality checklist

First apply the common checklist in `shared-requirement-definition-contract.md`.

## Skill-specific checks

- Relation strength is not overstated.
- Preserved differences are visible.
- Cluster ids and member ids are stable.

- Metadata `workflow_node` is a real host workflow identifier, not a placeholder.
- Anti-patterns AP-01 through AP-10 and the five skill-specific AP rows have been checked.
