---
name: requirement-deduplication-and-clustering
display_name: 需求去重聚类 / Requirement Deduplication and Clustering
description: deduplicate and cluster requirement items by exact duplication, high similarity, or theme-level relation while preserving source evidence and differences. use when requirement lists, tickets, notes, or backlog exports need traceable clusters and over-merge protection for context enrichment, user research, prioritization, or requirement writing. not for final scope selection or roadmap ranking.
---

# Requirement Deduplication And Clustering / 需求去重聚类

## Contract baseline

- contract_version: `requirement-definition-suite-v1.3.0`
- skill_id: `requirement-deduplication-and-clustering`
- schema: `requirement.deduplication.v4`
- artifact_target: `requirement-clusters.csv`
- selected_mode: `exact_duplicate_scan / theme_clustering / source_aware_deduplication / overmerge_risk_review / partial_pool_triage`
- composable_with: `requirement-collection-consolidation, requirement-context-enrichment, user-pain-point-analysis, user-journey-analysis`
- downstream_route_tokens: `context_enrichment, planning_intake, human_review`

This skill is self-contained and can run directly on partial input. It may compose with sibling skills, but it must not require them as prerequisites or encode private workflow node ids.

## Use this skill to

- Convert messy input into the skill's contracted deliverable while keeping source traceability.
- Preserve uncertainty, conflict, missing context, and evidence boundaries.
- Produce artifacts that can be validated locally before handoff.

## Do not use this skill to

- choosing a winning requirement; hiding preserved differences; scoring business value.
- Invent facts, user needs, source ids, evidence, priorities, or delivery commitments.
- Replace downstream planning, technical design, quality gates, or final approval.

## Required row contract

The following fields are required in every `requirement-clusters.csv` row. Use `|` for multi-value cells.

| field | required | enum / format |
| --- | --- | --- |
| `cluster_id` | required | `CLU-<scope>-<nnn>` |
| `cluster_label` | required | short theme label |
| `member_requirement_ids` | required | `\|`-separated `REQ-*` ids |
| `duplicate_type` | required | `exact\|high_similarity\|theme_related\|overmerge_risk` |
| `canonical_requirement_id` | required | representative member id or `none` |
| `preserved_differences` | required | free text describing meaningful differences |
| `source_ids` | required | `\|`-separated source anchors |
| `confidence` | required | `high\|medium\|low\|needs_human_review` |
| `overmerge_risk` | required | `none\|low\|medium\|high` |
| `open_questions` | required | free text or `none` |
| `evidence_refs` | recommended | `\|`-separated evidence anchors |
| `notes` | recommended | additional context |

## Required output

Produce `requirement-clusters.csv` as CSV using `references/field-contract.yaml`; use `|` for multi-value cells.

Always produce a sidecar metadata file with the same basename and `.metadata.yaml` suffix. Metadata must include `artifact_id`, `skill_id`, `contract_version`, `schema`, `workflow_node`, `selected_mode`, `readiness`, `confidence`, `source_artifacts`, `evidence_refs`, and `downstream_routes`.

## Workflow

1. Identify source materials, evidence anchors, roles, scope, dates, and uncertainty.
2. Select one `selected_mode` using `references/selected-mode-decision-tree.md`.
3. Read `references/anti-patterns.md` and avoid the listed failure modes.
4. Produce `requirement-clusters.csv` using the Required row contract table above and `references/field-contract.yaml`.
5. Produce sidecar metadata using `references/metadata-schema.json`.
6. Run `python3 scripts/validate_artifact.py <artifact>` and `python3 scripts/validate_metadata.py <artifact.metadata.yaml>`. Use `python3 scripts/validate_artifact.py --summary` to inspect the local row/section contract.
7. Run `python3 scripts/check_node_neutrality.py <artifact>` and `python3 scripts/check_order_neutrality.py <artifact>` to confirm no private workflow IDs or order-binding fields leaked in.
8. Run `python3 scripts/validate_release_consistency.py .` before packaging
9. To validate the full 5-skill requirement-definition chain, run `python3 scripts/validate_requirement_definition_chain.py --collection <002.metadata.yaml> --dedup <003.metadata.yaml> --context <004.metadata.yaml> --pain <005.metadata.yaml> --journey <006.metadata.yaml>`. See `examples/integration/README.md` for a ready-made checkout example. or final handoff when working inside the skill directory.

## Mode selection quick guide

| signal in input | recommended mode |
| --- | --- |
| Many exact-text duplicates | `exact_duplicate_scan` |
| Diverse wordings of same need | `theme_clustering` |
| Different sources for same requirement | `source_aware_deduplication` |
| Risk that merging loses nuance | `overmerge_risk_review` |
| Sparse or low-evidence pool | `partial_pool_triage` |

## References

Consult these files only when needed:

- `references/shared-requirement-definition-contract.md` for common contract, route tokens, and quality baseline.
- `references/requirement-id-space.md` for artifact and row id naming.
- `references/field-contract.yaml` for row/schema fields.
- `references/output-template.md` for default deliverable structure.
- `references/metadata-schema.json` for metadata sidecar contract.
- `references/selected-mode-decision-tree.md` for mode selection.
- `references/anti-patterns.md` for common mistakes and correct patterns.
- `references/common-failure-modes.md` for debugging weak outputs.
- `examples/upstream/` for generic upstream cascade samples when testing intake from feedback-loop artifacts.
- `references/quality-checklist.md` for final self-check.

## Boundary rules

- Use `composable_with` to describe optional sibling composition; do not use prerequisite/order fields.
- Use semantic route tokens such as `deduplication`, `context_enrichment`, `pain_analysis`, `journey_analysis`, `planning_intake`, or `human_review`.
- Keep private host workflow mappings outside the skill package.
- Prefer a partial but well-labeled result over an overconfident complete-looking artifact.
