#!/usr/bin/env python3
import re, sys
from pathlib import Path
CONFIG={'display': 'Requirement Deduplication And Clustering', 'cn': '需求去重与聚类', 'family_role': 'deduplication', 'artifact_type': 'csv', 'primary_artifact': 'requirement-clusters.csv', 'schema': 'requirement.deduplication.v4', 'id_field': 'cluster_id', 'id_re': '^RCL-[a-z0-9_]+-\\d{3,}$', 'required': ['cluster_id', 'representative_requirement', 'member_requirement_ids', 'relation_strength', 'merge_recommendation', 'preserved_differences', 'evidence_refs', 'confidence', 'open_questions'], 'recommended': ['theme', 'source_count', 'duplicate_count', 'cluster_rationale', 'risk_of_overmerge'], 'enums': {'relation_strength': ['exact_duplicate', 'highly_similar', 'theme_related', 'needs_human_review'], 'merge_recommendation': ['merge', 'keep_separate', 'split_cluster', 'human_review'], 'confidence': ['high', 'medium', 'low', 'needs_human_review']}, 'modes': ['exact_duplicate_scan', 'theme_clustering', 'source_aware_deduplication', 'overmerge_risk_review', 'partial_pool_triage'], 'description': 'deduplicate and cluster requirement items by exact duplication, high similarity, or theme-level relation while preserving source evidence and differences. use when requirement lists, tickets, notes, or backlog exports need traceable clusters and over-merge protection for context enrichment, user research, prioritization, or requirement writing. not for final scope selection or roadmap ranking.', 'route_tokens': ['context_enrichment', 'planning_intake', 'human_review'], 'composable': ['requirement-collection-consolidation', 'requirement-context-enrichment', 'user-pain-point-analysis', 'user-journey-analysis'], 'not_for': ['choosing a winning requirement', 'hiding preserved differences', 'scoring business value'], 'skill_id': 'requirement-deduplication-and-clustering', 'contract_version': 'requirement-definition-suite-v1.3.0'}
PRIVATE_NODE_RE = re.compile(r"\b[Nn]\d{3}\b")
RETIRED_VERSION_TOKENS = (
    "requirement-definition-suite-v" + "1.1.0",
    "requirement-definition-suite-v" + "1.2.0",
    "requirement.collection.v" + "2", "requirement.collection.v" + "3",
    "requirement.deduplication.v" + "2", "requirement.deduplication.v" + "3",
    "requirement.context.v" + "2", "requirement.context.v" + "3",
    "user.pain-point.v" + "2", "user.pain-point.v" + "3",
    "user.journey.v" + "2", "user.journey.v" + "3",
)

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    args=ap.parse_args(); d=Path(args.skill_dir); p=d/'SKILL.md'
    errors=[]
    if not p.exists(): errors.append('SKILL.md missing')
    else:
        text=p.read_text(encoding='utf-8')
        if not text.startswith('---'): errors.append('missing YAML frontmatter')
        if f"name: {CONFIG['skill_id']}" not in text: errors.append('frontmatter name mismatch')
        if 'description:' not in text: errors.append('frontmatter description missing')
        if 'TODO' in text or '[TODO' in text: errors.append('TODO placeholder remains')
        if PRIVATE_NODE_RE.search(text): errors.append('private workflow-node code found in SKILL.md')
        for token in RETIRED_VERSION_TOKENS:
            if token in text:
                errors.append(f'retired contract or schema token remains in SKILL.md: {token}')
        forbidden=['depends' + '_on','blo' + 'cks']
        for word in forbidden:
            if re.search(rf"(^|[\s`'\"]){word}(\s*:|[`'\"])", text, re.I): errors.append(f'forbidden order field {word!r}')
        for req in ['references/shared-requirement-definition-contract.md','scripts/validate_artifact.py','scripts/validate_metadata.py']:
            if req not in text: errors.append(f'SKILL.md does not reference {req}')
    for rel in ['agents/openai.yaml','references/metadata-schema.json','references/anti-patterns.md','scripts/validate_release_consistency.py']:
        if not (d/rel).exists(): errors.append(f'missing {rel}')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: SKILL.md baseline for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
