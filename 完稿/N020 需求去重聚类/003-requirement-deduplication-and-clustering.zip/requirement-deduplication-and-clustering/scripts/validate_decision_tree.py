#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
CONFIG={'display': 'Requirement Deduplication And Clustering', 'cn': '需求去重与聚类', 'family_role': 'deduplication', 'artifact_type': 'csv', 'primary_artifact': 'requirement-clusters.csv', 'schema': 'requirement.deduplication.v4', 'id_field': 'cluster_id', 'id_re': '^RCL-[a-z0-9_]+-\\d{3,}$', 'required': ['cluster_id', 'representative_requirement', 'member_requirement_ids', 'relation_strength', 'merge_recommendation', 'preserved_differences', 'evidence_refs', 'confidence', 'open_questions'], 'recommended': ['theme', 'source_count', 'duplicate_count', 'cluster_rationale', 'risk_of_overmerge'], 'enums': {'relation_strength': ['exact_duplicate', 'highly_similar', 'theme_related', 'needs_human_review'], 'merge_recommendation': ['merge', 'keep_separate', 'split_cluster', 'human_review'], 'confidence': ['high', 'medium', 'low', 'needs_human_review']}, 'modes': ['exact_duplicate_scan', 'theme_clustering', 'source_aware_deduplication', 'overmerge_risk_review', 'partial_pool_triage'], 'description': 'deduplicate and cluster requirement items by exact duplication, high similarity, or theme-level relation while preserving source evidence and differences. use when requirement lists, tickets, notes, or backlog exports need traceable clusters and over-merge protection for context enrichment, user research, prioritization, or requirement writing. not for final scope selection or roadmap ranking.', 'route_tokens': ['context_enrichment', 'planning_intake', 'human_review'], 'composable': ['requirement-collection-consolidation', 'requirement-context-enrichment', 'user-pain-point-analysis', 'user-journey-analysis'], 'not_for': ['choosing a winning requirement', 'hiding preserved differences', 'scoring business value'], 'skill_id': 'requirement-deduplication-and-clustering', 'contract_version': 'requirement-definition-suite-v1.3.0'}

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('skill_dir', nargs='?', default='.')
    d=Path(ap.parse_args().skill_dir)
    errors=[]
    dt=d/'references/selected-mode-decision-tree.md'
    ms=d/'references/metadata-schema.json'
    sm=d/'SKILL.md'
    if not dt.exists(): errors.append('selected-mode-decision-tree.md missing')
    else:
        text=dt.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if f'`{m}`' not in text: errors.append(f'mode {m} missing from decision tree')
    if ms.exists():
        meta=json.loads(ms.read_text(encoding='utf-8'))
        enum=meta.get('properties',{}).get('selected_mode',{}).get('enum',[])
        if set(enum)!=set(CONFIG['modes']): errors.append('metadata selected_mode enum mismatch')
    else: errors.append('metadata-schema.json missing')
    if sm.exists():
        s=sm.read_text(encoding='utf-8')
        for m in CONFIG['modes']:
            if m not in s: errors.append(f'mode {m} missing from SKILL.md')
    if errors:
        for e in errors: print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: selected-mode decision tree aligned for {CONFIG['skill_id']}")
    return 0
if __name__=='__main__': sys.exit(main())
