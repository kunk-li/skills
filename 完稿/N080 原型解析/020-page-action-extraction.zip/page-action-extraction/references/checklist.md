# Checklist (v3)

## Inputs and boundaries
- [ ] active operating mode declared
- [ ] page namespace imported or self-generated
- [ ] 018 features consumed when available
- [ ] 019 backend IDs consumed when available
- [ ] N070 visibility rules consumed when available

## Namespaces
- [ ] action IDs are unique
- [ ] backend linkage is non-empty for every action

## Content depth
- [ ] success and failure branches exist for every action
- [ ] trigger type classified
- [ ] visibility rules are concrete when evidence exists
- [ ] irreversible or sensitive actions have been swept for secondary confirmation
- [ ] confirmation strength is assigned using the 4-level model when confirmation exists or is clearly needed

## Cross-skill grain
- [ ] action/feature ratio checked when 018 exists
- [ ] pages over 3x are explained

## Output hygiene
- [ ] feedback exists
- [ ] global-constraint scan exists
- [ ] self-check completed
