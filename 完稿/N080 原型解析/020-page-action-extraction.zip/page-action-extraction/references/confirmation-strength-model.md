# Secondary Confirmation Strength Model / 二次确认强度模型

Use the four-level confirmation strength model in 020.

| strength | Meaning | Typical examples |
|---|---|---|
| weak | low-cost reminder or passive notice | soft hint, inline reminder |
| medium | explicit confirm action without extra credential | modal confirm, checkbox acknowledge |
| strong | irreversible or sensitive action gated by extra step | typed confirmation, OTP, step-up verification |
| very_strong | high-impact or regulated action requiring elevated review | compliance submission, destructive role change, financial release |

---

## 量化决策矩阵 / Quantitative Decision Matrix

对每个动作在三个维度独立评分，求和后查表确定确认强度。

### 维度 1：可逆性 / Reversibility（0–4 分）

| 分值 | 描述 | 示例 |
|---|---:|---|
| 0 | 完全可逆，系统自动恢复 | 切换 UI 视图 |
| 1 | 可逆，但需要用户手动操作 | 移入草稿箱、标记为未读 |
| 2 | 部分可逆，有时间窗口或副作用 | 软删除（保留 30 天回收站）、撤回消息 |
| 3 | 难逆，依赖外部系统或人工干预 | 已发送的邮件、已触发的工单 |
| 4 | 完全不可逆 | 永久删除、资金转出、合规提交 |

### 维度 2：影响规模 / Impact Scale（0–4 分）

| 分值 | 描述 | 示例 |
|---|---:|---|
| 0 | 仅影响自身当前视图 | 折叠面板、主题切换 |
| 1 | 影响当前用户的单条记录 | 修改单个任务状态 |
| 2 | 影响当前用户的多条记录或一个对象 | 批量标记、修改项目属性 |
| 3 | 影响其他用户或跨团队 | 移除团队成员、批量分配任务 |
| 4 | 影响全系统或所有用户 | 停机维护、全量数据迁移 |

### 维度 3：合规敏感度 / Compliance Sensitivity（0–4 分）

| 分值 | 描述 | 示例 |
|---|---:|---|
| 0 | 无合规关联 | 修改 UI 偏好 |
| 1 | 轻微合规关联，不影响审计 | 修改展示名称 |
| 2 | 有审计要求，但非强监管 | 删除操作日志记录、修改用户角色 |
| 3 | 强监管领域（金融/医疗/政府），需要留痕 | 修改报销金额、变更诊断记录 |
| 4 | 合规禁止区域，需要额外授权 | 导出用户 PII、关闭合规功能 |

### 强度映射表 / Strength Mapping

```
total_score = reversibility + impact_scale + compliance_sensitivity

if total_score <= 2:
  confirmation_strength = weak
elif total_score <= 5:
  confirmation_strength = medium
elif total_score <= 8:
  confirmation_strength = strong
else:  # 9–12
  confirmation_strength = very_strong
```

### Hard overrides（优先于总分）

不论总分如何，下列动作直接映射为最高强度：

| 动作特征 | 最低强度 |
|---|---|
| 涉及资金划拨或支付 | very_strong |
| 合规提交（无法撤回） | very_strong |
| 永久删除 + 影响 ≥3 用户 | very_strong |
| 权限提升（grant admin/owner） | strong |
| 批量删除 | strong |
| 发送通知给外部用户 | strong |

### 示例评分

| 动作 | 可逆性 | 影响规模 | 合规敏感度 | 总分 | 强度 |
|---|---:|---:|---:|---:|---|
| 切换暗色模式 | 0 | 0 | 0 | 0 | weak |
| 标记任务完成 | 1 | 1 | 0 | 2 | weak |
| 移除项目成员 | 2 | 3 | 1 | 6 | strong |
| 提交合规申报 | 4 | 2 | 4 | 10 | very_strong |
| 永久删除账户 | 4 | 2 | 3 | 9 | very_strong |
| 批量归档工单 | 2 | 2 | 0 | 4 | medium |

---

## 输出要求

- `very_strong` actions should be flagged for downstream human-control or high-control-node review.
- If no confirmation exists for an obviously irreversible action, record it as a design risk rather than silently accepting it.
- Always record `confirmation_strength_score` (三维合计) in addition to the final `confirmation_strength` enum so reviewers can audit the judgment.
- When hard override applies, record `confirmation_override_reason`.

---

## 确认强度判别决策树 / Confirmation Strength Decision Tree

```
Q1: 该动作是否在 Hard Overrides 列表中（资金/永久删除+≥3用户/合规提交/权限提升）？
    YES → directly → very_strong，不需要计算总分
    NO  → Q2

Q2: 计算 total_score = reversibility + impact_scale + compliance_sensitivity

Q3: total_score 是多少？
    ≤ 2  → weak
    3–5  → medium
    6–8  → strong
    9–12 → very_strong
```

## 边界 Case 对照表

| Action | 可逆性 | 影响规模 | 合规敏感度 | 总分 | 强度 | 易错方向 |
|---|---:|---:|---:|---:|---|---|
| 切换主题 | 0 | 0 | 0 | 0 | weak | 常被过高估计 |
| 移除项目成员 | 2 | 3 | 1 | 6 | strong | 忽略影响规模=3 |
| 提交合规申报 | 4 | 2 | 4 | 10 | very_strong | Hard override 直接 very_strong |
| 批量归档工单（50 条） | 2 | 2 | 0 | 4 | medium | 批量量大但可撤销 |
| 发布公告（全体用户） | 3 | 4 | 1 | 8 | strong | 影响规模不可忽视 |
| 测试环境清空数据 | 4 | 1 | 0 | 5 | medium | 测试环境影响规模低 |
| 重置他人密码 | 3 | 1 | 2 | 6 | strong | 合规敏感度被低估 |
| 永久删除 1 条自己的记录 | 4 | 1 | 0 | 5 | medium | 非批量不触发 override |
