# Secondary Confirmation Strength Model / 二次确认强度模型

Use the four-level confirmation strength model in 020.

| strength | Meaning | Typical examples |
|---|---|---|
| weak | low-cost reminder or passive notice | soft hint, inline reminder |
| medium | explicit confirm action without extra credential | modal confirm, checkbox acknowledge |
| strong | irreversible or sensitive action gated by extra step | typed confirmation, OTP, step-up verification |
| very_strong | high-impact or regulated action requiring elevated review | compliance submission, destructive role change, financial release |

Recommended mapping:
- delete, bulk delete, irreversible state-change, permission escalation, financial submission, compliance export, or sensitive data release should always be swept.
- `very_strong` actions should be flagged for downstream human-control or high-control-node review.
- If no confirmation exists for an obviously irreversible action, record it as a design risk rather than silently accepting it.
