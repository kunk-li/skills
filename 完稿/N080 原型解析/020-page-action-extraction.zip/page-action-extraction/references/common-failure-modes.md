# Common Failure Modes (v3)

## FM-1 · action coverage too thin
Material features should usually map to at least one action.

## FM-2 · backend linkage left blank
If 019 is missing, use explicit placeholders instead of empty cells.

## FM-3 · success-only action description
Every action needs both success and failure branches.

## FM-4 · visibility rules too vague
Use real roles, states, or conditions when the evidence supports them.

## FM-5 · irreversible actions not swept
Delete, export, approval, financial, permission-change, and compliance actions must all be reviewed for secondary confirmation.

## FM-6 · confirmation strength missing
If confirmation exists or is clearly needed, classify it as weak / medium / strong / very_strong.

## FM-7 · HCN-worthy actions buried in the table
Very-strong actions should be surfaced for downstream high-control review instead of disappearing into generic rows.
