# Scoring Rubric (v3)

| Dimension | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| action coverage | 100% feature-to-action mapping | >= 90% | >= 70% | < 70% |
| grain ratio | all pages <= 3x or justified | >= 90% | >= 70% | weak |
| backend linkage completeness | 100% bound or explicitly pure_frontend | >= 90% | >= 70% | weak |
| visibility precision | specific and evidence-bound | >= 90% | >= 80% | vague |
| confirmation sweep completeness | all irreversible/sensitive actions swept | >= 80% | >= 50% | weak |
| confirmation strength quality | all swept actions classified or justified | >= 80% | >= 50% | missing |
| global constraints and feedback | complete | mostly complete | partial | missing |

---

## 动作清单完整性量化评分

```
action_completeness_score = 100 - (
  missing_confirmation_strength × 10 +    # 明显不可逆动作无 confirmation_strength
  untraced_action × 8 +                   # ACT-* 无法追溯到 PRD-XX 或 REQ-*
  missing_precondition × 5 +              # 有前置状态要求但未声明 precondition
  confirmation_score_missing × 5         # 有 strength 但无三维合计分数
)
clip to [0, 100]
```
