# Scoring Rubric (v3)

| Dimension | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| action coverage | 100% feature-to-action mapping | >= 90% | >= 70% | < 70% |
| grain ratio | all pages <= 3x or justified | >= 90% | >= 70% | weak |
| backend linkage completeness | 100% bound or explicitly pure_frontend | >= 90% | >= 70% | weak |
| visibility precision | specific and evidence-bound | >= 90% | >= 80% | vague |
| confirmation sweep completeness | all irreversible/sensitive actions swept | >= 80% | >= 50% | weak |
| confirmation strength quality | all swept actions classified or justified | >= 80% | >= 50% | missing |
| global constraints and feedback | complete | mostly complete | partial | missing |
