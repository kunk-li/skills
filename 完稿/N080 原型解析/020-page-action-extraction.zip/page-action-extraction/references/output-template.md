# Output Template (v3)

Use the fixed structure below.

## 1. Summary
Include total actions, per-page distribution, confirmation-swept action count, irreversible-action count, and pure-frontend ratio.

## 2. Confirmed facts
## 3. Action catalog
| action_id | trigger_element | trigger_type | prerequisite_state | cross_module_prerequisite | backend_action | success_result | failure_result | visibility_rule | secondary_confirmation | audit | confidence |
|---|---|---|---|---|---|---|---|---|---|---|---|

`confidence` must use the three-value enum from `N080_COMMON_CONTRACTS.md` C0.1: `confirmed`, `stable_inference`, or `needs_confirmation`.

## 4. Button visibility summary
| visibility_rule | actions | source |
|---|---|---|

## 5. Trigger classification summary
List all five trigger classes even if one is empty.

## 6. Secondary-confirmation sweep
| action_id | confirmation_type | confirmation_strength | sweep_status | rationale | source | high_control_handoff |
|---|---|---|---|---|---|---|

Rules:
- sweep_status must distinguish `covered`, `none_observed`, or `needs_confirmation`
- `confirmation_strength` must use weak / medium / strong / very_strong
- `high_control_handoff` should flag very-strong actions
- rows with `high_control_handoff=true` must be exported as a standalone CSV `高风险动作待审清单.csv` with the column subset `action_id, page_id, trigger_element, confirmation_strength, rationale, source`
- if the sweep finds no `very_strong` action, still emit an empty `高风险动作待审清单.csv` with only the header row and note `no high-control actions detected` in §1 Summary

## 7. Two-way feedback
## 8. Global-constraint collisions
## 9. Needs-confirmation items
## 10. Self-check
Include page alignment, action uniqueness, backend linkage completeness, sweep completeness, grain ratio, C4, and C5.
