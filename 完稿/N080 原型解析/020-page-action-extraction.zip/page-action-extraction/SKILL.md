---
name: page-action-extraction
description: extract stable page-level action catalogs, trigger conditions, visibility rules, confirmation strength, and backend linkage from prototypes, partial prototypes, or prototype-absent fallback artifacts during n080 prototype-driven analysis. use after or alongside 018 and 019 to expand features into actions, sweep irreversible actions for secondary confirmation, and keep outputs aligned with api ids, be ids, and field ids.
---

# Page Action Extraction (fused v4)

Decompose page-level capabilities into stable action catalogs with trigger conditions, result branches, visibility, secondary confirmation, confirmation strength, and backend linkage.

## Operating modes / 运行模式
- `has-prototype`
- `partial-prototype`
- `inferred-from-prototype-absent`

The active mode must be declared in the summary. In prototype-absent mode, confirmation design and visibility rules should stay conservative and evidence-bound.

## Standalone and collaboration modes / 单独与组合模式
### Standalone mode / 单独使用
- Can extract action catalogs from prototypes or fallback artifacts even when 018 or 019 are missing.
- May self-generate page and action IDs when 018 is not available.
- May temporarily use `API-TBD`, `BE-TBD`, textual backend descriptions, or `pure_frontend` when 019 is missing.

### Multi-skill mode / 组合使用
- Reuse page and feature namespaces from 018.
- Reuse `API-` and `BE-` IDs from 019.
- Reuse role and visibility vocabulary from N070 permission artifacts.

## Standalone use cases / 独立使用场景
- action catalog extraction for a prototype handoff workshop
- permission and action matrix seeding before RBAC design
- irreversible-action sweep for compliance-sensitive modules
- legacy UI click-flow reconstruction when only PRD/API docs remain

## Fallback behavior / 降级策略
- Without 018: self-generate page IDs and extract actions directly.
- Without 019: keep backend linkage non-empty using `API-TBD`, `BE-TBD`, textual descriptions, or `pure_frontend`.
- Without N070: derive visibility and prerequisite rules from source wording and mark them `source-derived` when needed.
- Without prototype material: switch to `inferred-from-prototype-absent` mode and avoid overclaiming irreversible-action semantics unless supported by documentation.

## Position in N080 / 节点定位
- **Stage B** (parallel with 019 and 021)
- Upstream: 018 (recommended), 019 (recommended), N070 (recommended)
- Downstream: N130, N230, N100, and N380 when very-strong confirmations require high-control review

## Inputs / 输入边界
### Allowed inputs
- primary: prototype HTML, screenshots, annotated mockups, prototype descriptions
- recommended upstream: 018 feature catalog
- recommended upstream: 019 API / BE catalog
- recommended upstream: N070 permission matrix, business rules, object catalog
- cross-reference: PRD text, API docs, acceptance criteria

### Prohibited
- current database state
- current code state
- undocumented oral background

## Core goal
Produce action catalogs that capture:
1. stable action IDs
2. trigger conditions and prerequisite states
3. success and failure branches
4. visibility rules
5. backend linkage
6. secondary confirmation type and confirmation strength for high-impact actions
7. two-way feedback, global-constraint collisions, and self-check

## Workflow
1. import or build page namespace
2. expand each feature into one or more actions
3. classify trigger type and prerequisite state
4. bind backend linkage using 019 when possible
5. sweep all irreversible, sensitive, financial, permission-changing, export, delete, or compliance-relevant actions for secondary confirmation
6. classify confirmation strength using `references/confirmation-strength-model.md`
7. flag `very_strong` actions for N100 and N380 high-control review handoff and prepare a standalone export
8. output C4, C5, and C7

## Output contract
Follow `references/output-template.md` and always include:
- action catalog
- button visibility summary
- trigger classification summary
- secondary-confirmation sweep summary
- two-way feedback
- global-constraint collisions
- needs-confirmation items
- self-check
- `高风险动作待审清单.csv` export for all `high_control_handoff=true` rows

## Grounding rules
- Every action must express both success and failure branches.
- `backend_action` must reference real `API-` or `BE-` IDs when 019 exists; otherwise use explicit placeholders rather than blanks.
- All irreversible or high-impact actions must be swept in the secondary-confirmation section, even if the result is `none observed`.
- Confirmation strength must use the four-level model: `weak`, `medium`, `strong`, `very_strong`.
- `very_strong` actions must be handed off to **N100** and **N380** instead of being buried in the generic action table.
- Every row with `high_control_handoff=true` must be exportable to `高风险动作待审清单.csv`; if no row qualifies, still emit an empty file with headers and record `no high-control actions detected` in the summary.

## Minimal embedded contract / 最小内嵌契约
Even if `N080_COMMON_CONTRACTS.md` is not opened, this skill must still:
- declare the active operating mode
- use stable `ACT-{module}-P{page_seq}-{nn}` IDs
- keep backend linkage non-empty
- run a full secondary-confirmation sweep for irreversible or sensitive actions
- classify confirmation strength using the four-level model
- output two-way feedback, global-constraint collisions, and self-check

## Quality bar
- Prefer the full C0-C10 contract from `N080_COMMON_CONTRACTS.md`.
- Target at least **12/14** against `references/scoring-rubric.md`.
- If below bar, explicitly say which action classes remain weakly evidenced or are waiting for 019/N070 backfill.

## Reference files
- `N080_COMMON_CONTRACTS.md` (required, min contract_version 1.0.0)
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/confirmation-strength-model.md`
