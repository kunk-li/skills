---
name: page-action-extraction
description: Extract page-level action catalogs, trigger conditions, visibility rules, and confirmation strength from prototypes; expands features into actions and sweeps irreversible actions for secondary confirmation.
---

# Page Action Extraction (fused v4)

Decompose page-level capabilities into stable action catalogs with trigger conditions, result branches, visibility, secondary confirmation, confirmation strength, and backend linkage.

## Operating modes / 运行模式
- `has-prototype`
- `partial-prototype`
- `inferred-from-prototype-absent`

The active mode must be declared in the summary. In prototype-absent mode, confirmation design and visibility rules should stay conservative and evidence-bound.

## Standalone and collaboration modes / 单独与组合模式
### Standalone mode / 单独使用
- Can extract action catalogs from prototypes or fallback artifacts even when 018 or 019 are missing.
- May self-generate page and action IDs when 018 is not available.
- May temporarily use `API-TBD`, `BE-TBD`, textual backend descriptions, or `pure_frontend` when 019 is missing.

### Multi-skill mode / 组合使用
- Reuse page and feature namespaces from 018.
- Reuse `API-` and `BE-` IDs from 019.
- Reuse role and visibility vocabulary from N070 permission artifacts.

## Standalone use cases / 独立使用场景
- action catalog extraction for a prototype handoff workshop
- permission and action matrix seeding before RBAC design
- irreversible-action sweep for compliance-sensitive modules
- legacy UI click-flow reconstruction when only PRD/API docs remain

## Fallback behavior / 降级策略
- Without 018: self-generate page IDs and extract actions directly.
- Without 019: keep backend linkage non-empty using `API-TBD`, `BE-TBD`, textual descriptions, or `pure_frontend`.
- Without N070: derive visibility and prerequisite rules from source wording and mark them `source-derived` when needed.
- Without prototype material: switch to `inferred-from-prototype-absent` mode and avoid overclaiming irreversible-action semantics unless supported by documentation.

## Position in N080 / 节点定位
- **Stage B** (parallel with 019 and 021)
- Upstream: 018 (recommended), 019 (recommended), N070 (recommended)
- Downstream: N130, N230, N100, and N380 when very-strong confirmations require high-control review

## Inputs / 输入边界
### Allowed inputs
- primary: prototype HTML, screenshots, annotated mockups, prototype descriptions
- recommended upstream: 018 feature catalog
- recommended upstream: 019 API / BE catalog
- recommended upstream: N070 permission matrix, business rules, object catalog
- cross-reference: PRD text, API docs, acceptance criteria

### Prohibited
- current database state
- current code state
- undocumented oral background

## Role / 角色定位
Produce action catalogs that capture:
1. stable action IDs
2. trigger conditions and prerequisite states
3. success and failure branches
4. visibility rules
5. backend linkage
6. secondary confirmation type and confirmation strength for high-impact actions
7. two-way feedback, global-constraint collisions, and self-check

## Workflow
1. import or build page namespace
2. expand each feature into one or more actions
3. classify trigger type and prerequisite state
4. bind backend linkage using 019 when possible
5. sweep all irreversible, sensitive, financial, permission-changing, export, delete, or compliance-relevant actions for secondary confirmation
6. classify confirmation strength using `references/confirmation-strength-model.md`
7. flag `very_strong` actions for N100 and N380 high-control review handoff and prepare a standalone export
8. output C4, C5, and C7

## Output contract
Follow `references/output-template.md` and always include:
- action catalog
- button visibility summary
- trigger classification summary
- secondary-confirmation sweep summary
- two-way feedback
- global-constraint collisions
- needs-confirmation items
- self-check
- `高风险动作待审清单.csv` export for all `high_control_handoff=true` rows

## Boundary rules / 边界规则
- Every action must express both success and failure branches.
- `backend_action` must reference real `API-` or `BE-` IDs when 019 exists; otherwise use explicit placeholders rather than blanks.
- All irreversible or high-impact actions must be swept in the secondary-confirmation section, even if the result is `none observed`.
- Confirmation strength must use the four-level model: `weak`, `medium`, `strong`, `very_strong`.
- `very_strong` actions must be handed off to **N100** and **N380** instead of being buried in the generic action table.
- Every row with `high_control_handoff=true` must be exportable to `高风险动作待审清单.csv`; if no row qualifies, still emit an empty file with headers and record `no high-control actions detected` in the summary.

## Minimal embedded contract / 最小内嵌契约
Even if `N080_COMMON_CONTRACTS.md` is not opened, this skill must still:
- declare the active operating mode
- use stable `ACT-{module}-P{page_seq}-{nn}` IDs
- keep backend linkage non-empty
- run a full secondary-confirmation sweep for irreversible or sensitive actions
- classify confirmation strength using the four-level model
- output two-way feedback, global-constraint collisions, and self-check

## Quality bar
- Prefer the full C0-C10 contract from `N080_COMMON_CONTRACTS.md`.
- Target at least **12/14** against `references/scoring-rubric.md`.
- If below bar, explicitly say which action classes remain weakly evidenced or are waiting for 019/N070 backfill.

## Reference files / 参考文件
- `N080_COMMON_CONTRACTS.md` (required, min contract_version 1.0.0)
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/confirmation-strength-model.md`


## Workflow v2 artifact contract
```yaml
artifact_type: n080.page-actions
schema_version: "1.1.0"
producer_skill: page-action-extraction
consumer_nodes: [N090, N100]
workflow_alias: 页面动作清单.md
produced_event_name: produced.n080.page-actions
canonical_fields:
  - action_id      # ACT-{module}-P{page_seq}-{nnn}
  - page_id
  - label
  - trigger
  - confirmation_strength        # weak / medium / strong / very_strong
  - confirmation_strength_score  # 三维合计（可逆性+影响规模+合规敏感度）
  - confirmation_override_reason # hard override 时必填
  - reversibility
  - confidence
  - evidence
n005_consumption: indirect
```


## Self-check / 节点内自检

按 `N080_COMMON_CONTRACTS.md §C7` 自检清单执行（必做）：
- 页面命名空间一致性（所有兄弟 skill 使用相同 P-* ID）
- 元素 ID 唯一性
- upstream_feedback 和缺页裁决已输出
- fallback 模式已声明
- cross-skill ID 引用完整
并按 `references/scoring-rubric.md` 做质量评分（目标 ≥ 3）。

## Key references
- `references/n080-scoring-model.md`：**N080 量化评分公式（evidence_score + vocab_alignment + readiness_score 综合得分 + hard overrides）（必读）**
- `../018-prototype-to-feature-points/prototype-to-feature-points/references/node-guide.md`：**N080 节点导航——4 个 skill 执行顺序、三档 fallback 模式（必读，见 018）**
- `../018-prototype-to-feature-points/prototype-to-feature-points/references/handoff-to-n090.md`：**N080→N090 节点交接协议——ACT-* ID 到 PRD-07/09 的映射规则（必读，见 018）**

- `N080_COMMON_CONTRACTS.md`：**N080 节点契约：页面命名空间、跨 skill ID、confidence 枚举（必读）**
- `references/confirmation-strength-model.md`：**确认强度三维量化矩阵 + 判别决策树（Hard Override → Q1-Q3）+ 8 行边界 case 表（必读）**
- `references/scoring-rubric.md`：**动作清单完整性量化公式（= 100 - 扣分项）+ 确认强度决策树（见 confirmation-strength-model.md）（必读）**
- `references/output-template.md`：输出结构
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
