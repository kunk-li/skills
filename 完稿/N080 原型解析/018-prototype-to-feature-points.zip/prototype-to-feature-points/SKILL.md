---
name: prototype-to-feature-points
description: extract page inventories, feature catalogs, backend-intent baselines, and two-way feedback from prototypes, partial prototypes, or prototype-absent fallback artifacts during n080 prototype-driven analysis. use as the stage a foundation skill that establishes the shared p- and ft- namespaces for sibling skills 019, 020, and 021, including legacy-system reverse analysis when no prototype is available.
---

# Prototype To Feature Points (fused v4)

Extract page-level capabilities from visual materials or approved fallback artifacts. This is the **Stage A foundation skill** for N080 and should normally run before 019, 020, and 021.

## Operating modes / 运行模式
- `has-prototype`: full prototype material is available.
- `partial-prototype`: only some prototype pages, screenshots, or annotations are available.
- `inferred-from-prototype-absent`: no usable prototype exists, so the skill must reconstruct likely pages and features from documented fallback artifacts such as PRD, API docs, acceptance criteria, release notes, or operations manuals.

The active mode must be declared in the summary and all low-confidence content must stay in `stable inference` or `needs confirmation`.

## Standalone and collaboration modes / 单独与组合模式
### Standalone mode / 单独使用
- Can run from prototype HTML, screenshots, annotated mockups, or documented fallback artifacts.
- Must still establish the `P-{module}-{nn}` page namespace and the `FT-{module}-{page_seq}-{nn}` feature namespace.
- If authority vocabulary is missing, use source wording and mark it `source-derived` or `needs_confirmation`.

### Multi-skill mode / 组合使用
- Serves as **N080 Stage A** and provides the shared page namespace and feature catalog for 019, 020, and 021.
- When N070 outputs exist, use their authoritative object and role vocabulary to reduce naming drift.
- When PRD or API docs exist, use them only for cross-checking and missing-page adjudication; do not let them override direct prototype evidence.

## Standalone use cases / 独立使用场景
- prototype inventory for a new product module
- reverse feature discovery for a legacy system with no maintained prototype
- cross-channel prototype comparison before PRD consolidation
- front-end migration planning where the page map must be reconstructed first

## Fallback behavior / 降级策略
- Without N070: build the page map and feature catalog directly from visible evidence and mark source-derived vocabulary.
- Without global context: keep the global-constraint section and record `global context not provided`.
- Without PRD: still finish the feature catalog; two-way feedback can reference only prototype-visible facts and gaps.
- Without prototype material: switch to `inferred-from-prototype-absent` mode and make the provenance explicit in the summary and relevant rows.

## Position in N080 / 节点定位
- **Stage A**
- Upstream: N070 structured outputs (recommended, not mandatory)
- Downstream: 019 / 020 / 021 plus N090 / N100 / N130 / N230

## Inputs / 输入边界
### Allowed inputs
- primary: prototype HTML, screenshots, annotated mockups, accessible prototype descriptions
- recommended upstream: N070 outputs, especially object catalog, role graph, and permission matrix
- recommended secondary: system-level global context documents and naming dictionaries
- cross-reference: PRD text, API docs, acceptance criteria, release notes

### Prohibited
- current database state
- current code state
- undocumented oral background

## Core goal
Produce a stable page-oriented feature baseline with:
1. standardized page IDs (`P-{module}-{nn}`)
2. standardized feature IDs (`FT-{module}-{page_seq}-{nn}`)
3. a feature catalog that covers all visible or stably reconstructed capabilities
4. cross-page consistency observations
5. backend intent hints for 019
6. upstream feedback, missing-page adjudication, global-constraint scan, and self-check

## Workflow
1. inventory all pages, dialogs, drawers, tabs, panels, and wizard steps
2. assign page IDs and page types using `references/page-type-taxonomy.md`
3. decompose pages by capability rather than widget ornamentation
4. cross-reference every feature against upstream requirement artifacts when they exist
5. build the backend-intent baseline without guessing implementation details
6. output C4 two-way feedback, C5 global-constraint collisions, and C7 self-check

## Output contract
Follow `references/output-template.md` and always include:
- §1 summary with active mode, page count, feature count, feedback count, and missing-page count
- §2 page inventory
- §3 feature catalog
- §4 cross-prototype observations
- §5 backend intent summary
- §6 two-way feedback
- §7 global-constraint collisions
- §8 needs-confirmation items
- §9 recommended next steps
- §10 self-check

**Hard rule for §5**: the backend-intent summary must cover **all feature IDs from §3**. It is not a selective sample table.

## Grounding rules
- Write confirmed facts first, then stable inference, then needs-confirmation items.
- `feature_type` must come from the node-wide action vocabulary: browse / create / edit / delete / submit / approve / export / state-change / display-only.
- Backend intent may only describe what the prototype or fallback artifact stably supports; detailed implementation belongs downstream.
- In multi-skill mode, `§5 Backend intent summary` must stop at the intent layer so 019 can consume it as a capability candidate; do not write HTTP methods, API paths, or request parameters in `§5`.
- Each intent row should remain one conservative capability candidate that 019 can map in combination mode; if one feature implies multiple backend capabilities, split or annotate them without leaking implementation detail.
- Do not merge materially different cross-channel or cross-version capabilities into one feature row just to keep the table short.

## Minimal embedded contract / 最小内嵌契约
Even if `N080_COMMON_CONTRACTS.md` is not opened, this skill must still:
- declare one active operating mode: `has-prototype`, `partial-prototype`, or `inferred-from-prototype-absent`
- use the three evidence layers
- use `P-{module}-{nn}` and `FT-{module}-{page_seq}-{nn}` namespaces
- output two-way feedback, global-constraint collisions, and self-check
- ensure §5 backend intent summary covers every feature ID from §3

## Quality bar
- Prefer the full C0-C10 contract from `N080_COMMON_CONTRACTS.md`.
- Target at least **12/14** against `references/scoring-rubric.md`.
- If below bar, explicitly state missing evidence, risk, and the best next artifact to request.

## Reference files
- `N080_COMMON_CONTRACTS.md` (required, min contract_version 1.0.0)
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/page-type-taxonomy.md`
