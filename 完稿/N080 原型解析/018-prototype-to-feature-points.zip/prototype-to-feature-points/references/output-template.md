# Output Template (v3)

Use the fixed 10-section structure.

## 1. Summary
Always include:
- active operating mode
- total pages
- total features
- upstream feedback count
- missing-page adjudication count

## 2. Page inventory
| page_id | page_name | page_type | evidence | channel | notes |
|---|---|---|---|---|---|

## 3. Feature catalog
| feature_id | page_id | capability | feature_type | frontend_behavior | backend_intent | upstream_ref | notes |
|---|---|---|---|---|---|---|---|

## 4. Cross-prototype or cross-artifact observations
Highlight naming drift, channel inconsistency, flow gaps, or version inconsistency.

## 5. Backend intent summary
| feature_id | page_id | backend_intent | evidence | confidence |
|---|---|---|---|---|

Hard rule: every `feature_id` from §3 must appear once in §5.
`confidence` must use the three-value enum from `N080_COMMON_CONTRACTS.md` C0.1: `confirmed`, `stable_inference`, or `needs_confirmation`.

## 6. Two-way feedback
### 6.1 upstream feedback list
### 6.2 missing-page adjudication

## 7. Global-constraint collisions
| scan_type | hit | page_id | risk | suggestion |
|---|---|---|---|---|

## 8. Needs-confirmation items
| priority | category | question | owner |
|---|---|---|---|

## 9. Recommended next steps
Specify handoff guidance for 019, 020, and 021.

## 10. Self-check
Include page-namespace check, feature-ID uniqueness, §5 full coverage, C4, C5, and evidence layering.
