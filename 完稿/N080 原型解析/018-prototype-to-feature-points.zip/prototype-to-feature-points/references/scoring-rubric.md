# Scoring Rubric (v3)

| Dimension | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| page coverage | 100% | >= 90% | >= 70% | < 70% |
| feature-id consistency | full unique and valid | >= 95% | >= 80% | < 80% |
| upstream feedback | >= 5 clear items or justified none | >= 3 | >= 1 | missing |
| missing-page adjudication | all addressed | >= 80% addressed | >= 50% addressed | < 50% |
| global-constraint scan | all 3 scans with detail | all 3 scans | partial | none |
| feature typing completeness | 100% typed | >= 90% | >= 70% | < 70% |
| backend-intent coverage | §5 covers 100% of feature IDs | >= 95% | >= 80% | partial sample only |
