# Page Type Taxonomy / 页面类型分类

Use these stable page types in 018 page inventory.

| Type | Definition | Typical cues |
|---|---|---|
| page | Full destination page or route | left nav entry, breadcrumb, full-screen content |
| dialog | Blocking modal surface | centered modal, explicit confirm/cancel |
| drawer | Side sheet or slide-over | right-side or bottom slide panel |
| tab | Switchable view within one page | tab header, segment switch, no route change |
| panel | Embedded management or info region | collapsible side panel, embedded module block |
| wizard-step | One step in a multi-step flow | stepper, progress dots, next/back |
| other | Anything real but not fitting above | explicitly explain in notes |

Rules:
- Prefer `page` over `panel` only when the unit behaves like an independent destination.
- Dialogs and drawers must still receive page IDs when they host distinct capabilities, actions, or forms.
- Tabs become independent page inventory items only when they contain materially different capabilities.
