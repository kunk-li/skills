# Page Type Taxonomy / 页面类型分类

Use these stable page types in 018 page inventory.

| Type | Definition | Typical cues |
|---|---|---|
| page | Full destination page or route | left nav entry, breadcrumb, full-screen content |
| dialog | Blocking modal surface | centered modal, explicit confirm/cancel |
| drawer | Side sheet or slide-over | right-side or bottom slide panel |
| tab | Switchable view within one page | tab header, segment switch, no route change |
| panel | Embedded management or info region | collapsible side panel, embedded module block |
| wizard-step | One step in a multi-step flow | stepper, progress dots, next/back |
| other | Anything real but not fitting above | explicitly explain in notes |

Rules:
- Prefer `page` over `panel` only when the unit behaves like an independent destination.
- Dialogs and drawers must still receive page IDs when they host distinct capabilities, actions, or forms.
- Tabs become independent page inventory items only when they contain materially different capabilities.

---

## 页面类型选择决策树

```
Q1: 页面是否允许用户输入数据并提交？
    YES（有表单/提交操作）→ form_page
    NO  → Q2

Q2: 页面是否以展示多条记录为主，且通常有筛选/搜索？
    YES → list_page
    NO  → Q3

Q3: 页面是否聚焦在单个对象的全部属性和操作？
    YES → detail_page
    NO  → Q4

Q4: 页面是否是系统的"首页"或多种信息的聚合展示？
    YES → dashboard_page
    NO  → Q5

Q5: 页面是否引导用户完成多步骤流程（每步一页或一节）？
    YES → wizard_page
    NO  → 其他类型（modal / empty_state / error_page 等）
```

### 边界 Case 对照表

| 场景 | 正确 page_type | 常见误判 | 判别信号 |
|---|---|---|---|
| 订单详情+操作（审批/退款） | detail_page | form_page | 主体是单对象展示，操作是附属 |
| 用户筛选+批量操作 | list_page | dashboard_page | 核心是多记录管理 |
| 创建/编辑对话框 | form_page | detail_page | 主体是数据输入和提交 |
| 注册多步骤 | wizard_page | form_page | 有明确的步骤顺序和进度 |
| 空购物车状态 | empty_state | list_page | 无记录时的专属视图 |

### N080 覆盖检查

每个页面类型都应有对应的检查项：
- `form_page`：必须有 021 字段清单覆盖
- `list_page`：必须有 020 动作清单（筛选/排序/批量操作）
- `detail_page`：必须有 020 动作清单 + 021 关键字段
- `dashboard_page`：必须说明数据来源（哪个 API/对象提供数据）
- `wizard_page`：必须有步骤顺序和每步的必填字段
