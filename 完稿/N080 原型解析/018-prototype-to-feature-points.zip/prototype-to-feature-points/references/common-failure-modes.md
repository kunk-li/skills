# Common Failure Modes (v3)

## FM-1 · authority naming drift
Use authoritative upstream object names when they exist. Do not replace them with UI nicknames.

## FM-2 · prototype-only additions not fed back
If prototypes reveal upstream-missing entities, fields, actions, or roles, they must appear in the feedback list.

## FM-3 · widget-level over-splitting
Split by capability, not by ornament or styling.

## FM-4 · page inventory incomplete
Dialogs, drawers, tabs, and wizard steps must be inventoried when they host material capabilities.

## FM-5 · channel differences flattened
Do not merge materially different channel behavior into one feature row.

## FM-6 · backend intent over-inferred
A button does not justify inventing internal tables, workflows, or transaction design.

## FM-7 · missing-page adjudication skipped
Every upstream-defined but prototype-missing feature needs an adjudication decision.

## FM-8 · global constraints not scanned
If a global context exists, the three required scans must run.

## FM-9 · backend intent summary is partial
§5 must cover every feature ID from §3. Sample-only summaries are not acceptable.
