# Checklist (v3)

## Inputs and boundaries
- [ ] primary input came from prototype or approved fallback artifacts
- [ ] active mode is explicitly declared (`has-prototype` / `partial-prototype` / `inferred-from-prototype-absent`)
- [ ] upstream N070 outputs were used when available
- [ ] PRD or API docs were used only as cross-reference, not as silent authority overrides

## Namespaces
- [ ] every page uses `P-{module}-{nn}`
- [ ] every feature uses `FT-{module}-{page_seq}-{nn}`
- [ ] feature IDs are unique

## Content depth
- [ ] page types follow `page-type-taxonomy.md`
- [ ] feature types use the node action vocabulary
- [ ] §5 backend intent summary covers **all** feature IDs from §3
- [ ] backend intent does not guess implementation details

## Two-way feedback and constraints
- [ ] upstream feedback section exists
- [ ] missing-page adjudication exists
- [ ] global-constraint scan was executed

## Output hygiene
- [ ] 10-section template followed
- [ ] confirmed fact / stable inference / needs confirmation are separated
- [ ] self-check completed
