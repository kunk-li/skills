# Example I/O (generic)

## Example: P-OPS-05 项目成员管理（节选）

### Input cues
- 页面包含：成员列表、添加成员弹窗、移除成员确认弹窗
- 上游 N070 已识别对象：Project、User、Project_Member_Assignment
- PRD 描述了“项目管理员可维护成员”“成员上限受套餐约束”

### Output (§3 Feature catalog excerpt)

| feature_id | 页面 | capability | 类型 | 前端表现 | 后端意图 | N070 对应 | 备注 |
|---|---|---|---|---|---|---|---|
| FT-OPS-05-01 | P-OPS-05 项目成员列表 | 查看当前项目成员 | browse | 列表展示 + 计数标签 | 查询 Project_Member_Assignment | F-OPS-011 | 若角色名来自字典服务，需在 021 标记数据来源 |
| FT-OPS-05-02 | P-OPS-05 添加成员弹窗 | 提交新增成员关系 | submit | 点击“添加成员”后打开模态 | 创建 Project_Member_Assignment | F-OPS-012 | 配额或人数上限规则待 019 校验细化 |
| FT-OPS-05-03 | P-OPS-05 成员行操作 | 移除成员 | delete | 行内“移除”按钮 + 确认弹窗 | 删除 Project_Member_Assignment | F-OPS-013 | 是否要求二次确认由 020 继续判定 |

### Output (§6 Two-way feedback excerpt)

| 原型新增内容 | 出处页面 | 建议反哺 N070 位置 | 紧急度 |
|---|---|---|---|
| 成员关系存在“到期时间”字段，但 N070 对象表未列 | P-OPS-05 | N070 §4 Project_Member_Assignment 属性补充 | P1 |

### Output (§6 Missing-page adjudication excerpt)

| N070 功能 ID | 缺页位置 | 裁决 | 理由 |
|---|---|---|---|
| F-OPS-020 | 批量导入成员页 | (b) 后台流程不在原型范围 | 当前原型只覆盖在线维护，不含批量导入后台 |
