# N080 → N090 节点交接协议

> 本文件定义 N080（原型解析）向 N090（PRD 产出与评审）的正式交接规范。

---

## 1. N080 输出捆绑包 / Upstream Output Bundle

N090 消费 N080 的以下产物（按重要性排序）：

| 产物 | 来源 Skill | 主要字段 | N090 用途 |
|---|---|---|---|
| 页面地图（Page Map） | 018 | `P-{module}-{nn}` + feature list | PRD-05 页面/能力概览 |
| 功能点目录（Feature Catalog） | 018 | `FT-{module}-{page_seq}-{nn}` | PRD-06 功能需求清单的溯源 |
| 后端能力清单（BE Catalog） | 019 | `BE-{module}-{nn}` + `API-{module}-{nn}` | PRD-06/07 后端需求与接口定义 |
| 动作清单（Action Inventory） | 020 | `ACT-{module}-P{seq}-{nn}` + confirmation_strength | PRD-07 业务规则中的操作约束 |
| 字段清单（Field Catalog） | 021 | `FLD-{module}-P{seq}-{nn}` + constraint_type | PRD-10 数据对象与关键字段 |
| 反哺上游清单（Upstream Feedback） | 018-021 | `upstream_feedback[]` 条目 | 补充 N070 未覆盖的对象/规则 |
| 缺页裁决清单（Missing Page List） | 018 | `missing_page_adjudication[]` | PRD-03 范围与非范围 |

### 降级规则

```
if N080 全部不可用（无原型）:
  N090 采用 from-source 模式，直接从 N070 输出和原始需求文字生成 PRD
  在 PRD-16 附录中声明 upstream_n080_available: false

if 只有 018 可用（019-021 不可用）:
  PRD-06 可有功能清单，但 PRD-10 字段部分标记为 needs_confirmation
  PRD-07 的操作约束来源降级为 N070 规则

if 018 + 019 可用，020-021 不可用:
  PRD-07 缺少 confirmation_strength 数据，该列填 unknown（待 020 补充）
```

---

## 2. N090 入场校验 / Downstream Intake Protocol

N090（022）启动前执行以下校验：

```yaml
n080_intake_check:
  # Step 1: 确认 N080 完成信号
  n080_handoff_received:
    ready_for_n090: true | false   # 来自 N070-N080-transition.md §5
    stable_page_namespace: true    # P-* 命名空间是否稳定

  # Step 2: ID 命名空间清单
  available_namespaces:
    page_ids:    [P-ORDER-01, P-ORDER-02, ...]     # 来自 018
    feature_ids: [FT-ORDER-01-001, ...]             # 来自 018
    be_ids:      [BE-ORDER-001, API-ORDER-001, ...] # 来自 019，可为空
    action_ids:  [ACT-ORDER-P01-001, ...]           # 来自 020，可为空
    field_ids:   [FLD-ORDER-P01-001, ...]           # 来自 021，可为空

  # Step 3: 覆盖缺口（N080 未覆盖的 N070 需求）
  n080_coverage_gaps:
    uncovered_req_ids: [REQ-ORDER-005, ...]
    orphan_obj_ids:    [OBJ-ORDER-003, ...]
    disposition: "将在 PRD-15 待确认项中标注"
```

---

## 3. PRD 章节与 N080 ID 的对应关系

以下为 N080 产物到 PRD 章节的标准映射。N090 在生成每个章节时，应将对应 N080 ID 填入该章节的 `upstream_refs[]`：

| PRD 章节 | 主要消费的 N080 产物 | upstream_refs 中的 ref_type |
|---|---|---|
| PRD-03 范围与非范围 | 018 的 missing_page_adjudication[] | page |
| PRD-04 角色与核心场景 | 018 的 feature catalog 中角色行 | feature |
| PRD-05 业务流程/页面概览 | 018 的 page map + feature catalog | page, feature |
| PRD-06 功能需求清单 | 018 FT-* + 019 BE-* | feature, backend |
| PRD-07 业务规则 | 020 ACT-* + 020 confirmation_strength | action |
| PRD-09 权限要求 | 020 ACT-* 的 confirmation_strength = very_strong/strong | action |
| PRD-10 数据对象与关键字段 | 021 FLD-* + 017 OBJ-* | field, object |
| PRD-11 异常与边界处理 | 020 的 missing_confirmation 设计风险条目 | action |
| PRD-12 非功能与约束 | 019 的 missing_endpoint / missing_validation | backend |
| PRD-14 依赖与风险 | 019 的 BE-GAP 条目 | backend |

### 未覆盖 N080 产物的处理

当某个 `FT-*` 或 `ACT-*` 没有对应的 PRD 章节条目时：

```
action: 在 PRD-15 待确认项中添加一条：
  source_ref: FT-ORDER-02-003
  source_skill: 018
  question: "该功能点是否纳入本期 PRD 范围？"
  blocking_level: major
  deadline_proximity: before_review
```

---

## 4. N090 的 N080 覆盖检查 / Coverage Verification

022 完成 PRD 生成后，在 `traceability_summary` 中输出：

```yaml
n080_coverage_report:
  total_features: 24         # 018 输出的 FT-* 总数
  referenced_in_prd: 21      # 被 upstream_refs[] 引用的 FT-* 数
  unreferenced_features:     # 未出现在任何 PRD 章节的 FT-*
    - ft_id: FT-SETTING-03-002
      disposition: out_of_scope | pending_decision | deferred
  
  total_actions: 18          # 020 输出的 ACT-* 总数
  referenced_in_prd: 16
  unreferenced_actions:
    - act_id: ACT-ORDER-P03-002
      disposition: pending_decision

  backend_gaps_addressed: 3  # 019 的 BE-GAP 中已在 PRD 中处理的数量
  backend_gaps_pending: 2    # 未处理的 BE-GAP（将成为 GAP-XXX）
```

`unreferenced_features` 中每条 disposition = `pending_decision` 的，应自动创建 `GAP-XXX` 条目（由 023 补全）。

---

## 5. 交接完成信号 / Handoff Completion Signal

N090 完成后，在 artifact contract header 中输出：

```yaml
n080_to_n090_handoff:
  status: complete | partial | no_upstream
  n080_artifacts_consumed: [018, 019, 020, 021]
  prd_sections_with_upstream_refs: 10    # 有 upstream_refs[] 的 PRD 章节数
  prd_sections_total: 16
  coverage_ratio: 0.625                  # 有 upstream_refs 的章节占比
  unresolved_n080_items: 4              # 未能纳入 PRD 的 N080 条目数
  ready_for_n100: true                   # PRD 完成且可进入 N100 质量检查
```

`ready_for_n100: false` 的条件：PRD-06 或 PRD-07 章节为空，且 N080 有可用功能/动作条目。
