# Orchestration (fused v3)

## 上游
- N070（推荐）：角色图、对象表、权限矩阵、业务规则
- PRD（交叉核对）：仅用于双向缺位对照

## N080 中位置
- **Stage A**：018 必须先执行
- 输出的 §2 page 清单 和 §3 feature catalog 是 019/020/021 的共享输入

## 下游
- 019：消费 §2 page 清单 + §5 后端意图汇总
- 020：消费 §2 page 清单 + §3 feature catalog
- 021：消费 §2 page 清单 + §3 feature catalog 中 form 类 feature
- N090 / N100 / N130 / N230：消费结构化目录做后续设计与测试

## 共同契约要求
- C2：Page ID 是 N080 权威命名空间
- C3：Feature ID 必须稳定且可被 020/021 引用
- C4：§6 反哺与缺页必出
- C5：§7 全局约束碰撞必出
- C7：018 完成后，019/020/021 不得自创 page id
