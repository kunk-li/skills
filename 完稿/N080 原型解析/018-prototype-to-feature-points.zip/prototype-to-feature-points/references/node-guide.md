# N080 原型解析 — 节点导航

> **节点定位**：以原型（HTML/截图/标注稿）为主驱动力，将视觉材料转化为结构化的功能点、后端需求、动作和字段 artifacts。N080 与 N070 互为补充——N070 从文字出发，N080 从视觉出发。

---

## Skills 一览

| ID | Skill | 主要输出 | 适用场景 |
|---|---|---|---|
| 018 | prototype-to-feature-points | FT-* 功能点目录 + 页面地图 P- | 任何有原型的分析起点 |
| 019 | prototype-to-backend-requirements | BE-*/API-* 后端能力清单 | 需要推导服务端接口和存储需求 |
| 020 | page-action-extraction | ACT-* 动作清单 + 确认强度评估 | 需要完整捕获用户操作及风险 |
| 021 | form-field-extraction | FLD-*/F* 字段和表单清单 | 需要结构化字段约束和条件规则 |

---

## 推荐执行顺序

```
018（首先运行，建立共享页面命名空间）→ 019 → 020 → 021
```

018 建立的 `P-{module}-{nn}` 页面 ID 是整个 N080 的锚点，其他三个 skill 均复用此 ID。

---

## 三档运行模式（必须在输出中声明）

| 模式 | 条件 | 处理方式 |
|---|---|---|
| `has-prototype` | 完整原型可用 | 原型证据作为权威 |
| `partial-prototype` | 部分页面/截图 | 有原型的按原型处理，缺失的标注 `source-derived` |
| `no-prototype` | 无原型 | 从 N070 输出 + 文字推断，全部标注 `source-derived` |

---

## 关键共享契约

**N080_COMMON_CONTRACTS.md**（每个 skill 目录内各有一份）：

- **C0**：三层置信度（confirmed / stable_inference / needs_confirmation）
- **C1**：fallback 三档模式定义
- **C2**：页面命名空间 `P-{module}-{nn}`（所有 N080 skill 必须复用）
- **C3**：跨 skill ID 命名空间（FT-/BE-/API-/ACT-/FLD-/F*）
- **C4**：双向反哺（upstream_feedback + missing_page 裁决）
- **C5**：兄弟 skill 更新策略

---

## 020 特别说明：确认强度量化评分

**必须阅读 `references/confirmation-strength-model.md`**（该文件包含量化决策矩阵）

对每个 action，在三维度打分：
- 可逆性（0-4）× 影响规模（0-4）× 合规敏感度（0-4）
- 总分 ≤2 → weak；3-5 → medium；6-8 → strong；9-12 → very_strong
- Hard overrides：资金划拨/合规提交/永久删除 → very_strong（优先于总分）

---

## 与 N090 的交接规则

N080 输出流入 N090（PRD 产出）时：
- N090 使用 PRD-01..PRD-12 章节 ID，但**尚未定义 N080 的 P-/FT-/ACT-/FLD- 如何嵌入**
- 当前建议：在 N090 output 的每个 PRD 章节中，手动在 `upstream_refs[]` 字段记录对应的 N080 ID
- 反哺方向：原型发现的 N070 缺口，写入 `upstream_feedback[]` → 推送给 022 prd-generation 作为输入

---

## 跨节点交接协议

- 上游：参见 `transitions/N070-N080-transition.md`（如何消费 N070 词汇）
- 下游：参见 `transitions/N080-N090-transition.md`（如何向 N090 交付 P-/FT-/ACT-/FLD-）

N080 完成后须在 output summary 中输出 `n070_to_n080_handoff` 块（含 `ready_for_n090` 信号），N090 方可启动。

## 常见误用

| 误用 | 正确做法 |
|---|---|
| 018 和 020 用不同的页面 ID | 018 优先运行并建立 P-*，020/021 必须复用相同的 P-* |
| 把 "稳定推断" 写成已确认事实 | 置信度使用 C0 三层：confirmed / stable_inference / needs_confirmation |
| 020 的 very_strong 凭主观判断 | 使用 confirmation-strength-model.md 三维打分矩阵 |
| 019 不存在时直接猜 BE- | 在 `upstream_alignment` 段标注 N070 vocabulary 来源 |
