# Example I/O (generic)

## Example: P-OPS-05 项目成员管理（节选）

### Known evidence
- 018 §2 已给出 page id `P-OPS-05`
- 018 §3 已识别 feature：查看成员、添加成员、移除成员
- N070 已识别对象：Project、User、Project_Member_Assignment

### Output (§3 Backend capability list excerpt)

| capability_id | 能力名称 | 触发页面 | 优先级 | N070 对应 | 备注 | 证据 |
|---|---|---|---|---|---|---|
| BE-OPS-06 | 查询项目成员列表 | P-OPS-05 | P0 | F-OPS-011 | 需返回成员、角色、到期时间 | prototype.html#P-OPS-05 |
| BE-OPS-07 | 创建项目成员关系 | P-OPS-05 | P0 | F-OPS-012 | 可能存在成员上限校验 | prototype.html#P-OPS-05 |
| BE-OPS-08 | 移除项目成员关系 | P-OPS-05 | P1 | F-OPS-013 | 是否要求二次确认待定 | prototype.html#P-OPS-05 |

### Output (§4 Page-to-API mapping excerpt)

| api_id | 页面 | HTTP method + 路径 | 请求参数 | 关键校验 | 后端依赖 |
|---|---|---|---|---|---|
| API-OPS-12 | P-OPS-05 | GET /projects/{project_id}/members | project_id, role?, status? | 访问权限、项目存在性 | BE-OPS-06 |
| API-OPS-13 | P-OPS-05 | POST /projects/{project_id}/members | user_id, role, expires_at | 成员上限、角色合法性、重复关系 | BE-OPS-07 |
| API-OPS-14 | P-OPS-05 | DELETE /projects/{project_id}/members/{member_id} | member_id | 删除权限、关系存在性 | BE-OPS-08 |

### Output (§7 Missing backend assumptions excerpt)

| # | 假设的后端行为 | 原型暗示位置 | 影响 | 决策方 | 风险 |
|---|---|---|---|---|---|
| 1 | 移除成员后会同步回收关联任务权限 | 成员行操作包含“影响访问范围”提示 | 影响权限一致性与审计 | 产品 + 后端 | 中 |
