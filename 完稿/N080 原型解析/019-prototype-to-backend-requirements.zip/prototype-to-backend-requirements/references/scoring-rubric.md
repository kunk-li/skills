# Scoring Rubric (v3)

| Dimension | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| backend capability coverage | full | >= 90% | >= 70% | < 70% |
| API mapping completeness | strong and evidence-bound | >= 90% | >= 70% | weak |
| authoritative object naming | 100% | >= 95% | >= 80% | drift |
| validation depth | multi-type and structured | >= 80% | >= 50% | shallow |
| BE-GAP coverage | all missing backend assumptions captured | >= 80% | >= 50% | weak |
| BE-GAP taxonomy use | 100% typed | >= 90% | >= 70% | not typed |
| global constraints and feedback | complete | mostly complete | partial | missing |

---

## 边界 Case 对照表 / Boundary Case Reference

| Case | 描述 | 正确处理 | 常见误判 | 判别理由 |
|---|---|---|---|---|
| 前端可见但无后端 | 纯展示类数据（如用户头像 URL） | 不产出 BE-GAP，标注 frontend_only | 产出 missing_endpoint | 无服务端逻辑的展示不需要 API |
| 同端点多功能 | 一个 API endpoint 同时支持查询和更新 | 分别记录两个 BE-* 条目，共享 endpoint | 合并为一条 | 不同业务能力应独立溯源 |
| 推断出的 API | 原型按钮说"提交"但无明确后端说明 | confidence=stable_inference，标注推断依据 | confidence=confirmed | 原型无明确 API 描述不构成确认 |
| 外部系统调用 | 系统调用第三方支付 API | 产出 missing_dependency 类型的 BE-GAP | 产出 missing_endpoint | 外部依赖不属于内部 API 设计 |
| 批量操作 | 批量删除、批量状态变更 | 单独产出 BE-* 条目，标注 batch_supported=true | 与单条合并 | 批量接口通常有独立的参数结构 |
| 无状态纯计算 | 如"价格计算器"（前端 JS 计算） | 不产出 BE-*，在 upstream_feedback 中标注 | 产出 missing_endpoint | 前端计算不产生服务端依赖 |
