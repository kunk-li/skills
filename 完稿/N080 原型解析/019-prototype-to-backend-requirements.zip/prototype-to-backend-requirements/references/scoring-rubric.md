# Scoring Rubric (v3)

| Dimension | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| backend capability coverage | full | >= 90% | >= 70% | < 70% |
| API mapping completeness | strong and evidence-bound | >= 90% | >= 70% | weak |
| authoritative object naming | 100% | >= 95% | >= 80% | drift |
| validation depth | multi-type and structured | >= 80% | >= 50% | shallow |
| BE-GAP coverage | all missing backend assumptions captured | >= 80% | >= 50% | weak |
| BE-GAP taxonomy use | 100% typed | >= 90% | >= 70% | not typed |
| global constraints and feedback | complete | mostly complete | partial | missing |
