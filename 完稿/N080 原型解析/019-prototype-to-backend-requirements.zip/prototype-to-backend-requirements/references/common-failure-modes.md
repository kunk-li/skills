# Common Failure Modes (v3)

## FM-1 · object name drift
Use authoritative upstream object names whenever available.

## FM-2 · missing backend capability for obvious write paths
Any visible submit, delete, approve, export, or state-change path should trigger a backend capability row.

## FM-3 · API details over-specified
Do not invent payload shapes, transactions, or idempotency details from weak UI hints.

## FM-4 · validation types incomplete
Cover multiple rule types instead of compressing everything into `required`.

## FM-5 · external dependencies omitted
If a path clearly depends on a dictionary service, file service, or third-party integration, record it.

## FM-6 · query and write paths mixed together
Separate read and write APIs where the evidence supports that split.

## FM-7 · BE-GAP items not surfaced
Implicit backend needs must become explicit BE-GAP items.

## FM-8 · BE-GAP taxonomy missing
Every gap must be typed as `missing_object`, `missing_endpoint`, `missing_validation`, or `missing_event`.

## FM-9 · API namespace drift
If downstream API documentation exists, keep the same API IDs instead of renumbering them.
