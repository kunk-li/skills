# BE-GAP Taxonomy / BE-GAP 缺口分类

Use these four categories in 019 whenever prototype evidence or fallback artifacts imply missing backend support.

| gap_type | Meaning | Example |
|---|---|---|
| missing_object | data object or dictionary is implied but not defined upstream | settlement_rule, secondary_role |
| missing_endpoint | capability is implied but no stable API contract exists | bulk-approve endpoint missing |
| missing_validation | validation or guard is implied but not defined | duplicate prevention, quota guard |
| missing_event | event, callback, or async side effect is implied but not defined | compliance_weekly event, webhook callback |

Usage rules:
- Every BE-GAP item must pick exactly one primary `gap_type`.
- If one gap has multiple symptoms, classify it by the most actionable missing element first.
- High-risk gaps should explicitly feed N160, N230, or downstream API documentation.
