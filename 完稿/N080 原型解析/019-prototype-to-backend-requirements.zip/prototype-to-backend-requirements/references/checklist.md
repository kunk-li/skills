# Checklist (v3)

## Inputs and boundaries
- [ ] active operating mode declared
- [ ] page namespace imported from 018 or explicitly self-generated
- [ ] N070 vocabulary used when available
- [ ] prototype-absent fallback stayed evidence-bound

## Namespaces
- [ ] page IDs are stable
- [ ] `BE-{module}-{nn}` IDs are unique
- [ ] `API-{module}-{nn}` IDs are unique
- [ ] downstream API namespace stability is preserved

## Content depth
- [ ] every capability is traceable to a page or fallback artifact
- [ ] every API row includes method/path, parameters, core validation, and backend dependencies as far as evidence allows
- [ ] validation rules are typed, not flattened into one vague sentence
- [ ] every BE-GAP item uses one of the 4 gap types

## Two-way feedback and constraints
- [ ] feedback list exists
- [ ] missing-page adjudication exists
- [ ] global-constraint scan exists

## Output hygiene
- [ ] fixed template followed
- [ ] confirmed fact / stable inference / needs confirmation are separated
- [ ] self-check completed
