# Orchestration (fused v3)

## 上游
- 018（必备）：§2 page 清单、§3 feature catalog、§5 后端意图汇总
- N070（推荐）：§4 对象、§5 权限矩阵、业务规则、状态流转
- PRD（交叉核对）

## N080 中位置
- **Stage B**：建议与 020 / 021 并行
- 若 020 / 021 先产出，可先用 `API-TBD` 占位，Stage C 必须回补为真实 `API-` / `BE-` ID

## 下游
- N130：§3 后端能力清单 + §4 page-to-api mapping
- N230：§4 page-to-api mapping + §6 校验规则清单
- N100：§8 / §9 反哺与约束命中

## 共同契约要求
- C2：Page ID 必须与 018 一致
- C3：`BE-` / `API-` ID 全局唯一，可被 020 / 021 引用
- C4：双向反哺必出
- C5：全局约束碰撞必出
- C8：异构表必须拆分为独立 csv，禁止宽表并集
