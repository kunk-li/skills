# Output Template (v3)

Use the fixed structure below.

## 1. Summary
Include active mode, BE count, API count, data-mapping count, validation count, and BE-GAP count.

## 2. Confirmed facts
Only facts strongly grounded by source evidence.

## 3. Backend capability list
| capability_id | capability_name | page_id | priority | upstream_ref | notes | evidence |
|---|---|---|---|---|---|---|

Rules:
- in multi-skill mode, `upstream_ref` should point to the matching 018 `§5 Backend intent summary` row when available
- in standalone mode, `upstream_ref` may be `self-derived`, but §1 Summary must declare standalone mode and page-namespace provenance
- if a future `confidence` column is added, values must use the C0.1 enum from `N080_COMMON_CONTRACTS.md`

## 4. Page-to-API mapping
| api_id | page_id | method_and_path | key_params | key_validations | backend_dependencies |
|---|---|---|---|---|---|

## 5. Page-to-data mapping
| page_id | primary_object | field_subset | source | cross_module |
|---|---|---|---|---|

## 6. Validation list
| validation_type | validation_point | trigger_location | failure_feedback | layer |
|---|---|---|---|---|

## 7. BE-GAP register
| # | gap_type | missing_backend_item | evidence_location | impact | owner | risk |
|---|---|---|---|---|---|---|

Use one primary `gap_type` from the four-type taxonomy.

## 8. Two-way feedback
## 9. Global-constraint collisions
## 10. Needs-confirmation items
## 11. Self-check
Include page alignment, BE/API uniqueness, authoritative object naming, BE-GAP typing, C4, C5, and evidence layering.
