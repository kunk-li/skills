---
name: prototype-to-backend-requirements
description: extract backend capabilities, api mappings, data mappings, validation needs, and be-gap items from prototypes, partial prototypes, or prototype-absent fallback artifacts during n080 prototype-driven analysis. use after or alongside 018 to derive stable be- and api- namespaces, keep api ids reusable by downstream api documentation, and surface missing objects, endpoints, validations, or events without guessing implementation.
---

# Prototype To Backend Requirements (fused v4)

Infer backend-ready capabilities, API mappings, data mappings, validation needs, and BE-GAP items from prototype evidence or approved fallback artifacts.

## Operating modes / 运行模式
- `has-prototype`
- `partial-prototype`
- `inferred-from-prototype-absent`

The active mode must be declared in the summary. In `inferred-from-prototype-absent` mode, every non-obvious API or backend inference must carry explicit provenance and confidence.

## Standalone and collaboration modes / 单独与组合模式
### Standalone mode / 单独使用
- Can run with prototype material alone, or with prototype-absent fallback artifacts when no prototype exists.
- May self-generate page IDs if 018 is unavailable, but must declare that the namespace is self-generated.
- May use `source-derived` object names when authoritative upstream vocabulary is missing.

### Multi-skill mode / 组合使用
- Reuse the page namespace and feature catalog from 018 whenever possible.
- Reuse authoritative object, role, and rule vocabulary from N070 whenever available.
- Produce `BE-` and `API-` IDs that downstream skills can consume directly, including later API-documentation work.

## Standalone use cases / 独立使用场景
- backend capability discovery from clickable prototypes
- legacy UI or PRD to API-gap reconstruction when backend docs are incomplete
- microservice boundary sizing based on page-triggered capabilities
- pre-PRD technical feasibility mapping for a new module

## Fallback behavior / 降级策略
- Without 018: build the page namespace directly from source material and declare it `self-generated`.
- Without N070: use source wording but mark object names and rules `source-derived`.
- Without global context: still keep the global-constraint section and note that the context was not provided.
- Without prototype material: switch to `inferred-from-prototype-absent` mode and keep implementation details in `needs_confirmation` unless documentation is strong enough.

## Position in N080 / 节点定位
- **Stage B** (parallel with 020 and 021)
- Upstream: 018 (recommended), N070 (recommended)
- Downstream: N130, N230, N100, and any downstream API documentation or interface inventory skill

## Inputs / 输入边界
### Allowed inputs
- primary: prototype HTML, screenshots, annotated mockups, prototype descriptions
- recommended upstream: 018 page inventory and feature catalog
- recommended upstream: N070 object catalog, permission matrix, business rules
- recommended secondary: global context and domain glossary
- cross-reference: PRD text, API docs, acceptance criteria, release notes

### Prohibited
- current database state
- current code state
- undocumented oral background

## Role / 角色定位
Produce:
1. backend capability list (`BE-{module}-{nn}`)
2. page-to-api mapping (`API-{module}-{nn}`)
3. page-to-data mapping
4. validation catalog
5. BE-GAP register with explicit gap types
6. two-way feedback, global-constraint collisions, and self-check

## Workflow
1. import or build the page namespace
2. create the backend capability list and trace each capability to a page and upstream requirement when possible
3. derive API rows, but only as far as the evidence stably supports
4. build page-to-data mapping with authoritative object names whenever possible
5. classify validation rules and missing backend assumptions
6. classify every BE-GAP item using `references/be-gap-taxonomy.md`
7. output C4, C5, and C7

## Output contract
Follow `references/output-template.md` and always include:
- backend capability list
- page-to-api mapping
- page-to-data mapping
- validation list
- BE-GAP register
- two-way feedback
- global-constraint collisions
- needs-confirmation items
- self-check

## Boundary rules / 边界规则
- API paths, methods, and validation expectations must be traceable to prototype evidence or approved fallback artifacts.
- In multi-skill mode, each row in `§3 Backend capability list` should preferentially cite the matching intent hint from 018 `§5 Backend intent summary` as `upstream_ref`.
- In standalone mode, `upstream_ref` may be `self-derived`, but `§1 Summary` must explicitly declare standalone mode and whether the page namespace is self-generated.
- If 019 discovers a capability that 018 missed during multi-skill execution, record it in `C4.1 upstream feedback` instead of silently adding an uncited upstream mapping.
- When downstream API-documentation generation exists, keep the `API-` namespace stable instead of renumbering.
- Do not invent payload shapes, transaction boundaries, idempotency behavior, or internal table design from weak visual hints.
- Every BE-GAP item must use one of four primary categories: `missing_object`, `missing_endpoint`, `missing_validation`, or `missing_event`.

## Minimal embedded contract / 最小内嵌契约
Even if `N080_COMMON_CONTRACTS.md` is not opened, this skill must still:
- declare the active operating mode
- use `BE-{module}-{nn}` and `API-{module}-{nn}` namespaces
- keep page IDs aligned with 018 when 018 exists
- classify every BE-GAP item with the 4-type taxonomy
- keep object names authoritative or explicitly mark them `source-derived`
- output two-way feedback, global-constraint collisions, and self-check

## Quality bar
- Prefer the full C0-C10 contract from `N080_COMMON_CONTRACTS.md`.
- Target at least **12/14** against `references/scoring-rubric.md`.
- If below bar, say which backend assumptions, API details, or data mappings remain unresolved.

## Reference files / 参考文件
- `N080_COMMON_CONTRACTS.md` (required, min contract_version 1.0.0)
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/be-gap-taxonomy.md`


## Workflow v2 artifact contract
```yaml
artifact_type: n080.backend-requirements
schema_version: "1.1.0"
producer_skill: prototype-to-backend-requirements
consumer_nodes: [N090, N100, N150]
workflow_alias: 后端需求清单.md
produced_event_name: produced.n080.backend-requirements
canonical_fields:
  - be_id          # BE-{module}-{nnn}
  - api_id         # API-{module}-{nnn}
  - capability
  - method
  - path
  - confidence
  - be_gap_type    # missing_object / missing_endpoint / missing_validation / missing_event
  - evidence
n005_consumption: indirect
```


## Self-check / 节点内自检

按 `N080_COMMON_CONTRACTS.md §C7` 自检清单执行（必做）：
- 页面命名空间一致性（所有兄弟 skill 使用相同 P-* ID）
- 元素 ID 唯一性
- upstream_feedback 和缺页裁决已输出
- fallback 模式已声明
- cross-skill ID 引用完整
并按 `references/scoring-rubric.md` 做质量评分（目标 ≥ 3）。

## Key references
- `references/cross-node-bridge-contract.md`：N080→N090 upstream_refs 规范 + N100 GAP 回写规则（跨节点桥接契约）
- `references/n080-scoring-model.md`：**N080 量化评分公式（evidence_score + vocab_alignment + readiness_score 综合得分 + hard overrides）（必读）**
- `../018-prototype-to-feature-points/prototype-to-feature-points/references/node-guide.md`：**N080 节点导航——4 个 skill 执行顺序、三档 fallback 模式、与 N090 交接规则（必读，见 018）**
- `../018-prototype-to-feature-points/prototype-to-feature-points/references/handoff-to-n090.md`：**N080→N090 节点交接协议——BE-*/API-* ID 到 PRD 章节映射规则（必读，见 018）**

- `N080_COMMON_CONTRACTS.md`：**N080 节点契约：页面命名空间、跨 skill ID、fallback 三档模式（必读）**
- `references/be-gap-taxonomy.md`：**BE-GAP 四类缺口分类定义（必读）**
- `references/scoring-rubric.md`：质量评分 1-4 级标准
- `references/output-template.md`：输出结构
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
