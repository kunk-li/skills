---
name: form-field-extraction
description: Extract field catalogs, validation rules, defaults, conditional and display logic, and data-source hints for submission and query/filter forms, including schema-driven dynamic forms.
---

# Form Field Extraction (fused v4)

Extract field catalogs, validation rules, default values, conditional rules, display logic, linkage, and data-source hints. This skill must cover **both submission forms and query/filter forms**.

## Operating modes / 运行模式
- `has-prototype`
- `partial-prototype`
- `inferred-from-prototype-absent`

The active mode must be declared in the summary. In prototype-absent mode, conditional rules should use compact DSL or stay in `needs_confirmation` instead of drifting into prose guesses.

## Standalone and collaboration modes / 单独与组合模式
### Standalone mode / 单独使用
- Can extract field catalogs directly from prototypes or approved fallback artifacts.
- May self-generate form and field IDs when 018 is not available.
- May use `API-TBD`, `query_param`, or textual submission targets when 019 is not available.

### Multi-skill mode / 组合使用
- Reuse page and form-bearing feature context from 018.
- Reuse `API-` IDs from 019 for submission targets.
- Reuse N070 object vocabulary, rule IDs, and permission clues when they exist.

## Standalone use cases / 独立使用场景
- form inventory for CRM, HR, finance, or workflow systems
- reverse mapping from UI forms to downstream schema design
- validation-rule discovery before test design
- schema-driven dynamic form analysis in legacy systems with incomplete design docs

## Fallback behavior / 降级策略
- Without 018: identify forms, filters, and search regions directly from source materials.
- Without 019: keep submission targets explicit but non-empty using `API-TBD`, `query_param`, or textual descriptions.
- Without N070: use source wording for rule/object names and mark them `source-derived` when needed.
- Without prototype material: switch to `inferred-from-prototype-absent` mode and keep conditional rules formal and conservative.

## Position in N080 / 节点定位
- **Stage B** (parallel with 019 and 020)
- Upstream: 018 (recommended), 019 (recommended), N070 (recommended)
- Downstream: N130 schema/data design, N230 validation and boundary testing, N100 quality review

## Inputs / 输入边界
### Allowed inputs
- primary: prototype HTML, screenshots, annotated mockups, prototype descriptions
- recommended upstream: 018 form-bearing feature catalog
- recommended upstream: 019 API catalog
- recommended upstream: N070 object catalog, rules, permission matrix
- cross-reference: PRD text, API docs, acceptance criteria

### Prohibited
- current database state
- current code state
- undocumented oral background

## Role / 角色定位
Extract fields for both submission and query/filter surfaces, including:
1. field catalog
2. validation catalog
3. defaults
4. display logic
5. data sources
6. reverse cross-check against upstream object catalogs
7. missing field definitions, two-way feedback, global-constraint collisions, and self-check

## Workflow
1. import or build the page and form inventory
2. identify submission forms and query/filter forms
3. classify each form as static or schema-driven using `references/form-schema-patterns.md`
4. extract fields and fill all fixed columns
5. write conditional required, visibility, or default logic using the DSL in `references/conditional-required-dsl.md`
6. bind submission targets using 019 when possible
7. reverse-check fields against upstream object definitions
8. output C4, C5, and C7

## Output contract
Follow `references/output-template.md` and always include:
- field catalog
- validation rules summary
- default values summary
- display conditions summary
- data-source summary
- two-way feedback
- global-constraint collisions
- reverse object cross-check
- missing field definitions
- self-check

## Boundary rules / 边界规则
- Query and filter fields are mandatory scope, not optional extras.
- Conditional required, visible, enabled, or default rules must use compact DSL fragments such as `required_if:` or `visible_if:` whenever the condition is stable enough.
- If a form is schema-driven, identify the controlling field and record shared fields plus representative branch fields.
- Do not flatten a schema-driven form into a fake static form just because the full branch catalog is incomplete.

## Minimal embedded contract / 最小内嵌契约
Even if `N080_COMMON_CONTRACTS.md` is not opened, this skill must still:
- declare the active operating mode
- cover both submission and query/filter forms
- use stable `FLD-{module}-P{page_seq}-{nn}` IDs and `F{seq}` form IDs
- keep submission targets explicit and non-empty
- use DSL fragments for stable conditional rules instead of free-text descriptions
- output two-way feedback, global-constraint collisions, reverse cross-check, and self-check

## Quality bar
- Prefer the full C0-C10 contract from `N080_COMMON_CONTRACTS.md`.
- Target at least **12/14** against `references/scoring-rubric.md`.
- If below bar, explicitly state which fields, branches, or rules remain unresolved.

## Reference files / 参考文件
- `N080_COMMON_CONTRACTS.md` (required, min contract_version 1.0.0)
- `references/output-template.md`
- `references/checklist.md`
- `references/common-failure-modes.md`
- `references/orchestration.md`
- `references/scoring-rubric.md`
- `references/example-io.md`
- `references/conditional-required-dsl.md`
- `references/form-schema-patterns.md`


## Workflow v2 artifact contract
```yaml
artifact_type: n080.form-fields
schema_version: "1.1.0"
producer_skill: form-field-extraction
consumer_nodes: [N090, N100, N150]
workflow_alias: 表单字段清单.md
produced_event_name: produced.n080.form-fields
canonical_fields:
  - field_id       # FLD-{module}-P{page_seq}-{nnn}
  - form_id        # F{seq}
  - page_id
  - field_name
  - type
  - required
  - conditional_required_expr    # DSL 条件必填表达式
  - validation_rules[]
  - confidence
  - evidence
n005_consumption: indirect
```


## Self-check / 节点内自检

按 `N080_COMMON_CONTRACTS.md §C7` 自检清单执行（必做）：
- 页面命名空间一致性（所有兄弟 skill 使用相同 P-* ID）
- 元素 ID 唯一性
- upstream_feedback 和缺页裁决已输出
- fallback 模式已声明
- cross-skill ID 引用完整
并按 `references/scoring-rubric.md` 做质量评分（目标 ≥ 3）。

## Key references
- `references/cross-node-bridge-contract.md`：N080→N090 upstream_refs 规范 + N100 GAP 回写规则（跨节点桥接契约）
- `references/n080-scoring-model.md`：**N080 量化评分公式（evidence_score + vocab_alignment + readiness_score 综合得分 + hard overrides）（必读）**
- `../018-prototype-to-feature-points/prototype-to-feature-points/references/node-guide.md`：**N080 节点导航——4 个 skill 执行顺序（必读，见 018）**
- `../018-prototype-to-feature-points/prototype-to-feature-points/references/handoff-to-n090.md`：**N080→N090 节点交接协议——FLD-*/F* 到 PRD-10 映射规则（必读，见 018）**

- `N080_COMMON_CONTRACTS.md`：**N080 节点契约：页面命名空间、跨 skill ID（必读）**
- `references/conditional-required-dsl.md`：**条件必填 DSL 语法及表达限制（必读）**
- `references/form-schema-patterns.md`：常见表单结构模式
- `references/scoring-rubric.md`：质量评分 1-4 级标准
- `references/output-template.md`：输出结构
- `references/checklist.md`：交付前自检清单
- `references/common-failure-modes.md`：常见错误模式
