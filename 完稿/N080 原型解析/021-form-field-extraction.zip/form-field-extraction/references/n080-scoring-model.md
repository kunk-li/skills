# N080 量化评分模型 / N080 Quantitative Scoring Model

本文件为 N080 四个 skill（018/019/020/021）提供统一的量化评分框架，补充各 skill 的 scoring-rubric.md 中的定性 1-4 分评估。

---

## 1. 共同评分维度（所有 N080 skill 适用）

### 1.1 证据覆盖率 / Evidence Coverage Score

```
evidence_score = (
  confirmed_items / total_items
) × 100

confirmed_items: confidence = "confirmed" 的条目数
total_items:     所有输出条目总数（含 needs_confirmation）
```

| evidence_score | 等级 |
|---:|---|
| ≥ 80 | excellent |
| 60–79 | review-ready |
| 40–59 | usable with gaps |
| < 40 | needs rework |

### 1.2 N070 词汇对齐率 / Vocabulary Alignment Score

```
vocab_alignment_score = (
  items_using_n070_vocab / total_items_that_could_reference_n070
) × 100

若 N070 输出不可用（has-prototype 且无 N070）：此维度标记 not_applicable
```

| vocab_alignment_score | 等级 |
|---:|---|
| ≥ 80 | strong alignment |
| 50–79 | acceptable |
| < 50 | naming drift risk → 需补充 upstream_feedback |

### 1.3 N080 输出就绪分 / Output Readiness Score

所有 N080 skill 共享如下输出就绪计算：

```
readiness_score = 100 - (
  missing_required_fields  × 10 +
  unresolved_needs_confirmation_blocking × 15 +
  missing_upstream_feedback × 8 +
  page_namespace_violations × 20
)
clip to [0, 100]
```

扣分说明：
- `missing_required_fields`：输出模板中标为 required 的字段缺失数
- `unresolved_needs_confirmation_blocking`：confidence=needs_confirmation 且 blocking=true 的条目数
- `missing_upstream_feedback`：有原型证据但未写 upstream_feedback 的反哺候补数
- `page_namespace_violations`：使用了与 018 P-* 不一致的页面 ID 数

### 1.4 综合得分公式

```
n080_overall_score = (
  0.35 × evidence_score +
  0.25 × vocab_alignment_score +   # N070 不可用时设为 evidence_score 替代
  0.40 × readiness_score
)
```

| n080_overall_score | pass_readiness |
|---:|---|
| ≥ 85 | ready |
| 70–84 | conditional_ready |
| 50–69 | needs_action |
| < 50 | not_ready |

---

## 2. Skill 专项评分补充

### 018 prototype-to-feature-points 专项

```
coverage_ratio = ft_ids_produced / n070_req_count_in_scope

若 N070 不可用：coverage_ratio = not_applicable

建议：coverage_ratio ≥ 0.7 时视为"覆盖充分"
```

额外扣分项（加入 readiness_score 计算）：
- 缺 page map（整个 §2 空白）：−30
- 缺 feature catalog（§3 空白）：−30
- fallback_mode 未声明：−10

### 019 prototype-to-backend-requirements 专项

```
be_gap_coverage = be_gap_items_with_routing / total_be_gap_items

routing：每条 BE-GAP 指向了 N160/N230 等下游节点
```

额外扣分项：
- BE-GAP 条目无 `gap_type`（missing_object/endpoint/validation/event）：每条 −5
- 与 018 的 P-* / FT-* 命名空间不一致：每处 −10

### 020 page-action-extraction 专项

```
confirmation_coverage = actions_with_confirmation_score / total_irreversible_actions

irreversible_actions：effect 含 permanent_delete / financial / compliance 的条目
```

额外扣分项：
- 明显不可逆的动作（ACT-* 含 delete/submit/release/export）无 `confirmation_strength` 字段：每条 −15
- `confirmation_strength_score` 三维合计缺失（只给枚举不给分数）：每条 −5

### 021 form-field-extraction 专项

```
field_contract_completeness = fields_with_constraint / total_fields

constraint：有 type / validation_rule / conditional_required 至少之一
```

额外扣分项：
- 有 conditional_required 但无 DSL 表达式：每字段 −8
- 枚举类字段无 allowed_values 列表：每字段 −5

---

## 3. 评分输出要求

每个 N080 skill 的输出中必须包含：

```yaml
n080_quality_metrics:
  evidence_score: <0-100>
  vocab_alignment_score: <0-100 | not_applicable>
  readiness_score: <0-100>
  overall_score: <0-100>
  pass_readiness: ready | conditional_ready | needs_action | not_ready
  skill_specific:
    # 018: coverage_ratio
    # 019: be_gap_coverage
    # 020: confirmation_coverage
    # 021: field_contract_completeness
    metric_name: <metric_value>
  deduction_log:
    - reason: "missing_required_fields"
      count: 2
      deduction: 20
```

---

## 4. Hard Overrides（优先于 overall_score）

以下任一条件触发 pass_readiness = not_ready，无论分数多高：

```
1. page_namespace_violations > 0 且非首次运行
   （已有 P-* 命名空间的情况下仍使用自定义 page ID）

2. fallback_mode 未声明

3. ready_for_n090 = false
   （N080 内部兄弟 skill 尚未达到输出要求）

4. confidence=confirmed 的条目数 < 1
   （全部为推断，无任何直接原型证据）
```
