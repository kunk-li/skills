# Checklist (v3)

## Inputs and boundaries
- [ ] active operating mode declared
- [ ] page/form inventory imported or self-generated
- [ ] submission and query/filter forms both covered
- [ ] schema-driven vs static classification performed when relevant

## Namespaces
- [ ] page IDs stable
- [ ] field IDs unique
- [ ] form IDs consistent across sections

## Content depth
- [ ] every field row has all fixed columns
- [ ] validation rules are multi-dimensional
- [ ] conditional rules use DSL fragments instead of loose prose when stable enough
- [ ] data sources are from the fixed source taxonomy
- [ ] reverse object cross-check completed

## Output hygiene
- [ ] feedback exists
- [ ] global-constraint scan exists
- [ ] self-check completed
