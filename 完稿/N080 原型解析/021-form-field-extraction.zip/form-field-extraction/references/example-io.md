# Example I/O (generic)

## Example: schema-driven ticket form

### Field catalog excerpt
| field_id | field_name | form_id | field_type | default_value | required | validation_rules | linkage | display_logic | data_source | submit_target | confidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| FLD-OPS-P03-01 | ticket_type | F3 | select | none | yes | enum dictionary | none | always | dictionary_api | API-OPS-22 ticket_type | confirmed |
| FLD-OPS-P03-02 | usdt_amount | F3 | input.number | none | `required_if: ticket_type == "USDT"` | `range: > 0` | none | `visible_if: ticket_type == "USDT"` | user_input | API-OPS-22 usdt_amount | stable_inference |
| FLD-OPS-P03-03 | wallet_address | F3 | input.text | none | `required_if: ticket_type in ["USDT", "CHAIN_TRANSFER"]` | `format: wallet_address` | none | `visible_if: ticket_type in ["USDT", "CHAIN_TRANSFER"]` | user_input | API-OPS-22 wallet_address | stable_inference |

### Reverse object cross-check excerpt
| field | mapped_object | listed_in_upstream | note |
|---|---|---|---|
| usdt_amount | Settlement_Request | no | feed back to upstream object catalog |
