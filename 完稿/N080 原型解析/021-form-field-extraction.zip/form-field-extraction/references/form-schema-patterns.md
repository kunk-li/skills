# Form Schema Patterns / 静态表单与 schema 驱动表单模式

Use this note in 021 to separate static forms from schema-driven forms.

## Static form
- Field set is fixed.
- Field inventory can be fully enumerated in one pass.
- Examples: login form, profile edit form, simple search filter.

## Schema-driven form
- Field set changes with a controlling value such as ticket type, product type, region, or role.
- The output should capture common fields plus representative field groups for major branches.
- Conditional rules must use DSL snippets such as `required_if:` and `visible_if:`.

## Extraction rule
- Always identify the controlling field.
- Record shared fields first.
- Then record representative branch fields for the top-level branches that materially change validation or submission payload.
- If the branch catalog is incomplete, mark the missing schema as `needs_confirmation` instead of pretending the form is static.
