# Common Failure Modes (v3)

## FM-1 · query or filter forms skipped
Query and filter fields are mandatory scope.

## FM-2 · field naming drift
Keep business-facing field names stable and avoid mixing labels with technical aliases.

## FM-3 · validation rules collapsed to `required`
Cover format, uniqueness, length, range, dictionary, immutable, and linkage rules when evidence exists.

## FM-4 · RBAC or state-based visibility omitted
Display logic often depends on role, state, or step progression.

## FM-5 · reverse object cross-check missing
The reverse cross-check is one of the main value-adds of 021 and must not be skipped.

## FM-6 · natural-language conditional rules
If a conditional requirement is stable enough, write it as `required_if:` or a related DSL fragment rather than vague prose.

## FM-7 · schema-driven form flattened into static form
Identify the controller field and record representative branch fields instead of pretending all branches are the same.
