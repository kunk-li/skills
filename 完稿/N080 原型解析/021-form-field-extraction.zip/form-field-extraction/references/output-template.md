# Output Template (v3)

Use the fixed 12-section structure. Submission forms and query/filter forms are both mandatory.

## 1. Summary
Include active mode, form counts by class, field count, and reverse-cross-check findings.

## 2. Confirmed facts
## 3. Field catalog
| field_id | field_name | form_id | field_type | default_value | required | validation_rules | linkage | display_logic | data_source | submit_target | confidence |
|---|---|---|---|---|---|---|---|---|---|---|---|

Rules:
- use `API-{module}-{nn}` for submit targets when available
- use `query_param` for query/filter targets
- conditional requirements and display logic should use DSL fragments such as `required_if:` and `visible_if:` when stable enough
- `confidence` must use the three-value enum from `N080_COMMON_CONTRACTS.md` C0.1: `confirmed`, `stable_inference`, or `needs_confirmation`

## 4. Validation rules summary
| field_id | validation_type | rule_detail | failure_message | implementation_layer |
|---|---|---|---|---|

## 5. Default values summary
## 6. Display conditions summary
## 7. Data-source summary
## 8. Two-way feedback
## 9. Global-constraint collisions
## 10. Reverse object cross-check
## 11. Missing field definitions
## 12. Self-check
Include dual-form coverage, conditional-rule DSL usage, reverse cross-check, C4, and C5.
