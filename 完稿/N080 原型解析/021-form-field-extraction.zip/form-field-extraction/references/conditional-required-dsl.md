# Conditional Required DSL / 条件必填 DSL

Use short, machine-readable DSL fragments instead of free-text conditional rules.

## Core forms
- `required_if: ticket_type == "USDT"`
- `visible_if: country in ["US", "CA"]`
- `enabled_if: status == "ACTIVE"`
- `default_if: role == "manager" -> "read_only"`
- `options_from_if: channel == "bank" -> dict.bank_codes`

## Writing rules
- Prefer one condition per line.
- Use field names, not labels, on the left side.
- Use stable literals on the right side.
- If the condition is not stable enough, mark it as `needs_confirmation` instead of paraphrasing loosely.

## When to use
- conditional required fields
- conditional visibility
- conditional defaults
- dynamic option sources
- schema-driven forms with branch-dependent fields
