# Scoring Rubric (v3)

| Dimension | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| field coverage | 100% | >= 90% | >= 70% | < 70% |
| dual-form coverage | submission + query/filter fully covered | mostly covered | partial | weak |
| validation depth | rich multi-type coverage | >= 80% | >= 50% | shallow |
| conditional rule formalization | DSL used for all stable conditional rules | >= 80% | >= 50% | prose only |
| reverse cross-check | 100% fields traced back | >= 90% | >= 70% | weak |
| display logic quality | role/state/step awareness strong | >= 80% | >= 50% | weak |
| global constraints and feedback | complete | mostly complete | partial | missing |
