# Scoring Rubric (v3)

| Dimension | 4 | 3 | 2 | 1 |
|---|---|---|---|---|
| field coverage | 100% | >= 90% | >= 70% | < 70% |
| dual-form coverage | submission + query/filter fully covered | mostly covered | partial | weak |
| validation depth | rich multi-type coverage | >= 80% | >= 50% | shallow |
| conditional rule formalization | DSL used for all stable conditional rules | >= 80% | >= 50% | prose only |
| reverse cross-check | 100% fields traced back | >= 90% | >= 70% | weak |
| display logic quality | role/state/step awareness strong | >= 80% | >= 50% | weak |
| global constraints and feedback | complete | mostly complete | partial | missing |

---

## 边界 Case 对照表 / Boundary Case Reference

| Case | 描述 | 正确处理 | 常见误判 | 判别理由 |
|---|---|---|---|---|
| 字段名相同，不同表单含义不同 | 两个表单都有 "amount" 字段但含义不同 | 分别产出两个 FLD-* 条目 | 合并为一个 | 相同字段名在不同上下文中是不同字段 |
| 跨步骤依赖 | 步骤 2 的字段值依赖步骤 1 的输入 | conditional_required DSL 中引用步骤 1 字段 | 标注为普通 required | 跨步骤依赖需明确触发路径 |
| 只读字段 | 表单中显示但不可编辑（如"创建时间"） | editable=false，不计入 required/optional | 按 required 处理 | 只读字段不构成提交所需字段 |
| 计算字段 | "总价"由"数量×单价"自动计算 | computed=true，formula="quantity*unit_price" | 纳入 required | 计算字段无需用户输入 |
| 文件上传字段 | 合同附件、身份证照片 | field_type=file，标注 allowed_extensions + max_size | 按文本字段处理 | 文件字段有专属约束（类型/大小/数量） |
| 历史行为条件 | "如果用户曾经提交过则显示X" | conditional_required DSL 中标注 certainty=待确认 + open_question | 直接在 DSL 中假设实现 | 历史行为难以用前端字段状态直接表达 |
| 枚举值数量过多 | 省份/城市选择，枚举值超过 100 个 | allowed_values=dynamic（来自数据接口），标注 source_api | 枚举全部列出 | 动态枚举应指向数据来源而非内联 |
