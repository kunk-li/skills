---
contract_version: 1.0.0
last_changed: 2026-04-23
changelog:
  - 1.0.0 (2026-04-23): initial contract-governed release for n080 skills; adds confidence enum and sync policy
---

# N080 Common Contracts / N080 共同契约

> Shared by 018 `prototype-to-feature-points`, 019 `prototype-to-backend-requirements`, 020 `page-action-extraction`, and 021 `form-field-extraction`.
> Every N080 skill must read this file before producing output. Treat it as the node-level source of truth and the reusable sample pattern for other workflow nodes.

---

## C0 · Evidence layers / 证据分层

Every conclusion must be expressed in one of three layers:

1. **Confirmed fact / 已确认事实**: directly observable from prototypes, or jointly supported by prototype evidence and authoritative upstream artifacts.
2. **Stable inference / 稳定推断**: strongly implied by the available evidence, but still requires implementation or business confirmation.
3. **Needs confirmation / 待确认项**: not stably supported by the available evidence, or has more than one plausible interpretation.

Rules:
- Never write implementation guesses as confirmed facts.
- Never use database reality, source code reality, or undocumented oral context to replace missing evidence.
- Every cross-skill reference must preserve a source anchor or a source note.

### C0.1 · Confidence enum / 置信度枚举

Any skill that exposes a `confidence` column in any table must use exactly one of these three values (case-sensitive, English only):

| value | meaning | corresponds to C0 layer |
|---|---|---|
| `confirmed` | directly observable or jointly supported by authoritative upstream | Confirmed fact / 已确认事实 |
| `stable_inference` | strongly implied, but still needs business or implementation validation | Stable inference / 稳定推断 |
| `needs_confirmation` | multiple plausible interpretations or weak evidence | Needs confirmation / 待确认项 |

Mixed-language values (for example `明确`, `待定`), free-text, or skill-local enums (for example `high/medium/low`) are not allowed.

---

## C1 · Node positioning, input boundary, and fallback taxonomy / 节点定位、输入边界与 fallback 分类

N080 is **prototype-driven analysis by default**. Its primary mission is to understand visual materials and turn them into structured page, feature, backend, action, and field artifacts.

### Allowed inputs / 允许输入

**Preferred primary inputs**
- prototype HTML
- screenshots
- annotated mockups
- accessible prototype descriptions

**Recommended upstream inputs**
- N070 structured outputs, especially object catalog, role graph, permission matrix, and business-rule inventory

**Recommended secondary inputs**
- node-level or system-level global context documents
- naming dictionaries, role-code registries, deprecation lists, long-term forbidden concepts

**Cross-reference inputs**
- PRD text
- API documentation
- acceptance criteria
- previously generated page catalogs or field catalogs

### Prohibited inputs / 禁止输入
- current database state
- current code state
- undocumented oral background

### Fallback operating modes / 三档运行模式

All four N080 skills must explicitly declare one of the following modes in their output summary:

1. **`has-prototype`**
   - Full prototype materials are available.
   - Prototype evidence is still the authority.

2. **`partial-prototype`**
   - Only some pages, dialogs, drawers, or screenshots are available.
   - Missing coverage must be flagged, not silently inferred.

3. **`inferred-from-prototype-absent`**
   - No usable prototype material is available.
   - Reverse inference is allowed only from documented artifacts such as PRD, API docs, release notes, acceptance criteria, screenshots from running systems, or structured operations manuals.
   - All node outputs must explicitly mark their provenance as `inferred-from-prototype-absent`.
   - This mode broadens standalone usefulness for legacy systems, but does not relax evidence discipline.

---

## C2 · Page namespace / 页面命名空间

All page identifiers must use `P-{module}-{nn}`.

Rules:
- All four N080 skills must reuse the same page IDs.
- If the source materials do not provide page IDs, assign them by appearance order and explicitly declare that the namespace is self-generated.
- Do not replace page IDs with local aliases when referencing across skills.

---

## C3 · Cross-skill ID namespaces / 跨 skill ID 命名空间

| Skill | Output element | ID format |
|---|---|---|
| 018 | Feature | `FT-{module}-{page_seq}-{nn}` |
| 019 | Backend capability | `BE-{module}-{nn}` |
| 019 | API endpoint | `API-{module}-{nn}` |
| 020 | Action | `ACT-{module}-P{page_seq}-{nn}` |
| 021 | Field | `FLD-{module}-P{page_seq}-{nn}` |
| 021 | Form | `F{seq}` |

Rules:
- IDs must be stable and unique inside each skill.
- 020 and 021 must reuse real `API-` or `BE-` IDs when 019 exists.
- When downstream API-documentation generation exists, keep the `API-` namespace stable instead of renumbering.
- Object names should reuse the authoritative upstream vocabulary when available; otherwise label them `source-derived`.

---

## C4 · Two-way feedback / 双向反哺

Every N080 output must contain both of the following:

### C4.1 Upstream feedback list / 反哺上游清单
Used when prototypes or fallback artifacts reveal content that upstream requirement artifacts did not define.

### C4.2 Missing-page adjudication / 缺页裁决清单
Used when upstream requirement artifacts define functionality that the prototype or fallback material does not show.

Neither section may be omitted. If the section is empty, explicitly state that it was checked and no items were found.

---

## C5 · Global-constraint propagation scan / 全局约束传递性扫描

When global context exists, all four skills must scan for:

1. forbidden concepts
2. ghost entities or retired roles
3. red-line operations

Even if no hit is found, the output must still record that the scan was executed.

---

## C6 · Stage order, parallelism, and handoff / 阶段顺序、并行与交接

Recommended execution order:

```text
Stage A: 018 prototype-to-feature-points
            ↓
Stage B: 019 + 020 + 021
            ↓
Stage C: cross-skill consistency backfill and self-check
```

Rules:
- 018 runs first and establishes the shared page namespace.
- 019, 020, and 021 may run in parallel after Stage A.
- If 020 or 021 start before 019 finishes, temporary placeholders such as `API-TBD` are allowed, but Stage C must backfill them with real IDs.
- If 019, 020, or 021 discover unstable page or feature naming, they must push the fix back to 018 before finalizing the node.

### Cross-skill grain contract / 粒度契约
- one feature may map to zero or more actions
- one action may map to zero or one form
- one action must map to at least one backend capability or be explicitly marked as pure frontend
- if a page has action-to-feature ratio greater than 3x, 020 must explain why
- query and filter forms are in scope; they must not be skipped

---

## C7 · Mandatory self-check / 必做自检

Every skill must self-check:
- page namespace consistency
- element ID uniqueness
- two-way feedback completeness
- global-constraint scan completeness
- cross-skill ID references
- active fallback mode declaration

---

## C8 · Output format discipline / 输出格式纪律

- Use explicit section headers.
- Keep table schemas stable.
- Separate confirmed facts, stable inference, and needs-confirmation content.
- Do not replace concrete cross-skill IDs with vague prose references.
- One CSV should hold one stable schema only.

---

## C9 · Things never to do / 禁止事项

- Do not write prototype-invisible content as confirmed fact.
- Do not skip dialogs, drawers, tabs, query bars, filters, irreversible actions, or confirmation states.
- Do not omit upstream feedback, missing-page adjudication, global-constraint collisions, or self-check.
- Do not treat `inferred-from-prototype-absent` as permission to invent implementation details.

---

## C10 · Evidence anchor formats / 证据锚点格式

Use these formats:

```text
[doc_id]§[section].L[start]-L[end]
[global][doc_id]§[section].L[start]-L[end]
{prototype_id}#P-XX-YY
```

---

## C11 · Contract sync policy / 契约同步规则

This file is duplicated into each N080 skill package. Any change must:

1. Bump `contract_version` using semver
   - **Major**: breaking change of C2 or C3 namespaces, or any schema rule that breaks downstream consumption
   - **Minor**: additive rule or section with behavior impact but no breaking rename
   - **Patch**: wording fix, example update, or clarification with no behavior change
2. Sync all 4 duplicates in the same commit; pre-commit or CI should check SHA equivalence
3. Inspect each `SKILL.md` file's `Minimal embedded contract` section for knock-on updates
4. Keep each skill's declared minimum contract version aligned with this file before packaging
5. Do not machine-compare descriptive package labels such as `fused v4`; skill-package semver is a separate backlog item and is not enforced by this contract
