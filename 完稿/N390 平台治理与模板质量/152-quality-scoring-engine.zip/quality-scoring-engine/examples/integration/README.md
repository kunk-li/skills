# Integration Examples / 集成示例

This directory contains a six-artifact integration example demonstrating the full N380→N390 cascade:
gate decision → fallback switching → HCN escalation → audit trail → template registry → quality score.

## Gate Failure Full Cascade (platform-202619)

| Family | Skill | Artifact | File |
| --- | --- | --- | --- |
| N380 | 147 gate-pass-decision | GATE-LOG-platform-202619 | `gate-fail-example.csv` |
| N380 | 148 fallback-switching | FB-platform-001 | `fallback-activation-example.csv` |
| N380 | 149 human-confirmation-node-management | HCN-platform-001 | `hcn-escalation-example.csv` |
| N390 | 150 audit-trail-management | AU-platform-fail-001 | `audit-ledger-n380-template-ingestion.csv` |
| N390 | 151 template-management | TMPL-n380-gate-v2 | `template-index-n380-schemas.csv` |
| N390 | 152 quality-scoring-engine | QS-gate-platform-001 | `quality-scorecard-core-fail.csv` |

## Validate the cascade

Run from any N380 or N390 skill directory:

```bash
# N380 3-skill cascade (gate/fallback/HCN refs resolve)
python scripts/validate_cascade.py \
    examples/integration/gate-fail-example.csv \
    examples/integration/fallback-activation-example.csv \
    examples/integration/hcn-escalation-example.csv

# N380+N390 full 6-skill cascade (from any N390 skill dir)
python scripts/validate_six_skill_cascade.py \
    examples/integration/gate-fail-example.csv \
    examples/integration/fallback-activation-example.csv \
    examples/integration/hcn-escalation-example.csv \
    examples/integration/audit-ledger-n380-template-ingestion.csv \
    examples/integration/template-index-n380-schemas.csv \
    examples/integration/quality-scorecard-core-fail.csv
```
