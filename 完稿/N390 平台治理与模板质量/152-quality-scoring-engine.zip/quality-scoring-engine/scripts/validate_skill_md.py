#!/usr/bin/env python3
from __future__ import annotations
import re, sys
from pathlib import Path
from n390_validators_common import CONTRACT_VERSION
EXPECTED_HEADING = "## N390 v1.4.0 contract baseline"

def main(path: Path) -> int:
    text = path.read_text(encoding='utf-8')
    errors = []
    if EXPECTED_HEADING not in text:
        errors.append(f"SKILL.md must contain heading {EXPECTED_HEADING!r}")
    m = re.search(r"contract_version:\s*`([^`]+)`", text)
    if not m:
        errors.append('SKILL.md baseline missing contract_version line')
    elif m.group(1) != CONTRACT_VERSION:
        errors.append(f"SKILL.md contract_version body says {m.group(1)!r}, expected {CONTRACT_VERSION!r}")
    fm = re.search(r"---\n(.*?)\n---", text, re.S)
    if fm:
        desc_match = re.search(r"description:\s*(.*)", fm.group(1), re.S)
        if desc_match:
            desc = desc_match.group(1).strip().replace('\n', ' ')
            if len(desc) < 140:
                errors.append(f"frontmatter description is too short for reliable routing ({len(desc)} chars)")
            if 'not for' not in desc or 'use ' not in desc:
                errors.append("description should include sibling-skill redirects such as 'not for ... use ...'")
    if errors:
        for e in errors:
            print('ERROR:', e, file=sys.stderr)
        return 1
    print(f"OK: {path} skill metadata aligned with {CONTRACT_VERSION}")
    return 0

if __name__ == '__main__':
    raise SystemExit(main(Path(sys.argv[1])))
