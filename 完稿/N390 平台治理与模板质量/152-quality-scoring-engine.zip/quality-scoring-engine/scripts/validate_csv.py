#!/usr/bin/env python3
"""Validate quality-scoring CSV files."""
from __future__ import annotations
import argparse,csv,math,re,sys
from pathlib import Path
EXPECTED=["scoring_run_id","artifact_ref","dimension_id","dimension_name","dimension_type","score","weight","weighted_score","weighting_mode","confidence","evidence_ref","gate_signal","notes"]
DIM_RE=re.compile(r"^Q-\d{3,6}$")
DIM_TYPE={"core","extension"}; CONF={"high","medium","low"}; GATE={"PASS","COND_GO","FAIL","INFO"}; WEIGHTING_MODE={"balanced","gate_strict","audit_weighted","custom"}
CORE_DIMENSIONS={"requirements_clarity","traceability","test_coverage","release_readiness","auditability","rollback_readiness","security_review","data_governance","operability","observability","performance_readiness","dependency_health","documentation_quality","template_reusability","human_confirmation_readiness"}
def expected_gate(score:float)->str:
    if score<6.0: return 'FAIL'
    if score<7.5: return 'COND_GO'
    return 'PASS'
def main(argv=None):
    p=argparse.ArgumentParser(); p.add_argument('csv_path',type=Path); p.add_argument('--strict',action='store_true')
    args=p.parse_args(argv)
    try:
        with args.csv_path.open('r',encoding='utf-8-sig',newline='') as f:
            reader=csv.DictReader(f)
            if reader.fieldnames!=EXPECTED: raise ValueError(f"header must be exactly {EXPECTED}, got {reader.fieldnames}")
            rows=list(reader)
        if not rows: raise ValueError('scorecard must contain at least one row')
        seen=set(); total_weight=0.0; core_by_run_artifact={}
        for i,row in enumerate(rows,start=2):
            key=(row['scoring_run_id'],row['artifact_ref'],row['dimension_id'])
            if key in seen: raise ValueError(f"line {i}: duplicate scoring row {key}")
            seen.add(key)
            if not row['scoring_run_id'].strip() or not row['artifact_ref'].strip(): raise ValueError(f"line {i}: scoring_run_id and artifact_ref are required")
            if not DIM_RE.match(row['dimension_id'].strip()): raise ValueError(f"line {i}: dimension_id must look like Q-001")
            name=row['dimension_name'].strip()
            if not name: raise ValueError(f"line {i}: dimension_name is required")
            dim_type=row['dimension_type'].strip()
            if dim_type not in DIM_TYPE: raise ValueError(f"line {i}: dimension_type must be core or extension")
            weighting_mode=row['weighting_mode'].strip()
            if weighting_mode not in WEIGHTING_MODE: raise ValueError(f"line {i}: weighting_mode must be one of {sorted(WEIGHTING_MODE)}")
            if dim_type=='core' and name not in CORE_DIMENSIONS: raise ValueError(f"line {i}: core dimension_name {name!r} is not in canonical core dimensions")
            score=float(row['score']); weight=float(row['weight']); weighted=float(row['weighted_score'])
            if score<0 or score>10: raise ValueError(f"line {i}: score must be between 0 and 10")
            if weight<=0: raise ValueError(f"line {i}: weight must be > 0")
            if not math.isclose(weighted,score*weight,rel_tol=1e-6,abs_tol=0.005): raise ValueError(f"line {i}: weighted_score must equal score * weight")
            weighting_mode=row.get('weighting_mode','').strip()
            if weighting_mode not in WEIGHTING_MODE: raise ValueError(f"line {i}: weighting_mode must be one of {sorted(WEIGHTING_MODE)}")
            if weighting_mode=='custom' and 'weighting_reason=' not in row['notes']:
                raise ValueError(f"line {i}: custom weighting_mode requires notes weighting_reason=<reason>")
            total_weight += weight
            if row['confidence'].strip() not in CONF: raise ValueError(f"line {i}: confidence must be high, medium, or low")
            if not row['evidence_ref'].strip(): raise ValueError(f"line {i}: evidence_ref is required or use 待核对")
            gate=row['gate_signal'].strip()
            if gate not in GATE: raise ValueError(f"line {i}: gate_signal must be one of {sorted(GATE)}")
            if dim_type=='core' and gate=='INFO': raise ValueError(f"line {i}: core dimensions must produce PASS/COND_GO/FAIL, not INFO")
            if gate!='INFO' and gate!=expected_gate(score): raise ValueError(f"line {i}: gate_signal {gate} conflicts with score {score}; expected {expected_gate(score)} or INFO")
            if row['confidence'].strip()=='low' and gate=='PASS': print(f"WARN: line {i}: low confidence PASS should be reviewed", file=sys.stderr)
            if ',' in row['notes'] and '|' not in row['notes']: raise ValueError(f"line {i}: use pipe-delimited notes instead of comma-separated lists")
            if dim_type=='core': core_by_run_artifact.setdefault((row['scoring_run_id'],row['artifact_ref']),set()).add(name)
        if total_weight<=0: raise ValueError('total weight must be > 0')
        if args.strict:
            for key,names in core_by_run_artifact.items():
                missing=CORE_DIMENSIONS-names
                if missing: raise ValueError(f"strict: run/artifact {key} missing core dimensions {sorted(missing)}")
    except Exception as exc:
        print(f"INVALID: {exc}",file=sys.stderr); return 1
    print(f"VALID scorecard: {args.csv_path} ({len(rows)} rows)"); return 0
if __name__=='__main__': raise SystemExit(main())
