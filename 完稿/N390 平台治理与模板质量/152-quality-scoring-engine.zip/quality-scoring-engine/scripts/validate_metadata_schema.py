#!/usr/bin/env python3
"""Small zero-dependency metadata JSON Schema validator for the bundled N390 schema subset."""
from __future__ import annotations
import json, re, sys
from pathlib import Path
from n390_validators_common import load_yaml_like, print_errors

def validate_obj(schema, obj, path='root'):
    errors=[]
    typ=schema.get('type')
    if typ == 'object':
        if not isinstance(obj, dict): return [f"{path}: expected object"]
        for req in schema.get('required', []):
            if req not in obj: errors.append(f"{path}: missing required field {req!r}")
        if schema.get('additionalProperties') is False:
            allowed=set(schema.get('properties', {}).keys())
            for k in obj:
                if k not in allowed: errors.append(f"{path}: unexpected field {k!r}")
        for k, sub in schema.get('properties', {}).items():
            if k in obj: errors += validate_obj(sub, obj[k], f"{path}.{k}")
    elif typ == 'array':
        if not isinstance(obj, list): return [f"{path}: expected array"]
    elif typ == 'string':
        if not isinstance(obj, str): return [f"{path}: expected string"]
    if 'const' in schema and obj != schema['const']:
        errors.append(f"{path}: expected {schema['const']!r}, got {obj!r}")
    if 'enum' in schema and obj not in schema['enum']:
        errors.append(f"{path}: expected one of {schema['enum']!r}, got {obj!r}")
    if 'pattern' in schema and isinstance(obj, str) and not re.match(schema['pattern'], obj):
        errors.append(f"{path}: {obj!r} does not match pattern {schema['pattern']}")
    return errors

def main(meta_path: Path, schema_path: Path|None=None) -> int:
    if schema_path is None:
        schema_path = Path(__file__).resolve().parents[1] / 'references' / 'metadata-schema.json'
    schema=json.loads(schema_path.read_text(encoding='utf-8'))
    obj=load_yaml_like(meta_path)
    errors=validate_obj(schema, obj)
    if print_errors(errors): return 1
    print(f"OK: {meta_path} passes metadata JSON Schema {schema_path}")
    return 0
if __name__ == '__main__':
    args=[Path(a) for a in sys.argv[1:]]
    raise SystemExit(main(*args))
