#!/usr/bin/env python3
"""Shared N390 validator helpers. Each skill carries its own generated copy."""
from __future__ import annotations
import json, re, sys
from pathlib import Path
CONTRACT_VERSION = "n390-governance-sink-v1.4.0"
WORKFLOW_NODE = "N390"
ARTIFACT_FAMILY_ID = "n390-governance-sink-suite"
PLACEHOLDERS = {"", "待确认", "待核对", "unknown", "UNKNOWN", "not_applicable"}
READINESS = {"draft", "partial", "ready", "blocked"}
CONFIDENCE = {"high", "medium", "low"}
CONFIDENTIALITY = {"public_internal", "restricted_internal", "confidential"}
ENGINE_CONSUMABLE = {"csv", "yaml", "both", "no"}
ARTIFACT_ID_RE = {
    "150": re.compile(r"^AUDIT-LEDGER-[A-Za-z0-9_-]+-(\d{6}|\d{2})$"),
    "151": re.compile(r"^TPL-INDEX-[A-Za-z0-9_-]+-(\d{6}|\d{2})$"),
    "152": re.compile(r"^QS-RUN-[A-Za-z0-9_-]+-(\d{8}|\d{6}|\d{2})$"),
}
REQUIRED_METADATA_FIELDS = ['artifact_family_id', 'artifact_id', 'artifact_target', 'composition_role', 'confidence', 'confidentiality_level', 'contract_version', 'cross_artifact_refs', 'csv_schema', 'engine_consumable', 'evidence_refs', 'freshness', 'function_bias', 'governance_scope', 'open_blockers', 'owner_placeholders', 'pending_clarifications', 'readiness', 'selected_mode', 'skill_id', 'skill_name', 'source_artifacts', 'source_time_window', 'stage_position', 'upstream_id_aliases', 'workflow_node']
REQUIRED_HANDOFF_FIELDS = ['artifact_family_id', 'artifact_id', 'artifact_target', 'confidence', 'consumer_skill_or_node', 'contract_version', 'cross_artifact_refs', 'handoff_id', 'next_best_checks', 'pending_clarifications', 'producer_skill', 'readiness', 'required_fields']

def load_yaml_like(path: Path):
    text = path.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except Exception:
        try:
            import yaml
            return yaml.safe_load(text)
        except Exception as exc:
            raise ValueError(f"cannot parse metadata as JSON or YAML: {exc}")

def split_pipe(value: str):
    return [p.strip() for p in str(value or "").split("|") if p.strip()]

def is_placeholder(value: str) -> bool:
    return str(value or "").strip() in PLACEHOLDERS

def print_errors(errors):
    for e in errors:
        print(f"ERROR: {e}", file=sys.stderr)
    return 1 if errors else 0
