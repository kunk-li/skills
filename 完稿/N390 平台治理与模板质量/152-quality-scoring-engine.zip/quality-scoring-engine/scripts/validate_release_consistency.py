#!/usr/bin/env python3
from __future__ import annotations
import sys, subprocess
from pathlib import Path
from n390_validators_common import load_yaml_like, CONTRACT_VERSION, print_errors

def run(cmd):
    p = subprocess.run(cmd, text=True, capture_output=True)
    if p.returncode != 0:
        return [p.stderr.strip() or p.stdout.strip() or f"failed: {' '.join(map(str, cmd))}"]
    return []

def skill_dir_from_meta(meta: Path) -> Path:
    return meta.parent.parent

def main(audit_meta: Path, template_meta: Path, score_meta: Path):
    errors=[]
    metas=[audit_meta, template_meta, score_meta]
    labels=['150','151','152']
    data=[]
    # Fast path: load metadata and fail version mismatches before invoking per-skill validators.
    for label, m in zip(labels, metas):
        md = load_yaml_like(m).get('metadata', {})
        data.append(md)
        if md.get('contract_version') != CONTRACT_VERSION:
            errors.append(f"{label}: metadata contract_version {md.get('contract_version')!r} does not match expected {CONTRACT_VERSION!r}")
    versions={d.get('contract_version') for d in data}
    if versions != {CONTRACT_VERSION}:
        errors.append(f"contract_version mismatch across N390 family: {sorted(str(v) for v in versions)}")
        return print_errors(errors)
    # Full validators run only after the version contract is coherent.
    for label, m in zip(labels, metas):
        root=skill_dir_from_meta(m)
        cmds=[
            [sys.executable, str(root/'scripts'/'validate_skill_md.py'), str(root/'SKILL.md')],
            [sys.executable, str(root/'scripts'/'validate_metadata.py'), str(m)],
            [sys.executable, str(root/'scripts'/'validate_metadata_schema.py'), str(m)],
            [sys.executable, str(root/'scripts'/'validate_decision_tree.py'), str(root/'references'/'selected-mode-decision-tree.md'), str(root/'references'/'output-contract.yaml')],
        ]
        for cmd in cmds:
            for e in run(cmd):
                errors.append(f"{label}: {e} (hint: re-run {' '.join(map(str, cmd))})")
    # 5-in-1: audit event template materialization for the canonical N380 -> N390 example.
    audit_root = skill_dir_from_meta(audit_meta)
    audit_csv = audit_root/'examples'/'audit-ledger-n380-template-ingestion.csv'
    audit_template = audit_root/'examples'/'n380-audit-event-template.txt'
    audit_validator = audit_root/'scripts'/'validate_audit_event_template.py'
    if audit_csv.exists() and audit_template.exists() and audit_validator.exists():
        cmd=[sys.executable, str(audit_validator), str(audit_csv), '--template', audit_template.read_text(encoding='utf-8')]
        for e in run(cmd):
            errors.append(f"150: {e} (hint: re-run {sys.executable} {audit_validator} {audit_csv} --template <template-text>)")
    else:
        errors.append('150: canonical audit_event_template example or validator is missing')
    ids={d.get('artifact_id') for d in data}
    for d in data:
        aid=d.get('artifact_id')
        refs=set(d.get('cross_artifact_refs') or [])
        if aid in refs:
            errors.append(f"{aid}: self-reference in cross_artifact_refs")
        if d.get('readiness')=='ready' and not refs.intersection(ids-{aid}):
            errors.append(f"{aid}: ready artifact should reference at least one sibling artifact")
    if print_errors(errors): return 1
    print('OK: N390 release consistency and N380 audit-template handshake checks passed')
    return 0
if __name__ == '__main__':
    if len(sys.argv) != 4:
        print(
            "Usage: python validate_release_consistency.py "
            "<150.metadata.yaml> <151.metadata.yaml> <152.metadata.yaml>",
            file=sys.stderr,
        )
        raise SystemExit(1)
    raise SystemExit(main(Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])))
