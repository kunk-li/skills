#!/usr/bin/env python3
"""Validate N380 -> N390 six-skill cascade integrity.

Arguments:
  gate.csv fallback.csv hcn.csv audit.csv template.csv score.csv

This compatibility-layer validator reads only cascade-relevant fields. It intentionally
accepts older quality-score CSV files that may not yet include newer local columns such
as `weighting_mode`, because the release-level cascade only needs evidence and linkage.
Run each skill's validate_csv.py separately for strict per-skill schema validation.
"""
from __future__ import annotations
import argparse, csv
from pathlib import Path
from n390_validators_common import split_pipe, print_errors

def read_rows(path: Path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def index(rows, key):
    return {r.get(key,'').strip(): r for r in rows if r.get(key,'').strip()}

def note_values(notes: str):
    out={}
    for part in split_pipe(notes):
        if '=' in part:
            k,v=part.split('=',1); out[k.strip()]=v.strip()
    return out

def main(args=None):
    p=argparse.ArgumentParser()
    p.add_argument('gate_csv', type=Path); p.add_argument('fallback_csv', type=Path); p.add_argument('hcn_csv', type=Path)
    p.add_argument('audit_csv', type=Path); p.add_argument('template_csv', type=Path); p.add_argument('score_csv', type=Path)
    p.add_argument('--strict', action='store_true', help='enable stricter cross-node evidence expectations')
    ns=p.parse_args(args)
    errors=[]
    gate_rows=read_rows(ns.gate_csv); fb_rows=read_rows(ns.fallback_csv); hcn_rows=read_rows(ns.hcn_csv)
    au_rows=read_rows(ns.audit_csv); tpl_rows=read_rows(ns.template_csv); qs_rows=read_rows(ns.score_csv)
    fb=index(fb_rows,'fb_id'); hcn=index(hcn_rows,'hcn_id'); au=index(au_rows,'id')
    tpl=index(tpl_rows,'template_id')
    gate_ids={r.get('gate_id','').strip() for r in gate_rows}
    for g in gate_rows:
        gid=g.get('gate_id','').strip(); decision=g.get('decision','').strip()
        hrefs=[x for x in split_pipe(g.get('hcn_ref','')) if x not in {'not_applicable','待确认'}]
        frefs=[x for x in split_pipe(g.get('fallback_ref','')) if x not in {'not_applicable','待确认'}]
        for hr in hrefs:
            if hr not in hcn: errors.append(f"gate {gid}: hcn_ref {hr} missing from HCN CSV")
        for fr in frefs:
            if fr not in fb: errors.append(f"gate {gid}: fallback_ref {fr} missing from fallback CSV")
        if decision in {'FAIL','COND_GO','PENDING'} and not hrefs:
            errors.append(f"gate {gid}: non-PASS decision requires concrete HCN reference")
        audit_ref=g.get('audit_ref','').strip()
        if audit_ref and audit_ref not in {'not_applicable','待确认'} and audit_ref not in au:
            materialized=any(note_values(a.get('notes','')).get('gate_ref')==gid or gid in a.get('notes','') for a in au_rows)
            if not materialized: errors.append(f"gate {gid}: audit_ref {audit_ref} not found and no AU row materializes gate_ref")
    for f in fb_rows:
        fr=f.get('fb_id','').strip(); gate=f.get('gate_ref','').strip(); hr=f.get('hcn_ref','').strip()
        if gate and gate not in gate_ids: errors.append(f"fallback {fr}: gate_ref {gate} missing from gate CSV")
        if f.get('activation_status') in {'ACTIVE','BLOCKED','DISABLED'} and hr not in hcn: errors.append(f"fallback {fr}: active/blocking status requires HCN row {hr}")
    for h in hcn_rows:
        hid=h.get('hcn_id','').strip(); gate=h.get('gate_ref','').strip(); fr=h.get('fallback_ref','').strip()
        if gate and gate not in gate_ids: errors.append(f"HCN {hid}: gate_ref {gate} missing from gate CSV")
        if fr not in {'','not_applicable','待确认'} and fr not in fb: errors.append(f"HCN {hid}: fallback_ref {fr} missing from fallback CSV")
        if h.get('audit_required')=='yes' and not any(hid in a.get('artifact_version','') or hid in a.get('notes','') for a in au_rows):
            errors.append(f"HCN {hid}: audit_required=yes but no AU row targets this HCN")
    if not any(r.get('artifact_type')=='schema' for r in tpl_rows):
        errors.append('template CSV: expected at least one artifact_type=schema row for upstream schema governance')
    au_ids=set(au.keys()); tpl_ids=set(tpl.keys())
    if ns.strict:
        for t in tpl_rows:
            tid=t.get('template_id','').strip()
            status=t.get('lifecycle_status','').strip()
            transition=t.get('transition_audit_ref','').strip()
            if status in {'active','deprecated','dormant'} and transition and transition not in {'not_applicable','待确认'} and transition not in au_ids:
                errors.append(f"template {tid}: transition_audit_ref {transition} missing from audit CSV")
            elif status in {'active','deprecated'} and transition in {'','not_applicable','待确认'}:
                errors.append(f"template {tid}: {status} lifecycle requires concrete transition_audit_ref")
        for a in au_rows:
            action=a.get('action','').strip()
            if action in {'template_registered','template_updated','template_deprecated'}:
                notes=note_values(a.get('notes',''))
                t_ref=notes.get('template_ref') or a.get('artifact_version','').split('@',1)[0].replace('template:','')
                if t_ref not in tpl_ids:
                    errors.append(f"audit {a.get('id')}: {action} should link to a known template_ref")
    for q in qs_rows:
        evs=split_pipe(q.get('evidence_ref',''))
        # Only cascade-relevant fields are required here; missing dimension_type means an old score format is tolerated.
        if q.get('dimension_type')=='core' and ns.strict and not any(ev in au_ids or ev.startswith('AU-') or ev in tpl_ids or ev.startswith('TPL-') or ev.startswith('GATE-') for ev in evs):
            errors.append(f"score row {q.get('dimension_id')}: strict core row should cite AU/TPL/GATE evidence")
    if print_errors(errors): return 1
    print('OK: N380-N390 six-skill cascade validates gate/fallback/HCN -> audit/template/quality linkage')
    return 0
if __name__=='__main__': raise SystemExit(main())
