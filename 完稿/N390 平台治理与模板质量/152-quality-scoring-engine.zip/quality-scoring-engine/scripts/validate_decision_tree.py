#!/usr/bin/env python3
"""Validate selected-mode decision tree leaves against output-contract.yaml."""
from __future__ import annotations
import re, sys
from pathlib import Path
from n390_validators_common import load_yaml_like, print_errors

def main(tree_path: Path, contract_path: Path) -> int:
    errors=[]
    text=tree_path.read_text(encoding='utf-8')
    contract=load_yaml_like(contract_path)
    modes=set(contract.get('selected_modes') or [])
    found=set(re.findall(r"->\s*([a-z0-9_]+)", text))
    missing=modes-found
    extra=found-modes
    if missing: errors.append(f"decision tree missing selected mode leaves: {sorted(missing)}")
    if extra: errors.append(f"decision tree contains unknown mode leaves: {sorted(extra)}")
    if print_errors(errors): return 1
    print(f"OK: decision tree modes match output contract ({len(modes)} modes)")
    return 0
if __name__=='__main__':
    if len(sys.argv)!=3:
        print('usage: validate_decision_tree.py <selected-mode-decision-tree.md> <output-contract.yaml>', file=sys.stderr); sys.exit(2)
    raise SystemExit(main(Path(sys.argv[1]), Path(sys.argv[2])))
