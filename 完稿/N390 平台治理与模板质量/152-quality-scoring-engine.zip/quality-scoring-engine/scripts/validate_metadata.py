#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
from n390_validators_common import *

def main(path: Path) -> int:
    errors=[]
    data=load_yaml_like(path)
    md=data.get('metadata', {}) if isinstance(data, dict) else {}
    handoff=data.get('downstream_handoff', {}) if isinstance(data, dict) else {}
    missing=sorted(set(REQUIRED_METADATA_FIELDS)-set(md.keys()))
    if missing: errors.append(f"metadata missing required fields: {missing}")
    hmissing=sorted(set(REQUIRED_HANDOFF_FIELDS)-set(handoff.keys()))
    if hmissing: errors.append(f"downstream_handoff missing required fields: {hmissing}")
    if md.get('contract_version') != CONTRACT_VERSION: errors.append(f"metadata.contract_version must be {CONTRACT_VERSION}, got {md.get('contract_version')!r}")
    if handoff and handoff.get('contract_version') != CONTRACT_VERSION: errors.append('downstream_handoff.contract_version mismatch')
    if md.get('workflow_node') != WORKFLOW_NODE: errors.append('workflow_node must be N390')
    if md.get('artifact_family_id') != ARTIFACT_FAMILY_ID: errors.append('artifact_family_id mismatch')
    skill_id=str(md.get('skill_id',''))
    artifact_id=str(md.get('artifact_id',''))
    if skill_id in ARTIFACT_ID_RE and not ARTIFACT_ID_RE[skill_id].match(artifact_id): errors.append(f"artifact_id {artifact_id!r} does not match pattern for skill {skill_id}")
    if artifact_id and artifact_id in (md.get('cross_artifact_refs') or []): errors.append('cross_artifact_refs must not include own artifact_id')
    if 'readiness' in md and md.get('readiness') not in READINESS: errors.append('readiness invalid')
    if 'confidence' in md and md.get('confidence') not in CONFIDENCE: errors.append('confidence invalid')
    if 'confidentiality_level' in md and md.get('confidentiality_level') not in CONFIDENTIALITY: errors.append('confidentiality_level invalid')
    if 'engine_consumable' in md and md.get('engine_consumable') not in ENGINE_CONSUMABLE: errors.append('engine_consumable invalid')
    if print_errors(errors): return 1
    print(f"OK: {path} metadata passes N390 contract")
    return 0
if __name__ == '__main__':
    raise SystemExit(main(Path(sys.argv[1])))
