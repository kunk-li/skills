---
name: quality-scoring-engine
description: produce evidence-backed quality scorecards for artifacts, templates, auditability, governance completeness, release readiness, and gate advice. use when the user needs weighted_score validation, core quality dimensions, PASS/COND_GO/FAIL gate_signal recommendations, or low-confidence score warnings. not for approving gates (use gate-pass-decision), cataloging templates (use template-management), or storing immutable event history (use audit-trail-management).
---

# Quality Scoring Engine

## N390 v1.4.0 contract baseline

- contract_version: `n390-governance-sink-v1.4.0`
- workflow_node: `N390`
- skill_id: `152`
- csv_schema: `n390.quality-scorecard.v2`
- artifact_target: `质量评分结果.csv`

This skill is self-contained and can run alone with partial evidence. It composes with sibling N390 skills through `artifact_id`, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff`.

## References

Before producing final output, consult:
- `references/n390-shared-governance-contract.md`
- `references/n390-id-space.md`
- `references/output-contract.yaml`
- `references/metadata-schema.json`
- `references/anti-patterns.md`
- `references/selected-mode-decision-tree.md`
- `references/quality-scoring-engine-quality-checklist.md`
- skill-specific schema/rubric files packaged with this skill

## Selected mode

Choose one selected mode from: `core_quality_scorecard / template_quality_score / gate_advice_scorecard / trend_or_delta_scoring`. Record it in the sidecar metadata.

## Required output

Produce the CSV artifact `质量评分结果.csv` and a sidecar metadata file. Keep CSV machine-readable. Use `|` for multi-value cells, not bare commas.

## Workflow

1. Identify source artifacts, upstream IDs, evidence, and open gaps. Read `references/anti-patterns.md` before finalizing rows.
2. Select mode and readiness using `references/selected-mode-decision-tree.md`.
3. Produce rows using the exact CSV schema.
4. Produce sidecar metadata with `metadata` and `downstream_handoff` sections.
5. Run `scripts/validate_csv.py` on the CSV.
6. Run `scripts/validate_metadata.py` and `scripts/validate_metadata_schema.py` on metadata.
7. For a three-artifact N390 family, run `scripts/validate_release_consistency.py`; for N380→N390 end-to-end validation, run `scripts/validate_six_skill_cascade.py`.
8. Review `references/anti-patterns.md`, apply the quality checklist, and summarize readiness/confidence.

## Skill-specific rule

Core dimensions must produce PASS/COND_GO/FAIL, never INFO. Scores support gate advice but do not approve gates. Low-confidence PASS rows must be reviewed.

## Boundaries

- Do not replace sibling skills: audit trails, template lifecycle, and quality scoring have distinct ownership.
- Do not invent evidence, owners, dates, scores, or approvals.
- Do not depend on files outside this skill package.
