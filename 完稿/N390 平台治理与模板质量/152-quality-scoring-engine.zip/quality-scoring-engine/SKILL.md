---
name: quality-scoring-engine
display_name: 质量评分引擎 / Quality Scoring Engine
description: produce evidence-backed quality scorecards covering artifact quality, auditability, governance completeness, and release readiness with PASS/COND_GO/FAIL gate_signal recommendations. use when weighted score validation or low-confidence score warnings are needed. not for gate approval (use gate-pass-decision), template cataloging (use template-management), or audit history (use audit-trail-management).
---

# Quality Scoring Engine

## N390 v1.4.0 contract baseline

- contract_version: `n390-governance-sink-v1.4.0`
- workflow_node: `N390`
- skill_id: `152`
- csv_schema: `n390.quality-scorecard.v2`
- artifact_target: `质量评分结果.csv`

This skill is self-contained and can run alone with partial evidence. It composes with sibling N390 skills through `artifact_id`, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff`.

## Mode selection at a glance

| mode | when to use |
| --- | --- |
| `core_quality_scorecard` | scoring core artifact quality dimensions |
| `template_quality_score` | evaluating quality of a template asset |
| `gate_advice_scorecard` | producing a PASS/COND_GO/FAIL gate_signal recommendation |
| `trend_or_delta_scoring` | comparing quality scores across versions or time |

For detailed decision logic, consult `references/selected-mode-decision-tree.md`.

## References

Before producing final output, consult:
- `references/n390-shared-governance-contract.md`
- `references/n390-id-space.md`
- `references/output-contract.yaml`
- `references/metadata-schema.json`
- `references/anti-patterns.md`
- `references/selected-mode-decision-tree.md`
- `references/quality-scoring-engine-quality-checklist.md`
- skill-specific schema/rubric files packaged with this skill

## Selected mode

Choose one selected mode from: `core_quality_scorecard / template_quality_score / gate_advice_scorecard / trend_or_delta_scoring`. Record it in the sidecar metadata.

## Required output

Produce the CSV artifact `质量评分结果.csv` and a sidecar metadata file. Keep CSV machine-readable. Use `|` for multi-value cells, not bare commas.

## Inline field contract

Primary artifact: `质量评分结果.csv`  Schema: `n390.quality-scorecard.v2`

Produce CSV rows in exact schema column order (see `references/output-contract.yaml`). Use `待确认` for missing fields; `not_applicable` only when explicitly irrelevant.

| field | required | description |
| --- | --- | --- |
| `score_id` | required | stable score row id — `QS-<scope>-<nnn>` |
| `target_artifact_id` | required | artifact being scored |
| `dimension` | required | quality dimension being assessed |
| `dimension_type` | required | `core\|supplemental\|gate_advice` |
| `raw_score` | required | numeric score or ordinal level |
| `weight` | required | dimension weight in weighted_score calculation |
| `weighted_score` | required | raw_score × weight |
| `gate_signal` | required | `pass\|cond_go\|fail` — core dimensions only; never `info` |
| `confidence` | required | `high\|medium\|low\|needs_human_review` |
| `evidence_refs` | required | source anchors for this score |
| `cross_artifact_refs` | required | sibling N390 artifact IDs |
| `low_confidence_flag` | required | `true\|false` — `true` triggers mandatory human review for PASS rows |
| `open_questions` | required | unresolved questions or `none` |

## Workflow

1. Identify source artifacts, upstream IDs, evidence, and open gaps. Note missing fields as `待确认` rather than silently omitting them.
2. Read `references/anti-patterns.md` before writing any rows; anti-patterns from sibling skills (N380 gate/fallback/HCN) may also apply when the source is an N380 artifact.
3. Select one `selected_mode` using `references/selected-mode-decision-tree.md` and record it in metadata.
4. Produce CSV rows in the exact schema column order defined in `references/output-contract.yaml`.
5. Produce sidecar metadata with `metadata` and `downstream_handoff` sections; use `references/metadata-schema.json` for field requirements.
6. Run `scripts/validate_csv.py <csv-file>` and fix any schema or ordering errors before continuing.
7. Run `scripts/validate_metadata.py <metadata.yaml>` to confirm contract_version, artifact_id, and required fields.
8. Run `scripts/validate_metadata_schema.py <metadata.yaml>` for JSON Schema strict validation.
9. Run `scripts/validate_skill_md.py SKILL.md` to prevent stale contract_version headings.
10. Run `scripts/validate_decision_tree.py references/selected-mode-decision-tree.md references/output-contract.yaml` to prevent selected_mode drift.
11. For a three-artifact N390 family release, run `scripts/validate_release_consistency.py <150.meta> <151.meta> <152.meta>`; for N380→N390 end-to-end validation, run `scripts/validate_six_skill_cascade.py`.
12. Apply `references/quality-checklist.md` and summarize `readiness` and `confidence` in the sidecar.

## Skill-specific rule

Core dimensions must produce PASS/COND_GO/FAIL, never INFO. Scores support gate advice but do not approve gates. Low-confidence PASS rows must be reviewed.

## Boundaries

- Do not replace sibling skills: audit trails, template lifecycle, and quality scoring have distinct ownership.
- Do not invent evidence, owners, dates, scores, or approvals.
- Do not depend on files outside this skill package.

## Six-skill N380→N390 integration cascade

To validate the full N380→N390 six-skill cascade from the `examples/integration/` directory:

```bash
python scripts/validate_six_skill_cascade.py \
    examples/integration/gate-fail-example.csv \
    examples/integration/fallback-activation-example.csv \
    examples/integration/hcn-escalation-example.csv \
    examples/integration/audit-ledger-n380-template-ingestion.csv \
    examples/integration/template-index-n380-schemas.csv \
    examples/integration/quality-scorecard-core-fail.csv
```

See `examples/integration/README.md` for the full artifact listing and cross-reference map.

