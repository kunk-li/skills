# Real Examples / 真实示例参考

These examples illustrate correctly formed quality scorecard rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Gate advice scorecard — PASS/COND_GO/FAIL semantics

**Input**: A gate artifact is submitted for quality scoring across five dimensions.

**Correct pattern**:
```
scorecard_id: QSC-gate-invoice-001
source_artifact_id: GATE-invoice-export-001
dimension_scores:
  - dimension: evidence_completeness | score: PASS | rationale: all dimensions carry evidence_refs
  - dimension: schema_conformance | score: PASS | rationale: all required CSV columns present
  - dimension: hcn_linkage | score: COND_GO | rationale: hcn_ref present but sign-off is pending
  - dimension: audit_readiness | score: PASS | rationale: audit_handoff_required set correctly
  - dimension: fallback_coverage | score: FAIL | rationale: fallback_ref missing despite COND_GO verdict
overall_verdict: FAIL
routing_recommendation: return to fallback-switching to populate fallback_ref before gate re-submission
```

**Rule**: Core dimensions (schema_conformance, hcn_linkage, fallback_coverage) must never output `INFO` — they must output `PASS`, `COND_GO`, or `FAIL`. Only extension dimensions may output `INFO`.

---

## Example 2: Template quality score — scoring dimensions must map to CSV schema

**Input**: TMPL-gate-pass-v2 is submitted for a quality score before publishing.

**Correct pattern**:
```
scorecard_id: QSC-template-gate-v2-001
source_artifact_id: TMPL-gate-pass-v2
dimension_scores:
  - dimension: field_coverage | score: PASS | rationale: all required fields in output-contract.yaml are present
  - dimension: enum_validity | score: PASS | rationale: all enum values match schema definition
  - dimension: version_alignment | score: PASS | rationale: contract_version matches n380-platform-gate-v1.5.0
overall_verdict: PASS
```

**Rule**: scoring-dimensions.md must map each dimension name to the corresponding CSV column it evaluates — without this mapping, the scorer cannot locate the field being tested.

---

## Example 3: Trend or delta scoring — comparing two versions

**Input**: Gate quality scores from Q1 (QSC-gate-q1-summary) and Q2 (QSC-gate-q2-summary) need to be compared.

**Correct pattern**:
```
scorecard_id: QSC-delta-q1-q2-001
comparison_mode: trend_or_delta_scoring
baseline_scorecard: QSC-gate-q1-summary
current_scorecard: QSC-gate-q2-summary
dimension_deltas:
  - dimension: evidence_completeness | q1: COND_GO | q2: PASS | trend: improving
  - dimension: fallback_coverage | q1: FAIL | q2: COND_GO | trend: improving
  - dimension: hcn_linkage | q1: PASS | q2: PASS | trend: stable
overall_trend: improving
notes: Two dimensions improved from Q1 to Q2; no regressions detected.
```
