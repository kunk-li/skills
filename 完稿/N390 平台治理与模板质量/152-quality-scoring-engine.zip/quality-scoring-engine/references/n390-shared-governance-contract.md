# N390 Shared Governance Sink Contract

## Contract version
`n390-governance-sink-v1.4.0`

## Node scope
N390 is the governance sink for audit records, reusable templates, and quality scoring. The three skills are independently usable, but become stronger when joined by stable `artifact_id`, row-level IDs, `evidence_refs`, and `downstream_handoff`.

## Encapsulation governance
Each N390 skill is self-contained. Shared rules, schemas, validators, examples, and references are packaged inside each skill. Do not rely on `node_shared/`, `node_tools/`, or external directories.

## Release consistency rule
A valid N390 release keeps the same `contract_version` in `SKILL.md`, `references/output-contract.yaml`, `references/metadata-schema.json`, sidecar metadata examples, and all validators. The three skill-local copies of this shared contract and `n390-id-space.md` should stay byte-identical.

## Shared metadata schema
Every N390 sidecar metadata file must include `metadata` and `downstream_handoff` sections. Required metadata fields:

- contract_version
- workflow_node
- skill_id
- skill_name
- artifact_family_id
- artifact_id
- csv_schema
- selected_mode
- readiness
- governance_scope
- source_time_window
- source_artifacts
- upstream_id_aliases
- evidence_refs
- cross_artifact_refs
- pending_clarifications
- open_blockers
- owner_placeholders
- confidentiality_level
- confidence
- composition_role
- function_bias
- stage_position
- artifact_target
- engine_consumable
- freshness

## Artifact and row id rules
- 150 audit artifact: `AUDIT-LEDGER-<project_or_scope>-<yyyymm_or_nn>`; row id: `AU-<nnn>`.
- 151 template artifact: `TPL-INDEX-<project_or_scope>-<yyyymm_or_nn>`; row id: `TPL-<project>-<nnn>` or legacy `TPL-<nnn>`.
- 152 score artifact: `QS-RUN-<project_or_scope>-<yyyymmdd_or_nn>`; row id: `QS-<date>-<nn>` plus dimension id `Q-<nnn>`.
- Temporary IDs use `TEMP-N390-<date>-<source>` and must be listed in `upstream_id_aliases`.

## N380 to N390 audit handshake
N380 produces `audit_required`, `audit_handoff_required`, `audit_event_template`, and `audit_ref`. N390 150 consumes these values:

1. Parse `audit_event_template` strings beginning with `AU:new`.
2. Fill known placeholders such as `{signer}` and `{status}` from the source event.
3. Materialize one AU row in `审计留痕日志.csv`.
4. Preserve `linked_gate`, `linked_fallback`, `target`, `decision`, and `evidence` in AU fields or `notes`.
5. Return or expose the generated `AU-*` row id so N380 can complete `audit_ref`.

N390 does not mutate N380 artifacts directly. It emits a ledger row and a handoff record.

## Evidence reference schema
Use evidence refs with `ref_id`, `source_family`, `source_name`, `time_window_or_version`, `upstream_id_aliases`, `confidence`, `layer`, and `excerpt_or_pointer`.

## Standard composition paths
1. `gate-to-audit`: N380 gate/fallback/HCN -> 150 audit ledger.
2. `template-governance`: 151 template registry -> 150 audit row -> 152 quality score.
3. `quality-to-gate`: 152 quality signal -> N380 evidence_ref -> 150 audit row.
4. `audit-to-template-refresh`: 150 audit patterns -> 151 template lifecycle review -> 152 score.
5. `standalone-fallback`: any skill can run with partial evidence and `readiness=partial`.

## Downstream handoff schema
Required handoff fields:
- contract_version
- handoff_id
- producer_skill
- consumer_skill_or_node
- artifact_family_id
- artifact_id
- artifact_target
- required_fields
- cross_artifact_refs
- pending_clarifications
- readiness
- confidence
- next_best_checks

## Common execution workflow
1. Identify upstream artifacts and IDs.
2. Choose `selected_mode`.
3. Produce CSV rows according to the skill schema.
4. Produce sidecar metadata.
5. Run `validate_csv.py`.
6. Run `validate_metadata.py` and `validate_metadata_schema.py`.
7. When sibling artifacts exist, run `validate_release_consistency.py`.
8. Apply the quality checklist and report readiness, confidence, and blockers.

## Common self-check
- No invented evidence, approvals, owners, scores, or dates.
- Use role/team placeholders instead of personal owners unless the source explicitly provides a name.
- Keep row IDs stable across updates.
- Use pipe separators for list-like CSV fields.
- Do not self-reference in `cross_artifact_refs`.
- Preserve upstream IDs from N380, N370, N360, N350, N340, N330, N320, and N310.
- For N380 audit handoffs, preserve gate/fallback/hcn links.
- For templates, keep lifecycle transitions auditable.
- For scores, do not downgrade core dimensions to INFO.
- Use `待确认` or `待核对` rather than guessing.

## Tone and content rules
Be precise, audit-safe, and append-only where relevant. Separate facts from inference and make gaps visible.


## Anti-pattern governance
Each N390 skill packages `references/anti-patterns.md`. Read it before final output. The anti-pattern files translate validator failures and historical regression cases into LLM-readable bad pattern, reason, validator expectation, and corrected pattern blocks.

## Selected-mode decision tree governance
Each N390 skill packages `references/selected-mode-decision-tree.md` plus `scripts/validate_decision_tree.py`. The decision tree leaves must exactly match `selected_modes` in `output-contract.yaml`; release consistency should fail when they drift.

## Six-skill cascade governance
N390 may be validated with N380 as a six-skill governance cascade: 147 gate, 148 fallback, 149 HCN, 150 audit, 151 template, 152 quality score. Use `scripts/validate_six_skill_cascade.py` to verify row-level references and N380 schema materialization in N390.

## Quality scoring weighting mode governance
Quality-scoring rows must include `weighting_mode`. Allowed modes are `balanced`, `gate_strict`, `audit_weighted`, and `custom`. `balanced` is the default for mixed scorecards, `gate_strict` is used when gate advice is primary, `audit_weighted` is used when auditability drives the score, and `custom` requires explanatory notes.


## v1.2.0 governance extensions

N390 v1.4.0 adds three release-grade controls:

1. **Anti-pattern library.** Each skill packages `references/anti-patterns.md` containing known bad rows, why they are wrong, the validator expected to catch them, and the corrected pattern.
2. **Selected-mode decision tree.** Each skill packages `references/selected-mode-decision-tree.md`; the chosen `selected_mode` must be consistent with that tree and recorded in metadata.
3. **N380-to-N390 six-skill cascade.** `validate_six_skill_cascade.py` validates that N380 gate / fallback / HCN rows can hand off into N390 audit / template / quality rows without broken AU, schema, or quality-score links.



## v1.4.0 governance refinements

N390 v1.4.0 tightens the v1.2.0 governance layer without changing the artifact family shape.

### Shared anti-pattern seed list

The shared list below is the canonical cross-skill anti-pattern catalog. Skill-specific `references/anti-patterns.md` files should keep only the local AP blocks and point to this section instead of duplicating the shared list.

1. N380 `audit_event_template` has no materialized AU row.
2. AU ledger timestamp order moves backward.
3. AU action is outside the supported set.
4. `audit_correction` does not include `corrects=<AU-id>`.
5. Dormant template sets `deprecation_date` instead of using lifecycle `deprecated`.
6. Template dates use prose such as `Q2 2026` instead of `YYYY-MM-DD`.
7. Active template has no adjacent skill references.
8. `artifact_type=schema` is missing for N380/N370/N360 CSV schema templates.
9. Core quality dimension emits `gate_signal=INFO`.
10. Core dimension name is outside the canonical core list.
11. Low-confidence PASS is accepted without review warning.
12. Quality scorecard omits `weighting_mode`, hiding how weights were chosen.
13. Cross-artifact references point to a sibling artifact that is not in the release family.

### v1.2 to v1.3 weighting_mode migration note

`quality-scoring-engine` requires the `weighting_mode` column introduced in v1.2.0. Older v1.1.x scorecards with 12 columns must be migrated by inserting `weighting_mode` between `weighted_score` and `confidence`. Use one of:

- `balanced` for mixed scorecards.
- `gate_strict` when gate advice is primary.
- `audit_weighted` when auditability drives scoring.
- `custom` only when `notes` contains `weighting_reason=<reason>`.

### Strict metadata JSON Schema

Every metadata schema should set `additionalProperties: false` at the root, `metadata`, `downstream_handoff`, and every declared nested object. This catches typo fields such as `audit_handoffrequired` before release.

### Release consistency short-circuit

Release consistency validators must compare `contract_version` across the three metadata files before launching component validators. If versions differ, fail immediately and avoid misleading errors from missing scripts in older packages.

### Decision tree strictness

Decision-tree validators must compare tree leaves only with `output-contract.yaml` `selected_modes`. Do not infer valid modes from suffixes such as `_mode`, `_review`, or `_register`.


## V1.4.0 A+ release gates
N390 v1.4.0 closes the final A+ release gaps from v1.4.0:

1. **Template lifecycle audit hook.** Template lifecycle transitions must expose a `transition_audit_ref` column. For `dormant` and `deprecated` lifecycle states, this reference should point to an AU-* row that explains the transition. In strict cascade mode, the AU row must exist and must refer back to the template row using `template_ref=<template_id>` or a matching template artifact pointer.
2. **Five-in-one release consistency.** Release consistency validates SKILL.md, metadata semantic rules, JSON Schema, selected-mode decision tree, and the N380 audit-event-template handoff when audit examples are packaged.
3. **Strict audit/template linkage.** `validate_six_skill_cascade.py --strict` checks AU ↔ template references, template transition audit refs, and quality rows that cite template evidence. Default mode remains tolerant for historical artifacts; strict mode is recommended for CI.
4. **A+ governance posture.** v1.4.0 remains self-contained. No external node-level scripts or shared directories are required.


## V1.4.0 A+ closure gates
- `validate_release_consistency.py` is now a five-in-one gate: SKILL.md, semantic metadata, JSON Schema, selected-mode decision tree, and N380 audit_event_template materialization.
- `validate_six_skill_cascade.py --strict` tightens AU/template lifecycle references and quality evidence references.
- Template lifecycle rows use `transition_audit_ref` to join lifecycle transitions back to the immutable audit ledger.


## Strict audit/template cascade

In strict six-skill cascade mode, template lifecycle rows must cite resolvable `transition_audit_ref` values and AU rows with template lifecycle actions must link to known `TPL-*` rows through `template_ref` or `artifact_version`.
