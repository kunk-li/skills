# Selected Mode Decision Tree: Quality Scoring Engine

Use exactly one `selected_mode` in metadata.

```text
Are you scoring all canonical core dimensions for one artifact/run?
├── yes -> core_quality_scorecard
└── no: is the scored object a reusable template/schema?
    ├── yes -> template_quality_score
    └── no: should the score feed a gate decision as evidence?
        ├── yes -> gate_advice_scorecard
        └── no -> trend_or_delta_scoring
```

Guardrails:
- Core dimensions must use PASS / COND_GO / FAIL, never INFO.
- Extension dimensions may use INFO when they are not gate-driving.
- Low-confidence PASS rows should be reviewed before gate use.
- `weighting_mode` must be explicitly set in each CSV row.
