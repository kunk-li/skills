# N390 ID Space

contract_version: n390-governance-sink-v1.4.0
artifact_family_id: n390-governance-sink-suite

## Artifact IDs
- AUDIT-LEDGER-<project_or_scope>-<yyyymm_or_nn>
- TPL-INDEX-<project_or_scope>-<yyyymm_or_nn>
- QS-RUN-<project_or_scope>-<yyyymmdd_or_nn>

## Row IDs
- AU-<nnn> for audit ledger rows.
- TPL-<project>-<nnn> for template rows; legacy TPL-<nnn> is accepted.
- QS-<yyyy-mm-dd>-<nn> for score runs; Q-<nnn> for dimensions.

## Cross-node IDs
- N380: GATE-*, FB-*, HCN-*, audit_event_template, audit_ref.
- N370: RT-RULESET-*, PIPELINE-*, STM-*, SNAP-*.
- N360: STR-REC-*, RHY-TRK-*, PE-ALIGN-*, QE-ALIGN-*.
- N350: TASK-*, BLK-*, RISK-*, STATUS-*.
- N340: ACT-*, WR-*, FAQ-*, PAT-*.
- N330: DOC-*.
- N320: INC-*, ANCHOR-*.

Never rewrite upstream IDs. Put aliases in `upstream_id_aliases`.
