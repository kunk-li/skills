# Quality Scoring Engine Quality Checklist

1. Metadata and downstream_handoff pass semantic and JSON Schema validation.
2. CSV rows pass `scripts/validate_csv.py`.
3. IDs follow `references/n390-id-space.md`.
4. `cross_artifact_refs` do not include the artifact's own id.
5. Evidence references preserve upstream IDs instead of rewriting them.
6. `owner_placeholders` use role/team unless a source explicitly provides a person.
7. Unknowns use `待确认` or `待核对`, not invented values.
8. Sibling N390 artifacts are referenced when available.
9. N380 handoff fields are preserved when present.
10. Readiness and confidence match evidence quality.

## Skill-specific checks
- Core dimensions never emit INFO.
- Core dimension names use the canonical set.
- Weighted scores equal score * weight.


## Weighting mode
Rows include `weighting_mode`: `balanced`, `gate_strict`, `audit_weighted`, or `custom`. `custom` requires `notes` to include `weighting_reason=<reason>`.


## v1.2.0 weighting_mode migration

N390 v1.2.0 introduced the required `weighting_mode` column. Older 12-column scorecards must be migrated by inserting `weighting_mode` between `weighted_score` and `confidence`; otherwise v1.4.0 validators will reject the file as a schema mismatch.
