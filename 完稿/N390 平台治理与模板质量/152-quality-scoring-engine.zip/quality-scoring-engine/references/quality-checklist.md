# N390 common quality checklist

This file is the generic checklist target referenced by SKILL.md. It complements `quality-scoring-engine-quality-checklist.md` in this package.

## Checks

- Quality scorecards must separate source decisions, evidence scoring, and release recommendations.
- Route sibling concerns to the correct N390 skill instead of absorbing them.
- Preserve `artifact_id`, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff` when a handoff is needed.
- Do not turn partial evidence into a green release or governance verdict.
