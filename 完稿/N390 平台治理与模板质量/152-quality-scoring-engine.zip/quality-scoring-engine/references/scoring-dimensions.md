# Scoring Dimensions

Core dimensions are canonical and must not be renamed when `dimension_type=core`:

requirements_clarity, traceability, test_coverage, release_readiness, auditability, rollback_readiness, security_review, data_governance, operability, observability, performance_readiness, dependency_health, documentation_quality, template_reusability, human_confirmation_readiness.

Core dimensions must emit PASS, COND_GO, or FAIL, never INFO. INFO is reserved for extension dimensions.


## Weighting mode
Rows include `weighting_mode`: `balanced`, `gate_strict`, `audit_weighted`, or `custom`. `custom` requires `notes` to include `weighting_reason=<reason>`.
