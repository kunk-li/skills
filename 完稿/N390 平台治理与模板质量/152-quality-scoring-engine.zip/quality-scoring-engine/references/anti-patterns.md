# N390 Quality Scoring Anti-Patterns

Use this file before finalizing quality scoring rows. Quality scores can influence gates, so score semantics must be strict.

## Skill-specific anti-patterns

### AP-152-1: Core dimension with INFO gate_signal
- Bad: `dimension_type=core`, `score=3.0`, `gate_signal=INFO`.
- Why it is wrong: Core dimensions are gating dimensions; INFO is only for extension dimensions.
- Validator expectation: `validate_csv.py` rejects core dimensions with `gate_signal=INFO`.
- Correct pattern: Emit `FAIL`, `COND_GO`, or `PASS` according to score thresholds.

### AP-152-2: Unknown core dimension name
- Bad: `dimension_type=core`, `dimension_name=arbitrary_xxx`.
- Why it is wrong: Core dimensions must be stable across runs to support trend and gate logic.
- Validator expectation: `validate_csv.py` checks core names against the canonical set.
- Correct pattern: Use names such as `requirements_clarity`, `traceability`, `rollback_readiness`, or other canonical names.

### AP-152-3: Low-confidence PASS without review signal
- Bad: `confidence=low`, `gate_signal=PASS`, no warning or review note.
- Why it is wrong: A low-confidence PASS should not silently clear a governance concern.
- Validator expectation: `validate_csv.py` emits a warning for low-confidence PASS.
- Correct pattern: Keep the PASS if evidence supports it, but note review needs and keep confidence explicit.

### AP-152-4: Missing weighting_mode
- Bad: Score rows do not state whether weights are standard, template governance, audit weighted, or extension-only.
- Why it is wrong: Consumers cannot compare scorecards or reproduce weighted totals without the weighting policy.
- Validator expectation: v1.2.0 CSV requires `weighting_mode` and validates its enum.
- Correct pattern: Use `standard_core_weights`, `template_governance`, `audit_weighted`, or `extension_observation`.

## Shared anti-pattern seed list

See `references/n390-shared-governance-contract.md` section `Shared anti-pattern seed list` for the canonical 13 cross-skill anti-patterns. Do not duplicate the shared list here; keep this file focused on skill-specific mistakes.

## weighting_mode migration

N390 v1.2.0 and later require the `weighting_mode` column. Migrate v1.1.x scorecards by inserting `weighting_mode` between `weighted_score` and `confidence`; choose `balanced`, `gate_strict`, `audit_weighted`, or `custom` with `weighting_reason=<reason>`.
