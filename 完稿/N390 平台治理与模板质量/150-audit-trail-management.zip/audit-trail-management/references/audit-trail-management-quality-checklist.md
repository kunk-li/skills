# Audit Trail Management Quality Checklist

1. Metadata and downstream_handoff pass semantic and JSON Schema validation.
2. CSV rows pass `scripts/validate_csv.py`.
3. IDs follow `references/n390-id-space.md`.
4. `cross_artifact_refs` do not include the artifact's own id.
5. Evidence references preserve upstream IDs instead of rewriting them.
6. `owner_placeholders` use role/team unless a source explicitly provides a person.
7. Unknowns use `待确认` or `待核对`, not invented values.
8. Sibling N390 artifacts are referenced when available.
9. N380 handoff fields are preserved when present.
10. Readiness and confidence match evidence quality.

## Skill-specific checks
- N380 `audit_event_template` is parsed or explicitly marked not_applicable.
- Append-only updates preserve every prior row.
- `audit_correction` rows include `corrects=<AU-id>` in notes.
