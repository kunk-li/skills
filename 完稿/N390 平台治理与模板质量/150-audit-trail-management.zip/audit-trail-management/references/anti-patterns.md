# N390 Audit Trail Anti-Patterns

Use this file before finalizing audit ledger rows. Each anti-pattern states the bad pattern, why it is wrong, the validator expectation, and the corrected pattern.

## Skill-specific anti-patterns

### AP-150-1: Ignoring N380 audit_event_template
- Bad: Create an AU row from prose while leaving the N380 `audit_event_template` unparsed.
- Why it is wrong: N380 already prepared a canonical audit handoff. Ignoring it breaks `audit_ref` round-trip and can drop `linked_gate`, `linked_fallback`, or `target`.
- Validator expectation: `scripts/validate_audit_event_template.py` can prove that an AU row materializes the template target, evidence, and linked refs.
- Correct pattern: Parse `AU:new actor=... target=... linked_gate=... evidence=...`, fill placeholders from source evidence, and write the corresponding AU row.

### AP-150-2: Timestamp rollback in append-only ledger
- Bad: Append `AU-002` with a timestamp earlier than `AU-001`.
- Why it is wrong: Append-only ledgers preserve chronological order; timestamp rollback creates an audit ambiguity.
- Validator expectation: `validate_csv.py` rejects timestamp order regressions.
- Correct pattern: Keep prior rows unchanged and append corrections as later rows.

### AP-150-3: Unsupported action string
- Bad: `action=random_action` or `action=approved` without mapping to a supported audit action.
- Why it is wrong: Audit actions must be machine groupable.
- Validator expectation: `validate_csv.py` enforces the supported action set.
- Correct pattern: Use `hcn_signed`, `hcn_rejected`, `fallback_activated`, `template_updated`, `quality_score_updated`, or another supported action.

### AP-150-4: Audit correction without corrects=<AU-id>
- Bad: `action=audit_correction` with notes that do not identify the corrected AU row.
- Why it is wrong: Append-only correction rows must point back to the original entry.
- Validator expectation: `validate_csv.py` rejects correction rows without `corrects=`.
- Correct pattern: Add `corrects=AU-001|reason=...` in notes.

## Shared anti-pattern seed list

See `references/n390-shared-governance-contract.md` section `Shared anti-pattern seed list` for the canonical 13 cross-skill anti-patterns. Do not duplicate the shared list here; keep this file focused on skill-specific mistakes.
