# Selected Mode Decision Tree: Audit Trail Management

Use this before producing audit ledger rows.

```text
Is the source an N380 row or HCN event containing audit_event_template?
├── yes -> n380_audit_template_ingestion
└── no: are you appending new governance events to an existing ledger?
    ├── yes -> append_only_update
    └── no: are you correcting a previous AU row without deleting it?
        ├── yes -> correction_entry
        └── no -> event_ingestion with readiness=partial if evidence is incomplete
```

## Guardrails
- `n380_audit_template_ingestion` must use `validate_audit_event_template.py` when the template is available.
- `correction_entry` must include `corrects=<AU-id>` in notes.
- Never overwrite or reorder prior ledger rows; append a new AU row instead.
