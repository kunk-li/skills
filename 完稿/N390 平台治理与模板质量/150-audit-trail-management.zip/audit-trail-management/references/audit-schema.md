# Audit Schema

Columns: id,timestamp,actor,action,artifact_version,evidence_ref,reversible,notes.

## N380 audit_event_template ingestion
Parse canonical N380 templates beginning with `AU:new`. Preserve target, linked_gate, linked_fallback, linked_state, decision, and evidence. The generated AU row id becomes the N390-side audit_ref.

## Action enum
Use one of: gate_pass_decision, hcn_signed, hcn_rejected, hcn_escalated, fallback_activated, fallback_rehearsal_skipped, state_transitioned, template_registered, template_updated, template_deprecated, quality_score_updated, snapshot_created, pm_override_recorded, audit_correction.
