# N390 common quality checklist

This file is the generic checklist target referenced by SKILL.md. It complements `audit-trail-management-quality-checklist.md` in this package.

## Checks

- Audit ledger rows must be append-only, evidence-backed, and linked through audit_ref/cross_artifact_refs.
- Route sibling concerns to the correct N390 skill instead of absorbing them.
- Preserve `artifact_id`, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff` when a handoff is needed.
- Do not turn partial evidence into a green release or governance verdict.
