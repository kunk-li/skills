# Real Examples / 真实示例参考

These examples illustrate correctly formed audit ledger rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Event ingestion — append-only; never overwrite

**Input**: A gate passes. The audit ledger must record the event.

**Correct pattern**:
```
audit_id: AU-gate-invoice-sso-001
event_type: gate_pass
source_artifact_id: GATE-invoice-sso-001
source_artifact_type: gate_pass_decision
event_timestamp: "2026-05-21T10:00:00Z"
actor: system-gate-engine
summary: Gate GATE-invoice-sso-001 passed with overall_verdict PASS
evidence_refs: GATE-invoice-sso-001
```

**Critical rule**: Once written, this row must never be edited or deleted. If a correction is needed, write a new correction_entry row that references this audit_id. (Append-only contract.)

---

## Example 2: Correction entry — reference the original, do not overwrite

**Input**: Audit row AU-gate-invoice-sso-001 has a typo in `actor` — was written as `sytem-gate-engine`. A correction is needed.

**Correct pattern**:
```
audit_id: AU-correction-001
event_type: correction_entry
corrects_audit_id: AU-gate-invoice-sso-001
corrected_field: actor
original_value: sytem-gate-engine
corrected_value: system-gate-engine
correction_reason: typographical error in actor field
correction_timestamp: "2026-05-21T11:30:00Z"
correction_actor: audit-admin-001
```

**Anti-pattern**: Editing `AU-gate-invoice-sso-001` directly — this violates the append-only contract and makes it impossible to reconstruct what the original record said.

---

## Example 3: N380 audit template ingestion — all required handoff fields

**Input**: N380 emits an `audit_handoff_required: yes` signal with a completed audit_event_template.

**Correct pattern**:
```
audit_id: AU-n380-template-001
event_type: n380_audit_template_ingestion
source_n380_artifact_id: GATE-invoice-export-002
n380_audit_event_type: gate_delta_refresh
hcn_ref: HCN-security-sign-off-001
fallback_ref: FB-invoice-ai-001
audit_required: yes
ingestion_timestamp: "2026-05-21T12:00:00Z"
```

**Rule**: If `audit_handoff_required: yes` is set in the N380 artifact, this ingestion row is mandatory — omitting it breaks the N380→N390 audit handshake.
