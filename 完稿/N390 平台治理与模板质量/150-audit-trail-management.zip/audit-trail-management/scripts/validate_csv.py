#!/usr/bin/env python3
"""Validate audit-trail CSV files and optional append-only updates."""
from __future__ import annotations
import argparse, csv, re, sys
from datetime import datetime
from pathlib import Path
EXPECTED = ["id", "timestamp", "actor", "action", "artifact_version", "evidence_ref", "reversible", "notes"]
ID_RE = re.compile(r"^AU-\d{3,6}$")
REVERSIBLE = {"YES", "NO", "PARTIAL", "UNKNOWN"}
ACTIONS = {
    "gate_pass_decision", "hcn_signed", "hcn_rejected", "hcn_escalated", "fallback_activated",
    "fallback_rehearsal_skipped", "state_transitioned", "template_registered", "template_updated",
    "template_deprecated", "quality_score_updated", "snapshot_created", "pm_override_recorded", "audit_correction"
}

def parse_ts(value):
    if value in {"待确认", "待核对"}: return None
    try:
        return datetime.fromisoformat(value)
    except Exception:
        raise ValueError(f"timestamp must be ISO-8601 or 待确认, got {value!r}")

def read_rows(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != EXPECTED:
            raise ValueError(f"{path}: header must be exactly {EXPECTED}, got {reader.fieldnames}")
        rows = list(reader)
    if not rows: raise ValueError(f"{path}: ledger must contain at least one row")
    return rows

def validate_rows(rows, path: Path, strict=False):
    seen=set(); last_num=-1; prev_ts=None
    for i,row in enumerate(rows,start=2):
        rid=row['id'].strip()
        if not ID_RE.match(rid): raise ValueError(f"{path}:{i}: id must look like AU-001, got {rid!r}")
        if rid in seen: raise ValueError(f"{path}:{i}: duplicate id {rid}")
        seen.add(rid); num=int(rid.split('-')[1])
        if num <= last_num: raise ValueError(f"{path}:{i}: ids must be monotonically increasing")
        last_num=num
        for col in ["timestamp","actor","action","artifact_version","evidence_ref","reversible"]:
            if not row[col].strip(): raise ValueError(f"{path}:{i}: {col} must not be empty")
        ts=parse_ts(row['timestamp'].strip())
        if ts and prev_ts and ts < prev_ts: raise ValueError(f"{path}:{i}: timestamp must be monotonic append-only")
        if ts: prev_ts=ts
        action=row['action'].strip()
        if action not in ACTIONS: raise ValueError(f"{path}:{i}: unsupported action {action!r}")
        if row['reversible'].strip() not in REVERSIBLE: raise ValueError(f"{path}:{i}: reversible must be one of {sorted(REVERSIBLE)}")
        if ',' in row['notes'] and '|' not in row['notes']: raise ValueError(f"{path}:{i}: use pipe-delimited key/value notes instead of comma-separated lists")
        if action == 'audit_correction' and 'corrects=' not in row['notes']:
            raise ValueError(f"{path}:{i}: audit_correction requires notes corrects=<AU-id>")

def check_append_only(new_rows, old_rows):
    if len(new_rows) < len(old_rows): raise ValueError("new ledger is shorter than previous ledger")
    for idx, old in enumerate(old_rows):
        if new_rows[idx] != old: raise ValueError(f"append-only violation at data row {idx+2}: previous row was modified or reordered")

def main(argv=None):
    p=argparse.ArgumentParser(); p.add_argument('csv_path', type=Path); p.add_argument('--previous', type=Path); p.add_argument('--strict', action='store_true')
    args=p.parse_args(argv)
    try:
        new_rows=read_rows(args.csv_path); validate_rows(new_rows,args.csv_path,args.strict)
        if args.previous:
            old_rows=read_rows(args.previous); validate_rows(old_rows,args.previous,args.strict); check_append_only(new_rows,old_rows)
    except Exception as exc:
        print(f"INVALID: {exc}", file=sys.stderr); return 1
    print(f"VALID audit ledger: {args.csv_path} ({len(new_rows)} rows)"); return 0
if __name__=='__main__': raise SystemExit(main())
