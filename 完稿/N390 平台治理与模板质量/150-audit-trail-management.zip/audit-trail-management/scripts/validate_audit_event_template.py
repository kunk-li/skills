#!/usr/bin/env python3
"""Validate N380 -> N390 audit handshake: HCN audit_event_template materialized as AU row."""
from __future__ import annotations
import argparse, csv, re, sys
from pathlib import Path
from n390_validators_common import split_pipe, print_errors

def parse_notes(notes):
    out={}
    for part in split_pipe(notes):
        if '=' in part:
            k,v=part.split('=',1); out[k.strip()]=v.strip()
    return out

def load_au_ids(path):
    rows=[]
    with path.open(encoding='utf-8-sig', newline='') as f:
        for r in csv.DictReader(f): rows.append(r)
    return rows

def main(audit_csv: Path, template: str):
    errors=[]
    if not template.startswith('AU:new'):
        errors.append('audit_event_template must start with AU:new')
    # Extract key=value pairs from template; placeholders are accepted.
    tpl=dict(re.findall(r"(actor|action|target|linked_gate|linked_fallback|linked_state|decision|evidence)=([^\s]+)", template))
    if 'target' not in tpl or 'evidence' not in tpl:
        errors.append('audit_event_template must include target and evidence')
    rows=load_au_ids(audit_csv)
    matched=False
    for r in rows:
        notes=parse_notes(r.get('notes',''))
        if tpl.get('target') and tpl['target'] in (r.get('artifact_version','') + '|' + r.get('notes','')) and (not tpl.get('evidence') or r.get('evidence_ref') == tpl.get('evidence')):
            matched=True
            if tpl.get('linked_gate') and notes.get('gate_ref') != tpl.get('linked_gate'):
                errors.append(f"AU row {r.get('id')}: notes.gate_ref does not match linked_gate")
            if tpl.get('linked_fallback') and notes.get('fallback_ref') not in {tpl.get('linked_fallback'), tpl.get('linked_fallback','').replace('FB-','FB-')}:
                # fallback may be represented as fb_ref in older rows
                if notes.get('fb_ref') != tpl.get('linked_fallback'):
                    errors.append(f"AU row {r.get('id')}: notes fallback ref does not match linked_fallback")
            if tpl.get('evidence') and r.get('evidence_ref') != tpl.get('evidence'):
                errors.append(f"AU row {r.get('id')}: evidence_ref does not match template evidence")
    if not matched:
        errors.append('no AU row materializes audit_event_template target')
    if print_errors(errors): return 1
    print('OK: N380 audit_event_template is materialized by N390 audit ledger')
    return 0
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('audit_csv', type=Path); p.add_argument('--template', required=True)
    a=p.parse_args(); raise SystemExit(main(a.audit_csv, a.template))
