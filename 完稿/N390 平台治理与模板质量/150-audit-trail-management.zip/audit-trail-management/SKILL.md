---
name: audit-trail-management
description: materialize immutable AU-* audit ledger rows from governance events, especially N380 audit_event_template handoffs, gate/fallback/hcn decisions, template lifecycle changes, quality score updates, and correction entries. use when the user needs append-only audit history, N380 audit_ref completion, audit snapshot views, or audit-event template ingestion. not for cataloging reusable templates (use template-management) or scoring quality and gate advice (use quality-scoring-engine).
---

# Audit Trail Management

## N390 v1.4.0 contract baseline

- contract_version: `n390-governance-sink-v1.4.0`
- workflow_node: `N390`
- skill_id: `150`
- csv_schema: `n390.audit-trail.v2`
- artifact_target: `审计留痕日志.csv`

This skill is self-contained and can run alone with partial evidence. It composes with sibling N390 skills through `artifact_id`, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff`.

## References

Before producing final output, consult:
- `references/n390-shared-governance-contract.md`
- `references/n390-id-space.md`
- `references/output-contract.yaml`
- `references/metadata-schema.json`
- `references/anti-patterns.md`
- `references/selected-mode-decision-tree.md`
- `references/audit-trail-management-quality-checklist.md`
- skill-specific schema/rubric files packaged with this skill

## Selected mode

Choose one selected mode from: `event_ingestion / append_only_update / n380_audit_template_ingestion / correction_entry`. Record it in the sidecar metadata.

## Required output

Produce the CSV artifact `审计留痕日志.csv` and a sidecar metadata file. Keep CSV machine-readable. Use `|` for multi-value cells, not bare commas.

## Workflow

1. Identify source artifacts, upstream IDs, evidence, and open gaps. Read `references/anti-patterns.md` before finalizing rows.
2. Select mode and readiness using `references/selected-mode-decision-tree.md`.
3. Produce rows using the exact CSV schema.
4. Produce sidecar metadata with `metadata` and `downstream_handoff` sections.
5. Run `scripts/validate_csv.py` on the CSV.
6. Run `scripts/validate_metadata.py` and `scripts/validate_metadata_schema.py` on metadata.
7. For a three-artifact N390 family, run `scripts/validate_release_consistency.py`; for N380→N390 end-to-end validation, run `scripts/validate_six_skill_cascade.py`.
8. Review `references/anti-patterns.md`, apply the quality checklist, and summarize readiness/confidence.

## Skill-specific rule

If the source is N380 and contains `audit_event_template`, materialize it as an AU row and validate the handoff with `scripts/validate_audit_event_template.py`. Append-only updates must preserve all previous rows exactly.

## Boundaries

- Do not replace sibling skills: audit trails, template lifecycle, and quality scoring have distinct ownership.
- Do not invent evidence, owners, dates, scores, or approvals.
- Do not depend on files outside this skill package.
