---
name: audit-trail-management
display_name: 审计留痕管理 / Audit Trail Management
description: Materialize immutable AU-* audit ledger rows and audit_ref completion; route gate decisions to 147, fallback to 148, HCN to 149, template registry to 151, and quality scoring to 152.
---

# Audit Trail Management

## N390 v1.4.0 contract baseline

- contract_version: `n390-governance-sink-v1.4.0`
- workflow_node: `N390`
- skill_id: `150`
- csv_schema: `n390.audit-trail.v2`
- artifact_target: `审计留痕日志.csv`

This skill is self-contained and can run alone with partial evidence. It composes with sibling N390 skills through `artifact_id`, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff`.

## Sibling routing / 兄弟技能路由

Use 150 only to materialize AU-* audit ledger rows and audit_ref completion.
Route sibling N390 concerns instead of absorbing them:
- gate verdict aggregation -> 147 gate-pass-decision
- fallback activation or rollback planning -> 148 fallback-switching
- human signature / approval / override node design -> 149 human-confirmation-node-management
- reusable template or schema registry rows -> 151 template-management
- scorecards, dimensions, and gate_signal recommendation -> 152 quality-scoring-engine

When an input mixes these concerns, emit only the AU-* rows and keep sibling work
as `downstream_handoff` / `cross_artifact_refs`.


## Mode selection at a glance

| mode | when to use |
| --- | --- |
| `event_ingestion` | ingesting new governance events as AU rows |
| `append_only_update` | appending rows to an existing ledger without modifying prior rows |
| `n380_audit_template_ingestion` | materializing AU rows from an N380 audit_event_template handoff |
| `correction_entry` | recording a correction or amendment to a prior AU row |

For detailed decision logic, consult `references/selected-mode-decision-tree.md`.

## References

Before producing final output, consult:
- `references/n390-shared-governance-contract.md`
- `references/n390-id-space.md`
- `references/output-contract.yaml`
- `references/metadata-schema.json`
- `references/anti-patterns.md`
- `references/selected-mode-decision-tree.md`
- `references/audit-trail-management-quality-checklist.md`
- skill-specific schema/rubric files packaged with this skill

## Selected mode

Choose one selected mode from: `event_ingestion / append_only_update / n380_audit_template_ingestion / correction_entry`. Record it in the sidecar metadata.

## Required output

Produce the CSV artifact `审计留痕日志.csv` and a sidecar metadata file. Keep CSV machine-readable. Use `|` for multi-value cells, not bare commas.

## Inline field contract

Primary artifact: `审计留痕日志.csv`  Schema: `n390.audit-trail.v2`

Produce CSV rows in exact schema column order (see `references/output-contract.yaml`). Use `待确认` for missing fields; `not_applicable` only when explicitly irrelevant.

| field | required | description |
| --- | --- | --- |
| `au_id` | required | immutable AU row id — `AU-<scope>-<nnn>` |
| `event_type` | required | governance event type |
| `source_artifact_id` | required | artifact that triggered this audit event |
| `event_timestamp` | required | ISO-8601 datetime |
| `actor` | required | human or system actor |
| `action` | required | action performed |
| `outcome` | required | `pass\|cond_go\|fail\|correction\|override` |
| `evidence_refs` | required | source anchors for this event |
| `cross_artifact_refs` | required | sibling N390 artifact IDs |
| `immutability_note` | required | append-only statement; prior rows must not be modified |
| `confidence` | required | `high\|medium\|low\|needs_human_review` |
| `open_questions` | required | unresolved questions or `none` |

## Workflow

1. Identify source artifacts, upstream IDs, evidence, and open gaps. Note missing fields as `待确认` rather than silently omitting them.
2. Read `references/anti-patterns.md` before writing any rows; anti-patterns from sibling skills (N380 gate/fallback/HCN) may also apply when the source is an N380 artifact.
3. Select one `selected_mode` using `references/selected-mode-decision-tree.md` and record it in metadata.
4. Produce CSV rows in the exact schema column order defined in `references/output-contract.yaml`.
5. Produce sidecar metadata with `metadata` and `downstream_handoff` sections; use `references/metadata-schema.json` for field requirements.
6. Run `scripts/validate_csv.py <csv-file>` and fix any schema or ordering errors before continuing.
7. Run `scripts/validate_metadata.py <metadata.yaml>` to confirm contract_version, artifact_id, and required fields.
8. Run `scripts/validate_metadata_schema.py <metadata.yaml>` for JSON Schema strict validation.
9. Run `scripts/validate_skill_md.py SKILL.md` to prevent stale contract_version headings.
10. Run `scripts/validate_decision_tree.py references/selected-mode-decision-tree.md references/output-contract.yaml` to prevent selected_mode drift.
11. For a three-artifact N390 family release, run `scripts/validate_release_consistency.py <150.meta> <151.meta> <152.meta>`; for N380→N390 end-to-end validation, run `scripts/validate_six_skill_cascade.py`.
12. Apply `references/quality-checklist.md` and summarize `readiness` and `confidence` in the sidecar.

## Skill-specific rule

If the source is N380 and contains `audit_event_template`, materialize it as an AU row and validate the handoff with `scripts/validate_audit_event_template.py`. Append-only updates must preserve all previous rows exactly.

## Boundaries

- Do not replace sibling skills: audit trails, template lifecycle, and quality scoring have distinct ownership.
- Do not invent evidence, owners, dates, scores, or approvals.
- Do not depend on files outside this skill package.

## Six-skill N380→N390 integration cascade

To validate the full N380→N390 six-skill cascade from the `examples/integration/` directory:

```bash
python scripts/validate_six_skill_cascade.py \
    examples/integration/gate-fail-example.csv \
    examples/integration/fallback-activation-example.csv \
    examples/integration/hcn-escalation-example.csv \
    examples/integration/audit-ledger-n380-template-ingestion.csv \
    examples/integration/template-index-n380-schemas.csv \
    examples/integration/quality-scorecard-core-fail.csv
```

See `examples/integration/README.md` for the full artifact listing and cross-reference map.

