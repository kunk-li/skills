# Template Management Quality Checklist

1. Metadata and downstream_handoff pass semantic and JSON Schema validation.
2. CSV rows pass `scripts/validate_csv.py`.
3. IDs follow `references/n390-id-space.md`.
4. `cross_artifact_refs` do not include the artifact's own id.
5. Evidence references preserve upstream IDs instead of rewriting them.
6. `owner_placeholders` use role/team unless a source explicitly provides a person.
7. Unknowns use `待确认` or `待核对`, not invented values.
8. Sibling N390 artifacts are referenced when available.
9. N380 handoff fields are preserved when present.
10. Readiness and confidence match evidence quality.

## Skill-specific checks
- Active templates include adjacent_skills and success_criteria.
- Dormant templates do not set deprecation_date.
- N380 csv_schema templates use `artifact_type=schema`.

- Lifecycle changes include `transition_audit_ref` and the referenced AU row exists when running six-skill cascade strict mode.
