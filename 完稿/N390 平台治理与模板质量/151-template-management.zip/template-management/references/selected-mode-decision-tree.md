# Selected Mode Decision Tree: Template Management

Use this before producing template index rows.

```text
Are you creating a new template library or initial index for a project?
├── yes -> template_library_bootstrap
└── no: are you reviewing lifecycle status of existing templates?
    ├── yes -> template_lifecycle_review
    └── no: are you registering CSV/schema contracts from N380/N370/N360/N350?
        ├── yes -> schema_template_registry
        └── no: are you mapping templates to adjacent skills or consumers?
            ├── yes -> adjacent_skill_mapping
            └── no -> template_lifecycle_review with readiness=partial
```

## Guardrails
- N380/N370/N360/N350 CSV or metadata schemas should use `artifact_type=schema`.
- Dormant templates must not carry `deprecation_date`; explain dormancy in notes.
- Active templates need adjacent skills or nodes so they are discoverable.
