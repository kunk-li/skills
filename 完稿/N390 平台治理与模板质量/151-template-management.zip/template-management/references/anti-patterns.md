# N390 Template Management Anti-Patterns

Use this file before finalizing template index rows. Template governance is an asset registry, not a loose list of file names.

## Skill-specific anti-patterns

### AP-151-1: Dormant template with deprecation_date
- Bad: `lifecycle_status=dormant` and `deprecation_date=2026-06-01`.
- Why it is wrong: Dormant means paused or not currently recommended; deprecated means retired.
- Validator expectation: `validate_csv.py` rejects dormant rows with `deprecation_date`.
- Correct pattern: Use `lifecycle_status=deprecated` if the template is retired, otherwise leave deprecation date empty and explain dormancy in notes.

### AP-151-2: Non-ISO date values
- Bad: `last_reviewed=April 20th 2026` or `deprecation_date=Q2 2026`.
- Why it is wrong: Date fields are used by downstream refresh jobs and must sort lexicographically.
- Validator expectation: `validate_csv.py` requires `YYYY-MM-DD`.
- Correct pattern: Use `2026-04-20`.

### AP-151-3: Active template with no adjacent skills
- Bad: An active template has empty `adjacent_skills`.
- Why it is wrong: Active templates must be discoverable by at least one consuming skill or node.
- Validator expectation: `validate_csv.py` rejects active rows with no adjacent skills.
- Correct pattern: Fill `adjacent_skills` with pipe-separated skills such as `gate-pass-decision|audit-trail-management`.

### AP-151-4: N380 CSV schema not registered as artifact_type=schema
- Bad: Catalog `n380.gate-pass-decision.v2` as a generic CSV template.
- Why it is wrong: Schema artifacts are executable contracts and need schema lifecycle treatment.
- Validator expectation: The v1.2.0 schema supports and expects `artifact_type=schema` for upstream schema rows.
- Correct pattern: Use `artifact_type=schema` and evidence pointing to the upstream output contract or metadata schema.

## Shared anti-pattern seed list

See `references/n390-shared-governance-contract.md` section `Shared anti-pattern seed list` for the canonical 13 cross-skill anti-patterns. Do not duplicate the shared list here; keep this file focused on skill-specific mistakes.


### AP-151-5: Lifecycle transition without AU hook
- Bad: A dormant or deprecated template row has no `transition_audit_ref`.
- Why it is wrong: template lifecycle transitions must be auditable in the N390 ledger, otherwise template governance cannot explain why a template changed state.
- Validator expectation: `validate_csv.py` rejects dormant/deprecated rows without concrete `transition_audit_ref`, and `validate_six_skill_cascade.py --strict` checks that the referenced AU row exists.
- Correct pattern: Set `transition_audit_ref=AU-...` and ensure the AU row notes include `template_ref=<template_id>`.


### AP-151-6: Template lifecycle transition without audit linkage
- Bad: Deprecate or dormant-review a template without `transition_audit_ref`.
- Why it is wrong: lifecycle state changes must be explainable through the immutable audit ledger.
- Validator expectation: `validate_csv.py` rejects dormant/deprecated rows without AU-* transition references, and cascade strict checks the AU row exists.
- Correct pattern: Add `transition_audit_ref=AU-...` and an AU row with `template_ref=<TPL-id>` in notes.
