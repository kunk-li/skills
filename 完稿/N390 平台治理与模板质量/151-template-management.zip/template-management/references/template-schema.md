# Template Schema

Template rows catalog reusable governance assets. `artifact_type=schema` is valid and should be used for upstream CSV/YAML/JSON schemas such as `n380.gate-pass-decision.v2`.

Active templates require `success_criteria` and `adjacent_skills`. Dormant templates must not have `deprecation_date` and should explain the dormancy reason in `notes`. Deprecated templates require an ISO `deprecation_date`.


## Lifecycle audit hook

Every template row includes `transition_audit_ref`. Active and deprecated lifecycle states require a concrete `AU-*` row so N390 template governance remains traceable through `audit-trail-management`. Dormant templates should also preserve the most recent lifecycle AU when available.
