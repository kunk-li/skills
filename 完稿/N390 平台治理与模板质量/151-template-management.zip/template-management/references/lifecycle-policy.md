# Template Lifecycle Policy

## active

Use when the template is currently recommended, required by a workflow, or actively consumed by at least one skill.

Required:
- `success_criteria` is non-empty.
- `deprecation_date` is empty.

## dormant

Use when the template is valid but not currently recommended or frequently used.

Typical reasons:
- Project phase ended.
- Template is kept for fallback or historical replay.
- Template may become active again in a future release.

## deprecated

Use when the template should not be used for new work.

Required:
- `deprecation_date` is set.
- `notes` should include a migration target when available.
- Keep the row for auditability; do not delete it.


## Transition audit reference
N390 v1.4.0 adds `transition_audit_ref` to the template index CSV. Use it to point from a template lifecycle row to the AU-* row that registered, updated, dormant-reviewed, or deprecated the template. For `dormant` and `deprecated`, the reference should be concrete rather than `not_applicable` unless the artifact is explicitly partial.
