# Real Examples / 真实示例参考

These examples illustrate correctly formed template registry rows and common edge cases. Use them alongside the bundled `examples/` files.

---

## Example 1: Schema template registry — version field is required

**Input**: A new gate decision CSV schema is published for N380 v1.5.0.

**Correct pattern**:
```
template_id: TMPL-gate-pass-v2
template_name: n380.gate-pass-decision.v2
template_type: csv_schema
contract_version: n380-platform-gate-v1.5.0
status: active
published_at: "2026-05-01"
owner: n380-platform-team
description: Gate pass decision CSV schema for N380 platform gate v1.5.0; includes hcn_ref, fallback_ref, audit_ref columns
```

**Rule**: Every template row must carry `contract_version` — without it, the template cannot be validated against the correct family contract.

---

## Example 2: Template lifecycle — dormant before deprecated

**Input**: TMPL-gate-pass-v1 has had no usage in 90 days but is still referenced in one legacy pipeline.

**Correct pattern**:
```
template_id: TMPL-gate-pass-v1
status: dormant
dormant_since: "2026-03-01"
dormant_reason: superseded by TMPL-gate-pass-v2; one legacy pipeline still references this template
migration_target: TMPL-gate-pass-v2
migration_deadline: "2026-06-01"
```

**Rule**: Set `status: dormant` before `deprecated`. Dormant allows the legacy reference to complete migration; deprecated signals no further use is permitted.

---

## Example 3: Template deprecation — migration path must be explicit

**Input**: TMPL-gate-pass-v1 migration is complete. Ready to deprecate.

**Correct pattern**:
```
template_id: TMPL-gate-pass-v1
status: deprecated
deprecated_at: "2026-06-01"
deprecated_reason: all pipelines migrated to TMPL-gate-pass-v2; v1 schema no longer supported
migration_completed: yes
replacement_template_id: TMPL-gate-pass-v2
```

**Anti-pattern**: Jumping directly from `active` to `deprecated` without a `dormant` period — pipelines that still reference the template have no migration runway and may fail unexpectedly.
