#!/usr/bin/env python3
"""Validate template-management CSV files."""
from __future__ import annotations
import argparse,csv,re,sys
from pathlib import Path
EXPECTED=["template_id","title","artifact_type","version","lifecycle_status","frequency","adjacent_skills","deprecation_date","success_criteria","owner","last_reviewed","evidence_ref","transition_audit_ref","notes"]
ID_RE=re.compile(r"^(TPL-\d{3,6}|TPL-[A-Za-z0-9_-]+-\d{3,6})$")
STATUS={"active","dormant","deprecated"}
TYPES={"md","csv","yaml","json","xlsx","docx","pptx","code","pattern","runbook","schema","other"}
FREQ={"daily","weekly","sprint","monthly","release","on-change","ad-hoc","unknown"}
DATE_RE=re.compile(r"^\d{4}-\d{2}-\d{2}$")
VERSION_RE=re.compile(r"^(v?\d+(\.\d+){0,2}(-[A-Za-z0-9_.-]+)?|n\d{3}\.[A-Za-z0-9_.-]+\.v\d+)$")
PLACEHOLDER={"", "待确认", "待核对", "not_applicable", "unknown"}

def main(argv=None):
    p=argparse.ArgumentParser(); p.add_argument('csv_path',type=Path); p.add_argument('--strict', action='store_true')
    args=p.parse_args(argv)
    warnings=[]
    try:
        with args.csv_path.open('r',encoding='utf-8-sig',newline='') as f:
            reader=csv.DictReader(f)
            if reader.fieldnames!=EXPECTED: raise ValueError(f"header must be exactly {EXPECTED}, got {reader.fieldnames}")
            rows=list(reader)
        if not rows: raise ValueError('template index must contain at least one row')
        seen=set()
        for i,row in enumerate(rows,start=2):
            tid=row['template_id'].strip()
            if not ID_RE.match(tid): raise ValueError(f"line {i}: template_id must look like TPL-001 or TPL-platform-001, got {tid!r}")
            if tid in seen: raise ValueError(f"line {i}: duplicate template_id {tid}")
            seen.add(tid)
            for col in ['title','artifact_type','version','lifecycle_status','frequency','owner','last_reviewed','evidence_ref','transition_audit_ref']:
                if not row[col].strip(): raise ValueError(f"line {i}: {col} must not be empty")
            if not VERSION_RE.match(row['version'].strip()): raise ValueError(f"line {i}: version must look like v1, v1.0, 1.2.3, v1.2.3-beta, or n390.schema-name.v2")
            if row['artifact_type'].strip() not in TYPES: raise ValueError(f"line {i}: unsupported artifact_type {row['artifact_type']!r}")
            status=row['lifecycle_status'].strip()
            if status not in STATUS: raise ValueError(f"line {i}: lifecycle_status must be one of {sorted(STATUS)}")
            if row['frequency'].strip() not in FREQ: raise ValueError(f"line {i}: frequency must be one of {sorted(FREQ)}")
            if not DATE_RE.match(row['last_reviewed'].strip()): raise ValueError(f"line {i}: last_reviewed must be YYYY-MM-DD")
            dep=row['deprecation_date'].strip()
            if dep and not DATE_RE.match(dep): raise ValueError(f"line {i}: deprecation_date must be YYYY-MM-DD when present")
            if ',' in row['adjacent_skills']: raise ValueError(f"line {i}: adjacent_skills must use pipe separators, not commas")
            transition=row['transition_audit_ref'].strip()
            if status in {'active','deprecated'} and not transition.startswith('AU-'):
                raise ValueError(f"line {i}: {status} template requires concrete transition_audit_ref starting with AU-")
            if status=='dormant' and transition in PLACEHOLDER:
                warnings.append(f"line {i}: dormant template should keep a transition_audit_ref when lifecycle status changed")
            if status=='active':
                if dep: raise ValueError(f"line {i}: active template cannot have deprecation_date")
                if not row['success_criteria'].strip(): raise ValueError(f"line {i}: active template requires success_criteria")
                if not row['adjacent_skills'].strip(): raise ValueError(f"line {i}: active template requires adjacent_skills")
            if status=='deprecated' and not dep: raise ValueError(f"line {i}: deprecated template requires deprecation_date")
            if status=='dormant':
                if dep: raise ValueError(f"line {i}: dormant template should not set deprecation_date; use deprecated instead")
                if args.strict and not row['notes'].strip(): raise ValueError(f"line {i}: dormant template should explain why in notes")
    except Exception as exc:
        print(f"INVALID: {exc}",file=sys.stderr); return 1
    for w in warnings:
        print(f"WARN: {w}", file=sys.stderr)
    print(f"VALID template index: {args.csv_path} ({len(rows)} rows)"); return 0
if __name__=='__main__': raise SystemExit(main())
