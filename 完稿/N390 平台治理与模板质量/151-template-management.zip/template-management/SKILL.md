---
name: template-management
description: catalog reusable templates and schema assets across governance nodes, including N380 csv_schema templates, audit ledger templates, scorecard templates, runbooks, lifecycle status, adjacent skills, migration notes, and deprecation governance. use when the user needs TPL-* rows, active/dormant/deprecated lifecycle management, schema template registry entries, or adjacent-skill mapping. not for immutable audit events (use audit-trail-management) or quality scoring (use quality-scoring-engine).
---

# Template Management

## N390 v1.4.0 contract baseline

- contract_version: `n390-governance-sink-v1.4.0`
- workflow_node: `N390`
- skill_id: `151`
- csv_schema: `n390.template-registry.v3`
- artifact_target: `模板库索引.csv`

This skill is self-contained and can run alone with partial evidence. It composes with sibling N390 skills through `artifact_id`, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff`.

## References

Before producing final output, consult:
- `references/n390-shared-governance-contract.md`
- `references/n390-id-space.md`
- `references/output-contract.yaml`
- `references/metadata-schema.json`
- `references/anti-patterns.md`
- `references/selected-mode-decision-tree.md`
- `references/template-management-quality-checklist.md`
- skill-specific schema/rubric files packaged with this skill

## Selected mode

Choose one selected mode from: `template_library_bootstrap / template_lifecycle_review / schema_template_registry / adjacent_skill_mapping`. Record it in the sidecar metadata.

## Required output

Produce the CSV artifact `模板库索引.csv` and a sidecar metadata file. Keep CSV machine-readable. Use `|` for multi-value cells, not bare commas.

## Workflow

1. Identify source artifacts, upstream IDs, evidence, and open gaps. Read `references/anti-patterns.md` before finalizing rows.
2. Select mode and readiness using `references/selected-mode-decision-tree.md`.
3. Produce rows using the exact CSV schema.
4. Produce sidecar metadata with `metadata` and `downstream_handoff` sections.
5. Run `scripts/validate_csv.py` on the CSV.
6. Run `scripts/validate_metadata.py` and `scripts/validate_metadata_schema.py` on metadata.
7. For a three-artifact N390 family, run `scripts/validate_release_consistency.py`; for N380→N390 end-to-end validation, run `scripts/validate_six_skill_cascade.py`.
8. Review `references/anti-patterns.md`, apply the quality checklist, and summarize readiness/confidence.

## Skill-specific rule

Treat N380/N370/N360/N350 schemas as `artifact_type=schema` template assets. Active templates require adjacent skills and success criteria. Dormant templates require an explanatory note.

## Boundaries

- Do not replace sibling skills: audit trails, template lifecycle, and quality scoring have distinct ownership.
- Do not invent evidence, owners, dates, scores, or approvals.
- Do not depend on files outside this skill package.
