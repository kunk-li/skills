---
name: template-management
display_name: 模板库管理 / Template Management
description: Catalog reusable templates and schema assets (CSV schemas, audit ledger templates, scorecards, runbooks) as TPL-* rows with active/dormant/deprecated lifecycle and deprecation governance.
---

# Template Management

## N390 v1.4.0 contract baseline

- contract_version: `n390-governance-sink-v1.4.0`
- workflow_node: `N390`
- skill_id: `151`
- csv_schema: `n390.template-registry.v3`
- artifact_target: `模板库索引.csv`

This skill is self-contained and can run alone with partial evidence. It composes with sibling N390 skills through `artifact_id`, `cross_artifact_refs`, `evidence_refs`, and `downstream_handoff`.

## Mode selection at a glance

| mode | when to use |
| --- | --- |
| `template_library_bootstrap` | creating an initial template registry from scratch |
| `template_lifecycle_review` | reviewing active/dormant/deprecated status across templates |
| `schema_template_registry` | registering N380/N390 CSV schema templates |
| `adjacent_skill_mapping` | mapping templates to the skills that consume them |

For detailed decision logic, consult `references/selected-mode-decision-tree.md`.

## References

Before producing final output, consult:
- `references/n390-shared-governance-contract.md`
- `references/n390-id-space.md`
- `references/output-contract.yaml`
- `references/metadata-schema.json`
- `references/anti-patterns.md`
- `references/selected-mode-decision-tree.md`
- `references/template-management-quality-checklist.md`
- skill-specific schema/rubric files packaged with this skill

## Selected mode

Choose one selected mode from: `template_library_bootstrap / template_lifecycle_review / schema_template_registry / adjacent_skill_mapping`. Record it in the sidecar metadata.

## Required output

Produce the CSV artifact `模板库索引.csv` and a sidecar metadata file. Keep CSV machine-readable. Use `|` for multi-value cells, not bare commas.

## Inline field contract

Primary artifact: `模板库索引.csv`  Schema: `n390.template-registry.v3`

Produce CSV rows in exact schema column order (see `references/output-contract.yaml`). Use `待确认` for missing fields; `not_applicable` only when explicitly irrelevant.

| field | required | description |
| --- | --- | --- |
| `tpl_id` | required | stable template id — `TPL-<scope>-<nnn>` |
| `template_name` | required | human-readable template name |
| `artifact_type` | required | `schema\|runbook\|scorecard\|audit_ledger\|custom` |
| `lifecycle_status` | required | `active\|dormant\|deprecated` |
| `adjacent_skills` | required | `\|`-separated skill IDs that consume this template |
| `success_criteria` | required | how to know the template is used correctly (required for active) |
| `dormant_note` | required | reason for dormant status or `not_applicable` |
| `migration_note` | recommended | migration guidance when deprecating |
| `deprecation_date` | recommended | ISO-8601 date when deprecated |
| `cross_artifact_refs` | required | sibling N390 artifact IDs |
| `evidence_refs` | required | source anchors |

## Workflow

1. Identify source artifacts, upstream IDs, evidence, and open gaps. Note missing fields as `待确认` rather than silently omitting them.
2. Read `references/anti-patterns.md` before writing any rows; anti-patterns from sibling skills (N380 gate/fallback/HCN) may also apply when the source is an N380 artifact.
3. Select one `selected_mode` using `references/selected-mode-decision-tree.md` and record it in metadata.
4. Produce CSV rows in the exact schema column order defined in `references/output-contract.yaml`.
5. Produce sidecar metadata with `metadata` and `downstream_handoff` sections; use `references/metadata-schema.json` for field requirements.
6. Run `scripts/validate_csv.py <csv-file>` and fix any schema or ordering errors before continuing.
7. Run `scripts/validate_metadata.py <metadata.yaml>` to confirm contract_version, artifact_id, and required fields.
8. Run `scripts/validate_metadata_schema.py <metadata.yaml>` for JSON Schema strict validation.
9. Run `scripts/validate_skill_md.py SKILL.md` to prevent stale contract_version headings.
10. Run `scripts/validate_decision_tree.py references/selected-mode-decision-tree.md references/output-contract.yaml` to prevent selected_mode drift.
11. For a three-artifact N390 family release, run `scripts/validate_release_consistency.py <150.meta> <151.meta> <152.meta>`; for N380→N390 end-to-end validation, run `scripts/validate_six_skill_cascade.py`.
12. Apply `references/quality-checklist.md` and summarize `readiness` and `confidence` in the sidecar.

## Skill-specific rule

Treat N380/N370/N360/N350 schemas as `artifact_type=schema` template assets. Active templates require adjacent skills and success criteria. Dormant templates require an explanatory note.

## Boundaries

- Do not replace sibling skills: audit trails, template lifecycle, and quality scoring have distinct ownership.
- Do not invent evidence, owners, dates, scores, or approvals.
- Do not depend on files outside this skill package.

## Six-skill N380→N390 integration cascade

To validate the full N380→N390 six-skill cascade from the `examples/integration/` directory:

```bash
python scripts/validate_six_skill_cascade.py \
    examples/integration/gate-fail-example.csv \
    examples/integration/fallback-activation-example.csv \
    examples/integration/hcn-escalation-example.csv \
    examples/integration/audit-ledger-n380-template-ingestion.csv \
    examples/integration/template-index-n380-schemas.csv \
    examples/integration/quality-scorecard-core-fail.csv
```

See `examples/integration/README.md` for the full artifact listing and cross-reference map.

