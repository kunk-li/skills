# Quality checklist

Before finalizing the output:
- Confirm recommendation state is explicit and justified.
- Confirm hard requirements and soft requirements are separated.
- Confirm the observation period is adequate for the decision state.
- Confirm signoff fields are real, pending, or omitted; never invent approvals.
- Confirm follow-up items exist for any conditional or deferred decision.
- Confirm linked PRV traceability remains intact.

## 2.1.1 reactive checks

- Confirm `skill_contract_version` and `artifact_contract` are present.
- Confirm `reactive_handoff` includes produced and gap/SLA events when relevant.
- Confirm recommendation states are advisory and not formal gate decisions.
- Confirm signoff evidence is real, pending, or explicitly missing; never fabricated.
- Confirm no signoff field uses anything resembling a real timestamp, real person name, or role-specific approval unless that evidence is explicitly provided. Use placeholder syntax such as `<pending_pm_signoff>` or mark the item as `pending_input` when evidence is missing.
- Confirm acceptance dimension gaps are preserved instead of causing all-or-nothing rejection.
- Confirm N005 feedback candidates are captured when release observations should influence future requirements or validation focus.
