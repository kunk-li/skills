## Self-check quantified rules — final extensions

| Rule ID | Precise condition | Measurement | Failure action |
|---|---|---|---|
| SCR-GOLIVEAC-053 | `ga_decision_view.p0_failed` > 0 → `recommendation: NO_GO` always | conditional | `self_check.failed_rules: ["SCR-GOLIVEAC-053: p0_failed>0 but recommendation≠NO_GO"]` |
| SCR-GOLIVEAC-054 | `adversarial_detection.injection_attempt_detected` boolean declared | key exists | `self_check.warnings: ["SCR-GOLIVEAC-054: injection_detected missing"]` |