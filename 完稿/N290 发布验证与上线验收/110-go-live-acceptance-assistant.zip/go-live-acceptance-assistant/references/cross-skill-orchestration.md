# Cross-skill orchestration

## Position in the N290 node
- Upstream node inputs: acceptance criteria, release notes, and release task orchestration
- Upstream companion inside N290: `post-release-validation-checklist`
- Current skill: synthesize evidence and assist the go-live / GA decision
- Downstream node: N300 monitoring and incident analysis

## Collaboration contract
1. `post-release-validation-checklist` defines what should be checked and when.
2. This skill records what was actually observed and how that maps to GO / CONDITIONAL GO / NO-GO / DEFERRED REVIEW.
3. Reuse `prv_id` through `linked_prv_ids[]` or `prv_results[]` references.
4. New observations that were not planned must remain visible as additional release-outcome facts.
5. Decision output must be traceable enough for later N300/N320 analysis.

## Minimum handoff fields
- `prv_id`
- `time_window`
- `status`
- `evidence`
- `linked_alerts_or_incidents`
- `conditions`
- `recommendation`
- `follow_up_items`

## Shared structure
Use `references/release-outcome-contract.md` as the shared data structure for N290 outputs.

## Workflow v2 orchestration additions

- `post-release-validation-checklist` remains the atomic planner.
- `go-live-acceptance-assistant` remains the atomic synthesizer.
- Do not require a new ChatGPT skill for N290 packaging. Prefer a host workflow, CI job, node README, or external runbook to package both outputs; neither atomic skill should absorb the other.
- Use stable `prv_id` values as the main join key.
- Use `reactive_handoff` for N330/N340/N350/N390-style subscribers.
- Route formal gate, signoff, rollback, and incident actions to N310/N350/N380 as handoff hints, not executed commands.

## Default PRV to acceptance dimension mapping

Use this mapping only as a default semantic bridge from the planned validation checklist to the acceptance record. It is not a hard schema; this skill should still rely on available evidence and preserve evidence gaps when data is missing.

| 109 PRV dimension | Default 110 acceptance dimension |
|---|---|
| `D1_functional` | `functional` |
| `D2_data_integrity` | `functional` + `technical` |
| `D3_performance` | `technical` |
| `D4_security` | `technical` + `operational` |
| `D5_compliance` | `functional` + `operational` |
| `D6_integration` | `technical` |
| `D7_monitoring` | `operational` |
| `D8_rollback_readiness` | `operational` |

Boundary rule: this mapping helps traceability; it must not force a missing acceptance dimension to become a rejection.
