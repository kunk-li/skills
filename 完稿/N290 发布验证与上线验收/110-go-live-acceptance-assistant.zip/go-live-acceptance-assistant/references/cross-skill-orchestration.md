# Cross-skill orchestration

## Position in the release-validation node
- Upstream node inputs: acceptance criteria, release notes, and release task orchestration
- Upstream companion inside release-validation: `post-release-validation-checklist`
- Current skill: synthesize evidence and assist the go-live / GA decision
- Downstream node: ops-runtime monitoring and incident analysis

## Collaboration contract
1. `post-release-validation-checklist` defines what should be checked and when.
2. This skill records what was actually observed and how that maps to GO / CONDITIONAL GO / NO-GO / DEFERRED REVIEW.
3. Reuse `prv_id` through `linked_prv_ids[]` or `prv_results[]` references.
4. New observations that were not planned must remain visible as additional release-outcome facts.
5. Decision output must be traceable enough for later ops-runtime/postmortem analysis.

## Minimum handoff fields
- `prv_id`
- `time_window`
- `status`
- `evidence`
- `linked_alerts_or_incidents`
- `conditions`
- `recommendation`
- `follow_up_items`

## Shared structure
Use `references/release-outcome-contract.md` as the shared data structure for release-validation outputs.

## Workflow v2 orchestration additions

- `post-release-validation-checklist` remains the atomic planner.
- `go-live-acceptance-assistant` remains the atomic synthesizer.
- Do not require a new ChatGPT skill for release-validation packaging. Prefer a host workflow, CI job, node README, or external runbook to package both outputs; neither atomic skill should absorb the other.
- Use stable `prv_id` values as the main join key.
- Use `reactive_handoff` for deployment/rollout/infra/reporting-style subscribers.
- Route formal gate, signoff, rollback, and incident actions to incident-response/infra/notifications as handoff hints, not executed commands.

## Default PRV to acceptance dimension mapping

Use this mapping only as a default semantic bridge from the planned validation checklist to the acceptance record. It is not a hard schema; this skill should still rely on available evidence and preserve evidence gaps when data is missing.

| 109 PRV dimension | Default 110 acceptance dimension |
|---|---|
| `D1_functional` | `functional` |
| `D2_data_integrity` | `functional` + `technical` |
| `D3_performance` | `technical` |
| `D4_security` | `technical` + `operational` |
| `D5_compliance` | `functional` + `operational` |
| `D6_integration` | `technical` |
| `D7_monitoring` | `operational` |
| `D8_rollback_readiness` | `operational` |

Boundary rule: this mapping helps traceability; it must not force a missing acceptance dimension to become a rejection.


---

## Boundary comparison table — go-live vs post-release-validation vs release-risk

| Dimension | go-live-acceptance-assistant | post-release-validation-checklist | release-risk-assessment | on-call-response-recommendation |
|---|---|---|---|---|
| **Primary question** | "Did we PASS? GO or NO-GO?" | "What must we check AFTER deploy?" | "Should we deploy AT ALL?" | "What do responders do RIGHT NOW?" |
| **Timing** | After PRV results are collected | Immediately after deploy (T+0 onward) | Before deploy (pre-flight gate) | During active incident |
| **Output type** | GA decision record: GO/NO-GO/CONDITIONAL_GO + sign-off tracking | PRV item list with pass/fail results | Risk register with go/no-go recommendation | Response sequence with timed steps |
| **Owns** | GA decision authority, criteria evaluation, sign-off consolidation | PRV item design, validation execution, result recording | Risk scoring, composite score, circuit breaker | Incident command, triage steps, escalation |
| **Does not own** | PRV item design (→109), risk assessment (→101), incident response (→120) | GA decision (→110), pre-deploy risk (→101) | Post-deploy validation (→109/110) | GA decision (→110) |

### Routing decision tree
```
"Did we PASS acceptance? Should we declare GA?"  → go-live-acceptance-assistant ✓
"What to validate after deploy?"                  → post-release-validation-checklist
"Should we have deployed at all?"                 → release-risk-assessment [too late if post-deploy]
"We have an active incident — what now?"          → on-call-response-recommendation
"Something failed in PRV — what do we do?"       → on-call-response-recommendation → remediation

Canonical sequence: 109 designs PRV → 109 records results → 110 evaluates → 110 issues GO/NO-GO
```

### Hard ownership rules
- **110 MUST NOT**: design PRV items → that is 109's job
- **110 MUST NOT**: make risk assessments → that is 101's job
- **110 MUST**: receive PRV results as input from 109 before issuing GO
- **110 MUST**: set `recommendation: DEFERRED_REVIEW` when no PRV results provided

---

## Routing decision tree
```
User question →
  "Did we PASS acceptance? GO or NO-GO?" → go-live-acceptance-assistant ✓ YOU ARE HERE
  "What should we validate AFTER deploy?" → post-release-validation-checklist
  "What happened at runtime?" → ops-runtime skills
  "Was there an incident?" → incident-response skills

Key rule: 109 designs the validation plan → 110 evaluates the outcomes.
          Never combine planning and decision in one skill call.
```

---

## Boundary comparison table — go-live complete

| Dimension | go-live-acceptance-assistant | post-release-validation-checklist | release-risk-assessment | on-call-response-recommendation |
|---|---|---|---|---|
| **Primary question** | "GO or NO-GO? Is this release accepted?" | "What to CHECK after deploy?" | "Should we deploy AT ALL?" | "Incident during GA — what NOW?" |
| **Timing** | After PRV results collected (T+0 to T+GA) | Immediately after deploy (T+0 onward) | Before deploy (pre-flight gate) | During active incident |
| **Output type** | GA decision record: GO/NO-GO/CONDITIONAL_GO + sign-offs | PRV item list with checkpoint times and pass/fail | Risk register with composite score | Response sequence with timed steps |
| **Owns** | GA decision authority, criteria evaluation, sign-off consolidation, consumer notification gate | PRV item design, pass/fail criteria, execution monitoring | Risk scoring, circuit breaker | Incident command, triage, escalation |
| **Does not own** | PRV item design (→109), risk assessment (→101), incident response (→120) | GA decision (→110), pre-deploy readiness (→103) | Post-deploy validation (→109/110) | GA decision (→110) |

### Routing rules
```
"Did we pass? Should we declare GA?"     → 110 ✓
"What to validate after deploy?"          → 109
"Should we have deployed at all?"         → 101 (too late if post-deploy)
"Something failed in PRV"                 → 120 (incident) → 121 (remediation)
"Breaking changes need consumer notice?"  → 110 checks consumer_impact_assessment
```

