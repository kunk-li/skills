# V2 comprehensive reference without boundary creep

Use the complete release-validation v2 acceptance model as a reference library, not as a mandatory schema.

## Keep inside this skill

- Evidence-backed release outcome synthesis
- Hard versus soft requirement evaluation
- Advisory GO / CONDITIONAL_GO / NO_GO / DEFERRED_REVIEW recommendation
- Acceptance dimension summaries when evidence exists
- Pending signoff and follow-up tracking

## Keep outside this skill

- Formal gate decisions
- Enterprise signoff order or authorization matrix
- Legal acceptance declaration
- Acceptance invalidation authority
- Incident response execution
- Portfolio, billing, or contract milestone closure

## Adaptive acceptance dimensions

Evaluate these dimensions when evidence exists:

- functional acceptance
- technical acceptance
- business acceptance
- operational acceptance

If a dimension has no evidence, mark it as `evidence_gap`, `not_applicable_for_scenario`, or `pending_input`; do not reject the artifact.

## Formal declaration handling

A formal declaration may be drafted only when the user provides explicit signoff evidence and asks for drafting support. Otherwise keep the output as decision support and mark formal acceptance as pending.
