# go-live-acceptance-assistant — feedback loop protocol

## Retrospective integration
After each release, compare GA decision vs actual post-release outcome.

### Signal types and actions
| Signal | Trigger | Action |
|---|---|---|
| `false_positive` | CONDITIONAL_GO issued; release caused incident | Review condition design; tighten PRV requirements |
| `false_negative` | NO_GO issued; conditions were actually cleared | Review evidence threshold; calibrate PRV pass criteria |
| `premature_go` | GO issued before all P0 PRV confirmed | Tighten P0 gate enforcement in SCR |
| `correct` | GA decision matched actual outcome | Add to real-examples.md as calibration |

## feedback_signal_candidates schema
```yaml
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: correct | false_positive | false_negative | premature_go
    prv_result_ref: "PRV-001 result"
    ga_recommendation: GO | NO_GO | CONDITIONAL_GO
    verification_method: "Compare post-release SLO data to PRV pass_criteria"
    calibration_action: "If false_positive: add SLO probe to P0 PRV items"
    priority: P1
    status: pending
```

## Version bump triggers
- 3+ `premature_go` within 90 days → patch; tighten P0 gate SCR
- New deployment type → minor; add mode
- decision schema change → major; migration guide


---

## Feedback loop — advanced integration (v2)

### Signal-type differentiated handling

| Signal type | Immediate action | Update target |
|---|---|---|
| `false_positive` | Mark in real-examples; review confidence rules | Add calibration note to relevant SCR rule |
| `false_negative` | Document missed signal source in failure-modes.md | Add new scenario to real-examples.md |
| `missed_evidence` | Add new input tier or degradation rule | Update large-input handling thresholds |
| `wrong_confidence` | Update relevant field contract confidence rule | Review confidence_ceiling_rule |
| `slow_resolution` | Simplify the section that caused delay | Consider adding a fast-track mode |
| `correct` | Add as green-path calibration example | No version bump required |

### Postmortem auto-mapping rule
When a postmortem references an artifact from this skill:

```yaml
postmortem_integration:
  trigger: "postmortem references artifact_id from this skill"
  auto_actions:
    - action: classify_feedback_signals
      source: "postmortem.outcome vs artifact.recommendation"
      output: "feedback_signal_candidates[] with verified signal_type"
    - action: update_real_examples
      condition: "signal_type in [false_negative, correct]"
    - action: open_scr_review
      condition: "signal_type in [false_positive, wrong_confidence]"
```

### Retrospective YAML flow
```yaml
retrospective_flow:
  step_1: "Retrieve artifact from this skill for the completed release/incident"
  step_2: "Compare recommendation vs actual outcome"
  step_3:
    if_false_negative: "Add new real-examples.md scenario; file patch bump ticket"
    if_correct: "Add calibration example to real-examples.md"
    if_false_positive: "Review SCR confidence rules"
  step_4: "Mark feedback_signal_candidates[].status: verified | deferred"
```
