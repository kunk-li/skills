# failure-modes — release-validation

Common failure modes across release-validation post-release validation and acceptance skills.

## FM01: No PRV execution results available
- **Symptom:** `post-release-validation-checklist` items defined but not executed before `go-live-acceptance-assistant` is invoked.
- **Impact:** `go-live-acceptance-assistant` cannot issue GO — only DEFERRED_REVIEW.
- **Handling:** `go-live-acceptance-assistant` sets `ga_decision: DEFERRED_REVIEW`. List unexecuted P0 PRV items in `blockers_and_conditions`. Do not invent pass outcomes.

## FM02: All PRV results are passive_observation only
- **Symptom:** No active probes, synthetic monitors, or human confirmations executed.
- **Impact:** Cannot confirm production health from passive signals alone.
- **Handling:** Set `ga_decision: DEFERRED_REVIEW`. Require at least 1 P0 active_probe before issuing GO or CONDITIONAL_GO.

## FM03: Missing baseline for quantitative pass criteria
- **Symptom:** PRV items reference metric thresholds but no baseline data is available.
- **Impact:** Pass/fail criteria cannot be evaluated objectively.
- **Handling:** Mark affected PRV items as `contract_confidence: inferred`. Emit `baseline_required: true` in `downstream_handoff`. Do not reject the artifact — downgrade readiness instead.

## FM04: Signoff evidence absent
- **Symptom:** Required role-based signoffs (PM, SRE, Tech Lead) not provided.
- **Impact:** `ga_decision: CONDITIONAL_GO` cannot be elevated to GO.
- **Handling:** List missing signoffs in `blockers_and_conditions`. Keep `signoff_evidence.status: pending`. Never fabricate signoff.

## FM05: PRV partial completion — weighted coverage < 100% P0
- **Symptom:** Some P0 PRV items not executed before acceptance is requested.
- **Impact:** GO decision cannot be issued while mandatory P0 items are incomplete.
- **Handling:** Set `ga_decision: CONDITIONAL_GO` at best if some P0 pass. List missing P0 items explicitly. `go-live-acceptance-assistant` must consume `weighted_completion.P0_executed` from `post-release-validation-checklist` handoff.

## FM06: Circuit breaker triggered
- **Symptom:** release-validation skill re-invoked ≥3 times without resolving readiness.
- **Impact:** Further re-invocation will not resolve missing PRV results.
- **Handling:** Stop regeneration. Emit `readiness: red`. Require new PRV execution evidence before re-invoking. Escalate to release-manager.


---

## Degradation examples

### readiness: red — NO_GO: P0 PRV critical failure

```yaml
metadata:
  readiness: red
ga_decision_view:
  recommendation: NO_GO
  p0_failed: 1
  p0_failed_items:
    - prv_id: PRV-003
      description: "Checkout conversion regression: -38.2%"
      severity: critical
      fail_action: block_ga
signoff_evidence_summary:
  - role: release-manager
    status: blocked
    blocked_reason: "Cannot sign NO_GO — must initiate rollback"
consumer_impact_assessment:
  breaking_changes_present: false
  consumer_notification_required: false
downstream_handoff:
  handoffs:
    - target: rollback-plan-generation
      handoff_type: action_hint
      urgency: immediate
      blocking: true
      summary: "NO_GO: initiate Phase 1 rollback immediately"
    - target: on-call-response-recommendation
      handoff_type: routing
      urgency: immediate
      summary: "GA failure — active incident declared"
self_check:
  passed: false
  failed_rules:
    - "SCR-GOLIVEAC-051: P0 PRV failed → recommendation must be NO_GO"
    - "SCR-GOLIVEAC-052: GO prohibited without PRV results — precondition not met"
```