# 上线验收记录 常见失败模式

## F1: 把观察写成结论
症状：直接写“问题由配置错误导致”，但证据只支持“怀疑”。
修正：结论降级为 `candidate_explanations`，并保留 `confidence`。

## F2: 原计划项与新增项混写
症状：所有问题都堆在一起，无法判断哪些来自原 PRV。
修正：原计划项走 `linked_prv_ids[]`，新增问题走 `additional_observations[]`。

## F3: gate 输入越界成 gate 决策
症状：在验收记录里直接写“决定继续全量发布”。
修正：只整理 `decision_inputs[]` 和证据，把最终决策留给负责人。

## F4: 按时间写流水账，缺结构
症状：整篇都是 prose，没有阶段、blocker 和风险分组。
修正：强制按 `checkpoint_id` 组织，必要时再加专题节。

## F5: blocker 只有状态没有证据
症状：只写“已修复”。
修正：补修复动作、验证结果和证据来源。

## F6: 把 RCA 塞进汇总 skill
症状：开始深挖根因链路和长期修复方案。
修正：保持在汇总、归类、handoff 边界内。

## F7: formal acceptance is fabricated
Symptom: The output includes signed acceptance, legal declaration, or final gate closure without explicit evidence.
Fix: Keep formal acceptance pending and provide decision support only.

## F8: enterprise governance is invented
Symptom: The output invents signoff order, invalidation authority, or contract/billing closure rules.
Fix: Summarize only policies or approvals provided by the user; otherwise route gaps to N350/N380 handoff.
