# output-template

This template defines the minimum required structure for `上线验收记录.md`.

## Metadata block
```yaml
metadata:
  selected_mode: dashboard_mode | auto_decision_mode | audit_mode
  acceptance_scenario: standard_release | hotfix | canary_or_feature_flag | partial_deployment | post_incident_validation | unknown
  readiness: green | amber | red | partial
  skill_contract_version: 2.1.1
  artifact_schema_name: N290GoLiveAcceptanceRecord
  artifact_schema_version: 2.1.1
  function_bias: go_live_acceptance_synthesis_and_ga_decision_support
  stage_position: release_and_delivery.release_validation.go_live_acceptance
  workflow_node: release-validation
  node_artifact_target: 上线验收记录.md
  evidence_profile: {}
  tool_collaboration_mode: standalone | composed
```

## release_outcome block
```yaml
release_outcome:
  release_id: string
  prv_results: []        # list of PRV execution results from post-release-validation-checklist
  metrics_snapshot: {}   # key SLO/KPI values at acceptance time
  incidents: []          # any incidents during the observation window
  defects_found: []      # defects surfaced post-deploy
  risks_materialized: [] # pre-identified risks that occurred
  ga_decision: GO | CONDITIONAL_GO | NO_GO | DEFERRED_REVIEW
```

## ga_decision_view block
```yaml
ga_decision_view:
  recommendation: GO | CONDITIONAL_GO | NO_GO | DEFERRED_REVIEW
  reasoning: string      # explicit rationale citing evidence_refs
  conditions: []         # for CONDITIONAL_GO only
  unresolved_hard_requirements: []  # for NO_GO / DEFERRED_REVIEW
```

## ga_criteria_evaluation block
```yaml
ga_criteria_evaluation:
  hard_requirements:
    - criterion_id: string
      description: string
      status: pass | fail | not_evaluated
      evidence_refs: []
  soft_requirements:
    - criterion_id: string
      description: string
      status: pass | fail | advisory
```

## self_check block
```yaml
self_check:
  passed: true | false
  failed_rules: []
  quality_check_failures: []
```


---

## Downstream handoff YAML templates

### 正常路径: GO → release-task-orchestration post-deploy tracking
```yaml
downstream_handoff:
  produced_by: go-live-acceptance-assistant
  artifact: GA决策记录.md
  emit_event:
    event_name: produced.release-validation.go_live_acceptance.v2
  handoffs:
    - target: post-release-validation-checklist
      handoff_type: evidence
      summary: "GA decision: GO. All P0 PRV passed. Conditions: SLO monitoring 30min."
      required_fields:
        - ga_decision_view.recommendation
        - ga_decision_view.conditions
        - signoff_evidence_summary
      confidence: high
      next_best_checks:
        - "109: close remaining P1 PRV items per post_ga_tracking"
    - target: release-task-orchestration
      handoff_type: action_hint
      summary: "GO issued — proceed with post-deploy stabilization tasks"
      confidence: high
  refresh_triggers:
    - skill: post-release-validation-checklist
      reason: "GO conditions status changed — 109 should update P1 items"
      condition: "go-live condition status changes from pending to verified"
```

### 阻断路径: NO_GO → rollback + incident
```yaml
downstream_handoff:
  handoffs:
    - target: rollback-plan-generation
      handoff_type: action_hint
      summary: "NO_GO issued — initiate rollback per pre-approved plan"
      urgency: immediate
      blocking: true
    - target: on-call-response-recommendation
      handoff_type: routing
      summary: "GA failed — active incident response required"
      urgency: immediate
```


---

## Standalone guarantee
This skill runs independently with only a deployment event and release identity. Do not refuse output because PRV results or metrics are missing.

### Standalone minimum → DEFERRED_REVIEW
When only deployment evidence is available:
- Set `readiness: partial`, `ga_decision: DEFERRED_REVIEW`
- Populate all required sections; use `not_available` for missing metrics
- List every missing evidence item in `downstream_handoff.missing_evidence`
- Set `self_check.passed: false` with rule `"No PRV results — DEFERRED_REVIEW only"`

### Field contract — ga_criteria_evaluation required fields

| Field | Required | Values / notes |
|---|---|---|
| `prv_results[]` | yes | empty array `[]` if none; never omit |
| `metrics_snapshot` | yes | `not_available` if absent; never omit |
| `incidents[]` | yes | empty array `[]` if none |
| `ga_decision` | yes | `GO` / `CONDITIONAL_GO` / `NO_GO` / `DEFERRED_REVIEW` |
| `recommendation` | yes | must match `ga_decision` |
| `reasoning` | yes | explicit rationale referencing evidence |
| `conditions[]` | if CONDITIONAL_GO | each condition needs owner + due timestamp |
| `failed_hard_requirements[]` | if NO_GO | each item needs prv_id + failure_detail |

### Decision rules (enforced in self_check)
| Condition | Forced decision |
|---|---|
| Any P0 PRV = FAIL | `NO_GO` — non-negotiable |
| All P0 PRV = PASS, P1 pending or soft gaps | `CONDITIONAL_GO` |
| All P0+P1 PRV = PASS, observation closed, all sign-offs | `GO` |
| No PRV results available | `DEFERRED_REVIEW` |
| Only passive_observation evidence, no active probes | `DEFERRED_REVIEW` |

---

## Output completeness rule
Every go-live artifact MUST include:
- `ga_decision_view.recommendation` ∈ valid enum
- `signoff_evidence_summary[]` with ≥ 1 role
- `consumer_impact_assessment` present (may have `breaking_changes_present: false`)
- `downstream_handoff` typed to ≥ 1 target
- `feedback_signal_candidates` ≥ 1 entry
- `adversarial_detection` with `injection_attempt_detected`

---

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `dashboard_mode`
- `auto_decision_mode`
- `audit_mode`

`auto_decision_mode` means auto-generated decision support, not an automatic final decision.

Also declare `acceptance_scenario` when known:
- `standard_release`
- `hotfix`
- `canary_or_feature_flag`
- `partial_deployment`
- `post_incident_validation`
- `unknown`

Scenario rules are adaptive. Missing dimensions or missing signoffs should become evidence gaps, pending items, or `DEFERRED_REVIEW`; do not reject the artifact solely because a full enterprise checklist is unavailable.

---

## Downstream handoff YAML

### 正常 GO 路径
```yaml
downstream_handoff:
  produced_by: go-live-acceptance-assistant
  artifact: 上线验收记录.md
  emit_event:
    event_name: produced.release-validation.go_live_acceptance.v2
  handoffs:
    - target: post-release-validation-checklist
      handoff_type: evidence
      summary: "GA: GO. All P0 passed. Conditions: SLO monitor 30min."
      required_fields: [ga_decision_view.recommendation, conditions, signoff_evidence_summary]
      confidence: high
      next_best_checks:
        - "109: close remaining P1 PRV items per post_ga_tracking"
    - target: release-task-orchestration
      handoff_type: action_hint
      summary: "GO issued — proceed to post-deploy stabilization (P5)"
      confidence: high
  refresh_triggers:
    - skill: post-release-validation-checklist
      reason: "GO conditions changed — 109 should update P1 tracking"
      condition: "condition status changed from pending to verified"
```

### NO-GO 路径
```yaml
downstream_handoff:
  handoffs:
    - target: rollback-plan-generation
      handoff_type: action_hint
      urgency: immediate
      summary: "NO-GO — execute rollback per pre-approved plan"
      blocking: true
    - target: on-call-response-recommendation
      handoff_type: routing
      urgency: immediate
      summary: "GA failed — active incident response required"
```



---

## Downstream handoff — refresh_triggers extended

### 完整 refresh_triggers 规则
```yaml
downstream_handoff_refresh_rules:
  to_post_release_validation:
    refresh_triggers:
      - reason: "GA conditions changed — PRV must track new requirements"
        condition: "CONDITIONAL_GO conditions list updated"
        action: "109 must add PRV items for new conditions"
      - reason: "NO_GO issued — rollback PRV tracking needed"
        condition: "recommendation changes to NO_GO"
        action: "109 must switch to rollback-tracking mode"
  to_release_task_orchestration:
    refresh_triggers:
      - reason: "CONDITIONAL_GO extended — stabilization phase prolonged"
        condition: "CONDITIONAL_GO deadline extended"
        action: "108 P5_stabilize phase must extend monitoring window"
  to_rollback_plan_generation:
    refresh_triggers:
      - reason: "NO_GO confirmed — execute pre-approved rollback"
        condition: "recommendation = NO_GO"
        action: "105 Phase 1 must be executed immediately"
        urgency: immediate
```



---

## Downstream handoff

### GO 路径
```yaml
downstream_handoff:
  produced_by: go-live-acceptance-assistant
  artifact: 上线验收记录.md
  emit_event:
    event_name: produced.release-validation.ga_decision.v2
  handoffs:
    - target: post-release-validation-checklist
      handoff_type: action_hint
      summary: "GO issued. Continue regression_watch mode for 48h. P1 conditions tracked."
      required_fields: [ga_decision_view.recommendation, conditions, metadata.version]
      confidence: high
      next_best_checks:
        - "109: switch to regression_watch mode; monitor for 48h"
    - target: release-task-orchestration
      handoff_type: action_hint
      summary: "GO — proceed with P5 stabilization tasks"
      confidence: high
  refresh_triggers:
    - skill: post-release-validation-checklist
      reason: "GO conditions changed — 109 should update tracking"
      condition: "condition status changes from pending to resolved"
    - skill: release-task-orchestration
      reason: "GA decision issued — P5 tasks can be triggered"
      condition: "recommendation changes from CONDITIONAL_GO to GO"
```

### NO_GO 路径
```yaml
downstream_handoff:
  handoffs:
    - target: rollback-plan-generation
      handoff_type: action_hint
      urgency: immediate
      blocking: true
      summary: "NO_GO — execute rollback Phase 1 immediately"
    - target: on-call-response-recommendation
      handoff_type: routing
      urgency: immediate
      summary: "GA failure — active incident declared"
```
