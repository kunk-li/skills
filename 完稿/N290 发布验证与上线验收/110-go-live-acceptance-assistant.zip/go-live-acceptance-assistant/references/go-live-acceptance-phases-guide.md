# Go-live acceptance phases guide

Suggested checkpoints:
- `t_plus_0m`: first deploy confirmation and immediate core-path checks
- `t_plus_15m`: short stabilization window after traffic cutover
- `t_plus_1h`: first quantitative metric comparison window
- `t_plus_24h`: first full-cycle validation
- `t_plus_7d`: weekly behavior and long-tail issue review
- `t_plus_28d`: go-live acceptance horizon and GA decision point

Use the nearest relevant checkpoints, but keep the sequence explicit.

## Scenario-adaptive phase handling

`t_plus_30d` is the preferred long-horizon acceptance point. Read `t_plus_28d` as a compatible alias when older artifacts use it.

Do not require every scenario to use every checkpoint. Use the nearest relevant checkpoints and preserve gaps for unfinished observation periods.
