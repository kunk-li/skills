## Mock input fixture

```yaml
mock_input:
  source: "deployment_event_only"
  content: "release_id: payment-service-v2.1.3, deployed_at: 2026-05-20T14:00:00Z"
  expected_output_shape:
    ga_decision_view:
      recommendation: DEFERRED_REVIEW
    blockers_and_conditions:
      min_entries: 1
    self_check:
      passed: false
      failed_rules: ["No PRV results — DEFERRED_REVIEW only"]
```
