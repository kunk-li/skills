# real-examples

These examples illustrate how to produce the `上线验收记录.md` artifact under different evidence and deployment conditions. Use as output calibration references — not as verbatim templates.

---

## Example 1: Minimum standalone — deploy event only, DEFERRED_REVIEW

**Scenario:** Only a deployment timestamp and service name are available. No PRV results yet.

**Input given:**
- release_id: `payment-service-v2.1.3`
- deployed_at: `2026-05-20T14:00:00Z`
- target_env: production
- No PRV results, no metrics snapshot

**Expected output shape:**
```yaml
metadata:
  selected_mode: dashboard_mode
  acceptance_scenario: standard_release
  readiness: partial
  skill_contract_version: 2.1.1
  workflow_node: release-validation
  node_artifact_target: 上线验收记录.md
  evidence_profile:
    confirmed: [deployment_event]
    missing_evidence: [prv_results, metrics_snapshot, signoff_roster]
release_outcome:
  release_id: payment-service-v2.1.3
  deployed_at: "2026-05-20T14:00:00Z"
  prv_results: []
  metrics_snapshot: not_available
  incidents: []
  ga_decision: DEFERRED_REVIEW
ga_decision_view:
  recommendation: DEFERRED_REVIEW
  reasoning: "No PRV execution results available. Dashboard assembled from deployment event only. GO decision requires at least P0 PRV pass confirmation."
  unresolved_hard_requirements:
    - "P0 active probe not executed"
    - "SLO burn rate unconfirmed"
    - "No signoff evidence"
blockers_and_conditions:
  - blocker_id: BC-001
    description: "No PRV results — cannot issue GO or CONDITIONAL_GO"
    severity: critical
    resolution: "Execute post-release-validation-checklist (109) P0 items, then re-invoke 110"
downstream_handoff:
  to_skill: post-release-validation-checklist
  missing_evidence: [prv_results, metrics_snapshot]
  next_best_checks:
    - "Run PRV-001 (smoke test) and PRV-002 (SLO probe) immediately"
    - "Provide 7-day error rate baseline for comparison"
self_check:
  passed: false
  failed_rules: ["No PRV results — DEFERRED_REVIEW only"]
```

**Key calibration:** Never invent PRV outcomes. `DEFERRED_REVIEW` is the correct decision when evidence is absent. Producing a partial artifact with clear `missing_evidence` is more useful than refusing to run.

---

## Example 2: Hotfix acceptance — all P0 passed, CONDITIONAL_GO

**Scenario:** Hotfix deployed at 02:15 UTC. P0 smoke tests passed. SRE is still in the 30-minute observation window. PM sign-off is pending.

**Input given:**
- release_id: `payment-service-hotfix-v2.1.4`
- PRV results: PRV-001 PASS, PRV-002 PASS, PRV-003 pending (observation window open)
- metrics_snapshot: error_rate 0.4%, p99 280ms, SLO burn 0.9×
- signoff: tech_lead signed, sre signed, pm pending

**Expected output shape:**
```yaml
metadata:
  selected_mode: auto_decision_mode
  acceptance_scenario: hotfix
  readiness: amber
  skill_contract_version: 2.1.1
  workflow_node: release-validation
  node_artifact_target: 上线验收记录.md
release_outcome:
  release_id: payment-service-hotfix-v2.1.4
  prv_results:
    - prv_id: PRV-001
      description: Smoke test — /health and /checkout
      prv_priority: P0
      result: PASS
      actual_value: "HTTP 200, latency 120ms"
    - prv_id: PRV-002
      description: SLO burn rate active probe
      prv_priority: P0
      result: PASS
      actual_value: "burn_rate 0.9× (threshold 2.0×)"
    - prv_id: PRV-003
      description: 30-min observation window
      prv_priority: P1
      result: in_progress
      remaining: "18 minutes"
  metrics_snapshot:
    error_rate: "0.4% (baseline 0.3%)"
    p99_latency: "280ms (baseline 260ms)"
    slo_burn_rate: "0.9×"
  ga_decision: CONDITIONAL_GO
ga_decision_view:
  recommendation: CONDITIONAL_GO
  reasoning: "P0 PRV items passed. Metrics within tolerance. Observation window 18 min remaining. PM sign-off pending."
  conditions:
    - condition_id: COND-001
      description: "Monitor error rate for remaining 18 minutes. Rollback if rate exceeds 1%."
      owner: sre-oncall
      due: "2026-05-20T02:45:00Z"
      auto_escalate_if_missed: true
    - condition_id: COND-002
      description: "PM sign-off required before declaring full GO."
      owner: pm-team
      due: "2026-05-20T03:00:00Z"
signoff_evidence_summary:
  tech_lead: {status: signed, timestamp: "2026-05-20T02:20:00Z"}
  sre: {status: signed, timestamp: "2026-05-20T02:22:00Z"}
  pm: {status: pending, owner_placeholder: "pm-team"}
post_ga_tracking:
  follow_up_items:
    - item: "Confirm PM sign-off"
      owner: pm-team
      due: "2026-05-20T03:00:00Z"
    - item: "Close PRV-003 observation window result"
      owner: sre-oncall
      due: "2026-05-20T02:45:00Z"
self_check:
  passed: true
  warnings: ["PM sign-off pending", "Observation window still open"]
```

**Key calibration:** `CONDITIONAL_GO` is correct when P0 items pass but soft requirements (observation window, signoff) remain open. Conditions must have concrete owners and due timestamps.

---

## Example 3: Full evidence — standard release, full GO

**Scenario:** Standard release with all PRV items executed, full observation window closed, all sign-offs obtained.

**Input given:**
- 5 PRV items all PASS (P0×2, P1×2, P2×1)
- error_rate 0.18% (vs baseline 0.20%), p99 310ms (vs baseline 320ms)
- No incidents during 60-min observation window
- All role sign-offs obtained: pm, tech_lead, sre, compliance

**Expected output shape:**
```yaml
metadata:
  selected_mode: auto_decision_mode
  acceptance_scenario: standard_release
  readiness: green
  skill_contract_version: 2.1.1
ga_decision_view:
  recommendation: GO
  reasoning: "All P0 and P1 PRV items passed. Metrics improved vs baseline. 60-min observation window closed clean. All role sign-offs obtained."
  evidence_summary:
    prv_pass_rate: "5/5 (100%)"
    p0_pass_rate: "2/2 (100%)"
    observation_window: "60 min — no incidents"
    metrics_vs_baseline: "error_rate -10%, p99 -3%"
signoff_evidence_summary:
  pm: {status: signed, timestamp: "2026-05-20T15:10:00Z"}
  tech_lead: {status: signed, timestamp: "2026-05-20T15:08:00Z"}
  sre: {status: signed, timestamp: "2026-05-20T15:09:00Z"}
  compliance: {status: signed, timestamp: "2026-05-20T15:11:00Z"}
blockers_and_conditions:
  conditions_outstanding: 0
  blockers_open: 0
self_check:
  passed: true
  failed_rules: []
```

**Key calibration:** Full GO requires all P0 PRV pass + observation window closed + all required sign-offs. Metrics improvement vs baseline supports but is not required for GO.

---

## Example 4: P0 hard failure — NO_GO forced

**Scenario:** Payment checkout smoke test fails 3/3. Release must be blocked.

**Input given:**
- PRV-001: FAIL (HTTP 500 for 3/3 probe requests on /checkout)
- PRV-002: PASS
- No incidents yet (failure just detected)

**Expected output shape:**
```yaml
metadata:
  selected_mode: auto_decision_mode
  acceptance_scenario: standard_release
  readiness: red
  skill_contract_version: 2.1.1
ga_decision_view:
  recommendation: NO_GO
  reasoning: "P0 hard requirement failed: PRV-001 smoke test returned HTTP 500 for all 3 probes. Checkout flow is broken."
  failed_hard_requirements:
    - prv_id: PRV-001
      prv_priority: P0
      requirement: mandatory
      result: FAIL
      failure_detail: "payment-service /checkout HTTP 500, 3/3 probe attempts"
      linked_service: payment-service
blockers_and_conditions:
  - blocker_id: BC-NOGO-001
    description: "P0 PRV-001 failed — checkout broken"
    severity: critical
    resolution: "Fix payment-service error. Re-execute PRV-001 before reconsidering GO."
reactive_handoff:
  exception_event:
    event_name: exception.release-validation.go_live_blocked.v2
    trigger_reason: p0_prv_failure
    subscribers: [incident-response, notifications, release-manager]
downstream_handoff:
  to_skill: on-call-response-recommendation
  urgency: immediate
  context: "P0 PRV failure. Checkout broken. Initiate incident response."
self_check:
  passed: false
  failed_rules: ["P0 hard requirement PRV-001 failed — NO_GO forced"]
```

**Key calibration:** NO_GO on P0 failure is non-negotiable. `reactive_handoff.exception_event` must be emitted to trigger incident response. Never soften a P0 failure to CONDITIONAL_GO regardless of other passing items.

---

## Example 5: Canary acceptance — feature flag at 10% traffic, partial evidence

**Scenario:** Canary at 10% traffic for 20 minutes. Metrics look stable but observation window is only half complete. No full sign-off yet.

**Input given:**
- canary_traffic_pct: 10%
- error_rate canary: 0.22% (baseline 0.20%) — within 20% tolerance
- p99 canary: 290ms (baseline 280ms) — within 10% tolerance
- observation_elapsed: 20min (target 40min)
- PRV-001 (smoke): PASS; PRV-003 (observation window): in_progress

**Expected output shape:**
```yaml
metadata:
  selected_mode: auto_decision_mode
  acceptance_scenario: canary_or_feature_flag
  readiness: amber
  skill_contract_version: 2.1.1
release_outcome:
  ga_decision: CONDITIONAL_GO
  canary_state:
    traffic_pct: 10
    observation_elapsed_min: 20
    observation_target_min: 40
    remaining_min: 20
ga_decision_view:
  recommendation: CONDITIONAL_GO
  reasoning: "Canary at 10% traffic. Metrics within tolerance. Observation window 50% complete (20/40 min). Promotion to next stage conditional on window close."
  conditions:
    - condition_id: COND-CANARY-001
      description: "Complete 40-min observation window. Promote to 25% only if error_rate stays < 0.5%."
      owner: sre-oncall
      due: "T+20min"
      auto_halt_threshold: "error_rate > 0.5% OR p99 > 400ms"
  promotion_gate:
    next_stage_traffic_pct: 25
    gate_criteria: "error_rate < 0.5% AND p99 < 350ms AND no P0 incidents"
self_check:
  passed: true
  warnings: ["Observation window still open — do not promote until T+20min"]
```

**Key calibration:** Canary scenario uses `CONDITIONAL_GO` with explicit `promotion_gate` and `auto_halt_threshold`. Never issue full GO during an open canary observation window.

---

## Example 6: audit_mode — post-incident release re-validation

**Scenario:** Release was rolled back due to incident. After fix, re-running acceptance in `audit_mode` for compliance evidence.

**Input given:**
- Original incident: INC-001 (payment timeout, resolved T+45min)
- Rollback executed at T+30min
- Re-deploy completed T+2h
- All P0 PRVs now pass on re-deploy
- Audit trail requires full documentation of original failure + re-validation

**Expected output shape:**
```yaml
metadata:
  selected_mode: audit_mode
  acceptance_scenario: post_incident_validation
  readiness: green
  skill_contract_version: 2.1.1
  iter_count: 2
release_outcome:
  release_id: payment-service-v2.1.3-revalidation
  incident_history:
    - incident_id: INC-001
      severity: P1
      description: "Payment timeout at 10% canary traffic"
      resolution: rollback_executed
      resolved_at: "T+45min"
      root_cause_ref: "root-cause-analysis-recommendation output RCA-001"
  ga_decision: GO
ga_decision_view:
  recommendation: GO
  reasoning: "Post-incident re-validation complete. All P0 PRVs pass on re-deploy. RCA confirmed root cause resolved. Audit trail preserved."
  audit_evidence_refs:
    - ref: INC-001
      type: incident_record
    - ref: RCA-001
      type: root_cause_analysis
    - ref: RollbackRecord-v2.1.3
      type: rollback_execution_record
compliance_notes:
  iter_count: 2
  original_failure_documented: true
  rollback_executed: true
  re_validation_completed: true
  audit_trail_complete: true
self_check:
  passed: true
  failed_rules: []
  audit_mode_confirmed: true
```

**Key calibration:** `audit_mode` must preserve `incident_history`, `iter_count`, and full `audit_evidence_refs`. A second-attempt GO after rollback is valid and should be documented, not hidden.


---

## Scenario calibration
See `references/real-examples.md` for six annotated scenarios:
1. **Minimum standalone** — deploy event only → DEFERRED_REVIEW
2. **Hotfix CONDITIONAL_GO** — P0 pass, observation window open, PM pending
3. **Full GO** — all evidence complete, all sign-offs obtained
4. **NO_GO** — P0 hard failure forces block + incident escalation
5. **Canary CONDITIONAL_GO** — 10% traffic, window half-complete, promotion gate defined
6. **audit_mode post-incident** — re-validation after rollback with full audit trail

For GA decision criteria definitions, see `references/ga-decision-criteria.md`.
For field naming contract (shared + skill-specific), see `references/field-contract.md`.
For readiness inheritance from 109 to 110, see `references/readiness-inheritance.md`.
For reactive handoff event envelopes, see `references/reactive-integration.md`.

---

## Output examples by mode

### dashboard_mode — minimal evidence, DEFERRED_REVIEW
```yaml
metadata:
  selected_mode: dashboard_mode
  acceptance_scenario: standard_release
  readiness: partial
  skill_contract_version: 2.1.1
  workflow_node: release-validation
  node_artifact_target: 上线验收记录.md
release_outcome:
  ga_decision: DEFERRED_REVIEW
ga_decision_view:
  recommendation: DEFERRED_REVIEW
  reasoning: "PRV results not yet available. Dashboard assembled from deployment evidence only."
  unresolved_hard_requirements:
    - "P0 active probe not executed"
    - "SLO burn rate not confirmed"
blockers_and_conditions:
  - blocker_id: BC-001
    description: "No PRV execution results — GO decision requires at least P0 PRV results"
    severity: critical
self_check:
  passed: false
  failed_rules: ["No PRV results — DEFERRED_REVIEW only"]
```

### auto_decision_mode — P0 PRVs passed, CONDITIONAL_GO
```yaml
metadata:
  selected_mode: auto_decision_mode
  acceptance_scenario: hotfix
  readiness: amber
  skill_contract_version: 2.1.1
  workflow_node: release-validation
  node_artifact_target: 上线验收记录.md
release_outcome:
  ga_decision: CONDITIONAL_GO
ga_decision_view:
  recommendation: CONDITIONAL_GO
  reasoning: "P0 active probes passed. P1 SLO observation window still open."
  conditions:
    - condition_id: COND-001
      description: "Monitor error rate for 30 additional minutes. Rollback if rate exceeds 1%."
      owner: sre-team
      due: "T+30min"
blockers_and_conditions:
  conditions_outstanding: 1
self_check:
  passed: true
  failed_rules: []
```

### audit_mode — full evidence, NO_GO
```yaml
metadata:
  selected_mode: audit_mode
  acceptance_scenario: standard_release
  readiness: red
  skill_contract_version: 2.1.1
  workflow_node: release-validation
  node_artifact_target: 上线验收记录.md
release_outcome:
  ga_decision: NO_GO
ga_decision_view:
  recommendation: NO_GO
  reasoning: "Hard requirement failed: payment flow P0 smoke test returned HTTP 500."
  failed_hard_requirements:
    - prv_id: PRV-001
      requirement: mandatory
      prv_priority: P0
      result: FAIL
      failure_detail: "payment-service /checkout returned HTTP 500 for 3/3 probe requests"
blockers_and_conditions:
  - blocker_id: BC-NOGO-001
    description: "P0 hard requirement failed — payment flow broken"
    severity: critical
    resolution: "Fix payment-service error before re-running PRV-001"
self_check:
  passed: false
  failed_rules: ["P0 hard requirement failed — NO_GO forced"]
```
