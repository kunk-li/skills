# 字段命名 contract

本 skill 与 `post-release-validation-checklist` 共享一组基础字段，并在此基础上增加“阶段化验收记录”专有字段。

## 共享字段

| 字段 | 说明 |
| --- | --- |
| `id` | 当前输出中的稳定项 ID。 |
| `name` | 短标题。 |
| `object_name` | 核心对象、系统、模块或业务实体。 |
| `action_name` | 核心动作。 |
| `evidence` | 证据数组。 |
| `confidence` | `explicit / inferred / unknown`。 |
| `open_questions` | 待确认问题数组。 |

## 本 skill 的专有扩展字段

| 字段 | 说明 |
| --- | --- |
| `checkpoint_id` | 阶段检查点，如 `t_plus_0`、`gate_1`。 |
| `checkpoint_type` | `observation / gate_input / review`。 |
| `focus_area` | 当前记录聚焦的验收维度或专题。 |
| `observation_facts` | 事实数组。 |
| `linked_prv_ids` | 关联的 `PRV-xxx` 编号。 |
| `linked_risks` | 关联风险或上游风险标识。 |
| `blocker_status` | blocker 当前状态和验证摘要。 |
| `candidate_explanations` | 候选解释，不等于 RCA。 |
| `impacts` | 影响数组。 |
| `owner_placeholder` | 占位负责人。 |
| `decision_inputs` | 可供 gate 决策参考的输入，不是最终决策。 |
| `additional_observations` | 原计划外新增观察项。 |

## 兼容映射

| 旧字段 | 新字段 |
| --- | --- |
| `summary_notes` | `observation_facts` |
| `candidate_causes` | `candidate_explanations` |
| `related_checklist_ids` | `linked_prv_ids` |
| `pending_questions` | `open_questions` |

## 使用规则

- 先归一字段，再分析。
- 原计划项与新增项要分开。
- 如果输入里已经有 `PRV-xxx`，输出时不要丢失。

## Contract versioning additions

Add these top-level fields when producing release-validation-compatible outputs:

| Field | Meaning |
| --- | --- |
| `skill_contract_version` | Current contract version, `2.1.1`. |
| `artifact_contract` | Schema identity and producer metadata. |
| `reactive_handoff` | Event-like records for Workflow v2 subscribers. |
| `feedback_signal_candidates` | Observed issues that may feed feedback later. |
| `acceptance_dimension_summary` | Functional, technical, business, and operational summaries when evidence exists. |
| `signoff_evidence_summary` | Provided signoff evidence and pending gaps; never fabricated approvals. |

Keep old field mappings readable, but output the 2.1.1 fields by default.


---

## Field contract — ga_decision_view

| Field | Required | Values / notes |
|---|---|---|
| `recommendation` | yes | ∈ {GO, NO_GO, CONDITIONAL_GO, DEFERRED_REVIEW} |
| `p0_total` | yes | integer |
| `p0_passed` | yes | integer |
| `p0_failed` | yes | integer; > 0 → recommendation must be NO_GO |
| `conditions[]` | if CONDITIONAL_GO | each with `owner`, `due`, `evidence_required` |
| `failed_items[]` | if p0_failed > 0 | each with `prv_id`, `severity`, `fail_action` |