# Workflow v2 reactive integration

This skill remains an atomic acceptance-record and decision-support skill. Workflow v2 responsibilities are exposed through handoff records, not executed here.

## Artifact contract

Every output should include:

```yaml
artifact_contract:
  schema_name: N290GoLiveAcceptanceRecord
  schema_version: 2.1.1
  producer_skill: go-live-acceptance-assistant
  workflow_node: N290
  artifact_target: go_live_acceptance_record
  compatibility:
    reads_from:
      - post-release-validation-checklist
      - N270.release_preparation
      - N280.release_execution
    consumed_by:
      - N300.monitoring
      - N310.response
      - N320.postmortem
      - N350.coordination
      - N380.gate_and_human_confirmation
      - N390.audit
```

## Event envelopes

Emit event-like records in `reactive_handoff`. Do not actually publish events unless the host environment provides an event bus tool.

Recommended event names:
- `produced.N290.go_live_acceptance_record`
- `exception.N290.acceptance_evidence_gap`
- `sla.N290.signoff_pending`
- `sla.N290.followup_owner_needed`

Each event envelope should include:
- `event_name`
- `artifact_id`
- `schema_version`
- `trigger_reason`
- `subscribers_hint`
- `next_owner_placeholder`

## N005 feedback loop

Use `feedback_signal_candidates[]` for observations that should influence future requirements or PRV planning:
- recurring blocker categories
- release-attributed incidents or defects
- customer support spikes
- SLO or KPI deviations
- missing readiness evidence that repeatedly affects acceptance

Do not perform root-cause analysis or requirement mining inside this skill; hand off candidates to N300/N320/N005-compatible processing.
