# post-release-validation-checklist — feedback loop protocol

## Retrospective integration
After each release, compare PRV predictions vs actual release outcome.

### Signal types and actions
| Signal | Trigger | Action |
|---|---|---|
| `false_positive` | PRV item failed but release succeeded | Review pass_criteria threshold; calibrate |
| `false_negative` | PRV item passed but incident occurred post-release | Add new PRV item covering missed scenario |
| `wrong_confidence` | Confidence label wrong | Tighten tier ceiling rules |
| `correct` | PRV accurately predicted outcome | Add green-path example to real-examples.md |

## feedback_signal_candidates schema
```yaml
feedback_signal_candidates:
  - signal_id: FSC-001
    signal_type: false_negative
    prv_item_ref: PRV-003
    description: "PRV-003 passed but memory leak surfaced 2h post-GA"
    verification_method: "Compare PRV-003 pass_criteria to actual memory metrics at T+2h"
    calibration_action: "Extend PRV-003 checkpoint_time to T+2h; tighten threshold"
    priority: P1
    status: pending
```

## Version bump triggers
- 3+ `false_negative` for same PRV dimension → patch; tighten threshold
- New deployment type (canary, blue-green) → minor; add mode
- PRV schema field renamed → major; migration guide


---

## Feedback loop — advanced integration (v2)

### Signal-type differentiated handling

| Signal type | Immediate action | Update target |
|---|---|---|
| `false_positive` | Mark in real-examples; review confidence rules | Add calibration note to relevant SCR rule |
| `false_negative` | Document missed signal source in failure-modes.md | Add new scenario to real-examples.md |
| `missed_evidence` | Add new input tier or degradation rule | Update large-input handling thresholds |
| `wrong_confidence` | Update relevant field contract confidence rule | Review confidence_ceiling_rule |
| `slow_resolution` | Simplify the section that caused delay | Consider adding a fast-track mode |
| `correct` | Add as green-path calibration example | No version bump required |

### Postmortem auto-mapping rule
When a postmortem references an artifact from this skill:

```yaml
postmortem_integration:
  trigger: "postmortem references artifact_id from this skill"
  auto_actions:
    - action: classify_feedback_signals
      source: "postmortem.outcome vs artifact.recommendation"
      output: "feedback_signal_candidates[] with verified signal_type"
    - action: update_real_examples
      condition: "signal_type in [false_negative, correct]"
    - action: open_scr_review
      condition: "signal_type in [false_positive, wrong_confidence]"
```

### Retrospective YAML flow
```yaml
retrospective_flow:
  step_1: "Retrieve artifact from this skill for the completed release/incident"
  step_2: "Compare recommendation vs actual outcome"
  step_3:
    if_false_negative: "Add new real-examples.md scenario; file patch bump ticket"
    if_correct: "Add calibration example to real-examples.md"
    if_false_positive: "Review SCR confidence rules"
  step_4: "Mark feedback_signal_candidates[].status: verified | deferred"
```
