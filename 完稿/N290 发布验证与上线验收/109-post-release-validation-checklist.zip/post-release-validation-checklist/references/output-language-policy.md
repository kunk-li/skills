## Output language policy

### Bilingual term glossary (incident & validation context)

| English term | 中文标准译法 |
|---|---|
| incident | 故障 / 事件 |
| on-call | 值班 |
| tier | 级别 (T1=严重 / T2=重要 / T3=一般) |
| containment | 遏制 |
| escalation | 升级 |
| hotfix | 热修复 |
| rollback | 回滚 |
| go/no-go | 通过/拒绝 |
| acceptance | 验收 |
| PRV (post-release validation) | 发布后验证 |
| blast radius | 影响范围 |
| MTTR | 平均恢复时间 |
| root cause | 根因 |
| remediation | 修复 |
| postmortem | 事后复盘 |
| signoff | 签字确认 |
| observation window | 观察窗口 |
| circuit breaker | 熔断 |

### Japanese/Korean output rules
When `output_language: ja` or `ko` is set by operator:
- YAML field names: English (unchanged)
- Prose sections: Japanese or Korean respectively
- Tier labels: `T1/T2/T3` (keep numeric — universally understood)
- Time expressions: use ISO-8601 for timestamps; local time format for human-readable durations

### Incident response Chinese output example
```yaml
metadata:
  readiness: partial
  selected_mode: quick_triage
  output_language: zh-CN
tier_auto_classification:
  tier: T2
  rationale_zh: "单服务受影响，错误率 < 20%，无确认数据丢失，判定为T2级别故障"
response_sequence_zh:
  - step: 1
    action_zh: "指定事件指挥官"
    timebox: 5m
    success_criteria_zh: "事件指挥官确认承接，在Slack #incidents频道发布接管消息"
  - step: 2
    action_zh: "拉取支付服务过去2小时内的部署记录"
    timebox: 5m
downstream_handoff:
  next_best_checks_zh:
    - "如发现近期部署，启动修复方案建议（remediation-plan-recommendation）"
```
