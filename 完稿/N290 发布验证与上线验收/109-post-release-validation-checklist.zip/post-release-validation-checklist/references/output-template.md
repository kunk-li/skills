# Output template

Use a csv-friendly markdown table plus a short summary.

## Summary
- release scope
- selected mode
- readiness
- checklist size and time windows
- highest-risk P0 items

## Required tables
1. `prv_items`
2. `dimension_coverage_matrix`
3. `checkpoint_plan`
4. `on_failure_playbooks`
5. `downstream_handoff`


---

## Downstream handoff YAML templates

### 正常路径: 109 → 110 (all P0 passed)
```yaml
downstream_handoff:
  produced_by: post-release-validation-checklist
  artifact: 发布后验证清单.csv
  produced_event: produced.release-validation.prv_checklist.v2
  handoffs:
    - target: go-live-acceptance-assistant
      handoff_type: evidence
      summary: "P0 completion 100% (2/2 pass). P1 completion 75% (3/4 pass). Ready for GA decision."
      required_fields:
        - prv_items
        - weighted_completion.P0_completion_pct
        - weighted_completion.P0_total
        - weighted_completion.P0_pass
      confidence: high
      next_best_checks:
        - "110: issue GO — P0 completion 100%"
        - "110: note P1 pending item as CONDITIONAL_GO condition if required"
  refresh_triggers:
    - skill: go-live-acceptance-assistant
      reason: "PRV results updated — GA decision must re-evaluate"
      condition: "any prv_item.result changed after 110 first ran"
```

### 阻断路径: P0 FAILED → block GA
```yaml
downstream_handoff:
  handoffs:
    - target: go-live-acceptance-assistant
      handoff_type: gap
      summary: "P0 PRV-001 FAILED: smoke test error rate 4.2%. Block GA."
      blocking: true
      required_fields: [prv_id, result, fail_action, actual_value]
    - target: on-call-response-recommendation
      handoff_type: routing
      summary: "PRV failure — initiate incident response"
      urgency: immediate
```


---

## Standalone guarantee
This skill runs immediately after deployment with only a deployment timestamp and service name.

### Minimum standalone example — deploy event only
```yaml
metadata:
  readiness: partial
  selected_mode: rapid_prv
  release_scenario: standard_release
  skill_contract_version: 2.1.0
  workflow_node: release-validation
  node_artifact_target: 发布后验证清单.csv
evidence_profile:
  confirmed: [deployment_timestamp, service_name]
  missing_evidence: [acceptance_criteria, release_notes, runtime_baseline]
  missing_evidence_impact: "PRV items use conservative defaults. Pass criteria are static thresholds only."
prv_items:
  - prv_id: PRV-001
    description: "Service health probe — GET /health returns HTTP 200"
    prv_priority: P0
    validation_type: active_probe
    checkpoint_time: T+5min
    pass_criteria: "HTTP 200 within 5 seconds"
    fail_criteria: "HTTP non-200 or timeout"
    fail_action: escalate_to_oncall_immediately
    owner: sre-oncall
    result: pending
  - prv_id: PRV-002
    description: "Error rate within 2× baseline (conservative default)"
    prv_priority: P1
    validation_type: passive_observation
    checkpoint_time: T+15min
    pass_criteria: "error_rate < 2× deployment baseline (baseline unknown — use 1% static threshold)"
    fail_action: notify_release_manager
    owner: sre-oncall
    result: pending
weighted_completion:
  P0_total: 1
  P0_executed: 0
  P0_completion_pct: 0
downstream_handoff:
  to_skill: go-live-acceptance-assistant
  prv_completion_summary:
    P0_total: 1
    P0_executed: 0
  missing_evidence: [acceptance_criteria, baseline_metrics]
self_check:
  passed: true
  warnings: ["Conservative defaults — provide 验收标准.md to calibrate pass criteria"]
```

---

## Output completeness rule
Every PRV checklist artifact MUST include:
- `prv_items` ≥ 1 P0 item with numeric `pass_criteria`
- `weighted_completion` with ALL 7 fields above
- P0 FAIL → `overall_readiness: red` AND `downstream_handoff.blocking: true` to 110
- P0 FAIL → additional handoff to on-call with `urgency: immediate`
- `consumer_notification` section when `breaking_changes_present: true`
- `feedback_signal_candidates` ≥ 1 with `signal_type`

---

## Selected mode / mode selection
Every result must declare `selected_mode`, `readiness`, and `evidence_profile` at the top.

Allowed modes:
- `rapid_prv`
- `comprehensive_prv`
- `continuous_prv`

Also declare `release_scenario` when known:
- `standard_release`
- `hotfix`
- `canary_or_feature_flag`
- `partial_deployment`
- `post_incident_validation`
- `unknown`

Mode rules are adaptive. A hotfix or partial deployment may legitimately use fewer windows than a comprehensive standard release. Record coverage gaps instead of rejecting the output.

---

## Downstream handoff YAML

### P0 all pass → GO 路径
```yaml
downstream_handoff:
  produced_by: post-release-validation-checklist
  artifact: 发布后验证清单.csv
  emit_event:
    event_name: produced.release-validation.prv_checklist.v2
  handoffs:
    - target: go-live-acceptance-assistant
      handoff_type: evidence
      summary: "P0 completion: 100% (2/2 pass). P1: 75% (3/4). Ready for GA decision."
      required_fields: [prv_items, weighted_completion.P0_completion_pct]
      confidence: high
      next_best_checks:
        - "110: issue GO — P0 completion 100%"
  refresh_triggers:
    - skill: go-live-acceptance-assistant
      reason: "PRV results updated — GA decision must re-evaluate"
      condition: "any prv_item.result changed after 110 ran"
```

### P0 FAILED → 阻断 + 告警
```yaml
downstream_handoff:
  handoffs:
    - target: go-live-acceptance-assistant
      handoff_type: gap
      blocking: true
      summary: "P0 PRV-001 FAILED: smoke test error_rate 4.2%. Block GA."
    - target: on-call-response-recommendation
      handoff_type: routing
      urgency: immediate
      summary: "PRV P0 failure — incident response required"
```



---

## Downstream handoff — refresh_triggers extended

### 完整 refresh_triggers 规则
```yaml
downstream_handoff_refresh_rules:
  to_go_live_acceptance_assistant:
    refresh_triggers:
      - reason: "P0 PRV item result changed"
        condition: "any prv_item.priority=P0 result changes from pending to pass/fail"
        action: "110 must re-evaluate GA recommendation"
      - reason: "P1 item added as blocking condition"
        condition: "P1 item escalated to P0 by release manager"
        action: "110 conditions list must be updated"
      - reason: "canary stage completed — next stage PRV due"
        condition: "selected_mode=canary_prv AND stage advances"
        action: "110 must refresh per-stage verdict"
  to_on_call_response:
    refresh_triggers:
      - reason: "P0 regression detected mid-monitoring"
        condition: "regression_watch mode: metric degrades >10% for >2h"
        action: "120 incident response must be activated"
```



---

## Downstream handoff

### 全部 P0 通过 → GO
```yaml
downstream_handoff:
  produced_by: post-release-validation-checklist
  artifact: 发布后验证清单.csv
  emit_event:
    event_name: produced.release-validation.prv_checklist.v2
  handoffs:
    - target: go-live-acceptance-assistant
      handoff_type: evidence
      summary: "PRV complete: P0 3/3 pass (100%). P1 4/5 (80%). Ready for GA decision."
      required_fields: [prv_items, weighted_completion, metadata.version]
      confidence: high
      next_best_checks:
        - "110: issue GO — P0 completion 100%; P1 CHK-007 can be post-GA condition"
    - target: release-task-orchestration
      handoff_type: action_hint
      summary: "PRV passed — proceed to post-deploy stabilization (P5 tasks)"
      confidence: high
  refresh_triggers:
    - skill: go-live-acceptance-assistant
      reason: "PRV result updated — GA decision must be re-evaluated"
      condition: "any prv_item.result changes after 110 ran"
    - skill: release-task-orchestration
      reason: "PRV completion changed — P5 stabilization tasks may be triggered"
      condition: "weighted_completion.P0_completion_pct crosses 100%"
```

### P0 FAIL → 阻断
```yaml
downstream_handoff:
  handoffs:
    - target: go-live-acceptance-assistant
      handoff_type: gap
      blocking: true
      summary: "P0 PRV-003 FAIL: conversion regression -38%. Block GA immediately."
    - target: on-call-response-recommendation
      handoff_type: routing
      urgency: immediate
      summary: "PRV regression confirmed — incident response required"
```
