# Skill evolution review checklist

Use this checklist when changing this skill or its contract. It is a governance aid, not a runtime rejection template.

## Change boundary checks

- New fields must remain one of: `recommendation`, `evidence`, `placeholder`, `handoff`, or `coverage_gap`.
- Do not add rules that make incomplete evidence an all-or-nothing rejection. Preserve the artifact, lower readiness, and state the missing evidence.
- Do not add executed actions such as rollback, incident creation, paging, signoff approval, legal acceptance, or gate decision.
- Do not add workflow consumers that are outside the current workflow topology unless a node-level owner exists.
- Keep SKILL.md below 200 lines. Move details to references before expanding the control plane.

## Versioning checks

- Quality-only clarification: patch-level guidance; do not change artifact schema version unless the runtime schema changes.
- Additive output field: minor schema change after consumers are ready.
- Removed or semantically changed field: major schema change, with an alias or migration period first.
- Do not increase contract versions repeatedly before a real schema registry or validator exists.

## Anti-regression checks

- `acceptance_dimension_summary` must not become a hard four-dimension required schema.
- `reactive_handoff` must remain an event envelope unless a host event bus tool is available.
- `feedback_signal_candidates` must influence future planning through feedback; do not rewrite the current release artifact.
- Review checklist failures should create review comments and follow-up items, not automatically invalidate a valid release artifact.
