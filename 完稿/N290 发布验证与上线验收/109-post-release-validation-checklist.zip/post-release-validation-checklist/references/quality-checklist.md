# Quality checklist

Before finalizing the output:
- Confirm every P0 item is measurable or binary-verifiable.
- Confirm all 8 dimensions are represented in comprehensive mode.
- Confirm each metric-based PRV has a baseline source or an explicit missing-baseline warning.
- Confirm every PRV has a concrete owner placeholder and expected evidence.
- Confirm every failure path points to an escalation or rollback playbook.
- Confirm no item silently assumes live traffic before the time window exists.

## 2.1.0 reactive checks

- Confirm `skill_contract_version` and `artifact_contract` are present.
- Confirm `reactive_handoff` includes produced and gap events when relevant.
- Confirm `coverage_gaps` is used instead of hard rejection for incomplete evidence.
- Confirm failure actions are recommendation-only and do not execute rollback or incident creation.
- Confirm N005 feedback candidates are captured when prior incidents, defects, or customer signals influence PRV focus.
