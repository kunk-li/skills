# Workflow v2 reactive integration

This skill remains an atomic checklist-generation skill. Workflow v2 responsibilities are exposed through handoff records, not executed here.

## Artifact contract

Every output should include:

```yaml
artifact_contract:
  schema_name: N290PostReleaseValidationChecklist
  schema_version: 2.1.0
  producer_skill: post-release-validation-checklist
  workflow_node: N290
  artifact_target: post_release_validation_checklist
  compatibility:
    reads_from:
      - N270.release_preparation
      - N280.release_execution
    consumed_by:
      - go-live-acceptance-assistant
      - N300.monitoring
      - N310.response
      - N380.gate_and_human_confirmation
      - N390.audit
```

## Event envelopes

Emit event-like records in `reactive_handoff`. Do not actually publish events unless the host environment provides an event bus tool.

Recommended event names:
- `produced.N290.post_release_validation_checklist`
- `exception.N290.validation_coverage_gap`
- `sla.N290.owner_confirmation_needed`

Each event envelope should include:
- `event_name`
- `artifact_id`
- `schema_version`
- `trigger_reason`
- `subscribers_hint`
- `next_owner_placeholder`

## N005 feedback loop

Use `feedback_signal_candidates[]` to preserve signals that should improve future PRV focus:
- repeated PRV failures
- missing baselines
- recurring customer-support observations
- defect clusters or incident themes

Do not mine requirements directly in this skill; hand off candidates to N005-compatible downstream processing.
