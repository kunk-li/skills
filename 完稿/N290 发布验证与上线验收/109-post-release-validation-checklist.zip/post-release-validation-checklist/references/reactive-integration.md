# Workflow v2 reactive integration

This skill remains an atomic checklist-generation skill. Workflow v2 responsibilities are exposed through handoff records, not executed here.

## Artifact contract

Every output should include:

```yaml
artifact_contract:
  schema_name: N290PostReleaseValidationChecklist
  schema_version: 2.1.0
  producer_skill: post-release-validation-checklist
  workflow_node: release-validation
  artifact_target: post_release_validation_checklist
  compatibility:
    reads_from:
      - release-prep.release_preparation
      - release-exec.release_execution
    consumed_by:
      - go-live-acceptance-assistant
      - ops-runtime.monitoring
      - incident-response.response
      - notifications.gate_and_human_confirmation
      - reporting.audit
```

## Event envelopes

Emit event-like records in `reactive_handoff`. Do not actually publish events unless the host environment provides an event bus tool.

Recommended event names:
- `produced.release-validation.post_release_validation_checklist`
- `exception.release-validation.validation_coverage_gap`
- `sla.release-validation.owner_confirmation_needed`

Each event envelope should include:
- `event_name`
- `artifact_id`
- `schema_version`
- `trigger_reason`
- `subscribers_hint`
- `next_owner_placeholder`

## feedback feedback loop

Use `feedback_signal_candidates[]` to preserve signals that should improve future PRV focus:
- repeated PRV failures
- missing baselines
- recurring customer-support observations
- defect clusters or incident themes

Do not mine requirements directly in this skill; hand off candidates to feedback-compatible downstream processing.
