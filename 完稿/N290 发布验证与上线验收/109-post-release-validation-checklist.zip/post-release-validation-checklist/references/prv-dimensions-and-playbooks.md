# PRV dimensions and playbooks

## Time windows
- `t_plus_0m`: first confirmation after deployment or first traffic cutover
- `t_plus_15m`: immediate stability and alert warm-up
- `t_plus_1h`: short-term behavior under live traffic
- `t_plus_24h`: first full business-day health check
- `t_plus_7d`: weekly-cycle validation
- `t_plus_28d`: go-live acceptance horizon

## Priority model
- `P0`: must pass, directly blocks GA or triggers rollback/incident handling
- `P1`: should pass, failures require signoff or compensating action
- `P2`: observe, record, and trend; does not block by default

## Requirement model
- `mandatory`: no skip, no silent downgrade
- `signoff_required`: can proceed only with documented approval
- `observe_only`: track and trend without blocking by default

## Validation types
- `active_probe`: explicit action such as curl, synthetic request, or scripted verification
- `passive_observation`: read dashboards, traces, logs, alerts, or complaint streams
- `synthetic_monitor`: continuously scheduled validation after deployment
- `human_confirmation`: human-visible confirmation that cannot be automated yet

## Dimensions
- `D1 functional`
- `D2 data_integrity`
- `D3 performance`
- `D4 security`
- `D5 compliance`
- `D6 integration`
- `D7 monitoring`
- `D8 rollback_readiness`

## Failure playbook hints
- Functional P0 failure -> incident page, immediate rollback decision, repeat probe after rollback
- Data integrity failure -> halt rollout, preserve evidence, open reconciliation / rollback path
- Performance failure -> compare against baseline, evaluate scale or rollback within SLA
- Compliance failure -> treat as hard stop regardless of traffic level
- Monitoring failure -> repair visibility first if it blinds other PRVs

## Scenario-adaptive window handling

`t_plus_30d` is the preferred long-horizon acceptance window. Read `t_plus_28d` as a compatible alias when older artifacts use it.

Do not require every scenario to use every window. Use only windows that match the release shape and evidence. Missing windows should become coverage gaps, not automatic rejection.
