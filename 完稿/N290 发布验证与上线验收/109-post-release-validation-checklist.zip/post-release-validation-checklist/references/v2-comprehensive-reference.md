# V2 comprehensive reference without boundary creep

Use the complete N290 v2 model as a reference library, not as a mandatory schema.

## Keep inside this skill

- Post-release validation checklist design
- Time-window planning
- Validation dimensions and coverage gaps
- Evidence expectations and baseline requirements
- Recommended failure playbook hints

## Keep outside this skill

- Rollback execution
- Incident creation or paging
- Final gate decisions
- Human approval workflow management
- Contract, billing, portfolio, or legal acceptance closure

## Adaptive windows

Use the nearest valid window sequence for the release scenario:

- hotfix: usually immediate, 15-minute, and 1-hour checks are enough
- canary or feature flag: align windows to traffic or flag phases
- partial deployment: align windows to deployment slice and blast radius
- standard release: use immediate, 15-minute, 1-hour, 24-hour, 7-day, and 30-day windows when evidence supports it
- post-incident validation: align windows to recovery milestones

## Completeness handling

Avoid all-or-nothing rejection. Express gaps as:

- `coverage_gap`
- `missing_baseline`
- `pending_owner_confirmation`
- `deferred_observation_window`
- `not_applicable_for_scenario`
