## Mock input fixture

```yaml
mock_input:
  scenario: "deploy_event_only"
  content: "service: payment-service, deployed_at: 2026-05-20T14:00:00Z"
  expected_output_shape:
    prv_items:
      min_entries: 2
      p0_items: ">= 1"
    weighted_completion:
      P0_total: ">= 1"
      P0_executed: 0
    self_check:
      passed: true
      warnings: ["Conservative defaults — provide 验收标准.md to calibrate pass criteria"]

mock_input_2:
  scenario: "all_p0_passed_hotfix"
  content:
    prv_001_result: pass
    prv_002_result: pass
    release_scenario: hotfix
  expected_output_shape:
    weighted_completion:
      P0_completion_pct: 100
    downstream_handoff:
      to_skill: go-live-acceptance-assistant
    self_check:
      passed: true
```
