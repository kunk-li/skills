# Cross-skill orchestration

## Position in the N290 node
- Upstream node inputs: acceptance criteria, release notes, and release task orchestration
- Current skill: define the post-release validation checklist
- Downstream companion: `go-live-acceptance-assistant`
- Node output chain: `发布后验证清单.csv` -> `上线验收记录.md`

## Collaboration contract
1. `post-release-validation-checklist` defines the planned validation set.
2. Each planned row must have a stable `prv_id`.
3. `go-live-acceptance-assistant` consumes the executed results using `linked_prv_ids[]` or a one-to-one `prv_results[]` mapping.
4. If an unplanned observation appears after deployment, keep it as an additional observation; never silently rewrite the planned checklist.
5. Decision hints flow forward, but final GO / CONDITIONAL GO / NO-GO synthesis belongs to the companion skill.

## Minimum handoff fields
- `prv_id`
- `time_window`
- `prv_priority`
- `prv_dimension`
- `validation_type`
- `pass_criteria`
- `fail_criteria`
- `evidence_expected`
- `on_failure_action`
- `related_prvs`

## Shared structure
Use `references/release-outcome-contract.md` as the shared release outcome data structure.

## Workflow v2 orchestration additions

- `post-release-validation-checklist` remains the atomic planner.
- `go-live-acceptance-assistant` remains the atomic synthesizer.
- Do not require a new ChatGPT skill for N290 packaging. Prefer a host workflow, CI job, node README, or external runbook to package both outputs; neither atomic skill should absorb the other.
- Use stable `prv_id` values as the main join key.
- Use `reactive_handoff` for N330/N340/N350/N390-style subscribers.
- Route rollback, incident, and gate actions to N310/N380 as handoff hints, not executed commands.

## Default PRV to acceptance dimension mapping

Use this mapping only as a default semantic bridge from the planned validation checklist to the acceptance record. It is not a hard schema; the acceptance assistant should still rely on available evidence and preserve evidence gaps when data is missing.

| 109 PRV dimension | Default 110 acceptance dimension |
|---|---|
| `D1_functional` | `functional` |
| `D2_data_integrity` | `functional` + `technical` |
| `D3_performance` | `technical` |
| `D4_security` | `technical` + `operational` |
| `D5_compliance` | `functional` + `operational` |
| `D6_integration` | `technical` |
| `D7_monitoring` | `operational` |
| `D8_rollback_readiness` | `operational` |

Boundary rule: this mapping helps traceability; it must not force a missing acceptance dimension to become a rejection.
