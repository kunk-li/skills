# Cross-skill orchestration

## Position in the release-validation node
- Upstream node inputs: acceptance criteria, release notes, and release task orchestration
- Current skill: define the post-release validation checklist
- Downstream companion: `go-live-acceptance-assistant`
- Node output chain: `发布后验证清单.csv` -> `上线验收记录.md`

## Collaboration contract
1. `post-release-validation-checklist` defines the planned validation set.
2. Each planned row must have a stable `prv_id`.
3. `go-live-acceptance-assistant` consumes the executed results using `linked_prv_ids[]` or a one-to-one `prv_results[]` mapping.
4. If an unplanned observation appears after deployment, keep it as an additional observation; never silently rewrite the planned checklist.
5. Decision hints flow forward, but final GO / CONDITIONAL GO / NO-GO synthesis belongs to the companion skill.

## Minimum handoff fields
- `prv_id`
- `time_window`
- `prv_priority`
- `prv_dimension`
- `validation_type`
- `pass_criteria`
- `fail_criteria`
- `evidence_expected`
- `on_failure_action`
- `related_prvs`

## Shared structure
Use `references/release-outcome-contract.md` as the shared release outcome data structure.

## Workflow v2 orchestration additions

- `post-release-validation-checklist` remains the atomic planner.
- `go-live-acceptance-assistant` remains the atomic synthesizer.
- Do not require a new ChatGPT skill for release-validation packaging. Prefer a host workflow, CI job, node README, or external runbook to package both outputs; neither atomic skill should absorb the other.
- Use stable `prv_id` values as the main join key.
- Use `reactive_handoff` for deployment/rollout/infra/reporting-style subscribers.
- Route rollback, incident, and gate actions to incident-response/notifications as handoff hints, not executed commands.

## Default PRV to acceptance dimension mapping

Use this mapping only as a default semantic bridge from the planned validation checklist to the acceptance record. It is not a hard schema; the acceptance assistant should still rely on available evidence and preserve evidence gaps when data is missing.

| 109 PRV dimension | Default 110 acceptance dimension |
|---|---|
| `D1_functional` | `functional` |
| `D2_data_integrity` | `functional` + `technical` |
| `D3_performance` | `technical` |
| `D4_security` | `technical` + `operational` |
| `D5_compliance` | `functional` + `operational` |
| `D6_integration` | `technical` |
| `D7_monitoring` | `operational` |
| `D8_rollback_readiness` | `operational` |

Boundary rule: this mapping helps traceability; it must not force a missing acceptance dimension to become a rejection.


---

## Boundary comparison table — post-release-validation vs go-live vs release-checklist

| Dimension | post-release-validation-checklist | go-live-acceptance-assistant | release-checklist-generation | on-call-response-recommendation |
|---|---|---|---|---|
| **Primary question** | "What must we check AFTER deploy?" | "Did we PASS? GO or NO-GO?" | "Are we READY to deploy?" | "Incident active — what now?" |
| **Timing** | Post-deploy (T+0 onward) | After PRV results collected | Pre-deploy (T-14d to T-0) | During active incident |
| **Output type** | PRV item list with checkpoint times and pass/fail criteria | GA decision record | Pre-deploy readiness checklist | Response sequence |
| **Owns** | PRV item design, pass/fail criteria definition, execution monitoring | GA decision making, sign-off consolidation | Pre-deploy gate items, sign-off tracking | Incident command, escalation |
| **Does not own** | GA decision (→110), pre-deploy readiness (→103), incident response (→120) | PRV design (→109), risk assessment (→101) | Post-deploy checks (→109), GA decision (→110) | PRV design (→109), GA decision (→110) |

### Content boundaries
```
109 MUST contain: PRV items with checkpoint_time (T+0, T+5min, T+1h, T+24h)
109 MUST NOT contain: pre-deploy items with timing_marker T-14d..T-0 (those go in 103)
109 MUST NOT contain: GA decision or GO/NO-GO recommendation (that goes in 110)
109 feeds → 110 which makes the final call
```

---

## Routing decision tree
```
User question →
  "What must we check AFTER deploy?" → post-release-validation-checklist ✓ YOU ARE HERE
  "Did we pass? GO or NO-GO?" → go-live-acceptance-assistant
  "Set up release checks BEFORE deploy" → release-checklist-generation
  "A PRV item failed — investigate" → ops-runtime skills (log-analysis, monitoring-metric-interpretation)
```

---

## Boundary comparison table — post-release complete

| Dimension | post-release-validation-checklist | go-live-acceptance-assistant | release-checklist-generation | on-call-response-recommendation |
|---|---|---|---|---|
| **Primary question** | "What to CHECK after deploy?" | "GO or NO-GO?" | "Ready to START deploying?" | "Active incident — what NOW?" |
| **Timing** | T+0 onward (post-deploy) | After 109 results collected | T-14d to T-0 (pre-deploy) | During incident |
| **Output type** | PRV item list: checkpoint_times, pass_criteria, results | GA decision record | Pre-deploy readiness checklist | Response sequence |
| **Owns** | PRV item design, pass/fail criteria, result recording | GA decision making | Pre-deploy gate items | Incident command |
| **Does not own** | GA decision (→110), pre-deploy readiness (→103), incident response (→120) | PRV design (→109), risk assessment (→101) | Post-deploy checks (→109), GA decision (→110) | PRV design (→109), GA decision (→110) |

### Content boundaries
```
109 items have timing: T+0, T+5min, T+1h, T+24h (post-deploy)
103 items have timing: T-14d, T-7d, T-3d, T-1d, T-0 (pre-deploy)
Never mix: T-Xd items in 109; T+Xh items in 103

109 feeds → 110 which makes the final call
109 MUST NOT issue GO/NO-GO → that is 110's job
```

