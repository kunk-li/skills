# 发布后验证清单 常见失败模式

## F1: 忽略 rollback_triggers
症状：只写 `check_steps` 和 `expected_result`，没有回滚触发阈值。
修正：每个关键 PRV 都要有单项 `rollback_triggers`，并区分全局触发器。

## F2: owner_placeholder 冒充真实 owner
症状：直接写真实姓名或随意拍脑袋指定负责人。
修正：统一用 `<SRE_oncall>`、`<release_owner>` 这类占位符，除非用户明确提供真实 owner。

## F3: 时间窗口分类混乱
症状：把 4 小时观察项放进 `t0`，或把部署窗口动作写进 `same_day`。
修正：严格区分 `t0 / t1 / same_day / day2_plus`。

## F4: confidence 留空或全写 explicit
症状：所有条目都看起来像已证实结论。
修正：不确定的内容显式标注 `inferred` 或 `unknown`。

## F5: JSON 字段名不统一
症状：混用 `rule_id / risk_id / pattern_id` 等同义字段。
修正：共享语义统一为 `id / name / object_name / action_name`。

## F6: 只有 expected_result，没有 expected_signals
症状：只说“应该 200 OK”，缺少可观察指标。
修正：尽量补出可观察信号，如日志、报警、成功率、错误率或人工核验动作。

## F7: 按时间窗口散列输出而非 checklist_items[]
症状：输出 `t0_checks[]`、`t1_checks[]` 多个数组。
修正：统一用 `checklist_items[]`，每项自带 `time_window`。

## F8: v2 completeness becomes hard rejection
Symptom: Missing one time window, owner, metric, or dimension causes the whole checklist to fail.
Fix: Preserve the checklist, downgrade readiness, and add a `coverage_gaps` row.

## F9: handoff hint becomes executed action
Symptom: The output says rollback was triggered or an incident was created without tool evidence.
Fix: Use recommendation-only wording and route the action to N310/N380 handoff fields.
