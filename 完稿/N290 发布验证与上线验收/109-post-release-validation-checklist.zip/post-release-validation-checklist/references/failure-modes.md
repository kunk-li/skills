# failure-modes — release-validation

Common failure modes across release-validation post-release validation and acceptance skills.

## FM01: No PRV execution results available
- **Symptom:** `post-release-validation-checklist` items defined but not executed before `go-live-acceptance-assistant` is invoked.
- **Impact:** `go-live-acceptance-assistant` cannot issue GO — only DEFERRED_REVIEW.
- **Handling:** `go-live-acceptance-assistant` sets `ga_decision: DEFERRED_REVIEW`. List unexecuted P0 PRV items in `blockers_and_conditions`. Do not invent pass outcomes.

## FM02: All PRV results are passive_observation only
- **Symptom:** No active probes, synthetic monitors, or human confirmations executed.
- **Impact:** Cannot confirm production health from passive signals alone.
- **Handling:** Set `ga_decision: DEFERRED_REVIEW`. Require at least 1 P0 active_probe before issuing GO or CONDITIONAL_GO.

## FM03: Missing baseline for quantitative pass criteria
- **Symptom:** PRV items reference metric thresholds but no baseline data is available.
- **Impact:** Pass/fail criteria cannot be evaluated objectively.
- **Handling:** Mark affected PRV items as `contract_confidence: inferred`. Emit `baseline_required: true` in `downstream_handoff`. Do not reject the artifact — downgrade readiness instead.

## FM04: Signoff evidence absent
- **Symptom:** Required role-based signoffs (PM, SRE, Tech Lead) not provided.
- **Impact:** `ga_decision: CONDITIONAL_GO` cannot be elevated to GO.
- **Handling:** List missing signoffs in `blockers_and_conditions`. Keep `signoff_evidence.status: pending`. Never fabricate signoff.

## FM05: PRV partial completion — weighted coverage < 100% P0
- **Symptom:** Some P0 PRV items not executed before acceptance is requested.
- **Impact:** GO decision cannot be issued while mandatory P0 items are incomplete.
- **Handling:** Set `ga_decision: CONDITIONAL_GO` at best if some P0 pass. List missing P0 items explicitly. `go-live-acceptance-assistant` must consume `weighted_completion.P0_executed` from `post-release-validation-checklist` handoff.

## FM06: Circuit breaker triggered
- **Symptom:** release-validation skill re-invoked ≥3 times without resolving readiness.
- **Impact:** Further re-invocation will not resolve missing PRV results.
- **Handling:** Stop regeneration. Emit `readiness: red`. Require new PRV execution evidence before re-invoking. Escalate to release-manager.


---

## Degradation examples — confidence quantification extended

### readiness: amber — canary PRV with stage 1 in_progress

```yaml
metadata:
  readiness: amber
  selected_mode: canary_prv
evidence_profile:
  confidence_ceiling_applied: medium
canary_prv:
  stages:
    - stage_id: stage_1
      scope: "5% traffic"
      prv_items:
        - prv_id: C-PRV-001
          description: "Error rate probe for canary cohort"
          prv_priority: P0
          result: pass
          actual_value: "0.31%"
        - prv_id: C-PRV-002
          description: "P99 latency probe"
          prv_priority: P0
          result: in_progress
          checkpoint_time: T+15min
      stage_verdict: waiting_for_prv
  overall_canary_verdict: in_progress
weighted_completion:
  P0_total: 2
  P0_pass: 1
  P0_completion_pct: 50
self_check:
  passed: true
  warnings: ["amber — canary stage_1 P0 at 50%; await C-PRV-002 checkpoint"]
```

### readiness: red — P0 PRV failed, regression detected

```yaml
metadata:
  readiness: red
prv_items:
  - prv_id: PRV-003
    description: "Checkout conversion rate regression probe"
    prv_priority: P0
    result: fail
    pass_criteria: "conversion_rate ≥ 0.32 (baseline 0.34, -6% tolerance)"
    actual_value: "0.21"
    fail_action: escalate_to_oncall_immediately
    regression_magnitude: "-38.2%"
weighted_completion:
  P0_total: 3
  P0_pass: 2
  P0_fail: 1
  P0_completion_pct: 0  # ANY P0 fail = 0% complete
downstream_handoff:
  handoffs:
    - target: go-live-acceptance-assistant
      handoff_type: gap
      blocking: true
      summary: "PRV P0 FAIL: conversion_rate 0.21 < 0.32. Block GA immediately."
    - target: on-call-response-recommendation
      handoff_type: routing
      urgency: immediate
      summary: "PRV regression confirmed — incident response required"
self_check:
  passed: false
  failed_rules:
    - "SCR-POSTRELE-051: P0 PRV-003 failed — overall_ready: false; GA blocked"
```