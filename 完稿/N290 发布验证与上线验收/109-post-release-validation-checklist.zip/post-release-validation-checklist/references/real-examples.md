# real-examples — post-release-validation-checklist

These examples illustrate how to produce this skill's artifact under different evidence conditions.
Use them as output calibration references — not as templates to copy verbatim.

---

## Example 1: Full green path — all P0 items pass (T+5min, T+1h, T+24h)

**Scenario:** Payment service v2.3 deployed successfully. Three checkpoint windows used.

**Input given:**
- Deployment: payment-service v2.3, released 09:00 UTC
- Risk level: amber (DB migration included)
- SLO baseline: error_rate 0.08%, p99_latency 120ms

**Expected output shape:**
```yaml
metadata:
  readiness: green
  selected_mode: standard_prv
  release_scenario: standard
  skill_contract_version: 2.1.0
prv_items:
  - prv_id: PRV-001
    description: "Smoke test — POST /v2/payments with test payload"
    prv_priority: P0
    validation_type: active_probe
    checkpoint_time: T+5min
    pass_criteria: "HTTP 200, latency < 500ms, response contains payment_reference field"
    fail_criteria: "Any non-200, or latency > 500ms, or missing payment_reference field"
    fail_action: rollback_immediately
    owner: sre-oncall
    result: pass
    actual_value: "HTTP 200, latency 143ms, field present"

  - prv_id: PRV-002
    description: "DB migration validation — verify payment_reference column exists and is populated"
    prv_priority: P0
    validation_type: db_query
    checkpoint_time: T+5min
    pass_criteria: "SELECT COUNT(*) FROM orders WHERE payment_reference IS NOT NULL > 0"
    fail_criteria: "Column absent or query fails"
    fail_action: escalate_to_dba_immediately
    owner: dba-team
    result: pass
    actual_value: "Column exists, 1,247 rows populated"

  - prv_id: PRV-003
    description: "SLO burn rate — error_rate stays within 2× baseline over T+1h window"
    prv_priority: P0
    validation_type: metric_probe
    checkpoint_time: T+1h
    pass_criteria: "error_rate < 0.20% (2.5× baseline 0.08%)"
    fail_criteria: "error_rate > 0.20% sustained for > 5min"
    fail_action: page_oncall_and_evaluate_rollback
    owner: sre-oncall
    result: pass
    actual_value: "error_rate 0.09% (peak), stable"

  - prv_id: PRV-004
    description: "p99 latency observation — T+1h window"
    prv_priority: P1
    validation_type: metric_probe
    checkpoint_time: T+1h
    pass_criteria: "p99_latency_ms < 200ms (baseline 120ms + 67% headroom)"
    fail_action: create_investigation_ticket
    owner: sre-oncall
    result: pass
    actual_value: "p99 138ms"

  - prv_id: PRV-005
    description: "Extended stability — 24h error budget consumption check"
    prv_priority: P1
    validation_type: metric_probe
    checkpoint_time: T+24h
    pass_criteria: "Cumulative SLO budget consumed < 5% of monthly budget"
    fail_action: schedule_review_with_release_manager
    owner: sre-lead
    result: pass
    actual_value: "Budget consumed 0.8% of monthly"

weighted_completion:
  P0_total: 3
  P0_executed: 3
  P0_pass: 3
  P0_completion_pct: 100
  P1_total: 2
  P1_executed: 2
  P1_pass: 2
downstream_handoff:
  to_skill: go-live-acceptance-assistant
  prv_completion_summary:
    P0_total: 3
    P0_executed: 3
    P0_pass: 3
    P1_pass: 2
  recommended_ga_input: "All P0 pass. P1 pass. Recommend GO."
self_check:
  passed: true
  warnings: []
```

**Key calibration:** Green path requires ALL P0 items to pass AND `P0_completion_pct: 100`. Do not issue GO recommendation from this skill — that belongs to go-live-acceptance-assistant (110).

---

## Example 2: P0 item failure — NO-GO signal to go-live-acceptance-assistant

**Scenario:** T+5min smoke test passes, but at T+1h the SLO burn rate spikes above threshold.

**Input given:**
- Deployment: checkout-service v1.8
- T+5min smoke test: HTTP 200 ✓
- T+1h: error_rate climbs from 0.1% baseline to 0.45% (3.5× above 2.0% threshold)

**Expected output shape:**
```yaml
metadata:
  readiness: red
  selected_mode: standard_prv
prv_items:
  - prv_id: PRV-001
    description: "Smoke test — POST /checkout"
    prv_priority: P0
    checkpoint_time: T+5min
    pass_criteria: "HTTP 200, latency < 300ms"
    result: pass
    actual_value: "HTTP 200, 87ms"

  - prv_id: PRV-002
    description: "SLO burn rate — T+1h window"
    prv_priority: P0
    checkpoint_time: T+1h
    pass_criteria: "error_rate < 0.30% (3× baseline 0.10%)"
    fail_criteria: "error_rate > 0.30% sustained > 5min"
    fail_action: page_oncall_and_evaluate_rollback
    result: fail
    actual_value: "error_rate 0.45% sustained for 12min at T+1h"
    failure_context:
      first_breach: "T+52min"
      sustained_duration: "12 minutes"
      recommended_action: "Escalate to on-call; evaluate rollback per rollback-plan-generation phase_1"

weighted_completion:
  P0_total: 3
  P0_executed: 2
  P0_pass: 1
  P0_fail: 1
  P0_completion_pct: 33    # only 1 of 3 P0 items passed
downstream_handoff:
  to_skill: go-live-acceptance-assistant
  prv_completion_summary:
    P0_total: 3
    P0_pass: 1
    P0_fail: 1
    P0_pending: 1
  recommended_ga_input: "P0 PRV-002 FAILED. Signal NO-GO to go-live-acceptance-assistant."
  reactive_handoff:
    to_skill: on-call-response-recommendation
    urgency: immediate
    reason: "P0 SLO breach at T+1h — incident response required"
self_check:
  passed: false
  failed_rules:
    - "P0 item PRV-002 result=fail — P0_completion_pct is 33%, not 100%"
```

**Key calibration:** A single P0 failure sets `readiness: red` regardless of other passes. Route `reactive_handoff` to on-call-response-recommendation immediately; do not wait for T+24h.

---

## Example 3: CONDITIONAL_GO path — P0 pass, one P1 pending with risk owner sign-off

**Scenario:** GA is desired today, but the T+24h P1 item (extended latency window) has not completed. Release manager accepts the risk in writing.

**Input given:**
- All 3 P0 items: pass ✓
- P1-001 (T+24h latency monitoring): not yet executed (deployment was 6h ago)
- Release manager provided written risk acceptance for the pending P1

**Expected output shape:**
```yaml
metadata:
  readiness: amber
  selected_mode: standard_prv
prv_items:
  - prv_id: PRV-001
    prv_priority: P0
    result: pass
  - prv_id: PRV-002
    prv_priority: P0
    result: pass
  - prv_id: PRV-003
    prv_priority: P0
    result: pass
  - prv_id: PRV-004
    description: "Extended T+24h latency monitoring window"
    prv_priority: P1
    checkpoint_time: T+24h
    result: pending
    pending_reason: "Deployment is 6h old; T+24h checkpoint not yet reached"
    risk_owner_sign_off:
      accepted_by: release-manager
      accepted_at: "2026-05-21T15:00:00Z"
      acceptance_note: "P1 monitoring window accepted as async follow-up; P0 items all pass"

weighted_completion:
  P0_total: 3
  P0_executed: 3
  P0_pass: 3
  P0_completion_pct: 100
  P1_total: 1
  P1_pending: 1
downstream_handoff:
  to_skill: go-live-acceptance-assistant
  prv_completion_summary:
    P0_total: 3
    P0_pass: 3
    P1_pending: 1
    risk_owner_sign_off: accepted
  recommended_ga_input: "P0 complete (100%). P1 pending with RM sign-off. Signal CONDITIONAL_GO."
self_check:
  passed: true
  warnings:
    - "amber: P1 PRV-004 pending — RM risk sign-off accepted; monitor until T+24h"
```

**Key calibration:** `readiness: amber` when P0 is 100% but P1 items are pending. Always document `risk_owner_sign_off` with timestamp and accepted_by. This skill does NOT issue CONDITIONAL_GO — that is go-live-acceptance-assistant's authority.

---

## Example 4: Hotfix rapid_prv — 2 P0 items, no P1/P2

**Scenario:** P1 incident hotfix deployed at 02:15 UTC. Minimal PRV under time pressure.

```yaml
metadata:
  readiness: green
  selected_mode: rapid_prv
  release_scenario: hotfix
prv_items:
  - prv_id: PRV-001
    description: "Smoke test — GET /health and POST /checkout"
    prv_priority: P0
    validation_type: active_probe
    checkpoint_time: T+5min
    pass_criteria: "HTTP 200 within 3s for both endpoints"
    fail_action: escalate_to_oncall_immediately
    result: pass
    actual_value: "HTTP 200, latency 95ms"
  - prv_id: PRV-002
    description: "SLO burn rate active probe"
    prv_priority: P0
    validation_type: synthetic_monitor
    checkpoint_time: T+10min
    pass_criteria: "SLO burn rate < 2.0×"
    fail_action: rollback
    result: pass
    actual_value: "burn_rate 0.8×"
weighted_completion:
  P0_total: 2
  P0_executed: 2
  P0_completion_pct: 100
downstream_handoff:
  to_skill: go-live-acceptance-assistant
  recommended_ga_input: "Hotfix rapid_prv: all P0 pass. GO signal."
self_check:
  passed: true
```

**Key calibration:** Hotfix `rapid_prv` intentionally has 2 P0 items. Fewer, sharper P0 items beat a long partially-executed checklist under incident pressure.

---

## Example 5: Minimum input — readiness: partial (no deployment context yet)

**Scenario:** Operator asks to design the PRV checklist before deployment starts.

**Input given:** Only "payment-service v2.3, amber risk, DB migration included"

```yaml
metadata:
  readiness: partial
  selected_mode: standard_prv
  evidence_profile:
    confirmed: [release_identity, risk_level, change_type]
    missing_evidence:
      - slo_baseline (using estimated thresholds)
      - deployment_timestamp (T+0 unknown — checkpoints are relative)
      - rollback_plan artifact (fail_action defaults to escalate)
    missing_evidence_impact: "pass_criteria use estimated thresholds; actual values cannot be recorded until deployment completes"
prv_items:
  - prv_id: PRV-001
    description: "Smoke test — verify primary endpoint responds"
    prv_priority: P0
    checkpoint_time: T+5min
    pass_criteria: "HTTP 200, latency < 500ms (estimated — update with actual baseline)"
    fail_action: escalate_to_oncall
    result: pending
  - prv_id: PRV-002
    description: "DB migration column validation"
    prv_priority: P0
    checkpoint_time: T+5min
    pass_criteria: "New column present and non-null count > 0 (to be verified post-deploy)"
    fail_action: escalate_to_dba
    result: pending
  - prv_id: PRV-003
    description: "SLO burn rate — T+1h window"
    prv_priority: P0
    checkpoint_time: T+1h
    pass_criteria: "error_rate < 0.30% (estimated; update with actual SLO baseline)"
    fail_action: evaluate_rollback
    result: pending
self_check:
  passed: false
  failed_rules:
    - "slo_baseline absent — pass_criteria are estimates; update before execution"
    - "deployment_timestamp unknown — result fields all pending"
```

**Key calibration:** Producing a PRV design artifact before deployment is valid and useful. Mark all results `pending`, document missing_evidence, and update thresholds once SLO baseline is confirmed.
