---
name: data-flow-mapping
description: map data creation, sync, retry, compensation, and consumption flows with transaction boundaries and exception paths. triggers on 表结构设计草案.sql or 接口设计草案.yaml.
---
# data-flow-mapping


## Flow priority quick-reference
Map flows in this order to ensure exception paths are not forgotten.

| Priority | Flow category | Check when |
|---|---|---|
| 1 (always) | happy_path | core business action succeeds end-to-end |
| 2 (always) | retry | transient failure: network timeout, DB deadlock, rate limit |
| 3 (always) | dead_letter | permanent failure after max retries |
| 4 (when async) | compensation | saga rollback when downstream step fails |
| 5 (when cached) | cache_invalidation | cache becomes stale after write |
| 6 (when regulated) | audit | every write/delete on regulated data |
| 7 (when replicated) | replication | data movement between systems or tiers |
| 8 (when batched) | archival | hot → warm → cold tier migration |

## Transaction scope decision table
| Scenario | `tx_kind` to use | Notes |
|---|---|---|
| Single DB write | `local` | standard ACID transaction |
| Write + event publish | `outbox` | write to outbox table in same transaction; relay publishes |
| Multi-service write | `saga` | choreography or orchestration; requires compensation steps |
| Read replica read | `none` | no transaction; note staleness window |
| Cache read | `none` | note TTL and cache invalidation strategy |
| Batch insert | `local` (chunked) | chunk size: 500-1000 rows; each chunk is one transaction |

## Flow taxonomy quick-reference
| Flow type | Trigger | Key risk | Mapping obligation |
|---|---|---|---|
| `creation` | API write / import | duplicate, partial write | idempotency key, rollback point |
| `update` | state transition, patch | lost update, version conflict | optimistic lock or queue serialization |
| `sync` | cross-service replication | lag, inconsistency window | eventual consistency SLA |
| `retry` | timeout, transient error | duplicate execution | idempotency required |
| `compensation` | saga rollback, failed step | partial state | compensating transaction |
| `consumption` | queue/event consumer | at-least-once, out-of-order | deduplication logic |
| `export/batch` | scheduled, triggered | large data, memory | cursor pagination, chunk size |

## Transaction boundary rules
- A flow crossing service boundaries **cannot** use a local DB transaction.
- Distributed transactions → use Saga (choreography or orchestration) or Outbox pattern.
- Mark every flow with: `transaction_scope: local | saga | outbox | eventual_consistent`
- Every compensation step must reference the `flow_id` it compensates.

## Exception path checklist
For every primary flow, check:
- [ ] what happens if the DB write succeeds but the event publish fails?
- [ ] what happens if the consumer crashes mid-processing?
- [ ] what happens if the same message is delivered twice?
- [ ] what is the maximum acceptable lag before data is considered stale?


## Trigger conditions
Map data flows when any of the following are present:
- table schema from 046 (`表结构设计草案.sql`)
- API spec from 043 (`接口设计草案.yaml`)
- event catalog or message broker configuration
- N130 technical solution describing system flows

## Standalone rule
Map flows at the step level even without complete upstream. Use `flow_confidence: inferred` for steps derived from PRD or solution prose. Prioritize happy path first, then exception paths, then DLQ/compensation.

## Role and boundary
本 skill 对齐技能总表中in the technical-solution-design -> 数据设计 -> 数据流分析 / 数据流梳理」。

它是 **understanding_support** 型技能：重点是把“创建、变更、同步和消费链路”讲清楚，帮助后续一致性、测试、依赖、监控和韧性设计，而不是直接替代最终技术裁决。

### Boundary
- 止于方案、接口、数据与任务设计，不进入代码编写、测试执行和发布落地。
- 负责组织关系、流转、拓扑和异常路径，不直接输出最终实现动作。
- 表结构定义优先由 046 提供；访问路径优化优先由 047 提供。
- 本 skill 不应把安全、容量、SLO、监控全部定死，只提供 flow-aware 输入与风险提示。

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 4 种模式：
- `flow-from-analysis`：从技术方案、业务规则、状态流转和表结构出发梳理流；默认模式。
- `from-api-catalog`：基于 API surface 推导同步调用链与写入链路。
- `from-event-catalog`：基于事件或消息目录推导异步发布 / 订阅链路。
- `resilience-review`：围绕 retry / fallback / compensation / DLQ / replay 做异常流补全。

## Primary inputs
### 推荐输入
- 技术方案分析
- 表结构设计建议
- API catalog / interface intent / webhook list
- 事件目录、批处理、定时任务、导出任务
- 状态流转、审计要求、保留与归档规则

### 可选增强
- 线上事故复盘、重试规则、DLQ 说明
- 流量规模预估、峰值倍数、传输大小
- 敏感数据分类要求

## Standalone rule
可以单独使用，但没有 046 / API / 事件目录时必须降级：
- 允许从 PRD、技术方案文字和状态流转中推 provisional flows。
- 但必须显式标记 `confirmed / inferred / pending`。
- 若异常流证据不足，不能假装系统天然可靠；应在 `exception_path_coverage` 中写出缺口。

## Core output contract
默认输出 Markdown，图示优先 ASCII；环境支持时可追加 Mermaid。优先遵循 `references/output-template.md` 与 `references/flow-structure.md`。

结果至少包含：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: understanding_support`
  - `stage_position: technical_solution_design.data_design.data_flow_analysis`
  - `evidence_profile`
- `flow_scope`
- `data_lifecycle_views[]`
- `flow_catalog[]`
  - `flow_id`
  - `flow_category`
  - `flow_semantics`
  - `source`
  - `target`
  - `payload`
  - `trigger`
  - `topology`
  - `sync_or_async`
  - `storage_touchpoints`
  - `data_classification`
  - `flow_metrics`
  - `reliability_notes`
  - `evidence`
  - `confidence`
- `flow_diagram`
- `exception_path_coverage`
- `data_classification_summary`
- `flow_metrics_summary`
- `gaps_and_risks`
- `open_questions[]`
- `downstream_handoff`
- `self_check`

## Design rules
### Happy + exception coverage / 正常流 + 异常流并存
每个关键业务用例都应至少描述：
- 1 条 `happy_path`
- 以及适用时至少 1 条 `retry` / `fallback` / `compensation` / `dead_letter` / `replay`

如果某类异常流不适用，必须明确写 `not_applicable`，而不是完全缺失。

### Flow semantics discipline / 语义纪律
每条流都必须给出 `flow_semantics`，只允许使用受控类别，如：
- `sync_call`
- `async_publish`
- `async_subscribe`
- `batch_export`
- `streaming_push`
- `webhook`
- `file_transfer`
- `db_replication`
- `shared_storage_access`

### Data classification discipline / 数据分类纪律
每条流必须标 `data_classification`：
- `public`
- `internal`
- `confidential`
- `pii`
- `financial`
- `regulated`

对高敏类别必须补充最少保护提示：传输加密、日志脱敏、访问控制、审计要求。

### Topology and direction discipline / 拓扑与方向纪律
每条流必须写明 `topology`，如：
- `point_to_point`
- `broadcast`
- `gather`
- `pipeline`
- `request_response`
- `pub_sub`

不要用模糊的“系统 A 和 B 有交互”代替方向化流定义。

### Flow metrics discipline / 流量规模纪律
关键流尽量给：
- `per_event_size`
- `events_per_second` 或 daily volume
- 延迟预期
- delivery guarantee / retry budget
- peak factor

若只能估算，也要标 estimated，而不是伪装成测量值。

### Boundary discipline / 边界纪律
- 不要在本 skill 中重新定义表结构；引用 046 的命名。
- 不要直接设计完整索引；只指出某条流需要的 access path，再 handoff 给 047。
- 不要把 resilience、security、monitoring 直接定成最终实现，只输出 flow-aware 输入。

## Execution workflow
1. 识别 selected mode 与 evidence profile。
2. 统一业务对象、表、API、事件和批任务命名。
3. 先画 happy path，再补 retry / fallback / compensation / DLQ / replay。
4. 为每条流补上 semantics、topology、direction、classification、metrics。
5. 对涉及存储的步骤引用 046 的表或对象命名。
6. 对依赖访问路径的批量 / 检索流，向 047 提出 access-path hints。
7. 输出 lifecycle view、diagram、异常覆盖度和 gaps。
8. 形成 handoff 给一致性检查、依赖识别、监控、测试与 N170 设计。
9. 运行 checklist 与 common-failure review。

## Dynamic completeness
- 单用例：全链路细化到触发、写入、消费、异常
- 中等系统：覆盖全部核心链路 + 关键异常流
- 大型系统：优先覆盖核心 happy path、跨边界链路和高风险异常流；低风险边角链路可摘要

## Quality bar
合格结果应让 reviewer 能快速回答：
- 数据从哪来、到哪去、怎么失败、如何恢复
- 哪些流含敏感数据
- 哪些流依赖异步、批量或跨库一致性
- 哪些流可能需要额外索引、监控、测试与补偿设计

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/flow-taxonomy.md`
- `references/composition-contract.md`

## Reference files
- `references/output-template.md`
- `references/flow-structure.md`
- `references/flow-taxonomy.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`


## N160 v2 optimization layer

Use this layer when the skill is composed with 046 and 047 inside N160 or when the caller asks for implementation-ready data-flow mapping.

### Contract-first inputs

Prefer this input shape:

```yaml
tables: from 046 table_catalog, keyed by table_id
services: from N140
api_specs: from N150
state_machines: from N070, optional
index_hints: from 047, optional
external_systems: optional
```

### Enhanced output contract

In v2-compatible output, extend each `flow_catalog[]` item with step-level structure:

```yaml
flow_catalog:
  - flow_id: FLOW-xxx
    name: string
    flow_kind: happy_path | rollback | retry | dlq | replication | archival | backup | audit | sync_reconciliation
    trigger:
      trigger_kind: api_call | event | scheduled | manual | upstream_flow
      trigger_source: string
    steps:
      - step_number: integer
        step_name: string
        actor:
          kind: service | database | cache | queue | external_api | scheduler
          id: string
        action: read | write | update | delete | publish_event | consume_event | invoke_api | compute | validate | transform | enrich
        data_involved:
          source: table_id | api_ref | event_ref | external_system_ref
          fields: []
          sensitivity_classes: []
        transaction_boundary: see references/transaction-boundary.md
        consistency_guarantee: strong | eventual | read_your_writes | monotonic_read
        latency_budget: string | unknown
        on_failure:
          action: retry | compensate | dlq | abort | alert_and_continue
          retry_policy: optional
          compensation_flow_id: string | null
    read_write_separation: see references/read-write-cache-semantics.md
    data_lifecycle:
      creation_point: string
      mutation_points: []
      final_state_location: table_id | external_system | none
      archival_point: string | null
      deletion_point: string | null
```

### Additional design rules

- Every step must include `transaction_boundary`; if no transaction applies, write `tx_kind: none`.
- Every step must include `on_failure`; if not applicable, explain why.
- Every write or delete touching regulated data must have an audit flow or an explicit gap.
- Storage touchpoints must use 046 `table_id` values.
- Sensitive data propagation must be reflected in `compliance_obligations`.
- Cross-service writes should use Saga or outbox semantics by default; do not recommend 2PC unless the caller explicitly provides that platform constraint.

### Additional references

- `references/n160-shared-naming.md`
- `references/transaction-boundary.md`
- `references/read-write-cache-semantics.md`
- `references/compliance-obligations.md`

## v2 artifact contract

```yaml
artifact_schema_version: n160.data-flow.v2.1.0
skill_name: data-flow-mapping
produced_event: produced.n160.data_flow_map.v2
blocker_mapping: B-N160-03
readiness: ready | provisional | blocked
rule_results:
  - rule_id: R01_every_flow_has_source_and_sink
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_exception_paths_covered
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R03_sensitive_data_classification_propagated
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R04_retry_and_compensation_paths_mapped
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R05_table_ids_from_046_used
    severity: reject
    result: pass | warn | reject | not_applicable
route_back_to: none | n160-schema | n150
# none        — data flow complete; N170/N260 may proceed
# n160-schema — flow requires undeclared table; revise 046 first
# n150        — API surface incomplete; revise N150 before re-mapping
feedback_signal_to_n005:
  signal_type: none | consistency_gap_detected | resilience_risk_signal
  summary: ""
  target_n070_skills:
  - 017-data-object-identification
  - 015-state-transition-mapping
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
eventbus_subscribers: [N260]   # N260 quality gate subscribes to data flow for consistency test planning
```

## Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| `数据对象目录.md` (017) | OBJ-* storage.medium, constraint_tags: append_only, relationships[].consistency_mode | flow step storage targets, consistency mode per hop |
| `业务规则清单.md` (014) | idempotency rules, compensation rules, temporal rules | retry flows, compensation flows, scheduled flows |
| `状态转移图.md` (015) | SM-* transitions, side_effects[], recovery_note | state-change flows, recovery paths |
| `权限矩阵.csv` (016) | compliance_flag, audit_level | sensitive-data classification, compliance obligations |
