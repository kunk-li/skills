# Read Write and Cache Semantics

Use this flow-level block when reads, writes, replicas, or cache are involved.

```yaml
read_write_separation:
  writes_to: [table_id]
  reads_from: [table_id]
  read_replica_usage:
    enabled: true | false | unknown
    fallback_to_primary_on:
      - recent_writes_within_window
      - transaction_context
      - user_session_read_your_writes
  cache_usage:
    read_strategy: none | read_through | cache_aside
    write_strategy: none | write_through | write_behind | write_around
    invalidation: ttl | event_driven | manual | not_applicable
    consistency_window: duration | unknown
```

Rules:

- If a flow requires read-your-writes, flag replica and cache risks.
- If write-behind cache is used, require failure and replay handling.
- If event-driven invalidation is used, link to the event flow id.
