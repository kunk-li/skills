# Orchestration

## Upstream
Best inputs:
- technical solution analysis
- table-schema-design-recommendation
- api-design-recommendation
- index-design-recommendation
- state transition and business rule artifacts

## Downstream
Main consumers:
- dependency identification
- data consistency check generation
- performance and reliability review
- monitoring design
- test scenario generation

## 048 -> other nodes
| 048 field | consumer | why |
| --- | --- | --- |
| flow_catalog | dependency identification | identify coupling and handoffs |
| data_classification_summary | security / compliance review | data protection scope |
| exception_path_coverage | test / resilience design | failure-case coverage |
| flow_metrics_summary | performance / monitoring | capacity and latency assumptions |


## N160 v2 node behavior

Run 048 after 046 and preferably after 047. Use 046 for table ids and field sensitivity. Use 047 for access-path hints, high-write pressure, and slow-query feedback.

048 should feed N170 with transaction, consistency, idempotency, audit, security, and compliance inputs.
