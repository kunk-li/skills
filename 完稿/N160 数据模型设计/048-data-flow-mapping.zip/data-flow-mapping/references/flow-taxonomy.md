# Flow Taxonomy

## flow_category
- happy_path
- retry
- fallback
- compensation
- dead_letter
- replay
- migration

## flow_semantics
- sync_call
- async_publish
- async_subscribe
- batch_export
- streaming_push
- webhook
- file_transfer
- db_replication
- shared_storage_access

## topology
- point_to_point
- broadcast
- gather
- pipeline
- request_response
- pub_sub


## N160 v2 additional flow categories

- `replication`: primary to replica or CDC movement.
- `archival`: hot store to cold store or retention archive.
- `backup`: backup and restore-oriented movement.
- `audit`: immutable evidence trail for writes, deletes, or sensitive reads.
- `sync_reconciliation`: reconciliation between systems or ledgers.
