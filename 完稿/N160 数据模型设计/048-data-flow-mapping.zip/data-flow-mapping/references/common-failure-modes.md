# Common Failure Modes

- only drawing happy path and forgetting failure recovery
- saying systems “interact” without source, target, or direction
- omitting data classification for sensitive flows
- mixing provisional guesses with confirmed flows
- inventing indexes or schema changes instead of handing off to 046 / 047
- ignoring batch, replay, or DLQ paths in event-heavy systems


## N160 v2 failure modes

1. Flow mentions storage by display table name instead of 046 `table_id`.
2. Happy path exists but rollback, retry, DLQ, or audit gaps are hidden.
3. Transaction boundaries are missing, especially around cross-service writes.
4. Sensitive data is labeled but propagation and obligations are not mapped.
5. Cache or replica reads are shown without read-your-writes risk.
6. A write/delete flow touches regulated data without an audit flow.
