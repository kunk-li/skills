# Common failure modes — data-flow-mapping

## F1: only happy path mapped
Symptom: the flow diagram shows the success path but omits retry, fallback, compensation, DLQ, and error recovery.
Fix: every primary flow must explicitly check exception paths. At minimum: what happens on DB write failure, on event publish failure, on consumer crash mid-processing, and on duplicate delivery.

## F2: vague topology
Symptom: the flow says "system A calls system B" without specifying direction, protocol, sync/async, or data classification.
Fix: every flow step must have `action`, `storage_write/read`, `tx_kind`, and `on_failure`. Topology means knowing which system writes, which reads, and in which order.

## F3: sensitive data propagation unmapped
Symptom: PII flows through the system (user email → audit event → export job) but the data classification is only labeled at the source.
Fix: trace sensitive data through every flow step. `data_classification` must be declared per flow, not just per table. Include masking rules at each hop.

## F4: provisional flows mixed with confirmed
Symptom: some flows are confirmed by API spec or DB schema evidence; others are assumed from PRD text — but they look identical in the output.
Fix: mark every flow's `confidence: confirmed | inferred | pending`. Inferred flows must cite the assumption. Pending flows must state what evidence is needed.

## F5: index and schema changes invented
Symptom: the data flow analysis recommends adding a new DB index or changing a table schema to support the flow.
Fix: 048's boundary ends at describing flows. Schema changes go to 046; index changes go to 047. Emit a `downstream_handoff.to_046_schema` or `to_047_index` hint instead.

## F6: DLQ paths omitted in event-heavy systems
Symptom: async event consumers are shown consuming from a topic, but there is no dead-letter queue flow for failed messages.
Fix: every async consumer must have a DLQ or equivalent handling path. Model it as a `dead_letter` flow type with `on_failure`, `retry_policy`, and `alert` fields.

## F7: transaction boundaries absent on cross-service writes
Symptom: a flow writes to two services' databases in sequence but `tx_kind` is not set and no saga or outbox is mentioned.
Fix: cross-service writes cannot use local DB transactions. Every cross-service write must declare: `transaction_scope: saga | outbox | eventual_consistent` with compensation steps.

## F8: cache reads without consistency risk
Symptom: a read replica or Redis cache is shown in a flow but no read-your-writes risk or staleness window is documented.
Fix: every cached or replicated read must include `cache_risk` with `staleness_window` and `read_your_writes_violation: true/false`. Reference `read-write-cache-semantics.md`.
