# Output Template: Data Flow Mapping

## 1. Objective
- scope
- selected_mode
- readiness
- stage_position

## 2. Evidence Profile
| source | what it confirms | remaining uncertainty |

## 3. Flow Scope and Lifecycle View
| object or use case | lifecycle stage | notes |

## 4. Flow Catalog
| flow_id | flow_category | flow_semantics | source | target | payload | trigger | topology | sync_or_async | storage_touchpoints | data_classification | flow_metrics | reliability_notes | evidence | confidence |

## 5. Flow Diagram
Use ASCII by default. Add Mermaid only when it adds clarity.

## 6. Exception Path Coverage
| use case | happy_path | retry | fallback | compensation | dead_letter | replay | notes |

## 7. Gaps and Risks
| gap_id | area | why it matters | suggested next step |

## 8. Downstream Handoff
| consumer | what to read | why |

## 9. Self-Check
Summarize checklist and scoring outcomes.


## 10. N160 v2 Contract Addendum

For implementation-ready output, include:

- `flow_kind` with happy, retry, rollback, dlq, audit, archival, backup, replication, or reconciliation semantics.
- `steps[]` for every important flow.
- step-level `transaction_boundary` and `on_failure`.
- `read_write_separation` when replicas or cache are relevant.
- `data_lifecycle` from creation to archival or deletion.
- `compliance_obligations` for sensitive data.

Storage references must use 046 `table_id` values.
