# Compliance Obligation Mapping

Map data classification to required flow checks.

| sensitivity | obligations |
| --- | --- |
| pii | deletion path, access control, masking, minimization, export audit |
| pci | tokenization, no raw PAN persistence, encrypted transit, access audit |
| phi | encrypted transit and rest, access log, minimum necessary access |
| financial | immutable audit trail, retention policy, approval traceability |
| confidential | access control, logging minimization, retention decision |

## Output block

```yaml
compliance_obligations:
  - obligation_id: string
    triggered_by:
      type: sensitivity_class | rule_ref | regulation
      value: string
      regulation: GDPR | CCPA | PCI-DSS | HIPAA | SOX | null
    affected_flows: [flow_id]
    required_path: deletion | masking | audit | tokenization | retention | access_log
    status: satisfied | missing | not_applicable | pending
    evidence: string
```

Rules:

- If a flow touches PII, check whether a deletion or anonymization path exists.
- If a write or delete touches regulated data, require an audit flow.
- Missing obligations must appear in `gaps_and_risks` and `open_questions`.


Compatibility note:
- Older scalar `triggered_by` values are still readable, but v2-compatible output should use the object form above.
- `triggered_by.regulation` is optional. Use `null` when the obligation is derived from sensitivity or an internal rule rather than a named regulation.
