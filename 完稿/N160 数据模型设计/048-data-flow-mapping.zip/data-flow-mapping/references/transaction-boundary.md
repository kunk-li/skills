# Transaction Boundary Contract

Use this contract for every step in `flow_catalog[].steps[]`.

```yaml
transaction_boundary:
  in_same_tx_as: [step_number]
  commit_point: true | false
  tx_kind: local | distributed_saga | outbox | none
  on_rollback:
    action: full_rollback | compensate | partial_commit_accepted | not_applicable
    compensation_flow_id: string | null
```

Hard rules:

- Every step must declare a transaction boundary or explicitly mark `tx_kind: none`.
- Cross-service writes should use `distributed_saga` or `outbox`; do not recommend 2PC by default.
- Any step with `action: write | update | delete | publish_event` must declare its commit point or outbox relation.
- If rollback behavior is unknown, mark `readiness: blocked` for that flow or add an open question.
