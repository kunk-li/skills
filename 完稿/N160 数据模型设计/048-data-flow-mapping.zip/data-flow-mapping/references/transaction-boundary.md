# Transaction Boundary Contract

Use this contract for every step in `flow_catalog[].steps[]`.

```yaml
transaction_boundary:
  in_same_tx_as: [step_number]
  commit_point: true | false
  tx_kind: local | distributed_saga | outbox | none
  on_rollback:
    action: full_rollback | compensate | partial_commit_accepted | not_applicable
    compensation_flow_id: string | null
  cross_store_ordering: protective_side_effect_first | business_commit_first_then_best_effort | not_applicable
  secondary_store_kind: session_store | cache | message_queue | external_side_effect | best_effort_telemetry | none
  secondary_is_reversible: true | false
  accepted_intermediate_state: string        # required when cross_store_ordering != not_applicable
  reconciliation: reconcile_replay | compensation | none_safe_by_direction
```

Hard rules:

- Every step must declare a transaction boundary or explicitly mark `tx_kind: none`.
- Cross-service writes should use `distributed_saga` or `outbox`; do not recommend 2PC by default.
- Any step with `action: write | update | delete | publish_event` must declare its commit point or outbox relation.
- If rollback behavior is unknown, mark `readiness: blocked` for that flow or add an open question.
- R07 cross-store ordering: a step whose state change must land on both a transactional store and a non-transactional secondary store (different engines, no shared transaction) must declare `cross_store_ordering` + `accepted_intermediate_state`. Reject if it claims a single atomic no-intermediate-state across both stores, or nests an irreversible secondary-store mutation inside a rollbackable primary transaction (rollback cannot undo it). Pick a fail-safe direction: `protective_side_effect_first` (protective effect lands before the business commit — over-applying is acceptable, missing it is not, e.g. revoke/block before persisting the restriction), or `business_commit_first_then_best_effort` (commit business, then best-effort secondary write + named reconciliation — only when the secondary effect is compensable / eventually consistent). Single-store steps, best-effort droppable telemetry, and the audit trail (defer durability to 051 R08) are `not_applicable`. Distinct from cross-service tx_kind (federation) and from 049 (concurrent-actor races): this is one actor's sequential two-store commit ordering.
