# Compatibility map — data-flow-mapping v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 046 table-schema-design-recommendation | `table_id, store_type, pii_fields` | `storage touchpoints` | ALL flow steps must reference 046 table_ids |
| 043 api-design-recommendation | `api_catalog[].request/response` | `trigger and outcome mapping` | API calls become flow trigger and result steps |
| 049 concurrency-control-recommendation | `concurrency_designs[], locking_strategy` | `transaction boundary design` | concurrency designs inform flow transaction scope |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 049 concurrency-control-recommendation | `concurrent access paths, contention points` | `scenario classification` | concurrent flow paths seed S01-S12 classification |
| 050 idempotency-design-recommendation | `async/retry flows` | `channel coverage` | retry and compensation flows define idempotency channels |
| N300 monitoring | `metrics[], alerting rules` | `SLI/SLO definitions` | flow metrics become monitoring dashboards |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
