# Delivery checklist — data-flow-mapping

## A. flow catalog completeness
- [ ] Happy path covered for every primary use case
- [ ] At least one exception path covered per primary flow (or `not_applicable` with reason)
- [ ] Flow types declared: `creation | update | sync | retry | compensation | consumption | dead_letter | archival | audit`

## B. step-level structure
- [ ] Every flow has step-level breakdown with: `step_id`, `action`, `storage_touchpoint` (using 046 `table_id`), `tx_kind`, `on_failure`
- [ ] `tx_kind` uses canonical enum: `local | saga | outbox | eventual_consistent | none`
- [ ] No storage reference uses display name — must use `table_id` from 046

## C. transaction boundaries
- [ ] Every cross-service write declares: `transaction_scope`, saga/outbox/eventual mechanism, compensation steps
- [ ] Local transactions do not span service boundaries
- [ ] `transaction_boundary.md` guidance applied

## D. data classification
- [ ] Sensitive data (PII/PCI/PHI/financial) traced through every hop
- [ ] `data_classification` declared per flow (not just at source table)
- [ ] Masking and propagation rules explicit at each hop

## E. cache and replica consistency
- [ ] Cache reads include: `staleness_window`, `read_your_writes_violation`, `mitigation`
- [ ] Read replicas include lag estimate and consistency contract
- [ ] `read-write-cache-semantics.md` applied

## F. compliance obligations
- [ ] Regulatory obligations mapped from `compliance-obligations.md`
- [ ] Flows touching regulated data have audit flow or gap documented
- [ ] `compliance_obligations[]` present in output

## G. observability
- [ ] Key flows have `metrics[]` (counter, gauge, or histogram)
- [ ] At least one alerting rule per critical flow
- [ ] DLQ depth metric present for every async consumer

## H. downstream handoff
- [ ] `downstream_handoff` references 046 for schema gaps, 047 for index hints, N170 for NFR needs

## One-vote rejection items
- [ ] Storage step uses display name instead of `table_id`
- [ ] Cross-service write without saga/outbox declaration
- [ ] DLQ path absent for async consumers in event-heavy system
