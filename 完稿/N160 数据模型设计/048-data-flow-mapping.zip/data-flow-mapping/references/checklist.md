# Checklist

- happy path is covered
- at least one relevant exception path is covered or marked not_applicable
- every flow has semantics and topology
- sensitive data classes are labeled
- key flows have metrics or clear estimates
- storage touchpoints align with 046 naming
- access-path hints handed off to 047 when needed
- gaps and risks are explicit


## N160 v2 checks

- every storage touchpoint references a valid 046 table_id
- every key flow has step-level structure
- every step has transaction_boundary or tx_kind none
- every step has on_failure behavior or a not-applicable explanation
- cross-service writes use Saga, event, or outbox semantics by default
- every write or delete touching regulated data has an audit flow or gap
- PII, PCI, PHI, financial, and confidential data propagation is mapped
- read replica and cache consistency risks are explicit
- compliance obligations are satisfied or listed as missing
