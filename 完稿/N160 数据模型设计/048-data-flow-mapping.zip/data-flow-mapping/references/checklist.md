# Delivery checklist — data-flow-mapping

## A. flow catalog completeness
- [ ] Happy path covered for every primary use case
- [ ] At least one exception path covered per primary flow (or `not_applicable` with reason)
- [ ] Flow types declared: `creation | update | sync | retry | compensation | consumption | dead_letter | archival | audit`

## B. step-level structure
- [ ] Every flow has step-level breakdown with: `step_id`, `action`, `storage_touchpoint` (using 046 `table_id`), `tx_kind`, `on_failure`
- [ ] `tx_kind` uses canonical enum: `local | saga | outbox | eventual_consistent | none`
- [ ] No storage reference uses display name — must use `table_id` from 046

## C. transaction boundaries
- [ ] Every cross-service write declares: `transaction_scope`, saga/outbox/eventual mechanism, compensation steps
- [ ] Local transactions do not span service boundaries
- [ ] `transaction_boundary.md` guidance applied
- [ ] Every step writing both a transactional store and a non-transactional secondary store declares `cross_store_ordering` + fail-safe direction + accepted intermediate state; no step claims atomic no-intermediate-state across the two, and no irreversible secondary-store mutation sits inside a rollbackable transaction (R07; best-effort telemetry and single-store steps are not_applicable)

## D. data classification
- [ ] Sensitive data (PII/PCI/PHI/financial) traced through every hop
- [ ] `data_classification` declared per flow (not just at source table)
- [ ] Masking and propagation rules explicit at each hop

## E. cache and replica consistency
- [ ] Cache reads include: `staleness_window`, `read_your_writes_violation`, `mitigation`
- [ ] Read replicas include lag estimate and consistency contract
- [ ] `read-write-cache-semantics.md` applied
- [ ] For each value bound at a decision step (lock/snapshot/freeze), every downstream approve/execute/pay/reconcile step reads the persisted `snapshot_field`, not a live re-read; any intended live read of a bound value is flagged `live_read_is_by_design` with rationale (R06)

## E2. cross-artifact single source of truth
- [ ] Every business threshold/limit/boundary value, persisted structure definition (schema fields/columns), and mechanically-derived key that appears in ≥2 artifacts — across different types (application-code constant, deploy/migration script, workflow-engine condition, DDL, front-end template) or the same type (the same business threshold / control-basis defined as a `private static final` in ≥2 Java classes; same-language copies are not exempt) — declares a `single_source_ref` and how each copy derives from it; copies with no single source and free to drift independently are rejected (R08), including a control-basis literal scattered across ≥2 independent copies alongside a `@deprecated` old value or a comment trail of an up/down revision (control_basis_literal_drift)
- [ ] No runtime-overridable source coexists with a hard-coded literal copy that does not follow it; no persisted structure is split across parallel authoritative artifacts left for manual reconciliation (require: entity field set ⊆ authoritative-schema column set + single authoritative landing point for structure changes)
- [ ] Any attribute whose legal values are derived from a related attribute enforces the bidirectional invariant at every write entry, and the downstream read/admit check granularity (per-element vs aggregate key) matches the write-side assignment granularity (R08)
- [ ] A value/structure with exactly one authoritative definition referenced via a shared constant/enum/import is single-source reuse, not flagged (R08 not_applicable)

## F. compliance obligations
- [ ] Regulatory obligations mapped from `compliance-obligations.md`
- [ ] Flows touching regulated data have audit flow or gap documented
- [ ] `compliance_obligations[]` present in output

## G. observability
- [ ] Key flows have `metrics[]` (counter, gauge, or histogram)
- [ ] At least one alerting rule per critical flow
- [ ] DLQ depth metric present for every async consumer

## H. downstream handoff
- [ ] `downstream_handoff` references 046 for schema gaps, 047 for index hints, N170 for NFR needs

## One-vote rejection items
- [ ] Storage step uses display name instead of `table_id`
- [ ] Cross-service write without saga/outbox declaration
- [ ] DLQ path absent for async consumers in event-heavy system
