# Composition Contract

Stable output names:
- `flow_scope`
- `data_lifecycle_views`
- `flow_catalog`
- `flow_diagram`
- `exception_path_coverage`
- `data_classification_summary`
- `flow_metrics_summary`
- `gaps_and_risks`
- `downstream_handoff`

Composition notes:
- consumes 046 schema names and 047 access-path hints
- feeds dependency, consistency, testing, monitoring, and N170 design


## N160 shared contract

- Consume 046 table ids as the storage universe.
- Consume 047 access-path hints only as performance context; do not redefine indexes.
- Emit `storage_touchpoints[]` using 046 `table_id` values.
- Emit transaction and failure semantics needed by N170 concurrency, idempotency, audit, security, and compliance design.
- Unknown table references are blocking consistency failures.

See `references/n160-shared-naming.md`.
