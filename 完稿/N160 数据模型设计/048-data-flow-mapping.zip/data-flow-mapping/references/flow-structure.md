# Flow Structure Guide

Recommended order:
1. flow scope
2. lifecycle view
3. flow catalog
4. diagram
5. exception coverage
6. gaps and risks
7. downstream handoff

Diagram rule:
- use stable names from upstream schemas / APIs / events
- use one notation style consistently
- label sync vs async vs batch where it matters


## N160 v2 step structure

```yaml
steps:
  - step_number: integer
    step_name: string
    actor:
      kind: service | database | cache | queue | external_api | scheduler
      id: string
    action: read | write | update | delete | publish_event | consume_event | invoke_api | compute | validate | transform | enrich
    data_involved:
      source: table_id | api_ref | event_ref | external_system_ref
      fields: []
      sensitivity_classes: []
    transaction_boundary: {}
    consistency_guarantee: strong | eventual | read_your_writes | monotonic_read
    latency_budget: string | unknown
    on_failure: {}
```

For flows with more than five steps or cross-service writes, add Mermaid sequence and data-flow diagrams.
If a flow contains a state machine reference (`state_machine_ref` exists), append a Mermaid `state_diagram`.
