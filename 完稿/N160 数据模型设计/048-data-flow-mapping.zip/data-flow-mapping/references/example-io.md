# Example I/O

## Example input
- Ticket approval system: submit → approve → audit event → HR callback
- Tables: tickets, approval_steps, audit_events
- APIs: POST /tickets (create), POST /tickets/{id}/approval (decide)

## Good output sketch

```yaml
flow_catalog:
  - flow_id: FLOW-TICKET-CREATE
    flow_type: creation
    description: Employee creates a ticket draft and submits for approval
    trigger: POST /api/v1/tickets
    transaction_scope: local
    steps:
      - step_id: S01
        action: validate business rules (balance, overlap)
        storage_write: [TBL-TICKET-001]
        tx_kind: begin
        on_failure: rollback + return 422 with error code
      - step_id: S02
        action: publish order.created event to message bus
        storage_write: [outbox_events table]
        tx_kind: commit with outbox
        on_failure: outbox relay retries with exponential backoff; idempotency key prevents duplicate events
    exception_paths:
      - scenario: DB write succeeds, event publish fails
        handling: outbox pattern ensures at-least-once delivery; downstream must be idempotent
      - scenario: duplicate request (same idempotency key)
        handling: IDEM-001 deduplication; return cached 200 or 201

  - flow_id: FLOW-APPROVAL-DECIDE
    flow_type: update
    description: Manager approves or rejects a pending step
    trigger: POST /api/v1/tickets/{id}/approval
    transaction_scope: local
    steps:
      - step_id: S01
        action: state machine guard — reject if ticket not SUBMITTED
        storage_read: [TBL-TICKET-001]
        on_failure: return 409 TICKET_INVALID_STATE
      - step_id: S02
        action: write approval decision and update ticket status
        storage_write: [TBL-APPROVAL-001, TBL-TICKET-001]
        tx_kind: local transaction
        on_failure: rollback
      - step_id: S03
        action: write audit event
        storage_write: [TBL-AUDIT-001]
        tx_kind: separate append — no rollback; idempotent write
        on_failure: log + retry; failure does not block approval
      - step_id: S04
        action: trigger HR callback if final approval
        tx_kind: async outbox
        on_failure: outbox relay retries; HR system must accept idempotent callbacks

data_classification:
  - flow_id: FLOW-TICKET-CREATE
    sensitive_fields:
      - field: subject
        classification: internal_confidential
        propagation: stored in tickets table; not forwarded to HR callback raw
  - flow_id: FLOW-APPROVAL-DECIDE
    sensitive_fields:
      - field: reason
        classification: internal_confidential
        propagation: stored in approval_steps; masked in audit payload to actor_id only

compliance_obligations:
  - regulation: SOC2 CC7
    flow_ref: FLOW-APPROVAL-DECIDE
    obligation: all approval decisions must generate an audit event
    status: planned
    gap: none — S03 covers this
```

## ex-002 · DLQ and metrics flows — extended example

```yaml
  - flow_id: FLOW-AUDIT-DLQ
    flow_type: dead_letter
    description: Failed audit event writes are routed to DLQ for manual review and replay
    trigger: audit event publish fails after 3 retries
    transaction_scope: n/a (async, post-commit)
    steps:
      - step_id: S01
        action: event relay detects publish failure after max retries
        storage_write: [dlq_audit_events table]
        tx_kind: none (fire-and-forget insert to DLQ table)
        on_failure: log + ops alert; do NOT block original flow
      - step_id: S02
        action: ops team manually reviews DLQ, triggers replay
        storage_write: [audit_events via replay job]
        tx_kind: idempotent append (AUDIT-001 idempotency key)
        on_failure: escalate to compliance team

  - flow_id: FLOW-ORDER-CACHE
    flow_type: sync_reconciliation
    description: Redis cache for order status; risk of read-your-writes violation after write
    trigger: GET /orders/{id}/status immediately after POST /orders/{id}/approval
    steps:
      - step_id: S01
        action: approval writes to DB (order status updated)
        storage_write: [TBL-TICKET-001]
        tx_kind: local
      - step_id: S02
        action: cache invalidation via DELETE orders:{id}
        storage_write: [Redis cache]
        tx_kind: best-effort (fire after DB commit)
        on_failure: cache serves stale data for up to TTL duration
    cache_risk:
      scenario: cache invalidation lost (Redis unavailable)
      window: up to 60s TTL
      read_your_writes_violation: true
      mitigation: "POST response includes updated status; client should prefer response body over cache for immediate next read"

observability_notes:
  - flow_id: FLOW-TICKET-CREATE
    key_metrics:
      - metric: flow_step_duration_ms{step="S01_validate"}
      - metric: flow_errors_total{flow="TICKET_CREATE", step="S02_outbox"}
      - metric: outbox_relay_lag_seconds
    alerting:
      - alert: OutboxRelayLagHigh
        condition: outbox_relay_lag_seconds > 30
        severity: warning
  - flow_id: FLOW-AUDIT-DLQ
    key_metrics:
      - metric: dlq_depth_gauge{queue="audit_events"}
      - metric: dlq_replay_attempts_total
    alerting:
      - alert: AuditDLQNonEmpty
        condition: dlq_depth_gauge > 0
        severity: critical
        reason: compliance obligation — all audit events must eventually be written
```

## ex-003 · blocked — missing API spec and schema

```yaml
skill_name: data-flow-mapping
readiness: blocked
blocker_mapping: B-N160-03
route_back_to: table-schema-design-recommendation

blockers:
  - blocker_id: BLK-FLOW-001
    type: missing_schema
    description: "Cannot map flow steps to storage touchpoints without confirmed table schemas from 046"
    impact: "Flow steps referencing TBL-TICKET-001 cannot use stable table_id — will cause schema drift in downstream consumers"
    resolution_required: "046 must produce confirmed table catalog before flow mapping"
    unblock_evidence: "046 output with readiness: ready and all table_ids confirmed"

  - blocker_id: BLK-FLOW-002
    type: missing_api_spec
    description: "No 接口设计草案.yaml — cannot map API trigger → flow steps accurately"
    impact: "Flow triggers are speculative; transaction boundaries may be wrong (sync vs async)"
    resolution_required: "043 api-design-recommendation must complete before flow mapping"
    unblock_evidence: "接口设计草案.yaml with at least the primary write endpoints defined"

partial_flows:
  note: "Skeleton flows provided for N130 architecture validation only — not for production use"
  flows:
    - flow_id: FLOW-TICKET-CREATE-SKELETON
      confidence: inferred
      storage_refs: ["TBL-TICKET-001 (provisional — table_id not yet confirmed)"]
      warning: "DO NOT use this flow in N180 planning until blockers resolved"
```

## ex-004 · degraded — flow mapping from architecture description only

```yaml
skill_name: data-flow-mapping
readiness: provisional
selected_mode: architecture_sketch
evidence_profile:
  confirmed: [TSA-001 architecture description]
  inferred: [all flow steps derived from component description prose]
  pending: [table schemas from 046 (for table_id references), API spec from 043 (for trigger endpoints)]

degraded_reason: "Neither 046 schema nor 043 API spec available — flow steps reference assumed table names"
degraded_impact: "table_id references are placeholders — will cause downstream integration failures if used as-is"

flows:
  - flow_id: FLOW-TICKET-CREATE-PROVISIONAL
    flow_type: creation
    confidence: inferred
    steps:
      - step_id: S01
        action: "POST /tickets — validate request (assumed REST endpoint)"
        storage_touchpoint: "leave_tickets table (PLACEHOLDER — awaiting 046 table_id)"
        tx_kind: local
        on_failure: "return 422 (assumed)"
        warning: "storage_touchpoint must be updated with confirmed table_id from 046"

pending_confirmations:
  - "Replace all PLACEHOLDER storage references with confirmed 046 table_ids"
  - "Replace all assumed endpoints with confirmed 043 API-### references"
  - "DLQ paths cannot be designed until async flows confirmed by 043"
```
