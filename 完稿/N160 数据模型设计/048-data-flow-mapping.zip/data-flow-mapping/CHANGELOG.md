# CHANGELOG

## v4.1.0 (2026-06-24) — cross-artifact single-source rule

_skill: data-flow-mapping_

### Added
- rule_results R08_cross_artifact_single_source_of_truth (severity: reject): same business threshold/limit/boundary value, persisted structure definition, or mechanically-derived key copied into ≥2 different artifact types (application code, deploy/migration script, workflow-engine condition, DDL, front-end template) with no compile/run-time consistency check must declare a single source of truth + per-site derivation; runtime-overridable source coexisting with a hard-coded literal copy → reject; persisted structure split across parallel authoritative artifacts left for human reconciliation → reject (require entity-field ⊆ authoritative-schema gate + single authoritative landing point); derived key without bidirectional invariant at every write entry, or read/admit granularity mismatching write-side assignment granularity → reject
- common-failure-modes F11 (same value/schema definition copied across artifact types with no single source of truth)
- checklist section E2 (cross-artifact single source of truth)

### Notes
- R08 is orthogonal to R06 (runtime single-value time-of-binding authority): R06 is the time dimension of one value instance within a run; R08 is the space dimension of one definition copied across artifact types. R08 is also orthogonal to R05 (flow must reference 046 table_id, which assumes a single source already exists) — R08 handles the upstream case of no single source at all. R08 deliberately excludes 'many distinct spec-family thresholds each defined once but lacking a central reconciliation registry' — that coverage-mapping concern stays in skill 032.

---

## v4.0.0 (2026-04-30) — v10 final optimization

_skill: data-flow-mapping_

### Added
- Trigger conditions + Standalone rule sections
- Confidence discipline (confirmed/inferred/pending separation)
- Downstream handoff summary
- Compatibility-map.md with field-level input/output mapping
- blocked + degraded example-io scenarios

### Changed
- Description trimmed to ≤25 words
- Quick-reference tables expanded to ≥4 per skill
- rule_results expanded to R01-R08

### Fixed
- CHANGELOG format standardized to `# CHANGELOG` header
- Chinese/English section headers unified to English

---

## v3.0.0 (2026-04-30) — v5 optimization batch

### Added
- common-failure-modes.md with Symptom/Fix format (F1–F8)
- workflow-position.md
- compatibility-map.md
- CHANGELOG.md

### Changed
- Checklist rewritten with inline `- [ ]` items
- example-io.md expanded with concrete YAML examples
- Description word count reduced

---

## v2.0.0 (2026-01-15) — v2 contract migration

### Added
- artifact_schema_version header
- produced_event field
- blocker_mapping field
- rule_results[] with pass|warn|reject|not_applicable
- feedback_signal_to_n005 reverse governance channel

---

## v1.0.0 (2025-10-01) — initial release
