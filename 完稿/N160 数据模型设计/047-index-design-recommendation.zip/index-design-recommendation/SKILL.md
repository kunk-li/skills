---
name: index-design-recommendation
description: recommend indexes from query patterns and table schemas. triggers on 表结构设计草案.sql or query pattern descriptions. always consumes 046 table_id references.
---
# index-design-recommendation


## Query pattern quick-reference
Match query pattern to index type before designing.

| Query pattern | Recommended index | Column order | Example |
|---|---|---|---|
| Equality filter on 1 column | single B-tree | the filtered column | `WHERE tenant_id = ?` → `(tenant_id)` |
| Equality + sort | composite B-tree | filter cols first, sort col last | `WHERE status=? ORDER BY created_at` → `(status, created_at)` |
| Equality + range | composite B-tree | equality cols first, range col last | `WHERE tenant_id=? AND created_at BETWEEN` → `(tenant_id, created_at)` |
| Soft-delete filter | partial index | column with WHERE clause | `WHERE is_deleted=0` → `PARTIAL (is_deleted=0)` |
| Uniqueness enforcement | unique B-tree | all unique columns | `UNIQUE (tenant_id, email) WHERE is_deleted=0` |
| Full-text search | FULLTEXT | text column | not a substitute for search engine |
| JSON field lookup | GIN (PostgreSQL) or virtual column | extracted field | prefer virtual column + B-tree over direct JSON index |
| Covering query (avoid table lookup) | covering composite | filter + sort + SELECT cols | `(status, created_at) INCLUDE (subject, owner_id)` |

## Index count governance
| Table write rate | Recommended max indexes | Action if exceeded |
|---|---|---|
| < 100/min | 8 indexes | no restriction |
| 100-1000/min | 5 indexes | review all non-critical indexes |
| 1000-10000/min | 3 indexes | only PK + critical business indexes |
| > 10000/min | 2 indexes | minimize to absolute minimum; consider partitioning |

## Index type quick-reference
| Index type | Use case | Cost signal |
|---|---|---|
| B-tree (default) | equality + range on low-cardinality to high-cardinality | standard write overhead |
| Composite B-tree | multi-column filter, covering index | column order matters: filter first, sort second, cover last |
| Unique | enforce uniqueness constraint | same as B-tree + write validation |
| Partial | filter on subset (e.g. `WHERE is_deleted = 0`) | smaller index, faster scans |
| Full-text | keyword search on text columns | not a replacement for search engine |
| JSON / GIN (PG) | JSON field queries | high write cost; use sparingly |
| Covering index | include all SELECT columns to avoid table lookup | reduces I/O; increases write cost |

## Index order rule
For composite indexes: **filter columns first, sort/order columns second, cover columns last.**
Example: query `WHERE status = 'active' ORDER BY created_at` → index `(status, created_at)`.

## Redundancy governance rules
- Never create an index that is a left-prefix of an existing index.
- Flag any index unused for >30 days in production as a removal candidate.
- Record `write_amplification_estimate` for every index on high-write tables (>10k inserts/min).


## Trigger conditions
Design database indexes when any of the following are present:
- table schema from 046 (`表结构设计草案.sql`)
- query pattern descriptions from API specs or code
- explicit index design or slow query investigation requests
- batch processing access patterns

## Standalone rule
Always consume 046 `table_id` references — never reference tables by display name. Without 046 output, infer table structure from available schema artifacts and set `readiness: provisional`.

## Role and boundary
本 skill 对齐技能总表中in the technical-solution-design -> 数据设计 -> 索引设计」。

它是 **decision_support** 型技能：核心不是直接改数据库，而是把“给出唯一索引、联合索引和查询索引建议”转成有依据、有取舍、有审计能力的决策产物。

### Boundary
- 止于方案、接口、数据与任务设计，不进入代码编写、测试执行和发布落地。
- 负责提出索引建议、解释读写权衡、指出冗余和缺失。
- 不直接创建或修改线上索引。
- 表结构本身、字段类型和主键策略优先由 `table-schema-design-recommendation` 定义。
- 流量和异常链路的语义说明优先由 `data-flow-mapping` 补足。

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 3 种模式：
- `pre-design`：基于 query patterns 和 046 的表结构做前置索引设计；默认模式。
- `audit-existing`：基于已有 schema、索引清单、usage stats 或 explain 结果做索引审计。
- `explain-driven-review`：围绕具体慢查询、EXPLAIN 或 rows examined 问题给修正建议。

## Primary inputs
### 推荐输入
- `query_patterns_input`
- 表结构设计结果、主键和唯一约束
- API 草案中的过滤、分页、排序和搜索场景
- 批处理、导出、同步、归档任务说明
- 已有 explain、慢查询、usage stats（如有）

### 可选增强
- 表规模预估、写入 TPS、读写比例
- retention / append-only / 高峰倍数
- 现有索引清单和冗余索引候选

## Standalone rule
可以单独使用，但没有 query patterns 时必须降级：
- 先从 API、报表、批量导出、列表页、检索需求中提 provisional patterns。
- 将这些模式明确标记为 `inferred_query_pattern`。
- 不能因为“怕漏加”就生成大量缺乏服务对象的索引。

## Core output contract
默认输出 Markdown，必要时附 CSV-like table。优先遵循 `references/output-template.md` 与 `references/query-pattern-contract.md`。

结果至少包含：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: decision_support`
  - `stage_position: technical_solution_design.data_design.index_design`
  - `evidence_profile`
- `query_patterns_summary`
- `index_catalog[]`
  - `idx_id`
  - `table_name`
  - `index_name`
  - `columns`
  - `index_type`
  - `index_purpose`
  - `query_patterns_served`
  - `composite_order_rationale`
  - `uniqueness`
  - `write_cost_note`
  - `storage_cost_note`
  - `evidence`
  - `confidence`
- `covering_index_analysis[]`
- `deferred_or_rejected_indexes[]`
- `cost_model`
- `index_count_audit`
- `validation_plan`
- `open_questions[]`
- `downstream_handoff`
- `self_check`

## Design rules
### Query-first rule / 查询模式优先
每个索引都必须服务至少一个已知 query pattern、join path、sort path、batch path 或 uniqueness rule。

若一个索引不服务任何明确模式：
- 默认进入 `deferred_or_rejected_indexes`
- 不要因为“以后可能有用”而默认保留

### Read-write cost discipline / 读写权衡纪律
对每个索引都要给出：
- `read_benefit`
- `write_cost`
- `storage_cost`（定性或估计）

对高写入表必须更克制：
- append-only / audit / event 类表，要特别警惕索引膨胀
- 若写入 TPS 很高，优先保核心检索路径，延后低收益索引

### Composite order discipline / 复合索引顺序纪律
默认使用以下顺序规则：
1. 等值列优先
2. 等值列内部高选择性优先
3. 范围 / 排序列靠后
4. 覆盖列只在收益明确时追加到尾部

输出中必须给出 `composite_order_rationale`，不能只报一个列组合。

### Covering index discipline / 覆盖索引纪律
当查询返回列较少且访问频繁时，主动检查覆盖索引机会。
但不要为了“全覆盖”把索引扩成宽索引怪物。

### Count and redundancy discipline / 数量与冗余纪律
每张表都要做 `index_count_audit`：
- 检查冗余前缀索引
- 检查长期未使用索引（若有证据）
- 检查表总索引数是否超过合理水平

### Boundary discipline / 边界纪律
- 不要重新发明表结构或字段类型；缺字段时回推给 046。
- 不要把流量语义和异常链路全部在本 skill 里讲完；交给 048。
- 不要把 DBA 执行步骤伪装成已落地变更。

## Execution workflow
1. 识别 selected mode 与 evidence profile。
2. 归一 query patterns，标注 confirmed / inferred。
3. 对齐 046 中的表名、列名、主键与唯一约束。
4. 为高频点查、范围查、排序、join、batch、aggregate 场景设计索引。
5. 为每条索引写清楚 service pattern、顺序理由和读写成本。
6. 扫描 covering 机会。
7. 扫描冗余索引、未使用索引和过度索引表。
8. 形成 validation plan（EXPLAIN / usage / rows examined / p99 验证）。
9. 输出 handoff 给查询优化、性能评审、048 流分析和 N200 SQL 草稿。
10. 运行 checklist 与 common-failure review。

## Dynamic completeness
- 单功能：覆盖全部关键查询路径
- 中等系统：覆盖全部高频路径 + 高风险批任务
- 大型系统：优先覆盖核心读写链路，低频路径可进入 deferred section

## Quality bar
合格结果应使 reviewer 能回答：
- 这个索引到底服务什么查询
- 它的写入代价是否值得
- 列顺序是否合理
- 是否存在冗余或过度索引

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/query-pattern-contract.md`
- `references/cost-model-guide.md`
- `references/composition-contract.md`

## Reference files
- `references/output-template.md`
- `references/query-pattern-contract.md`
- `references/cost-model-guide.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`


## N160 v2 optimization layer

Use this layer when the skill is composed with 046 and 048 inside N160 or when the caller asks for implementation-ready index design.

### Contract-first inputs

Prefer this input shape:

```yaml
tables: from 046 table_catalog, keyed by table_id
query_patterns: explicit or inferred access paths
stack_declaration: inherited from 046
volume_projection: inherited from 046 when available
existing_indexes: optional
sensitivity_map: inherited from 046 columns
flow_hints: optional, from 048
```

### Enhanced output contract

In v2-compatible output, use this index item shape:

```yaml
index_catalog:
  - idx_id: IDX-[A-Z]+-[0-9]{3,}
    table: DB-[A-Z]+-[0-9]{3,}
    index_name: string
    index_type: btree | hash | gin | gist | fulltext | spatial | bitmap
    columns:
      - column_name: snake_case
        order: ASC | DESC
        position: integer
    unique: true | false
    covering_index:
      enabled: true | false
      included_columns: []
      rationale: string
    partial_index:
      enabled: true | false
      where_clause: string | null
      rationale: string | null
    serves_queries: []
    cost_analysis:
      storage_cost:
        estimated_size_mb: integer | unknown
        growth_per_month_mb: integer | unknown
      write_overhead:
        insert_cost: negligible | small | moderate | high
        update_cost: none | when_indexed_column_changes
        percentage_writes_affected: number | unknown
      read_benefit:
        queries_accelerated: integer
        average_speedup: string | unknown
        p99_improvement: string | unknown
      net_benefit: strongly_positive | positive | neutral | negative
    partition_interaction: see references/partition-index-contract.md
    sensitive_index_handling: see references/pii-indexing.md
```

### Additional design rules

- `index_catalog[].table` must equal a 046 `table_id`.
- Every indexed column must exist in the matching 046 table.
- For partitioned tables, include `partition_interaction`.
- For PII, PCI, PHI, financial, or confidential fields, use `sensitive_index_handling`; avoid plain-text indexes unless a waiver is explicit.
- Scan for N plus one risks using `references/n-plus-1-patterns.md`.
- Keep human names as display fields only; do not use them as join keys.

### Additional references

- `references/n160-shared-naming.md`
- `references/partition-index-contract.md`
- `references/n-plus-1-patterns.md`
- `references/pii-indexing.md`


## Confidence discipline
Every index recommendation must declare the certainty of its serving patterns:
- `query_confidence: confirmed` — query pattern observed in production code or query logs
- `query_confidence: inferred` — derived from API contract or feature description; estimated access pattern
- `query_confidence: pending` — requires query log analysis before index can be justified

Inferred indexes must include `write_amplification_estimate`. Pending indexes are listed as candidates only.
## v2 artifact contract

```yaml
artifact_schema_version: n160.index-design.v2.1.0
skill_name: index-design-recommendation
produced_event: produced.n160.index_design.v2
blocker_mapping: B-N160-02
readiness: ready | provisional | blocked
rule_results:
  - rule_id: R01_every_index_has_query_pattern_ref
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_redundant_indexes_identified
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R03_write_amplification_assessed
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R04_table_ids_from_046_used
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R05_pii_columns_not_indexed_plaintext
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R06_write_amplification_on_high_write_tables
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R07_pii_index_waiver_required
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R08_redundancy_audit_complete
    severity: warn
    result: pass | warn | reject | not_applicable
route_back_to: none | n160-schema
# none        — index design complete; N160 package ready
# n160-schema — index requires column not declared in 046; revise 046 first
feedback_signal_to_n005:
  signal_type: none | index_smell_detected | query_pattern_signal
  summary: ""
  target_n070_skills:
  - 017-data-object-identification
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
eventbus_subscribers: [N260]
# N260 → 索引设计输出触发查询性能专项测试计划
```

## Upstream linkage from N070

| upstream artifact | consume fields | maps to |
|---|---|---|
| `数据对象目录.md` (017) | constraint_tags: read_heavy, write_heavy, cache_friendly | index strategy bias |
| `业务规则清单.md` (014) | temporal rules, rate_limit rules | time-range index candidates |
| `权限矩阵.csv` (016) | grain=field, pii handling | pii-indexing constraints |
