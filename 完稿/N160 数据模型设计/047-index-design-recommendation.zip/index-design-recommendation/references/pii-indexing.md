# PII Indexing Rule

Do not recommend plain-text indexes on sensitive fields without a protection decision.

## Output block

```yaml
sensitive_index_handling:
  column_name: string
  sensitivity_class: pii | pci | phi | financial | confidential
  recommended_shape: hash_index | deterministic_encrypted_index | token_index | avoid_index | waiver
  rationale: string
  leakage_risk: low | medium | high
```

Rules:

- For PII equality lookup, prefer hash or deterministic token indexes.
- For PCI, avoid raw PAN storage and raw PAN indexes.
- For free-text search over sensitive fields, route to security review before recommending an index.
- If a plain-text index is unavoidable, mark it as a waiver with owner and risk.
