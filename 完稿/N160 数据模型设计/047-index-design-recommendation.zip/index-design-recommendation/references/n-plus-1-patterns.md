# N Plus One Detection Patterns

Scan query patterns, API loops, ORM notes, and data-flow hints for N plus one risks.

## Common signals

- One list query returns N parent records, followed by one child query per parent.
- Query pattern names include `for each`, `loop`, `per item`, `per user`, or `per order`.
- API response includes nested children but the evidence only shows a parent index.
- Data-flow mapping shows repeated read steps inside a loop.

## Output block

```yaml
n_plus_1_risks:
  - risk_id: string
    parent_query: string
    repeated_child_query: string
    estimated_extra_queries: integer | unknown
    severity: low | medium | high
    recommended_fix: join | batch_in | prefetch_relation | materialized_view | cache
    index_support_needed: [idx_id]
```

## Fix guidance

- Use JOIN when cardinality is bounded and consistency must be immediate.
- Use `IN` batch loading when parent IDs are known and child rows are moderate.
- Use relation prefetch when the ORM supports predictable eager loading.
- Use cache or materialized view only when freshness requirements allow it.
