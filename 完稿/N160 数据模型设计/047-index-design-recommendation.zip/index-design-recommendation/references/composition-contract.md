# Composition Contract

Stable output names:
- `query_patterns_summary`
- `index_catalog`
- `covering_index_analysis`
- `cost_model`
- `index_count_audit`
- `validation_plan`
- `downstream_handoff`

Composition notes:
- consumes 046 table universe
- provides access-path evidence to 048 and performance review


## N160 shared contract

- Consume 046 `table_catalog[]` as the only table and column universe.
- Emit `index_catalog[].table` as a 046 `table_id`.
- Emit human-readable `table_name` only as a display helper.
- Return blocking gaps to 046 when required columns or unique constraints are missing.
- Provide access-path hints to 048 without redefining flow semantics.

See `references/n160-shared-naming.md`.
