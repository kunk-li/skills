# N160 Shared Naming Contract

Use this file when composing `table-schema-design-recommendation`, `index-design-recommendation`, and `data-flow-mapping` inside N160.

## Stable identifiers

| name | pattern | owner | consumed by |
| --- | --- | --- | --- |
| `table_id` | `DB-[A-Z]+-[0-9]{3,}` | 046 | 047, 048, N170, N190, N200 |
| `column_name` | `snake_case` | 046 | 047, 048, N200, docs |
| `idx_id` | `IDX-[A-Z]+-[0-9]{3,}` | 047 | 046 aggregation, N200, performance review |
| `flow_id` | `FLOW-[A-Z0-9-]+` or `FLOW-[0-9]{3,}` | 048 | 046 aggregation, N170, N230, monitoring |
| `object_ref` | `OBJ-[A-Z]+-[0-9]{3,}` | upstream N070 | 046, 048 |
| `service_ref` | `SVC-[A-Z0-9-]+` | upstream N140 | 046, 048 |
| `api_ref` | `API-[A-Z0-9-]+` | upstream N150 | 047, 048 |
| `rule_ref` | `RULE-[A-Z0-9-]+` | upstream N070 | 046, 048 |

## Cross-skill reference rules

1. 047 `index_catalog[].table` must equal one 046 `table_catalog[].table_id`.
2. 047 `index_catalog[].columns[].column_name` must exist in the matching 046 table.
3. 048 `flow_catalog[].storage_touchpoints[]` must use 046 `table_id`, not free-text table names.
4. 048 `flow_catalog[].steps[].data_involved.source` should use `table_id`, `api_ref`, `event_ref`, or `external_system_ref`.
5. Any 047 or 048 reference to an unknown table must fail self-check and be pushed back to 046.
6. If 046 renames a table or column, downstream skills must update references or mark the output `readiness: blocked`.

## Compatibility rule

Keep human-readable names in parallel fields such as `table_name` or `display_name`, but never use them as the machine join key.
