# Delivery checklist — index-design-recommendation

## A. query pattern coverage
- [ ] Every index references at least one explicit `serving_pattern` with query text or description
- [ ] All high-frequency queries have index coverage analysis
- [ ] N+1 risk patterns scanned from `references/n-plus-1-patterns.md`

## B. index design quality
- [ ] Composite index column order rationale stated (equality first, range/sort last)
- [ ] Covering index opportunities reviewed with `INCLUDE`/`covering` analysis
- [ ] Redundancy audit complete: `left_prefix_overlaps` checked

## C. write cost analysis
- [ ] `write_amplification_estimate` present for every index on tables with >1k inserts/min
- [ ] High-write tables have write/read trade-off explicitly documented
- [ ] Total index count per table noted with "too many indexes" warning if >6

## D. table-ID cross-reference
- [ ] Every index references a valid `table_id` from 046
- [ ] Every indexed column exists in the 046 DDL for that table
- [ ] Schema mismatches result in route-back hint to 046, not silent fill

## E. special index types
- [ ] Partial indexes used where appropriate (e.g. `WHERE is_deleted = 0`)
- [ ] Partition tables checked against `partition-index-contract.md`
- [ ] PII columns checked against `pii-indexing.md`; no plain-text index without waiver

## F. validation plan
- [ ] `validation_plan` present with: EXPLAIN targets, expected scan type, performance metric
- [ ] Drop recommendations include safety check (confirm zero active usage first)

## G. downstream handoff
- [ ] `downstream_handoff` includes reference to 048 for access-path hints

## One-vote rejection items
- [ ] Index without a serving query pattern
- [ ] Composite index column order not justified
- [ ] PII column indexed without waiver
- [ ] Table ID cross-reference failure not flagged
