# Checklist

- every index serves a real pattern or constraint
- query patterns are explicit and confidence-tagged
- composite order rationale is written
- write cost note included
- covering opportunities reviewed
- redundancy and count audit included
- missing table or field issues pushed back to 046
- validation plan included


## N160 v2 checks

- every index references a valid 046 table_id
- every indexed column exists in the matching 046 table
- every new index has structured cost_analysis
- partitioned tables include partition_interaction
- PII and regulated fields avoid plain-text indexes or include an explicit waiver
- top query patterns are reviewed for covering indexes
- N plus one risks are scanned and reported
- left-prefix redundancy is checked
