# Cost Model Guide

Estimate qualitatively or quantitatively:
- read_benefit: scan reduction, sort avoidance, join improvement
- write_cost: extra index maintenance per insert/update/delete
- storage_cost: key width, row count, replicas

Suggested interpretation:
- high read benefit + low write cost: strong recommend
- moderate benefit + moderate cost: conditional
- low benefit + high write cost: reject or defer


## N160 v2 structured cost model

```yaml
cost_analysis:
  storage_cost:
    estimated_size_mb: integer | unknown
    growth_per_month_mb: integer | unknown
  write_overhead:
    insert_cost: negligible | small | moderate | high
    update_cost: none | when_indexed_column_changes
    delete_cost: small | moderate | high | unknown
    percentage_writes_affected: number | unknown
  read_benefit:
    queries_accelerated: integer
    average_speedup: string | unknown
    p99_improvement: string | unknown
  net_benefit: strongly_positive | positive | neutral | negative
```

## Left-prefix redundancy algorithm

```text
for each pair of indexes A and B on the same table:
  if A.columns is a left prefix of B.columns:
    if A is unique and B is not unique:
      keep A for uniqueness
    else:
      flag A as redundant and recommend drop_this
```
