# Example I/O

## Example input
- Table schema: tickets (TBL-TICKET-001), audit_events (TBL-AUDIT-001)
- Query patterns:
  1. List tickets by tenant_id + status, ordered by created_at DESC
  2. Fetch ticket by public_id
  3. Export audit_events by occurred_at range for a given target_id

## Good output sketch

```yaml
index_catalog:
  - index_id: IDX-TICKET-001
    table_id: TBL-TICKET-001
    index_name: idx_tickets_tenant_status_created
    index_type: btree_composite
    columns: [tenant_id, status, created_at]
    column_order_rationale: tenant_id first (equality filter, highest cardinality partition); status second (equality filter); created_at last (sort/range)
    serving_patterns: [list tickets by tenant + status ordered by created_at]
    write_amplification_estimate: low — tickets table is read-heavy
    covering: false
    redundancy_check: no left-prefix overlap with existing indexes

  - index_id: IDX-TICKET-002
    table_id: TBL-TICKET-001
    index_name: uk_tickets_public_id
    index_type: unique
    columns: [public_id]
    serving_patterns: [fetch ticket by public_id (API lookup)]
    note: already defined as UNIQUE in DDL; listed here for completeness

  - index_id: IDX-AUDIT-001
    table_id: TBL-AUDIT-001
    index_name: idx_audit_target_occurred
    index_type: btree_composite
    columns: [target_id, occurred_at]
    column_order_rationale: target_id (equality filter); occurred_at (range scan for export)
    serving_patterns: [export audit_events by target_id + date range]
    write_amplification_estimate: HIGH — audit_events is append-only high-write table; monitor index size growth
    recommendation: if write rate exceeds 5k/s, consider dropping and using partition pruning instead

redundancy_audit:
  checked: true
  overlaps_found: none

validation_plan:
  - run EXPLAIN SELECT on all 3 query patterns after index creation
  - confirm idx_tickets_tenant_status_created uses range scan (not full-index scan) for status filter
  - monitor audit_events index size weekly for first month
```

## ex-002 · negative cases — common index mistakes

```yaml
negative_cases:
  - case_id: NEG-047-001
    title: "Wrong composite index column order"
    table_id: TBL-TICKET-001
    bad_index:
      name: idx_tickets_bad
      columns: [created_at, tenant_id, status]
      query: "WHERE tenant_id = ? AND status = 'active' ORDER BY created_at DESC"
      problem: "created_at is range/sort — putting it first makes index useless for the equality filters. MySQL must scan entire created_at range."
    correct_index:
      name: idx_tickets_tenant_status_created
      columns: [tenant_id, status, created_at]
      rationale: "Equality filters (tenant_id, status) first; sort column (created_at) last. MySQL uses equality to narrow, then sorts within the matched rows."
      expected_explain: "type: range, key: idx_tickets_tenant_status_created"

  - case_id: NEG-047-002
    title: "Index on PII column without waiver"
    table_id: TBL-USER-001
    bad_index:
      name: idx_users_email
      columns: [email]
      problem: "email is PII — plain-text index exposes email values in index files, backups, and slow query logs. Violates R07_pii_index_waiver_required."
    correct_approach:
      option_a: "Index on hashed_email (SHA-256 with pepper) — lookup by hash, not plaintext"
      option_b: "Use opaque user token for lookups; email stored encrypted, never indexed"
      option_c: "Accept waiver with documented compensating control (encrypted disk, restricted backup access)"
      required_fields: [waiver_owner, compensating_control, review_date]

  - case_id: NEG-047-003
    title: "Redundant prefix index wastes write capacity"
    table_id: TBL-ORDER-001
    bad_indexes:
      - {name: idx_orders_a, columns: [tenant_id, status, created_at]}
      - {name: idx_orders_b, columns: [tenant_id, status]}  # LEFT-PREFIX DUPLICATE
    problem: "idx_orders_b is a left-prefix of idx_orders_a. MySQL will never use idx_orders_b when idx_orders_a exists and serves the same queries faster."
    correct_action:
      drop: idx_orders_b
      verification: "Run SHOW INDEX USAGE for 30 days; confirm idx_orders_b usage = 0 before dropping"
      write_amplification_saved: "~0.3ms per insert on orders table (estimated)"
```

## ex-003 · blocked — table schema not finalized

```yaml
skill_name: index-design-recommendation
readiness: blocked
blocker_mapping: B-N160-02
route_back_to: table-schema-design-recommendation

blockers:
  - blocker_id: BLK-IDX-001
    type: schema_not_finalized
    description: "TBL-TICKET-001 schema is marked as provisional in 046 — column list is incomplete and PII classification pending. Cannot design indexes on an unstable schema."
    impact: "Any index designed now may be invalid after schema revision. Composite index column order depends on confirmed column types."
    resolution_required: "046 must produce readiness: ready output before index design proceeds"
    unblock_evidence: "046 output with all columns confirmed and PII classified"

  - blocker_id: BLK-IDX-002
    type: missing_query_patterns
    description: "No API spec (接口设计草案.yaml) available — cannot derive query patterns from endpoint definitions"
    impact: "Index design without query patterns is speculative. High risk of designing indexes that serve no actual queries."
    resolution_required: "Either complete 043 api-design-recommendation, or provide explicit query pattern descriptions"
    unblock_evidence: "接口设计草案.yaml OR written query pattern descriptions (minimum: list endpoints + filter/sort fields)"

provisional_candidates:
  note: "Provisional index candidates listed for planning purposes only — DO NOT implement until blockers resolved"
  candidates:
    - table_id: TBL-TICKET-001
      index_name: idx_ticket_requester_status_provisional
      columns: [requester_id, status]
      confidence: inferred
      serving_pattern: "GET /tickets?requester_id=&status= (assumed from domain)"
```

## ex-004 · degraded — index design from query descriptions only (no schema)

```yaml
skill_name: index-design-recommendation
readiness: provisional
selected_mode: query_pattern_only
evidence_profile:
  confirmed: []
  inferred: [query patterns from API description prose, table structure assumed]
  pending: [table schema from 046 with confirmed table_ids and column types]

degraded_reason: "No 表结构设计草案.sql from 046 — indexes designed from query pattern descriptions only"
degraded_impact: "Index column types unverified; composite index column order based on assumed cardinality; no table_id cross-reference possible"

provisional_indexes:
  - table_name: "leave_tickets (PROVISIONAL — table_id TBD pending 046)"
    index_candidates:
      - index_name: idx_tickets_requester_status_PROVISIONAL
        columns: [requester_id, status, created_at]
        rationale: "Assumed from 'list my tickets filtered by status' query description"
        confidence: inferred
        warning: "Column order and types unverified — do not implement until 046 confirms schema"
        query_confidence: inferred

pending_confirmations:
  - "046 must confirm: column types, whether version column exists (needed for optimistic lock index)"
  - "DBA to review write amplification estimate on high-write tables"
  - "All provisional index names must be regenerated with confirmed table_ids"
```
