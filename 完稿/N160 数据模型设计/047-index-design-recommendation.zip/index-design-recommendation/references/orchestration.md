# Orchestration

## Upstream
Best inputs:
- table-schema-design-recommendation
- api-design-recommendation
- data-flow-mapping for batch/export flows
- slow query or explain evidence when auditing existing systems

## Downstream
Main consumers:
- query optimization recommendation
- performance risk analysis
- data-flow-mapping
- SQL draft generation / DBA review

## 047 -> 048 mapping
| 047 field | 048 usage |
| --- | --- |
| query_patterns_summary | identify read paths and batch flows |
| index_catalog | validate whether a flow has supporting access paths |
| write_cost_note | flag high-write pressure on flow hotspots |
| deferred indexes | mark potential future bottlenecks |


## N160 v2 node behavior

Run 047 after 046 when table shape is available. If 047 finds missing columns, unique constraints, or partition assumptions, return a blocking gap to 046 instead of inventing schema.

047 should feed 048 with access-path hints, high-write hotspots, and deferred index risks.
