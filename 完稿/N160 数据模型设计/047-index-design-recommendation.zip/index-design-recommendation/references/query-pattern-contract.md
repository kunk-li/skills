# Query Pattern Contract

Minimum fields per query pattern:
- pattern_id
- table or entity
- type: point_lookup / range / sort / join / aggregate / batch_read
- frequency or importance
- conditions
- sort_by
- returning columns
- latency requirement
- confidence

When exact frequency is unknown, use relative labels such as high / medium / low.


## N160 v2 query pattern fields

```yaml
query_patterns:
  - query_id: string
    table: DB-[A-Z]+-[0-9]{3,}
    description: string
    frequency: string
    where_conditions: []
    order_by: []
    group_by: []
    select_columns: []
    expected_row_count: integer | unknown
    latency_target: string | unknown
    source_api_ref: API-xxx | null
    evidence_level: confirmed | inferred | pending
```

Use 046 `table_id` for `table`.
