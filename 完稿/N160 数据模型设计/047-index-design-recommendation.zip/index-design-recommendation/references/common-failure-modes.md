# Common failure modes — index-design-recommendation

## F1: index without a serving query
Symptom: an index is recommended ("add index on user_id") but no query pattern, join path, or sort path is cited.
Fix: every index must reference at least one `serving_pattern` with the specific query it enables. No pattern, no index.

## F2: wrong composite column order
Symptom: index on `(created_at, status)` recommended when the query filters on `status = 'active'` and sorts by `created_at`.
Fix: composite column order rule — equality filter columns first, range/sort columns last. For `WHERE status = ? ORDER BY created_at`, the correct order is `(status, created_at)`.

## F3: covering index too wide
Symptom: a covering index includes 8+ columns "just in case" to avoid any table lookup.
Fix: covering indexes should include only the SELECT columns used by the specific high-frequency query. Every extra column adds write amplification. Document the trade-off.

## F4: high-write table overloaded
Symptom: an audit table receiving 5k+ inserts/min gets 4 new indexes without a write cost analysis.
Fix: include `write_amplification_estimate` for every index on high-write tables (>1k inserts/min). Consider deferring non-critical indexes or using partial indexes.

## F5: redundant prefix indexes ignored
Symptom: `idx_a_b_c` and `idx_a_b` both exist; the shorter one is a left-prefix duplicate and is never used.
Fix: run redundancy audit. A `redundancy_audit.overlaps_found` entry must appear in every output. Recommend dropping the redundant index.

## F6: schema holes silently filled
Symptom: an index references a column that doesn't exist in 046's schema, but the discrepancy is not flagged.
Fix: every index must reference a valid `table_id` from 046 and a column that exists in that table's DDL. Schema mismatches → route back to 046.

## F7: partition indexes ignore partition pruning
Symptom: a range index on `created_at` is recommended for a monthly-partitioned table, ignoring that partition pruning already handles the range.
Fix: check `partition-index-contract.md` before recommending range indexes on partitioned tables. The partition key often makes a redundant range index unnecessary.

## F8: PII columns indexed without waiver
Symptom: an index on `user_email` or `national_id` is recommended without noting the PII exposure risk.
Fix: PII and regulated columns must not be indexed in plain text without explicit waiver or tokenization. Reference `pii-indexing.md` and state the protection mechanism.
