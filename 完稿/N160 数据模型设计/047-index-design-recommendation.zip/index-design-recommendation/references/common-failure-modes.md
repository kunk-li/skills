# Common Failure Modes

- index created with no explicit query pattern served
- composite order chosen without equality/selectivity reasoning
- covering index expanded until it becomes too wide
- high-write table overloaded with low-value indexes
- redundant prefix indexes ignored
- schema holes silently filled instead of escalating back to 046


## N160 v2 failure modes

1. Index references a table name that cannot be joined to 046 `table_id`.
2. Index is recommended without a serving query, join path, sort path, or uniqueness rule.
3. Partitioned table indexes ignore partition pruning implications.
4. PII indexes are proposed in plain text without a waiver.
5. Write-heavy tables receive many low-benefit indexes.
6. N plus one evidence is present but not reported.
