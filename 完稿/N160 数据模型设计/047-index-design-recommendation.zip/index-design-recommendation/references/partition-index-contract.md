# Partition and Index Interaction Contract

Use this when a table from 046 is partitioned or might be partitioned.

```yaml
partition_interaction:
  table_is_partitioned: true | false | unknown
  partition_key: string | null
  is_local_index: true | false | unknown
  prefix_includes_partition_key:
    value: true | false | unknown
    rationale: string
  cross_partition_query_risk: none | low | medium | high | unknown
```

Rules:

- For partitioned tables, explain whether each major query prunes partitions.
- Prefer indexes that include the partition key when that helps pruning.
- Allow exceptions when the business query is naturally keyed by user, tenant, or external id.
- If cross-partition scans are unavoidable, add validation and monitoring notes.
