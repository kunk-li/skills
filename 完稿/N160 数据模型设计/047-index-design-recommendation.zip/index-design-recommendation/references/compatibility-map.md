# Compatibility map — index-design-recommendation v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| 046 table-schema-design-recommendation | `table_id, columns[], pk_strategy` | `index design canvas` | ALL indexes must reference valid 046 table_ids |
| 043 api-design-recommendation | `api_catalog[].request patterns` | `query pattern derivation` | API request parameters define filter/sort patterns |
| 048 data-flow-mapping | `flow steps with storage access` | `access pattern evidence` | flow steps reveal read/write patterns needing indexes |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 048 data-flow-mapping | `index_catalog, covering hints` | `access path hints` | 047 indexes inform 048 read path optimization |
| N190 code-generation | `CREATE INDEX DDL` | `migration scripts` | index DDL consumed by migration generator |
| N260 testing | `validation_plan` | `performance test scenarios` | validation plan feeds index performance tests |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
