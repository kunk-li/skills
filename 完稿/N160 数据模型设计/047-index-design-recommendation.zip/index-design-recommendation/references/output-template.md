# Output Template: Index Design Recommendation

## 1. Objective
- scope
- selected_mode
- readiness
- stage_position

## 2. Evidence Profile
| source | what it confirms | remaining uncertainty |

## 3. Query Patterns Summary
| pattern_id | type | frequency | conditions | sort | returning | confidence |

## 4. Index Catalog
| idx_id | table_name | index_name | columns | index_type | index_purpose | query_patterns_served | composite_order_rationale | uniqueness | write_cost_note | storage_cost_note | evidence | confidence |

## 5. Covering Index Analysis
| pattern_id | current_state | proposed_covering_shape | benefit | caution |

## 6. Deferred or Rejected Indexes
| candidate | reason_not_now | trigger_to_revisit |

## 7. Cost Model and Count Audit
- read_benefit vs write_cost summary
- redundant indexes
- excessive count tables
- unused index hints if evidence exists

## 8. Validation Plan
| query | how to validate | success signal |

## 9. Downstream Handoff
| consumer | what to read | why |

## 10. Self-Check
Summarize checklist and scoring outcomes.


## 11. N160 v2 Contract Addendum

Use `table`, not `table_name`, as the machine key in `index_catalog[]`. The value must be a 046 `table_id`.

Add these blocks when available:

- `cost_analysis` with storage, write overhead, read benefit, and net benefit.
- `partition_interaction` for partitioned or high-volume tables.
- `sensitive_index_handling` for PII, PCI, PHI, financial, or confidential fields.
- `n_plus_1_risks` when repeated child queries are detected.
- `redundancy_check` with left-prefix, duplicate, and containment findings.
