---
name: table-schema-design-recommendation
description: recommend tables, columns, pk strategies, constraint placement, and schema evolution rules. triggers on 数据对象目录.md. inside n160 always precedes index-design and data-flow-mapping.
---
# table-schema-design-recommendation


## DDL structure quick-reference
Every table DDL must follow this order and include these elements.

```sql
CREATE TABLE {table_name} (
  -- 1. Primary key (first, always)
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,   -- or UUID VARCHAR(36) NOT NULL

  -- 2. Business identity (externally visible if different from PK)
  public_id   VARCHAR(36) NOT NULL,                -- UUID for external exposure

  -- 3. Foreign keys / tenant scope
  tenant_id   BIGINT NOT NULL,
  parent_id   BIGINT NULL,

  -- 4. Business fields (domain-specific)
  status      ENUM('DRAFT','ACTIVE','ARCHIVED') NOT NULL DEFAULT 'DRAFT',
  name        VARCHAR(255) NOT NULL,

  -- 5. Sensitive / regulated fields (tag these explicitly)
  email       VARCHAR(320) NULL,                   -- PII: masked in audit logs

  -- 6. Standard audit columns (always last, always present)
  created_at  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  is_deleted  TINYINT(1) NOT NULL DEFAULT 0,
  version     INT NOT NULL DEFAULT 0,              -- optimistic lock

  -- 7. Unique constraints
  UNIQUE KEY uk_{table}_public_id (public_id),
  UNIQUE KEY uk_{table}_tenant_name (tenant_id, name) -- composite unique

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Column type quick-reference:**

| Data type | Use | Anti-pattern |
|---|---|---|
| `BIGINT` | internal IDs, counters | UUID stored as BIGINT |
| `VARCHAR(36)` | UUID v4/v7 external IDs | UUID stored as CHAR(32) without dashes |
| `DECIMAL(19,4)` | money, financial amounts | `FLOAT` or `DOUBLE` for money |
| `DATETIME(3)` | timestamps with ms precision | `DATETIME` (loses ms) |
| `ENUM(...)` | stable status values ≤10 | ENUM with >10 values (use lookup table) |
| `JSON` | flexible attributes, metadata | sensitive or indexed data |
| `TEXT` | long content, notes | VARCHAR >16KB |

## PK strategy quick-reference
Choose PK strategy before writing DDL. Record decision in `pk_strategy_decisions[]`.

| Strategy | When to use | Caution |
|---|---|---|
| Auto-increment `BIGINT` | internal tables, no external exposure | never expose as API identifier |
| `UUID v4` | externally exposed, multi-origin | index size cost; use prefix if ordered needed |
| `ULID` / `UUID v7` | ordered by time, external-safe | verify DB/driver support |
| Composite natural key | junction tables, unique business identity | changes when business rule changes |
| Surrogate + unique constraint | business identity exists but unstable | adds index but safer for joins |

## Standard column template
Every non-lookup table should include:
```sql
id          BIGINT AUTO_INCREMENT PRIMARY KEY,
created_at  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
updated_at  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
is_deleted  TINYINT(1) NOT NULL DEFAULT 0,   -- soft delete flag
version     INT NOT NULL DEFAULT 0            -- optimistic lock
```

## Soft delete rule
- Use `is_deleted` + unique constraint trick for soft-delete with uniqueness: add partial index `WHERE is_deleted = 0`.
- Never allow hard deletes on tables with foreign key consumers unless cascades are verified.


## Trigger conditions
Design table schemas when any of the following are present:
- `数据对象目录.md` from N070 data-object-identification
- N130 technical solution analysis
- existing DDL, ER diagrams, or schema documentation
- explicit table design requests

## Standalone rule
Use `selected_mode: schema-from-analysis`. Without structured upstream, infer schema from domain objects in PRD. Set `readiness: provisional` and mark all inferred fields as `confidence: inferred`. Never emit final DDL without `target_stack` declared.

## Role and boundary
本 skill 对齐技能总表中in the technical-solution-design -> 数据设计 -> 表结构设计」。

它是 **direct_result** 型技能：要把“给出表、字段、关系和约束建议”落成可交付的结构化结果，而不是只给口头建议。

### Boundary
- 止于方案、接口、数据与任务设计，不进入代码编写、测试执行和发布落地。
- 负责提出表结构、字段、主键、约束、时间字段、软删和演进建议。
- 不直接修改真实数据库、代码或线上流程。
- 二级索引、覆盖索引、冗余索引治理主要交给 `index-design-recommendation`。
- 数据创建 / 变更 / 同步 / 异常链路主要交给 `data-flow-mapping`。

## Selected mode
每次输出顶部必须声明 `selected_mode`、`readiness` 和 `evidence_profile`。

允许 4 种模式：
- `schema-from-analysis`：从开发需求解析、技术方案分析、数据对象和规则中设计表结构；默认模式。
- `reverse-engineer`：从现有 schema / DDL / ER 图逆向整理结构并指出问题。
- `compare-stacks`：同一逻辑模型在 mysql / postgres / sqlserver / oracle 等候选栈下做差异对比。
- `migration-planning`：围绕 schema 演进、兼容性、迁移与回滚策略输出。

## Primary inputs
### 推荐输入
- 开发需求解析 / technical solution analysis
- 数据对象清单、业务规则、状态流转、权限与审计要求
- 现有 DDL、ER 图、schema 文档、migration 历史
- API 草案、批处理需求、保留期限 / retention 规则

### 可选增强
- 目标数据库引擎、版本、扩展能力
- 多租户、append-only、PII / financial / regulated 要求
- 历史 schema 变更事故、性能瓶颈、表规模预估

## Standalone rule
即使没有上游结构化输出，也可以单独使用。

降级规则：
- 若只有 PRD 或技术方案文字，允许反推 provisional schema。
- 若只有既有 DDL，允许做 reverse-engineer 整理与 gap 分析。
- 若 `target_stack` 未确认，不要伪装成“最终可执行通用 DDL”；应输出 compare matrix 或 `pending decision`。
- 必须把 `confirmed / inferred / pending` 分层写清楚。

## Core output contract
默认输出 Markdown，并可在需要时补 SQL appendix 或 migration appendix。优先遵循 `references/output-template.md` 与 `references/ddl-structure.md`。

结果至少包含这些结构：
- `metadata`
  - `selected_mode`
  - `readiness`
  - `function_bias: direct_result`
  - `stage_position: technical_solution_design.data_design.table_schema_design`
  - `evidence_profile`
- `target_stack`
  - `engine`
  - `dialect`
  - `version`
  - `extensions`
  - `stack_decision_status`
- `logical_model_summary`
- `table_catalog[]`
  - `table_id`
  - `name`
  - `purpose`
  - `store_type`
  - `columns[]`
  - `primary_key`
  - `foreign_keys_or_soft_refs`
  - `standard_columns_profile`
  - `soft_delete_policy`
  - `timezone_policy`
  - `retention_or_append_only_hint`
  - `pii_or_sensitive_fields`
  - `evidence`
  - `confidence`
- `pk_strategy_decisions[]`
- `standard_columns_template`
- `constraints_placement`
- `schema_evolution_rules`
- `migration_plan[]`
- `open_questions[]`
- `downstream_handoff`
- `self_check`

## Design rules
### Stack-first rule / 栈先行
先确认 `target_stack`，再落物理 DDL。

如果目标栈不清楚：
- 先给 `stack_comparison`，再给 provisional DDL。
- 显式说明 mysql / postgres / sqlserver / oracle 的差异点，不要用“通用 SQL”掩盖差异。

典型差异应被显式利用或规避：
- MySQL: `JSON`, generated column, InnoDB, `utf8mb4` / collation
- PostgreSQL: `JSONB`, `GIN`, `TIMESTAMPTZ`, partitioning
- SQL Server / Oracle: computed or generated behavior only when justified

### PK strategy discipline / 主键策略纪律
每张表必须给出主键策略或继承的项目级策略。

允许的推荐类型：
- `auto_increment` / `bigserial`
- `ulid`
- `snowflake`
- `uuid`
- `composite`

决策至少考虑：
- 预期数据量
- 写入并发
- 是否需要 public_id 与内部 PK 分离
- 是否要跨库唯一
- 是否需要有序写入 / 减少索引热点

### Standard columns discipline / 标准列纪律
默认标准列模板至少考虑：
- `id`
- `created_at` / `updated_at`
- `created_by` / `updated_by`
- `version`

按场景可选：
- `is_deleted` / `deleted_at` / `deleted_by`
- `tenant_id`

但以下表可豁免，且必须写明理由：
- append-only 表
- lookup / reference 表
- 临时或幂等表

所有时间字段默认 UTC 存储。显示时区转换属于应用层或 UI 层，不属于持久层时间真相。

### Constraint placement / 约束落点纪律
每条关键约束都要归类为：
- `db_constraint`
- `application_constraint`
- `double_sided`

放置原则：
- 数据不变式优先放 DB 层
- 合规关键或 append-only 规则可做双保险
- 跨服务、依赖外部状态、不可稳定表达的规则不要假装能完全落 DB

### Evolution discipline / 演进纪律
任何破坏性变更都必须附：
- forward plan
- rollback plan
- compatibility note
- risk note

默认兼容规则：至少向后兼容 1 个版本，除非明确写出 waiver。

大表变更必须提及在线迁移或分阶段迁移策略，而不是只写一个理想化 `ALTER TABLE`。

### Provenance discipline for columns and enums / 列与枚举出处纪律
A schema draft's worst failure is emitting an INVENTED column name, enum value, or type as if it were confirmed fact. Guard it:
- Every concrete specific — a column name, an enum value/literal, a numeric default/threshold, a UK/index name — must be traceable to a provided source (PRD/上游工件), OR be explicitly marked **inferred**. Never present an invented literal as confirmed.
- When you add a column the source does not give (e.g. a standard `version`/audit column per this skill's own template, or a physical table name the PRD never names), tag it **inferred (本 skill 纪律补入;source 未给)** — do not let it read as source-confirmed.
- When the source signals a contradiction (an enum cardinality exceeding a stated soft cap, a term the source leaves undefined, two conflicting values), **hedge and flag it as an open question** rather than freezing a guessed value.
- This is about honesty of confidence, not about adding structure — label grounded vs guessed correctly; do not invent to satisfy it.

### Boundary discipline / 边界纪律
- 不要在本 skill 中展开完整二级索引策略；将访问路径优化交给 047。
- 不要用 narrative flow 取代 schema 设计；流向和异常链路交给 048。
- 不要把业务猜测写成 finalized DDL。

## Execution workflow
1. 识别 selected mode、stage position、evidence profile。
2. 确认或比较 `target_stack`。
3. 归一业务对象、生命周期、ownership、敏感数据类别。
4. 先建逻辑模型，再映射到物理表与存储特性。
5. 为每张表给出 PK 策略与理由。
6. 应用标准列、软删、时区、租户与审计模板。
7. 将关键规则落到 `constraints_placement`。
8. 记录栈差异、兼容性影响和 schema evolution 策略。
9. 在需要时给 SQL appendix 或 migration appendix。
10. 输出给 047 / 048 / N170 / N190 / N200 / N330 的 handoff。
11. 运行 checklist 与 common-failure review。

## Dynamic completeness
- 单个 feature：覆盖全部核心表
- 中等系统：覆盖全部核心表 + 关键卫星表
- 大型域：核心表详写，低价值卫星表可摘要并显式 defer

不要为了凑条数而制造表，也不要因为系统大就只给空泛原则。

## Quality bar
合格结果应当能被以下下游直接消费，而不需重新解释：
- `index-design-recommendation`
- `data-flow-mapping`
- 性能 / 安全 / 审计设计
- Repository / SQL / migration 草稿生成

使用以下参考文件自检：
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/stack-and-pk-taxonomy.md`
- `references/composition-contract.md`

## Reference files
- `references/output-template.md`
- `references/ddl-structure.md`
- `references/checklist.md`
- `references/scoring-rubric.md`
- `references/common-failure-modes.md`
- `references/stack-and-pk-taxonomy.md`
- `references/mode-selection.md`
- `references/orchestration.md`
- `references/example-io.md`
- `references/composition-contract.md`


## N160 v2 optimization layer

Use this layer when the skill is used inside N160 data model design or when the caller asks for v2-compatible, machine-consumable output.

### Additional mode

Add a fifth mode:

- `aggregation-mode`: assemble `N160_data_model_package.md` from 046 table schema output plus 047 index output plus 048 data-flow output. Use only when downstream outputs are provided or when the user asks for node-level packaging.

### Contract-first inputs

For production-grade output, require `stack_declaration` before final DDL. Use `references/stack-declaration-contract.md`.

Also accept these optional but preferred inputs:

```yaml
service_boundaries: from N140
business_rules: from N070
state_machines: from N070
volume_projection: optional capacity signal
index_design_output: from 047, only for aggregation-mode
data_flow_output: from 048, only for aggregation-mode
```

If `stack_declaration` is missing, switch to `compare-stacks` or mark `stack_decision_status: pending`. Do not present final DDL as production-ready.

### Enhanced output contract

In v2-compatible output, extend each `table_catalog[]` item with:

```yaml
table_id: DB-[A-Z]+-[0-9]{3,}
service_owner: SVC-xxx
derived_from_object: OBJ-xxx
columns:
  - column_name: snake_case
    data_type:
      abstract_type: id | uuid | short_text | long_text | money | timestamp | boolean | enum | json | binary
      concrete_type: string
    nullable: true | false
    check_constraint:
      expression: string | null
      derived_from_rule: RULE-xxx | null
    sensitivity: see references/sensitivity-contract.md
keys:
  primary_key:
    columns: []
    strategy: auto_increment | uuid | snowflake | hash | composite
  unique_keys: []
  foreign_keys: []
partitioning:
  enabled: true | false
  trigger_reason: string | null
  partition_scheme:
    strategy: range_monthly | list | hash | composite | null
    partition_key: string | null
    range_monthly:
      partitions_keep: integer | null
      auto_create: true | false | null
      archival_after: string | null
    list:
      values_source: tenant_id | region | status | other | null
    hash:
      partition_count: integer | null
append_only_enforcement: see references/append-only-enforcement.md
schema_version:
  current_version: string
  migration_tool: string
  migration_file_path: string
  rollback_ddl_provided: true | false
retention:
  policy: never_delete | after_x_years | ttl_based | manual
```

### N160 composition rules

- Treat 046 as the N160 schema registry anchor.
- Use `table_id`, not display names, as the cross-skill join key.
- In `aggregation-mode`, follow `references/node-aggregation-template.md` and include Section 8 cross-skill consistency checks.
- If 047 or 048 references an unknown table or column, set `readiness: blocked` and list the exact mismatch.
- Merge column-level sensitivity with 048 sensitive-data propagation before handing off to N170.

### Additional references

- `references/stack-declaration-contract.md`
- `references/n160-shared-naming.md`
- `references/node-aggregation-template.md`
- `references/append-only-enforcement.md`
- `references/sensitivity-contract.md`
- `references/volume-projection-contract.md`

## v2 artifact contract

Add this header to every non-blocked output. N160 skills now participate in the event bus and gate system.

```yaml
artifact_schema_version: n160.table-schema.v2.1.0
skill_name: table-schema-design-recommendation
produced_event: produced.n160.table_schema.v2
blocker_mapping: B-N160-01
readiness: ready | provisional | blocked
rule_results:
  - rule_id: R01_every_table_has_pk_strategy
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R02_standard_columns_present
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R03_pii_tables_flagged
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R04_append_only_enforcement_noted
    severity: reject
    result: pass | warn | reject | not_applicable
  - rule_id: R05_schema_evolution_rules_present
    severity: warn
    result: pass | warn | reject | not_applicable
  - rule_id: R06_downstream_047_048_can_consume
    severity: reject
    result: pass | warn | reject | not_applicable
route_back_to: none | n130 | n120
# none  — schema ready; 047 and 048 may consume
# n130  — table scope contradicts solution constraints; revise 038 first
# n120  — object identification gaps; return to N120 requirement parsing
feedback_signal_to_n005:
  signal_type: none | schema_gap_detected | data_model_pattern
  summary: ""
  target_n070_skills:
  - 017-data-object-identification
  # when signal fires, these N070 artifacts should be reviewed and revised via N005→N010→N030→N070 loop
eventbus_subscribers: [N330]    # N330 subscribes to generate data dictionary
```

## Upstream linkage from N070 (mandatory when artifacts exist)

| upstream artifact | consume fields | maps to |
|---|---|---|
| `数据对象目录.md` (017) | OBJ-* ddd_role, key_attributes, storage.medium, constraint_tags[], relationships[] | table candidates, column seeds, storage type, constraint placement |
| `业务规则清单.md` (014) | RULE-* hardness, condition_expr, object_or_scope | CHECK constraints, validation rules |
| `状态转移图.md` (015) | SM-* states[], invariants[] | status columns, state transition log tables |
| `权限矩阵.csv` (016) | grain=field, field_policy | field-level visibility, column masking hints |
| `验收标准.md` (032) | data consistency acceptance criteria | column constraints, retention policy |

When `constraint_tags: audit_required` appears on an OBJ, ensure the table includes audit columns and propagate to 047 and 048.
When `constraint_tags: pii` appears, flag the table in `sensitivity_contract` and propagate to 048 sensitive-data classification.
