# Common failure modes — table-schema-design-recommendation

## F1: generic DDL without stack declaration
Symptom: DDL is emitted but no `target_stack` (engine, dialect, version) is declared; the output claims to be "generic SQL".
Fix: stack-first rule — declare `target_stack` before writing any DDL. If the stack is unknown, emit a `stack_comparison` matrix and provisional DDL instead of fake "universal" SQL.

## F2: UUID everywhere without reasoning
Symptom: every table uses UUID v4 primary key regardless of access pattern, cardinality, or write volume.
Fix: choose PK strategy per table using the decision table. Auto-increment BIGINT for internal tables; UUID/ULID only for externally exposed or multi-origin records. Document `pk_strategy_rationale`.

## F3: inconsistent soft-delete policy
Symptom: some tables use `is_deleted`, others use `deleted_at`, others hard-delete — across similar domain objects.
Fix: define one `soft_delete_policy` at the schema level. All tables either use it, are explicitly exempt (with reason), or use hard-delete with a documented cascading plan.

## F4: timezone policy omitted
Symptom: DATETIME columns appear without specifying whether they store UTC or local time. The schema mixes `DATETIME` and `TIMESTAMP` without explanation.
Fix: declare `timezone_policy: all DATETIME stored as UTC`. Document any exception. Never mix timezone assumptions silently.

## F5: all constraints forced to DB layer
Symptom: business rules that depend on external state (e.g., "max 5 pending orders per user") appear as DB constraints.
Fix: classify constraints: `db_layer` (enforced by DB engine), `application_layer` (enforced in app), `double_sided` (both). External-state-dependent rules belong in `application_layer`.

## F6: migration with no rollback
Symptom: a migration plan changes columns, drops tables, or alters PKs without stating how to roll back.
Fix: every destructive migration step must have a forward and rollback path. For column drops: use two-phase (add new → migrate data → drop old). For PK changes: always use blue-green.

## F7: index over-design inside this skill
Symptom: composite indexes, covering indexes, or full-text indexes are created inside 046 without handing off to 047.
Fix: 046 defines tables and PK/FK only. Secondary index design goes to 047. Mention the handoff in `downstream_handoff.to_047_index_design`.

## F8: sensitive fields in prose, not schema
Symptom: PII or regulated fields are mentioned in the description text but not tagged in `column.sensitivity` or `pii_or_sensitive_fields[]`.
Fix: every PII, PCI, PHI, or regulated field must appear in `pii_or_sensitive_fields[]` with `classification`, `masking_rule`, and `retention_note`.
