# Common Failure Modes

- generic ddl with no target stack
- UUID used everywhere without volume or write-path reasoning
- soft delete mixed inconsistently across similar tables
- UTC / timezone policy omitted
- all business rules forced into DB constraints even when external-state dependent
- no migration / rollback note for destructive change
- secondary index over-design inside this skill instead of handing off to 047


## N160 v2 failure modes

1. Final DDL is emitted without stack declaration.
2. 047 or 048 uses display table names instead of 046 `table_id`.
3. Sensitive fields are listed in prose but not in column-level schema.
4. Audit tables are declared append-only but no DB, application, and permission guard is provided.
5. Migration has no rollback path.
6. Aggregation-mode reports ready while cross-skill consistency checks fail.
