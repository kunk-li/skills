# Orchestration

## Upstream
Best inputs:
- engineering requirement parsing
- technical solution analysis
- data-object-identification
- api-design-recommendation when request/response payloads imply persistence shape

## Downstream
Main consumers:
- index-design-recommendation
- data-flow-mapping
- advanced / non-functional design
- repository / sql draft generation
- documentation generation

## 046 -> 047 mapping
| 046 field | 047 usage |
| --- | --- |
| table_catalog | valid table and column universe |
| primary_key / unique constraints | baseline index inventory |
| retention_or_append_only_hint | write-cost guardrails |
| pii_or_sensitive_fields | index caution and audit notes |

## 046 -> 048 mapping
| 046 field | 048 usage |
| --- | --- |
| logical_model_summary | entity lifecycle anchors |
| table_catalog | storage touchpoints |
| append_only / retention hints | replay, archive, audit flows |
| sensitive fields | data classification requirements |


## N160 v2 node behavior

046 is the schema registry anchor for N160. Run it first unless the user is only auditing existing indexes or only mapping flows.

Recommended order:

1. 046 table schema and stack declaration
2. 047 query-driven index matrix
3. 048 data lifecycle and transaction-aware flows
4. 046 aggregation-mode for `N160_data_model_package.md`

Fail fast when shared naming or stack compatibility breaks.
