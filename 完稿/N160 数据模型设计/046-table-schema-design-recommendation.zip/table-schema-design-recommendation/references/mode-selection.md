# Mode Selection

| mode | use when | emphasis |
| --- | --- | --- |
| schema-from-analysis | requirements and solution notes are primary | fresh schema proposal |
| reverse-engineer | existing ddl or schema already exists | normalize and gap-find |
| compare-stacks | target DB is undecided | engine-aware comparison |
| migration-planning | schema change risk is central | evolution, rollback, rollout |

| aggregation-mode | 047 and 048 outputs are available or the user asks for N160 package | node-level package and consistency gate |
