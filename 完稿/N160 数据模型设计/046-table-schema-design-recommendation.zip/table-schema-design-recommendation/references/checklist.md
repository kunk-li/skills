# Delivery checklist — table-schema-design-recommendation

## A. stack declaration
- [ ] `target_stack` declared: engine, dialect, version, extensions
- [ ] `stack_decision_status` set: `confirmed | pending | assumed`
- [ ] Provisional DDL marked when stack is unconfirmed

## B. table catalog completeness
- [ ] Every in-scope entity has a table entry with: `table_id`, `name`, `purpose`, `store_type`, `columns[]`
- [ ] Each column has: `name`, `type`, `nullable`, `default`, and `sensitivity` if PII/regulated

## C. PK strategy
- [ ] Every table has `primary_key` with `strategy` and `rationale`
- [ ] Surrogate auto-increment: confirm it is NOT exposed as an API identifier
- [ ] UUID/ULID: confirm driver/DB version support and index size impact noted

## D. standard columns
- [ ] Standard columns policy declared for the schema
- [ ] Each table applies policy or is explicitly exempt with reason
- [ ] `created_at`, `updated_at` typed with millisecond precision (`DATETIME(3)` or `TIMESTAMPTZ`)

## E. soft delete and timezone
- [ ] `soft_delete_policy` declared at schema level
- [ ] `timezone_policy` declared (canonical: all DATETIME stored as UTC)
- [ ] Append-only tables explicitly exempted from soft-delete and `updated_at`

## F. constraint placement
- [ ] Constraints classified: `db_layer`, `application_layer`, `double_sided`
- [ ] External-state-dependent rules NOT in DB constraints
- [ ] MONEY/DECIMAL fields use `DECIMAL`/`NUMERIC`, never `FLOAT`/`DOUBLE`

## G. PII/sensitivity classification
- [ ] `pii_or_sensitive_fields[]` populated for every PII, PCI, PHI, or regulated column
- [ ] Each sensitive field has: `classification`, `masking_rule`, `retention_note`

## H. evolution and migration
- [ ] `schema_evolution_rules` present with change-type rules
- [ ] Every destructive migration step has forward AND rollback path
- [ ] Two-phase migration plan for column drops

## I. downstream handoff
- [ ] `downstream_handoff.to_047_index_design` references tables needing secondary indexes
- [ ] `downstream_handoff.to_048_data_flow_mapping` references flows to be analyzed
- [ ] `downstream_handoff.to_051_audit` references append-only audit tables

## One-vote rejection items
- [ ] Final DDL emitted without stack declaration
- [ ] Money/financial fields use float type
- [ ] PII fields not tagged in sensitivity block
- [ ] Migration with no rollback path

- [ ] `R_ARCH_DECISION_COMMITTED` (reject): 本 skill 拥有的**架构决策**（表结构(列/类型/约束/索引/主键·从数据对象目录017设计)）必须按**四步**拍定,绝不留 `pending`/`UNDETERMINED`/空:① 查决策已存在?② 查被订正?(版本叠层);③ **有→遵循【现行】**(不照旧/不留空/不另默认);④ 真无→工程默认(从017逐字段设计schema+遵命名规范,不清按工程惯例定),标 made_by=design_default。留空是缺陷(本skill职责·会被026误升not_executable下游推stub)。仅真产品输入可留 needs_decision。
