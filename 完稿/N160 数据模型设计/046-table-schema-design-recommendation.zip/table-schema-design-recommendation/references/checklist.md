# Checklist

- target_stack chosen or explicitly pending
- table catalog complete for in-scope entities
- every table has PK rationale
- standard columns / exemptions explained
- timezone policy explicit
- soft-delete policy explicit
- constraints placed in db / application / double_sided buckets
- schema evolution and migration notes included
- secondary index work deferred to 047 where appropriate
- downstream handoff included


## N160 v2 checks

- stack_declaration present before final DDL
- table_id follows shared naming contract
- every downstream table reference can be joined by table_id
- money fields use decimal or numeric, never float or double
- timestamp policy uses UTC canonical storage
- PII, PCI, PHI, financial, and regulated fields have sensitivity blocks
- audit or compliance tables have append-only enforcement or a blocking waiver
- high-volume tables have partition or retention reasoning
- every migration has forward and rollback notes
- aggregation-mode includes cross-skill consistency checks
