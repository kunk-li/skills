# Stack Declaration Contract

Use this contract before emitting production-grade DDL or migration advice.

## Required fields

```yaml
stack_declaration:
  primary_db: mysql | postgres | oracle | sql_server | mariadb
  version: string
  character_set: string | null
  collation: string | null
  engine: innodb | rocksdb | tokudb | null
  timezone_handling: utc | local
  migration_tool: flyway | liquibase | typeorm_migrations | alembic | other | pending
```

## Hard rule

- If `stack_declaration.primary_db` or `stack_declaration.version` is missing, do not emit final DDL.
- Switch to `compare-stacks` or mark `stack_decision_status: pending`.
- You may emit provisional DDL only when it is clearly labeled as non-final.

## Dialect-sensitive decisions

| area | mysql | postgres | rule |
| --- | --- | --- | --- |
| json | JSON plus generated columns where needed | JSONB plus GIN where needed | do not use one dialect assumption for both |
| timestamp | TIMESTAMP(6) or DATETIME(6) | TIMESTAMPTZ | store canonical time in UTC |
| money | DECIMAL(20,6) | NUMERIC(20,6) | never use float or double |
| uuid | CHAR(36), BINARY(16), or app generated | UUID | declare strategy explicitly |
| text search | FULLTEXT or external engine | GIN or external engine | route to 047 when index-heavy |

## Fallback behavior

If the caller only has a PRD or technical note, produce:

```yaml
stack_decision_status: pending
readiness: review-ready
selected_mode: compare-stacks
```
