# Workflow position

## Node: N160
## Step order: 1_of_3

## Upstream inputs (feeds this skill)
- 038
- N120 data objects

## Downstream consumers (this skill feeds)
- 047
- 048
- N170

## When to use standalone vs in-workflow
- **Standalone**: when no structured upstream artifacts exist; start from raw requirements or PRD; output will be `readiness: provisional`.
- **In-workflow**: when upstream artifacts are available; inherit IDs and fields; output can reach `readiness: ready`.

## Minimum required inputs for `readiness: ready`
See `references/v2-contract.md` (N170 group) or `references/exact-contract.md` (N130/N140 group) for the typed input schema.
