# Append-Only Enforcement Contract

Use this contract for audit, ledger, compliance, event, and immutable history tables.

## Trigger condition

Apply when any table has one of these attributes:

- `table_kind: audit | ledger | event_log | compliance_history`
- `append_only: true`
- retention policy says records must not be deleted or mutated

## Required output block

```yaml
append_only_enforcement:
  enabled: true
  enforcement_layers:
    db_trigger:
      no_update_trigger_ddl: string
      no_delete_trigger_ddl: string
    application_guard:
      annotation_or_policy: string
      error_code: string
    permission_guard:
      revoke_update_delete_from: [app_user, read_user]
      allow_only: [admin_role]
```

## Hard rule

If `append_only_enforcement.enabled: true`, all three layers must be present. One-layer protection is not enough for production-grade output.

## Waiver

A waiver is allowed only for early design drafts. Mark it as:

```yaml
append_only_enforcement:
  enabled: true
  readiness: blocked
  waiver_reason: string
  owner_to_confirm: string
```
