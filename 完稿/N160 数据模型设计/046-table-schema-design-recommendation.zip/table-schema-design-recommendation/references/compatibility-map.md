# Compatibility map — table-schema-design-recommendation v2 alignment

## Input artifact field mapping
Maps upstream artifact vocabulary to this skill's runtime fields.

| Upstream source | Upstream field | This skill's field | Notes |
|---|---|---|---|
| N070 017 data-object-identification | `OBJ-* ddd_role, constraint_tags` | `table_catalog seeds` | data objects become table candidates |
| 038 technical-solution-analysis | `architecture_three_states, data constraints` | `evolution rules, migration plan` | architecture decisions shape schema evolution |
| 051 audit-trail-design | `A01-A10 mandatory categories` | `audit table design` | audit categories define append-only tables |

## Output artifact field mapping
Maps this skill's output to downstream consumer fields.

| Downstream consumer | This skill's field | Consumer's field | Notes |
|---|---|---|---|
| 047 index-design-recommendation | `table_id, columns[], pk_strategy` | `index design input` | 047 must reference 046 table_ids |
| 048 data-flow-mapping | `table_id, store_type, pii_fields` | `flow step storage targets` | 048 references 046 table_ids in flow steps |
| N160 downstream | `DDL, migration_plan` | `implementation artifacts` | DDL consumed by N190 for schema migration generation |

## v2 contract field cross-reference
| v2 header field | Purpose | Downstream consumer |
|---|---|---|
| `artifact_schema_version` | Schema version for N380 aggregation | N380 |
| `produced_event` | Event bus trigger for N330/N340 | N330, N340 |
| `blocker_mapping` | SLA queue key for N380 | N380 |
| `rule_results[]` | Gate pass/warn/reject per rule | N380 automated check |
| `feedback_signal_to_n005` | Loop-back to N070 revision | N005 workflow orchestrator |
| `route_back_to` | Return path when gaps detected | Upstream skill |
