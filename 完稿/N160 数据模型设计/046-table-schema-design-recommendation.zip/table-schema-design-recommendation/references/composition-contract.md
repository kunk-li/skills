# Composition Contract

This skill should emit stable, machine-readable names for:
- `table_catalog`
- `pk_strategy_decisions`
- `standard_columns_template`
- `constraints_placement`
- `schema_evolution_rules`
- `migration_plan`
- `downstream_handoff`

Downstream expectations:
- 047 consumes valid table/column names and uniqueness baseline
- 048 consumes storage touchpoints, append-only hints, and sensitive data markers


## N160 shared contract

- 046 owns `table_id` and column definitions.
- 047 must reference 046 tables through `index_catalog[].table` using `table_id`.
- 048 must reference 046 tables through `storage_touchpoints[]` and step sources using `table_id`.
- Unknown table or column references are blocking consistency failures.
- In `aggregation-mode`, 046 emits `N160_data_model_package.md` with a cross-skill consistency check.

See `references/n160-shared-naming.md` and `references/node-aggregation-template.md`.
