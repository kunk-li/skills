# Column Sensitivity Contract

Use this block inside every column where data protection matters.

```yaml
sensitivity:
  class: public | internal | confidential | pii | pci | phi | financial | regulated
  encryption:
    at_rest: true | false
    method: none | application | tde | column_level | hash_only
    key_rotation: duration | null
  masking:
    default_masked_in_query: true | false
    unmask_role_required: string | null
  audit_on_read: true | false
  derived_from_rule_refs: [RULE-xxx]
```

Rules:

- `pii`, `pci`, and `phi` require encryption or a documented waiver.
- `pci` should avoid storing raw PAN; prefer tokenization.
- `financial` requires audit and retention reasoning.
- Sensitive fields should be checked against 047 index decisions and 048 flow propagation.
