# Volume Projection Contract

Use this optional block when capacity, partitioning, retention, or index cost matters.

```yaml
volume_projection:
  rows_year_1: integer | null
  rows_year_3: integer | null
  row_size_estimate_bytes: integer | null
  read_write_ratio: read_heavy | write_heavy | balanced | unknown
  sustained_qps: string | null
  peak_qps: string | null
  hot_data_percentage: number | null
```

Decision rules:

- If `rows_year_1 > 50000000`, suggest partitioning or explain why not.
- If `hot_data_percentage < 20`, consider archival or hot/cold separation.
- If `write_heavy` and many indexes are proposed by 047, flag write-amplification risk.
- If no projection is available, mark partition decisions as provisional.
