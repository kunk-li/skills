# Example I/O

## Example input
- Technical solution for ticket approval system
- Data objects: Ticket, ApprovalStep, AuditEvent
- Target stack: MySQL 8.0, UTF8MB4

## Good output sketch

```sql
-- target_stack: mysql_8, dialect: mysql, version: 8.0

-- table_id: TBL-TICKET-001
CREATE TABLE tickets (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,   -- pk_strategy: surrogate_auto_increment; never expose in API
  public_id     VARCHAR(36) NOT NULL,                 -- externally visible UUID; indexed separately
  tenant_id     BIGINT NOT NULL,
  status        ENUM('DRAFT','SUBMITTED','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
  subject       VARCHAR(500) NOT NULL,
  created_by    BIGINT NOT NULL,
  created_at    DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at    DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  is_deleted    TINYINT(1) NOT NULL DEFAULT 0,
  version       INT NOT NULL DEFAULT 0,               -- optimistic lock
  UNIQUE KEY uk_tickets_public_id (public_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- table_id: TBL-APPROVAL-001
CREATE TABLE approval_steps (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  ticket_id     BIGINT NOT NULL,                     -- FK to tickets.id (soft ref; no cascade delete)
  approver_id   BIGINT NOT NULL,
  step_order    TINYINT NOT NULL,
  decision      ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  decided_at    DATETIME(3) NULL,
  reason        TEXT NULL,
  created_at    DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at    DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  version       INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- table_id: TBL-AUDIT-001  (append-only)
CREATE TABLE audit_events (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  event_type    VARCHAR(100) NOT NULL,               -- e.g. ticket.status_changed
  actor_id      BIGINT NOT NULL,
  target_id     BIGINT NOT NULL,
  target_type   VARCHAR(50) NOT NULL,
  payload       JSON NOT NULL,                        -- masked PII before storage
  trace_id      VARCHAR(64) NOT NULL,
  occurred_at   DATETIME(3) NOT NULL,
  recorded_at   DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
  -- NO updated_at, NO is_deleted — append-only table
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## Key design decisions recorded

```yaml
pk_strategy_decisions:
  - table_id: TBL-TICKET-001
    strategy: surrogate_auto_increment + public_id UUID
    rationale: internal joins use BIGINT for performance; external API uses UUID to avoid enumeration attacks

standard_columns:
  applied_to: [TBL-TICKET-001, TBL-APPROVAL-001]
  exemptions:
    TBL-AUDIT-001: append-only; no updated_at or is_deleted

soft_delete_policy:
  tables: [TBL-TICKET-001]
  mechanism: is_deleted=1 + unique index on (tenant_id, public_id) WHERE is_deleted=0

timezone_policy: all DATETIME stored as UTC; application converts for display

evolution_rules:
  - never drop a column without a 2-phase migration (add new column → migrate data → drop old)
  - ENUM changes require full table rebuild in MySQL 8; prefer separate status table for frequently changing enums
```

## ex-002 · negative cases — common schema mistakes

```yaml
negative_cases:
  - case_id: NEG-046-001
    title: "FLOAT used for money column"
    bad_ddl: "amount FLOAT NOT NULL"
    table_id: TBL-PAYMENT-001
    problem: "FLOAT has IEEE 754 precision loss: 19.99 may be stored as 19.990000000001 — financial calculations incorrect"
    correct_ddl: "amount DECIMAL(19,4) NOT NULL"
    rule: "Money/financial fields MUST use DECIMAL or NUMERIC, never FLOAT or DOUBLE"

  - case_id: NEG-046-002
    title: "Auto-increment PK exposed as external API ID"
    bad_example:
      table_id: TBL-ORDER-001
      pk: "id BIGINT AUTO_INCREMENT PRIMARY KEY"
      api_usage: "GET /orders/{id} uses id=1,2,3... in URL"
    problem: "Sequential IDs expose record count, enable enumeration attacks, and couple API contract to DB internals"
    correct_example:
      table_id: TBL-ORDER-001
      pk: "id BIGINT AUTO_INCREMENT PRIMARY KEY"
      external_id: "public_id VARCHAR(36) NOT NULL — UUID for API; id for internal joins"
      api_usage: "GET /orders/{public_id} — UUID is safe to expose"

  - case_id: NEG-046-003
    title: "No timezone policy — DATETIME vs TIMESTAMP mixed"
    bad_example:
      table_id: TBL-EVENT-001
      columns: ["created_at TIMESTAMP", "scheduled_for DATETIME", "completed_at TIMESTAMP"]
    problem: "TIMESTAMP auto-converts to server timezone; DATETIME stores as-is. Mixed columns cause off-by-hours bugs in DST regions."
    correct_example:
      table_id: TBL-EVENT-001
      policy: "timezone_policy: all DATETIME(3) stored as UTC; application converts for display"
      columns: ["created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)", "scheduled_for DATETIME(3) NOT NULL", "completed_at DATETIME(3) NULL"]

  - case_id: NEG-046-004
    title: "Append-only audit table has updated_at and is_deleted"
    bad_ddl: |
      CREATE TABLE audit_events (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        event_type VARCHAR(100) NOT NULL,
        updated_at DATETIME(3) ON UPDATE CURRENT_TIMESTAMP(3),  -- BAD: audit records are immutable
        is_deleted TINYINT(1) DEFAULT 0                          -- BAD: audit records cannot be deleted
      );
    correct_ddl: |
      CREATE TABLE audit_events (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        event_type VARCHAR(100) NOT NULL,
        occurred_at DATETIME(3) NOT NULL,
        recorded_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
        -- NO updated_at, NO is_deleted, NO version — append-only
      );
    rule: "R02 in 051: audit tables must NOT have updated_at or is_deleted"
```

## ex-003 · degraded — no data object catalog; schema derived from solution analysis

```yaml
skill_name: table-schema-design-recommendation
readiness: provisional
selected_mode: schema-from-analysis
target_stack: {engine: MySQL, dialect: InnoDB, version: "8.0", extensions: []}
evidence_profile:
  confirmed: [technical-solution-analysis TSA-001]
  inferred: [all tables derived from architecture component list]
  pending: [data volume projections, PII classification from DPO]

degraded_reason: "No 数据对象目录.md available; tables inferred from N130 architecture component descriptions"
degraded_impact: "Column lists are provisional — business fields may be incomplete; PII classification unverified"

tables:
  - table_id: TBL-TICKET-001
    name: leave_tickets
    confidence: inferred
    inferred_from: "TSA-001 component COMP-001-OrderCore"
    provisional_columns:
      - {name: id, type: "BIGINT AUTO_INCREMENT", confidence: confirmed}
      - {name: status, type: "ENUM('DRAFT','SUBMITTED','APPROVED','REJECTED')", confidence: confirmed}
      - {name: requester_id, type: "BIGINT NOT NULL", confidence: confirmed}
      - {name: reason, type: "VARCHAR(1000)", confidence: inferred, note: "field name provisional — confirm with product owner"}
    columns_pending: ["approver_id (confirm: single or multiple?)", "delegation fields if multi-level approval"]

pending_confirmations:
  - "Run 017 data-object-identification to get authoritative object list"
  - "DPO to classify PII fields before schema is finalized"
  - "Confirm volume projections for partitioning decision"
```

## ex-004 · blocked — stack unknown, cannot emit DDL

```yaml
skill_name: table-schema-design-recommendation
readiness: blocked
blocker_mapping: B-N160-01
route_back_to: technical-solution-analysis

blockers:
  - blocker_id: BLK-SCHEMA-001
    type: unknown_target_stack
    description: "Technical solution analysis (038) left target_stack: TBD — team is evaluating MySQL vs PostgreSQL vs CockroachDB"
    impact: "DDL syntax differs critically across stacks (ENUM vs CHECK, UUID vs gen_random_uuid(), partitioning syntax). Cannot emit DDL without stack decision."
    resolution_required: "Architecture team must commit to a database stack before table design proceeds"
    unblock_evidence: "Updated TSA-001 with technology: confirmed for the database component"

  - blocker_id: BLK-SCHEMA-002
    type: missing_data_objects
    description: "No 数据对象目录.md from N070-017 and no entity descriptions in solution analysis"
    impact: "Cannot determine what tables are needed — table catalog would be entirely invented"
    resolution_required: "Either run N070-017 data-object-identification, or product team provides entity list"
    unblock_evidence: "数据对象目录.md OR explicit entity list with ≥3 confirmed domain objects"

provisional_output:
  note: "Only policy decisions can be made without stack or entity definitions"
  stack_decision_status: pending
  schema_evolution_rules: "Will apply once stack is confirmed"
  timezone_policy: "All timestamps stored as UTC (applies regardless of stack)"
  soft_delete_policy: "Soft-delete via is_deleted column (applies regardless of stack)"
```
