# Output Template: Table Schema Design Recommendation

## 1. Objective
- scope
- excluded scope
- selected_mode
- readiness
- stage_position

## 2. Evidence Profile
| source | what it confirms | remaining uncertainty |

## 3. Target Stack
| engine | dialect | version | extensions | decision_status | rationale |

## 4. Logical Model Summary
| object | purpose | lifecycle | owner |

## 5. Table Catalog
For each table include:
- table_id / name / purpose / store_type
- columns
- primary_key
- foreign_keys_or_soft_refs
- standard_columns_profile
- soft_delete_policy
- timezone_policy
- retention_or_append_only_hint
- pii_or_sensitive_fields
- evidence / confidence

## 6. PK Strategy Decisions
| table | recommendation | rationale | tradeoffs | alternative_if_fail |

## 7. Standard Columns and Constraint Placement
- standard_columns_template
- db_constraints
- application_constraints
- double_sided

## 8. Schema Evolution and Migration Plan
| change_area | compatibility_rule | forward | rollback | risk |

## 9. Open Questions
| id | question | impact | owner |

## 10. Downstream Handoff
| consumer | what to read | why |

## 11. Self-Check
Summarize checklist and scoring outcomes.


## 12. N160 v2 Contract Addendum

Include these sections when implementation-ready output is requested:

- `stack_declaration` with primary DB, version, timezone, and migration tool.
- `volume_projection` when capacity or partition decisions are in scope.
- Column-level `sensitivity` for PII, PCI, PHI, financial, confidential, or regulated data.
- `append_only_enforcement` for audit, ledger, event log, and compliance tables.
- `schema_version` and rollback-capable migration notes.
- `cross_skill_keys` using `table_id`, `object_ref`, and `service_ref`.

When `selected_mode: aggregation-mode`, use `references/node-aggregation-template.md` instead of this basic template.
