# N160 Node Aggregation Template

Use this file only in `aggregation-mode`, when 046 receives outputs from 047 and 048 in addition to its own schema output.

# N160_data_model_package.md

## 1. Stack Declaration
- Source: 046 `stack_declaration`.
- Include decision status and unresolved stack questions.

## 2. Table Catalog and DDL
- Source: 046 `table_catalog`, `ddl_emission`, `migration_plan`.
- Include `table_id` as the primary machine key.

## 3. Index Matrix
- Source: 047 `index_catalog`, `cost_analysis`, `index_count_audit`.
- Each index must reference a valid 046 `table_id` and valid columns.

## 4. Data Flow Diagrams
- Source: 048 `flow_catalog`, `flow_overview.diagrams`.
- Each storage touchpoint must reference a valid 046 `table_id`.

## 5. Sensitive Data Tracking
- Merge 046 column-level `sensitivity` with 048 sensitive-data propagation.
- Highlight any sensitive field that appears in logs, events, exports, cache, or search indexes.

## 6. Compliance Obligations
- Source: 048 `compliance_obligations` plus 046 retention and encryption fields.
- Include required deletion, masking, audit, tokenization, and retention paths.

## 7. Migration Path
- Source: 046 `schema_version`, `migration_plan`, and 047 index rollout notes.
- Include forward, rollback, online DDL concerns, and deployment ordering.

## 8. Cross-Skill Consistency Check

| check | pass criteria | result |
| --- | --- | --- |
| table ids | every 047 and 048 table reference exists in 046 | pass/fail |
| column refs | every 047 indexed column exists in the matching 046 table | pass/fail |
| stack usage | 047/048 decisions are compatible with 046 stack | pass/fail |
| sensitivity | 046 sensitive fields appear in 048 propagation map | pass/fail |
| migration | DDL and index rollout order is explicit | pass/fail |
| open questions | unresolved blockers are assigned to owners | pass/fail |

If any required check fails, set `readiness: blocked` and list the exact upstream fix.
