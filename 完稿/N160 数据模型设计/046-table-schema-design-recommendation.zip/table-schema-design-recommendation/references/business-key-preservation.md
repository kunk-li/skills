# Business-key preservation in schema design

Use this reference whenever upstream requirements, business rules, object models, state machines, or APIs define a composite identity, scoped uniqueness rule, lifecycle generation, attempt number, or callback-correlation tuple.

## Preserve the business identity

1. Extract every confirmed identity tuple and its scope from the authoritative upstream sources. Record the source artifact and rule or section for each component.
2. Map every component to a table column and to the applicable primary/unique constraint or explicit application-level invariant. Do not omit a component merely because an upstream artifact gives it a different name.
3. Keep domain lifecycle numbers distinct from transport delivery counters, callback retries, optimistic-lock versions, and unrelated sequence numbers. Do not substitute one category for another.
4. When an API or callback contract carries an identity tuple, compare its fields with the stored binding. List every mismatch as a conflict or open question; do not silently weaken the table key or callback correlation.
5. For conditional uniqueness such as one active row per business key, state the exact scope and enforcement layer. If the selected database cannot represent it directly or the stack is unknown, preserve the invariant as provisional and identify the enforcement decision still required.

## Review matrix

For each business identity, include: source and anchor; full ordered tuple; lifecycle or delivery-counter category for each numeric component; target table and columns; unique-key or application-constraint expression; API/callback correlation fields; confidence; and unresolved decisions.

A schema passes this review only when every source-confirmed key component is represented in the target identity or an explicit, evidence-backed decision explains why it is not persisted. A delivery retry number cannot satisfy a missing business-attempt component.

## Focused example

If the source defines one approval binding per `(ticket, stage, stage_attempt_no)` and callbacks must match `(ticket, stage, stage_attempt_no, approval_instance_id)`, keep `stage_attempt_no` in the business key and the callback check. A separate `callback_attempt_no` may track delivery retries; it is not interchangeable with the lifecycle attempt.
