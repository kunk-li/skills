# OpenAPI to controller mapping

> Authoritative source note: this Markdown file is a human-readable guide. The corresponding `*-algorithms.yaml`, input/output contracts, shared enum dictionary, and self-check YAML files are the source of truth for executable decisions.

Map `operationId` to method name. Map path and HTTP method to framework route annotation. Map path/query/header parameters to typed method parameters with validation. Map requestBody to request DTO with validation. Map documented responses to OpenAPI/Swagger response annotations or equivalent documentation.

Schema validation defaults:
- required -> not null / required field
- format: email -> email validator
- format: uuid -> uuid validator
- minLength/maxLength -> size bounds
- minimum/maximum -> numeric bounds
- pattern -> pattern validator

Controller output should remain adapter-level; service behavior is represented only as service_signature_hints.
