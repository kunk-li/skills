# controller-draft-generation 常见失败模式 v2.3

## F1. Entity 直接暴露给 API 层

**症状**：controller 方法签名写成 `public OrderEntity createOrder(@RequestBody OrderEntity req)`，跳过了 DTO 层。

**后果**：JPA 实体的内部字段（如 `version`、`createdBy`、关联实体懒加载代理）直接序列化到 HTTP 响应；前端拿到大量内部字段，安全风险与序列化异常并存；后续重构 entity 等于破坏 API。

**修正**：
- 所有 request 类型必须引用 N200 dto-vo-generation 产物中的 `*Request` 类。
- 所有 response 类型必须引用 N200 产物中的 `*Response` / `*View` 类。
- entity 类型在 controller 草稿中**不允许出现**；如必须引用，作为 service 内部类型，controller 不感知。

---

## F2. 错误码静默兜底

**症状**：controller 抛出 `RuntimeException` 或 `Exception`，未引用 N200 exception-class-generation 中的具体异常类；或全局 `@ExceptionHandler` 把所有异常都映射成 `500 Internal Server Error`。

**后果**：客户端无法区分业务错误与系统错误；可观测性差；告警噪声大。

**修正**：
- 引用 `错误码清单.csv` 中的 error_code，每个 endpoint 在 swagger 注解中声明 `@ApiResponse(code=4xx, ...)`。
- 委托 `exception-class-generation` 提供的具体异常类（如 `OrderNotFoundException`）；controller 不在内联代码中创建匿名异常。

---

## F3. 路径与方法的 RESTful 偏移

**症状**：在 OpenAPI 已声明 `POST /orders` 创建订单的情况下，controller 草稿写成 `POST /createOrder` 或 `GET /order/create`。

**后果**：API 契约与实现不一致；网关路由失效；OpenAPI 自动生成的 SDK 无法调用。

**修正**：
- `R0X_openapi_path_aligned`：路径与 HTTP 方法严格按输入的 OpenAPI / 接口意图清单生成；不允许 controller skill 自行重命名路径。
- 输入 OpenAPI 与显式 `crud_batch` 模式存在路径冲突时，进入 `pending[]` 等待人工决策。

---

## F4. quick_endpoint 模式生成完整 swagger 注解集

**症状**：`selected_mode: quick_endpoint`（应当只产出方法签名 + 最少注解）但实际输出包含完整的 `@Operation` / `@Parameter` / `@ApiResponse` / `@SecurityRequirement` 全套。

**后果**：mode 失去意义；用户期待最小输出但拿到完整产物，时间预期落空；与下游 `migration_mode` 的差异被抹平。

**修正**：
- `R0X_mode_output_proportional`：每个 mode 在 `references/controller-output-contract.yaml` 的 `mode_dispatch` 段中声明允许的字段集；超出范围的注解必须省略。
- `quick_endpoint` 仅输出 `@RestController` + `@RequestMapping` + 方法签名 + `@RequestMapping(method=...)`；validation/swagger/security 进 `pending[]`。

---

## F5. Service 方法引用断裂

**症状**：controller 中调用 `orderService.cancelOrder(id, reason)`，但 service-draft-generation 输出的 service 方法签名为 `cancelOrder(Long id)`（缺 `reason` 参数）。

**后果**：N190 aggregator 检测到 `unresolved_references[]`；package readiness 降级为 constrained；用户需手工对齐。

**修正**：
- controller 草稿在 `## Composition` 段必须引用 service-draft-generation 的 `methods[].signature`，不存在则进 `pending[]` 并显式标 `expected_service_method`。
- 优先建议人工把 controller 草稿与 service 草稿同步生成（一次会话内）。

---

## F6. crud_batch 模式遗漏字段约束

**症状**：`crud_batch` 模式批量生成 5 个资源的 CRUD endpoint，但忽略了某些资源有自定义校验（如 `User.email` 必须唯一）。

**后果**：N200 validator-code-generation 提示遗漏，N210 静态检查告警；endpoint 上线后用户绕过校验。

**修正**：
- `crud_batch` 模式必须为每个资源声明 `validation_rules_source: <ref>`，缺失则该资源进 `pending[]`。
- 输入 `业务规则清单.csv` 必须按资源粒度过滤，不允许全局复用一套规则。

---

## F. Query string embedded in @Mapping path

**症状**：`@GetMapping("/resource/list?type={type}")` —— 把查询参数写进了 mapping 注解的路径值里。

**后果**：Spring 的 mapping path 不解析 query，此路由字面上不匹配任何请求（端点静默失效，编译不报错、运行 404）。

**修正**：
- @*Mapping 路径值必须是纯 URI path，绝不含 `?`。
- 查询参数一律用 `@RequestParam`（或框架等价机制）声明，不嵌进路径注解。
- 由 `controller-self-check.yaml` R12 机器拦截（on_violation: reject）。
