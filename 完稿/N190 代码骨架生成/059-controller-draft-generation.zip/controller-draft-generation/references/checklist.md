# controller-draft-generation 交付检查清单 v2.3

## A. artifact_contract 完整性
- ☐ 输出以 `artifact_contract` YAML 块开头
- ☐ `schema_version: n190.artifact.v2.3` 已声明
- ☐ `producer_skill: controller-draft-generation`、`producer_node: N190`、`artifact_name: Controller草稿.java` 三项一致
- ☐ `readiness` ∈ {`pass`, `provisional`, `constrained`, `blocked`}
- ☐ `selected_mode` ∈ {`quick_endpoint`, `full_controller`, `crud_batch`, `migration_mode`}

## B. 输入与契约对齐
- ☐ 至少有 OpenAPI / 接口清单 / endpoint 描述 / CRUD 实体 之一作为最小输入
- ☐ 每个 endpoint 都标注 HTTP 方法、路径、请求 / 响应 schema 引用
- ☐ 路径参数、查询参数、请求体、响应体的字段名严格沿用输入契约
- ☐ 错误码引用 `错误码清单.csv` 或显式标 `error_code: pending`

## C. 注解与 cross-cutting 集成
- ☐ Validation 注解（`@Valid`、`@NotNull`、`@Size`）已根据 DTO 字段约束生成
- ☐ Swagger / OpenAPI 注解（`@Operation`、`@Parameter`、`@ApiResponse`）已成对生成
- ☐ Security 注解（`@PreAuthorize` / `@RolesAllowed`）已根据 N170 安全设计生成
- ☐ Idempotency / Audit 注解仅在 N170 输入显示需要时生成，否则标 `pending`

## D. 响应封装与异常处理
- ☐ 响应统一封装在 `ApiResponse<T>` 或同等 envelope 内（除非输入显式禁止）
- ☐ 异常映射委托 `exception-class-generation` 产物，未在本 controller 中重新定义异常
- ☐ 分页响应使用稳定 envelope（`Page<T>` / `PageResult<T>`），字段名与 DTO 对齐

## E. 推断与发明纪律
- ☐ 未给出 base controller 时不臆造继承关系，标 `pending`
- ☐ 未给出 service 接口时不臆造方法签名，仅标 `expected_service_method: <name>` 进 `pending[]`
- ☐ 所有推断进 `inferred[]` 并引用 OpenAPI path / schema field

## F. 追溯与下游交接
- ☐ `traces_to_tasks[]` 引用 N180 task_id（实现 endpoint 的任务）
- ☐ `downstream_consumers: [N200, N210, N330]` 已声明
- ☐ `to_service_draft.expected_methods[]` 已写明
- ☐ `to_dto_vo.required_request_dtos[]` / `required_response_dtos[]` 已写明

## G. 红线问题
- ☐ 没有把 Entity 直接作为 request / response 类型暴露
- ☐ 没有在 `migration_mode` 中重写路由路径
- ☐ 没有在 `quick_endpoint` 模式下伪造完整 swagger / security 注解集
