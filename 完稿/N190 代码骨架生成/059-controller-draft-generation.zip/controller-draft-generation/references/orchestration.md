# controller-draft-generation 编排说明 v2.3

## 上游优先级

1. `接口设计草案.yaml`（N150 OpenAPI）— 决定 endpoint 路径、HTTP 方法、请求/响应 schema
2. `接口意图清单.csv`（N120）— 弱契约场景下的 endpoint 范围
3. `工程骨架.zip`（N190 sibling，code-scaffold-generation）— 提供 `package_layout` 与 `base_controller` / `response_envelope`
4. `业务规则清单.csv`（N070）— 影响 endpoint 行为的业务规则
5. `错误码清单.csv`（N150 副产物）— swagger `@ApiResponse` 引用
6. `安全风险分析.md`（N170）— `@PreAuthorize` 表达式
7. `开发任务拆分表.csv`（N180）— `traces_to_tasks[]`

最小输入：单个 endpoint 描述 / OpenAPI path / CRUD 实体描述任一即可（`quick_endpoint` 模式）。

## 下游衔接

| 下游 sibling | 提供字段 | 用途 |
|---|---|---|
| `service-draft-generation` | `to_service_draft.expected_methods[]` | service 应实现的方法签名 |
| `dto-vo-generation`（N200） | `to_dto_vo.required_request_dtos[]` / `required_response_dtos[]` | DTO 类生成清单 |
| `validator-code-generation`（N200） | `to_validator.required_field_rules[]` | 字段级校验规则来源 |

| 下游节点 | 消费字段 | 用途 |
|---|---|---|
| **N200** | `required_dtos` / `error_codes` | DTO 与异常类生成 |
| **N210** | `endpoint_files[]` | 静态检查范围 |
| **N240** | `endpoint_signatures[]` / `expected_status_codes[]` | API 测试生成 |
| **N330** | `api_surface` | API 文档（OpenAPI 已有则复用） |

## 字段级映射

### N150 (OpenAPI) → controller
| OpenAPI 字段 | controller 字段 | 说明 |
|---|---|---|
| `paths.{path}.{method}.operationId` | 方法名 | 直接对应；若 operationId 缺失则按 path + method 推导 |
| `paths.{path}.{method}.requestBody.schema.$ref` | request DTO 类型 | 通过 N200 dto-vo-generation 解析 |
| `paths.{path}.{method}.responses.{code}.schema.$ref` | response DTO 类型 | 同上 |
| `paths.{path}.{method}.parameters[]` | `@RequestParam` / `@PathVariable` / `@RequestHeader` 注解 | 按 `in` 字段分流 |
| `paths.{path}.{method}.security[]` | `@PreAuthorize` / `@RolesAllowed` | 与 N170 安全模型对齐 |
| `components.responses.ErrorXXX` | `@ApiResponse` 引用 | 与错误码清单对齐 |

### N070 业务规则 → controller
| 业务规则字段 | controller 体现 |
|---|---|
| `rule_id` | swagger 注解中标 `@Operation(description="...see RULE-007")` |
| `rule_type: validation` | 对应 `@Valid` 触发的字段约束 |
| `rule_type: business_logic` | controller 不实现，下推给 service；仅注释引用 |

## 反向约束

### controller 基于 sibling 的约束
- `service_method_calls[]` 中的方法签名必须能在 service-draft-generation 输出中找到；不匹配进 `unresolved_references[]`。
- request/response DTO 类型必须在 dto-vo-generation 输出中存在；否则进 `to_dto_vo.required_*[]`。
- 包路径必须落在 code-scaffold-generation 的 `package_layout.base + .web` 内。

### 错误码引用约束
- 每个 `@ApiResponse(code=4xx)` 必须引用 `错误码清单.csv` 中存在的 error_code；缺失进 `pending[]`。

## Mode-specific orchestration

| Mode | 上游消费 | 下游 handoff |
|---|---|---|
| `quick_endpoint` | 单个 OpenAPI path 即可 | 仅声明该 endpoint 的最小 service/dto 引用 |
| `full_controller` | 完整 OpenAPI + N070 + N170 | 完整 service/dto/validator handoff |
| `crud_batch` | 多个实体 + 表结构 | 每实体一份 DTO 清单与 service 方法清单 |
| `migration_mode` | 已有 controller 源码 + 新约定 | 输出 diff，保留路径不变 |
