# Example IO - Controller v2.4

## Input excerpt
```yaml
openapi_spec_or_endpoint_list:
  - operation_id: createOrder
    http_method: POST
    path: /api/v1/orders
    request_body: CreateOrderRequest
    responses: [201, 400, 401, 403, 409]
scaffold_contract:
  shared_common_module:
    response_envelope: ApiResponse
  annotation_catalog:
    idempotency: [Idempotent]
    audit: [Auditable]
authorization_model:
  type: permission_based
  permission: ORDER_CREATE
n180_core_flow_inventory:
  - core_flow_id: FLOW-ORDER-CREATE
    task_id: TASK-ORDER-CREATE
    resource: order
    action: create
    trigger: HTTP_POST
```

## Output excerpt
```yaml
artifact_contract:
  schema_version: skills.codegen.controller.v2.4
  artifact_type: controller_contract
  produced_by: controller-draft-generation
  readiness: contract_aligned
  confirmed: [createOrder operation, response envelope, permission]
  inferred: [service signature createOrder]
  pending: [actual generated file not compiled]
controller_contract:
  endpoint_method_map:
    - api_ref: createOrder
      http_method: POST
      path: /api/v1/orders
      method_name: createOrder
  service_signature_hints:
    - method_name: createOrder
      request_type: CreateOrderRequest
      response_type: OrderResponse
      nfr_context_params: [idempotency_key]
      source_api_ref: createOrder
  controller_action_surface_matrix:
    - surface_id: ORDER-CREATE
      source_refs: [createOrder, FLOW-ORDER-CREATE]
      n150_endpoint_refs: [createOrder]
      n180_core_flow_refs: [FLOW-ORDER-CREATE]
      resource: order
      action: create
      surface_kind: resource_crud
      route: "POST /api/v1/orders"
      non_http_reason: null
      service_call_refs: [OrderService.createOrder]
      permission_guard_refs: [ORDER_CREATE]
      request_model_refs: [CreateOrderRequest]
      response_model_refs: [OrderResponse]
      positive_test_handoff_refs: [OrderControllerTest.create_order_201]
      negative_test_handoff_refs: [OrderControllerTest.create_order_409_duplicate]
      coverage_status: covered
      gap_reason: ""
  controller_action_surface_summary:
    expected_surface_count: 1
    covered_surface_count: 1
    scoped_deferred_surface_count: 0
    uncovered_surface_count: 0
```
