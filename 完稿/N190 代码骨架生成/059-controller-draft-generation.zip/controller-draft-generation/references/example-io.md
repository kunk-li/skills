# Example IO - Controller v2.3

## Input excerpt
```yaml
openapi_spec_or_endpoint_list:
  - operation_id: createOrder
    http_method: POST
    path: /api/v1/orders
    request_body: CreateOrderRequest
    responses: [201, 400, 401, 403, 409]
scaffold_contract:
  shared_common_module:
    response_envelope: ApiResponse
  annotation_catalog:
    idempotency: [Idempotent]
    audit: [Auditable]
authorization_model:
  type: permission_based
  permission: ORDER_CREATE
```

## Output excerpt
```yaml
artifact_contract:
  schema_version: skills.codegen.controller.v2.3
  artifact_type: controller_contract
  produced_by: controller-draft-generation
  readiness: contract_aligned
  confirmed: [createOrder operation, response envelope, permission]
  inferred: [service signature createOrder]
  pending: [actual generated file not compiled]
controller_contract:
  endpoint_method_map:
    - api_ref: createOrder
      http_method: POST
      path: /api/v1/orders
      method_name: createOrder
  service_signature_hints:
    - method_name: createOrder
      request_type: CreateOrderRequest
      response_type: OrderResponse
      nfr_context_params: [idempotency_key]
      source_api_ref: createOrder
```
