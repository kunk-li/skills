# N190 code generation scoring rubric v2.3

总分 8 分，按以下 4 个维度各 0–2 分。`overall_level` 映射：8 分 = S，6–7 分 = A，4–5 分 = B，<4 分 = C。

## 1. standalone_usability（独立可用性）

- **2 分**：最小输入即可执行；输出 `artifact_contract` 完整可单独使用，不强依赖 sibling skill。
- **1 分**：依赖推荐输入（OpenAPI / 表结构 / 实体）才能产出有效结果。
- **0 分**：缺少推荐输入即无法降级，直接 blocked。

## 2. contract_completeness（契约完整度）

- **2 分**：`artifact_contract` 全部必填字段写齐；`readiness` / `evidence_profile` / `inferred[]` / `pending[]` 显式声明；`traces_to_tasks[]` 在有 N180 输入时填写。
- **1 分**：关键字段已填，但部分子字段为 null 或 pending 未注明原因。
- **0 分**：超过 30% 必填字段为 null，或 readiness 未声明。

## 3. uncertainty_handling（不确定性处理）

- **2 分**：所有推断进 `inferred[]` 并引用触发输入字段；未知进 `pending[]`；未声明 `stack_declaration` 时主动标 `pending`；从不静默发明类名 / 包路径 / 框架选型。
- **1 分**：部分推断未标注；少量字段静默使用默认值。
- **0 分**：静默发明类名、包名、框架或注解集合。

## 4. downstream_handoff（下游交接）

- **2 分**：`downstream_consumers` 显式列出 N200 / N210 / N330；sibling 字段引用精确（如 `to_controller_draft.base_controller`），下游可直接消费。
- **1 分**：有 handoff 段落但字段名模糊或层级不清。
- **0 分**：无 `downstream_handoff` 段落，或仅泛泛指向"下一节点"。

## 红线（直接 0 分）

- 声明 `build_verified: true` 但未提供执行命令与输出证据。
- 兄弟 skill 契约冲突未进入 `pending[]` 或 `self_gate.failed_rules[]`。
- 输入分类未执行就直接给 `readiness: pass`。
