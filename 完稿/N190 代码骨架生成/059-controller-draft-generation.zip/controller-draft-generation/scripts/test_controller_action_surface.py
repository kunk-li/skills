#!/usr/bin/env python3
from __future__ import annotations

import tempfile
from pathlib import Path

from validate_controller_action_surface import validate


def base_contract() -> dict:
    return {
        "artifact_contract": {
            "schema_version": "skills.codegen.controller.v2.4",
            "produced_by": "controller-draft-generation",
            "selected_mode": "full_controller",
            "readiness": "pass",
            "expected_controller_action_surface_count": 2,
        },
        "controller_contract": {
            "controller_action_surface_matrix": [
                {
                    "surface_id": "ORDER-CREATE",
                    "source_refs": ["N150:createOrder", "N180:FLOW-ORDER-CREATE"],
                    "n150_endpoint_refs": ["createOrder"],
                    "n180_core_flow_refs": ["FLOW-ORDER-CREATE"],
                    "resource": "order",
                    "action": "create",
                    "surface_kind": "resource_crud",
                    "route": "POST /api/v1/orders",
                    "non_http_reason": "",
                    "service_call_refs": ["OrderService.createOrder"],
                    "permission_guard_refs": ["ORDER_CREATE"],
                    "request_model_refs": ["CreateOrderRequest"],
                    "response_model_refs": ["OrderResponse"],
                    "positive_test_handoff_refs": ["OrderControllerTest.create_order_201"],
                    "negative_test_handoff_refs": ["OrderControllerTest.create_order_409_duplicate"],
                    "coverage_status": "covered",
                    "gap_reason": "",
                },
                {
                    "surface_id": "ORDER-EXPORT",
                    "source_refs": ["N150:exportOrders", "PERM:ORDER_EXPORT"],
                    "n150_endpoint_refs": ["exportOrders"],
                    "n180_core_flow_refs": ["FLOW-ORDER-EXPORT"],
                    "resource": "order",
                    "action": "export",
                    "surface_kind": "export",
                    "route": "GET /api/v1/orders/export",
                    "non_http_reason": "",
                    "service_call_refs": ["OrderService.exportOrders"],
                    "permission_guard_refs": ["ORDER_EXPORT"],
                    "request_model_refs": ["OrderExportQuery"],
                    "response_model_refs": ["FileResponse"],
                    "positive_test_handoff_refs": ["OrderControllerTest.export_order_200"],
                    "negative_test_handoff_refs": ["OrderControllerTest.export_order_403"],
                    "coverage_status": "covered",
                    "gap_reason": "",
                },
            ],
            "controller_action_surface_summary": {
                "expected_surface_count": 2,
                "covered_surface_count": 2,
                "scoped_deferred_surface_count": 0,
                "uncovered_surface_count": 0,
            },
        },
    }


def main() -> int:
    good = base_contract()

    bad_missing_surface = base_contract()
    bad_missing_surface["controller_contract"]["controller_action_surface_matrix"] = (
        bad_missing_surface["controller_contract"]["controller_action_surface_matrix"][:1]
    )
    bad_missing_surface["controller_contract"]["controller_action_surface_summary"] = {
        "expected_surface_count": 2,
        "covered_surface_count": 1,
        "scoped_deferred_surface_count": 0,
        "uncovered_surface_count": 1,
    }

    bad_missing_service = base_contract()
    bad_missing_service["controller_contract"]["controller_action_surface_matrix"][0]["service_call_refs"] = []

    good_errors = validate(good)
    missing_surface_errors = validate(bad_missing_surface)
    missing_service_errors = validate(bad_missing_service)
    if good_errors:
        print("TEST-CONTROLLER-ACTION-SURFACE status=fail case=good errors=" + repr(good_errors))
        return 2
    if not missing_surface_errors:
        print("TEST-CONTROLLER-ACTION-SURFACE status=fail case=bad_missing_surface_passed")
        return 2
    if not missing_service_errors:
        print("TEST-CONTROLLER-ACTION-SURFACE status=fail case=bad_missing_service_passed")
        return 2
    with tempfile.TemporaryDirectory() as tmp:
        Path(tmp, "evidence.txt").write_text(
            "good_passed=true\nbad_missing_surface_failed=true\nbad_missing_service_failed=true\n",
            encoding="utf-8",
        )
    print(
        "TEST-CONTROLLER-ACTION-SURFACE status=pass "
        "good_passed=true bad_missing_surface_failed=true bad_missing_service_failed=true"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
