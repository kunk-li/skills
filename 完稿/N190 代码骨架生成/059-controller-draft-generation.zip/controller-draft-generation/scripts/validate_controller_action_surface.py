#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


MATRIX_MODES = {"full_controller", "crud_batch"}
HIGH_READINESS = {"pass", "contract_aligned", "implementation_ready", "build_verified"}
VALID_STATUSES = {"covered", "scoped_deferred", "blocked"}
REQUIRED_COVERED_FIELDS = [
    "source_refs",
    "resource",
    "action",
    "service_call_refs",
    "positive_test_handoff_refs",
    "negative_test_handoff_refs",
]


def as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def int_field(value: Any, default: int = -1) -> int:
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def nonempty(row: dict[str, Any], field: str) -> bool:
    value = row.get(field)
    if isinstance(value, list):
        return bool(value)
    if isinstance(value, str):
        return bool(value.strip())
    return value is not None


def any_nonempty(row: dict[str, Any], fields: list[str]) -> bool:
    return any(nonempty(row, field) for field in fields)


def load_contract(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("top-level JSON must be an object")
    return data


def contract_blocks(data: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    artifact = data.get("artifact_contract", data)
    if not isinstance(artifact, dict):
        raise ValueError("artifact_contract must be an object")
    controller = data.get("controller_contract")
    if not isinstance(controller, dict):
        controller = artifact.get("controller_contract")
    if not isinstance(controller, dict):
        controller = artifact
    return artifact, controller


def validate(data: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    artifact, controller = contract_blocks(data)
    selected_mode = str(artifact.get("selected_mode") or "").strip()
    readiness = str(artifact.get("readiness") or "").strip()
    matrix_required = selected_mode in MATRIX_MODES or readiness in HIGH_READINESS

    matrix = as_list(controller.get("controller_action_surface_matrix"))
    if not matrix:
        matrix = as_list(artifact.get("controller_action_surface_matrix"))
    summary = controller.get("controller_action_surface_summary")
    if not isinstance(summary, dict):
        summary = artifact.get("controller_action_surface_summary")
    if not isinstance(summary, dict):
        summary = {}

    expected = int_field(
        summary.get("expected_surface_count"),
        int_field(artifact.get("expected_controller_action_surface_count"), len(matrix)),
    )

    if matrix_required and expected <= 0:
        errors.append("controller_action_surface_summary.expected_surface_count must be > 0 for high-readiness controller outputs")
    if matrix_required and not matrix:
        errors.append("controller_action_surface_matrix is required for high-readiness controller outputs")

    if expected >= 0 and len(matrix) != expected:
        errors.append("controller_action_surface_matrix must contain exactly one row per expected action surface")

    counts = {"covered": 0, "scoped_deferred": 0, "blocked": 0}
    seen_ids: set[str] = set()
    for idx, item in enumerate(matrix):
        if not isinstance(item, dict):
            errors.append(f"controller_action_surface_matrix[{idx}] must be an object")
            continue
        surface_id = str(item.get("surface_id") or "").strip()
        if not surface_id:
            errors.append(f"controller_action_surface_matrix[{idx}].surface_id is required")
        elif surface_id in seen_ids:
            errors.append(f"duplicate surface_id: {surface_id}")
        else:
            seen_ids.add(surface_id)

        status = str(item.get("coverage_status") or "").strip()
        if status not in VALID_STATUSES:
            errors.append(f"{surface_id or idx}: coverage_status must be covered, scoped_deferred, or blocked")
            continue
        counts[status] += 1

        if status == "covered":
            for field in REQUIRED_COVERED_FIELDS:
                if not nonempty(item, field):
                    errors.append(f"{surface_id or idx}: covered row missing {field}")
            if not any_nonempty(item, ["route", "non_http_reason"]):
                errors.append(f"{surface_id or idx}: covered row needs route or non_http_reason")
            if not any_nonempty(item, ["permission_guard_refs", "permission_boundary_rationale"]):
                errors.append(f"{surface_id or idx}: covered row needs permission_guard_refs or permission_boundary_rationale")
            if not any_nonempty(item, ["request_model_refs", "request_model_rationale"]):
                errors.append(f"{surface_id or idx}: covered row needs request_model_refs or request_model_rationale")
            if not any_nonempty(item, ["response_model_refs", "response_model_rationale"]):
                errors.append(f"{surface_id or idx}: covered row needs response_model_refs or response_model_rationale")
        else:
            if not nonempty(item, "gap_reason"):
                errors.append(f"{surface_id or idx}: {status} row needs gap_reason")

    expected_counts = {
        "covered_surface_count": counts["covered"],
        "scoped_deferred_surface_count": counts["scoped_deferred"],
        "uncovered_surface_count": counts["blocked"],
    }
    for field, value in expected_counts.items():
        if int_field(summary.get(field)) != value:
            errors.append(f"controller_action_surface_summary.{field} must equal {value}")

    if readiness == "pass" and counts["blocked"] > 0:
        errors.append("readiness=pass requires uncovered_surface_count=0")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate controller action-surface coverage.")
    parser.add_argument("contract_json", type=Path)
    args = parser.parse_args()

    try:
        errors = validate(load_contract(args.contract_json))
    except Exception as exc:
        print(f"CONTROLLER-ACTION-SURFACE status=fail error={exc}", file=sys.stderr)
        return 2
    if errors:
        print("CONTROLLER-ACTION-SURFACE status=fail")
        for error in errors:
            print(f"- {error}")
        return 2
    print("CONTROLLER-ACTION-SURFACE status=pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
