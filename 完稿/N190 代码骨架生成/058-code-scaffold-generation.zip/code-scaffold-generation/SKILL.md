---
name: code-scaffold-generation
description: Generate project scaffolds and shared engineering foundations — package layout, bootstrap, CI/CD, and cross-cutting infra: logging, tracing, auth, idempotency, rate limiting, circuit breakers.
---

# Code Scaffold Generation

## Purpose

Generate a reusable scaffold code-generation contract. Keep this skill generic, contract-first, and honest about evidence. This v2.3 version keeps the v2.2.1 node-agnostic design and adds v2 reactive workflow anchors, structured input classification, explicit produced-event declaration, tech_stack_adapter chapter, and clearer minimum-input degradation rules.

## Workflow anchors

```yaml
function_bias: direct_result
workflow_node: N190
node_artifact_target: source_tree_contribution   # 默认 source_tree_write;draft_package 模式退化为 工程骨架.zip
output_target_mode: source_tree_write            # source_tree_write(默认·持续开发) | draft_package(一次性 greenfield)
generation_scope: incremental                    # incremental(默认·只产/patch 目标功能相关文件) | full(整层批量)
node_artifact_role: project scaffold and cross-cutting infrastructure code draft
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
event_aggregation_note: >
  This skill does not publish its own produced event directly to the event bus.
  The N190 node orchestrator (or scaffold-package-aggregator when present)
  is responsible for emitting produced.N190.scaffold_package after all four
  N190 skills complete. Each skill contributes its artifact_contract to that
  aggregation step.
```

## 产物落地模型 / Output target model（v2.1 新增·CAND-A3-CODEGEN-01 折叠）

codegen 类 skill 的产物是**对一棵共享模块源码树的贡献**,不是各自一个 zip 包。两种模式:

- **`source_tree_write`(默认·持续开发)**:把生成的 .java/.sql 等**就地写入调用方给定的共享源码树**,按包路径落位(如 `<module_root>/src/main/java/<pkg>/...`)。产物身份 = 被写/改文件的清单(`written_files[]` / `patched_files[]`),不是 zip。zip 仅在分发时可选打包,**不作为 node artifact 身份**(与 v2-contract「zip 文件名只是分发期提示」一致)。
- **`draft_package`(一次性 greenfield)**:无既有树时,才退化为打成一个 `工程骨架.zip` 草稿包供 review。**此模式仅用于从零起、无共享树的场景**。

**生成粒度 `generation_scope`**:
- **`incremental`(默认)**:调用方给定**目标范围**(一个功能 / 一个实体 / 一组接口),只生成或修改**与该目标相关的文件**;先探测共享树里是否已存在同名类——**已存在则不覆盖**,改为输出 patch/diff 或就地增强并在 `patched_files[]` 标注,其余文件一律不碰。
- **`full`**:整层批量生成(仅 greenfield 或用户显式要求整层重建时用)。

**去重叠铁律(no-duplication)**:不得重复生成本 N190/N200 家族其它 skill 已贡献进共享树的类(scaffold 已产的 enum / exception / base 类等)。检测到已有 → **补齐缺的 / 就地增强,不另起一份**,避免同一类在多个产物里各一份。

产物落地后必须在 `artifact_contract` 里如实列 `output_target_mode` / `generation_scope` / `written_files[]` / `patched_files[]` / `skipped_existing[]`。



## Selected mode / mode selection

Every result must declare `selected_mode`, `readiness`, and `evidence_profile` inside the `artifact_contract` block.

Allowed modes:
- `quick_skeleton` — minimal scaffold for early POCs; emit core layout + bootstrap only, defer cross-cutting layers.
- `full_scaffold` — default mode; emit complete scaffold including layout, common modules, cross-cutting infra, and CI/CD hints.
- `cross_cutting_only` — assume scaffold exists; emit only logging / tracing / auth / idempotency / audit / rate-limit / circuit-breaker decisions.
- `incremental_patch` — retrofit an existing project; emit only the delta against the input project layout, never overwrite existing decisions.

## Readiness 决策表

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 推荐输入全部齐备；技术栈明确；无未解决冲突 | 完整产物 + 所有契约字段填写 |
| `provisional` | 核心输入齐备；推荐输入部分缺失 | 输出已知层；缺失层进 `pending[]`；`evidence_profile: mixed` |
| `constrained` | 仅有描述性文字；无结构化输入文件 | 从文字提取意图；所有字段标 `inferred`；`tech_stack_declaration: pending` |
| `blocked` | 无任何可用输入 | 输出 `request_for_inputs[]`；列明最小输入要求 |

## Required v2 reactive output blocks

Every output must begin with the following YAML block before any skill-specific content:

```yaml
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: code-scaffold-generation
  producer_node: N190
  output_target_mode: source_tree_write | draft_package   # 默认 source_tree_write
  generation_scope: incremental | full                    # 默认 incremental
  artifact_name: source_tree_contribution                 # draft_package 模式=工程骨架.zip
  artifact_type: code_source_contribution | code_draft
  written_files: []
  patched_files: []
  skipped_existing: []
  target_scope: "<incremental 时:本次目标功能/实体/接口>"
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N200, N210, N330]
  traces_to_tasks: []   # task_ids from N180 开发任务拆分表.csv that this scaffold covers

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending: []

quality_self_score:
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
```

## Genericity rule

This skill is a reusable atomic capability. Do not bind its instructions or outputs to a workflow node id, stage id, downstream node id, or node-specific filename. When a workflow node uses this skill, put node routing, aggregation, event publication, and downstream naming in the node orchestrator, not in this skill.

## Input classification

### minimum / core_required (at least one required)
- `技术方案分析.md` (from N130) — module intent, layer decisions
- `接口意图清单.csv` (from N120) — service entry points
- a textual description of the service/module to scaffold

If none are present: set `readiness: blocked`, output only a skeleton template with all fields `pending`.

### recommended (workflow-aligned)
- `技术方案分析.md` from N130
- `接口设计草案.yaml` from N150 — drives controller/API layer decisions
- `表结构设计草案.sql` from N160 — drives repository/entity layer decisions
- `开发任务拆分表.csv` from N180 — populates `traces_to_tasks[]`
- `并发控制建议.md` / `幂等设计建议.md` / `安全风险分析.md` from N170 — cross-cutting infrastructure selection

### optional enrichment
- `模块边界图.md` / `服务拆分建议.md` from N140 — package layout
- CI/CD pipeline requirements, existing project conventions

### degradation rules
- Missing recommended inputs → `readiness: constrained`; emit only confirmed layers, mark missing layers `pending`.
- Missing `traces_to_tasks` → set to `[]`, note `evidence_profile: heuristic_only` for task tracing.
- Never invent package names, class names, or framework choices without citing the matched input field.

## Enum and schema policy

Load `references/shared-codegen-enums.yaml` before reading or writing any contract field that uses an enum. Use the shared `query_purpose` and `cardinality` enums exactly so sibling skills can compose without manual string mapping. Use neutral schema namespaces such as `skills.codegen.scaffold.v2.3`; do not use workflow-node ids inside skill-level schema versions.

## Rule source authority

Use YAML contracts as the authoritative source for schemas, enums, algorithms, and self-checks. Treat Markdown reference files as explanatory guides only; when Markdown guidance conflicts with `*-algorithms.yaml`, `*-input-contract.yaml`, `*-output-contract.yaml`, `*-self-check.yaml`, or `shared-codegen-enums.yaml`, follow the YAML file and record the conflict in `pending[]`.

## Execution workflow

1. Emit the `artifact_contract` / `self_gate` / `quality_self_score` block first.
2. Classify inputs (minimum / recommended / optional) and set `readiness` and `evidence_profile`.
3. Load the input contract, output contract, shared enum dictionary, and algorithm table.
4. Normalize inputs into the field names defined by `references/scaffold-input-contract.yaml`.
5. Apply the structured algorithms in `references/scaffold-algorithms.yaml`. Cite matched rule id in `inferred[]` for every inferred decision.
6. Emit `scaffold_contract` using `references/scaffold-output-contract.yaml`. Include all required fields even when values are `pending`.
7. Apply `references/scaffold-self-check.yaml` and populate `self_gate`.
8. Populate `traces_to_tasks[]` from N180 task ids where available.
9. Add human-readable notes only after the machine-readable contract.

## Output contract

Every output must start with a YAML block named `artifact_contract`. Never claim `build_verified` unless a build/test command was actually run and evidence is shown. Put assumptions in `inferred[]` and unknowns in `pending[]` instead of silently inventing facts.

## Tech stack adapter

Output defaults to Java (Spring Boot) examples. Switch to the appropriate adapter when context indicates a different stack:

| Stack | Scaffold conventions |
|---|---|
| Java / Spring Boot | Maven/Gradle multi-module, `@SpringBootApplication`, package-by-feature |
| TypeScript / Node | pnpm workspace / nx monorepo, barrel exports, `tsconfig.json` per module |
| Python | `pyproject.toml` / poetry, src-layout, `__init__.py` per layer |
| Go | Go modules, `cmd/` + `internal/` + `pkg/` layout |
| Kotlin / Spring | Same as Java but with `data class` and coroutine-aware scaffold hints |

Never present a Java-only solution as the universal standard. If the stack is unknown, output a neutral scaffold with placeholders and record `stack_declaration: pending`.

## Produced event / 产物事件

本 skill 是 N190 节点的子技能，产物交由 `scaffold-package-aggregator` 聚合后统一发布节点级事件：

```yaml
event_emission:
  emitted_by: standalone_skill
  node_event_publisher: scaffold-package-aggregator
  artifact_contract_field: artifact_contract.readiness
  artifact_name: source_tree_contribution   # draft_package 模式为 工程骨架.zip
  downstream_consumers: [N200, N210, N240, N330]
  note: >
    本 skill 不自行发布 produced.n190.scaffold_package 事件。
    完成后通知 scaffold-package-aggregator 消费 artifact_contract，由聚合器决定节点 readiness。
```

## Boundary

This skill emits its own layer contract and sibling handoff hints but does not aggregate N190 node results or publish the node-level produced event. Those responsibilities belong to the N190 node orchestrator.

## Composition

When a sibling contract is supplied, consume it explicitly and name the exact fields used. For inconsistent sibling contracts, record the mismatch in `pending[]` or `self_check_result.blockers`.

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可执行，输出可独立使用 | 依赖推荐输入才可用 | 无最小输入也无法降级 |
| `contract_completeness` | artifact_contract 所有字段填写，无 null 留白 | 关键字段已填，部分 pending | 超过 30% 字段为 null |
| `uncertainty_handling` | 所有推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明类名/框架 |
| `downstream_handoff` | sibling 字段引用精确，下游可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。`quality_self_score` 必须在 `self_gate` 之后、人类可读说明之前输出。

## Machine-readable self_check rules

- `R01_artifact_contract_first`: 每次输出必须以 `artifact_contract` YAML 块开头; `on_violation: reject`
- `R02_readiness_set`: `readiness` 必须是 `pass | provisional | constrained | blocked` 之一; `on_violation: reject`
- `R03_no_invented_names`: 未引用输入字段时不得臆造类名/包名/框架选型; `on_violation: reject`
- `R04_build_verified_evidence`: 声明 `build_verified` 必须附实际执行命令和输出作为证据; `on_violation: reject`
- `R05_pending_not_silent`: 未知值必须进入 `pending[]`，不得静默省略; `on_violation: reject`
- `R06_tech_stack_declared`: `stack_declaration` 必须明确声明或标为 `pending`; `on_violation: warn`
- `R07_traces_to_tasks_set`: `traces_to_tasks[]` 必须引用 N180 task_id 或显式设为 `[]` 并注明 `evidence_profile`; `on_violation: warn`
- `R08_sibling_conflict_recorded`: 兄弟 skill 契约冲突必须进入 `pending[]` 或 `self_gate.failed_rules[]`，不得静默覆盖; `on_violation: reject`

## Common failure modes

1. **Stack assumption leak** — 未声明 `stack_declaration` 就默认输出 Java-only 方案，非 Java 项目无法使用。修复：先检查上下文中的框架标志（`pom.xml`/`package.json`/`go.mod`），未知时设 `stack_declaration: pending`。
2. **Silent invention** — 缺少输入时臆造类名或包路径，导致下游编译失败。修复：所有推断值写入 `inferred[]` 并引用触发的输入字段；无对应字段时进入 `pending[]`。
3. **Missing readiness gate** — 推荐输入全部缺失时仍输出 `readiness: pass`，误导下游节点认为产物可直接使用。修复：执行输入分类后强制重算 `readiness`。

## References

- `references/shared-codegen-enums.yaml`: canonical enum dictionary for all four code-generation skills
- `references/scaffold-input-contract.yaml`: field-level input schema and normalization rules
- `references/scaffold-output-contract.yaml`: required output schema and field contract
- `references/scaffold-self-check.yaml`: executable quality checks and violation policy
- `references/scaffold-algorithms.yaml`: structured decision tables and algorithms
- `references/layout-and-cross-cutting-policy.md`: domain-specific generation guidance
- `references/example-io.md`: concrete input/output example
- `references/routing-metadata.yaml`: optional platform scheduling metadata
- `references/checklist.md`: delivery checklist for self-review before emit
- `references/scoring-rubric.md`: 4-dimension self-scoring rubric (S/A/B/C)
- `references/common-failure-modes.md`: detailed failure mode catalog with symptom/impact/fix
- `references/orchestration.md`: upstream priority, downstream handoff, field-level mapping, mode-specific orchestration
