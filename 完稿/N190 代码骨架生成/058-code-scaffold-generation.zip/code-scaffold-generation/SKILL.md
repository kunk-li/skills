---
name: code-scaffold-generation
description: generate generic project scaffolds and shared engineering foundations. use when asked to create or retrofit a service/module skeleton, choose package layout, define common modules, bootstrap, ci/cd scaffolding, or cross-cutting infrastructure such as logging, tracing, validation, error handling, auth, idempotency, audit, rate limiting, or circuit breakers. standalone and node-agnostic; v2.2.1 adds shared enum alignment, input contracts, and structured algorithms.
---

# Code Scaffold Generation

## Purpose

Generate a reusable scaffold code-generation contract. Keep this skill generic, contract-first, and honest about evidence. This v2.2.1 version keeps the v2.1 node-agnostic design and adds shared enum alignment, field-level input contracts, structured algorithms, metadata checks, and richer examples.

## Genericity rule

This skill is a reusable atomic capability. Do not bind its instructions or outputs to a workflow node id, stage id, downstream node id, or node-specific filename. When a workflow node uses this skill, put node routing, aggregation, event publication, and downstream naming in the node orchestrator, not in this skill.

## Input policy

Use the best available inputs without blocking on perfect upstream context. First load `references/scaffold-input-contract.yaml` and classify inputs as minimum, recommended, or enhanced. For every important field, record whether the value is confirmed, inferred, or pending. If minimum inputs are missing, ask for the missing contract or produce only a safe provisional outline.

## Enum and schema policy

Load `references/shared-codegen-enums.yaml` before reading or writing any contract field that uses an enum. Use the shared `query_purpose` and `cardinality` enums exactly so sibling skills can compose without manual string mapping. Use neutral schema namespaces such as `skills.codegen.scaffold.v2.2.1`; do not use workflow-node ids inside skill-level schema versions.

## Rule source authority

Use YAML contracts as the authoritative source for schemas, enums, algorithms, and self-checks. Treat Markdown reference files as explanatory guides only; when Markdown guidance conflicts with `*-algorithms.yaml`, `*-input-contract.yaml`, `*-output-contract.yaml`, `*-self-check.yaml`, or `shared-codegen-enums.yaml`, follow the YAML file and record the conflict in `pending[]`.

## Execution workflow

1. Load the input contract, output contract, shared enum dictionary, and algorithm table for this skill.
2. Normalize inputs into the field names defined by `references/scaffold-input-contract.yaml`.
3. Apply the structured algorithms in `references/scaffold-algorithms.yaml`. When a decision is inferred, cite the matched rule id in `inferred[]` or the relevant contract field.
4. Emit `scaffold_contract` using `references/scaffold-output-contract.yaml`. Include all required fields even when values are `pending`.
5. Apply `references/scaffold-self-check.yaml` and include `self_check_result.passed`, `warnings`, and `blockers`.
6. Add human-readable notes only after the machine-readable contract.

## Output contract

Every output must start with a YAML block named `artifact_contract`. Never claim `build_verified` unless a build/test command was actually run and evidence is shown. Put assumptions in `inferred[]` and unknowns in `pending[]` instead of silently inventing facts.

## Boundary

Use the boundary rules in the output and self-check contracts. This skill should emit its own layer contract and sibling handoff hints, but should not take responsibility for node-level aggregation or unrelated architectural layers.

## Composition

When a sibling contract is supplied, consume it explicitly and name the exact fields used. When this skill emits handoff hints for a sibling skill, use the structured contract fields and shared enum dictionary rather than prose-only handoff. For inconsistent sibling contracts, record the mismatch in `pending[]` or `self_check_result.blockers` according to the self-check severity.

## References

- `references/shared-codegen-enums.yaml`: canonical enum dictionary for all four code-generation skills
- `references/scaffold-input-contract.yaml`: field-level input schema and normalization rules
- `references/scaffold-output-contract.yaml`: required output schema and field contract
- `references/scaffold-self-check.yaml`: executable quality checks and violation policy
- `references/scaffold-algorithms.yaml`: structured decision tables and algorithms
- `references/layout-and-cross-cutting-policy.md`: domain-specific generation guidance
- `references/example-io.md`: concrete input/output example
- `references/routing-metadata.yaml`: optional platform scheduling metadata
