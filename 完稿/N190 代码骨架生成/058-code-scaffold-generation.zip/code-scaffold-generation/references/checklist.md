# code-scaffold-generation 交付检查清单 v2.3

## A. artifact_contract 完整性
- ☐ 输出以 `artifact_contract` YAML 块开头
- ☐ `schema_version: n190.artifact.v2.3` 已声明
- ☐ `producer_skill: code-scaffold-generation`、`producer_node: N190`、`artifact_name: 工程骨架.zip` 三项一致
- ☐ `readiness` 取值 ∈ {`pass`, `provisional`, `constrained`, `blocked`}
- ☐ `evidence_profile` 取值 ∈ {`direct_contract`, `inferred_from_schema`, `heuristic_only`, `mixed`}
- ☐ `selected_mode` 取值 ∈ {`quick_skeleton`, `full_scaffold`, `cross_cutting_only`, `incremental_patch`}

## B. 输入分类与降级
- ☐ 已检查 minimum/core_required（`技术方案分析.md` / `接口意图清单.csv` / 服务描述）至少存在一项
- ☐ 推荐输入（N130/N150/N160/N170/N180）已逐项标记 confirmed / inferred / missing
- ☐ 推荐输入缺失时 `readiness` 已设为 `constrained` 而非 `pass`
- ☐ 完全无最小输入时 `readiness: blocked` 且仅输出占位骨架

## C. 技术栈与命名纪律
- ☐ `stack_declaration` 已显式声明（java/typescript/python/go/kotlin），未知则填 `pending`
- ☐ 未引用输入字段时未臆造类名 / 包路径 / 框架选型
- ☐ 所有推断进入 `inferred[]` 并附 `matched_rule_id` 或 `source_field`
- ☐ 所有未知进入 `pending[]`，未静默省略

## D. 跨切面 / cross-cutting 决策
- ☐ logging / tracing / validation / error-handling / auth / idempotency / audit / rate-limit / circuit-breaker 九类至少给出 yes / no / pending 三态判断
- ☐ 高于 N170 设计层面的决策（架构级缓存等）已移交 N170/N300，未在本骨架内定案
- ☐ `cross_cutting_only` 模式下不重复输出已存在的层级

## E. 追溯与下游交接
- ☐ `traces_to_tasks[]` 引用 N180 task_id 或显式 `[]` 并注明 `evidence_profile: heuristic_only`
- ☐ `downstream_consumers: [N200, N210, N330]` 已声明
- ☐ `to_controller_draft` / `to_service_draft` / `to_repository_draft` 三个 sibling handoff 字段已写明，缺失字段标 pending
- ☐ 兄弟 skill 契约冲突已进入 `pending[]` 或 `self_gate.failed_rules[]`

## F. 红线问题
- ☐ 没有声明 `build_verified: true` 而未提供命令与输出证据
- ☐ 没有把 java-only 默认包装成"通用方案"
- ☐ 没有在 `incremental_patch` 模式下覆盖已存在的项目决策
- ☐ 没有在 `selected_mode` 与 `readiness` 之间出现矛盾（如 mode=quick_skeleton 但 readiness=pass+full evidence）
