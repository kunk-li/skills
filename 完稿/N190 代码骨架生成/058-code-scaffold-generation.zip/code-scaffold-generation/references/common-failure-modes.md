# code-scaffold-generation 常见失败模式 v2.3

## F1. Stack assumption leak（栈假设泄漏）

**症状**：未声明 `stack_declaration` 就默认输出 Java/Spring Boot 方案，非 Java 项目无法使用；或在 Node/Python 项目中给出 `pom.xml` 路径。

**后果**：下游 controller / service / repository 草稿全部基于错误栈生成；用户无法直接编译；返工成本高。

**修正**：
- 启动阶段先扫描上下文中的栈标志：`pom.xml` / `build.gradle` / `package.json` / `pyproject.toml` / `go.mod` / `Cargo.toml` / `tsconfig.json`。
- 未发现明确栈标志时设 `stack_declaration: pending`，并在 `pending[]` 中要求人工确认。
- 仅当 `stack_declaration` 已确认时使用 `## Tech stack adapter` 表中的对应模板；禁止把 Java 模板包装为"通用方案"。

---

## F2. Silent invention（静默发明）

**症状**：缺少模块边界图或接口设计时，aggregator 自行臆造类名（`OrderServiceImpl`）、包路径（`com.acme.order.service`）、框架选型（默认引入 `springfox`）。

**后果**：下游编译失败或与其他系统命名空间冲突；`evidence_profile` 标 `direct_contract` 但实际是 `heuristic_only`，误导 N210 静态检查。

**修正**：
- 所有臆造值必须进 `inferred[]`，并附 `source_field: <input field that triggered this>`。
- 没有任何输入支持时进 `pending[]`，**不写**进 `confirmed[]` 或 `inferred[]`。
- `R03_no_invented_names` 是 reject 级别红线。

---

## F3. Missing readiness gate（readiness 门禁缺失）

**症状**：minimum 输入（技术方案分析 / 接口意图清单 / 服务描述）全部缺失时仍输出 `readiness: pass`，让下游 N190 sibling 误以为骨架可直接消费。

**后果**：N190 aggregator 收到 4 个 sibling 都标 pass 但实际上 scaffold 主键缺失；package 级 readiness 错误传导；下游 N240 测试基于幻影骨架。

**修正**：
- 执行流程第 2 步必须显式做输入分类（minimum / recommended / optional）。
- minimum 全部缺失 → 强制 `readiness: blocked`，仅输出占位骨架并标全部字段 `pending`。
- minimum 存在但 recommended 大量缺失 → `readiness: constrained`。

---

## F4. Cross-cutting decision overreach（cross-cutting 决策越界）

**症状**：在 N170（非功能设计）尚未决定 idempotency 策略时，scaffold 直接写死 `@Idempotent` 注解；或在没有 N300 缓存设计时输出 Redis 配置。

**后果**：跨节点决策权被前移；N170 / N300 后续输出与 scaffold 冲突，需返工。

**修正**：
- `cross_cutting_only` mode 与 `full_scaffold` mode 都必须先检查 N170 输入；缺失时该项 cross-cutting 标 `pending`，不写默认实现。
- 架构级缓存、限流策略不在 scaffold 内定案；只声明 hook 点（`cache_strategy_hook: pending_n300`）。

---

## F5. incremental_patch 模式覆写已有决策

**症状**：`incremental_patch` 模式下 aggregator 误删/重写用户项目里已有的 `application.yml`、`logback.xml`，破坏既有运行时行为。

**后果**：用户项目损坏；CI 流水线断裂；信任丢失。

**修正**：
- `incremental_patch` 模式仅输出**增量 patch 提议**（diff/summary 形式），不直接覆盖文件。
- 每条 patch 必须显式声明 `affects_files: []` 与 `existing_content_preserved: true|false`。
- 检测到目标文件已存在且未在输入中授权覆盖 → 自动降级为 `proposal_only` 子模式。

---

## F6. quick_skeleton 与 readiness 矛盾

**症状**：`selected_mode: quick_skeleton`（明确表示只输出最小骨架）但同时声明 `readiness: pass` 与 `evidence_profile: direct_contract`。

**后果**：自相矛盾——quick mode 本质是降级输出，不应宣称完整证据。

**修正**：
- `R09_mode_readiness_consistent`（建议新增）：`quick_*` 模式下 `readiness` 不能高于 `provisional`，且 `evidence_profile` 不能高于 `mixed`。
- `cross_cutting_only` 模式下 `readiness` 取决于 cross-cutting 输入完整度，不能继承宿主项目的 readiness。
