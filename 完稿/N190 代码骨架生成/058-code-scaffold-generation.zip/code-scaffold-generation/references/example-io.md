# Example IO - Scaffold v2.3

## Input excerpt
```yaml
service_or_module_description: order service for creating and querying orders
tech_stack_or_stack_assumption:
  language: java
  framework: spring_boot
  build_tool: maven
coding_conventions:
  package_organization: feature_based
nfr_designs:
  idempotency_design: present
  audit_design: present
  authorization_model: permission_based
```

## Output excerpt
```yaml
artifact_contract:
  schema_version: skills.codegen.scaffold.v2.3
  artifact_type: scaffold_contract
  produced_by: code-scaffold-generation
  readiness: contract_aligned
  confirmed: [java spring boot, feature based layout requested]
  inferred: [idempotency and audit capabilities enabled from nfr evidence]
  pending: [actual build not executed]
scaffold_contract:
  service_name: order-service
  package_layout:
    strategy: feature_based
    matched_rule_id: LAYOUT-002
    rationale: feature independence is high and changes should stay localized
  annotation_catalog:
    idempotency: [Idempotent]
    audit: [Auditable]
  handoff:
    to_controller_draft:
      - base_controller: com.company.common.web.BaseController
      - response_envelope: ApiResponse
```
