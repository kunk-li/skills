# code-scaffold-generation 编排说明 v2.3

## 上游优先级

优先复用以下输入，缺失时按降级规则处理：

1. `技术方案分析.md`（N130）— 决定 layer / module 拆分基线
2. `接口意图清单.csv`（N120）— 决定 controller 层 endpoint 范围
3. `模块边界图.md` / `服务拆分建议.md`（N140）— 决定 package_layout
4. `接口设计草案.yaml`（N150）— 与 controller 草稿对齐
5. `表结构设计草案.sql`（N160）— 与 repository 草稿对齐
6. `开发任务拆分表.csv`（N180）— 填 `traces_to_tasks[]`
7. `并发控制建议.md` / `幂等设计建议.md` / `安全风险分析.md`（N170）— cross-cutting 选型

仅有"服务/模块描述"文本时可执行 `quick_skeleton` 模式输出占位骨架，但必须标 `inferred[]`。

## 下游衔接

| 下游 sibling | 提供字段 | 用途 |
|---|---|---|
| `controller-draft-generation` | `package_layout.base + .web` 包路径 / `base_controller` / `response_envelope` / `cross_cutting.swagger` | controller 类的位置与基类 |
| `service-draft-generation` | `package_layout.base + .service` 包路径 / `transaction_manager` / `cross_cutting.transaction_aop` | service 类的位置与事务管理 |
| `repository-draft-generation` | `package_layout.base + .repository` 包路径 / `orm_declaration` / `dialect_declaration` | repository 类的位置与 ORM/方言 |

| 下游节点 | 消费字段 | 用途 |
|---|---|---|
| **N200** | `package_layout.base + .dto` / `.exception` / `.enum` | DTO/枚举/异常类的目标位置 |
| **N210** | `package_layout` 全集 | 静态检查范围 |
| **N240** | `test_layout` / `coverage_target` | 测试代码生成位置 |
| **N330** | `api_surface` | API 文档基线 |

## 字段级映射

### N130 → code-scaffold-generation
| N130 字段 | scaffold 字段 | 说明 |
|---|---|---|
| `system.name` | `service_name` | 一一对应 |
| `layers[]` | `package_layout.strategy` 提示 | feature_based / layer_based 选择参考 |
| `modules[]` | `module_groups[]` | 与 N140 模块边界图协同 |
| `tech_stack` | `stack_declaration` | 必须严格继承，不可改写 |

### N170 → code-scaffold-generation cross-cutting
| N170 输入 | scaffold cross-cutting 字段 | 说明 |
|---|---|---|
| `idempotency_design` | `cross_cutting.idempotency` | enabled / disabled / pending |
| `audit_design` | `cross_cutting.audit` | enabled / disabled / pending |
| `security.authorization_model` | `cross_cutting.auth` | jwt / oauth2 / permission_based / pending |
| `concurrency_design` | `cross_cutting.concurrency` | 锁策略选型提示 |
| `rate_limiting` | `cross_cutting.rate_limit` | bucket / leaky_bucket / disabled / pending |
| `circuit_breaker` | `cross_cutting.circuit_breaker` | resilience4j / hystrix / disabled / pending |

## 反向约束

### 4 sibling 基于 scaffold 的约束
- controller / service / repository 草稿的 `package_path` 必须落在 scaffold `package_layout.base` 内。
- 4 sibling 的 `stack_declaration` 必须与 scaffold 一致；不一致由 N190 aggregator reject。
- annotation_catalog 中声明的注解必须对应实际依赖；遗漏依赖进入 `to_pom.required_dependencies[]`。

### scaffold 基于 N170 的约束
- `cross_cutting.idempotency: enabled` 但 N170 未输出 idempotency_design → 强制降级为 pending。
- 不允许 scaffold 在 N170 之前定案 cross-cutting 选型。

## Mode-specific orchestration

| Mode | 上游消费 | 下游 handoff |
|---|---|---|
| `quick_skeleton` | 仅服务描述即可 | 仅声明 `package_layout.base`；其他层 pending |
| `full_scaffold` | N130-N170 全集 | 完整 4 sibling handoff |
| `cross_cutting_only` | N170 + 已有 scaffold | 仅 cross-cutting 字段更新 |
| `incremental_patch` | 已有项目源码 + N170 增量 | diff/proposal 形式输出 |
