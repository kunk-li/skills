# Layout and cross-cutting policy

> Authoritative source note: this Markdown file is a human-readable guide. The corresponding `*-algorithms.yaml`, input/output contracts, shared enum dictionary, and self-check YAML files are the source of truth for executable decisions.

Choose `layered` for small services or teams familiar with MVC. Choose `feature_based` when feature ownership and parallel work matter. Choose `ddd` or `hexagonal` only when domain complexity justifies the extra boundaries.

Generate cross-cutting capabilities once in common/config/infrastructure locations. Downstream controller/service/repository drafts must consume the annotation catalog and base classes from scaffold_contract instead of inventing their own wrappers.

For incomplete inputs, default to conservative scaffolding and record missing NFR choices in pending[].
