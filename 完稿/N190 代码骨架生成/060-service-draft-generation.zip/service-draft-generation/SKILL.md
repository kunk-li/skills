---
name: service-draft-generation
description: Draft service-layer methods and flow skeletons from controllers, API actions, business rules, and state transitions — transaction boundaries, AOP annotations, exception semantics.
---

# Service Draft Generation

## Purpose

Generate a reusable service code-generation contract. Keep this skill generic, contract-first, and honest about evidence. This v2.3 version keeps the v2.2.1 node-agnostic design and adds v2 reactive workflow anchors, structured selected_mode, delivery checklist, scoring rubric, and clearer minimum-input degradation rules.


## Workflow anchors

```yaml
function_bias: direct_result
workflow_node: N190
node_artifact_target: source_tree_contribution   # 默认 source_tree_write;draft_package 模式退化为 Service草稿.zip
output_target_mode: source_tree_write            # source_tree_write(默认·持续开发) | draft_package(一次性 greenfield)
generation_scope: incremental                    # incremental(默认·只产/patch 目标功能相关文件) | full(整层批量)
node_artifact_role: code_draft for N190 coding scaffold stage
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
event_aggregation_note: >
    This skill does not publish its own produced event directly to the event bus.
  The N190 node orchestrator (or scaffold-package-aggregator when present)
  is responsible for emitting produced.N190.scaffold_package after all four
  N190 skills complete. Each skill contributes its artifact_contract to that
  aggregation step.
```

## 产物落地模型 / Output target model（v2.1 新增·CAND-A3-CODEGEN-01 折叠）

codegen 类 skill 的产物是**对一棵共享模块源码树的贡献**,不是各自一个 zip 包。两种模式:

- **`source_tree_write`(默认·持续开发)**:把生成的 .java/.sql 等**就地写入调用方给定的共享源码树**,按包路径落位(如 `<module_root>/src/main/java/<pkg>/...`)。产物身份 = 被写/改文件的清单(`written_files[]` / `patched_files[]`),不是 zip。zip 仅在分发时可选打包,**不作为 node artifact 身份**(与 v2-contract「zip 文件名只是分发期提示」一致)。
- **`draft_package`(一次性 greenfield)**:无既有树时,才退化为打成一个 `Service草稿.zip` 草稿包供 review。**此模式仅用于从零起、无共享树的场景**。

**生成粒度 `generation_scope`**:
- **`incremental`(默认)**:调用方给定**目标范围**(一个功能 / 一个实体 / 一组接口),只生成或修改**与该目标相关的文件**;先探测共享树里是否已存在同名类——**已存在则不覆盖**,改为输出 patch/diff 或就地增强并在 `patched_files[]` 标注,其余文件一律不碰。
- **`full`**:整层批量生成(仅 greenfield 或用户显式要求整层重建时用)。

**去重叠铁律(no-duplication)**:不得重复生成本 N190/N200 家族其它 skill 已贡献进共享树的类(scaffold 已产的 enum / exception / base 类等)。检测到已有 → **补齐缺的 / 就地增强,不另起一份**,避免同一类在多个产物里各一份。

产物落地后必须在 `artifact_contract` 里如实列 `output_target_mode` / `generation_scope` / `written_files[]` / `patched_files[]` / `skipped_existing[]`。



## Selected mode / mode selection

Every result must declare `selected_mode`, `readiness`, and `evidence_profile` inside the `artifact_contract` block.

Allowed modes:
- `quick_service` — single service method skeleton from one controller hint or business rule.
- `full_service` — default mode; emit complete service class with method flow skeletons, transaction boundaries, validation hooks, and exception mapping.
- `flow_only` — emit method flow skeletons (input -> validation -> repository call -> mapping -> output) without full annotation set.
- `migration_mode` — port existing services to a new transaction propagation, exception, or event-publishing convention without reinventing logic.
- `implement` — produce a COMPILED, TESTED, RUNNABLE implementation (real method bodies, not skeletons). Requires resolved contracts (N200) + a decision-ledger (resolved 业务依赖条件). Business method bodies carry real logic; ZERO UnsupportedOperationException / TODO-return in method bodies. For a full/complete/deployable business module, runnable means a self-contained runtime package with build descriptor, runtime config, replaceable local adapters, startup entrypoint, smoke command, and machine-check output. Subject to the six implement gates (R_IMPL_COMPILE/TEST/NOSTUB/DECISION_JUDGMENT/FAILSAFE/SELF_CONTAINED_RUNTIME) — draft modes above are exempt from them. Use when the chain must yield working core business, not a scaffold. See `## Implement mode` below.

## Readiness 决策表

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 推荐输入全部齐备；技术栈明确；无未解决冲突 | 完整产物 + 所有契约字段填写 |
| `provisional` | 核心输入齐备；推荐输入部分缺失 | 输出已知层；缺失层进 `pending[]`；`evidence_profile: mixed` |
| `constrained` | 仅有描述性文字；无结构化输入文件 | 从文字提取意图；所有字段标 `inferred`；`tech_stack_declaration: pending` |
| `blocked` | 无任何可用输入 | 输出 `request_for_inputs[]`；列明最小输入要求 |

## Required v2 reactive output blocks

Every output must begin with the following YAML block:

```yaml
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: service-draft-generation
  producer_node: N190
  output_target_mode: source_tree_write | draft_package   # 默认 source_tree_write
  generation_scope: incremental | full                    # 默认 incremental
  artifact_name: source_tree_contribution                 # draft_package 模式=Service草稿.zip
  artifact_type: code_source_contribution | code_draft
  written_files: []
  patched_files: []
  skipped_existing: []
  target_scope: "<incremental 时:本次目标功能/实体/接口>"
  delivery_scope: single_method | service_slice | full_business_module | complete_module | deployable_package
  selected_mode: quick_service | full_service | flow_only | migration_mode | implement
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  n180_handoff_consumed:
    present: true | false
    implementable_core_flow_count: 0
    expected_selected_mode: implement | pending
    implementation_decision_ledger_refs: []
    scoped_deferred_features: []
  self_contained_runtime_package:
    required: auto | true | false
    reason_if_not_required: ""
    build_descriptor: ""
    runtime_config: ""
    local_or_replaceable_adapter_wiring: []
    startup_entrypoint: ""
    smoke_command: ""
    machine_check_output_ref: ""
  feature_depth_obligations:
    - obligation_id: ""
      obligation_type: source_backed_eligibility | business_calendar_temporal_policy | enumerated_detector_breadth | read_side_security_filter
      source_refs: []
      implementation_refs: []
      repository_or_adapter_refs: []
      required_positive_cases: []
      required_negative_cases: []
      handoff_to: [N190, N240, N260]
  downstream_consumers: [N200, N210, N330]
  traces_to_tasks: []

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending: []

quality_self_score:
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
```

## Genericity rule

This skill is a reusable atomic capability. Do not bind its instructions or outputs to a workflow node id, stage id, downstream node id, or node-specific filename. When a workflow node uses this skill, put node routing, aggregation, event publication, and downstream naming in the node orchestrator, not in this skill.


## Input classification

### minimum / core_required (at least one required)
- `技术方案分析.md` (from N130) — business operations and flow descriptions
- `接口意图清单.csv` (from N120) — API actions that map to service methods
- business operation descriptions in natural language

If none are present: set `readiness: blocked`, output only a skeleton template with all fields `pending`.

### recommended (workflow-aligned)
- `技术方案分析.md` from N130 — core service logic
- `业务规则清单.csv` from N070 — rule-driven branching
- `状态流转表.csv` from N070 — state machine transitions
- `并发控制建议.md` / `幂等设计建议.md` / `审计留痕方案.md` from N170 — AOP and transaction annotation hints
- `开发任务拆分表.csv` from N180 — populates `traces_to_tasks[]`
- `codegen_blocker_classification[]` / `codegen_dependency_resolution[]` from N180 — classifies D-code-affecting blockers by PRD/code/implementation/owner boundary
- `implementation_decision_ledger[]` from N180 — releases pre-code, brownfield-extractable, and implementation-owned decisions to implement mode
- `downstream_handoff.N190` from N180 — may force `selected_mode=implement` for implementable core flows
- `数据流图.md` from N160 — cross-service data flow for service call hints

### optional enrichment
- `接口设计草案.yaml` from N150 — request/response shape hints for method signatures
- `安全风险分析.md` from N170 — authorization check placement
- Existing service conventions
- Authorized brownfield current-state code inventory — only for extracting current routes/enums/states/adapters/compatibility shape when the project is brownfield; not a shakedown oracle and not required for greenfield production mode

### degradation rules
- Missing recommended inputs → `readiness: constrained`; emit only confirmed layers, mark missing layers `pending`.
- If `downstream_handoff.N190.implementable_core_flow_count > 0` and `downstream_handoff.N190.060_selected_mode == implement`, missing recommended inputs do not permit `full_service` / `flow_only` / `guarded_reference` downgrade; generate the unblocked core flows in `implement` mode and scope only true owner blockers into `scoped_deferred_features[]`.
- A fail/constrained API/design/planning gate is not by itself a production codegen blocker. First consume N180's blocker classification: pre-code decidable, brownfield-code-extractable, and implementation-layer-owned rows become required rules or decision ledger entries; only true owner/product blockers may defer their named feature/API scope.
- Missing `traces_to_tasks` → set to `[]`, note `evidence_profile: heuristic_only`.
- Never invent class names or framework choices without citing the matched input field.
- Specified-rule traceability (self-check R13): every business rule / state transition given in the input must trace to an implementing method or explicit branch. A rule the spec DID state but no method implements (e.g. only its error-code/enum is declared, with no detecting logic = dead declaration) is a silent-drop completeness defect — flag it naming the rule id. This is distinct from R12 (R12 derives complements the spec omitted; R13 catches specified rules generation dropped).
- Idempotency-by-default (algorithms NFR-000): an operation that can be delivered more than once by design (external workflow-engine callback, MQ consumer, scheduled retry, payment/credit apply, at-least-once trigger) is idempotent by default even without an idempotency input — guard the effect on a stable dedup key with an ATOMIC check-then-apply (UNIQUE dedup row / conditional UPDATE WHERE-not-applied / 061 locking read); a plain 'if already in target state return' is not enough under concurrency. Record in `inferred[]`.
- Necessary-complement completeness (self-check R12): for every state-changing method, derive and account for its business-necessary complement even if the PRD is silent — a value-adding op needs its reversal (credit↔reverse, deposit↔withdraw, accrue↔refund), a lifecycle-opening op needs its close (create↔delete, freeze↔unfreeze, approve↔reject/undo, submit↔cancel), and every non-terminal state needs an exit. A credit with no reversal path is a completeness defect, not an omission; emit the missing complement or record it in `inferred[]`. Only complements with a real business relation are in scope — a PRD-absent, unrelated ops/infra mechanism is NOT flagged.
- Missing `并发控制建议` does NOT downgrade concurrency safety. When a method is a read-modify-write on shared mutable state (counter increment, status/state-machine transition, balance/quota/limit update, insert-if-absent upsert), apply `transaction_boundary_inference` rule TX-006: `@Transactional` alone is insufficient (READ_COMMITTED still loses updates); the read step must use the repository's locking read (061 LS-000/LS-002 SELECT FOR UPDATE) or an atomic conditional update / optimistic `@Version`, and insert-if-absent must carry a UNIQUE constraint + duplicate-key retry. Never emit a plain read→check→write for shared state; record the default in `inferred[]`.
- Missing `安全风险分析` does NOT downgrade security enforcement to fail-open (algorithms SEC-000): when a method's result gates a security/compliance enforcement point (authentication, MFA/TOTP verify, authorization/permission, signature/integrity, compliance verify), its exception / missing-bean / unknown branch defaults to DENY (return false or throw the reject), never ALLOW. A permissive `catch → return true` (or swallow-and-continue) on a security gate is a fail-open defect; a bypass is legal only behind an explicit config switch defaulting OFF. Scope: only enforcement-gating decisions — a non-enforcement availability fail-soft is a separate tradeoff. Record in `inferred[]`.
- Sensitive-field masking is single-source (algorithms SEC-001): when a method masks / force-nulls / desensitizes PII by comparing a masked-field-name set against the emitted column key (`forceNull.contains(fieldName)`), the mask-field set and the column keys must reference ONE canonical field registry — never two independently typed literal sets. A masked key that drifts from the column key (`"id_card"` vs `"id_number"`) makes the mask a silent no-op / PII leak. Key both sites off one catalog; if none is supplied, derive it and record in `inferred[]`.
- Owner-scoped resource access enforces ownership by default (algorithms SEC-002): when a method reads/mutates a resource keyed by a caller-supplied id/token and the resource is owner- or permission-scoped (a sibling site enforces actor==owner/tenant/role), enforce that same predicate before access — possession of a valid id/token is not sufficient. Prefer the codebase's uniform declarative guard over a one-off in-method `if` so enforcement does not diverge across sibling endpoints. Record inferred entitlement in `inferred[]`.
- Cross-store changes use a fail-safe ordering (algorithms XS-000): a single logical change spanning a transactional store and a non-transactional secondary store (session/cache/queue/external/mandatory-audit) is NOT one atomic transaction — do a protective/irreversible side effect first-then-commit (never nest it inside the rollbackable tx), commit-then-best-effort + reconciliation for a compensable effect, and same-transaction-or-outbox+reconcile for a must-not-be-lost audit/write. Never business-commit-then-swallow a mandatory secondary write. Record the ordering in `inferred[]`. Best-effort telemetry / single-store steps are exempt.
- Two-column contract, no silent row-drop (algorithms DF-000): when a persist/upsert writes a business value into a column documented as one of an equal-by-contract / kept-in-sync column set (e.g. a legacy score column and a new composite column the entity says are held equal), write ALL columns of that set with the same value — or the canonical column the known downstream consumers read. Never write only one while downstream reads the other and filters it `IS NOT NULL` — that persists the row but drops it silently downstream (bonus/export/dashboard see nothing, no error). Record in `inferred[]`. Scope: only columns documented as the same logical value; genuinely different columns are exempt.
- Feature-depth obligations (algorithms FD-000): when a feature's business meaning depends on dynamic source facts, calendars, an enumerated detector/status vocabulary, or read-side security filters, `implement` mode must emit `feature_depth_obligations[]` and implement the named depth, not a thin constant/local subset. Each obligation names positive and negative cases and hands them to N240. Missing an obligation is a completeness defect even when happy-path tests pass.
- Safety defaults carry their adversarial test obligation (self-check R16): any method that applied a safety default (TX-006/LS-000/NFR-000/SEC-000/001/002/XS-000) emits, in `inferred[]`, the test scenario a happy-path/single-threaded green suite would pass while the defect survives — concurrent-two-thread no-lost-update, redelivery single-apply, dependency-absent denies, drifted-key still masks, non-owner rejected, secondary-store-loss reconciled. A green happy-path test does not prove the guard works; name the adversarial obligation so downstream test design cannot silently skip it. Plain CRUD/query with no applied default needs none.



## Enum and schema policy

Load `references/shared-codegen-enums.yaml` before reading or writing any contract field that uses an enum. Use the shared `query_purpose` and `cardinality` enums exactly so sibling skills can compose without manual string mapping. Use neutral schema namespaces such as `skills.codegen.service.v2.3`; do not use workflow-node ids inside skill-level schema versions.

## Rule source authority

Use YAML contracts as the authoritative source for schemas, enums, algorithms, and self-checks. Treat Markdown reference files as explanatory guides only; when Markdown guidance conflicts with `*-algorithms.yaml`, `*-input-contract.yaml`, `*-output-contract.yaml`, `*-self-check.yaml`, or `shared-codegen-enums.yaml`, follow the YAML file and record the conflict in `pending[]`.

## Execution workflow

1. Load the input contract, output contract, shared enum dictionary, and algorithm table for this skill.
2. Normalize inputs into the field names defined by `references/service-input-contract.yaml`.
3. If N180 handoff fields are present, apply `n180_handoff_dispatch` before ordinary mode selection. This decides whether `implement` is mandatory and which scoped features remain deferred.
4. Apply the structured algorithms in `references/service-algorithms.yaml`. When a decision is inferred, cite the matched rule id in `inferred[]` or the relevant contract field.
5. Emit `service_contract` using `references/service-output-contract.yaml`. Include all required fields even when values are `pending`.
6. Apply `references/service-self-check.yaml` and include `self_check_result.passed`, `warnings`, and `blockers`.
7. Add human-readable notes only after the machine-readable contract.

## Output contract

Every output must start with a YAML block named `artifact_contract`. Never claim `build_verified` unless a build/test command was actually run and evidence is shown. Put assumptions in `inferred[]` and unknowns in `pending[]` instead of silently inventing facts.

## Produced event / 产物事件

本 skill 是 N190 节点的子技能，产物交由 `scaffold-package-aggregator` 聚合后统一发布节点级事件：

```yaml
event_emission:
  emitted_by: standalone_skill
  node_event_publisher: scaffold-package-aggregator
  artifact_contract_field: artifact_contract.readiness
  artifact_name: source_tree_contribution   # draft_package 模式为 Service草稿.zip
  downstream_consumers: [N200, N210, N240, N330]
  note: >
    本 skill 不自行发布 produced.n190.scaffold_package 事件。
    完成后通知 scaffold-package-aggregator 消费 artifact_contract，由聚合器决定节点 readiness。
```

## Boundary

Use the boundary rules in the output and self-check contracts. This skill should emit its own layer contract and sibling handoff hints, but should not take responsibility for node-level aggregation or unrelated architectural layers.

## Composition

When a sibling contract is supplied, consume it explicitly and name the exact fields used. When this skill emits handoff hints for a sibling skill, use the structured contract fields and shared enum dictionary rather than prose-only handoff. For inconsistent sibling contracts, record the mismatch in `pending[]` or `self_check_result.blockers` according to the self-check severity.


## Tech stack adapter

Output defaults to Java (Spring Boot / Spring MVC) examples. Switch adapters when context indicates a different stack:

| Stack | Service conventions |
|---|---|
| Java / Spring | `@Service`, `@Transactional(rollbackFor=Exception.class)`, AOP for audit/idempotency |
| Java / Spring WebFlux | Reactive service with `@Transactional` on reactive tx manager |
| TypeScript / NestJS | `@Injectable()` service, transaction via TypeORM/Prisma `$transaction` |
| Python | Service class or function module, SQLAlchemy session context manager |
| Go | Service struct with interface, explicit context propagation |
| Saga / CQRS | Command handler + event emitter skeleton; mark saga steps with `compensatable: true` |

Never present a Java-only solution as universal. If the stack is unknown, output neutral placeholders and record `stack_declaration: pending`.

**Transaction boundaries declared here must be validated by N210 transaction-boundary-check; expose `@Transactional` annotations with propagation and rollback-for in downstream_handoff.**

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可执行，输出可独立使用 | 依赖推荐输入才可用 | 无最小输入也无法降级 |
| `contract_completeness` | artifact_contract 所有字段填写，无 null 留白 | 关键字段已填，部分 pending | 超过 30% 字段为 null |
| `uncertainty_handling` | 所有推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明类名/框架 |
| `downstream_handoff` | sibling 字段引用精确，下游可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。`quality_self_score` 必须在 `self_gate` 之后、人类可读说明之前输出。

## Machine-readable self_check rules

- `R01_artifact_contract_first`: 每次输出必须以 `artifact_contract` YAML 块开头; `on_violation: reject`
- `R02_readiness_set`: `readiness` 必须是 `pass | provisional | constrained | blocked` 之一; `on_violation: reject`
- `R03_no_invented_names`: 未引用输入字段时不得臆造类名/包名/框架选型; `on_violation: reject`
- `R04_build_verified_evidence`: 声明 `build_verified` 必须附实际执行命令和输出作为证据; `on_violation: reject`
- `R05_pending_not_silent`: 未知值必须进入 `pending[]`，不得静默省略; `on_violation: reject`
- `R06_tech_stack_declared`: `stack_declaration` 必须明确声明或标为 `pending`; `on_violation: warn`
- `R07_traces_to_tasks_set`: `traces_to_tasks[]` 必须引用 N180 task_id 或显式设为 `[]` 并注明 `evidence_profile`; `on_violation: warn`
- `R08_sibling_conflict_recorded`: 兄弟 skill 契约冲突必须进入 `pending[]` 或 `self_gate.failed_rules[]`，不得静默覆盖; `on_violation: reject`
- `R_IMPL_COMPILE`(仅 implement 模式）: 产出的 src+test 必须编译通过(编译器 exit 0); draft 模式豁免; `on_violation: reject`
- `R_IMPL_TEST`(仅 implement）: 测试真跑通过(exit 0·assert>0·每业务规则≥1正+≥1负); 测试点覆盖≠代码执行覆盖; `on_violation: reject`
- `R_IMPL_NOSTUB`(仅 implement）: 业务【方法体】零桩(剥注释/字符串后无 UnsupportedOperationException/TODO占位); 原文 grep 不算——注释里提到该词不得判违; `on_violation: reject`
- `R_IMPL_DECISION_JUDGMENT`(仅 implement）: 先分架构决策(实现层自裁·made_by=implement_layer·禁 deferred)vs 产品决策(查 decision-ledger·高危未决 deferred·可裁 inferred_*); 架构决策标 deferred=误分类违规; `on_violation: reject`
- `R_IMPL_FAILSAFE`(仅 implement）: 守卫/强制点默认 fail-closed(throw/未装配即启动失败),禁 return-true 空放行; `on_violation: reject`
- `R_IMPL_SELF_CONTAINED_RUNTIME`(仅 implement+完整业务模块）: 当 `delivery_scope` 为 `full_business_module | complete_module | deployable_package`,或用户/上游要求完整/全量/部署/上线/可运行时,必须产出 self-contained runtime package: build descriptor、runtime config、local/replaceable adapter wiring、startup entrypoint、smoke command、machine-check output(exit 0)。只读参考仓只可作为 oracle/reference,不得当 target path、patch flow 或 production integration proof; `on_violation: reject`
- `R_IMPL_N180_HANDOFF_CONSUMED`: N180 声明 `060_selected_mode=implement` 且 `implementable_core_flow_count>0` 时,本 skill 的 `selected_mode` 必须为 `implement`,并消费 `implementation_decision_ledger[]`;不得输出 guarded reference / draft-only / in-memory-only 替代品; `on_violation: reject`
- `R_IMPL_FEATURE_DEPTH_OBLIGATIONS`: implement/full module 中,source-backed eligibility、business-calendar temporal policy、enumerated detector breadth、read-side security filter 任一形态出现时,必须输出 `feature_depth_obligations[]`,实现引用和正负测试义务齐全并交 N240;不得只实现 happy-path/local-constant/subset detector; `on_violation: reject`

## Common failure modes

1. **Stack assumption leak** — 未声明 `stack_declaration` 就默认输出 Java-only 方案，非 Java 项目无法使用。修复：先检查上下文中的框架标志（`pom.xml`/`package.json`/`go.mod`），未知时设 `stack_declaration: pending`。
2. **Silent invention** — 缺少输入时臆造类名或包路径，导致下游编译失败。修复：所有推断值写入 `inferred[]` 并引用触发的输入字段；无对应字段时进入 `pending[]`。
3. **Missing readiness gate** — 推荐输入全部缺失时仍输出 `readiness: pass`，误导下游节点认为产物可直接使用。修复：执行输入分类后强制重算 `readiness`。
4. **Naive cross-cutting control** — when a method implements a cross-cutting control (grant-ceiling / resource-owner / value-snapshot / idempotency / lifecycle revocation / control enforcement / audit durability / cross-store write), a naive happy-path form (boolean gate bypassable, SELECT-only dedup TOCTOU, claimed cross-store atomicity, post-commit-swallowed audit, deny-on-missing absent) is a recurring defect class. Fix: generate the failure-safe form per `references/cross-cutting-control-patterns.md` (fail-closed default / single source of truth + entry re-check / safe direction), recording pattern-required infrastructure in inferred[]/pending[].

## Implement mode（实现层 · 补库结构性缺失的"把已决策规格实现到能跑"一层）

Draft 模式(quick/full/flow/migration)产 skeleton;`implement` 模式产可编译可跑可测的实现。它是链路从"脚手架"到"可用软件"缺的一层(功能级深审曾证核心业务 0/41 可跑,因所有代码生成 skill 只产草稿)。

**输入(除 draft 模式所需外,另需)**:`decision_ledger` / `implementation_decision_ledger[]` —— 把 GATE100/026/N180 标出的、卡住实现的业务依赖条件解析掉的台账(每条含 resolution/source/risk)。若 N180 提供 `downstream_handoff.N190.060_selected_mode=implement`,优先消费该 handoff。

**判断层(R_IMPL_DECISION_JUDGMENT 强制)**:先分决策性质——
- **架构决策**(裁决合成算法/事务+可靠投递策略/表 schema/错误码方案/分层/并发机制):实现层自己拍(工程判断+最佳实践),记 `made_by=implement_layer`,**绝不 deferred**。PRD 不写架构是对的,链路因此阻塞是缺陷(026 曾把架构判 not_executable 拖垮全链)。
- **产品决策**(角色数/风险偏好/业务阈值/key-management 基建/业务规则):查 decision_ledger。UNRESOLVED+高危/不可逆/基建→`deferred_blocked`(不臆造);可裁冲突→`inferred_authority`;低危→`inferred_default`+review。

**输出**:`Service实现.zip` 或 source tree contribution(src/ 可编译实现 + test/ 可运行测试 + IMPL-REPORT.md:每方法 traces_to〈design+decision〉+ deferred_blocked 清单)。当交付范围是 full/complete/deployable 业务模块时,输出还必须包含可独立运行的 package:构建描述、运行配置、本地可替换 adapter wiring、启动入口、smoke 命令和机器校验输出。只读参考仓只能作参考,不能把生成物绑定成它的 patch/target module。

**七门自检(与 draft 的根本分界)**:draft 自检只验"产物带契约头";implement 只认"能跑"——COMPILE+TEST+NO_STUB(查方法体)+DECISION_JUDGMENT+FAILSAFE+SELF_CONTAINED_RUNTIME(完整模块适用)+FEATURE_DEPTH_OBLIGATIONS 任一不过则 readiness=blocked,不得标 done。

**N180 handoff 强制**:当 N180 已确认存在 implementable core flows,060 不能用 API gate fail、PRD 未写 schema/事务/route 兼容、或推荐输入缺失来整段降级为 guarded reference。它必须实现未阻塞核心流；仅对 `true_owner_product_blocker` 指定的功能/API 输出 scoped deferred。

**校准**:D-103/104/105 实验 4 手写切片(authz/session/audit/expanded 28/28)+ D-106 一个子代理仅凭本规格自主产 TotpReset(独立跑三门:COMPILE/TEST 21/21/NO_STUB/FAILSAFE 全过)= 证契约可被 agent 遵循。

## References

- `references/shared-codegen-enums.yaml`: canonical enum dictionary for all four code-generation skills
- `references/service-input-contract.yaml`: field-level input schema and normalization rules
- `references/service-output-contract.yaml`: required output schema and field contract
- `references/service-self-check.yaml`: executable quality checks and violation policy
- `references/service-algorithms.yaml`: structured decision tables and algorithms
- `references/transaction-aop-inference.md`: domain-specific generation guidance
- `references/cross-cutting-control-patterns.md`: failure-safe patterns for cross-cutting controls (grant-ceiling, resource-owner/IDOR, value-snapshot, idempotency/uniqueness, lifecycle revocation, control enforcement, audit durability, cross-store ordering) — generate to these forms, not the naive happy-path
- `references/example-io.md`: concrete input/output example
- `references/routing-metadata.yaml`: optional platform scheduling metadata
- `references/checklist.md`: delivery checklist for self-review before emit
- `references/scoring-rubric.md`: 4-dimension self-scoring rubric (S/A/B/C)
- `references/common-failure-modes.md`: detailed failure mode catalog with symptom/impact/fix
- `references/orchestration.md`: upstream priority, downstream handoff, field-level mapping, mode-specific orchestration


## Language-agnostic artifact packaging(CAND-B5 · 2026-07-18)

本 skill 的产物是「service / 用例编排层的一组源文件」,打包为**语言无关容器** `Service草稿.zip`,而非单个语言专属文件。

- **不写死语言后缀**:容器内文件的语言与后缀由 `tech_stack.language` 决定(见 `references/shared-codegen-enums.yaml` 的 language 枚举:java / go / node / python / rust / kotlin / other)—— 落地为 `.java` / `.py` / `.go` / `.ts` / `.rs` / `.kt` / … 。这遵守本 skill 的 Genericity rule(不绑定 node-specific / 语言专属文件名)。
- **为什么是容器不是单文件**:真实模块的service / 用例编排层通常是多个文件(多个类 / 多个源文件);单个 `.java` 既装不下多类、又把实现语言写死。容器形态与本节点已有的 058 `工程骨架.zip` / 062 `DTO_VO草稿.zip` 一致。
- **落地**:每个文件的路径 / 包 / 后缀遵循 `tech_stack` 的 package_layout 与 language 约定;由节点编排(如 scaffold-package-aggregator)合成到完整工程。
- **历史**:此前产物名写死 `.java`,与库的多语言 `shared.language` 枚举 + 本 skill 的通用性声明矛盾(非 java 团队用此节点产不出对的东西);已改为语言无关容器。
