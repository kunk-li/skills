---
name: service-draft-generation
description: Draft service-layer methods and flow skeletons from controllers, API actions, business rules, and state transitions — transaction boundaries, AOP annotations, exception semantics.
---

# Service Draft Generation

## Purpose

Generate a reusable service code-generation contract. Keep this skill generic, contract-first, and honest about evidence. This v2.3 version keeps the v2.2.1 node-agnostic design and adds v2 reactive workflow anchors, structured selected_mode, delivery checklist, scoring rubric, and clearer minimum-input degradation rules.


## Workflow anchors

```yaml
function_bias: direct_result
workflow_node: N190
node_artifact_target: Service草稿.java
node_artifact_role: code_draft for N190 coding scaffold stage
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
event_aggregation_note: >
    This skill does not publish its own produced event directly to the event bus.
  The N190 node orchestrator (or scaffold-package-aggregator when present)
  is responsible for emitting produced.N190.scaffold_package after all four
  N190 skills complete. Each skill contributes its artifact_contract to that
  aggregation step.
```


## Selected mode / mode selection

Every result must declare `selected_mode`, `readiness`, and `evidence_profile` inside the `artifact_contract` block.

Allowed modes:
- `quick_service` — single service method skeleton from one controller hint or business rule.
- `full_service` — default mode; emit complete service class with method flow skeletons, transaction boundaries, validation hooks, and exception mapping.
- `flow_only` — emit method flow skeletons (input -> validation -> repository call -> mapping -> output) without full annotation set.
- `migration_mode` — port existing services to a new transaction propagation, exception, or event-publishing convention without reinventing logic.

## Readiness 决策表

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 推荐输入全部齐备；技术栈明确；无未解决冲突 | 完整产物 + 所有契约字段填写 |
| `provisional` | 核心输入齐备；推荐输入部分缺失 | 输出已知层；缺失层进 `pending[]`；`evidence_profile: mixed` |
| `constrained` | 仅有描述性文字；无结构化输入文件 | 从文字提取意图；所有字段标 `inferred`；`tech_stack_declaration: pending` |
| `blocked` | 无任何可用输入 | 输出 `request_for_inputs[]`；列明最小输入要求 |

## Required v2 reactive output blocks

Every output must begin with the following YAML block:

```yaml
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: service-draft-generation
  producer_node: N190
  artifact_name: Service草稿.java
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  downstream_consumers: [N200, N210, N330]
  traces_to_tasks: []

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending: []

quality_self_score:
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
```

## Genericity rule

This skill is a reusable atomic capability. Do not bind its instructions or outputs to a workflow node id, stage id, downstream node id, or node-specific filename. When a workflow node uses this skill, put node routing, aggregation, event publication, and downstream naming in the node orchestrator, not in this skill.


## Input classification

### minimum / core_required (at least one required)
- `技术方案分析.md` (from N130) — business operations and flow descriptions
- `接口意图清单.csv` (from N120) — API actions that map to service methods
- business operation descriptions in natural language

If none are present: set `readiness: blocked`, output only a skeleton template with all fields `pending`.

### recommended (workflow-aligned)
- `技术方案分析.md` from N130 — core service logic
- `业务规则清单.csv` from N070 — rule-driven branching
- `状态流转表.csv` from N070 — state machine transitions
- `并发控制建议.md` / `幂等设计建议.md` / `审计留痕方案.md` from N170 — AOP and transaction annotation hints
- `开发任务拆分表.csv` from N180 — populates `traces_to_tasks[]`
- `数据流图.md` from N160 — cross-service data flow for service call hints

### optional enrichment
- `接口设计草案.yaml` from N150 — request/response shape hints for method signatures
- `安全风险分析.md` from N170 — authorization check placement
- Existing service conventions

### degradation rules
- Missing recommended inputs → `readiness: constrained`; emit only confirmed layers, mark missing layers `pending`.
- Missing `traces_to_tasks` → set to `[]`, note `evidence_profile: heuristic_only`.
- Never invent class names or framework choices without citing the matched input field.
- Specified-rule traceability (self-check R13): every business rule / state transition given in the input must trace to an implementing method or explicit branch. A rule the spec DID state but no method implements (e.g. only its error-code/enum is declared, with no detecting logic = dead declaration) is a silent-drop completeness defect — flag it naming the rule id. This is distinct from R12 (R12 derives complements the spec omitted; R13 catches specified rules generation dropped).
- Idempotency-by-default (algorithms NFR-000): an operation that can be delivered more than once by design (external/wflow callback, MQ consumer, scheduled retry, payment/credit apply, at-least-once trigger) is idempotent by default even without an idempotency input — guard the effect on a stable dedup key with an ATOMIC check-then-apply (UNIQUE dedup row / conditional UPDATE WHERE-not-applied / 061 locking read); a plain 'if already in target state return' is not enough under concurrency. Record in `inferred[]`.
- Necessary-complement completeness (self-check R12): for every state-changing method, derive and account for its business-necessary complement even if the PRD is silent — a value-adding op needs its reversal (credit↔reverse, deposit↔withdraw, accrue↔refund), a lifecycle-opening op needs its close (create↔delete, freeze↔unfreeze, approve↔reject/undo, submit↔cancel), and every non-terminal state needs an exit. A credit with no reversal path is a completeness defect, not an omission; emit the missing complement or record it in `inferred[]`. Only complements with a real business relation are in scope — a PRD-absent, unrelated ops/infra mechanism is NOT flagged.
- Missing `并发控制建议` does NOT downgrade concurrency safety. When a method is a read-modify-write on shared mutable state (counter increment, status/state-machine transition, balance/quota/limit update, insert-if-absent upsert), apply `transaction_boundary_inference` rule TX-006: `@Transactional` alone is insufficient (READ_COMMITTED still loses updates); the read step must use the repository's locking read (061 LS-000/LS-002 SELECT FOR UPDATE) or an atomic conditional update / optimistic `@Version`, and insert-if-absent must carry a UNIQUE constraint + duplicate-key retry. Never emit a plain read→check→write for shared state; record the default in `inferred[]`.
- Missing `安全风险分析` does NOT downgrade security enforcement to fail-open (algorithms SEC-000): when a method's result gates a security/compliance enforcement point (authentication, MFA/TOTP verify, authorization/permission, signature/integrity, compliance verify), its exception / missing-bean / unknown branch defaults to DENY (return false or throw the reject), never ALLOW. A permissive `catch → return true` (or swallow-and-continue) on a security gate is a fail-open defect; a bypass is legal only behind an explicit config switch defaulting OFF. Scope: only enforcement-gating decisions — a non-enforcement availability fail-soft is a separate tradeoff. Record in `inferred[]`.
- Sensitive-field masking is single-source (algorithms SEC-001): when a method masks / force-nulls / desensitizes PII by comparing a masked-field-name set against the emitted column key (`forceNull.contains(fieldName)`), the mask-field set and the column keys must reference ONE canonical field registry — never two independently typed literal sets. A masked key that drifts from the column key (`"id_card"` vs `"id_number"`) makes the mask a silent no-op / PII leak. Key both sites off one catalog; if none is supplied, derive it and record in `inferred[]`.
- Owner-scoped resource access enforces ownership by default (algorithms SEC-002): when a method reads/mutates a resource keyed by a caller-supplied id/token and the resource is owner- or permission-scoped (a sibling site enforces actor==owner/tenant/role), enforce that same predicate before access — possession of a valid id/token is not sufficient. Prefer the codebase's uniform declarative guard over a one-off in-method `if` so enforcement does not diverge across sibling endpoints. Record inferred entitlement in `inferred[]`.
- Cross-store changes use a fail-safe ordering (algorithms XS-000): a single logical change spanning a transactional store and a non-transactional secondary store (session/cache/queue/external/mandatory-audit) is NOT one atomic transaction — do a protective/irreversible side effect first-then-commit (never nest it inside the rollbackable tx), commit-then-best-effort + reconciliation for a compensable effect, and same-transaction-or-outbox+reconcile for a must-not-be-lost audit/write. Never business-commit-then-swallow a mandatory secondary write. Record the ordering in `inferred[]`. Best-effort telemetry / single-store steps are exempt.
- Two-column contract, no silent row-drop (algorithms DF-000): when a persist/upsert writes a business value into a column documented as one of an equal-by-contract / kept-in-sync column set (e.g. a legacy score column and a new composite column the entity says are held equal), write ALL columns of that set with the same value — or the canonical column the known downstream consumers read. Never write only one while downstream reads the other and filters it `IS NOT NULL` — that persists the row but drops it silently downstream (bonus/export/dashboard see nothing, no error). Record in `inferred[]`. Scope: only columns documented as the same logical value; genuinely different columns are exempt.
- Safety defaults carry their adversarial test obligation (self-check R16): any method that applied a safety default (TX-006/LS-000/NFR-000/SEC-000/001/002/XS-000) emits, in `inferred[]`, the test scenario a happy-path/single-threaded green suite would pass while the defect survives — concurrent-two-thread no-lost-update, redelivery single-apply, dependency-absent denies, drifted-key still masks, non-owner rejected, secondary-store-loss reconciled. A green happy-path test does not prove the guard works; name the adversarial obligation so downstream test design cannot silently skip it. Plain CRUD/query with no applied default needs none.



## Enum and schema policy

Load `references/shared-codegen-enums.yaml` before reading or writing any contract field that uses an enum. Use the shared `query_purpose` and `cardinality` enums exactly so sibling skills can compose without manual string mapping. Use neutral schema namespaces such as `skills.codegen.service.v2.3`; do not use workflow-node ids inside skill-level schema versions.

## Rule source authority

Use YAML contracts as the authoritative source for schemas, enums, algorithms, and self-checks. Treat Markdown reference files as explanatory guides only; when Markdown guidance conflicts with `*-algorithms.yaml`, `*-input-contract.yaml`, `*-output-contract.yaml`, `*-self-check.yaml`, or `shared-codegen-enums.yaml`, follow the YAML file and record the conflict in `pending[]`.

## Execution workflow

1. Load the input contract, output contract, shared enum dictionary, and algorithm table for this skill.
2. Normalize inputs into the field names defined by `references/service-input-contract.yaml`.
3. Apply the structured algorithms in `references/service-algorithms.yaml`. When a decision is inferred, cite the matched rule id in `inferred[]` or the relevant contract field.
4. Emit `service_contract` using `references/service-output-contract.yaml`. Include all required fields even when values are `pending`.
5. Apply `references/service-self-check.yaml` and include `self_check_result.passed`, `warnings`, and `blockers`.
6. Add human-readable notes only after the machine-readable contract.

## Output contract

Every output must start with a YAML block named `artifact_contract`. Never claim `build_verified` unless a build/test command was actually run and evidence is shown. Put assumptions in `inferred[]` and unknowns in `pending[]` instead of silently inventing facts.

## Produced event / 产物事件

本 skill 是 N190 节点的子技能，产物交由 `scaffold-package-aggregator` 聚合后统一发布节点级事件：

```yaml
event_emission:
  emitted_by: standalone_skill
  node_event_publisher: scaffold-package-aggregator
  artifact_contract_field: artifact_contract.readiness
  artifact_name: "Service草稿.java"
  downstream_consumers: [N200, N210, N240, N330]
  note: >
    本 skill 不自行发布 produced.n190.scaffold_package 事件。
    完成后通知 scaffold-package-aggregator 消费 artifact_contract，由聚合器决定节点 readiness。
```

## Boundary

Use the boundary rules in the output and self-check contracts. This skill should emit its own layer contract and sibling handoff hints, but should not take responsibility for node-level aggregation or unrelated architectural layers.

## Composition

When a sibling contract is supplied, consume it explicitly and name the exact fields used. When this skill emits handoff hints for a sibling skill, use the structured contract fields and shared enum dictionary rather than prose-only handoff. For inconsistent sibling contracts, record the mismatch in `pending[]` or `self_check_result.blockers` according to the self-check severity.


## Tech stack adapter

Output defaults to Java (Spring Boot / Spring MVC) examples. Switch adapters when context indicates a different stack:

| Stack | Service conventions |
|---|---|
| Java / Spring | `@Service`, `@Transactional(rollbackFor=Exception.class)`, AOP for audit/idempotency |
| Java / Spring WebFlux | Reactive service with `@Transactional` on reactive tx manager |
| TypeScript / NestJS | `@Injectable()` service, transaction via TypeORM/Prisma `$transaction` |
| Python | Service class or function module, SQLAlchemy session context manager |
| Go | Service struct with interface, explicit context propagation |
| Saga / CQRS | Command handler + event emitter skeleton; mark saga steps with `compensatable: true` |

Never present a Java-only solution as universal. If the stack is unknown, output neutral placeholders and record `stack_declaration: pending`.

**Transaction boundaries declared here must be validated by N210 transaction-boundary-check; expose `@Transactional` annotations with propagation and rollback-for in downstream_handoff.**

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可执行，输出可独立使用 | 依赖推荐输入才可用 | 无最小输入也无法降级 |
| `contract_completeness` | artifact_contract 所有字段填写，无 null 留白 | 关键字段已填，部分 pending | 超过 30% 字段为 null |
| `uncertainty_handling` | 所有推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明类名/框架 |
| `downstream_handoff` | sibling 字段引用精确，下游可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。`quality_self_score` 必须在 `self_gate` 之后、人类可读说明之前输出。

## Machine-readable self_check rules

- `R01_artifact_contract_first`: 每次输出必须以 `artifact_contract` YAML 块开头; `on_violation: reject`
- `R02_readiness_set`: `readiness` 必须是 `pass | provisional | constrained | blocked` 之一; `on_violation: reject`
- `R03_no_invented_names`: 未引用输入字段时不得臆造类名/包名/框架选型; `on_violation: reject`
- `R04_build_verified_evidence`: 声明 `build_verified` 必须附实际执行命令和输出作为证据; `on_violation: reject`
- `R05_pending_not_silent`: 未知值必须进入 `pending[]`，不得静默省略; `on_violation: reject`
- `R06_tech_stack_declared`: `stack_declaration` 必须明确声明或标为 `pending`; `on_violation: warn`
- `R07_traces_to_tasks_set`: `traces_to_tasks[]` 必须引用 N180 task_id 或显式设为 `[]` 并注明 `evidence_profile`; `on_violation: warn`
- `R08_sibling_conflict_recorded`: 兄弟 skill 契约冲突必须进入 `pending[]` 或 `self_gate.failed_rules[]`，不得静默覆盖; `on_violation: reject`

## Common failure modes

1. **Stack assumption leak** — 未声明 `stack_declaration` 就默认输出 Java-only 方案，非 Java 项目无法使用。修复：先检查上下文中的框架标志（`pom.xml`/`package.json`/`go.mod`），未知时设 `stack_declaration: pending`。
2. **Silent invention** — 缺少输入时臆造类名或包路径，导致下游编译失败。修复：所有推断值写入 `inferred[]` 并引用触发的输入字段；无对应字段时进入 `pending[]`。
3. **Missing readiness gate** — 推荐输入全部缺失时仍输出 `readiness: pass`，误导下游节点认为产物可直接使用。修复：执行输入分类后强制重算 `readiness`。
4. **Naive cross-cutting control** — when a method implements a cross-cutting control (grant-ceiling / resource-owner / value-snapshot / idempotency / lifecycle revocation / control enforcement / audit durability / cross-store write), a naive happy-path form (boolean gate bypassable, SELECT-only dedup TOCTOU, claimed cross-store atomicity, post-commit-swallowed audit, deny-on-missing absent) is a recurring defect class. Fix: generate the failure-safe form per `references/cross-cutting-control-patterns.md` (fail-closed default / single source of truth + entry re-check / safe direction), recording pattern-required infrastructure in inferred[]/pending[].

## References

- `references/shared-codegen-enums.yaml`: canonical enum dictionary for all four code-generation skills
- `references/service-input-contract.yaml`: field-level input schema and normalization rules
- `references/service-output-contract.yaml`: required output schema and field contract
- `references/service-self-check.yaml`: executable quality checks and violation policy
- `references/service-algorithms.yaml`: structured decision tables and algorithms
- `references/transaction-aop-inference.md`: domain-specific generation guidance
- `references/cross-cutting-control-patterns.md`: failure-safe patterns for cross-cutting controls (grant-ceiling, resource-owner/IDOR, value-snapshot, idempotency/uniqueness, lifecycle revocation, control enforcement, audit durability, cross-store ordering) — generate to these forms, not the naive happy-path
- `references/example-io.md`: concrete input/output example
- `references/routing-metadata.yaml`: optional platform scheduling metadata
- `references/checklist.md`: delivery checklist for self-review before emit
- `references/scoring-rubric.md`: 4-dimension self-scoring rubric (S/A/B/C)
- `references/common-failure-modes.md`: detailed failure mode catalog with symptom/impact/fix
- `references/orchestration.md`: upstream priority, downstream handoff, field-level mapping, mode-specific orchestration
