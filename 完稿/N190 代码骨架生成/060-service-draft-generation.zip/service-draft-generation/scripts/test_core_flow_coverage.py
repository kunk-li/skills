#!/usr/bin/env python3
from __future__ import annotations

import tempfile
from pathlib import Path

from validate_core_flow_coverage import validate


def base_contract() -> dict:
    return {
        "selected_mode": "implement",
        "readiness": "pass",
        "n180_handoff_consumed": {
            "implementable_core_flow_count": 2,
            "scoped_deferred_features": [],
        },
        "implementation_depth_ladder": [
            {
                "core_flow_id": "FLOW-001",
                "source_refs": ["RULE-001"],
                "n180_task_refs": ["TASK-001"],
                "controller_action_refs": ["Controller.create"],
                "service_method_refs": ["Service.create"],
                "state_branch_refs": ["STATE-A->STATE-B"],
                "repository_or_adapter_refs": ["Repo.save"],
                "sql_or_schema_refs": ["table_a"],
                "positive_test_refs": ["ServiceTest.create_ok"],
                "negative_test_refs": ["ServiceTest.create_rejects_bad_state"],
                "runtime_or_smoke_refs": ["mvn test"],
                "coverage_status": "covered",
                "gap_reason": "",
            },
            {
                "core_flow_id": "FLOW-002",
                "source_refs": ["RULE-002"],
                "n180_task_refs": ["TASK-002"],
                "controller_action_refs": ["Controller.cancel"],
                "service_method_refs": ["Service.cancel"],
                "state_branch_refs": ["STATE-B->STATE-C"],
                "repository_or_adapter_refs": ["Repo.save"],
                "sql_or_schema_refs": ["table_a"],
                "positive_test_refs": ["ServiceTest.cancel_ok"],
                "negative_test_refs": ["ServiceTest.cancel_rejects_final"],
                "runtime_or_smoke_refs": ["mvn test"],
                "coverage_status": "covered",
                "gap_reason": "",
            },
        ],
        "core_flow_coverage_matrix": {
            "expected_core_flow_count": 2,
            "covered_core_flow_count": 2,
            "scoped_deferred_core_flow_count": 0,
            "uncovered_core_flow_count": 0,
        },
    }


def main() -> int:
    good = base_contract()
    bad = base_contract()
    bad["implementation_depth_ladder"] = bad["implementation_depth_ladder"][:1]
    bad["core_flow_coverage_matrix"] = {
        "expected_core_flow_count": 2,
        "covered_core_flow_count": 1,
        "scoped_deferred_core_flow_count": 0,
        "uncovered_core_flow_count": 1,
    }
    bad["readiness"] = "pass"

    good_errors = validate(good)
    bad_errors = validate(bad)
    if good_errors:
        print("TEST-CORE-FLOW-COVERAGE status=fail case=good errors=" + repr(good_errors))
        return 2
    if not bad_errors:
        print("TEST-CORE-FLOW-COVERAGE status=fail case=bad_missing_flow_passed")
        return 2
    with tempfile.TemporaryDirectory() as tmp:
        Path(tmp, "evidence.txt").write_text(
            "good_passed=true\nbad_missing_flow_failed=true\n",
            encoding="utf-8",
        )
    print("TEST-CORE-FLOW-COVERAGE status=pass good_passed=true bad_missing_flow_failed=true")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
