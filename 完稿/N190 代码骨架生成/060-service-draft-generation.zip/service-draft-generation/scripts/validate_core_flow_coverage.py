#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


REQUIRED_COVERED_FIELDS = [
    "source_refs",
    "n180_task_refs",
    "service_method_refs",
    "positive_test_refs",
    "negative_test_refs",
    "runtime_or_smoke_refs",
]


def as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def load_contract(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("top-level JSON must be an object")
    contract = data.get("artifact_contract", data)
    if not isinstance(contract, dict):
        raise ValueError("artifact_contract must be an object")
    return contract


def nonempty(row: dict[str, Any], field: str) -> bool:
    value = row.get(field)
    if isinstance(value, list):
        return bool(value)
    if isinstance(value, str):
        return bool(value.strip())
    return value is not None


def int_field(value: Any, default: int = -1) -> int:
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def validate(contract: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if contract.get("selected_mode") != "implement":
        return errors

    handoff = contract.get("n180_handoff_consumed")
    if not isinstance(handoff, dict):
        errors.append("n180_handoff_consumed is required for implement mode")
        return errors

    expected = int_field(handoff.get("implementable_core_flow_count"), 0)
    if expected <= 0:
        return errors

    ladder = as_list(contract.get("implementation_depth_ladder"))
    matrix = contract.get("core_flow_coverage_matrix")
    scoped_deferred = set(str(item) for item in as_list(handoff.get("scoped_deferred_features")))

    if not isinstance(matrix, dict):
        errors.append("core_flow_coverage_matrix is required when implementable_core_flow_count > 0")
        matrix = {}

    if int_field(matrix.get("expected_core_flow_count")) != expected:
        errors.append("core_flow_coverage_matrix.expected_core_flow_count must equal N180 implementable_core_flow_count")

    if len(ladder) != expected:
        errors.append("implementation_depth_ladder must contain exactly one row per N180 implementable core flow")

    counts = {"covered": 0, "scoped_deferred": 0, "blocked": 0}
    seen_ids: set[str] = set()
    for idx, item in enumerate(ladder):
        if not isinstance(item, dict):
            errors.append(f"implementation_depth_ladder[{idx}] must be an object")
            continue
        flow_id = str(item.get("core_flow_id") or "").strip()
        if not flow_id:
            errors.append(f"implementation_depth_ladder[{idx}].core_flow_id is required")
        elif flow_id in seen_ids:
            errors.append(f"duplicate core_flow_id: {flow_id}")
        else:
            seen_ids.add(flow_id)

        status = str(item.get("coverage_status") or "").strip()
        if status not in counts:
            errors.append(f"{flow_id or idx}: coverage_status must be covered, scoped_deferred, or blocked")
            continue
        counts[status] += 1

        if status == "covered":
            for field in REQUIRED_COVERED_FIELDS:
                if not nonempty(item, field):
                    errors.append(f"{flow_id or idx}: covered row missing {field}")
            has_controller = nonempty(item, "controller_action_refs") or nonempty(item, "non_http_trigger_rationale")
            if not has_controller:
                errors.append(f"{flow_id or idx}: covered row needs controller_action_refs or non_http_trigger_rationale")
            has_persistence = (
                nonempty(item, "repository_or_adapter_refs")
                or nonempty(item, "no_persistence_rationale")
            )
            if not has_persistence:
                errors.append(f"{flow_id or idx}: covered row needs repository_or_adapter_refs or no_persistence_rationale")
        elif status == "scoped_deferred":
            if flow_id not in scoped_deferred:
                errors.append(f"{flow_id or idx}: scoped_deferred row must be listed in scoped_deferred_features")
            if not nonempty(item, "gap_reason"):
                errors.append(f"{flow_id or idx}: scoped_deferred row needs gap_reason")
        elif status == "blocked":
            if not nonempty(item, "gap_reason"):
                errors.append(f"{flow_id or idx}: blocked row needs gap_reason")

    expected_counts = {
        "covered_core_flow_count": counts["covered"],
        "scoped_deferred_core_flow_count": counts["scoped_deferred"],
        "uncovered_core_flow_count": counts["blocked"],
    }
    for field, value in expected_counts.items():
        if int_field(matrix.get(field)) != value:
            errors.append(f"core_flow_coverage_matrix.{field} must equal {value}")

    if contract.get("readiness") == "pass" and counts["blocked"] > 0:
        errors.append("readiness=pass requires uncovered_core_flow_count=0")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate service implement-mode core-flow coverage.")
    parser.add_argument("contract_json", type=Path)
    args = parser.parse_args()

    try:
        errors = validate(load_contract(args.contract_json))
    except Exception as exc:
        print(f"CORE-FLOW-COVERAGE status=fail error={exc}", file=sys.stderr)
        return 2
    if errors:
        print("CORE-FLOW-COVERAGE status=fail")
        for error in errors:
            print(f"- {error}")
        return 2
    print("CORE-FLOW-COVERAGE status=pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
