# Example IO - Service v2.4

## Input excerpt
```yaml
controller_contract:
  service_signature_hints:
    - method_name: createOrder
      request_type: CreateOrderRequest
      response_type: OrderResponse
      nfr_context_params: [idempotency_key]
business_rules:
  - order amount must be positive
  - user must exist before order creation
idempotency_design:
  key_header: X-Idempotency-Key
```

## Output excerpt
```yaml
artifact_contract:
  schema_version: skills.codegen.service.v2.4
  artifact_type: service_contract
  produced_by: service-draft-generation
  readiness: contract_aligned
  selected_mode: implement
  confirmed: [createOrder signature, positive amount rule]
  inferred: [TX-002 single entity write transaction, REPO-HINT-005 single aggregate mutation]
  pending: [exact repository package]
  n180_handoff_consumed:
    present: true
    implementable_core_flow_count: 1
    expected_selected_mode: implement
    implementation_decision_ledger_refs: [DEC-ORDER-001]
    scoped_deferred_features: []
  feature_depth_obligations:
    - obligation_id: FD-ORDER-ELIGIBILITY-001
      obligation_type: source_backed_eligibility
      source_refs: [RULE-ORDER-ELIGIBILITY-001, API-ORDER-CREATE]
      implementation_refs: [OrderService.createOrder]
      repository_or_adapter_refs: [EligibilityRepository.findCurrentEligibility]
      required_positive_cases: [TC-ORDER-ELIGIBILITY-001]
      required_negative_cases: [TC-ORDER-ELIGIBILITY-002, TC-ORDER-ELIGIBILITY-003]
      handoff_to: [N240]
  implementation_depth_ladder:
    - core_flow_id: FLOW-ORDER-001
      core_flow_name: create order
      source_refs: [RULE-ORDER-001]
      n180_task_refs: [TASK-ORDER-001]
      controller_action_refs: [OrderController.createOrder]
      service_method_refs: [OrderService.createOrder]
      state_branch_refs: []
      repository_or_adapter_refs: [OrderRepository.save]
      sql_or_schema_refs: [orders]
      positive_test_refs: [OrderServiceTest.createOrder_positive]
      negative_test_refs: [OrderServiceTest.createOrder_rejectsInvalidAmount]
      runtime_or_smoke_refs: [mvn test]
      coverage_status: covered
      gap_reason: ""
  core_flow_coverage_matrix:
    expected_core_flow_count: 1
    covered_core_flow_count: 1
    scoped_deferred_core_flow_count: 0
    uncovered_core_flow_count: 0
    coverage_basis: n180_core_flow_count
    rows: [FLOW-ORDER-001]
service_contract:
  service_method_map:
    - method_name: createOrder
      invoked_by:
        - source_contract: controller_contract
          controller_name: OrderController
          controller_method_name: createOrder
          source_api_ref: createOrder
          required: true
      request_type: CreateOrderRequest
      response_type: OrderResponse
      responsibility: create a single order aggregate
  transaction_plan:
    - method_name: createOrder
      propagation: REQUIRED
      read_only: false
      matched_rule_id: TX-002
  repository_call_hints:
    - repository_name: OrderRepository
      method_name: save
      purpose: mutate_single
      expected_cardinality: single
      consistency_or_locking_need: transactional write
```
