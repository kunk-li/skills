# Example IO - Service v2.3

## Input excerpt
```yaml
controller_contract:
  service_signature_hints:
    - method_name: createOrder
      request_type: CreateOrderRequest
      response_type: OrderResponse
      nfr_context_params: [idempotency_key]
business_rules:
  - order amount must be positive
  - user must exist before order creation
idempotency_design:
  key_header: X-Idempotency-Key
```

## Output excerpt
```yaml
artifact_contract:
  schema_version: skills.codegen.service.v2.3
  artifact_type: service_contract
  produced_by: service-draft-generation
  readiness: contract_aligned
  confirmed: [createOrder signature, positive amount rule]
  inferred: [TX-002 single entity write transaction, REPO-HINT-005 single aggregate mutation]
  pending: [exact repository package]
service_contract:
  service_method_map:
    - method_name: createOrder
      invoked_by:
        - source_contract: controller_contract
          controller_name: OrderController
          controller_method_name: createOrder
          source_api_ref: createOrder
          required: true
      request_type: CreateOrderRequest
      response_type: OrderResponse
      responsibility: create a single order aggregate
  transaction_plan:
    - method_name: createOrder
      propagation: REQUIRED
      read_only: false
      matched_rule_id: TX-002
  repository_call_hints:
    - repository_name: OrderRepository
      method_name: save
      purpose: mutate_single
      expected_cardinality: single
      consistency_or_locking_need: transactional write
```
