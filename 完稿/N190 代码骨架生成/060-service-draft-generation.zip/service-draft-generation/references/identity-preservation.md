# Source-defined lifecycle identity preservation

Use this rule when a service method mutates a stateful business object or accepts an external callback whose identity is defined by upstream requirements, state transitions, API contracts, schema, or concurrency design.

Carry the same source-defined identity tuple through the request/callback contract, service method signature, repository lookup, persistence binding, current-state predicate, and transition guard. Callback validation may add an external approval-instance identity. Keep that tuple separate from delivery idempotency keys, callback delivery retry counters, and aggregate row versions. A method must not infer that a workflow id or callback id alone represents a lifecycle attempt unless an upstream contract explicitly guarantees that mapping.

For each tuple, emit positive evidence for the active matching attempt and negative evidence for each stale or mismatched identity dimension. If upstream artifacts conflict or the source-to-storage/owner-field mapping is unresolved, preserve the source tuple, identify the conflicting artifacts, leave the method blocked/pending, and do not claim implementation readiness. Never invent a reopen/new-attempt trigger.
