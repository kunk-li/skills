# service-draft-generation 交付检查清单 v2.3

## A. artifact_contract 完整性
- ☐ 输出以 `artifact_contract` YAML 块开头
- ☐ `schema_version: n190.artifact.v2.3` 已声明
- ☐ `producer_skill: service-draft-generation`、`producer_node: N190`、`artifact_name: Service草稿.zip` 三项一致
- ☐ `readiness` ∈ {`pass`, `provisional`, `constrained`, `blocked`}
- ☐ `selected_mode` ∈ {`quick_service`, `full_service`, `flow_only`, `migration_mode`}

## B. 输入与方法对齐
- ☐ 至少有 controller hint / API action / 业务规则 / 状态机 之一作为最小输入
- ☐ 每个 service 方法都对应 controller 中的一个 endpoint 或一条业务规则
- ☐ 方法参数类型引用 DTO（来自 dto-vo-generation），未直接接收 Entity
- ☐ 方法返回值类型引用 DTO 或 VO，未直接返回 Entity

## C. 方法流骨架
- ☐ 每个方法都包含五段式骨架：input → validation → repository / external call → mapping → output
- ☐ 校验委托 `validator-code-generation` 产物，未在 service 中重写校验逻辑
- ☐ 业务规则引用 `业务规则清单.csv` 中的 rule_id，未在 service 中重新定义
- ☐ 异常抛出引用 `exception-class-generation` 产物中的异常类

## D. 事务与并发
- ☐ 事务边界（`@Transactional`、propagation、rollbackFor）已声明在 service 方法上
- ☐ 自调用（this.method()）路径已识别并标记 `self_invocation_risk: pending` 交给 N210 transaction-boundary-check 复核
- ☐ AFTER_COMMIT 事件 / outbox / 长事务风险已显式标注或标 `pending`
- ☐ 并发控制（乐观锁 / 悲观锁 / 分布式锁）选择已记录在 `concurrency_strategy` 字段

## E. 推断与发明纪律
- ☐ 未给出业务规则时不臆造业务逻辑分支，标 `business_logic: pending`
- ☐ 未给出状态机时不臆造状态转换，标 `state_transitions: pending`
- ☐ 所有推断进 `inferred[]` 并引用 controller method / business rule id
- ☐ source-backed eligibility、business-calendar temporal policy、enumerated detector breadth、read-side security filter 均已落 `feature_depth_obligations[]` 并交 N240

## F. 追溯与下游交接
- ☐ `traces_to_tasks[]` 引用 N180 task_id（业务实现任务）
- ☐ `downstream_consumers: [N200, N210, N240, N330]` 已声明
- ☐ `to_repository_draft.expected_methods[]` 已写明
- ☐ `to_validator.required_field_rules[]` 已写明
- ☐ `to_test (N240).method_signatures[]` 已写明，便于 N240 生成测试

## G. 红线问题
- ☐ 没有在 service 中编写 SQL 字符串（应委托 repository / sql-draft）
- ☐ 没有在 service 中处理 HTTP / 序列化（应保留在 controller）
- ☐ 没有在 `flow_only` 模式下生成完整业务实现
- ☐ 没有在没有事务证据的情况下声明 ACID OK
