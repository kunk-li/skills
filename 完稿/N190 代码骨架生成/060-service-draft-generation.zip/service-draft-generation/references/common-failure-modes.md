# service-draft-generation 常见失败模式 v2.3

## F1. 在 service 中编写 SQL 字符串

**症状**：service 方法内出现 `String sql = "SELECT * FROM orders WHERE user_id = ?"`，绕过 repository 层。

**后果**：数据访问散落；SQL 注入风险；与 ORM 不一致。

**修正**：
- service 只能调用 repository 方法或 N200 sql-draft-generation 提供的命名查询。
- service 中检测到 SQL 字符串字面量（含 `SELECT/INSERT/UPDATE/DELETE` 关键词）→ reject 并要求委托 repository。

---

## F2. 自调用导致事务失效

**症状**：service 内 `this.methodA()` 调用同类的 `@Transactional` 方法 `methodB`，但 Spring 的事务代理仅对外部调用生效，导致 `methodB` 的事务实际上没启动。

**后果**：数据不一致；异常发生时无法回滚；测试通过但生产数据错乱。

**修正**：
- 检测 service 内是否存在 `this.<method>` 调用且 `<method>` 标 `@Transactional` 不同传播级别 → 进入 `self_invocation_risk: pending`。
- 在 `to_n210_check.transaction_boundary[]` 中显式列出，交给 transaction-boundary-check 复核。
- 推荐使用 `applicationContext.getBean(MyService.class).methodB()` 或拆分到不同 service。

---

## F3. AFTER_COMMIT 事件与事务的混淆

**症状**：service 在 `@Transactional` 方法内 `eventPublisher.publishEvent(orderCreated)`，期待事件在事务提交后发布；但未声明 `@TransactionalEventListener(phase = AFTER_COMMIT)`，事件实际在事务中发布。

**后果**：事件订阅者读不到本次事务写入的数据（事务尚未提交）；产生"幻读式"故障。

**修正**：
- 检测 `eventPublisher.publishEvent(...)` 在 `@Transactional` 方法内 → 明确标 `event_phase: pending`，要求人工选择 `IN_TX` / `AFTER_COMMIT` / `AFTER_ROLLBACK`。
- 推荐 outbox 模式作为更可靠的 AFTER_COMMIT 替代；在 N300 集成设计中沉淀。

---

## F4. flow_only 模式生成完整业务实现

**症状**：`selected_mode: flow_only`（应当只输出 input → validation → repository → mapping → output 五段式骨架，无具体逻辑）但实际写出了完整业务分支与计算。

**后果**：用户期待骨架以便填空，拿到完整代码反而难以接管；与 `full_service` mode 难以区分。

**修正**：
- `flow_only` 模式严格输出五段式注释占位（如 `// 1. validate input` / `// TODO: business rule from RULE-007`）。
- 业务分支的 `if/switch` 与计算逻辑必须出现在 `full_service` 或 `migration_mode` 才允许。

---

## F5. 校验逻辑重写

**症状**：service 方法内手写 `if (request.getEmail() == null || !request.getEmail().contains("@")) throw new ValidationException(...)`。

**后果**：校验规则散落；与 N200 validator-code-generation 产物重复甚至冲突；规则变更需要改两处。

**修正**：
- service 入口处只调用 `validator.validate(request)` 一次，将所有校验委托 validator-code-generation 产物。
- 若必须在 service 内做业务级校验（涉及数据库查询，如"订单状态必须为 PENDING"），应分离到独立 `OrderStateValidator` 类，不与字段级校验混合。

---

## F6. 长事务

**症状**：service 方法标 `@Transactional` 且方法体内含外部 HTTP 调用、消息发送或大文件 I/O。

**后果**：数据库连接长时间占用；连接池耗尽；并发能力下降。

**修正**：
- 检测 `@Transactional` 方法内的 `RestTemplate.exchange` / `WebClient.post` / `kafkaTemplate.send` / `S3Client.putObject` 等阻塞 I/O → `long_transaction_risk: high`，进入 `pending[]`。
- 推荐拆分：事务方法只负责 DB 写入，外部调用放到 `@TransactionalEventListener(AFTER_COMMIT)` 或独立线程池。
- 与 transaction-boundary-check 联动复核。

---

## F7. quick_service 模式补全完整 service 类

**症状**：`selected_mode: quick_service`（应当只输出单一方法骨架）但生成了完整的 `OrderService` 接口 + 实现类 + 全部 CRUD 方法。

**后果**：mode 失效；用户拿到的代码量超出预期。

**修正**：
- `quick_service` 严格仅输出请求中明确提到的 1 个方法的签名 + 五段式注释。
- 方法所属类名只需出现一次，不展开其他兄弟方法。

---

## F8. 业务规则臆造

**症状**：缺少 `业务规则清单.csv` 时，service 方法内自行写出"金额超过 10000 需要审批"等业务分支。

**后果**：违反 `R03_no_invented_names` 同源原则的语义版本；规则与产品需求冲突。

**修正**：
- 业务分支必须引用 rule_id（如 `// see RULE-007`）；无对应 rule_id 时进入 `pending[]` 并标 `business_logic: pending_rules`。
- service 草稿在缺少业务规则输入时，五段式中"3. business logic"段直接写 `// TODO: pending business rules`，不臆造分支。
