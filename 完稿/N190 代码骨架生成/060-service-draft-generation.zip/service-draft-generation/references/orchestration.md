# service-draft-generation 编排说明 v2.3

## 上游优先级

1. `Controller草稿.java`（N190 sibling）— `service_method_calls[]` 决定 service 应实现的方法
2. `工程骨架.zip`（N190 sibling）— `package_layout` 与 `transaction_manager` / `cross_cutting`
3. `业务规则清单.csv`（N070）— 业务分支与状态机
4. `状态机定义.md`（N130 副产物）— 状态转换约束
5. `Repository草稿.java`（N190 sibling）— 数据访问方法
6. `异常类.java` / `校验器代码.java`（N200）— 异常映射与校验委托
7. `安全风险分析.md` / `并发控制建议.md`（N170）— 事务传播与并发策略
8. `开发任务拆分表.csv`（N180）— `traces_to_tasks[]`

最小输入：单个 controller hint 或 API action 描述（`quick_service` 模式）。

## 下游衔接

| 下游 sibling / 节点 | 提供字段 | 用途 |
|---|---|---|
| **repository-draft-generation** | `to_repository.expected_methods[]` | repository 应实现的方法 |
| **N200 dto-vo-generation** | `to_dto_vo.internal_dtos[]` | service 内部使用的 DTO |
| **N200 validator-code-generation** | `to_validator.business_validation_rules[]` | 业务级校验规则 |
| **N200 exception-class-generation** | `to_exception.thrown_types[]` | service 抛出的异常类型 |
| **N210 transaction-boundary-check** | `transaction_methods[]` / `self_invocation_risks[]` | 事务边界静态检查 |
| **N240** | `service_method_signatures[]` / `mock_targets[]` | 单测生成 |
| **N330** | `business_flow_descriptions[]` | 业务文档 |

## 字段级映射

### Controller 草稿 → service
| controller 字段 | service 字段 |
|---|---|
| `service_method_calls[].signature` | `methods[].signature` 必须匹配 |
| `service_method_calls[].args[].type` | `methods[].param_types` 一致 |
| `service_method_calls[].return_type` | `methods[].return_type` 一致 |

### N070 业务规则 → service
| rule_type | service 体现 |
|---|---|
| `business_logic` | service 方法分支引用 `// see RULE-xxx` |
| `state_machine` | service 内 `OrderState.next(currentState, action)` 调用 |
| `derived_calculation` | service 内业务计算方法（不在 controller / repository） |

### N170 → service
| N170 输入 | service 字段 |
|---|---|
| `concurrency_design.optimistic_locking` | `methods[].concurrency_strategy: optimistic` + `@Version` 提示给 entity |
| `concurrency_design.pessimistic_locking` | repository 调用使用 `findByIdForUpdate` |
| `idempotency_design.token_based` | service 方法首参增加 `@IdempotencyKey String token` |
| `concurrency_design.distributed_lock` | `// TODO: acquire distributed lock` 占位，交 N300 决定 |

## 反向约束

### service 基于 sibling 的约束
- 包路径必须落在 scaffold `package_layout.base + .service` 内。
- 方法签名必须能被 controller 的 `service_method_calls[]` 引用；不一致则 N190 aggregator reject。
- 调用的 repository 方法必须存在于 repository 草稿；缺失进入 `to_repository.expected_methods[]`。

### service 不允许的范围
- 不允许编写 SQL 字符串或调用 `entityManager.createNativeQuery`（绕过 repository）。
- 不允许直接处理 HTTP 请求/响应对象（`HttpServletRequest` / `ResponseEntity`）—— 这是 controller 的职责。
- 不允许在事务方法内做阻塞 I/O（HTTP 调用 / 消息发送 / 大文件 I/O）；检测到则进入 `long_transaction_risk: high`。

### 事务传播约束
- 默认 `@Transactional(propagation = REQUIRED)`；其他传播级别必须有明确依据（如 `REQUIRES_NEW` 用于审计独立事务）。
- 自调用风险必须显式声明 `self_invocation_risk: pending` 而非静默忽略。

## Mode-specific orchestration

| Mode | 上游消费 | 下游 handoff |
|---|---|---|
| `quick_service` | 单个 controller method | 仅该方法的 5 段式骨架 + repository 调用清单 |
| `full_service` | 完整 controller + N070 + N170 | 完整 repository / dto / validator / exception handoff |
| `flow_only` | controller hints | 仅 5 段式注释占位，无业务分支 |
| `migration_mode` | 已有 service + 新事务/异常约定 | 输出 diff，保留业务逻辑 |
