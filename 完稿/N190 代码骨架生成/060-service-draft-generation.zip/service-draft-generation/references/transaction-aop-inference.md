# Transaction and AOP inference

> Authoritative source note: this Markdown file is a human-readable guide. The corresponding `*-algorithms.yaml`, input/output contracts, shared enum dictionary, and self-check YAML files are the source of truth for executable decisions.

Default transaction inference:
- single aggregate write -> REQUIRED, READ_COMMITTED, read_only=false
- pure query -> SUPPORTS or framework equivalent, read_only=true
- cross aggregate write -> REQUIRED plus explicit consistency note; recommend saga/outbox when distributed
- audit must succeed with business write -> same transaction or mandatory policy
- external side effect after commit -> publish event or outbox step, not direct irreversible call inside transaction unless justified

AOP inference:
- idempotency design -> idempotent annotation/context key
- audit design -> auditable event type
- authorization model -> permission declaration if service-level enforcement is used
- external dependency -> circuit breaker and retry policy
- performance observability -> timed/traced annotations
