# Cross-cutting control patterns (service-method generation guidance)

When a service method implements one of the cross-cutting controls below, generate it to the pattern here rather than the naive happy-path shape. The naive forms (boolean gate, single-layer dedup, claimed cross-store atomicity, post-commit-swallowed audit, deny-on-missing absent) are the recurring defect classes. Generic and stack-agnostic. Mark pattern-required infrastructure in inferred[]/pending[].

## Three meta-principles
1. Fail-closed by default: missing dependency / unknown enum / null input / absent factor leads to denial, never a pass. Use Optional/three-state verdicts, not booleans.
2. Single source of truth + re-check at every entry: authoritative state in the primary transactional store; every capability/read entry re-reads it fail-closed, never trusting a cache, session token, client parameter, or denormalized value.
3. Safe direction for irreversible/protective effects: over-applying a protection is acceptable, missing it is not; never nest an irreversible secondary-store mutation inside a rollbackable transaction; detect misses with a reconciliation pass + replay.

## Per-control patterns
- Grant-ceiling: pure check(grantorEnvelope, demand); resolve envelope as Optional (empty=deny, no grant-everything default); measure the actual signer not the initiator; reject degenerate envelope at construction.
- Resource-owner/IDOR: authorize iff caller in owners(endpoint, instance); differentiate owner sets per endpoint; collapse not-found and not-owner to one response (no existence leak); list/export scope = caller owned set intersected with (never expanded by) client filters; owner filter in the query layer not in-memory; role-can-call never implies can-access-this-instance.
- Value-snapshot: persist a group of immutable fields (including the computed result) + source id at binding; resolver re-checks consistency and detects drift at read; never fall back to a live read on missing snapshot; a refresh is an explicit re-lock overwrite with audit.
- Idempotency/uniqueness: DB UNIQUE is final truth (L2); a cache pre-claim (L1) only lowers contention; an app-layer SELECT (L3) only yields a friendly conflict — SELECT-then-insert alone has a TOCTOU race; normalize the identity; a partial unique index excludes terminal states.
- Lifecycle revocation: terminal/suspended subjects denied across every capability face (act/login/query); primary-store status is the single truth source and every entry re-checks it fail-closed; session revocation is best-effort immediacy; unfreeze restores symmetrically; termination irreversible.
- Control enforcement: enforcing method returns void (pass continue, fail throw), never a boolean; factor verdicts three-state with no PASS default; unwired/unavailable factor treated as failure; empty allow-lists deny; trust only a verified input source.
- Audit/mandatory-write durability: never business-committed-but-audit-silently-lost; either same-transaction (audit-fail rolls business back), or outbox intent in the business transaction + async deliver + reconciliation flagging committed-without-audit + replay.

## Cross-store ordering
A single logical state change on both a transactional store and a non-transactional secondary store (session/cache/queue/external) cannot be one XA transaction. Pick an ordering whose intermediate state is fail-safe: protective side effect first then commit business (over-protect-safe), or commit business first then best-effort secondary write + reconciliation (only when compensable). Best-effort telemetry, single-store steps, and the audit trail are exempt. Design-side rule 048 R07.
