#!/usr/bin/env python3
"""Validate repository persistence-depth evidence in a generated contract.

The checker is intentionally dependency-free. It accepts JSON on stdin or from
the first CLI argument. YAML producers can pipe their parsed JSON equivalent
from the surrounding harness.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


ALLOWED_KINDS = {
    "aggregate_root",
    "child_entity",
    "source_lineage",
    "snapshot",
    "workflow_state",
    "baseline_seed",
    "read_model",
    "external_reference",
    "no_persistence",
}

ALLOWED_STATUS = {"covered", "scoped_deferred", "blocked", "uncovered"}

BASE_REQUIRED_FIELDS = {
    "persistence_id",
    "source_refs",
    "n180_core_flow_refs",
    "domain_object",
    "persistence_kind",
    "repository_refs",
    "mapper_or_query_refs",
    "schema_refs",
    "seed_trace_refs",
    "rollback_or_irreversible_refs",
    "positive_test_handoff_refs",
    "negative_test_handoff_refs",
    "runtime_boundary_refs",
    "coverage_status",
    "gap_reason",
}

KIND_REQUIRED_REFS = {
    "aggregate_root": {
        "repository_refs",
        "mapper_or_query_refs",
        "schema_refs",
        "positive_test_handoff_refs",
        "negative_test_handoff_refs",
        "runtime_boundary_refs",
    },
    "child_entity": {
        "repository_refs",
        "mapper_or_query_refs",
        "schema_refs",
        "rollback_or_irreversible_refs",
        "positive_test_handoff_refs",
        "negative_test_handoff_refs",
    },
    "source_lineage": {
        "repository_refs",
        "schema_refs",
        "seed_trace_refs",
        "runtime_boundary_refs",
    },
    "snapshot": {
        "repository_refs",
        "schema_refs",
        "rollback_or_irreversible_refs",
        "runtime_boundary_refs",
    },
    "workflow_state": {
        "repository_refs",
        "mapper_or_query_refs",
        "schema_refs",
        "positive_test_handoff_refs",
        "negative_test_handoff_refs",
        "runtime_boundary_refs",
    },
    "baseline_seed": {
        "schema_refs",
        "seed_trace_refs",
        "rollback_or_irreversible_refs",
        "positive_test_handoff_refs",
    },
    "read_model": {
        "repository_refs",
        "mapper_or_query_refs",
        "schema_refs",
        "positive_test_handoff_refs",
        "runtime_boundary_refs",
    },
    "external_reference": {
        "repository_refs",
        "schema_refs",
        "runtime_boundary_refs",
    },
    "no_persistence": {"source_refs", "gap_reason"},
}


def _is_present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set, dict)):
        return bool(value)
    return True


def _find_contract(document: dict[str, Any]) -> dict[str, Any]:
    if isinstance(document.get("repository_contract"), dict):
        return document["repository_contract"]
    if isinstance(document.get("artifact_contract"), dict):
        return document["artifact_contract"]
    return document


def validate(document: dict[str, Any]) -> list[str]:
    contract = _find_contract(document)
    rows = contract.get("persistence_depth_matrix")
    summary = contract.get("persistence_depth_summary", {})
    errors: list[str] = []

    if not isinstance(rows, list) or not rows:
        return ["persistence_depth_matrix must be a non-empty list"]

    seen_ids: set[str] = set()
    counts = {"covered": 0, "scoped_deferred": 0, "uncovered": 0}

    for idx, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            errors.append(f"row {idx}: must be an object")
            continue

        missing_fields = sorted(BASE_REQUIRED_FIELDS - set(row))
        if missing_fields:
            errors.append(f"row {idx}: missing fields {', '.join(missing_fields)}")

        persistence_id = row.get("persistence_id")
        if not _is_present(persistence_id):
            errors.append(f"row {idx}: persistence_id is empty")
        elif persistence_id in seen_ids:
            errors.append(f"row {idx}: duplicate persistence_id {persistence_id}")
        else:
            seen_ids.add(str(persistence_id))

        kind = row.get("persistence_kind")
        status = row.get("coverage_status")
        if kind not in ALLOWED_KINDS:
            errors.append(f"row {idx}: invalid persistence_kind {kind!r}")
            continue
        if status not in ALLOWED_STATUS:
            errors.append(f"row {idx}: invalid coverage_status {status!r}")
            continue

        if status == "covered":
            for field in sorted(KIND_REQUIRED_REFS[kind]):
                if not _is_present(row.get(field)):
                    errors.append(
                        f"row {idx}: covered {kind} missing required {field}"
                    )
        else:
            if not _is_present(row.get("gap_reason")):
                errors.append(
                    f"row {idx}: {status} row must explain gap_reason"
                )

        if status in counts:
            counts[status] += 1
        elif status == "blocked":
            counts["uncovered"] += 1

    expected = summary.get("expected_domain_objects")
    covered = summary.get("covered_domain_objects")
    scoped = summary.get("scoped_deferred_domain_objects")
    uncovered = summary.get("uncovered_domain_objects")
    if expected is not None and expected != len(rows):
        errors.append(
            f"summary expected_domain_objects={expected} but matrix has {len(rows)} rows"
        )
    if covered is not None and covered != counts["covered"]:
        errors.append(
            f"summary covered_domain_objects={covered} but counted {counts['covered']}"
        )
    if scoped is not None and scoped != counts["scoped_deferred"]:
        errors.append(
            "summary scoped_deferred_domain_objects="
            f"{scoped} but counted {counts['scoped_deferred']}"
        )
    if uncovered is not None and uncovered != counts["uncovered"]:
        errors.append(
            f"summary uncovered_domain_objects={uncovered} but counted {counts['uncovered']}"
        )

    return errors


def _load_document() -> dict[str, Any]:
    if len(sys.argv) > 1 and sys.argv[1] not in {"-", "--"}:
        return json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    return json.loads(sys.stdin.read())


def main() -> int:
    errors = validate(_load_document())
    if errors:
        print("PERSISTENCE-DEPTH status=fail")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PERSISTENCE-DEPTH status=pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
