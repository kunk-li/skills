#!/usr/bin/env python3
"""Self-tests for validate_persistence_depth.py."""

from __future__ import annotations

from validate_persistence_depth import validate


def _valid_contract() -> dict:
    return {
        "repository_contract": {
            "persistence_depth_matrix": [
                {
                    "persistence_id": "PDM-ORDER-001",
                    "source_refs": ["entity.Order"],
                    "n180_core_flow_refs": ["TASK-ORDER-LIST"],
                    "domain_object": "Order",
                    "persistence_kind": "aggregate_root",
                    "repository_refs": ["OrderRepository"],
                    "mapper_or_query_refs": ["findByUserIdAndStatus"],
                    "schema_refs": ["orders"],
                    "seed_trace_refs": [],
                    "rollback_or_irreversible_refs": [],
                    "positive_test_handoff_refs": ["N240:list_orders_allowed"],
                    "negative_test_handoff_refs": ["N240:list_orders_denied"],
                    "runtime_boundary_refs": ["DB-ORDERS"],
                    "coverage_status": "covered",
                    "gap_reason": "",
                },
                {
                    "persistence_id": "PDM-SEED-001",
                    "source_refs": ["seed.order_status"],
                    "n180_core_flow_refs": ["TASK-ORDER-LIST"],
                    "domain_object": "OrderStatusBaseline",
                    "persistence_kind": "baseline_seed",
                    "repository_refs": [],
                    "mapper_or_query_refs": [],
                    "schema_refs": ["order_status_dict"],
                    "seed_trace_refs": ["seed_order_status.sql"],
                    "rollback_or_irreversible_refs": ["rollback_order_status.sql"],
                    "positive_test_handoff_refs": ["N240:seed_exists"],
                    "negative_test_handoff_refs": [],
                    "runtime_boundary_refs": ["DB-ORDERS"],
                    "coverage_status": "covered",
                    "gap_reason": "",
                },
            ],
            "persistence_depth_summary": {
                "expected_domain_objects": 2,
                "covered_domain_objects": 2,
                "scoped_deferred_domain_objects": 0,
                "uncovered_domain_objects": 0,
            },
        }
    }


def test_valid_contract_passes() -> None:
    assert validate(_valid_contract()) == []


def test_covered_row_requires_kind_refs() -> None:
    doc = _valid_contract()
    doc["repository_contract"]["persistence_depth_matrix"][0]["schema_refs"] = []
    errors = validate(doc)
    assert any("missing required schema_refs" in error for error in errors)


def test_noncovered_requires_gap_reason() -> None:
    doc = _valid_contract()
    doc["repository_contract"]["persistence_depth_matrix"][0][
        "coverage_status"
    ] = "scoped_deferred"
    errors = validate(doc)
    assert any("gap_reason" in error for error in errors)


def test_summary_counts_must_match_rows() -> None:
    doc = _valid_contract()
    doc["repository_contract"]["persistence_depth_summary"][
        "covered_domain_objects"
    ] = 1
    errors = validate(doc)
    assert any("covered_domain_objects=1" in error for error in errors)


def main() -> int:
    test_valid_contract_passes()
    test_covered_row_requires_kind_refs()
    test_noncovered_requires_gap_reason()
    test_summary_counts_must_match_rows()
    print("PERSISTENCE-DEPTH-SELFTEST status=pass tests=4")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
