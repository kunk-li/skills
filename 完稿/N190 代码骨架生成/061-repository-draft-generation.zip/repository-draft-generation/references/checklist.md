# repository-draft-generation 交付检查清单 v2.3

## A. artifact_contract 完整性
- ☐ 输出以 `artifact_contract` YAML 块开头
- ☐ `schema_version: n190.artifact.v2.3` 已声明
- ☐ `producer_skill: repository-draft-generation`、`producer_node: N190`、`artifact_name: Repository草稿.zip` 三项一致
- ☐ `readiness` ∈ {`pass`, `provisional`, `constrained`, `blocked`}
- ☐ `selected_mode` ∈ {`quick_repository`, `full_repository`, `query_focused`, `migration_mode`}

## B. 输入与 schema 对齐
- ☐ 至少有 实体定义 / 表结构 / query 目标 / repository 模式 之一作为最小输入
- ☐ 主键、唯一键、外键已识别，每个 query 方法引用对应索引或标 `index_hint: pending`
- ☐ 读侧屏蔽/租户/owner/角色/合规过滤已落 `read_side_security_filters[]`，并覆盖 list/search/export/read-model 查询
- ☐ 字段类型沿用 DB schema（DECIMAL / BIGINT / TIMESTAMP），不臆造 Java 类型

## C. 查询方法纪律
- ☐ 命名查询（`findByXxxAndYyy`）明确对应 SQL 等价形式
- ☐ 分页方法使用 `Pageable` / `Page<T>`，未发明私有分页对象
- ☐ 动态条件查询委托 Specification / Criteria，未在 repository 接口中堆叠 if-else
- ☐ 写操作（save / update / delete）的事务边界由 service 层声明，repository 不内嵌事务

## D. 方言与 ORM 适配
- ☐ `dialect_declaration` 已声明（mysql / postgresql / oracle / mssql / sqlite），未知则填 `pending`
- ☐ `orm_declaration` 已声明（jpa / mybatis / mybatis-plus / jooq / spring-data-jdbc），未知则填 `pending`
- ☐ 方言敏感语法（LIMIT / OFFSET / RETURNING / 序列）已根据 dialect 选择，否则进 `pending[]`

## E. 推断与发明纪律
- ☐ 未给出实体时不臆造字段，标 `entity_pending: true`
- ☐ 复杂查询（JOIN / 子查询 / 窗口函数）必须引用 `query-optimization-recommendation` 的优化建议或标 pending
- ☐ 所有推断进 `inferred[]` 并引用表 / 列名 / 索引名

## F. 追溯与下游交接
- ☐ `traces_to_tasks[]` 引用 N180 task_id（数据访问任务）
- ☐ `downstream_consumers: [N200, N210, N330]` 已声明
- ☐ `to_service_draft.expected_repository_methods[]` 已写明
- ☐ `to_sql_draft.required_ddl[]` / `required_indexes[]` 已写明
- ☐ `production_boundary_manifest[]` 已列出 release-critical DB/cache/search/object-store/external-source 边界，并交给 N240/N260/N270
- ☐ `read_side_security_filters[]` 已交 N240/N260 生成允许/拒绝/特权旁路测试
- ☐ manifest 中 `evidence_tier_required=production_external_integration`；没有把本地、单测、mock、in-memory 或 self-contained 证据当成生产集成通过

## G. 红线问题
- ☐ 没有把 repository 方法返回值类型设为 Entity 而暴露给 controller
- ☐ 没有在 repository 接口中嵌入业务规则
- ☐ 没有在 `query_focused` 模式下补全 CRUD 方法（应仅输出 query 增量）
- ☐ 没有在没有索引证据的情况下声明性能 OK
- ☐ 没有让生产持久化边界从后续 N240/N260/N270 证据链中消失
