# repository-draft-generation 编排说明 v2.3

## 上游优先级

1. `表结构设计草案.sql`（N160）— 实体字段、索引、约束的主数据源
2. `工程骨架.zip`（N190 sibling）— `package_layout` 与 `orm_declaration` / `dialect_declaration`
3. `Service草稿.zip`（N190 sibling）— `repository_method_calls[]` 决定 repository 应实现的方法
4. `查询优化建议.md`（N200 query-optimization-recommendation）— 优化候选与索引建议
5. `开发任务拆分表.csv`（N180）— `traces_to_tasks[]`

最小输入：实体定义 / 表结构 / query 目标 / repository 模式任一即可（`quick_repository` 模式）。

## 下游衔接

| 下游 sibling / 节点 | 提供字段 | 用途 |
|---|---|---|
| **service-draft-generation** | `repository_methods[].signature` | service 调用基线 |
| **N200 sql-draft-generation** | `to_sql.required_ddl[]` / `required_indexes[]` | DDL 与索引生成 |
| **N200 query-optimization-recommendation** | `query_methods[]` | 优化目标 |
| **N210** | `repository_files[]` | 静态检查范围 |
| **N240** | `repository_method_signatures[]` | 数据访问层测试 |
| **N330** | `entity_surface[]` | 数据模型文档 |

## 字段级映射

### N160 (DDL) → repository
| DDL 元素 | repository 字段 |
|---|---|
| `CREATE TABLE orders` | Entity 类名 `Order` + `@Table(name="orders")` |
| 列定义 | Entity 字段 + `@Column` |
| 主键 | `@Id` + `@GeneratedValue` |
| 唯一索引 | `@Column(unique=true)` 或 `@Table(uniqueConstraints=...)` |
| 复合索引 | `@Index` 或 repository 方法名提示 |
| 外键 | `@ManyToOne` / `@OneToMany`（默认 LAZY） |
| 软删除字段 | `@SQLDelete` + `@Where(clause="deleted_at IS NULL")` |
| 审计字段 | `@CreatedDate` / `@LastModifiedDate` 与 `@EntityListeners(AuditingEntityListener.class)` |

### service repository_method_calls[] → repository methods
service 中的每个 `repository.methodName(...)` 调用必须能映射到 repository 方法：
- 命名查询：`findByXxxAndYyy(...)` 与 Spring Data 命名规则一致
- 自定义查询：`@Query` 注解 + JPQL/HQL/SQL，方言敏感语法等 `dialect_declaration` 确定后才输出
- 动态条件：`Specification<Order>` 或 `Predicate` 参数

### N200 query-optimization-recommendation → repository
| 优化建议字段 | repository 体现 |
|---|---|
| `index_hint` | `@Query(value="...", hint="USE INDEX(idx_user_status)")`（仅 MySQL） |
| `pagination_strategy: keyset` | repository 增加 `findByCreatedAtLessThanOrderByCreatedAtDesc(Pageable)` |
| `n_plus_one_fix` | `@EntityGraph(attributePaths={"items"})` 标注 |

## 反向约束

### repository 基于 sibling 的约束
- 包路径必须落在 scaffold `package_layout.base + .repository` 内。
- ORM 选型必须与 scaffold 的 `orm_declaration` 一致（jpa / mybatis / mybatis-plus / jooq / spring-data-jdbc）。
- 方言必须与 scaffold 的 `dialect_declaration` 一致；方言无关方法可在 `dialect: pending` 下输出。

### repository 不允许的范围
- 不允许在方法上写 `@Transactional`（除 `readOnly=true` 提示）；事务由 service 层管理。
- 不允许在 repository 接口或实现中嵌入业务规则（如 `findActiveOrdersForVip`）。
- 不允许返回 entity 类型给 controller；controller 不直接 import repository。

## Mode-specific orchestration

| Mode | 上游消费 | 下游 handoff |
|---|---|---|
| `quick_repository` | 单个实体 / 表结构 | 仅声明该实体的 CRUD 方法签名 |
| `full_repository` | 完整表结构 + service 方法清单 + 索引建议 | 完整 query + sql + test handoff |
| `query_focused` | 已有 repository + service 新增方法 | 仅输出查询方法增量 diff |
| `migration_mode` | 已有 repository + 新 ORM/方言 | 输出 diff，保留方法签名不变 |
