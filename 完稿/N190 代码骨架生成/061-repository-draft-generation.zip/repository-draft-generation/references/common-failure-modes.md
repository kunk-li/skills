# repository-draft-generation 常见失败模式 v2.3

## F1. 方言假设

**症状**：在 `dialect_declaration: pending` 的情况下生成 `LIMIT 10 OFFSET 0`（MySQL/PostgreSQL 语法），而项目实际使用 Oracle（应为 `OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY`）。

**后果**：repository 草稿一编译就报方言错；用户失去信任。

**修正**：
- 启动时扫描输入：`spring.datasource.url` / `application.yml` / `liquibase` 配置中的方言提示。
- 未识别方言时设 `dialect_declaration: pending`，输出方言无关的中间表达（JPA criteria 或 Spring Data 命名查询），分页统一用 `Pageable`。
- `R0X_dialect_specific_syntax`：方言敏感语法必须等 `dialect_declaration` 确定后才输出。

---

## F2. N+1 查询陷阱

**症状**：方法名 `findOrdersByUserId` 返回 `List<Order>`，每个 Order 通过 `@OneToMany` 懒加载关联 `OrderItem` —— 触发 N+1 查询。

**后果**：性能问题在生产环境才暴露；DBA 投诉；监控告警风暴。

**修正**：
- 检测方法返回值是否包含 `@OneToMany` / `@ManyToMany` 关联实体，是则建议提供 `findOrdersByUserIdWithItems`（使用 `@EntityGraph` 或 JOIN FETCH）。
- 在 `inferred[]` 中标记 `n_plus_one_risk: true` 并交给 N200 query-optimization-recommendation 复核。
- `R0X_n_plus_one_warning`：检测到联表懒加载必须警告。

---

## F3. 索引证据缺失却声明性能 OK

**症状**：repository 草稿包含 `findByUserIdAndStatusAndCreatedAtBetween`（3 字段复合查询），但输入的 `表结构设计草案.sql` 中没有对应索引；草稿仍标 `readiness: pass`。

**后果**：表数据量上来后该查询全表扫描；P99 飙升。

**修正**：
- 每个查询方法都必须引用对应索引或标 `index_hint: pending`。
- `R0X_index_evidence_required`：未引用索引的查询方法 `evidence_profile` 不能高于 `mixed`。
- 必要时把缺失索引写入 `to_sql_draft.required_indexes[]` 交给 sql-draft-generation。

---

## F4. 在 repository 接口中嵌入业务规则

**症状**：repository 方法 `findActiveOrdersForVipUser(Long userId)` 内部硬编码 `status = 'ACTIVE' AND user.level >= 'VIP'`。

**后果**：业务规则散落在数据访问层；规则变更需要改 repository；难以测试与维护。

**修正**：
- repository 方法只接受参数，不内嵌业务规则。
- 业务条件由 service 层组合 `Specification` / `Criteria` 后传入；或通过 query DSL（QueryDSL、jOOQ）。
- `R0X_no_business_logic`：repository 方法名中不允许出现 `Active` / `Vip` / `Pending` 等业务状态词，应使用通用 `findByStatusAndLevel`。

---

## F5. query_focused 模式补全 CRUD

**症状**：`selected_mode: query_focused`（用户明确表示已有 repository，仅扩展查询）但草稿仍输出完整 CRUD（save / delete / count 等）。

**后果**：mode 失效；用户需要手工删除冗余方法；diff 噪声大。

**修正**：
- `query_focused` 模式严格只输出查询方法增量；CRUD 标 `assumed_existing: true` 并不输出。
- 输入若包含已有 repository 接口源码，则与之 diff 后只输出新增/修改的查询方法。

---

## F6. 写操作内嵌事务

**症状**：repository 方法上写 `@Transactional`，企图在 repository 层管理事务。

**后果**：事务边界被前移到 repository；service 层多个 repository 调用无法在一个事务中；与 Spring 推荐的"事务在 service 层"模式冲突。

**修正**：
- repository 方法**不允许** `@Transactional`（除非是只读 `@Transactional(readOnly = true)` 提示）。
- 事务边界由 service 草稿声明；migration_mode 中发现 repository 上有 `@Transactional` 时进入 `pending[]` 并交 transaction-boundary-check 复核。

---

## F7. ORM 假设泄漏

**症状**：在 `orm_declaration: pending` 时输出 `@Query("SELECT o FROM Order o WHERE ...")`（JPA 语法），但项目实际使用 MyBatis。

**后果**：代码完全无法运行；用户必须重写。

**修正**：
- 启动时扫描 `*.xml` mapper / `@Mapper` 注解 / `MyBatisAutoConfiguration` 来识别 ORM。
- 未识别时设 `orm_declaration: pending`，输出方法签名而不附 SQL；让用户在确定 ORM 后由 sql-draft-generation 填充。
