# Example IO - Repository v2.4

## Input excerpt
```yaml
entity_definition_or_table_schema_or_query_goals:
  entity: Order
  fields: [id, user_id, status, created_at, deleted_at]
service_contract_repository_call_hints:
  - repository_name: OrderRepository
    method_name: findByUserIdAndStatus
    purpose: filter_by_conditions
    expected_cardinality: page
    domain_object: Order
    n180_core_flow_ref: TASK-ORDER-LIST
index_design:
  - index_ref: IDX_ORDER_USER_STATUS_CREATED
    columns: [user_id, status, created_at]
seed_or_baseline_requirements:
  - seed_ref: SEED-ORDER-STATUS
    domain_object: OrderStatusBaseline
```

## Output excerpt
```yaml
artifact_contract:
  schema_version: skills.codegen.repository.v2.4
  artifact_type: repository_contract
  produced_by: repository-draft-generation
  readiness: contract_aligned
  confirmed: [Order table fields, service repository hint, matching index]
  inferred: [QS-001 can use derived name in spring data jpa]
  pending: [fetch strategy depends on relationship model]
repository_contract:
  query_method_plan:
    - method_name: findByUserIdAndStatus
      purpose: filter_by_conditions
      query_strategy:
        type: derived_name
        matched_rule_id: QS-001
      pagination:
        enabled: true
        return_type: page
      index_alignment:
        index_ref: IDX_ORDER_USER_STATUS_CREATED
        full_scan_risk: false
    - method_name: saveOrder
      purpose: mutate_single
      query_strategy:
        type: explicit_query
        matched_rule_id: QS-003
      pagination:
        enabled: false
        return_type: single
  persistence_depth_matrix:
    - persistence_id: PDM-ORDER-001
      source_refs: [entity_definition_or_table_schema_or_query_goals]
      n180_core_flow_refs: [TASK-ORDER-LIST]
      domain_object: Order
      persistence_kind: aggregate_root
      repository_refs: [OrderRepository]
      mapper_or_query_refs: [findByUserIdAndStatus, saveOrder]
      schema_refs: [orders, IDX_ORDER_USER_STATUS_CREATED]
      seed_trace_refs: []
      rollback_or_irreversible_refs: [rollback_sql.orders]
      positive_test_handoff_refs: [N240:list_orders_allowed]
      negative_test_handoff_refs: [N240:list_orders_denied]
      runtime_boundary_refs: [production_boundary_manifest.DB-ORDERS]
      coverage_status: covered
      gap_reason: ""
    - persistence_id: PDM-ORDER-002
      source_refs: [seed_or_baseline_requirements.SEED-ORDER-STATUS]
      n180_core_flow_refs: [TASK-ORDER-LIST]
      domain_object: OrderStatusBaseline
      persistence_kind: baseline_seed
      repository_refs: []
      mapper_or_query_refs: []
      schema_refs: [order_status_dict]
      seed_trace_refs: [seed_order_status.sql]
      rollback_or_irreversible_refs: [rollback_sql.order_status_dict]
      positive_test_handoff_refs: [N240:status_seed_exists]
      negative_test_handoff_refs: []
      runtime_boundary_refs: [production_boundary_manifest.DB-ORDERS]
      coverage_status: covered
      gap_reason: ""
  persistence_depth_summary:
    expected_domain_objects: 2
    covered_domain_objects: 2
    scoped_deferred_domain_objects: 0
    uncovered_domain_objects: 0
```
