# Example IO - Repository v2.3

## Input excerpt
```yaml
entity_definition_or_table_schema_or_query_goals:
  entity: Order
  fields: [id, user_id, status, created_at, deleted_at]
service_contract_repository_call_hints:
  - repository_name: OrderRepository
    method_name: findByUserIdAndStatus
    purpose: filter_by_conditions
    expected_cardinality: page
index_design:
  - index_ref: IDX_ORDER_USER_STATUS_CREATED
    columns: [user_id, status, created_at]
```

## Output excerpt
```yaml
artifact_contract:
  schema_version: skills.codegen.repository.v2.3
  artifact_type: repository_contract
  produced_by: repository-draft-generation
  readiness: contract_aligned
  confirmed: [Order table fields, service repository hint, matching index]
  inferred: [QS-001 can use derived name in spring data jpa]
  pending: [fetch strategy depends on relationship model]
repository_contract:
  query_method_plan:
    - method_name: findByUserIdAndStatus
      purpose: filter_by_conditions
      query_strategy:
        type: derived_name
        matched_rule_id: QS-001
      pagination:
        enabled: true
        return_type: page
      index_alignment:
        index_ref: IDX_ORDER_USER_STATUS_CREATED
        full_scan_risk: false
    - method_name: saveOrder
      purpose: mutate_single
      query_strategy:
        type: explicit_query
        matched_rule_id: QS-003
      pagination:
        enabled: false
        return_type: single
```
