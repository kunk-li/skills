# Persistence convention guide

> Authoritative source note: this Markdown file is a human-readable guide. The corresponding `*-algorithms.yaml`, input/output contracts, shared enum dictionary, and self-check YAML files are the source of truth for executable decisions.

Use derived query names only for simple predicates. Switch to explicit queries or query builders when names exceed 60 characters, include joins/subqueries/aggregates, or represent dynamic filters.

Pagination should use one standard per service/module: Page/PagedResponse, cursor, or slice. Do not mix list-plus-total ad hoc shapes.

N+1 detection heuristic: if a query returns a collection of entities with one-to-many or many-to-many relationships and no fetch plan is declared, mark risk=true and propose entity graph, join fetch, batch fetching, select-in, prefetch, or explicit DTO projection depending on persistence style.

Index alignment: extract equality/range/order predicates and map them to indexes. If no index exists, record full_scan_risk and rationale instead of hiding the risk.

Persistence depth: every generated repository surface must be reconciled against the business persistence inventory before readiness can be pass. Build `persistence_depth_matrix[]` from N160/N170/N180/service/query inputs and include rows for aggregate roots, child entities, source-lineage records, workflow states, baseline seeds, snapshots, read models and external references. A row may be `covered` only when repository or mapper/query refs, schema refs, rollback or irreversible refs, test handoff refs and runtime-boundary refs are present as required by `repository-algorithms.yaml`. Treat missing seed trace for baseline data and missing source-lineage storage as completeness gaps, not optional polish.
