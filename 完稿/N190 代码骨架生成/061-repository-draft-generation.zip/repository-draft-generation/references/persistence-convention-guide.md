# Persistence convention guide

> Authoritative source note: this Markdown file is a human-readable guide. The corresponding `*-algorithms.yaml`, input/output contracts, shared enum dictionary, and self-check YAML files are the source of truth for executable decisions.

Use derived query names only for simple predicates. Switch to explicit queries or query builders when names exceed 60 characters, include joins/subqueries/aggregates, or represent dynamic filters.

Pagination should use one standard per service/module: Page/PagedResponse, cursor, or slice. Do not mix list-plus-total ad hoc shapes.

N+1 detection heuristic: if a query returns a collection of entities with one-to-many or many-to-many relationships and no fetch plan is declared, mark risk=true and propose entity graph, join fetch, batch fetching, select-in, prefetch, or explicit DTO projection depending on persistence style.

Index alignment: extract equality/range/order predicates and map them to indexes. If no index exists, record full_scan_risk and rationale instead of hiding the risk.
