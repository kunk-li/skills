---
name: repository-draft-generation
description: Draft repository or data-access code from entities, schemas, and query goals — query methods, dynamic queries, pagination contracts, N+1 checks, index alignment, ORM style.
---

# Repository Draft Generation

## Purpose

Generate a reusable repository code-generation contract. Keep this skill generic, contract-first, and honest about evidence. This v2.3 version keeps the v2.2.1 node-agnostic design and adds v2 reactive workflow anchors, structured selected_mode, delivery checklist, scoring rubric, and clearer minimum-input degradation rules.


## Workflow anchors

```yaml
function_bias: direct_result
workflow_node: N190
node_artifact_target: source_tree_contribution   # 默认 source_tree_write;draft_package 模式退化为 Repository草稿.zip
output_target_mode: source_tree_write            # source_tree_write(默认·持续开发) | draft_package(一次性 greenfield)
generation_scope: incremental                    # incremental(默认·只产/patch 目标功能相关文件) | full(整层批量)
node_artifact_role: code_draft for N190 coding scaffold stage
composition_policy: standalone_first_composable_stronger
content_identity: stable_skill_name_not_archive_number
event_aggregation_note: >
    This skill does not publish its own produced event directly to the event bus.
  The N190 node orchestrator (or scaffold-package-aggregator when present)
  is responsible for emitting produced.N190.scaffold_package after all four
  N190 skills complete. Each skill contributes its artifact_contract to that
  aggregation step.
```

## 产物落地模型 / Output target model（v2.1 新增·CAND-A3-CODEGEN-01 折叠）

codegen 类 skill 的产物是**对一棵共享模块源码树的贡献**,不是各自一个 zip 包。两种模式:

- **`source_tree_write`(默认·持续开发)**:把生成的 .java/.sql 等**就地写入调用方给定的共享源码树**,按包路径落位(如 `<module_root>/src/main/java/<pkg>/...`)。产物身份 = 被写/改文件的清单(`written_files[]` / `patched_files[]`),不是 zip。zip 仅在分发时可选打包,**不作为 node artifact 身份**(与 v2-contract「zip 文件名只是分发期提示」一致)。
- **`draft_package`(一次性 greenfield)**:无既有树时,才退化为打成一个 `Repository草稿.zip` 草稿包供 review。**此模式仅用于从零起、无共享树的场景**。

**生成粒度 `generation_scope`**:
- **`incremental`(默认)**:调用方给定**目标范围**(一个功能 / 一个实体 / 一组接口),只生成或修改**与该目标相关的文件**;先探测共享树里是否已存在同名类——**已存在则不覆盖**,改为输出 patch/diff 或就地增强并在 `patched_files[]` 标注,其余文件一律不碰。
- **`full`**:整层批量生成(仅 greenfield 或用户显式要求整层重建时用)。

**去重叠铁律(no-duplication)**:不得重复生成本 N190/N200 家族其它 skill 已贡献进共享树的类(scaffold 已产的 enum / exception / base 类等)。检测到已有 → **补齐缺的 / 就地增强,不另起一份**,避免同一类在多个产物里各一份。

产物落地后必须在 `artifact_contract` 里如实列 `output_target_mode` / `generation_scope` / `written_files[]` / `patched_files[]` / `skipped_existing[]`。



## Selected mode / mode selection

Every result must declare `selected_mode`, `readiness`, and `evidence_profile` inside the `artifact_contract` block.

Allowed modes:
- `quick_repository` — single repository draft from one entity; minimal query methods.
- `full_repository` — default mode; emit complete repository with CRUD, query methods, pagination, dynamic conditions, and transaction hints.
- `query_focused` — expand query methods only when service layer or query-optimization-recommendation provides query goals.
- `migration_mode` — port existing repositories to a new ORM/dialect/pagination convention without reinventing schema.

## Readiness 决策表

| readiness | 触发条件 | 输出策略 |
|---|---|---|
| `pass` | 推荐输入全部齐备；技术栈明确；无未解决冲突 | 完整产物 + 所有契约字段填写 |
| `provisional` | 核心输入齐备；推荐输入部分缺失 | 输出已知层；缺失层进 `pending[]`；`evidence_profile: mixed` |
| `constrained` | 仅有描述性文字；无结构化输入文件 | 从文字提取意图；所有字段标 `inferred`；`tech_stack_declaration: pending` |
| `blocked` | 无任何可用输入 | 输出 `request_for_inputs[]`；列明最小输入要求 |

## Required v2 reactive output blocks

Every output must begin with the following YAML block:

```yaml
artifact_contract:
  schema_version: n190.artifact.v2.3
  producer_skill: repository-draft-generation
  producer_node: N190
  output_target_mode: source_tree_write | draft_package   # 默认 source_tree_write
  generation_scope: incremental | full                    # 默认 incremental
  artifact_name: source_tree_contribution                 # draft_package 模式=Repository草稿.zip
  artifact_type: code_source_contribution | code_draft
  written_files: []
  patched_files: []
  skipped_existing: []
  target_scope: "<incremental 时:本次目标功能/实体/接口>"
  artifact_type: code_draft
  readiness: pass | provisional | constrained | blocked
  evidence_profile: direct_contract | inferred_from_schema | heuristic_only | mixed
  source_inputs: []
  production_boundary_manifest:
    - boundary_id: ""
      boundary_type: db | cache | search | object_store | external_source
      production_surface: ""
      repository_refs: []
      schema_refs: []
      required_evidence: []
      release_critical: true | false
      evidence_tier_required: production_external_integration
      handoff_to: [N240, N260, N270]
  read_side_security_filters:
    - filter_id: ""
      query_ref: ""
      protected_resource: ""
      predicate_source_ref: ""
      filter_predicates: []
      allowed_case_refs: []
      denied_case_refs: []
      privileged_bypass_case_refs: []
      handoff_to: [N240, N260]
  downstream_consumers: [N200, N210, N330]
  traces_to_tasks: []

self_gate:
  status: pass | warn | block
  failed_rules: []
  warnings: []
  pending: []

quality_self_score:
  scale: 0_to_2_per_dimension
  dimensions:
    standalone_usability: null
    contract_completeness: null
    uncertainty_handling: null
    downstream_handoff: null
  overall_level: S | A | B | C
```

## Genericity rule

This skill is a reusable atomic capability. Do not bind its instructions or outputs to a workflow node id, stage id, downstream node id, or node-specific filename. When a workflow node uses this skill, put node routing, aggregation, event publication, and downstream naming in the node orchestrator, not in this skill.


## Input classification

### minimum / core_required (at least one required)
- `表结构设计草案.sql` (from N160) — entity/table schema
- `数据对象清单.csv` (from N070) — domain objects
- entity or table definition text

If none are present: set `readiness: blocked`, output only a skeleton template with all fields `pending`.

### recommended (workflow-aligned)
- `表结构设计草案.sql` from N160 — table schema and column types
- `索引建议清单.csv` from N160 — index-aware query methods
- `并发控制建议.md` from N170 — locking strategy (optimistic vs pessimistic)
- `接口设计草案.yaml` from N150 — query intent from API needs
- `开发任务拆分表.csv` from N180 — populates `traces_to_tasks[]`

### optional enrichment
- `数据流图.md` from N160 — cross-aggregate data access patterns
- `幂等设计建议.md` from N170 — upsert / insert-if-absent patterns
- ORM configuration, existing repository conventions

### degradation rules
- Missing recommended inputs → `readiness: constrained`; emit only confirmed layers, mark missing layers `pending`.
- Missing `traces_to_tasks` → set to `[]`, note `evidence_profile: heuristic_only`.
- Never invent class names or framework choices without citing the matched input field.
- Missing `并发控制建议` (concurrency-control input) does NOT mean "no locking". When the operation is a read-modify-write on shared mutable persistent state (counter increment, status/state-machine transition, balance/quota/limit update, or insert-if-absent upsert), apply `locking_strategy` rule LS-000 in `repository-algorithms.yaml`: default to a concurrency-safe pattern (SELECT FOR UPDATE / optimistic `@Version` / unique-constraint upsert with duplicate-key handling), never a plain read-then-write, and record the default in `inferred[]`. Silent lock-free RMW is a defect, not an acceptable degradation.
- Read-side security predicates are not optional plumbing. When service/permission/API inputs say a list/search/export/read model must shield, redact, tenant-filter, owner-filter, role-filter, or exclude restricted records, emit `read_side_security_filters[]` and put the predicate into every affected repository/query plan. Repository stays generic: it does not decide authorization; it enforces the predicate supplied by the service/permission contract.



## Enum and schema policy

Load `references/shared-codegen-enums.yaml` before reading or writing any contract field that uses an enum. Use the shared `query_purpose` and `cardinality` enums exactly so sibling skills can compose without manual string mapping. Use neutral schema namespaces such as `skills.codegen.repository.v2.3`; do not use workflow-node ids inside skill-level schema versions.

## Rule source authority

Use YAML contracts as the authoritative source for schemas, enums, algorithms, and self-checks. Treat Markdown reference files as explanatory guides only; when Markdown guidance conflicts with `*-algorithms.yaml`, `*-input-contract.yaml`, `*-output-contract.yaml`, `*-self-check.yaml`, or `shared-codegen-enums.yaml`, follow the YAML file and record the conflict in `pending[]`.

## Execution workflow

1. Load the input contract, output contract, shared enum dictionary, and algorithm table for this skill.
2. Normalize inputs into the field names defined by `references/repository-input-contract.yaml`.
3. Apply the structured algorithms in `references/repository-algorithms.yaml`. When a decision is inferred, cite the matched rule id in `inferred[]` or the relevant contract field.
4. Emit `repository_contract` using `references/repository-output-contract.yaml`. Include all required fields even when values are `pending`.
5. Emit `production_boundary_manifest[]` for every release-critical persistent/external data boundary so N240 can plan runtime proof and N270 can block release when proof is absent.
6. Emit `read_side_security_filters[]` for query/list/search/export/read-model predicates supplied by service, permission, API, or data-scope inputs.
7. Apply `references/repository-self-check.yaml` and include `self_check_result.passed`, `warnings`, and `blockers`.
8. Add human-readable notes only after the machine-readable contract.

## Output contract

Every output must start with a YAML block named `artifact_contract`. Never claim `build_verified` unless a build/test command was actually run and evidence is shown. Put assumptions in `inferred[]` and unknowns in `pending[]` instead of silently inventing facts.

## Produced event / 产物事件

本 skill 是 N190 节点的子技能，产物交由 `scaffold-package-aggregator` 聚合后统一发布节点级事件：

```yaml
event_emission:
  emitted_by: standalone_skill
  node_event_publisher: scaffold-package-aggregator
  artifact_contract_field: artifact_contract.readiness
  artifact_name: source_tree_contribution   # draft_package 模式为 Repository草稿.zip
  downstream_consumers: [N200, N210, N240, N330]
  note: >
    本 skill 不自行发布 produced.n190.scaffold_package 事件。
    完成后通知 scaffold-package-aggregator 消费 artifact_contract，由聚合器决定节点 readiness。
```

## Boundary

Use the boundary rules in the output and self-check contracts. This skill should emit its own layer contract and sibling handoff hints, but should not take responsibility for node-level aggregation or unrelated architectural layers.

## Composition

When a sibling contract is supplied, consume it explicitly and name the exact fields used. When this skill emits handoff hints for a sibling skill, use the structured contract fields and shared enum dictionary rather than prose-only handoff. For inconsistent sibling contracts, record the mismatch in `pending[]` or `self_check_result.blockers` according to the self-check severity.


## Tech stack adapter

Output defaults to Java (Spring Boot / Spring MVC) examples. Switch adapters when context indicates a different stack:

| Stack | Repository conventions |
|---|---|
| Java / Spring Data JPA | `JpaRepository<Entity, ID>`, `@Query`, `Specification`, `@Lock` |
| Java / Spring Data R2DBC | `ReactiveCrudRepository`, reactive query methods |
| Java / MyBatis | Mapper interface + XML/annotation SQL, `@Options`, ResultMap |
| TypeScript / TypeORM | `Repository<Entity>`, `QueryBuilder`, `findOne`/`find` options |
| TypeScript / Prisma | `prisma.model.findMany`, `$queryRaw`, transaction client |
| Python / SQLAlchemy | `Session.query` / `select()`, `async_session` for async |
| Go / GORM | `db.Where().Find()`, raw SQL with `db.Raw()`, scopes |
| Read replica routing | Declare `read_replica_hint: true` on read-only methods; route via `@Transactional(readOnly=true)` or datasource router |

Never present a Java-only solution as universal. If the stack is unknown, output neutral placeholders and record `stack_declaration: pending`.

**N+1 risk hints declared here feed into N200 query-optimization-recommendation; expose `n_plus_one_candidates[]` in downstream_handoff.**

## Inline scoring rubric

每次输出完成后，用以下标准自评 `quality_self_score`：

| 维度 | 2分（满分） | 1分（部分） | 0分（缺失） |
|---|---|---|---|
| `standalone_usability` | 最小输入即可执行，输出可独立使用 | 依赖推荐输入才可用 | 无最小输入也无法降级 |
| `contract_completeness` | artifact_contract 所有字段填写，无 null 留白 | 关键字段已填，部分 pending | 超过 30% 字段为 null |
| `uncertainty_handling` | 所有推断进 inferred[]，未知进 pending[]，不发明事实 | 部分推断未标注 | 静默发明类名/框架 |
| `downstream_handoff` | sibling 字段引用精确，下游可直接消费 | 有 handoff 但字段模糊 | 无 downstream_handoff |

`overall_level` 映射：8分=S，6-7分=A，4-5分=B，<4分=C。`quality_self_score` 必须在 `self_gate` 之后、人类可读说明之前输出。

## Machine-readable self_check rules

- `R01_artifact_contract_first`: 每次输出必须以 `artifact_contract` YAML 块开头; `on_violation: reject`
- `R02_readiness_set`: `readiness` 必须是 `pass | provisional | constrained | blocked` 之一; `on_violation: reject`
- `R03_no_invented_names`: 未引用输入字段时不得臆造类名/包名/框架选型; `on_violation: reject`
- `R04_build_verified_evidence`: 声明 `build_verified` 必须附实际执行命令和输出作为证据; `on_violation: reject`
- `R05_pending_not_silent`: 未知值必须进入 `pending[]`，不得静默省略; `on_violation: reject`
- `R06_tech_stack_declared`: `stack_declaration` 必须明确声明或标为 `pending`; `on_violation: warn`
- `R07_traces_to_tasks_set`: `traces_to_tasks[]` 必须引用 N180 task_id 或显式设为 `[]` 并注明 `evidence_profile`; `on_violation: warn`
- `R08_sibling_conflict_recorded`: 兄弟 skill 契约冲突必须进入 `pending[]` 或 `self_gate.failed_rules[]`，不得静默覆盖; `on_violation: reject`
- `R12_production_boundary_manifest`: release-critical repository / mapper / external-source access must emit `production_boundary_manifest[]` with boundary id, boundary type, production surface, repository/schema refs, required evidence and `evidence_tier_required=production_external_integration`; local/in-memory proof may be recorded only as lower-tier evidence, never as release clearance; `on_violation: reject`

## Common failure modes

1. **Stack assumption leak** — 未声明 `stack_declaration` 就默认输出 Java-only 方案，非 Java 项目无法使用。修复：先检查上下文中的框架标志（`pom.xml`/`package.json`/`go.mod`），未知时设 `stack_declaration: pending`。
2. **Silent invention** — 缺少输入时臆造类名或包路径，导致下游编译失败。修复：所有推断值写入 `inferred[]` 并引用触发的输入字段；无对应字段时进入 `pending[]`。
3. **Missing readiness gate** — 推荐输入全部缺失时仍输出 `readiness: pass`，误导下游节点认为产物可直接使用。修复：执行输入分类后强制重算 `readiness`。
4. **Runtime boundary disappears** — repository methods are emitted, but no downstream artifact knows that DB/mapper/index/lock proof is still release-critical. Fix: emit `production_boundary_manifest[]` and hand it to N240/N260/N270; do not let compile/unit/local smoke evidence stand in for production DB or external-source proof.

## References

- `references/shared-codegen-enums.yaml`: canonical enum dictionary for all four code-generation skills
- `references/repository-input-contract.yaml`: field-level input schema and normalization rules
- `references/repository-output-contract.yaml`: required output schema and field contract
- `references/repository-self-check.yaml`: executable quality checks and violation policy
- `references/repository-algorithms.yaml`: structured decision tables and algorithms
- `references/persistence-convention-guide.md`: domain-specific generation guidance
- `references/example-io.md`: concrete input/output example
- `references/routing-metadata.yaml`: optional platform scheduling metadata
- `references/checklist.md`: delivery checklist for self-review before emit
- `references/scoring-rubric.md`: 4-dimension self-scoring rubric (S/A/B/C)
- `references/common-failure-modes.md`: detailed failure mode catalog with symptom/impact/fix
- `references/orchestration.md`: upstream priority, downstream handoff, field-level mapping, mode-specific orchestration


## Language-agnostic artifact packaging(CAND-B5 · 2026-07-18)

本 skill 的产物是「repository / 持久化层的一组源文件」,打包为**语言无关容器** `Repository草稿.zip`,而非单个语言专属文件。

- **不写死语言后缀**:容器内文件的语言与后缀由 `tech_stack.language` 决定(见 `references/shared-codegen-enums.yaml` 的 language 枚举:java / go / node / python / rust / kotlin / other)—— 落地为 `.java` / `.py` / `.go` / `.ts` / `.rs` / `.kt` / … 。这遵守本 skill 的 Genericity rule(不绑定 node-specific / 语言专属文件名)。
- **为什么是容器不是单文件**:真实模块的repository / 持久化层通常是多个文件(多个类 / 多个源文件);单个 `.java` 既装不下多类、又把实现语言写死。容器形态与本节点已有的 058 `工程骨架.zip` / 062 `DTO_VO草稿.zip` 一致。
- **落地**:每个文件的路径 / 包 / 后缀遵循 `tech_stack` 的 package_layout 与 language 约定;由节点编排(如 scaffold-package-aggregator)合成到完整工程。
- **历史**:此前产物名写死 `.java`,与库的多语言 `shared.language` 枚举 + 本 skill 的通用性声明矛盾(非 java 团队用此节点产不出对的东西);已改为语言无关容器。
